<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-31 02:29:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 02:29:11 --> Config Class Initialized
INFO - 2023-10-31 02:29:11 --> Hooks Class Initialized
DEBUG - 2023-10-31 02:29:11 --> UTF-8 Support Enabled
INFO - 2023-10-31 02:29:11 --> Utf8 Class Initialized
INFO - 2023-10-31 02:29:11 --> URI Class Initialized
DEBUG - 2023-10-31 02:29:11 --> No URI present. Default controller set.
INFO - 2023-10-31 02:29:11 --> Router Class Initialized
INFO - 2023-10-31 02:29:11 --> Output Class Initialized
INFO - 2023-10-31 02:29:11 --> Security Class Initialized
DEBUG - 2023-10-31 02:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 02:29:11 --> Input Class Initialized
INFO - 2023-10-31 02:29:11 --> Language Class Initialized
INFO - 2023-10-31 02:29:11 --> Loader Class Initialized
INFO - 2023-10-31 02:29:11 --> Helper loaded: url_helper
INFO - 2023-10-31 02:29:11 --> Helper loaded: file_helper
INFO - 2023-10-31 02:29:11 --> Helper loaded: html_helper
INFO - 2023-10-31 02:29:11 --> Helper loaded: text_helper
INFO - 2023-10-31 02:29:11 --> Helper loaded: form_helper
INFO - 2023-10-31 02:29:11 --> Helper loaded: lang_helper
INFO - 2023-10-31 02:29:11 --> Helper loaded: security_helper
INFO - 2023-10-31 02:29:11 --> Helper loaded: cookie_helper
INFO - 2023-10-31 02:29:11 --> Database Driver Class Initialized
INFO - 2023-10-31 02:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 02:29:11 --> Parser Class Initialized
INFO - 2023-10-31 02:29:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 02:29:11 --> Pagination Class Initialized
INFO - 2023-10-31 02:29:11 --> Form Validation Class Initialized
INFO - 2023-10-31 02:29:11 --> Controller Class Initialized
INFO - 2023-10-31 02:29:11 --> Model Class Initialized
DEBUG - 2023-10-31 02:29:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-31 02:29:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 02:29:11 --> Config Class Initialized
INFO - 2023-10-31 02:29:11 --> Hooks Class Initialized
DEBUG - 2023-10-31 02:29:11 --> UTF-8 Support Enabled
INFO - 2023-10-31 02:29:11 --> Utf8 Class Initialized
INFO - 2023-10-31 02:29:11 --> URI Class Initialized
INFO - 2023-10-31 02:29:11 --> Router Class Initialized
INFO - 2023-10-31 02:29:11 --> Output Class Initialized
INFO - 2023-10-31 02:29:11 --> Security Class Initialized
DEBUG - 2023-10-31 02:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 02:29:11 --> Input Class Initialized
INFO - 2023-10-31 02:29:11 --> Language Class Initialized
INFO - 2023-10-31 02:29:11 --> Loader Class Initialized
INFO - 2023-10-31 02:29:11 --> Helper loaded: url_helper
INFO - 2023-10-31 02:29:11 --> Helper loaded: file_helper
INFO - 2023-10-31 02:29:11 --> Helper loaded: html_helper
INFO - 2023-10-31 02:29:11 --> Helper loaded: text_helper
INFO - 2023-10-31 02:29:11 --> Helper loaded: form_helper
INFO - 2023-10-31 02:29:11 --> Helper loaded: lang_helper
INFO - 2023-10-31 02:29:11 --> Helper loaded: security_helper
INFO - 2023-10-31 02:29:11 --> Helper loaded: cookie_helper
INFO - 2023-10-31 02:29:11 --> Database Driver Class Initialized
INFO - 2023-10-31 02:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 02:29:11 --> Parser Class Initialized
INFO - 2023-10-31 02:29:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 02:29:11 --> Pagination Class Initialized
INFO - 2023-10-31 02:29:11 --> Form Validation Class Initialized
INFO - 2023-10-31 02:29:11 --> Controller Class Initialized
INFO - 2023-10-31 02:29:11 --> Model Class Initialized
DEBUG - 2023-10-31 02:29:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:29:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-31 02:29:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:29:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 02:29:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 02:29:11 --> Model Class Initialized
INFO - 2023-10-31 02:29:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 02:29:11 --> Final output sent to browser
DEBUG - 2023-10-31 02:29:11 --> Total execution time: 0.0371
ERROR - 2023-10-31 02:29:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 02:29:14 --> Config Class Initialized
INFO - 2023-10-31 02:29:14 --> Hooks Class Initialized
DEBUG - 2023-10-31 02:29:14 --> UTF-8 Support Enabled
INFO - 2023-10-31 02:29:14 --> Utf8 Class Initialized
INFO - 2023-10-31 02:29:14 --> URI Class Initialized
INFO - 2023-10-31 02:29:14 --> Router Class Initialized
INFO - 2023-10-31 02:29:14 --> Output Class Initialized
INFO - 2023-10-31 02:29:14 --> Security Class Initialized
DEBUG - 2023-10-31 02:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 02:29:14 --> Input Class Initialized
INFO - 2023-10-31 02:29:14 --> Language Class Initialized
INFO - 2023-10-31 02:29:14 --> Loader Class Initialized
INFO - 2023-10-31 02:29:14 --> Helper loaded: url_helper
INFO - 2023-10-31 02:29:14 --> Helper loaded: file_helper
INFO - 2023-10-31 02:29:14 --> Helper loaded: html_helper
INFO - 2023-10-31 02:29:14 --> Helper loaded: text_helper
INFO - 2023-10-31 02:29:14 --> Helper loaded: form_helper
INFO - 2023-10-31 02:29:14 --> Helper loaded: lang_helper
INFO - 2023-10-31 02:29:14 --> Helper loaded: security_helper
INFO - 2023-10-31 02:29:14 --> Helper loaded: cookie_helper
INFO - 2023-10-31 02:29:14 --> Database Driver Class Initialized
INFO - 2023-10-31 02:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 02:29:14 --> Parser Class Initialized
INFO - 2023-10-31 02:29:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 02:29:14 --> Pagination Class Initialized
INFO - 2023-10-31 02:29:14 --> Form Validation Class Initialized
INFO - 2023-10-31 02:29:14 --> Controller Class Initialized
INFO - 2023-10-31 02:29:14 --> Model Class Initialized
DEBUG - 2023-10-31 02:29:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:29:14 --> Model Class Initialized
INFO - 2023-10-31 02:29:14 --> Final output sent to browser
DEBUG - 2023-10-31 02:29:14 --> Total execution time: 0.0186
ERROR - 2023-10-31 02:29:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 02:29:15 --> Config Class Initialized
INFO - 2023-10-31 02:29:15 --> Hooks Class Initialized
DEBUG - 2023-10-31 02:29:15 --> UTF-8 Support Enabled
INFO - 2023-10-31 02:29:15 --> Utf8 Class Initialized
INFO - 2023-10-31 02:29:15 --> URI Class Initialized
DEBUG - 2023-10-31 02:29:15 --> No URI present. Default controller set.
INFO - 2023-10-31 02:29:15 --> Router Class Initialized
INFO - 2023-10-31 02:29:15 --> Output Class Initialized
INFO - 2023-10-31 02:29:15 --> Security Class Initialized
DEBUG - 2023-10-31 02:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 02:29:15 --> Input Class Initialized
INFO - 2023-10-31 02:29:15 --> Language Class Initialized
INFO - 2023-10-31 02:29:15 --> Loader Class Initialized
INFO - 2023-10-31 02:29:15 --> Helper loaded: url_helper
INFO - 2023-10-31 02:29:15 --> Helper loaded: file_helper
INFO - 2023-10-31 02:29:15 --> Helper loaded: html_helper
INFO - 2023-10-31 02:29:15 --> Helper loaded: text_helper
INFO - 2023-10-31 02:29:15 --> Helper loaded: form_helper
INFO - 2023-10-31 02:29:15 --> Helper loaded: lang_helper
INFO - 2023-10-31 02:29:15 --> Helper loaded: security_helper
INFO - 2023-10-31 02:29:15 --> Helper loaded: cookie_helper
INFO - 2023-10-31 02:29:15 --> Database Driver Class Initialized
INFO - 2023-10-31 02:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 02:29:15 --> Parser Class Initialized
INFO - 2023-10-31 02:29:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 02:29:15 --> Pagination Class Initialized
INFO - 2023-10-31 02:29:15 --> Form Validation Class Initialized
INFO - 2023-10-31 02:29:15 --> Controller Class Initialized
INFO - 2023-10-31 02:29:15 --> Model Class Initialized
DEBUG - 2023-10-31 02:29:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:29:15 --> Model Class Initialized
DEBUG - 2023-10-31 02:29:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:29:15 --> Model Class Initialized
INFO - 2023-10-31 02:29:15 --> Model Class Initialized
INFO - 2023-10-31 02:29:15 --> Model Class Initialized
INFO - 2023-10-31 02:29:15 --> Model Class Initialized
DEBUG - 2023-10-31 02:29:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 02:29:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:29:15 --> Model Class Initialized
INFO - 2023-10-31 02:29:15 --> Model Class Initialized
INFO - 2023-10-31 02:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-31 02:29:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 02:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 02:29:15 --> Model Class Initialized
INFO - 2023-10-31 02:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 02:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 02:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 02:29:15 --> Final output sent to browser
DEBUG - 2023-10-31 02:29:15 --> Total execution time: 0.3674
ERROR - 2023-10-31 02:29:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 02:29:16 --> Config Class Initialized
INFO - 2023-10-31 02:29:16 --> Hooks Class Initialized
DEBUG - 2023-10-31 02:29:16 --> UTF-8 Support Enabled
INFO - 2023-10-31 02:29:16 --> Utf8 Class Initialized
INFO - 2023-10-31 02:29:16 --> URI Class Initialized
INFO - 2023-10-31 02:29:16 --> Router Class Initialized
INFO - 2023-10-31 02:29:16 --> Output Class Initialized
INFO - 2023-10-31 02:29:16 --> Security Class Initialized
DEBUG - 2023-10-31 02:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 02:29:16 --> Input Class Initialized
INFO - 2023-10-31 02:29:16 --> Language Class Initialized
INFO - 2023-10-31 02:29:16 --> Loader Class Initialized
INFO - 2023-10-31 02:29:16 --> Helper loaded: url_helper
INFO - 2023-10-31 02:29:16 --> Helper loaded: file_helper
INFO - 2023-10-31 02:29:16 --> Helper loaded: html_helper
INFO - 2023-10-31 02:29:16 --> Helper loaded: text_helper
INFO - 2023-10-31 02:29:16 --> Helper loaded: form_helper
INFO - 2023-10-31 02:29:16 --> Helper loaded: lang_helper
INFO - 2023-10-31 02:29:16 --> Helper loaded: security_helper
INFO - 2023-10-31 02:29:16 --> Helper loaded: cookie_helper
INFO - 2023-10-31 02:29:16 --> Database Driver Class Initialized
INFO - 2023-10-31 02:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 02:29:16 --> Parser Class Initialized
INFO - 2023-10-31 02:29:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 02:29:16 --> Pagination Class Initialized
INFO - 2023-10-31 02:29:16 --> Form Validation Class Initialized
INFO - 2023-10-31 02:29:16 --> Controller Class Initialized
DEBUG - 2023-10-31 02:29:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 02:29:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:29:16 --> Model Class Initialized
INFO - 2023-10-31 02:29:16 --> Final output sent to browser
DEBUG - 2023-10-31 02:29:16 --> Total execution time: 0.0126
ERROR - 2023-10-31 02:29:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 02:29:54 --> Config Class Initialized
INFO - 2023-10-31 02:29:54 --> Hooks Class Initialized
DEBUG - 2023-10-31 02:29:54 --> UTF-8 Support Enabled
INFO - 2023-10-31 02:29:54 --> Utf8 Class Initialized
INFO - 2023-10-31 02:29:54 --> URI Class Initialized
DEBUG - 2023-10-31 02:29:54 --> No URI present. Default controller set.
INFO - 2023-10-31 02:29:54 --> Router Class Initialized
INFO - 2023-10-31 02:29:54 --> Output Class Initialized
INFO - 2023-10-31 02:29:54 --> Security Class Initialized
DEBUG - 2023-10-31 02:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 02:29:54 --> Input Class Initialized
INFO - 2023-10-31 02:29:54 --> Language Class Initialized
INFO - 2023-10-31 02:29:54 --> Loader Class Initialized
INFO - 2023-10-31 02:29:54 --> Helper loaded: url_helper
INFO - 2023-10-31 02:29:54 --> Helper loaded: file_helper
INFO - 2023-10-31 02:29:54 --> Helper loaded: html_helper
INFO - 2023-10-31 02:29:54 --> Helper loaded: text_helper
INFO - 2023-10-31 02:29:54 --> Helper loaded: form_helper
INFO - 2023-10-31 02:29:54 --> Helper loaded: lang_helper
INFO - 2023-10-31 02:29:54 --> Helper loaded: security_helper
INFO - 2023-10-31 02:29:54 --> Helper loaded: cookie_helper
INFO - 2023-10-31 02:29:54 --> Database Driver Class Initialized
INFO - 2023-10-31 02:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 02:29:54 --> Parser Class Initialized
INFO - 2023-10-31 02:29:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 02:29:54 --> Pagination Class Initialized
INFO - 2023-10-31 02:29:54 --> Form Validation Class Initialized
INFO - 2023-10-31 02:29:54 --> Controller Class Initialized
INFO - 2023-10-31 02:29:54 --> Model Class Initialized
DEBUG - 2023-10-31 02:29:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-31 02:29:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 02:29:54 --> Config Class Initialized
INFO - 2023-10-31 02:29:54 --> Hooks Class Initialized
DEBUG - 2023-10-31 02:29:54 --> UTF-8 Support Enabled
INFO - 2023-10-31 02:29:54 --> Utf8 Class Initialized
INFO - 2023-10-31 02:29:54 --> URI Class Initialized
INFO - 2023-10-31 02:29:54 --> Router Class Initialized
INFO - 2023-10-31 02:29:54 --> Output Class Initialized
INFO - 2023-10-31 02:29:54 --> Security Class Initialized
DEBUG - 2023-10-31 02:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 02:29:54 --> Input Class Initialized
INFO - 2023-10-31 02:29:54 --> Language Class Initialized
INFO - 2023-10-31 02:29:54 --> Loader Class Initialized
INFO - 2023-10-31 02:29:54 --> Helper loaded: url_helper
INFO - 2023-10-31 02:29:54 --> Helper loaded: file_helper
INFO - 2023-10-31 02:29:54 --> Helper loaded: html_helper
INFO - 2023-10-31 02:29:54 --> Helper loaded: text_helper
INFO - 2023-10-31 02:29:54 --> Helper loaded: form_helper
INFO - 2023-10-31 02:29:54 --> Helper loaded: lang_helper
INFO - 2023-10-31 02:29:54 --> Helper loaded: security_helper
INFO - 2023-10-31 02:29:54 --> Helper loaded: cookie_helper
INFO - 2023-10-31 02:29:54 --> Database Driver Class Initialized
INFO - 2023-10-31 02:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 02:29:54 --> Parser Class Initialized
INFO - 2023-10-31 02:29:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 02:29:54 --> Pagination Class Initialized
INFO - 2023-10-31 02:29:54 --> Form Validation Class Initialized
INFO - 2023-10-31 02:29:54 --> Controller Class Initialized
INFO - 2023-10-31 02:29:54 --> Model Class Initialized
DEBUG - 2023-10-31 02:29:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:29:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-31 02:29:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:29:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 02:29:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 02:29:54 --> Model Class Initialized
INFO - 2023-10-31 02:29:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 02:29:54 --> Final output sent to browser
DEBUG - 2023-10-31 02:29:54 --> Total execution time: 0.0331
ERROR - 2023-10-31 02:29:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 02:29:59 --> Config Class Initialized
INFO - 2023-10-31 02:29:59 --> Hooks Class Initialized
DEBUG - 2023-10-31 02:29:59 --> UTF-8 Support Enabled
INFO - 2023-10-31 02:29:59 --> Utf8 Class Initialized
INFO - 2023-10-31 02:29:59 --> URI Class Initialized
INFO - 2023-10-31 02:29:59 --> Router Class Initialized
INFO - 2023-10-31 02:29:59 --> Output Class Initialized
INFO - 2023-10-31 02:29:59 --> Security Class Initialized
DEBUG - 2023-10-31 02:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 02:29:59 --> Input Class Initialized
INFO - 2023-10-31 02:29:59 --> Language Class Initialized
INFO - 2023-10-31 02:29:59 --> Loader Class Initialized
INFO - 2023-10-31 02:29:59 --> Helper loaded: url_helper
INFO - 2023-10-31 02:29:59 --> Helper loaded: file_helper
INFO - 2023-10-31 02:29:59 --> Helper loaded: html_helper
INFO - 2023-10-31 02:29:59 --> Helper loaded: text_helper
INFO - 2023-10-31 02:29:59 --> Helper loaded: form_helper
INFO - 2023-10-31 02:29:59 --> Helper loaded: lang_helper
INFO - 2023-10-31 02:29:59 --> Helper loaded: security_helper
INFO - 2023-10-31 02:29:59 --> Helper loaded: cookie_helper
INFO - 2023-10-31 02:29:59 --> Database Driver Class Initialized
INFO - 2023-10-31 02:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 02:29:59 --> Parser Class Initialized
INFO - 2023-10-31 02:29:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 02:29:59 --> Pagination Class Initialized
INFO - 2023-10-31 02:29:59 --> Form Validation Class Initialized
INFO - 2023-10-31 02:29:59 --> Controller Class Initialized
INFO - 2023-10-31 02:29:59 --> Model Class Initialized
DEBUG - 2023-10-31 02:29:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:29:59 --> Model Class Initialized
INFO - 2023-10-31 02:29:59 --> Final output sent to browser
DEBUG - 2023-10-31 02:29:59 --> Total execution time: 0.0179
ERROR - 2023-10-31 02:29:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 02:29:59 --> Config Class Initialized
INFO - 2023-10-31 02:29:59 --> Hooks Class Initialized
DEBUG - 2023-10-31 02:29:59 --> UTF-8 Support Enabled
INFO - 2023-10-31 02:29:59 --> Utf8 Class Initialized
INFO - 2023-10-31 02:29:59 --> URI Class Initialized
DEBUG - 2023-10-31 02:29:59 --> No URI present. Default controller set.
INFO - 2023-10-31 02:29:59 --> Router Class Initialized
INFO - 2023-10-31 02:29:59 --> Output Class Initialized
INFO - 2023-10-31 02:29:59 --> Security Class Initialized
DEBUG - 2023-10-31 02:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 02:29:59 --> Input Class Initialized
INFO - 2023-10-31 02:29:59 --> Language Class Initialized
INFO - 2023-10-31 02:29:59 --> Loader Class Initialized
INFO - 2023-10-31 02:29:59 --> Helper loaded: url_helper
INFO - 2023-10-31 02:29:59 --> Helper loaded: file_helper
INFO - 2023-10-31 02:29:59 --> Helper loaded: html_helper
INFO - 2023-10-31 02:29:59 --> Helper loaded: text_helper
INFO - 2023-10-31 02:29:59 --> Helper loaded: form_helper
INFO - 2023-10-31 02:29:59 --> Helper loaded: lang_helper
INFO - 2023-10-31 02:29:59 --> Helper loaded: security_helper
INFO - 2023-10-31 02:29:59 --> Helper loaded: cookie_helper
INFO - 2023-10-31 02:29:59 --> Database Driver Class Initialized
INFO - 2023-10-31 02:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 02:29:59 --> Parser Class Initialized
INFO - 2023-10-31 02:29:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 02:29:59 --> Pagination Class Initialized
INFO - 2023-10-31 02:29:59 --> Form Validation Class Initialized
INFO - 2023-10-31 02:29:59 --> Controller Class Initialized
INFO - 2023-10-31 02:29:59 --> Model Class Initialized
DEBUG - 2023-10-31 02:29:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:29:59 --> Model Class Initialized
DEBUG - 2023-10-31 02:29:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:29:59 --> Model Class Initialized
INFO - 2023-10-31 02:29:59 --> Model Class Initialized
INFO - 2023-10-31 02:29:59 --> Model Class Initialized
INFO - 2023-10-31 02:29:59 --> Model Class Initialized
DEBUG - 2023-10-31 02:29:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 02:29:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:29:59 --> Model Class Initialized
INFO - 2023-10-31 02:29:59 --> Model Class Initialized
INFO - 2023-10-31 02:29:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-31 02:29:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:29:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 02:29:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 02:29:59 --> Model Class Initialized
INFO - 2023-10-31 02:29:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 02:29:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 02:29:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 02:29:59 --> Final output sent to browser
DEBUG - 2023-10-31 02:29:59 --> Total execution time: 0.2027
ERROR - 2023-10-31 02:30:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 02:30:09 --> Config Class Initialized
INFO - 2023-10-31 02:30:09 --> Hooks Class Initialized
DEBUG - 2023-10-31 02:30:09 --> UTF-8 Support Enabled
INFO - 2023-10-31 02:30:09 --> Utf8 Class Initialized
INFO - 2023-10-31 02:30:09 --> URI Class Initialized
INFO - 2023-10-31 02:30:09 --> Router Class Initialized
INFO - 2023-10-31 02:30:09 --> Output Class Initialized
INFO - 2023-10-31 02:30:09 --> Security Class Initialized
DEBUG - 2023-10-31 02:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 02:30:09 --> Input Class Initialized
INFO - 2023-10-31 02:30:09 --> Language Class Initialized
INFO - 2023-10-31 02:30:09 --> Loader Class Initialized
INFO - 2023-10-31 02:30:09 --> Helper loaded: url_helper
INFO - 2023-10-31 02:30:09 --> Helper loaded: file_helper
INFO - 2023-10-31 02:30:09 --> Helper loaded: html_helper
INFO - 2023-10-31 02:30:09 --> Helper loaded: text_helper
INFO - 2023-10-31 02:30:09 --> Helper loaded: form_helper
INFO - 2023-10-31 02:30:09 --> Helper loaded: lang_helper
INFO - 2023-10-31 02:30:09 --> Helper loaded: security_helper
INFO - 2023-10-31 02:30:09 --> Helper loaded: cookie_helper
INFO - 2023-10-31 02:30:09 --> Database Driver Class Initialized
INFO - 2023-10-31 02:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 02:30:09 --> Parser Class Initialized
INFO - 2023-10-31 02:30:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 02:30:09 --> Pagination Class Initialized
INFO - 2023-10-31 02:30:09 --> Form Validation Class Initialized
INFO - 2023-10-31 02:30:09 --> Controller Class Initialized
DEBUG - 2023-10-31 02:30:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 02:30:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:30:09 --> Model Class Initialized
DEBUG - 2023-10-31 02:30:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:30:09 --> Model Class Initialized
DEBUG - 2023-10-31 02:30:09 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:30:09 --> Model Class Initialized
INFO - 2023-10-31 02:30:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-10-31 02:30:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:30:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 02:30:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 02:30:09 --> Model Class Initialized
INFO - 2023-10-31 02:30:09 --> Model Class Initialized
INFO - 2023-10-31 02:30:09 --> Model Class Initialized
INFO - 2023-10-31 02:30:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 02:30:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 02:30:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 02:30:09 --> Final output sent to browser
DEBUG - 2023-10-31 02:30:09 --> Total execution time: 0.1537
ERROR - 2023-10-31 02:30:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 02:30:09 --> Config Class Initialized
INFO - 2023-10-31 02:30:09 --> Hooks Class Initialized
DEBUG - 2023-10-31 02:30:09 --> UTF-8 Support Enabled
INFO - 2023-10-31 02:30:09 --> Utf8 Class Initialized
INFO - 2023-10-31 02:30:09 --> URI Class Initialized
INFO - 2023-10-31 02:30:09 --> Router Class Initialized
INFO - 2023-10-31 02:30:09 --> Output Class Initialized
INFO - 2023-10-31 02:30:09 --> Security Class Initialized
DEBUG - 2023-10-31 02:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 02:30:09 --> Input Class Initialized
INFO - 2023-10-31 02:30:09 --> Language Class Initialized
INFO - 2023-10-31 02:30:09 --> Loader Class Initialized
INFO - 2023-10-31 02:30:09 --> Helper loaded: url_helper
INFO - 2023-10-31 02:30:09 --> Helper loaded: file_helper
INFO - 2023-10-31 02:30:09 --> Helper loaded: html_helper
INFO - 2023-10-31 02:30:09 --> Helper loaded: text_helper
INFO - 2023-10-31 02:30:09 --> Helper loaded: form_helper
INFO - 2023-10-31 02:30:09 --> Helper loaded: lang_helper
INFO - 2023-10-31 02:30:09 --> Helper loaded: security_helper
INFO - 2023-10-31 02:30:09 --> Helper loaded: cookie_helper
INFO - 2023-10-31 02:30:09 --> Database Driver Class Initialized
INFO - 2023-10-31 02:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 02:30:09 --> Parser Class Initialized
INFO - 2023-10-31 02:30:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 02:30:09 --> Pagination Class Initialized
INFO - 2023-10-31 02:30:09 --> Form Validation Class Initialized
INFO - 2023-10-31 02:30:09 --> Controller Class Initialized
DEBUG - 2023-10-31 02:30:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 02:30:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:30:09 --> Model Class Initialized
DEBUG - 2023-10-31 02:30:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:30:09 --> Model Class Initialized
INFO - 2023-10-31 02:30:09 --> Final output sent to browser
DEBUG - 2023-10-31 02:30:09 --> Total execution time: 0.0203
ERROR - 2023-10-31 02:30:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 02:30:13 --> Config Class Initialized
INFO - 2023-10-31 02:30:13 --> Hooks Class Initialized
DEBUG - 2023-10-31 02:30:13 --> UTF-8 Support Enabled
INFO - 2023-10-31 02:30:13 --> Utf8 Class Initialized
INFO - 2023-10-31 02:30:13 --> URI Class Initialized
INFO - 2023-10-31 02:30:13 --> Router Class Initialized
INFO - 2023-10-31 02:30:13 --> Output Class Initialized
INFO - 2023-10-31 02:30:13 --> Security Class Initialized
DEBUG - 2023-10-31 02:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 02:30:13 --> Input Class Initialized
INFO - 2023-10-31 02:30:13 --> Language Class Initialized
INFO - 2023-10-31 02:30:13 --> Loader Class Initialized
INFO - 2023-10-31 02:30:13 --> Helper loaded: url_helper
INFO - 2023-10-31 02:30:13 --> Helper loaded: file_helper
INFO - 2023-10-31 02:30:13 --> Helper loaded: html_helper
INFO - 2023-10-31 02:30:13 --> Helper loaded: text_helper
INFO - 2023-10-31 02:30:13 --> Helper loaded: form_helper
INFO - 2023-10-31 02:30:13 --> Helper loaded: lang_helper
INFO - 2023-10-31 02:30:13 --> Helper loaded: security_helper
INFO - 2023-10-31 02:30:13 --> Helper loaded: cookie_helper
INFO - 2023-10-31 02:30:13 --> Database Driver Class Initialized
INFO - 2023-10-31 02:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 02:30:13 --> Parser Class Initialized
INFO - 2023-10-31 02:30:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 02:30:13 --> Pagination Class Initialized
INFO - 2023-10-31 02:30:13 --> Form Validation Class Initialized
INFO - 2023-10-31 02:30:13 --> Controller Class Initialized
INFO - 2023-10-31 02:30:13 --> Model Class Initialized
DEBUG - 2023-10-31 02:30:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 02:30:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:30:13 --> Model Class Initialized
DEBUG - 2023-10-31 02:30:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:30:13 --> Model Class Initialized
INFO - 2023-10-31 02:30:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-31 02:30:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:30:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 02:30:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 02:30:13 --> Model Class Initialized
INFO - 2023-10-31 02:30:14 --> Model Class Initialized
INFO - 2023-10-31 02:30:14 --> Model Class Initialized
INFO - 2023-10-31 02:30:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 02:30:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 02:30:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 02:30:14 --> Final output sent to browser
DEBUG - 2023-10-31 02:30:14 --> Total execution time: 0.1346
ERROR - 2023-10-31 02:30:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 02:30:14 --> Config Class Initialized
INFO - 2023-10-31 02:30:14 --> Hooks Class Initialized
DEBUG - 2023-10-31 02:30:14 --> UTF-8 Support Enabled
INFO - 2023-10-31 02:30:14 --> Utf8 Class Initialized
INFO - 2023-10-31 02:30:14 --> URI Class Initialized
INFO - 2023-10-31 02:30:14 --> Router Class Initialized
INFO - 2023-10-31 02:30:14 --> Output Class Initialized
INFO - 2023-10-31 02:30:14 --> Security Class Initialized
DEBUG - 2023-10-31 02:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 02:30:14 --> Input Class Initialized
INFO - 2023-10-31 02:30:14 --> Language Class Initialized
INFO - 2023-10-31 02:30:14 --> Loader Class Initialized
INFO - 2023-10-31 02:30:14 --> Helper loaded: url_helper
INFO - 2023-10-31 02:30:14 --> Helper loaded: file_helper
INFO - 2023-10-31 02:30:14 --> Helper loaded: html_helper
INFO - 2023-10-31 02:30:14 --> Helper loaded: text_helper
INFO - 2023-10-31 02:30:14 --> Helper loaded: form_helper
INFO - 2023-10-31 02:30:14 --> Helper loaded: lang_helper
INFO - 2023-10-31 02:30:14 --> Helper loaded: security_helper
INFO - 2023-10-31 02:30:14 --> Helper loaded: cookie_helper
INFO - 2023-10-31 02:30:14 --> Database Driver Class Initialized
INFO - 2023-10-31 02:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 02:30:14 --> Parser Class Initialized
INFO - 2023-10-31 02:30:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 02:30:14 --> Pagination Class Initialized
INFO - 2023-10-31 02:30:14 --> Form Validation Class Initialized
INFO - 2023-10-31 02:30:14 --> Controller Class Initialized
INFO - 2023-10-31 02:30:14 --> Model Class Initialized
DEBUG - 2023-10-31 02:30:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 02:30:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:30:14 --> Model Class Initialized
DEBUG - 2023-10-31 02:30:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:30:14 --> Model Class Initialized
INFO - 2023-10-31 02:30:14 --> Final output sent to browser
DEBUG - 2023-10-31 02:30:14 --> Total execution time: 0.0466
ERROR - 2023-10-31 02:30:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 02:30:22 --> Config Class Initialized
INFO - 2023-10-31 02:30:22 --> Hooks Class Initialized
DEBUG - 2023-10-31 02:30:22 --> UTF-8 Support Enabled
INFO - 2023-10-31 02:30:22 --> Utf8 Class Initialized
INFO - 2023-10-31 02:30:22 --> URI Class Initialized
INFO - 2023-10-31 02:30:22 --> Router Class Initialized
INFO - 2023-10-31 02:30:22 --> Output Class Initialized
INFO - 2023-10-31 02:30:22 --> Security Class Initialized
DEBUG - 2023-10-31 02:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 02:30:22 --> Input Class Initialized
INFO - 2023-10-31 02:30:22 --> Language Class Initialized
INFO - 2023-10-31 02:30:22 --> Loader Class Initialized
INFO - 2023-10-31 02:30:22 --> Helper loaded: url_helper
INFO - 2023-10-31 02:30:22 --> Helper loaded: file_helper
INFO - 2023-10-31 02:30:22 --> Helper loaded: html_helper
INFO - 2023-10-31 02:30:22 --> Helper loaded: text_helper
INFO - 2023-10-31 02:30:22 --> Helper loaded: form_helper
INFO - 2023-10-31 02:30:22 --> Helper loaded: lang_helper
INFO - 2023-10-31 02:30:22 --> Helper loaded: security_helper
INFO - 2023-10-31 02:30:22 --> Helper loaded: cookie_helper
INFO - 2023-10-31 02:30:22 --> Database Driver Class Initialized
INFO - 2023-10-31 02:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 02:30:22 --> Parser Class Initialized
INFO - 2023-10-31 02:30:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 02:30:22 --> Pagination Class Initialized
INFO - 2023-10-31 02:30:22 --> Form Validation Class Initialized
INFO - 2023-10-31 02:30:22 --> Controller Class Initialized
INFO - 2023-10-31 02:30:22 --> Model Class Initialized
DEBUG - 2023-10-31 02:30:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 02:30:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:30:22 --> Model Class Initialized
DEBUG - 2023-10-31 02:30:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:30:22 --> Model Class Initialized
INFO - 2023-10-31 02:30:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-31 02:30:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:30:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 02:30:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 02:30:22 --> Model Class Initialized
INFO - 2023-10-31 02:30:22 --> Model Class Initialized
INFO - 2023-10-31 02:30:22 --> Model Class Initialized
INFO - 2023-10-31 02:30:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 02:30:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 02:30:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 02:30:22 --> Final output sent to browser
DEBUG - 2023-10-31 02:30:22 --> Total execution time: 0.2253
ERROR - 2023-10-31 02:30:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 02:30:23 --> Config Class Initialized
INFO - 2023-10-31 02:30:23 --> Hooks Class Initialized
DEBUG - 2023-10-31 02:30:23 --> UTF-8 Support Enabled
INFO - 2023-10-31 02:30:23 --> Utf8 Class Initialized
INFO - 2023-10-31 02:30:23 --> URI Class Initialized
INFO - 2023-10-31 02:30:23 --> Router Class Initialized
INFO - 2023-10-31 02:30:23 --> Output Class Initialized
INFO - 2023-10-31 02:30:23 --> Security Class Initialized
DEBUG - 2023-10-31 02:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 02:30:23 --> Input Class Initialized
INFO - 2023-10-31 02:30:23 --> Language Class Initialized
INFO - 2023-10-31 02:30:23 --> Loader Class Initialized
INFO - 2023-10-31 02:30:23 --> Helper loaded: url_helper
INFO - 2023-10-31 02:30:23 --> Helper loaded: file_helper
INFO - 2023-10-31 02:30:23 --> Helper loaded: html_helper
INFO - 2023-10-31 02:30:23 --> Helper loaded: text_helper
INFO - 2023-10-31 02:30:23 --> Helper loaded: form_helper
INFO - 2023-10-31 02:30:23 --> Helper loaded: lang_helper
INFO - 2023-10-31 02:30:23 --> Helper loaded: security_helper
INFO - 2023-10-31 02:30:23 --> Helper loaded: cookie_helper
INFO - 2023-10-31 02:30:23 --> Database Driver Class Initialized
INFO - 2023-10-31 02:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 02:30:23 --> Parser Class Initialized
INFO - 2023-10-31 02:30:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 02:30:23 --> Pagination Class Initialized
INFO - 2023-10-31 02:30:23 --> Form Validation Class Initialized
INFO - 2023-10-31 02:30:23 --> Controller Class Initialized
INFO - 2023-10-31 02:30:23 --> Model Class Initialized
DEBUG - 2023-10-31 02:30:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 02:30:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:30:23 --> Model Class Initialized
DEBUG - 2023-10-31 02:30:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:30:23 --> Model Class Initialized
INFO - 2023-10-31 02:30:23 --> Final output sent to browser
DEBUG - 2023-10-31 02:30:23 --> Total execution time: 0.0602
ERROR - 2023-10-31 02:54:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 02:54:02 --> Config Class Initialized
INFO - 2023-10-31 02:54:02 --> Hooks Class Initialized
DEBUG - 2023-10-31 02:54:02 --> UTF-8 Support Enabled
INFO - 2023-10-31 02:54:02 --> Utf8 Class Initialized
INFO - 2023-10-31 02:54:02 --> URI Class Initialized
INFO - 2023-10-31 02:54:02 --> Router Class Initialized
INFO - 2023-10-31 02:54:02 --> Output Class Initialized
INFO - 2023-10-31 02:54:02 --> Security Class Initialized
DEBUG - 2023-10-31 02:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 02:54:02 --> Input Class Initialized
INFO - 2023-10-31 02:54:02 --> Language Class Initialized
INFO - 2023-10-31 02:54:02 --> Loader Class Initialized
INFO - 2023-10-31 02:54:02 --> Helper loaded: url_helper
INFO - 2023-10-31 02:54:02 --> Helper loaded: file_helper
INFO - 2023-10-31 02:54:02 --> Helper loaded: html_helper
INFO - 2023-10-31 02:54:02 --> Helper loaded: text_helper
INFO - 2023-10-31 02:54:02 --> Helper loaded: form_helper
INFO - 2023-10-31 02:54:02 --> Helper loaded: lang_helper
INFO - 2023-10-31 02:54:02 --> Helper loaded: security_helper
INFO - 2023-10-31 02:54:02 --> Helper loaded: cookie_helper
INFO - 2023-10-31 02:54:02 --> Database Driver Class Initialized
INFO - 2023-10-31 02:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 02:54:02 --> Parser Class Initialized
INFO - 2023-10-31 02:54:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 02:54:02 --> Pagination Class Initialized
INFO - 2023-10-31 02:54:02 --> Form Validation Class Initialized
INFO - 2023-10-31 02:54:02 --> Controller Class Initialized
INFO - 2023-10-31 02:54:02 --> Model Class Initialized
DEBUG - 2023-10-31 02:54:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 02:54:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:54:02 --> Model Class Initialized
INFO - 2023-10-31 02:54:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-10-31 02:54:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:54:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 02:54:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 02:54:02 --> Model Class Initialized
INFO - 2023-10-31 02:54:02 --> Model Class Initialized
INFO - 2023-10-31 02:54:02 --> Model Class Initialized
INFO - 2023-10-31 02:54:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 02:54:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 02:54:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 02:54:02 --> Final output sent to browser
DEBUG - 2023-10-31 02:54:02 --> Total execution time: 0.1467
ERROR - 2023-10-31 02:54:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 02:54:02 --> Config Class Initialized
INFO - 2023-10-31 02:54:02 --> Hooks Class Initialized
DEBUG - 2023-10-31 02:54:02 --> UTF-8 Support Enabled
INFO - 2023-10-31 02:54:02 --> Utf8 Class Initialized
INFO - 2023-10-31 02:54:02 --> URI Class Initialized
INFO - 2023-10-31 02:54:02 --> Router Class Initialized
INFO - 2023-10-31 02:54:02 --> Output Class Initialized
INFO - 2023-10-31 02:54:02 --> Security Class Initialized
DEBUG - 2023-10-31 02:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 02:54:02 --> Input Class Initialized
INFO - 2023-10-31 02:54:02 --> Language Class Initialized
INFO - 2023-10-31 02:54:02 --> Loader Class Initialized
INFO - 2023-10-31 02:54:02 --> Helper loaded: url_helper
INFO - 2023-10-31 02:54:02 --> Helper loaded: file_helper
INFO - 2023-10-31 02:54:02 --> Helper loaded: html_helper
INFO - 2023-10-31 02:54:02 --> Helper loaded: text_helper
INFO - 2023-10-31 02:54:02 --> Helper loaded: form_helper
INFO - 2023-10-31 02:54:02 --> Helper loaded: lang_helper
INFO - 2023-10-31 02:54:02 --> Helper loaded: security_helper
INFO - 2023-10-31 02:54:02 --> Helper loaded: cookie_helper
INFO - 2023-10-31 02:54:02 --> Database Driver Class Initialized
INFO - 2023-10-31 02:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 02:54:02 --> Parser Class Initialized
INFO - 2023-10-31 02:54:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 02:54:02 --> Pagination Class Initialized
INFO - 2023-10-31 02:54:02 --> Form Validation Class Initialized
INFO - 2023-10-31 02:54:02 --> Controller Class Initialized
INFO - 2023-10-31 02:54:02 --> Model Class Initialized
DEBUG - 2023-10-31 02:54:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 02:54:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:54:02 --> Model Class Initialized
INFO - 2023-10-31 02:54:02 --> Final output sent to browser
DEBUG - 2023-10-31 02:54:02 --> Total execution time: 0.1168
ERROR - 2023-10-31 02:54:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 02:54:05 --> Config Class Initialized
INFO - 2023-10-31 02:54:05 --> Hooks Class Initialized
DEBUG - 2023-10-31 02:54:05 --> UTF-8 Support Enabled
INFO - 2023-10-31 02:54:05 --> Utf8 Class Initialized
INFO - 2023-10-31 02:54:05 --> URI Class Initialized
INFO - 2023-10-31 02:54:05 --> Router Class Initialized
INFO - 2023-10-31 02:54:05 --> Output Class Initialized
INFO - 2023-10-31 02:54:05 --> Security Class Initialized
DEBUG - 2023-10-31 02:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 02:54:05 --> Input Class Initialized
INFO - 2023-10-31 02:54:05 --> Language Class Initialized
INFO - 2023-10-31 02:54:05 --> Loader Class Initialized
INFO - 2023-10-31 02:54:05 --> Helper loaded: url_helper
INFO - 2023-10-31 02:54:05 --> Helper loaded: file_helper
INFO - 2023-10-31 02:54:05 --> Helper loaded: html_helper
INFO - 2023-10-31 02:54:05 --> Helper loaded: text_helper
INFO - 2023-10-31 02:54:05 --> Helper loaded: form_helper
INFO - 2023-10-31 02:54:05 --> Helper loaded: lang_helper
INFO - 2023-10-31 02:54:05 --> Helper loaded: security_helper
INFO - 2023-10-31 02:54:05 --> Helper loaded: cookie_helper
INFO - 2023-10-31 02:54:05 --> Database Driver Class Initialized
INFO - 2023-10-31 02:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 02:54:05 --> Parser Class Initialized
INFO - 2023-10-31 02:54:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 02:54:05 --> Pagination Class Initialized
INFO - 2023-10-31 02:54:05 --> Form Validation Class Initialized
INFO - 2023-10-31 02:54:05 --> Controller Class Initialized
INFO - 2023-10-31 02:54:05 --> Model Class Initialized
DEBUG - 2023-10-31 02:54:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 02:54:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:54:05 --> Model Class Initialized
INFO - 2023-10-31 02:54:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2023-10-31 02:54:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:54:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 02:54:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 02:54:05 --> Model Class Initialized
INFO - 2023-10-31 02:54:05 --> Model Class Initialized
INFO - 2023-10-31 02:54:05 --> Model Class Initialized
INFO - 2023-10-31 02:54:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 02:54:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 02:54:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 02:54:05 --> Final output sent to browser
DEBUG - 2023-10-31 02:54:05 --> Total execution time: 0.1363
ERROR - 2023-10-31 02:54:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 02:54:05 --> Config Class Initialized
INFO - 2023-10-31 02:54:05 --> Hooks Class Initialized
DEBUG - 2023-10-31 02:54:05 --> UTF-8 Support Enabled
INFO - 2023-10-31 02:54:05 --> Utf8 Class Initialized
INFO - 2023-10-31 02:54:05 --> URI Class Initialized
INFO - 2023-10-31 02:54:05 --> Router Class Initialized
INFO - 2023-10-31 02:54:05 --> Output Class Initialized
INFO - 2023-10-31 02:54:05 --> Security Class Initialized
DEBUG - 2023-10-31 02:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 02:54:05 --> Input Class Initialized
INFO - 2023-10-31 02:54:05 --> Language Class Initialized
INFO - 2023-10-31 02:54:05 --> Loader Class Initialized
INFO - 2023-10-31 02:54:05 --> Helper loaded: url_helper
INFO - 2023-10-31 02:54:05 --> Helper loaded: file_helper
INFO - 2023-10-31 02:54:05 --> Helper loaded: html_helper
INFO - 2023-10-31 02:54:05 --> Helper loaded: text_helper
INFO - 2023-10-31 02:54:05 --> Helper loaded: form_helper
INFO - 2023-10-31 02:54:05 --> Helper loaded: lang_helper
INFO - 2023-10-31 02:54:05 --> Helper loaded: security_helper
INFO - 2023-10-31 02:54:05 --> Helper loaded: cookie_helper
INFO - 2023-10-31 02:54:05 --> Database Driver Class Initialized
INFO - 2023-10-31 02:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 02:54:05 --> Parser Class Initialized
INFO - 2023-10-31 02:54:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 02:54:05 --> Pagination Class Initialized
INFO - 2023-10-31 02:54:05 --> Form Validation Class Initialized
INFO - 2023-10-31 02:54:05 --> Controller Class Initialized
INFO - 2023-10-31 02:54:05 --> Model Class Initialized
DEBUG - 2023-10-31 02:54:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 02:54:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:54:05 --> Model Class Initialized
INFO - 2023-10-31 02:54:05 --> Final output sent to browser
DEBUG - 2023-10-31 02:54:05 --> Total execution time: 0.0160
ERROR - 2023-10-31 02:54:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 02:54:08 --> Config Class Initialized
INFO - 2023-10-31 02:54:08 --> Hooks Class Initialized
DEBUG - 2023-10-31 02:54:08 --> UTF-8 Support Enabled
INFO - 2023-10-31 02:54:08 --> Utf8 Class Initialized
INFO - 2023-10-31 02:54:08 --> URI Class Initialized
INFO - 2023-10-31 02:54:08 --> Router Class Initialized
INFO - 2023-10-31 02:54:08 --> Output Class Initialized
INFO - 2023-10-31 02:54:08 --> Security Class Initialized
DEBUG - 2023-10-31 02:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 02:54:08 --> Input Class Initialized
INFO - 2023-10-31 02:54:08 --> Language Class Initialized
INFO - 2023-10-31 02:54:08 --> Loader Class Initialized
INFO - 2023-10-31 02:54:08 --> Helper loaded: url_helper
INFO - 2023-10-31 02:54:08 --> Helper loaded: file_helper
INFO - 2023-10-31 02:54:08 --> Helper loaded: html_helper
INFO - 2023-10-31 02:54:08 --> Helper loaded: text_helper
INFO - 2023-10-31 02:54:08 --> Helper loaded: form_helper
INFO - 2023-10-31 02:54:08 --> Helper loaded: lang_helper
INFO - 2023-10-31 02:54:08 --> Helper loaded: security_helper
INFO - 2023-10-31 02:54:08 --> Helper loaded: cookie_helper
INFO - 2023-10-31 02:54:08 --> Database Driver Class Initialized
INFO - 2023-10-31 02:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 02:54:08 --> Parser Class Initialized
INFO - 2023-10-31 02:54:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 02:54:08 --> Pagination Class Initialized
INFO - 2023-10-31 02:54:08 --> Form Validation Class Initialized
INFO - 2023-10-31 02:54:08 --> Controller Class Initialized
INFO - 2023-10-31 02:54:08 --> Model Class Initialized
DEBUG - 2023-10-31 02:54:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 02:54:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:54:08 --> Model Class Initialized
DEBUG - 2023-10-31 02:54:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:54:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-10-31 02:54:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:54:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 02:54:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 02:54:08 --> Model Class Initialized
INFO - 2023-10-31 02:54:08 --> Model Class Initialized
INFO - 2023-10-31 02:54:08 --> Model Class Initialized
INFO - 2023-10-31 02:54:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 02:54:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 02:54:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 02:54:08 --> Final output sent to browser
DEBUG - 2023-10-31 02:54:08 --> Total execution time: 0.1431
ERROR - 2023-10-31 02:54:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 02:54:12 --> Config Class Initialized
INFO - 2023-10-31 02:54:12 --> Hooks Class Initialized
DEBUG - 2023-10-31 02:54:12 --> UTF-8 Support Enabled
INFO - 2023-10-31 02:54:12 --> Utf8 Class Initialized
INFO - 2023-10-31 02:54:12 --> URI Class Initialized
INFO - 2023-10-31 02:54:12 --> Router Class Initialized
INFO - 2023-10-31 02:54:12 --> Output Class Initialized
INFO - 2023-10-31 02:54:12 --> Security Class Initialized
DEBUG - 2023-10-31 02:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 02:54:12 --> Input Class Initialized
INFO - 2023-10-31 02:54:12 --> Language Class Initialized
INFO - 2023-10-31 02:54:12 --> Loader Class Initialized
INFO - 2023-10-31 02:54:12 --> Helper loaded: url_helper
INFO - 2023-10-31 02:54:12 --> Helper loaded: file_helper
INFO - 2023-10-31 02:54:12 --> Helper loaded: html_helper
INFO - 2023-10-31 02:54:12 --> Helper loaded: text_helper
INFO - 2023-10-31 02:54:12 --> Helper loaded: form_helper
INFO - 2023-10-31 02:54:12 --> Helper loaded: lang_helper
INFO - 2023-10-31 02:54:12 --> Helper loaded: security_helper
INFO - 2023-10-31 02:54:12 --> Helper loaded: cookie_helper
INFO - 2023-10-31 02:54:12 --> Database Driver Class Initialized
INFO - 2023-10-31 02:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 02:54:12 --> Parser Class Initialized
INFO - 2023-10-31 02:54:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 02:54:12 --> Pagination Class Initialized
INFO - 2023-10-31 02:54:12 --> Form Validation Class Initialized
INFO - 2023-10-31 02:54:12 --> Controller Class Initialized
INFO - 2023-10-31 02:54:12 --> Model Class Initialized
DEBUG - 2023-10-31 02:54:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 02:54:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:54:12 --> Model Class Initialized
INFO - 2023-10-31 02:54:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-10-31 02:54:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:54:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 02:54:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 02:54:12 --> Model Class Initialized
INFO - 2023-10-31 02:54:12 --> Model Class Initialized
INFO - 2023-10-31 02:54:12 --> Model Class Initialized
INFO - 2023-10-31 02:54:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 02:54:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 02:54:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 02:54:12 --> Final output sent to browser
DEBUG - 2023-10-31 02:54:12 --> Total execution time: 0.1378
ERROR - 2023-10-31 02:54:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 02:54:13 --> Config Class Initialized
INFO - 2023-10-31 02:54:13 --> Hooks Class Initialized
DEBUG - 2023-10-31 02:54:13 --> UTF-8 Support Enabled
INFO - 2023-10-31 02:54:13 --> Utf8 Class Initialized
INFO - 2023-10-31 02:54:13 --> URI Class Initialized
INFO - 2023-10-31 02:54:13 --> Router Class Initialized
INFO - 2023-10-31 02:54:13 --> Output Class Initialized
INFO - 2023-10-31 02:54:13 --> Security Class Initialized
DEBUG - 2023-10-31 02:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 02:54:13 --> Input Class Initialized
INFO - 2023-10-31 02:54:13 --> Language Class Initialized
INFO - 2023-10-31 02:54:13 --> Loader Class Initialized
INFO - 2023-10-31 02:54:13 --> Helper loaded: url_helper
INFO - 2023-10-31 02:54:13 --> Helper loaded: file_helper
INFO - 2023-10-31 02:54:13 --> Helper loaded: html_helper
INFO - 2023-10-31 02:54:13 --> Helper loaded: text_helper
INFO - 2023-10-31 02:54:13 --> Helper loaded: form_helper
INFO - 2023-10-31 02:54:13 --> Helper loaded: lang_helper
INFO - 2023-10-31 02:54:13 --> Helper loaded: security_helper
INFO - 2023-10-31 02:54:13 --> Helper loaded: cookie_helper
INFO - 2023-10-31 02:54:13 --> Database Driver Class Initialized
INFO - 2023-10-31 02:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 02:54:13 --> Parser Class Initialized
INFO - 2023-10-31 02:54:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 02:54:13 --> Pagination Class Initialized
INFO - 2023-10-31 02:54:13 --> Form Validation Class Initialized
INFO - 2023-10-31 02:54:13 --> Controller Class Initialized
INFO - 2023-10-31 02:54:13 --> Model Class Initialized
DEBUG - 2023-10-31 02:54:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 02:54:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:54:13 --> Model Class Initialized
INFO - 2023-10-31 02:54:13 --> Final output sent to browser
DEBUG - 2023-10-31 02:54:13 --> Total execution time: 0.0291
ERROR - 2023-10-31 02:54:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 02:54:24 --> Config Class Initialized
INFO - 2023-10-31 02:54:24 --> Hooks Class Initialized
DEBUG - 2023-10-31 02:54:24 --> UTF-8 Support Enabled
INFO - 2023-10-31 02:54:24 --> Utf8 Class Initialized
INFO - 2023-10-31 02:54:24 --> URI Class Initialized
INFO - 2023-10-31 02:54:24 --> Router Class Initialized
INFO - 2023-10-31 02:54:24 --> Output Class Initialized
INFO - 2023-10-31 02:54:24 --> Security Class Initialized
DEBUG - 2023-10-31 02:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 02:54:24 --> Input Class Initialized
INFO - 2023-10-31 02:54:24 --> Language Class Initialized
INFO - 2023-10-31 02:54:24 --> Loader Class Initialized
INFO - 2023-10-31 02:54:24 --> Helper loaded: url_helper
INFO - 2023-10-31 02:54:24 --> Helper loaded: file_helper
INFO - 2023-10-31 02:54:24 --> Helper loaded: html_helper
INFO - 2023-10-31 02:54:24 --> Helper loaded: text_helper
INFO - 2023-10-31 02:54:24 --> Helper loaded: form_helper
INFO - 2023-10-31 02:54:24 --> Helper loaded: lang_helper
INFO - 2023-10-31 02:54:24 --> Helper loaded: security_helper
INFO - 2023-10-31 02:54:24 --> Helper loaded: cookie_helper
INFO - 2023-10-31 02:54:24 --> Database Driver Class Initialized
INFO - 2023-10-31 02:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 02:54:24 --> Parser Class Initialized
INFO - 2023-10-31 02:54:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 02:54:24 --> Pagination Class Initialized
INFO - 2023-10-31 02:54:24 --> Form Validation Class Initialized
INFO - 2023-10-31 02:54:24 --> Controller Class Initialized
INFO - 2023-10-31 02:54:24 --> Model Class Initialized
DEBUG - 2023-10-31 02:54:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 02:54:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:54:24 --> Model Class Initialized
INFO - 2023-10-31 02:54:24 --> Final output sent to browser
DEBUG - 2023-10-31 02:54:24 --> Total execution time: 0.0662
ERROR - 2023-10-31 02:54:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 02:54:33 --> Config Class Initialized
INFO - 2023-10-31 02:54:33 --> Hooks Class Initialized
DEBUG - 2023-10-31 02:54:33 --> UTF-8 Support Enabled
INFO - 2023-10-31 02:54:33 --> Utf8 Class Initialized
INFO - 2023-10-31 02:54:33 --> URI Class Initialized
DEBUG - 2023-10-31 02:54:33 --> No URI present. Default controller set.
INFO - 2023-10-31 02:54:33 --> Router Class Initialized
INFO - 2023-10-31 02:54:33 --> Output Class Initialized
INFO - 2023-10-31 02:54:33 --> Security Class Initialized
DEBUG - 2023-10-31 02:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 02:54:33 --> Input Class Initialized
INFO - 2023-10-31 02:54:33 --> Language Class Initialized
INFO - 2023-10-31 02:54:33 --> Loader Class Initialized
INFO - 2023-10-31 02:54:33 --> Helper loaded: url_helper
INFO - 2023-10-31 02:54:33 --> Helper loaded: file_helper
INFO - 2023-10-31 02:54:33 --> Helper loaded: html_helper
INFO - 2023-10-31 02:54:33 --> Helper loaded: text_helper
INFO - 2023-10-31 02:54:33 --> Helper loaded: form_helper
INFO - 2023-10-31 02:54:33 --> Helper loaded: lang_helper
INFO - 2023-10-31 02:54:33 --> Helper loaded: security_helper
INFO - 2023-10-31 02:54:33 --> Helper loaded: cookie_helper
INFO - 2023-10-31 02:54:33 --> Database Driver Class Initialized
INFO - 2023-10-31 02:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 02:54:33 --> Parser Class Initialized
INFO - 2023-10-31 02:54:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 02:54:33 --> Pagination Class Initialized
INFO - 2023-10-31 02:54:33 --> Form Validation Class Initialized
INFO - 2023-10-31 02:54:33 --> Controller Class Initialized
INFO - 2023-10-31 02:54:33 --> Model Class Initialized
DEBUG - 2023-10-31 02:54:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:54:33 --> Model Class Initialized
DEBUG - 2023-10-31 02:54:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:54:33 --> Model Class Initialized
INFO - 2023-10-31 02:54:33 --> Model Class Initialized
INFO - 2023-10-31 02:54:33 --> Model Class Initialized
INFO - 2023-10-31 02:54:33 --> Model Class Initialized
DEBUG - 2023-10-31 02:54:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 02:54:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:54:33 --> Model Class Initialized
INFO - 2023-10-31 02:54:33 --> Model Class Initialized
INFO - 2023-10-31 02:54:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-31 02:54:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:54:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 02:54:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 02:54:33 --> Model Class Initialized
INFO - 2023-10-31 02:54:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 02:54:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 02:54:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 02:54:34 --> Final output sent to browser
DEBUG - 2023-10-31 02:54:34 --> Total execution time: 0.2032
ERROR - 2023-10-31 02:55:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 02:55:41 --> Config Class Initialized
INFO - 2023-10-31 02:55:41 --> Hooks Class Initialized
DEBUG - 2023-10-31 02:55:41 --> UTF-8 Support Enabled
INFO - 2023-10-31 02:55:41 --> Utf8 Class Initialized
INFO - 2023-10-31 02:55:41 --> URI Class Initialized
DEBUG - 2023-10-31 02:55:41 --> No URI present. Default controller set.
INFO - 2023-10-31 02:55:41 --> Router Class Initialized
INFO - 2023-10-31 02:55:41 --> Output Class Initialized
INFO - 2023-10-31 02:55:41 --> Security Class Initialized
DEBUG - 2023-10-31 02:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 02:55:41 --> Input Class Initialized
INFO - 2023-10-31 02:55:41 --> Language Class Initialized
INFO - 2023-10-31 02:55:41 --> Loader Class Initialized
INFO - 2023-10-31 02:55:41 --> Helper loaded: url_helper
INFO - 2023-10-31 02:55:41 --> Helper loaded: file_helper
INFO - 2023-10-31 02:55:41 --> Helper loaded: html_helper
INFO - 2023-10-31 02:55:41 --> Helper loaded: text_helper
INFO - 2023-10-31 02:55:41 --> Helper loaded: form_helper
INFO - 2023-10-31 02:55:41 --> Helper loaded: lang_helper
INFO - 2023-10-31 02:55:41 --> Helper loaded: security_helper
INFO - 2023-10-31 02:55:41 --> Helper loaded: cookie_helper
INFO - 2023-10-31 02:55:41 --> Database Driver Class Initialized
INFO - 2023-10-31 02:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 02:55:41 --> Parser Class Initialized
INFO - 2023-10-31 02:55:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 02:55:41 --> Pagination Class Initialized
INFO - 2023-10-31 02:55:41 --> Form Validation Class Initialized
INFO - 2023-10-31 02:55:41 --> Controller Class Initialized
INFO - 2023-10-31 02:55:41 --> Model Class Initialized
DEBUG - 2023-10-31 02:55:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:55:41 --> Model Class Initialized
DEBUG - 2023-10-31 02:55:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:55:41 --> Model Class Initialized
INFO - 2023-10-31 02:55:41 --> Model Class Initialized
INFO - 2023-10-31 02:55:41 --> Model Class Initialized
INFO - 2023-10-31 02:55:41 --> Model Class Initialized
DEBUG - 2023-10-31 02:55:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 02:55:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:55:41 --> Model Class Initialized
INFO - 2023-10-31 02:55:41 --> Model Class Initialized
INFO - 2023-10-31 02:55:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-31 02:55:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:55:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 02:55:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 02:55:41 --> Model Class Initialized
INFO - 2023-10-31 02:55:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 02:55:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 02:55:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 02:55:41 --> Final output sent to browser
DEBUG - 2023-10-31 02:55:41 --> Total execution time: 0.2036
ERROR - 2023-10-31 02:56:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 02:56:09 --> Config Class Initialized
INFO - 2023-10-31 02:56:09 --> Hooks Class Initialized
DEBUG - 2023-10-31 02:56:09 --> UTF-8 Support Enabled
INFO - 2023-10-31 02:56:09 --> Utf8 Class Initialized
INFO - 2023-10-31 02:56:09 --> URI Class Initialized
DEBUG - 2023-10-31 02:56:09 --> No URI present. Default controller set.
INFO - 2023-10-31 02:56:09 --> Router Class Initialized
INFO - 2023-10-31 02:56:09 --> Output Class Initialized
INFO - 2023-10-31 02:56:09 --> Security Class Initialized
DEBUG - 2023-10-31 02:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 02:56:09 --> Input Class Initialized
INFO - 2023-10-31 02:56:09 --> Language Class Initialized
INFO - 2023-10-31 02:56:09 --> Loader Class Initialized
INFO - 2023-10-31 02:56:09 --> Helper loaded: url_helper
INFO - 2023-10-31 02:56:09 --> Helper loaded: file_helper
INFO - 2023-10-31 02:56:09 --> Helper loaded: html_helper
INFO - 2023-10-31 02:56:09 --> Helper loaded: text_helper
INFO - 2023-10-31 02:56:09 --> Helper loaded: form_helper
INFO - 2023-10-31 02:56:09 --> Helper loaded: lang_helper
INFO - 2023-10-31 02:56:09 --> Helper loaded: security_helper
INFO - 2023-10-31 02:56:09 --> Helper loaded: cookie_helper
INFO - 2023-10-31 02:56:09 --> Database Driver Class Initialized
INFO - 2023-10-31 02:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 02:56:09 --> Parser Class Initialized
INFO - 2023-10-31 02:56:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 02:56:09 --> Pagination Class Initialized
INFO - 2023-10-31 02:56:09 --> Form Validation Class Initialized
INFO - 2023-10-31 02:56:09 --> Controller Class Initialized
INFO - 2023-10-31 02:56:09 --> Model Class Initialized
DEBUG - 2023-10-31 02:56:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:56:09 --> Model Class Initialized
DEBUG - 2023-10-31 02:56:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:56:09 --> Model Class Initialized
INFO - 2023-10-31 02:56:09 --> Model Class Initialized
INFO - 2023-10-31 02:56:09 --> Model Class Initialized
INFO - 2023-10-31 02:56:09 --> Model Class Initialized
DEBUG - 2023-10-31 02:56:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 02:56:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:56:09 --> Model Class Initialized
INFO - 2023-10-31 02:56:09 --> Model Class Initialized
INFO - 2023-10-31 02:56:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-31 02:56:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 02:56:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 02:56:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 02:56:09 --> Model Class Initialized
INFO - 2023-10-31 02:56:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 02:56:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 02:56:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 02:56:09 --> Final output sent to browser
DEBUG - 2023-10-31 02:56:09 --> Total execution time: 0.2052
ERROR - 2023-10-31 03:17:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:17:45 --> Config Class Initialized
INFO - 2023-10-31 03:17:45 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:17:45 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:17:45 --> Utf8 Class Initialized
INFO - 2023-10-31 03:17:45 --> URI Class Initialized
DEBUG - 2023-10-31 03:17:45 --> No URI present. Default controller set.
INFO - 2023-10-31 03:17:45 --> Router Class Initialized
INFO - 2023-10-31 03:17:45 --> Output Class Initialized
INFO - 2023-10-31 03:17:45 --> Security Class Initialized
DEBUG - 2023-10-31 03:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:17:45 --> Input Class Initialized
INFO - 2023-10-31 03:17:45 --> Language Class Initialized
INFO - 2023-10-31 03:17:45 --> Loader Class Initialized
INFO - 2023-10-31 03:17:45 --> Helper loaded: url_helper
INFO - 2023-10-31 03:17:45 --> Helper loaded: file_helper
INFO - 2023-10-31 03:17:45 --> Helper loaded: html_helper
INFO - 2023-10-31 03:17:45 --> Helper loaded: text_helper
INFO - 2023-10-31 03:17:45 --> Helper loaded: form_helper
INFO - 2023-10-31 03:17:45 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:17:45 --> Helper loaded: security_helper
INFO - 2023-10-31 03:17:45 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:17:45 --> Database Driver Class Initialized
INFO - 2023-10-31 03:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:17:45 --> Parser Class Initialized
INFO - 2023-10-31 03:17:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:17:45 --> Pagination Class Initialized
INFO - 2023-10-31 03:17:45 --> Form Validation Class Initialized
INFO - 2023-10-31 03:17:45 --> Controller Class Initialized
INFO - 2023-10-31 03:17:45 --> Model Class Initialized
DEBUG - 2023-10-31 03:17:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:17:45 --> Model Class Initialized
DEBUG - 2023-10-31 03:17:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:17:45 --> Model Class Initialized
INFO - 2023-10-31 03:17:45 --> Model Class Initialized
INFO - 2023-10-31 03:17:45 --> Model Class Initialized
INFO - 2023-10-31 03:17:45 --> Model Class Initialized
DEBUG - 2023-10-31 03:17:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:17:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:17:45 --> Model Class Initialized
INFO - 2023-10-31 03:17:45 --> Model Class Initialized
INFO - 2023-10-31 03:17:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-31 03:17:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:17:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 03:17:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 03:17:45 --> Model Class Initialized
INFO - 2023-10-31 03:17:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 03:17:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 03:17:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 03:17:46 --> Final output sent to browser
DEBUG - 2023-10-31 03:17:46 --> Total execution time: 0.2095
ERROR - 2023-10-31 03:17:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:17:50 --> Config Class Initialized
INFO - 2023-10-31 03:17:50 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:17:50 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:17:50 --> Utf8 Class Initialized
INFO - 2023-10-31 03:17:50 --> URI Class Initialized
INFO - 2023-10-31 03:17:50 --> Router Class Initialized
INFO - 2023-10-31 03:17:50 --> Output Class Initialized
INFO - 2023-10-31 03:17:50 --> Security Class Initialized
DEBUG - 2023-10-31 03:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:17:50 --> Input Class Initialized
INFO - 2023-10-31 03:17:51 --> Language Class Initialized
INFO - 2023-10-31 03:17:51 --> Loader Class Initialized
INFO - 2023-10-31 03:17:51 --> Helper loaded: url_helper
INFO - 2023-10-31 03:17:51 --> Helper loaded: file_helper
INFO - 2023-10-31 03:17:51 --> Helper loaded: html_helper
INFO - 2023-10-31 03:17:51 --> Helper loaded: text_helper
INFO - 2023-10-31 03:17:51 --> Helper loaded: form_helper
INFO - 2023-10-31 03:17:51 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:17:51 --> Helper loaded: security_helper
INFO - 2023-10-31 03:17:51 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:17:51 --> Database Driver Class Initialized
INFO - 2023-10-31 03:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:17:51 --> Parser Class Initialized
INFO - 2023-10-31 03:17:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:17:51 --> Pagination Class Initialized
INFO - 2023-10-31 03:17:51 --> Form Validation Class Initialized
INFO - 2023-10-31 03:17:51 --> Controller Class Initialized
INFO - 2023-10-31 03:17:51 --> Model Class Initialized
DEBUG - 2023-10-31 03:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:17:51 --> Final output sent to browser
DEBUG - 2023-10-31 03:17:51 --> Total execution time: 0.0132
ERROR - 2023-10-31 03:17:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:17:51 --> Config Class Initialized
INFO - 2023-10-31 03:17:51 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:17:51 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:17:51 --> Utf8 Class Initialized
INFO - 2023-10-31 03:17:51 --> URI Class Initialized
INFO - 2023-10-31 03:17:51 --> Router Class Initialized
INFO - 2023-10-31 03:17:51 --> Output Class Initialized
INFO - 2023-10-31 03:17:51 --> Security Class Initialized
DEBUG - 2023-10-31 03:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:17:51 --> Input Class Initialized
INFO - 2023-10-31 03:17:51 --> Language Class Initialized
INFO - 2023-10-31 03:17:51 --> Loader Class Initialized
INFO - 2023-10-31 03:17:51 --> Helper loaded: url_helper
INFO - 2023-10-31 03:17:51 --> Helper loaded: file_helper
INFO - 2023-10-31 03:17:51 --> Helper loaded: html_helper
INFO - 2023-10-31 03:17:51 --> Helper loaded: text_helper
INFO - 2023-10-31 03:17:51 --> Helper loaded: form_helper
INFO - 2023-10-31 03:17:51 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:17:51 --> Helper loaded: security_helper
INFO - 2023-10-31 03:17:51 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:17:51 --> Database Driver Class Initialized
INFO - 2023-10-31 03:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:17:51 --> Parser Class Initialized
INFO - 2023-10-31 03:17:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:17:51 --> Pagination Class Initialized
INFO - 2023-10-31 03:17:51 --> Form Validation Class Initialized
INFO - 2023-10-31 03:17:51 --> Controller Class Initialized
INFO - 2023-10-31 03:17:51 --> Model Class Initialized
DEBUG - 2023-10-31 03:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:17:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-31 03:17:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:17:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 03:17:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 03:17:51 --> Model Class Initialized
INFO - 2023-10-31 03:17:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 03:17:51 --> Final output sent to browser
DEBUG - 2023-10-31 03:17:51 --> Total execution time: 0.0294
ERROR - 2023-10-31 03:17:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:17:57 --> Config Class Initialized
INFO - 2023-10-31 03:17:57 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:17:57 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:17:57 --> Utf8 Class Initialized
INFO - 2023-10-31 03:17:57 --> URI Class Initialized
INFO - 2023-10-31 03:17:57 --> Router Class Initialized
INFO - 2023-10-31 03:17:57 --> Output Class Initialized
INFO - 2023-10-31 03:17:57 --> Security Class Initialized
DEBUG - 2023-10-31 03:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:17:57 --> Input Class Initialized
INFO - 2023-10-31 03:17:57 --> Language Class Initialized
INFO - 2023-10-31 03:17:57 --> Loader Class Initialized
INFO - 2023-10-31 03:17:57 --> Helper loaded: url_helper
INFO - 2023-10-31 03:17:57 --> Helper loaded: file_helper
INFO - 2023-10-31 03:17:57 --> Helper loaded: html_helper
INFO - 2023-10-31 03:17:57 --> Helper loaded: text_helper
INFO - 2023-10-31 03:17:57 --> Helper loaded: form_helper
INFO - 2023-10-31 03:17:57 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:17:57 --> Helper loaded: security_helper
INFO - 2023-10-31 03:17:57 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:17:57 --> Database Driver Class Initialized
INFO - 2023-10-31 03:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:17:57 --> Parser Class Initialized
INFO - 2023-10-31 03:17:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:17:57 --> Pagination Class Initialized
INFO - 2023-10-31 03:17:57 --> Form Validation Class Initialized
INFO - 2023-10-31 03:17:57 --> Controller Class Initialized
INFO - 2023-10-31 03:17:57 --> Model Class Initialized
DEBUG - 2023-10-31 03:17:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:17:57 --> Model Class Initialized
INFO - 2023-10-31 03:17:57 --> Final output sent to browser
DEBUG - 2023-10-31 03:17:57 --> Total execution time: 0.0167
ERROR - 2023-10-31 03:17:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:17:58 --> Config Class Initialized
INFO - 2023-10-31 03:17:58 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:17:58 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:17:58 --> Utf8 Class Initialized
INFO - 2023-10-31 03:17:58 --> URI Class Initialized
DEBUG - 2023-10-31 03:17:58 --> No URI present. Default controller set.
INFO - 2023-10-31 03:17:58 --> Router Class Initialized
INFO - 2023-10-31 03:17:58 --> Output Class Initialized
INFO - 2023-10-31 03:17:58 --> Security Class Initialized
DEBUG - 2023-10-31 03:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:17:58 --> Input Class Initialized
INFO - 2023-10-31 03:17:58 --> Language Class Initialized
INFO - 2023-10-31 03:17:58 --> Loader Class Initialized
INFO - 2023-10-31 03:17:58 --> Helper loaded: url_helper
INFO - 2023-10-31 03:17:58 --> Helper loaded: file_helper
INFO - 2023-10-31 03:17:58 --> Helper loaded: html_helper
INFO - 2023-10-31 03:17:58 --> Helper loaded: text_helper
INFO - 2023-10-31 03:17:58 --> Helper loaded: form_helper
INFO - 2023-10-31 03:17:58 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:17:58 --> Helper loaded: security_helper
INFO - 2023-10-31 03:17:58 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:17:58 --> Database Driver Class Initialized
INFO - 2023-10-31 03:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:17:58 --> Parser Class Initialized
INFO - 2023-10-31 03:17:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:17:58 --> Pagination Class Initialized
INFO - 2023-10-31 03:17:58 --> Form Validation Class Initialized
INFO - 2023-10-31 03:17:58 --> Controller Class Initialized
INFO - 2023-10-31 03:17:58 --> Model Class Initialized
DEBUG - 2023-10-31 03:17:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:17:58 --> Model Class Initialized
DEBUG - 2023-10-31 03:17:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:17:58 --> Model Class Initialized
INFO - 2023-10-31 03:17:58 --> Model Class Initialized
INFO - 2023-10-31 03:17:58 --> Model Class Initialized
INFO - 2023-10-31 03:17:58 --> Model Class Initialized
DEBUG - 2023-10-31 03:17:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:17:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:17:58 --> Model Class Initialized
INFO - 2023-10-31 03:17:58 --> Model Class Initialized
INFO - 2023-10-31 03:17:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-31 03:17:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:17:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 03:17:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 03:17:58 --> Model Class Initialized
INFO - 2023-10-31 03:17:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 03:17:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 03:17:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 03:17:58 --> Final output sent to browser
DEBUG - 2023-10-31 03:17:58 --> Total execution time: 0.1983
ERROR - 2023-10-31 03:18:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:18:02 --> Config Class Initialized
INFO - 2023-10-31 03:18:02 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:18:02 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:18:02 --> Utf8 Class Initialized
INFO - 2023-10-31 03:18:02 --> URI Class Initialized
INFO - 2023-10-31 03:18:02 --> Router Class Initialized
INFO - 2023-10-31 03:18:02 --> Output Class Initialized
INFO - 2023-10-31 03:18:02 --> Security Class Initialized
DEBUG - 2023-10-31 03:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:18:02 --> Input Class Initialized
INFO - 2023-10-31 03:18:02 --> Language Class Initialized
INFO - 2023-10-31 03:18:02 --> Loader Class Initialized
INFO - 2023-10-31 03:18:02 --> Helper loaded: url_helper
INFO - 2023-10-31 03:18:02 --> Helper loaded: file_helper
INFO - 2023-10-31 03:18:02 --> Helper loaded: html_helper
INFO - 2023-10-31 03:18:02 --> Helper loaded: text_helper
INFO - 2023-10-31 03:18:02 --> Helper loaded: form_helper
INFO - 2023-10-31 03:18:02 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:18:02 --> Helper loaded: security_helper
INFO - 2023-10-31 03:18:02 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:18:02 --> Database Driver Class Initialized
INFO - 2023-10-31 03:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:18:02 --> Parser Class Initialized
INFO - 2023-10-31 03:18:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:18:02 --> Pagination Class Initialized
INFO - 2023-10-31 03:18:02 --> Form Validation Class Initialized
INFO - 2023-10-31 03:18:02 --> Controller Class Initialized
DEBUG - 2023-10-31 03:18:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:18:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:18:02 --> Model Class Initialized
DEBUG - 2023-10-31 03:18:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:18:02 --> Model Class Initialized
DEBUG - 2023-10-31 03:18:02 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:18:02 --> Model Class Initialized
INFO - 2023-10-31 03:18:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-10-31 03:18:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:18:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 03:18:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 03:18:02 --> Model Class Initialized
INFO - 2023-10-31 03:18:02 --> Model Class Initialized
INFO - 2023-10-31 03:18:02 --> Model Class Initialized
INFO - 2023-10-31 03:18:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 03:18:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 03:18:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 03:18:02 --> Final output sent to browser
DEBUG - 2023-10-31 03:18:02 --> Total execution time: 0.1404
ERROR - 2023-10-31 03:18:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:18:03 --> Config Class Initialized
INFO - 2023-10-31 03:18:03 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:18:03 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:18:03 --> Utf8 Class Initialized
INFO - 2023-10-31 03:18:03 --> URI Class Initialized
INFO - 2023-10-31 03:18:03 --> Router Class Initialized
INFO - 2023-10-31 03:18:03 --> Output Class Initialized
INFO - 2023-10-31 03:18:03 --> Security Class Initialized
DEBUG - 2023-10-31 03:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:18:03 --> Input Class Initialized
INFO - 2023-10-31 03:18:03 --> Language Class Initialized
INFO - 2023-10-31 03:18:03 --> Loader Class Initialized
INFO - 2023-10-31 03:18:03 --> Helper loaded: url_helper
INFO - 2023-10-31 03:18:03 --> Helper loaded: file_helper
INFO - 2023-10-31 03:18:03 --> Helper loaded: html_helper
INFO - 2023-10-31 03:18:03 --> Helper loaded: text_helper
INFO - 2023-10-31 03:18:03 --> Helper loaded: form_helper
INFO - 2023-10-31 03:18:03 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:18:03 --> Helper loaded: security_helper
INFO - 2023-10-31 03:18:03 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:18:03 --> Database Driver Class Initialized
INFO - 2023-10-31 03:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:18:03 --> Parser Class Initialized
INFO - 2023-10-31 03:18:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:18:03 --> Pagination Class Initialized
INFO - 2023-10-31 03:18:03 --> Form Validation Class Initialized
INFO - 2023-10-31 03:18:03 --> Controller Class Initialized
DEBUG - 2023-10-31 03:18:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:18:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:18:03 --> Model Class Initialized
DEBUG - 2023-10-31 03:18:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:18:03 --> Model Class Initialized
INFO - 2023-10-31 03:18:03 --> Final output sent to browser
DEBUG - 2023-10-31 03:18:03 --> Total execution time: 0.0204
ERROR - 2023-10-31 03:18:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:18:07 --> Config Class Initialized
INFO - 2023-10-31 03:18:07 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:18:07 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:18:07 --> Utf8 Class Initialized
INFO - 2023-10-31 03:18:07 --> URI Class Initialized
INFO - 2023-10-31 03:18:07 --> Router Class Initialized
INFO - 2023-10-31 03:18:07 --> Output Class Initialized
INFO - 2023-10-31 03:18:07 --> Security Class Initialized
DEBUG - 2023-10-31 03:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:18:07 --> Input Class Initialized
INFO - 2023-10-31 03:18:07 --> Language Class Initialized
INFO - 2023-10-31 03:18:07 --> Loader Class Initialized
INFO - 2023-10-31 03:18:07 --> Helper loaded: url_helper
INFO - 2023-10-31 03:18:07 --> Helper loaded: file_helper
INFO - 2023-10-31 03:18:07 --> Helper loaded: html_helper
INFO - 2023-10-31 03:18:07 --> Helper loaded: text_helper
INFO - 2023-10-31 03:18:07 --> Helper loaded: form_helper
INFO - 2023-10-31 03:18:07 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:18:07 --> Helper loaded: security_helper
INFO - 2023-10-31 03:18:07 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:18:07 --> Database Driver Class Initialized
INFO - 2023-10-31 03:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:18:07 --> Parser Class Initialized
INFO - 2023-10-31 03:18:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:18:07 --> Pagination Class Initialized
INFO - 2023-10-31 03:18:07 --> Form Validation Class Initialized
INFO - 2023-10-31 03:18:07 --> Controller Class Initialized
DEBUG - 2023-10-31 03:18:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:18:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:18:07 --> Model Class Initialized
DEBUG - 2023-10-31 03:18:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:18:07 --> Model Class Initialized
INFO - 2023-10-31 03:18:07 --> Final output sent to browser
DEBUG - 2023-10-31 03:18:07 --> Total execution time: 0.0218
ERROR - 2023-10-31 03:18:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:18:38 --> Config Class Initialized
INFO - 2023-10-31 03:18:38 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:18:38 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:18:38 --> Utf8 Class Initialized
INFO - 2023-10-31 03:18:38 --> URI Class Initialized
DEBUG - 2023-10-31 03:18:38 --> No URI present. Default controller set.
INFO - 2023-10-31 03:18:38 --> Router Class Initialized
INFO - 2023-10-31 03:18:38 --> Output Class Initialized
INFO - 2023-10-31 03:18:38 --> Security Class Initialized
DEBUG - 2023-10-31 03:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:18:38 --> Input Class Initialized
INFO - 2023-10-31 03:18:38 --> Language Class Initialized
INFO - 2023-10-31 03:18:38 --> Loader Class Initialized
INFO - 2023-10-31 03:18:38 --> Helper loaded: url_helper
INFO - 2023-10-31 03:18:38 --> Helper loaded: file_helper
INFO - 2023-10-31 03:18:38 --> Helper loaded: html_helper
INFO - 2023-10-31 03:18:38 --> Helper loaded: text_helper
INFO - 2023-10-31 03:18:38 --> Helper loaded: form_helper
INFO - 2023-10-31 03:18:38 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:18:38 --> Helper loaded: security_helper
INFO - 2023-10-31 03:18:38 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:18:38 --> Database Driver Class Initialized
INFO - 2023-10-31 03:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:18:38 --> Parser Class Initialized
INFO - 2023-10-31 03:18:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:18:38 --> Pagination Class Initialized
INFO - 2023-10-31 03:18:38 --> Form Validation Class Initialized
INFO - 2023-10-31 03:18:38 --> Controller Class Initialized
INFO - 2023-10-31 03:18:38 --> Model Class Initialized
DEBUG - 2023-10-31 03:18:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:18:38 --> Model Class Initialized
DEBUG - 2023-10-31 03:18:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:18:38 --> Model Class Initialized
INFO - 2023-10-31 03:18:38 --> Model Class Initialized
INFO - 2023-10-31 03:18:38 --> Model Class Initialized
INFO - 2023-10-31 03:18:38 --> Model Class Initialized
DEBUG - 2023-10-31 03:18:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:18:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:18:38 --> Model Class Initialized
INFO - 2023-10-31 03:18:38 --> Model Class Initialized
INFO - 2023-10-31 03:18:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-31 03:18:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:18:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 03:18:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 03:18:38 --> Model Class Initialized
INFO - 2023-10-31 03:18:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 03:18:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 03:18:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 03:18:38 --> Final output sent to browser
DEBUG - 2023-10-31 03:18:38 --> Total execution time: 0.2073
ERROR - 2023-10-31 03:18:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:18:49 --> Config Class Initialized
INFO - 2023-10-31 03:18:49 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:18:49 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:18:49 --> Utf8 Class Initialized
INFO - 2023-10-31 03:18:49 --> URI Class Initialized
INFO - 2023-10-31 03:18:49 --> Router Class Initialized
INFO - 2023-10-31 03:18:49 --> Output Class Initialized
INFO - 2023-10-31 03:18:49 --> Security Class Initialized
DEBUG - 2023-10-31 03:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:18:49 --> Input Class Initialized
INFO - 2023-10-31 03:18:49 --> Language Class Initialized
INFO - 2023-10-31 03:18:49 --> Loader Class Initialized
INFO - 2023-10-31 03:18:49 --> Helper loaded: url_helper
INFO - 2023-10-31 03:18:49 --> Helper loaded: file_helper
INFO - 2023-10-31 03:18:49 --> Helper loaded: html_helper
INFO - 2023-10-31 03:18:49 --> Helper loaded: text_helper
INFO - 2023-10-31 03:18:49 --> Helper loaded: form_helper
INFO - 2023-10-31 03:18:49 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:18:49 --> Helper loaded: security_helper
INFO - 2023-10-31 03:18:49 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:18:49 --> Database Driver Class Initialized
INFO - 2023-10-31 03:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:18:49 --> Parser Class Initialized
INFO - 2023-10-31 03:18:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:18:49 --> Pagination Class Initialized
INFO - 2023-10-31 03:18:49 --> Form Validation Class Initialized
INFO - 2023-10-31 03:18:49 --> Controller Class Initialized
INFO - 2023-10-31 03:18:49 --> Model Class Initialized
DEBUG - 2023-10-31 03:18:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:18:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:18:49 --> Model Class Initialized
DEBUG - 2023-10-31 03:18:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:18:49 --> Model Class Initialized
INFO - 2023-10-31 03:18:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-31 03:18:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:18:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 03:18:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 03:18:49 --> Model Class Initialized
INFO - 2023-10-31 03:18:49 --> Model Class Initialized
INFO - 2023-10-31 03:18:49 --> Model Class Initialized
INFO - 2023-10-31 03:18:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 03:18:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 03:18:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 03:18:49 --> Final output sent to browser
DEBUG - 2023-10-31 03:18:49 --> Total execution time: 0.1366
ERROR - 2023-10-31 03:18:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:18:50 --> Config Class Initialized
INFO - 2023-10-31 03:18:50 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:18:50 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:18:50 --> Utf8 Class Initialized
INFO - 2023-10-31 03:18:50 --> URI Class Initialized
INFO - 2023-10-31 03:18:50 --> Router Class Initialized
INFO - 2023-10-31 03:18:50 --> Output Class Initialized
INFO - 2023-10-31 03:18:50 --> Security Class Initialized
DEBUG - 2023-10-31 03:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:18:50 --> Input Class Initialized
INFO - 2023-10-31 03:18:50 --> Language Class Initialized
INFO - 2023-10-31 03:18:50 --> Loader Class Initialized
INFO - 2023-10-31 03:18:50 --> Helper loaded: url_helper
INFO - 2023-10-31 03:18:50 --> Helper loaded: file_helper
INFO - 2023-10-31 03:18:50 --> Helper loaded: html_helper
INFO - 2023-10-31 03:18:50 --> Helper loaded: text_helper
INFO - 2023-10-31 03:18:50 --> Helper loaded: form_helper
INFO - 2023-10-31 03:18:50 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:18:50 --> Helper loaded: security_helper
INFO - 2023-10-31 03:18:50 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:18:50 --> Database Driver Class Initialized
INFO - 2023-10-31 03:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:18:50 --> Parser Class Initialized
INFO - 2023-10-31 03:18:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:18:50 --> Pagination Class Initialized
INFO - 2023-10-31 03:18:50 --> Form Validation Class Initialized
INFO - 2023-10-31 03:18:50 --> Controller Class Initialized
INFO - 2023-10-31 03:18:50 --> Model Class Initialized
DEBUG - 2023-10-31 03:18:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:18:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:18:50 --> Model Class Initialized
DEBUG - 2023-10-31 03:18:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:18:50 --> Model Class Initialized
INFO - 2023-10-31 03:18:50 --> Final output sent to browser
DEBUG - 2023-10-31 03:18:50 --> Total execution time: 0.0425
ERROR - 2023-10-31 03:18:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:18:53 --> Config Class Initialized
INFO - 2023-10-31 03:18:53 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:18:53 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:18:53 --> Utf8 Class Initialized
INFO - 2023-10-31 03:18:53 --> URI Class Initialized
INFO - 2023-10-31 03:18:53 --> Router Class Initialized
INFO - 2023-10-31 03:18:53 --> Output Class Initialized
INFO - 2023-10-31 03:18:53 --> Security Class Initialized
DEBUG - 2023-10-31 03:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:18:53 --> Input Class Initialized
INFO - 2023-10-31 03:18:53 --> Language Class Initialized
INFO - 2023-10-31 03:18:53 --> Loader Class Initialized
INFO - 2023-10-31 03:18:53 --> Helper loaded: url_helper
INFO - 2023-10-31 03:18:53 --> Helper loaded: file_helper
INFO - 2023-10-31 03:18:53 --> Helper loaded: html_helper
INFO - 2023-10-31 03:18:53 --> Helper loaded: text_helper
INFO - 2023-10-31 03:18:53 --> Helper loaded: form_helper
INFO - 2023-10-31 03:18:53 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:18:53 --> Helper loaded: security_helper
INFO - 2023-10-31 03:18:53 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:18:53 --> Database Driver Class Initialized
INFO - 2023-10-31 03:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:18:53 --> Parser Class Initialized
INFO - 2023-10-31 03:18:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:18:53 --> Pagination Class Initialized
INFO - 2023-10-31 03:18:53 --> Form Validation Class Initialized
INFO - 2023-10-31 03:18:53 --> Controller Class Initialized
INFO - 2023-10-31 03:18:53 --> Model Class Initialized
DEBUG - 2023-10-31 03:18:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:18:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:18:53 --> Model Class Initialized
DEBUG - 2023-10-31 03:18:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:18:53 --> Model Class Initialized
INFO - 2023-10-31 03:18:53 --> Final output sent to browser
DEBUG - 2023-10-31 03:18:53 --> Total execution time: 0.0638
ERROR - 2023-10-31 03:19:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:19:13 --> Config Class Initialized
INFO - 2023-10-31 03:19:13 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:19:13 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:19:13 --> Utf8 Class Initialized
INFO - 2023-10-31 03:19:13 --> URI Class Initialized
INFO - 2023-10-31 03:19:13 --> Router Class Initialized
INFO - 2023-10-31 03:19:13 --> Output Class Initialized
INFO - 2023-10-31 03:19:13 --> Security Class Initialized
DEBUG - 2023-10-31 03:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:19:13 --> Input Class Initialized
INFO - 2023-10-31 03:19:13 --> Language Class Initialized
INFO - 2023-10-31 03:19:13 --> Loader Class Initialized
INFO - 2023-10-31 03:19:13 --> Helper loaded: url_helper
INFO - 2023-10-31 03:19:13 --> Helper loaded: file_helper
INFO - 2023-10-31 03:19:13 --> Helper loaded: html_helper
INFO - 2023-10-31 03:19:13 --> Helper loaded: text_helper
INFO - 2023-10-31 03:19:13 --> Helper loaded: form_helper
INFO - 2023-10-31 03:19:13 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:19:13 --> Helper loaded: security_helper
INFO - 2023-10-31 03:19:13 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:19:13 --> Database Driver Class Initialized
INFO - 2023-10-31 03:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:19:13 --> Parser Class Initialized
INFO - 2023-10-31 03:19:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:19:13 --> Pagination Class Initialized
INFO - 2023-10-31 03:19:13 --> Form Validation Class Initialized
INFO - 2023-10-31 03:19:13 --> Controller Class Initialized
INFO - 2023-10-31 03:19:13 --> Model Class Initialized
DEBUG - 2023-10-31 03:19:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:19:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:19:13 --> Model Class Initialized
DEBUG - 2023-10-31 03:19:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:19:13 --> Model Class Initialized
DEBUG - 2023-10-31 03:19:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:19:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-31 03:19:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:19:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 03:19:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 03:19:13 --> Model Class Initialized
INFO - 2023-10-31 03:19:13 --> Model Class Initialized
INFO - 2023-10-31 03:19:13 --> Model Class Initialized
INFO - 2023-10-31 03:19:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 03:19:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 03:19:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 03:19:13 --> Final output sent to browser
DEBUG - 2023-10-31 03:19:13 --> Total execution time: 0.1529
ERROR - 2023-10-31 03:19:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:19:19 --> Config Class Initialized
INFO - 2023-10-31 03:19:19 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:19:19 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:19:19 --> Utf8 Class Initialized
INFO - 2023-10-31 03:19:19 --> URI Class Initialized
INFO - 2023-10-31 03:19:19 --> Router Class Initialized
INFO - 2023-10-31 03:19:19 --> Output Class Initialized
INFO - 2023-10-31 03:19:19 --> Security Class Initialized
DEBUG - 2023-10-31 03:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:19:19 --> Input Class Initialized
INFO - 2023-10-31 03:19:19 --> Language Class Initialized
INFO - 2023-10-31 03:19:19 --> Loader Class Initialized
INFO - 2023-10-31 03:19:19 --> Helper loaded: url_helper
INFO - 2023-10-31 03:19:19 --> Helper loaded: file_helper
INFO - 2023-10-31 03:19:19 --> Helper loaded: html_helper
INFO - 2023-10-31 03:19:19 --> Helper loaded: text_helper
INFO - 2023-10-31 03:19:19 --> Helper loaded: form_helper
INFO - 2023-10-31 03:19:19 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:19:19 --> Helper loaded: security_helper
INFO - 2023-10-31 03:19:19 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:19:19 --> Database Driver Class Initialized
INFO - 2023-10-31 03:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:19:19 --> Parser Class Initialized
INFO - 2023-10-31 03:19:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:19:19 --> Pagination Class Initialized
INFO - 2023-10-31 03:19:19 --> Form Validation Class Initialized
INFO - 2023-10-31 03:19:19 --> Controller Class Initialized
INFO - 2023-10-31 03:19:19 --> Model Class Initialized
DEBUG - 2023-10-31 03:19:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:19:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:19:19 --> Model Class Initialized
DEBUG - 2023-10-31 03:19:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:19:19 --> Model Class Initialized
INFO - 2023-10-31 03:19:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-31 03:19:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:19:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 03:19:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 03:19:19 --> Model Class Initialized
INFO - 2023-10-31 03:19:19 --> Model Class Initialized
INFO - 2023-10-31 03:19:19 --> Model Class Initialized
INFO - 2023-10-31 03:19:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 03:19:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 03:19:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 03:19:19 --> Final output sent to browser
DEBUG - 2023-10-31 03:19:19 --> Total execution time: 0.1365
ERROR - 2023-10-31 03:19:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:19:20 --> Config Class Initialized
INFO - 2023-10-31 03:19:20 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:19:20 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:19:20 --> Utf8 Class Initialized
INFO - 2023-10-31 03:19:20 --> URI Class Initialized
INFO - 2023-10-31 03:19:20 --> Router Class Initialized
INFO - 2023-10-31 03:19:20 --> Output Class Initialized
INFO - 2023-10-31 03:19:20 --> Security Class Initialized
DEBUG - 2023-10-31 03:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:19:20 --> Input Class Initialized
INFO - 2023-10-31 03:19:20 --> Language Class Initialized
INFO - 2023-10-31 03:19:20 --> Loader Class Initialized
INFO - 2023-10-31 03:19:20 --> Helper loaded: url_helper
INFO - 2023-10-31 03:19:20 --> Helper loaded: file_helper
INFO - 2023-10-31 03:19:20 --> Helper loaded: html_helper
INFO - 2023-10-31 03:19:20 --> Helper loaded: text_helper
INFO - 2023-10-31 03:19:20 --> Helper loaded: form_helper
INFO - 2023-10-31 03:19:20 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:19:20 --> Helper loaded: security_helper
INFO - 2023-10-31 03:19:20 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:19:20 --> Database Driver Class Initialized
INFO - 2023-10-31 03:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:19:20 --> Parser Class Initialized
INFO - 2023-10-31 03:19:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:19:20 --> Pagination Class Initialized
INFO - 2023-10-31 03:19:20 --> Form Validation Class Initialized
INFO - 2023-10-31 03:19:20 --> Controller Class Initialized
INFO - 2023-10-31 03:19:20 --> Model Class Initialized
DEBUG - 2023-10-31 03:19:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:19:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:19:20 --> Model Class Initialized
DEBUG - 2023-10-31 03:19:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:19:20 --> Model Class Initialized
INFO - 2023-10-31 03:19:20 --> Final output sent to browser
DEBUG - 2023-10-31 03:19:20 --> Total execution time: 0.0441
ERROR - 2023-10-31 03:19:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:19:23 --> Config Class Initialized
INFO - 2023-10-31 03:19:23 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:19:23 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:19:23 --> Utf8 Class Initialized
INFO - 2023-10-31 03:19:23 --> URI Class Initialized
INFO - 2023-10-31 03:19:23 --> Router Class Initialized
INFO - 2023-10-31 03:19:23 --> Output Class Initialized
INFO - 2023-10-31 03:19:23 --> Security Class Initialized
DEBUG - 2023-10-31 03:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:19:23 --> Input Class Initialized
INFO - 2023-10-31 03:19:23 --> Language Class Initialized
INFO - 2023-10-31 03:19:23 --> Loader Class Initialized
INFO - 2023-10-31 03:19:23 --> Helper loaded: url_helper
INFO - 2023-10-31 03:19:23 --> Helper loaded: file_helper
INFO - 2023-10-31 03:19:23 --> Helper loaded: html_helper
INFO - 2023-10-31 03:19:23 --> Helper loaded: text_helper
INFO - 2023-10-31 03:19:23 --> Helper loaded: form_helper
INFO - 2023-10-31 03:19:23 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:19:23 --> Helper loaded: security_helper
INFO - 2023-10-31 03:19:23 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:19:23 --> Database Driver Class Initialized
INFO - 2023-10-31 03:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:19:23 --> Parser Class Initialized
INFO - 2023-10-31 03:19:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:19:23 --> Pagination Class Initialized
INFO - 2023-10-31 03:19:23 --> Form Validation Class Initialized
INFO - 2023-10-31 03:19:23 --> Controller Class Initialized
INFO - 2023-10-31 03:19:23 --> Model Class Initialized
DEBUG - 2023-10-31 03:19:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:19:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:19:23 --> Model Class Initialized
DEBUG - 2023-10-31 03:19:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:19:23 --> Model Class Initialized
INFO - 2023-10-31 03:19:23 --> Final output sent to browser
DEBUG - 2023-10-31 03:19:23 --> Total execution time: 0.0627
ERROR - 2023-10-31 03:19:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:19:27 --> Config Class Initialized
INFO - 2023-10-31 03:19:27 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:19:27 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:19:27 --> Utf8 Class Initialized
INFO - 2023-10-31 03:19:27 --> URI Class Initialized
DEBUG - 2023-10-31 03:19:27 --> No URI present. Default controller set.
INFO - 2023-10-31 03:19:27 --> Router Class Initialized
INFO - 2023-10-31 03:19:27 --> Output Class Initialized
INFO - 2023-10-31 03:19:27 --> Security Class Initialized
DEBUG - 2023-10-31 03:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:19:27 --> Input Class Initialized
INFO - 2023-10-31 03:19:27 --> Language Class Initialized
INFO - 2023-10-31 03:19:27 --> Loader Class Initialized
INFO - 2023-10-31 03:19:27 --> Helper loaded: url_helper
INFO - 2023-10-31 03:19:27 --> Helper loaded: file_helper
INFO - 2023-10-31 03:19:27 --> Helper loaded: html_helper
INFO - 2023-10-31 03:19:27 --> Helper loaded: text_helper
INFO - 2023-10-31 03:19:27 --> Helper loaded: form_helper
INFO - 2023-10-31 03:19:27 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:19:27 --> Helper loaded: security_helper
INFO - 2023-10-31 03:19:27 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:19:27 --> Database Driver Class Initialized
INFO - 2023-10-31 03:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:19:27 --> Parser Class Initialized
INFO - 2023-10-31 03:19:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:19:27 --> Pagination Class Initialized
INFO - 2023-10-31 03:19:27 --> Form Validation Class Initialized
INFO - 2023-10-31 03:19:27 --> Controller Class Initialized
INFO - 2023-10-31 03:19:27 --> Model Class Initialized
DEBUG - 2023-10-31 03:19:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:19:27 --> Model Class Initialized
DEBUG - 2023-10-31 03:19:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:19:27 --> Model Class Initialized
INFO - 2023-10-31 03:19:27 --> Model Class Initialized
INFO - 2023-10-31 03:19:27 --> Model Class Initialized
INFO - 2023-10-31 03:19:27 --> Model Class Initialized
DEBUG - 2023-10-31 03:19:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:19:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:19:27 --> Model Class Initialized
INFO - 2023-10-31 03:19:27 --> Model Class Initialized
INFO - 2023-10-31 03:19:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-31 03:19:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:19:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 03:19:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 03:19:27 --> Model Class Initialized
INFO - 2023-10-31 03:19:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 03:19:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 03:19:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 03:19:27 --> Final output sent to browser
DEBUG - 2023-10-31 03:19:27 --> Total execution time: 0.2002
ERROR - 2023-10-31 03:19:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:19:39 --> Config Class Initialized
INFO - 2023-10-31 03:19:39 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:19:39 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:19:39 --> Utf8 Class Initialized
INFO - 2023-10-31 03:19:39 --> URI Class Initialized
INFO - 2023-10-31 03:19:39 --> Router Class Initialized
INFO - 2023-10-31 03:19:39 --> Output Class Initialized
INFO - 2023-10-31 03:19:39 --> Security Class Initialized
DEBUG - 2023-10-31 03:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:19:39 --> Input Class Initialized
INFO - 2023-10-31 03:19:39 --> Language Class Initialized
INFO - 2023-10-31 03:19:39 --> Loader Class Initialized
INFO - 2023-10-31 03:19:39 --> Helper loaded: url_helper
INFO - 2023-10-31 03:19:39 --> Helper loaded: file_helper
INFO - 2023-10-31 03:19:39 --> Helper loaded: html_helper
INFO - 2023-10-31 03:19:39 --> Helper loaded: text_helper
INFO - 2023-10-31 03:19:39 --> Helper loaded: form_helper
INFO - 2023-10-31 03:19:39 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:19:39 --> Helper loaded: security_helper
INFO - 2023-10-31 03:19:39 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:19:39 --> Database Driver Class Initialized
INFO - 2023-10-31 03:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:19:39 --> Parser Class Initialized
INFO - 2023-10-31 03:19:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:19:39 --> Pagination Class Initialized
INFO - 2023-10-31 03:19:39 --> Form Validation Class Initialized
INFO - 2023-10-31 03:19:39 --> Controller Class Initialized
DEBUG - 2023-10-31 03:19:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:19:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:19:39 --> Model Class Initialized
DEBUG - 2023-10-31 03:19:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:19:39 --> Model Class Initialized
DEBUG - 2023-10-31 03:19:39 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:19:39 --> Model Class Initialized
INFO - 2023-10-31 03:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-10-31 03:19:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 03:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 03:19:39 --> Model Class Initialized
INFO - 2023-10-31 03:19:39 --> Model Class Initialized
INFO - 2023-10-31 03:19:39 --> Model Class Initialized
INFO - 2023-10-31 03:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 03:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 03:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 03:19:39 --> Final output sent to browser
DEBUG - 2023-10-31 03:19:39 --> Total execution time: 0.1353
ERROR - 2023-10-31 03:19:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:19:40 --> Config Class Initialized
INFO - 2023-10-31 03:19:40 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:19:40 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:19:40 --> Utf8 Class Initialized
INFO - 2023-10-31 03:19:40 --> URI Class Initialized
INFO - 2023-10-31 03:19:40 --> Router Class Initialized
INFO - 2023-10-31 03:19:40 --> Output Class Initialized
INFO - 2023-10-31 03:19:40 --> Security Class Initialized
DEBUG - 2023-10-31 03:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:19:40 --> Input Class Initialized
INFO - 2023-10-31 03:19:40 --> Language Class Initialized
INFO - 2023-10-31 03:19:40 --> Loader Class Initialized
INFO - 2023-10-31 03:19:40 --> Helper loaded: url_helper
INFO - 2023-10-31 03:19:40 --> Helper loaded: file_helper
INFO - 2023-10-31 03:19:40 --> Helper loaded: html_helper
INFO - 2023-10-31 03:19:40 --> Helper loaded: text_helper
INFO - 2023-10-31 03:19:40 --> Helper loaded: form_helper
INFO - 2023-10-31 03:19:40 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:19:40 --> Helper loaded: security_helper
INFO - 2023-10-31 03:19:40 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:19:40 --> Database Driver Class Initialized
INFO - 2023-10-31 03:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:19:40 --> Parser Class Initialized
INFO - 2023-10-31 03:19:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:19:40 --> Pagination Class Initialized
INFO - 2023-10-31 03:19:40 --> Form Validation Class Initialized
INFO - 2023-10-31 03:19:40 --> Controller Class Initialized
DEBUG - 2023-10-31 03:19:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:19:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:19:40 --> Model Class Initialized
DEBUG - 2023-10-31 03:19:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:19:40 --> Model Class Initialized
INFO - 2023-10-31 03:19:40 --> Final output sent to browser
DEBUG - 2023-10-31 03:19:40 --> Total execution time: 0.0220
ERROR - 2023-10-31 03:19:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:19:43 --> Config Class Initialized
INFO - 2023-10-31 03:19:43 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:19:43 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:19:43 --> Utf8 Class Initialized
INFO - 2023-10-31 03:19:43 --> URI Class Initialized
INFO - 2023-10-31 03:19:43 --> Router Class Initialized
INFO - 2023-10-31 03:19:43 --> Output Class Initialized
INFO - 2023-10-31 03:19:43 --> Security Class Initialized
DEBUG - 2023-10-31 03:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:19:43 --> Input Class Initialized
INFO - 2023-10-31 03:19:43 --> Language Class Initialized
INFO - 2023-10-31 03:19:43 --> Loader Class Initialized
INFO - 2023-10-31 03:19:43 --> Helper loaded: url_helper
INFO - 2023-10-31 03:19:43 --> Helper loaded: file_helper
INFO - 2023-10-31 03:19:43 --> Helper loaded: html_helper
INFO - 2023-10-31 03:19:43 --> Helper loaded: text_helper
INFO - 2023-10-31 03:19:43 --> Helper loaded: form_helper
INFO - 2023-10-31 03:19:43 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:19:43 --> Helper loaded: security_helper
INFO - 2023-10-31 03:19:43 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:19:43 --> Database Driver Class Initialized
INFO - 2023-10-31 03:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:19:43 --> Parser Class Initialized
INFO - 2023-10-31 03:19:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:19:43 --> Pagination Class Initialized
INFO - 2023-10-31 03:19:43 --> Form Validation Class Initialized
INFO - 2023-10-31 03:19:43 --> Controller Class Initialized
DEBUG - 2023-10-31 03:19:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:19:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:19:43 --> Model Class Initialized
DEBUG - 2023-10-31 03:19:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:19:43 --> Model Class Initialized
INFO - 2023-10-31 03:19:43 --> Final output sent to browser
DEBUG - 2023-10-31 03:19:43 --> Total execution time: 0.0206
ERROR - 2023-10-31 03:20:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:20:14 --> Config Class Initialized
INFO - 2023-10-31 03:20:14 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:20:14 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:20:14 --> Utf8 Class Initialized
INFO - 2023-10-31 03:20:14 --> URI Class Initialized
INFO - 2023-10-31 03:20:14 --> Router Class Initialized
INFO - 2023-10-31 03:20:14 --> Output Class Initialized
INFO - 2023-10-31 03:20:14 --> Security Class Initialized
DEBUG - 2023-10-31 03:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:20:14 --> Input Class Initialized
INFO - 2023-10-31 03:20:14 --> Language Class Initialized
INFO - 2023-10-31 03:20:14 --> Loader Class Initialized
INFO - 2023-10-31 03:20:14 --> Helper loaded: url_helper
INFO - 2023-10-31 03:20:14 --> Helper loaded: file_helper
INFO - 2023-10-31 03:20:14 --> Helper loaded: html_helper
INFO - 2023-10-31 03:20:14 --> Helper loaded: text_helper
INFO - 2023-10-31 03:20:14 --> Helper loaded: form_helper
INFO - 2023-10-31 03:20:14 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:20:14 --> Helper loaded: security_helper
INFO - 2023-10-31 03:20:14 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:20:14 --> Database Driver Class Initialized
INFO - 2023-10-31 03:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:20:14 --> Parser Class Initialized
INFO - 2023-10-31 03:20:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:20:14 --> Pagination Class Initialized
INFO - 2023-10-31 03:20:14 --> Form Validation Class Initialized
INFO - 2023-10-31 03:20:14 --> Controller Class Initialized
DEBUG - 2023-10-31 03:20:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:20:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:20:14 --> Model Class Initialized
DEBUG - 2023-10-31 03:20:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:20:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:20:14 --> Ltarget class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:20:14 --> Model Class Initialized
DEBUG - 2023-10-31 03:20:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:20:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:20:14 --> Model Class Initialized
DEBUG - 2023-10-31 03:20:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:20:14 --> Model Class Initialized
INFO - 2023-10-31 03:20:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/target/target.php
DEBUG - 2023-10-31 03:20:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:20:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 03:20:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 03:20:14 --> Model Class Initialized
INFO - 2023-10-31 03:20:14 --> Model Class Initialized
INFO - 2023-10-31 03:20:14 --> Model Class Initialized
INFO - 2023-10-31 03:20:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 03:20:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 03:20:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 03:20:14 --> Final output sent to browser
DEBUG - 2023-10-31 03:20:14 --> Total execution time: 0.1355
ERROR - 2023-10-31 03:20:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:20:15 --> Config Class Initialized
INFO - 2023-10-31 03:20:15 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:20:15 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:20:15 --> Utf8 Class Initialized
INFO - 2023-10-31 03:20:15 --> URI Class Initialized
INFO - 2023-10-31 03:20:15 --> Router Class Initialized
INFO - 2023-10-31 03:20:15 --> Output Class Initialized
INFO - 2023-10-31 03:20:15 --> Security Class Initialized
DEBUG - 2023-10-31 03:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:20:15 --> Input Class Initialized
INFO - 2023-10-31 03:20:15 --> Language Class Initialized
INFO - 2023-10-31 03:20:15 --> Loader Class Initialized
INFO - 2023-10-31 03:20:15 --> Helper loaded: url_helper
INFO - 2023-10-31 03:20:15 --> Helper loaded: file_helper
INFO - 2023-10-31 03:20:15 --> Helper loaded: html_helper
INFO - 2023-10-31 03:20:15 --> Helper loaded: text_helper
INFO - 2023-10-31 03:20:15 --> Helper loaded: form_helper
INFO - 2023-10-31 03:20:15 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:20:15 --> Helper loaded: security_helper
INFO - 2023-10-31 03:20:15 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:20:15 --> Database Driver Class Initialized
INFO - 2023-10-31 03:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:20:15 --> Parser Class Initialized
INFO - 2023-10-31 03:20:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:20:15 --> Pagination Class Initialized
INFO - 2023-10-31 03:20:15 --> Form Validation Class Initialized
INFO - 2023-10-31 03:20:15 --> Controller Class Initialized
DEBUG - 2023-10-31 03:20:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:20:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:20:15 --> Model Class Initialized
DEBUG - 2023-10-31 03:20:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:20:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:20:15 --> Model Class Initialized
DEBUG - 2023-10-31 03:20:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:20:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:20:15 --> Model Class Initialized
DEBUG - 2023-10-31 03:20:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:20:15 --> Model Class Initialized
INFO - 2023-10-31 03:20:15 --> Final output sent to browser
DEBUG - 2023-10-31 03:20:15 --> Total execution time: 0.0228
ERROR - 2023-10-31 03:20:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:20:25 --> Config Class Initialized
INFO - 2023-10-31 03:20:25 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:20:25 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:20:25 --> Utf8 Class Initialized
INFO - 2023-10-31 03:20:25 --> URI Class Initialized
DEBUG - 2023-10-31 03:20:25 --> No URI present. Default controller set.
INFO - 2023-10-31 03:20:25 --> Router Class Initialized
INFO - 2023-10-31 03:20:25 --> Output Class Initialized
INFO - 2023-10-31 03:20:25 --> Security Class Initialized
DEBUG - 2023-10-31 03:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:20:25 --> Input Class Initialized
INFO - 2023-10-31 03:20:25 --> Language Class Initialized
INFO - 2023-10-31 03:20:25 --> Loader Class Initialized
INFO - 2023-10-31 03:20:25 --> Helper loaded: url_helper
INFO - 2023-10-31 03:20:25 --> Helper loaded: file_helper
INFO - 2023-10-31 03:20:25 --> Helper loaded: html_helper
INFO - 2023-10-31 03:20:25 --> Helper loaded: text_helper
INFO - 2023-10-31 03:20:25 --> Helper loaded: form_helper
INFO - 2023-10-31 03:20:25 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:20:25 --> Helper loaded: security_helper
INFO - 2023-10-31 03:20:25 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:20:25 --> Database Driver Class Initialized
INFO - 2023-10-31 03:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:20:25 --> Parser Class Initialized
INFO - 2023-10-31 03:20:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:20:25 --> Pagination Class Initialized
INFO - 2023-10-31 03:20:25 --> Form Validation Class Initialized
INFO - 2023-10-31 03:20:25 --> Controller Class Initialized
INFO - 2023-10-31 03:20:25 --> Model Class Initialized
DEBUG - 2023-10-31 03:20:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:20:25 --> Model Class Initialized
DEBUG - 2023-10-31 03:20:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:20:25 --> Model Class Initialized
INFO - 2023-10-31 03:20:25 --> Model Class Initialized
INFO - 2023-10-31 03:20:25 --> Model Class Initialized
INFO - 2023-10-31 03:20:25 --> Model Class Initialized
DEBUG - 2023-10-31 03:20:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:20:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:20:25 --> Model Class Initialized
INFO - 2023-10-31 03:20:25 --> Model Class Initialized
INFO - 2023-10-31 03:20:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-31 03:20:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:20:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 03:20:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 03:20:25 --> Model Class Initialized
INFO - 2023-10-31 03:20:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 03:20:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 03:20:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 03:20:25 --> Final output sent to browser
DEBUG - 2023-10-31 03:20:25 --> Total execution time: 0.2018
ERROR - 2023-10-31 03:20:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:20:45 --> Config Class Initialized
INFO - 2023-10-31 03:20:45 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:20:45 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:20:45 --> Utf8 Class Initialized
INFO - 2023-10-31 03:20:45 --> URI Class Initialized
INFO - 2023-10-31 03:20:45 --> Router Class Initialized
INFO - 2023-10-31 03:20:45 --> Output Class Initialized
INFO - 2023-10-31 03:20:45 --> Security Class Initialized
DEBUG - 2023-10-31 03:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:20:45 --> Input Class Initialized
INFO - 2023-10-31 03:20:45 --> Language Class Initialized
INFO - 2023-10-31 03:20:45 --> Loader Class Initialized
INFO - 2023-10-31 03:20:45 --> Helper loaded: url_helper
INFO - 2023-10-31 03:20:45 --> Helper loaded: file_helper
INFO - 2023-10-31 03:20:45 --> Helper loaded: html_helper
INFO - 2023-10-31 03:20:45 --> Helper loaded: text_helper
INFO - 2023-10-31 03:20:45 --> Helper loaded: form_helper
INFO - 2023-10-31 03:20:45 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:20:45 --> Helper loaded: security_helper
INFO - 2023-10-31 03:20:45 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:20:45 --> Database Driver Class Initialized
INFO - 2023-10-31 03:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:20:45 --> Parser Class Initialized
INFO - 2023-10-31 03:20:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:20:45 --> Pagination Class Initialized
INFO - 2023-10-31 03:20:45 --> Form Validation Class Initialized
INFO - 2023-10-31 03:20:45 --> Controller Class Initialized
DEBUG - 2023-10-31 03:20:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:20:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:20:45 --> Model Class Initialized
DEBUG - 2023-10-31 03:20:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:20:45 --> Model Class Initialized
DEBUG - 2023-10-31 03:20:45 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:20:45 --> Model Class Initialized
INFO - 2023-10-31 03:20:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-10-31 03:20:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:20:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 03:20:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 03:20:45 --> Model Class Initialized
INFO - 2023-10-31 03:20:45 --> Model Class Initialized
INFO - 2023-10-31 03:20:45 --> Model Class Initialized
INFO - 2023-10-31 03:20:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 03:20:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 03:20:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 03:20:45 --> Final output sent to browser
DEBUG - 2023-10-31 03:20:45 --> Total execution time: 0.1366
ERROR - 2023-10-31 03:20:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:20:45 --> Config Class Initialized
INFO - 2023-10-31 03:20:45 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:20:45 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:20:45 --> Utf8 Class Initialized
INFO - 2023-10-31 03:20:45 --> URI Class Initialized
INFO - 2023-10-31 03:20:45 --> Router Class Initialized
INFO - 2023-10-31 03:20:45 --> Output Class Initialized
INFO - 2023-10-31 03:20:45 --> Security Class Initialized
DEBUG - 2023-10-31 03:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:20:45 --> Input Class Initialized
INFO - 2023-10-31 03:20:45 --> Language Class Initialized
INFO - 2023-10-31 03:20:45 --> Loader Class Initialized
INFO - 2023-10-31 03:20:45 --> Helper loaded: url_helper
INFO - 2023-10-31 03:20:45 --> Helper loaded: file_helper
INFO - 2023-10-31 03:20:45 --> Helper loaded: html_helper
INFO - 2023-10-31 03:20:45 --> Helper loaded: text_helper
INFO - 2023-10-31 03:20:45 --> Helper loaded: form_helper
INFO - 2023-10-31 03:20:45 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:20:45 --> Helper loaded: security_helper
INFO - 2023-10-31 03:20:45 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:20:45 --> Database Driver Class Initialized
INFO - 2023-10-31 03:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:20:45 --> Parser Class Initialized
INFO - 2023-10-31 03:20:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:20:45 --> Pagination Class Initialized
INFO - 2023-10-31 03:20:45 --> Form Validation Class Initialized
INFO - 2023-10-31 03:20:45 --> Controller Class Initialized
DEBUG - 2023-10-31 03:20:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:20:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:20:45 --> Model Class Initialized
DEBUG - 2023-10-31 03:20:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:20:45 --> Model Class Initialized
INFO - 2023-10-31 03:20:45 --> Final output sent to browser
DEBUG - 2023-10-31 03:20:45 --> Total execution time: 0.0212
ERROR - 2023-10-31 03:20:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:20:49 --> Config Class Initialized
INFO - 2023-10-31 03:20:49 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:20:49 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:20:49 --> Utf8 Class Initialized
INFO - 2023-10-31 03:20:49 --> URI Class Initialized
INFO - 2023-10-31 03:20:49 --> Router Class Initialized
INFO - 2023-10-31 03:20:49 --> Output Class Initialized
INFO - 2023-10-31 03:20:49 --> Security Class Initialized
DEBUG - 2023-10-31 03:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:20:49 --> Input Class Initialized
INFO - 2023-10-31 03:20:49 --> Language Class Initialized
INFO - 2023-10-31 03:20:49 --> Loader Class Initialized
INFO - 2023-10-31 03:20:49 --> Helper loaded: url_helper
INFO - 2023-10-31 03:20:49 --> Helper loaded: file_helper
INFO - 2023-10-31 03:20:49 --> Helper loaded: html_helper
INFO - 2023-10-31 03:20:49 --> Helper loaded: text_helper
INFO - 2023-10-31 03:20:49 --> Helper loaded: form_helper
INFO - 2023-10-31 03:20:49 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:20:49 --> Helper loaded: security_helper
INFO - 2023-10-31 03:20:49 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:20:49 --> Database Driver Class Initialized
INFO - 2023-10-31 03:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:20:49 --> Parser Class Initialized
INFO - 2023-10-31 03:20:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:20:49 --> Pagination Class Initialized
INFO - 2023-10-31 03:20:49 --> Form Validation Class Initialized
INFO - 2023-10-31 03:20:49 --> Controller Class Initialized
DEBUG - 2023-10-31 03:20:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:20:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:20:49 --> Model Class Initialized
DEBUG - 2023-10-31 03:20:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:20:49 --> Model Class Initialized
INFO - 2023-10-31 03:20:49 --> Final output sent to browser
DEBUG - 2023-10-31 03:20:49 --> Total execution time: 0.0237
ERROR - 2023-10-31 03:37:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:37:23 --> Config Class Initialized
INFO - 2023-10-31 03:37:23 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:37:23 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:37:23 --> Utf8 Class Initialized
INFO - 2023-10-31 03:37:23 --> URI Class Initialized
DEBUG - 2023-10-31 03:37:23 --> No URI present. Default controller set.
INFO - 2023-10-31 03:37:23 --> Router Class Initialized
INFO - 2023-10-31 03:37:23 --> Output Class Initialized
INFO - 2023-10-31 03:37:23 --> Security Class Initialized
DEBUG - 2023-10-31 03:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:37:23 --> Input Class Initialized
INFO - 2023-10-31 03:37:23 --> Language Class Initialized
INFO - 2023-10-31 03:37:23 --> Loader Class Initialized
INFO - 2023-10-31 03:37:23 --> Helper loaded: url_helper
INFO - 2023-10-31 03:37:23 --> Helper loaded: file_helper
INFO - 2023-10-31 03:37:23 --> Helper loaded: html_helper
INFO - 2023-10-31 03:37:23 --> Helper loaded: text_helper
INFO - 2023-10-31 03:37:23 --> Helper loaded: form_helper
INFO - 2023-10-31 03:37:23 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:37:23 --> Helper loaded: security_helper
INFO - 2023-10-31 03:37:23 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:37:23 --> Database Driver Class Initialized
INFO - 2023-10-31 03:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:37:23 --> Parser Class Initialized
INFO - 2023-10-31 03:37:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:37:23 --> Pagination Class Initialized
INFO - 2023-10-31 03:37:23 --> Form Validation Class Initialized
INFO - 2023-10-31 03:37:23 --> Controller Class Initialized
INFO - 2023-10-31 03:37:23 --> Model Class Initialized
DEBUG - 2023-10-31 03:37:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-31 03:37:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:37:24 --> Config Class Initialized
INFO - 2023-10-31 03:37:24 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:37:24 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:37:24 --> Utf8 Class Initialized
INFO - 2023-10-31 03:37:24 --> URI Class Initialized
INFO - 2023-10-31 03:37:24 --> Router Class Initialized
INFO - 2023-10-31 03:37:24 --> Output Class Initialized
INFO - 2023-10-31 03:37:24 --> Security Class Initialized
DEBUG - 2023-10-31 03:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:37:24 --> Input Class Initialized
INFO - 2023-10-31 03:37:24 --> Language Class Initialized
INFO - 2023-10-31 03:37:24 --> Loader Class Initialized
INFO - 2023-10-31 03:37:24 --> Helper loaded: url_helper
INFO - 2023-10-31 03:37:24 --> Helper loaded: file_helper
INFO - 2023-10-31 03:37:24 --> Helper loaded: html_helper
INFO - 2023-10-31 03:37:24 --> Helper loaded: text_helper
INFO - 2023-10-31 03:37:24 --> Helper loaded: form_helper
INFO - 2023-10-31 03:37:24 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:37:24 --> Helper loaded: security_helper
INFO - 2023-10-31 03:37:24 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:37:24 --> Database Driver Class Initialized
INFO - 2023-10-31 03:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:37:24 --> Parser Class Initialized
INFO - 2023-10-31 03:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:37:24 --> Pagination Class Initialized
INFO - 2023-10-31 03:37:24 --> Form Validation Class Initialized
INFO - 2023-10-31 03:37:24 --> Controller Class Initialized
INFO - 2023-10-31 03:37:24 --> Model Class Initialized
DEBUG - 2023-10-31 03:37:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:37:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-31 03:37:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:37:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 03:37:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 03:37:24 --> Model Class Initialized
INFO - 2023-10-31 03:37:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 03:37:24 --> Final output sent to browser
DEBUG - 2023-10-31 03:37:24 --> Total execution time: 0.0302
ERROR - 2023-10-31 03:37:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:37:55 --> Config Class Initialized
INFO - 2023-10-31 03:37:55 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:37:55 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:37:55 --> Utf8 Class Initialized
INFO - 2023-10-31 03:37:55 --> URI Class Initialized
INFO - 2023-10-31 03:37:55 --> Router Class Initialized
INFO - 2023-10-31 03:37:55 --> Output Class Initialized
INFO - 2023-10-31 03:37:55 --> Security Class Initialized
DEBUG - 2023-10-31 03:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:37:55 --> Input Class Initialized
INFO - 2023-10-31 03:37:55 --> Language Class Initialized
INFO - 2023-10-31 03:37:55 --> Loader Class Initialized
INFO - 2023-10-31 03:37:55 --> Helper loaded: url_helper
INFO - 2023-10-31 03:37:55 --> Helper loaded: file_helper
INFO - 2023-10-31 03:37:55 --> Helper loaded: html_helper
INFO - 2023-10-31 03:37:55 --> Helper loaded: text_helper
INFO - 2023-10-31 03:37:55 --> Helper loaded: form_helper
INFO - 2023-10-31 03:37:55 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:37:55 --> Helper loaded: security_helper
INFO - 2023-10-31 03:37:55 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:37:55 --> Database Driver Class Initialized
INFO - 2023-10-31 03:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:37:55 --> Parser Class Initialized
INFO - 2023-10-31 03:37:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:37:55 --> Pagination Class Initialized
INFO - 2023-10-31 03:37:55 --> Form Validation Class Initialized
INFO - 2023-10-31 03:37:55 --> Controller Class Initialized
INFO - 2023-10-31 03:37:55 --> Model Class Initialized
DEBUG - 2023-10-31 03:37:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:37:55 --> Model Class Initialized
INFO - 2023-10-31 03:37:55 --> Final output sent to browser
DEBUG - 2023-10-31 03:37:55 --> Total execution time: 0.0199
ERROR - 2023-10-31 03:37:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:37:56 --> Config Class Initialized
INFO - 2023-10-31 03:37:56 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:37:56 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:37:56 --> Utf8 Class Initialized
INFO - 2023-10-31 03:37:56 --> URI Class Initialized
DEBUG - 2023-10-31 03:37:56 --> No URI present. Default controller set.
INFO - 2023-10-31 03:37:56 --> Router Class Initialized
INFO - 2023-10-31 03:37:56 --> Output Class Initialized
INFO - 2023-10-31 03:37:56 --> Security Class Initialized
DEBUG - 2023-10-31 03:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:37:56 --> Input Class Initialized
INFO - 2023-10-31 03:37:56 --> Language Class Initialized
INFO - 2023-10-31 03:37:56 --> Loader Class Initialized
INFO - 2023-10-31 03:37:56 --> Helper loaded: url_helper
INFO - 2023-10-31 03:37:56 --> Helper loaded: file_helper
INFO - 2023-10-31 03:37:56 --> Helper loaded: html_helper
INFO - 2023-10-31 03:37:56 --> Helper loaded: text_helper
INFO - 2023-10-31 03:37:56 --> Helper loaded: form_helper
INFO - 2023-10-31 03:37:56 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:37:56 --> Helper loaded: security_helper
INFO - 2023-10-31 03:37:56 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:37:56 --> Database Driver Class Initialized
INFO - 2023-10-31 03:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:37:56 --> Parser Class Initialized
INFO - 2023-10-31 03:37:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:37:56 --> Pagination Class Initialized
INFO - 2023-10-31 03:37:56 --> Form Validation Class Initialized
INFO - 2023-10-31 03:37:56 --> Controller Class Initialized
INFO - 2023-10-31 03:37:56 --> Model Class Initialized
DEBUG - 2023-10-31 03:37:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:37:56 --> Model Class Initialized
DEBUG - 2023-10-31 03:37:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:37:56 --> Model Class Initialized
INFO - 2023-10-31 03:37:56 --> Model Class Initialized
INFO - 2023-10-31 03:37:56 --> Model Class Initialized
INFO - 2023-10-31 03:37:56 --> Model Class Initialized
DEBUG - 2023-10-31 03:37:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:37:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:37:56 --> Model Class Initialized
INFO - 2023-10-31 03:37:56 --> Model Class Initialized
INFO - 2023-10-31 03:37:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-31 03:37:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:37:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 03:37:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 03:37:56 --> Model Class Initialized
INFO - 2023-10-31 03:37:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 03:37:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 03:37:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 03:37:56 --> Final output sent to browser
DEBUG - 2023-10-31 03:37:56 --> Total execution time: 0.2064
ERROR - 2023-10-31 03:38:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:38:09 --> Config Class Initialized
INFO - 2023-10-31 03:38:09 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:38:09 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:38:09 --> Utf8 Class Initialized
INFO - 2023-10-31 03:38:09 --> URI Class Initialized
INFO - 2023-10-31 03:38:09 --> Router Class Initialized
INFO - 2023-10-31 03:38:09 --> Output Class Initialized
INFO - 2023-10-31 03:38:09 --> Security Class Initialized
DEBUG - 2023-10-31 03:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:38:09 --> Input Class Initialized
INFO - 2023-10-31 03:38:09 --> Language Class Initialized
INFO - 2023-10-31 03:38:09 --> Loader Class Initialized
INFO - 2023-10-31 03:38:09 --> Helper loaded: url_helper
INFO - 2023-10-31 03:38:09 --> Helper loaded: file_helper
INFO - 2023-10-31 03:38:09 --> Helper loaded: html_helper
INFO - 2023-10-31 03:38:09 --> Helper loaded: text_helper
INFO - 2023-10-31 03:38:09 --> Helper loaded: form_helper
INFO - 2023-10-31 03:38:09 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:38:09 --> Helper loaded: security_helper
INFO - 2023-10-31 03:38:09 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:38:09 --> Database Driver Class Initialized
INFO - 2023-10-31 03:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:38:09 --> Parser Class Initialized
INFO - 2023-10-31 03:38:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:38:09 --> Pagination Class Initialized
INFO - 2023-10-31 03:38:09 --> Form Validation Class Initialized
INFO - 2023-10-31 03:38:09 --> Controller Class Initialized
INFO - 2023-10-31 03:38:09 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:38:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:09 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:09 --> Model Class Initialized
INFO - 2023-10-31 03:38:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-31 03:38:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 03:38:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 03:38:09 --> Model Class Initialized
INFO - 2023-10-31 03:38:09 --> Model Class Initialized
INFO - 2023-10-31 03:38:09 --> Model Class Initialized
INFO - 2023-10-31 03:38:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 03:38:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 03:38:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 03:38:09 --> Final output sent to browser
DEBUG - 2023-10-31 03:38:09 --> Total execution time: 0.1416
ERROR - 2023-10-31 03:38:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:38:10 --> Config Class Initialized
INFO - 2023-10-31 03:38:10 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:38:10 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:38:10 --> Utf8 Class Initialized
INFO - 2023-10-31 03:38:10 --> URI Class Initialized
INFO - 2023-10-31 03:38:10 --> Router Class Initialized
INFO - 2023-10-31 03:38:10 --> Output Class Initialized
INFO - 2023-10-31 03:38:10 --> Security Class Initialized
DEBUG - 2023-10-31 03:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:38:10 --> Input Class Initialized
INFO - 2023-10-31 03:38:10 --> Language Class Initialized
INFO - 2023-10-31 03:38:10 --> Loader Class Initialized
INFO - 2023-10-31 03:38:10 --> Helper loaded: url_helper
INFO - 2023-10-31 03:38:10 --> Helper loaded: file_helper
INFO - 2023-10-31 03:38:10 --> Helper loaded: html_helper
INFO - 2023-10-31 03:38:10 --> Helper loaded: text_helper
INFO - 2023-10-31 03:38:10 --> Helper loaded: form_helper
INFO - 2023-10-31 03:38:10 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:38:10 --> Helper loaded: security_helper
INFO - 2023-10-31 03:38:10 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:38:10 --> Database Driver Class Initialized
INFO - 2023-10-31 03:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:38:10 --> Parser Class Initialized
INFO - 2023-10-31 03:38:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:38:10 --> Pagination Class Initialized
INFO - 2023-10-31 03:38:10 --> Form Validation Class Initialized
INFO - 2023-10-31 03:38:10 --> Controller Class Initialized
INFO - 2023-10-31 03:38:10 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:38:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:10 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:10 --> Model Class Initialized
INFO - 2023-10-31 03:38:10 --> Final output sent to browser
DEBUG - 2023-10-31 03:38:10 --> Total execution time: 0.0428
ERROR - 2023-10-31 03:38:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:38:15 --> Config Class Initialized
INFO - 2023-10-31 03:38:15 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:38:15 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:38:15 --> Utf8 Class Initialized
INFO - 2023-10-31 03:38:15 --> URI Class Initialized
INFO - 2023-10-31 03:38:15 --> Router Class Initialized
INFO - 2023-10-31 03:38:15 --> Output Class Initialized
INFO - 2023-10-31 03:38:15 --> Security Class Initialized
DEBUG - 2023-10-31 03:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:38:15 --> Input Class Initialized
INFO - 2023-10-31 03:38:15 --> Language Class Initialized
INFO - 2023-10-31 03:38:15 --> Loader Class Initialized
INFO - 2023-10-31 03:38:15 --> Helper loaded: url_helper
INFO - 2023-10-31 03:38:15 --> Helper loaded: file_helper
INFO - 2023-10-31 03:38:15 --> Helper loaded: html_helper
INFO - 2023-10-31 03:38:15 --> Helper loaded: text_helper
INFO - 2023-10-31 03:38:15 --> Helper loaded: form_helper
INFO - 2023-10-31 03:38:15 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:38:15 --> Helper loaded: security_helper
INFO - 2023-10-31 03:38:15 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:38:15 --> Database Driver Class Initialized
INFO - 2023-10-31 03:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:38:15 --> Parser Class Initialized
INFO - 2023-10-31 03:38:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:38:15 --> Pagination Class Initialized
INFO - 2023-10-31 03:38:15 --> Form Validation Class Initialized
INFO - 2023-10-31 03:38:15 --> Controller Class Initialized
INFO - 2023-10-31 03:38:15 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:38:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:15 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:15 --> Model Class Initialized
INFO - 2023-10-31 03:38:15 --> Final output sent to browser
DEBUG - 2023-10-31 03:38:15 --> Total execution time: 0.0424
ERROR - 2023-10-31 03:38:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:38:15 --> Config Class Initialized
INFO - 2023-10-31 03:38:15 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:38:15 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:38:15 --> Utf8 Class Initialized
INFO - 2023-10-31 03:38:15 --> URI Class Initialized
INFO - 2023-10-31 03:38:15 --> Router Class Initialized
INFO - 2023-10-31 03:38:15 --> Output Class Initialized
INFO - 2023-10-31 03:38:15 --> Security Class Initialized
DEBUG - 2023-10-31 03:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:38:15 --> Input Class Initialized
INFO - 2023-10-31 03:38:15 --> Language Class Initialized
INFO - 2023-10-31 03:38:15 --> Loader Class Initialized
INFO - 2023-10-31 03:38:15 --> Helper loaded: url_helper
INFO - 2023-10-31 03:38:15 --> Helper loaded: file_helper
INFO - 2023-10-31 03:38:15 --> Helper loaded: html_helper
INFO - 2023-10-31 03:38:15 --> Helper loaded: text_helper
INFO - 2023-10-31 03:38:15 --> Helper loaded: form_helper
INFO - 2023-10-31 03:38:15 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:38:15 --> Helper loaded: security_helper
INFO - 2023-10-31 03:38:15 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:38:15 --> Database Driver Class Initialized
INFO - 2023-10-31 03:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:38:15 --> Parser Class Initialized
INFO - 2023-10-31 03:38:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:38:15 --> Pagination Class Initialized
INFO - 2023-10-31 03:38:15 --> Form Validation Class Initialized
INFO - 2023-10-31 03:38:15 --> Controller Class Initialized
INFO - 2023-10-31 03:38:15 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:38:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:15 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:15 --> Model Class Initialized
INFO - 2023-10-31 03:38:15 --> Final output sent to browser
DEBUG - 2023-10-31 03:38:15 --> Total execution time: 0.0431
ERROR - 2023-10-31 03:38:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:38:16 --> Config Class Initialized
INFO - 2023-10-31 03:38:16 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:38:16 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:38:16 --> Utf8 Class Initialized
INFO - 2023-10-31 03:38:16 --> URI Class Initialized
INFO - 2023-10-31 03:38:16 --> Router Class Initialized
INFO - 2023-10-31 03:38:16 --> Output Class Initialized
INFO - 2023-10-31 03:38:16 --> Security Class Initialized
DEBUG - 2023-10-31 03:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:38:16 --> Input Class Initialized
INFO - 2023-10-31 03:38:16 --> Language Class Initialized
INFO - 2023-10-31 03:38:16 --> Loader Class Initialized
INFO - 2023-10-31 03:38:16 --> Helper loaded: url_helper
INFO - 2023-10-31 03:38:16 --> Helper loaded: file_helper
INFO - 2023-10-31 03:38:16 --> Helper loaded: html_helper
INFO - 2023-10-31 03:38:16 --> Helper loaded: text_helper
INFO - 2023-10-31 03:38:16 --> Helper loaded: form_helper
INFO - 2023-10-31 03:38:16 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:38:16 --> Helper loaded: security_helper
INFO - 2023-10-31 03:38:16 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:38:16 --> Database Driver Class Initialized
INFO - 2023-10-31 03:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:38:16 --> Parser Class Initialized
INFO - 2023-10-31 03:38:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:38:16 --> Pagination Class Initialized
INFO - 2023-10-31 03:38:16 --> Form Validation Class Initialized
INFO - 2023-10-31 03:38:16 --> Controller Class Initialized
INFO - 2023-10-31 03:38:16 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:38:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:16 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:16 --> Model Class Initialized
INFO - 2023-10-31 03:38:16 --> Final output sent to browser
DEBUG - 2023-10-31 03:38:16 --> Total execution time: 0.0397
ERROR - 2023-10-31 03:38:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:38:17 --> Config Class Initialized
INFO - 2023-10-31 03:38:17 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:38:17 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:38:17 --> Utf8 Class Initialized
INFO - 2023-10-31 03:38:17 --> URI Class Initialized
INFO - 2023-10-31 03:38:17 --> Router Class Initialized
INFO - 2023-10-31 03:38:17 --> Output Class Initialized
INFO - 2023-10-31 03:38:17 --> Security Class Initialized
DEBUG - 2023-10-31 03:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:38:17 --> Input Class Initialized
INFO - 2023-10-31 03:38:17 --> Language Class Initialized
INFO - 2023-10-31 03:38:17 --> Loader Class Initialized
INFO - 2023-10-31 03:38:17 --> Helper loaded: url_helper
INFO - 2023-10-31 03:38:17 --> Helper loaded: file_helper
INFO - 2023-10-31 03:38:17 --> Helper loaded: html_helper
INFO - 2023-10-31 03:38:17 --> Helper loaded: text_helper
INFO - 2023-10-31 03:38:17 --> Helper loaded: form_helper
INFO - 2023-10-31 03:38:17 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:38:17 --> Helper loaded: security_helper
INFO - 2023-10-31 03:38:17 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:38:17 --> Database Driver Class Initialized
INFO - 2023-10-31 03:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:38:17 --> Parser Class Initialized
INFO - 2023-10-31 03:38:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:38:17 --> Pagination Class Initialized
INFO - 2023-10-31 03:38:17 --> Form Validation Class Initialized
INFO - 2023-10-31 03:38:17 --> Controller Class Initialized
INFO - 2023-10-31 03:38:17 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:38:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:17 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:17 --> Model Class Initialized
INFO - 2023-10-31 03:38:17 --> Final output sent to browser
DEBUG - 2023-10-31 03:38:17 --> Total execution time: 0.0433
ERROR - 2023-10-31 03:38:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:38:17 --> Config Class Initialized
INFO - 2023-10-31 03:38:17 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:38:17 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:38:17 --> Utf8 Class Initialized
INFO - 2023-10-31 03:38:17 --> URI Class Initialized
INFO - 2023-10-31 03:38:17 --> Router Class Initialized
INFO - 2023-10-31 03:38:17 --> Output Class Initialized
INFO - 2023-10-31 03:38:17 --> Security Class Initialized
DEBUG - 2023-10-31 03:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:38:17 --> Input Class Initialized
INFO - 2023-10-31 03:38:17 --> Language Class Initialized
INFO - 2023-10-31 03:38:17 --> Loader Class Initialized
INFO - 2023-10-31 03:38:17 --> Helper loaded: url_helper
INFO - 2023-10-31 03:38:17 --> Helper loaded: file_helper
INFO - 2023-10-31 03:38:17 --> Helper loaded: html_helper
INFO - 2023-10-31 03:38:17 --> Helper loaded: text_helper
INFO - 2023-10-31 03:38:17 --> Helper loaded: form_helper
INFO - 2023-10-31 03:38:17 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:38:17 --> Helper loaded: security_helper
INFO - 2023-10-31 03:38:17 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:38:17 --> Database Driver Class Initialized
INFO - 2023-10-31 03:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:38:17 --> Parser Class Initialized
INFO - 2023-10-31 03:38:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:38:17 --> Pagination Class Initialized
INFO - 2023-10-31 03:38:17 --> Form Validation Class Initialized
INFO - 2023-10-31 03:38:17 --> Controller Class Initialized
INFO - 2023-10-31 03:38:17 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:38:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:17 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:17 --> Model Class Initialized
INFO - 2023-10-31 03:38:17 --> Final output sent to browser
DEBUG - 2023-10-31 03:38:17 --> Total execution time: 0.0405
ERROR - 2023-10-31 03:38:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:38:25 --> Config Class Initialized
INFO - 2023-10-31 03:38:25 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:38:25 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:38:25 --> Utf8 Class Initialized
INFO - 2023-10-31 03:38:25 --> URI Class Initialized
INFO - 2023-10-31 03:38:25 --> Router Class Initialized
INFO - 2023-10-31 03:38:25 --> Output Class Initialized
INFO - 2023-10-31 03:38:25 --> Security Class Initialized
DEBUG - 2023-10-31 03:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:38:25 --> Input Class Initialized
INFO - 2023-10-31 03:38:25 --> Language Class Initialized
INFO - 2023-10-31 03:38:25 --> Loader Class Initialized
INFO - 2023-10-31 03:38:25 --> Helper loaded: url_helper
INFO - 2023-10-31 03:38:25 --> Helper loaded: file_helper
INFO - 2023-10-31 03:38:25 --> Helper loaded: html_helper
INFO - 2023-10-31 03:38:25 --> Helper loaded: text_helper
INFO - 2023-10-31 03:38:25 --> Helper loaded: form_helper
INFO - 2023-10-31 03:38:25 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:38:25 --> Helper loaded: security_helper
INFO - 2023-10-31 03:38:25 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:38:25 --> Database Driver Class Initialized
INFO - 2023-10-31 03:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:38:25 --> Parser Class Initialized
INFO - 2023-10-31 03:38:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:38:25 --> Pagination Class Initialized
INFO - 2023-10-31 03:38:25 --> Form Validation Class Initialized
INFO - 2023-10-31 03:38:25 --> Controller Class Initialized
INFO - 2023-10-31 03:38:25 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:38:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:25 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:25 --> Model Class Initialized
INFO - 2023-10-31 03:38:25 --> Final output sent to browser
DEBUG - 2023-10-31 03:38:25 --> Total execution time: 0.0265
ERROR - 2023-10-31 03:38:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:38:26 --> Config Class Initialized
INFO - 2023-10-31 03:38:26 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:38:26 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:38:26 --> Utf8 Class Initialized
INFO - 2023-10-31 03:38:26 --> URI Class Initialized
INFO - 2023-10-31 03:38:26 --> Router Class Initialized
INFO - 2023-10-31 03:38:26 --> Output Class Initialized
INFO - 2023-10-31 03:38:26 --> Security Class Initialized
DEBUG - 2023-10-31 03:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:38:26 --> Input Class Initialized
INFO - 2023-10-31 03:38:26 --> Language Class Initialized
INFO - 2023-10-31 03:38:26 --> Loader Class Initialized
INFO - 2023-10-31 03:38:26 --> Helper loaded: url_helper
INFO - 2023-10-31 03:38:26 --> Helper loaded: file_helper
INFO - 2023-10-31 03:38:26 --> Helper loaded: html_helper
INFO - 2023-10-31 03:38:26 --> Helper loaded: text_helper
INFO - 2023-10-31 03:38:26 --> Helper loaded: form_helper
INFO - 2023-10-31 03:38:26 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:38:26 --> Helper loaded: security_helper
INFO - 2023-10-31 03:38:26 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:38:26 --> Database Driver Class Initialized
INFO - 2023-10-31 03:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:38:26 --> Parser Class Initialized
INFO - 2023-10-31 03:38:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:38:26 --> Pagination Class Initialized
INFO - 2023-10-31 03:38:26 --> Form Validation Class Initialized
INFO - 2023-10-31 03:38:26 --> Controller Class Initialized
INFO - 2023-10-31 03:38:26 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:38:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:26 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:26 --> Model Class Initialized
INFO - 2023-10-31 03:38:26 --> Final output sent to browser
DEBUG - 2023-10-31 03:38:26 --> Total execution time: 0.0220
ERROR - 2023-10-31 03:38:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:38:26 --> Config Class Initialized
INFO - 2023-10-31 03:38:26 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:38:26 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:38:26 --> Utf8 Class Initialized
INFO - 2023-10-31 03:38:26 --> URI Class Initialized
INFO - 2023-10-31 03:38:26 --> Router Class Initialized
INFO - 2023-10-31 03:38:26 --> Output Class Initialized
INFO - 2023-10-31 03:38:26 --> Security Class Initialized
DEBUG - 2023-10-31 03:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:38:26 --> Input Class Initialized
INFO - 2023-10-31 03:38:26 --> Language Class Initialized
INFO - 2023-10-31 03:38:26 --> Loader Class Initialized
INFO - 2023-10-31 03:38:26 --> Helper loaded: url_helper
INFO - 2023-10-31 03:38:26 --> Helper loaded: file_helper
INFO - 2023-10-31 03:38:26 --> Helper loaded: html_helper
INFO - 2023-10-31 03:38:26 --> Helper loaded: text_helper
INFO - 2023-10-31 03:38:26 --> Helper loaded: form_helper
INFO - 2023-10-31 03:38:26 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:38:26 --> Helper loaded: security_helper
INFO - 2023-10-31 03:38:26 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:38:26 --> Database Driver Class Initialized
INFO - 2023-10-31 03:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:38:26 --> Parser Class Initialized
INFO - 2023-10-31 03:38:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:38:26 --> Pagination Class Initialized
INFO - 2023-10-31 03:38:26 --> Form Validation Class Initialized
INFO - 2023-10-31 03:38:26 --> Controller Class Initialized
INFO - 2023-10-31 03:38:26 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:38:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:26 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:26 --> Model Class Initialized
INFO - 2023-10-31 03:38:26 --> Final output sent to browser
DEBUG - 2023-10-31 03:38:26 --> Total execution time: 0.0219
ERROR - 2023-10-31 03:38:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:38:32 --> Config Class Initialized
INFO - 2023-10-31 03:38:32 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:38:32 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:38:32 --> Utf8 Class Initialized
INFO - 2023-10-31 03:38:32 --> URI Class Initialized
INFO - 2023-10-31 03:38:32 --> Router Class Initialized
INFO - 2023-10-31 03:38:32 --> Output Class Initialized
INFO - 2023-10-31 03:38:32 --> Security Class Initialized
DEBUG - 2023-10-31 03:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:38:32 --> Input Class Initialized
INFO - 2023-10-31 03:38:32 --> Language Class Initialized
INFO - 2023-10-31 03:38:32 --> Loader Class Initialized
INFO - 2023-10-31 03:38:32 --> Helper loaded: url_helper
INFO - 2023-10-31 03:38:32 --> Helper loaded: file_helper
INFO - 2023-10-31 03:38:32 --> Helper loaded: html_helper
INFO - 2023-10-31 03:38:32 --> Helper loaded: text_helper
INFO - 2023-10-31 03:38:32 --> Helper loaded: form_helper
INFO - 2023-10-31 03:38:32 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:38:32 --> Helper loaded: security_helper
INFO - 2023-10-31 03:38:32 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:38:32 --> Database Driver Class Initialized
INFO - 2023-10-31 03:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:38:32 --> Parser Class Initialized
INFO - 2023-10-31 03:38:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:38:32 --> Pagination Class Initialized
INFO - 2023-10-31 03:38:32 --> Form Validation Class Initialized
INFO - 2023-10-31 03:38:32 --> Controller Class Initialized
INFO - 2023-10-31 03:38:32 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:32 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:32 --> Model Class Initialized
INFO - 2023-10-31 03:38:32 --> Final output sent to browser
DEBUG - 2023-10-31 03:38:32 --> Total execution time: 0.0269
ERROR - 2023-10-31 03:38:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:38:37 --> Config Class Initialized
INFO - 2023-10-31 03:38:37 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:38:37 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:38:37 --> Utf8 Class Initialized
INFO - 2023-10-31 03:38:37 --> URI Class Initialized
INFO - 2023-10-31 03:38:37 --> Router Class Initialized
INFO - 2023-10-31 03:38:37 --> Output Class Initialized
INFO - 2023-10-31 03:38:37 --> Security Class Initialized
DEBUG - 2023-10-31 03:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:38:37 --> Input Class Initialized
INFO - 2023-10-31 03:38:37 --> Language Class Initialized
INFO - 2023-10-31 03:38:37 --> Loader Class Initialized
INFO - 2023-10-31 03:38:37 --> Helper loaded: url_helper
INFO - 2023-10-31 03:38:37 --> Helper loaded: file_helper
INFO - 2023-10-31 03:38:37 --> Helper loaded: html_helper
INFO - 2023-10-31 03:38:37 --> Helper loaded: text_helper
INFO - 2023-10-31 03:38:37 --> Helper loaded: form_helper
INFO - 2023-10-31 03:38:37 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:38:37 --> Helper loaded: security_helper
INFO - 2023-10-31 03:38:37 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:38:37 --> Database Driver Class Initialized
INFO - 2023-10-31 03:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:38:37 --> Parser Class Initialized
INFO - 2023-10-31 03:38:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:38:37 --> Pagination Class Initialized
INFO - 2023-10-31 03:38:37 --> Form Validation Class Initialized
INFO - 2023-10-31 03:38:37 --> Controller Class Initialized
INFO - 2023-10-31 03:38:37 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:38:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:37 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:37 --> Model Class Initialized
INFO - 2023-10-31 03:38:37 --> Final output sent to browser
DEBUG - 2023-10-31 03:38:37 --> Total execution time: 0.0219
ERROR - 2023-10-31 03:38:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:38:42 --> Config Class Initialized
INFO - 2023-10-31 03:38:42 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:38:42 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:38:42 --> Utf8 Class Initialized
INFO - 2023-10-31 03:38:42 --> URI Class Initialized
INFO - 2023-10-31 03:38:42 --> Router Class Initialized
INFO - 2023-10-31 03:38:42 --> Output Class Initialized
INFO - 2023-10-31 03:38:42 --> Security Class Initialized
DEBUG - 2023-10-31 03:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:38:42 --> Input Class Initialized
INFO - 2023-10-31 03:38:42 --> Language Class Initialized
INFO - 2023-10-31 03:38:42 --> Loader Class Initialized
INFO - 2023-10-31 03:38:42 --> Helper loaded: url_helper
INFO - 2023-10-31 03:38:42 --> Helper loaded: file_helper
INFO - 2023-10-31 03:38:42 --> Helper loaded: html_helper
INFO - 2023-10-31 03:38:42 --> Helper loaded: text_helper
INFO - 2023-10-31 03:38:42 --> Helper loaded: form_helper
INFO - 2023-10-31 03:38:42 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:38:42 --> Helper loaded: security_helper
INFO - 2023-10-31 03:38:42 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:38:42 --> Database Driver Class Initialized
INFO - 2023-10-31 03:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:38:42 --> Parser Class Initialized
INFO - 2023-10-31 03:38:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:38:42 --> Pagination Class Initialized
INFO - 2023-10-31 03:38:42 --> Form Validation Class Initialized
INFO - 2023-10-31 03:38:42 --> Controller Class Initialized
INFO - 2023-10-31 03:38:42 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:42 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:42 --> Model Class Initialized
INFO - 2023-10-31 03:38:42 --> Final output sent to browser
DEBUG - 2023-10-31 03:38:42 --> Total execution time: 0.0220
ERROR - 2023-10-31 03:38:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:38:43 --> Config Class Initialized
INFO - 2023-10-31 03:38:43 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:38:43 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:38:43 --> Utf8 Class Initialized
INFO - 2023-10-31 03:38:43 --> URI Class Initialized
INFO - 2023-10-31 03:38:43 --> Router Class Initialized
INFO - 2023-10-31 03:38:43 --> Output Class Initialized
INFO - 2023-10-31 03:38:43 --> Security Class Initialized
DEBUG - 2023-10-31 03:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:38:43 --> Input Class Initialized
INFO - 2023-10-31 03:38:43 --> Language Class Initialized
INFO - 2023-10-31 03:38:43 --> Loader Class Initialized
INFO - 2023-10-31 03:38:43 --> Helper loaded: url_helper
INFO - 2023-10-31 03:38:43 --> Helper loaded: file_helper
INFO - 2023-10-31 03:38:43 --> Helper loaded: html_helper
INFO - 2023-10-31 03:38:43 --> Helper loaded: text_helper
INFO - 2023-10-31 03:38:43 --> Helper loaded: form_helper
INFO - 2023-10-31 03:38:43 --> Helper loaded: lang_helper
INFO - 2023-10-31 03:38:43 --> Helper loaded: security_helper
INFO - 2023-10-31 03:38:43 --> Helper loaded: cookie_helper
INFO - 2023-10-31 03:38:43 --> Database Driver Class Initialized
INFO - 2023-10-31 03:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 03:38:43 --> Parser Class Initialized
INFO - 2023-10-31 03:38:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 03:38:43 --> Pagination Class Initialized
INFO - 2023-10-31 03:38:43 --> Form Validation Class Initialized
INFO - 2023-10-31 03:38:43 --> Controller Class Initialized
INFO - 2023-10-31 03:38:43 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 03:38:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:43 --> Model Class Initialized
DEBUG - 2023-10-31 03:38:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 03:38:43 --> Model Class Initialized
INFO - 2023-10-31 03:38:43 --> Final output sent to browser
DEBUG - 2023-10-31 03:38:43 --> Total execution time: 0.0274
ERROR - 2023-10-31 03:42:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 03:42:41 --> Config Class Initialized
INFO - 2023-10-31 03:42:41 --> Hooks Class Initialized
DEBUG - 2023-10-31 03:42:41 --> UTF-8 Support Enabled
INFO - 2023-10-31 03:42:41 --> Utf8 Class Initialized
INFO - 2023-10-31 03:42:41 --> URI Class Initialized
INFO - 2023-10-31 03:42:41 --> Router Class Initialized
INFO - 2023-10-31 03:42:41 --> Output Class Initialized
INFO - 2023-10-31 03:42:41 --> Security Class Initialized
DEBUG - 2023-10-31 03:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 03:42:41 --> Input Class Initialized
INFO - 2023-10-31 03:42:41 --> Language Class Initialized
ERROR - 2023-10-31 03:42:41 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-10-31 09:10:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:10:20 --> Config Class Initialized
INFO - 2023-10-31 09:10:20 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:10:20 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:10:20 --> Utf8 Class Initialized
INFO - 2023-10-31 09:10:20 --> URI Class Initialized
DEBUG - 2023-10-31 09:10:20 --> No URI present. Default controller set.
INFO - 2023-10-31 09:10:20 --> Router Class Initialized
INFO - 2023-10-31 09:10:20 --> Output Class Initialized
INFO - 2023-10-31 09:10:20 --> Security Class Initialized
DEBUG - 2023-10-31 09:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:10:20 --> Input Class Initialized
INFO - 2023-10-31 09:10:20 --> Language Class Initialized
INFO - 2023-10-31 09:10:20 --> Loader Class Initialized
INFO - 2023-10-31 09:10:20 --> Helper loaded: url_helper
INFO - 2023-10-31 09:10:20 --> Helper loaded: file_helper
INFO - 2023-10-31 09:10:20 --> Helper loaded: html_helper
INFO - 2023-10-31 09:10:20 --> Helper loaded: text_helper
INFO - 2023-10-31 09:10:20 --> Helper loaded: form_helper
INFO - 2023-10-31 09:10:20 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:10:20 --> Helper loaded: security_helper
INFO - 2023-10-31 09:10:20 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:10:20 --> Database Driver Class Initialized
INFO - 2023-10-31 09:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:10:20 --> Parser Class Initialized
INFO - 2023-10-31 09:10:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:10:20 --> Pagination Class Initialized
INFO - 2023-10-31 09:10:20 --> Form Validation Class Initialized
INFO - 2023-10-31 09:10:20 --> Controller Class Initialized
INFO - 2023-10-31 09:10:20 --> Model Class Initialized
DEBUG - 2023-10-31 09:10:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-31 09:10:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:10:20 --> Config Class Initialized
INFO - 2023-10-31 09:10:20 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:10:20 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:10:20 --> Utf8 Class Initialized
INFO - 2023-10-31 09:10:20 --> URI Class Initialized
INFO - 2023-10-31 09:10:20 --> Router Class Initialized
INFO - 2023-10-31 09:10:20 --> Output Class Initialized
INFO - 2023-10-31 09:10:20 --> Security Class Initialized
DEBUG - 2023-10-31 09:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:10:20 --> Input Class Initialized
INFO - 2023-10-31 09:10:20 --> Language Class Initialized
INFO - 2023-10-31 09:10:20 --> Loader Class Initialized
INFO - 2023-10-31 09:10:20 --> Helper loaded: url_helper
INFO - 2023-10-31 09:10:20 --> Helper loaded: file_helper
INFO - 2023-10-31 09:10:20 --> Helper loaded: html_helper
INFO - 2023-10-31 09:10:20 --> Helper loaded: text_helper
INFO - 2023-10-31 09:10:20 --> Helper loaded: form_helper
INFO - 2023-10-31 09:10:20 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:10:20 --> Helper loaded: security_helper
INFO - 2023-10-31 09:10:20 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:10:20 --> Database Driver Class Initialized
INFO - 2023-10-31 09:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:10:20 --> Parser Class Initialized
INFO - 2023-10-31 09:10:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:10:20 --> Pagination Class Initialized
INFO - 2023-10-31 09:10:20 --> Form Validation Class Initialized
INFO - 2023-10-31 09:10:20 --> Controller Class Initialized
INFO - 2023-10-31 09:10:20 --> Model Class Initialized
DEBUG - 2023-10-31 09:10:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:10:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-31 09:10:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:10:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 09:10:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 09:10:20 --> Model Class Initialized
INFO - 2023-10-31 09:10:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 09:10:20 --> Final output sent to browser
DEBUG - 2023-10-31 09:10:20 --> Total execution time: 0.0312
ERROR - 2023-10-31 09:10:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:10:23 --> Config Class Initialized
INFO - 2023-10-31 09:10:23 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:10:23 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:10:23 --> Utf8 Class Initialized
INFO - 2023-10-31 09:10:23 --> URI Class Initialized
INFO - 2023-10-31 09:10:23 --> Router Class Initialized
INFO - 2023-10-31 09:10:23 --> Output Class Initialized
INFO - 2023-10-31 09:10:23 --> Security Class Initialized
DEBUG - 2023-10-31 09:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:10:23 --> Input Class Initialized
INFO - 2023-10-31 09:10:23 --> Language Class Initialized
INFO - 2023-10-31 09:10:23 --> Loader Class Initialized
INFO - 2023-10-31 09:10:23 --> Helper loaded: url_helper
INFO - 2023-10-31 09:10:23 --> Helper loaded: file_helper
INFO - 2023-10-31 09:10:23 --> Helper loaded: html_helper
INFO - 2023-10-31 09:10:23 --> Helper loaded: text_helper
INFO - 2023-10-31 09:10:23 --> Helper loaded: form_helper
INFO - 2023-10-31 09:10:23 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:10:23 --> Helper loaded: security_helper
INFO - 2023-10-31 09:10:23 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:10:23 --> Database Driver Class Initialized
INFO - 2023-10-31 09:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:10:23 --> Parser Class Initialized
INFO - 2023-10-31 09:10:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:10:23 --> Pagination Class Initialized
INFO - 2023-10-31 09:10:23 --> Form Validation Class Initialized
INFO - 2023-10-31 09:10:23 --> Controller Class Initialized
INFO - 2023-10-31 09:10:23 --> Model Class Initialized
DEBUG - 2023-10-31 09:10:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:10:23 --> Model Class Initialized
INFO - 2023-10-31 09:10:23 --> Final output sent to browser
DEBUG - 2023-10-31 09:10:23 --> Total execution time: 0.0200
ERROR - 2023-10-31 09:10:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:10:23 --> Config Class Initialized
INFO - 2023-10-31 09:10:23 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:10:23 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:10:23 --> Utf8 Class Initialized
INFO - 2023-10-31 09:10:23 --> URI Class Initialized
DEBUG - 2023-10-31 09:10:23 --> No URI present. Default controller set.
INFO - 2023-10-31 09:10:23 --> Router Class Initialized
INFO - 2023-10-31 09:10:23 --> Output Class Initialized
INFO - 2023-10-31 09:10:23 --> Security Class Initialized
DEBUG - 2023-10-31 09:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:10:23 --> Input Class Initialized
INFO - 2023-10-31 09:10:23 --> Language Class Initialized
INFO - 2023-10-31 09:10:23 --> Loader Class Initialized
INFO - 2023-10-31 09:10:23 --> Helper loaded: url_helper
INFO - 2023-10-31 09:10:23 --> Helper loaded: file_helper
INFO - 2023-10-31 09:10:23 --> Helper loaded: html_helper
INFO - 2023-10-31 09:10:23 --> Helper loaded: text_helper
INFO - 2023-10-31 09:10:23 --> Helper loaded: form_helper
INFO - 2023-10-31 09:10:23 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:10:23 --> Helper loaded: security_helper
INFO - 2023-10-31 09:10:23 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:10:23 --> Database Driver Class Initialized
INFO - 2023-10-31 09:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:10:23 --> Parser Class Initialized
INFO - 2023-10-31 09:10:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:10:23 --> Pagination Class Initialized
INFO - 2023-10-31 09:10:23 --> Form Validation Class Initialized
INFO - 2023-10-31 09:10:23 --> Controller Class Initialized
INFO - 2023-10-31 09:10:23 --> Model Class Initialized
DEBUG - 2023-10-31 09:10:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:10:23 --> Model Class Initialized
DEBUG - 2023-10-31 09:10:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:10:23 --> Model Class Initialized
INFO - 2023-10-31 09:10:23 --> Model Class Initialized
INFO - 2023-10-31 09:10:23 --> Model Class Initialized
INFO - 2023-10-31 09:10:23 --> Model Class Initialized
DEBUG - 2023-10-31 09:10:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:10:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:10:23 --> Model Class Initialized
INFO - 2023-10-31 09:10:23 --> Model Class Initialized
INFO - 2023-10-31 09:10:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-31 09:10:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:10:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 09:10:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 09:10:23 --> Model Class Initialized
INFO - 2023-10-31 09:10:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 09:10:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 09:10:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 09:10:24 --> Final output sent to browser
DEBUG - 2023-10-31 09:10:24 --> Total execution time: 0.3492
ERROR - 2023-10-31 09:10:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:10:24 --> Config Class Initialized
INFO - 2023-10-31 09:10:24 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:10:24 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:10:24 --> Utf8 Class Initialized
INFO - 2023-10-31 09:10:24 --> URI Class Initialized
INFO - 2023-10-31 09:10:24 --> Router Class Initialized
INFO - 2023-10-31 09:10:24 --> Output Class Initialized
INFO - 2023-10-31 09:10:24 --> Security Class Initialized
DEBUG - 2023-10-31 09:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:10:24 --> Input Class Initialized
INFO - 2023-10-31 09:10:24 --> Language Class Initialized
INFO - 2023-10-31 09:10:24 --> Loader Class Initialized
INFO - 2023-10-31 09:10:24 --> Helper loaded: url_helper
INFO - 2023-10-31 09:10:24 --> Helper loaded: file_helper
INFO - 2023-10-31 09:10:24 --> Helper loaded: html_helper
INFO - 2023-10-31 09:10:24 --> Helper loaded: text_helper
INFO - 2023-10-31 09:10:24 --> Helper loaded: form_helper
INFO - 2023-10-31 09:10:24 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:10:24 --> Helper loaded: security_helper
INFO - 2023-10-31 09:10:24 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:10:24 --> Database Driver Class Initialized
INFO - 2023-10-31 09:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:10:24 --> Parser Class Initialized
INFO - 2023-10-31 09:10:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:10:24 --> Pagination Class Initialized
INFO - 2023-10-31 09:10:24 --> Form Validation Class Initialized
INFO - 2023-10-31 09:10:24 --> Controller Class Initialized
DEBUG - 2023-10-31 09:10:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:10:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:10:24 --> Model Class Initialized
INFO - 2023-10-31 09:10:24 --> Final output sent to browser
DEBUG - 2023-10-31 09:10:24 --> Total execution time: 0.0124
ERROR - 2023-10-31 09:10:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:10:32 --> Config Class Initialized
INFO - 2023-10-31 09:10:32 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:10:32 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:10:32 --> Utf8 Class Initialized
INFO - 2023-10-31 09:10:32 --> URI Class Initialized
INFO - 2023-10-31 09:10:32 --> Router Class Initialized
INFO - 2023-10-31 09:10:32 --> Output Class Initialized
INFO - 2023-10-31 09:10:32 --> Security Class Initialized
DEBUG - 2023-10-31 09:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:10:32 --> Input Class Initialized
INFO - 2023-10-31 09:10:32 --> Language Class Initialized
INFO - 2023-10-31 09:10:32 --> Loader Class Initialized
INFO - 2023-10-31 09:10:32 --> Helper loaded: url_helper
INFO - 2023-10-31 09:10:32 --> Helper loaded: file_helper
INFO - 2023-10-31 09:10:32 --> Helper loaded: html_helper
INFO - 2023-10-31 09:10:32 --> Helper loaded: text_helper
INFO - 2023-10-31 09:10:32 --> Helper loaded: form_helper
INFO - 2023-10-31 09:10:32 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:10:32 --> Helper loaded: security_helper
INFO - 2023-10-31 09:10:32 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:10:32 --> Database Driver Class Initialized
INFO - 2023-10-31 09:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:10:32 --> Parser Class Initialized
INFO - 2023-10-31 09:10:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:10:32 --> Pagination Class Initialized
INFO - 2023-10-31 09:10:32 --> Form Validation Class Initialized
INFO - 2023-10-31 09:10:32 --> Controller Class Initialized
INFO - 2023-10-31 09:10:32 --> Model Class Initialized
DEBUG - 2023-10-31 09:10:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:10:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:10:32 --> Model Class Initialized
DEBUG - 2023-10-31 09:10:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:10:32 --> Model Class Initialized
INFO - 2023-10-31 09:10:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-31 09:10:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:10:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 09:10:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 09:10:32 --> Model Class Initialized
INFO - 2023-10-31 09:10:32 --> Model Class Initialized
INFO - 2023-10-31 09:10:32 --> Model Class Initialized
INFO - 2023-10-31 09:10:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 09:10:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 09:10:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 09:10:32 --> Final output sent to browser
DEBUG - 2023-10-31 09:10:32 --> Total execution time: 0.2118
ERROR - 2023-10-31 09:10:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:10:33 --> Config Class Initialized
INFO - 2023-10-31 09:10:33 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:10:33 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:10:33 --> Utf8 Class Initialized
INFO - 2023-10-31 09:10:33 --> URI Class Initialized
INFO - 2023-10-31 09:10:33 --> Router Class Initialized
INFO - 2023-10-31 09:10:33 --> Output Class Initialized
INFO - 2023-10-31 09:10:33 --> Security Class Initialized
DEBUG - 2023-10-31 09:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:10:33 --> Input Class Initialized
INFO - 2023-10-31 09:10:33 --> Language Class Initialized
INFO - 2023-10-31 09:10:33 --> Loader Class Initialized
INFO - 2023-10-31 09:10:33 --> Helper loaded: url_helper
INFO - 2023-10-31 09:10:33 --> Helper loaded: file_helper
INFO - 2023-10-31 09:10:33 --> Helper loaded: html_helper
INFO - 2023-10-31 09:10:33 --> Helper loaded: text_helper
INFO - 2023-10-31 09:10:33 --> Helper loaded: form_helper
INFO - 2023-10-31 09:10:33 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:10:33 --> Helper loaded: security_helper
INFO - 2023-10-31 09:10:33 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:10:33 --> Database Driver Class Initialized
INFO - 2023-10-31 09:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:10:33 --> Parser Class Initialized
INFO - 2023-10-31 09:10:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:10:33 --> Pagination Class Initialized
INFO - 2023-10-31 09:10:33 --> Form Validation Class Initialized
INFO - 2023-10-31 09:10:33 --> Controller Class Initialized
INFO - 2023-10-31 09:10:33 --> Model Class Initialized
DEBUG - 2023-10-31 09:10:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:10:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:10:33 --> Model Class Initialized
DEBUG - 2023-10-31 09:10:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:10:33 --> Model Class Initialized
INFO - 2023-10-31 09:10:33 --> Final output sent to browser
DEBUG - 2023-10-31 09:10:33 --> Total execution time: 0.0636
ERROR - 2023-10-31 09:10:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:10:39 --> Config Class Initialized
INFO - 2023-10-31 09:10:39 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:10:39 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:10:39 --> Utf8 Class Initialized
INFO - 2023-10-31 09:10:39 --> URI Class Initialized
DEBUG - 2023-10-31 09:10:39 --> No URI present. Default controller set.
INFO - 2023-10-31 09:10:39 --> Router Class Initialized
INFO - 2023-10-31 09:10:39 --> Output Class Initialized
INFO - 2023-10-31 09:10:39 --> Security Class Initialized
DEBUG - 2023-10-31 09:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:10:39 --> Input Class Initialized
INFO - 2023-10-31 09:10:39 --> Language Class Initialized
INFO - 2023-10-31 09:10:39 --> Loader Class Initialized
INFO - 2023-10-31 09:10:39 --> Helper loaded: url_helper
INFO - 2023-10-31 09:10:39 --> Helper loaded: file_helper
INFO - 2023-10-31 09:10:39 --> Helper loaded: html_helper
INFO - 2023-10-31 09:10:39 --> Helper loaded: text_helper
INFO - 2023-10-31 09:10:39 --> Helper loaded: form_helper
INFO - 2023-10-31 09:10:39 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:10:39 --> Helper loaded: security_helper
INFO - 2023-10-31 09:10:39 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:10:39 --> Database Driver Class Initialized
INFO - 2023-10-31 09:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:10:39 --> Parser Class Initialized
INFO - 2023-10-31 09:10:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:10:39 --> Pagination Class Initialized
INFO - 2023-10-31 09:10:39 --> Form Validation Class Initialized
INFO - 2023-10-31 09:10:39 --> Controller Class Initialized
INFO - 2023-10-31 09:10:39 --> Model Class Initialized
DEBUG - 2023-10-31 09:10:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:10:39 --> Model Class Initialized
DEBUG - 2023-10-31 09:10:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:10:39 --> Model Class Initialized
INFO - 2023-10-31 09:10:39 --> Model Class Initialized
INFO - 2023-10-31 09:10:39 --> Model Class Initialized
INFO - 2023-10-31 09:10:39 --> Model Class Initialized
DEBUG - 2023-10-31 09:10:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:10:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:10:39 --> Model Class Initialized
INFO - 2023-10-31 09:10:39 --> Model Class Initialized
INFO - 2023-10-31 09:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-31 09:10:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 09:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 09:10:39 --> Model Class Initialized
INFO - 2023-10-31 09:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 09:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 09:10:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 09:10:39 --> Final output sent to browser
DEBUG - 2023-10-31 09:10:39 --> Total execution time: 0.3903
ERROR - 2023-10-31 09:11:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:11:18 --> Config Class Initialized
INFO - 2023-10-31 09:11:18 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:11:18 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:11:18 --> Utf8 Class Initialized
INFO - 2023-10-31 09:11:18 --> URI Class Initialized
INFO - 2023-10-31 09:11:18 --> Router Class Initialized
INFO - 2023-10-31 09:11:18 --> Output Class Initialized
INFO - 2023-10-31 09:11:18 --> Security Class Initialized
DEBUG - 2023-10-31 09:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:11:18 --> Input Class Initialized
INFO - 2023-10-31 09:11:18 --> Language Class Initialized
INFO - 2023-10-31 09:11:18 --> Loader Class Initialized
INFO - 2023-10-31 09:11:18 --> Helper loaded: url_helper
INFO - 2023-10-31 09:11:18 --> Helper loaded: file_helper
INFO - 2023-10-31 09:11:18 --> Helper loaded: html_helper
INFO - 2023-10-31 09:11:18 --> Helper loaded: text_helper
INFO - 2023-10-31 09:11:18 --> Helper loaded: form_helper
INFO - 2023-10-31 09:11:18 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:11:18 --> Helper loaded: security_helper
INFO - 2023-10-31 09:11:18 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:11:18 --> Database Driver Class Initialized
INFO - 2023-10-31 09:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:11:18 --> Parser Class Initialized
INFO - 2023-10-31 09:11:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:11:18 --> Pagination Class Initialized
INFO - 2023-10-31 09:11:18 --> Form Validation Class Initialized
INFO - 2023-10-31 09:11:18 --> Controller Class Initialized
DEBUG - 2023-10-31 09:11:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:11:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:11:18 --> Model Class Initialized
DEBUG - 2023-10-31 09:11:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:11:18 --> Model Class Initialized
DEBUG - 2023-10-31 09:11:18 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:11:18 --> Model Class Initialized
INFO - 2023-10-31 09:11:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-10-31 09:11:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:11:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 09:11:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 09:11:18 --> Model Class Initialized
INFO - 2023-10-31 09:11:18 --> Model Class Initialized
INFO - 2023-10-31 09:11:18 --> Model Class Initialized
INFO - 2023-10-31 09:11:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 09:11:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 09:11:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 09:11:18 --> Final output sent to browser
DEBUG - 2023-10-31 09:11:18 --> Total execution time: 0.1951
ERROR - 2023-10-31 09:11:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:11:19 --> Config Class Initialized
INFO - 2023-10-31 09:11:19 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:11:19 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:11:19 --> Utf8 Class Initialized
INFO - 2023-10-31 09:11:19 --> URI Class Initialized
INFO - 2023-10-31 09:11:19 --> Router Class Initialized
INFO - 2023-10-31 09:11:19 --> Output Class Initialized
INFO - 2023-10-31 09:11:19 --> Security Class Initialized
DEBUG - 2023-10-31 09:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:11:19 --> Input Class Initialized
INFO - 2023-10-31 09:11:19 --> Language Class Initialized
INFO - 2023-10-31 09:11:19 --> Loader Class Initialized
INFO - 2023-10-31 09:11:19 --> Helper loaded: url_helper
INFO - 2023-10-31 09:11:19 --> Helper loaded: file_helper
INFO - 2023-10-31 09:11:19 --> Helper loaded: html_helper
INFO - 2023-10-31 09:11:19 --> Helper loaded: text_helper
INFO - 2023-10-31 09:11:19 --> Helper loaded: form_helper
INFO - 2023-10-31 09:11:19 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:11:19 --> Helper loaded: security_helper
INFO - 2023-10-31 09:11:19 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:11:19 --> Database Driver Class Initialized
INFO - 2023-10-31 09:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:11:19 --> Parser Class Initialized
INFO - 2023-10-31 09:11:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:11:19 --> Pagination Class Initialized
INFO - 2023-10-31 09:11:19 --> Form Validation Class Initialized
INFO - 2023-10-31 09:11:19 --> Controller Class Initialized
DEBUG - 2023-10-31 09:11:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:11:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:11:19 --> Model Class Initialized
DEBUG - 2023-10-31 09:11:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:11:19 --> Model Class Initialized
INFO - 2023-10-31 09:11:19 --> Final output sent to browser
DEBUG - 2023-10-31 09:11:19 --> Total execution time: 0.0311
ERROR - 2023-10-31 09:11:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:11:24 --> Config Class Initialized
INFO - 2023-10-31 09:11:24 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:11:24 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:11:24 --> Utf8 Class Initialized
INFO - 2023-10-31 09:11:24 --> URI Class Initialized
INFO - 2023-10-31 09:11:24 --> Router Class Initialized
INFO - 2023-10-31 09:11:24 --> Output Class Initialized
INFO - 2023-10-31 09:11:24 --> Security Class Initialized
DEBUG - 2023-10-31 09:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:11:24 --> Input Class Initialized
INFO - 2023-10-31 09:11:24 --> Language Class Initialized
INFO - 2023-10-31 09:11:24 --> Loader Class Initialized
INFO - 2023-10-31 09:11:24 --> Helper loaded: url_helper
INFO - 2023-10-31 09:11:24 --> Helper loaded: file_helper
INFO - 2023-10-31 09:11:24 --> Helper loaded: html_helper
INFO - 2023-10-31 09:11:24 --> Helper loaded: text_helper
INFO - 2023-10-31 09:11:24 --> Helper loaded: form_helper
INFO - 2023-10-31 09:11:24 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:11:24 --> Helper loaded: security_helper
INFO - 2023-10-31 09:11:24 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:11:24 --> Database Driver Class Initialized
INFO - 2023-10-31 09:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:11:24 --> Parser Class Initialized
INFO - 2023-10-31 09:11:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:11:24 --> Pagination Class Initialized
INFO - 2023-10-31 09:11:24 --> Form Validation Class Initialized
INFO - 2023-10-31 09:11:24 --> Controller Class Initialized
DEBUG - 2023-10-31 09:11:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:11:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:11:24 --> Model Class Initialized
DEBUG - 2023-10-31 09:11:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:11:24 --> Model Class Initialized
INFO - 2023-10-31 09:11:24 --> Final output sent to browser
DEBUG - 2023-10-31 09:11:24 --> Total execution time: 0.1685
ERROR - 2023-10-31 09:11:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:11:34 --> Config Class Initialized
INFO - 2023-10-31 09:11:34 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:11:34 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:11:34 --> Utf8 Class Initialized
INFO - 2023-10-31 09:11:34 --> URI Class Initialized
DEBUG - 2023-10-31 09:11:34 --> No URI present. Default controller set.
INFO - 2023-10-31 09:11:34 --> Router Class Initialized
INFO - 2023-10-31 09:11:34 --> Output Class Initialized
INFO - 2023-10-31 09:11:34 --> Security Class Initialized
DEBUG - 2023-10-31 09:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:11:34 --> Input Class Initialized
INFO - 2023-10-31 09:11:34 --> Language Class Initialized
INFO - 2023-10-31 09:11:34 --> Loader Class Initialized
INFO - 2023-10-31 09:11:34 --> Helper loaded: url_helper
INFO - 2023-10-31 09:11:34 --> Helper loaded: file_helper
INFO - 2023-10-31 09:11:34 --> Helper loaded: html_helper
INFO - 2023-10-31 09:11:34 --> Helper loaded: text_helper
INFO - 2023-10-31 09:11:34 --> Helper loaded: form_helper
INFO - 2023-10-31 09:11:34 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:11:34 --> Helper loaded: security_helper
INFO - 2023-10-31 09:11:34 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:11:34 --> Database Driver Class Initialized
INFO - 2023-10-31 09:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:11:34 --> Parser Class Initialized
INFO - 2023-10-31 09:11:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:11:34 --> Pagination Class Initialized
INFO - 2023-10-31 09:11:34 --> Form Validation Class Initialized
INFO - 2023-10-31 09:11:34 --> Controller Class Initialized
INFO - 2023-10-31 09:11:34 --> Model Class Initialized
DEBUG - 2023-10-31 09:11:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:11:34 --> Model Class Initialized
DEBUG - 2023-10-31 09:11:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:11:34 --> Model Class Initialized
INFO - 2023-10-31 09:11:34 --> Model Class Initialized
INFO - 2023-10-31 09:11:34 --> Model Class Initialized
INFO - 2023-10-31 09:11:34 --> Model Class Initialized
DEBUG - 2023-10-31 09:11:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:11:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:11:34 --> Model Class Initialized
INFO - 2023-10-31 09:11:34 --> Model Class Initialized
INFO - 2023-10-31 09:11:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-31 09:11:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:11:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 09:11:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 09:11:35 --> Model Class Initialized
INFO - 2023-10-31 09:11:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 09:11:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 09:11:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 09:11:35 --> Final output sent to browser
DEBUG - 2023-10-31 09:11:35 --> Total execution time: 0.3613
ERROR - 2023-10-31 09:13:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:13:35 --> Config Class Initialized
INFO - 2023-10-31 09:13:35 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:13:35 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:13:35 --> Utf8 Class Initialized
INFO - 2023-10-31 09:13:35 --> URI Class Initialized
DEBUG - 2023-10-31 09:13:35 --> No URI present. Default controller set.
INFO - 2023-10-31 09:13:35 --> Router Class Initialized
INFO - 2023-10-31 09:13:35 --> Output Class Initialized
INFO - 2023-10-31 09:13:35 --> Security Class Initialized
DEBUG - 2023-10-31 09:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:13:35 --> Input Class Initialized
INFO - 2023-10-31 09:13:35 --> Language Class Initialized
INFO - 2023-10-31 09:13:35 --> Loader Class Initialized
INFO - 2023-10-31 09:13:35 --> Helper loaded: url_helper
INFO - 2023-10-31 09:13:35 --> Helper loaded: file_helper
INFO - 2023-10-31 09:13:35 --> Helper loaded: html_helper
INFO - 2023-10-31 09:13:36 --> Helper loaded: text_helper
INFO - 2023-10-31 09:13:36 --> Helper loaded: form_helper
INFO - 2023-10-31 09:13:36 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:13:36 --> Helper loaded: security_helper
INFO - 2023-10-31 09:13:36 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:13:36 --> Database Driver Class Initialized
INFO - 2023-10-31 09:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:13:36 --> Parser Class Initialized
INFO - 2023-10-31 09:13:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:13:36 --> Pagination Class Initialized
INFO - 2023-10-31 09:13:36 --> Form Validation Class Initialized
INFO - 2023-10-31 09:13:36 --> Controller Class Initialized
INFO - 2023-10-31 09:13:36 --> Model Class Initialized
DEBUG - 2023-10-31 09:13:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:13:36 --> Model Class Initialized
DEBUG - 2023-10-31 09:13:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:13:36 --> Model Class Initialized
INFO - 2023-10-31 09:13:36 --> Model Class Initialized
INFO - 2023-10-31 09:13:36 --> Model Class Initialized
INFO - 2023-10-31 09:13:36 --> Model Class Initialized
DEBUG - 2023-10-31 09:13:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:13:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:13:36 --> Model Class Initialized
INFO - 2023-10-31 09:13:36 --> Model Class Initialized
INFO - 2023-10-31 09:13:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-31 09:13:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:13:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 09:13:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 09:13:36 --> Model Class Initialized
INFO - 2023-10-31 09:13:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 09:13:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 09:13:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 09:13:36 --> Final output sent to browser
DEBUG - 2023-10-31 09:13:36 --> Total execution time: 0.3597
ERROR - 2023-10-31 09:23:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:23:10 --> Config Class Initialized
INFO - 2023-10-31 09:23:10 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:23:10 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:23:10 --> Utf8 Class Initialized
INFO - 2023-10-31 09:23:10 --> URI Class Initialized
DEBUG - 2023-10-31 09:23:10 --> No URI present. Default controller set.
INFO - 2023-10-31 09:23:10 --> Router Class Initialized
INFO - 2023-10-31 09:23:10 --> Output Class Initialized
INFO - 2023-10-31 09:23:10 --> Security Class Initialized
DEBUG - 2023-10-31 09:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:23:10 --> Input Class Initialized
INFO - 2023-10-31 09:23:10 --> Language Class Initialized
INFO - 2023-10-31 09:23:10 --> Loader Class Initialized
INFO - 2023-10-31 09:23:10 --> Helper loaded: url_helper
INFO - 2023-10-31 09:23:10 --> Helper loaded: file_helper
INFO - 2023-10-31 09:23:10 --> Helper loaded: html_helper
INFO - 2023-10-31 09:23:10 --> Helper loaded: text_helper
INFO - 2023-10-31 09:23:10 --> Helper loaded: form_helper
INFO - 2023-10-31 09:23:10 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:23:10 --> Helper loaded: security_helper
INFO - 2023-10-31 09:23:10 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:23:10 --> Database Driver Class Initialized
INFO - 2023-10-31 09:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:23:10 --> Parser Class Initialized
INFO - 2023-10-31 09:23:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:23:10 --> Pagination Class Initialized
INFO - 2023-10-31 09:23:10 --> Form Validation Class Initialized
INFO - 2023-10-31 09:23:10 --> Controller Class Initialized
INFO - 2023-10-31 09:23:10 --> Model Class Initialized
DEBUG - 2023-10-31 09:23:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:23:10 --> Model Class Initialized
DEBUG - 2023-10-31 09:23:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:23:10 --> Model Class Initialized
INFO - 2023-10-31 09:23:10 --> Model Class Initialized
INFO - 2023-10-31 09:23:10 --> Model Class Initialized
INFO - 2023-10-31 09:23:10 --> Model Class Initialized
DEBUG - 2023-10-31 09:23:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:23:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:23:10 --> Model Class Initialized
INFO - 2023-10-31 09:23:10 --> Model Class Initialized
INFO - 2023-10-31 09:23:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-31 09:23:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:23:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 09:23:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 09:23:10 --> Model Class Initialized
INFO - 2023-10-31 09:23:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 09:23:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 09:23:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 09:23:11 --> Final output sent to browser
DEBUG - 2023-10-31 09:23:11 --> Total execution time: 0.3835
ERROR - 2023-10-31 09:27:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:27:03 --> Config Class Initialized
INFO - 2023-10-31 09:27:03 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:27:03 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:27:03 --> Utf8 Class Initialized
INFO - 2023-10-31 09:27:03 --> URI Class Initialized
DEBUG - 2023-10-31 09:27:03 --> No URI present. Default controller set.
INFO - 2023-10-31 09:27:03 --> Router Class Initialized
INFO - 2023-10-31 09:27:03 --> Output Class Initialized
INFO - 2023-10-31 09:27:03 --> Security Class Initialized
DEBUG - 2023-10-31 09:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:27:03 --> Input Class Initialized
INFO - 2023-10-31 09:27:03 --> Language Class Initialized
INFO - 2023-10-31 09:27:03 --> Loader Class Initialized
INFO - 2023-10-31 09:27:03 --> Helper loaded: url_helper
INFO - 2023-10-31 09:27:03 --> Helper loaded: file_helper
INFO - 2023-10-31 09:27:03 --> Helper loaded: html_helper
INFO - 2023-10-31 09:27:03 --> Helper loaded: text_helper
INFO - 2023-10-31 09:27:03 --> Helper loaded: form_helper
INFO - 2023-10-31 09:27:03 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:27:03 --> Helper loaded: security_helper
INFO - 2023-10-31 09:27:03 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:27:03 --> Database Driver Class Initialized
INFO - 2023-10-31 09:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:27:03 --> Parser Class Initialized
INFO - 2023-10-31 09:27:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:27:03 --> Pagination Class Initialized
INFO - 2023-10-31 09:27:03 --> Form Validation Class Initialized
INFO - 2023-10-31 09:27:03 --> Controller Class Initialized
INFO - 2023-10-31 09:27:03 --> Model Class Initialized
DEBUG - 2023-10-31 09:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:27:03 --> Model Class Initialized
DEBUG - 2023-10-31 09:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:27:03 --> Model Class Initialized
INFO - 2023-10-31 09:27:03 --> Model Class Initialized
INFO - 2023-10-31 09:27:03 --> Model Class Initialized
INFO - 2023-10-31 09:27:03 --> Model Class Initialized
DEBUG - 2023-10-31 09:27:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:27:03 --> Model Class Initialized
INFO - 2023-10-31 09:27:03 --> Model Class Initialized
INFO - 2023-10-31 09:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-31 09:27:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 09:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 09:27:03 --> Model Class Initialized
INFO - 2023-10-31 09:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 09:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 09:27:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 09:27:03 --> Final output sent to browser
DEBUG - 2023-10-31 09:27:03 --> Total execution time: 0.3621
ERROR - 2023-10-31 09:27:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:27:09 --> Config Class Initialized
INFO - 2023-10-31 09:27:09 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:27:09 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:27:09 --> Utf8 Class Initialized
INFO - 2023-10-31 09:27:09 --> URI Class Initialized
INFO - 2023-10-31 09:27:09 --> Router Class Initialized
INFO - 2023-10-31 09:27:09 --> Output Class Initialized
INFO - 2023-10-31 09:27:09 --> Security Class Initialized
DEBUG - 2023-10-31 09:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:27:09 --> Input Class Initialized
INFO - 2023-10-31 09:27:09 --> Language Class Initialized
INFO - 2023-10-31 09:27:09 --> Loader Class Initialized
INFO - 2023-10-31 09:27:09 --> Helper loaded: url_helper
INFO - 2023-10-31 09:27:09 --> Helper loaded: file_helper
INFO - 2023-10-31 09:27:09 --> Helper loaded: html_helper
INFO - 2023-10-31 09:27:09 --> Helper loaded: text_helper
INFO - 2023-10-31 09:27:09 --> Helper loaded: form_helper
INFO - 2023-10-31 09:27:09 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:27:09 --> Helper loaded: security_helper
INFO - 2023-10-31 09:27:09 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:27:09 --> Database Driver Class Initialized
INFO - 2023-10-31 09:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:27:09 --> Parser Class Initialized
INFO - 2023-10-31 09:27:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:27:09 --> Pagination Class Initialized
INFO - 2023-10-31 09:27:09 --> Form Validation Class Initialized
INFO - 2023-10-31 09:27:09 --> Controller Class Initialized
INFO - 2023-10-31 09:27:09 --> Model Class Initialized
DEBUG - 2023-10-31 09:27:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:27:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:27:09 --> Model Class Initialized
DEBUG - 2023-10-31 09:27:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:27:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-10-31 09:27:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:27:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 09:27:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 09:27:09 --> Model Class Initialized
INFO - 2023-10-31 09:27:09 --> Model Class Initialized
INFO - 2023-10-31 09:27:09 --> Model Class Initialized
INFO - 2023-10-31 09:27:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 09:27:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 09:27:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 09:27:09 --> Final output sent to browser
DEBUG - 2023-10-31 09:27:09 --> Total execution time: 0.2146
ERROR - 2023-10-31 09:27:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:27:20 --> Config Class Initialized
INFO - 2023-10-31 09:27:20 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:27:20 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:27:20 --> Utf8 Class Initialized
INFO - 2023-10-31 09:27:20 --> URI Class Initialized
INFO - 2023-10-31 09:27:20 --> Router Class Initialized
INFO - 2023-10-31 09:27:20 --> Output Class Initialized
INFO - 2023-10-31 09:27:20 --> Security Class Initialized
DEBUG - 2023-10-31 09:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:27:20 --> Input Class Initialized
INFO - 2023-10-31 09:27:20 --> Language Class Initialized
INFO - 2023-10-31 09:27:20 --> Loader Class Initialized
INFO - 2023-10-31 09:27:20 --> Helper loaded: url_helper
INFO - 2023-10-31 09:27:20 --> Helper loaded: file_helper
INFO - 2023-10-31 09:27:20 --> Helper loaded: html_helper
INFO - 2023-10-31 09:27:20 --> Helper loaded: text_helper
INFO - 2023-10-31 09:27:20 --> Helper loaded: form_helper
INFO - 2023-10-31 09:27:20 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:27:20 --> Helper loaded: security_helper
INFO - 2023-10-31 09:27:20 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:27:20 --> Database Driver Class Initialized
INFO - 2023-10-31 09:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:27:20 --> Parser Class Initialized
INFO - 2023-10-31 09:27:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:27:21 --> Pagination Class Initialized
INFO - 2023-10-31 09:27:21 --> Form Validation Class Initialized
INFO - 2023-10-31 09:27:21 --> Controller Class Initialized
INFO - 2023-10-31 09:27:21 --> Model Class Initialized
DEBUG - 2023-10-31 09:27:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:27:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:27:21 --> Model Class Initialized
INFO - 2023-10-31 09:27:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-10-31 09:27:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:27:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 09:27:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 09:27:21 --> Model Class Initialized
INFO - 2023-10-31 09:27:21 --> Model Class Initialized
INFO - 2023-10-31 09:27:21 --> Model Class Initialized
INFO - 2023-10-31 09:27:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 09:27:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 09:27:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 09:27:21 --> Final output sent to browser
DEBUG - 2023-10-31 09:27:21 --> Total execution time: 0.1934
ERROR - 2023-10-31 09:27:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:27:21 --> Config Class Initialized
INFO - 2023-10-31 09:27:21 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:27:21 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:27:21 --> Utf8 Class Initialized
INFO - 2023-10-31 09:27:21 --> URI Class Initialized
INFO - 2023-10-31 09:27:21 --> Router Class Initialized
INFO - 2023-10-31 09:27:21 --> Output Class Initialized
INFO - 2023-10-31 09:27:21 --> Security Class Initialized
DEBUG - 2023-10-31 09:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:27:21 --> Input Class Initialized
INFO - 2023-10-31 09:27:21 --> Language Class Initialized
INFO - 2023-10-31 09:27:21 --> Loader Class Initialized
INFO - 2023-10-31 09:27:21 --> Helper loaded: url_helper
INFO - 2023-10-31 09:27:21 --> Helper loaded: file_helper
INFO - 2023-10-31 09:27:21 --> Helper loaded: html_helper
INFO - 2023-10-31 09:27:21 --> Helper loaded: text_helper
INFO - 2023-10-31 09:27:21 --> Helper loaded: form_helper
INFO - 2023-10-31 09:27:21 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:27:21 --> Helper loaded: security_helper
INFO - 2023-10-31 09:27:21 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:27:21 --> Database Driver Class Initialized
INFO - 2023-10-31 09:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:27:21 --> Parser Class Initialized
INFO - 2023-10-31 09:27:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:27:21 --> Pagination Class Initialized
INFO - 2023-10-31 09:27:21 --> Form Validation Class Initialized
INFO - 2023-10-31 09:27:21 --> Controller Class Initialized
INFO - 2023-10-31 09:27:21 --> Model Class Initialized
DEBUG - 2023-10-31 09:27:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:27:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:27:21 --> Model Class Initialized
INFO - 2023-10-31 09:27:21 --> Final output sent to browser
DEBUG - 2023-10-31 09:27:21 --> Total execution time: 0.0229
ERROR - 2023-10-31 09:27:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:27:35 --> Config Class Initialized
INFO - 2023-10-31 09:27:35 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:27:35 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:27:35 --> Utf8 Class Initialized
INFO - 2023-10-31 09:27:35 --> URI Class Initialized
INFO - 2023-10-31 09:27:35 --> Router Class Initialized
INFO - 2023-10-31 09:27:35 --> Output Class Initialized
INFO - 2023-10-31 09:27:35 --> Security Class Initialized
DEBUG - 2023-10-31 09:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:27:35 --> Input Class Initialized
INFO - 2023-10-31 09:27:35 --> Language Class Initialized
INFO - 2023-10-31 09:27:35 --> Loader Class Initialized
INFO - 2023-10-31 09:27:35 --> Helper loaded: url_helper
INFO - 2023-10-31 09:27:35 --> Helper loaded: file_helper
INFO - 2023-10-31 09:27:35 --> Helper loaded: html_helper
INFO - 2023-10-31 09:27:35 --> Helper loaded: text_helper
INFO - 2023-10-31 09:27:35 --> Helper loaded: form_helper
INFO - 2023-10-31 09:27:35 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:27:35 --> Helper loaded: security_helper
INFO - 2023-10-31 09:27:35 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:27:35 --> Database Driver Class Initialized
INFO - 2023-10-31 09:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:27:35 --> Parser Class Initialized
INFO - 2023-10-31 09:27:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:27:35 --> Pagination Class Initialized
INFO - 2023-10-31 09:27:35 --> Form Validation Class Initialized
INFO - 2023-10-31 09:27:35 --> Controller Class Initialized
INFO - 2023-10-31 09:27:35 --> Model Class Initialized
DEBUG - 2023-10-31 09:27:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:27:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:27:35 --> Model Class Initialized
DEBUG - 2023-10-31 09:27:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:27:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-10-31 09:27:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:27:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 09:27:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 09:27:35 --> Model Class Initialized
INFO - 2023-10-31 09:27:35 --> Model Class Initialized
INFO - 2023-10-31 09:27:35 --> Model Class Initialized
INFO - 2023-10-31 09:27:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 09:27:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 09:27:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 09:27:35 --> Final output sent to browser
DEBUG - 2023-10-31 09:27:35 --> Total execution time: 0.1868
ERROR - 2023-10-31 09:27:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:27:55 --> Config Class Initialized
INFO - 2023-10-31 09:27:55 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:27:55 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:27:55 --> Utf8 Class Initialized
INFO - 2023-10-31 09:27:55 --> URI Class Initialized
INFO - 2023-10-31 09:27:55 --> Router Class Initialized
INFO - 2023-10-31 09:27:55 --> Output Class Initialized
INFO - 2023-10-31 09:27:55 --> Security Class Initialized
DEBUG - 2023-10-31 09:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:27:55 --> Input Class Initialized
INFO - 2023-10-31 09:27:55 --> Language Class Initialized
INFO - 2023-10-31 09:27:55 --> Loader Class Initialized
INFO - 2023-10-31 09:27:55 --> Helper loaded: url_helper
INFO - 2023-10-31 09:27:55 --> Helper loaded: file_helper
INFO - 2023-10-31 09:27:55 --> Helper loaded: html_helper
INFO - 2023-10-31 09:27:55 --> Helper loaded: text_helper
INFO - 2023-10-31 09:27:55 --> Helper loaded: form_helper
INFO - 2023-10-31 09:27:55 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:27:55 --> Helper loaded: security_helper
INFO - 2023-10-31 09:27:55 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:27:55 --> Database Driver Class Initialized
INFO - 2023-10-31 09:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:27:55 --> Parser Class Initialized
INFO - 2023-10-31 09:27:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:27:55 --> Pagination Class Initialized
INFO - 2023-10-31 09:27:55 --> Form Validation Class Initialized
INFO - 2023-10-31 09:27:55 --> Controller Class Initialized
INFO - 2023-10-31 09:27:55 --> Model Class Initialized
DEBUG - 2023-10-31 09:27:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:27:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:27:55 --> Model Class Initialized
INFO - 2023-10-31 09:27:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-10-31 09:27:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:27:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 09:27:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 09:27:55 --> Model Class Initialized
INFO - 2023-10-31 09:27:55 --> Model Class Initialized
INFO - 2023-10-31 09:27:55 --> Model Class Initialized
INFO - 2023-10-31 09:27:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 09:27:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 09:27:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 09:27:55 --> Final output sent to browser
DEBUG - 2023-10-31 09:27:55 --> Total execution time: 0.2002
ERROR - 2023-10-31 09:27:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:27:55 --> Config Class Initialized
INFO - 2023-10-31 09:27:55 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:27:55 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:27:55 --> Utf8 Class Initialized
INFO - 2023-10-31 09:27:55 --> URI Class Initialized
INFO - 2023-10-31 09:27:55 --> Router Class Initialized
INFO - 2023-10-31 09:27:55 --> Output Class Initialized
INFO - 2023-10-31 09:27:55 --> Security Class Initialized
DEBUG - 2023-10-31 09:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:27:55 --> Input Class Initialized
INFO - 2023-10-31 09:27:55 --> Language Class Initialized
INFO - 2023-10-31 09:27:55 --> Loader Class Initialized
INFO - 2023-10-31 09:27:55 --> Helper loaded: url_helper
INFO - 2023-10-31 09:27:55 --> Helper loaded: file_helper
INFO - 2023-10-31 09:27:55 --> Helper loaded: html_helper
INFO - 2023-10-31 09:27:55 --> Helper loaded: text_helper
INFO - 2023-10-31 09:27:55 --> Helper loaded: form_helper
INFO - 2023-10-31 09:27:55 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:27:55 --> Helper loaded: security_helper
INFO - 2023-10-31 09:27:55 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:27:55 --> Database Driver Class Initialized
INFO - 2023-10-31 09:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:27:56 --> Parser Class Initialized
INFO - 2023-10-31 09:27:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:27:56 --> Pagination Class Initialized
INFO - 2023-10-31 09:27:56 --> Form Validation Class Initialized
INFO - 2023-10-31 09:27:56 --> Controller Class Initialized
INFO - 2023-10-31 09:27:56 --> Model Class Initialized
DEBUG - 2023-10-31 09:27:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:27:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:27:56 --> Model Class Initialized
INFO - 2023-10-31 09:27:56 --> Final output sent to browser
DEBUG - 2023-10-31 09:27:56 --> Total execution time: 0.0187
ERROR - 2023-10-31 09:28:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:28:22 --> Config Class Initialized
INFO - 2023-10-31 09:28:22 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:28:22 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:28:22 --> Utf8 Class Initialized
INFO - 2023-10-31 09:28:22 --> URI Class Initialized
INFO - 2023-10-31 09:28:22 --> Router Class Initialized
INFO - 2023-10-31 09:28:22 --> Output Class Initialized
INFO - 2023-10-31 09:28:22 --> Security Class Initialized
DEBUG - 2023-10-31 09:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:28:22 --> Input Class Initialized
INFO - 2023-10-31 09:28:22 --> Language Class Initialized
INFO - 2023-10-31 09:28:22 --> Loader Class Initialized
INFO - 2023-10-31 09:28:22 --> Helper loaded: url_helper
INFO - 2023-10-31 09:28:22 --> Helper loaded: file_helper
INFO - 2023-10-31 09:28:22 --> Helper loaded: html_helper
INFO - 2023-10-31 09:28:22 --> Helper loaded: text_helper
INFO - 2023-10-31 09:28:22 --> Helper loaded: form_helper
INFO - 2023-10-31 09:28:22 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:28:22 --> Helper loaded: security_helper
INFO - 2023-10-31 09:28:22 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:28:22 --> Database Driver Class Initialized
INFO - 2023-10-31 09:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:28:22 --> Parser Class Initialized
INFO - 2023-10-31 09:28:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:28:22 --> Pagination Class Initialized
INFO - 2023-10-31 09:28:22 --> Form Validation Class Initialized
INFO - 2023-10-31 09:28:22 --> Controller Class Initialized
INFO - 2023-10-31 09:28:22 --> Model Class Initialized
DEBUG - 2023-10-31 09:28:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:28:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:28:22 --> Model Class Initialized
ERROR - 2023-10-31 09:28:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:28:23 --> Config Class Initialized
INFO - 2023-10-31 09:28:23 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:28:23 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:28:23 --> Utf8 Class Initialized
INFO - 2023-10-31 09:28:23 --> URI Class Initialized
INFO - 2023-10-31 09:28:23 --> Router Class Initialized
INFO - 2023-10-31 09:28:23 --> Output Class Initialized
INFO - 2023-10-31 09:28:23 --> Security Class Initialized
DEBUG - 2023-10-31 09:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:28:23 --> Input Class Initialized
INFO - 2023-10-31 09:28:23 --> Language Class Initialized
INFO - 2023-10-31 09:28:23 --> Loader Class Initialized
INFO - 2023-10-31 09:28:23 --> Helper loaded: url_helper
INFO - 2023-10-31 09:28:23 --> Helper loaded: file_helper
INFO - 2023-10-31 09:28:23 --> Helper loaded: html_helper
INFO - 2023-10-31 09:28:23 --> Helper loaded: text_helper
INFO - 2023-10-31 09:28:23 --> Helper loaded: form_helper
INFO - 2023-10-31 09:28:23 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:28:23 --> Helper loaded: security_helper
INFO - 2023-10-31 09:28:23 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:28:23 --> Database Driver Class Initialized
INFO - 2023-10-31 09:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:28:23 --> Parser Class Initialized
INFO - 2023-10-31 09:28:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:28:23 --> Pagination Class Initialized
INFO - 2023-10-31 09:28:23 --> Form Validation Class Initialized
INFO - 2023-10-31 09:28:23 --> Controller Class Initialized
INFO - 2023-10-31 09:28:23 --> Model Class Initialized
DEBUG - 2023-10-31 09:28:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:28:23 --> Model Class Initialized
INFO - 2023-10-31 09:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-10-31 09:28:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 09:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 09:28:23 --> Model Class Initialized
INFO - 2023-10-31 09:28:23 --> Model Class Initialized
INFO - 2023-10-31 09:28:23 --> Model Class Initialized
INFO - 2023-10-31 09:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 09:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 09:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 09:28:23 --> Final output sent to browser
DEBUG - 2023-10-31 09:28:23 --> Total execution time: 0.1965
ERROR - 2023-10-31 09:28:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:28:23 --> Config Class Initialized
INFO - 2023-10-31 09:28:23 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:28:23 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:28:23 --> Utf8 Class Initialized
INFO - 2023-10-31 09:28:23 --> URI Class Initialized
INFO - 2023-10-31 09:28:23 --> Router Class Initialized
INFO - 2023-10-31 09:28:23 --> Output Class Initialized
INFO - 2023-10-31 09:28:23 --> Security Class Initialized
DEBUG - 2023-10-31 09:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:28:23 --> Input Class Initialized
INFO - 2023-10-31 09:28:23 --> Language Class Initialized
INFO - 2023-10-31 09:28:23 --> Loader Class Initialized
INFO - 2023-10-31 09:28:23 --> Helper loaded: url_helper
INFO - 2023-10-31 09:28:23 --> Helper loaded: file_helper
INFO - 2023-10-31 09:28:23 --> Helper loaded: html_helper
INFO - 2023-10-31 09:28:23 --> Helper loaded: text_helper
INFO - 2023-10-31 09:28:23 --> Helper loaded: form_helper
INFO - 2023-10-31 09:28:23 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:28:23 --> Helper loaded: security_helper
INFO - 2023-10-31 09:28:23 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:28:23 --> Database Driver Class Initialized
INFO - 2023-10-31 09:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:28:23 --> Parser Class Initialized
INFO - 2023-10-31 09:28:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:28:23 --> Pagination Class Initialized
INFO - 2023-10-31 09:28:23 --> Form Validation Class Initialized
INFO - 2023-10-31 09:28:23 --> Controller Class Initialized
INFO - 2023-10-31 09:28:23 --> Model Class Initialized
DEBUG - 2023-10-31 09:28:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:28:23 --> Model Class Initialized
INFO - 2023-10-31 09:28:23 --> Final output sent to browser
DEBUG - 2023-10-31 09:28:23 --> Total execution time: 0.0169
ERROR - 2023-10-31 09:28:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:28:26 --> Config Class Initialized
INFO - 2023-10-31 09:28:26 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:28:26 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:28:26 --> Utf8 Class Initialized
INFO - 2023-10-31 09:28:26 --> URI Class Initialized
INFO - 2023-10-31 09:28:26 --> Router Class Initialized
INFO - 2023-10-31 09:28:26 --> Output Class Initialized
INFO - 2023-10-31 09:28:26 --> Security Class Initialized
DEBUG - 2023-10-31 09:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:28:26 --> Input Class Initialized
INFO - 2023-10-31 09:28:26 --> Language Class Initialized
INFO - 2023-10-31 09:28:26 --> Loader Class Initialized
INFO - 2023-10-31 09:28:26 --> Helper loaded: url_helper
INFO - 2023-10-31 09:28:26 --> Helper loaded: file_helper
INFO - 2023-10-31 09:28:26 --> Helper loaded: html_helper
INFO - 2023-10-31 09:28:26 --> Helper loaded: text_helper
INFO - 2023-10-31 09:28:26 --> Helper loaded: form_helper
INFO - 2023-10-31 09:28:26 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:28:26 --> Helper loaded: security_helper
INFO - 2023-10-31 09:28:26 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:28:26 --> Database Driver Class Initialized
INFO - 2023-10-31 09:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:28:26 --> Parser Class Initialized
INFO - 2023-10-31 09:28:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:28:26 --> Pagination Class Initialized
INFO - 2023-10-31 09:28:26 --> Form Validation Class Initialized
INFO - 2023-10-31 09:28:26 --> Controller Class Initialized
INFO - 2023-10-31 09:28:26 --> Model Class Initialized
DEBUG - 2023-10-31 09:28:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:28:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:28:26 --> Model Class Initialized
INFO - 2023-10-31 09:28:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-10-31 09:28:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:28:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 09:28:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 09:28:26 --> Model Class Initialized
INFO - 2023-10-31 09:28:26 --> Model Class Initialized
INFO - 2023-10-31 09:28:26 --> Model Class Initialized
INFO - 2023-10-31 09:28:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 09:28:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 09:28:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 09:28:26 --> Final output sent to browser
DEBUG - 2023-10-31 09:28:26 --> Total execution time: 0.2201
ERROR - 2023-10-31 09:28:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:28:27 --> Config Class Initialized
INFO - 2023-10-31 09:28:27 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:28:27 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:28:27 --> Utf8 Class Initialized
INFO - 2023-10-31 09:28:27 --> URI Class Initialized
INFO - 2023-10-31 09:28:27 --> Router Class Initialized
INFO - 2023-10-31 09:28:27 --> Output Class Initialized
INFO - 2023-10-31 09:28:27 --> Security Class Initialized
DEBUG - 2023-10-31 09:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:28:27 --> Input Class Initialized
INFO - 2023-10-31 09:28:27 --> Language Class Initialized
INFO - 2023-10-31 09:28:27 --> Loader Class Initialized
INFO - 2023-10-31 09:28:27 --> Helper loaded: url_helper
INFO - 2023-10-31 09:28:27 --> Helper loaded: file_helper
INFO - 2023-10-31 09:28:27 --> Helper loaded: html_helper
INFO - 2023-10-31 09:28:27 --> Helper loaded: text_helper
INFO - 2023-10-31 09:28:27 --> Helper loaded: form_helper
INFO - 2023-10-31 09:28:27 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:28:27 --> Helper loaded: security_helper
INFO - 2023-10-31 09:28:27 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:28:27 --> Database Driver Class Initialized
INFO - 2023-10-31 09:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:28:27 --> Parser Class Initialized
INFO - 2023-10-31 09:28:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:28:27 --> Pagination Class Initialized
INFO - 2023-10-31 09:28:27 --> Form Validation Class Initialized
INFO - 2023-10-31 09:28:27 --> Controller Class Initialized
INFO - 2023-10-31 09:28:27 --> Model Class Initialized
DEBUG - 2023-10-31 09:28:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:28:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:28:27 --> Model Class Initialized
INFO - 2023-10-31 09:28:27 --> Final output sent to browser
DEBUG - 2023-10-31 09:28:27 --> Total execution time: 0.0150
ERROR - 2023-10-31 09:28:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:28:30 --> Config Class Initialized
INFO - 2023-10-31 09:28:30 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:28:30 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:28:30 --> Utf8 Class Initialized
INFO - 2023-10-31 09:28:30 --> URI Class Initialized
INFO - 2023-10-31 09:28:30 --> Router Class Initialized
INFO - 2023-10-31 09:28:30 --> Output Class Initialized
INFO - 2023-10-31 09:28:30 --> Security Class Initialized
DEBUG - 2023-10-31 09:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:28:30 --> Input Class Initialized
INFO - 2023-10-31 09:28:30 --> Language Class Initialized
INFO - 2023-10-31 09:28:30 --> Loader Class Initialized
INFO - 2023-10-31 09:28:30 --> Helper loaded: url_helper
INFO - 2023-10-31 09:28:30 --> Helper loaded: file_helper
INFO - 2023-10-31 09:28:30 --> Helper loaded: html_helper
INFO - 2023-10-31 09:28:30 --> Helper loaded: text_helper
INFO - 2023-10-31 09:28:30 --> Helper loaded: form_helper
INFO - 2023-10-31 09:28:30 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:28:30 --> Helper loaded: security_helper
INFO - 2023-10-31 09:28:30 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:28:30 --> Database Driver Class Initialized
INFO - 2023-10-31 09:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:28:30 --> Parser Class Initialized
INFO - 2023-10-31 09:28:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:28:30 --> Pagination Class Initialized
INFO - 2023-10-31 09:28:30 --> Form Validation Class Initialized
INFO - 2023-10-31 09:28:30 --> Controller Class Initialized
INFO - 2023-10-31 09:28:30 --> Model Class Initialized
DEBUG - 2023-10-31 09:28:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:28:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:28:30 --> Model Class Initialized
INFO - 2023-10-31 09:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2023-10-31 09:28:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 09:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 09:28:30 --> Model Class Initialized
INFO - 2023-10-31 09:28:30 --> Model Class Initialized
INFO - 2023-10-31 09:28:30 --> Model Class Initialized
INFO - 2023-10-31 09:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 09:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 09:28:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 09:28:30 --> Final output sent to browser
DEBUG - 2023-10-31 09:28:30 --> Total execution time: 0.1839
ERROR - 2023-10-31 09:28:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:28:31 --> Config Class Initialized
INFO - 2023-10-31 09:28:31 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:28:31 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:28:31 --> Utf8 Class Initialized
INFO - 2023-10-31 09:28:31 --> URI Class Initialized
INFO - 2023-10-31 09:28:31 --> Router Class Initialized
INFO - 2023-10-31 09:28:31 --> Output Class Initialized
INFO - 2023-10-31 09:28:31 --> Security Class Initialized
DEBUG - 2023-10-31 09:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:28:31 --> Input Class Initialized
INFO - 2023-10-31 09:28:31 --> Language Class Initialized
INFO - 2023-10-31 09:28:31 --> Loader Class Initialized
INFO - 2023-10-31 09:28:31 --> Helper loaded: url_helper
INFO - 2023-10-31 09:28:31 --> Helper loaded: file_helper
INFO - 2023-10-31 09:28:31 --> Helper loaded: html_helper
INFO - 2023-10-31 09:28:31 --> Helper loaded: text_helper
INFO - 2023-10-31 09:28:31 --> Helper loaded: form_helper
INFO - 2023-10-31 09:28:31 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:28:31 --> Helper loaded: security_helper
INFO - 2023-10-31 09:28:31 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:28:31 --> Database Driver Class Initialized
INFO - 2023-10-31 09:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:28:31 --> Parser Class Initialized
INFO - 2023-10-31 09:28:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:28:31 --> Pagination Class Initialized
INFO - 2023-10-31 09:28:31 --> Form Validation Class Initialized
INFO - 2023-10-31 09:28:31 --> Controller Class Initialized
INFO - 2023-10-31 09:28:31 --> Model Class Initialized
DEBUG - 2023-10-31 09:28:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:28:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:28:31 --> Model Class Initialized
INFO - 2023-10-31 09:28:31 --> Final output sent to browser
DEBUG - 2023-10-31 09:28:31 --> Total execution time: 0.0217
ERROR - 2023-10-31 09:28:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:28:32 --> Config Class Initialized
INFO - 2023-10-31 09:28:32 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:28:32 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:28:32 --> Utf8 Class Initialized
INFO - 2023-10-31 09:28:32 --> URI Class Initialized
INFO - 2023-10-31 09:28:32 --> Router Class Initialized
INFO - 2023-10-31 09:28:32 --> Output Class Initialized
INFO - 2023-10-31 09:28:32 --> Security Class Initialized
DEBUG - 2023-10-31 09:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:28:32 --> Input Class Initialized
INFO - 2023-10-31 09:28:32 --> Language Class Initialized
INFO - 2023-10-31 09:28:32 --> Loader Class Initialized
INFO - 2023-10-31 09:28:32 --> Helper loaded: url_helper
INFO - 2023-10-31 09:28:32 --> Helper loaded: file_helper
INFO - 2023-10-31 09:28:32 --> Helper loaded: html_helper
INFO - 2023-10-31 09:28:32 --> Helper loaded: text_helper
INFO - 2023-10-31 09:28:32 --> Helper loaded: form_helper
INFO - 2023-10-31 09:28:32 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:28:32 --> Helper loaded: security_helper
INFO - 2023-10-31 09:28:32 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:28:32 --> Database Driver Class Initialized
INFO - 2023-10-31 09:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:28:32 --> Parser Class Initialized
INFO - 2023-10-31 09:28:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:28:32 --> Pagination Class Initialized
INFO - 2023-10-31 09:28:32 --> Form Validation Class Initialized
INFO - 2023-10-31 09:28:32 --> Controller Class Initialized
INFO - 2023-10-31 09:28:32 --> Model Class Initialized
DEBUG - 2023-10-31 09:28:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:28:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:28:32 --> Model Class Initialized
DEBUG - 2023-10-31 09:28:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:28:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-10-31 09:28:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:28:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 09:28:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 09:28:32 --> Model Class Initialized
INFO - 2023-10-31 09:28:32 --> Model Class Initialized
INFO - 2023-10-31 09:28:32 --> Model Class Initialized
INFO - 2023-10-31 09:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 09:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 09:28:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 09:28:33 --> Final output sent to browser
DEBUG - 2023-10-31 09:28:33 --> Total execution time: 0.1929
ERROR - 2023-10-31 09:29:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:29:08 --> Config Class Initialized
INFO - 2023-10-31 09:29:08 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:29:08 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:29:08 --> Utf8 Class Initialized
INFO - 2023-10-31 09:29:08 --> URI Class Initialized
DEBUG - 2023-10-31 09:29:08 --> No URI present. Default controller set.
INFO - 2023-10-31 09:29:08 --> Router Class Initialized
INFO - 2023-10-31 09:29:08 --> Output Class Initialized
INFO - 2023-10-31 09:29:08 --> Security Class Initialized
DEBUG - 2023-10-31 09:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:29:08 --> Input Class Initialized
INFO - 2023-10-31 09:29:08 --> Language Class Initialized
INFO - 2023-10-31 09:29:08 --> Loader Class Initialized
INFO - 2023-10-31 09:29:08 --> Helper loaded: url_helper
INFO - 2023-10-31 09:29:08 --> Helper loaded: file_helper
INFO - 2023-10-31 09:29:08 --> Helper loaded: html_helper
INFO - 2023-10-31 09:29:08 --> Helper loaded: text_helper
INFO - 2023-10-31 09:29:08 --> Helper loaded: form_helper
INFO - 2023-10-31 09:29:08 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:29:08 --> Helper loaded: security_helper
INFO - 2023-10-31 09:29:08 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:29:08 --> Database Driver Class Initialized
INFO - 2023-10-31 09:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:29:08 --> Parser Class Initialized
INFO - 2023-10-31 09:29:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:29:08 --> Pagination Class Initialized
INFO - 2023-10-31 09:29:08 --> Form Validation Class Initialized
INFO - 2023-10-31 09:29:08 --> Controller Class Initialized
INFO - 2023-10-31 09:29:08 --> Model Class Initialized
DEBUG - 2023-10-31 09:29:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-31 09:29:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:29:09 --> Config Class Initialized
INFO - 2023-10-31 09:29:09 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:29:09 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:29:09 --> Utf8 Class Initialized
INFO - 2023-10-31 09:29:09 --> URI Class Initialized
INFO - 2023-10-31 09:29:09 --> Router Class Initialized
INFO - 2023-10-31 09:29:09 --> Output Class Initialized
INFO - 2023-10-31 09:29:09 --> Security Class Initialized
DEBUG - 2023-10-31 09:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:29:09 --> Input Class Initialized
INFO - 2023-10-31 09:29:09 --> Language Class Initialized
INFO - 2023-10-31 09:29:09 --> Loader Class Initialized
INFO - 2023-10-31 09:29:09 --> Helper loaded: url_helper
INFO - 2023-10-31 09:29:09 --> Helper loaded: file_helper
INFO - 2023-10-31 09:29:09 --> Helper loaded: html_helper
INFO - 2023-10-31 09:29:09 --> Helper loaded: text_helper
INFO - 2023-10-31 09:29:09 --> Helper loaded: form_helper
INFO - 2023-10-31 09:29:09 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:29:09 --> Helper loaded: security_helper
INFO - 2023-10-31 09:29:09 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:29:09 --> Database Driver Class Initialized
INFO - 2023-10-31 09:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:29:09 --> Parser Class Initialized
INFO - 2023-10-31 09:29:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:29:09 --> Pagination Class Initialized
INFO - 2023-10-31 09:29:09 --> Form Validation Class Initialized
INFO - 2023-10-31 09:29:09 --> Controller Class Initialized
INFO - 2023-10-31 09:29:09 --> Model Class Initialized
DEBUG - 2023-10-31 09:29:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:29:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-31 09:29:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:29:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 09:29:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 09:29:09 --> Model Class Initialized
INFO - 2023-10-31 09:29:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 09:29:09 --> Final output sent to browser
DEBUG - 2023-10-31 09:29:09 --> Total execution time: 0.0318
ERROR - 2023-10-31 09:29:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:29:22 --> Config Class Initialized
INFO - 2023-10-31 09:29:22 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:29:22 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:29:22 --> Utf8 Class Initialized
INFO - 2023-10-31 09:29:22 --> URI Class Initialized
INFO - 2023-10-31 09:29:22 --> Router Class Initialized
INFO - 2023-10-31 09:29:22 --> Output Class Initialized
INFO - 2023-10-31 09:29:22 --> Security Class Initialized
DEBUG - 2023-10-31 09:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:29:22 --> Input Class Initialized
INFO - 2023-10-31 09:29:22 --> Language Class Initialized
INFO - 2023-10-31 09:29:22 --> Loader Class Initialized
INFO - 2023-10-31 09:29:22 --> Helper loaded: url_helper
INFO - 2023-10-31 09:29:22 --> Helper loaded: file_helper
INFO - 2023-10-31 09:29:22 --> Helper loaded: html_helper
INFO - 2023-10-31 09:29:22 --> Helper loaded: text_helper
INFO - 2023-10-31 09:29:22 --> Helper loaded: form_helper
INFO - 2023-10-31 09:29:22 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:29:22 --> Helper loaded: security_helper
INFO - 2023-10-31 09:29:22 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:29:22 --> Database Driver Class Initialized
INFO - 2023-10-31 09:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:29:22 --> Parser Class Initialized
INFO - 2023-10-31 09:29:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:29:22 --> Pagination Class Initialized
INFO - 2023-10-31 09:29:22 --> Form Validation Class Initialized
INFO - 2023-10-31 09:29:22 --> Controller Class Initialized
INFO - 2023-10-31 09:29:22 --> Model Class Initialized
DEBUG - 2023-10-31 09:29:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:29:22 --> Model Class Initialized
INFO - 2023-10-31 09:29:22 --> Final output sent to browser
DEBUG - 2023-10-31 09:29:22 --> Total execution time: 0.0197
ERROR - 2023-10-31 09:29:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:29:22 --> Config Class Initialized
INFO - 2023-10-31 09:29:22 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:29:22 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:29:22 --> Utf8 Class Initialized
INFO - 2023-10-31 09:29:22 --> URI Class Initialized
DEBUG - 2023-10-31 09:29:22 --> No URI present. Default controller set.
INFO - 2023-10-31 09:29:22 --> Router Class Initialized
INFO - 2023-10-31 09:29:22 --> Output Class Initialized
INFO - 2023-10-31 09:29:22 --> Security Class Initialized
DEBUG - 2023-10-31 09:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:29:22 --> Input Class Initialized
INFO - 2023-10-31 09:29:22 --> Language Class Initialized
INFO - 2023-10-31 09:29:22 --> Loader Class Initialized
INFO - 2023-10-31 09:29:22 --> Helper loaded: url_helper
INFO - 2023-10-31 09:29:22 --> Helper loaded: file_helper
INFO - 2023-10-31 09:29:22 --> Helper loaded: html_helper
INFO - 2023-10-31 09:29:22 --> Helper loaded: text_helper
INFO - 2023-10-31 09:29:22 --> Helper loaded: form_helper
INFO - 2023-10-31 09:29:22 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:29:22 --> Helper loaded: security_helper
INFO - 2023-10-31 09:29:22 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:29:22 --> Database Driver Class Initialized
INFO - 2023-10-31 09:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:29:22 --> Parser Class Initialized
INFO - 2023-10-31 09:29:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:29:22 --> Pagination Class Initialized
INFO - 2023-10-31 09:29:22 --> Form Validation Class Initialized
INFO - 2023-10-31 09:29:22 --> Controller Class Initialized
INFO - 2023-10-31 09:29:22 --> Model Class Initialized
DEBUG - 2023-10-31 09:29:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:29:22 --> Model Class Initialized
DEBUG - 2023-10-31 09:29:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:29:22 --> Model Class Initialized
INFO - 2023-10-31 09:29:22 --> Model Class Initialized
INFO - 2023-10-31 09:29:22 --> Model Class Initialized
INFO - 2023-10-31 09:29:22 --> Model Class Initialized
DEBUG - 2023-10-31 09:29:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:29:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:29:22 --> Model Class Initialized
INFO - 2023-10-31 09:29:22 --> Model Class Initialized
INFO - 2023-10-31 09:29:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-31 09:29:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:29:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 09:29:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 09:29:22 --> Model Class Initialized
INFO - 2023-10-31 09:29:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 09:29:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 09:29:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 09:29:22 --> Final output sent to browser
DEBUG - 2023-10-31 09:29:22 --> Total execution time: 0.1955
ERROR - 2023-10-31 09:29:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:29:27 --> Config Class Initialized
INFO - 2023-10-31 09:29:27 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:29:27 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:29:27 --> Utf8 Class Initialized
INFO - 2023-10-31 09:29:27 --> URI Class Initialized
INFO - 2023-10-31 09:29:27 --> Router Class Initialized
INFO - 2023-10-31 09:29:27 --> Output Class Initialized
INFO - 2023-10-31 09:29:27 --> Security Class Initialized
DEBUG - 2023-10-31 09:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:29:27 --> Input Class Initialized
INFO - 2023-10-31 09:29:27 --> Language Class Initialized
INFO - 2023-10-31 09:29:27 --> Loader Class Initialized
INFO - 2023-10-31 09:29:27 --> Helper loaded: url_helper
INFO - 2023-10-31 09:29:27 --> Helper loaded: file_helper
INFO - 2023-10-31 09:29:27 --> Helper loaded: html_helper
INFO - 2023-10-31 09:29:27 --> Helper loaded: text_helper
INFO - 2023-10-31 09:29:27 --> Helper loaded: form_helper
INFO - 2023-10-31 09:29:27 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:29:27 --> Helper loaded: security_helper
INFO - 2023-10-31 09:29:27 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:29:27 --> Database Driver Class Initialized
INFO - 2023-10-31 09:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:29:27 --> Parser Class Initialized
INFO - 2023-10-31 09:29:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:29:27 --> Pagination Class Initialized
INFO - 2023-10-31 09:29:27 --> Form Validation Class Initialized
INFO - 2023-10-31 09:29:27 --> Controller Class Initialized
INFO - 2023-10-31 09:29:27 --> Model Class Initialized
DEBUG - 2023-10-31 09:29:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:29:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:29:27 --> Model Class Initialized
DEBUG - 2023-10-31 09:29:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:29:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-10-31 09:29:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:29:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 09:29:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 09:29:27 --> Model Class Initialized
INFO - 2023-10-31 09:29:27 --> Model Class Initialized
INFO - 2023-10-31 09:29:27 --> Model Class Initialized
INFO - 2023-10-31 09:29:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 09:29:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 09:29:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 09:29:27 --> Final output sent to browser
DEBUG - 2023-10-31 09:29:27 --> Total execution time: 0.1361
ERROR - 2023-10-31 09:29:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:29:32 --> Config Class Initialized
INFO - 2023-10-31 09:29:32 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:29:32 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:29:32 --> Utf8 Class Initialized
INFO - 2023-10-31 09:29:32 --> URI Class Initialized
INFO - 2023-10-31 09:29:32 --> Router Class Initialized
INFO - 2023-10-31 09:29:32 --> Output Class Initialized
INFO - 2023-10-31 09:29:32 --> Security Class Initialized
DEBUG - 2023-10-31 09:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:29:32 --> Input Class Initialized
INFO - 2023-10-31 09:29:32 --> Language Class Initialized
INFO - 2023-10-31 09:29:32 --> Loader Class Initialized
INFO - 2023-10-31 09:29:32 --> Helper loaded: url_helper
INFO - 2023-10-31 09:29:32 --> Helper loaded: file_helper
INFO - 2023-10-31 09:29:32 --> Helper loaded: html_helper
INFO - 2023-10-31 09:29:32 --> Helper loaded: text_helper
INFO - 2023-10-31 09:29:32 --> Helper loaded: form_helper
INFO - 2023-10-31 09:29:32 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:29:32 --> Helper loaded: security_helper
INFO - 2023-10-31 09:29:32 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:29:32 --> Database Driver Class Initialized
INFO - 2023-10-31 09:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:29:32 --> Parser Class Initialized
INFO - 2023-10-31 09:29:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:29:32 --> Pagination Class Initialized
INFO - 2023-10-31 09:29:32 --> Form Validation Class Initialized
INFO - 2023-10-31 09:29:32 --> Controller Class Initialized
INFO - 2023-10-31 09:29:32 --> Model Class Initialized
DEBUG - 2023-10-31 09:29:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:29:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:29:32 --> Model Class Initialized
DEBUG - 2023-10-31 09:29:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:29:32 --> Model Class Initialized
INFO - 2023-10-31 09:29:32 --> Final output sent to browser
DEBUG - 2023-10-31 09:29:32 --> Total execution time: 0.0880
ERROR - 2023-10-31 09:29:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:29:33 --> Config Class Initialized
INFO - 2023-10-31 09:29:33 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:29:33 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:29:33 --> Utf8 Class Initialized
INFO - 2023-10-31 09:29:33 --> URI Class Initialized
INFO - 2023-10-31 09:29:33 --> Router Class Initialized
INFO - 2023-10-31 09:29:33 --> Output Class Initialized
INFO - 2023-10-31 09:29:33 --> Security Class Initialized
DEBUG - 2023-10-31 09:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:29:33 --> Input Class Initialized
INFO - 2023-10-31 09:29:33 --> Language Class Initialized
INFO - 2023-10-31 09:29:33 --> Loader Class Initialized
INFO - 2023-10-31 09:29:33 --> Helper loaded: url_helper
INFO - 2023-10-31 09:29:33 --> Helper loaded: file_helper
INFO - 2023-10-31 09:29:33 --> Helper loaded: html_helper
INFO - 2023-10-31 09:29:33 --> Helper loaded: text_helper
INFO - 2023-10-31 09:29:33 --> Helper loaded: form_helper
INFO - 2023-10-31 09:29:33 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:29:33 --> Helper loaded: security_helper
INFO - 2023-10-31 09:29:33 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:29:33 --> Database Driver Class Initialized
INFO - 2023-10-31 09:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:29:33 --> Parser Class Initialized
INFO - 2023-10-31 09:29:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:29:33 --> Pagination Class Initialized
INFO - 2023-10-31 09:29:33 --> Form Validation Class Initialized
INFO - 2023-10-31 09:29:33 --> Controller Class Initialized
INFO - 2023-10-31 09:29:33 --> Model Class Initialized
DEBUG - 2023-10-31 09:29:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:29:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:29:33 --> Model Class Initialized
DEBUG - 2023-10-31 09:29:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:29:33 --> Model Class Initialized
INFO - 2023-10-31 09:29:33 --> Final output sent to browser
DEBUG - 2023-10-31 09:29:33 --> Total execution time: 0.0858
ERROR - 2023-10-31 09:29:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:29:33 --> Config Class Initialized
INFO - 2023-10-31 09:29:33 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:29:33 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:29:33 --> Utf8 Class Initialized
INFO - 2023-10-31 09:29:33 --> URI Class Initialized
INFO - 2023-10-31 09:29:33 --> Router Class Initialized
INFO - 2023-10-31 09:29:33 --> Output Class Initialized
INFO - 2023-10-31 09:29:33 --> Security Class Initialized
DEBUG - 2023-10-31 09:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:29:33 --> Input Class Initialized
INFO - 2023-10-31 09:29:33 --> Language Class Initialized
INFO - 2023-10-31 09:29:33 --> Loader Class Initialized
INFO - 2023-10-31 09:29:33 --> Helper loaded: url_helper
INFO - 2023-10-31 09:29:33 --> Helper loaded: file_helper
INFO - 2023-10-31 09:29:33 --> Helper loaded: html_helper
INFO - 2023-10-31 09:29:33 --> Helper loaded: text_helper
INFO - 2023-10-31 09:29:33 --> Helper loaded: form_helper
INFO - 2023-10-31 09:29:33 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:29:33 --> Helper loaded: security_helper
INFO - 2023-10-31 09:29:33 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:29:33 --> Database Driver Class Initialized
INFO - 2023-10-31 09:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:29:33 --> Parser Class Initialized
INFO - 2023-10-31 09:29:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:29:33 --> Pagination Class Initialized
INFO - 2023-10-31 09:29:33 --> Form Validation Class Initialized
INFO - 2023-10-31 09:29:33 --> Controller Class Initialized
INFO - 2023-10-31 09:29:33 --> Model Class Initialized
DEBUG - 2023-10-31 09:29:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:29:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:29:33 --> Model Class Initialized
DEBUG - 2023-10-31 09:29:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:29:33 --> Model Class Initialized
INFO - 2023-10-31 09:29:33 --> Final output sent to browser
DEBUG - 2023-10-31 09:29:33 --> Total execution time: 0.0771
ERROR - 2023-10-31 09:29:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:29:33 --> Config Class Initialized
INFO - 2023-10-31 09:29:33 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:29:33 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:29:33 --> Utf8 Class Initialized
INFO - 2023-10-31 09:29:33 --> URI Class Initialized
INFO - 2023-10-31 09:29:33 --> Router Class Initialized
INFO - 2023-10-31 09:29:33 --> Output Class Initialized
INFO - 2023-10-31 09:29:33 --> Security Class Initialized
DEBUG - 2023-10-31 09:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:29:33 --> Input Class Initialized
INFO - 2023-10-31 09:29:33 --> Language Class Initialized
INFO - 2023-10-31 09:29:33 --> Loader Class Initialized
INFO - 2023-10-31 09:29:33 --> Helper loaded: url_helper
INFO - 2023-10-31 09:29:33 --> Helper loaded: file_helper
INFO - 2023-10-31 09:29:33 --> Helper loaded: html_helper
INFO - 2023-10-31 09:29:33 --> Helper loaded: text_helper
INFO - 2023-10-31 09:29:33 --> Helper loaded: form_helper
INFO - 2023-10-31 09:29:33 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:29:33 --> Helper loaded: security_helper
INFO - 2023-10-31 09:29:33 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:29:33 --> Database Driver Class Initialized
INFO - 2023-10-31 09:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:29:33 --> Parser Class Initialized
INFO - 2023-10-31 09:29:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:29:33 --> Pagination Class Initialized
INFO - 2023-10-31 09:29:33 --> Form Validation Class Initialized
INFO - 2023-10-31 09:29:33 --> Controller Class Initialized
INFO - 2023-10-31 09:29:33 --> Model Class Initialized
DEBUG - 2023-10-31 09:29:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:29:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:29:33 --> Model Class Initialized
DEBUG - 2023-10-31 09:29:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:29:33 --> Model Class Initialized
INFO - 2023-10-31 09:29:34 --> Final output sent to browser
DEBUG - 2023-10-31 09:29:34 --> Total execution time: 0.0839
ERROR - 2023-10-31 09:29:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:29:40 --> Config Class Initialized
INFO - 2023-10-31 09:29:40 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:29:40 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:29:40 --> Utf8 Class Initialized
INFO - 2023-10-31 09:29:40 --> URI Class Initialized
INFO - 2023-10-31 09:29:40 --> Router Class Initialized
INFO - 2023-10-31 09:29:40 --> Output Class Initialized
INFO - 2023-10-31 09:29:40 --> Security Class Initialized
DEBUG - 2023-10-31 09:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:29:40 --> Input Class Initialized
INFO - 2023-10-31 09:29:40 --> Language Class Initialized
INFO - 2023-10-31 09:29:40 --> Loader Class Initialized
INFO - 2023-10-31 09:29:40 --> Helper loaded: url_helper
INFO - 2023-10-31 09:29:40 --> Helper loaded: file_helper
INFO - 2023-10-31 09:29:40 --> Helper loaded: html_helper
INFO - 2023-10-31 09:29:40 --> Helper loaded: text_helper
INFO - 2023-10-31 09:29:40 --> Helper loaded: form_helper
INFO - 2023-10-31 09:29:40 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:29:40 --> Helper loaded: security_helper
INFO - 2023-10-31 09:29:40 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:29:40 --> Database Driver Class Initialized
INFO - 2023-10-31 09:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:29:40 --> Parser Class Initialized
INFO - 2023-10-31 09:29:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:29:40 --> Pagination Class Initialized
INFO - 2023-10-31 09:29:40 --> Form Validation Class Initialized
INFO - 2023-10-31 09:29:40 --> Controller Class Initialized
INFO - 2023-10-31 09:29:40 --> Model Class Initialized
DEBUG - 2023-10-31 09:29:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:29:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:29:40 --> Model Class Initialized
INFO - 2023-10-31 09:29:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-10-31 09:29:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:29:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 09:29:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 09:29:40 --> Model Class Initialized
INFO - 2023-10-31 09:29:40 --> Model Class Initialized
INFO - 2023-10-31 09:29:40 --> Model Class Initialized
INFO - 2023-10-31 09:29:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 09:29:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 09:29:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 09:29:40 --> Final output sent to browser
DEBUG - 2023-10-31 09:29:40 --> Total execution time: 0.1308
ERROR - 2023-10-31 09:29:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:29:40 --> Config Class Initialized
INFO - 2023-10-31 09:29:40 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:29:40 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:29:40 --> Utf8 Class Initialized
INFO - 2023-10-31 09:29:40 --> URI Class Initialized
INFO - 2023-10-31 09:29:40 --> Router Class Initialized
INFO - 2023-10-31 09:29:40 --> Output Class Initialized
INFO - 2023-10-31 09:29:40 --> Security Class Initialized
DEBUG - 2023-10-31 09:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:29:40 --> Input Class Initialized
INFO - 2023-10-31 09:29:40 --> Language Class Initialized
INFO - 2023-10-31 09:29:40 --> Loader Class Initialized
INFO - 2023-10-31 09:29:40 --> Helper loaded: url_helper
INFO - 2023-10-31 09:29:40 --> Helper loaded: file_helper
INFO - 2023-10-31 09:29:40 --> Helper loaded: html_helper
INFO - 2023-10-31 09:29:40 --> Helper loaded: text_helper
INFO - 2023-10-31 09:29:40 --> Helper loaded: form_helper
INFO - 2023-10-31 09:29:40 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:29:40 --> Helper loaded: security_helper
INFO - 2023-10-31 09:29:40 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:29:40 --> Database Driver Class Initialized
INFO - 2023-10-31 09:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:29:40 --> Parser Class Initialized
INFO - 2023-10-31 09:29:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:29:40 --> Pagination Class Initialized
INFO - 2023-10-31 09:29:40 --> Form Validation Class Initialized
INFO - 2023-10-31 09:29:40 --> Controller Class Initialized
INFO - 2023-10-31 09:29:40 --> Model Class Initialized
DEBUG - 2023-10-31 09:29:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:29:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:29:40 --> Model Class Initialized
INFO - 2023-10-31 09:29:40 --> Final output sent to browser
DEBUG - 2023-10-31 09:29:40 --> Total execution time: 0.0159
ERROR - 2023-10-31 09:29:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:29:42 --> Config Class Initialized
INFO - 2023-10-31 09:29:42 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:29:42 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:29:42 --> Utf8 Class Initialized
INFO - 2023-10-31 09:29:42 --> URI Class Initialized
INFO - 2023-10-31 09:29:42 --> Router Class Initialized
INFO - 2023-10-31 09:29:42 --> Output Class Initialized
INFO - 2023-10-31 09:29:42 --> Security Class Initialized
DEBUG - 2023-10-31 09:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:29:42 --> Input Class Initialized
INFO - 2023-10-31 09:29:42 --> Language Class Initialized
INFO - 2023-10-31 09:29:42 --> Loader Class Initialized
INFO - 2023-10-31 09:29:42 --> Helper loaded: url_helper
INFO - 2023-10-31 09:29:42 --> Helper loaded: file_helper
INFO - 2023-10-31 09:29:42 --> Helper loaded: html_helper
INFO - 2023-10-31 09:29:42 --> Helper loaded: text_helper
INFO - 2023-10-31 09:29:42 --> Helper loaded: form_helper
INFO - 2023-10-31 09:29:42 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:29:42 --> Helper loaded: security_helper
INFO - 2023-10-31 09:29:42 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:29:42 --> Database Driver Class Initialized
INFO - 2023-10-31 09:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:29:42 --> Parser Class Initialized
INFO - 2023-10-31 09:29:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:29:42 --> Pagination Class Initialized
INFO - 2023-10-31 09:29:42 --> Form Validation Class Initialized
INFO - 2023-10-31 09:29:42 --> Controller Class Initialized
INFO - 2023-10-31 09:29:42 --> Model Class Initialized
DEBUG - 2023-10-31 09:29:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:29:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:29:42 --> Model Class Initialized
INFO - 2023-10-31 09:29:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2023-10-31 09:29:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:29:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 09:29:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 09:29:42 --> Model Class Initialized
INFO - 2023-10-31 09:29:42 --> Model Class Initialized
INFO - 2023-10-31 09:29:42 --> Model Class Initialized
INFO - 2023-10-31 09:29:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 09:29:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 09:29:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 09:29:43 --> Final output sent to browser
DEBUG - 2023-10-31 09:29:43 --> Total execution time: 0.1262
ERROR - 2023-10-31 09:29:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:29:43 --> Config Class Initialized
INFO - 2023-10-31 09:29:43 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:29:43 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:29:43 --> Utf8 Class Initialized
INFO - 2023-10-31 09:29:43 --> URI Class Initialized
INFO - 2023-10-31 09:29:43 --> Router Class Initialized
INFO - 2023-10-31 09:29:43 --> Output Class Initialized
INFO - 2023-10-31 09:29:43 --> Security Class Initialized
DEBUG - 2023-10-31 09:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:29:43 --> Input Class Initialized
INFO - 2023-10-31 09:29:43 --> Language Class Initialized
INFO - 2023-10-31 09:29:43 --> Loader Class Initialized
INFO - 2023-10-31 09:29:43 --> Helper loaded: url_helper
INFO - 2023-10-31 09:29:43 --> Helper loaded: file_helper
INFO - 2023-10-31 09:29:43 --> Helper loaded: html_helper
INFO - 2023-10-31 09:29:43 --> Helper loaded: text_helper
INFO - 2023-10-31 09:29:43 --> Helper loaded: form_helper
INFO - 2023-10-31 09:29:43 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:29:43 --> Helper loaded: security_helper
INFO - 2023-10-31 09:29:43 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:29:43 --> Database Driver Class Initialized
INFO - 2023-10-31 09:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:29:43 --> Parser Class Initialized
INFO - 2023-10-31 09:29:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:29:43 --> Pagination Class Initialized
INFO - 2023-10-31 09:29:43 --> Form Validation Class Initialized
INFO - 2023-10-31 09:29:43 --> Controller Class Initialized
INFO - 2023-10-31 09:29:43 --> Model Class Initialized
DEBUG - 2023-10-31 09:29:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:29:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:29:43 --> Model Class Initialized
INFO - 2023-10-31 09:29:43 --> Final output sent to browser
DEBUG - 2023-10-31 09:29:43 --> Total execution time: 0.0169
ERROR - 2023-10-31 09:29:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:29:46 --> Config Class Initialized
INFO - 2023-10-31 09:29:46 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:29:46 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:29:46 --> Utf8 Class Initialized
INFO - 2023-10-31 09:29:46 --> URI Class Initialized
INFO - 2023-10-31 09:29:46 --> Router Class Initialized
INFO - 2023-10-31 09:29:46 --> Output Class Initialized
INFO - 2023-10-31 09:29:46 --> Security Class Initialized
DEBUG - 2023-10-31 09:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:29:46 --> Input Class Initialized
INFO - 2023-10-31 09:29:46 --> Language Class Initialized
INFO - 2023-10-31 09:29:46 --> Loader Class Initialized
INFO - 2023-10-31 09:29:46 --> Helper loaded: url_helper
INFO - 2023-10-31 09:29:46 --> Helper loaded: file_helper
INFO - 2023-10-31 09:29:46 --> Helper loaded: html_helper
INFO - 2023-10-31 09:29:46 --> Helper loaded: text_helper
INFO - 2023-10-31 09:29:46 --> Helper loaded: form_helper
INFO - 2023-10-31 09:29:46 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:29:46 --> Helper loaded: security_helper
INFO - 2023-10-31 09:29:46 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:29:46 --> Database Driver Class Initialized
INFO - 2023-10-31 09:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:29:46 --> Parser Class Initialized
INFO - 2023-10-31 09:29:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:29:46 --> Pagination Class Initialized
INFO - 2023-10-31 09:29:46 --> Form Validation Class Initialized
INFO - 2023-10-31 09:29:46 --> Controller Class Initialized
INFO - 2023-10-31 09:29:46 --> Model Class Initialized
DEBUG - 2023-10-31 09:29:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:29:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:29:46 --> Model Class Initialized
DEBUG - 2023-10-31 09:29:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:29:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-10-31 09:29:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:29:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 09:29:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 09:29:46 --> Model Class Initialized
INFO - 2023-10-31 09:29:46 --> Model Class Initialized
INFO - 2023-10-31 09:29:46 --> Model Class Initialized
INFO - 2023-10-31 09:29:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 09:29:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 09:29:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 09:29:46 --> Final output sent to browser
DEBUG - 2023-10-31 09:29:46 --> Total execution time: 0.1270
ERROR - 2023-10-31 09:35:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:35:39 --> Config Class Initialized
INFO - 2023-10-31 09:35:39 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:35:39 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:35:39 --> Utf8 Class Initialized
INFO - 2023-10-31 09:35:39 --> URI Class Initialized
INFO - 2023-10-31 09:35:39 --> Router Class Initialized
INFO - 2023-10-31 09:35:39 --> Output Class Initialized
INFO - 2023-10-31 09:35:39 --> Security Class Initialized
DEBUG - 2023-10-31 09:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:35:39 --> Input Class Initialized
INFO - 2023-10-31 09:35:39 --> Language Class Initialized
INFO - 2023-10-31 09:35:39 --> Loader Class Initialized
INFO - 2023-10-31 09:35:39 --> Helper loaded: url_helper
INFO - 2023-10-31 09:35:39 --> Helper loaded: file_helper
INFO - 2023-10-31 09:35:39 --> Helper loaded: html_helper
INFO - 2023-10-31 09:35:39 --> Helper loaded: text_helper
INFO - 2023-10-31 09:35:39 --> Helper loaded: form_helper
INFO - 2023-10-31 09:35:39 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:35:39 --> Helper loaded: security_helper
INFO - 2023-10-31 09:35:39 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:35:39 --> Database Driver Class Initialized
INFO - 2023-10-31 09:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:35:39 --> Parser Class Initialized
INFO - 2023-10-31 09:35:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:35:39 --> Pagination Class Initialized
INFO - 2023-10-31 09:35:39 --> Form Validation Class Initialized
INFO - 2023-10-31 09:35:39 --> Controller Class Initialized
INFO - 2023-10-31 09:35:39 --> Model Class Initialized
DEBUG - 2023-10-31 09:35:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:35:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:35:39 --> Model Class Initialized
INFO - 2023-10-31 09:35:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2023-10-31 09:35:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:35:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 09:35:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 09:35:39 --> Model Class Initialized
INFO - 2023-10-31 09:35:39 --> Model Class Initialized
INFO - 2023-10-31 09:35:39 --> Model Class Initialized
INFO - 2023-10-31 09:35:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 09:35:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 09:35:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 09:35:39 --> Final output sent to browser
DEBUG - 2023-10-31 09:35:39 --> Total execution time: 0.1300
ERROR - 2023-10-31 09:35:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:35:40 --> Config Class Initialized
INFO - 2023-10-31 09:35:40 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:35:40 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:35:40 --> Utf8 Class Initialized
INFO - 2023-10-31 09:35:40 --> URI Class Initialized
INFO - 2023-10-31 09:35:40 --> Router Class Initialized
INFO - 2023-10-31 09:35:40 --> Output Class Initialized
INFO - 2023-10-31 09:35:40 --> Security Class Initialized
DEBUG - 2023-10-31 09:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:35:40 --> Input Class Initialized
INFO - 2023-10-31 09:35:40 --> Language Class Initialized
INFO - 2023-10-31 09:35:40 --> Loader Class Initialized
INFO - 2023-10-31 09:35:40 --> Helper loaded: url_helper
INFO - 2023-10-31 09:35:40 --> Helper loaded: file_helper
INFO - 2023-10-31 09:35:40 --> Helper loaded: html_helper
INFO - 2023-10-31 09:35:40 --> Helper loaded: text_helper
INFO - 2023-10-31 09:35:40 --> Helper loaded: form_helper
INFO - 2023-10-31 09:35:40 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:35:40 --> Helper loaded: security_helper
INFO - 2023-10-31 09:35:40 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:35:40 --> Database Driver Class Initialized
INFO - 2023-10-31 09:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:35:40 --> Parser Class Initialized
INFO - 2023-10-31 09:35:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:35:40 --> Pagination Class Initialized
INFO - 2023-10-31 09:35:40 --> Form Validation Class Initialized
INFO - 2023-10-31 09:35:40 --> Controller Class Initialized
INFO - 2023-10-31 09:35:40 --> Model Class Initialized
DEBUG - 2023-10-31 09:35:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:35:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:35:40 --> Model Class Initialized
INFO - 2023-10-31 09:35:40 --> Final output sent to browser
DEBUG - 2023-10-31 09:35:40 --> Total execution time: 0.0188
ERROR - 2023-10-31 09:35:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:35:51 --> Config Class Initialized
INFO - 2023-10-31 09:35:51 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:35:51 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:35:51 --> Utf8 Class Initialized
INFO - 2023-10-31 09:35:51 --> URI Class Initialized
DEBUG - 2023-10-31 09:35:51 --> No URI present. Default controller set.
INFO - 2023-10-31 09:35:51 --> Router Class Initialized
INFO - 2023-10-31 09:35:51 --> Output Class Initialized
INFO - 2023-10-31 09:35:51 --> Security Class Initialized
DEBUG - 2023-10-31 09:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:35:51 --> Input Class Initialized
INFO - 2023-10-31 09:35:51 --> Language Class Initialized
INFO - 2023-10-31 09:35:51 --> Loader Class Initialized
INFO - 2023-10-31 09:35:51 --> Helper loaded: url_helper
INFO - 2023-10-31 09:35:51 --> Helper loaded: file_helper
INFO - 2023-10-31 09:35:51 --> Helper loaded: html_helper
INFO - 2023-10-31 09:35:51 --> Helper loaded: text_helper
INFO - 2023-10-31 09:35:51 --> Helper loaded: form_helper
INFO - 2023-10-31 09:35:51 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:35:51 --> Helper loaded: security_helper
INFO - 2023-10-31 09:35:51 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:35:51 --> Database Driver Class Initialized
INFO - 2023-10-31 09:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:35:51 --> Parser Class Initialized
INFO - 2023-10-31 09:35:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:35:51 --> Pagination Class Initialized
INFO - 2023-10-31 09:35:51 --> Form Validation Class Initialized
INFO - 2023-10-31 09:35:51 --> Controller Class Initialized
INFO - 2023-10-31 09:35:51 --> Model Class Initialized
DEBUG - 2023-10-31 09:35:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:35:51 --> Model Class Initialized
DEBUG - 2023-10-31 09:35:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:35:51 --> Model Class Initialized
INFO - 2023-10-31 09:35:51 --> Model Class Initialized
INFO - 2023-10-31 09:35:51 --> Model Class Initialized
INFO - 2023-10-31 09:35:51 --> Model Class Initialized
DEBUG - 2023-10-31 09:35:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:35:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:35:51 --> Model Class Initialized
INFO - 2023-10-31 09:35:51 --> Model Class Initialized
INFO - 2023-10-31 09:35:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-31 09:35:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:35:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 09:35:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 09:35:51 --> Model Class Initialized
INFO - 2023-10-31 09:35:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 09:35:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 09:35:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 09:35:51 --> Final output sent to browser
DEBUG - 2023-10-31 09:35:51 --> Total execution time: 0.3445
ERROR - 2023-10-31 09:40:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:40:28 --> Config Class Initialized
INFO - 2023-10-31 09:40:28 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:40:28 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:40:28 --> Utf8 Class Initialized
INFO - 2023-10-31 09:40:28 --> URI Class Initialized
INFO - 2023-10-31 09:40:28 --> Router Class Initialized
INFO - 2023-10-31 09:40:28 --> Output Class Initialized
INFO - 2023-10-31 09:40:28 --> Security Class Initialized
DEBUG - 2023-10-31 09:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:40:28 --> Input Class Initialized
INFO - 2023-10-31 09:40:28 --> Language Class Initialized
INFO - 2023-10-31 09:40:28 --> Loader Class Initialized
INFO - 2023-10-31 09:40:28 --> Helper loaded: url_helper
INFO - 2023-10-31 09:40:28 --> Helper loaded: file_helper
INFO - 2023-10-31 09:40:28 --> Helper loaded: html_helper
INFO - 2023-10-31 09:40:28 --> Helper loaded: text_helper
INFO - 2023-10-31 09:40:28 --> Helper loaded: form_helper
INFO - 2023-10-31 09:40:28 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:40:28 --> Helper loaded: security_helper
INFO - 2023-10-31 09:40:28 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:40:28 --> Database Driver Class Initialized
INFO - 2023-10-31 09:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:40:28 --> Parser Class Initialized
INFO - 2023-10-31 09:40:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:40:28 --> Pagination Class Initialized
INFO - 2023-10-31 09:40:28 --> Form Validation Class Initialized
INFO - 2023-10-31 09:40:28 --> Controller Class Initialized
INFO - 2023-10-31 09:40:28 --> Model Class Initialized
DEBUG - 2023-10-31 09:40:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:40:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:40:28 --> Model Class Initialized
DEBUG - 2023-10-31 09:40:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:40:28 --> Model Class Initialized
INFO - 2023-10-31 09:40:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-31 09:40:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:40:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-31 09:40:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-31 09:40:28 --> Model Class Initialized
INFO - 2023-10-31 09:40:28 --> Model Class Initialized
INFO - 2023-10-31 09:40:28 --> Model Class Initialized
INFO - 2023-10-31 09:40:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-31 09:40:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-31 09:40:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-31 09:40:29 --> Final output sent to browser
DEBUG - 2023-10-31 09:40:29 --> Total execution time: 0.1984
ERROR - 2023-10-31 09:40:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 09:40:29 --> Config Class Initialized
INFO - 2023-10-31 09:40:29 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:40:29 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:40:29 --> Utf8 Class Initialized
INFO - 2023-10-31 09:40:29 --> URI Class Initialized
INFO - 2023-10-31 09:40:29 --> Router Class Initialized
INFO - 2023-10-31 09:40:29 --> Output Class Initialized
INFO - 2023-10-31 09:40:29 --> Security Class Initialized
DEBUG - 2023-10-31 09:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:40:29 --> Input Class Initialized
INFO - 2023-10-31 09:40:29 --> Language Class Initialized
INFO - 2023-10-31 09:40:29 --> Loader Class Initialized
INFO - 2023-10-31 09:40:29 --> Helper loaded: url_helper
INFO - 2023-10-31 09:40:29 --> Helper loaded: file_helper
INFO - 2023-10-31 09:40:29 --> Helper loaded: html_helper
INFO - 2023-10-31 09:40:29 --> Helper loaded: text_helper
INFO - 2023-10-31 09:40:29 --> Helper loaded: form_helper
INFO - 2023-10-31 09:40:29 --> Helper loaded: lang_helper
INFO - 2023-10-31 09:40:29 --> Helper loaded: security_helper
INFO - 2023-10-31 09:40:29 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:40:29 --> Database Driver Class Initialized
INFO - 2023-10-31 09:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:40:29 --> Parser Class Initialized
INFO - 2023-10-31 09:40:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-31 09:40:29 --> Pagination Class Initialized
INFO - 2023-10-31 09:40:29 --> Form Validation Class Initialized
INFO - 2023-10-31 09:40:29 --> Controller Class Initialized
INFO - 2023-10-31 09:40:29 --> Model Class Initialized
DEBUG - 2023-10-31 09:40:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-31 09:40:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:40:29 --> Model Class Initialized
DEBUG - 2023-10-31 09:40:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-31 09:40:29 --> Model Class Initialized
INFO - 2023-10-31 09:40:29 --> Final output sent to browser
DEBUG - 2023-10-31 09:40:29 --> Total execution time: 0.0569
ERROR - 2023-10-31 19:33:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-31 19:33:13 --> Config Class Initialized
INFO - 2023-10-31 19:33:13 --> Hooks Class Initialized
DEBUG - 2023-10-31 19:33:13 --> UTF-8 Support Enabled
INFO - 2023-10-31 19:33:13 --> Utf8 Class Initialized
INFO - 2023-10-31 19:33:13 --> URI Class Initialized
INFO - 2023-10-31 19:33:13 --> Router Class Initialized
INFO - 2023-10-31 19:33:13 --> Output Class Initialized
INFO - 2023-10-31 19:33:13 --> Security Class Initialized
DEBUG - 2023-10-31 19:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 19:33:13 --> Input Class Initialized
INFO - 2023-10-31 19:33:13 --> Language Class Initialized
ERROR - 2023-10-31 19:33:13 --> 404 Page Not Found: Well-known/assetlinks.json
