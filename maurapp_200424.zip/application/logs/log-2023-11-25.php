<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-25 02:41:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-25 02:41:46 --> Config Class Initialized
INFO - 2023-11-25 02:41:46 --> Hooks Class Initialized
DEBUG - 2023-11-25 02:41:46 --> UTF-8 Support Enabled
INFO - 2023-11-25 02:41:46 --> Utf8 Class Initialized
INFO - 2023-11-25 02:41:46 --> URI Class Initialized
DEBUG - 2023-11-25 02:41:46 --> No URI present. Default controller set.
INFO - 2023-11-25 02:41:46 --> Router Class Initialized
INFO - 2023-11-25 02:41:46 --> Output Class Initialized
INFO - 2023-11-25 02:41:46 --> Security Class Initialized
DEBUG - 2023-11-25 02:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 02:41:46 --> Input Class Initialized
INFO - 2023-11-25 02:41:46 --> Language Class Initialized
INFO - 2023-11-25 02:41:46 --> Loader Class Initialized
INFO - 2023-11-25 02:41:46 --> Helper loaded: url_helper
INFO - 2023-11-25 02:41:46 --> Helper loaded: file_helper
INFO - 2023-11-25 02:41:46 --> Helper loaded: html_helper
INFO - 2023-11-25 02:41:46 --> Helper loaded: text_helper
INFO - 2023-11-25 02:41:46 --> Helper loaded: form_helper
INFO - 2023-11-25 02:41:46 --> Helper loaded: lang_helper
INFO - 2023-11-25 02:41:46 --> Helper loaded: security_helper
INFO - 2023-11-25 02:41:46 --> Helper loaded: cookie_helper
INFO - 2023-11-25 02:41:46 --> Database Driver Class Initialized
INFO - 2023-11-25 02:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 02:41:46 --> Parser Class Initialized
INFO - 2023-11-25 02:41:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-25 02:41:46 --> Pagination Class Initialized
INFO - 2023-11-25 02:41:46 --> Form Validation Class Initialized
INFO - 2023-11-25 02:41:46 --> Controller Class Initialized
INFO - 2023-11-25 02:41:46 --> Model Class Initialized
DEBUG - 2023-11-25 02:41:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-25 02:41:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-25 02:41:47 --> Config Class Initialized
INFO - 2023-11-25 02:41:47 --> Hooks Class Initialized
DEBUG - 2023-11-25 02:41:47 --> UTF-8 Support Enabled
INFO - 2023-11-25 02:41:47 --> Utf8 Class Initialized
INFO - 2023-11-25 02:41:47 --> URI Class Initialized
INFO - 2023-11-25 02:41:47 --> Router Class Initialized
INFO - 2023-11-25 02:41:47 --> Output Class Initialized
INFO - 2023-11-25 02:41:47 --> Security Class Initialized
DEBUG - 2023-11-25 02:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 02:41:47 --> Input Class Initialized
INFO - 2023-11-25 02:41:47 --> Language Class Initialized
INFO - 2023-11-25 02:41:47 --> Loader Class Initialized
INFO - 2023-11-25 02:41:47 --> Helper loaded: url_helper
INFO - 2023-11-25 02:41:47 --> Helper loaded: file_helper
INFO - 2023-11-25 02:41:47 --> Helper loaded: html_helper
INFO - 2023-11-25 02:41:47 --> Helper loaded: text_helper
INFO - 2023-11-25 02:41:47 --> Helper loaded: form_helper
INFO - 2023-11-25 02:41:47 --> Helper loaded: lang_helper
INFO - 2023-11-25 02:41:47 --> Helper loaded: security_helper
INFO - 2023-11-25 02:41:47 --> Helper loaded: cookie_helper
INFO - 2023-11-25 02:41:47 --> Database Driver Class Initialized
INFO - 2023-11-25 02:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 02:41:47 --> Parser Class Initialized
INFO - 2023-11-25 02:41:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-25 02:41:47 --> Pagination Class Initialized
INFO - 2023-11-25 02:41:47 --> Form Validation Class Initialized
INFO - 2023-11-25 02:41:47 --> Controller Class Initialized
INFO - 2023-11-25 02:41:47 --> Model Class Initialized
DEBUG - 2023-11-25 02:41:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-25 02:41:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-25 02:41:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-25 02:41:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-25 02:41:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-25 02:41:47 --> Model Class Initialized
INFO - 2023-11-25 02:41:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-25 02:41:47 --> Final output sent to browser
DEBUG - 2023-11-25 02:41:47 --> Total execution time: 0.0397
ERROR - 2023-11-25 02:42:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-25 02:42:26 --> Config Class Initialized
INFO - 2023-11-25 02:42:26 --> Hooks Class Initialized
DEBUG - 2023-11-25 02:42:26 --> UTF-8 Support Enabled
INFO - 2023-11-25 02:42:26 --> Utf8 Class Initialized
INFO - 2023-11-25 02:42:26 --> URI Class Initialized
INFO - 2023-11-25 02:42:26 --> Router Class Initialized
INFO - 2023-11-25 02:42:26 --> Output Class Initialized
INFO - 2023-11-25 02:42:26 --> Security Class Initialized
DEBUG - 2023-11-25 02:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 02:42:26 --> Input Class Initialized
INFO - 2023-11-25 02:42:26 --> Language Class Initialized
INFO - 2023-11-25 02:42:26 --> Loader Class Initialized
INFO - 2023-11-25 02:42:26 --> Helper loaded: url_helper
INFO - 2023-11-25 02:42:26 --> Helper loaded: file_helper
INFO - 2023-11-25 02:42:26 --> Helper loaded: html_helper
INFO - 2023-11-25 02:42:26 --> Helper loaded: text_helper
INFO - 2023-11-25 02:42:26 --> Helper loaded: form_helper
INFO - 2023-11-25 02:42:26 --> Helper loaded: lang_helper
INFO - 2023-11-25 02:42:26 --> Helper loaded: security_helper
INFO - 2023-11-25 02:42:26 --> Helper loaded: cookie_helper
INFO - 2023-11-25 02:42:26 --> Database Driver Class Initialized
INFO - 2023-11-25 02:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 02:42:26 --> Parser Class Initialized
INFO - 2023-11-25 02:42:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-25 02:42:26 --> Pagination Class Initialized
INFO - 2023-11-25 02:42:26 --> Form Validation Class Initialized
INFO - 2023-11-25 02:42:26 --> Controller Class Initialized
INFO - 2023-11-25 02:42:26 --> Model Class Initialized
DEBUG - 2023-11-25 02:42:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-25 02:42:26 --> Model Class Initialized
INFO - 2023-11-25 02:42:26 --> Final output sent to browser
DEBUG - 2023-11-25 02:42:26 --> Total execution time: 0.0236
ERROR - 2023-11-25 02:42:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-25 02:42:26 --> Config Class Initialized
INFO - 2023-11-25 02:42:26 --> Hooks Class Initialized
DEBUG - 2023-11-25 02:42:26 --> UTF-8 Support Enabled
INFO - 2023-11-25 02:42:26 --> Utf8 Class Initialized
INFO - 2023-11-25 02:42:26 --> URI Class Initialized
DEBUG - 2023-11-25 02:42:26 --> No URI present. Default controller set.
INFO - 2023-11-25 02:42:26 --> Router Class Initialized
INFO - 2023-11-25 02:42:26 --> Output Class Initialized
INFO - 2023-11-25 02:42:26 --> Security Class Initialized
DEBUG - 2023-11-25 02:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 02:42:26 --> Input Class Initialized
INFO - 2023-11-25 02:42:26 --> Language Class Initialized
INFO - 2023-11-25 02:42:26 --> Loader Class Initialized
INFO - 2023-11-25 02:42:26 --> Helper loaded: url_helper
INFO - 2023-11-25 02:42:26 --> Helper loaded: file_helper
INFO - 2023-11-25 02:42:26 --> Helper loaded: html_helper
INFO - 2023-11-25 02:42:26 --> Helper loaded: text_helper
INFO - 2023-11-25 02:42:26 --> Helper loaded: form_helper
INFO - 2023-11-25 02:42:26 --> Helper loaded: lang_helper
INFO - 2023-11-25 02:42:26 --> Helper loaded: security_helper
INFO - 2023-11-25 02:42:26 --> Helper loaded: cookie_helper
INFO - 2023-11-25 02:42:26 --> Database Driver Class Initialized
INFO - 2023-11-25 02:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 02:42:26 --> Parser Class Initialized
INFO - 2023-11-25 02:42:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-25 02:42:26 --> Pagination Class Initialized
INFO - 2023-11-25 02:42:26 --> Form Validation Class Initialized
INFO - 2023-11-25 02:42:26 --> Controller Class Initialized
INFO - 2023-11-25 02:42:26 --> Model Class Initialized
DEBUG - 2023-11-25 02:42:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-25 02:42:26 --> Model Class Initialized
DEBUG - 2023-11-25 02:42:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-25 02:42:26 --> Model Class Initialized
INFO - 2023-11-25 02:42:26 --> Model Class Initialized
INFO - 2023-11-25 02:42:26 --> Model Class Initialized
INFO - 2023-11-25 02:42:26 --> Model Class Initialized
DEBUG - 2023-11-25 02:42:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-25 02:42:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-25 02:42:26 --> Model Class Initialized
INFO - 2023-11-25 02:42:26 --> Model Class Initialized
INFO - 2023-11-25 02:42:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-25 02:42:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-25 02:42:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-25 02:42:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-25 02:42:26 --> Model Class Initialized
INFO - 2023-11-25 02:42:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-25 02:42:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-25 02:42:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-25 02:42:26 --> Final output sent to browser
DEBUG - 2023-11-25 02:42:26 --> Total execution time: 0.3924
ERROR - 2023-11-25 02:42:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-25 02:42:27 --> Config Class Initialized
INFO - 2023-11-25 02:42:27 --> Hooks Class Initialized
DEBUG - 2023-11-25 02:42:27 --> UTF-8 Support Enabled
INFO - 2023-11-25 02:42:27 --> Utf8 Class Initialized
INFO - 2023-11-25 02:42:27 --> URI Class Initialized
INFO - 2023-11-25 02:42:27 --> Router Class Initialized
INFO - 2023-11-25 02:42:27 --> Output Class Initialized
INFO - 2023-11-25 02:42:27 --> Security Class Initialized
DEBUG - 2023-11-25 02:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 02:42:27 --> Input Class Initialized
INFO - 2023-11-25 02:42:27 --> Language Class Initialized
INFO - 2023-11-25 02:42:27 --> Loader Class Initialized
INFO - 2023-11-25 02:42:27 --> Helper loaded: url_helper
INFO - 2023-11-25 02:42:27 --> Helper loaded: file_helper
INFO - 2023-11-25 02:42:27 --> Helper loaded: html_helper
INFO - 2023-11-25 02:42:27 --> Helper loaded: text_helper
INFO - 2023-11-25 02:42:27 --> Helper loaded: form_helper
INFO - 2023-11-25 02:42:27 --> Helper loaded: lang_helper
INFO - 2023-11-25 02:42:27 --> Helper loaded: security_helper
INFO - 2023-11-25 02:42:27 --> Helper loaded: cookie_helper
INFO - 2023-11-25 02:42:27 --> Database Driver Class Initialized
INFO - 2023-11-25 02:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 02:42:27 --> Parser Class Initialized
INFO - 2023-11-25 02:42:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-25 02:42:27 --> Pagination Class Initialized
INFO - 2023-11-25 02:42:27 --> Form Validation Class Initialized
INFO - 2023-11-25 02:42:27 --> Controller Class Initialized
DEBUG - 2023-11-25 02:42:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-25 02:42:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-25 02:42:27 --> Model Class Initialized
INFO - 2023-11-25 02:42:27 --> Final output sent to browser
DEBUG - 2023-11-25 02:42:27 --> Total execution time: 0.0130
ERROR - 2023-11-25 02:42:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-25 02:42:35 --> Config Class Initialized
INFO - 2023-11-25 02:42:35 --> Hooks Class Initialized
DEBUG - 2023-11-25 02:42:35 --> UTF-8 Support Enabled
INFO - 2023-11-25 02:42:35 --> Utf8 Class Initialized
INFO - 2023-11-25 02:42:35 --> URI Class Initialized
INFO - 2023-11-25 02:42:35 --> Router Class Initialized
INFO - 2023-11-25 02:42:35 --> Output Class Initialized
INFO - 2023-11-25 02:42:35 --> Security Class Initialized
DEBUG - 2023-11-25 02:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 02:42:35 --> Input Class Initialized
INFO - 2023-11-25 02:42:35 --> Language Class Initialized
INFO - 2023-11-25 02:42:35 --> Loader Class Initialized
INFO - 2023-11-25 02:42:35 --> Helper loaded: url_helper
INFO - 2023-11-25 02:42:35 --> Helper loaded: file_helper
INFO - 2023-11-25 02:42:35 --> Helper loaded: html_helper
INFO - 2023-11-25 02:42:35 --> Helper loaded: text_helper
INFO - 2023-11-25 02:42:35 --> Helper loaded: form_helper
INFO - 2023-11-25 02:42:35 --> Helper loaded: lang_helper
INFO - 2023-11-25 02:42:35 --> Helper loaded: security_helper
INFO - 2023-11-25 02:42:35 --> Helper loaded: cookie_helper
INFO - 2023-11-25 02:42:35 --> Database Driver Class Initialized
INFO - 2023-11-25 02:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 02:42:35 --> Parser Class Initialized
INFO - 2023-11-25 02:42:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-25 02:42:35 --> Pagination Class Initialized
INFO - 2023-11-25 02:42:35 --> Form Validation Class Initialized
INFO - 2023-11-25 02:42:35 --> Controller Class Initialized
INFO - 2023-11-25 02:42:35 --> Model Class Initialized
DEBUG - 2023-11-25 02:42:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-25 02:42:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-25 02:42:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-25 02:42:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-25 02:42:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-25 02:42:35 --> Model Class Initialized
INFO - 2023-11-25 02:42:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-25 02:42:35 --> Final output sent to browser
DEBUG - 2023-11-25 02:42:35 --> Total execution time: 0.0298
ERROR - 2023-11-25 02:42:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-25 02:42:35 --> Config Class Initialized
INFO - 2023-11-25 02:42:35 --> Hooks Class Initialized
DEBUG - 2023-11-25 02:42:35 --> UTF-8 Support Enabled
INFO - 2023-11-25 02:42:35 --> Utf8 Class Initialized
INFO - 2023-11-25 02:42:35 --> URI Class Initialized
INFO - 2023-11-25 02:42:35 --> Router Class Initialized
INFO - 2023-11-25 02:42:35 --> Output Class Initialized
INFO - 2023-11-25 02:42:35 --> Security Class Initialized
DEBUG - 2023-11-25 02:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 02:42:35 --> Input Class Initialized
INFO - 2023-11-25 02:42:35 --> Language Class Initialized
INFO - 2023-11-25 02:42:35 --> Loader Class Initialized
INFO - 2023-11-25 02:42:35 --> Helper loaded: url_helper
INFO - 2023-11-25 02:42:35 --> Helper loaded: file_helper
INFO - 2023-11-25 02:42:35 --> Helper loaded: html_helper
INFO - 2023-11-25 02:42:35 --> Helper loaded: text_helper
INFO - 2023-11-25 02:42:35 --> Helper loaded: form_helper
INFO - 2023-11-25 02:42:35 --> Helper loaded: lang_helper
INFO - 2023-11-25 02:42:35 --> Helper loaded: security_helper
INFO - 2023-11-25 02:42:35 --> Helper loaded: cookie_helper
INFO - 2023-11-25 02:42:35 --> Database Driver Class Initialized
INFO - 2023-11-25 02:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 02:42:35 --> Parser Class Initialized
INFO - 2023-11-25 02:42:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-25 02:42:35 --> Pagination Class Initialized
INFO - 2023-11-25 02:42:35 --> Form Validation Class Initialized
INFO - 2023-11-25 02:42:35 --> Controller Class Initialized
INFO - 2023-11-25 02:42:35 --> Model Class Initialized
DEBUG - 2023-11-25 02:42:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-25 02:42:35 --> Model Class Initialized
DEBUG - 2023-11-25 02:42:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-25 02:42:35 --> Model Class Initialized
INFO - 2023-11-25 02:42:35 --> Model Class Initialized
INFO - 2023-11-25 02:42:35 --> Model Class Initialized
INFO - 2023-11-25 02:42:35 --> Model Class Initialized
DEBUG - 2023-11-25 02:42:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-25 02:42:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-25 02:42:35 --> Model Class Initialized
INFO - 2023-11-25 02:42:35 --> Model Class Initialized
INFO - 2023-11-25 02:42:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-25 02:42:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-25 02:42:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-25 02:42:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-25 02:42:35 --> Model Class Initialized
INFO - 2023-11-25 02:42:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-25 02:42:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-25 02:42:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-25 02:42:35 --> Final output sent to browser
DEBUG - 2023-11-25 02:42:35 --> Total execution time: 0.3928
ERROR - 2023-11-25 03:37:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-25 03:37:54 --> Config Class Initialized
INFO - 2023-11-25 03:37:54 --> Hooks Class Initialized
DEBUG - 2023-11-25 03:37:54 --> UTF-8 Support Enabled
INFO - 2023-11-25 03:37:54 --> Utf8 Class Initialized
INFO - 2023-11-25 03:37:54 --> URI Class Initialized
INFO - 2023-11-25 03:37:54 --> Router Class Initialized
INFO - 2023-11-25 03:37:54 --> Output Class Initialized
INFO - 2023-11-25 03:37:54 --> Security Class Initialized
DEBUG - 2023-11-25 03:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 03:37:54 --> Input Class Initialized
INFO - 2023-11-25 03:37:54 --> Language Class Initialized
ERROR - 2023-11-25 03:37:54 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-11-25 06:23:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-25 06:23:49 --> Config Class Initialized
INFO - 2023-11-25 06:23:49 --> Hooks Class Initialized
DEBUG - 2023-11-25 06:23:49 --> UTF-8 Support Enabled
INFO - 2023-11-25 06:23:49 --> Utf8 Class Initialized
INFO - 2023-11-25 06:23:49 --> URI Class Initialized
DEBUG - 2023-11-25 06:23:49 --> No URI present. Default controller set.
INFO - 2023-11-25 06:23:49 --> Router Class Initialized
INFO - 2023-11-25 06:23:49 --> Output Class Initialized
INFO - 2023-11-25 06:23:49 --> Security Class Initialized
DEBUG - 2023-11-25 06:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 06:23:49 --> Input Class Initialized
INFO - 2023-11-25 06:23:49 --> Language Class Initialized
INFO - 2023-11-25 06:23:49 --> Loader Class Initialized
INFO - 2023-11-25 06:23:49 --> Helper loaded: url_helper
INFO - 2023-11-25 06:23:49 --> Helper loaded: file_helper
INFO - 2023-11-25 06:23:49 --> Helper loaded: html_helper
INFO - 2023-11-25 06:23:49 --> Helper loaded: text_helper
INFO - 2023-11-25 06:23:49 --> Helper loaded: form_helper
INFO - 2023-11-25 06:23:49 --> Helper loaded: lang_helper
INFO - 2023-11-25 06:23:49 --> Helper loaded: security_helper
INFO - 2023-11-25 06:23:49 --> Helper loaded: cookie_helper
INFO - 2023-11-25 06:23:49 --> Database Driver Class Initialized
INFO - 2023-11-25 06:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 06:23:49 --> Parser Class Initialized
INFO - 2023-11-25 06:23:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-25 06:23:49 --> Pagination Class Initialized
INFO - 2023-11-25 06:23:49 --> Form Validation Class Initialized
INFO - 2023-11-25 06:23:49 --> Controller Class Initialized
INFO - 2023-11-25 06:23:49 --> Model Class Initialized
DEBUG - 2023-11-25 06:23:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-25 06:23:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-25 06:23:50 --> Config Class Initialized
INFO - 2023-11-25 06:23:50 --> Hooks Class Initialized
DEBUG - 2023-11-25 06:23:50 --> UTF-8 Support Enabled
INFO - 2023-11-25 06:23:50 --> Utf8 Class Initialized
INFO - 2023-11-25 06:23:50 --> URI Class Initialized
INFO - 2023-11-25 06:23:50 --> Router Class Initialized
INFO - 2023-11-25 06:23:50 --> Output Class Initialized
INFO - 2023-11-25 06:23:50 --> Security Class Initialized
DEBUG - 2023-11-25 06:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 06:23:50 --> Input Class Initialized
INFO - 2023-11-25 06:23:50 --> Language Class Initialized
INFO - 2023-11-25 06:23:50 --> Loader Class Initialized
INFO - 2023-11-25 06:23:50 --> Helper loaded: url_helper
INFO - 2023-11-25 06:23:50 --> Helper loaded: file_helper
INFO - 2023-11-25 06:23:50 --> Helper loaded: html_helper
INFO - 2023-11-25 06:23:50 --> Helper loaded: text_helper
INFO - 2023-11-25 06:23:50 --> Helper loaded: form_helper
INFO - 2023-11-25 06:23:50 --> Helper loaded: lang_helper
INFO - 2023-11-25 06:23:50 --> Helper loaded: security_helper
INFO - 2023-11-25 06:23:50 --> Helper loaded: cookie_helper
INFO - 2023-11-25 06:23:50 --> Database Driver Class Initialized
INFO - 2023-11-25 06:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 06:23:50 --> Parser Class Initialized
INFO - 2023-11-25 06:23:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-25 06:23:50 --> Pagination Class Initialized
INFO - 2023-11-25 06:23:50 --> Form Validation Class Initialized
INFO - 2023-11-25 06:23:50 --> Controller Class Initialized
INFO - 2023-11-25 06:23:50 --> Model Class Initialized
DEBUG - 2023-11-25 06:23:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-25 06:23:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-25 06:23:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-25 06:23:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-25 06:23:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-25 06:23:50 --> Model Class Initialized
INFO - 2023-11-25 06:23:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-25 06:23:50 --> Final output sent to browser
DEBUG - 2023-11-25 06:23:50 --> Total execution time: 0.0328
ERROR - 2023-11-25 06:23:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-25 06:23:54 --> Config Class Initialized
INFO - 2023-11-25 06:23:54 --> Hooks Class Initialized
DEBUG - 2023-11-25 06:23:54 --> UTF-8 Support Enabled
INFO - 2023-11-25 06:23:54 --> Utf8 Class Initialized
INFO - 2023-11-25 06:23:54 --> URI Class Initialized
INFO - 2023-11-25 06:23:54 --> Router Class Initialized
INFO - 2023-11-25 06:23:54 --> Output Class Initialized
INFO - 2023-11-25 06:23:54 --> Security Class Initialized
DEBUG - 2023-11-25 06:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 06:23:54 --> Input Class Initialized
INFO - 2023-11-25 06:23:54 --> Language Class Initialized
INFO - 2023-11-25 06:23:54 --> Loader Class Initialized
INFO - 2023-11-25 06:23:54 --> Helper loaded: url_helper
INFO - 2023-11-25 06:23:54 --> Helper loaded: file_helper
INFO - 2023-11-25 06:23:54 --> Helper loaded: html_helper
INFO - 2023-11-25 06:23:54 --> Helper loaded: text_helper
INFO - 2023-11-25 06:23:54 --> Helper loaded: form_helper
INFO - 2023-11-25 06:23:54 --> Helper loaded: lang_helper
INFO - 2023-11-25 06:23:54 --> Helper loaded: security_helper
INFO - 2023-11-25 06:23:54 --> Helper loaded: cookie_helper
INFO - 2023-11-25 06:23:54 --> Database Driver Class Initialized
INFO - 2023-11-25 06:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 06:23:54 --> Parser Class Initialized
INFO - 2023-11-25 06:23:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-25 06:23:54 --> Pagination Class Initialized
INFO - 2023-11-25 06:23:54 --> Form Validation Class Initialized
INFO - 2023-11-25 06:23:54 --> Controller Class Initialized
INFO - 2023-11-25 06:23:54 --> Model Class Initialized
DEBUG - 2023-11-25 06:23:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-25 06:23:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-25 06:23:54 --> Config Class Initialized
INFO - 2023-11-25 06:23:54 --> Hooks Class Initialized
DEBUG - 2023-11-25 06:23:54 --> UTF-8 Support Enabled
INFO - 2023-11-25 06:23:54 --> Utf8 Class Initialized
INFO - 2023-11-25 06:23:54 --> URI Class Initialized
INFO - 2023-11-25 06:23:54 --> Router Class Initialized
INFO - 2023-11-25 06:23:54 --> Output Class Initialized
INFO - 2023-11-25 06:23:54 --> Security Class Initialized
DEBUG - 2023-11-25 06:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 06:23:54 --> Input Class Initialized
INFO - 2023-11-25 06:23:54 --> Language Class Initialized
INFO - 2023-11-25 06:23:54 --> Loader Class Initialized
INFO - 2023-11-25 06:23:54 --> Helper loaded: url_helper
INFO - 2023-11-25 06:23:54 --> Helper loaded: file_helper
INFO - 2023-11-25 06:23:54 --> Helper loaded: html_helper
INFO - 2023-11-25 06:23:54 --> Helper loaded: text_helper
INFO - 2023-11-25 06:23:54 --> Helper loaded: form_helper
INFO - 2023-11-25 06:23:54 --> Helper loaded: lang_helper
INFO - 2023-11-25 06:23:54 --> Helper loaded: security_helper
INFO - 2023-11-25 06:23:54 --> Helper loaded: cookie_helper
INFO - 2023-11-25 06:23:54 --> Database Driver Class Initialized
INFO - 2023-11-25 06:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 06:23:54 --> Parser Class Initialized
INFO - 2023-11-25 06:23:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-25 06:23:54 --> Pagination Class Initialized
INFO - 2023-11-25 06:23:54 --> Form Validation Class Initialized
INFO - 2023-11-25 06:23:54 --> Controller Class Initialized
INFO - 2023-11-25 06:23:54 --> Model Class Initialized
DEBUG - 2023-11-25 06:23:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-25 06:23:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-25 06:23:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-25 06:23:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-25 06:23:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-25 06:23:54 --> Model Class Initialized
INFO - 2023-11-25 06:23:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-25 06:23:54 --> Final output sent to browser
DEBUG - 2023-11-25 06:23:54 --> Total execution time: 0.0291
ERROR - 2023-11-25 07:51:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-25 07:51:41 --> Config Class Initialized
INFO - 2023-11-25 07:51:41 --> Hooks Class Initialized
DEBUG - 2023-11-25 07:51:41 --> UTF-8 Support Enabled
INFO - 2023-11-25 07:51:41 --> Utf8 Class Initialized
INFO - 2023-11-25 07:51:41 --> URI Class Initialized
DEBUG - 2023-11-25 07:51:41 --> No URI present. Default controller set.
INFO - 2023-11-25 07:51:41 --> Router Class Initialized
INFO - 2023-11-25 07:51:41 --> Output Class Initialized
INFO - 2023-11-25 07:51:41 --> Security Class Initialized
DEBUG - 2023-11-25 07:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 07:51:41 --> Input Class Initialized
INFO - 2023-11-25 07:51:41 --> Language Class Initialized
INFO - 2023-11-25 07:51:41 --> Loader Class Initialized
INFO - 2023-11-25 07:51:41 --> Helper loaded: url_helper
INFO - 2023-11-25 07:51:41 --> Helper loaded: file_helper
INFO - 2023-11-25 07:51:41 --> Helper loaded: html_helper
INFO - 2023-11-25 07:51:41 --> Helper loaded: text_helper
INFO - 2023-11-25 07:51:41 --> Helper loaded: form_helper
INFO - 2023-11-25 07:51:41 --> Helper loaded: lang_helper
INFO - 2023-11-25 07:51:41 --> Helper loaded: security_helper
INFO - 2023-11-25 07:51:41 --> Helper loaded: cookie_helper
INFO - 2023-11-25 07:51:41 --> Database Driver Class Initialized
INFO - 2023-11-25 07:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 07:51:41 --> Parser Class Initialized
INFO - 2023-11-25 07:51:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-25 07:51:41 --> Pagination Class Initialized
INFO - 2023-11-25 07:51:41 --> Form Validation Class Initialized
INFO - 2023-11-25 07:51:41 --> Controller Class Initialized
INFO - 2023-11-25 07:51:41 --> Model Class Initialized
DEBUG - 2023-11-25 07:51:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-25 07:51:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-25 07:51:41 --> Config Class Initialized
INFO - 2023-11-25 07:51:41 --> Hooks Class Initialized
DEBUG - 2023-11-25 07:51:41 --> UTF-8 Support Enabled
INFO - 2023-11-25 07:51:41 --> Utf8 Class Initialized
INFO - 2023-11-25 07:51:41 --> URI Class Initialized
INFO - 2023-11-25 07:51:41 --> Router Class Initialized
INFO - 2023-11-25 07:51:41 --> Output Class Initialized
INFO - 2023-11-25 07:51:41 --> Security Class Initialized
DEBUG - 2023-11-25 07:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 07:51:41 --> Input Class Initialized
INFO - 2023-11-25 07:51:41 --> Language Class Initialized
INFO - 2023-11-25 07:51:41 --> Loader Class Initialized
INFO - 2023-11-25 07:51:41 --> Helper loaded: url_helper
INFO - 2023-11-25 07:51:41 --> Helper loaded: file_helper
INFO - 2023-11-25 07:51:41 --> Helper loaded: html_helper
INFO - 2023-11-25 07:51:41 --> Helper loaded: text_helper
INFO - 2023-11-25 07:51:41 --> Helper loaded: form_helper
INFO - 2023-11-25 07:51:41 --> Helper loaded: lang_helper
INFO - 2023-11-25 07:51:41 --> Helper loaded: security_helper
INFO - 2023-11-25 07:51:41 --> Helper loaded: cookie_helper
INFO - 2023-11-25 07:51:41 --> Database Driver Class Initialized
INFO - 2023-11-25 07:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 07:51:41 --> Parser Class Initialized
INFO - 2023-11-25 07:51:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-25 07:51:41 --> Pagination Class Initialized
INFO - 2023-11-25 07:51:41 --> Form Validation Class Initialized
INFO - 2023-11-25 07:51:41 --> Controller Class Initialized
INFO - 2023-11-25 07:51:41 --> Model Class Initialized
DEBUG - 2023-11-25 07:51:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-25 07:51:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-25 07:51:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-25 07:51:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-25 07:51:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-25 07:51:41 --> Model Class Initialized
INFO - 2023-11-25 07:51:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-25 07:51:41 --> Final output sent to browser
DEBUG - 2023-11-25 07:51:41 --> Total execution time: 0.0361
ERROR - 2023-11-25 17:41:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-25 17:41:23 --> Config Class Initialized
INFO - 2023-11-25 17:41:23 --> Hooks Class Initialized
DEBUG - 2023-11-25 17:41:23 --> UTF-8 Support Enabled
INFO - 2023-11-25 17:41:23 --> Utf8 Class Initialized
INFO - 2023-11-25 17:41:23 --> URI Class Initialized
DEBUG - 2023-11-25 17:41:23 --> No URI present. Default controller set.
INFO - 2023-11-25 17:41:23 --> Router Class Initialized
INFO - 2023-11-25 17:41:23 --> Output Class Initialized
INFO - 2023-11-25 17:41:23 --> Security Class Initialized
DEBUG - 2023-11-25 17:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 17:41:23 --> Input Class Initialized
INFO - 2023-11-25 17:41:23 --> Language Class Initialized
INFO - 2023-11-25 17:41:23 --> Loader Class Initialized
INFO - 2023-11-25 17:41:23 --> Helper loaded: url_helper
INFO - 2023-11-25 17:41:23 --> Helper loaded: file_helper
INFO - 2023-11-25 17:41:23 --> Helper loaded: html_helper
INFO - 2023-11-25 17:41:23 --> Helper loaded: text_helper
INFO - 2023-11-25 17:41:23 --> Helper loaded: form_helper
INFO - 2023-11-25 17:41:23 --> Helper loaded: lang_helper
INFO - 2023-11-25 17:41:23 --> Helper loaded: security_helper
INFO - 2023-11-25 17:41:23 --> Helper loaded: cookie_helper
INFO - 2023-11-25 17:41:23 --> Database Driver Class Initialized
INFO - 2023-11-25 17:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 17:41:23 --> Parser Class Initialized
INFO - 2023-11-25 17:41:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-25 17:41:23 --> Pagination Class Initialized
INFO - 2023-11-25 17:41:23 --> Form Validation Class Initialized
INFO - 2023-11-25 17:41:23 --> Controller Class Initialized
INFO - 2023-11-25 17:41:23 --> Model Class Initialized
DEBUG - 2023-11-25 17:41:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-25 17:41:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-25 17:41:24 --> Config Class Initialized
INFO - 2023-11-25 17:41:24 --> Hooks Class Initialized
DEBUG - 2023-11-25 17:41:24 --> UTF-8 Support Enabled
INFO - 2023-11-25 17:41:24 --> Utf8 Class Initialized
INFO - 2023-11-25 17:41:24 --> URI Class Initialized
INFO - 2023-11-25 17:41:24 --> Router Class Initialized
INFO - 2023-11-25 17:41:24 --> Output Class Initialized
INFO - 2023-11-25 17:41:24 --> Security Class Initialized
DEBUG - 2023-11-25 17:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 17:41:24 --> Input Class Initialized
INFO - 2023-11-25 17:41:24 --> Language Class Initialized
INFO - 2023-11-25 17:41:24 --> Loader Class Initialized
INFO - 2023-11-25 17:41:24 --> Helper loaded: url_helper
INFO - 2023-11-25 17:41:24 --> Helper loaded: file_helper
INFO - 2023-11-25 17:41:24 --> Helper loaded: html_helper
INFO - 2023-11-25 17:41:24 --> Helper loaded: text_helper
INFO - 2023-11-25 17:41:24 --> Helper loaded: form_helper
INFO - 2023-11-25 17:41:24 --> Helper loaded: lang_helper
INFO - 2023-11-25 17:41:24 --> Helper loaded: security_helper
INFO - 2023-11-25 17:41:24 --> Helper loaded: cookie_helper
INFO - 2023-11-25 17:41:24 --> Database Driver Class Initialized
INFO - 2023-11-25 17:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 17:41:24 --> Parser Class Initialized
INFO - 2023-11-25 17:41:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-25 17:41:24 --> Pagination Class Initialized
INFO - 2023-11-25 17:41:24 --> Form Validation Class Initialized
INFO - 2023-11-25 17:41:24 --> Controller Class Initialized
INFO - 2023-11-25 17:41:24 --> Model Class Initialized
DEBUG - 2023-11-25 17:41:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-25 17:41:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-25 17:41:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-25 17:41:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-25 17:41:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-25 17:41:24 --> Model Class Initialized
INFO - 2023-11-25 17:41:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-25 17:41:24 --> Final output sent to browser
DEBUG - 2023-11-25 17:41:24 --> Total execution time: 0.0336
ERROR - 2023-11-25 18:08:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-25 18:08:01 --> Config Class Initialized
INFO - 2023-11-25 18:08:01 --> Hooks Class Initialized
DEBUG - 2023-11-25 18:08:01 --> UTF-8 Support Enabled
INFO - 2023-11-25 18:08:01 --> Utf8 Class Initialized
INFO - 2023-11-25 18:08:01 --> URI Class Initialized
INFO - 2023-11-25 18:08:01 --> Router Class Initialized
INFO - 2023-11-25 18:08:01 --> Output Class Initialized
INFO - 2023-11-25 18:08:01 --> Security Class Initialized
DEBUG - 2023-11-25 18:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 18:08:01 --> Input Class Initialized
INFO - 2023-11-25 18:08:01 --> Language Class Initialized
ERROR - 2023-11-25 18:08:01 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-11-25 22:18:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-25 22:18:28 --> Config Class Initialized
INFO - 2023-11-25 22:18:28 --> Hooks Class Initialized
DEBUG - 2023-11-25 22:18:28 --> UTF-8 Support Enabled
INFO - 2023-11-25 22:18:28 --> Utf8 Class Initialized
INFO - 2023-11-25 22:18:28 --> URI Class Initialized
DEBUG - 2023-11-25 22:18:28 --> No URI present. Default controller set.
INFO - 2023-11-25 22:18:28 --> Router Class Initialized
INFO - 2023-11-25 22:18:28 --> Output Class Initialized
INFO - 2023-11-25 22:18:28 --> Security Class Initialized
DEBUG - 2023-11-25 22:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 22:18:28 --> Input Class Initialized
INFO - 2023-11-25 22:18:28 --> Language Class Initialized
INFO - 2023-11-25 22:18:28 --> Loader Class Initialized
INFO - 2023-11-25 22:18:28 --> Helper loaded: url_helper
INFO - 2023-11-25 22:18:28 --> Helper loaded: file_helper
INFO - 2023-11-25 22:18:28 --> Helper loaded: html_helper
INFO - 2023-11-25 22:18:28 --> Helper loaded: text_helper
INFO - 2023-11-25 22:18:28 --> Helper loaded: form_helper
INFO - 2023-11-25 22:18:28 --> Helper loaded: lang_helper
INFO - 2023-11-25 22:18:28 --> Helper loaded: security_helper
INFO - 2023-11-25 22:18:28 --> Helper loaded: cookie_helper
INFO - 2023-11-25 22:18:28 --> Database Driver Class Initialized
INFO - 2023-11-25 22:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 22:18:28 --> Parser Class Initialized
INFO - 2023-11-25 22:18:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-25 22:18:28 --> Pagination Class Initialized
INFO - 2023-11-25 22:18:28 --> Form Validation Class Initialized
INFO - 2023-11-25 22:18:28 --> Controller Class Initialized
INFO - 2023-11-25 22:18:28 --> Model Class Initialized
DEBUG - 2023-11-25 22:18:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-25 22:18:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-25 22:18:29 --> Config Class Initialized
INFO - 2023-11-25 22:18:29 --> Hooks Class Initialized
DEBUG - 2023-11-25 22:18:29 --> UTF-8 Support Enabled
INFO - 2023-11-25 22:18:29 --> Utf8 Class Initialized
INFO - 2023-11-25 22:18:29 --> URI Class Initialized
INFO - 2023-11-25 22:18:29 --> Router Class Initialized
INFO - 2023-11-25 22:18:29 --> Output Class Initialized
INFO - 2023-11-25 22:18:29 --> Security Class Initialized
DEBUG - 2023-11-25 22:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-25 22:18:29 --> Input Class Initialized
INFO - 2023-11-25 22:18:29 --> Language Class Initialized
INFO - 2023-11-25 22:18:29 --> Loader Class Initialized
INFO - 2023-11-25 22:18:29 --> Helper loaded: url_helper
INFO - 2023-11-25 22:18:29 --> Helper loaded: file_helper
INFO - 2023-11-25 22:18:29 --> Helper loaded: html_helper
INFO - 2023-11-25 22:18:29 --> Helper loaded: text_helper
INFO - 2023-11-25 22:18:29 --> Helper loaded: form_helper
INFO - 2023-11-25 22:18:29 --> Helper loaded: lang_helper
INFO - 2023-11-25 22:18:29 --> Helper loaded: security_helper
INFO - 2023-11-25 22:18:29 --> Helper loaded: cookie_helper
INFO - 2023-11-25 22:18:29 --> Database Driver Class Initialized
INFO - 2023-11-25 22:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-25 22:18:29 --> Parser Class Initialized
INFO - 2023-11-25 22:18:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-25 22:18:29 --> Pagination Class Initialized
INFO - 2023-11-25 22:18:29 --> Form Validation Class Initialized
INFO - 2023-11-25 22:18:29 --> Controller Class Initialized
INFO - 2023-11-25 22:18:29 --> Model Class Initialized
DEBUG - 2023-11-25 22:18:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-25 22:18:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-25 22:18:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-25 22:18:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-25 22:18:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-25 22:18:29 --> Model Class Initialized
INFO - 2023-11-25 22:18:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-25 22:18:29 --> Final output sent to browser
DEBUG - 2023-11-25 22:18:29 --> Total execution time: 0.0323
