<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-29 01:54:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 01:54:55 --> Config Class Initialized
INFO - 2024-02-29 01:54:55 --> Hooks Class Initialized
DEBUG - 2024-02-29 01:54:55 --> UTF-8 Support Enabled
INFO - 2024-02-29 01:54:55 --> Utf8 Class Initialized
INFO - 2024-02-29 01:54:55 --> URI Class Initialized
DEBUG - 2024-02-29 01:54:55 --> No URI present. Default controller set.
INFO - 2024-02-29 01:54:55 --> Router Class Initialized
INFO - 2024-02-29 01:54:55 --> Output Class Initialized
INFO - 2024-02-29 01:54:55 --> Security Class Initialized
DEBUG - 2024-02-29 01:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 01:54:55 --> Input Class Initialized
INFO - 2024-02-29 01:54:55 --> Language Class Initialized
INFO - 2024-02-29 01:54:55 --> Loader Class Initialized
INFO - 2024-02-29 01:54:55 --> Helper loaded: url_helper
INFO - 2024-02-29 01:54:55 --> Helper loaded: file_helper
INFO - 2024-02-29 01:54:55 --> Helper loaded: html_helper
INFO - 2024-02-29 01:54:55 --> Helper loaded: text_helper
INFO - 2024-02-29 01:54:55 --> Helper loaded: form_helper
INFO - 2024-02-29 01:54:55 --> Helper loaded: lang_helper
INFO - 2024-02-29 01:54:55 --> Helper loaded: security_helper
INFO - 2024-02-29 01:54:55 --> Helper loaded: cookie_helper
INFO - 2024-02-29 01:54:55 --> Database Driver Class Initialized
INFO - 2024-02-29 01:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 01:54:55 --> Parser Class Initialized
INFO - 2024-02-29 01:54:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 01:54:55 --> Pagination Class Initialized
INFO - 2024-02-29 01:54:55 --> Form Validation Class Initialized
INFO - 2024-02-29 01:54:55 --> Controller Class Initialized
INFO - 2024-02-29 01:54:55 --> Model Class Initialized
DEBUG - 2024-02-29 01:54:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-29 01:54:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 01:54:56 --> Config Class Initialized
INFO - 2024-02-29 01:54:56 --> Hooks Class Initialized
DEBUG - 2024-02-29 01:54:56 --> UTF-8 Support Enabled
INFO - 2024-02-29 01:54:56 --> Utf8 Class Initialized
INFO - 2024-02-29 01:54:56 --> URI Class Initialized
INFO - 2024-02-29 01:54:56 --> Router Class Initialized
INFO - 2024-02-29 01:54:56 --> Output Class Initialized
INFO - 2024-02-29 01:54:56 --> Security Class Initialized
DEBUG - 2024-02-29 01:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 01:54:56 --> Input Class Initialized
INFO - 2024-02-29 01:54:56 --> Language Class Initialized
INFO - 2024-02-29 01:54:56 --> Loader Class Initialized
INFO - 2024-02-29 01:54:56 --> Helper loaded: url_helper
INFO - 2024-02-29 01:54:56 --> Helper loaded: file_helper
INFO - 2024-02-29 01:54:56 --> Helper loaded: html_helper
INFO - 2024-02-29 01:54:56 --> Helper loaded: text_helper
INFO - 2024-02-29 01:54:56 --> Helper loaded: form_helper
INFO - 2024-02-29 01:54:56 --> Helper loaded: lang_helper
INFO - 2024-02-29 01:54:56 --> Helper loaded: security_helper
INFO - 2024-02-29 01:54:56 --> Helper loaded: cookie_helper
INFO - 2024-02-29 01:54:56 --> Database Driver Class Initialized
INFO - 2024-02-29 01:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 01:54:56 --> Parser Class Initialized
INFO - 2024-02-29 01:54:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 01:54:56 --> Pagination Class Initialized
INFO - 2024-02-29 01:54:56 --> Form Validation Class Initialized
INFO - 2024-02-29 01:54:56 --> Controller Class Initialized
INFO - 2024-02-29 01:54:56 --> Model Class Initialized
DEBUG - 2024-02-29 01:54:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:54:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-29 01:54:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:54:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 01:54:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 01:54:56 --> Model Class Initialized
INFO - 2024-02-29 01:54:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 01:54:56 --> Final output sent to browser
DEBUG - 2024-02-29 01:54:56 --> Total execution time: 0.0351
ERROR - 2024-02-29 01:55:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 01:55:30 --> Config Class Initialized
INFO - 2024-02-29 01:55:30 --> Hooks Class Initialized
DEBUG - 2024-02-29 01:55:30 --> UTF-8 Support Enabled
INFO - 2024-02-29 01:55:30 --> Utf8 Class Initialized
INFO - 2024-02-29 01:55:30 --> URI Class Initialized
INFO - 2024-02-29 01:55:30 --> Router Class Initialized
INFO - 2024-02-29 01:55:30 --> Output Class Initialized
INFO - 2024-02-29 01:55:30 --> Security Class Initialized
DEBUG - 2024-02-29 01:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 01:55:30 --> Input Class Initialized
INFO - 2024-02-29 01:55:30 --> Language Class Initialized
INFO - 2024-02-29 01:55:30 --> Loader Class Initialized
INFO - 2024-02-29 01:55:30 --> Helper loaded: url_helper
INFO - 2024-02-29 01:55:30 --> Helper loaded: file_helper
INFO - 2024-02-29 01:55:30 --> Helper loaded: html_helper
INFO - 2024-02-29 01:55:30 --> Helper loaded: text_helper
INFO - 2024-02-29 01:55:30 --> Helper loaded: form_helper
INFO - 2024-02-29 01:55:30 --> Helper loaded: lang_helper
INFO - 2024-02-29 01:55:30 --> Helper loaded: security_helper
INFO - 2024-02-29 01:55:30 --> Helper loaded: cookie_helper
INFO - 2024-02-29 01:55:30 --> Database Driver Class Initialized
INFO - 2024-02-29 01:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 01:55:30 --> Parser Class Initialized
INFO - 2024-02-29 01:55:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 01:55:30 --> Pagination Class Initialized
INFO - 2024-02-29 01:55:30 --> Form Validation Class Initialized
INFO - 2024-02-29 01:55:30 --> Controller Class Initialized
INFO - 2024-02-29 01:55:30 --> Model Class Initialized
DEBUG - 2024-02-29 01:55:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:55:30 --> Model Class Initialized
INFO - 2024-02-29 01:55:30 --> Final output sent to browser
DEBUG - 2024-02-29 01:55:30 --> Total execution time: 0.0215
ERROR - 2024-02-29 01:55:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 01:55:31 --> Config Class Initialized
INFO - 2024-02-29 01:55:31 --> Hooks Class Initialized
DEBUG - 2024-02-29 01:55:31 --> UTF-8 Support Enabled
INFO - 2024-02-29 01:55:31 --> Utf8 Class Initialized
INFO - 2024-02-29 01:55:31 --> URI Class Initialized
DEBUG - 2024-02-29 01:55:31 --> No URI present. Default controller set.
INFO - 2024-02-29 01:55:31 --> Router Class Initialized
INFO - 2024-02-29 01:55:31 --> Output Class Initialized
INFO - 2024-02-29 01:55:31 --> Security Class Initialized
DEBUG - 2024-02-29 01:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 01:55:31 --> Input Class Initialized
INFO - 2024-02-29 01:55:31 --> Language Class Initialized
INFO - 2024-02-29 01:55:31 --> Loader Class Initialized
INFO - 2024-02-29 01:55:31 --> Helper loaded: url_helper
INFO - 2024-02-29 01:55:31 --> Helper loaded: file_helper
INFO - 2024-02-29 01:55:31 --> Helper loaded: html_helper
INFO - 2024-02-29 01:55:31 --> Helper loaded: text_helper
INFO - 2024-02-29 01:55:31 --> Helper loaded: form_helper
INFO - 2024-02-29 01:55:31 --> Helper loaded: lang_helper
INFO - 2024-02-29 01:55:31 --> Helper loaded: security_helper
INFO - 2024-02-29 01:55:31 --> Helper loaded: cookie_helper
INFO - 2024-02-29 01:55:31 --> Database Driver Class Initialized
INFO - 2024-02-29 01:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 01:55:31 --> Parser Class Initialized
INFO - 2024-02-29 01:55:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 01:55:31 --> Pagination Class Initialized
INFO - 2024-02-29 01:55:31 --> Form Validation Class Initialized
INFO - 2024-02-29 01:55:31 --> Controller Class Initialized
INFO - 2024-02-29 01:55:31 --> Model Class Initialized
DEBUG - 2024-02-29 01:55:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:55:31 --> Model Class Initialized
DEBUG - 2024-02-29 01:55:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:55:31 --> Model Class Initialized
INFO - 2024-02-29 01:55:31 --> Model Class Initialized
INFO - 2024-02-29 01:55:31 --> Model Class Initialized
INFO - 2024-02-29 01:55:31 --> Model Class Initialized
DEBUG - 2024-02-29 01:55:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 01:55:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:55:31 --> Model Class Initialized
INFO - 2024-02-29 01:55:31 --> Model Class Initialized
INFO - 2024-02-29 01:55:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 01:55:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:55:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 01:55:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 01:55:31 --> Model Class Initialized
INFO - 2024-02-29 01:55:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 01:55:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 01:55:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 01:55:31 --> Final output sent to browser
DEBUG - 2024-02-29 01:55:31 --> Total execution time: 0.2470
ERROR - 2024-02-29 01:55:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 01:55:44 --> Config Class Initialized
INFO - 2024-02-29 01:55:44 --> Hooks Class Initialized
DEBUG - 2024-02-29 01:55:44 --> UTF-8 Support Enabled
INFO - 2024-02-29 01:55:44 --> Utf8 Class Initialized
INFO - 2024-02-29 01:55:44 --> URI Class Initialized
INFO - 2024-02-29 01:55:44 --> Router Class Initialized
INFO - 2024-02-29 01:55:44 --> Output Class Initialized
INFO - 2024-02-29 01:55:44 --> Security Class Initialized
DEBUG - 2024-02-29 01:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 01:55:44 --> Input Class Initialized
INFO - 2024-02-29 01:55:44 --> Language Class Initialized
INFO - 2024-02-29 01:55:44 --> Loader Class Initialized
INFO - 2024-02-29 01:55:44 --> Helper loaded: url_helper
INFO - 2024-02-29 01:55:44 --> Helper loaded: file_helper
INFO - 2024-02-29 01:55:44 --> Helper loaded: html_helper
INFO - 2024-02-29 01:55:44 --> Helper loaded: text_helper
INFO - 2024-02-29 01:55:44 --> Helper loaded: form_helper
INFO - 2024-02-29 01:55:44 --> Helper loaded: lang_helper
INFO - 2024-02-29 01:55:44 --> Helper loaded: security_helper
INFO - 2024-02-29 01:55:44 --> Helper loaded: cookie_helper
INFO - 2024-02-29 01:55:44 --> Database Driver Class Initialized
INFO - 2024-02-29 01:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 01:55:44 --> Parser Class Initialized
INFO - 2024-02-29 01:55:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 01:55:44 --> Pagination Class Initialized
INFO - 2024-02-29 01:55:44 --> Form Validation Class Initialized
INFO - 2024-02-29 01:55:44 --> Controller Class Initialized
DEBUG - 2024-02-29 01:55:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 01:55:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:55:44 --> Model Class Initialized
DEBUG - 2024-02-29 01:55:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:55:44 --> Model Class Initialized
DEBUG - 2024-02-29 01:55:44 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:55:44 --> Model Class Initialized
INFO - 2024-02-29 01:55:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-29 01:55:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:55:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 01:55:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 01:55:44 --> Model Class Initialized
INFO - 2024-02-29 01:55:44 --> Model Class Initialized
INFO - 2024-02-29 01:55:44 --> Model Class Initialized
INFO - 2024-02-29 01:55:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 01:55:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 01:55:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 01:55:44 --> Final output sent to browser
DEBUG - 2024-02-29 01:55:44 --> Total execution time: 0.1536
ERROR - 2024-02-29 01:55:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 01:55:45 --> Config Class Initialized
INFO - 2024-02-29 01:55:45 --> Hooks Class Initialized
DEBUG - 2024-02-29 01:55:45 --> UTF-8 Support Enabled
INFO - 2024-02-29 01:55:45 --> Utf8 Class Initialized
INFO - 2024-02-29 01:55:45 --> URI Class Initialized
INFO - 2024-02-29 01:55:45 --> Router Class Initialized
INFO - 2024-02-29 01:55:45 --> Output Class Initialized
INFO - 2024-02-29 01:55:45 --> Security Class Initialized
DEBUG - 2024-02-29 01:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 01:55:45 --> Input Class Initialized
INFO - 2024-02-29 01:55:45 --> Language Class Initialized
INFO - 2024-02-29 01:55:45 --> Loader Class Initialized
INFO - 2024-02-29 01:55:45 --> Helper loaded: url_helper
INFO - 2024-02-29 01:55:45 --> Helper loaded: file_helper
INFO - 2024-02-29 01:55:45 --> Helper loaded: html_helper
INFO - 2024-02-29 01:55:45 --> Helper loaded: text_helper
INFO - 2024-02-29 01:55:45 --> Helper loaded: form_helper
INFO - 2024-02-29 01:55:45 --> Helper loaded: lang_helper
INFO - 2024-02-29 01:55:45 --> Helper loaded: security_helper
INFO - 2024-02-29 01:55:45 --> Helper loaded: cookie_helper
INFO - 2024-02-29 01:55:45 --> Database Driver Class Initialized
INFO - 2024-02-29 01:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 01:55:45 --> Parser Class Initialized
INFO - 2024-02-29 01:55:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 01:55:45 --> Pagination Class Initialized
INFO - 2024-02-29 01:55:45 --> Form Validation Class Initialized
INFO - 2024-02-29 01:55:45 --> Controller Class Initialized
DEBUG - 2024-02-29 01:55:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 01:55:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:55:45 --> Model Class Initialized
DEBUG - 2024-02-29 01:55:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:55:45 --> Model Class Initialized
INFO - 2024-02-29 01:55:45 --> Final output sent to browser
DEBUG - 2024-02-29 01:55:45 --> Total execution time: 0.0222
ERROR - 2024-02-29 01:55:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 01:55:51 --> Config Class Initialized
INFO - 2024-02-29 01:55:51 --> Hooks Class Initialized
DEBUG - 2024-02-29 01:55:51 --> UTF-8 Support Enabled
INFO - 2024-02-29 01:55:51 --> Utf8 Class Initialized
INFO - 2024-02-29 01:55:51 --> URI Class Initialized
INFO - 2024-02-29 01:55:51 --> Router Class Initialized
INFO - 2024-02-29 01:55:51 --> Output Class Initialized
INFO - 2024-02-29 01:55:51 --> Security Class Initialized
DEBUG - 2024-02-29 01:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 01:55:51 --> Input Class Initialized
INFO - 2024-02-29 01:55:51 --> Language Class Initialized
INFO - 2024-02-29 01:55:51 --> Loader Class Initialized
INFO - 2024-02-29 01:55:51 --> Helper loaded: url_helper
INFO - 2024-02-29 01:55:51 --> Helper loaded: file_helper
INFO - 2024-02-29 01:55:51 --> Helper loaded: html_helper
INFO - 2024-02-29 01:55:51 --> Helper loaded: text_helper
INFO - 2024-02-29 01:55:51 --> Helper loaded: form_helper
INFO - 2024-02-29 01:55:51 --> Helper loaded: lang_helper
INFO - 2024-02-29 01:55:51 --> Helper loaded: security_helper
INFO - 2024-02-29 01:55:51 --> Helper loaded: cookie_helper
INFO - 2024-02-29 01:55:51 --> Database Driver Class Initialized
INFO - 2024-02-29 01:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 01:55:51 --> Parser Class Initialized
INFO - 2024-02-29 01:55:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 01:55:51 --> Pagination Class Initialized
INFO - 2024-02-29 01:55:51 --> Form Validation Class Initialized
INFO - 2024-02-29 01:55:51 --> Controller Class Initialized
DEBUG - 2024-02-29 01:55:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 01:55:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:55:51 --> Model Class Initialized
DEBUG - 2024-02-29 01:55:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:55:51 --> Model Class Initialized
INFO - 2024-02-29 01:55:51 --> Final output sent to browser
DEBUG - 2024-02-29 01:55:51 --> Total execution time: 0.0358
ERROR - 2024-02-29 01:56:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 01:56:45 --> Config Class Initialized
INFO - 2024-02-29 01:56:45 --> Hooks Class Initialized
DEBUG - 2024-02-29 01:56:45 --> UTF-8 Support Enabled
INFO - 2024-02-29 01:56:45 --> Utf8 Class Initialized
INFO - 2024-02-29 01:56:45 --> URI Class Initialized
DEBUG - 2024-02-29 01:56:45 --> No URI present. Default controller set.
INFO - 2024-02-29 01:56:45 --> Router Class Initialized
INFO - 2024-02-29 01:56:45 --> Output Class Initialized
INFO - 2024-02-29 01:56:45 --> Security Class Initialized
DEBUG - 2024-02-29 01:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 01:56:45 --> Input Class Initialized
INFO - 2024-02-29 01:56:45 --> Language Class Initialized
INFO - 2024-02-29 01:56:45 --> Loader Class Initialized
INFO - 2024-02-29 01:56:45 --> Helper loaded: url_helper
INFO - 2024-02-29 01:56:45 --> Helper loaded: file_helper
INFO - 2024-02-29 01:56:45 --> Helper loaded: html_helper
INFO - 2024-02-29 01:56:45 --> Helper loaded: text_helper
INFO - 2024-02-29 01:56:45 --> Helper loaded: form_helper
INFO - 2024-02-29 01:56:45 --> Helper loaded: lang_helper
INFO - 2024-02-29 01:56:45 --> Helper loaded: security_helper
INFO - 2024-02-29 01:56:45 --> Helper loaded: cookie_helper
INFO - 2024-02-29 01:56:45 --> Database Driver Class Initialized
INFO - 2024-02-29 01:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 01:56:45 --> Parser Class Initialized
INFO - 2024-02-29 01:56:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 01:56:45 --> Pagination Class Initialized
INFO - 2024-02-29 01:56:45 --> Form Validation Class Initialized
INFO - 2024-02-29 01:56:45 --> Controller Class Initialized
INFO - 2024-02-29 01:56:45 --> Model Class Initialized
DEBUG - 2024-02-29 01:56:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:56:45 --> Model Class Initialized
DEBUG - 2024-02-29 01:56:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:56:45 --> Model Class Initialized
INFO - 2024-02-29 01:56:45 --> Model Class Initialized
INFO - 2024-02-29 01:56:45 --> Model Class Initialized
INFO - 2024-02-29 01:56:45 --> Model Class Initialized
DEBUG - 2024-02-29 01:56:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 01:56:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:56:45 --> Model Class Initialized
INFO - 2024-02-29 01:56:45 --> Model Class Initialized
INFO - 2024-02-29 01:56:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 01:56:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:56:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 01:56:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 01:56:45 --> Model Class Initialized
INFO - 2024-02-29 01:56:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 01:56:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 01:56:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 01:56:46 --> Final output sent to browser
DEBUG - 2024-02-29 01:56:46 --> Total execution time: 0.2388
ERROR - 2024-02-29 01:56:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 01:56:51 --> Config Class Initialized
INFO - 2024-02-29 01:56:51 --> Hooks Class Initialized
DEBUG - 2024-02-29 01:56:51 --> UTF-8 Support Enabled
INFO - 2024-02-29 01:56:51 --> Utf8 Class Initialized
INFO - 2024-02-29 01:56:51 --> URI Class Initialized
INFO - 2024-02-29 01:56:51 --> Router Class Initialized
INFO - 2024-02-29 01:56:51 --> Output Class Initialized
INFO - 2024-02-29 01:56:51 --> Security Class Initialized
DEBUG - 2024-02-29 01:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 01:56:51 --> Input Class Initialized
INFO - 2024-02-29 01:56:51 --> Language Class Initialized
INFO - 2024-02-29 01:56:51 --> Loader Class Initialized
INFO - 2024-02-29 01:56:51 --> Helper loaded: url_helper
INFO - 2024-02-29 01:56:51 --> Helper loaded: file_helper
INFO - 2024-02-29 01:56:51 --> Helper loaded: html_helper
INFO - 2024-02-29 01:56:51 --> Helper loaded: text_helper
INFO - 2024-02-29 01:56:51 --> Helper loaded: form_helper
INFO - 2024-02-29 01:56:51 --> Helper loaded: lang_helper
INFO - 2024-02-29 01:56:51 --> Helper loaded: security_helper
INFO - 2024-02-29 01:56:51 --> Helper loaded: cookie_helper
INFO - 2024-02-29 01:56:51 --> Database Driver Class Initialized
INFO - 2024-02-29 01:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 01:56:51 --> Parser Class Initialized
INFO - 2024-02-29 01:56:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 01:56:51 --> Pagination Class Initialized
INFO - 2024-02-29 01:56:51 --> Form Validation Class Initialized
INFO - 2024-02-29 01:56:51 --> Controller Class Initialized
INFO - 2024-02-29 01:56:51 --> Model Class Initialized
DEBUG - 2024-02-29 01:56:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 01:56:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:56:51 --> Model Class Initialized
DEBUG - 2024-02-29 01:56:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:56:51 --> Model Class Initialized
INFO - 2024-02-29 01:56:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-29 01:56:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:56:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 01:56:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 01:56:51 --> Model Class Initialized
INFO - 2024-02-29 01:56:51 --> Model Class Initialized
INFO - 2024-02-29 01:56:51 --> Model Class Initialized
INFO - 2024-02-29 01:56:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 01:56:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 01:56:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 01:56:51 --> Final output sent to browser
DEBUG - 2024-02-29 01:56:51 --> Total execution time: 0.1607
ERROR - 2024-02-29 01:56:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 01:56:52 --> Config Class Initialized
INFO - 2024-02-29 01:56:52 --> Hooks Class Initialized
DEBUG - 2024-02-29 01:56:52 --> UTF-8 Support Enabled
INFO - 2024-02-29 01:56:52 --> Utf8 Class Initialized
INFO - 2024-02-29 01:56:52 --> URI Class Initialized
INFO - 2024-02-29 01:56:52 --> Router Class Initialized
INFO - 2024-02-29 01:56:52 --> Output Class Initialized
INFO - 2024-02-29 01:56:52 --> Security Class Initialized
DEBUG - 2024-02-29 01:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 01:56:52 --> Input Class Initialized
INFO - 2024-02-29 01:56:52 --> Language Class Initialized
INFO - 2024-02-29 01:56:52 --> Loader Class Initialized
INFO - 2024-02-29 01:56:52 --> Helper loaded: url_helper
INFO - 2024-02-29 01:56:52 --> Helper loaded: file_helper
INFO - 2024-02-29 01:56:52 --> Helper loaded: html_helper
INFO - 2024-02-29 01:56:52 --> Helper loaded: text_helper
INFO - 2024-02-29 01:56:52 --> Helper loaded: form_helper
INFO - 2024-02-29 01:56:52 --> Helper loaded: lang_helper
INFO - 2024-02-29 01:56:52 --> Helper loaded: security_helper
INFO - 2024-02-29 01:56:52 --> Helper loaded: cookie_helper
INFO - 2024-02-29 01:56:52 --> Database Driver Class Initialized
INFO - 2024-02-29 01:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 01:56:52 --> Parser Class Initialized
INFO - 2024-02-29 01:56:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 01:56:52 --> Pagination Class Initialized
INFO - 2024-02-29 01:56:52 --> Form Validation Class Initialized
INFO - 2024-02-29 01:56:52 --> Controller Class Initialized
INFO - 2024-02-29 01:56:52 --> Model Class Initialized
DEBUG - 2024-02-29 01:56:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 01:56:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:56:52 --> Model Class Initialized
DEBUG - 2024-02-29 01:56:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:56:52 --> Model Class Initialized
INFO - 2024-02-29 01:56:52 --> Final output sent to browser
DEBUG - 2024-02-29 01:56:52 --> Total execution time: 0.0528
ERROR - 2024-02-29 01:58:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 01:58:16 --> Config Class Initialized
INFO - 2024-02-29 01:58:16 --> Hooks Class Initialized
DEBUG - 2024-02-29 01:58:16 --> UTF-8 Support Enabled
INFO - 2024-02-29 01:58:16 --> Utf8 Class Initialized
INFO - 2024-02-29 01:58:16 --> URI Class Initialized
DEBUG - 2024-02-29 01:58:16 --> No URI present. Default controller set.
INFO - 2024-02-29 01:58:16 --> Router Class Initialized
INFO - 2024-02-29 01:58:16 --> Output Class Initialized
INFO - 2024-02-29 01:58:16 --> Security Class Initialized
DEBUG - 2024-02-29 01:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 01:58:16 --> Input Class Initialized
INFO - 2024-02-29 01:58:16 --> Language Class Initialized
INFO - 2024-02-29 01:58:16 --> Loader Class Initialized
INFO - 2024-02-29 01:58:16 --> Helper loaded: url_helper
INFO - 2024-02-29 01:58:16 --> Helper loaded: file_helper
INFO - 2024-02-29 01:58:16 --> Helper loaded: html_helper
INFO - 2024-02-29 01:58:16 --> Helper loaded: text_helper
INFO - 2024-02-29 01:58:16 --> Helper loaded: form_helper
INFO - 2024-02-29 01:58:16 --> Helper loaded: lang_helper
INFO - 2024-02-29 01:58:16 --> Helper loaded: security_helper
INFO - 2024-02-29 01:58:16 --> Helper loaded: cookie_helper
INFO - 2024-02-29 01:58:16 --> Database Driver Class Initialized
INFO - 2024-02-29 01:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 01:58:16 --> Parser Class Initialized
INFO - 2024-02-29 01:58:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 01:58:16 --> Pagination Class Initialized
INFO - 2024-02-29 01:58:16 --> Form Validation Class Initialized
INFO - 2024-02-29 01:58:16 --> Controller Class Initialized
INFO - 2024-02-29 01:58:16 --> Model Class Initialized
DEBUG - 2024-02-29 01:58:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:58:16 --> Model Class Initialized
DEBUG - 2024-02-29 01:58:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:58:16 --> Model Class Initialized
INFO - 2024-02-29 01:58:16 --> Model Class Initialized
INFO - 2024-02-29 01:58:16 --> Model Class Initialized
INFO - 2024-02-29 01:58:16 --> Model Class Initialized
DEBUG - 2024-02-29 01:58:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 01:58:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:58:16 --> Model Class Initialized
INFO - 2024-02-29 01:58:16 --> Model Class Initialized
INFO - 2024-02-29 01:58:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 01:58:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:58:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 01:58:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 01:58:16 --> Model Class Initialized
ERROR - 2024-02-29 01:58:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 01:58:16 --> Config Class Initialized
INFO - 2024-02-29 01:58:16 --> Hooks Class Initialized
DEBUG - 2024-02-29 01:58:16 --> UTF-8 Support Enabled
INFO - 2024-02-29 01:58:16 --> Utf8 Class Initialized
INFO - 2024-02-29 01:58:16 --> URI Class Initialized
INFO - 2024-02-29 01:58:16 --> Router Class Initialized
INFO - 2024-02-29 01:58:16 --> Output Class Initialized
INFO - 2024-02-29 01:58:16 --> Security Class Initialized
DEBUG - 2024-02-29 01:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 01:58:16 --> Input Class Initialized
INFO - 2024-02-29 01:58:16 --> Language Class Initialized
INFO - 2024-02-29 01:58:16 --> Loader Class Initialized
INFO - 2024-02-29 01:58:16 --> Helper loaded: url_helper
INFO - 2024-02-29 01:58:16 --> Helper loaded: file_helper
INFO - 2024-02-29 01:58:16 --> Helper loaded: html_helper
INFO - 2024-02-29 01:58:16 --> Helper loaded: text_helper
INFO - 2024-02-29 01:58:16 --> Helper loaded: form_helper
INFO - 2024-02-29 01:58:16 --> Helper loaded: lang_helper
INFO - 2024-02-29 01:58:16 --> Helper loaded: security_helper
INFO - 2024-02-29 01:58:16 --> Helper loaded: cookie_helper
INFO - 2024-02-29 01:58:16 --> Database Driver Class Initialized
INFO - 2024-02-29 01:58:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 01:58:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 01:58:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 01:58:16 --> Final output sent to browser
DEBUG - 2024-02-29 01:58:16 --> Total execution time: 0.2428
INFO - 2024-02-29 01:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 01:58:16 --> Parser Class Initialized
INFO - 2024-02-29 01:58:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 01:58:16 --> Pagination Class Initialized
INFO - 2024-02-29 01:58:16 --> Form Validation Class Initialized
INFO - 2024-02-29 01:58:16 --> Controller Class Initialized
INFO - 2024-02-29 01:58:16 --> Model Class Initialized
DEBUG - 2024-02-29 01:58:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:58:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-29 01:58:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:58:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 01:58:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 01:58:16 --> Model Class Initialized
INFO - 2024-02-29 01:58:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 01:58:16 --> Final output sent to browser
DEBUG - 2024-02-29 01:58:16 --> Total execution time: 0.1256
ERROR - 2024-02-29 01:58:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 01:58:17 --> Config Class Initialized
INFO - 2024-02-29 01:58:17 --> Hooks Class Initialized
DEBUG - 2024-02-29 01:58:17 --> UTF-8 Support Enabled
INFO - 2024-02-29 01:58:17 --> Utf8 Class Initialized
INFO - 2024-02-29 01:58:17 --> URI Class Initialized
INFO - 2024-02-29 01:58:17 --> Router Class Initialized
INFO - 2024-02-29 01:58:17 --> Output Class Initialized
INFO - 2024-02-29 01:58:17 --> Security Class Initialized
DEBUG - 2024-02-29 01:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 01:58:17 --> Input Class Initialized
INFO - 2024-02-29 01:58:17 --> Language Class Initialized
INFO - 2024-02-29 01:58:17 --> Loader Class Initialized
INFO - 2024-02-29 01:58:17 --> Helper loaded: url_helper
INFO - 2024-02-29 01:58:17 --> Helper loaded: file_helper
INFO - 2024-02-29 01:58:17 --> Helper loaded: html_helper
INFO - 2024-02-29 01:58:17 --> Helper loaded: text_helper
INFO - 2024-02-29 01:58:17 --> Helper loaded: form_helper
INFO - 2024-02-29 01:58:17 --> Helper loaded: lang_helper
INFO - 2024-02-29 01:58:17 --> Helper loaded: security_helper
INFO - 2024-02-29 01:58:17 --> Helper loaded: cookie_helper
INFO - 2024-02-29 01:58:17 --> Database Driver Class Initialized
INFO - 2024-02-29 01:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 01:58:17 --> Parser Class Initialized
INFO - 2024-02-29 01:58:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 01:58:17 --> Pagination Class Initialized
INFO - 2024-02-29 01:58:17 --> Form Validation Class Initialized
INFO - 2024-02-29 01:58:17 --> Controller Class Initialized
INFO - 2024-02-29 01:58:17 --> Model Class Initialized
DEBUG - 2024-02-29 01:58:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:58:17 --> Model Class Initialized
DEBUG - 2024-02-29 01:58:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:58:17 --> Model Class Initialized
INFO - 2024-02-29 01:58:17 --> Model Class Initialized
INFO - 2024-02-29 01:58:17 --> Model Class Initialized
INFO - 2024-02-29 01:58:17 --> Model Class Initialized
DEBUG - 2024-02-29 01:58:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 01:58:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:58:17 --> Model Class Initialized
INFO - 2024-02-29 01:58:17 --> Model Class Initialized
INFO - 2024-02-29 01:58:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 01:58:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 01:58:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 01:58:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 01:58:17 --> Model Class Initialized
INFO - 2024-02-29 01:58:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 01:58:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 01:58:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 01:58:17 --> Final output sent to browser
DEBUG - 2024-02-29 01:58:17 --> Total execution time: 0.2625
ERROR - 2024-02-29 03:43:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 03:43:56 --> Config Class Initialized
INFO - 2024-02-29 03:43:56 --> Hooks Class Initialized
DEBUG - 2024-02-29 03:43:56 --> UTF-8 Support Enabled
INFO - 2024-02-29 03:43:56 --> Utf8 Class Initialized
INFO - 2024-02-29 03:43:56 --> URI Class Initialized
INFO - 2024-02-29 03:43:56 --> Router Class Initialized
INFO - 2024-02-29 03:43:56 --> Output Class Initialized
INFO - 2024-02-29 03:43:56 --> Security Class Initialized
DEBUG - 2024-02-29 03:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 03:43:56 --> Input Class Initialized
INFO - 2024-02-29 03:43:56 --> Language Class Initialized
ERROR - 2024-02-29 03:43:56 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-02-29 04:01:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:01:09 --> Config Class Initialized
INFO - 2024-02-29 04:01:09 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:01:09 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:01:09 --> Utf8 Class Initialized
INFO - 2024-02-29 04:01:09 --> URI Class Initialized
DEBUG - 2024-02-29 04:01:09 --> No URI present. Default controller set.
INFO - 2024-02-29 04:01:09 --> Router Class Initialized
INFO - 2024-02-29 04:01:09 --> Output Class Initialized
INFO - 2024-02-29 04:01:09 --> Security Class Initialized
DEBUG - 2024-02-29 04:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:01:09 --> Input Class Initialized
INFO - 2024-02-29 04:01:09 --> Language Class Initialized
INFO - 2024-02-29 04:01:09 --> Loader Class Initialized
INFO - 2024-02-29 04:01:09 --> Helper loaded: url_helper
INFO - 2024-02-29 04:01:09 --> Helper loaded: file_helper
INFO - 2024-02-29 04:01:09 --> Helper loaded: html_helper
INFO - 2024-02-29 04:01:09 --> Helper loaded: text_helper
INFO - 2024-02-29 04:01:09 --> Helper loaded: form_helper
INFO - 2024-02-29 04:01:09 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:01:09 --> Helper loaded: security_helper
INFO - 2024-02-29 04:01:09 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:01:09 --> Database Driver Class Initialized
INFO - 2024-02-29 04:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:01:09 --> Parser Class Initialized
INFO - 2024-02-29 04:01:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:01:09 --> Pagination Class Initialized
INFO - 2024-02-29 04:01:09 --> Form Validation Class Initialized
INFO - 2024-02-29 04:01:09 --> Controller Class Initialized
INFO - 2024-02-29 04:01:09 --> Model Class Initialized
DEBUG - 2024-02-29 04:01:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-29 04:01:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:01:10 --> Config Class Initialized
INFO - 2024-02-29 04:01:10 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:01:10 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:01:10 --> Utf8 Class Initialized
INFO - 2024-02-29 04:01:10 --> URI Class Initialized
INFO - 2024-02-29 04:01:10 --> Router Class Initialized
INFO - 2024-02-29 04:01:10 --> Output Class Initialized
INFO - 2024-02-29 04:01:10 --> Security Class Initialized
DEBUG - 2024-02-29 04:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:01:10 --> Input Class Initialized
INFO - 2024-02-29 04:01:10 --> Language Class Initialized
INFO - 2024-02-29 04:01:10 --> Loader Class Initialized
INFO - 2024-02-29 04:01:10 --> Helper loaded: url_helper
INFO - 2024-02-29 04:01:10 --> Helper loaded: file_helper
INFO - 2024-02-29 04:01:10 --> Helper loaded: html_helper
INFO - 2024-02-29 04:01:10 --> Helper loaded: text_helper
INFO - 2024-02-29 04:01:10 --> Helper loaded: form_helper
INFO - 2024-02-29 04:01:10 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:01:10 --> Helper loaded: security_helper
INFO - 2024-02-29 04:01:10 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:01:10 --> Database Driver Class Initialized
INFO - 2024-02-29 04:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:01:10 --> Parser Class Initialized
INFO - 2024-02-29 04:01:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:01:10 --> Pagination Class Initialized
INFO - 2024-02-29 04:01:10 --> Form Validation Class Initialized
INFO - 2024-02-29 04:01:10 --> Controller Class Initialized
INFO - 2024-02-29 04:01:10 --> Model Class Initialized
DEBUG - 2024-02-29 04:01:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:01:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-29 04:01:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:01:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:01:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:01:10 --> Model Class Initialized
INFO - 2024-02-29 04:01:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:01:10 --> Final output sent to browser
DEBUG - 2024-02-29 04:01:10 --> Total execution time: 0.0366
ERROR - 2024-02-29 04:01:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:01:19 --> Config Class Initialized
INFO - 2024-02-29 04:01:19 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:01:19 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:01:19 --> Utf8 Class Initialized
INFO - 2024-02-29 04:01:19 --> URI Class Initialized
INFO - 2024-02-29 04:01:19 --> Router Class Initialized
INFO - 2024-02-29 04:01:19 --> Output Class Initialized
INFO - 2024-02-29 04:01:19 --> Security Class Initialized
DEBUG - 2024-02-29 04:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:01:19 --> Input Class Initialized
INFO - 2024-02-29 04:01:19 --> Language Class Initialized
INFO - 2024-02-29 04:01:19 --> Loader Class Initialized
INFO - 2024-02-29 04:01:19 --> Helper loaded: url_helper
INFO - 2024-02-29 04:01:19 --> Helper loaded: file_helper
INFO - 2024-02-29 04:01:19 --> Helper loaded: html_helper
INFO - 2024-02-29 04:01:19 --> Helper loaded: text_helper
INFO - 2024-02-29 04:01:19 --> Helper loaded: form_helper
INFO - 2024-02-29 04:01:19 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:01:19 --> Helper loaded: security_helper
INFO - 2024-02-29 04:01:19 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:01:19 --> Database Driver Class Initialized
INFO - 2024-02-29 04:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:01:19 --> Parser Class Initialized
INFO - 2024-02-29 04:01:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:01:19 --> Pagination Class Initialized
INFO - 2024-02-29 04:01:19 --> Form Validation Class Initialized
INFO - 2024-02-29 04:01:19 --> Controller Class Initialized
INFO - 2024-02-29 04:01:19 --> Model Class Initialized
DEBUG - 2024-02-29 04:01:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:01:19 --> Model Class Initialized
INFO - 2024-02-29 04:01:19 --> Final output sent to browser
DEBUG - 2024-02-29 04:01:19 --> Total execution time: 0.0196
ERROR - 2024-02-29 04:01:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:01:19 --> Config Class Initialized
INFO - 2024-02-29 04:01:19 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:01:19 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:01:19 --> Utf8 Class Initialized
INFO - 2024-02-29 04:01:19 --> URI Class Initialized
DEBUG - 2024-02-29 04:01:19 --> No URI present. Default controller set.
INFO - 2024-02-29 04:01:19 --> Router Class Initialized
INFO - 2024-02-29 04:01:19 --> Output Class Initialized
INFO - 2024-02-29 04:01:19 --> Security Class Initialized
DEBUG - 2024-02-29 04:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:01:19 --> Input Class Initialized
INFO - 2024-02-29 04:01:19 --> Language Class Initialized
INFO - 2024-02-29 04:01:19 --> Loader Class Initialized
INFO - 2024-02-29 04:01:19 --> Helper loaded: url_helper
INFO - 2024-02-29 04:01:19 --> Helper loaded: file_helper
INFO - 2024-02-29 04:01:19 --> Helper loaded: html_helper
INFO - 2024-02-29 04:01:19 --> Helper loaded: text_helper
INFO - 2024-02-29 04:01:19 --> Helper loaded: form_helper
INFO - 2024-02-29 04:01:19 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:01:19 --> Helper loaded: security_helper
INFO - 2024-02-29 04:01:19 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:01:19 --> Database Driver Class Initialized
INFO - 2024-02-29 04:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:01:19 --> Parser Class Initialized
INFO - 2024-02-29 04:01:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:01:19 --> Pagination Class Initialized
INFO - 2024-02-29 04:01:19 --> Form Validation Class Initialized
INFO - 2024-02-29 04:01:19 --> Controller Class Initialized
INFO - 2024-02-29 04:01:19 --> Model Class Initialized
DEBUG - 2024-02-29 04:01:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:01:19 --> Model Class Initialized
DEBUG - 2024-02-29 04:01:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:01:19 --> Model Class Initialized
INFO - 2024-02-29 04:01:19 --> Model Class Initialized
INFO - 2024-02-29 04:01:19 --> Model Class Initialized
INFO - 2024-02-29 04:01:19 --> Model Class Initialized
DEBUG - 2024-02-29 04:01:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:01:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:01:19 --> Model Class Initialized
INFO - 2024-02-29 04:01:19 --> Model Class Initialized
INFO - 2024-02-29 04:01:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 04:01:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:01:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:01:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:01:19 --> Model Class Initialized
INFO - 2024-02-29 04:01:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 04:01:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 04:01:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:01:19 --> Final output sent to browser
DEBUG - 2024-02-29 04:01:19 --> Total execution time: 0.2424
ERROR - 2024-02-29 04:01:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:01:22 --> Config Class Initialized
INFO - 2024-02-29 04:01:22 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:01:23 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:01:23 --> Utf8 Class Initialized
INFO - 2024-02-29 04:01:23 --> URI Class Initialized
INFO - 2024-02-29 04:01:23 --> Router Class Initialized
INFO - 2024-02-29 04:01:23 --> Output Class Initialized
INFO - 2024-02-29 04:01:23 --> Security Class Initialized
DEBUG - 2024-02-29 04:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:01:23 --> Input Class Initialized
INFO - 2024-02-29 04:01:23 --> Language Class Initialized
INFO - 2024-02-29 04:01:23 --> Loader Class Initialized
INFO - 2024-02-29 04:01:23 --> Helper loaded: url_helper
INFO - 2024-02-29 04:01:23 --> Helper loaded: file_helper
INFO - 2024-02-29 04:01:23 --> Helper loaded: html_helper
INFO - 2024-02-29 04:01:23 --> Helper loaded: text_helper
INFO - 2024-02-29 04:01:23 --> Helper loaded: form_helper
INFO - 2024-02-29 04:01:23 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:01:23 --> Helper loaded: security_helper
INFO - 2024-02-29 04:01:23 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:01:23 --> Database Driver Class Initialized
INFO - 2024-02-29 04:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:01:23 --> Parser Class Initialized
INFO - 2024-02-29 04:01:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:01:23 --> Pagination Class Initialized
INFO - 2024-02-29 04:01:23 --> Form Validation Class Initialized
INFO - 2024-02-29 04:01:23 --> Controller Class Initialized
DEBUG - 2024-02-29 04:01:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:01:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:01:23 --> Model Class Initialized
DEBUG - 2024-02-29 04:01:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:01:23 --> Model Class Initialized
DEBUG - 2024-02-29 04:01:23 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:01:23 --> Model Class Initialized
INFO - 2024-02-29 04:01:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-29 04:01:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:01:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:01:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:01:23 --> Model Class Initialized
INFO - 2024-02-29 04:01:23 --> Model Class Initialized
INFO - 2024-02-29 04:01:23 --> Model Class Initialized
INFO - 2024-02-29 04:01:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 04:01:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 04:01:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:01:23 --> Final output sent to browser
DEBUG - 2024-02-29 04:01:23 --> Total execution time: 0.1559
ERROR - 2024-02-29 04:01:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:01:23 --> Config Class Initialized
INFO - 2024-02-29 04:01:23 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:01:23 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:01:23 --> Utf8 Class Initialized
INFO - 2024-02-29 04:01:23 --> URI Class Initialized
INFO - 2024-02-29 04:01:23 --> Router Class Initialized
INFO - 2024-02-29 04:01:23 --> Output Class Initialized
INFO - 2024-02-29 04:01:23 --> Security Class Initialized
DEBUG - 2024-02-29 04:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:01:23 --> Input Class Initialized
INFO - 2024-02-29 04:01:23 --> Language Class Initialized
INFO - 2024-02-29 04:01:23 --> Loader Class Initialized
INFO - 2024-02-29 04:01:23 --> Helper loaded: url_helper
INFO - 2024-02-29 04:01:23 --> Helper loaded: file_helper
INFO - 2024-02-29 04:01:23 --> Helper loaded: html_helper
INFO - 2024-02-29 04:01:23 --> Helper loaded: text_helper
INFO - 2024-02-29 04:01:23 --> Helper loaded: form_helper
INFO - 2024-02-29 04:01:23 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:01:23 --> Helper loaded: security_helper
INFO - 2024-02-29 04:01:23 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:01:23 --> Database Driver Class Initialized
INFO - 2024-02-29 04:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:01:23 --> Parser Class Initialized
INFO - 2024-02-29 04:01:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:01:23 --> Pagination Class Initialized
INFO - 2024-02-29 04:01:23 --> Form Validation Class Initialized
INFO - 2024-02-29 04:01:23 --> Controller Class Initialized
DEBUG - 2024-02-29 04:01:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:01:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:01:23 --> Model Class Initialized
DEBUG - 2024-02-29 04:01:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:01:23 --> Model Class Initialized
INFO - 2024-02-29 04:01:23 --> Final output sent to browser
DEBUG - 2024-02-29 04:01:23 --> Total execution time: 0.0247
ERROR - 2024-02-29 04:01:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:01:27 --> Config Class Initialized
INFO - 2024-02-29 04:01:27 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:01:27 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:01:27 --> Utf8 Class Initialized
INFO - 2024-02-29 04:01:27 --> URI Class Initialized
INFO - 2024-02-29 04:01:27 --> Router Class Initialized
INFO - 2024-02-29 04:01:27 --> Output Class Initialized
INFO - 2024-02-29 04:01:27 --> Security Class Initialized
DEBUG - 2024-02-29 04:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:01:27 --> Input Class Initialized
INFO - 2024-02-29 04:01:27 --> Language Class Initialized
INFO - 2024-02-29 04:01:27 --> Loader Class Initialized
INFO - 2024-02-29 04:01:27 --> Helper loaded: url_helper
INFO - 2024-02-29 04:01:27 --> Helper loaded: file_helper
INFO - 2024-02-29 04:01:27 --> Helper loaded: html_helper
INFO - 2024-02-29 04:01:27 --> Helper loaded: text_helper
INFO - 2024-02-29 04:01:27 --> Helper loaded: form_helper
INFO - 2024-02-29 04:01:27 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:01:27 --> Helper loaded: security_helper
INFO - 2024-02-29 04:01:27 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:01:27 --> Database Driver Class Initialized
INFO - 2024-02-29 04:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:01:27 --> Parser Class Initialized
INFO - 2024-02-29 04:01:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:01:27 --> Pagination Class Initialized
INFO - 2024-02-29 04:01:27 --> Form Validation Class Initialized
INFO - 2024-02-29 04:01:27 --> Controller Class Initialized
DEBUG - 2024-02-29 04:01:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:01:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:01:27 --> Model Class Initialized
DEBUG - 2024-02-29 04:01:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:01:27 --> Model Class Initialized
INFO - 2024-02-29 04:01:27 --> Final output sent to browser
DEBUG - 2024-02-29 04:01:27 --> Total execution time: 0.0346
ERROR - 2024-02-29 04:03:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:03:07 --> Config Class Initialized
INFO - 2024-02-29 04:03:07 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:03:07 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:03:07 --> Utf8 Class Initialized
INFO - 2024-02-29 04:03:07 --> URI Class Initialized
DEBUG - 2024-02-29 04:03:07 --> No URI present. Default controller set.
INFO - 2024-02-29 04:03:07 --> Router Class Initialized
INFO - 2024-02-29 04:03:07 --> Output Class Initialized
INFO - 2024-02-29 04:03:07 --> Security Class Initialized
DEBUG - 2024-02-29 04:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:03:07 --> Input Class Initialized
INFO - 2024-02-29 04:03:07 --> Language Class Initialized
INFO - 2024-02-29 04:03:07 --> Loader Class Initialized
INFO - 2024-02-29 04:03:07 --> Helper loaded: url_helper
INFO - 2024-02-29 04:03:07 --> Helper loaded: file_helper
INFO - 2024-02-29 04:03:07 --> Helper loaded: html_helper
INFO - 2024-02-29 04:03:07 --> Helper loaded: text_helper
INFO - 2024-02-29 04:03:07 --> Helper loaded: form_helper
INFO - 2024-02-29 04:03:07 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:03:07 --> Helper loaded: security_helper
INFO - 2024-02-29 04:03:07 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:03:07 --> Database Driver Class Initialized
INFO - 2024-02-29 04:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:03:07 --> Parser Class Initialized
INFO - 2024-02-29 04:03:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:03:07 --> Pagination Class Initialized
INFO - 2024-02-29 04:03:07 --> Form Validation Class Initialized
INFO - 2024-02-29 04:03:07 --> Controller Class Initialized
INFO - 2024-02-29 04:03:07 --> Model Class Initialized
DEBUG - 2024-02-29 04:03:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:03:07 --> Model Class Initialized
DEBUG - 2024-02-29 04:03:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:03:07 --> Model Class Initialized
INFO - 2024-02-29 04:03:07 --> Model Class Initialized
INFO - 2024-02-29 04:03:07 --> Model Class Initialized
INFO - 2024-02-29 04:03:07 --> Model Class Initialized
DEBUG - 2024-02-29 04:03:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:03:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:03:07 --> Model Class Initialized
INFO - 2024-02-29 04:03:07 --> Model Class Initialized
INFO - 2024-02-29 04:03:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 04:03:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:03:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:03:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:03:07 --> Model Class Initialized
INFO - 2024-02-29 04:03:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 04:03:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 04:03:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:03:07 --> Final output sent to browser
DEBUG - 2024-02-29 04:03:07 --> Total execution time: 0.2434
ERROR - 2024-02-29 04:05:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:05:43 --> Config Class Initialized
INFO - 2024-02-29 04:05:43 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:05:43 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:05:43 --> Utf8 Class Initialized
INFO - 2024-02-29 04:05:43 --> URI Class Initialized
INFO - 2024-02-29 04:05:43 --> Router Class Initialized
INFO - 2024-02-29 04:05:43 --> Output Class Initialized
INFO - 2024-02-29 04:05:43 --> Security Class Initialized
DEBUG - 2024-02-29 04:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:05:43 --> Input Class Initialized
INFO - 2024-02-29 04:05:43 --> Language Class Initialized
INFO - 2024-02-29 04:05:43 --> Loader Class Initialized
INFO - 2024-02-29 04:05:43 --> Helper loaded: url_helper
INFO - 2024-02-29 04:05:43 --> Helper loaded: file_helper
INFO - 2024-02-29 04:05:43 --> Helper loaded: html_helper
INFO - 2024-02-29 04:05:43 --> Helper loaded: text_helper
INFO - 2024-02-29 04:05:43 --> Helper loaded: form_helper
INFO - 2024-02-29 04:05:43 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:05:43 --> Helper loaded: security_helper
INFO - 2024-02-29 04:05:43 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:05:43 --> Database Driver Class Initialized
INFO - 2024-02-29 04:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:05:43 --> Parser Class Initialized
INFO - 2024-02-29 04:05:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:05:43 --> Pagination Class Initialized
INFO - 2024-02-29 04:05:43 --> Form Validation Class Initialized
INFO - 2024-02-29 04:05:43 --> Controller Class Initialized
DEBUG - 2024-02-29 04:05:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:05:43 --> Model Class Initialized
DEBUG - 2024-02-29 04:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:05:43 --> Model Class Initialized
INFO - 2024-02-29 04:05:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-02-29 04:05:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:05:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:05:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:05:43 --> Model Class Initialized
INFO - 2024-02-29 04:05:43 --> Model Class Initialized
INFO - 2024-02-29 04:05:43 --> Model Class Initialized
INFO - 2024-02-29 04:05:43 --> Model Class Initialized
INFO - 2024-02-29 04:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 04:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 04:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:05:44 --> Final output sent to browser
DEBUG - 2024-02-29 04:05:44 --> Total execution time: 0.1870
ERROR - 2024-02-29 04:10:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:10:32 --> Config Class Initialized
INFO - 2024-02-29 04:10:32 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:10:32 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:10:32 --> Utf8 Class Initialized
INFO - 2024-02-29 04:10:32 --> URI Class Initialized
INFO - 2024-02-29 04:10:32 --> Router Class Initialized
INFO - 2024-02-29 04:10:32 --> Output Class Initialized
INFO - 2024-02-29 04:10:32 --> Security Class Initialized
DEBUG - 2024-02-29 04:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:10:32 --> Input Class Initialized
INFO - 2024-02-29 04:10:32 --> Language Class Initialized
INFO - 2024-02-29 04:10:32 --> Loader Class Initialized
INFO - 2024-02-29 04:10:32 --> Helper loaded: url_helper
INFO - 2024-02-29 04:10:32 --> Helper loaded: file_helper
INFO - 2024-02-29 04:10:32 --> Helper loaded: html_helper
INFO - 2024-02-29 04:10:32 --> Helper loaded: text_helper
INFO - 2024-02-29 04:10:32 --> Helper loaded: form_helper
INFO - 2024-02-29 04:10:32 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:10:32 --> Helper loaded: security_helper
INFO - 2024-02-29 04:10:32 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:10:32 --> Database Driver Class Initialized
INFO - 2024-02-29 04:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:10:32 --> Parser Class Initialized
INFO - 2024-02-29 04:10:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:10:32 --> Pagination Class Initialized
INFO - 2024-02-29 04:10:32 --> Form Validation Class Initialized
INFO - 2024-02-29 04:10:32 --> Controller Class Initialized
DEBUG - 2024-02-29 04:10:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:10:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:10:32 --> Model Class Initialized
DEBUG - 2024-02-29 04:10:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:10:32 --> Model Class Initialized
DEBUG - 2024-02-29 04:10:32 --> Auth class already loaded. Second attempt ignored.
ERROR - 2024-02-29 04:10:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:10:32 --> Config Class Initialized
INFO - 2024-02-29 04:10:32 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:10:32 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:10:32 --> Utf8 Class Initialized
INFO - 2024-02-29 04:10:32 --> URI Class Initialized
INFO - 2024-02-29 04:10:32 --> Router Class Initialized
INFO - 2024-02-29 04:10:32 --> Output Class Initialized
INFO - 2024-02-29 04:10:32 --> Security Class Initialized
DEBUG - 2024-02-29 04:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:10:32 --> Input Class Initialized
INFO - 2024-02-29 04:10:32 --> Language Class Initialized
INFO - 2024-02-29 04:10:32 --> Loader Class Initialized
INFO - 2024-02-29 04:10:32 --> Helper loaded: url_helper
INFO - 2024-02-29 04:10:32 --> Helper loaded: file_helper
INFO - 2024-02-29 04:10:32 --> Helper loaded: html_helper
INFO - 2024-02-29 04:10:32 --> Helper loaded: text_helper
INFO - 2024-02-29 04:10:32 --> Helper loaded: form_helper
INFO - 2024-02-29 04:10:32 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:10:32 --> Helper loaded: security_helper
INFO - 2024-02-29 04:10:32 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:10:32 --> Database Driver Class Initialized
INFO - 2024-02-29 04:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:10:32 --> Parser Class Initialized
INFO - 2024-02-29 04:10:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:10:32 --> Pagination Class Initialized
INFO - 2024-02-29 04:10:32 --> Form Validation Class Initialized
INFO - 2024-02-29 04:10:32 --> Controller Class Initialized
DEBUG - 2024-02-29 04:10:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:10:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:10:32 --> Model Class Initialized
DEBUG - 2024-02-29 04:10:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:10:32 --> Model Class Initialized
INFO - 2024-02-29 04:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-02-29 04:10:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:10:33 --> Model Class Initialized
INFO - 2024-02-29 04:10:33 --> Model Class Initialized
INFO - 2024-02-29 04:10:33 --> Model Class Initialized
INFO - 2024-02-29 04:10:33 --> Model Class Initialized
INFO - 2024-02-29 04:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 04:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 04:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:10:33 --> Final output sent to browser
DEBUG - 2024-02-29 04:10:33 --> Total execution time: 0.1976
ERROR - 2024-02-29 04:13:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:13:01 --> Config Class Initialized
INFO - 2024-02-29 04:13:01 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:13:01 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:13:01 --> Utf8 Class Initialized
INFO - 2024-02-29 04:13:01 --> URI Class Initialized
DEBUG - 2024-02-29 04:13:01 --> No URI present. Default controller set.
INFO - 2024-02-29 04:13:01 --> Router Class Initialized
INFO - 2024-02-29 04:13:01 --> Output Class Initialized
INFO - 2024-02-29 04:13:01 --> Security Class Initialized
DEBUG - 2024-02-29 04:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:13:01 --> Input Class Initialized
INFO - 2024-02-29 04:13:01 --> Language Class Initialized
INFO - 2024-02-29 04:13:01 --> Loader Class Initialized
INFO - 2024-02-29 04:13:01 --> Helper loaded: url_helper
INFO - 2024-02-29 04:13:01 --> Helper loaded: file_helper
INFO - 2024-02-29 04:13:01 --> Helper loaded: html_helper
INFO - 2024-02-29 04:13:01 --> Helper loaded: text_helper
INFO - 2024-02-29 04:13:01 --> Helper loaded: form_helper
INFO - 2024-02-29 04:13:01 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:13:01 --> Helper loaded: security_helper
INFO - 2024-02-29 04:13:01 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:13:01 --> Database Driver Class Initialized
INFO - 2024-02-29 04:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:13:01 --> Parser Class Initialized
INFO - 2024-02-29 04:13:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:13:01 --> Pagination Class Initialized
INFO - 2024-02-29 04:13:01 --> Form Validation Class Initialized
INFO - 2024-02-29 04:13:01 --> Controller Class Initialized
INFO - 2024-02-29 04:13:01 --> Model Class Initialized
DEBUG - 2024-02-29 04:13:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-29 04:13:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:13:02 --> Config Class Initialized
INFO - 2024-02-29 04:13:02 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:13:02 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:13:02 --> Utf8 Class Initialized
INFO - 2024-02-29 04:13:02 --> URI Class Initialized
INFO - 2024-02-29 04:13:02 --> Router Class Initialized
INFO - 2024-02-29 04:13:02 --> Output Class Initialized
INFO - 2024-02-29 04:13:02 --> Security Class Initialized
DEBUG - 2024-02-29 04:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:13:02 --> Input Class Initialized
INFO - 2024-02-29 04:13:02 --> Language Class Initialized
INFO - 2024-02-29 04:13:02 --> Loader Class Initialized
INFO - 2024-02-29 04:13:02 --> Helper loaded: url_helper
INFO - 2024-02-29 04:13:02 --> Helper loaded: file_helper
INFO - 2024-02-29 04:13:02 --> Helper loaded: html_helper
INFO - 2024-02-29 04:13:02 --> Helper loaded: text_helper
INFO - 2024-02-29 04:13:02 --> Helper loaded: form_helper
INFO - 2024-02-29 04:13:02 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:13:02 --> Helper loaded: security_helper
INFO - 2024-02-29 04:13:02 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:13:02 --> Database Driver Class Initialized
INFO - 2024-02-29 04:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:13:02 --> Parser Class Initialized
INFO - 2024-02-29 04:13:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:13:02 --> Pagination Class Initialized
INFO - 2024-02-29 04:13:02 --> Form Validation Class Initialized
INFO - 2024-02-29 04:13:02 --> Controller Class Initialized
INFO - 2024-02-29 04:13:02 --> Model Class Initialized
DEBUG - 2024-02-29 04:13:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-29 04:13:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:13:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:13:02 --> Model Class Initialized
INFO - 2024-02-29 04:13:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:13:02 --> Final output sent to browser
DEBUG - 2024-02-29 04:13:02 --> Total execution time: 0.0344
ERROR - 2024-02-29 04:13:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:13:12 --> Config Class Initialized
INFO - 2024-02-29 04:13:12 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:13:12 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:13:12 --> Utf8 Class Initialized
INFO - 2024-02-29 04:13:12 --> URI Class Initialized
INFO - 2024-02-29 04:13:12 --> Router Class Initialized
INFO - 2024-02-29 04:13:12 --> Output Class Initialized
INFO - 2024-02-29 04:13:12 --> Security Class Initialized
DEBUG - 2024-02-29 04:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:13:12 --> Input Class Initialized
INFO - 2024-02-29 04:13:12 --> Language Class Initialized
INFO - 2024-02-29 04:13:12 --> Loader Class Initialized
INFO - 2024-02-29 04:13:12 --> Helper loaded: url_helper
INFO - 2024-02-29 04:13:12 --> Helper loaded: file_helper
INFO - 2024-02-29 04:13:12 --> Helper loaded: html_helper
INFO - 2024-02-29 04:13:12 --> Helper loaded: text_helper
INFO - 2024-02-29 04:13:12 --> Helper loaded: form_helper
INFO - 2024-02-29 04:13:12 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:13:12 --> Helper loaded: security_helper
INFO - 2024-02-29 04:13:12 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:13:12 --> Database Driver Class Initialized
INFO - 2024-02-29 04:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:13:12 --> Parser Class Initialized
INFO - 2024-02-29 04:13:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:13:12 --> Pagination Class Initialized
INFO - 2024-02-29 04:13:12 --> Form Validation Class Initialized
INFO - 2024-02-29 04:13:12 --> Controller Class Initialized
INFO - 2024-02-29 04:13:12 --> Model Class Initialized
DEBUG - 2024-02-29 04:13:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:12 --> Model Class Initialized
INFO - 2024-02-29 04:13:12 --> Final output sent to browser
DEBUG - 2024-02-29 04:13:12 --> Total execution time: 0.0170
ERROR - 2024-02-29 04:13:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:13:13 --> Config Class Initialized
INFO - 2024-02-29 04:13:13 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:13:13 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:13:13 --> Utf8 Class Initialized
INFO - 2024-02-29 04:13:13 --> URI Class Initialized
DEBUG - 2024-02-29 04:13:13 --> No URI present. Default controller set.
INFO - 2024-02-29 04:13:13 --> Router Class Initialized
INFO - 2024-02-29 04:13:13 --> Output Class Initialized
INFO - 2024-02-29 04:13:13 --> Security Class Initialized
DEBUG - 2024-02-29 04:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:13:13 --> Input Class Initialized
INFO - 2024-02-29 04:13:13 --> Language Class Initialized
INFO - 2024-02-29 04:13:13 --> Loader Class Initialized
INFO - 2024-02-29 04:13:13 --> Helper loaded: url_helper
INFO - 2024-02-29 04:13:13 --> Helper loaded: file_helper
INFO - 2024-02-29 04:13:13 --> Helper loaded: html_helper
INFO - 2024-02-29 04:13:13 --> Helper loaded: text_helper
INFO - 2024-02-29 04:13:13 --> Helper loaded: form_helper
INFO - 2024-02-29 04:13:13 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:13:13 --> Helper loaded: security_helper
INFO - 2024-02-29 04:13:13 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:13:13 --> Database Driver Class Initialized
INFO - 2024-02-29 04:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:13:13 --> Parser Class Initialized
INFO - 2024-02-29 04:13:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:13:13 --> Pagination Class Initialized
INFO - 2024-02-29 04:13:13 --> Form Validation Class Initialized
INFO - 2024-02-29 04:13:13 --> Controller Class Initialized
INFO - 2024-02-29 04:13:13 --> Model Class Initialized
DEBUG - 2024-02-29 04:13:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:13 --> Model Class Initialized
DEBUG - 2024-02-29 04:13:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:13 --> Model Class Initialized
INFO - 2024-02-29 04:13:13 --> Model Class Initialized
INFO - 2024-02-29 04:13:13 --> Model Class Initialized
INFO - 2024-02-29 04:13:13 --> Model Class Initialized
DEBUG - 2024-02-29 04:13:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:13:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:13 --> Model Class Initialized
INFO - 2024-02-29 04:13:13 --> Model Class Initialized
INFO - 2024-02-29 04:13:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 04:13:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:13:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:13:13 --> Model Class Initialized
INFO - 2024-02-29 04:13:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 04:13:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 04:13:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:13:13 --> Final output sent to browser
DEBUG - 2024-02-29 04:13:13 --> Total execution time: 0.4267
ERROR - 2024-02-29 04:13:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:13:14 --> Config Class Initialized
INFO - 2024-02-29 04:13:14 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:13:14 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:13:14 --> Utf8 Class Initialized
INFO - 2024-02-29 04:13:14 --> URI Class Initialized
INFO - 2024-02-29 04:13:14 --> Router Class Initialized
INFO - 2024-02-29 04:13:14 --> Output Class Initialized
INFO - 2024-02-29 04:13:14 --> Security Class Initialized
DEBUG - 2024-02-29 04:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:13:14 --> Input Class Initialized
INFO - 2024-02-29 04:13:14 --> Language Class Initialized
INFO - 2024-02-29 04:13:14 --> Loader Class Initialized
INFO - 2024-02-29 04:13:14 --> Helper loaded: url_helper
INFO - 2024-02-29 04:13:14 --> Helper loaded: file_helper
INFO - 2024-02-29 04:13:14 --> Helper loaded: html_helper
INFO - 2024-02-29 04:13:14 --> Helper loaded: text_helper
INFO - 2024-02-29 04:13:14 --> Helper loaded: form_helper
INFO - 2024-02-29 04:13:14 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:13:14 --> Helper loaded: security_helper
INFO - 2024-02-29 04:13:14 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:13:14 --> Database Driver Class Initialized
INFO - 2024-02-29 04:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:13:14 --> Parser Class Initialized
INFO - 2024-02-29 04:13:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:13:14 --> Pagination Class Initialized
INFO - 2024-02-29 04:13:14 --> Form Validation Class Initialized
INFO - 2024-02-29 04:13:14 --> Controller Class Initialized
DEBUG - 2024-02-29 04:13:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:13:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:14 --> Model Class Initialized
INFO - 2024-02-29 04:13:14 --> Final output sent to browser
DEBUG - 2024-02-29 04:13:14 --> Total execution time: 0.0132
ERROR - 2024-02-29 04:13:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:13:20 --> Config Class Initialized
INFO - 2024-02-29 04:13:20 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:13:20 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:13:20 --> Utf8 Class Initialized
INFO - 2024-02-29 04:13:20 --> URI Class Initialized
INFO - 2024-02-29 04:13:20 --> Router Class Initialized
INFO - 2024-02-29 04:13:20 --> Output Class Initialized
INFO - 2024-02-29 04:13:20 --> Security Class Initialized
DEBUG - 2024-02-29 04:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:13:20 --> Input Class Initialized
INFO - 2024-02-29 04:13:20 --> Language Class Initialized
INFO - 2024-02-29 04:13:20 --> Loader Class Initialized
INFO - 2024-02-29 04:13:20 --> Helper loaded: url_helper
INFO - 2024-02-29 04:13:20 --> Helper loaded: file_helper
INFO - 2024-02-29 04:13:20 --> Helper loaded: html_helper
INFO - 2024-02-29 04:13:20 --> Helper loaded: text_helper
INFO - 2024-02-29 04:13:20 --> Helper loaded: form_helper
INFO - 2024-02-29 04:13:20 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:13:20 --> Helper loaded: security_helper
INFO - 2024-02-29 04:13:20 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:13:20 --> Database Driver Class Initialized
INFO - 2024-02-29 04:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:13:20 --> Parser Class Initialized
INFO - 2024-02-29 04:13:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:13:20 --> Pagination Class Initialized
INFO - 2024-02-29 04:13:20 --> Form Validation Class Initialized
INFO - 2024-02-29 04:13:20 --> Controller Class Initialized
DEBUG - 2024-02-29 04:13:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:13:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:20 --> Model Class Initialized
DEBUG - 2024-02-29 04:13:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:20 --> Model Class Initialized
DEBUG - 2024-02-29 04:13:20 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:20 --> Model Class Initialized
INFO - 2024-02-29 04:13:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-29 04:13:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:13:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:13:20 --> Model Class Initialized
INFO - 2024-02-29 04:13:20 --> Model Class Initialized
INFO - 2024-02-29 04:13:20 --> Model Class Initialized
INFO - 2024-02-29 04:13:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 04:13:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 04:13:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:13:20 --> Final output sent to browser
DEBUG - 2024-02-29 04:13:20 --> Total execution time: 0.2206
ERROR - 2024-02-29 04:13:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:13:21 --> Config Class Initialized
INFO - 2024-02-29 04:13:21 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:13:21 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:13:21 --> Utf8 Class Initialized
INFO - 2024-02-29 04:13:21 --> URI Class Initialized
INFO - 2024-02-29 04:13:21 --> Router Class Initialized
INFO - 2024-02-29 04:13:21 --> Output Class Initialized
INFO - 2024-02-29 04:13:21 --> Security Class Initialized
DEBUG - 2024-02-29 04:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:13:21 --> Input Class Initialized
INFO - 2024-02-29 04:13:21 --> Language Class Initialized
INFO - 2024-02-29 04:13:21 --> Loader Class Initialized
INFO - 2024-02-29 04:13:21 --> Helper loaded: url_helper
INFO - 2024-02-29 04:13:21 --> Helper loaded: file_helper
INFO - 2024-02-29 04:13:21 --> Helper loaded: html_helper
INFO - 2024-02-29 04:13:21 --> Helper loaded: text_helper
INFO - 2024-02-29 04:13:21 --> Helper loaded: form_helper
INFO - 2024-02-29 04:13:21 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:13:21 --> Helper loaded: security_helper
INFO - 2024-02-29 04:13:21 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:13:21 --> Database Driver Class Initialized
INFO - 2024-02-29 04:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:13:21 --> Parser Class Initialized
INFO - 2024-02-29 04:13:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:13:21 --> Pagination Class Initialized
INFO - 2024-02-29 04:13:21 --> Form Validation Class Initialized
INFO - 2024-02-29 04:13:21 --> Controller Class Initialized
DEBUG - 2024-02-29 04:13:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:13:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:21 --> Model Class Initialized
DEBUG - 2024-02-29 04:13:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:21 --> Model Class Initialized
INFO - 2024-02-29 04:13:21 --> Final output sent to browser
DEBUG - 2024-02-29 04:13:21 --> Total execution time: 0.0351
ERROR - 2024-02-29 04:13:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:13:24 --> Config Class Initialized
INFO - 2024-02-29 04:13:24 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:13:24 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:13:24 --> Utf8 Class Initialized
INFO - 2024-02-29 04:13:24 --> URI Class Initialized
INFO - 2024-02-29 04:13:24 --> Router Class Initialized
INFO - 2024-02-29 04:13:24 --> Output Class Initialized
INFO - 2024-02-29 04:13:24 --> Security Class Initialized
DEBUG - 2024-02-29 04:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:13:24 --> Input Class Initialized
INFO - 2024-02-29 04:13:24 --> Language Class Initialized
INFO - 2024-02-29 04:13:24 --> Loader Class Initialized
INFO - 2024-02-29 04:13:24 --> Helper loaded: url_helper
INFO - 2024-02-29 04:13:24 --> Helper loaded: file_helper
INFO - 2024-02-29 04:13:24 --> Helper loaded: html_helper
INFO - 2024-02-29 04:13:24 --> Helper loaded: text_helper
INFO - 2024-02-29 04:13:24 --> Helper loaded: form_helper
INFO - 2024-02-29 04:13:24 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:13:24 --> Helper loaded: security_helper
INFO - 2024-02-29 04:13:24 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:13:24 --> Database Driver Class Initialized
INFO - 2024-02-29 04:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:13:24 --> Parser Class Initialized
INFO - 2024-02-29 04:13:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:13:24 --> Pagination Class Initialized
INFO - 2024-02-29 04:13:24 --> Form Validation Class Initialized
INFO - 2024-02-29 04:13:24 --> Controller Class Initialized
DEBUG - 2024-02-29 04:13:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:13:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:24 --> Model Class Initialized
DEBUG - 2024-02-29 04:13:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:24 --> Model Class Initialized
INFO - 2024-02-29 04:13:24 --> Final output sent to browser
DEBUG - 2024-02-29 04:13:24 --> Total execution time: 0.0365
ERROR - 2024-02-29 04:13:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:13:24 --> Config Class Initialized
INFO - 2024-02-29 04:13:24 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:13:24 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:13:24 --> Utf8 Class Initialized
INFO - 2024-02-29 04:13:24 --> URI Class Initialized
INFO - 2024-02-29 04:13:24 --> Router Class Initialized
INFO - 2024-02-29 04:13:24 --> Output Class Initialized
INFO - 2024-02-29 04:13:24 --> Security Class Initialized
DEBUG - 2024-02-29 04:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:13:24 --> Input Class Initialized
INFO - 2024-02-29 04:13:24 --> Language Class Initialized
INFO - 2024-02-29 04:13:24 --> Loader Class Initialized
INFO - 2024-02-29 04:13:24 --> Helper loaded: url_helper
INFO - 2024-02-29 04:13:24 --> Helper loaded: file_helper
INFO - 2024-02-29 04:13:24 --> Helper loaded: html_helper
INFO - 2024-02-29 04:13:24 --> Helper loaded: text_helper
INFO - 2024-02-29 04:13:24 --> Helper loaded: form_helper
INFO - 2024-02-29 04:13:24 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:13:24 --> Helper loaded: security_helper
INFO - 2024-02-29 04:13:24 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:13:24 --> Database Driver Class Initialized
INFO - 2024-02-29 04:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:13:24 --> Parser Class Initialized
INFO - 2024-02-29 04:13:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:13:24 --> Pagination Class Initialized
INFO - 2024-02-29 04:13:24 --> Form Validation Class Initialized
INFO - 2024-02-29 04:13:24 --> Controller Class Initialized
DEBUG - 2024-02-29 04:13:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:13:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:24 --> Model Class Initialized
DEBUG - 2024-02-29 04:13:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:24 --> Model Class Initialized
INFO - 2024-02-29 04:13:25 --> Final output sent to browser
DEBUG - 2024-02-29 04:13:25 --> Total execution time: 0.0332
ERROR - 2024-02-29 04:13:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:13:25 --> Config Class Initialized
INFO - 2024-02-29 04:13:25 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:13:25 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:13:25 --> Utf8 Class Initialized
INFO - 2024-02-29 04:13:25 --> URI Class Initialized
INFO - 2024-02-29 04:13:25 --> Router Class Initialized
INFO - 2024-02-29 04:13:25 --> Output Class Initialized
INFO - 2024-02-29 04:13:25 --> Security Class Initialized
DEBUG - 2024-02-29 04:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:13:25 --> Input Class Initialized
INFO - 2024-02-29 04:13:25 --> Language Class Initialized
INFO - 2024-02-29 04:13:25 --> Loader Class Initialized
INFO - 2024-02-29 04:13:25 --> Helper loaded: url_helper
INFO - 2024-02-29 04:13:25 --> Helper loaded: file_helper
INFO - 2024-02-29 04:13:25 --> Helper loaded: html_helper
INFO - 2024-02-29 04:13:25 --> Helper loaded: text_helper
INFO - 2024-02-29 04:13:25 --> Helper loaded: form_helper
INFO - 2024-02-29 04:13:25 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:13:25 --> Helper loaded: security_helper
INFO - 2024-02-29 04:13:25 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:13:25 --> Database Driver Class Initialized
INFO - 2024-02-29 04:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:13:25 --> Parser Class Initialized
INFO - 2024-02-29 04:13:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:13:25 --> Pagination Class Initialized
INFO - 2024-02-29 04:13:25 --> Form Validation Class Initialized
INFO - 2024-02-29 04:13:25 --> Controller Class Initialized
DEBUG - 2024-02-29 04:13:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:13:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:25 --> Model Class Initialized
DEBUG - 2024-02-29 04:13:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:25 --> Model Class Initialized
INFO - 2024-02-29 04:13:25 --> Final output sent to browser
DEBUG - 2024-02-29 04:13:25 --> Total execution time: 0.0205
ERROR - 2024-02-29 04:13:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:13:25 --> Config Class Initialized
INFO - 2024-02-29 04:13:25 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:13:25 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:13:25 --> Utf8 Class Initialized
INFO - 2024-02-29 04:13:25 --> URI Class Initialized
INFO - 2024-02-29 04:13:25 --> Router Class Initialized
INFO - 2024-02-29 04:13:25 --> Output Class Initialized
INFO - 2024-02-29 04:13:25 --> Security Class Initialized
DEBUG - 2024-02-29 04:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:13:25 --> Input Class Initialized
INFO - 2024-02-29 04:13:25 --> Language Class Initialized
INFO - 2024-02-29 04:13:25 --> Loader Class Initialized
INFO - 2024-02-29 04:13:25 --> Helper loaded: url_helper
INFO - 2024-02-29 04:13:25 --> Helper loaded: file_helper
INFO - 2024-02-29 04:13:25 --> Helper loaded: html_helper
INFO - 2024-02-29 04:13:25 --> Helper loaded: text_helper
INFO - 2024-02-29 04:13:25 --> Helper loaded: form_helper
INFO - 2024-02-29 04:13:25 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:13:25 --> Helper loaded: security_helper
INFO - 2024-02-29 04:13:25 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:13:25 --> Database Driver Class Initialized
INFO - 2024-02-29 04:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:13:25 --> Parser Class Initialized
INFO - 2024-02-29 04:13:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:13:25 --> Pagination Class Initialized
INFO - 2024-02-29 04:13:25 --> Form Validation Class Initialized
INFO - 2024-02-29 04:13:25 --> Controller Class Initialized
DEBUG - 2024-02-29 04:13:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:13:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:25 --> Model Class Initialized
DEBUG - 2024-02-29 04:13:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:25 --> Model Class Initialized
INFO - 2024-02-29 04:13:25 --> Final output sent to browser
DEBUG - 2024-02-29 04:13:25 --> Total execution time: 0.0175
ERROR - 2024-02-29 04:13:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:13:30 --> Config Class Initialized
INFO - 2024-02-29 04:13:30 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:13:30 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:13:30 --> Utf8 Class Initialized
INFO - 2024-02-29 04:13:30 --> URI Class Initialized
INFO - 2024-02-29 04:13:30 --> Router Class Initialized
INFO - 2024-02-29 04:13:30 --> Output Class Initialized
INFO - 2024-02-29 04:13:30 --> Security Class Initialized
DEBUG - 2024-02-29 04:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:13:30 --> Input Class Initialized
INFO - 2024-02-29 04:13:30 --> Language Class Initialized
INFO - 2024-02-29 04:13:30 --> Loader Class Initialized
INFO - 2024-02-29 04:13:30 --> Helper loaded: url_helper
INFO - 2024-02-29 04:13:30 --> Helper loaded: file_helper
INFO - 2024-02-29 04:13:30 --> Helper loaded: html_helper
INFO - 2024-02-29 04:13:30 --> Helper loaded: text_helper
INFO - 2024-02-29 04:13:30 --> Helper loaded: form_helper
INFO - 2024-02-29 04:13:30 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:13:30 --> Helper loaded: security_helper
INFO - 2024-02-29 04:13:30 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:13:30 --> Database Driver Class Initialized
INFO - 2024-02-29 04:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:13:30 --> Parser Class Initialized
INFO - 2024-02-29 04:13:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:13:30 --> Pagination Class Initialized
INFO - 2024-02-29 04:13:30 --> Form Validation Class Initialized
INFO - 2024-02-29 04:13:30 --> Controller Class Initialized
DEBUG - 2024-02-29 04:13:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:13:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:30 --> Model Class Initialized
DEBUG - 2024-02-29 04:13:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:30 --> Model Class Initialized
INFO - 2024-02-29 04:13:30 --> Final output sent to browser
DEBUG - 2024-02-29 04:13:30 --> Total execution time: 0.0179
ERROR - 2024-02-29 04:13:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:13:30 --> Config Class Initialized
INFO - 2024-02-29 04:13:30 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:13:30 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:13:30 --> Utf8 Class Initialized
INFO - 2024-02-29 04:13:30 --> URI Class Initialized
INFO - 2024-02-29 04:13:30 --> Router Class Initialized
INFO - 2024-02-29 04:13:30 --> Output Class Initialized
INFO - 2024-02-29 04:13:30 --> Security Class Initialized
DEBUG - 2024-02-29 04:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:13:30 --> Input Class Initialized
INFO - 2024-02-29 04:13:30 --> Language Class Initialized
INFO - 2024-02-29 04:13:30 --> Loader Class Initialized
INFO - 2024-02-29 04:13:30 --> Helper loaded: url_helper
INFO - 2024-02-29 04:13:30 --> Helper loaded: file_helper
INFO - 2024-02-29 04:13:30 --> Helper loaded: html_helper
INFO - 2024-02-29 04:13:30 --> Helper loaded: text_helper
INFO - 2024-02-29 04:13:30 --> Helper loaded: form_helper
INFO - 2024-02-29 04:13:30 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:13:30 --> Helper loaded: security_helper
INFO - 2024-02-29 04:13:30 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:13:30 --> Database Driver Class Initialized
INFO - 2024-02-29 04:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:13:30 --> Parser Class Initialized
INFO - 2024-02-29 04:13:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:13:30 --> Pagination Class Initialized
INFO - 2024-02-29 04:13:30 --> Form Validation Class Initialized
INFO - 2024-02-29 04:13:30 --> Controller Class Initialized
DEBUG - 2024-02-29 04:13:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:13:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:30 --> Model Class Initialized
DEBUG - 2024-02-29 04:13:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:30 --> Model Class Initialized
INFO - 2024-02-29 04:13:30 --> Final output sent to browser
DEBUG - 2024-02-29 04:13:30 --> Total execution time: 0.0308
ERROR - 2024-02-29 04:13:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:13:33 --> Config Class Initialized
INFO - 2024-02-29 04:13:33 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:13:33 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:13:33 --> Utf8 Class Initialized
INFO - 2024-02-29 04:13:33 --> URI Class Initialized
INFO - 2024-02-29 04:13:33 --> Router Class Initialized
INFO - 2024-02-29 04:13:33 --> Output Class Initialized
INFO - 2024-02-29 04:13:33 --> Security Class Initialized
DEBUG - 2024-02-29 04:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:13:33 --> Input Class Initialized
INFO - 2024-02-29 04:13:33 --> Language Class Initialized
INFO - 2024-02-29 04:13:33 --> Loader Class Initialized
INFO - 2024-02-29 04:13:33 --> Helper loaded: url_helper
INFO - 2024-02-29 04:13:33 --> Helper loaded: file_helper
INFO - 2024-02-29 04:13:33 --> Helper loaded: html_helper
INFO - 2024-02-29 04:13:33 --> Helper loaded: text_helper
INFO - 2024-02-29 04:13:33 --> Helper loaded: form_helper
INFO - 2024-02-29 04:13:33 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:13:33 --> Helper loaded: security_helper
INFO - 2024-02-29 04:13:33 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:13:33 --> Database Driver Class Initialized
INFO - 2024-02-29 04:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:13:33 --> Parser Class Initialized
INFO - 2024-02-29 04:13:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:13:33 --> Pagination Class Initialized
INFO - 2024-02-29 04:13:33 --> Form Validation Class Initialized
INFO - 2024-02-29 04:13:33 --> Controller Class Initialized
DEBUG - 2024-02-29 04:13:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:13:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:33 --> Model Class Initialized
DEBUG - 2024-02-29 04:13:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:33 --> Model Class Initialized
INFO - 2024-02-29 04:13:33 --> Final output sent to browser
DEBUG - 2024-02-29 04:13:33 --> Total execution time: 0.0336
ERROR - 2024-02-29 04:13:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:13:35 --> Config Class Initialized
INFO - 2024-02-29 04:13:35 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:13:35 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:13:35 --> Utf8 Class Initialized
INFO - 2024-02-29 04:13:35 --> URI Class Initialized
INFO - 2024-02-29 04:13:35 --> Router Class Initialized
INFO - 2024-02-29 04:13:35 --> Output Class Initialized
INFO - 2024-02-29 04:13:35 --> Security Class Initialized
DEBUG - 2024-02-29 04:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:13:35 --> Input Class Initialized
INFO - 2024-02-29 04:13:35 --> Language Class Initialized
INFO - 2024-02-29 04:13:35 --> Loader Class Initialized
INFO - 2024-02-29 04:13:35 --> Helper loaded: url_helper
INFO - 2024-02-29 04:13:35 --> Helper loaded: file_helper
INFO - 2024-02-29 04:13:35 --> Helper loaded: html_helper
INFO - 2024-02-29 04:13:35 --> Helper loaded: text_helper
INFO - 2024-02-29 04:13:35 --> Helper loaded: form_helper
INFO - 2024-02-29 04:13:35 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:13:35 --> Helper loaded: security_helper
INFO - 2024-02-29 04:13:35 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:13:35 --> Database Driver Class Initialized
INFO - 2024-02-29 04:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:13:35 --> Parser Class Initialized
INFO - 2024-02-29 04:13:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:13:35 --> Pagination Class Initialized
INFO - 2024-02-29 04:13:35 --> Form Validation Class Initialized
INFO - 2024-02-29 04:13:35 --> Controller Class Initialized
DEBUG - 2024-02-29 04:13:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:13:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:35 --> Model Class Initialized
DEBUG - 2024-02-29 04:13:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:35 --> Model Class Initialized
INFO - 2024-02-29 04:13:35 --> Final output sent to browser
DEBUG - 2024-02-29 04:13:35 --> Total execution time: 0.0314
ERROR - 2024-02-29 04:13:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:13:35 --> Config Class Initialized
INFO - 2024-02-29 04:13:35 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:13:35 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:13:35 --> Utf8 Class Initialized
INFO - 2024-02-29 04:13:35 --> URI Class Initialized
INFO - 2024-02-29 04:13:35 --> Router Class Initialized
INFO - 2024-02-29 04:13:35 --> Output Class Initialized
INFO - 2024-02-29 04:13:35 --> Security Class Initialized
DEBUG - 2024-02-29 04:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:13:35 --> Input Class Initialized
INFO - 2024-02-29 04:13:35 --> Language Class Initialized
INFO - 2024-02-29 04:13:35 --> Loader Class Initialized
INFO - 2024-02-29 04:13:35 --> Helper loaded: url_helper
INFO - 2024-02-29 04:13:35 --> Helper loaded: file_helper
INFO - 2024-02-29 04:13:35 --> Helper loaded: html_helper
INFO - 2024-02-29 04:13:35 --> Helper loaded: text_helper
INFO - 2024-02-29 04:13:35 --> Helper loaded: form_helper
INFO - 2024-02-29 04:13:35 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:13:35 --> Helper loaded: security_helper
INFO - 2024-02-29 04:13:35 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:13:35 --> Database Driver Class Initialized
INFO - 2024-02-29 04:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:13:35 --> Parser Class Initialized
INFO - 2024-02-29 04:13:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:13:35 --> Pagination Class Initialized
INFO - 2024-02-29 04:13:35 --> Form Validation Class Initialized
INFO - 2024-02-29 04:13:35 --> Controller Class Initialized
DEBUG - 2024-02-29 04:13:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:13:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:35 --> Model Class Initialized
DEBUG - 2024-02-29 04:13:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:35 --> Model Class Initialized
INFO - 2024-02-29 04:13:35 --> Final output sent to browser
DEBUG - 2024-02-29 04:13:35 --> Total execution time: 0.0324
ERROR - 2024-02-29 04:13:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:13:38 --> Config Class Initialized
INFO - 2024-02-29 04:13:38 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:13:38 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:13:38 --> Utf8 Class Initialized
INFO - 2024-02-29 04:13:38 --> URI Class Initialized
INFO - 2024-02-29 04:13:38 --> Router Class Initialized
INFO - 2024-02-29 04:13:38 --> Output Class Initialized
INFO - 2024-02-29 04:13:38 --> Security Class Initialized
DEBUG - 2024-02-29 04:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:13:38 --> Input Class Initialized
INFO - 2024-02-29 04:13:38 --> Language Class Initialized
INFO - 2024-02-29 04:13:38 --> Loader Class Initialized
INFO - 2024-02-29 04:13:38 --> Helper loaded: url_helper
INFO - 2024-02-29 04:13:38 --> Helper loaded: file_helper
INFO - 2024-02-29 04:13:38 --> Helper loaded: html_helper
INFO - 2024-02-29 04:13:38 --> Helper loaded: text_helper
INFO - 2024-02-29 04:13:38 --> Helper loaded: form_helper
INFO - 2024-02-29 04:13:38 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:13:38 --> Helper loaded: security_helper
INFO - 2024-02-29 04:13:38 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:13:38 --> Database Driver Class Initialized
INFO - 2024-02-29 04:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:13:38 --> Parser Class Initialized
INFO - 2024-02-29 04:13:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:13:38 --> Pagination Class Initialized
INFO - 2024-02-29 04:13:38 --> Form Validation Class Initialized
INFO - 2024-02-29 04:13:38 --> Controller Class Initialized
DEBUG - 2024-02-29 04:13:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:13:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:38 --> Model Class Initialized
DEBUG - 2024-02-29 04:13:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:38 --> Model Class Initialized
INFO - 2024-02-29 04:13:38 --> Final output sent to browser
DEBUG - 2024-02-29 04:13:38 --> Total execution time: 0.0308
ERROR - 2024-02-29 04:13:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:13:38 --> Config Class Initialized
INFO - 2024-02-29 04:13:38 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:13:38 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:13:38 --> Utf8 Class Initialized
INFO - 2024-02-29 04:13:38 --> URI Class Initialized
INFO - 2024-02-29 04:13:38 --> Router Class Initialized
INFO - 2024-02-29 04:13:38 --> Output Class Initialized
INFO - 2024-02-29 04:13:38 --> Security Class Initialized
DEBUG - 2024-02-29 04:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:13:38 --> Input Class Initialized
INFO - 2024-02-29 04:13:38 --> Language Class Initialized
INFO - 2024-02-29 04:13:38 --> Loader Class Initialized
INFO - 2024-02-29 04:13:38 --> Helper loaded: url_helper
INFO - 2024-02-29 04:13:38 --> Helper loaded: file_helper
INFO - 2024-02-29 04:13:38 --> Helper loaded: html_helper
INFO - 2024-02-29 04:13:38 --> Helper loaded: text_helper
INFO - 2024-02-29 04:13:38 --> Helper loaded: form_helper
INFO - 2024-02-29 04:13:38 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:13:38 --> Helper loaded: security_helper
INFO - 2024-02-29 04:13:38 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:13:38 --> Database Driver Class Initialized
INFO - 2024-02-29 04:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:13:38 --> Parser Class Initialized
INFO - 2024-02-29 04:13:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:13:38 --> Pagination Class Initialized
INFO - 2024-02-29 04:13:38 --> Form Validation Class Initialized
INFO - 2024-02-29 04:13:38 --> Controller Class Initialized
DEBUG - 2024-02-29 04:13:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:13:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:38 --> Model Class Initialized
DEBUG - 2024-02-29 04:13:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:38 --> Model Class Initialized
INFO - 2024-02-29 04:13:38 --> Final output sent to browser
DEBUG - 2024-02-29 04:13:38 --> Total execution time: 0.0321
ERROR - 2024-02-29 04:13:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:13:39 --> Config Class Initialized
INFO - 2024-02-29 04:13:39 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:13:39 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:13:39 --> Utf8 Class Initialized
INFO - 2024-02-29 04:13:39 --> URI Class Initialized
INFO - 2024-02-29 04:13:39 --> Router Class Initialized
INFO - 2024-02-29 04:13:39 --> Output Class Initialized
INFO - 2024-02-29 04:13:39 --> Security Class Initialized
DEBUG - 2024-02-29 04:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:13:39 --> Input Class Initialized
INFO - 2024-02-29 04:13:39 --> Language Class Initialized
INFO - 2024-02-29 04:13:39 --> Loader Class Initialized
INFO - 2024-02-29 04:13:39 --> Helper loaded: url_helper
INFO - 2024-02-29 04:13:39 --> Helper loaded: file_helper
INFO - 2024-02-29 04:13:39 --> Helper loaded: html_helper
INFO - 2024-02-29 04:13:39 --> Helper loaded: text_helper
INFO - 2024-02-29 04:13:39 --> Helper loaded: form_helper
INFO - 2024-02-29 04:13:39 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:13:39 --> Helper loaded: security_helper
INFO - 2024-02-29 04:13:39 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:13:39 --> Database Driver Class Initialized
INFO - 2024-02-29 04:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:13:39 --> Parser Class Initialized
INFO - 2024-02-29 04:13:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:13:39 --> Pagination Class Initialized
INFO - 2024-02-29 04:13:39 --> Form Validation Class Initialized
INFO - 2024-02-29 04:13:39 --> Controller Class Initialized
DEBUG - 2024-02-29 04:13:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:13:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:39 --> Model Class Initialized
DEBUG - 2024-02-29 04:13:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:39 --> Model Class Initialized
INFO - 2024-02-29 04:13:39 --> Final output sent to browser
DEBUG - 2024-02-29 04:13:39 --> Total execution time: 0.0303
ERROR - 2024-02-29 04:13:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:13:40 --> Config Class Initialized
INFO - 2024-02-29 04:13:40 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:13:40 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:13:40 --> Utf8 Class Initialized
INFO - 2024-02-29 04:13:40 --> URI Class Initialized
INFO - 2024-02-29 04:13:40 --> Router Class Initialized
INFO - 2024-02-29 04:13:40 --> Output Class Initialized
INFO - 2024-02-29 04:13:40 --> Security Class Initialized
DEBUG - 2024-02-29 04:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:13:40 --> Input Class Initialized
INFO - 2024-02-29 04:13:40 --> Language Class Initialized
INFO - 2024-02-29 04:13:40 --> Loader Class Initialized
INFO - 2024-02-29 04:13:40 --> Helper loaded: url_helper
INFO - 2024-02-29 04:13:40 --> Helper loaded: file_helper
INFO - 2024-02-29 04:13:40 --> Helper loaded: html_helper
INFO - 2024-02-29 04:13:40 --> Helper loaded: text_helper
INFO - 2024-02-29 04:13:40 --> Helper loaded: form_helper
INFO - 2024-02-29 04:13:40 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:13:40 --> Helper loaded: security_helper
INFO - 2024-02-29 04:13:40 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:13:40 --> Database Driver Class Initialized
INFO - 2024-02-29 04:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:13:40 --> Parser Class Initialized
INFO - 2024-02-29 04:13:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:13:40 --> Pagination Class Initialized
INFO - 2024-02-29 04:13:40 --> Form Validation Class Initialized
INFO - 2024-02-29 04:13:40 --> Controller Class Initialized
DEBUG - 2024-02-29 04:13:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:13:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:40 --> Model Class Initialized
DEBUG - 2024-02-29 04:13:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:40 --> Model Class Initialized
INFO - 2024-02-29 04:13:40 --> Final output sent to browser
DEBUG - 2024-02-29 04:13:40 --> Total execution time: 0.0391
ERROR - 2024-02-29 04:13:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:13:40 --> Config Class Initialized
INFO - 2024-02-29 04:13:40 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:13:40 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:13:40 --> Utf8 Class Initialized
INFO - 2024-02-29 04:13:40 --> URI Class Initialized
INFO - 2024-02-29 04:13:40 --> Router Class Initialized
INFO - 2024-02-29 04:13:40 --> Output Class Initialized
INFO - 2024-02-29 04:13:40 --> Security Class Initialized
DEBUG - 2024-02-29 04:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:13:40 --> Input Class Initialized
INFO - 2024-02-29 04:13:40 --> Language Class Initialized
INFO - 2024-02-29 04:13:40 --> Loader Class Initialized
INFO - 2024-02-29 04:13:40 --> Helper loaded: url_helper
INFO - 2024-02-29 04:13:40 --> Helper loaded: file_helper
INFO - 2024-02-29 04:13:40 --> Helper loaded: html_helper
INFO - 2024-02-29 04:13:40 --> Helper loaded: text_helper
INFO - 2024-02-29 04:13:40 --> Helper loaded: form_helper
INFO - 2024-02-29 04:13:40 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:13:40 --> Helper loaded: security_helper
INFO - 2024-02-29 04:13:40 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:13:40 --> Database Driver Class Initialized
INFO - 2024-02-29 04:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:13:40 --> Parser Class Initialized
INFO - 2024-02-29 04:13:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:13:40 --> Pagination Class Initialized
INFO - 2024-02-29 04:13:40 --> Form Validation Class Initialized
INFO - 2024-02-29 04:13:40 --> Controller Class Initialized
DEBUG - 2024-02-29 04:13:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:13:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:40 --> Model Class Initialized
DEBUG - 2024-02-29 04:13:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:40 --> Model Class Initialized
INFO - 2024-02-29 04:13:41 --> Final output sent to browser
DEBUG - 2024-02-29 04:13:41 --> Total execution time: 0.0280
ERROR - 2024-02-29 04:13:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:13:47 --> Config Class Initialized
INFO - 2024-02-29 04:13:47 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:13:47 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:13:47 --> Utf8 Class Initialized
INFO - 2024-02-29 04:13:47 --> URI Class Initialized
INFO - 2024-02-29 04:13:47 --> Router Class Initialized
INFO - 2024-02-29 04:13:47 --> Output Class Initialized
INFO - 2024-02-29 04:13:47 --> Security Class Initialized
DEBUG - 2024-02-29 04:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:13:47 --> Input Class Initialized
INFO - 2024-02-29 04:13:47 --> Language Class Initialized
INFO - 2024-02-29 04:13:47 --> Loader Class Initialized
INFO - 2024-02-29 04:13:47 --> Helper loaded: url_helper
INFO - 2024-02-29 04:13:47 --> Helper loaded: file_helper
INFO - 2024-02-29 04:13:47 --> Helper loaded: html_helper
INFO - 2024-02-29 04:13:47 --> Helper loaded: text_helper
INFO - 2024-02-29 04:13:47 --> Helper loaded: form_helper
INFO - 2024-02-29 04:13:47 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:13:47 --> Helper loaded: security_helper
INFO - 2024-02-29 04:13:47 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:13:47 --> Database Driver Class Initialized
INFO - 2024-02-29 04:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:13:47 --> Parser Class Initialized
INFO - 2024-02-29 04:13:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:13:47 --> Pagination Class Initialized
INFO - 2024-02-29 04:13:47 --> Form Validation Class Initialized
INFO - 2024-02-29 04:13:47 --> Controller Class Initialized
DEBUG - 2024-02-29 04:13:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:13:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:47 --> Model Class Initialized
DEBUG - 2024-02-29 04:13:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:47 --> Model Class Initialized
INFO - 2024-02-29 04:13:47 --> Final output sent to browser
DEBUG - 2024-02-29 04:13:47 --> Total execution time: 0.0156
ERROR - 2024-02-29 04:13:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:13:50 --> Config Class Initialized
INFO - 2024-02-29 04:13:50 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:13:50 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:13:50 --> Utf8 Class Initialized
INFO - 2024-02-29 04:13:50 --> URI Class Initialized
INFO - 2024-02-29 04:13:50 --> Router Class Initialized
INFO - 2024-02-29 04:13:50 --> Output Class Initialized
INFO - 2024-02-29 04:13:50 --> Security Class Initialized
DEBUG - 2024-02-29 04:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:13:50 --> Input Class Initialized
INFO - 2024-02-29 04:13:50 --> Language Class Initialized
INFO - 2024-02-29 04:13:50 --> Loader Class Initialized
INFO - 2024-02-29 04:13:50 --> Helper loaded: url_helper
INFO - 2024-02-29 04:13:50 --> Helper loaded: file_helper
INFO - 2024-02-29 04:13:50 --> Helper loaded: html_helper
INFO - 2024-02-29 04:13:50 --> Helper loaded: text_helper
INFO - 2024-02-29 04:13:50 --> Helper loaded: form_helper
INFO - 2024-02-29 04:13:50 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:13:50 --> Helper loaded: security_helper
INFO - 2024-02-29 04:13:50 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:13:50 --> Database Driver Class Initialized
INFO - 2024-02-29 04:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:13:50 --> Parser Class Initialized
INFO - 2024-02-29 04:13:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:13:50 --> Pagination Class Initialized
INFO - 2024-02-29 04:13:50 --> Form Validation Class Initialized
INFO - 2024-02-29 04:13:50 --> Controller Class Initialized
DEBUG - 2024-02-29 04:13:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:13:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:50 --> Model Class Initialized
DEBUG - 2024-02-29 04:13:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:50 --> Model Class Initialized
DEBUG - 2024-02-29 04:13:50 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:50 --> Model Class Initialized
INFO - 2024-02-29 04:13:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-29 04:13:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:13:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:13:50 --> Model Class Initialized
INFO - 2024-02-29 04:13:50 --> Model Class Initialized
INFO - 2024-02-29 04:13:50 --> Model Class Initialized
INFO - 2024-02-29 04:13:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 04:13:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 04:13:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:13:50 --> Final output sent to browser
DEBUG - 2024-02-29 04:13:50 --> Total execution time: 0.2302
ERROR - 2024-02-29 04:13:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:13:52 --> Config Class Initialized
INFO - 2024-02-29 04:13:52 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:13:52 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:13:52 --> Utf8 Class Initialized
INFO - 2024-02-29 04:13:52 --> URI Class Initialized
INFO - 2024-02-29 04:13:52 --> Router Class Initialized
INFO - 2024-02-29 04:13:52 --> Output Class Initialized
INFO - 2024-02-29 04:13:52 --> Security Class Initialized
DEBUG - 2024-02-29 04:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:13:52 --> Input Class Initialized
INFO - 2024-02-29 04:13:52 --> Language Class Initialized
INFO - 2024-02-29 04:13:52 --> Loader Class Initialized
INFO - 2024-02-29 04:13:52 --> Helper loaded: url_helper
INFO - 2024-02-29 04:13:52 --> Helper loaded: file_helper
INFO - 2024-02-29 04:13:52 --> Helper loaded: html_helper
INFO - 2024-02-29 04:13:52 --> Helper loaded: text_helper
INFO - 2024-02-29 04:13:52 --> Helper loaded: form_helper
INFO - 2024-02-29 04:13:52 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:13:52 --> Helper loaded: security_helper
INFO - 2024-02-29 04:13:52 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:13:52 --> Database Driver Class Initialized
INFO - 2024-02-29 04:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:13:52 --> Parser Class Initialized
INFO - 2024-02-29 04:13:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:13:52 --> Pagination Class Initialized
INFO - 2024-02-29 04:13:52 --> Form Validation Class Initialized
INFO - 2024-02-29 04:13:52 --> Controller Class Initialized
DEBUG - 2024-02-29 04:13:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:13:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:52 --> Model Class Initialized
DEBUG - 2024-02-29 04:13:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:13:52 --> Model Class Initialized
INFO - 2024-02-29 04:13:52 --> Final output sent to browser
DEBUG - 2024-02-29 04:13:52 --> Total execution time: 0.0313
ERROR - 2024-02-29 04:16:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:16:52 --> Config Class Initialized
INFO - 2024-02-29 04:16:52 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:16:52 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:16:52 --> Utf8 Class Initialized
INFO - 2024-02-29 04:16:52 --> URI Class Initialized
INFO - 2024-02-29 04:16:52 --> Router Class Initialized
INFO - 2024-02-29 04:16:52 --> Output Class Initialized
INFO - 2024-02-29 04:16:52 --> Security Class Initialized
DEBUG - 2024-02-29 04:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:16:52 --> Input Class Initialized
INFO - 2024-02-29 04:16:52 --> Language Class Initialized
INFO - 2024-02-29 04:16:52 --> Loader Class Initialized
INFO - 2024-02-29 04:16:52 --> Helper loaded: url_helper
INFO - 2024-02-29 04:16:52 --> Helper loaded: file_helper
INFO - 2024-02-29 04:16:52 --> Helper loaded: html_helper
INFO - 2024-02-29 04:16:52 --> Helper loaded: text_helper
INFO - 2024-02-29 04:16:52 --> Helper loaded: form_helper
INFO - 2024-02-29 04:16:52 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:16:52 --> Helper loaded: security_helper
INFO - 2024-02-29 04:16:52 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:16:52 --> Database Driver Class Initialized
INFO - 2024-02-29 04:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:16:52 --> Parser Class Initialized
INFO - 2024-02-29 04:16:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:16:52 --> Pagination Class Initialized
INFO - 2024-02-29 04:16:52 --> Form Validation Class Initialized
INFO - 2024-02-29 04:16:52 --> Controller Class Initialized
DEBUG - 2024-02-29 04:16:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:16:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:16:52 --> Model Class Initialized
DEBUG - 2024-02-29 04:16:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:16:52 --> Model Class Initialized
INFO - 2024-02-29 04:16:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-02-29 04:16:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:16:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:16:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:16:53 --> Model Class Initialized
INFO - 2024-02-29 04:16:53 --> Model Class Initialized
INFO - 2024-02-29 04:16:53 --> Model Class Initialized
INFO - 2024-02-29 04:16:53 --> Model Class Initialized
INFO - 2024-02-29 04:16:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 04:16:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 04:16:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:16:53 --> Final output sent to browser
DEBUG - 2024-02-29 04:16:53 --> Total execution time: 0.1883
ERROR - 2024-02-29 04:16:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:16:54 --> Config Class Initialized
INFO - 2024-02-29 04:16:54 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:16:54 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:16:54 --> Utf8 Class Initialized
INFO - 2024-02-29 04:16:54 --> URI Class Initialized
DEBUG - 2024-02-29 04:16:54 --> No URI present. Default controller set.
INFO - 2024-02-29 04:16:54 --> Router Class Initialized
INFO - 2024-02-29 04:16:54 --> Output Class Initialized
INFO - 2024-02-29 04:16:54 --> Security Class Initialized
DEBUG - 2024-02-29 04:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:16:54 --> Input Class Initialized
INFO - 2024-02-29 04:16:54 --> Language Class Initialized
INFO - 2024-02-29 04:16:54 --> Loader Class Initialized
INFO - 2024-02-29 04:16:54 --> Helper loaded: url_helper
INFO - 2024-02-29 04:16:54 --> Helper loaded: file_helper
INFO - 2024-02-29 04:16:54 --> Helper loaded: html_helper
INFO - 2024-02-29 04:16:54 --> Helper loaded: text_helper
INFO - 2024-02-29 04:16:54 --> Helper loaded: form_helper
INFO - 2024-02-29 04:16:54 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:16:54 --> Helper loaded: security_helper
INFO - 2024-02-29 04:16:54 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:16:54 --> Database Driver Class Initialized
INFO - 2024-02-29 04:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:16:54 --> Parser Class Initialized
INFO - 2024-02-29 04:16:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:16:54 --> Pagination Class Initialized
INFO - 2024-02-29 04:16:54 --> Form Validation Class Initialized
INFO - 2024-02-29 04:16:54 --> Controller Class Initialized
INFO - 2024-02-29 04:16:54 --> Model Class Initialized
DEBUG - 2024-02-29 04:16:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:16:54 --> Model Class Initialized
DEBUG - 2024-02-29 04:16:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:16:54 --> Model Class Initialized
INFO - 2024-02-29 04:16:54 --> Model Class Initialized
INFO - 2024-02-29 04:16:54 --> Model Class Initialized
INFO - 2024-02-29 04:16:54 --> Model Class Initialized
DEBUG - 2024-02-29 04:16:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:16:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:16:54 --> Model Class Initialized
INFO - 2024-02-29 04:16:54 --> Model Class Initialized
INFO - 2024-02-29 04:16:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 04:16:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:16:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:16:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:16:54 --> Model Class Initialized
INFO - 2024-02-29 04:16:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 04:16:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 04:16:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:16:54 --> Final output sent to browser
DEBUG - 2024-02-29 04:16:54 --> Total execution time: 0.2355
ERROR - 2024-02-29 04:17:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:17:06 --> Config Class Initialized
INFO - 2024-02-29 04:17:06 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:17:06 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:17:06 --> Utf8 Class Initialized
INFO - 2024-02-29 04:17:06 --> URI Class Initialized
INFO - 2024-02-29 04:17:06 --> Router Class Initialized
INFO - 2024-02-29 04:17:06 --> Output Class Initialized
INFO - 2024-02-29 04:17:06 --> Security Class Initialized
DEBUG - 2024-02-29 04:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:17:06 --> Input Class Initialized
INFO - 2024-02-29 04:17:06 --> Language Class Initialized
INFO - 2024-02-29 04:17:06 --> Loader Class Initialized
INFO - 2024-02-29 04:17:06 --> Helper loaded: url_helper
INFO - 2024-02-29 04:17:06 --> Helper loaded: file_helper
INFO - 2024-02-29 04:17:06 --> Helper loaded: html_helper
INFO - 2024-02-29 04:17:06 --> Helper loaded: text_helper
INFO - 2024-02-29 04:17:06 --> Helper loaded: form_helper
INFO - 2024-02-29 04:17:06 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:17:06 --> Helper loaded: security_helper
INFO - 2024-02-29 04:17:06 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:17:06 --> Database Driver Class Initialized
INFO - 2024-02-29 04:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:17:06 --> Parser Class Initialized
INFO - 2024-02-29 04:17:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:17:06 --> Pagination Class Initialized
INFO - 2024-02-29 04:17:06 --> Form Validation Class Initialized
INFO - 2024-02-29 04:17:06 --> Controller Class Initialized
INFO - 2024-02-29 04:17:06 --> Model Class Initialized
DEBUG - 2024-02-29 04:17:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:17:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:17:06 --> Model Class Initialized
DEBUG - 2024-02-29 04:17:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:17:06 --> Model Class Initialized
INFO - 2024-02-29 04:17:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-29 04:17:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:17:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:17:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:17:07 --> Model Class Initialized
INFO - 2024-02-29 04:17:07 --> Model Class Initialized
INFO - 2024-02-29 04:17:07 --> Model Class Initialized
INFO - 2024-02-29 04:17:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 04:17:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 04:17:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:17:07 --> Final output sent to browser
DEBUG - 2024-02-29 04:17:07 --> Total execution time: 0.1870
ERROR - 2024-02-29 04:33:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:33:32 --> Config Class Initialized
INFO - 2024-02-29 04:33:32 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:33:32 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:33:32 --> Utf8 Class Initialized
INFO - 2024-02-29 04:33:32 --> URI Class Initialized
DEBUG - 2024-02-29 04:33:32 --> No URI present. Default controller set.
INFO - 2024-02-29 04:33:32 --> Router Class Initialized
INFO - 2024-02-29 04:33:32 --> Output Class Initialized
INFO - 2024-02-29 04:33:32 --> Security Class Initialized
DEBUG - 2024-02-29 04:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:33:32 --> Input Class Initialized
INFO - 2024-02-29 04:33:32 --> Language Class Initialized
INFO - 2024-02-29 04:33:32 --> Loader Class Initialized
INFO - 2024-02-29 04:33:32 --> Helper loaded: url_helper
INFO - 2024-02-29 04:33:32 --> Helper loaded: file_helper
INFO - 2024-02-29 04:33:32 --> Helper loaded: html_helper
INFO - 2024-02-29 04:33:32 --> Helper loaded: text_helper
INFO - 2024-02-29 04:33:32 --> Helper loaded: form_helper
INFO - 2024-02-29 04:33:32 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:33:32 --> Helper loaded: security_helper
INFO - 2024-02-29 04:33:32 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:33:32 --> Database Driver Class Initialized
INFO - 2024-02-29 04:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:33:32 --> Parser Class Initialized
INFO - 2024-02-29 04:33:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:33:32 --> Pagination Class Initialized
INFO - 2024-02-29 04:33:32 --> Form Validation Class Initialized
INFO - 2024-02-29 04:33:32 --> Controller Class Initialized
INFO - 2024-02-29 04:33:32 --> Model Class Initialized
DEBUG - 2024-02-29 04:33:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:33:32 --> Model Class Initialized
DEBUG - 2024-02-29 04:33:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:33:32 --> Model Class Initialized
INFO - 2024-02-29 04:33:32 --> Model Class Initialized
INFO - 2024-02-29 04:33:32 --> Model Class Initialized
INFO - 2024-02-29 04:33:32 --> Model Class Initialized
DEBUG - 2024-02-29 04:33:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:33:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:33:32 --> Model Class Initialized
INFO - 2024-02-29 04:33:32 --> Model Class Initialized
INFO - 2024-02-29 04:33:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 04:33:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:33:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:33:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:33:32 --> Model Class Initialized
INFO - 2024-02-29 04:33:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 04:33:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 04:33:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:33:32 --> Final output sent to browser
DEBUG - 2024-02-29 04:33:32 --> Total execution time: 0.2406
ERROR - 2024-02-29 04:33:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:33:35 --> Config Class Initialized
INFO - 2024-02-29 04:33:35 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:33:35 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:33:35 --> Utf8 Class Initialized
INFO - 2024-02-29 04:33:35 --> URI Class Initialized
INFO - 2024-02-29 04:33:35 --> Router Class Initialized
INFO - 2024-02-29 04:33:35 --> Output Class Initialized
INFO - 2024-02-29 04:33:35 --> Security Class Initialized
DEBUG - 2024-02-29 04:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:33:35 --> Input Class Initialized
INFO - 2024-02-29 04:33:35 --> Language Class Initialized
INFO - 2024-02-29 04:33:35 --> Loader Class Initialized
INFO - 2024-02-29 04:33:35 --> Helper loaded: url_helper
INFO - 2024-02-29 04:33:35 --> Helper loaded: file_helper
INFO - 2024-02-29 04:33:35 --> Helper loaded: html_helper
INFO - 2024-02-29 04:33:35 --> Helper loaded: text_helper
INFO - 2024-02-29 04:33:35 --> Helper loaded: form_helper
INFO - 2024-02-29 04:33:35 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:33:35 --> Helper loaded: security_helper
INFO - 2024-02-29 04:33:35 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:33:35 --> Database Driver Class Initialized
INFO - 2024-02-29 04:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:33:35 --> Parser Class Initialized
INFO - 2024-02-29 04:33:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:33:35 --> Pagination Class Initialized
INFO - 2024-02-29 04:33:35 --> Form Validation Class Initialized
INFO - 2024-02-29 04:33:35 --> Controller Class Initialized
DEBUG - 2024-02-29 04:33:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:33:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:33:35 --> Model Class Initialized
DEBUG - 2024-02-29 04:33:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:33:35 --> Model Class Initialized
DEBUG - 2024-02-29 04:33:35 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:33:35 --> Model Class Initialized
INFO - 2024-02-29 04:33:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-29 04:33:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:33:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:33:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:33:35 --> Model Class Initialized
INFO - 2024-02-29 04:33:35 --> Model Class Initialized
INFO - 2024-02-29 04:33:35 --> Model Class Initialized
INFO - 2024-02-29 04:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 04:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 04:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:33:36 --> Final output sent to browser
DEBUG - 2024-02-29 04:33:36 --> Total execution time: 0.1523
ERROR - 2024-02-29 04:33:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:33:37 --> Config Class Initialized
INFO - 2024-02-29 04:33:37 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:33:37 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:33:37 --> Utf8 Class Initialized
INFO - 2024-02-29 04:33:37 --> URI Class Initialized
INFO - 2024-02-29 04:33:37 --> Router Class Initialized
INFO - 2024-02-29 04:33:37 --> Output Class Initialized
INFO - 2024-02-29 04:33:37 --> Security Class Initialized
DEBUG - 2024-02-29 04:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:33:37 --> Input Class Initialized
INFO - 2024-02-29 04:33:37 --> Language Class Initialized
INFO - 2024-02-29 04:33:37 --> Loader Class Initialized
INFO - 2024-02-29 04:33:37 --> Helper loaded: url_helper
INFO - 2024-02-29 04:33:37 --> Helper loaded: file_helper
INFO - 2024-02-29 04:33:37 --> Helper loaded: html_helper
INFO - 2024-02-29 04:33:37 --> Helper loaded: text_helper
INFO - 2024-02-29 04:33:37 --> Helper loaded: form_helper
INFO - 2024-02-29 04:33:37 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:33:37 --> Helper loaded: security_helper
INFO - 2024-02-29 04:33:37 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:33:37 --> Database Driver Class Initialized
INFO - 2024-02-29 04:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:33:37 --> Parser Class Initialized
INFO - 2024-02-29 04:33:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:33:37 --> Pagination Class Initialized
INFO - 2024-02-29 04:33:37 --> Form Validation Class Initialized
INFO - 2024-02-29 04:33:37 --> Controller Class Initialized
DEBUG - 2024-02-29 04:33:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:33:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:33:37 --> Model Class Initialized
DEBUG - 2024-02-29 04:33:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:33:37 --> Model Class Initialized
INFO - 2024-02-29 04:33:37 --> Final output sent to browser
DEBUG - 2024-02-29 04:33:37 --> Total execution time: 0.0228
ERROR - 2024-02-29 04:33:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:33:42 --> Config Class Initialized
INFO - 2024-02-29 04:33:42 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:33:42 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:33:42 --> Utf8 Class Initialized
INFO - 2024-02-29 04:33:42 --> URI Class Initialized
INFO - 2024-02-29 04:33:42 --> Router Class Initialized
INFO - 2024-02-29 04:33:42 --> Output Class Initialized
INFO - 2024-02-29 04:33:42 --> Security Class Initialized
DEBUG - 2024-02-29 04:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:33:42 --> Input Class Initialized
INFO - 2024-02-29 04:33:42 --> Language Class Initialized
INFO - 2024-02-29 04:33:42 --> Loader Class Initialized
INFO - 2024-02-29 04:33:42 --> Helper loaded: url_helper
INFO - 2024-02-29 04:33:42 --> Helper loaded: file_helper
INFO - 2024-02-29 04:33:42 --> Helper loaded: html_helper
INFO - 2024-02-29 04:33:42 --> Helper loaded: text_helper
INFO - 2024-02-29 04:33:42 --> Helper loaded: form_helper
INFO - 2024-02-29 04:33:42 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:33:42 --> Helper loaded: security_helper
INFO - 2024-02-29 04:33:42 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:33:42 --> Database Driver Class Initialized
INFO - 2024-02-29 04:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:33:42 --> Parser Class Initialized
INFO - 2024-02-29 04:33:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:33:42 --> Pagination Class Initialized
INFO - 2024-02-29 04:33:42 --> Form Validation Class Initialized
INFO - 2024-02-29 04:33:42 --> Controller Class Initialized
DEBUG - 2024-02-29 04:33:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:33:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:33:42 --> Model Class Initialized
DEBUG - 2024-02-29 04:33:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:33:42 --> Model Class Initialized
INFO - 2024-02-29 04:33:42 --> Final output sent to browser
DEBUG - 2024-02-29 04:33:42 --> Total execution time: 0.0362
ERROR - 2024-02-29 04:34:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:34:10 --> Config Class Initialized
INFO - 2024-02-29 04:34:10 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:34:10 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:34:10 --> Utf8 Class Initialized
INFO - 2024-02-29 04:34:10 --> URI Class Initialized
DEBUG - 2024-02-29 04:34:10 --> No URI present. Default controller set.
INFO - 2024-02-29 04:34:10 --> Router Class Initialized
INFO - 2024-02-29 04:34:10 --> Output Class Initialized
INFO - 2024-02-29 04:34:10 --> Security Class Initialized
DEBUG - 2024-02-29 04:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:34:10 --> Input Class Initialized
INFO - 2024-02-29 04:34:10 --> Language Class Initialized
INFO - 2024-02-29 04:34:10 --> Loader Class Initialized
INFO - 2024-02-29 04:34:10 --> Helper loaded: url_helper
INFO - 2024-02-29 04:34:10 --> Helper loaded: file_helper
INFO - 2024-02-29 04:34:10 --> Helper loaded: html_helper
INFO - 2024-02-29 04:34:10 --> Helper loaded: text_helper
INFO - 2024-02-29 04:34:10 --> Helper loaded: form_helper
INFO - 2024-02-29 04:34:10 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:34:10 --> Helper loaded: security_helper
INFO - 2024-02-29 04:34:10 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:34:10 --> Database Driver Class Initialized
INFO - 2024-02-29 04:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:34:10 --> Parser Class Initialized
INFO - 2024-02-29 04:34:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:34:10 --> Pagination Class Initialized
INFO - 2024-02-29 04:34:10 --> Form Validation Class Initialized
INFO - 2024-02-29 04:34:10 --> Controller Class Initialized
INFO - 2024-02-29 04:34:10 --> Model Class Initialized
DEBUG - 2024-02-29 04:34:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:34:10 --> Model Class Initialized
DEBUG - 2024-02-29 04:34:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:34:10 --> Model Class Initialized
INFO - 2024-02-29 04:34:10 --> Model Class Initialized
INFO - 2024-02-29 04:34:10 --> Model Class Initialized
INFO - 2024-02-29 04:34:10 --> Model Class Initialized
DEBUG - 2024-02-29 04:34:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:34:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:34:10 --> Model Class Initialized
INFO - 2024-02-29 04:34:10 --> Model Class Initialized
INFO - 2024-02-29 04:34:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 04:34:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:34:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:34:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:34:10 --> Model Class Initialized
INFO - 2024-02-29 04:34:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 04:34:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 04:34:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:34:10 --> Final output sent to browser
DEBUG - 2024-02-29 04:34:10 --> Total execution time: 0.2519
ERROR - 2024-02-29 04:34:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:34:13 --> Config Class Initialized
INFO - 2024-02-29 04:34:13 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:34:13 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:34:13 --> Utf8 Class Initialized
INFO - 2024-02-29 04:34:13 --> URI Class Initialized
DEBUG - 2024-02-29 04:34:13 --> No URI present. Default controller set.
INFO - 2024-02-29 04:34:13 --> Router Class Initialized
INFO - 2024-02-29 04:34:13 --> Output Class Initialized
INFO - 2024-02-29 04:34:13 --> Security Class Initialized
DEBUG - 2024-02-29 04:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:34:13 --> Input Class Initialized
INFO - 2024-02-29 04:34:13 --> Language Class Initialized
INFO - 2024-02-29 04:34:13 --> Loader Class Initialized
INFO - 2024-02-29 04:34:13 --> Helper loaded: url_helper
INFO - 2024-02-29 04:34:13 --> Helper loaded: file_helper
INFO - 2024-02-29 04:34:13 --> Helper loaded: html_helper
INFO - 2024-02-29 04:34:13 --> Helper loaded: text_helper
INFO - 2024-02-29 04:34:13 --> Helper loaded: form_helper
INFO - 2024-02-29 04:34:13 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:34:13 --> Helper loaded: security_helper
INFO - 2024-02-29 04:34:13 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:34:13 --> Database Driver Class Initialized
INFO - 2024-02-29 04:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:34:13 --> Parser Class Initialized
INFO - 2024-02-29 04:34:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:34:13 --> Pagination Class Initialized
INFO - 2024-02-29 04:34:13 --> Form Validation Class Initialized
INFO - 2024-02-29 04:34:13 --> Controller Class Initialized
INFO - 2024-02-29 04:34:13 --> Model Class Initialized
DEBUG - 2024-02-29 04:34:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:34:13 --> Model Class Initialized
DEBUG - 2024-02-29 04:34:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:34:13 --> Model Class Initialized
INFO - 2024-02-29 04:34:13 --> Model Class Initialized
INFO - 2024-02-29 04:34:13 --> Model Class Initialized
INFO - 2024-02-29 04:34:13 --> Model Class Initialized
DEBUG - 2024-02-29 04:34:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:34:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:34:13 --> Model Class Initialized
INFO - 2024-02-29 04:34:13 --> Model Class Initialized
INFO - 2024-02-29 04:34:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 04:34:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:34:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:34:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:34:13 --> Model Class Initialized
INFO - 2024-02-29 04:34:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 04:34:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 04:34:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:34:13 --> Final output sent to browser
DEBUG - 2024-02-29 04:34:13 --> Total execution time: 0.2366
ERROR - 2024-02-29 04:34:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:34:19 --> Config Class Initialized
INFO - 2024-02-29 04:34:19 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:34:19 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:34:19 --> Utf8 Class Initialized
INFO - 2024-02-29 04:34:19 --> URI Class Initialized
INFO - 2024-02-29 04:34:19 --> Router Class Initialized
INFO - 2024-02-29 04:34:19 --> Output Class Initialized
INFO - 2024-02-29 04:34:19 --> Security Class Initialized
DEBUG - 2024-02-29 04:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:34:19 --> Input Class Initialized
INFO - 2024-02-29 04:34:19 --> Language Class Initialized
INFO - 2024-02-29 04:34:19 --> Loader Class Initialized
INFO - 2024-02-29 04:34:19 --> Helper loaded: url_helper
INFO - 2024-02-29 04:34:19 --> Helper loaded: file_helper
INFO - 2024-02-29 04:34:19 --> Helper loaded: html_helper
INFO - 2024-02-29 04:34:19 --> Helper loaded: text_helper
INFO - 2024-02-29 04:34:19 --> Helper loaded: form_helper
INFO - 2024-02-29 04:34:19 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:34:19 --> Helper loaded: security_helper
INFO - 2024-02-29 04:34:19 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:34:19 --> Database Driver Class Initialized
INFO - 2024-02-29 04:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:34:19 --> Parser Class Initialized
INFO - 2024-02-29 04:34:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:34:19 --> Pagination Class Initialized
INFO - 2024-02-29 04:34:19 --> Form Validation Class Initialized
INFO - 2024-02-29 04:34:19 --> Controller Class Initialized
INFO - 2024-02-29 04:34:19 --> Model Class Initialized
DEBUG - 2024-02-29 04:34:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:34:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:34:19 --> Model Class Initialized
DEBUG - 2024-02-29 04:34:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:34:19 --> Model Class Initialized
INFO - 2024-02-29 04:34:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-29 04:34:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:34:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:34:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:34:19 --> Model Class Initialized
INFO - 2024-02-29 04:34:19 --> Model Class Initialized
INFO - 2024-02-29 04:34:19 --> Model Class Initialized
INFO - 2024-02-29 04:34:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 04:34:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 04:34:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:34:19 --> Final output sent to browser
DEBUG - 2024-02-29 04:34:19 --> Total execution time: 0.1833
ERROR - 2024-02-29 04:34:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:34:19 --> Config Class Initialized
INFO - 2024-02-29 04:34:19 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:34:19 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:34:19 --> Utf8 Class Initialized
INFO - 2024-02-29 04:34:19 --> URI Class Initialized
INFO - 2024-02-29 04:34:19 --> Router Class Initialized
INFO - 2024-02-29 04:34:19 --> Output Class Initialized
INFO - 2024-02-29 04:34:19 --> Security Class Initialized
DEBUG - 2024-02-29 04:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:34:19 --> Input Class Initialized
INFO - 2024-02-29 04:34:19 --> Language Class Initialized
INFO - 2024-02-29 04:34:19 --> Loader Class Initialized
INFO - 2024-02-29 04:34:19 --> Helper loaded: url_helper
INFO - 2024-02-29 04:34:19 --> Helper loaded: file_helper
INFO - 2024-02-29 04:34:19 --> Helper loaded: html_helper
INFO - 2024-02-29 04:34:19 --> Helper loaded: text_helper
INFO - 2024-02-29 04:34:19 --> Helper loaded: form_helper
INFO - 2024-02-29 04:34:19 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:34:19 --> Helper loaded: security_helper
INFO - 2024-02-29 04:34:19 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:34:19 --> Database Driver Class Initialized
INFO - 2024-02-29 04:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:34:19 --> Parser Class Initialized
INFO - 2024-02-29 04:34:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:34:19 --> Pagination Class Initialized
INFO - 2024-02-29 04:34:19 --> Form Validation Class Initialized
INFO - 2024-02-29 04:34:19 --> Controller Class Initialized
INFO - 2024-02-29 04:34:19 --> Model Class Initialized
DEBUG - 2024-02-29 04:34:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:34:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:34:19 --> Model Class Initialized
DEBUG - 2024-02-29 04:34:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:34:19 --> Model Class Initialized
INFO - 2024-02-29 04:34:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-29 04:34:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:34:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:34:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:34:19 --> Model Class Initialized
INFO - 2024-02-29 04:34:19 --> Model Class Initialized
INFO - 2024-02-29 04:34:19 --> Model Class Initialized
INFO - 2024-02-29 04:34:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 04:34:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 04:34:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:34:19 --> Final output sent to browser
DEBUG - 2024-02-29 04:34:19 --> Total execution time: 0.1876
ERROR - 2024-02-29 04:34:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:34:25 --> Config Class Initialized
INFO - 2024-02-29 04:34:25 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:34:25 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:34:25 --> Utf8 Class Initialized
INFO - 2024-02-29 04:34:25 --> URI Class Initialized
INFO - 2024-02-29 04:34:25 --> Router Class Initialized
INFO - 2024-02-29 04:34:25 --> Output Class Initialized
INFO - 2024-02-29 04:34:25 --> Security Class Initialized
DEBUG - 2024-02-29 04:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:34:25 --> Input Class Initialized
INFO - 2024-02-29 04:34:25 --> Language Class Initialized
INFO - 2024-02-29 04:34:25 --> Loader Class Initialized
INFO - 2024-02-29 04:34:25 --> Helper loaded: url_helper
INFO - 2024-02-29 04:34:25 --> Helper loaded: file_helper
INFO - 2024-02-29 04:34:25 --> Helper loaded: html_helper
INFO - 2024-02-29 04:34:25 --> Helper loaded: text_helper
INFO - 2024-02-29 04:34:25 --> Helper loaded: form_helper
INFO - 2024-02-29 04:34:25 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:34:25 --> Helper loaded: security_helper
INFO - 2024-02-29 04:34:25 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:34:25 --> Database Driver Class Initialized
INFO - 2024-02-29 04:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:34:25 --> Parser Class Initialized
INFO - 2024-02-29 04:34:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:34:25 --> Pagination Class Initialized
INFO - 2024-02-29 04:34:25 --> Form Validation Class Initialized
INFO - 2024-02-29 04:34:25 --> Controller Class Initialized
INFO - 2024-02-29 04:34:25 --> Model Class Initialized
DEBUG - 2024-02-29 04:34:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:34:25 --> Final output sent to browser
DEBUG - 2024-02-29 04:34:25 --> Total execution time: 0.0157
ERROR - 2024-02-29 04:34:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:34:26 --> Config Class Initialized
INFO - 2024-02-29 04:34:26 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:34:26 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:34:26 --> Utf8 Class Initialized
INFO - 2024-02-29 04:34:26 --> URI Class Initialized
INFO - 2024-02-29 04:34:26 --> Router Class Initialized
INFO - 2024-02-29 04:34:26 --> Output Class Initialized
INFO - 2024-02-29 04:34:26 --> Security Class Initialized
DEBUG - 2024-02-29 04:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:34:26 --> Input Class Initialized
INFO - 2024-02-29 04:34:26 --> Language Class Initialized
INFO - 2024-02-29 04:34:26 --> Loader Class Initialized
INFO - 2024-02-29 04:34:26 --> Helper loaded: url_helper
INFO - 2024-02-29 04:34:26 --> Helper loaded: file_helper
INFO - 2024-02-29 04:34:26 --> Helper loaded: html_helper
INFO - 2024-02-29 04:34:26 --> Helper loaded: text_helper
INFO - 2024-02-29 04:34:26 --> Helper loaded: form_helper
INFO - 2024-02-29 04:34:26 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:34:26 --> Helper loaded: security_helper
INFO - 2024-02-29 04:34:26 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:34:26 --> Database Driver Class Initialized
INFO - 2024-02-29 04:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:34:26 --> Parser Class Initialized
INFO - 2024-02-29 04:34:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:34:26 --> Pagination Class Initialized
INFO - 2024-02-29 04:34:26 --> Form Validation Class Initialized
INFO - 2024-02-29 04:34:26 --> Controller Class Initialized
INFO - 2024-02-29 04:34:26 --> Model Class Initialized
DEBUG - 2024-02-29 04:34:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:34:26 --> Final output sent to browser
DEBUG - 2024-02-29 04:34:26 --> Total execution time: 0.0143
ERROR - 2024-02-29 04:34:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:34:29 --> Config Class Initialized
INFO - 2024-02-29 04:34:29 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:34:29 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:34:29 --> Utf8 Class Initialized
INFO - 2024-02-29 04:34:29 --> URI Class Initialized
INFO - 2024-02-29 04:34:29 --> Router Class Initialized
INFO - 2024-02-29 04:34:29 --> Output Class Initialized
INFO - 2024-02-29 04:34:29 --> Security Class Initialized
DEBUG - 2024-02-29 04:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:34:29 --> Input Class Initialized
INFO - 2024-02-29 04:34:29 --> Language Class Initialized
INFO - 2024-02-29 04:34:29 --> Loader Class Initialized
INFO - 2024-02-29 04:34:29 --> Helper loaded: url_helper
INFO - 2024-02-29 04:34:29 --> Helper loaded: file_helper
INFO - 2024-02-29 04:34:29 --> Helper loaded: html_helper
INFO - 2024-02-29 04:34:29 --> Helper loaded: text_helper
INFO - 2024-02-29 04:34:29 --> Helper loaded: form_helper
INFO - 2024-02-29 04:34:29 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:34:29 --> Helper loaded: security_helper
INFO - 2024-02-29 04:34:29 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:34:29 --> Database Driver Class Initialized
INFO - 2024-02-29 04:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:34:29 --> Parser Class Initialized
INFO - 2024-02-29 04:34:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:34:29 --> Pagination Class Initialized
INFO - 2024-02-29 04:34:29 --> Form Validation Class Initialized
INFO - 2024-02-29 04:34:29 --> Controller Class Initialized
INFO - 2024-02-29 04:34:29 --> Model Class Initialized
DEBUG - 2024-02-29 04:34:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:34:29 --> Final output sent to browser
DEBUG - 2024-02-29 04:34:29 --> Total execution time: 0.0152
ERROR - 2024-02-29 04:34:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:34:30 --> Config Class Initialized
INFO - 2024-02-29 04:34:30 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:34:30 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:34:30 --> Utf8 Class Initialized
INFO - 2024-02-29 04:34:30 --> URI Class Initialized
INFO - 2024-02-29 04:34:30 --> Router Class Initialized
INFO - 2024-02-29 04:34:30 --> Output Class Initialized
INFO - 2024-02-29 04:34:30 --> Security Class Initialized
DEBUG - 2024-02-29 04:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:34:30 --> Input Class Initialized
INFO - 2024-02-29 04:34:30 --> Language Class Initialized
INFO - 2024-02-29 04:34:30 --> Loader Class Initialized
INFO - 2024-02-29 04:34:30 --> Helper loaded: url_helper
INFO - 2024-02-29 04:34:30 --> Helper loaded: file_helper
INFO - 2024-02-29 04:34:30 --> Helper loaded: html_helper
INFO - 2024-02-29 04:34:30 --> Helper loaded: text_helper
INFO - 2024-02-29 04:34:30 --> Helper loaded: form_helper
INFO - 2024-02-29 04:34:30 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:34:30 --> Helper loaded: security_helper
INFO - 2024-02-29 04:34:30 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:34:30 --> Database Driver Class Initialized
INFO - 2024-02-29 04:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:34:30 --> Parser Class Initialized
INFO - 2024-02-29 04:34:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:34:30 --> Pagination Class Initialized
INFO - 2024-02-29 04:34:30 --> Form Validation Class Initialized
INFO - 2024-02-29 04:34:30 --> Controller Class Initialized
INFO - 2024-02-29 04:34:30 --> Model Class Initialized
DEBUG - 2024-02-29 04:34:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-29 04:34:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-29 04:34:30 --> Final output sent to browser
DEBUG - 2024-02-29 04:34:30 --> Total execution time: 0.0211
ERROR - 2024-02-29 04:34:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:34:31 --> Config Class Initialized
INFO - 2024-02-29 04:34:31 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:34:31 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:34:31 --> Utf8 Class Initialized
INFO - 2024-02-29 04:34:31 --> URI Class Initialized
INFO - 2024-02-29 04:34:31 --> Router Class Initialized
INFO - 2024-02-29 04:34:31 --> Output Class Initialized
INFO - 2024-02-29 04:34:31 --> Security Class Initialized
DEBUG - 2024-02-29 04:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:34:31 --> Input Class Initialized
INFO - 2024-02-29 04:34:31 --> Language Class Initialized
INFO - 2024-02-29 04:34:31 --> Loader Class Initialized
INFO - 2024-02-29 04:34:31 --> Helper loaded: url_helper
INFO - 2024-02-29 04:34:31 --> Helper loaded: file_helper
INFO - 2024-02-29 04:34:31 --> Helper loaded: html_helper
INFO - 2024-02-29 04:34:31 --> Helper loaded: text_helper
INFO - 2024-02-29 04:34:31 --> Helper loaded: form_helper
INFO - 2024-02-29 04:34:31 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:34:31 --> Helper loaded: security_helper
INFO - 2024-02-29 04:34:31 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:34:31 --> Database Driver Class Initialized
INFO - 2024-02-29 04:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:34:31 --> Parser Class Initialized
INFO - 2024-02-29 04:34:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:34:31 --> Pagination Class Initialized
INFO - 2024-02-29 04:34:31 --> Form Validation Class Initialized
INFO - 2024-02-29 04:34:31 --> Controller Class Initialized
INFO - 2024-02-29 04:34:31 --> Model Class Initialized
DEBUG - 2024-02-29 04:34:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-29 04:34:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-29 04:34:31 --> Final output sent to browser
DEBUG - 2024-02-29 04:34:31 --> Total execution time: 0.0156
ERROR - 2024-02-29 04:34:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:34:35 --> Config Class Initialized
INFO - 2024-02-29 04:34:35 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:34:35 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:34:35 --> Utf8 Class Initialized
INFO - 2024-02-29 04:34:35 --> URI Class Initialized
INFO - 2024-02-29 04:34:35 --> Router Class Initialized
INFO - 2024-02-29 04:34:35 --> Output Class Initialized
INFO - 2024-02-29 04:34:35 --> Security Class Initialized
DEBUG - 2024-02-29 04:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:34:35 --> Input Class Initialized
INFO - 2024-02-29 04:34:35 --> Language Class Initialized
INFO - 2024-02-29 04:34:35 --> Loader Class Initialized
INFO - 2024-02-29 04:34:35 --> Helper loaded: url_helper
INFO - 2024-02-29 04:34:35 --> Helper loaded: file_helper
INFO - 2024-02-29 04:34:35 --> Helper loaded: html_helper
INFO - 2024-02-29 04:34:35 --> Helper loaded: text_helper
INFO - 2024-02-29 04:34:35 --> Helper loaded: form_helper
INFO - 2024-02-29 04:34:35 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:34:35 --> Helper loaded: security_helper
INFO - 2024-02-29 04:34:35 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:34:35 --> Database Driver Class Initialized
INFO - 2024-02-29 04:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:34:35 --> Parser Class Initialized
INFO - 2024-02-29 04:34:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:34:35 --> Pagination Class Initialized
INFO - 2024-02-29 04:34:35 --> Form Validation Class Initialized
INFO - 2024-02-29 04:34:35 --> Controller Class Initialized
INFO - 2024-02-29 04:34:35 --> Model Class Initialized
DEBUG - 2024-02-29 04:34:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:34:35 --> Final output sent to browser
DEBUG - 2024-02-29 04:34:35 --> Total execution time: 0.0151
ERROR - 2024-02-29 04:34:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:34:39 --> Config Class Initialized
INFO - 2024-02-29 04:34:39 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:34:39 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:34:39 --> Utf8 Class Initialized
INFO - 2024-02-29 04:34:39 --> URI Class Initialized
INFO - 2024-02-29 04:34:39 --> Router Class Initialized
INFO - 2024-02-29 04:34:39 --> Output Class Initialized
INFO - 2024-02-29 04:34:39 --> Security Class Initialized
DEBUG - 2024-02-29 04:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:34:39 --> Input Class Initialized
INFO - 2024-02-29 04:34:39 --> Language Class Initialized
INFO - 2024-02-29 04:34:39 --> Loader Class Initialized
INFO - 2024-02-29 04:34:39 --> Helper loaded: url_helper
INFO - 2024-02-29 04:34:39 --> Helper loaded: file_helper
INFO - 2024-02-29 04:34:39 --> Helper loaded: html_helper
INFO - 2024-02-29 04:34:39 --> Helper loaded: text_helper
INFO - 2024-02-29 04:34:39 --> Helper loaded: form_helper
INFO - 2024-02-29 04:34:39 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:34:39 --> Helper loaded: security_helper
INFO - 2024-02-29 04:34:39 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:34:39 --> Database Driver Class Initialized
INFO - 2024-02-29 04:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:34:39 --> Parser Class Initialized
INFO - 2024-02-29 04:34:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:34:39 --> Pagination Class Initialized
INFO - 2024-02-29 04:34:39 --> Form Validation Class Initialized
INFO - 2024-02-29 04:34:39 --> Controller Class Initialized
INFO - 2024-02-29 04:34:39 --> Model Class Initialized
DEBUG - 2024-02-29 04:34:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:34:39 --> Final output sent to browser
DEBUG - 2024-02-29 04:34:39 --> Total execution time: 0.0149
ERROR - 2024-02-29 04:34:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:34:48 --> Config Class Initialized
INFO - 2024-02-29 04:34:48 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:34:48 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:34:48 --> Utf8 Class Initialized
INFO - 2024-02-29 04:34:48 --> URI Class Initialized
INFO - 2024-02-29 04:34:48 --> Router Class Initialized
INFO - 2024-02-29 04:34:48 --> Output Class Initialized
INFO - 2024-02-29 04:34:48 --> Security Class Initialized
DEBUG - 2024-02-29 04:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:34:48 --> Input Class Initialized
INFO - 2024-02-29 04:34:48 --> Language Class Initialized
INFO - 2024-02-29 04:34:48 --> Loader Class Initialized
INFO - 2024-02-29 04:34:48 --> Helper loaded: url_helper
INFO - 2024-02-29 04:34:48 --> Helper loaded: file_helper
INFO - 2024-02-29 04:34:48 --> Helper loaded: html_helper
INFO - 2024-02-29 04:34:48 --> Helper loaded: text_helper
INFO - 2024-02-29 04:34:48 --> Helper loaded: form_helper
INFO - 2024-02-29 04:34:48 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:34:48 --> Helper loaded: security_helper
INFO - 2024-02-29 04:34:48 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:34:48 --> Database Driver Class Initialized
INFO - 2024-02-29 04:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:34:48 --> Parser Class Initialized
INFO - 2024-02-29 04:34:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:34:48 --> Pagination Class Initialized
INFO - 2024-02-29 04:34:48 --> Form Validation Class Initialized
INFO - 2024-02-29 04:34:48 --> Controller Class Initialized
INFO - 2024-02-29 04:34:48 --> Model Class Initialized
DEBUG - 2024-02-29 04:34:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:34:48 --> Final output sent to browser
DEBUG - 2024-02-29 04:34:48 --> Total execution time: 0.0153
ERROR - 2024-02-29 04:34:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:34:49 --> Config Class Initialized
INFO - 2024-02-29 04:34:49 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:34:49 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:34:49 --> Utf8 Class Initialized
INFO - 2024-02-29 04:34:49 --> URI Class Initialized
INFO - 2024-02-29 04:34:49 --> Router Class Initialized
INFO - 2024-02-29 04:34:49 --> Output Class Initialized
INFO - 2024-02-29 04:34:49 --> Security Class Initialized
DEBUG - 2024-02-29 04:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:34:49 --> Input Class Initialized
INFO - 2024-02-29 04:34:49 --> Language Class Initialized
INFO - 2024-02-29 04:34:49 --> Loader Class Initialized
INFO - 2024-02-29 04:34:49 --> Helper loaded: url_helper
INFO - 2024-02-29 04:34:49 --> Helper loaded: file_helper
INFO - 2024-02-29 04:34:49 --> Helper loaded: html_helper
INFO - 2024-02-29 04:34:49 --> Helper loaded: text_helper
INFO - 2024-02-29 04:34:49 --> Helper loaded: form_helper
INFO - 2024-02-29 04:34:49 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:34:49 --> Helper loaded: security_helper
INFO - 2024-02-29 04:34:49 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:34:49 --> Database Driver Class Initialized
INFO - 2024-02-29 04:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:34:49 --> Parser Class Initialized
INFO - 2024-02-29 04:34:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:34:49 --> Pagination Class Initialized
INFO - 2024-02-29 04:34:49 --> Form Validation Class Initialized
INFO - 2024-02-29 04:34:49 --> Controller Class Initialized
INFO - 2024-02-29 04:34:49 --> Model Class Initialized
DEBUG - 2024-02-29 04:34:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:34:49 --> Final output sent to browser
DEBUG - 2024-02-29 04:34:49 --> Total execution time: 0.0156
ERROR - 2024-02-29 04:34:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:34:51 --> Config Class Initialized
INFO - 2024-02-29 04:34:51 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:34:51 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:34:51 --> Utf8 Class Initialized
INFO - 2024-02-29 04:34:51 --> URI Class Initialized
INFO - 2024-02-29 04:34:51 --> Router Class Initialized
INFO - 2024-02-29 04:34:51 --> Output Class Initialized
INFO - 2024-02-29 04:34:51 --> Security Class Initialized
DEBUG - 2024-02-29 04:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:34:51 --> Input Class Initialized
INFO - 2024-02-29 04:34:51 --> Language Class Initialized
INFO - 2024-02-29 04:34:51 --> Loader Class Initialized
INFO - 2024-02-29 04:34:51 --> Helper loaded: url_helper
INFO - 2024-02-29 04:34:51 --> Helper loaded: file_helper
INFO - 2024-02-29 04:34:51 --> Helper loaded: html_helper
INFO - 2024-02-29 04:34:51 --> Helper loaded: text_helper
INFO - 2024-02-29 04:34:51 --> Helper loaded: form_helper
INFO - 2024-02-29 04:34:51 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:34:51 --> Helper loaded: security_helper
INFO - 2024-02-29 04:34:51 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:34:51 --> Database Driver Class Initialized
INFO - 2024-02-29 04:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:34:51 --> Parser Class Initialized
INFO - 2024-02-29 04:34:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:34:51 --> Pagination Class Initialized
INFO - 2024-02-29 04:34:51 --> Form Validation Class Initialized
INFO - 2024-02-29 04:34:51 --> Controller Class Initialized
INFO - 2024-02-29 04:34:51 --> Final output sent to browser
DEBUG - 2024-02-29 04:34:51 --> Total execution time: 0.0141
ERROR - 2024-02-29 04:34:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:34:58 --> Config Class Initialized
INFO - 2024-02-29 04:34:58 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:34:58 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:34:58 --> Utf8 Class Initialized
INFO - 2024-02-29 04:34:58 --> URI Class Initialized
INFO - 2024-02-29 04:34:58 --> Router Class Initialized
INFO - 2024-02-29 04:34:58 --> Output Class Initialized
INFO - 2024-02-29 04:34:58 --> Security Class Initialized
DEBUG - 2024-02-29 04:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:34:58 --> Input Class Initialized
INFO - 2024-02-29 04:34:58 --> Language Class Initialized
INFO - 2024-02-29 04:34:58 --> Loader Class Initialized
INFO - 2024-02-29 04:34:58 --> Helper loaded: url_helper
INFO - 2024-02-29 04:34:58 --> Helper loaded: file_helper
INFO - 2024-02-29 04:34:58 --> Helper loaded: html_helper
INFO - 2024-02-29 04:34:58 --> Helper loaded: text_helper
INFO - 2024-02-29 04:34:58 --> Helper loaded: form_helper
INFO - 2024-02-29 04:34:58 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:34:58 --> Helper loaded: security_helper
INFO - 2024-02-29 04:34:58 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:34:58 --> Database Driver Class Initialized
INFO - 2024-02-29 04:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:34:58 --> Parser Class Initialized
INFO - 2024-02-29 04:34:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:34:58 --> Pagination Class Initialized
INFO - 2024-02-29 04:34:58 --> Form Validation Class Initialized
INFO - 2024-02-29 04:34:58 --> Controller Class Initialized
INFO - 2024-02-29 04:34:58 --> Model Class Initialized
DEBUG - 2024-02-29 04:34:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:34:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:34:58 --> Model Class Initialized
DEBUG - 2024-02-29 04:34:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:34:58 --> Model Class Initialized
INFO - 2024-02-29 04:34:58 --> Final output sent to browser
DEBUG - 2024-02-29 04:34:58 --> Total execution time: 0.1272
ERROR - 2024-02-29 04:34:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:34:59 --> Config Class Initialized
INFO - 2024-02-29 04:34:59 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:34:59 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:34:59 --> Utf8 Class Initialized
INFO - 2024-02-29 04:34:59 --> URI Class Initialized
INFO - 2024-02-29 04:34:59 --> Router Class Initialized
INFO - 2024-02-29 04:34:59 --> Output Class Initialized
INFO - 2024-02-29 04:34:59 --> Security Class Initialized
DEBUG - 2024-02-29 04:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:34:59 --> Input Class Initialized
INFO - 2024-02-29 04:34:59 --> Language Class Initialized
INFO - 2024-02-29 04:34:59 --> Loader Class Initialized
INFO - 2024-02-29 04:34:59 --> Helper loaded: url_helper
INFO - 2024-02-29 04:34:59 --> Helper loaded: file_helper
INFO - 2024-02-29 04:34:59 --> Helper loaded: html_helper
INFO - 2024-02-29 04:34:59 --> Helper loaded: text_helper
INFO - 2024-02-29 04:34:59 --> Helper loaded: form_helper
INFO - 2024-02-29 04:34:59 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:34:59 --> Helper loaded: security_helper
INFO - 2024-02-29 04:34:59 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:34:59 --> Database Driver Class Initialized
INFO - 2024-02-29 04:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:34:59 --> Parser Class Initialized
INFO - 2024-02-29 04:34:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:34:59 --> Pagination Class Initialized
INFO - 2024-02-29 04:34:59 --> Form Validation Class Initialized
INFO - 2024-02-29 04:34:59 --> Controller Class Initialized
INFO - 2024-02-29 04:35:00 --> Model Class Initialized
DEBUG - 2024-02-29 04:35:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:35:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:35:00 --> Model Class Initialized
DEBUG - 2024-02-29 04:35:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:35:00 --> Model Class Initialized
INFO - 2024-02-29 04:35:00 --> Final output sent to browser
DEBUG - 2024-02-29 04:35:00 --> Total execution time: 0.1265
ERROR - 2024-02-29 04:35:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:35:00 --> Config Class Initialized
INFO - 2024-02-29 04:35:00 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:35:00 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:35:00 --> Utf8 Class Initialized
INFO - 2024-02-29 04:35:00 --> URI Class Initialized
INFO - 2024-02-29 04:35:00 --> Router Class Initialized
INFO - 2024-02-29 04:35:00 --> Output Class Initialized
INFO - 2024-02-29 04:35:00 --> Security Class Initialized
DEBUG - 2024-02-29 04:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:35:00 --> Input Class Initialized
INFO - 2024-02-29 04:35:00 --> Language Class Initialized
INFO - 2024-02-29 04:35:00 --> Loader Class Initialized
INFO - 2024-02-29 04:35:00 --> Helper loaded: url_helper
INFO - 2024-02-29 04:35:00 --> Helper loaded: file_helper
INFO - 2024-02-29 04:35:00 --> Helper loaded: html_helper
INFO - 2024-02-29 04:35:00 --> Helper loaded: text_helper
INFO - 2024-02-29 04:35:00 --> Helper loaded: form_helper
INFO - 2024-02-29 04:35:00 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:35:00 --> Helper loaded: security_helper
INFO - 2024-02-29 04:35:00 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:35:00 --> Database Driver Class Initialized
INFO - 2024-02-29 04:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:35:00 --> Parser Class Initialized
INFO - 2024-02-29 04:35:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:35:00 --> Pagination Class Initialized
INFO - 2024-02-29 04:35:00 --> Form Validation Class Initialized
INFO - 2024-02-29 04:35:00 --> Controller Class Initialized
INFO - 2024-02-29 04:35:00 --> Model Class Initialized
DEBUG - 2024-02-29 04:35:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:35:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:35:00 --> Model Class Initialized
DEBUG - 2024-02-29 04:35:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:35:00 --> Model Class Initialized
INFO - 2024-02-29 04:35:00 --> Final output sent to browser
DEBUG - 2024-02-29 04:35:00 --> Total execution time: 0.1284
ERROR - 2024-02-29 04:35:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:35:08 --> Config Class Initialized
INFO - 2024-02-29 04:35:08 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:35:08 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:35:08 --> Utf8 Class Initialized
INFO - 2024-02-29 04:35:08 --> URI Class Initialized
INFO - 2024-02-29 04:35:08 --> Router Class Initialized
INFO - 2024-02-29 04:35:08 --> Output Class Initialized
INFO - 2024-02-29 04:35:08 --> Security Class Initialized
DEBUG - 2024-02-29 04:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:35:08 --> Input Class Initialized
INFO - 2024-02-29 04:35:08 --> Language Class Initialized
INFO - 2024-02-29 04:35:08 --> Loader Class Initialized
INFO - 2024-02-29 04:35:08 --> Helper loaded: url_helper
INFO - 2024-02-29 04:35:08 --> Helper loaded: file_helper
INFO - 2024-02-29 04:35:08 --> Helper loaded: html_helper
INFO - 2024-02-29 04:35:08 --> Helper loaded: text_helper
INFO - 2024-02-29 04:35:08 --> Helper loaded: form_helper
INFO - 2024-02-29 04:35:08 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:35:08 --> Helper loaded: security_helper
INFO - 2024-02-29 04:35:08 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:35:08 --> Database Driver Class Initialized
INFO - 2024-02-29 04:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:35:08 --> Parser Class Initialized
INFO - 2024-02-29 04:35:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:35:08 --> Pagination Class Initialized
INFO - 2024-02-29 04:35:08 --> Form Validation Class Initialized
INFO - 2024-02-29 04:35:08 --> Controller Class Initialized
INFO - 2024-02-29 04:35:08 --> Model Class Initialized
DEBUG - 2024-02-29 04:35:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:35:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:35:08 --> Model Class Initialized
INFO - 2024-02-29 04:35:08 --> Model Class Initialized
INFO - 2024-02-29 04:35:08 --> Final output sent to browser
DEBUG - 2024-02-29 04:35:08 --> Total execution time: 0.0247
ERROR - 2024-02-29 04:35:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:35:16 --> Config Class Initialized
INFO - 2024-02-29 04:35:16 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:35:16 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:35:16 --> Utf8 Class Initialized
INFO - 2024-02-29 04:35:16 --> URI Class Initialized
INFO - 2024-02-29 04:35:16 --> Router Class Initialized
INFO - 2024-02-29 04:35:16 --> Output Class Initialized
INFO - 2024-02-29 04:35:16 --> Security Class Initialized
DEBUG - 2024-02-29 04:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:35:16 --> Input Class Initialized
INFO - 2024-02-29 04:35:16 --> Language Class Initialized
INFO - 2024-02-29 04:35:16 --> Loader Class Initialized
INFO - 2024-02-29 04:35:16 --> Helper loaded: url_helper
INFO - 2024-02-29 04:35:16 --> Helper loaded: file_helper
INFO - 2024-02-29 04:35:16 --> Helper loaded: html_helper
INFO - 2024-02-29 04:35:16 --> Helper loaded: text_helper
INFO - 2024-02-29 04:35:16 --> Helper loaded: form_helper
INFO - 2024-02-29 04:35:16 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:35:16 --> Helper loaded: security_helper
INFO - 2024-02-29 04:35:16 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:35:16 --> Database Driver Class Initialized
INFO - 2024-02-29 04:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:35:16 --> Parser Class Initialized
INFO - 2024-02-29 04:35:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:35:16 --> Pagination Class Initialized
INFO - 2024-02-29 04:35:16 --> Form Validation Class Initialized
INFO - 2024-02-29 04:35:16 --> Controller Class Initialized
INFO - 2024-02-29 04:35:16 --> Model Class Initialized
DEBUG - 2024-02-29 04:35:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:35:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:35:16 --> Model Class Initialized
INFO - 2024-02-29 04:35:16 --> Final output sent to browser
DEBUG - 2024-02-29 04:35:16 --> Total execution time: 0.0163
ERROR - 2024-02-29 04:35:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:35:18 --> Config Class Initialized
INFO - 2024-02-29 04:35:18 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:35:18 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:35:18 --> Utf8 Class Initialized
INFO - 2024-02-29 04:35:18 --> URI Class Initialized
INFO - 2024-02-29 04:35:18 --> Router Class Initialized
INFO - 2024-02-29 04:35:18 --> Output Class Initialized
INFO - 2024-02-29 04:35:18 --> Security Class Initialized
DEBUG - 2024-02-29 04:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:35:18 --> Input Class Initialized
INFO - 2024-02-29 04:35:18 --> Language Class Initialized
INFO - 2024-02-29 04:35:18 --> Loader Class Initialized
INFO - 2024-02-29 04:35:18 --> Helper loaded: url_helper
INFO - 2024-02-29 04:35:18 --> Helper loaded: file_helper
INFO - 2024-02-29 04:35:18 --> Helper loaded: html_helper
INFO - 2024-02-29 04:35:18 --> Helper loaded: text_helper
INFO - 2024-02-29 04:35:18 --> Helper loaded: form_helper
INFO - 2024-02-29 04:35:18 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:35:18 --> Helper loaded: security_helper
INFO - 2024-02-29 04:35:18 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:35:18 --> Database Driver Class Initialized
INFO - 2024-02-29 04:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:35:18 --> Parser Class Initialized
INFO - 2024-02-29 04:35:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:35:18 --> Pagination Class Initialized
INFO - 2024-02-29 04:35:18 --> Form Validation Class Initialized
INFO - 2024-02-29 04:35:18 --> Controller Class Initialized
INFO - 2024-02-29 04:35:18 --> Model Class Initialized
DEBUG - 2024-02-29 04:35:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:35:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:35:18 --> Model Class Initialized
INFO - 2024-02-29 04:35:18 --> Final output sent to browser
DEBUG - 2024-02-29 04:35:18 --> Total execution time: 0.0169
ERROR - 2024-02-29 04:35:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:35:48 --> Config Class Initialized
INFO - 2024-02-29 04:35:48 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:35:48 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:35:48 --> Utf8 Class Initialized
INFO - 2024-02-29 04:35:48 --> URI Class Initialized
INFO - 2024-02-29 04:35:48 --> Router Class Initialized
INFO - 2024-02-29 04:35:48 --> Output Class Initialized
INFO - 2024-02-29 04:35:48 --> Security Class Initialized
DEBUG - 2024-02-29 04:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:35:48 --> Input Class Initialized
INFO - 2024-02-29 04:35:48 --> Language Class Initialized
INFO - 2024-02-29 04:35:48 --> Loader Class Initialized
INFO - 2024-02-29 04:35:48 --> Helper loaded: url_helper
INFO - 2024-02-29 04:35:48 --> Helper loaded: file_helper
INFO - 2024-02-29 04:35:48 --> Helper loaded: html_helper
INFO - 2024-02-29 04:35:48 --> Helper loaded: text_helper
INFO - 2024-02-29 04:35:48 --> Helper loaded: form_helper
INFO - 2024-02-29 04:35:48 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:35:48 --> Helper loaded: security_helper
INFO - 2024-02-29 04:35:48 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:35:48 --> Database Driver Class Initialized
INFO - 2024-02-29 04:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:35:48 --> Parser Class Initialized
INFO - 2024-02-29 04:35:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:35:48 --> Pagination Class Initialized
INFO - 2024-02-29 04:35:48 --> Form Validation Class Initialized
INFO - 2024-02-29 04:35:48 --> Controller Class Initialized
INFO - 2024-02-29 04:35:48 --> Model Class Initialized
DEBUG - 2024-02-29 04:35:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:35:48 --> Model Class Initialized
DEBUG - 2024-02-29 04:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:35:48 --> Model Class Initialized
INFO - 2024-02-29 04:35:49 --> Final output sent to browser
DEBUG - 2024-02-29 04:35:49 --> Total execution time: 0.1287
ERROR - 2024-02-29 04:35:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:35:49 --> Config Class Initialized
INFO - 2024-02-29 04:35:49 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:35:49 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:35:49 --> Utf8 Class Initialized
INFO - 2024-02-29 04:35:49 --> URI Class Initialized
INFO - 2024-02-29 04:35:49 --> Router Class Initialized
INFO - 2024-02-29 04:35:49 --> Output Class Initialized
INFO - 2024-02-29 04:35:49 --> Security Class Initialized
DEBUG - 2024-02-29 04:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:35:49 --> Input Class Initialized
INFO - 2024-02-29 04:35:49 --> Language Class Initialized
INFO - 2024-02-29 04:35:49 --> Loader Class Initialized
INFO - 2024-02-29 04:35:49 --> Helper loaded: url_helper
INFO - 2024-02-29 04:35:49 --> Helper loaded: file_helper
INFO - 2024-02-29 04:35:49 --> Helper loaded: html_helper
INFO - 2024-02-29 04:35:49 --> Helper loaded: text_helper
INFO - 2024-02-29 04:35:49 --> Helper loaded: form_helper
INFO - 2024-02-29 04:35:49 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:35:49 --> Helper loaded: security_helper
INFO - 2024-02-29 04:35:49 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:35:49 --> Database Driver Class Initialized
INFO - 2024-02-29 04:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:35:49 --> Parser Class Initialized
INFO - 2024-02-29 04:35:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:35:49 --> Pagination Class Initialized
INFO - 2024-02-29 04:35:49 --> Form Validation Class Initialized
INFO - 2024-02-29 04:35:49 --> Controller Class Initialized
INFO - 2024-02-29 04:35:49 --> Model Class Initialized
DEBUG - 2024-02-29 04:35:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:35:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:35:49 --> Model Class Initialized
DEBUG - 2024-02-29 04:35:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:35:49 --> Model Class Initialized
INFO - 2024-02-29 04:35:49 --> Final output sent to browser
DEBUG - 2024-02-29 04:35:49 --> Total execution time: 0.1255
ERROR - 2024-02-29 04:35:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:35:49 --> Config Class Initialized
INFO - 2024-02-29 04:35:49 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:35:49 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:35:49 --> Utf8 Class Initialized
INFO - 2024-02-29 04:35:49 --> URI Class Initialized
INFO - 2024-02-29 04:35:49 --> Router Class Initialized
INFO - 2024-02-29 04:35:49 --> Output Class Initialized
INFO - 2024-02-29 04:35:49 --> Security Class Initialized
DEBUG - 2024-02-29 04:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:35:49 --> Input Class Initialized
INFO - 2024-02-29 04:35:49 --> Language Class Initialized
INFO - 2024-02-29 04:35:49 --> Loader Class Initialized
INFO - 2024-02-29 04:35:49 --> Helper loaded: url_helper
INFO - 2024-02-29 04:35:49 --> Helper loaded: file_helper
INFO - 2024-02-29 04:35:49 --> Helper loaded: html_helper
INFO - 2024-02-29 04:35:49 --> Helper loaded: text_helper
INFO - 2024-02-29 04:35:49 --> Helper loaded: form_helper
INFO - 2024-02-29 04:35:49 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:35:49 --> Helper loaded: security_helper
INFO - 2024-02-29 04:35:49 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:35:49 --> Database Driver Class Initialized
INFO - 2024-02-29 04:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:35:49 --> Parser Class Initialized
INFO - 2024-02-29 04:35:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:35:49 --> Pagination Class Initialized
INFO - 2024-02-29 04:35:49 --> Form Validation Class Initialized
INFO - 2024-02-29 04:35:49 --> Controller Class Initialized
INFO - 2024-02-29 04:35:49 --> Model Class Initialized
DEBUG - 2024-02-29 04:35:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:35:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:35:49 --> Model Class Initialized
DEBUG - 2024-02-29 04:35:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:35:49 --> Model Class Initialized
INFO - 2024-02-29 04:35:50 --> Final output sent to browser
DEBUG - 2024-02-29 04:35:50 --> Total execution time: 0.1269
ERROR - 2024-02-29 04:35:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:35:56 --> Config Class Initialized
INFO - 2024-02-29 04:35:56 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:35:56 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:35:56 --> Utf8 Class Initialized
INFO - 2024-02-29 04:35:56 --> URI Class Initialized
INFO - 2024-02-29 04:35:56 --> Router Class Initialized
INFO - 2024-02-29 04:35:56 --> Output Class Initialized
INFO - 2024-02-29 04:35:56 --> Security Class Initialized
DEBUG - 2024-02-29 04:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:35:56 --> Input Class Initialized
INFO - 2024-02-29 04:35:56 --> Language Class Initialized
INFO - 2024-02-29 04:35:56 --> Loader Class Initialized
INFO - 2024-02-29 04:35:56 --> Helper loaded: url_helper
INFO - 2024-02-29 04:35:56 --> Helper loaded: file_helper
INFO - 2024-02-29 04:35:56 --> Helper loaded: html_helper
INFO - 2024-02-29 04:35:56 --> Helper loaded: text_helper
INFO - 2024-02-29 04:35:56 --> Helper loaded: form_helper
INFO - 2024-02-29 04:35:56 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:35:56 --> Helper loaded: security_helper
INFO - 2024-02-29 04:35:56 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:35:56 --> Database Driver Class Initialized
INFO - 2024-02-29 04:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:35:56 --> Parser Class Initialized
INFO - 2024-02-29 04:35:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:35:56 --> Pagination Class Initialized
INFO - 2024-02-29 04:35:56 --> Form Validation Class Initialized
INFO - 2024-02-29 04:35:56 --> Controller Class Initialized
INFO - 2024-02-29 04:35:56 --> Model Class Initialized
DEBUG - 2024-02-29 04:35:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:35:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:35:56 --> Model Class Initialized
DEBUG - 2024-02-29 04:35:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:35:56 --> Model Class Initialized
INFO - 2024-02-29 04:35:56 --> Final output sent to browser
DEBUG - 2024-02-29 04:35:56 --> Total execution time: 0.0302
ERROR - 2024-02-29 04:35:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:35:57 --> Config Class Initialized
INFO - 2024-02-29 04:35:57 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:35:57 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:35:57 --> Utf8 Class Initialized
INFO - 2024-02-29 04:35:57 --> URI Class Initialized
INFO - 2024-02-29 04:35:57 --> Router Class Initialized
INFO - 2024-02-29 04:35:57 --> Output Class Initialized
INFO - 2024-02-29 04:35:57 --> Security Class Initialized
DEBUG - 2024-02-29 04:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:35:57 --> Input Class Initialized
INFO - 2024-02-29 04:35:57 --> Language Class Initialized
INFO - 2024-02-29 04:35:57 --> Loader Class Initialized
INFO - 2024-02-29 04:35:57 --> Helper loaded: url_helper
INFO - 2024-02-29 04:35:57 --> Helper loaded: file_helper
INFO - 2024-02-29 04:35:57 --> Helper loaded: html_helper
INFO - 2024-02-29 04:35:57 --> Helper loaded: text_helper
INFO - 2024-02-29 04:35:57 --> Helper loaded: form_helper
INFO - 2024-02-29 04:35:57 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:35:57 --> Helper loaded: security_helper
INFO - 2024-02-29 04:35:57 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:35:57 --> Database Driver Class Initialized
INFO - 2024-02-29 04:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:35:57 --> Parser Class Initialized
INFO - 2024-02-29 04:35:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:35:57 --> Pagination Class Initialized
INFO - 2024-02-29 04:35:57 --> Form Validation Class Initialized
INFO - 2024-02-29 04:35:57 --> Controller Class Initialized
INFO - 2024-02-29 04:35:57 --> Model Class Initialized
DEBUG - 2024-02-29 04:35:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:35:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:35:57 --> Model Class Initialized
DEBUG - 2024-02-29 04:35:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:35:57 --> Model Class Initialized
INFO - 2024-02-29 04:35:57 --> Final output sent to browser
DEBUG - 2024-02-29 04:35:57 --> Total execution time: 0.0323
ERROR - 2024-02-29 04:36:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:36:02 --> Config Class Initialized
INFO - 2024-02-29 04:36:02 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:36:02 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:36:02 --> Utf8 Class Initialized
INFO - 2024-02-29 04:36:02 --> URI Class Initialized
INFO - 2024-02-29 04:36:02 --> Router Class Initialized
INFO - 2024-02-29 04:36:02 --> Output Class Initialized
INFO - 2024-02-29 04:36:02 --> Security Class Initialized
DEBUG - 2024-02-29 04:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:36:02 --> Input Class Initialized
INFO - 2024-02-29 04:36:02 --> Language Class Initialized
INFO - 2024-02-29 04:36:02 --> Loader Class Initialized
INFO - 2024-02-29 04:36:02 --> Helper loaded: url_helper
INFO - 2024-02-29 04:36:02 --> Helper loaded: file_helper
INFO - 2024-02-29 04:36:02 --> Helper loaded: html_helper
INFO - 2024-02-29 04:36:02 --> Helper loaded: text_helper
INFO - 2024-02-29 04:36:02 --> Helper loaded: form_helper
INFO - 2024-02-29 04:36:02 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:36:02 --> Helper loaded: security_helper
INFO - 2024-02-29 04:36:02 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:36:02 --> Database Driver Class Initialized
INFO - 2024-02-29 04:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:36:02 --> Parser Class Initialized
INFO - 2024-02-29 04:36:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:36:02 --> Pagination Class Initialized
INFO - 2024-02-29 04:36:02 --> Form Validation Class Initialized
INFO - 2024-02-29 04:36:02 --> Controller Class Initialized
INFO - 2024-02-29 04:36:02 --> Model Class Initialized
DEBUG - 2024-02-29 04:36:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:36:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:36:02 --> Model Class Initialized
DEBUG - 2024-02-29 04:36:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:36:02 --> Model Class Initialized
INFO - 2024-02-29 04:36:02 --> Final output sent to browser
DEBUG - 2024-02-29 04:36:02 --> Total execution time: 0.0258
ERROR - 2024-02-29 04:36:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:36:08 --> Config Class Initialized
INFO - 2024-02-29 04:36:08 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:36:08 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:36:08 --> Utf8 Class Initialized
INFO - 2024-02-29 04:36:08 --> URI Class Initialized
INFO - 2024-02-29 04:36:08 --> Router Class Initialized
INFO - 2024-02-29 04:36:08 --> Output Class Initialized
INFO - 2024-02-29 04:36:08 --> Security Class Initialized
DEBUG - 2024-02-29 04:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:36:08 --> Input Class Initialized
INFO - 2024-02-29 04:36:08 --> Language Class Initialized
INFO - 2024-02-29 04:36:08 --> Loader Class Initialized
INFO - 2024-02-29 04:36:08 --> Helper loaded: url_helper
INFO - 2024-02-29 04:36:08 --> Helper loaded: file_helper
INFO - 2024-02-29 04:36:08 --> Helper loaded: html_helper
INFO - 2024-02-29 04:36:08 --> Helper loaded: text_helper
INFO - 2024-02-29 04:36:08 --> Helper loaded: form_helper
INFO - 2024-02-29 04:36:08 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:36:08 --> Helper loaded: security_helper
INFO - 2024-02-29 04:36:08 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:36:08 --> Database Driver Class Initialized
INFO - 2024-02-29 04:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:36:08 --> Parser Class Initialized
INFO - 2024-02-29 04:36:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:36:08 --> Pagination Class Initialized
INFO - 2024-02-29 04:36:08 --> Form Validation Class Initialized
INFO - 2024-02-29 04:36:08 --> Controller Class Initialized
INFO - 2024-02-29 04:36:08 --> Model Class Initialized
DEBUG - 2024-02-29 04:36:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:36:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:36:08 --> Model Class Initialized
INFO - 2024-02-29 04:36:08 --> Model Class Initialized
INFO - 2024-02-29 04:36:08 --> Final output sent to browser
DEBUG - 2024-02-29 04:36:08 --> Total execution time: 0.0190
ERROR - 2024-02-29 04:36:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:36:13 --> Config Class Initialized
INFO - 2024-02-29 04:36:13 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:36:13 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:36:13 --> Utf8 Class Initialized
INFO - 2024-02-29 04:36:13 --> URI Class Initialized
INFO - 2024-02-29 04:36:13 --> Router Class Initialized
INFO - 2024-02-29 04:36:13 --> Output Class Initialized
INFO - 2024-02-29 04:36:13 --> Security Class Initialized
DEBUG - 2024-02-29 04:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:36:13 --> Input Class Initialized
INFO - 2024-02-29 04:36:13 --> Language Class Initialized
INFO - 2024-02-29 04:36:13 --> Loader Class Initialized
INFO - 2024-02-29 04:36:13 --> Helper loaded: url_helper
INFO - 2024-02-29 04:36:13 --> Helper loaded: file_helper
INFO - 2024-02-29 04:36:13 --> Helper loaded: html_helper
INFO - 2024-02-29 04:36:13 --> Helper loaded: text_helper
INFO - 2024-02-29 04:36:13 --> Helper loaded: form_helper
INFO - 2024-02-29 04:36:13 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:36:13 --> Helper loaded: security_helper
INFO - 2024-02-29 04:36:13 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:36:13 --> Database Driver Class Initialized
INFO - 2024-02-29 04:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:36:13 --> Parser Class Initialized
INFO - 2024-02-29 04:36:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:36:13 --> Pagination Class Initialized
INFO - 2024-02-29 04:36:13 --> Form Validation Class Initialized
INFO - 2024-02-29 04:36:13 --> Controller Class Initialized
INFO - 2024-02-29 04:36:13 --> Model Class Initialized
DEBUG - 2024-02-29 04:36:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:36:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:36:13 --> Model Class Initialized
INFO - 2024-02-29 04:36:13 --> Final output sent to browser
DEBUG - 2024-02-29 04:36:13 --> Total execution time: 0.0158
ERROR - 2024-02-29 04:36:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:36:41 --> Config Class Initialized
INFO - 2024-02-29 04:36:41 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:36:41 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:36:41 --> Utf8 Class Initialized
INFO - 2024-02-29 04:36:41 --> URI Class Initialized
INFO - 2024-02-29 04:36:41 --> Router Class Initialized
INFO - 2024-02-29 04:36:41 --> Output Class Initialized
INFO - 2024-02-29 04:36:41 --> Security Class Initialized
DEBUG - 2024-02-29 04:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:36:41 --> Input Class Initialized
INFO - 2024-02-29 04:36:41 --> Language Class Initialized
INFO - 2024-02-29 04:36:41 --> Loader Class Initialized
INFO - 2024-02-29 04:36:41 --> Helper loaded: url_helper
INFO - 2024-02-29 04:36:41 --> Helper loaded: file_helper
INFO - 2024-02-29 04:36:41 --> Helper loaded: html_helper
INFO - 2024-02-29 04:36:41 --> Helper loaded: text_helper
INFO - 2024-02-29 04:36:41 --> Helper loaded: form_helper
INFO - 2024-02-29 04:36:41 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:36:41 --> Helper loaded: security_helper
INFO - 2024-02-29 04:36:41 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:36:41 --> Database Driver Class Initialized
INFO - 2024-02-29 04:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:36:41 --> Parser Class Initialized
INFO - 2024-02-29 04:36:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:36:41 --> Pagination Class Initialized
INFO - 2024-02-29 04:36:41 --> Form Validation Class Initialized
INFO - 2024-02-29 04:36:41 --> Controller Class Initialized
INFO - 2024-02-29 04:36:41 --> Model Class Initialized
DEBUG - 2024-02-29 04:36:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:36:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:36:41 --> Model Class Initialized
DEBUG - 2024-02-29 04:36:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:36:41 --> Model Class Initialized
INFO - 2024-02-29 04:36:41 --> Final output sent to browser
DEBUG - 2024-02-29 04:36:41 --> Total execution time: 0.1283
ERROR - 2024-02-29 04:36:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:36:42 --> Config Class Initialized
INFO - 2024-02-29 04:36:42 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:36:42 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:36:42 --> Utf8 Class Initialized
INFO - 2024-02-29 04:36:42 --> URI Class Initialized
INFO - 2024-02-29 04:36:42 --> Router Class Initialized
INFO - 2024-02-29 04:36:42 --> Output Class Initialized
INFO - 2024-02-29 04:36:42 --> Security Class Initialized
DEBUG - 2024-02-29 04:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:36:42 --> Input Class Initialized
INFO - 2024-02-29 04:36:42 --> Language Class Initialized
INFO - 2024-02-29 04:36:42 --> Loader Class Initialized
INFO - 2024-02-29 04:36:42 --> Helper loaded: url_helper
INFO - 2024-02-29 04:36:42 --> Helper loaded: file_helper
INFO - 2024-02-29 04:36:42 --> Helper loaded: html_helper
INFO - 2024-02-29 04:36:42 --> Helper loaded: text_helper
INFO - 2024-02-29 04:36:42 --> Helper loaded: form_helper
INFO - 2024-02-29 04:36:42 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:36:42 --> Helper loaded: security_helper
INFO - 2024-02-29 04:36:42 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:36:42 --> Database Driver Class Initialized
INFO - 2024-02-29 04:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:36:42 --> Parser Class Initialized
INFO - 2024-02-29 04:36:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:36:42 --> Pagination Class Initialized
INFO - 2024-02-29 04:36:42 --> Form Validation Class Initialized
INFO - 2024-02-29 04:36:42 --> Controller Class Initialized
INFO - 2024-02-29 04:36:42 --> Model Class Initialized
DEBUG - 2024-02-29 04:36:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:36:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:36:42 --> Model Class Initialized
DEBUG - 2024-02-29 04:36:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:36:42 --> Model Class Initialized
INFO - 2024-02-29 04:36:42 --> Final output sent to browser
DEBUG - 2024-02-29 04:36:42 --> Total execution time: 0.1315
ERROR - 2024-02-29 04:37:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:37:00 --> Config Class Initialized
INFO - 2024-02-29 04:37:00 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:37:00 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:37:00 --> Utf8 Class Initialized
INFO - 2024-02-29 04:37:00 --> URI Class Initialized
INFO - 2024-02-29 04:37:00 --> Router Class Initialized
INFO - 2024-02-29 04:37:00 --> Output Class Initialized
INFO - 2024-02-29 04:37:00 --> Security Class Initialized
DEBUG - 2024-02-29 04:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:37:00 --> Input Class Initialized
INFO - 2024-02-29 04:37:00 --> Language Class Initialized
INFO - 2024-02-29 04:37:00 --> Loader Class Initialized
INFO - 2024-02-29 04:37:00 --> Helper loaded: url_helper
INFO - 2024-02-29 04:37:00 --> Helper loaded: file_helper
INFO - 2024-02-29 04:37:00 --> Helper loaded: html_helper
INFO - 2024-02-29 04:37:00 --> Helper loaded: text_helper
INFO - 2024-02-29 04:37:00 --> Helper loaded: form_helper
INFO - 2024-02-29 04:37:00 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:37:00 --> Helper loaded: security_helper
INFO - 2024-02-29 04:37:00 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:37:00 --> Database Driver Class Initialized
INFO - 2024-02-29 04:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:37:00 --> Parser Class Initialized
INFO - 2024-02-29 04:37:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:37:00 --> Pagination Class Initialized
INFO - 2024-02-29 04:37:00 --> Form Validation Class Initialized
INFO - 2024-02-29 04:37:00 --> Controller Class Initialized
INFO - 2024-02-29 04:37:00 --> Model Class Initialized
DEBUG - 2024-02-29 04:37:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:37:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:37:00 --> Model Class Initialized
DEBUG - 2024-02-29 04:37:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:37:00 --> Model Class Initialized
INFO - 2024-02-29 04:37:00 --> Final output sent to browser
DEBUG - 2024-02-29 04:37:00 --> Total execution time: 0.1309
ERROR - 2024-02-29 04:37:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:37:12 --> Config Class Initialized
INFO - 2024-02-29 04:37:12 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:37:12 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:37:12 --> Utf8 Class Initialized
INFO - 2024-02-29 04:37:12 --> URI Class Initialized
INFO - 2024-02-29 04:37:12 --> Router Class Initialized
INFO - 2024-02-29 04:37:12 --> Output Class Initialized
INFO - 2024-02-29 04:37:12 --> Security Class Initialized
DEBUG - 2024-02-29 04:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:37:12 --> Input Class Initialized
INFO - 2024-02-29 04:37:12 --> Language Class Initialized
INFO - 2024-02-29 04:37:12 --> Loader Class Initialized
INFO - 2024-02-29 04:37:12 --> Helper loaded: url_helper
INFO - 2024-02-29 04:37:12 --> Helper loaded: file_helper
INFO - 2024-02-29 04:37:12 --> Helper loaded: html_helper
INFO - 2024-02-29 04:37:12 --> Helper loaded: text_helper
INFO - 2024-02-29 04:37:12 --> Helper loaded: form_helper
INFO - 2024-02-29 04:37:12 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:37:12 --> Helper loaded: security_helper
INFO - 2024-02-29 04:37:12 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:37:12 --> Database Driver Class Initialized
INFO - 2024-02-29 04:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:37:12 --> Parser Class Initialized
INFO - 2024-02-29 04:37:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:37:12 --> Pagination Class Initialized
INFO - 2024-02-29 04:37:12 --> Form Validation Class Initialized
INFO - 2024-02-29 04:37:12 --> Controller Class Initialized
INFO - 2024-02-29 04:37:12 --> Model Class Initialized
DEBUG - 2024-02-29 04:37:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:37:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:37:12 --> Model Class Initialized
DEBUG - 2024-02-29 04:37:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:37:12 --> Model Class Initialized
INFO - 2024-02-29 04:37:12 --> Final output sent to browser
DEBUG - 2024-02-29 04:37:12 --> Total execution time: 0.0294
ERROR - 2024-02-29 04:37:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:37:13 --> Config Class Initialized
INFO - 2024-02-29 04:37:13 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:37:13 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:37:13 --> Utf8 Class Initialized
INFO - 2024-02-29 04:37:13 --> URI Class Initialized
INFO - 2024-02-29 04:37:13 --> Router Class Initialized
INFO - 2024-02-29 04:37:13 --> Output Class Initialized
INFO - 2024-02-29 04:37:13 --> Security Class Initialized
DEBUG - 2024-02-29 04:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:37:13 --> Input Class Initialized
INFO - 2024-02-29 04:37:13 --> Language Class Initialized
INFO - 2024-02-29 04:37:13 --> Loader Class Initialized
INFO - 2024-02-29 04:37:13 --> Helper loaded: url_helper
INFO - 2024-02-29 04:37:13 --> Helper loaded: file_helper
INFO - 2024-02-29 04:37:13 --> Helper loaded: html_helper
INFO - 2024-02-29 04:37:13 --> Helper loaded: text_helper
INFO - 2024-02-29 04:37:13 --> Helper loaded: form_helper
INFO - 2024-02-29 04:37:13 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:37:13 --> Helper loaded: security_helper
INFO - 2024-02-29 04:37:13 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:37:13 --> Database Driver Class Initialized
INFO - 2024-02-29 04:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:37:13 --> Parser Class Initialized
INFO - 2024-02-29 04:37:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:37:13 --> Pagination Class Initialized
INFO - 2024-02-29 04:37:13 --> Form Validation Class Initialized
INFO - 2024-02-29 04:37:13 --> Controller Class Initialized
INFO - 2024-02-29 04:37:13 --> Model Class Initialized
DEBUG - 2024-02-29 04:37:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:37:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:37:13 --> Model Class Initialized
DEBUG - 2024-02-29 04:37:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:37:13 --> Model Class Initialized
INFO - 2024-02-29 04:37:13 --> Final output sent to browser
DEBUG - 2024-02-29 04:37:13 --> Total execution time: 0.0269
ERROR - 2024-02-29 04:37:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:37:19 --> Config Class Initialized
INFO - 2024-02-29 04:37:19 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:37:19 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:37:19 --> Utf8 Class Initialized
INFO - 2024-02-29 04:37:19 --> URI Class Initialized
INFO - 2024-02-29 04:37:19 --> Router Class Initialized
INFO - 2024-02-29 04:37:19 --> Output Class Initialized
INFO - 2024-02-29 04:37:19 --> Security Class Initialized
DEBUG - 2024-02-29 04:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:37:19 --> Input Class Initialized
INFO - 2024-02-29 04:37:19 --> Language Class Initialized
INFO - 2024-02-29 04:37:19 --> Loader Class Initialized
INFO - 2024-02-29 04:37:19 --> Helper loaded: url_helper
INFO - 2024-02-29 04:37:19 --> Helper loaded: file_helper
INFO - 2024-02-29 04:37:19 --> Helper loaded: html_helper
INFO - 2024-02-29 04:37:19 --> Helper loaded: text_helper
INFO - 2024-02-29 04:37:19 --> Helper loaded: form_helper
INFO - 2024-02-29 04:37:19 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:37:19 --> Helper loaded: security_helper
INFO - 2024-02-29 04:37:19 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:37:19 --> Database Driver Class Initialized
INFO - 2024-02-29 04:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:37:19 --> Parser Class Initialized
INFO - 2024-02-29 04:37:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:37:19 --> Pagination Class Initialized
INFO - 2024-02-29 04:37:19 --> Form Validation Class Initialized
INFO - 2024-02-29 04:37:19 --> Controller Class Initialized
INFO - 2024-02-29 04:37:19 --> Model Class Initialized
DEBUG - 2024-02-29 04:37:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:37:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:37:19 --> Model Class Initialized
INFO - 2024-02-29 04:37:19 --> Model Class Initialized
INFO - 2024-02-29 04:37:19 --> Final output sent to browser
DEBUG - 2024-02-29 04:37:19 --> Total execution time: 0.0225
ERROR - 2024-02-29 04:37:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:37:23 --> Config Class Initialized
INFO - 2024-02-29 04:37:23 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:37:23 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:37:23 --> Utf8 Class Initialized
INFO - 2024-02-29 04:37:23 --> URI Class Initialized
INFO - 2024-02-29 04:37:23 --> Router Class Initialized
INFO - 2024-02-29 04:37:23 --> Output Class Initialized
INFO - 2024-02-29 04:37:23 --> Security Class Initialized
DEBUG - 2024-02-29 04:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:37:23 --> Input Class Initialized
INFO - 2024-02-29 04:37:23 --> Language Class Initialized
INFO - 2024-02-29 04:37:23 --> Loader Class Initialized
INFO - 2024-02-29 04:37:23 --> Helper loaded: url_helper
INFO - 2024-02-29 04:37:23 --> Helper loaded: file_helper
INFO - 2024-02-29 04:37:23 --> Helper loaded: html_helper
INFO - 2024-02-29 04:37:23 --> Helper loaded: text_helper
INFO - 2024-02-29 04:37:23 --> Helper loaded: form_helper
INFO - 2024-02-29 04:37:23 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:37:23 --> Helper loaded: security_helper
INFO - 2024-02-29 04:37:23 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:37:23 --> Database Driver Class Initialized
INFO - 2024-02-29 04:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:37:23 --> Parser Class Initialized
INFO - 2024-02-29 04:37:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:37:23 --> Pagination Class Initialized
INFO - 2024-02-29 04:37:23 --> Form Validation Class Initialized
INFO - 2024-02-29 04:37:23 --> Controller Class Initialized
INFO - 2024-02-29 04:37:23 --> Model Class Initialized
DEBUG - 2024-02-29 04:37:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:37:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:37:23 --> Model Class Initialized
INFO - 2024-02-29 04:37:23 --> Final output sent to browser
DEBUG - 2024-02-29 04:37:23 --> Total execution time: 0.0163
ERROR - 2024-02-29 04:38:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:38:17 --> Config Class Initialized
INFO - 2024-02-29 04:38:17 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:38:17 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:38:17 --> Utf8 Class Initialized
INFO - 2024-02-29 04:38:17 --> URI Class Initialized
INFO - 2024-02-29 04:38:17 --> Router Class Initialized
INFO - 2024-02-29 04:38:17 --> Output Class Initialized
INFO - 2024-02-29 04:38:17 --> Security Class Initialized
DEBUG - 2024-02-29 04:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:38:17 --> Input Class Initialized
INFO - 2024-02-29 04:38:17 --> Language Class Initialized
INFO - 2024-02-29 04:38:17 --> Loader Class Initialized
INFO - 2024-02-29 04:38:17 --> Helper loaded: url_helper
INFO - 2024-02-29 04:38:17 --> Helper loaded: file_helper
INFO - 2024-02-29 04:38:17 --> Helper loaded: html_helper
INFO - 2024-02-29 04:38:17 --> Helper loaded: text_helper
INFO - 2024-02-29 04:38:17 --> Helper loaded: form_helper
INFO - 2024-02-29 04:38:17 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:38:17 --> Helper loaded: security_helper
INFO - 2024-02-29 04:38:17 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:38:17 --> Database Driver Class Initialized
INFO - 2024-02-29 04:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:38:17 --> Parser Class Initialized
INFO - 2024-02-29 04:38:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:38:17 --> Pagination Class Initialized
INFO - 2024-02-29 04:38:17 --> Form Validation Class Initialized
INFO - 2024-02-29 04:38:17 --> Controller Class Initialized
INFO - 2024-02-29 04:38:17 --> Model Class Initialized
DEBUG - 2024-02-29 04:38:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:38:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:38:17 --> Model Class Initialized
DEBUG - 2024-02-29 04:38:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:38:17 --> Model Class Initialized
INFO - 2024-02-29 04:38:17 --> Final output sent to browser
DEBUG - 2024-02-29 04:38:17 --> Total execution time: 0.1375
ERROR - 2024-02-29 04:38:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:38:18 --> Config Class Initialized
INFO - 2024-02-29 04:38:18 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:38:18 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:38:18 --> Utf8 Class Initialized
INFO - 2024-02-29 04:38:18 --> URI Class Initialized
INFO - 2024-02-29 04:38:18 --> Router Class Initialized
INFO - 2024-02-29 04:38:18 --> Output Class Initialized
INFO - 2024-02-29 04:38:18 --> Security Class Initialized
DEBUG - 2024-02-29 04:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:38:18 --> Input Class Initialized
INFO - 2024-02-29 04:38:18 --> Language Class Initialized
INFO - 2024-02-29 04:38:18 --> Loader Class Initialized
INFO - 2024-02-29 04:38:18 --> Helper loaded: url_helper
INFO - 2024-02-29 04:38:18 --> Helper loaded: file_helper
INFO - 2024-02-29 04:38:18 --> Helper loaded: html_helper
INFO - 2024-02-29 04:38:18 --> Helper loaded: text_helper
INFO - 2024-02-29 04:38:18 --> Helper loaded: form_helper
INFO - 2024-02-29 04:38:18 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:38:18 --> Helper loaded: security_helper
INFO - 2024-02-29 04:38:18 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:38:18 --> Database Driver Class Initialized
INFO - 2024-02-29 04:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:38:18 --> Parser Class Initialized
INFO - 2024-02-29 04:38:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:38:18 --> Pagination Class Initialized
INFO - 2024-02-29 04:38:18 --> Form Validation Class Initialized
INFO - 2024-02-29 04:38:18 --> Controller Class Initialized
INFO - 2024-02-29 04:38:18 --> Model Class Initialized
DEBUG - 2024-02-29 04:38:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:38:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:38:18 --> Model Class Initialized
DEBUG - 2024-02-29 04:38:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:38:18 --> Model Class Initialized
INFO - 2024-02-29 04:38:18 --> Final output sent to browser
DEBUG - 2024-02-29 04:38:18 --> Total execution time: 0.1277
ERROR - 2024-02-29 04:38:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:38:19 --> Config Class Initialized
INFO - 2024-02-29 04:38:19 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:38:19 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:38:19 --> Utf8 Class Initialized
INFO - 2024-02-29 04:38:19 --> URI Class Initialized
INFO - 2024-02-29 04:38:19 --> Router Class Initialized
INFO - 2024-02-29 04:38:19 --> Output Class Initialized
INFO - 2024-02-29 04:38:19 --> Security Class Initialized
DEBUG - 2024-02-29 04:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:38:19 --> Input Class Initialized
INFO - 2024-02-29 04:38:19 --> Language Class Initialized
INFO - 2024-02-29 04:38:19 --> Loader Class Initialized
INFO - 2024-02-29 04:38:19 --> Helper loaded: url_helper
INFO - 2024-02-29 04:38:19 --> Helper loaded: file_helper
INFO - 2024-02-29 04:38:19 --> Helper loaded: html_helper
INFO - 2024-02-29 04:38:19 --> Helper loaded: text_helper
INFO - 2024-02-29 04:38:19 --> Helper loaded: form_helper
INFO - 2024-02-29 04:38:19 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:38:19 --> Helper loaded: security_helper
INFO - 2024-02-29 04:38:19 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:38:19 --> Database Driver Class Initialized
INFO - 2024-02-29 04:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:38:19 --> Parser Class Initialized
INFO - 2024-02-29 04:38:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:38:19 --> Pagination Class Initialized
INFO - 2024-02-29 04:38:19 --> Form Validation Class Initialized
INFO - 2024-02-29 04:38:19 --> Controller Class Initialized
INFO - 2024-02-29 04:38:19 --> Model Class Initialized
DEBUG - 2024-02-29 04:38:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:38:19 --> Model Class Initialized
DEBUG - 2024-02-29 04:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:38:19 --> Model Class Initialized
INFO - 2024-02-29 04:38:19 --> Final output sent to browser
DEBUG - 2024-02-29 04:38:19 --> Total execution time: 0.1257
ERROR - 2024-02-29 04:38:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:38:24 --> Config Class Initialized
INFO - 2024-02-29 04:38:24 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:38:24 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:38:24 --> Utf8 Class Initialized
INFO - 2024-02-29 04:38:24 --> URI Class Initialized
INFO - 2024-02-29 04:38:24 --> Router Class Initialized
INFO - 2024-02-29 04:38:24 --> Output Class Initialized
INFO - 2024-02-29 04:38:24 --> Security Class Initialized
DEBUG - 2024-02-29 04:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:38:24 --> Input Class Initialized
INFO - 2024-02-29 04:38:24 --> Language Class Initialized
INFO - 2024-02-29 04:38:24 --> Loader Class Initialized
INFO - 2024-02-29 04:38:24 --> Helper loaded: url_helper
INFO - 2024-02-29 04:38:24 --> Helper loaded: file_helper
INFO - 2024-02-29 04:38:24 --> Helper loaded: html_helper
INFO - 2024-02-29 04:38:24 --> Helper loaded: text_helper
INFO - 2024-02-29 04:38:24 --> Helper loaded: form_helper
INFO - 2024-02-29 04:38:24 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:38:24 --> Helper loaded: security_helper
INFO - 2024-02-29 04:38:24 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:38:24 --> Database Driver Class Initialized
INFO - 2024-02-29 04:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:38:24 --> Parser Class Initialized
INFO - 2024-02-29 04:38:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:38:24 --> Pagination Class Initialized
INFO - 2024-02-29 04:38:24 --> Form Validation Class Initialized
INFO - 2024-02-29 04:38:24 --> Controller Class Initialized
INFO - 2024-02-29 04:38:24 --> Model Class Initialized
DEBUG - 2024-02-29 04:38:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:38:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:38:24 --> Model Class Initialized
INFO - 2024-02-29 04:38:24 --> Model Class Initialized
INFO - 2024-02-29 04:38:24 --> Final output sent to browser
DEBUG - 2024-02-29 04:38:24 --> Total execution time: 0.0200
ERROR - 2024-02-29 04:38:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:38:28 --> Config Class Initialized
INFO - 2024-02-29 04:38:28 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:38:28 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:38:28 --> Utf8 Class Initialized
INFO - 2024-02-29 04:38:28 --> URI Class Initialized
INFO - 2024-02-29 04:38:28 --> Router Class Initialized
INFO - 2024-02-29 04:38:28 --> Output Class Initialized
INFO - 2024-02-29 04:38:28 --> Security Class Initialized
DEBUG - 2024-02-29 04:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:38:28 --> Input Class Initialized
INFO - 2024-02-29 04:38:28 --> Language Class Initialized
INFO - 2024-02-29 04:38:28 --> Loader Class Initialized
INFO - 2024-02-29 04:38:28 --> Helper loaded: url_helper
INFO - 2024-02-29 04:38:28 --> Helper loaded: file_helper
INFO - 2024-02-29 04:38:28 --> Helper loaded: html_helper
INFO - 2024-02-29 04:38:28 --> Helper loaded: text_helper
INFO - 2024-02-29 04:38:28 --> Helper loaded: form_helper
INFO - 2024-02-29 04:38:28 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:38:28 --> Helper loaded: security_helper
INFO - 2024-02-29 04:38:28 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:38:28 --> Database Driver Class Initialized
INFO - 2024-02-29 04:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:38:28 --> Parser Class Initialized
INFO - 2024-02-29 04:38:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:38:28 --> Pagination Class Initialized
INFO - 2024-02-29 04:38:28 --> Form Validation Class Initialized
INFO - 2024-02-29 04:38:28 --> Controller Class Initialized
INFO - 2024-02-29 04:38:28 --> Model Class Initialized
DEBUG - 2024-02-29 04:38:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:38:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:38:28 --> Model Class Initialized
INFO - 2024-02-29 04:38:28 --> Final output sent to browser
DEBUG - 2024-02-29 04:38:28 --> Total execution time: 0.0171
ERROR - 2024-02-29 04:38:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:38:47 --> Config Class Initialized
INFO - 2024-02-29 04:38:47 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:38:47 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:38:47 --> Utf8 Class Initialized
INFO - 2024-02-29 04:38:47 --> URI Class Initialized
INFO - 2024-02-29 04:38:47 --> Router Class Initialized
INFO - 2024-02-29 04:38:47 --> Output Class Initialized
INFO - 2024-02-29 04:38:47 --> Security Class Initialized
DEBUG - 2024-02-29 04:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:38:47 --> Input Class Initialized
INFO - 2024-02-29 04:38:47 --> Language Class Initialized
INFO - 2024-02-29 04:38:47 --> Loader Class Initialized
INFO - 2024-02-29 04:38:47 --> Helper loaded: url_helper
INFO - 2024-02-29 04:38:47 --> Helper loaded: file_helper
INFO - 2024-02-29 04:38:47 --> Helper loaded: html_helper
INFO - 2024-02-29 04:38:47 --> Helper loaded: text_helper
INFO - 2024-02-29 04:38:47 --> Helper loaded: form_helper
INFO - 2024-02-29 04:38:47 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:38:47 --> Helper loaded: security_helper
INFO - 2024-02-29 04:38:47 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:38:47 --> Database Driver Class Initialized
INFO - 2024-02-29 04:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:38:47 --> Parser Class Initialized
INFO - 2024-02-29 04:38:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:38:47 --> Pagination Class Initialized
INFO - 2024-02-29 04:38:47 --> Form Validation Class Initialized
INFO - 2024-02-29 04:38:47 --> Controller Class Initialized
INFO - 2024-02-29 04:38:47 --> Model Class Initialized
DEBUG - 2024-02-29 04:38:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:38:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:38:47 --> Model Class Initialized
DEBUG - 2024-02-29 04:38:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:38:47 --> Model Class Initialized
INFO - 2024-02-29 04:38:47 --> Final output sent to browser
DEBUG - 2024-02-29 04:38:47 --> Total execution time: 0.1278
ERROR - 2024-02-29 04:38:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:38:48 --> Config Class Initialized
INFO - 2024-02-29 04:38:48 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:38:48 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:38:48 --> Utf8 Class Initialized
INFO - 2024-02-29 04:38:48 --> URI Class Initialized
INFO - 2024-02-29 04:38:48 --> Router Class Initialized
INFO - 2024-02-29 04:38:48 --> Output Class Initialized
INFO - 2024-02-29 04:38:48 --> Security Class Initialized
DEBUG - 2024-02-29 04:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:38:48 --> Input Class Initialized
INFO - 2024-02-29 04:38:48 --> Language Class Initialized
INFO - 2024-02-29 04:38:48 --> Loader Class Initialized
INFO - 2024-02-29 04:38:48 --> Helper loaded: url_helper
INFO - 2024-02-29 04:38:48 --> Helper loaded: file_helper
INFO - 2024-02-29 04:38:48 --> Helper loaded: html_helper
INFO - 2024-02-29 04:38:48 --> Helper loaded: text_helper
INFO - 2024-02-29 04:38:48 --> Helper loaded: form_helper
INFO - 2024-02-29 04:38:48 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:38:48 --> Helper loaded: security_helper
INFO - 2024-02-29 04:38:48 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:38:48 --> Database Driver Class Initialized
INFO - 2024-02-29 04:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:38:48 --> Parser Class Initialized
INFO - 2024-02-29 04:38:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:38:48 --> Pagination Class Initialized
INFO - 2024-02-29 04:38:48 --> Form Validation Class Initialized
INFO - 2024-02-29 04:38:48 --> Controller Class Initialized
INFO - 2024-02-29 04:38:48 --> Model Class Initialized
DEBUG - 2024-02-29 04:38:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:38:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:38:48 --> Model Class Initialized
DEBUG - 2024-02-29 04:38:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:38:48 --> Model Class Initialized
INFO - 2024-02-29 04:38:48 --> Final output sent to browser
DEBUG - 2024-02-29 04:38:48 --> Total execution time: 0.1285
ERROR - 2024-02-29 04:38:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:38:48 --> Config Class Initialized
INFO - 2024-02-29 04:38:48 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:38:48 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:38:48 --> Utf8 Class Initialized
INFO - 2024-02-29 04:38:48 --> URI Class Initialized
INFO - 2024-02-29 04:38:48 --> Router Class Initialized
INFO - 2024-02-29 04:38:48 --> Output Class Initialized
INFO - 2024-02-29 04:38:48 --> Security Class Initialized
DEBUG - 2024-02-29 04:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:38:48 --> Input Class Initialized
INFO - 2024-02-29 04:38:48 --> Language Class Initialized
INFO - 2024-02-29 04:38:48 --> Loader Class Initialized
INFO - 2024-02-29 04:38:48 --> Helper loaded: url_helper
INFO - 2024-02-29 04:38:48 --> Helper loaded: file_helper
INFO - 2024-02-29 04:38:48 --> Helper loaded: html_helper
INFO - 2024-02-29 04:38:48 --> Helper loaded: text_helper
INFO - 2024-02-29 04:38:48 --> Helper loaded: form_helper
INFO - 2024-02-29 04:38:48 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:38:48 --> Helper loaded: security_helper
INFO - 2024-02-29 04:38:48 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:38:48 --> Database Driver Class Initialized
INFO - 2024-02-29 04:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:38:48 --> Parser Class Initialized
INFO - 2024-02-29 04:38:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:38:48 --> Pagination Class Initialized
INFO - 2024-02-29 04:38:48 --> Form Validation Class Initialized
INFO - 2024-02-29 04:38:48 --> Controller Class Initialized
INFO - 2024-02-29 04:38:48 --> Model Class Initialized
DEBUG - 2024-02-29 04:38:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:38:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:38:48 --> Model Class Initialized
DEBUG - 2024-02-29 04:38:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:38:48 --> Model Class Initialized
INFO - 2024-02-29 04:38:48 --> Final output sent to browser
DEBUG - 2024-02-29 04:38:48 --> Total execution time: 0.1269
ERROR - 2024-02-29 04:39:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:39:17 --> Config Class Initialized
INFO - 2024-02-29 04:39:17 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:39:17 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:39:17 --> Utf8 Class Initialized
INFO - 2024-02-29 04:39:17 --> URI Class Initialized
INFO - 2024-02-29 04:39:17 --> Router Class Initialized
INFO - 2024-02-29 04:39:17 --> Output Class Initialized
INFO - 2024-02-29 04:39:17 --> Security Class Initialized
DEBUG - 2024-02-29 04:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:39:17 --> Input Class Initialized
INFO - 2024-02-29 04:39:17 --> Language Class Initialized
INFO - 2024-02-29 04:39:17 --> Loader Class Initialized
INFO - 2024-02-29 04:39:17 --> Helper loaded: url_helper
INFO - 2024-02-29 04:39:17 --> Helper loaded: file_helper
INFO - 2024-02-29 04:39:17 --> Helper loaded: html_helper
INFO - 2024-02-29 04:39:17 --> Helper loaded: text_helper
INFO - 2024-02-29 04:39:17 --> Helper loaded: form_helper
INFO - 2024-02-29 04:39:17 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:39:17 --> Helper loaded: security_helper
INFO - 2024-02-29 04:39:17 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:39:17 --> Database Driver Class Initialized
INFO - 2024-02-29 04:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:39:17 --> Parser Class Initialized
INFO - 2024-02-29 04:39:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:39:17 --> Pagination Class Initialized
INFO - 2024-02-29 04:39:17 --> Form Validation Class Initialized
INFO - 2024-02-29 04:39:17 --> Controller Class Initialized
INFO - 2024-02-29 04:39:17 --> Model Class Initialized
DEBUG - 2024-02-29 04:39:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:39:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:39:17 --> Model Class Initialized
DEBUG - 2024-02-29 04:39:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:39:17 --> Model Class Initialized
INFO - 2024-02-29 04:39:17 --> Final output sent to browser
DEBUG - 2024-02-29 04:39:17 --> Total execution time: 0.0216
ERROR - 2024-02-29 04:39:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:39:20 --> Config Class Initialized
INFO - 2024-02-29 04:39:20 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:39:20 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:39:20 --> Utf8 Class Initialized
INFO - 2024-02-29 04:39:20 --> URI Class Initialized
INFO - 2024-02-29 04:39:20 --> Router Class Initialized
INFO - 2024-02-29 04:39:20 --> Output Class Initialized
INFO - 2024-02-29 04:39:20 --> Security Class Initialized
DEBUG - 2024-02-29 04:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:39:20 --> Input Class Initialized
INFO - 2024-02-29 04:39:20 --> Language Class Initialized
INFO - 2024-02-29 04:39:20 --> Loader Class Initialized
INFO - 2024-02-29 04:39:20 --> Helper loaded: url_helper
INFO - 2024-02-29 04:39:20 --> Helper loaded: file_helper
INFO - 2024-02-29 04:39:20 --> Helper loaded: html_helper
INFO - 2024-02-29 04:39:20 --> Helper loaded: text_helper
INFO - 2024-02-29 04:39:20 --> Helper loaded: form_helper
INFO - 2024-02-29 04:39:20 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:39:20 --> Helper loaded: security_helper
INFO - 2024-02-29 04:39:20 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:39:20 --> Database Driver Class Initialized
INFO - 2024-02-29 04:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:39:20 --> Parser Class Initialized
INFO - 2024-02-29 04:39:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:39:20 --> Pagination Class Initialized
INFO - 2024-02-29 04:39:20 --> Form Validation Class Initialized
INFO - 2024-02-29 04:39:20 --> Controller Class Initialized
INFO - 2024-02-29 04:39:20 --> Model Class Initialized
DEBUG - 2024-02-29 04:39:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:39:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:39:20 --> Model Class Initialized
DEBUG - 2024-02-29 04:39:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:39:20 --> Model Class Initialized
INFO - 2024-02-29 04:39:20 --> Final output sent to browser
DEBUG - 2024-02-29 04:39:20 --> Total execution time: 0.1259
ERROR - 2024-02-29 04:39:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:39:55 --> Config Class Initialized
INFO - 2024-02-29 04:39:55 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:39:55 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:39:55 --> Utf8 Class Initialized
INFO - 2024-02-29 04:39:55 --> URI Class Initialized
INFO - 2024-02-29 04:39:55 --> Router Class Initialized
INFO - 2024-02-29 04:39:55 --> Output Class Initialized
INFO - 2024-02-29 04:39:55 --> Security Class Initialized
DEBUG - 2024-02-29 04:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:39:55 --> Input Class Initialized
INFO - 2024-02-29 04:39:55 --> Language Class Initialized
INFO - 2024-02-29 04:39:55 --> Loader Class Initialized
INFO - 2024-02-29 04:39:55 --> Helper loaded: url_helper
INFO - 2024-02-29 04:39:55 --> Helper loaded: file_helper
INFO - 2024-02-29 04:39:55 --> Helper loaded: html_helper
INFO - 2024-02-29 04:39:55 --> Helper loaded: text_helper
INFO - 2024-02-29 04:39:55 --> Helper loaded: form_helper
INFO - 2024-02-29 04:39:55 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:39:55 --> Helper loaded: security_helper
INFO - 2024-02-29 04:39:55 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:39:55 --> Database Driver Class Initialized
INFO - 2024-02-29 04:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:39:55 --> Parser Class Initialized
INFO - 2024-02-29 04:39:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:39:55 --> Pagination Class Initialized
INFO - 2024-02-29 04:39:55 --> Form Validation Class Initialized
INFO - 2024-02-29 04:39:55 --> Controller Class Initialized
INFO - 2024-02-29 04:39:55 --> Model Class Initialized
DEBUG - 2024-02-29 04:39:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:39:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:39:55 --> Model Class Initialized
DEBUG - 2024-02-29 04:39:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:39:55 --> Model Class Initialized
INFO - 2024-02-29 04:39:55 --> Final output sent to browser
DEBUG - 2024-02-29 04:39:55 --> Total execution time: 0.0473
ERROR - 2024-02-29 04:39:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:39:55 --> Config Class Initialized
INFO - 2024-02-29 04:39:55 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:39:55 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:39:55 --> Utf8 Class Initialized
INFO - 2024-02-29 04:39:55 --> URI Class Initialized
INFO - 2024-02-29 04:39:55 --> Router Class Initialized
INFO - 2024-02-29 04:39:55 --> Output Class Initialized
INFO - 2024-02-29 04:39:55 --> Security Class Initialized
DEBUG - 2024-02-29 04:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:39:55 --> Input Class Initialized
INFO - 2024-02-29 04:39:55 --> Language Class Initialized
INFO - 2024-02-29 04:39:55 --> Loader Class Initialized
INFO - 2024-02-29 04:39:55 --> Helper loaded: url_helper
INFO - 2024-02-29 04:39:55 --> Helper loaded: file_helper
INFO - 2024-02-29 04:39:55 --> Helper loaded: html_helper
INFO - 2024-02-29 04:39:55 --> Helper loaded: text_helper
INFO - 2024-02-29 04:39:55 --> Helper loaded: form_helper
INFO - 2024-02-29 04:39:55 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:39:55 --> Helper loaded: security_helper
INFO - 2024-02-29 04:39:55 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:39:55 --> Database Driver Class Initialized
INFO - 2024-02-29 04:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:39:55 --> Parser Class Initialized
INFO - 2024-02-29 04:39:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:39:55 --> Pagination Class Initialized
INFO - 2024-02-29 04:39:55 --> Form Validation Class Initialized
INFO - 2024-02-29 04:39:55 --> Controller Class Initialized
INFO - 2024-02-29 04:39:55 --> Model Class Initialized
DEBUG - 2024-02-29 04:39:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:39:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:39:55 --> Model Class Initialized
DEBUG - 2024-02-29 04:39:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:39:55 --> Model Class Initialized
INFO - 2024-02-29 04:39:55 --> Final output sent to browser
DEBUG - 2024-02-29 04:39:55 --> Total execution time: 0.0256
ERROR - 2024-02-29 04:40:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:40:00 --> Config Class Initialized
INFO - 2024-02-29 04:40:00 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:40:00 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:40:00 --> Utf8 Class Initialized
INFO - 2024-02-29 04:40:00 --> URI Class Initialized
INFO - 2024-02-29 04:40:00 --> Router Class Initialized
INFO - 2024-02-29 04:40:00 --> Output Class Initialized
INFO - 2024-02-29 04:40:00 --> Security Class Initialized
DEBUG - 2024-02-29 04:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:40:00 --> Input Class Initialized
INFO - 2024-02-29 04:40:00 --> Language Class Initialized
INFO - 2024-02-29 04:40:00 --> Loader Class Initialized
INFO - 2024-02-29 04:40:00 --> Helper loaded: url_helper
INFO - 2024-02-29 04:40:00 --> Helper loaded: file_helper
INFO - 2024-02-29 04:40:00 --> Helper loaded: html_helper
INFO - 2024-02-29 04:40:00 --> Helper loaded: text_helper
INFO - 2024-02-29 04:40:00 --> Helper loaded: form_helper
INFO - 2024-02-29 04:40:00 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:40:00 --> Helper loaded: security_helper
INFO - 2024-02-29 04:40:00 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:40:00 --> Database Driver Class Initialized
INFO - 2024-02-29 04:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:40:00 --> Parser Class Initialized
INFO - 2024-02-29 04:40:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:40:00 --> Pagination Class Initialized
INFO - 2024-02-29 04:40:00 --> Form Validation Class Initialized
INFO - 2024-02-29 04:40:00 --> Controller Class Initialized
INFO - 2024-02-29 04:40:00 --> Model Class Initialized
DEBUG - 2024-02-29 04:40:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:40:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:40:00 --> Model Class Initialized
INFO - 2024-02-29 04:40:00 --> Model Class Initialized
INFO - 2024-02-29 04:40:00 --> Final output sent to browser
DEBUG - 2024-02-29 04:40:00 --> Total execution time: 0.0195
ERROR - 2024-02-29 04:40:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:40:04 --> Config Class Initialized
INFO - 2024-02-29 04:40:04 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:40:04 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:40:04 --> Utf8 Class Initialized
INFO - 2024-02-29 04:40:04 --> URI Class Initialized
INFO - 2024-02-29 04:40:04 --> Router Class Initialized
INFO - 2024-02-29 04:40:04 --> Output Class Initialized
INFO - 2024-02-29 04:40:04 --> Security Class Initialized
DEBUG - 2024-02-29 04:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:40:04 --> Input Class Initialized
INFO - 2024-02-29 04:40:04 --> Language Class Initialized
INFO - 2024-02-29 04:40:04 --> Loader Class Initialized
INFO - 2024-02-29 04:40:04 --> Helper loaded: url_helper
INFO - 2024-02-29 04:40:04 --> Helper loaded: file_helper
INFO - 2024-02-29 04:40:04 --> Helper loaded: html_helper
INFO - 2024-02-29 04:40:04 --> Helper loaded: text_helper
INFO - 2024-02-29 04:40:04 --> Helper loaded: form_helper
INFO - 2024-02-29 04:40:04 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:40:04 --> Helper loaded: security_helper
INFO - 2024-02-29 04:40:04 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:40:04 --> Database Driver Class Initialized
INFO - 2024-02-29 04:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:40:04 --> Parser Class Initialized
INFO - 2024-02-29 04:40:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:40:04 --> Pagination Class Initialized
INFO - 2024-02-29 04:40:04 --> Form Validation Class Initialized
INFO - 2024-02-29 04:40:04 --> Controller Class Initialized
INFO - 2024-02-29 04:40:04 --> Model Class Initialized
DEBUG - 2024-02-29 04:40:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:40:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:40:04 --> Model Class Initialized
INFO - 2024-02-29 04:40:04 --> Final output sent to browser
DEBUG - 2024-02-29 04:40:04 --> Total execution time: 0.0168
ERROR - 2024-02-29 04:40:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:40:21 --> Config Class Initialized
INFO - 2024-02-29 04:40:21 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:40:21 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:40:21 --> Utf8 Class Initialized
INFO - 2024-02-29 04:40:21 --> URI Class Initialized
INFO - 2024-02-29 04:40:21 --> Router Class Initialized
INFO - 2024-02-29 04:40:21 --> Output Class Initialized
INFO - 2024-02-29 04:40:21 --> Security Class Initialized
DEBUG - 2024-02-29 04:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:40:21 --> Input Class Initialized
INFO - 2024-02-29 04:40:21 --> Language Class Initialized
INFO - 2024-02-29 04:40:21 --> Loader Class Initialized
INFO - 2024-02-29 04:40:21 --> Helper loaded: url_helper
INFO - 2024-02-29 04:40:21 --> Helper loaded: file_helper
INFO - 2024-02-29 04:40:21 --> Helper loaded: html_helper
INFO - 2024-02-29 04:40:21 --> Helper loaded: text_helper
INFO - 2024-02-29 04:40:21 --> Helper loaded: form_helper
INFO - 2024-02-29 04:40:21 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:40:21 --> Helper loaded: security_helper
INFO - 2024-02-29 04:40:21 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:40:21 --> Database Driver Class Initialized
INFO - 2024-02-29 04:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:40:21 --> Parser Class Initialized
INFO - 2024-02-29 04:40:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:40:21 --> Pagination Class Initialized
INFO - 2024-02-29 04:40:21 --> Form Validation Class Initialized
INFO - 2024-02-29 04:40:21 --> Controller Class Initialized
INFO - 2024-02-29 04:40:21 --> Model Class Initialized
DEBUG - 2024-02-29 04:40:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:40:21 --> Model Class Initialized
DEBUG - 2024-02-29 04:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:40:21 --> Model Class Initialized
INFO - 2024-02-29 04:40:21 --> Email Class Initialized
DEBUG - 2024-02-29 04:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:40:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-29 04:40:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-02-29 04:40:21 --> Language file loaded: language/english/email_lang.php
INFO - 2024-02-29 04:40:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-02-29 04:40:22 --> Final output sent to browser
DEBUG - 2024-02-29 04:40:22 --> Total execution time: 0.2578
ERROR - 2024-02-29 04:43:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:43:57 --> Config Class Initialized
INFO - 2024-02-29 04:43:57 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:43:57 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:43:57 --> Utf8 Class Initialized
INFO - 2024-02-29 04:43:57 --> URI Class Initialized
DEBUG - 2024-02-29 04:43:57 --> No URI present. Default controller set.
INFO - 2024-02-29 04:43:57 --> Router Class Initialized
INFO - 2024-02-29 04:43:57 --> Output Class Initialized
INFO - 2024-02-29 04:43:57 --> Security Class Initialized
DEBUG - 2024-02-29 04:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:43:57 --> Input Class Initialized
INFO - 2024-02-29 04:43:57 --> Language Class Initialized
INFO - 2024-02-29 04:43:57 --> Loader Class Initialized
INFO - 2024-02-29 04:43:57 --> Helper loaded: url_helper
INFO - 2024-02-29 04:43:57 --> Helper loaded: file_helper
INFO - 2024-02-29 04:43:57 --> Helper loaded: html_helper
INFO - 2024-02-29 04:43:57 --> Helper loaded: text_helper
INFO - 2024-02-29 04:43:57 --> Helper loaded: form_helper
INFO - 2024-02-29 04:43:57 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:43:57 --> Helper loaded: security_helper
INFO - 2024-02-29 04:43:57 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:43:57 --> Database Driver Class Initialized
INFO - 2024-02-29 04:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:43:57 --> Parser Class Initialized
INFO - 2024-02-29 04:43:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:43:57 --> Pagination Class Initialized
INFO - 2024-02-29 04:43:57 --> Form Validation Class Initialized
INFO - 2024-02-29 04:43:57 --> Controller Class Initialized
INFO - 2024-02-29 04:43:57 --> Model Class Initialized
DEBUG - 2024-02-29 04:43:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:43:57 --> Model Class Initialized
DEBUG - 2024-02-29 04:43:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:43:57 --> Model Class Initialized
INFO - 2024-02-29 04:43:57 --> Model Class Initialized
INFO - 2024-02-29 04:43:57 --> Model Class Initialized
INFO - 2024-02-29 04:43:57 --> Model Class Initialized
DEBUG - 2024-02-29 04:43:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:43:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:43:57 --> Model Class Initialized
INFO - 2024-02-29 04:43:57 --> Model Class Initialized
INFO - 2024-02-29 04:43:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 04:43:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:43:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:43:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:43:57 --> Model Class Initialized
INFO - 2024-02-29 04:43:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 04:43:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 04:43:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:43:58 --> Final output sent to browser
DEBUG - 2024-02-29 04:43:58 --> Total execution time: 0.4567
ERROR - 2024-02-29 04:44:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:44:03 --> Config Class Initialized
INFO - 2024-02-29 04:44:03 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:44:03 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:44:03 --> Utf8 Class Initialized
INFO - 2024-02-29 04:44:03 --> URI Class Initialized
INFO - 2024-02-29 04:44:03 --> Router Class Initialized
INFO - 2024-02-29 04:44:03 --> Output Class Initialized
INFO - 2024-02-29 04:44:03 --> Security Class Initialized
DEBUG - 2024-02-29 04:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:44:03 --> Input Class Initialized
INFO - 2024-02-29 04:44:03 --> Language Class Initialized
INFO - 2024-02-29 04:44:03 --> Loader Class Initialized
INFO - 2024-02-29 04:44:03 --> Helper loaded: url_helper
INFO - 2024-02-29 04:44:03 --> Helper loaded: file_helper
INFO - 2024-02-29 04:44:03 --> Helper loaded: html_helper
INFO - 2024-02-29 04:44:03 --> Helper loaded: text_helper
INFO - 2024-02-29 04:44:03 --> Helper loaded: form_helper
INFO - 2024-02-29 04:44:03 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:44:03 --> Helper loaded: security_helper
INFO - 2024-02-29 04:44:03 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:44:03 --> Database Driver Class Initialized
INFO - 2024-02-29 04:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:44:03 --> Parser Class Initialized
INFO - 2024-02-29 04:44:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:44:03 --> Pagination Class Initialized
INFO - 2024-02-29 04:44:03 --> Form Validation Class Initialized
INFO - 2024-02-29 04:44:03 --> Controller Class Initialized
INFO - 2024-02-29 04:44:03 --> Model Class Initialized
DEBUG - 2024-02-29 04:44:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:44:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:44:03 --> Model Class Initialized
DEBUG - 2024-02-29 04:44:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:44:03 --> Model Class Initialized
INFO - 2024-02-29 04:44:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-29 04:44:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:44:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:44:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:44:03 --> Model Class Initialized
INFO - 2024-02-29 04:44:03 --> Model Class Initialized
INFO - 2024-02-29 04:44:03 --> Model Class Initialized
INFO - 2024-02-29 04:44:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 04:44:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 04:44:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:44:04 --> Final output sent to browser
DEBUG - 2024-02-29 04:44:04 --> Total execution time: 0.2354
ERROR - 2024-02-29 04:44:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:44:04 --> Config Class Initialized
INFO - 2024-02-29 04:44:04 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:44:04 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:44:04 --> Utf8 Class Initialized
INFO - 2024-02-29 04:44:04 --> URI Class Initialized
INFO - 2024-02-29 04:44:04 --> Router Class Initialized
INFO - 2024-02-29 04:44:04 --> Output Class Initialized
INFO - 2024-02-29 04:44:04 --> Security Class Initialized
DEBUG - 2024-02-29 04:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:44:04 --> Input Class Initialized
INFO - 2024-02-29 04:44:04 --> Language Class Initialized
INFO - 2024-02-29 04:44:04 --> Loader Class Initialized
INFO - 2024-02-29 04:44:04 --> Helper loaded: url_helper
INFO - 2024-02-29 04:44:04 --> Helper loaded: file_helper
INFO - 2024-02-29 04:44:04 --> Helper loaded: html_helper
INFO - 2024-02-29 04:44:04 --> Helper loaded: text_helper
INFO - 2024-02-29 04:44:04 --> Helper loaded: form_helper
INFO - 2024-02-29 04:44:04 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:44:04 --> Helper loaded: security_helper
INFO - 2024-02-29 04:44:04 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:44:04 --> Database Driver Class Initialized
INFO - 2024-02-29 04:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:44:04 --> Parser Class Initialized
INFO - 2024-02-29 04:44:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:44:04 --> Pagination Class Initialized
INFO - 2024-02-29 04:44:04 --> Form Validation Class Initialized
INFO - 2024-02-29 04:44:04 --> Controller Class Initialized
INFO - 2024-02-29 04:44:04 --> Model Class Initialized
DEBUG - 2024-02-29 04:44:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:44:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:44:04 --> Model Class Initialized
DEBUG - 2024-02-29 04:44:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:44:04 --> Model Class Initialized
INFO - 2024-02-29 04:44:04 --> Final output sent to browser
DEBUG - 2024-02-29 04:44:04 --> Total execution time: 0.0743
ERROR - 2024-02-29 04:44:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:44:09 --> Config Class Initialized
INFO - 2024-02-29 04:44:09 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:44:09 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:44:09 --> Utf8 Class Initialized
INFO - 2024-02-29 04:44:09 --> URI Class Initialized
INFO - 2024-02-29 04:44:09 --> Router Class Initialized
INFO - 2024-02-29 04:44:09 --> Output Class Initialized
INFO - 2024-02-29 04:44:09 --> Security Class Initialized
DEBUG - 2024-02-29 04:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:44:09 --> Input Class Initialized
INFO - 2024-02-29 04:44:09 --> Language Class Initialized
INFO - 2024-02-29 04:44:09 --> Loader Class Initialized
INFO - 2024-02-29 04:44:09 --> Helper loaded: url_helper
INFO - 2024-02-29 04:44:09 --> Helper loaded: file_helper
INFO - 2024-02-29 04:44:09 --> Helper loaded: html_helper
INFO - 2024-02-29 04:44:09 --> Helper loaded: text_helper
INFO - 2024-02-29 04:44:09 --> Helper loaded: form_helper
INFO - 2024-02-29 04:44:09 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:44:09 --> Helper loaded: security_helper
INFO - 2024-02-29 04:44:09 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:44:09 --> Database Driver Class Initialized
INFO - 2024-02-29 04:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:44:09 --> Parser Class Initialized
INFO - 2024-02-29 04:44:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:44:09 --> Pagination Class Initialized
INFO - 2024-02-29 04:44:09 --> Form Validation Class Initialized
INFO - 2024-02-29 04:44:09 --> Controller Class Initialized
INFO - 2024-02-29 04:44:09 --> Model Class Initialized
DEBUG - 2024-02-29 04:44:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:44:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:44:09 --> Model Class Initialized
DEBUG - 2024-02-29 04:44:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:44:09 --> Model Class Initialized
DEBUG - 2024-02-29 04:44:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:44:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-02-29 04:44:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:44:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:44:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:44:09 --> Model Class Initialized
INFO - 2024-02-29 04:44:09 --> Model Class Initialized
INFO - 2024-02-29 04:44:09 --> Model Class Initialized
INFO - 2024-02-29 04:44:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 04:44:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 04:44:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:44:09 --> Final output sent to browser
DEBUG - 2024-02-29 04:44:09 --> Total execution time: 0.2231
ERROR - 2024-02-29 04:50:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:50:38 --> Config Class Initialized
INFO - 2024-02-29 04:50:38 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:50:38 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:50:38 --> Utf8 Class Initialized
INFO - 2024-02-29 04:50:38 --> URI Class Initialized
DEBUG - 2024-02-29 04:50:38 --> No URI present. Default controller set.
INFO - 2024-02-29 04:50:38 --> Router Class Initialized
INFO - 2024-02-29 04:50:38 --> Output Class Initialized
INFO - 2024-02-29 04:50:38 --> Security Class Initialized
DEBUG - 2024-02-29 04:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:50:38 --> Input Class Initialized
INFO - 2024-02-29 04:50:38 --> Language Class Initialized
INFO - 2024-02-29 04:50:38 --> Loader Class Initialized
INFO - 2024-02-29 04:50:38 --> Helper loaded: url_helper
INFO - 2024-02-29 04:50:38 --> Helper loaded: file_helper
INFO - 2024-02-29 04:50:38 --> Helper loaded: html_helper
INFO - 2024-02-29 04:50:38 --> Helper loaded: text_helper
INFO - 2024-02-29 04:50:38 --> Helper loaded: form_helper
INFO - 2024-02-29 04:50:38 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:50:38 --> Helper loaded: security_helper
INFO - 2024-02-29 04:50:38 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:50:38 --> Database Driver Class Initialized
INFO - 2024-02-29 04:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:50:38 --> Parser Class Initialized
INFO - 2024-02-29 04:50:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:50:38 --> Pagination Class Initialized
INFO - 2024-02-29 04:50:38 --> Form Validation Class Initialized
INFO - 2024-02-29 04:50:38 --> Controller Class Initialized
INFO - 2024-02-29 04:50:38 --> Model Class Initialized
DEBUG - 2024-02-29 04:50:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:50:38 --> Model Class Initialized
DEBUG - 2024-02-29 04:50:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:50:38 --> Model Class Initialized
INFO - 2024-02-29 04:50:38 --> Model Class Initialized
INFO - 2024-02-29 04:50:38 --> Model Class Initialized
INFO - 2024-02-29 04:50:38 --> Model Class Initialized
DEBUG - 2024-02-29 04:50:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:50:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:50:38 --> Model Class Initialized
INFO - 2024-02-29 04:50:38 --> Model Class Initialized
INFO - 2024-02-29 04:50:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 04:50:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:50:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:50:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:50:38 --> Model Class Initialized
INFO - 2024-02-29 04:50:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 04:50:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 04:50:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:50:38 --> Final output sent to browser
DEBUG - 2024-02-29 04:50:38 --> Total execution time: 0.2411
ERROR - 2024-02-29 04:50:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:50:59 --> Config Class Initialized
INFO - 2024-02-29 04:50:59 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:50:59 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:50:59 --> Utf8 Class Initialized
INFO - 2024-02-29 04:50:59 --> URI Class Initialized
INFO - 2024-02-29 04:50:59 --> Router Class Initialized
INFO - 2024-02-29 04:50:59 --> Output Class Initialized
INFO - 2024-02-29 04:50:59 --> Security Class Initialized
DEBUG - 2024-02-29 04:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:50:59 --> Input Class Initialized
INFO - 2024-02-29 04:50:59 --> Language Class Initialized
INFO - 2024-02-29 04:50:59 --> Loader Class Initialized
INFO - 2024-02-29 04:50:59 --> Helper loaded: url_helper
INFO - 2024-02-29 04:50:59 --> Helper loaded: file_helper
INFO - 2024-02-29 04:50:59 --> Helper loaded: html_helper
INFO - 2024-02-29 04:50:59 --> Helper loaded: text_helper
INFO - 2024-02-29 04:50:59 --> Helper loaded: form_helper
INFO - 2024-02-29 04:50:59 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:50:59 --> Helper loaded: security_helper
INFO - 2024-02-29 04:50:59 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:50:59 --> Database Driver Class Initialized
INFO - 2024-02-29 04:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:50:59 --> Parser Class Initialized
INFO - 2024-02-29 04:50:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:50:59 --> Pagination Class Initialized
INFO - 2024-02-29 04:50:59 --> Form Validation Class Initialized
INFO - 2024-02-29 04:50:59 --> Controller Class Initialized
DEBUG - 2024-02-29 04:50:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:50:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:50:59 --> Model Class Initialized
DEBUG - 2024-02-29 04:50:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:50:59 --> Model Class Initialized
DEBUG - 2024-02-29 04:50:59 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:50:59 --> Model Class Initialized
INFO - 2024-02-29 04:50:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-29 04:50:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:50:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:50:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:50:59 --> Model Class Initialized
INFO - 2024-02-29 04:50:59 --> Model Class Initialized
INFO - 2024-02-29 04:50:59 --> Model Class Initialized
INFO - 2024-02-29 04:50:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 04:50:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 04:50:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:50:59 --> Final output sent to browser
DEBUG - 2024-02-29 04:50:59 --> Total execution time: 0.1526
ERROR - 2024-02-29 04:51:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:51:00 --> Config Class Initialized
INFO - 2024-02-29 04:51:00 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:51:00 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:51:00 --> Utf8 Class Initialized
INFO - 2024-02-29 04:51:00 --> URI Class Initialized
INFO - 2024-02-29 04:51:00 --> Router Class Initialized
INFO - 2024-02-29 04:51:00 --> Output Class Initialized
INFO - 2024-02-29 04:51:00 --> Security Class Initialized
DEBUG - 2024-02-29 04:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:51:00 --> Input Class Initialized
INFO - 2024-02-29 04:51:00 --> Language Class Initialized
INFO - 2024-02-29 04:51:00 --> Loader Class Initialized
INFO - 2024-02-29 04:51:00 --> Helper loaded: url_helper
INFO - 2024-02-29 04:51:00 --> Helper loaded: file_helper
INFO - 2024-02-29 04:51:00 --> Helper loaded: html_helper
INFO - 2024-02-29 04:51:00 --> Helper loaded: text_helper
INFO - 2024-02-29 04:51:00 --> Helper loaded: form_helper
INFO - 2024-02-29 04:51:00 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:51:00 --> Helper loaded: security_helper
INFO - 2024-02-29 04:51:00 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:51:00 --> Database Driver Class Initialized
INFO - 2024-02-29 04:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:51:00 --> Parser Class Initialized
INFO - 2024-02-29 04:51:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:51:00 --> Pagination Class Initialized
INFO - 2024-02-29 04:51:00 --> Form Validation Class Initialized
INFO - 2024-02-29 04:51:00 --> Controller Class Initialized
DEBUG - 2024-02-29 04:51:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:51:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:51:00 --> Model Class Initialized
DEBUG - 2024-02-29 04:51:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:51:00 --> Model Class Initialized
INFO - 2024-02-29 04:51:00 --> Final output sent to browser
DEBUG - 2024-02-29 04:51:00 --> Total execution time: 0.0258
ERROR - 2024-02-29 04:51:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:51:02 --> Config Class Initialized
INFO - 2024-02-29 04:51:02 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:51:02 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:51:02 --> Utf8 Class Initialized
INFO - 2024-02-29 04:51:02 --> URI Class Initialized
DEBUG - 2024-02-29 04:51:02 --> No URI present. Default controller set.
INFO - 2024-02-29 04:51:02 --> Router Class Initialized
INFO - 2024-02-29 04:51:02 --> Output Class Initialized
INFO - 2024-02-29 04:51:02 --> Security Class Initialized
DEBUG - 2024-02-29 04:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:51:02 --> Input Class Initialized
INFO - 2024-02-29 04:51:02 --> Language Class Initialized
INFO - 2024-02-29 04:51:02 --> Loader Class Initialized
INFO - 2024-02-29 04:51:02 --> Helper loaded: url_helper
INFO - 2024-02-29 04:51:02 --> Helper loaded: file_helper
INFO - 2024-02-29 04:51:02 --> Helper loaded: html_helper
INFO - 2024-02-29 04:51:02 --> Helper loaded: text_helper
INFO - 2024-02-29 04:51:02 --> Helper loaded: form_helper
INFO - 2024-02-29 04:51:02 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:51:02 --> Helper loaded: security_helper
INFO - 2024-02-29 04:51:02 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:51:02 --> Database Driver Class Initialized
INFO - 2024-02-29 04:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:51:02 --> Parser Class Initialized
INFO - 2024-02-29 04:51:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:51:02 --> Pagination Class Initialized
INFO - 2024-02-29 04:51:02 --> Form Validation Class Initialized
INFO - 2024-02-29 04:51:02 --> Controller Class Initialized
INFO - 2024-02-29 04:51:02 --> Model Class Initialized
DEBUG - 2024-02-29 04:51:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:51:02 --> Model Class Initialized
DEBUG - 2024-02-29 04:51:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:51:02 --> Model Class Initialized
INFO - 2024-02-29 04:51:02 --> Model Class Initialized
INFO - 2024-02-29 04:51:02 --> Model Class Initialized
INFO - 2024-02-29 04:51:02 --> Model Class Initialized
DEBUG - 2024-02-29 04:51:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:51:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:51:02 --> Model Class Initialized
INFO - 2024-02-29 04:51:02 --> Model Class Initialized
INFO - 2024-02-29 04:51:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 04:51:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:51:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:51:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:51:02 --> Model Class Initialized
INFO - 2024-02-29 04:51:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 04:51:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 04:51:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:51:02 --> Final output sent to browser
DEBUG - 2024-02-29 04:51:02 --> Total execution time: 0.2830
ERROR - 2024-02-29 04:51:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:51:12 --> Config Class Initialized
INFO - 2024-02-29 04:51:12 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:51:12 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:51:12 --> Utf8 Class Initialized
INFO - 2024-02-29 04:51:12 --> URI Class Initialized
INFO - 2024-02-29 04:51:12 --> Router Class Initialized
INFO - 2024-02-29 04:51:12 --> Output Class Initialized
INFO - 2024-02-29 04:51:12 --> Security Class Initialized
DEBUG - 2024-02-29 04:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:51:12 --> Input Class Initialized
INFO - 2024-02-29 04:51:12 --> Language Class Initialized
INFO - 2024-02-29 04:51:12 --> Loader Class Initialized
INFO - 2024-02-29 04:51:12 --> Helper loaded: url_helper
INFO - 2024-02-29 04:51:12 --> Helper loaded: file_helper
INFO - 2024-02-29 04:51:12 --> Helper loaded: html_helper
INFO - 2024-02-29 04:51:12 --> Helper loaded: text_helper
INFO - 2024-02-29 04:51:12 --> Helper loaded: form_helper
INFO - 2024-02-29 04:51:12 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:51:12 --> Helper loaded: security_helper
INFO - 2024-02-29 04:51:12 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:51:12 --> Database Driver Class Initialized
INFO - 2024-02-29 04:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:51:12 --> Parser Class Initialized
INFO - 2024-02-29 04:51:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:51:12 --> Pagination Class Initialized
INFO - 2024-02-29 04:51:12 --> Form Validation Class Initialized
INFO - 2024-02-29 04:51:12 --> Controller Class Initialized
INFO - 2024-02-29 04:51:12 --> Model Class Initialized
DEBUG - 2024-02-29 04:51:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:51:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:51:12 --> Model Class Initialized
DEBUG - 2024-02-29 04:51:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:51:12 --> Model Class Initialized
INFO - 2024-02-29 04:51:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-29 04:51:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:51:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:51:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:51:12 --> Model Class Initialized
INFO - 2024-02-29 04:51:12 --> Model Class Initialized
INFO - 2024-02-29 04:51:12 --> Model Class Initialized
INFO - 2024-02-29 04:51:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 04:51:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 04:51:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:51:12 --> Final output sent to browser
DEBUG - 2024-02-29 04:51:12 --> Total execution time: 0.1622
ERROR - 2024-02-29 04:51:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:51:13 --> Config Class Initialized
INFO - 2024-02-29 04:51:13 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:51:13 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:51:13 --> Utf8 Class Initialized
INFO - 2024-02-29 04:51:13 --> URI Class Initialized
INFO - 2024-02-29 04:51:13 --> Router Class Initialized
INFO - 2024-02-29 04:51:13 --> Output Class Initialized
INFO - 2024-02-29 04:51:13 --> Security Class Initialized
DEBUG - 2024-02-29 04:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:51:13 --> Input Class Initialized
INFO - 2024-02-29 04:51:13 --> Language Class Initialized
INFO - 2024-02-29 04:51:13 --> Loader Class Initialized
INFO - 2024-02-29 04:51:13 --> Helper loaded: url_helper
INFO - 2024-02-29 04:51:13 --> Helper loaded: file_helper
INFO - 2024-02-29 04:51:13 --> Helper loaded: html_helper
INFO - 2024-02-29 04:51:13 --> Helper loaded: text_helper
INFO - 2024-02-29 04:51:13 --> Helper loaded: form_helper
INFO - 2024-02-29 04:51:13 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:51:13 --> Helper loaded: security_helper
INFO - 2024-02-29 04:51:13 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:51:13 --> Database Driver Class Initialized
INFO - 2024-02-29 04:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:51:13 --> Parser Class Initialized
INFO - 2024-02-29 04:51:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:51:13 --> Pagination Class Initialized
INFO - 2024-02-29 04:51:13 --> Form Validation Class Initialized
INFO - 2024-02-29 04:51:13 --> Controller Class Initialized
INFO - 2024-02-29 04:51:13 --> Model Class Initialized
DEBUG - 2024-02-29 04:51:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:51:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:51:13 --> Model Class Initialized
DEBUG - 2024-02-29 04:51:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:51:13 --> Model Class Initialized
INFO - 2024-02-29 04:51:13 --> Final output sent to browser
DEBUG - 2024-02-29 04:51:13 --> Total execution time: 0.0391
ERROR - 2024-02-29 04:51:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:51:30 --> Config Class Initialized
INFO - 2024-02-29 04:51:30 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:51:30 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:51:30 --> Utf8 Class Initialized
INFO - 2024-02-29 04:51:30 --> URI Class Initialized
INFO - 2024-02-29 04:51:30 --> Router Class Initialized
INFO - 2024-02-29 04:51:30 --> Output Class Initialized
INFO - 2024-02-29 04:51:30 --> Security Class Initialized
DEBUG - 2024-02-29 04:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:51:30 --> Input Class Initialized
INFO - 2024-02-29 04:51:30 --> Language Class Initialized
INFO - 2024-02-29 04:51:30 --> Loader Class Initialized
INFO - 2024-02-29 04:51:30 --> Helper loaded: url_helper
INFO - 2024-02-29 04:51:30 --> Helper loaded: file_helper
INFO - 2024-02-29 04:51:30 --> Helper loaded: html_helper
INFO - 2024-02-29 04:51:30 --> Helper loaded: text_helper
INFO - 2024-02-29 04:51:30 --> Helper loaded: form_helper
INFO - 2024-02-29 04:51:30 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:51:30 --> Helper loaded: security_helper
INFO - 2024-02-29 04:51:30 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:51:30 --> Database Driver Class Initialized
INFO - 2024-02-29 04:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:51:30 --> Parser Class Initialized
INFO - 2024-02-29 04:51:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:51:30 --> Pagination Class Initialized
INFO - 2024-02-29 04:51:30 --> Form Validation Class Initialized
INFO - 2024-02-29 04:51:30 --> Controller Class Initialized
INFO - 2024-02-29 04:51:30 --> Model Class Initialized
DEBUG - 2024-02-29 04:51:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:51:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:51:30 --> Model Class Initialized
DEBUG - 2024-02-29 04:51:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:51:30 --> Model Class Initialized
DEBUG - 2024-02-29 04:51:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:51:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-02-29 04:51:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:51:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:51:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:51:31 --> Model Class Initialized
INFO - 2024-02-29 04:51:31 --> Model Class Initialized
INFO - 2024-02-29 04:51:31 --> Model Class Initialized
INFO - 2024-02-29 04:51:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 04:51:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 04:51:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:51:31 --> Final output sent to browser
DEBUG - 2024-02-29 04:51:31 --> Total execution time: 0.1657
ERROR - 2024-02-29 04:51:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:51:58 --> Config Class Initialized
INFO - 2024-02-29 04:51:58 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:51:58 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:51:58 --> Utf8 Class Initialized
INFO - 2024-02-29 04:51:58 --> URI Class Initialized
INFO - 2024-02-29 04:51:58 --> Router Class Initialized
INFO - 2024-02-29 04:51:58 --> Output Class Initialized
INFO - 2024-02-29 04:51:58 --> Security Class Initialized
DEBUG - 2024-02-29 04:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:51:58 --> Input Class Initialized
INFO - 2024-02-29 04:51:58 --> Language Class Initialized
INFO - 2024-02-29 04:51:58 --> Loader Class Initialized
INFO - 2024-02-29 04:51:58 --> Helper loaded: url_helper
INFO - 2024-02-29 04:51:58 --> Helper loaded: file_helper
INFO - 2024-02-29 04:51:58 --> Helper loaded: html_helper
INFO - 2024-02-29 04:51:58 --> Helper loaded: text_helper
INFO - 2024-02-29 04:51:58 --> Helper loaded: form_helper
INFO - 2024-02-29 04:51:58 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:51:58 --> Helper loaded: security_helper
INFO - 2024-02-29 04:51:58 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:51:58 --> Database Driver Class Initialized
INFO - 2024-02-29 04:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:51:58 --> Parser Class Initialized
INFO - 2024-02-29 04:51:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:51:58 --> Pagination Class Initialized
INFO - 2024-02-29 04:51:58 --> Form Validation Class Initialized
INFO - 2024-02-29 04:51:58 --> Controller Class Initialized
INFO - 2024-02-29 04:51:58 --> Model Class Initialized
DEBUG - 2024-02-29 04:51:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:51:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:51:58 --> Model Class Initialized
DEBUG - 2024-02-29 04:51:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:51:58 --> Model Class Initialized
INFO - 2024-02-29 04:51:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-29 04:51:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:51:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:51:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:51:58 --> Model Class Initialized
INFO - 2024-02-29 04:51:58 --> Model Class Initialized
INFO - 2024-02-29 04:51:58 --> Model Class Initialized
ERROR - 2024-02-29 04:51:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 04:51:58 --> Config Class Initialized
INFO - 2024-02-29 04:51:58 --> Hooks Class Initialized
DEBUG - 2024-02-29 04:51:58 --> UTF-8 Support Enabled
INFO - 2024-02-29 04:51:58 --> Utf8 Class Initialized
INFO - 2024-02-29 04:51:58 --> URI Class Initialized
DEBUG - 2024-02-29 04:51:58 --> No URI present. Default controller set.
INFO - 2024-02-29 04:51:58 --> Router Class Initialized
INFO - 2024-02-29 04:51:58 --> Output Class Initialized
INFO - 2024-02-29 04:51:58 --> Security Class Initialized
DEBUG - 2024-02-29 04:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 04:51:58 --> Input Class Initialized
INFO - 2024-02-29 04:51:58 --> Language Class Initialized
INFO - 2024-02-29 04:51:58 --> Loader Class Initialized
INFO - 2024-02-29 04:51:58 --> Helper loaded: url_helper
INFO - 2024-02-29 04:51:58 --> Helper loaded: file_helper
INFO - 2024-02-29 04:51:58 --> Helper loaded: html_helper
INFO - 2024-02-29 04:51:58 --> Helper loaded: text_helper
INFO - 2024-02-29 04:51:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 04:51:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 04:51:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:51:58 --> Helper loaded: form_helper
INFO - 2024-02-29 04:51:58 --> Helper loaded: lang_helper
INFO - 2024-02-29 04:51:58 --> Final output sent to browser
DEBUG - 2024-02-29 04:51:58 --> Total execution time: 0.1576
INFO - 2024-02-29 04:51:58 --> Helper loaded: security_helper
INFO - 2024-02-29 04:51:58 --> Helper loaded: cookie_helper
INFO - 2024-02-29 04:51:58 --> Database Driver Class Initialized
INFO - 2024-02-29 04:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 04:51:58 --> Parser Class Initialized
INFO - 2024-02-29 04:51:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 04:51:58 --> Pagination Class Initialized
INFO - 2024-02-29 04:51:58 --> Form Validation Class Initialized
INFO - 2024-02-29 04:51:58 --> Controller Class Initialized
INFO - 2024-02-29 04:51:58 --> Model Class Initialized
DEBUG - 2024-02-29 04:51:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:51:58 --> Model Class Initialized
DEBUG - 2024-02-29 04:51:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:51:58 --> Model Class Initialized
INFO - 2024-02-29 04:51:58 --> Model Class Initialized
INFO - 2024-02-29 04:51:58 --> Model Class Initialized
INFO - 2024-02-29 04:51:58 --> Model Class Initialized
DEBUG - 2024-02-29 04:51:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 04:51:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:51:58 --> Model Class Initialized
INFO - 2024-02-29 04:51:58 --> Model Class Initialized
INFO - 2024-02-29 04:51:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 04:51:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 04:51:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 04:51:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 04:51:58 --> Model Class Initialized
INFO - 2024-02-29 04:51:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 04:51:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 04:51:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 04:51:58 --> Final output sent to browser
DEBUG - 2024-02-29 04:51:58 --> Total execution time: 0.2382
ERROR - 2024-02-29 05:11:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 05:11:33 --> Config Class Initialized
INFO - 2024-02-29 05:11:33 --> Hooks Class Initialized
DEBUG - 2024-02-29 05:11:33 --> UTF-8 Support Enabled
INFO - 2024-02-29 05:11:33 --> Utf8 Class Initialized
INFO - 2024-02-29 05:11:33 --> URI Class Initialized
DEBUG - 2024-02-29 05:11:33 --> No URI present. Default controller set.
INFO - 2024-02-29 05:11:33 --> Router Class Initialized
INFO - 2024-02-29 05:11:33 --> Output Class Initialized
INFO - 2024-02-29 05:11:33 --> Security Class Initialized
DEBUG - 2024-02-29 05:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 05:11:33 --> Input Class Initialized
INFO - 2024-02-29 05:11:33 --> Language Class Initialized
INFO - 2024-02-29 05:11:33 --> Loader Class Initialized
INFO - 2024-02-29 05:11:33 --> Helper loaded: url_helper
INFO - 2024-02-29 05:11:33 --> Helper loaded: file_helper
INFO - 2024-02-29 05:11:33 --> Helper loaded: html_helper
INFO - 2024-02-29 05:11:33 --> Helper loaded: text_helper
INFO - 2024-02-29 05:11:33 --> Helper loaded: form_helper
INFO - 2024-02-29 05:11:33 --> Helper loaded: lang_helper
INFO - 2024-02-29 05:11:33 --> Helper loaded: security_helper
INFO - 2024-02-29 05:11:33 --> Helper loaded: cookie_helper
INFO - 2024-02-29 05:11:33 --> Database Driver Class Initialized
INFO - 2024-02-29 05:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 05:11:33 --> Parser Class Initialized
INFO - 2024-02-29 05:11:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 05:11:33 --> Pagination Class Initialized
INFO - 2024-02-29 05:11:33 --> Form Validation Class Initialized
INFO - 2024-02-29 05:11:33 --> Controller Class Initialized
INFO - 2024-02-29 05:11:33 --> Model Class Initialized
DEBUG - 2024-02-29 05:11:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 05:11:33 --> Model Class Initialized
DEBUG - 2024-02-29 05:11:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 05:11:33 --> Model Class Initialized
INFO - 2024-02-29 05:11:33 --> Model Class Initialized
INFO - 2024-02-29 05:11:33 --> Model Class Initialized
INFO - 2024-02-29 05:11:33 --> Model Class Initialized
DEBUG - 2024-02-29 05:11:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 05:11:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 05:11:33 --> Model Class Initialized
INFO - 2024-02-29 05:11:33 --> Model Class Initialized
INFO - 2024-02-29 05:11:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 05:11:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 05:11:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 05:11:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 05:11:33 --> Model Class Initialized
INFO - 2024-02-29 05:11:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 05:11:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 05:11:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 05:11:33 --> Final output sent to browser
DEBUG - 2024-02-29 05:11:33 --> Total execution time: 0.2491
ERROR - 2024-02-29 05:11:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 05:11:38 --> Config Class Initialized
INFO - 2024-02-29 05:11:38 --> Hooks Class Initialized
DEBUG - 2024-02-29 05:11:38 --> UTF-8 Support Enabled
INFO - 2024-02-29 05:11:38 --> Utf8 Class Initialized
INFO - 2024-02-29 05:11:38 --> URI Class Initialized
INFO - 2024-02-29 05:11:38 --> Router Class Initialized
INFO - 2024-02-29 05:11:38 --> Output Class Initialized
INFO - 2024-02-29 05:11:38 --> Security Class Initialized
DEBUG - 2024-02-29 05:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 05:11:38 --> Input Class Initialized
INFO - 2024-02-29 05:11:38 --> Language Class Initialized
INFO - 2024-02-29 05:11:38 --> Loader Class Initialized
INFO - 2024-02-29 05:11:38 --> Helper loaded: url_helper
INFO - 2024-02-29 05:11:38 --> Helper loaded: file_helper
INFO - 2024-02-29 05:11:38 --> Helper loaded: html_helper
INFO - 2024-02-29 05:11:38 --> Helper loaded: text_helper
INFO - 2024-02-29 05:11:38 --> Helper loaded: form_helper
INFO - 2024-02-29 05:11:38 --> Helper loaded: lang_helper
INFO - 2024-02-29 05:11:38 --> Helper loaded: security_helper
INFO - 2024-02-29 05:11:38 --> Helper loaded: cookie_helper
INFO - 2024-02-29 05:11:38 --> Database Driver Class Initialized
INFO - 2024-02-29 05:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 05:11:38 --> Parser Class Initialized
INFO - 2024-02-29 05:11:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 05:11:38 --> Pagination Class Initialized
INFO - 2024-02-29 05:11:38 --> Form Validation Class Initialized
INFO - 2024-02-29 05:11:38 --> Controller Class Initialized
DEBUG - 2024-02-29 05:11:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 05:11:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 05:11:38 --> Model Class Initialized
DEBUG - 2024-02-29 05:11:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 05:11:38 --> Model Class Initialized
DEBUG - 2024-02-29 05:11:38 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-29 05:11:38 --> Model Class Initialized
INFO - 2024-02-29 05:11:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-29 05:11:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 05:11:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 05:11:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 05:11:39 --> Model Class Initialized
INFO - 2024-02-29 05:11:39 --> Model Class Initialized
INFO - 2024-02-29 05:11:39 --> Model Class Initialized
INFO - 2024-02-29 05:11:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 05:11:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 05:11:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 05:11:39 --> Final output sent to browser
DEBUG - 2024-02-29 05:11:39 --> Total execution time: 0.1714
ERROR - 2024-02-29 05:11:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 05:11:40 --> Config Class Initialized
INFO - 2024-02-29 05:11:40 --> Hooks Class Initialized
DEBUG - 2024-02-29 05:11:40 --> UTF-8 Support Enabled
INFO - 2024-02-29 05:11:40 --> Utf8 Class Initialized
INFO - 2024-02-29 05:11:40 --> URI Class Initialized
INFO - 2024-02-29 05:11:40 --> Router Class Initialized
INFO - 2024-02-29 05:11:40 --> Output Class Initialized
INFO - 2024-02-29 05:11:40 --> Security Class Initialized
DEBUG - 2024-02-29 05:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 05:11:40 --> Input Class Initialized
INFO - 2024-02-29 05:11:40 --> Language Class Initialized
INFO - 2024-02-29 05:11:40 --> Loader Class Initialized
INFO - 2024-02-29 05:11:40 --> Helper loaded: url_helper
INFO - 2024-02-29 05:11:40 --> Helper loaded: file_helper
INFO - 2024-02-29 05:11:40 --> Helper loaded: html_helper
INFO - 2024-02-29 05:11:40 --> Helper loaded: text_helper
INFO - 2024-02-29 05:11:40 --> Helper loaded: form_helper
INFO - 2024-02-29 05:11:40 --> Helper loaded: lang_helper
INFO - 2024-02-29 05:11:40 --> Helper loaded: security_helper
INFO - 2024-02-29 05:11:40 --> Helper loaded: cookie_helper
INFO - 2024-02-29 05:11:40 --> Database Driver Class Initialized
INFO - 2024-02-29 05:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 05:11:40 --> Parser Class Initialized
INFO - 2024-02-29 05:11:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 05:11:40 --> Pagination Class Initialized
INFO - 2024-02-29 05:11:40 --> Form Validation Class Initialized
INFO - 2024-02-29 05:11:40 --> Controller Class Initialized
DEBUG - 2024-02-29 05:11:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 05:11:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 05:11:40 --> Model Class Initialized
DEBUG - 2024-02-29 05:11:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 05:11:40 --> Model Class Initialized
INFO - 2024-02-29 05:11:40 --> Final output sent to browser
DEBUG - 2024-02-29 05:11:40 --> Total execution time: 0.0272
ERROR - 2024-02-29 05:11:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 05:11:46 --> Config Class Initialized
INFO - 2024-02-29 05:11:46 --> Hooks Class Initialized
DEBUG - 2024-02-29 05:11:46 --> UTF-8 Support Enabled
INFO - 2024-02-29 05:11:46 --> Utf8 Class Initialized
INFO - 2024-02-29 05:11:46 --> URI Class Initialized
INFO - 2024-02-29 05:11:46 --> Router Class Initialized
INFO - 2024-02-29 05:11:46 --> Output Class Initialized
INFO - 2024-02-29 05:11:46 --> Security Class Initialized
DEBUG - 2024-02-29 05:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 05:11:46 --> Input Class Initialized
INFO - 2024-02-29 05:11:46 --> Language Class Initialized
INFO - 2024-02-29 05:11:46 --> Loader Class Initialized
INFO - 2024-02-29 05:11:46 --> Helper loaded: url_helper
INFO - 2024-02-29 05:11:46 --> Helper loaded: file_helper
INFO - 2024-02-29 05:11:46 --> Helper loaded: html_helper
INFO - 2024-02-29 05:11:46 --> Helper loaded: text_helper
INFO - 2024-02-29 05:11:46 --> Helper loaded: form_helper
INFO - 2024-02-29 05:11:46 --> Helper loaded: lang_helper
INFO - 2024-02-29 05:11:46 --> Helper loaded: security_helper
INFO - 2024-02-29 05:11:46 --> Helper loaded: cookie_helper
INFO - 2024-02-29 05:11:46 --> Database Driver Class Initialized
INFO - 2024-02-29 05:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 05:11:46 --> Parser Class Initialized
INFO - 2024-02-29 05:11:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 05:11:46 --> Pagination Class Initialized
INFO - 2024-02-29 05:11:46 --> Form Validation Class Initialized
INFO - 2024-02-29 05:11:46 --> Controller Class Initialized
DEBUG - 2024-02-29 05:11:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 05:11:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 05:11:46 --> Model Class Initialized
DEBUG - 2024-02-29 05:11:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 05:11:46 --> Model Class Initialized
INFO - 2024-02-29 05:11:46 --> Final output sent to browser
DEBUG - 2024-02-29 05:11:46 --> Total execution time: 0.0385
ERROR - 2024-02-29 05:13:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 05:13:56 --> Config Class Initialized
INFO - 2024-02-29 05:13:56 --> Hooks Class Initialized
DEBUG - 2024-02-29 05:13:56 --> UTF-8 Support Enabled
INFO - 2024-02-29 05:13:56 --> Utf8 Class Initialized
INFO - 2024-02-29 05:13:56 --> URI Class Initialized
INFO - 2024-02-29 05:13:56 --> Router Class Initialized
INFO - 2024-02-29 05:13:56 --> Output Class Initialized
INFO - 2024-02-29 05:13:56 --> Security Class Initialized
DEBUG - 2024-02-29 05:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 05:13:56 --> Input Class Initialized
INFO - 2024-02-29 05:13:56 --> Language Class Initialized
ERROR - 2024-02-29 05:13:56 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-02-29 05:24:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 05:24:27 --> Config Class Initialized
INFO - 2024-02-29 05:24:27 --> Hooks Class Initialized
DEBUG - 2024-02-29 05:24:27 --> UTF-8 Support Enabled
INFO - 2024-02-29 05:24:27 --> Utf8 Class Initialized
INFO - 2024-02-29 05:24:27 --> URI Class Initialized
DEBUG - 2024-02-29 05:24:27 --> No URI present. Default controller set.
INFO - 2024-02-29 05:24:27 --> Router Class Initialized
INFO - 2024-02-29 05:24:27 --> Output Class Initialized
INFO - 2024-02-29 05:24:27 --> Security Class Initialized
DEBUG - 2024-02-29 05:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 05:24:27 --> Input Class Initialized
INFO - 2024-02-29 05:24:27 --> Language Class Initialized
INFO - 2024-02-29 05:24:27 --> Loader Class Initialized
INFO - 2024-02-29 05:24:27 --> Helper loaded: url_helper
INFO - 2024-02-29 05:24:27 --> Helper loaded: file_helper
INFO - 2024-02-29 05:24:27 --> Helper loaded: html_helper
INFO - 2024-02-29 05:24:27 --> Helper loaded: text_helper
INFO - 2024-02-29 05:24:27 --> Helper loaded: form_helper
INFO - 2024-02-29 05:24:27 --> Helper loaded: lang_helper
INFO - 2024-02-29 05:24:27 --> Helper loaded: security_helper
INFO - 2024-02-29 05:24:27 --> Helper loaded: cookie_helper
INFO - 2024-02-29 05:24:27 --> Database Driver Class Initialized
INFO - 2024-02-29 05:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 05:24:27 --> Parser Class Initialized
INFO - 2024-02-29 05:24:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 05:24:27 --> Pagination Class Initialized
INFO - 2024-02-29 05:24:27 --> Form Validation Class Initialized
INFO - 2024-02-29 05:24:27 --> Controller Class Initialized
INFO - 2024-02-29 05:24:27 --> Model Class Initialized
DEBUG - 2024-02-29 05:24:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 05:24:27 --> Model Class Initialized
DEBUG - 2024-02-29 05:24:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 05:24:27 --> Model Class Initialized
INFO - 2024-02-29 05:24:27 --> Model Class Initialized
INFO - 2024-02-29 05:24:27 --> Model Class Initialized
INFO - 2024-02-29 05:24:27 --> Model Class Initialized
DEBUG - 2024-02-29 05:24:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 05:24:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 05:24:27 --> Model Class Initialized
INFO - 2024-02-29 05:24:27 --> Model Class Initialized
INFO - 2024-02-29 05:24:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 05:24:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 05:24:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 05:24:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 05:24:27 --> Model Class Initialized
INFO - 2024-02-29 05:24:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 05:24:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 05:24:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 05:24:27 --> Final output sent to browser
DEBUG - 2024-02-29 05:24:27 --> Total execution time: 0.2400
ERROR - 2024-02-29 05:24:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 05:24:33 --> Config Class Initialized
INFO - 2024-02-29 05:24:33 --> Hooks Class Initialized
DEBUG - 2024-02-29 05:24:33 --> UTF-8 Support Enabled
INFO - 2024-02-29 05:24:33 --> Utf8 Class Initialized
INFO - 2024-02-29 05:24:33 --> URI Class Initialized
INFO - 2024-02-29 05:24:33 --> Router Class Initialized
INFO - 2024-02-29 05:24:33 --> Output Class Initialized
INFO - 2024-02-29 05:24:33 --> Security Class Initialized
DEBUG - 2024-02-29 05:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 05:24:33 --> Input Class Initialized
INFO - 2024-02-29 05:24:33 --> Language Class Initialized
INFO - 2024-02-29 05:24:33 --> Loader Class Initialized
INFO - 2024-02-29 05:24:33 --> Helper loaded: url_helper
INFO - 2024-02-29 05:24:33 --> Helper loaded: file_helper
INFO - 2024-02-29 05:24:33 --> Helper loaded: html_helper
INFO - 2024-02-29 05:24:33 --> Helper loaded: text_helper
INFO - 2024-02-29 05:24:33 --> Helper loaded: form_helper
INFO - 2024-02-29 05:24:33 --> Helper loaded: lang_helper
INFO - 2024-02-29 05:24:33 --> Helper loaded: security_helper
INFO - 2024-02-29 05:24:33 --> Helper loaded: cookie_helper
INFO - 2024-02-29 05:24:33 --> Database Driver Class Initialized
INFO - 2024-02-29 05:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 05:24:33 --> Parser Class Initialized
INFO - 2024-02-29 05:24:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 05:24:33 --> Pagination Class Initialized
INFO - 2024-02-29 05:24:33 --> Form Validation Class Initialized
INFO - 2024-02-29 05:24:33 --> Controller Class Initialized
INFO - 2024-02-29 05:24:33 --> Model Class Initialized
DEBUG - 2024-02-29 05:24:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 05:24:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 05:24:33 --> Model Class Initialized
DEBUG - 2024-02-29 05:24:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 05:24:33 --> Model Class Initialized
INFO - 2024-02-29 05:24:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-29 05:24:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 05:24:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 05:24:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 05:24:33 --> Model Class Initialized
INFO - 2024-02-29 05:24:33 --> Model Class Initialized
INFO - 2024-02-29 05:24:33 --> Model Class Initialized
INFO - 2024-02-29 05:24:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 05:24:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 05:24:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 05:24:33 --> Final output sent to browser
DEBUG - 2024-02-29 05:24:33 --> Total execution time: 0.1586
ERROR - 2024-02-29 05:24:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 05:24:34 --> Config Class Initialized
INFO - 2024-02-29 05:24:34 --> Hooks Class Initialized
DEBUG - 2024-02-29 05:24:34 --> UTF-8 Support Enabled
INFO - 2024-02-29 05:24:34 --> Utf8 Class Initialized
INFO - 2024-02-29 05:24:34 --> URI Class Initialized
INFO - 2024-02-29 05:24:34 --> Router Class Initialized
INFO - 2024-02-29 05:24:34 --> Output Class Initialized
INFO - 2024-02-29 05:24:34 --> Security Class Initialized
DEBUG - 2024-02-29 05:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 05:24:34 --> Input Class Initialized
INFO - 2024-02-29 05:24:34 --> Language Class Initialized
INFO - 2024-02-29 05:24:34 --> Loader Class Initialized
INFO - 2024-02-29 05:24:34 --> Helper loaded: url_helper
INFO - 2024-02-29 05:24:34 --> Helper loaded: file_helper
INFO - 2024-02-29 05:24:34 --> Helper loaded: html_helper
INFO - 2024-02-29 05:24:34 --> Helper loaded: text_helper
INFO - 2024-02-29 05:24:34 --> Helper loaded: form_helper
INFO - 2024-02-29 05:24:34 --> Helper loaded: lang_helper
INFO - 2024-02-29 05:24:34 --> Helper loaded: security_helper
INFO - 2024-02-29 05:24:34 --> Helper loaded: cookie_helper
INFO - 2024-02-29 05:24:34 --> Database Driver Class Initialized
INFO - 2024-02-29 05:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 05:24:34 --> Parser Class Initialized
INFO - 2024-02-29 05:24:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 05:24:34 --> Pagination Class Initialized
INFO - 2024-02-29 05:24:34 --> Form Validation Class Initialized
INFO - 2024-02-29 05:24:34 --> Controller Class Initialized
INFO - 2024-02-29 05:24:34 --> Model Class Initialized
DEBUG - 2024-02-29 05:24:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 05:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 05:24:34 --> Model Class Initialized
DEBUG - 2024-02-29 05:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 05:24:34 --> Model Class Initialized
INFO - 2024-02-29 05:24:34 --> Final output sent to browser
DEBUG - 2024-02-29 05:24:34 --> Total execution time: 0.0406
ERROR - 2024-02-29 05:24:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 05:24:42 --> Config Class Initialized
INFO - 2024-02-29 05:24:42 --> Hooks Class Initialized
DEBUG - 2024-02-29 05:24:42 --> UTF-8 Support Enabled
INFO - 2024-02-29 05:24:42 --> Utf8 Class Initialized
INFO - 2024-02-29 05:24:42 --> URI Class Initialized
INFO - 2024-02-29 05:24:42 --> Router Class Initialized
INFO - 2024-02-29 05:24:42 --> Output Class Initialized
INFO - 2024-02-29 05:24:42 --> Security Class Initialized
DEBUG - 2024-02-29 05:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 05:24:42 --> Input Class Initialized
INFO - 2024-02-29 05:24:42 --> Language Class Initialized
INFO - 2024-02-29 05:24:42 --> Loader Class Initialized
INFO - 2024-02-29 05:24:42 --> Helper loaded: url_helper
INFO - 2024-02-29 05:24:42 --> Helper loaded: file_helper
INFO - 2024-02-29 05:24:42 --> Helper loaded: html_helper
INFO - 2024-02-29 05:24:42 --> Helper loaded: text_helper
INFO - 2024-02-29 05:24:42 --> Helper loaded: form_helper
INFO - 2024-02-29 05:24:42 --> Helper loaded: lang_helper
INFO - 2024-02-29 05:24:42 --> Helper loaded: security_helper
INFO - 2024-02-29 05:24:42 --> Helper loaded: cookie_helper
INFO - 2024-02-29 05:24:42 --> Database Driver Class Initialized
INFO - 2024-02-29 05:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 05:24:42 --> Parser Class Initialized
INFO - 2024-02-29 05:24:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 05:24:42 --> Pagination Class Initialized
INFO - 2024-02-29 05:24:42 --> Form Validation Class Initialized
INFO - 2024-02-29 05:24:42 --> Controller Class Initialized
INFO - 2024-02-29 05:24:42 --> Model Class Initialized
DEBUG - 2024-02-29 05:24:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 05:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 05:24:42 --> Model Class Initialized
DEBUG - 2024-02-29 05:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 05:24:42 --> Model Class Initialized
DEBUG - 2024-02-29 05:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 05:24:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-02-29 05:24:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 05:24:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 05:24:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 05:24:42 --> Model Class Initialized
INFO - 2024-02-29 05:24:42 --> Model Class Initialized
INFO - 2024-02-29 05:24:42 --> Model Class Initialized
INFO - 2024-02-29 05:24:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 05:24:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 05:24:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 05:24:42 --> Final output sent to browser
DEBUG - 2024-02-29 05:24:42 --> Total execution time: 0.1769
ERROR - 2024-02-29 06:16:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 06:16:00 --> Config Class Initialized
INFO - 2024-02-29 06:16:00 --> Hooks Class Initialized
DEBUG - 2024-02-29 06:16:00 --> UTF-8 Support Enabled
INFO - 2024-02-29 06:16:00 --> Utf8 Class Initialized
INFO - 2024-02-29 06:16:00 --> URI Class Initialized
DEBUG - 2024-02-29 06:16:00 --> No URI present. Default controller set.
INFO - 2024-02-29 06:16:00 --> Router Class Initialized
INFO - 2024-02-29 06:16:00 --> Output Class Initialized
INFO - 2024-02-29 06:16:00 --> Security Class Initialized
DEBUG - 2024-02-29 06:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 06:16:00 --> Input Class Initialized
INFO - 2024-02-29 06:16:00 --> Language Class Initialized
INFO - 2024-02-29 06:16:00 --> Loader Class Initialized
INFO - 2024-02-29 06:16:00 --> Helper loaded: url_helper
INFO - 2024-02-29 06:16:00 --> Helper loaded: file_helper
INFO - 2024-02-29 06:16:00 --> Helper loaded: html_helper
INFO - 2024-02-29 06:16:00 --> Helper loaded: text_helper
INFO - 2024-02-29 06:16:00 --> Helper loaded: form_helper
INFO - 2024-02-29 06:16:00 --> Helper loaded: lang_helper
INFO - 2024-02-29 06:16:00 --> Helper loaded: security_helper
INFO - 2024-02-29 06:16:00 --> Helper loaded: cookie_helper
INFO - 2024-02-29 06:16:00 --> Database Driver Class Initialized
INFO - 2024-02-29 06:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 06:16:00 --> Parser Class Initialized
INFO - 2024-02-29 06:16:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 06:16:00 --> Pagination Class Initialized
INFO - 2024-02-29 06:16:00 --> Form Validation Class Initialized
INFO - 2024-02-29 06:16:00 --> Controller Class Initialized
INFO - 2024-02-29 06:16:00 --> Model Class Initialized
DEBUG - 2024-02-29 06:16:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-29 06:16:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 06:16:00 --> Config Class Initialized
INFO - 2024-02-29 06:16:00 --> Hooks Class Initialized
DEBUG - 2024-02-29 06:16:00 --> UTF-8 Support Enabled
INFO - 2024-02-29 06:16:00 --> Utf8 Class Initialized
INFO - 2024-02-29 06:16:00 --> URI Class Initialized
INFO - 2024-02-29 06:16:00 --> Router Class Initialized
INFO - 2024-02-29 06:16:00 --> Output Class Initialized
INFO - 2024-02-29 06:16:00 --> Security Class Initialized
DEBUG - 2024-02-29 06:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 06:16:00 --> Input Class Initialized
INFO - 2024-02-29 06:16:00 --> Language Class Initialized
INFO - 2024-02-29 06:16:00 --> Loader Class Initialized
INFO - 2024-02-29 06:16:00 --> Helper loaded: url_helper
INFO - 2024-02-29 06:16:00 --> Helper loaded: file_helper
INFO - 2024-02-29 06:16:00 --> Helper loaded: html_helper
INFO - 2024-02-29 06:16:00 --> Helper loaded: text_helper
INFO - 2024-02-29 06:16:00 --> Helper loaded: form_helper
INFO - 2024-02-29 06:16:00 --> Helper loaded: lang_helper
INFO - 2024-02-29 06:16:00 --> Helper loaded: security_helper
INFO - 2024-02-29 06:16:00 --> Helper loaded: cookie_helper
INFO - 2024-02-29 06:16:00 --> Database Driver Class Initialized
INFO - 2024-02-29 06:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 06:16:00 --> Parser Class Initialized
INFO - 2024-02-29 06:16:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 06:16:00 --> Pagination Class Initialized
INFO - 2024-02-29 06:16:00 --> Form Validation Class Initialized
INFO - 2024-02-29 06:16:00 --> Controller Class Initialized
INFO - 2024-02-29 06:16:00 --> Model Class Initialized
DEBUG - 2024-02-29 06:16:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:16:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-29 06:16:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:16:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 06:16:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 06:16:00 --> Model Class Initialized
INFO - 2024-02-29 06:16:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 06:16:00 --> Final output sent to browser
DEBUG - 2024-02-29 06:16:00 --> Total execution time: 0.0293
ERROR - 2024-02-29 06:16:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 06:16:06 --> Config Class Initialized
INFO - 2024-02-29 06:16:06 --> Hooks Class Initialized
DEBUG - 2024-02-29 06:16:06 --> UTF-8 Support Enabled
INFO - 2024-02-29 06:16:06 --> Utf8 Class Initialized
INFO - 2024-02-29 06:16:06 --> URI Class Initialized
INFO - 2024-02-29 06:16:06 --> Router Class Initialized
INFO - 2024-02-29 06:16:06 --> Output Class Initialized
INFO - 2024-02-29 06:16:06 --> Security Class Initialized
DEBUG - 2024-02-29 06:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 06:16:06 --> Input Class Initialized
INFO - 2024-02-29 06:16:06 --> Language Class Initialized
INFO - 2024-02-29 06:16:06 --> Loader Class Initialized
INFO - 2024-02-29 06:16:06 --> Helper loaded: url_helper
INFO - 2024-02-29 06:16:06 --> Helper loaded: file_helper
INFO - 2024-02-29 06:16:06 --> Helper loaded: html_helper
INFO - 2024-02-29 06:16:06 --> Helper loaded: text_helper
INFO - 2024-02-29 06:16:06 --> Helper loaded: form_helper
INFO - 2024-02-29 06:16:06 --> Helper loaded: lang_helper
INFO - 2024-02-29 06:16:06 --> Helper loaded: security_helper
INFO - 2024-02-29 06:16:06 --> Helper loaded: cookie_helper
INFO - 2024-02-29 06:16:06 --> Database Driver Class Initialized
INFO - 2024-02-29 06:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 06:16:06 --> Parser Class Initialized
INFO - 2024-02-29 06:16:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 06:16:06 --> Pagination Class Initialized
INFO - 2024-02-29 06:16:06 --> Form Validation Class Initialized
INFO - 2024-02-29 06:16:06 --> Controller Class Initialized
INFO - 2024-02-29 06:16:06 --> Model Class Initialized
DEBUG - 2024-02-29 06:16:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:16:06 --> Model Class Initialized
INFO - 2024-02-29 06:16:06 --> Final output sent to browser
DEBUG - 2024-02-29 06:16:06 --> Total execution time: 0.0223
ERROR - 2024-02-29 06:16:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 06:16:07 --> Config Class Initialized
INFO - 2024-02-29 06:16:07 --> Hooks Class Initialized
DEBUG - 2024-02-29 06:16:07 --> UTF-8 Support Enabled
INFO - 2024-02-29 06:16:07 --> Utf8 Class Initialized
INFO - 2024-02-29 06:16:07 --> URI Class Initialized
DEBUG - 2024-02-29 06:16:07 --> No URI present. Default controller set.
INFO - 2024-02-29 06:16:07 --> Router Class Initialized
INFO - 2024-02-29 06:16:07 --> Output Class Initialized
INFO - 2024-02-29 06:16:07 --> Security Class Initialized
DEBUG - 2024-02-29 06:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 06:16:07 --> Input Class Initialized
INFO - 2024-02-29 06:16:07 --> Language Class Initialized
INFO - 2024-02-29 06:16:07 --> Loader Class Initialized
INFO - 2024-02-29 06:16:07 --> Helper loaded: url_helper
INFO - 2024-02-29 06:16:07 --> Helper loaded: file_helper
INFO - 2024-02-29 06:16:07 --> Helper loaded: html_helper
INFO - 2024-02-29 06:16:07 --> Helper loaded: text_helper
INFO - 2024-02-29 06:16:07 --> Helper loaded: form_helper
INFO - 2024-02-29 06:16:07 --> Helper loaded: lang_helper
INFO - 2024-02-29 06:16:07 --> Helper loaded: security_helper
INFO - 2024-02-29 06:16:07 --> Helper loaded: cookie_helper
INFO - 2024-02-29 06:16:07 --> Database Driver Class Initialized
INFO - 2024-02-29 06:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 06:16:07 --> Parser Class Initialized
INFO - 2024-02-29 06:16:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 06:16:07 --> Pagination Class Initialized
INFO - 2024-02-29 06:16:07 --> Form Validation Class Initialized
INFO - 2024-02-29 06:16:07 --> Controller Class Initialized
INFO - 2024-02-29 06:16:07 --> Model Class Initialized
DEBUG - 2024-02-29 06:16:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:16:07 --> Model Class Initialized
DEBUG - 2024-02-29 06:16:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:16:07 --> Model Class Initialized
INFO - 2024-02-29 06:16:07 --> Model Class Initialized
INFO - 2024-02-29 06:16:07 --> Model Class Initialized
INFO - 2024-02-29 06:16:07 --> Model Class Initialized
DEBUG - 2024-02-29 06:16:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 06:16:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:16:07 --> Model Class Initialized
INFO - 2024-02-29 06:16:07 --> Model Class Initialized
INFO - 2024-02-29 06:16:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 06:16:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:16:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 06:16:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 06:16:07 --> Model Class Initialized
INFO - 2024-02-29 06:16:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 06:16:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 06:16:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 06:16:07 --> Final output sent to browser
DEBUG - 2024-02-29 06:16:07 --> Total execution time: 0.4215
ERROR - 2024-02-29 06:16:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 06:16:07 --> Config Class Initialized
INFO - 2024-02-29 06:16:07 --> Hooks Class Initialized
DEBUG - 2024-02-29 06:16:07 --> UTF-8 Support Enabled
INFO - 2024-02-29 06:16:07 --> Utf8 Class Initialized
INFO - 2024-02-29 06:16:07 --> URI Class Initialized
INFO - 2024-02-29 06:16:07 --> Router Class Initialized
INFO - 2024-02-29 06:16:07 --> Output Class Initialized
INFO - 2024-02-29 06:16:07 --> Security Class Initialized
DEBUG - 2024-02-29 06:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 06:16:07 --> Input Class Initialized
INFO - 2024-02-29 06:16:07 --> Language Class Initialized
INFO - 2024-02-29 06:16:07 --> Loader Class Initialized
INFO - 2024-02-29 06:16:07 --> Helper loaded: url_helper
INFO - 2024-02-29 06:16:07 --> Helper loaded: file_helper
INFO - 2024-02-29 06:16:07 --> Helper loaded: html_helper
INFO - 2024-02-29 06:16:07 --> Helper loaded: text_helper
INFO - 2024-02-29 06:16:07 --> Helper loaded: form_helper
INFO - 2024-02-29 06:16:07 --> Helper loaded: lang_helper
INFO - 2024-02-29 06:16:07 --> Helper loaded: security_helper
INFO - 2024-02-29 06:16:07 --> Helper loaded: cookie_helper
INFO - 2024-02-29 06:16:07 --> Database Driver Class Initialized
INFO - 2024-02-29 06:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 06:16:07 --> Parser Class Initialized
INFO - 2024-02-29 06:16:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 06:16:07 --> Pagination Class Initialized
INFO - 2024-02-29 06:16:07 --> Form Validation Class Initialized
INFO - 2024-02-29 06:16:07 --> Controller Class Initialized
DEBUG - 2024-02-29 06:16:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 06:16:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:16:07 --> Model Class Initialized
INFO - 2024-02-29 06:16:07 --> Final output sent to browser
DEBUG - 2024-02-29 06:16:07 --> Total execution time: 0.0136
ERROR - 2024-02-29 06:16:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 06:16:12 --> Config Class Initialized
INFO - 2024-02-29 06:16:12 --> Hooks Class Initialized
DEBUG - 2024-02-29 06:16:12 --> UTF-8 Support Enabled
INFO - 2024-02-29 06:16:12 --> Utf8 Class Initialized
INFO - 2024-02-29 06:16:12 --> URI Class Initialized
INFO - 2024-02-29 06:16:12 --> Router Class Initialized
INFO - 2024-02-29 06:16:12 --> Output Class Initialized
INFO - 2024-02-29 06:16:12 --> Security Class Initialized
DEBUG - 2024-02-29 06:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 06:16:12 --> Input Class Initialized
INFO - 2024-02-29 06:16:12 --> Language Class Initialized
INFO - 2024-02-29 06:16:12 --> Loader Class Initialized
INFO - 2024-02-29 06:16:12 --> Helper loaded: url_helper
INFO - 2024-02-29 06:16:12 --> Helper loaded: file_helper
INFO - 2024-02-29 06:16:12 --> Helper loaded: html_helper
INFO - 2024-02-29 06:16:12 --> Helper loaded: text_helper
INFO - 2024-02-29 06:16:12 --> Helper loaded: form_helper
INFO - 2024-02-29 06:16:12 --> Helper loaded: lang_helper
INFO - 2024-02-29 06:16:12 --> Helper loaded: security_helper
INFO - 2024-02-29 06:16:12 --> Helper loaded: cookie_helper
INFO - 2024-02-29 06:16:12 --> Database Driver Class Initialized
INFO - 2024-02-29 06:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 06:16:12 --> Parser Class Initialized
INFO - 2024-02-29 06:16:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 06:16:12 --> Pagination Class Initialized
INFO - 2024-02-29 06:16:12 --> Form Validation Class Initialized
INFO - 2024-02-29 06:16:12 --> Controller Class Initialized
INFO - 2024-02-29 06:16:12 --> Model Class Initialized
DEBUG - 2024-02-29 06:16:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:16:12 --> Final output sent to browser
DEBUG - 2024-02-29 06:16:12 --> Total execution time: 0.0123
ERROR - 2024-02-29 06:16:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 06:16:12 --> Config Class Initialized
INFO - 2024-02-29 06:16:12 --> Hooks Class Initialized
DEBUG - 2024-02-29 06:16:12 --> UTF-8 Support Enabled
INFO - 2024-02-29 06:16:12 --> Utf8 Class Initialized
INFO - 2024-02-29 06:16:12 --> URI Class Initialized
INFO - 2024-02-29 06:16:12 --> Router Class Initialized
INFO - 2024-02-29 06:16:12 --> Output Class Initialized
INFO - 2024-02-29 06:16:12 --> Security Class Initialized
DEBUG - 2024-02-29 06:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 06:16:12 --> Input Class Initialized
INFO - 2024-02-29 06:16:12 --> Language Class Initialized
INFO - 2024-02-29 06:16:12 --> Loader Class Initialized
INFO - 2024-02-29 06:16:12 --> Helper loaded: url_helper
INFO - 2024-02-29 06:16:12 --> Helper loaded: file_helper
INFO - 2024-02-29 06:16:12 --> Helper loaded: html_helper
INFO - 2024-02-29 06:16:12 --> Helper loaded: text_helper
INFO - 2024-02-29 06:16:12 --> Helper loaded: form_helper
INFO - 2024-02-29 06:16:12 --> Helper loaded: lang_helper
INFO - 2024-02-29 06:16:12 --> Helper loaded: security_helper
INFO - 2024-02-29 06:16:12 --> Helper loaded: cookie_helper
INFO - 2024-02-29 06:16:12 --> Database Driver Class Initialized
INFO - 2024-02-29 06:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 06:16:12 --> Parser Class Initialized
INFO - 2024-02-29 06:16:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 06:16:12 --> Pagination Class Initialized
INFO - 2024-02-29 06:16:12 --> Form Validation Class Initialized
INFO - 2024-02-29 06:16:12 --> Controller Class Initialized
INFO - 2024-02-29 06:16:12 --> Model Class Initialized
DEBUG - 2024-02-29 06:16:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:16:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-29 06:16:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:16:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 06:16:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 06:16:12 --> Model Class Initialized
INFO - 2024-02-29 06:16:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 06:16:12 --> Final output sent to browser
DEBUG - 2024-02-29 06:16:12 --> Total execution time: 0.0272
ERROR - 2024-02-29 06:16:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 06:16:18 --> Config Class Initialized
INFO - 2024-02-29 06:16:18 --> Hooks Class Initialized
DEBUG - 2024-02-29 06:16:18 --> UTF-8 Support Enabled
INFO - 2024-02-29 06:16:18 --> Utf8 Class Initialized
INFO - 2024-02-29 06:16:18 --> URI Class Initialized
INFO - 2024-02-29 06:16:18 --> Router Class Initialized
INFO - 2024-02-29 06:16:18 --> Output Class Initialized
INFO - 2024-02-29 06:16:18 --> Security Class Initialized
DEBUG - 2024-02-29 06:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 06:16:18 --> Input Class Initialized
INFO - 2024-02-29 06:16:18 --> Language Class Initialized
INFO - 2024-02-29 06:16:18 --> Loader Class Initialized
INFO - 2024-02-29 06:16:18 --> Helper loaded: url_helper
INFO - 2024-02-29 06:16:18 --> Helper loaded: file_helper
INFO - 2024-02-29 06:16:18 --> Helper loaded: html_helper
INFO - 2024-02-29 06:16:18 --> Helper loaded: text_helper
INFO - 2024-02-29 06:16:18 --> Helper loaded: form_helper
INFO - 2024-02-29 06:16:18 --> Helper loaded: lang_helper
INFO - 2024-02-29 06:16:18 --> Helper loaded: security_helper
INFO - 2024-02-29 06:16:18 --> Helper loaded: cookie_helper
INFO - 2024-02-29 06:16:18 --> Database Driver Class Initialized
INFO - 2024-02-29 06:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 06:16:18 --> Parser Class Initialized
INFO - 2024-02-29 06:16:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 06:16:18 --> Pagination Class Initialized
INFO - 2024-02-29 06:16:18 --> Form Validation Class Initialized
INFO - 2024-02-29 06:16:18 --> Controller Class Initialized
INFO - 2024-02-29 06:16:18 --> Model Class Initialized
DEBUG - 2024-02-29 06:16:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:16:18 --> Model Class Initialized
INFO - 2024-02-29 06:16:18 --> Final output sent to browser
DEBUG - 2024-02-29 06:16:18 --> Total execution time: 0.0197
ERROR - 2024-02-29 06:16:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 06:16:18 --> Config Class Initialized
INFO - 2024-02-29 06:16:18 --> Hooks Class Initialized
DEBUG - 2024-02-29 06:16:18 --> UTF-8 Support Enabled
INFO - 2024-02-29 06:16:18 --> Utf8 Class Initialized
INFO - 2024-02-29 06:16:18 --> URI Class Initialized
DEBUG - 2024-02-29 06:16:18 --> No URI present. Default controller set.
INFO - 2024-02-29 06:16:18 --> Router Class Initialized
INFO - 2024-02-29 06:16:18 --> Output Class Initialized
INFO - 2024-02-29 06:16:18 --> Security Class Initialized
DEBUG - 2024-02-29 06:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 06:16:18 --> Input Class Initialized
INFO - 2024-02-29 06:16:18 --> Language Class Initialized
INFO - 2024-02-29 06:16:18 --> Loader Class Initialized
INFO - 2024-02-29 06:16:18 --> Helper loaded: url_helper
INFO - 2024-02-29 06:16:18 --> Helper loaded: file_helper
INFO - 2024-02-29 06:16:18 --> Helper loaded: html_helper
INFO - 2024-02-29 06:16:18 --> Helper loaded: text_helper
INFO - 2024-02-29 06:16:18 --> Helper loaded: form_helper
INFO - 2024-02-29 06:16:18 --> Helper loaded: lang_helper
INFO - 2024-02-29 06:16:18 --> Helper loaded: security_helper
INFO - 2024-02-29 06:16:18 --> Helper loaded: cookie_helper
INFO - 2024-02-29 06:16:18 --> Database Driver Class Initialized
INFO - 2024-02-29 06:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 06:16:18 --> Parser Class Initialized
INFO - 2024-02-29 06:16:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 06:16:18 --> Pagination Class Initialized
INFO - 2024-02-29 06:16:18 --> Form Validation Class Initialized
INFO - 2024-02-29 06:16:18 --> Controller Class Initialized
INFO - 2024-02-29 06:16:18 --> Model Class Initialized
DEBUG - 2024-02-29 06:16:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:16:18 --> Model Class Initialized
DEBUG - 2024-02-29 06:16:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:16:18 --> Model Class Initialized
INFO - 2024-02-29 06:16:18 --> Model Class Initialized
INFO - 2024-02-29 06:16:18 --> Model Class Initialized
INFO - 2024-02-29 06:16:18 --> Model Class Initialized
DEBUG - 2024-02-29 06:16:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 06:16:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:16:18 --> Model Class Initialized
INFO - 2024-02-29 06:16:18 --> Model Class Initialized
INFO - 2024-02-29 06:16:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 06:16:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:16:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 06:16:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 06:16:18 --> Model Class Initialized
INFO - 2024-02-29 06:16:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 06:16:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 06:16:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 06:16:18 --> Final output sent to browser
DEBUG - 2024-02-29 06:16:18 --> Total execution time: 0.2367
ERROR - 2024-02-29 06:16:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 06:16:22 --> Config Class Initialized
INFO - 2024-02-29 06:16:22 --> Hooks Class Initialized
DEBUG - 2024-02-29 06:16:22 --> UTF-8 Support Enabled
INFO - 2024-02-29 06:16:22 --> Utf8 Class Initialized
INFO - 2024-02-29 06:16:22 --> URI Class Initialized
INFO - 2024-02-29 06:16:22 --> Router Class Initialized
INFO - 2024-02-29 06:16:22 --> Output Class Initialized
INFO - 2024-02-29 06:16:22 --> Security Class Initialized
DEBUG - 2024-02-29 06:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 06:16:22 --> Input Class Initialized
INFO - 2024-02-29 06:16:22 --> Language Class Initialized
INFO - 2024-02-29 06:16:22 --> Loader Class Initialized
INFO - 2024-02-29 06:16:22 --> Helper loaded: url_helper
INFO - 2024-02-29 06:16:22 --> Helper loaded: file_helper
INFO - 2024-02-29 06:16:22 --> Helper loaded: html_helper
INFO - 2024-02-29 06:16:22 --> Helper loaded: text_helper
INFO - 2024-02-29 06:16:22 --> Helper loaded: form_helper
INFO - 2024-02-29 06:16:22 --> Helper loaded: lang_helper
INFO - 2024-02-29 06:16:22 --> Helper loaded: security_helper
INFO - 2024-02-29 06:16:22 --> Helper loaded: cookie_helper
INFO - 2024-02-29 06:16:22 --> Database Driver Class Initialized
INFO - 2024-02-29 06:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 06:16:22 --> Parser Class Initialized
INFO - 2024-02-29 06:16:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 06:16:22 --> Pagination Class Initialized
INFO - 2024-02-29 06:16:22 --> Form Validation Class Initialized
INFO - 2024-02-29 06:16:22 --> Controller Class Initialized
INFO - 2024-02-29 06:16:22 --> Model Class Initialized
DEBUG - 2024-02-29 06:16:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 06:16:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:16:22 --> Model Class Initialized
DEBUG - 2024-02-29 06:16:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:16:22 --> Model Class Initialized
INFO - 2024-02-29 06:16:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-29 06:16:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:16:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 06:16:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 06:16:22 --> Model Class Initialized
INFO - 2024-02-29 06:16:22 --> Model Class Initialized
INFO - 2024-02-29 06:16:22 --> Model Class Initialized
INFO - 2024-02-29 06:16:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 06:16:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 06:16:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 06:16:22 --> Final output sent to browser
DEBUG - 2024-02-29 06:16:22 --> Total execution time: 0.1621
ERROR - 2024-02-29 06:16:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 06:16:23 --> Config Class Initialized
INFO - 2024-02-29 06:16:23 --> Hooks Class Initialized
DEBUG - 2024-02-29 06:16:23 --> UTF-8 Support Enabled
INFO - 2024-02-29 06:16:23 --> Utf8 Class Initialized
INFO - 2024-02-29 06:16:23 --> URI Class Initialized
INFO - 2024-02-29 06:16:23 --> Router Class Initialized
INFO - 2024-02-29 06:16:23 --> Output Class Initialized
INFO - 2024-02-29 06:16:23 --> Security Class Initialized
DEBUG - 2024-02-29 06:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 06:16:23 --> Input Class Initialized
INFO - 2024-02-29 06:16:23 --> Language Class Initialized
INFO - 2024-02-29 06:16:23 --> Loader Class Initialized
INFO - 2024-02-29 06:16:23 --> Helper loaded: url_helper
INFO - 2024-02-29 06:16:23 --> Helper loaded: file_helper
INFO - 2024-02-29 06:16:23 --> Helper loaded: html_helper
INFO - 2024-02-29 06:16:23 --> Helper loaded: text_helper
INFO - 2024-02-29 06:16:23 --> Helper loaded: form_helper
INFO - 2024-02-29 06:16:23 --> Helper loaded: lang_helper
INFO - 2024-02-29 06:16:23 --> Helper loaded: security_helper
INFO - 2024-02-29 06:16:23 --> Helper loaded: cookie_helper
INFO - 2024-02-29 06:16:23 --> Database Driver Class Initialized
INFO - 2024-02-29 06:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 06:16:23 --> Parser Class Initialized
INFO - 2024-02-29 06:16:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 06:16:23 --> Pagination Class Initialized
INFO - 2024-02-29 06:16:23 --> Form Validation Class Initialized
INFO - 2024-02-29 06:16:23 --> Controller Class Initialized
INFO - 2024-02-29 06:16:23 --> Model Class Initialized
DEBUG - 2024-02-29 06:16:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 06:16:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:16:23 --> Model Class Initialized
DEBUG - 2024-02-29 06:16:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:16:23 --> Model Class Initialized
INFO - 2024-02-29 06:16:23 --> Final output sent to browser
DEBUG - 2024-02-29 06:16:23 --> Total execution time: 0.0378
ERROR - 2024-02-29 06:17:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 06:17:41 --> Config Class Initialized
INFO - 2024-02-29 06:17:41 --> Hooks Class Initialized
DEBUG - 2024-02-29 06:17:41 --> UTF-8 Support Enabled
INFO - 2024-02-29 06:17:41 --> Utf8 Class Initialized
INFO - 2024-02-29 06:17:41 --> URI Class Initialized
INFO - 2024-02-29 06:17:41 --> Router Class Initialized
INFO - 2024-02-29 06:17:41 --> Output Class Initialized
INFO - 2024-02-29 06:17:41 --> Security Class Initialized
DEBUG - 2024-02-29 06:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 06:17:41 --> Input Class Initialized
INFO - 2024-02-29 06:17:41 --> Language Class Initialized
INFO - 2024-02-29 06:17:41 --> Loader Class Initialized
INFO - 2024-02-29 06:17:41 --> Helper loaded: url_helper
INFO - 2024-02-29 06:17:41 --> Helper loaded: file_helper
INFO - 2024-02-29 06:17:41 --> Helper loaded: html_helper
INFO - 2024-02-29 06:17:41 --> Helper loaded: text_helper
INFO - 2024-02-29 06:17:41 --> Helper loaded: form_helper
INFO - 2024-02-29 06:17:41 --> Helper loaded: lang_helper
INFO - 2024-02-29 06:17:41 --> Helper loaded: security_helper
INFO - 2024-02-29 06:17:41 --> Helper loaded: cookie_helper
INFO - 2024-02-29 06:17:41 --> Database Driver Class Initialized
INFO - 2024-02-29 06:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 06:17:41 --> Parser Class Initialized
INFO - 2024-02-29 06:17:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 06:17:41 --> Pagination Class Initialized
INFO - 2024-02-29 06:17:41 --> Form Validation Class Initialized
INFO - 2024-02-29 06:17:41 --> Controller Class Initialized
INFO - 2024-02-29 06:17:41 --> Model Class Initialized
DEBUG - 2024-02-29 06:17:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 06:17:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:17:41 --> Model Class Initialized
DEBUG - 2024-02-29 06:17:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:17:41 --> Model Class Initialized
INFO - 2024-02-29 06:17:41 --> Final output sent to browser
DEBUG - 2024-02-29 06:17:41 --> Total execution time: 0.2074
ERROR - 2024-02-29 06:18:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 06:18:04 --> Config Class Initialized
INFO - 2024-02-29 06:18:04 --> Hooks Class Initialized
DEBUG - 2024-02-29 06:18:04 --> UTF-8 Support Enabled
INFO - 2024-02-29 06:18:04 --> Utf8 Class Initialized
INFO - 2024-02-29 06:18:04 --> URI Class Initialized
INFO - 2024-02-29 06:18:04 --> Router Class Initialized
INFO - 2024-02-29 06:18:04 --> Output Class Initialized
INFO - 2024-02-29 06:18:04 --> Security Class Initialized
DEBUG - 2024-02-29 06:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 06:18:04 --> Input Class Initialized
INFO - 2024-02-29 06:18:04 --> Language Class Initialized
INFO - 2024-02-29 06:18:04 --> Loader Class Initialized
INFO - 2024-02-29 06:18:04 --> Helper loaded: url_helper
INFO - 2024-02-29 06:18:04 --> Helper loaded: file_helper
INFO - 2024-02-29 06:18:04 --> Helper loaded: html_helper
INFO - 2024-02-29 06:18:04 --> Helper loaded: text_helper
INFO - 2024-02-29 06:18:04 --> Helper loaded: form_helper
INFO - 2024-02-29 06:18:04 --> Helper loaded: lang_helper
INFO - 2024-02-29 06:18:04 --> Helper loaded: security_helper
INFO - 2024-02-29 06:18:04 --> Helper loaded: cookie_helper
INFO - 2024-02-29 06:18:04 --> Database Driver Class Initialized
INFO - 2024-02-29 06:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 06:18:04 --> Parser Class Initialized
INFO - 2024-02-29 06:18:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 06:18:04 --> Pagination Class Initialized
INFO - 2024-02-29 06:18:04 --> Form Validation Class Initialized
INFO - 2024-02-29 06:18:04 --> Controller Class Initialized
INFO - 2024-02-29 06:18:04 --> Model Class Initialized
DEBUG - 2024-02-29 06:18:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 06:18:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:18:04 --> Model Class Initialized
DEBUG - 2024-02-29 06:18:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:18:04 --> Model Class Initialized
DEBUG - 2024-02-29 06:18:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:18:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-02-29 06:18:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:18:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 06:18:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 06:18:04 --> Model Class Initialized
INFO - 2024-02-29 06:18:04 --> Model Class Initialized
INFO - 2024-02-29 06:18:04 --> Model Class Initialized
INFO - 2024-02-29 06:18:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 06:18:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 06:18:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 06:18:05 --> Final output sent to browser
DEBUG - 2024-02-29 06:18:05 --> Total execution time: 0.1870
ERROR - 2024-02-29 06:21:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 06:21:26 --> Config Class Initialized
INFO - 2024-02-29 06:21:26 --> Hooks Class Initialized
DEBUG - 2024-02-29 06:21:26 --> UTF-8 Support Enabled
INFO - 2024-02-29 06:21:26 --> Utf8 Class Initialized
INFO - 2024-02-29 06:21:26 --> URI Class Initialized
DEBUG - 2024-02-29 06:21:26 --> No URI present. Default controller set.
INFO - 2024-02-29 06:21:26 --> Router Class Initialized
INFO - 2024-02-29 06:21:26 --> Output Class Initialized
INFO - 2024-02-29 06:21:26 --> Security Class Initialized
DEBUG - 2024-02-29 06:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 06:21:26 --> Input Class Initialized
INFO - 2024-02-29 06:21:26 --> Language Class Initialized
INFO - 2024-02-29 06:21:26 --> Loader Class Initialized
INFO - 2024-02-29 06:21:26 --> Helper loaded: url_helper
INFO - 2024-02-29 06:21:26 --> Helper loaded: file_helper
INFO - 2024-02-29 06:21:26 --> Helper loaded: html_helper
INFO - 2024-02-29 06:21:26 --> Helper loaded: text_helper
INFO - 2024-02-29 06:21:26 --> Helper loaded: form_helper
INFO - 2024-02-29 06:21:26 --> Helper loaded: lang_helper
INFO - 2024-02-29 06:21:26 --> Helper loaded: security_helper
INFO - 2024-02-29 06:21:26 --> Helper loaded: cookie_helper
INFO - 2024-02-29 06:21:26 --> Database Driver Class Initialized
INFO - 2024-02-29 06:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 06:21:26 --> Parser Class Initialized
INFO - 2024-02-29 06:21:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 06:21:26 --> Pagination Class Initialized
INFO - 2024-02-29 06:21:26 --> Form Validation Class Initialized
INFO - 2024-02-29 06:21:26 --> Controller Class Initialized
INFO - 2024-02-29 06:21:26 --> Model Class Initialized
DEBUG - 2024-02-29 06:21:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:21:26 --> Model Class Initialized
DEBUG - 2024-02-29 06:21:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:21:26 --> Model Class Initialized
INFO - 2024-02-29 06:21:26 --> Model Class Initialized
INFO - 2024-02-29 06:21:26 --> Model Class Initialized
INFO - 2024-02-29 06:21:26 --> Model Class Initialized
DEBUG - 2024-02-29 06:21:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 06:21:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:21:26 --> Model Class Initialized
INFO - 2024-02-29 06:21:26 --> Model Class Initialized
INFO - 2024-02-29 06:21:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 06:21:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 06:21:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 06:21:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 06:21:26 --> Model Class Initialized
INFO - 2024-02-29 06:21:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 06:21:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 06:21:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 06:21:27 --> Final output sent to browser
DEBUG - 2024-02-29 06:21:27 --> Total execution time: 0.2433
ERROR - 2024-02-29 08:55:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 08:55:04 --> Config Class Initialized
INFO - 2024-02-29 08:55:04 --> Hooks Class Initialized
DEBUG - 2024-02-29 08:55:04 --> UTF-8 Support Enabled
INFO - 2024-02-29 08:55:04 --> Utf8 Class Initialized
INFO - 2024-02-29 08:55:04 --> URI Class Initialized
DEBUG - 2024-02-29 08:55:04 --> No URI present. Default controller set.
INFO - 2024-02-29 08:55:04 --> Router Class Initialized
INFO - 2024-02-29 08:55:04 --> Output Class Initialized
INFO - 2024-02-29 08:55:04 --> Security Class Initialized
DEBUG - 2024-02-29 08:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 08:55:04 --> Input Class Initialized
INFO - 2024-02-29 08:55:04 --> Language Class Initialized
INFO - 2024-02-29 08:55:04 --> Loader Class Initialized
INFO - 2024-02-29 08:55:04 --> Helper loaded: url_helper
INFO - 2024-02-29 08:55:04 --> Helper loaded: file_helper
INFO - 2024-02-29 08:55:04 --> Helper loaded: html_helper
INFO - 2024-02-29 08:55:04 --> Helper loaded: text_helper
INFO - 2024-02-29 08:55:04 --> Helper loaded: form_helper
INFO - 2024-02-29 08:55:04 --> Helper loaded: lang_helper
INFO - 2024-02-29 08:55:04 --> Helper loaded: security_helper
INFO - 2024-02-29 08:55:04 --> Helper loaded: cookie_helper
INFO - 2024-02-29 08:55:04 --> Database Driver Class Initialized
INFO - 2024-02-29 08:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 08:55:04 --> Parser Class Initialized
INFO - 2024-02-29 08:55:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 08:55:04 --> Pagination Class Initialized
INFO - 2024-02-29 08:55:04 --> Form Validation Class Initialized
INFO - 2024-02-29 08:55:04 --> Controller Class Initialized
INFO - 2024-02-29 08:55:04 --> Model Class Initialized
DEBUG - 2024-02-29 08:55:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-29 08:55:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 08:55:05 --> Config Class Initialized
INFO - 2024-02-29 08:55:05 --> Hooks Class Initialized
DEBUG - 2024-02-29 08:55:05 --> UTF-8 Support Enabled
INFO - 2024-02-29 08:55:05 --> Utf8 Class Initialized
INFO - 2024-02-29 08:55:05 --> URI Class Initialized
INFO - 2024-02-29 08:55:05 --> Router Class Initialized
INFO - 2024-02-29 08:55:05 --> Output Class Initialized
INFO - 2024-02-29 08:55:05 --> Security Class Initialized
DEBUG - 2024-02-29 08:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 08:55:05 --> Input Class Initialized
INFO - 2024-02-29 08:55:05 --> Language Class Initialized
INFO - 2024-02-29 08:55:05 --> Loader Class Initialized
INFO - 2024-02-29 08:55:05 --> Helper loaded: url_helper
INFO - 2024-02-29 08:55:05 --> Helper loaded: file_helper
INFO - 2024-02-29 08:55:05 --> Helper loaded: html_helper
INFO - 2024-02-29 08:55:05 --> Helper loaded: text_helper
INFO - 2024-02-29 08:55:05 --> Helper loaded: form_helper
INFO - 2024-02-29 08:55:05 --> Helper loaded: lang_helper
INFO - 2024-02-29 08:55:05 --> Helper loaded: security_helper
INFO - 2024-02-29 08:55:05 --> Helper loaded: cookie_helper
INFO - 2024-02-29 08:55:05 --> Database Driver Class Initialized
INFO - 2024-02-29 08:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 08:55:05 --> Parser Class Initialized
INFO - 2024-02-29 08:55:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 08:55:05 --> Pagination Class Initialized
INFO - 2024-02-29 08:55:05 --> Form Validation Class Initialized
INFO - 2024-02-29 08:55:05 --> Controller Class Initialized
INFO - 2024-02-29 08:55:05 --> Model Class Initialized
DEBUG - 2024-02-29 08:55:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 08:55:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-29 08:55:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 08:55:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 08:55:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 08:55:05 --> Model Class Initialized
INFO - 2024-02-29 08:55:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 08:55:05 --> Final output sent to browser
DEBUG - 2024-02-29 08:55:05 --> Total execution time: 0.0399
ERROR - 2024-02-29 08:55:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 08:55:15 --> Config Class Initialized
INFO - 2024-02-29 08:55:15 --> Hooks Class Initialized
DEBUG - 2024-02-29 08:55:15 --> UTF-8 Support Enabled
INFO - 2024-02-29 08:55:15 --> Utf8 Class Initialized
INFO - 2024-02-29 08:55:15 --> URI Class Initialized
INFO - 2024-02-29 08:55:15 --> Router Class Initialized
INFO - 2024-02-29 08:55:15 --> Output Class Initialized
INFO - 2024-02-29 08:55:15 --> Security Class Initialized
DEBUG - 2024-02-29 08:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 08:55:15 --> Input Class Initialized
INFO - 2024-02-29 08:55:15 --> Language Class Initialized
INFO - 2024-02-29 08:55:15 --> Loader Class Initialized
INFO - 2024-02-29 08:55:15 --> Helper loaded: url_helper
INFO - 2024-02-29 08:55:15 --> Helper loaded: file_helper
INFO - 2024-02-29 08:55:15 --> Helper loaded: html_helper
INFO - 2024-02-29 08:55:15 --> Helper loaded: text_helper
INFO - 2024-02-29 08:55:15 --> Helper loaded: form_helper
INFO - 2024-02-29 08:55:15 --> Helper loaded: lang_helper
INFO - 2024-02-29 08:55:15 --> Helper loaded: security_helper
INFO - 2024-02-29 08:55:15 --> Helper loaded: cookie_helper
INFO - 2024-02-29 08:55:15 --> Database Driver Class Initialized
INFO - 2024-02-29 08:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 08:55:15 --> Parser Class Initialized
INFO - 2024-02-29 08:55:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 08:55:15 --> Pagination Class Initialized
INFO - 2024-02-29 08:55:15 --> Form Validation Class Initialized
INFO - 2024-02-29 08:55:15 --> Controller Class Initialized
INFO - 2024-02-29 08:55:15 --> Model Class Initialized
DEBUG - 2024-02-29 08:55:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 08:55:15 --> Model Class Initialized
INFO - 2024-02-29 08:55:15 --> Final output sent to browser
DEBUG - 2024-02-29 08:55:15 --> Total execution time: 0.0180
ERROR - 2024-02-29 08:55:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 08:55:15 --> Config Class Initialized
INFO - 2024-02-29 08:55:15 --> Hooks Class Initialized
DEBUG - 2024-02-29 08:55:15 --> UTF-8 Support Enabled
INFO - 2024-02-29 08:55:15 --> Utf8 Class Initialized
INFO - 2024-02-29 08:55:15 --> URI Class Initialized
DEBUG - 2024-02-29 08:55:15 --> No URI present. Default controller set.
INFO - 2024-02-29 08:55:15 --> Router Class Initialized
INFO - 2024-02-29 08:55:15 --> Output Class Initialized
INFO - 2024-02-29 08:55:15 --> Security Class Initialized
DEBUG - 2024-02-29 08:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 08:55:15 --> Input Class Initialized
INFO - 2024-02-29 08:55:15 --> Language Class Initialized
INFO - 2024-02-29 08:55:15 --> Loader Class Initialized
INFO - 2024-02-29 08:55:15 --> Helper loaded: url_helper
INFO - 2024-02-29 08:55:15 --> Helper loaded: file_helper
INFO - 2024-02-29 08:55:15 --> Helper loaded: html_helper
INFO - 2024-02-29 08:55:15 --> Helper loaded: text_helper
INFO - 2024-02-29 08:55:15 --> Helper loaded: form_helper
INFO - 2024-02-29 08:55:15 --> Helper loaded: lang_helper
INFO - 2024-02-29 08:55:15 --> Helper loaded: security_helper
INFO - 2024-02-29 08:55:15 --> Helper loaded: cookie_helper
INFO - 2024-02-29 08:55:15 --> Database Driver Class Initialized
INFO - 2024-02-29 08:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 08:55:15 --> Parser Class Initialized
INFO - 2024-02-29 08:55:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 08:55:15 --> Pagination Class Initialized
INFO - 2024-02-29 08:55:15 --> Form Validation Class Initialized
INFO - 2024-02-29 08:55:15 --> Controller Class Initialized
INFO - 2024-02-29 08:55:15 --> Model Class Initialized
DEBUG - 2024-02-29 08:55:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 08:55:15 --> Model Class Initialized
DEBUG - 2024-02-29 08:55:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 08:55:15 --> Model Class Initialized
INFO - 2024-02-29 08:55:15 --> Model Class Initialized
INFO - 2024-02-29 08:55:15 --> Model Class Initialized
INFO - 2024-02-29 08:55:15 --> Model Class Initialized
DEBUG - 2024-02-29 08:55:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 08:55:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 08:55:15 --> Model Class Initialized
INFO - 2024-02-29 08:55:15 --> Model Class Initialized
INFO - 2024-02-29 08:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 08:55:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 08:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 08:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 08:55:16 --> Model Class Initialized
INFO - 2024-02-29 08:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 08:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 08:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 08:55:16 --> Final output sent to browser
DEBUG - 2024-02-29 08:55:16 --> Total execution time: 0.4178
ERROR - 2024-02-29 08:55:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 08:55:17 --> Config Class Initialized
INFO - 2024-02-29 08:55:17 --> Hooks Class Initialized
DEBUG - 2024-02-29 08:55:17 --> UTF-8 Support Enabled
INFO - 2024-02-29 08:55:17 --> Utf8 Class Initialized
INFO - 2024-02-29 08:55:17 --> URI Class Initialized
INFO - 2024-02-29 08:55:17 --> Router Class Initialized
INFO - 2024-02-29 08:55:17 --> Output Class Initialized
INFO - 2024-02-29 08:55:17 --> Security Class Initialized
DEBUG - 2024-02-29 08:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 08:55:17 --> Input Class Initialized
INFO - 2024-02-29 08:55:17 --> Language Class Initialized
INFO - 2024-02-29 08:55:17 --> Loader Class Initialized
INFO - 2024-02-29 08:55:17 --> Helper loaded: url_helper
INFO - 2024-02-29 08:55:17 --> Helper loaded: file_helper
INFO - 2024-02-29 08:55:17 --> Helper loaded: html_helper
INFO - 2024-02-29 08:55:17 --> Helper loaded: text_helper
INFO - 2024-02-29 08:55:17 --> Helper loaded: form_helper
INFO - 2024-02-29 08:55:17 --> Helper loaded: lang_helper
INFO - 2024-02-29 08:55:17 --> Helper loaded: security_helper
INFO - 2024-02-29 08:55:17 --> Helper loaded: cookie_helper
INFO - 2024-02-29 08:55:17 --> Database Driver Class Initialized
INFO - 2024-02-29 08:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 08:55:17 --> Parser Class Initialized
INFO - 2024-02-29 08:55:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 08:55:17 --> Pagination Class Initialized
INFO - 2024-02-29 08:55:17 --> Form Validation Class Initialized
INFO - 2024-02-29 08:55:17 --> Controller Class Initialized
DEBUG - 2024-02-29 08:55:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 08:55:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 08:55:17 --> Model Class Initialized
INFO - 2024-02-29 08:55:17 --> Final output sent to browser
DEBUG - 2024-02-29 08:55:17 --> Total execution time: 0.0121
ERROR - 2024-02-29 08:55:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 08:55:26 --> Config Class Initialized
INFO - 2024-02-29 08:55:26 --> Hooks Class Initialized
DEBUG - 2024-02-29 08:55:26 --> UTF-8 Support Enabled
INFO - 2024-02-29 08:55:26 --> Utf8 Class Initialized
INFO - 2024-02-29 08:55:26 --> URI Class Initialized
INFO - 2024-02-29 08:55:26 --> Router Class Initialized
INFO - 2024-02-29 08:55:26 --> Output Class Initialized
INFO - 2024-02-29 08:55:26 --> Security Class Initialized
DEBUG - 2024-02-29 08:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 08:55:26 --> Input Class Initialized
INFO - 2024-02-29 08:55:26 --> Language Class Initialized
INFO - 2024-02-29 08:55:26 --> Loader Class Initialized
INFO - 2024-02-29 08:55:26 --> Helper loaded: url_helper
INFO - 2024-02-29 08:55:26 --> Helper loaded: file_helper
INFO - 2024-02-29 08:55:26 --> Helper loaded: html_helper
INFO - 2024-02-29 08:55:26 --> Helper loaded: text_helper
INFO - 2024-02-29 08:55:26 --> Helper loaded: form_helper
INFO - 2024-02-29 08:55:26 --> Helper loaded: lang_helper
INFO - 2024-02-29 08:55:26 --> Helper loaded: security_helper
INFO - 2024-02-29 08:55:26 --> Helper loaded: cookie_helper
INFO - 2024-02-29 08:55:26 --> Database Driver Class Initialized
INFO - 2024-02-29 08:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 08:55:26 --> Parser Class Initialized
INFO - 2024-02-29 08:55:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 08:55:26 --> Pagination Class Initialized
INFO - 2024-02-29 08:55:26 --> Form Validation Class Initialized
INFO - 2024-02-29 08:55:26 --> Controller Class Initialized
DEBUG - 2024-02-29 08:55:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 08:55:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 08:55:26 --> Model Class Initialized
DEBUG - 2024-02-29 08:55:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 08:55:26 --> Model Class Initialized
DEBUG - 2024-02-29 08:55:26 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-29 08:55:26 --> Model Class Initialized
INFO - 2024-02-29 08:55:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-29 08:55:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 08:55:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 08:55:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 08:55:26 --> Model Class Initialized
INFO - 2024-02-29 08:55:26 --> Model Class Initialized
INFO - 2024-02-29 08:55:26 --> Model Class Initialized
INFO - 2024-02-29 08:55:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 08:55:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 08:55:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 08:55:26 --> Final output sent to browser
DEBUG - 2024-02-29 08:55:26 --> Total execution time: 0.2278
ERROR - 2024-02-29 08:55:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 08:55:27 --> Config Class Initialized
INFO - 2024-02-29 08:55:27 --> Hooks Class Initialized
DEBUG - 2024-02-29 08:55:27 --> UTF-8 Support Enabled
INFO - 2024-02-29 08:55:27 --> Utf8 Class Initialized
INFO - 2024-02-29 08:55:27 --> URI Class Initialized
INFO - 2024-02-29 08:55:27 --> Router Class Initialized
INFO - 2024-02-29 08:55:27 --> Output Class Initialized
INFO - 2024-02-29 08:55:27 --> Security Class Initialized
DEBUG - 2024-02-29 08:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 08:55:27 --> Input Class Initialized
INFO - 2024-02-29 08:55:27 --> Language Class Initialized
INFO - 2024-02-29 08:55:27 --> Loader Class Initialized
INFO - 2024-02-29 08:55:27 --> Helper loaded: url_helper
INFO - 2024-02-29 08:55:27 --> Helper loaded: file_helper
INFO - 2024-02-29 08:55:27 --> Helper loaded: html_helper
INFO - 2024-02-29 08:55:27 --> Helper loaded: text_helper
INFO - 2024-02-29 08:55:27 --> Helper loaded: form_helper
INFO - 2024-02-29 08:55:27 --> Helper loaded: lang_helper
INFO - 2024-02-29 08:55:27 --> Helper loaded: security_helper
INFO - 2024-02-29 08:55:27 --> Helper loaded: cookie_helper
INFO - 2024-02-29 08:55:27 --> Database Driver Class Initialized
INFO - 2024-02-29 08:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 08:55:27 --> Parser Class Initialized
INFO - 2024-02-29 08:55:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 08:55:27 --> Pagination Class Initialized
INFO - 2024-02-29 08:55:27 --> Form Validation Class Initialized
INFO - 2024-02-29 08:55:27 --> Controller Class Initialized
DEBUG - 2024-02-29 08:55:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 08:55:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 08:55:27 --> Model Class Initialized
DEBUG - 2024-02-29 08:55:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 08:55:27 --> Model Class Initialized
INFO - 2024-02-29 08:55:27 --> Final output sent to browser
DEBUG - 2024-02-29 08:55:27 --> Total execution time: 0.0336
ERROR - 2024-02-29 08:58:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 08:58:11 --> Config Class Initialized
INFO - 2024-02-29 08:58:11 --> Hooks Class Initialized
DEBUG - 2024-02-29 08:58:11 --> UTF-8 Support Enabled
INFO - 2024-02-29 08:58:11 --> Utf8 Class Initialized
INFO - 2024-02-29 08:58:11 --> URI Class Initialized
DEBUG - 2024-02-29 08:58:11 --> No URI present. Default controller set.
INFO - 2024-02-29 08:58:11 --> Router Class Initialized
INFO - 2024-02-29 08:58:11 --> Output Class Initialized
INFO - 2024-02-29 08:58:11 --> Security Class Initialized
DEBUG - 2024-02-29 08:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 08:58:11 --> Input Class Initialized
INFO - 2024-02-29 08:58:11 --> Language Class Initialized
INFO - 2024-02-29 08:58:11 --> Loader Class Initialized
INFO - 2024-02-29 08:58:11 --> Helper loaded: url_helper
INFO - 2024-02-29 08:58:11 --> Helper loaded: file_helper
INFO - 2024-02-29 08:58:11 --> Helper loaded: html_helper
INFO - 2024-02-29 08:58:11 --> Helper loaded: text_helper
INFO - 2024-02-29 08:58:11 --> Helper loaded: form_helper
INFO - 2024-02-29 08:58:11 --> Helper loaded: lang_helper
INFO - 2024-02-29 08:58:11 --> Helper loaded: security_helper
INFO - 2024-02-29 08:58:11 --> Helper loaded: cookie_helper
INFO - 2024-02-29 08:58:11 --> Database Driver Class Initialized
INFO - 2024-02-29 08:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 08:58:11 --> Parser Class Initialized
INFO - 2024-02-29 08:58:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 08:58:11 --> Pagination Class Initialized
INFO - 2024-02-29 08:58:11 --> Form Validation Class Initialized
INFO - 2024-02-29 08:58:11 --> Controller Class Initialized
INFO - 2024-02-29 08:58:11 --> Model Class Initialized
DEBUG - 2024-02-29 08:58:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 08:58:11 --> Model Class Initialized
DEBUG - 2024-02-29 08:58:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 08:58:11 --> Model Class Initialized
INFO - 2024-02-29 08:58:11 --> Model Class Initialized
INFO - 2024-02-29 08:58:11 --> Model Class Initialized
INFO - 2024-02-29 08:58:11 --> Model Class Initialized
DEBUG - 2024-02-29 08:58:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 08:58:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 08:58:11 --> Model Class Initialized
INFO - 2024-02-29 08:58:11 --> Model Class Initialized
INFO - 2024-02-29 08:58:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 08:58:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 08:58:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 08:58:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 08:58:11 --> Model Class Initialized
INFO - 2024-02-29 08:58:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 08:58:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 08:58:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 08:58:11 --> Final output sent to browser
DEBUG - 2024-02-29 08:58:11 --> Total execution time: 0.4266
ERROR - 2024-02-29 09:06:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 09:06:01 --> Config Class Initialized
INFO - 2024-02-29 09:06:01 --> Hooks Class Initialized
DEBUG - 2024-02-29 09:06:01 --> UTF-8 Support Enabled
INFO - 2024-02-29 09:06:01 --> Utf8 Class Initialized
INFO - 2024-02-29 09:06:01 --> URI Class Initialized
DEBUG - 2024-02-29 09:06:01 --> No URI present. Default controller set.
INFO - 2024-02-29 09:06:01 --> Router Class Initialized
INFO - 2024-02-29 09:06:01 --> Output Class Initialized
INFO - 2024-02-29 09:06:01 --> Security Class Initialized
DEBUG - 2024-02-29 09:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 09:06:01 --> Input Class Initialized
INFO - 2024-02-29 09:06:01 --> Language Class Initialized
INFO - 2024-02-29 09:06:01 --> Loader Class Initialized
INFO - 2024-02-29 09:06:01 --> Helper loaded: url_helper
INFO - 2024-02-29 09:06:01 --> Helper loaded: file_helper
INFO - 2024-02-29 09:06:01 --> Helper loaded: html_helper
INFO - 2024-02-29 09:06:01 --> Helper loaded: text_helper
INFO - 2024-02-29 09:06:01 --> Helper loaded: form_helper
INFO - 2024-02-29 09:06:01 --> Helper loaded: lang_helper
INFO - 2024-02-29 09:06:01 --> Helper loaded: security_helper
INFO - 2024-02-29 09:06:01 --> Helper loaded: cookie_helper
INFO - 2024-02-29 09:06:01 --> Database Driver Class Initialized
INFO - 2024-02-29 09:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 09:06:01 --> Parser Class Initialized
INFO - 2024-02-29 09:06:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 09:06:01 --> Pagination Class Initialized
INFO - 2024-02-29 09:06:01 --> Form Validation Class Initialized
INFO - 2024-02-29 09:06:01 --> Controller Class Initialized
INFO - 2024-02-29 09:06:01 --> Model Class Initialized
DEBUG - 2024-02-29 09:06:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 09:06:01 --> Model Class Initialized
DEBUG - 2024-02-29 09:06:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 09:06:01 --> Model Class Initialized
INFO - 2024-02-29 09:06:01 --> Model Class Initialized
INFO - 2024-02-29 09:06:01 --> Model Class Initialized
INFO - 2024-02-29 09:06:01 --> Model Class Initialized
DEBUG - 2024-02-29 09:06:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 09:06:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 09:06:01 --> Model Class Initialized
INFO - 2024-02-29 09:06:01 --> Model Class Initialized
INFO - 2024-02-29 09:06:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 09:06:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 09:06:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 09:06:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 09:06:01 --> Model Class Initialized
INFO - 2024-02-29 09:06:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 09:06:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 09:06:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 09:06:01 --> Final output sent to browser
DEBUG - 2024-02-29 09:06:01 --> Total execution time: 0.4300
ERROR - 2024-02-29 09:10:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 09:10:06 --> Config Class Initialized
INFO - 2024-02-29 09:10:06 --> Hooks Class Initialized
DEBUG - 2024-02-29 09:10:06 --> UTF-8 Support Enabled
INFO - 2024-02-29 09:10:06 --> Utf8 Class Initialized
INFO - 2024-02-29 09:10:06 --> URI Class Initialized
DEBUG - 2024-02-29 09:10:06 --> No URI present. Default controller set.
INFO - 2024-02-29 09:10:06 --> Router Class Initialized
INFO - 2024-02-29 09:10:06 --> Output Class Initialized
INFO - 2024-02-29 09:10:06 --> Security Class Initialized
DEBUG - 2024-02-29 09:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 09:10:06 --> Input Class Initialized
INFO - 2024-02-29 09:10:06 --> Language Class Initialized
INFO - 2024-02-29 09:10:06 --> Loader Class Initialized
INFO - 2024-02-29 09:10:06 --> Helper loaded: url_helper
INFO - 2024-02-29 09:10:06 --> Helper loaded: file_helper
INFO - 2024-02-29 09:10:06 --> Helper loaded: html_helper
INFO - 2024-02-29 09:10:06 --> Helper loaded: text_helper
INFO - 2024-02-29 09:10:06 --> Helper loaded: form_helper
INFO - 2024-02-29 09:10:06 --> Helper loaded: lang_helper
INFO - 2024-02-29 09:10:06 --> Helper loaded: security_helper
INFO - 2024-02-29 09:10:06 --> Helper loaded: cookie_helper
INFO - 2024-02-29 09:10:06 --> Database Driver Class Initialized
INFO - 2024-02-29 09:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 09:10:06 --> Parser Class Initialized
INFO - 2024-02-29 09:10:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 09:10:06 --> Pagination Class Initialized
INFO - 2024-02-29 09:10:06 --> Form Validation Class Initialized
INFO - 2024-02-29 09:10:06 --> Controller Class Initialized
INFO - 2024-02-29 09:10:06 --> Model Class Initialized
DEBUG - 2024-02-29 09:10:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-29 09:10:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 09:10:08 --> Config Class Initialized
INFO - 2024-02-29 09:10:08 --> Hooks Class Initialized
DEBUG - 2024-02-29 09:10:08 --> UTF-8 Support Enabled
INFO - 2024-02-29 09:10:08 --> Utf8 Class Initialized
INFO - 2024-02-29 09:10:08 --> URI Class Initialized
INFO - 2024-02-29 09:10:08 --> Router Class Initialized
INFO - 2024-02-29 09:10:08 --> Output Class Initialized
INFO - 2024-02-29 09:10:08 --> Security Class Initialized
DEBUG - 2024-02-29 09:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 09:10:08 --> Input Class Initialized
INFO - 2024-02-29 09:10:08 --> Language Class Initialized
INFO - 2024-02-29 09:10:08 --> Loader Class Initialized
INFO - 2024-02-29 09:10:08 --> Helper loaded: url_helper
INFO - 2024-02-29 09:10:08 --> Helper loaded: file_helper
INFO - 2024-02-29 09:10:08 --> Helper loaded: html_helper
INFO - 2024-02-29 09:10:08 --> Helper loaded: text_helper
INFO - 2024-02-29 09:10:08 --> Helper loaded: form_helper
INFO - 2024-02-29 09:10:08 --> Helper loaded: lang_helper
INFO - 2024-02-29 09:10:08 --> Helper loaded: security_helper
INFO - 2024-02-29 09:10:08 --> Helper loaded: cookie_helper
INFO - 2024-02-29 09:10:08 --> Database Driver Class Initialized
INFO - 2024-02-29 09:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 09:10:08 --> Parser Class Initialized
INFO - 2024-02-29 09:10:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 09:10:08 --> Pagination Class Initialized
INFO - 2024-02-29 09:10:08 --> Form Validation Class Initialized
INFO - 2024-02-29 09:10:08 --> Controller Class Initialized
INFO - 2024-02-29 09:10:08 --> Model Class Initialized
DEBUG - 2024-02-29 09:10:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 09:10:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-29 09:10:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 09:10:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 09:10:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 09:10:08 --> Model Class Initialized
INFO - 2024-02-29 09:10:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 09:10:08 --> Final output sent to browser
DEBUG - 2024-02-29 09:10:08 --> Total execution time: 0.0312
ERROR - 2024-02-29 09:10:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 09:10:28 --> Config Class Initialized
INFO - 2024-02-29 09:10:28 --> Hooks Class Initialized
DEBUG - 2024-02-29 09:10:28 --> UTF-8 Support Enabled
INFO - 2024-02-29 09:10:28 --> Utf8 Class Initialized
INFO - 2024-02-29 09:10:28 --> URI Class Initialized
INFO - 2024-02-29 09:10:28 --> Router Class Initialized
INFO - 2024-02-29 09:10:28 --> Output Class Initialized
INFO - 2024-02-29 09:10:28 --> Security Class Initialized
DEBUG - 2024-02-29 09:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 09:10:28 --> Input Class Initialized
INFO - 2024-02-29 09:10:28 --> Language Class Initialized
INFO - 2024-02-29 09:10:28 --> Loader Class Initialized
INFO - 2024-02-29 09:10:28 --> Helper loaded: url_helper
INFO - 2024-02-29 09:10:28 --> Helper loaded: file_helper
INFO - 2024-02-29 09:10:28 --> Helper loaded: html_helper
INFO - 2024-02-29 09:10:28 --> Helper loaded: text_helper
INFO - 2024-02-29 09:10:28 --> Helper loaded: form_helper
INFO - 2024-02-29 09:10:28 --> Helper loaded: lang_helper
INFO - 2024-02-29 09:10:28 --> Helper loaded: security_helper
INFO - 2024-02-29 09:10:28 --> Helper loaded: cookie_helper
INFO - 2024-02-29 09:10:28 --> Database Driver Class Initialized
INFO - 2024-02-29 09:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 09:10:28 --> Parser Class Initialized
INFO - 2024-02-29 09:10:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 09:10:28 --> Pagination Class Initialized
INFO - 2024-02-29 09:10:28 --> Form Validation Class Initialized
INFO - 2024-02-29 09:10:28 --> Controller Class Initialized
INFO - 2024-02-29 09:10:28 --> Model Class Initialized
DEBUG - 2024-02-29 09:10:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 09:10:28 --> Model Class Initialized
INFO - 2024-02-29 09:10:28 --> Final output sent to browser
DEBUG - 2024-02-29 09:10:28 --> Total execution time: 0.0200
ERROR - 2024-02-29 09:10:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 09:10:28 --> Config Class Initialized
INFO - 2024-02-29 09:10:28 --> Hooks Class Initialized
DEBUG - 2024-02-29 09:10:28 --> UTF-8 Support Enabled
INFO - 2024-02-29 09:10:28 --> Utf8 Class Initialized
INFO - 2024-02-29 09:10:28 --> URI Class Initialized
DEBUG - 2024-02-29 09:10:28 --> No URI present. Default controller set.
INFO - 2024-02-29 09:10:28 --> Router Class Initialized
INFO - 2024-02-29 09:10:28 --> Output Class Initialized
INFO - 2024-02-29 09:10:28 --> Security Class Initialized
DEBUG - 2024-02-29 09:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 09:10:28 --> Input Class Initialized
INFO - 2024-02-29 09:10:28 --> Language Class Initialized
INFO - 2024-02-29 09:10:28 --> Loader Class Initialized
INFO - 2024-02-29 09:10:28 --> Helper loaded: url_helper
INFO - 2024-02-29 09:10:28 --> Helper loaded: file_helper
INFO - 2024-02-29 09:10:28 --> Helper loaded: html_helper
INFO - 2024-02-29 09:10:28 --> Helper loaded: text_helper
INFO - 2024-02-29 09:10:28 --> Helper loaded: form_helper
INFO - 2024-02-29 09:10:28 --> Helper loaded: lang_helper
INFO - 2024-02-29 09:10:28 --> Helper loaded: security_helper
INFO - 2024-02-29 09:10:28 --> Helper loaded: cookie_helper
INFO - 2024-02-29 09:10:28 --> Database Driver Class Initialized
INFO - 2024-02-29 09:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 09:10:28 --> Parser Class Initialized
INFO - 2024-02-29 09:10:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 09:10:28 --> Pagination Class Initialized
INFO - 2024-02-29 09:10:28 --> Form Validation Class Initialized
INFO - 2024-02-29 09:10:28 --> Controller Class Initialized
INFO - 2024-02-29 09:10:28 --> Model Class Initialized
DEBUG - 2024-02-29 09:10:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 09:10:28 --> Model Class Initialized
DEBUG - 2024-02-29 09:10:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 09:10:28 --> Model Class Initialized
INFO - 2024-02-29 09:10:28 --> Model Class Initialized
INFO - 2024-02-29 09:10:28 --> Model Class Initialized
INFO - 2024-02-29 09:10:28 --> Model Class Initialized
DEBUG - 2024-02-29 09:10:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 09:10:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 09:10:28 --> Model Class Initialized
INFO - 2024-02-29 09:10:28 --> Model Class Initialized
INFO - 2024-02-29 09:10:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 09:10:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 09:10:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 09:10:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 09:10:28 --> Model Class Initialized
INFO - 2024-02-29 09:10:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 09:10:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 09:10:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 09:10:29 --> Final output sent to browser
DEBUG - 2024-02-29 09:10:29 --> Total execution time: 0.2471
ERROR - 2024-02-29 09:10:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 09:10:50 --> Config Class Initialized
INFO - 2024-02-29 09:10:50 --> Hooks Class Initialized
DEBUG - 2024-02-29 09:10:50 --> UTF-8 Support Enabled
INFO - 2024-02-29 09:10:50 --> Utf8 Class Initialized
INFO - 2024-02-29 09:10:50 --> URI Class Initialized
INFO - 2024-02-29 09:10:50 --> Router Class Initialized
INFO - 2024-02-29 09:10:50 --> Output Class Initialized
INFO - 2024-02-29 09:10:50 --> Security Class Initialized
DEBUG - 2024-02-29 09:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 09:10:50 --> Input Class Initialized
INFO - 2024-02-29 09:10:50 --> Language Class Initialized
INFO - 2024-02-29 09:10:50 --> Loader Class Initialized
INFO - 2024-02-29 09:10:50 --> Helper loaded: url_helper
INFO - 2024-02-29 09:10:50 --> Helper loaded: file_helper
INFO - 2024-02-29 09:10:50 --> Helper loaded: html_helper
INFO - 2024-02-29 09:10:50 --> Helper loaded: text_helper
INFO - 2024-02-29 09:10:50 --> Helper loaded: form_helper
INFO - 2024-02-29 09:10:50 --> Helper loaded: lang_helper
INFO - 2024-02-29 09:10:51 --> Helper loaded: security_helper
INFO - 2024-02-29 09:10:51 --> Helper loaded: cookie_helper
INFO - 2024-02-29 09:10:51 --> Database Driver Class Initialized
INFO - 2024-02-29 09:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 09:10:51 --> Parser Class Initialized
INFO - 2024-02-29 09:10:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 09:10:51 --> Pagination Class Initialized
INFO - 2024-02-29 09:10:51 --> Form Validation Class Initialized
INFO - 2024-02-29 09:10:51 --> Controller Class Initialized
INFO - 2024-02-29 09:10:51 --> Model Class Initialized
DEBUG - 2024-02-29 09:10:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 09:10:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 09:10:51 --> Model Class Initialized
INFO - 2024-02-29 09:10:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2024-02-29 09:10:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 09:10:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 09:10:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 09:10:51 --> Model Class Initialized
INFO - 2024-02-29 09:10:51 --> Model Class Initialized
INFO - 2024-02-29 09:10:51 --> Model Class Initialized
INFO - 2024-02-29 09:10:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 09:10:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 09:10:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 09:10:51 --> Final output sent to browser
DEBUG - 2024-02-29 09:10:51 --> Total execution time: 0.1415
ERROR - 2024-02-29 09:10:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 09:10:51 --> Config Class Initialized
INFO - 2024-02-29 09:10:51 --> Hooks Class Initialized
DEBUG - 2024-02-29 09:10:51 --> UTF-8 Support Enabled
INFO - 2024-02-29 09:10:51 --> Utf8 Class Initialized
INFO - 2024-02-29 09:10:51 --> URI Class Initialized
INFO - 2024-02-29 09:10:51 --> Router Class Initialized
INFO - 2024-02-29 09:10:51 --> Output Class Initialized
INFO - 2024-02-29 09:10:51 --> Security Class Initialized
DEBUG - 2024-02-29 09:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 09:10:51 --> Input Class Initialized
INFO - 2024-02-29 09:10:51 --> Language Class Initialized
INFO - 2024-02-29 09:10:51 --> Loader Class Initialized
INFO - 2024-02-29 09:10:51 --> Helper loaded: url_helper
INFO - 2024-02-29 09:10:51 --> Helper loaded: file_helper
INFO - 2024-02-29 09:10:51 --> Helper loaded: html_helper
INFO - 2024-02-29 09:10:51 --> Helper loaded: text_helper
INFO - 2024-02-29 09:10:51 --> Helper loaded: form_helper
INFO - 2024-02-29 09:10:51 --> Helper loaded: lang_helper
INFO - 2024-02-29 09:10:51 --> Helper loaded: security_helper
INFO - 2024-02-29 09:10:51 --> Helper loaded: cookie_helper
INFO - 2024-02-29 09:10:51 --> Database Driver Class Initialized
INFO - 2024-02-29 09:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 09:10:51 --> Parser Class Initialized
INFO - 2024-02-29 09:10:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 09:10:51 --> Pagination Class Initialized
INFO - 2024-02-29 09:10:51 --> Form Validation Class Initialized
INFO - 2024-02-29 09:10:51 --> Controller Class Initialized
INFO - 2024-02-29 09:10:51 --> Model Class Initialized
DEBUG - 2024-02-29 09:10:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 09:10:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 09:10:51 --> Model Class Initialized
INFO - 2024-02-29 09:10:52 --> Final output sent to browser
DEBUG - 2024-02-29 09:10:52 --> Total execution time: 0.2127
ERROR - 2024-02-29 09:10:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 09:10:58 --> Config Class Initialized
INFO - 2024-02-29 09:10:58 --> Hooks Class Initialized
DEBUG - 2024-02-29 09:10:58 --> UTF-8 Support Enabled
INFO - 2024-02-29 09:10:58 --> Utf8 Class Initialized
INFO - 2024-02-29 09:10:58 --> URI Class Initialized
INFO - 2024-02-29 09:10:58 --> Router Class Initialized
INFO - 2024-02-29 09:10:58 --> Output Class Initialized
INFO - 2024-02-29 09:10:58 --> Security Class Initialized
DEBUG - 2024-02-29 09:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 09:10:58 --> Input Class Initialized
INFO - 2024-02-29 09:10:58 --> Language Class Initialized
INFO - 2024-02-29 09:10:58 --> Loader Class Initialized
INFO - 2024-02-29 09:10:58 --> Helper loaded: url_helper
INFO - 2024-02-29 09:10:58 --> Helper loaded: file_helper
INFO - 2024-02-29 09:10:58 --> Helper loaded: html_helper
INFO - 2024-02-29 09:10:58 --> Helper loaded: text_helper
INFO - 2024-02-29 09:10:58 --> Helper loaded: form_helper
INFO - 2024-02-29 09:10:58 --> Helper loaded: lang_helper
INFO - 2024-02-29 09:10:58 --> Helper loaded: security_helper
INFO - 2024-02-29 09:10:58 --> Helper loaded: cookie_helper
INFO - 2024-02-29 09:10:58 --> Database Driver Class Initialized
INFO - 2024-02-29 09:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 09:10:58 --> Parser Class Initialized
INFO - 2024-02-29 09:10:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 09:10:58 --> Pagination Class Initialized
INFO - 2024-02-29 09:10:58 --> Form Validation Class Initialized
INFO - 2024-02-29 09:10:58 --> Controller Class Initialized
INFO - 2024-02-29 09:10:58 --> Model Class Initialized
DEBUG - 2024-02-29 09:10:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 09:10:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 09:10:58 --> Model Class Initialized
INFO - 2024-02-29 09:10:58 --> Final output sent to browser
DEBUG - 2024-02-29 09:10:58 --> Total execution time: 0.2113
ERROR - 2024-02-29 09:28:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 09:28:59 --> Config Class Initialized
INFO - 2024-02-29 09:28:59 --> Hooks Class Initialized
DEBUG - 2024-02-29 09:28:59 --> UTF-8 Support Enabled
INFO - 2024-02-29 09:28:59 --> Utf8 Class Initialized
INFO - 2024-02-29 09:28:59 --> URI Class Initialized
DEBUG - 2024-02-29 09:28:59 --> No URI present. Default controller set.
INFO - 2024-02-29 09:28:59 --> Router Class Initialized
INFO - 2024-02-29 09:28:59 --> Output Class Initialized
INFO - 2024-02-29 09:28:59 --> Security Class Initialized
DEBUG - 2024-02-29 09:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 09:28:59 --> Input Class Initialized
INFO - 2024-02-29 09:28:59 --> Language Class Initialized
INFO - 2024-02-29 09:28:59 --> Loader Class Initialized
INFO - 2024-02-29 09:28:59 --> Helper loaded: url_helper
INFO - 2024-02-29 09:28:59 --> Helper loaded: file_helper
INFO - 2024-02-29 09:28:59 --> Helper loaded: html_helper
INFO - 2024-02-29 09:28:59 --> Helper loaded: text_helper
INFO - 2024-02-29 09:28:59 --> Helper loaded: form_helper
INFO - 2024-02-29 09:28:59 --> Helper loaded: lang_helper
INFO - 2024-02-29 09:28:59 --> Helper loaded: security_helper
INFO - 2024-02-29 09:28:59 --> Helper loaded: cookie_helper
INFO - 2024-02-29 09:28:59 --> Database Driver Class Initialized
INFO - 2024-02-29 09:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 09:28:59 --> Parser Class Initialized
INFO - 2024-02-29 09:28:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 09:28:59 --> Pagination Class Initialized
INFO - 2024-02-29 09:28:59 --> Form Validation Class Initialized
INFO - 2024-02-29 09:28:59 --> Controller Class Initialized
INFO - 2024-02-29 09:28:59 --> Model Class Initialized
DEBUG - 2024-02-29 09:28:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-29 09:28:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 09:28:59 --> Config Class Initialized
INFO - 2024-02-29 09:28:59 --> Hooks Class Initialized
DEBUG - 2024-02-29 09:28:59 --> UTF-8 Support Enabled
INFO - 2024-02-29 09:28:59 --> Utf8 Class Initialized
INFO - 2024-02-29 09:28:59 --> URI Class Initialized
INFO - 2024-02-29 09:28:59 --> Router Class Initialized
INFO - 2024-02-29 09:28:59 --> Output Class Initialized
INFO - 2024-02-29 09:28:59 --> Security Class Initialized
DEBUG - 2024-02-29 09:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 09:28:59 --> Input Class Initialized
INFO - 2024-02-29 09:28:59 --> Language Class Initialized
INFO - 2024-02-29 09:28:59 --> Loader Class Initialized
INFO - 2024-02-29 09:28:59 --> Helper loaded: url_helper
INFO - 2024-02-29 09:28:59 --> Helper loaded: file_helper
INFO - 2024-02-29 09:28:59 --> Helper loaded: html_helper
INFO - 2024-02-29 09:28:59 --> Helper loaded: text_helper
INFO - 2024-02-29 09:28:59 --> Helper loaded: form_helper
INFO - 2024-02-29 09:28:59 --> Helper loaded: lang_helper
INFO - 2024-02-29 09:28:59 --> Helper loaded: security_helper
INFO - 2024-02-29 09:28:59 --> Helper loaded: cookie_helper
INFO - 2024-02-29 09:28:59 --> Database Driver Class Initialized
INFO - 2024-02-29 09:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 09:28:59 --> Parser Class Initialized
INFO - 2024-02-29 09:28:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 09:28:59 --> Pagination Class Initialized
INFO - 2024-02-29 09:28:59 --> Form Validation Class Initialized
INFO - 2024-02-29 09:28:59 --> Controller Class Initialized
INFO - 2024-02-29 09:28:59 --> Model Class Initialized
DEBUG - 2024-02-29 09:28:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 09:28:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-29 09:28:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 09:28:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 09:28:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 09:28:59 --> Model Class Initialized
INFO - 2024-02-29 09:28:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 09:28:59 --> Final output sent to browser
DEBUG - 2024-02-29 09:28:59 --> Total execution time: 0.0334
ERROR - 2024-02-29 10:26:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 10:26:11 --> Config Class Initialized
INFO - 2024-02-29 10:26:11 --> Hooks Class Initialized
DEBUG - 2024-02-29 10:26:11 --> UTF-8 Support Enabled
INFO - 2024-02-29 10:26:11 --> Utf8 Class Initialized
INFO - 2024-02-29 10:26:11 --> URI Class Initialized
DEBUG - 2024-02-29 10:26:11 --> No URI present. Default controller set.
INFO - 2024-02-29 10:26:11 --> Router Class Initialized
INFO - 2024-02-29 10:26:11 --> Output Class Initialized
INFO - 2024-02-29 10:26:11 --> Security Class Initialized
DEBUG - 2024-02-29 10:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 10:26:11 --> Input Class Initialized
INFO - 2024-02-29 10:26:11 --> Language Class Initialized
INFO - 2024-02-29 10:26:11 --> Loader Class Initialized
INFO - 2024-02-29 10:26:11 --> Helper loaded: url_helper
INFO - 2024-02-29 10:26:11 --> Helper loaded: file_helper
INFO - 2024-02-29 10:26:11 --> Helper loaded: html_helper
INFO - 2024-02-29 10:26:11 --> Helper loaded: text_helper
INFO - 2024-02-29 10:26:11 --> Helper loaded: form_helper
INFO - 2024-02-29 10:26:11 --> Helper loaded: lang_helper
INFO - 2024-02-29 10:26:11 --> Helper loaded: security_helper
INFO - 2024-02-29 10:26:11 --> Helper loaded: cookie_helper
INFO - 2024-02-29 10:26:11 --> Database Driver Class Initialized
INFO - 2024-02-29 10:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 10:26:11 --> Parser Class Initialized
INFO - 2024-02-29 10:26:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 10:26:11 --> Pagination Class Initialized
INFO - 2024-02-29 10:26:11 --> Form Validation Class Initialized
INFO - 2024-02-29 10:26:11 --> Controller Class Initialized
INFO - 2024-02-29 10:26:11 --> Model Class Initialized
DEBUG - 2024-02-29 10:26:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:26:11 --> Model Class Initialized
DEBUG - 2024-02-29 10:26:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:26:11 --> Model Class Initialized
INFO - 2024-02-29 10:26:11 --> Model Class Initialized
INFO - 2024-02-29 10:26:11 --> Model Class Initialized
INFO - 2024-02-29 10:26:11 --> Model Class Initialized
DEBUG - 2024-02-29 10:26:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 10:26:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:26:11 --> Model Class Initialized
INFO - 2024-02-29 10:26:11 --> Model Class Initialized
INFO - 2024-02-29 10:26:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 10:26:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:26:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 10:26:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 10:26:11 --> Model Class Initialized
INFO - 2024-02-29 10:26:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 10:26:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 10:26:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 10:26:11 --> Final output sent to browser
DEBUG - 2024-02-29 10:26:11 --> Total execution time: 0.2475
ERROR - 2024-02-29 10:44:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 10:44:32 --> Config Class Initialized
INFO - 2024-02-29 10:44:32 --> Hooks Class Initialized
DEBUG - 2024-02-29 10:44:32 --> UTF-8 Support Enabled
INFO - 2024-02-29 10:44:32 --> Utf8 Class Initialized
INFO - 2024-02-29 10:44:32 --> URI Class Initialized
DEBUG - 2024-02-29 10:44:32 --> No URI present. Default controller set.
INFO - 2024-02-29 10:44:32 --> Router Class Initialized
INFO - 2024-02-29 10:44:32 --> Output Class Initialized
INFO - 2024-02-29 10:44:32 --> Security Class Initialized
DEBUG - 2024-02-29 10:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 10:44:32 --> Input Class Initialized
INFO - 2024-02-29 10:44:32 --> Language Class Initialized
INFO - 2024-02-29 10:44:32 --> Loader Class Initialized
INFO - 2024-02-29 10:44:32 --> Helper loaded: url_helper
INFO - 2024-02-29 10:44:32 --> Helper loaded: file_helper
INFO - 2024-02-29 10:44:32 --> Helper loaded: html_helper
INFO - 2024-02-29 10:44:32 --> Helper loaded: text_helper
INFO - 2024-02-29 10:44:32 --> Helper loaded: form_helper
INFO - 2024-02-29 10:44:32 --> Helper loaded: lang_helper
INFO - 2024-02-29 10:44:32 --> Helper loaded: security_helper
INFO - 2024-02-29 10:44:32 --> Helper loaded: cookie_helper
INFO - 2024-02-29 10:44:32 --> Database Driver Class Initialized
INFO - 2024-02-29 10:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 10:44:32 --> Parser Class Initialized
INFO - 2024-02-29 10:44:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 10:44:32 --> Pagination Class Initialized
INFO - 2024-02-29 10:44:32 --> Form Validation Class Initialized
INFO - 2024-02-29 10:44:32 --> Controller Class Initialized
INFO - 2024-02-29 10:44:32 --> Model Class Initialized
DEBUG - 2024-02-29 10:44:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-29 10:44:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 10:44:33 --> Config Class Initialized
INFO - 2024-02-29 10:44:33 --> Hooks Class Initialized
DEBUG - 2024-02-29 10:44:33 --> UTF-8 Support Enabled
INFO - 2024-02-29 10:44:33 --> Utf8 Class Initialized
INFO - 2024-02-29 10:44:33 --> URI Class Initialized
INFO - 2024-02-29 10:44:33 --> Router Class Initialized
INFO - 2024-02-29 10:44:33 --> Output Class Initialized
INFO - 2024-02-29 10:44:33 --> Security Class Initialized
DEBUG - 2024-02-29 10:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 10:44:33 --> Input Class Initialized
INFO - 2024-02-29 10:44:33 --> Language Class Initialized
INFO - 2024-02-29 10:44:33 --> Loader Class Initialized
INFO - 2024-02-29 10:44:33 --> Helper loaded: url_helper
INFO - 2024-02-29 10:44:33 --> Helper loaded: file_helper
INFO - 2024-02-29 10:44:33 --> Helper loaded: html_helper
INFO - 2024-02-29 10:44:33 --> Helper loaded: text_helper
INFO - 2024-02-29 10:44:33 --> Helper loaded: form_helper
INFO - 2024-02-29 10:44:33 --> Helper loaded: lang_helper
INFO - 2024-02-29 10:44:33 --> Helper loaded: security_helper
INFO - 2024-02-29 10:44:33 --> Helper loaded: cookie_helper
INFO - 2024-02-29 10:44:33 --> Database Driver Class Initialized
INFO - 2024-02-29 10:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 10:44:33 --> Parser Class Initialized
INFO - 2024-02-29 10:44:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 10:44:33 --> Pagination Class Initialized
INFO - 2024-02-29 10:44:33 --> Form Validation Class Initialized
INFO - 2024-02-29 10:44:33 --> Controller Class Initialized
INFO - 2024-02-29 10:44:33 --> Model Class Initialized
DEBUG - 2024-02-29 10:44:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:44:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-29 10:44:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:44:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 10:44:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 10:44:33 --> Model Class Initialized
INFO - 2024-02-29 10:44:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 10:44:33 --> Final output sent to browser
DEBUG - 2024-02-29 10:44:33 --> Total execution time: 0.0368
ERROR - 2024-02-29 10:44:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 10:44:47 --> Config Class Initialized
INFO - 2024-02-29 10:44:47 --> Hooks Class Initialized
DEBUG - 2024-02-29 10:44:47 --> UTF-8 Support Enabled
INFO - 2024-02-29 10:44:47 --> Utf8 Class Initialized
INFO - 2024-02-29 10:44:47 --> URI Class Initialized
INFO - 2024-02-29 10:44:47 --> Router Class Initialized
INFO - 2024-02-29 10:44:47 --> Output Class Initialized
INFO - 2024-02-29 10:44:47 --> Security Class Initialized
DEBUG - 2024-02-29 10:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 10:44:47 --> Input Class Initialized
INFO - 2024-02-29 10:44:47 --> Language Class Initialized
INFO - 2024-02-29 10:44:47 --> Loader Class Initialized
INFO - 2024-02-29 10:44:47 --> Helper loaded: url_helper
INFO - 2024-02-29 10:44:47 --> Helper loaded: file_helper
INFO - 2024-02-29 10:44:47 --> Helper loaded: html_helper
INFO - 2024-02-29 10:44:47 --> Helper loaded: text_helper
INFO - 2024-02-29 10:44:47 --> Helper loaded: form_helper
INFO - 2024-02-29 10:44:47 --> Helper loaded: lang_helper
INFO - 2024-02-29 10:44:47 --> Helper loaded: security_helper
INFO - 2024-02-29 10:44:47 --> Helper loaded: cookie_helper
INFO - 2024-02-29 10:44:47 --> Database Driver Class Initialized
INFO - 2024-02-29 10:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 10:44:47 --> Parser Class Initialized
INFO - 2024-02-29 10:44:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 10:44:47 --> Pagination Class Initialized
INFO - 2024-02-29 10:44:47 --> Form Validation Class Initialized
INFO - 2024-02-29 10:44:47 --> Controller Class Initialized
INFO - 2024-02-29 10:44:47 --> Model Class Initialized
DEBUG - 2024-02-29 10:44:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:44:47 --> Model Class Initialized
INFO - 2024-02-29 10:44:47 --> Final output sent to browser
DEBUG - 2024-02-29 10:44:47 --> Total execution time: 0.0200
ERROR - 2024-02-29 10:44:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 10:44:47 --> Config Class Initialized
INFO - 2024-02-29 10:44:47 --> Hooks Class Initialized
DEBUG - 2024-02-29 10:44:47 --> UTF-8 Support Enabled
INFO - 2024-02-29 10:44:47 --> Utf8 Class Initialized
INFO - 2024-02-29 10:44:47 --> URI Class Initialized
DEBUG - 2024-02-29 10:44:47 --> No URI present. Default controller set.
INFO - 2024-02-29 10:44:47 --> Router Class Initialized
INFO - 2024-02-29 10:44:47 --> Output Class Initialized
INFO - 2024-02-29 10:44:47 --> Security Class Initialized
DEBUG - 2024-02-29 10:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 10:44:47 --> Input Class Initialized
INFO - 2024-02-29 10:44:47 --> Language Class Initialized
INFO - 2024-02-29 10:44:47 --> Loader Class Initialized
INFO - 2024-02-29 10:44:47 --> Helper loaded: url_helper
INFO - 2024-02-29 10:44:47 --> Helper loaded: file_helper
INFO - 2024-02-29 10:44:47 --> Helper loaded: html_helper
INFO - 2024-02-29 10:44:47 --> Helper loaded: text_helper
INFO - 2024-02-29 10:44:47 --> Helper loaded: form_helper
INFO - 2024-02-29 10:44:47 --> Helper loaded: lang_helper
INFO - 2024-02-29 10:44:47 --> Helper loaded: security_helper
INFO - 2024-02-29 10:44:47 --> Helper loaded: cookie_helper
INFO - 2024-02-29 10:44:47 --> Database Driver Class Initialized
INFO - 2024-02-29 10:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 10:44:47 --> Parser Class Initialized
INFO - 2024-02-29 10:44:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 10:44:47 --> Pagination Class Initialized
INFO - 2024-02-29 10:44:47 --> Form Validation Class Initialized
INFO - 2024-02-29 10:44:47 --> Controller Class Initialized
INFO - 2024-02-29 10:44:47 --> Model Class Initialized
DEBUG - 2024-02-29 10:44:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:44:47 --> Model Class Initialized
DEBUG - 2024-02-29 10:44:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:44:47 --> Model Class Initialized
INFO - 2024-02-29 10:44:47 --> Model Class Initialized
INFO - 2024-02-29 10:44:47 --> Model Class Initialized
INFO - 2024-02-29 10:44:47 --> Model Class Initialized
DEBUG - 2024-02-29 10:44:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 10:44:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:44:47 --> Model Class Initialized
INFO - 2024-02-29 10:44:47 --> Model Class Initialized
INFO - 2024-02-29 10:44:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 10:44:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:44:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 10:44:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 10:44:48 --> Model Class Initialized
INFO - 2024-02-29 10:44:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 10:44:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 10:44:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 10:44:48 --> Final output sent to browser
DEBUG - 2024-02-29 10:44:48 --> Total execution time: 0.2386
ERROR - 2024-02-29 10:44:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 10:44:58 --> Config Class Initialized
INFO - 2024-02-29 10:44:58 --> Hooks Class Initialized
DEBUG - 2024-02-29 10:44:58 --> UTF-8 Support Enabled
INFO - 2024-02-29 10:44:58 --> Utf8 Class Initialized
INFO - 2024-02-29 10:44:58 --> URI Class Initialized
INFO - 2024-02-29 10:44:58 --> Router Class Initialized
INFO - 2024-02-29 10:44:58 --> Output Class Initialized
INFO - 2024-02-29 10:44:58 --> Security Class Initialized
DEBUG - 2024-02-29 10:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 10:44:58 --> Input Class Initialized
INFO - 2024-02-29 10:44:58 --> Language Class Initialized
INFO - 2024-02-29 10:44:58 --> Loader Class Initialized
INFO - 2024-02-29 10:44:58 --> Helper loaded: url_helper
INFO - 2024-02-29 10:44:58 --> Helper loaded: file_helper
INFO - 2024-02-29 10:44:58 --> Helper loaded: html_helper
INFO - 2024-02-29 10:44:58 --> Helper loaded: text_helper
INFO - 2024-02-29 10:44:58 --> Helper loaded: form_helper
INFO - 2024-02-29 10:44:58 --> Helper loaded: lang_helper
INFO - 2024-02-29 10:44:58 --> Helper loaded: security_helper
INFO - 2024-02-29 10:44:58 --> Helper loaded: cookie_helper
INFO - 2024-02-29 10:44:58 --> Database Driver Class Initialized
INFO - 2024-02-29 10:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 10:44:58 --> Parser Class Initialized
INFO - 2024-02-29 10:44:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 10:44:58 --> Pagination Class Initialized
INFO - 2024-02-29 10:44:58 --> Form Validation Class Initialized
INFO - 2024-02-29 10:44:58 --> Controller Class Initialized
INFO - 2024-02-29 10:44:58 --> Model Class Initialized
INFO - 2024-02-29 10:44:58 --> Model Class Initialized
INFO - 2024-02-29 10:44:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2024-02-29 10:44:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:44:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 10:44:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 10:44:58 --> Model Class Initialized
INFO - 2024-02-29 10:44:58 --> Model Class Initialized
INFO - 2024-02-29 10:44:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 10:44:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 10:44:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 10:44:58 --> Final output sent to browser
DEBUG - 2024-02-29 10:44:58 --> Total execution time: 0.1510
ERROR - 2024-02-29 10:44:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 10:44:59 --> Config Class Initialized
INFO - 2024-02-29 10:44:59 --> Hooks Class Initialized
DEBUG - 2024-02-29 10:44:59 --> UTF-8 Support Enabled
INFO - 2024-02-29 10:44:59 --> Utf8 Class Initialized
INFO - 2024-02-29 10:44:59 --> URI Class Initialized
INFO - 2024-02-29 10:44:59 --> Router Class Initialized
INFO - 2024-02-29 10:44:59 --> Output Class Initialized
INFO - 2024-02-29 10:44:59 --> Security Class Initialized
DEBUG - 2024-02-29 10:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 10:44:59 --> Input Class Initialized
INFO - 2024-02-29 10:44:59 --> Language Class Initialized
INFO - 2024-02-29 10:44:59 --> Loader Class Initialized
INFO - 2024-02-29 10:44:59 --> Helper loaded: url_helper
INFO - 2024-02-29 10:44:59 --> Helper loaded: file_helper
INFO - 2024-02-29 10:44:59 --> Helper loaded: html_helper
INFO - 2024-02-29 10:44:59 --> Helper loaded: text_helper
INFO - 2024-02-29 10:44:59 --> Helper loaded: form_helper
INFO - 2024-02-29 10:44:59 --> Helper loaded: lang_helper
INFO - 2024-02-29 10:44:59 --> Helper loaded: security_helper
INFO - 2024-02-29 10:44:59 --> Helper loaded: cookie_helper
INFO - 2024-02-29 10:44:59 --> Database Driver Class Initialized
INFO - 2024-02-29 10:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 10:44:59 --> Parser Class Initialized
INFO - 2024-02-29 10:44:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 10:44:59 --> Pagination Class Initialized
INFO - 2024-02-29 10:44:59 --> Form Validation Class Initialized
INFO - 2024-02-29 10:44:59 --> Controller Class Initialized
INFO - 2024-02-29 10:44:59 --> Model Class Initialized
INFO - 2024-02-29 10:44:59 --> Model Class Initialized
INFO - 2024-02-29 10:44:59 --> Final output sent to browser
DEBUG - 2024-02-29 10:44:59 --> Total execution time: 0.0814
ERROR - 2024-02-29 10:45:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 10:45:38 --> Config Class Initialized
INFO - 2024-02-29 10:45:38 --> Hooks Class Initialized
DEBUG - 2024-02-29 10:45:38 --> UTF-8 Support Enabled
INFO - 2024-02-29 10:45:38 --> Utf8 Class Initialized
INFO - 2024-02-29 10:45:38 --> URI Class Initialized
INFO - 2024-02-29 10:45:38 --> Router Class Initialized
INFO - 2024-02-29 10:45:38 --> Output Class Initialized
INFO - 2024-02-29 10:45:38 --> Security Class Initialized
DEBUG - 2024-02-29 10:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 10:45:38 --> Input Class Initialized
INFO - 2024-02-29 10:45:38 --> Language Class Initialized
INFO - 2024-02-29 10:45:38 --> Loader Class Initialized
INFO - 2024-02-29 10:45:38 --> Helper loaded: url_helper
INFO - 2024-02-29 10:45:38 --> Helper loaded: file_helper
INFO - 2024-02-29 10:45:38 --> Helper loaded: html_helper
INFO - 2024-02-29 10:45:38 --> Helper loaded: text_helper
INFO - 2024-02-29 10:45:38 --> Helper loaded: form_helper
INFO - 2024-02-29 10:45:38 --> Helper loaded: lang_helper
INFO - 2024-02-29 10:45:38 --> Helper loaded: security_helper
INFO - 2024-02-29 10:45:38 --> Helper loaded: cookie_helper
INFO - 2024-02-29 10:45:38 --> Database Driver Class Initialized
INFO - 2024-02-29 10:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 10:45:38 --> Parser Class Initialized
INFO - 2024-02-29 10:45:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 10:45:38 --> Pagination Class Initialized
INFO - 2024-02-29 10:45:38 --> Form Validation Class Initialized
INFO - 2024-02-29 10:45:38 --> Controller Class Initialized
INFO - 2024-02-29 10:45:38 --> Model Class Initialized
INFO - 2024-02-29 10:45:38 --> Model Class Initialized
INFO - 2024-02-29 10:45:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2024-02-29 10:45:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:45:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 10:45:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 10:45:38 --> Model Class Initialized
INFO - 2024-02-29 10:45:38 --> Model Class Initialized
INFO - 2024-02-29 10:45:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 10:45:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 10:45:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 10:45:38 --> Final output sent to browser
DEBUG - 2024-02-29 10:45:38 --> Total execution time: 0.1945
ERROR - 2024-02-29 10:45:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 10:45:39 --> Config Class Initialized
INFO - 2024-02-29 10:45:39 --> Hooks Class Initialized
DEBUG - 2024-02-29 10:45:39 --> UTF-8 Support Enabled
INFO - 2024-02-29 10:45:39 --> Utf8 Class Initialized
INFO - 2024-02-29 10:45:39 --> URI Class Initialized
INFO - 2024-02-29 10:45:39 --> Router Class Initialized
INFO - 2024-02-29 10:45:39 --> Output Class Initialized
INFO - 2024-02-29 10:45:39 --> Security Class Initialized
DEBUG - 2024-02-29 10:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 10:45:39 --> Input Class Initialized
INFO - 2024-02-29 10:45:39 --> Language Class Initialized
INFO - 2024-02-29 10:45:39 --> Loader Class Initialized
INFO - 2024-02-29 10:45:39 --> Helper loaded: url_helper
INFO - 2024-02-29 10:45:39 --> Helper loaded: file_helper
INFO - 2024-02-29 10:45:39 --> Helper loaded: html_helper
INFO - 2024-02-29 10:45:39 --> Helper loaded: text_helper
INFO - 2024-02-29 10:45:39 --> Helper loaded: form_helper
INFO - 2024-02-29 10:45:39 --> Helper loaded: lang_helper
INFO - 2024-02-29 10:45:39 --> Helper loaded: security_helper
INFO - 2024-02-29 10:45:39 --> Helper loaded: cookie_helper
INFO - 2024-02-29 10:45:39 --> Database Driver Class Initialized
INFO - 2024-02-29 10:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 10:45:39 --> Parser Class Initialized
INFO - 2024-02-29 10:45:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 10:45:39 --> Pagination Class Initialized
INFO - 2024-02-29 10:45:39 --> Form Validation Class Initialized
INFO - 2024-02-29 10:45:39 --> Controller Class Initialized
INFO - 2024-02-29 10:45:39 --> Model Class Initialized
INFO - 2024-02-29 10:45:39 --> Model Class Initialized
INFO - 2024-02-29 10:45:39 --> Final output sent to browser
DEBUG - 2024-02-29 10:45:39 --> Total execution time: 0.2009
ERROR - 2024-02-29 10:45:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 10:45:58 --> Config Class Initialized
INFO - 2024-02-29 10:45:58 --> Hooks Class Initialized
DEBUG - 2024-02-29 10:45:58 --> UTF-8 Support Enabled
INFO - 2024-02-29 10:45:58 --> Utf8 Class Initialized
INFO - 2024-02-29 10:45:58 --> URI Class Initialized
INFO - 2024-02-29 10:45:58 --> Router Class Initialized
INFO - 2024-02-29 10:45:58 --> Output Class Initialized
INFO - 2024-02-29 10:45:58 --> Security Class Initialized
DEBUG - 2024-02-29 10:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 10:45:58 --> Input Class Initialized
INFO - 2024-02-29 10:45:58 --> Language Class Initialized
INFO - 2024-02-29 10:45:58 --> Loader Class Initialized
INFO - 2024-02-29 10:45:58 --> Helper loaded: url_helper
INFO - 2024-02-29 10:45:58 --> Helper loaded: file_helper
INFO - 2024-02-29 10:45:58 --> Helper loaded: html_helper
INFO - 2024-02-29 10:45:58 --> Helper loaded: text_helper
INFO - 2024-02-29 10:45:58 --> Helper loaded: form_helper
INFO - 2024-02-29 10:45:58 --> Helper loaded: lang_helper
INFO - 2024-02-29 10:45:58 --> Helper loaded: security_helper
INFO - 2024-02-29 10:45:58 --> Helper loaded: cookie_helper
INFO - 2024-02-29 10:45:58 --> Database Driver Class Initialized
INFO - 2024-02-29 10:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 10:45:58 --> Parser Class Initialized
INFO - 2024-02-29 10:45:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 10:45:58 --> Pagination Class Initialized
INFO - 2024-02-29 10:45:58 --> Form Validation Class Initialized
INFO - 2024-02-29 10:45:58 --> Controller Class Initialized
INFO - 2024-02-29 10:45:58 --> Model Class Initialized
INFO - 2024-02-29 10:45:58 --> Model Class Initialized
INFO - 2024-02-29 10:45:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2024-02-29 10:45:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:45:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 10:45:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 10:45:58 --> Model Class Initialized
INFO - 2024-02-29 10:45:58 --> Model Class Initialized
INFO - 2024-02-29 10:45:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 10:45:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 10:45:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 10:45:58 --> Final output sent to browser
DEBUG - 2024-02-29 10:45:58 --> Total execution time: 0.1570
ERROR - 2024-02-29 10:45:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 10:45:59 --> Config Class Initialized
INFO - 2024-02-29 10:45:59 --> Hooks Class Initialized
DEBUG - 2024-02-29 10:45:59 --> UTF-8 Support Enabled
INFO - 2024-02-29 10:45:59 --> Utf8 Class Initialized
INFO - 2024-02-29 10:45:59 --> URI Class Initialized
INFO - 2024-02-29 10:45:59 --> Router Class Initialized
INFO - 2024-02-29 10:45:59 --> Output Class Initialized
INFO - 2024-02-29 10:45:59 --> Security Class Initialized
DEBUG - 2024-02-29 10:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 10:45:59 --> Input Class Initialized
INFO - 2024-02-29 10:45:59 --> Language Class Initialized
INFO - 2024-02-29 10:45:59 --> Loader Class Initialized
INFO - 2024-02-29 10:45:59 --> Helper loaded: url_helper
INFO - 2024-02-29 10:45:59 --> Helper loaded: file_helper
INFO - 2024-02-29 10:45:59 --> Helper loaded: html_helper
INFO - 2024-02-29 10:45:59 --> Helper loaded: text_helper
INFO - 2024-02-29 10:45:59 --> Helper loaded: form_helper
INFO - 2024-02-29 10:45:59 --> Helper loaded: lang_helper
INFO - 2024-02-29 10:45:59 --> Helper loaded: security_helper
INFO - 2024-02-29 10:45:59 --> Helper loaded: cookie_helper
INFO - 2024-02-29 10:45:59 --> Database Driver Class Initialized
INFO - 2024-02-29 10:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 10:45:59 --> Parser Class Initialized
INFO - 2024-02-29 10:45:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 10:45:59 --> Pagination Class Initialized
INFO - 2024-02-29 10:45:59 --> Form Validation Class Initialized
INFO - 2024-02-29 10:45:59 --> Controller Class Initialized
INFO - 2024-02-29 10:45:59 --> Model Class Initialized
INFO - 2024-02-29 10:45:59 --> Model Class Initialized
INFO - 2024-02-29 10:45:59 --> Final output sent to browser
DEBUG - 2024-02-29 10:45:59 --> Total execution time: 0.0851
ERROR - 2024-02-29 10:46:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 10:46:05 --> Config Class Initialized
INFO - 2024-02-29 10:46:05 --> Hooks Class Initialized
DEBUG - 2024-02-29 10:46:05 --> UTF-8 Support Enabled
INFO - 2024-02-29 10:46:05 --> Utf8 Class Initialized
INFO - 2024-02-29 10:46:05 --> URI Class Initialized
DEBUG - 2024-02-29 10:46:05 --> No URI present. Default controller set.
INFO - 2024-02-29 10:46:05 --> Router Class Initialized
INFO - 2024-02-29 10:46:05 --> Output Class Initialized
INFO - 2024-02-29 10:46:05 --> Security Class Initialized
DEBUG - 2024-02-29 10:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 10:46:05 --> Input Class Initialized
INFO - 2024-02-29 10:46:05 --> Language Class Initialized
INFO - 2024-02-29 10:46:05 --> Loader Class Initialized
INFO - 2024-02-29 10:46:05 --> Helper loaded: url_helper
INFO - 2024-02-29 10:46:05 --> Helper loaded: file_helper
INFO - 2024-02-29 10:46:05 --> Helper loaded: html_helper
INFO - 2024-02-29 10:46:05 --> Helper loaded: text_helper
INFO - 2024-02-29 10:46:05 --> Helper loaded: form_helper
INFO - 2024-02-29 10:46:05 --> Helper loaded: lang_helper
INFO - 2024-02-29 10:46:05 --> Helper loaded: security_helper
INFO - 2024-02-29 10:46:05 --> Helper loaded: cookie_helper
INFO - 2024-02-29 10:46:05 --> Database Driver Class Initialized
INFO - 2024-02-29 10:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 10:46:05 --> Parser Class Initialized
INFO - 2024-02-29 10:46:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 10:46:05 --> Pagination Class Initialized
INFO - 2024-02-29 10:46:05 --> Form Validation Class Initialized
INFO - 2024-02-29 10:46:05 --> Controller Class Initialized
INFO - 2024-02-29 10:46:05 --> Model Class Initialized
DEBUG - 2024-02-29 10:46:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:46:05 --> Model Class Initialized
DEBUG - 2024-02-29 10:46:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:46:05 --> Model Class Initialized
INFO - 2024-02-29 10:46:05 --> Model Class Initialized
INFO - 2024-02-29 10:46:05 --> Model Class Initialized
INFO - 2024-02-29 10:46:05 --> Model Class Initialized
DEBUG - 2024-02-29 10:46:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 10:46:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:46:05 --> Model Class Initialized
INFO - 2024-02-29 10:46:05 --> Model Class Initialized
INFO - 2024-02-29 10:46:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 10:46:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:46:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 10:46:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 10:46:05 --> Model Class Initialized
INFO - 2024-02-29 10:46:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 10:46:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 10:46:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 10:46:05 --> Final output sent to browser
DEBUG - 2024-02-29 10:46:05 --> Total execution time: 0.2254
ERROR - 2024-02-29 10:46:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 10:46:22 --> Config Class Initialized
INFO - 2024-02-29 10:46:22 --> Hooks Class Initialized
DEBUG - 2024-02-29 10:46:22 --> UTF-8 Support Enabled
INFO - 2024-02-29 10:46:22 --> Utf8 Class Initialized
INFO - 2024-02-29 10:46:22 --> URI Class Initialized
INFO - 2024-02-29 10:46:22 --> Router Class Initialized
INFO - 2024-02-29 10:46:22 --> Output Class Initialized
INFO - 2024-02-29 10:46:22 --> Security Class Initialized
DEBUG - 2024-02-29 10:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 10:46:22 --> Input Class Initialized
INFO - 2024-02-29 10:46:22 --> Language Class Initialized
INFO - 2024-02-29 10:46:22 --> Loader Class Initialized
INFO - 2024-02-29 10:46:22 --> Helper loaded: url_helper
INFO - 2024-02-29 10:46:22 --> Helper loaded: file_helper
INFO - 2024-02-29 10:46:22 --> Helper loaded: html_helper
INFO - 2024-02-29 10:46:22 --> Helper loaded: text_helper
INFO - 2024-02-29 10:46:22 --> Helper loaded: form_helper
INFO - 2024-02-29 10:46:22 --> Helper loaded: lang_helper
INFO - 2024-02-29 10:46:22 --> Helper loaded: security_helper
INFO - 2024-02-29 10:46:22 --> Helper loaded: cookie_helper
INFO - 2024-02-29 10:46:22 --> Database Driver Class Initialized
INFO - 2024-02-29 10:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 10:46:22 --> Parser Class Initialized
INFO - 2024-02-29 10:46:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 10:46:22 --> Pagination Class Initialized
INFO - 2024-02-29 10:46:22 --> Form Validation Class Initialized
INFO - 2024-02-29 10:46:22 --> Controller Class Initialized
INFO - 2024-02-29 10:46:22 --> Model Class Initialized
DEBUG - 2024-02-29 10:46:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 10:46:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:46:22 --> Model Class Initialized
DEBUG - 2024-02-29 10:46:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:46:22 --> Model Class Initialized
INFO - 2024-02-29 10:46:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-29 10:46:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:46:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 10:46:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 10:46:22 --> Model Class Initialized
INFO - 2024-02-29 10:46:22 --> Model Class Initialized
INFO - 2024-02-29 10:46:22 --> Model Class Initialized
INFO - 2024-02-29 10:46:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 10:46:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 10:46:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 10:46:22 --> Final output sent to browser
DEBUG - 2024-02-29 10:46:22 --> Total execution time: 0.1464
ERROR - 2024-02-29 10:46:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 10:46:23 --> Config Class Initialized
INFO - 2024-02-29 10:46:23 --> Hooks Class Initialized
DEBUG - 2024-02-29 10:46:23 --> UTF-8 Support Enabled
INFO - 2024-02-29 10:46:23 --> Utf8 Class Initialized
INFO - 2024-02-29 10:46:23 --> URI Class Initialized
INFO - 2024-02-29 10:46:23 --> Router Class Initialized
INFO - 2024-02-29 10:46:23 --> Output Class Initialized
INFO - 2024-02-29 10:46:23 --> Security Class Initialized
DEBUG - 2024-02-29 10:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 10:46:23 --> Input Class Initialized
INFO - 2024-02-29 10:46:23 --> Language Class Initialized
INFO - 2024-02-29 10:46:23 --> Loader Class Initialized
INFO - 2024-02-29 10:46:23 --> Helper loaded: url_helper
INFO - 2024-02-29 10:46:23 --> Helper loaded: file_helper
INFO - 2024-02-29 10:46:23 --> Helper loaded: html_helper
INFO - 2024-02-29 10:46:23 --> Helper loaded: text_helper
INFO - 2024-02-29 10:46:23 --> Helper loaded: form_helper
INFO - 2024-02-29 10:46:23 --> Helper loaded: lang_helper
INFO - 2024-02-29 10:46:23 --> Helper loaded: security_helper
INFO - 2024-02-29 10:46:23 --> Helper loaded: cookie_helper
INFO - 2024-02-29 10:46:23 --> Database Driver Class Initialized
INFO - 2024-02-29 10:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 10:46:23 --> Parser Class Initialized
INFO - 2024-02-29 10:46:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 10:46:23 --> Pagination Class Initialized
INFO - 2024-02-29 10:46:23 --> Form Validation Class Initialized
INFO - 2024-02-29 10:46:23 --> Controller Class Initialized
INFO - 2024-02-29 10:46:23 --> Model Class Initialized
DEBUG - 2024-02-29 10:46:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 10:46:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:46:23 --> Model Class Initialized
DEBUG - 2024-02-29 10:46:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:46:23 --> Model Class Initialized
INFO - 2024-02-29 10:46:23 --> Final output sent to browser
DEBUG - 2024-02-29 10:46:23 --> Total execution time: 0.0240
ERROR - 2024-02-29 10:47:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 10:47:21 --> Config Class Initialized
INFO - 2024-02-29 10:47:21 --> Hooks Class Initialized
DEBUG - 2024-02-29 10:47:21 --> UTF-8 Support Enabled
INFO - 2024-02-29 10:47:21 --> Utf8 Class Initialized
INFO - 2024-02-29 10:47:21 --> URI Class Initialized
DEBUG - 2024-02-29 10:47:21 --> No URI present. Default controller set.
INFO - 2024-02-29 10:47:21 --> Router Class Initialized
INFO - 2024-02-29 10:47:21 --> Output Class Initialized
INFO - 2024-02-29 10:47:21 --> Security Class Initialized
DEBUG - 2024-02-29 10:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 10:47:21 --> Input Class Initialized
INFO - 2024-02-29 10:47:21 --> Language Class Initialized
INFO - 2024-02-29 10:47:21 --> Loader Class Initialized
INFO - 2024-02-29 10:47:21 --> Helper loaded: url_helper
INFO - 2024-02-29 10:47:21 --> Helper loaded: file_helper
INFO - 2024-02-29 10:47:21 --> Helper loaded: html_helper
INFO - 2024-02-29 10:47:21 --> Helper loaded: text_helper
INFO - 2024-02-29 10:47:21 --> Helper loaded: form_helper
INFO - 2024-02-29 10:47:21 --> Helper loaded: lang_helper
INFO - 2024-02-29 10:47:21 --> Helper loaded: security_helper
INFO - 2024-02-29 10:47:21 --> Helper loaded: cookie_helper
INFO - 2024-02-29 10:47:21 --> Database Driver Class Initialized
INFO - 2024-02-29 10:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 10:47:21 --> Parser Class Initialized
INFO - 2024-02-29 10:47:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 10:47:21 --> Pagination Class Initialized
INFO - 2024-02-29 10:47:21 --> Form Validation Class Initialized
INFO - 2024-02-29 10:47:21 --> Controller Class Initialized
INFO - 2024-02-29 10:47:21 --> Model Class Initialized
DEBUG - 2024-02-29 10:47:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:47:21 --> Model Class Initialized
DEBUG - 2024-02-29 10:47:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:47:21 --> Model Class Initialized
INFO - 2024-02-29 10:47:21 --> Model Class Initialized
INFO - 2024-02-29 10:47:21 --> Model Class Initialized
INFO - 2024-02-29 10:47:21 --> Model Class Initialized
DEBUG - 2024-02-29 10:47:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 10:47:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:47:21 --> Model Class Initialized
INFO - 2024-02-29 10:47:21 --> Model Class Initialized
INFO - 2024-02-29 10:47:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 10:47:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:47:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 10:47:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 10:47:21 --> Model Class Initialized
INFO - 2024-02-29 10:47:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 10:47:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 10:47:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 10:47:21 --> Final output sent to browser
DEBUG - 2024-02-29 10:47:21 --> Total execution time: 0.2459
ERROR - 2024-02-29 10:47:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 10:47:29 --> Config Class Initialized
INFO - 2024-02-29 10:47:29 --> Hooks Class Initialized
DEBUG - 2024-02-29 10:47:29 --> UTF-8 Support Enabled
INFO - 2024-02-29 10:47:29 --> Utf8 Class Initialized
INFO - 2024-02-29 10:47:29 --> URI Class Initialized
INFO - 2024-02-29 10:47:29 --> Router Class Initialized
INFO - 2024-02-29 10:47:29 --> Output Class Initialized
INFO - 2024-02-29 10:47:29 --> Security Class Initialized
DEBUG - 2024-02-29 10:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 10:47:29 --> Input Class Initialized
INFO - 2024-02-29 10:47:29 --> Language Class Initialized
INFO - 2024-02-29 10:47:29 --> Loader Class Initialized
INFO - 2024-02-29 10:47:29 --> Helper loaded: url_helper
INFO - 2024-02-29 10:47:29 --> Helper loaded: file_helper
INFO - 2024-02-29 10:47:29 --> Helper loaded: html_helper
INFO - 2024-02-29 10:47:29 --> Helper loaded: text_helper
INFO - 2024-02-29 10:47:29 --> Helper loaded: form_helper
INFO - 2024-02-29 10:47:29 --> Helper loaded: lang_helper
INFO - 2024-02-29 10:47:29 --> Helper loaded: security_helper
INFO - 2024-02-29 10:47:29 --> Helper loaded: cookie_helper
INFO - 2024-02-29 10:47:29 --> Database Driver Class Initialized
INFO - 2024-02-29 10:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 10:47:29 --> Parser Class Initialized
INFO - 2024-02-29 10:47:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 10:47:29 --> Pagination Class Initialized
INFO - 2024-02-29 10:47:29 --> Form Validation Class Initialized
INFO - 2024-02-29 10:47:29 --> Controller Class Initialized
INFO - 2024-02-29 10:47:29 --> Model Class Initialized
DEBUG - 2024-02-29 10:47:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 10:47:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:47:29 --> Model Class Initialized
DEBUG - 2024-02-29 10:47:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:47:29 --> Model Class Initialized
INFO - 2024-02-29 10:47:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-29 10:47:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:47:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 10:47:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 10:47:29 --> Model Class Initialized
INFO - 2024-02-29 10:47:29 --> Model Class Initialized
INFO - 2024-02-29 10:47:29 --> Model Class Initialized
INFO - 2024-02-29 10:47:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 10:47:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 10:47:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 10:47:29 --> Final output sent to browser
DEBUG - 2024-02-29 10:47:29 --> Total execution time: 0.1449
ERROR - 2024-02-29 10:47:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 10:47:31 --> Config Class Initialized
INFO - 2024-02-29 10:47:31 --> Hooks Class Initialized
DEBUG - 2024-02-29 10:47:31 --> UTF-8 Support Enabled
INFO - 2024-02-29 10:47:31 --> Utf8 Class Initialized
INFO - 2024-02-29 10:47:31 --> URI Class Initialized
INFO - 2024-02-29 10:47:31 --> Router Class Initialized
INFO - 2024-02-29 10:47:31 --> Output Class Initialized
INFO - 2024-02-29 10:47:31 --> Security Class Initialized
DEBUG - 2024-02-29 10:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 10:47:31 --> Input Class Initialized
INFO - 2024-02-29 10:47:31 --> Language Class Initialized
INFO - 2024-02-29 10:47:31 --> Loader Class Initialized
INFO - 2024-02-29 10:47:31 --> Helper loaded: url_helper
INFO - 2024-02-29 10:47:31 --> Helper loaded: file_helper
INFO - 2024-02-29 10:47:31 --> Helper loaded: html_helper
INFO - 2024-02-29 10:47:31 --> Helper loaded: text_helper
INFO - 2024-02-29 10:47:31 --> Helper loaded: form_helper
INFO - 2024-02-29 10:47:31 --> Helper loaded: lang_helper
INFO - 2024-02-29 10:47:31 --> Helper loaded: security_helper
INFO - 2024-02-29 10:47:31 --> Helper loaded: cookie_helper
INFO - 2024-02-29 10:47:31 --> Database Driver Class Initialized
INFO - 2024-02-29 10:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 10:47:31 --> Parser Class Initialized
INFO - 2024-02-29 10:47:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 10:47:31 --> Pagination Class Initialized
INFO - 2024-02-29 10:47:31 --> Form Validation Class Initialized
INFO - 2024-02-29 10:47:31 --> Controller Class Initialized
INFO - 2024-02-29 10:47:31 --> Model Class Initialized
DEBUG - 2024-02-29 10:47:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 10:47:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:47:31 --> Model Class Initialized
DEBUG - 2024-02-29 10:47:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:47:31 --> Model Class Initialized
INFO - 2024-02-29 10:47:31 --> Final output sent to browser
DEBUG - 2024-02-29 10:47:31 --> Total execution time: 0.0248
ERROR - 2024-02-29 10:47:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 10:47:46 --> Config Class Initialized
INFO - 2024-02-29 10:47:46 --> Hooks Class Initialized
DEBUG - 2024-02-29 10:47:46 --> UTF-8 Support Enabled
INFO - 2024-02-29 10:47:46 --> Utf8 Class Initialized
INFO - 2024-02-29 10:47:46 --> URI Class Initialized
DEBUG - 2024-02-29 10:47:46 --> No URI present. Default controller set.
INFO - 2024-02-29 10:47:46 --> Router Class Initialized
INFO - 2024-02-29 10:47:46 --> Output Class Initialized
INFO - 2024-02-29 10:47:46 --> Security Class Initialized
DEBUG - 2024-02-29 10:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 10:47:46 --> Input Class Initialized
INFO - 2024-02-29 10:47:46 --> Language Class Initialized
INFO - 2024-02-29 10:47:46 --> Loader Class Initialized
INFO - 2024-02-29 10:47:46 --> Helper loaded: url_helper
INFO - 2024-02-29 10:47:46 --> Helper loaded: file_helper
INFO - 2024-02-29 10:47:46 --> Helper loaded: html_helper
INFO - 2024-02-29 10:47:46 --> Helper loaded: text_helper
INFO - 2024-02-29 10:47:46 --> Helper loaded: form_helper
INFO - 2024-02-29 10:47:46 --> Helper loaded: lang_helper
INFO - 2024-02-29 10:47:46 --> Helper loaded: security_helper
INFO - 2024-02-29 10:47:46 --> Helper loaded: cookie_helper
INFO - 2024-02-29 10:47:46 --> Database Driver Class Initialized
INFO - 2024-02-29 10:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 10:47:46 --> Parser Class Initialized
INFO - 2024-02-29 10:47:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 10:47:46 --> Pagination Class Initialized
INFO - 2024-02-29 10:47:46 --> Form Validation Class Initialized
INFO - 2024-02-29 10:47:46 --> Controller Class Initialized
INFO - 2024-02-29 10:47:46 --> Model Class Initialized
DEBUG - 2024-02-29 10:47:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:47:46 --> Model Class Initialized
DEBUG - 2024-02-29 10:47:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:47:46 --> Model Class Initialized
INFO - 2024-02-29 10:47:46 --> Model Class Initialized
INFO - 2024-02-29 10:47:46 --> Model Class Initialized
INFO - 2024-02-29 10:47:46 --> Model Class Initialized
DEBUG - 2024-02-29 10:47:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 10:47:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:47:46 --> Model Class Initialized
INFO - 2024-02-29 10:47:46 --> Model Class Initialized
INFO - 2024-02-29 10:47:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 10:47:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 10:47:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 10:47:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 10:47:47 --> Model Class Initialized
INFO - 2024-02-29 10:47:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 10:47:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 10:47:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 10:47:47 --> Final output sent to browser
DEBUG - 2024-02-29 10:47:47 --> Total execution time: 0.2356
ERROR - 2024-02-29 12:03:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 12:03:28 --> Config Class Initialized
INFO - 2024-02-29 12:03:28 --> Hooks Class Initialized
DEBUG - 2024-02-29 12:03:28 --> UTF-8 Support Enabled
INFO - 2024-02-29 12:03:28 --> Utf8 Class Initialized
INFO - 2024-02-29 12:03:28 --> URI Class Initialized
DEBUG - 2024-02-29 12:03:28 --> No URI present. Default controller set.
INFO - 2024-02-29 12:03:28 --> Router Class Initialized
INFO - 2024-02-29 12:03:28 --> Output Class Initialized
INFO - 2024-02-29 12:03:28 --> Security Class Initialized
DEBUG - 2024-02-29 12:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 12:03:28 --> Input Class Initialized
INFO - 2024-02-29 12:03:28 --> Language Class Initialized
INFO - 2024-02-29 12:03:28 --> Loader Class Initialized
INFO - 2024-02-29 12:03:28 --> Helper loaded: url_helper
INFO - 2024-02-29 12:03:28 --> Helper loaded: file_helper
INFO - 2024-02-29 12:03:28 --> Helper loaded: html_helper
INFO - 2024-02-29 12:03:28 --> Helper loaded: text_helper
INFO - 2024-02-29 12:03:28 --> Helper loaded: form_helper
INFO - 2024-02-29 12:03:28 --> Helper loaded: lang_helper
INFO - 2024-02-29 12:03:28 --> Helper loaded: security_helper
INFO - 2024-02-29 12:03:28 --> Helper loaded: cookie_helper
INFO - 2024-02-29 12:03:28 --> Database Driver Class Initialized
INFO - 2024-02-29 12:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 12:03:28 --> Parser Class Initialized
INFO - 2024-02-29 12:03:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 12:03:28 --> Pagination Class Initialized
INFO - 2024-02-29 12:03:28 --> Form Validation Class Initialized
INFO - 2024-02-29 12:03:28 --> Controller Class Initialized
INFO - 2024-02-29 12:03:28 --> Model Class Initialized
DEBUG - 2024-02-29 12:03:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-29 12:03:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 12:03:28 --> Config Class Initialized
INFO - 2024-02-29 12:03:28 --> Hooks Class Initialized
DEBUG - 2024-02-29 12:03:28 --> UTF-8 Support Enabled
INFO - 2024-02-29 12:03:28 --> Utf8 Class Initialized
INFO - 2024-02-29 12:03:28 --> URI Class Initialized
INFO - 2024-02-29 12:03:28 --> Router Class Initialized
INFO - 2024-02-29 12:03:28 --> Output Class Initialized
INFO - 2024-02-29 12:03:28 --> Security Class Initialized
DEBUG - 2024-02-29 12:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 12:03:28 --> Input Class Initialized
INFO - 2024-02-29 12:03:28 --> Language Class Initialized
INFO - 2024-02-29 12:03:28 --> Loader Class Initialized
INFO - 2024-02-29 12:03:28 --> Helper loaded: url_helper
INFO - 2024-02-29 12:03:28 --> Helper loaded: file_helper
INFO - 2024-02-29 12:03:28 --> Helper loaded: html_helper
INFO - 2024-02-29 12:03:28 --> Helper loaded: text_helper
INFO - 2024-02-29 12:03:28 --> Helper loaded: form_helper
INFO - 2024-02-29 12:03:28 --> Helper loaded: lang_helper
INFO - 2024-02-29 12:03:28 --> Helper loaded: security_helper
INFO - 2024-02-29 12:03:28 --> Helper loaded: cookie_helper
INFO - 2024-02-29 12:03:28 --> Database Driver Class Initialized
INFO - 2024-02-29 12:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 12:03:28 --> Parser Class Initialized
INFO - 2024-02-29 12:03:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 12:03:28 --> Pagination Class Initialized
INFO - 2024-02-29 12:03:28 --> Form Validation Class Initialized
INFO - 2024-02-29 12:03:28 --> Controller Class Initialized
INFO - 2024-02-29 12:03:28 --> Model Class Initialized
DEBUG - 2024-02-29 12:03:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 12:03:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-29 12:03:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 12:03:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 12:03:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 12:03:28 --> Model Class Initialized
INFO - 2024-02-29 12:03:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 12:03:28 --> Final output sent to browser
DEBUG - 2024-02-29 12:03:28 --> Total execution time: 0.0320
ERROR - 2024-02-29 12:03:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 12:03:44 --> Config Class Initialized
INFO - 2024-02-29 12:03:44 --> Hooks Class Initialized
DEBUG - 2024-02-29 12:03:44 --> UTF-8 Support Enabled
INFO - 2024-02-29 12:03:44 --> Utf8 Class Initialized
INFO - 2024-02-29 12:03:44 --> URI Class Initialized
INFO - 2024-02-29 12:03:44 --> Router Class Initialized
INFO - 2024-02-29 12:03:44 --> Output Class Initialized
INFO - 2024-02-29 12:03:44 --> Security Class Initialized
DEBUG - 2024-02-29 12:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 12:03:44 --> Input Class Initialized
INFO - 2024-02-29 12:03:44 --> Language Class Initialized
INFO - 2024-02-29 12:03:44 --> Loader Class Initialized
INFO - 2024-02-29 12:03:44 --> Helper loaded: url_helper
INFO - 2024-02-29 12:03:44 --> Helper loaded: file_helper
INFO - 2024-02-29 12:03:44 --> Helper loaded: html_helper
INFO - 2024-02-29 12:03:44 --> Helper loaded: text_helper
INFO - 2024-02-29 12:03:44 --> Helper loaded: form_helper
INFO - 2024-02-29 12:03:44 --> Helper loaded: lang_helper
INFO - 2024-02-29 12:03:44 --> Helper loaded: security_helper
INFO - 2024-02-29 12:03:44 --> Helper loaded: cookie_helper
INFO - 2024-02-29 12:03:44 --> Database Driver Class Initialized
INFO - 2024-02-29 12:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 12:03:44 --> Parser Class Initialized
INFO - 2024-02-29 12:03:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 12:03:44 --> Pagination Class Initialized
INFO - 2024-02-29 12:03:44 --> Form Validation Class Initialized
INFO - 2024-02-29 12:03:44 --> Controller Class Initialized
INFO - 2024-02-29 12:03:44 --> Model Class Initialized
DEBUG - 2024-02-29 12:03:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 12:03:44 --> Model Class Initialized
INFO - 2024-02-29 12:03:44 --> Final output sent to browser
DEBUG - 2024-02-29 12:03:44 --> Total execution time: 0.0208
ERROR - 2024-02-29 12:03:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 12:03:44 --> Config Class Initialized
INFO - 2024-02-29 12:03:44 --> Hooks Class Initialized
DEBUG - 2024-02-29 12:03:44 --> UTF-8 Support Enabled
INFO - 2024-02-29 12:03:44 --> Utf8 Class Initialized
INFO - 2024-02-29 12:03:44 --> URI Class Initialized
INFO - 2024-02-29 12:03:44 --> Router Class Initialized
INFO - 2024-02-29 12:03:44 --> Output Class Initialized
INFO - 2024-02-29 12:03:44 --> Security Class Initialized
DEBUG - 2024-02-29 12:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 12:03:44 --> Input Class Initialized
INFO - 2024-02-29 12:03:44 --> Language Class Initialized
INFO - 2024-02-29 12:03:44 --> Loader Class Initialized
INFO - 2024-02-29 12:03:44 --> Helper loaded: url_helper
INFO - 2024-02-29 12:03:44 --> Helper loaded: file_helper
INFO - 2024-02-29 12:03:44 --> Helper loaded: html_helper
INFO - 2024-02-29 12:03:44 --> Helper loaded: text_helper
INFO - 2024-02-29 12:03:44 --> Helper loaded: form_helper
INFO - 2024-02-29 12:03:44 --> Helper loaded: lang_helper
INFO - 2024-02-29 12:03:44 --> Helper loaded: security_helper
INFO - 2024-02-29 12:03:44 --> Helper loaded: cookie_helper
INFO - 2024-02-29 12:03:44 --> Database Driver Class Initialized
INFO - 2024-02-29 12:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 12:03:44 --> Parser Class Initialized
INFO - 2024-02-29 12:03:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 12:03:44 --> Pagination Class Initialized
INFO - 2024-02-29 12:03:44 --> Form Validation Class Initialized
INFO - 2024-02-29 12:03:44 --> Controller Class Initialized
INFO - 2024-02-29 12:03:44 --> Model Class Initialized
DEBUG - 2024-02-29 12:03:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 12:03:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-29 12:03:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 12:03:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 12:03:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 12:03:44 --> Model Class Initialized
INFO - 2024-02-29 12:03:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 12:03:44 --> Final output sent to browser
DEBUG - 2024-02-29 12:03:44 --> Total execution time: 0.0288
ERROR - 2024-02-29 12:03:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 12:03:57 --> Config Class Initialized
INFO - 2024-02-29 12:03:57 --> Hooks Class Initialized
DEBUG - 2024-02-29 12:03:57 --> UTF-8 Support Enabled
INFO - 2024-02-29 12:03:57 --> Utf8 Class Initialized
INFO - 2024-02-29 12:03:57 --> URI Class Initialized
INFO - 2024-02-29 12:03:57 --> Router Class Initialized
INFO - 2024-02-29 12:03:57 --> Output Class Initialized
INFO - 2024-02-29 12:03:57 --> Security Class Initialized
DEBUG - 2024-02-29 12:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 12:03:57 --> Input Class Initialized
INFO - 2024-02-29 12:03:57 --> Language Class Initialized
INFO - 2024-02-29 12:03:57 --> Loader Class Initialized
INFO - 2024-02-29 12:03:57 --> Helper loaded: url_helper
INFO - 2024-02-29 12:03:57 --> Helper loaded: file_helper
INFO - 2024-02-29 12:03:57 --> Helper loaded: html_helper
INFO - 2024-02-29 12:03:57 --> Helper loaded: text_helper
INFO - 2024-02-29 12:03:57 --> Helper loaded: form_helper
INFO - 2024-02-29 12:03:57 --> Helper loaded: lang_helper
INFO - 2024-02-29 12:03:57 --> Helper loaded: security_helper
INFO - 2024-02-29 12:03:57 --> Helper loaded: cookie_helper
INFO - 2024-02-29 12:03:57 --> Database Driver Class Initialized
INFO - 2024-02-29 12:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 12:03:57 --> Parser Class Initialized
INFO - 2024-02-29 12:03:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 12:03:57 --> Pagination Class Initialized
INFO - 2024-02-29 12:03:57 --> Form Validation Class Initialized
INFO - 2024-02-29 12:03:57 --> Controller Class Initialized
INFO - 2024-02-29 12:03:57 --> Model Class Initialized
DEBUG - 2024-02-29 12:03:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 12:03:57 --> Model Class Initialized
INFO - 2024-02-29 12:03:57 --> Final output sent to browser
DEBUG - 2024-02-29 12:03:57 --> Total execution time: 0.0187
ERROR - 2024-02-29 12:03:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 12:03:57 --> Config Class Initialized
INFO - 2024-02-29 12:03:57 --> Hooks Class Initialized
DEBUG - 2024-02-29 12:03:57 --> UTF-8 Support Enabled
INFO - 2024-02-29 12:03:57 --> Utf8 Class Initialized
INFO - 2024-02-29 12:03:57 --> URI Class Initialized
DEBUG - 2024-02-29 12:03:57 --> No URI present. Default controller set.
INFO - 2024-02-29 12:03:57 --> Router Class Initialized
INFO - 2024-02-29 12:03:57 --> Output Class Initialized
INFO - 2024-02-29 12:03:57 --> Security Class Initialized
DEBUG - 2024-02-29 12:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 12:03:57 --> Input Class Initialized
INFO - 2024-02-29 12:03:57 --> Language Class Initialized
INFO - 2024-02-29 12:03:57 --> Loader Class Initialized
INFO - 2024-02-29 12:03:57 --> Helper loaded: url_helper
INFO - 2024-02-29 12:03:57 --> Helper loaded: file_helper
INFO - 2024-02-29 12:03:57 --> Helper loaded: html_helper
INFO - 2024-02-29 12:03:57 --> Helper loaded: text_helper
INFO - 2024-02-29 12:03:57 --> Helper loaded: form_helper
INFO - 2024-02-29 12:03:57 --> Helper loaded: lang_helper
INFO - 2024-02-29 12:03:57 --> Helper loaded: security_helper
INFO - 2024-02-29 12:03:57 --> Helper loaded: cookie_helper
INFO - 2024-02-29 12:03:57 --> Database Driver Class Initialized
INFO - 2024-02-29 12:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 12:03:57 --> Parser Class Initialized
INFO - 2024-02-29 12:03:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 12:03:57 --> Pagination Class Initialized
INFO - 2024-02-29 12:03:57 --> Form Validation Class Initialized
INFO - 2024-02-29 12:03:57 --> Controller Class Initialized
INFO - 2024-02-29 12:03:57 --> Model Class Initialized
DEBUG - 2024-02-29 12:03:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 12:03:57 --> Model Class Initialized
DEBUG - 2024-02-29 12:03:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 12:03:57 --> Model Class Initialized
INFO - 2024-02-29 12:03:57 --> Model Class Initialized
INFO - 2024-02-29 12:03:57 --> Model Class Initialized
INFO - 2024-02-29 12:03:57 --> Model Class Initialized
DEBUG - 2024-02-29 12:03:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 12:03:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 12:03:57 --> Model Class Initialized
INFO - 2024-02-29 12:03:57 --> Model Class Initialized
INFO - 2024-02-29 12:03:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 12:03:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 12:03:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 12:03:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 12:03:57 --> Model Class Initialized
INFO - 2024-02-29 12:03:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 12:03:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 12:03:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 12:03:57 --> Final output sent to browser
DEBUG - 2024-02-29 12:03:57 --> Total execution time: 0.2396
ERROR - 2024-02-29 12:05:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 12:05:18 --> Config Class Initialized
INFO - 2024-02-29 12:05:18 --> Hooks Class Initialized
DEBUG - 2024-02-29 12:05:18 --> UTF-8 Support Enabled
INFO - 2024-02-29 12:05:18 --> Utf8 Class Initialized
INFO - 2024-02-29 12:05:18 --> URI Class Initialized
INFO - 2024-02-29 12:05:18 --> Router Class Initialized
INFO - 2024-02-29 12:05:18 --> Output Class Initialized
INFO - 2024-02-29 12:05:18 --> Security Class Initialized
DEBUG - 2024-02-29 12:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 12:05:18 --> Input Class Initialized
INFO - 2024-02-29 12:05:18 --> Language Class Initialized
INFO - 2024-02-29 12:05:18 --> Loader Class Initialized
INFO - 2024-02-29 12:05:18 --> Helper loaded: url_helper
INFO - 2024-02-29 12:05:18 --> Helper loaded: file_helper
INFO - 2024-02-29 12:05:18 --> Helper loaded: html_helper
INFO - 2024-02-29 12:05:18 --> Helper loaded: text_helper
INFO - 2024-02-29 12:05:18 --> Helper loaded: form_helper
INFO - 2024-02-29 12:05:18 --> Helper loaded: lang_helper
INFO - 2024-02-29 12:05:18 --> Helper loaded: security_helper
INFO - 2024-02-29 12:05:18 --> Helper loaded: cookie_helper
INFO - 2024-02-29 12:05:18 --> Database Driver Class Initialized
INFO - 2024-02-29 12:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 12:05:18 --> Parser Class Initialized
INFO - 2024-02-29 12:05:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 12:05:18 --> Pagination Class Initialized
INFO - 2024-02-29 12:05:18 --> Form Validation Class Initialized
INFO - 2024-02-29 12:05:18 --> Controller Class Initialized
INFO - 2024-02-29 12:05:18 --> Model Class Initialized
DEBUG - 2024-02-29 12:05:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 12:05:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 12:05:18 --> Model Class Initialized
DEBUG - 2024-02-29 12:05:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 12:05:18 --> Model Class Initialized
INFO - 2024-02-29 12:05:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-29 12:05:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 12:05:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 12:05:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 12:05:18 --> Model Class Initialized
INFO - 2024-02-29 12:05:18 --> Model Class Initialized
INFO - 2024-02-29 12:05:18 --> Model Class Initialized
INFO - 2024-02-29 12:05:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 12:05:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 12:05:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 12:05:18 --> Final output sent to browser
DEBUG - 2024-02-29 12:05:18 --> Total execution time: 0.1625
ERROR - 2024-02-29 12:05:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 12:05:19 --> Config Class Initialized
INFO - 2024-02-29 12:05:19 --> Hooks Class Initialized
DEBUG - 2024-02-29 12:05:19 --> UTF-8 Support Enabled
INFO - 2024-02-29 12:05:19 --> Utf8 Class Initialized
INFO - 2024-02-29 12:05:19 --> URI Class Initialized
INFO - 2024-02-29 12:05:19 --> Router Class Initialized
INFO - 2024-02-29 12:05:19 --> Output Class Initialized
INFO - 2024-02-29 12:05:19 --> Security Class Initialized
DEBUG - 2024-02-29 12:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 12:05:19 --> Input Class Initialized
INFO - 2024-02-29 12:05:19 --> Language Class Initialized
INFO - 2024-02-29 12:05:19 --> Loader Class Initialized
INFO - 2024-02-29 12:05:19 --> Helper loaded: url_helper
INFO - 2024-02-29 12:05:19 --> Helper loaded: file_helper
INFO - 2024-02-29 12:05:19 --> Helper loaded: html_helper
INFO - 2024-02-29 12:05:19 --> Helper loaded: text_helper
INFO - 2024-02-29 12:05:19 --> Helper loaded: form_helper
INFO - 2024-02-29 12:05:19 --> Helper loaded: lang_helper
INFO - 2024-02-29 12:05:19 --> Helper loaded: security_helper
INFO - 2024-02-29 12:05:19 --> Helper loaded: cookie_helper
INFO - 2024-02-29 12:05:19 --> Database Driver Class Initialized
INFO - 2024-02-29 12:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 12:05:19 --> Parser Class Initialized
INFO - 2024-02-29 12:05:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 12:05:19 --> Pagination Class Initialized
INFO - 2024-02-29 12:05:19 --> Form Validation Class Initialized
INFO - 2024-02-29 12:05:19 --> Controller Class Initialized
INFO - 2024-02-29 12:05:19 --> Model Class Initialized
DEBUG - 2024-02-29 12:05:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 12:05:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 12:05:19 --> Model Class Initialized
DEBUG - 2024-02-29 12:05:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 12:05:19 --> Model Class Initialized
INFO - 2024-02-29 12:05:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-29 12:05:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 12:05:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 12:05:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 12:05:19 --> Model Class Initialized
INFO - 2024-02-29 12:05:19 --> Model Class Initialized
INFO - 2024-02-29 12:05:19 --> Model Class Initialized
INFO - 2024-02-29 12:05:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 12:05:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 12:05:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 12:05:19 --> Final output sent to browser
DEBUG - 2024-02-29 12:05:19 --> Total execution time: 0.1562
ERROR - 2024-02-29 12:05:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 12:05:20 --> Config Class Initialized
INFO - 2024-02-29 12:05:20 --> Hooks Class Initialized
DEBUG - 2024-02-29 12:05:20 --> UTF-8 Support Enabled
INFO - 2024-02-29 12:05:20 --> Utf8 Class Initialized
INFO - 2024-02-29 12:05:20 --> URI Class Initialized
INFO - 2024-02-29 12:05:20 --> Router Class Initialized
INFO - 2024-02-29 12:05:20 --> Output Class Initialized
INFO - 2024-02-29 12:05:20 --> Security Class Initialized
DEBUG - 2024-02-29 12:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 12:05:20 --> Input Class Initialized
INFO - 2024-02-29 12:05:20 --> Language Class Initialized
INFO - 2024-02-29 12:05:20 --> Loader Class Initialized
INFO - 2024-02-29 12:05:20 --> Helper loaded: url_helper
INFO - 2024-02-29 12:05:20 --> Helper loaded: file_helper
INFO - 2024-02-29 12:05:20 --> Helper loaded: html_helper
INFO - 2024-02-29 12:05:20 --> Helper loaded: text_helper
INFO - 2024-02-29 12:05:20 --> Helper loaded: form_helper
INFO - 2024-02-29 12:05:20 --> Helper loaded: lang_helper
INFO - 2024-02-29 12:05:20 --> Helper loaded: security_helper
INFO - 2024-02-29 12:05:20 --> Helper loaded: cookie_helper
INFO - 2024-02-29 12:05:20 --> Database Driver Class Initialized
INFO - 2024-02-29 12:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 12:05:20 --> Parser Class Initialized
INFO - 2024-02-29 12:05:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 12:05:20 --> Pagination Class Initialized
INFO - 2024-02-29 12:05:20 --> Form Validation Class Initialized
INFO - 2024-02-29 12:05:20 --> Controller Class Initialized
INFO - 2024-02-29 12:05:20 --> Model Class Initialized
DEBUG - 2024-02-29 12:05:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 12:05:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 12:05:20 --> Model Class Initialized
DEBUG - 2024-02-29 12:05:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 12:05:20 --> Model Class Initialized
INFO - 2024-02-29 12:05:20 --> Final output sent to browser
DEBUG - 2024-02-29 12:05:20 --> Total execution time: 0.0408
ERROR - 2024-02-29 12:05:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 12:05:34 --> Config Class Initialized
INFO - 2024-02-29 12:05:34 --> Hooks Class Initialized
DEBUG - 2024-02-29 12:05:34 --> UTF-8 Support Enabled
INFO - 2024-02-29 12:05:34 --> Utf8 Class Initialized
INFO - 2024-02-29 12:05:34 --> URI Class Initialized
INFO - 2024-02-29 12:05:34 --> Router Class Initialized
INFO - 2024-02-29 12:05:34 --> Output Class Initialized
INFO - 2024-02-29 12:05:34 --> Security Class Initialized
DEBUG - 2024-02-29 12:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 12:05:34 --> Input Class Initialized
INFO - 2024-02-29 12:05:34 --> Language Class Initialized
INFO - 2024-02-29 12:05:34 --> Loader Class Initialized
INFO - 2024-02-29 12:05:34 --> Helper loaded: url_helper
INFO - 2024-02-29 12:05:34 --> Helper loaded: file_helper
INFO - 2024-02-29 12:05:34 --> Helper loaded: html_helper
INFO - 2024-02-29 12:05:34 --> Helper loaded: text_helper
INFO - 2024-02-29 12:05:34 --> Helper loaded: form_helper
INFO - 2024-02-29 12:05:34 --> Helper loaded: lang_helper
INFO - 2024-02-29 12:05:34 --> Helper loaded: security_helper
INFO - 2024-02-29 12:05:34 --> Helper loaded: cookie_helper
INFO - 2024-02-29 12:05:34 --> Database Driver Class Initialized
INFO - 2024-02-29 12:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 12:05:34 --> Parser Class Initialized
INFO - 2024-02-29 12:05:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 12:05:34 --> Pagination Class Initialized
INFO - 2024-02-29 12:05:34 --> Form Validation Class Initialized
INFO - 2024-02-29 12:05:34 --> Controller Class Initialized
INFO - 2024-02-29 12:05:34 --> Model Class Initialized
DEBUG - 2024-02-29 12:05:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 12:05:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 12:05:34 --> Model Class Initialized
DEBUG - 2024-02-29 12:05:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 12:05:34 --> Model Class Initialized
DEBUG - 2024-02-29 12:05:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 12:05:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-02-29 12:05:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 12:05:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 12:05:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 12:05:34 --> Model Class Initialized
INFO - 2024-02-29 12:05:34 --> Model Class Initialized
INFO - 2024-02-29 12:05:34 --> Model Class Initialized
INFO - 2024-02-29 12:05:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 12:05:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 12:05:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 12:05:34 --> Final output sent to browser
DEBUG - 2024-02-29 12:05:34 --> Total execution time: 0.1638
ERROR - 2024-02-29 14:05:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 14:05:22 --> Config Class Initialized
INFO - 2024-02-29 14:05:22 --> Hooks Class Initialized
DEBUG - 2024-02-29 14:05:22 --> UTF-8 Support Enabled
INFO - 2024-02-29 14:05:22 --> Utf8 Class Initialized
INFO - 2024-02-29 14:05:22 --> URI Class Initialized
DEBUG - 2024-02-29 14:05:22 --> No URI present. Default controller set.
INFO - 2024-02-29 14:05:22 --> Router Class Initialized
INFO - 2024-02-29 14:05:22 --> Output Class Initialized
INFO - 2024-02-29 14:05:22 --> Security Class Initialized
DEBUG - 2024-02-29 14:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 14:05:22 --> Input Class Initialized
INFO - 2024-02-29 14:05:22 --> Language Class Initialized
INFO - 2024-02-29 14:05:22 --> Loader Class Initialized
INFO - 2024-02-29 14:05:22 --> Helper loaded: url_helper
INFO - 2024-02-29 14:05:22 --> Helper loaded: file_helper
INFO - 2024-02-29 14:05:22 --> Helper loaded: html_helper
INFO - 2024-02-29 14:05:22 --> Helper loaded: text_helper
INFO - 2024-02-29 14:05:22 --> Helper loaded: form_helper
INFO - 2024-02-29 14:05:22 --> Helper loaded: lang_helper
INFO - 2024-02-29 14:05:22 --> Helper loaded: security_helper
INFO - 2024-02-29 14:05:22 --> Helper loaded: cookie_helper
INFO - 2024-02-29 14:05:22 --> Database Driver Class Initialized
INFO - 2024-02-29 14:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 14:05:22 --> Parser Class Initialized
INFO - 2024-02-29 14:05:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 14:05:22 --> Pagination Class Initialized
INFO - 2024-02-29 14:05:22 --> Form Validation Class Initialized
INFO - 2024-02-29 14:05:22 --> Controller Class Initialized
INFO - 2024-02-29 14:05:22 --> Model Class Initialized
DEBUG - 2024-02-29 14:05:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-29 14:05:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 14:05:22 --> Config Class Initialized
INFO - 2024-02-29 14:05:22 --> Hooks Class Initialized
DEBUG - 2024-02-29 14:05:22 --> UTF-8 Support Enabled
INFO - 2024-02-29 14:05:22 --> Utf8 Class Initialized
INFO - 2024-02-29 14:05:22 --> URI Class Initialized
INFO - 2024-02-29 14:05:22 --> Router Class Initialized
INFO - 2024-02-29 14:05:22 --> Output Class Initialized
INFO - 2024-02-29 14:05:22 --> Security Class Initialized
DEBUG - 2024-02-29 14:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 14:05:22 --> Input Class Initialized
INFO - 2024-02-29 14:05:22 --> Language Class Initialized
INFO - 2024-02-29 14:05:22 --> Loader Class Initialized
INFO - 2024-02-29 14:05:22 --> Helper loaded: url_helper
INFO - 2024-02-29 14:05:22 --> Helper loaded: file_helper
INFO - 2024-02-29 14:05:22 --> Helper loaded: html_helper
INFO - 2024-02-29 14:05:22 --> Helper loaded: text_helper
INFO - 2024-02-29 14:05:22 --> Helper loaded: form_helper
INFO - 2024-02-29 14:05:22 --> Helper loaded: lang_helper
INFO - 2024-02-29 14:05:22 --> Helper loaded: security_helper
INFO - 2024-02-29 14:05:22 --> Helper loaded: cookie_helper
INFO - 2024-02-29 14:05:22 --> Database Driver Class Initialized
INFO - 2024-02-29 14:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 14:05:22 --> Parser Class Initialized
INFO - 2024-02-29 14:05:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 14:05:22 --> Pagination Class Initialized
INFO - 2024-02-29 14:05:22 --> Form Validation Class Initialized
INFO - 2024-02-29 14:05:22 --> Controller Class Initialized
INFO - 2024-02-29 14:05:22 --> Model Class Initialized
DEBUG - 2024-02-29 14:05:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 14:05:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-29 14:05:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 14:05:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 14:05:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 14:05:22 --> Model Class Initialized
INFO - 2024-02-29 14:05:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 14:05:22 --> Final output sent to browser
DEBUG - 2024-02-29 14:05:22 --> Total execution time: 0.0362
ERROR - 2024-02-29 14:05:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 14:05:32 --> Config Class Initialized
INFO - 2024-02-29 14:05:32 --> Hooks Class Initialized
DEBUG - 2024-02-29 14:05:32 --> UTF-8 Support Enabled
INFO - 2024-02-29 14:05:32 --> Utf8 Class Initialized
INFO - 2024-02-29 14:05:32 --> URI Class Initialized
INFO - 2024-02-29 14:05:32 --> Router Class Initialized
INFO - 2024-02-29 14:05:32 --> Output Class Initialized
INFO - 2024-02-29 14:05:32 --> Security Class Initialized
DEBUG - 2024-02-29 14:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 14:05:32 --> Input Class Initialized
INFO - 2024-02-29 14:05:32 --> Language Class Initialized
INFO - 2024-02-29 14:05:32 --> Loader Class Initialized
INFO - 2024-02-29 14:05:32 --> Helper loaded: url_helper
INFO - 2024-02-29 14:05:32 --> Helper loaded: file_helper
INFO - 2024-02-29 14:05:32 --> Helper loaded: html_helper
INFO - 2024-02-29 14:05:32 --> Helper loaded: text_helper
INFO - 2024-02-29 14:05:32 --> Helper loaded: form_helper
INFO - 2024-02-29 14:05:32 --> Helper loaded: lang_helper
INFO - 2024-02-29 14:05:32 --> Helper loaded: security_helper
INFO - 2024-02-29 14:05:32 --> Helper loaded: cookie_helper
INFO - 2024-02-29 14:05:32 --> Database Driver Class Initialized
INFO - 2024-02-29 14:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 14:05:32 --> Parser Class Initialized
INFO - 2024-02-29 14:05:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 14:05:32 --> Pagination Class Initialized
INFO - 2024-02-29 14:05:32 --> Form Validation Class Initialized
INFO - 2024-02-29 14:05:32 --> Controller Class Initialized
INFO - 2024-02-29 14:05:32 --> Model Class Initialized
DEBUG - 2024-02-29 14:05:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 14:05:32 --> Model Class Initialized
INFO - 2024-02-29 14:05:32 --> Final output sent to browser
DEBUG - 2024-02-29 14:05:32 --> Total execution time: 0.0199
ERROR - 2024-02-29 14:05:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 14:05:33 --> Config Class Initialized
INFO - 2024-02-29 14:05:33 --> Hooks Class Initialized
DEBUG - 2024-02-29 14:05:33 --> UTF-8 Support Enabled
INFO - 2024-02-29 14:05:33 --> Utf8 Class Initialized
INFO - 2024-02-29 14:05:33 --> URI Class Initialized
DEBUG - 2024-02-29 14:05:33 --> No URI present. Default controller set.
INFO - 2024-02-29 14:05:33 --> Router Class Initialized
INFO - 2024-02-29 14:05:33 --> Output Class Initialized
INFO - 2024-02-29 14:05:33 --> Security Class Initialized
DEBUG - 2024-02-29 14:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 14:05:33 --> Input Class Initialized
INFO - 2024-02-29 14:05:33 --> Language Class Initialized
INFO - 2024-02-29 14:05:33 --> Loader Class Initialized
INFO - 2024-02-29 14:05:33 --> Helper loaded: url_helper
INFO - 2024-02-29 14:05:33 --> Helper loaded: file_helper
INFO - 2024-02-29 14:05:33 --> Helper loaded: html_helper
INFO - 2024-02-29 14:05:33 --> Helper loaded: text_helper
INFO - 2024-02-29 14:05:33 --> Helper loaded: form_helper
INFO - 2024-02-29 14:05:33 --> Helper loaded: lang_helper
INFO - 2024-02-29 14:05:33 --> Helper loaded: security_helper
INFO - 2024-02-29 14:05:33 --> Helper loaded: cookie_helper
INFO - 2024-02-29 14:05:33 --> Database Driver Class Initialized
INFO - 2024-02-29 14:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 14:05:33 --> Parser Class Initialized
INFO - 2024-02-29 14:05:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 14:05:33 --> Pagination Class Initialized
INFO - 2024-02-29 14:05:33 --> Form Validation Class Initialized
INFO - 2024-02-29 14:05:33 --> Controller Class Initialized
INFO - 2024-02-29 14:05:33 --> Model Class Initialized
DEBUG - 2024-02-29 14:05:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 14:05:33 --> Model Class Initialized
DEBUG - 2024-02-29 14:05:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 14:05:33 --> Model Class Initialized
INFO - 2024-02-29 14:05:33 --> Model Class Initialized
INFO - 2024-02-29 14:05:33 --> Model Class Initialized
INFO - 2024-02-29 14:05:33 --> Model Class Initialized
DEBUG - 2024-02-29 14:05:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 14:05:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 14:05:33 --> Model Class Initialized
INFO - 2024-02-29 14:05:33 --> Model Class Initialized
INFO - 2024-02-29 14:05:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-29 14:05:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 14:05:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 14:05:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 14:05:33 --> Model Class Initialized
INFO - 2024-02-29 14:05:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 14:05:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 14:05:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 14:05:33 --> Final output sent to browser
DEBUG - 2024-02-29 14:05:33 --> Total execution time: 0.4469
ERROR - 2024-02-29 14:05:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 14:05:34 --> Config Class Initialized
INFO - 2024-02-29 14:05:34 --> Hooks Class Initialized
DEBUG - 2024-02-29 14:05:34 --> UTF-8 Support Enabled
INFO - 2024-02-29 14:05:34 --> Utf8 Class Initialized
INFO - 2024-02-29 14:05:34 --> URI Class Initialized
INFO - 2024-02-29 14:05:34 --> Router Class Initialized
INFO - 2024-02-29 14:05:34 --> Output Class Initialized
INFO - 2024-02-29 14:05:34 --> Security Class Initialized
DEBUG - 2024-02-29 14:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 14:05:34 --> Input Class Initialized
INFO - 2024-02-29 14:05:34 --> Language Class Initialized
INFO - 2024-02-29 14:05:34 --> Loader Class Initialized
INFO - 2024-02-29 14:05:34 --> Helper loaded: url_helper
INFO - 2024-02-29 14:05:34 --> Helper loaded: file_helper
INFO - 2024-02-29 14:05:34 --> Helper loaded: html_helper
INFO - 2024-02-29 14:05:34 --> Helper loaded: text_helper
INFO - 2024-02-29 14:05:34 --> Helper loaded: form_helper
INFO - 2024-02-29 14:05:34 --> Helper loaded: lang_helper
INFO - 2024-02-29 14:05:34 --> Helper loaded: security_helper
INFO - 2024-02-29 14:05:34 --> Helper loaded: cookie_helper
INFO - 2024-02-29 14:05:34 --> Database Driver Class Initialized
INFO - 2024-02-29 14:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 14:05:34 --> Parser Class Initialized
INFO - 2024-02-29 14:05:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 14:05:34 --> Pagination Class Initialized
INFO - 2024-02-29 14:05:34 --> Form Validation Class Initialized
INFO - 2024-02-29 14:05:34 --> Controller Class Initialized
DEBUG - 2024-02-29 14:05:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 14:05:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 14:05:34 --> Model Class Initialized
INFO - 2024-02-29 14:05:34 --> Final output sent to browser
DEBUG - 2024-02-29 14:05:34 --> Total execution time: 0.0132
ERROR - 2024-02-29 14:05:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 14:05:44 --> Config Class Initialized
INFO - 2024-02-29 14:05:44 --> Hooks Class Initialized
DEBUG - 2024-02-29 14:05:44 --> UTF-8 Support Enabled
INFO - 2024-02-29 14:05:44 --> Utf8 Class Initialized
INFO - 2024-02-29 14:05:44 --> URI Class Initialized
INFO - 2024-02-29 14:05:44 --> Router Class Initialized
INFO - 2024-02-29 14:05:44 --> Output Class Initialized
INFO - 2024-02-29 14:05:44 --> Security Class Initialized
DEBUG - 2024-02-29 14:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 14:05:44 --> Input Class Initialized
INFO - 2024-02-29 14:05:44 --> Language Class Initialized
INFO - 2024-02-29 14:05:44 --> Loader Class Initialized
INFO - 2024-02-29 14:05:44 --> Helper loaded: url_helper
INFO - 2024-02-29 14:05:44 --> Helper loaded: file_helper
INFO - 2024-02-29 14:05:44 --> Helper loaded: html_helper
INFO - 2024-02-29 14:05:44 --> Helper loaded: text_helper
INFO - 2024-02-29 14:05:44 --> Helper loaded: form_helper
INFO - 2024-02-29 14:05:44 --> Helper loaded: lang_helper
INFO - 2024-02-29 14:05:44 --> Helper loaded: security_helper
INFO - 2024-02-29 14:05:44 --> Helper loaded: cookie_helper
INFO - 2024-02-29 14:05:44 --> Database Driver Class Initialized
INFO - 2024-02-29 14:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 14:05:44 --> Parser Class Initialized
INFO - 2024-02-29 14:05:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 14:05:44 --> Pagination Class Initialized
INFO - 2024-02-29 14:05:44 --> Form Validation Class Initialized
INFO - 2024-02-29 14:05:44 --> Controller Class Initialized
DEBUG - 2024-02-29 14:05:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 14:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 14:05:44 --> Model Class Initialized
DEBUG - 2024-02-29 14:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 14:05:44 --> Model Class Initialized
DEBUG - 2024-02-29 14:05:44 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-29 14:05:44 --> Model Class Initialized
INFO - 2024-02-29 14:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-29 14:05:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 14:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 14:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 14:05:44 --> Model Class Initialized
INFO - 2024-02-29 14:05:44 --> Model Class Initialized
INFO - 2024-02-29 14:05:44 --> Model Class Initialized
INFO - 2024-02-29 14:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 14:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 14:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 14:05:44 --> Final output sent to browser
DEBUG - 2024-02-29 14:05:44 --> Total execution time: 0.2251
ERROR - 2024-02-29 14:05:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 14:05:45 --> Config Class Initialized
INFO - 2024-02-29 14:05:45 --> Hooks Class Initialized
DEBUG - 2024-02-29 14:05:45 --> UTF-8 Support Enabled
INFO - 2024-02-29 14:05:45 --> Utf8 Class Initialized
INFO - 2024-02-29 14:05:45 --> URI Class Initialized
INFO - 2024-02-29 14:05:45 --> Router Class Initialized
INFO - 2024-02-29 14:05:45 --> Output Class Initialized
INFO - 2024-02-29 14:05:45 --> Security Class Initialized
DEBUG - 2024-02-29 14:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 14:05:45 --> Input Class Initialized
INFO - 2024-02-29 14:05:45 --> Language Class Initialized
INFO - 2024-02-29 14:05:45 --> Loader Class Initialized
INFO - 2024-02-29 14:05:45 --> Helper loaded: url_helper
INFO - 2024-02-29 14:05:45 --> Helper loaded: file_helper
INFO - 2024-02-29 14:05:45 --> Helper loaded: html_helper
INFO - 2024-02-29 14:05:45 --> Helper loaded: text_helper
INFO - 2024-02-29 14:05:45 --> Helper loaded: form_helper
INFO - 2024-02-29 14:05:45 --> Helper loaded: lang_helper
INFO - 2024-02-29 14:05:45 --> Helper loaded: security_helper
INFO - 2024-02-29 14:05:45 --> Helper loaded: cookie_helper
INFO - 2024-02-29 14:05:45 --> Database Driver Class Initialized
INFO - 2024-02-29 14:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 14:05:45 --> Parser Class Initialized
INFO - 2024-02-29 14:05:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 14:05:45 --> Pagination Class Initialized
INFO - 2024-02-29 14:05:45 --> Form Validation Class Initialized
INFO - 2024-02-29 14:05:45 --> Controller Class Initialized
DEBUG - 2024-02-29 14:05:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 14:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 14:05:45 --> Model Class Initialized
DEBUG - 2024-02-29 14:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 14:05:45 --> Model Class Initialized
INFO - 2024-02-29 14:05:45 --> Final output sent to browser
DEBUG - 2024-02-29 14:05:45 --> Total execution time: 0.0320
ERROR - 2024-02-29 14:05:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 14:05:50 --> Config Class Initialized
INFO - 2024-02-29 14:05:50 --> Hooks Class Initialized
DEBUG - 2024-02-29 14:05:50 --> UTF-8 Support Enabled
INFO - 2024-02-29 14:05:50 --> Utf8 Class Initialized
INFO - 2024-02-29 14:05:50 --> URI Class Initialized
INFO - 2024-02-29 14:05:50 --> Router Class Initialized
INFO - 2024-02-29 14:05:50 --> Output Class Initialized
INFO - 2024-02-29 14:05:50 --> Security Class Initialized
DEBUG - 2024-02-29 14:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 14:05:50 --> Input Class Initialized
INFO - 2024-02-29 14:05:50 --> Language Class Initialized
INFO - 2024-02-29 14:05:50 --> Loader Class Initialized
INFO - 2024-02-29 14:05:50 --> Helper loaded: url_helper
INFO - 2024-02-29 14:05:50 --> Helper loaded: file_helper
INFO - 2024-02-29 14:05:50 --> Helper loaded: html_helper
INFO - 2024-02-29 14:05:50 --> Helper loaded: text_helper
INFO - 2024-02-29 14:05:50 --> Helper loaded: form_helper
INFO - 2024-02-29 14:05:50 --> Helper loaded: lang_helper
INFO - 2024-02-29 14:05:50 --> Helper loaded: security_helper
INFO - 2024-02-29 14:05:50 --> Helper loaded: cookie_helper
INFO - 2024-02-29 14:05:50 --> Database Driver Class Initialized
INFO - 2024-02-29 14:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 14:05:50 --> Parser Class Initialized
INFO - 2024-02-29 14:05:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 14:05:50 --> Pagination Class Initialized
INFO - 2024-02-29 14:05:50 --> Form Validation Class Initialized
INFO - 2024-02-29 14:05:50 --> Controller Class Initialized
INFO - 2024-02-29 14:05:50 --> Model Class Initialized
DEBUG - 2024-02-29 14:05:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 14:05:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 14:05:50 --> Model Class Initialized
DEBUG - 2024-02-29 14:05:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 14:05:50 --> Model Class Initialized
INFO - 2024-02-29 14:05:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-29 14:05:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 14:05:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 14:05:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 14:05:50 --> Model Class Initialized
INFO - 2024-02-29 14:05:50 --> Model Class Initialized
INFO - 2024-02-29 14:05:50 --> Model Class Initialized
INFO - 2024-02-29 14:05:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 14:05:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 14:05:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 14:05:50 --> Final output sent to browser
DEBUG - 2024-02-29 14:05:50 --> Total execution time: 0.2503
ERROR - 2024-02-29 14:05:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 14:05:51 --> Config Class Initialized
INFO - 2024-02-29 14:05:51 --> Hooks Class Initialized
DEBUG - 2024-02-29 14:05:51 --> UTF-8 Support Enabled
INFO - 2024-02-29 14:05:51 --> Utf8 Class Initialized
INFO - 2024-02-29 14:05:51 --> URI Class Initialized
INFO - 2024-02-29 14:05:51 --> Router Class Initialized
INFO - 2024-02-29 14:05:51 --> Output Class Initialized
INFO - 2024-02-29 14:05:51 --> Security Class Initialized
DEBUG - 2024-02-29 14:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 14:05:51 --> Input Class Initialized
INFO - 2024-02-29 14:05:51 --> Language Class Initialized
INFO - 2024-02-29 14:05:51 --> Loader Class Initialized
INFO - 2024-02-29 14:05:51 --> Helper loaded: url_helper
INFO - 2024-02-29 14:05:51 --> Helper loaded: file_helper
INFO - 2024-02-29 14:05:51 --> Helper loaded: html_helper
INFO - 2024-02-29 14:05:51 --> Helper loaded: text_helper
INFO - 2024-02-29 14:05:51 --> Helper loaded: form_helper
INFO - 2024-02-29 14:05:51 --> Helper loaded: lang_helper
INFO - 2024-02-29 14:05:51 --> Helper loaded: security_helper
INFO - 2024-02-29 14:05:51 --> Helper loaded: cookie_helper
INFO - 2024-02-29 14:05:51 --> Database Driver Class Initialized
INFO - 2024-02-29 14:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 14:05:51 --> Parser Class Initialized
INFO - 2024-02-29 14:05:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 14:05:51 --> Pagination Class Initialized
INFO - 2024-02-29 14:05:51 --> Form Validation Class Initialized
INFO - 2024-02-29 14:05:51 --> Controller Class Initialized
INFO - 2024-02-29 14:05:51 --> Model Class Initialized
DEBUG - 2024-02-29 14:05:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 14:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 14:05:51 --> Model Class Initialized
DEBUG - 2024-02-29 14:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 14:05:51 --> Model Class Initialized
INFO - 2024-02-29 14:05:51 --> Final output sent to browser
DEBUG - 2024-02-29 14:05:51 --> Total execution time: 0.0802
ERROR - 2024-02-29 14:06:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 14:06:09 --> Config Class Initialized
INFO - 2024-02-29 14:06:09 --> Hooks Class Initialized
DEBUG - 2024-02-29 14:06:09 --> UTF-8 Support Enabled
INFO - 2024-02-29 14:06:09 --> Utf8 Class Initialized
INFO - 2024-02-29 14:06:09 --> URI Class Initialized
INFO - 2024-02-29 14:06:09 --> Router Class Initialized
INFO - 2024-02-29 14:06:09 --> Output Class Initialized
INFO - 2024-02-29 14:06:09 --> Security Class Initialized
DEBUG - 2024-02-29 14:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 14:06:09 --> Input Class Initialized
INFO - 2024-02-29 14:06:09 --> Language Class Initialized
INFO - 2024-02-29 14:06:09 --> Loader Class Initialized
INFO - 2024-02-29 14:06:09 --> Helper loaded: url_helper
INFO - 2024-02-29 14:06:09 --> Helper loaded: file_helper
INFO - 2024-02-29 14:06:09 --> Helper loaded: html_helper
INFO - 2024-02-29 14:06:09 --> Helper loaded: text_helper
INFO - 2024-02-29 14:06:09 --> Helper loaded: form_helper
INFO - 2024-02-29 14:06:09 --> Helper loaded: lang_helper
INFO - 2024-02-29 14:06:09 --> Helper loaded: security_helper
INFO - 2024-02-29 14:06:09 --> Helper loaded: cookie_helper
INFO - 2024-02-29 14:06:09 --> Database Driver Class Initialized
INFO - 2024-02-29 14:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 14:06:09 --> Parser Class Initialized
INFO - 2024-02-29 14:06:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 14:06:09 --> Pagination Class Initialized
INFO - 2024-02-29 14:06:09 --> Form Validation Class Initialized
INFO - 2024-02-29 14:06:09 --> Controller Class Initialized
INFO - 2024-02-29 14:06:09 --> Model Class Initialized
DEBUG - 2024-02-29 14:06:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 14:06:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 14:06:09 --> Model Class Initialized
DEBUG - 2024-02-29 14:06:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 14:06:09 --> Model Class Initialized
INFO - 2024-02-29 14:06:10 --> Final output sent to browser
DEBUG - 2024-02-29 14:06:10 --> Total execution time: 1.5910
ERROR - 2024-02-29 14:06:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 14:06:14 --> Config Class Initialized
INFO - 2024-02-29 14:06:14 --> Hooks Class Initialized
DEBUG - 2024-02-29 14:06:14 --> UTF-8 Support Enabled
INFO - 2024-02-29 14:06:14 --> Utf8 Class Initialized
INFO - 2024-02-29 14:06:14 --> URI Class Initialized
INFO - 2024-02-29 14:06:14 --> Router Class Initialized
INFO - 2024-02-29 14:06:14 --> Output Class Initialized
INFO - 2024-02-29 14:06:14 --> Security Class Initialized
DEBUG - 2024-02-29 14:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 14:06:14 --> Input Class Initialized
INFO - 2024-02-29 14:06:14 --> Language Class Initialized
INFO - 2024-02-29 14:06:14 --> Loader Class Initialized
INFO - 2024-02-29 14:06:14 --> Helper loaded: url_helper
INFO - 2024-02-29 14:06:14 --> Helper loaded: file_helper
INFO - 2024-02-29 14:06:14 --> Helper loaded: html_helper
INFO - 2024-02-29 14:06:14 --> Helper loaded: text_helper
INFO - 2024-02-29 14:06:14 --> Helper loaded: form_helper
INFO - 2024-02-29 14:06:14 --> Helper loaded: lang_helper
INFO - 2024-02-29 14:06:14 --> Helper loaded: security_helper
INFO - 2024-02-29 14:06:14 --> Helper loaded: cookie_helper
INFO - 2024-02-29 14:06:14 --> Database Driver Class Initialized
INFO - 2024-02-29 14:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 14:06:14 --> Parser Class Initialized
INFO - 2024-02-29 14:06:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 14:06:14 --> Pagination Class Initialized
INFO - 2024-02-29 14:06:14 --> Form Validation Class Initialized
INFO - 2024-02-29 14:06:14 --> Controller Class Initialized
INFO - 2024-02-29 14:06:14 --> Model Class Initialized
DEBUG - 2024-02-29 14:06:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-29 14:06:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 14:06:14 --> Model Class Initialized
DEBUG - 2024-02-29 14:06:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 14:06:14 --> Model Class Initialized
DEBUG - 2024-02-29 14:06:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-29 14:06:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-02-29 14:06:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-29 14:06:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-29 14:06:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-29 14:06:14 --> Model Class Initialized
INFO - 2024-02-29 14:06:14 --> Model Class Initialized
INFO - 2024-02-29 14:06:14 --> Model Class Initialized
INFO - 2024-02-29 14:06:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-29 14:06:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-29 14:06:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-29 14:06:14 --> Final output sent to browser
DEBUG - 2024-02-29 14:06:14 --> Total execution time: 0.2551
ERROR - 2024-02-29 14:59:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-29 14:59:52 --> Config Class Initialized
INFO - 2024-02-29 14:59:52 --> Hooks Class Initialized
DEBUG - 2024-02-29 14:59:52 --> UTF-8 Support Enabled
INFO - 2024-02-29 14:59:52 --> Utf8 Class Initialized
INFO - 2024-02-29 14:59:52 --> URI Class Initialized
DEBUG - 2024-02-29 14:59:52 --> No URI present. Default controller set.
INFO - 2024-02-29 14:59:52 --> Router Class Initialized
INFO - 2024-02-29 14:59:52 --> Output Class Initialized
INFO - 2024-02-29 14:59:52 --> Security Class Initialized
DEBUG - 2024-02-29 14:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-29 14:59:52 --> Input Class Initialized
INFO - 2024-02-29 14:59:52 --> Language Class Initialized
INFO - 2024-02-29 14:59:52 --> Loader Class Initialized
INFO - 2024-02-29 14:59:52 --> Helper loaded: url_helper
INFO - 2024-02-29 14:59:52 --> Helper loaded: file_helper
INFO - 2024-02-29 14:59:52 --> Helper loaded: html_helper
INFO - 2024-02-29 14:59:52 --> Helper loaded: text_helper
INFO - 2024-02-29 14:59:52 --> Helper loaded: form_helper
INFO - 2024-02-29 14:59:52 --> Helper loaded: lang_helper
INFO - 2024-02-29 14:59:52 --> Helper loaded: security_helper
INFO - 2024-02-29 14:59:52 --> Helper loaded: cookie_helper
INFO - 2024-02-29 14:59:52 --> Database Driver Class Initialized
INFO - 2024-02-29 14:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-29 14:59:52 --> Parser Class Initialized
INFO - 2024-02-29 14:59:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-29 14:59:52 --> Pagination Class Initialized
INFO - 2024-02-29 14:59:52 --> Form Validation Class Initialized
INFO - 2024-02-29 14:59:52 --> Controller Class Initialized
INFO - 2024-02-29 14:59:52 --> Model Class Initialized
DEBUG - 2024-02-29 14:59:52 --> Session class already loaded. Second attempt ignored.
