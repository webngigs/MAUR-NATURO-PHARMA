<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-25 01:44:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-25 01:44:17 --> Config Class Initialized
INFO - 2024-01-25 01:44:17 --> Hooks Class Initialized
DEBUG - 2024-01-25 01:44:17 --> UTF-8 Support Enabled
INFO - 2024-01-25 01:44:17 --> Utf8 Class Initialized
INFO - 2024-01-25 01:44:17 --> URI Class Initialized
INFO - 2024-01-25 01:44:17 --> Router Class Initialized
INFO - 2024-01-25 01:44:17 --> Output Class Initialized
INFO - 2024-01-25 01:44:17 --> Security Class Initialized
DEBUG - 2024-01-25 01:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-25 01:44:17 --> Input Class Initialized
INFO - 2024-01-25 01:44:17 --> Language Class Initialized
ERROR - 2024-01-25 01:44:17 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-01-25 06:25:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-25 06:25:09 --> Config Class Initialized
INFO - 2024-01-25 06:25:09 --> Hooks Class Initialized
DEBUG - 2024-01-25 06:25:09 --> UTF-8 Support Enabled
INFO - 2024-01-25 06:25:09 --> Utf8 Class Initialized
INFO - 2024-01-25 06:25:09 --> URI Class Initialized
DEBUG - 2024-01-25 06:25:09 --> No URI present. Default controller set.
INFO - 2024-01-25 06:25:09 --> Router Class Initialized
INFO - 2024-01-25 06:25:09 --> Output Class Initialized
INFO - 2024-01-25 06:25:09 --> Security Class Initialized
DEBUG - 2024-01-25 06:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-25 06:25:09 --> Input Class Initialized
INFO - 2024-01-25 06:25:09 --> Language Class Initialized
INFO - 2024-01-25 06:25:09 --> Loader Class Initialized
INFO - 2024-01-25 06:25:09 --> Helper loaded: url_helper
INFO - 2024-01-25 06:25:09 --> Helper loaded: file_helper
INFO - 2024-01-25 06:25:09 --> Helper loaded: html_helper
INFO - 2024-01-25 06:25:09 --> Helper loaded: text_helper
INFO - 2024-01-25 06:25:09 --> Helper loaded: form_helper
INFO - 2024-01-25 06:25:09 --> Helper loaded: lang_helper
INFO - 2024-01-25 06:25:09 --> Helper loaded: security_helper
INFO - 2024-01-25 06:25:09 --> Helper loaded: cookie_helper
INFO - 2024-01-25 06:25:09 --> Database Driver Class Initialized
INFO - 2024-01-25 06:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-25 06:25:09 --> Parser Class Initialized
INFO - 2024-01-25 06:25:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-25 06:25:09 --> Pagination Class Initialized
INFO - 2024-01-25 06:25:09 --> Form Validation Class Initialized
INFO - 2024-01-25 06:25:09 --> Controller Class Initialized
INFO - 2024-01-25 06:25:09 --> Model Class Initialized
DEBUG - 2024-01-25 06:25:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-25 06:25:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-25 06:25:10 --> Config Class Initialized
INFO - 2024-01-25 06:25:10 --> Hooks Class Initialized
DEBUG - 2024-01-25 06:25:10 --> UTF-8 Support Enabled
INFO - 2024-01-25 06:25:10 --> Utf8 Class Initialized
INFO - 2024-01-25 06:25:10 --> URI Class Initialized
INFO - 2024-01-25 06:25:10 --> Router Class Initialized
INFO - 2024-01-25 06:25:10 --> Output Class Initialized
INFO - 2024-01-25 06:25:10 --> Security Class Initialized
DEBUG - 2024-01-25 06:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-25 06:25:10 --> Input Class Initialized
INFO - 2024-01-25 06:25:10 --> Language Class Initialized
INFO - 2024-01-25 06:25:10 --> Loader Class Initialized
INFO - 2024-01-25 06:25:10 --> Helper loaded: url_helper
INFO - 2024-01-25 06:25:10 --> Helper loaded: file_helper
INFO - 2024-01-25 06:25:10 --> Helper loaded: html_helper
INFO - 2024-01-25 06:25:10 --> Helper loaded: text_helper
INFO - 2024-01-25 06:25:10 --> Helper loaded: form_helper
INFO - 2024-01-25 06:25:10 --> Helper loaded: lang_helper
INFO - 2024-01-25 06:25:10 --> Helper loaded: security_helper
INFO - 2024-01-25 06:25:10 --> Helper loaded: cookie_helper
INFO - 2024-01-25 06:25:10 --> Database Driver Class Initialized
INFO - 2024-01-25 06:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-25 06:25:10 --> Parser Class Initialized
INFO - 2024-01-25 06:25:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-25 06:25:10 --> Pagination Class Initialized
INFO - 2024-01-25 06:25:10 --> Form Validation Class Initialized
INFO - 2024-01-25 06:25:10 --> Controller Class Initialized
INFO - 2024-01-25 06:25:10 --> Model Class Initialized
DEBUG - 2024-01-25 06:25:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-25 06:25:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-25 06:25:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-25 06:25:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-25 06:25:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-25 06:25:10 --> Model Class Initialized
INFO - 2024-01-25 06:25:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-25 06:25:10 --> Final output sent to browser
DEBUG - 2024-01-25 06:25:10 --> Total execution time: 0.0389
ERROR - 2024-01-25 06:47:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-25 06:47:04 --> Config Class Initialized
INFO - 2024-01-25 06:47:04 --> Hooks Class Initialized
DEBUG - 2024-01-25 06:47:04 --> UTF-8 Support Enabled
INFO - 2024-01-25 06:47:04 --> Utf8 Class Initialized
INFO - 2024-01-25 06:47:04 --> URI Class Initialized
DEBUG - 2024-01-25 06:47:04 --> No URI present. Default controller set.
INFO - 2024-01-25 06:47:04 --> Router Class Initialized
INFO - 2024-01-25 06:47:04 --> Output Class Initialized
INFO - 2024-01-25 06:47:04 --> Security Class Initialized
DEBUG - 2024-01-25 06:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-25 06:47:04 --> Input Class Initialized
INFO - 2024-01-25 06:47:04 --> Language Class Initialized
INFO - 2024-01-25 06:47:04 --> Loader Class Initialized
INFO - 2024-01-25 06:47:04 --> Helper loaded: url_helper
INFO - 2024-01-25 06:47:04 --> Helper loaded: file_helper
INFO - 2024-01-25 06:47:04 --> Helper loaded: html_helper
INFO - 2024-01-25 06:47:04 --> Helper loaded: text_helper
INFO - 2024-01-25 06:47:04 --> Helper loaded: form_helper
INFO - 2024-01-25 06:47:04 --> Helper loaded: lang_helper
INFO - 2024-01-25 06:47:04 --> Helper loaded: security_helper
INFO - 2024-01-25 06:47:04 --> Helper loaded: cookie_helper
INFO - 2024-01-25 06:47:04 --> Database Driver Class Initialized
INFO - 2024-01-25 06:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-25 06:47:04 --> Parser Class Initialized
INFO - 2024-01-25 06:47:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-25 06:47:04 --> Pagination Class Initialized
INFO - 2024-01-25 06:47:04 --> Form Validation Class Initialized
INFO - 2024-01-25 06:47:04 --> Controller Class Initialized
INFO - 2024-01-25 06:47:04 --> Model Class Initialized
DEBUG - 2024-01-25 06:47:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-25 06:47:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-25 06:47:04 --> Config Class Initialized
INFO - 2024-01-25 06:47:04 --> Hooks Class Initialized
DEBUG - 2024-01-25 06:47:04 --> UTF-8 Support Enabled
INFO - 2024-01-25 06:47:04 --> Utf8 Class Initialized
INFO - 2024-01-25 06:47:04 --> URI Class Initialized
INFO - 2024-01-25 06:47:04 --> Router Class Initialized
INFO - 2024-01-25 06:47:04 --> Output Class Initialized
INFO - 2024-01-25 06:47:04 --> Security Class Initialized
DEBUG - 2024-01-25 06:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-25 06:47:04 --> Input Class Initialized
INFO - 2024-01-25 06:47:04 --> Language Class Initialized
INFO - 2024-01-25 06:47:04 --> Loader Class Initialized
INFO - 2024-01-25 06:47:04 --> Helper loaded: url_helper
INFO - 2024-01-25 06:47:04 --> Helper loaded: file_helper
INFO - 2024-01-25 06:47:04 --> Helper loaded: html_helper
INFO - 2024-01-25 06:47:04 --> Helper loaded: text_helper
INFO - 2024-01-25 06:47:04 --> Helper loaded: form_helper
INFO - 2024-01-25 06:47:04 --> Helper loaded: lang_helper
INFO - 2024-01-25 06:47:04 --> Helper loaded: security_helper
INFO - 2024-01-25 06:47:04 --> Helper loaded: cookie_helper
INFO - 2024-01-25 06:47:04 --> Database Driver Class Initialized
INFO - 2024-01-25 06:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-25 06:47:04 --> Parser Class Initialized
INFO - 2024-01-25 06:47:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-25 06:47:04 --> Pagination Class Initialized
INFO - 2024-01-25 06:47:04 --> Form Validation Class Initialized
INFO - 2024-01-25 06:47:04 --> Controller Class Initialized
INFO - 2024-01-25 06:47:04 --> Model Class Initialized
DEBUG - 2024-01-25 06:47:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-25 06:47:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-25 06:47:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-25 06:47:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-25 06:47:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-25 06:47:04 --> Model Class Initialized
INFO - 2024-01-25 06:47:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-25 06:47:04 --> Final output sent to browser
DEBUG - 2024-01-25 06:47:04 --> Total execution time: 0.0410
ERROR - 2024-01-25 12:13:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-25 12:13:34 --> Config Class Initialized
INFO - 2024-01-25 12:13:34 --> Hooks Class Initialized
DEBUG - 2024-01-25 12:13:34 --> UTF-8 Support Enabled
INFO - 2024-01-25 12:13:34 --> Utf8 Class Initialized
INFO - 2024-01-25 12:13:34 --> URI Class Initialized
INFO - 2024-01-25 12:13:34 --> Router Class Initialized
INFO - 2024-01-25 12:13:34 --> Output Class Initialized
INFO - 2024-01-25 12:13:34 --> Security Class Initialized
DEBUG - 2024-01-25 12:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-25 12:13:34 --> Input Class Initialized
INFO - 2024-01-25 12:13:34 --> Language Class Initialized
ERROR - 2024-01-25 12:13:34 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2024-01-25 12:13:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-25 12:13:35 --> Config Class Initialized
INFO - 2024-01-25 12:13:35 --> Hooks Class Initialized
DEBUG - 2024-01-25 12:13:35 --> UTF-8 Support Enabled
INFO - 2024-01-25 12:13:35 --> Utf8 Class Initialized
INFO - 2024-01-25 12:13:35 --> URI Class Initialized
DEBUG - 2024-01-25 12:13:35 --> No URI present. Default controller set.
INFO - 2024-01-25 12:13:35 --> Router Class Initialized
INFO - 2024-01-25 12:13:35 --> Output Class Initialized
INFO - 2024-01-25 12:13:35 --> Security Class Initialized
DEBUG - 2024-01-25 12:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-25 12:13:35 --> Input Class Initialized
INFO - 2024-01-25 12:13:35 --> Language Class Initialized
INFO - 2024-01-25 12:13:35 --> Loader Class Initialized
INFO - 2024-01-25 12:13:35 --> Helper loaded: url_helper
INFO - 2024-01-25 12:13:35 --> Helper loaded: file_helper
INFO - 2024-01-25 12:13:35 --> Helper loaded: html_helper
INFO - 2024-01-25 12:13:35 --> Helper loaded: text_helper
INFO - 2024-01-25 12:13:35 --> Helper loaded: form_helper
INFO - 2024-01-25 12:13:35 --> Helper loaded: lang_helper
INFO - 2024-01-25 12:13:35 --> Helper loaded: security_helper
INFO - 2024-01-25 12:13:35 --> Helper loaded: cookie_helper
INFO - 2024-01-25 12:13:35 --> Database Driver Class Initialized
INFO - 2024-01-25 12:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-25 12:13:35 --> Parser Class Initialized
INFO - 2024-01-25 12:13:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-25 12:13:35 --> Pagination Class Initialized
INFO - 2024-01-25 12:13:35 --> Form Validation Class Initialized
INFO - 2024-01-25 12:13:35 --> Controller Class Initialized
INFO - 2024-01-25 12:13:35 --> Model Class Initialized
DEBUG - 2024-01-25 12:13:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-25 12:13:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-25 12:13:37 --> Config Class Initialized
INFO - 2024-01-25 12:13:37 --> Hooks Class Initialized
DEBUG - 2024-01-25 12:13:37 --> UTF-8 Support Enabled
INFO - 2024-01-25 12:13:37 --> Utf8 Class Initialized
INFO - 2024-01-25 12:13:37 --> URI Class Initialized
INFO - 2024-01-25 12:13:37 --> Router Class Initialized
INFO - 2024-01-25 12:13:37 --> Output Class Initialized
INFO - 2024-01-25 12:13:37 --> Security Class Initialized
DEBUG - 2024-01-25 12:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-25 12:13:37 --> Input Class Initialized
INFO - 2024-01-25 12:13:37 --> Language Class Initialized
ERROR - 2024-01-25 12:13:37 --> 404 Page Not Found: Wp-cronphp/index
ERROR - 2024-01-25 12:38:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-25 12:38:58 --> Config Class Initialized
INFO - 2024-01-25 12:38:58 --> Hooks Class Initialized
DEBUG - 2024-01-25 12:38:58 --> UTF-8 Support Enabled
INFO - 2024-01-25 12:38:58 --> Utf8 Class Initialized
INFO - 2024-01-25 12:38:58 --> URI Class Initialized
DEBUG - 2024-01-25 12:38:58 --> No URI present. Default controller set.
INFO - 2024-01-25 12:38:58 --> Router Class Initialized
INFO - 2024-01-25 12:38:58 --> Output Class Initialized
INFO - 2024-01-25 12:38:58 --> Security Class Initialized
DEBUG - 2024-01-25 12:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-25 12:38:58 --> Input Class Initialized
INFO - 2024-01-25 12:38:58 --> Language Class Initialized
INFO - 2024-01-25 12:38:58 --> Loader Class Initialized
INFO - 2024-01-25 12:38:58 --> Helper loaded: url_helper
INFO - 2024-01-25 12:38:58 --> Helper loaded: file_helper
INFO - 2024-01-25 12:38:58 --> Helper loaded: html_helper
INFO - 2024-01-25 12:38:58 --> Helper loaded: text_helper
INFO - 2024-01-25 12:38:58 --> Helper loaded: form_helper
INFO - 2024-01-25 12:38:58 --> Helper loaded: lang_helper
INFO - 2024-01-25 12:38:58 --> Helper loaded: security_helper
INFO - 2024-01-25 12:38:58 --> Helper loaded: cookie_helper
INFO - 2024-01-25 12:38:58 --> Database Driver Class Initialized
INFO - 2024-01-25 12:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-25 12:38:58 --> Parser Class Initialized
INFO - 2024-01-25 12:38:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-25 12:38:58 --> Pagination Class Initialized
INFO - 2024-01-25 12:38:58 --> Form Validation Class Initialized
INFO - 2024-01-25 12:38:58 --> Controller Class Initialized
INFO - 2024-01-25 12:38:58 --> Model Class Initialized
DEBUG - 2024-01-25 12:38:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-25 12:38:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-25 12:38:58 --> Config Class Initialized
INFO - 2024-01-25 12:38:58 --> Hooks Class Initialized
DEBUG - 2024-01-25 12:38:58 --> UTF-8 Support Enabled
INFO - 2024-01-25 12:38:58 --> Utf8 Class Initialized
INFO - 2024-01-25 12:38:58 --> URI Class Initialized
INFO - 2024-01-25 12:38:58 --> Router Class Initialized
INFO - 2024-01-25 12:38:58 --> Output Class Initialized
INFO - 2024-01-25 12:38:58 --> Security Class Initialized
DEBUG - 2024-01-25 12:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-25 12:38:58 --> Input Class Initialized
INFO - 2024-01-25 12:38:58 --> Language Class Initialized
INFO - 2024-01-25 12:38:58 --> Loader Class Initialized
INFO - 2024-01-25 12:38:58 --> Helper loaded: url_helper
INFO - 2024-01-25 12:38:58 --> Helper loaded: file_helper
INFO - 2024-01-25 12:38:58 --> Helper loaded: html_helper
INFO - 2024-01-25 12:38:58 --> Helper loaded: text_helper
INFO - 2024-01-25 12:38:58 --> Helper loaded: form_helper
INFO - 2024-01-25 12:38:58 --> Helper loaded: lang_helper
INFO - 2024-01-25 12:38:58 --> Helper loaded: security_helper
INFO - 2024-01-25 12:38:58 --> Helper loaded: cookie_helper
INFO - 2024-01-25 12:38:58 --> Database Driver Class Initialized
INFO - 2024-01-25 12:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-25 12:38:58 --> Parser Class Initialized
INFO - 2024-01-25 12:38:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-25 12:38:58 --> Pagination Class Initialized
INFO - 2024-01-25 12:38:58 --> Form Validation Class Initialized
INFO - 2024-01-25 12:38:58 --> Controller Class Initialized
INFO - 2024-01-25 12:38:58 --> Model Class Initialized
DEBUG - 2024-01-25 12:38:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-25 12:38:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-25 12:38:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-25 12:38:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-25 12:38:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-25 12:38:58 --> Model Class Initialized
INFO - 2024-01-25 12:38:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-25 12:38:58 --> Final output sent to browser
DEBUG - 2024-01-25 12:38:58 --> Total execution time: 0.0344
ERROR - 2024-01-25 18:31:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-25 18:31:29 --> Config Class Initialized
INFO - 2024-01-25 18:31:29 --> Hooks Class Initialized
DEBUG - 2024-01-25 18:31:29 --> UTF-8 Support Enabled
INFO - 2024-01-25 18:31:29 --> Utf8 Class Initialized
INFO - 2024-01-25 18:31:29 --> URI Class Initialized
INFO - 2024-01-25 18:31:29 --> Router Class Initialized
INFO - 2024-01-25 18:31:29 --> Output Class Initialized
INFO - 2024-01-25 18:31:29 --> Security Class Initialized
DEBUG - 2024-01-25 18:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-25 18:31:29 --> Input Class Initialized
INFO - 2024-01-25 18:31:29 --> Language Class Initialized
ERROR - 2024-01-25 18:31:29 --> 404 Page Not Found: Well-known/assetlinks.json
