<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-15 12:10:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-15 12:10:02 --> Config Class Initialized
INFO - 2023-06-15 12:10:02 --> Hooks Class Initialized
DEBUG - 2023-06-15 12:10:02 --> UTF-8 Support Enabled
INFO - 2023-06-15 12:10:02 --> Utf8 Class Initialized
INFO - 2023-06-15 12:10:02 --> URI Class Initialized
DEBUG - 2023-06-15 12:10:02 --> No URI present. Default controller set.
INFO - 2023-06-15 12:10:02 --> Router Class Initialized
INFO - 2023-06-15 12:10:02 --> Output Class Initialized
INFO - 2023-06-15 12:10:02 --> Security Class Initialized
DEBUG - 2023-06-15 12:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-15 12:10:02 --> Input Class Initialized
INFO - 2023-06-15 12:10:02 --> Language Class Initialized
INFO - 2023-06-15 12:10:02 --> Loader Class Initialized
INFO - 2023-06-15 12:10:02 --> Helper loaded: url_helper
INFO - 2023-06-15 12:10:02 --> Helper loaded: file_helper
INFO - 2023-06-15 12:10:02 --> Helper loaded: html_helper
INFO - 2023-06-15 12:10:02 --> Helper loaded: text_helper
INFO - 2023-06-15 12:10:02 --> Helper loaded: form_helper
INFO - 2023-06-15 12:10:02 --> Helper loaded: lang_helper
INFO - 2023-06-15 12:10:02 --> Helper loaded: security_helper
INFO - 2023-06-15 12:10:02 --> Helper loaded: cookie_helper
INFO - 2023-06-15 12:10:02 --> Database Driver Class Initialized
INFO - 2023-06-15 12:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-15 12:10:02 --> Parser Class Initialized
INFO - 2023-06-15 12:10:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-15 12:10:02 --> Pagination Class Initialized
INFO - 2023-06-15 12:10:02 --> Form Validation Class Initialized
INFO - 2023-06-15 12:10:02 --> Controller Class Initialized
INFO - 2023-06-15 12:10:02 --> Model Class Initialized
DEBUG - 2023-06-15 12:10:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-15 12:10:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-15 12:10:03 --> Config Class Initialized
INFO - 2023-06-15 12:10:03 --> Hooks Class Initialized
DEBUG - 2023-06-15 12:10:03 --> UTF-8 Support Enabled
INFO - 2023-06-15 12:10:03 --> Utf8 Class Initialized
INFO - 2023-06-15 12:10:03 --> URI Class Initialized
INFO - 2023-06-15 12:10:03 --> Router Class Initialized
INFO - 2023-06-15 12:10:03 --> Output Class Initialized
INFO - 2023-06-15 12:10:03 --> Security Class Initialized
DEBUG - 2023-06-15 12:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-15 12:10:03 --> Input Class Initialized
INFO - 2023-06-15 12:10:03 --> Language Class Initialized
INFO - 2023-06-15 12:10:03 --> Loader Class Initialized
INFO - 2023-06-15 12:10:03 --> Helper loaded: url_helper
INFO - 2023-06-15 12:10:03 --> Helper loaded: file_helper
INFO - 2023-06-15 12:10:03 --> Helper loaded: html_helper
INFO - 2023-06-15 12:10:03 --> Helper loaded: text_helper
INFO - 2023-06-15 12:10:03 --> Helper loaded: form_helper
INFO - 2023-06-15 12:10:03 --> Helper loaded: lang_helper
INFO - 2023-06-15 12:10:03 --> Helper loaded: security_helper
INFO - 2023-06-15 12:10:03 --> Helper loaded: cookie_helper
INFO - 2023-06-15 12:10:03 --> Database Driver Class Initialized
INFO - 2023-06-15 12:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-15 12:10:03 --> Parser Class Initialized
INFO - 2023-06-15 12:10:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-15 12:10:03 --> Pagination Class Initialized
INFO - 2023-06-15 12:10:03 --> Form Validation Class Initialized
INFO - 2023-06-15 12:10:03 --> Controller Class Initialized
INFO - 2023-06-15 12:10:03 --> Model Class Initialized
DEBUG - 2023-06-15 12:10:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-15 12:10:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-15 12:10:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-15 12:10:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-15 12:10:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-15 12:10:03 --> Model Class Initialized
INFO - 2023-06-15 12:10:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-15 12:10:03 --> Final output sent to browser
DEBUG - 2023-06-15 12:10:03 --> Total execution time: 0.0314
ERROR - 2023-06-15 12:10:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-15 12:10:33 --> Config Class Initialized
INFO - 2023-06-15 12:10:33 --> Hooks Class Initialized
DEBUG - 2023-06-15 12:10:33 --> UTF-8 Support Enabled
INFO - 2023-06-15 12:10:33 --> Utf8 Class Initialized
INFO - 2023-06-15 12:10:33 --> URI Class Initialized
INFO - 2023-06-15 12:10:33 --> Router Class Initialized
INFO - 2023-06-15 12:10:33 --> Output Class Initialized
INFO - 2023-06-15 12:10:33 --> Security Class Initialized
DEBUG - 2023-06-15 12:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-15 12:10:33 --> Input Class Initialized
INFO - 2023-06-15 12:10:33 --> Language Class Initialized
INFO - 2023-06-15 12:10:33 --> Loader Class Initialized
INFO - 2023-06-15 12:10:33 --> Helper loaded: url_helper
INFO - 2023-06-15 12:10:33 --> Helper loaded: file_helper
INFO - 2023-06-15 12:10:33 --> Helper loaded: html_helper
INFO - 2023-06-15 12:10:33 --> Helper loaded: text_helper
INFO - 2023-06-15 12:10:33 --> Helper loaded: form_helper
INFO - 2023-06-15 12:10:33 --> Helper loaded: lang_helper
INFO - 2023-06-15 12:10:33 --> Helper loaded: security_helper
INFO - 2023-06-15 12:10:33 --> Helper loaded: cookie_helper
INFO - 2023-06-15 12:10:33 --> Database Driver Class Initialized
INFO - 2023-06-15 12:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-15 12:10:33 --> Parser Class Initialized
INFO - 2023-06-15 12:10:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-15 12:10:33 --> Pagination Class Initialized
INFO - 2023-06-15 12:10:33 --> Form Validation Class Initialized
INFO - 2023-06-15 12:10:33 --> Controller Class Initialized
INFO - 2023-06-15 12:10:33 --> Model Class Initialized
DEBUG - 2023-06-15 12:10:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-15 12:10:33 --> Model Class Initialized
INFO - 2023-06-15 12:10:33 --> Final output sent to browser
DEBUG - 2023-06-15 12:10:33 --> Total execution time: 0.0210
ERROR - 2023-06-15 12:10:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-15 12:10:33 --> Config Class Initialized
INFO - 2023-06-15 12:10:33 --> Hooks Class Initialized
DEBUG - 2023-06-15 12:10:33 --> UTF-8 Support Enabled
INFO - 2023-06-15 12:10:33 --> Utf8 Class Initialized
INFO - 2023-06-15 12:10:33 --> URI Class Initialized
DEBUG - 2023-06-15 12:10:33 --> No URI present. Default controller set.
INFO - 2023-06-15 12:10:33 --> Router Class Initialized
INFO - 2023-06-15 12:10:33 --> Output Class Initialized
INFO - 2023-06-15 12:10:33 --> Security Class Initialized
DEBUG - 2023-06-15 12:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-15 12:10:33 --> Input Class Initialized
INFO - 2023-06-15 12:10:33 --> Language Class Initialized
INFO - 2023-06-15 12:10:33 --> Loader Class Initialized
INFO - 2023-06-15 12:10:33 --> Helper loaded: url_helper
INFO - 2023-06-15 12:10:33 --> Helper loaded: file_helper
INFO - 2023-06-15 12:10:33 --> Helper loaded: html_helper
INFO - 2023-06-15 12:10:33 --> Helper loaded: text_helper
INFO - 2023-06-15 12:10:33 --> Helper loaded: form_helper
INFO - 2023-06-15 12:10:33 --> Helper loaded: lang_helper
INFO - 2023-06-15 12:10:33 --> Helper loaded: security_helper
INFO - 2023-06-15 12:10:33 --> Helper loaded: cookie_helper
INFO - 2023-06-15 12:10:33 --> Database Driver Class Initialized
INFO - 2023-06-15 12:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-15 12:10:33 --> Parser Class Initialized
INFO - 2023-06-15 12:10:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-15 12:10:33 --> Pagination Class Initialized
INFO - 2023-06-15 12:10:33 --> Form Validation Class Initialized
INFO - 2023-06-15 12:10:33 --> Controller Class Initialized
INFO - 2023-06-15 12:10:33 --> Model Class Initialized
DEBUG - 2023-06-15 12:10:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-15 12:10:33 --> Model Class Initialized
DEBUG - 2023-06-15 12:10:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-15 12:10:33 --> Model Class Initialized
INFO - 2023-06-15 12:10:33 --> Model Class Initialized
INFO - 2023-06-15 12:10:33 --> Model Class Initialized
INFO - 2023-06-15 12:10:33 --> Model Class Initialized
DEBUG - 2023-06-15 12:10:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-15 12:10:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-15 12:10:33 --> Model Class Initialized
INFO - 2023-06-15 12:10:33 --> Model Class Initialized
INFO - 2023-06-15 12:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-15 12:10:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-15 12:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-15 12:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-15 12:10:33 --> Model Class Initialized
INFO - 2023-06-15 12:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-15 12:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-15 12:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-15 12:10:33 --> Final output sent to browser
DEBUG - 2023-06-15 12:10:33 --> Total execution time: 0.0745
ERROR - 2023-06-15 12:10:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-15 12:10:56 --> Config Class Initialized
INFO - 2023-06-15 12:10:56 --> Hooks Class Initialized
DEBUG - 2023-06-15 12:10:56 --> UTF-8 Support Enabled
INFO - 2023-06-15 12:10:56 --> Utf8 Class Initialized
INFO - 2023-06-15 12:10:56 --> URI Class Initialized
INFO - 2023-06-15 12:10:56 --> Router Class Initialized
INFO - 2023-06-15 12:10:56 --> Output Class Initialized
INFO - 2023-06-15 12:10:56 --> Security Class Initialized
DEBUG - 2023-06-15 12:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-15 12:10:56 --> Input Class Initialized
INFO - 2023-06-15 12:10:56 --> Language Class Initialized
INFO - 2023-06-15 12:10:56 --> Loader Class Initialized
INFO - 2023-06-15 12:10:56 --> Helper loaded: url_helper
INFO - 2023-06-15 12:10:56 --> Helper loaded: file_helper
INFO - 2023-06-15 12:10:56 --> Helper loaded: html_helper
INFO - 2023-06-15 12:10:56 --> Helper loaded: text_helper
INFO - 2023-06-15 12:10:56 --> Helper loaded: form_helper
INFO - 2023-06-15 12:10:56 --> Helper loaded: lang_helper
INFO - 2023-06-15 12:10:56 --> Helper loaded: security_helper
INFO - 2023-06-15 12:10:56 --> Helper loaded: cookie_helper
INFO - 2023-06-15 12:10:56 --> Database Driver Class Initialized
INFO - 2023-06-15 12:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-15 12:10:56 --> Parser Class Initialized
INFO - 2023-06-15 12:10:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-15 12:10:56 --> Pagination Class Initialized
INFO - 2023-06-15 12:10:56 --> Form Validation Class Initialized
INFO - 2023-06-15 12:10:56 --> Controller Class Initialized
INFO - 2023-06-15 12:10:56 --> Model Class Initialized
DEBUG - 2023-06-15 12:10:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-15 12:10:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-15 12:10:56 --> Model Class Initialized
DEBUG - 2023-06-15 12:10:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-15 12:10:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-06-15 12:10:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-15 12:10:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-15 12:10:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-15 12:10:56 --> Model Class Initialized
INFO - 2023-06-15 12:10:56 --> Model Class Initialized
INFO - 2023-06-15 12:10:56 --> Model Class Initialized
INFO - 2023-06-15 12:10:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-15 12:10:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-15 12:10:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-15 12:10:56 --> Final output sent to browser
DEBUG - 2023-06-15 12:10:56 --> Total execution time: 0.0798
ERROR - 2023-06-15 12:12:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-15 12:12:38 --> Config Class Initialized
INFO - 2023-06-15 12:12:38 --> Hooks Class Initialized
DEBUG - 2023-06-15 12:12:38 --> UTF-8 Support Enabled
INFO - 2023-06-15 12:12:38 --> Utf8 Class Initialized
INFO - 2023-06-15 12:12:38 --> URI Class Initialized
DEBUG - 2023-06-15 12:12:38 --> No URI present. Default controller set.
INFO - 2023-06-15 12:12:38 --> Router Class Initialized
INFO - 2023-06-15 12:12:38 --> Output Class Initialized
INFO - 2023-06-15 12:12:38 --> Security Class Initialized
DEBUG - 2023-06-15 12:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-15 12:12:38 --> Input Class Initialized
INFO - 2023-06-15 12:12:38 --> Language Class Initialized
INFO - 2023-06-15 12:12:38 --> Loader Class Initialized
INFO - 2023-06-15 12:12:38 --> Helper loaded: url_helper
INFO - 2023-06-15 12:12:38 --> Helper loaded: file_helper
INFO - 2023-06-15 12:12:38 --> Helper loaded: html_helper
INFO - 2023-06-15 12:12:38 --> Helper loaded: text_helper
INFO - 2023-06-15 12:12:38 --> Helper loaded: form_helper
INFO - 2023-06-15 12:12:38 --> Helper loaded: lang_helper
INFO - 2023-06-15 12:12:38 --> Helper loaded: security_helper
INFO - 2023-06-15 12:12:38 --> Helper loaded: cookie_helper
INFO - 2023-06-15 12:12:38 --> Database Driver Class Initialized
INFO - 2023-06-15 12:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-15 12:12:38 --> Parser Class Initialized
INFO - 2023-06-15 12:12:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-15 12:12:38 --> Pagination Class Initialized
INFO - 2023-06-15 12:12:38 --> Form Validation Class Initialized
INFO - 2023-06-15 12:12:38 --> Controller Class Initialized
INFO - 2023-06-15 12:12:38 --> Model Class Initialized
DEBUG - 2023-06-15 12:12:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-15 15:26:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-15 15:26:54 --> Config Class Initialized
INFO - 2023-06-15 15:26:54 --> Hooks Class Initialized
DEBUG - 2023-06-15 15:26:54 --> UTF-8 Support Enabled
INFO - 2023-06-15 15:26:54 --> Utf8 Class Initialized
INFO - 2023-06-15 15:26:54 --> URI Class Initialized
DEBUG - 2023-06-15 15:26:54 --> No URI present. Default controller set.
INFO - 2023-06-15 15:26:54 --> Router Class Initialized
INFO - 2023-06-15 15:26:54 --> Output Class Initialized
INFO - 2023-06-15 15:26:54 --> Security Class Initialized
DEBUG - 2023-06-15 15:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-15 15:26:54 --> Input Class Initialized
INFO - 2023-06-15 15:26:54 --> Language Class Initialized
INFO - 2023-06-15 15:26:54 --> Loader Class Initialized
INFO - 2023-06-15 15:26:54 --> Helper loaded: url_helper
INFO - 2023-06-15 15:26:54 --> Helper loaded: file_helper
INFO - 2023-06-15 15:26:54 --> Helper loaded: html_helper
INFO - 2023-06-15 15:26:54 --> Helper loaded: text_helper
INFO - 2023-06-15 15:26:54 --> Helper loaded: form_helper
INFO - 2023-06-15 15:26:54 --> Helper loaded: lang_helper
INFO - 2023-06-15 15:26:54 --> Helper loaded: security_helper
INFO - 2023-06-15 15:26:54 --> Helper loaded: cookie_helper
INFO - 2023-06-15 15:26:54 --> Database Driver Class Initialized
INFO - 2023-06-15 15:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-15 15:26:54 --> Parser Class Initialized
INFO - 2023-06-15 15:26:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-15 15:26:54 --> Pagination Class Initialized
INFO - 2023-06-15 15:26:54 --> Form Validation Class Initialized
INFO - 2023-06-15 15:26:54 --> Controller Class Initialized
INFO - 2023-06-15 15:26:54 --> Model Class Initialized
DEBUG - 2023-06-15 15:26:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-15 15:26:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-15 15:26:55 --> Config Class Initialized
INFO - 2023-06-15 15:26:55 --> Hooks Class Initialized
DEBUG - 2023-06-15 15:26:55 --> UTF-8 Support Enabled
INFO - 2023-06-15 15:26:55 --> Utf8 Class Initialized
INFO - 2023-06-15 15:26:55 --> URI Class Initialized
INFO - 2023-06-15 15:26:55 --> Router Class Initialized
INFO - 2023-06-15 15:26:55 --> Output Class Initialized
INFO - 2023-06-15 15:26:55 --> Security Class Initialized
DEBUG - 2023-06-15 15:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-15 15:26:55 --> Input Class Initialized
INFO - 2023-06-15 15:26:55 --> Language Class Initialized
INFO - 2023-06-15 15:26:55 --> Loader Class Initialized
INFO - 2023-06-15 15:26:55 --> Helper loaded: url_helper
INFO - 2023-06-15 15:26:55 --> Helper loaded: file_helper
INFO - 2023-06-15 15:26:55 --> Helper loaded: html_helper
INFO - 2023-06-15 15:26:55 --> Helper loaded: text_helper
INFO - 2023-06-15 15:26:55 --> Helper loaded: form_helper
INFO - 2023-06-15 15:26:55 --> Helper loaded: lang_helper
INFO - 2023-06-15 15:26:55 --> Helper loaded: security_helper
INFO - 2023-06-15 15:26:55 --> Helper loaded: cookie_helper
INFO - 2023-06-15 15:26:55 --> Database Driver Class Initialized
INFO - 2023-06-15 15:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-15 15:26:55 --> Parser Class Initialized
INFO - 2023-06-15 15:26:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-15 15:26:55 --> Pagination Class Initialized
INFO - 2023-06-15 15:26:55 --> Form Validation Class Initialized
INFO - 2023-06-15 15:26:55 --> Controller Class Initialized
INFO - 2023-06-15 15:26:55 --> Model Class Initialized
DEBUG - 2023-06-15 15:26:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-15 15:26:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-15 15:26:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-15 15:26:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-15 15:26:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-15 15:26:55 --> Model Class Initialized
INFO - 2023-06-15 15:26:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-15 15:26:55 --> Final output sent to browser
DEBUG - 2023-06-15 15:26:55 --> Total execution time: 0.0325
ERROR - 2023-06-15 15:27:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-15 15:27:14 --> Config Class Initialized
INFO - 2023-06-15 15:27:14 --> Hooks Class Initialized
DEBUG - 2023-06-15 15:27:14 --> UTF-8 Support Enabled
INFO - 2023-06-15 15:27:14 --> Utf8 Class Initialized
INFO - 2023-06-15 15:27:14 --> URI Class Initialized
INFO - 2023-06-15 15:27:14 --> Router Class Initialized
INFO - 2023-06-15 15:27:14 --> Output Class Initialized
INFO - 2023-06-15 15:27:14 --> Security Class Initialized
DEBUG - 2023-06-15 15:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-15 15:27:14 --> Input Class Initialized
INFO - 2023-06-15 15:27:14 --> Language Class Initialized
INFO - 2023-06-15 15:27:14 --> Loader Class Initialized
INFO - 2023-06-15 15:27:14 --> Helper loaded: url_helper
INFO - 2023-06-15 15:27:14 --> Helper loaded: file_helper
INFO - 2023-06-15 15:27:14 --> Helper loaded: html_helper
INFO - 2023-06-15 15:27:14 --> Helper loaded: text_helper
INFO - 2023-06-15 15:27:14 --> Helper loaded: form_helper
INFO - 2023-06-15 15:27:14 --> Helper loaded: lang_helper
INFO - 2023-06-15 15:27:14 --> Helper loaded: security_helper
INFO - 2023-06-15 15:27:14 --> Helper loaded: cookie_helper
INFO - 2023-06-15 15:27:14 --> Database Driver Class Initialized
INFO - 2023-06-15 15:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-15 15:27:14 --> Parser Class Initialized
INFO - 2023-06-15 15:27:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-15 15:27:14 --> Pagination Class Initialized
INFO - 2023-06-15 15:27:14 --> Form Validation Class Initialized
INFO - 2023-06-15 15:27:14 --> Controller Class Initialized
INFO - 2023-06-15 15:27:14 --> Model Class Initialized
DEBUG - 2023-06-15 15:27:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-15 15:27:14 --> Model Class Initialized
INFO - 2023-06-15 15:27:14 --> Final output sent to browser
DEBUG - 2023-06-15 15:27:14 --> Total execution time: 0.0209
ERROR - 2023-06-15 15:27:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-15 15:27:15 --> Config Class Initialized
INFO - 2023-06-15 15:27:15 --> Hooks Class Initialized
DEBUG - 2023-06-15 15:27:15 --> UTF-8 Support Enabled
INFO - 2023-06-15 15:27:15 --> Utf8 Class Initialized
INFO - 2023-06-15 15:27:15 --> URI Class Initialized
DEBUG - 2023-06-15 15:27:15 --> No URI present. Default controller set.
INFO - 2023-06-15 15:27:15 --> Router Class Initialized
INFO - 2023-06-15 15:27:15 --> Output Class Initialized
INFO - 2023-06-15 15:27:15 --> Security Class Initialized
DEBUG - 2023-06-15 15:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-15 15:27:15 --> Input Class Initialized
INFO - 2023-06-15 15:27:15 --> Language Class Initialized
INFO - 2023-06-15 15:27:15 --> Loader Class Initialized
INFO - 2023-06-15 15:27:15 --> Helper loaded: url_helper
INFO - 2023-06-15 15:27:15 --> Helper loaded: file_helper
INFO - 2023-06-15 15:27:15 --> Helper loaded: html_helper
INFO - 2023-06-15 15:27:15 --> Helper loaded: text_helper
INFO - 2023-06-15 15:27:15 --> Helper loaded: form_helper
INFO - 2023-06-15 15:27:15 --> Helper loaded: lang_helper
INFO - 2023-06-15 15:27:15 --> Helper loaded: security_helper
INFO - 2023-06-15 15:27:15 --> Helper loaded: cookie_helper
INFO - 2023-06-15 15:27:15 --> Database Driver Class Initialized
INFO - 2023-06-15 15:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-15 15:27:15 --> Parser Class Initialized
INFO - 2023-06-15 15:27:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-15 15:27:15 --> Pagination Class Initialized
INFO - 2023-06-15 15:27:15 --> Form Validation Class Initialized
INFO - 2023-06-15 15:27:15 --> Controller Class Initialized
INFO - 2023-06-15 15:27:15 --> Model Class Initialized
DEBUG - 2023-06-15 15:27:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-15 15:27:15 --> Model Class Initialized
DEBUG - 2023-06-15 15:27:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-15 15:27:15 --> Model Class Initialized
INFO - 2023-06-15 15:27:15 --> Model Class Initialized
INFO - 2023-06-15 15:27:15 --> Model Class Initialized
INFO - 2023-06-15 15:27:15 --> Model Class Initialized
DEBUG - 2023-06-15 15:27:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-15 15:27:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-15 15:27:15 --> Model Class Initialized
INFO - 2023-06-15 15:27:15 --> Model Class Initialized
INFO - 2023-06-15 15:27:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-15 15:27:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-15 15:27:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-15 15:27:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-15 15:27:15 --> Model Class Initialized
INFO - 2023-06-15 15:27:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-15 15:27:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-15 15:27:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-15 15:27:15 --> Final output sent to browser
DEBUG - 2023-06-15 15:27:15 --> Total execution time: 0.0852
ERROR - 2023-06-15 15:27:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-15 15:27:33 --> Config Class Initialized
INFO - 2023-06-15 15:27:33 --> Hooks Class Initialized
DEBUG - 2023-06-15 15:27:33 --> UTF-8 Support Enabled
INFO - 2023-06-15 15:27:33 --> Utf8 Class Initialized
INFO - 2023-06-15 15:27:33 --> URI Class Initialized
INFO - 2023-06-15 15:27:33 --> Router Class Initialized
INFO - 2023-06-15 15:27:33 --> Output Class Initialized
INFO - 2023-06-15 15:27:33 --> Security Class Initialized
DEBUG - 2023-06-15 15:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-15 15:27:33 --> Input Class Initialized
INFO - 2023-06-15 15:27:33 --> Language Class Initialized
INFO - 2023-06-15 15:27:33 --> Loader Class Initialized
INFO - 2023-06-15 15:27:33 --> Helper loaded: url_helper
INFO - 2023-06-15 15:27:33 --> Helper loaded: file_helper
INFO - 2023-06-15 15:27:33 --> Helper loaded: html_helper
INFO - 2023-06-15 15:27:33 --> Helper loaded: text_helper
INFO - 2023-06-15 15:27:33 --> Helper loaded: form_helper
INFO - 2023-06-15 15:27:33 --> Helper loaded: lang_helper
INFO - 2023-06-15 15:27:33 --> Helper loaded: security_helper
INFO - 2023-06-15 15:27:33 --> Helper loaded: cookie_helper
INFO - 2023-06-15 15:27:33 --> Database Driver Class Initialized
INFO - 2023-06-15 15:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-15 15:27:33 --> Parser Class Initialized
INFO - 2023-06-15 15:27:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-15 15:27:33 --> Pagination Class Initialized
INFO - 2023-06-15 15:27:33 --> Form Validation Class Initialized
INFO - 2023-06-15 15:27:33 --> Controller Class Initialized
INFO - 2023-06-15 15:27:33 --> Model Class Initialized
DEBUG - 2023-06-15 15:27:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-15 15:27:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-15 15:27:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-15 15:27:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-15 15:27:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-15 15:27:33 --> Model Class Initialized
INFO - 2023-06-15 15:27:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-15 15:27:33 --> Final output sent to browser
DEBUG - 2023-06-15 15:27:33 --> Total execution time: 0.0305
ERROR - 2023-06-15 15:27:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-15 15:27:33 --> Config Class Initialized
INFO - 2023-06-15 15:27:33 --> Hooks Class Initialized
DEBUG - 2023-06-15 15:27:33 --> UTF-8 Support Enabled
INFO - 2023-06-15 15:27:33 --> Utf8 Class Initialized
INFO - 2023-06-15 15:27:33 --> URI Class Initialized
INFO - 2023-06-15 15:27:33 --> Router Class Initialized
INFO - 2023-06-15 15:27:33 --> Output Class Initialized
INFO - 2023-06-15 15:27:33 --> Security Class Initialized
DEBUG - 2023-06-15 15:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-15 15:27:33 --> Input Class Initialized
INFO - 2023-06-15 15:27:33 --> Language Class Initialized
INFO - 2023-06-15 15:27:33 --> Loader Class Initialized
INFO - 2023-06-15 15:27:33 --> Helper loaded: url_helper
INFO - 2023-06-15 15:27:33 --> Helper loaded: file_helper
INFO - 2023-06-15 15:27:33 --> Helper loaded: html_helper
INFO - 2023-06-15 15:27:33 --> Helper loaded: text_helper
INFO - 2023-06-15 15:27:33 --> Helper loaded: form_helper
INFO - 2023-06-15 15:27:33 --> Helper loaded: lang_helper
INFO - 2023-06-15 15:27:33 --> Helper loaded: security_helper
INFO - 2023-06-15 15:27:33 --> Helper loaded: cookie_helper
INFO - 2023-06-15 15:27:33 --> Database Driver Class Initialized
INFO - 2023-06-15 15:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-15 15:27:33 --> Parser Class Initialized
INFO - 2023-06-15 15:27:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-15 15:27:33 --> Pagination Class Initialized
INFO - 2023-06-15 15:27:33 --> Form Validation Class Initialized
INFO - 2023-06-15 15:27:33 --> Controller Class Initialized
INFO - 2023-06-15 15:27:33 --> Model Class Initialized
DEBUG - 2023-06-15 15:27:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-15 15:27:33 --> Model Class Initialized
DEBUG - 2023-06-15 15:27:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-15 15:27:33 --> Model Class Initialized
INFO - 2023-06-15 15:27:33 --> Model Class Initialized
INFO - 2023-06-15 15:27:33 --> Model Class Initialized
INFO - 2023-06-15 15:27:33 --> Model Class Initialized
DEBUG - 2023-06-15 15:27:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-15 15:27:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-15 15:27:33 --> Model Class Initialized
INFO - 2023-06-15 15:27:33 --> Model Class Initialized
INFO - 2023-06-15 15:27:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-15 15:27:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-15 15:27:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-15 15:27:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-15 15:27:33 --> Model Class Initialized
INFO - 2023-06-15 15:27:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-15 15:27:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-15 15:27:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-15 15:27:33 --> Final output sent to browser
DEBUG - 2023-06-15 15:27:33 --> Total execution time: 0.0834
ERROR - 2023-06-15 15:27:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-15 15:27:36 --> Config Class Initialized
INFO - 2023-06-15 15:27:36 --> Hooks Class Initialized
DEBUG - 2023-06-15 15:27:36 --> UTF-8 Support Enabled
INFO - 2023-06-15 15:27:36 --> Utf8 Class Initialized
INFO - 2023-06-15 15:27:36 --> URI Class Initialized
INFO - 2023-06-15 15:27:36 --> Router Class Initialized
INFO - 2023-06-15 15:27:36 --> Output Class Initialized
INFO - 2023-06-15 15:27:36 --> Security Class Initialized
DEBUG - 2023-06-15 15:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-15 15:27:36 --> Input Class Initialized
INFO - 2023-06-15 15:27:36 --> Language Class Initialized
INFO - 2023-06-15 15:27:36 --> Loader Class Initialized
INFO - 2023-06-15 15:27:36 --> Helper loaded: url_helper
INFO - 2023-06-15 15:27:36 --> Helper loaded: file_helper
INFO - 2023-06-15 15:27:36 --> Helper loaded: html_helper
INFO - 2023-06-15 15:27:36 --> Helper loaded: text_helper
INFO - 2023-06-15 15:27:36 --> Helper loaded: form_helper
INFO - 2023-06-15 15:27:36 --> Helper loaded: lang_helper
INFO - 2023-06-15 15:27:36 --> Helper loaded: security_helper
INFO - 2023-06-15 15:27:36 --> Helper loaded: cookie_helper
INFO - 2023-06-15 15:27:36 --> Database Driver Class Initialized
INFO - 2023-06-15 15:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-15 15:27:36 --> Parser Class Initialized
INFO - 2023-06-15 15:27:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-15 15:27:36 --> Pagination Class Initialized
INFO - 2023-06-15 15:27:36 --> Form Validation Class Initialized
INFO - 2023-06-15 15:27:36 --> Controller Class Initialized
INFO - 2023-06-15 15:27:36 --> Model Class Initialized
DEBUG - 2023-06-15 15:27:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-15 15:27:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-15 15:27:36 --> Model Class Initialized
DEBUG - 2023-06-15 15:27:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-15 15:27:36 --> Model Class Initialized
INFO - 2023-06-15 15:27:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-06-15 15:27:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-15 15:27:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-15 15:27:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-15 15:27:36 --> Model Class Initialized
INFO - 2023-06-15 15:27:36 --> Model Class Initialized
INFO - 2023-06-15 15:27:36 --> Model Class Initialized
INFO - 2023-06-15 15:27:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-15 15:27:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-15 15:27:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-15 15:27:36 --> Final output sent to browser
DEBUG - 2023-06-15 15:27:36 --> Total execution time: 0.0811
ERROR - 2023-06-15 15:27:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-15 15:27:37 --> Config Class Initialized
INFO - 2023-06-15 15:27:37 --> Hooks Class Initialized
DEBUG - 2023-06-15 15:27:37 --> UTF-8 Support Enabled
INFO - 2023-06-15 15:27:37 --> Utf8 Class Initialized
INFO - 2023-06-15 15:27:37 --> URI Class Initialized
INFO - 2023-06-15 15:27:37 --> Router Class Initialized
INFO - 2023-06-15 15:27:37 --> Output Class Initialized
INFO - 2023-06-15 15:27:37 --> Security Class Initialized
DEBUG - 2023-06-15 15:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-15 15:27:37 --> Input Class Initialized
INFO - 2023-06-15 15:27:37 --> Language Class Initialized
INFO - 2023-06-15 15:27:37 --> Loader Class Initialized
INFO - 2023-06-15 15:27:37 --> Helper loaded: url_helper
INFO - 2023-06-15 15:27:37 --> Helper loaded: file_helper
INFO - 2023-06-15 15:27:37 --> Helper loaded: html_helper
INFO - 2023-06-15 15:27:37 --> Helper loaded: text_helper
INFO - 2023-06-15 15:27:37 --> Helper loaded: form_helper
INFO - 2023-06-15 15:27:37 --> Helper loaded: lang_helper
INFO - 2023-06-15 15:27:37 --> Helper loaded: security_helper
INFO - 2023-06-15 15:27:37 --> Helper loaded: cookie_helper
INFO - 2023-06-15 15:27:37 --> Database Driver Class Initialized
INFO - 2023-06-15 15:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-15 15:27:37 --> Parser Class Initialized
INFO - 2023-06-15 15:27:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-15 15:27:37 --> Pagination Class Initialized
INFO - 2023-06-15 15:27:37 --> Form Validation Class Initialized
INFO - 2023-06-15 15:27:37 --> Controller Class Initialized
INFO - 2023-06-15 15:27:37 --> Model Class Initialized
DEBUG - 2023-06-15 15:27:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-15 15:27:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-15 15:27:37 --> Model Class Initialized
DEBUG - 2023-06-15 15:27:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-15 15:27:37 --> Model Class Initialized
INFO - 2023-06-15 15:27:37 --> Final output sent to browser
DEBUG - 2023-06-15 15:27:37 --> Total execution time: 0.0476
ERROR - 2023-06-15 16:13:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-15 16:13:34 --> Config Class Initialized
INFO - 2023-06-15 16:13:34 --> Hooks Class Initialized
DEBUG - 2023-06-15 16:13:34 --> UTF-8 Support Enabled
INFO - 2023-06-15 16:13:34 --> Utf8 Class Initialized
INFO - 2023-06-15 16:13:34 --> URI Class Initialized
DEBUG - 2023-06-15 16:13:34 --> No URI present. Default controller set.
INFO - 2023-06-15 16:13:34 --> Router Class Initialized
INFO - 2023-06-15 16:13:34 --> Output Class Initialized
INFO - 2023-06-15 16:13:34 --> Security Class Initialized
DEBUG - 2023-06-15 16:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-15 16:13:34 --> Input Class Initialized
INFO - 2023-06-15 16:13:34 --> Language Class Initialized
INFO - 2023-06-15 16:13:34 --> Loader Class Initialized
INFO - 2023-06-15 16:13:34 --> Helper loaded: url_helper
INFO - 2023-06-15 16:13:34 --> Helper loaded: file_helper
INFO - 2023-06-15 16:13:34 --> Helper loaded: html_helper
INFO - 2023-06-15 16:13:34 --> Helper loaded: text_helper
INFO - 2023-06-15 16:13:34 --> Helper loaded: form_helper
INFO - 2023-06-15 16:13:34 --> Helper loaded: lang_helper
INFO - 2023-06-15 16:13:34 --> Helper loaded: security_helper
INFO - 2023-06-15 16:13:34 --> Helper loaded: cookie_helper
INFO - 2023-06-15 16:13:34 --> Database Driver Class Initialized
INFO - 2023-06-15 16:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-15 16:13:34 --> Parser Class Initialized
INFO - 2023-06-15 16:13:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-15 16:13:34 --> Pagination Class Initialized
INFO - 2023-06-15 16:13:34 --> Form Validation Class Initialized
INFO - 2023-06-15 16:13:34 --> Controller Class Initialized
INFO - 2023-06-15 16:13:34 --> Model Class Initialized
DEBUG - 2023-06-15 16:13:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-15 16:13:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-15 16:13:34 --> Config Class Initialized
INFO - 2023-06-15 16:13:34 --> Hooks Class Initialized
DEBUG - 2023-06-15 16:13:34 --> UTF-8 Support Enabled
INFO - 2023-06-15 16:13:34 --> Utf8 Class Initialized
INFO - 2023-06-15 16:13:34 --> URI Class Initialized
INFO - 2023-06-15 16:13:34 --> Router Class Initialized
INFO - 2023-06-15 16:13:34 --> Output Class Initialized
INFO - 2023-06-15 16:13:34 --> Security Class Initialized
DEBUG - 2023-06-15 16:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-15 16:13:34 --> Input Class Initialized
INFO - 2023-06-15 16:13:34 --> Language Class Initialized
INFO - 2023-06-15 16:13:34 --> Loader Class Initialized
INFO - 2023-06-15 16:13:34 --> Helper loaded: url_helper
INFO - 2023-06-15 16:13:34 --> Helper loaded: file_helper
INFO - 2023-06-15 16:13:34 --> Helper loaded: html_helper
INFO - 2023-06-15 16:13:34 --> Helper loaded: text_helper
INFO - 2023-06-15 16:13:34 --> Helper loaded: form_helper
INFO - 2023-06-15 16:13:34 --> Helper loaded: lang_helper
INFO - 2023-06-15 16:13:34 --> Helper loaded: security_helper
INFO - 2023-06-15 16:13:34 --> Helper loaded: cookie_helper
INFO - 2023-06-15 16:13:34 --> Database Driver Class Initialized
INFO - 2023-06-15 16:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-15 16:13:34 --> Parser Class Initialized
INFO - 2023-06-15 16:13:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-15 16:13:34 --> Pagination Class Initialized
INFO - 2023-06-15 16:13:34 --> Form Validation Class Initialized
INFO - 2023-06-15 16:13:34 --> Controller Class Initialized
INFO - 2023-06-15 16:13:34 --> Model Class Initialized
DEBUG - 2023-06-15 16:13:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-15 16:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-15 16:13:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-15 16:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-15 16:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-15 16:13:34 --> Model Class Initialized
INFO - 2023-06-15 16:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-15 16:13:34 --> Final output sent to browser
DEBUG - 2023-06-15 16:13:34 --> Total execution time: 0.0324
ERROR - 2023-06-15 16:29:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-15 16:29:18 --> Config Class Initialized
INFO - 2023-06-15 16:29:18 --> Hooks Class Initialized
DEBUG - 2023-06-15 16:29:18 --> UTF-8 Support Enabled
INFO - 2023-06-15 16:29:18 --> Utf8 Class Initialized
INFO - 2023-06-15 16:29:18 --> URI Class Initialized
INFO - 2023-06-15 16:29:18 --> Router Class Initialized
INFO - 2023-06-15 16:29:18 --> Output Class Initialized
INFO - 2023-06-15 16:29:18 --> Security Class Initialized
DEBUG - 2023-06-15 16:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-15 16:29:18 --> Input Class Initialized
INFO - 2023-06-15 16:29:18 --> Language Class Initialized
INFO - 2023-06-15 16:29:18 --> Loader Class Initialized
INFO - 2023-06-15 16:29:18 --> Helper loaded: url_helper
INFO - 2023-06-15 16:29:18 --> Helper loaded: file_helper
INFO - 2023-06-15 16:29:18 --> Helper loaded: html_helper
INFO - 2023-06-15 16:29:18 --> Helper loaded: text_helper
INFO - 2023-06-15 16:29:18 --> Helper loaded: form_helper
INFO - 2023-06-15 16:29:18 --> Helper loaded: lang_helper
INFO - 2023-06-15 16:29:18 --> Helper loaded: security_helper
INFO - 2023-06-15 16:29:18 --> Helper loaded: cookie_helper
INFO - 2023-06-15 16:29:18 --> Database Driver Class Initialized
INFO - 2023-06-15 16:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-15 16:29:18 --> Parser Class Initialized
INFO - 2023-06-15 16:29:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-15 16:29:18 --> Pagination Class Initialized
INFO - 2023-06-15 16:29:18 --> Form Validation Class Initialized
INFO - 2023-06-15 16:29:18 --> Controller Class Initialized
INFO - 2023-06-15 16:29:18 --> Model Class Initialized
DEBUG - 2023-06-15 16:29:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-15 16:29:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-15 16:29:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-15 16:29:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-15 16:29:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-15 16:29:18 --> Model Class Initialized
INFO - 2023-06-15 16:29:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-15 16:29:18 --> Final output sent to browser
DEBUG - 2023-06-15 16:29:18 --> Total execution time: 0.0377
ERROR - 2023-06-15 16:34:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-15 16:34:50 --> Config Class Initialized
INFO - 2023-06-15 16:34:50 --> Hooks Class Initialized
DEBUG - 2023-06-15 16:34:50 --> UTF-8 Support Enabled
INFO - 2023-06-15 16:34:50 --> Utf8 Class Initialized
INFO - 2023-06-15 16:34:50 --> URI Class Initialized
INFO - 2023-06-15 16:34:50 --> Router Class Initialized
INFO - 2023-06-15 16:34:50 --> Output Class Initialized
INFO - 2023-06-15 16:34:50 --> Security Class Initialized
DEBUG - 2023-06-15 16:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-15 16:34:50 --> Input Class Initialized
INFO - 2023-06-15 16:34:50 --> Language Class Initialized
INFO - 2023-06-15 16:34:50 --> Loader Class Initialized
INFO - 2023-06-15 16:34:50 --> Helper loaded: url_helper
INFO - 2023-06-15 16:34:50 --> Helper loaded: file_helper
INFO - 2023-06-15 16:34:50 --> Helper loaded: html_helper
INFO - 2023-06-15 16:34:50 --> Helper loaded: text_helper
INFO - 2023-06-15 16:34:50 --> Helper loaded: form_helper
INFO - 2023-06-15 16:34:50 --> Helper loaded: lang_helper
INFO - 2023-06-15 16:34:50 --> Helper loaded: security_helper
INFO - 2023-06-15 16:34:50 --> Helper loaded: cookie_helper
INFO - 2023-06-15 16:34:50 --> Database Driver Class Initialized
INFO - 2023-06-15 16:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-15 16:34:50 --> Parser Class Initialized
INFO - 2023-06-15 16:34:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-15 16:34:50 --> Pagination Class Initialized
INFO - 2023-06-15 16:34:50 --> Form Validation Class Initialized
INFO - 2023-06-15 16:34:50 --> Controller Class Initialized
INFO - 2023-06-15 16:34:50 --> Model Class Initialized
DEBUG - 2023-06-15 16:34:50 --> Session class already loaded. Second attempt ignored.
