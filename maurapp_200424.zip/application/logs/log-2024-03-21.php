<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-03-21 04:33:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:33:47 --> Config Class Initialized
INFO - 2024-03-21 04:33:47 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:33:47 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:33:47 --> Utf8 Class Initialized
INFO - 2024-03-21 04:33:47 --> URI Class Initialized
DEBUG - 2024-03-21 04:33:47 --> No URI present. Default controller set.
INFO - 2024-03-21 04:33:47 --> Router Class Initialized
INFO - 2024-03-21 04:33:47 --> Output Class Initialized
INFO - 2024-03-21 04:33:47 --> Security Class Initialized
DEBUG - 2024-03-21 04:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:33:47 --> Input Class Initialized
INFO - 2024-03-21 04:33:47 --> Language Class Initialized
INFO - 2024-03-21 04:33:47 --> Loader Class Initialized
INFO - 2024-03-21 04:33:47 --> Helper loaded: url_helper
INFO - 2024-03-21 04:33:47 --> Helper loaded: file_helper
INFO - 2024-03-21 04:33:47 --> Helper loaded: html_helper
INFO - 2024-03-21 04:33:47 --> Helper loaded: text_helper
INFO - 2024-03-21 04:33:47 --> Helper loaded: form_helper
INFO - 2024-03-21 04:33:47 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:33:47 --> Helper loaded: security_helper
INFO - 2024-03-21 04:33:47 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:33:47 --> Database Driver Class Initialized
INFO - 2024-03-21 04:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:33:47 --> Parser Class Initialized
INFO - 2024-03-21 04:33:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:33:47 --> Pagination Class Initialized
INFO - 2024-03-21 04:33:47 --> Form Validation Class Initialized
INFO - 2024-03-21 04:33:47 --> Controller Class Initialized
INFO - 2024-03-21 04:33:47 --> Model Class Initialized
DEBUG - 2024-03-21 04:33:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-21 04:33:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:33:47 --> Config Class Initialized
INFO - 2024-03-21 04:33:47 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:33:47 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:33:47 --> Utf8 Class Initialized
INFO - 2024-03-21 04:33:47 --> URI Class Initialized
INFO - 2024-03-21 04:33:47 --> Router Class Initialized
INFO - 2024-03-21 04:33:47 --> Output Class Initialized
INFO - 2024-03-21 04:33:47 --> Security Class Initialized
DEBUG - 2024-03-21 04:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:33:47 --> Input Class Initialized
INFO - 2024-03-21 04:33:47 --> Language Class Initialized
INFO - 2024-03-21 04:33:47 --> Loader Class Initialized
INFO - 2024-03-21 04:33:47 --> Helper loaded: url_helper
INFO - 2024-03-21 04:33:47 --> Helper loaded: file_helper
INFO - 2024-03-21 04:33:47 --> Helper loaded: html_helper
INFO - 2024-03-21 04:33:47 --> Helper loaded: text_helper
INFO - 2024-03-21 04:33:47 --> Helper loaded: form_helper
INFO - 2024-03-21 04:33:47 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:33:47 --> Helper loaded: security_helper
INFO - 2024-03-21 04:33:47 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:33:47 --> Database Driver Class Initialized
INFO - 2024-03-21 04:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:33:47 --> Parser Class Initialized
INFO - 2024-03-21 04:33:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:33:47 --> Pagination Class Initialized
INFO - 2024-03-21 04:33:47 --> Form Validation Class Initialized
INFO - 2024-03-21 04:33:47 --> Controller Class Initialized
INFO - 2024-03-21 04:33:47 --> Model Class Initialized
DEBUG - 2024-03-21 04:33:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:33:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-21 04:33:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:33:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 04:33:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 04:33:47 --> Model Class Initialized
INFO - 2024-03-21 04:33:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 04:33:47 --> Final output sent to browser
DEBUG - 2024-03-21 04:33:47 --> Total execution time: 0.0352
ERROR - 2024-03-21 04:34:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:34:01 --> Config Class Initialized
INFO - 2024-03-21 04:34:01 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:34:01 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:34:01 --> Utf8 Class Initialized
INFO - 2024-03-21 04:34:01 --> URI Class Initialized
INFO - 2024-03-21 04:34:01 --> Router Class Initialized
INFO - 2024-03-21 04:34:01 --> Output Class Initialized
INFO - 2024-03-21 04:34:01 --> Security Class Initialized
DEBUG - 2024-03-21 04:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:34:01 --> Input Class Initialized
INFO - 2024-03-21 04:34:01 --> Language Class Initialized
INFO - 2024-03-21 04:34:01 --> Loader Class Initialized
INFO - 2024-03-21 04:34:01 --> Helper loaded: url_helper
INFO - 2024-03-21 04:34:01 --> Helper loaded: file_helper
INFO - 2024-03-21 04:34:01 --> Helper loaded: html_helper
INFO - 2024-03-21 04:34:01 --> Helper loaded: text_helper
INFO - 2024-03-21 04:34:01 --> Helper loaded: form_helper
INFO - 2024-03-21 04:34:01 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:34:01 --> Helper loaded: security_helper
INFO - 2024-03-21 04:34:01 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:34:01 --> Database Driver Class Initialized
INFO - 2024-03-21 04:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:34:01 --> Parser Class Initialized
INFO - 2024-03-21 04:34:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:34:01 --> Pagination Class Initialized
INFO - 2024-03-21 04:34:01 --> Form Validation Class Initialized
INFO - 2024-03-21 04:34:01 --> Controller Class Initialized
INFO - 2024-03-21 04:34:01 --> Model Class Initialized
DEBUG - 2024-03-21 04:34:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:34:01 --> Model Class Initialized
INFO - 2024-03-21 04:34:01 --> Final output sent to browser
DEBUG - 2024-03-21 04:34:01 --> Total execution time: 0.0215
ERROR - 2024-03-21 04:34:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:34:01 --> Config Class Initialized
INFO - 2024-03-21 04:34:01 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:34:01 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:34:01 --> Utf8 Class Initialized
INFO - 2024-03-21 04:34:01 --> URI Class Initialized
DEBUG - 2024-03-21 04:34:01 --> No URI present. Default controller set.
INFO - 2024-03-21 04:34:01 --> Router Class Initialized
INFO - 2024-03-21 04:34:01 --> Output Class Initialized
INFO - 2024-03-21 04:34:01 --> Security Class Initialized
DEBUG - 2024-03-21 04:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:34:01 --> Input Class Initialized
INFO - 2024-03-21 04:34:01 --> Language Class Initialized
INFO - 2024-03-21 04:34:01 --> Loader Class Initialized
INFO - 2024-03-21 04:34:01 --> Helper loaded: url_helper
INFO - 2024-03-21 04:34:01 --> Helper loaded: file_helper
INFO - 2024-03-21 04:34:01 --> Helper loaded: html_helper
INFO - 2024-03-21 04:34:01 --> Helper loaded: text_helper
INFO - 2024-03-21 04:34:01 --> Helper loaded: form_helper
INFO - 2024-03-21 04:34:01 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:34:01 --> Helper loaded: security_helper
INFO - 2024-03-21 04:34:01 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:34:01 --> Database Driver Class Initialized
INFO - 2024-03-21 04:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:34:01 --> Parser Class Initialized
INFO - 2024-03-21 04:34:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:34:01 --> Pagination Class Initialized
INFO - 2024-03-21 04:34:01 --> Form Validation Class Initialized
INFO - 2024-03-21 04:34:01 --> Controller Class Initialized
INFO - 2024-03-21 04:34:01 --> Model Class Initialized
DEBUG - 2024-03-21 04:34:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:34:01 --> Model Class Initialized
DEBUG - 2024-03-21 04:34:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:34:01 --> Model Class Initialized
INFO - 2024-03-21 04:34:01 --> Model Class Initialized
INFO - 2024-03-21 04:34:01 --> Model Class Initialized
INFO - 2024-03-21 04:34:01 --> Model Class Initialized
DEBUG - 2024-03-21 04:34:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:34:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:34:01 --> Model Class Initialized
INFO - 2024-03-21 04:34:01 --> Model Class Initialized
INFO - 2024-03-21 04:34:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-21 04:34:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:34:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 04:34:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 04:34:02 --> Model Class Initialized
INFO - 2024-03-21 04:34:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-21 04:34:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-21 04:34:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 04:34:02 --> Final output sent to browser
DEBUG - 2024-03-21 04:34:02 --> Total execution time: 0.3361
ERROR - 2024-03-21 04:34:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:34:06 --> Config Class Initialized
INFO - 2024-03-21 04:34:06 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:34:06 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:34:06 --> Utf8 Class Initialized
INFO - 2024-03-21 04:34:06 --> URI Class Initialized
INFO - 2024-03-21 04:34:06 --> Router Class Initialized
INFO - 2024-03-21 04:34:06 --> Output Class Initialized
INFO - 2024-03-21 04:34:06 --> Security Class Initialized
DEBUG - 2024-03-21 04:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:34:06 --> Input Class Initialized
INFO - 2024-03-21 04:34:06 --> Language Class Initialized
INFO - 2024-03-21 04:34:06 --> Loader Class Initialized
INFO - 2024-03-21 04:34:06 --> Helper loaded: url_helper
INFO - 2024-03-21 04:34:06 --> Helper loaded: file_helper
INFO - 2024-03-21 04:34:06 --> Helper loaded: html_helper
INFO - 2024-03-21 04:34:06 --> Helper loaded: text_helper
INFO - 2024-03-21 04:34:06 --> Helper loaded: form_helper
INFO - 2024-03-21 04:34:06 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:34:06 --> Helper loaded: security_helper
INFO - 2024-03-21 04:34:06 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:34:06 --> Database Driver Class Initialized
INFO - 2024-03-21 04:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:34:06 --> Parser Class Initialized
INFO - 2024-03-21 04:34:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:34:06 --> Pagination Class Initialized
INFO - 2024-03-21 04:34:06 --> Form Validation Class Initialized
INFO - 2024-03-21 04:34:06 --> Controller Class Initialized
INFO - 2024-03-21 04:34:06 --> Model Class Initialized
DEBUG - 2024-03-21 04:34:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:34:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:34:06 --> Model Class Initialized
DEBUG - 2024-03-21 04:34:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:34:06 --> Model Class Initialized
INFO - 2024-03-21 04:34:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-21 04:34:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:34:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 04:34:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 04:34:06 --> Model Class Initialized
INFO - 2024-03-21 04:34:06 --> Model Class Initialized
INFO - 2024-03-21 04:34:06 --> Model Class Initialized
INFO - 2024-03-21 04:34:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-21 04:34:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-21 04:34:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 04:34:06 --> Final output sent to browser
DEBUG - 2024-03-21 04:34:06 --> Total execution time: 0.1753
ERROR - 2024-03-21 04:34:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:34:07 --> Config Class Initialized
INFO - 2024-03-21 04:34:07 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:34:07 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:34:07 --> Utf8 Class Initialized
INFO - 2024-03-21 04:34:07 --> URI Class Initialized
INFO - 2024-03-21 04:34:07 --> Router Class Initialized
INFO - 2024-03-21 04:34:07 --> Output Class Initialized
INFO - 2024-03-21 04:34:07 --> Security Class Initialized
DEBUG - 2024-03-21 04:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:34:07 --> Input Class Initialized
INFO - 2024-03-21 04:34:07 --> Language Class Initialized
INFO - 2024-03-21 04:34:07 --> Loader Class Initialized
INFO - 2024-03-21 04:34:07 --> Helper loaded: url_helper
INFO - 2024-03-21 04:34:07 --> Helper loaded: file_helper
INFO - 2024-03-21 04:34:07 --> Helper loaded: html_helper
INFO - 2024-03-21 04:34:07 --> Helper loaded: text_helper
INFO - 2024-03-21 04:34:07 --> Helper loaded: form_helper
INFO - 2024-03-21 04:34:07 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:34:07 --> Helper loaded: security_helper
INFO - 2024-03-21 04:34:07 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:34:07 --> Database Driver Class Initialized
INFO - 2024-03-21 04:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:34:07 --> Parser Class Initialized
INFO - 2024-03-21 04:34:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:34:07 --> Pagination Class Initialized
INFO - 2024-03-21 04:34:07 --> Form Validation Class Initialized
INFO - 2024-03-21 04:34:07 --> Controller Class Initialized
INFO - 2024-03-21 04:34:07 --> Model Class Initialized
DEBUG - 2024-03-21 04:34:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:34:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:34:07 --> Model Class Initialized
DEBUG - 2024-03-21 04:34:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:34:07 --> Model Class Initialized
INFO - 2024-03-21 04:34:07 --> Final output sent to browser
DEBUG - 2024-03-21 04:34:07 --> Total execution time: 0.0486
ERROR - 2024-03-21 04:34:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:34:19 --> Config Class Initialized
INFO - 2024-03-21 04:34:19 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:34:19 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:34:19 --> Utf8 Class Initialized
INFO - 2024-03-21 04:34:19 --> URI Class Initialized
INFO - 2024-03-21 04:34:19 --> Router Class Initialized
INFO - 2024-03-21 04:34:19 --> Output Class Initialized
INFO - 2024-03-21 04:34:19 --> Security Class Initialized
DEBUG - 2024-03-21 04:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:34:19 --> Input Class Initialized
INFO - 2024-03-21 04:34:19 --> Language Class Initialized
INFO - 2024-03-21 04:34:19 --> Loader Class Initialized
INFO - 2024-03-21 04:34:19 --> Helper loaded: url_helper
INFO - 2024-03-21 04:34:19 --> Helper loaded: file_helper
INFO - 2024-03-21 04:34:19 --> Helper loaded: html_helper
INFO - 2024-03-21 04:34:19 --> Helper loaded: text_helper
INFO - 2024-03-21 04:34:19 --> Helper loaded: form_helper
INFO - 2024-03-21 04:34:19 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:34:19 --> Helper loaded: security_helper
INFO - 2024-03-21 04:34:19 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:34:19 --> Database Driver Class Initialized
INFO - 2024-03-21 04:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:34:19 --> Parser Class Initialized
INFO - 2024-03-21 04:34:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:34:19 --> Pagination Class Initialized
INFO - 2024-03-21 04:34:19 --> Form Validation Class Initialized
INFO - 2024-03-21 04:34:19 --> Controller Class Initialized
INFO - 2024-03-21 04:34:19 --> Model Class Initialized
DEBUG - 2024-03-21 04:34:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:34:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:34:19 --> Model Class Initialized
DEBUG - 2024-03-21 04:34:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:34:19 --> Model Class Initialized
INFO - 2024-03-21 04:34:19 --> Final output sent to browser
DEBUG - 2024-03-21 04:34:19 --> Total execution time: 0.0671
ERROR - 2024-03-21 04:34:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:34:20 --> Config Class Initialized
INFO - 2024-03-21 04:34:20 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:34:20 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:34:20 --> Utf8 Class Initialized
INFO - 2024-03-21 04:34:20 --> URI Class Initialized
INFO - 2024-03-21 04:34:20 --> Router Class Initialized
INFO - 2024-03-21 04:34:20 --> Output Class Initialized
INFO - 2024-03-21 04:34:20 --> Security Class Initialized
DEBUG - 2024-03-21 04:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:34:20 --> Input Class Initialized
INFO - 2024-03-21 04:34:20 --> Language Class Initialized
INFO - 2024-03-21 04:34:20 --> Loader Class Initialized
INFO - 2024-03-21 04:34:20 --> Helper loaded: url_helper
INFO - 2024-03-21 04:34:20 --> Helper loaded: file_helper
INFO - 2024-03-21 04:34:20 --> Helper loaded: html_helper
INFO - 2024-03-21 04:34:20 --> Helper loaded: text_helper
INFO - 2024-03-21 04:34:20 --> Helper loaded: form_helper
INFO - 2024-03-21 04:34:20 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:34:20 --> Helper loaded: security_helper
INFO - 2024-03-21 04:34:20 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:34:20 --> Database Driver Class Initialized
INFO - 2024-03-21 04:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:34:20 --> Parser Class Initialized
INFO - 2024-03-21 04:34:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:34:20 --> Pagination Class Initialized
INFO - 2024-03-21 04:34:20 --> Form Validation Class Initialized
INFO - 2024-03-21 04:34:20 --> Controller Class Initialized
INFO - 2024-03-21 04:34:20 --> Model Class Initialized
DEBUG - 2024-03-21 04:34:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:34:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:34:20 --> Model Class Initialized
DEBUG - 2024-03-21 04:34:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:34:20 --> Model Class Initialized
INFO - 2024-03-21 04:34:20 --> Final output sent to browser
DEBUG - 2024-03-21 04:34:20 --> Total execution time: 0.0634
ERROR - 2024-03-21 04:35:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:35:10 --> Config Class Initialized
INFO - 2024-03-21 04:35:10 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:35:10 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:35:10 --> Utf8 Class Initialized
INFO - 2024-03-21 04:35:10 --> URI Class Initialized
DEBUG - 2024-03-21 04:35:10 --> No URI present. Default controller set.
INFO - 2024-03-21 04:35:10 --> Router Class Initialized
INFO - 2024-03-21 04:35:10 --> Output Class Initialized
INFO - 2024-03-21 04:35:10 --> Security Class Initialized
DEBUG - 2024-03-21 04:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:35:10 --> Input Class Initialized
INFO - 2024-03-21 04:35:10 --> Language Class Initialized
INFO - 2024-03-21 04:35:10 --> Loader Class Initialized
INFO - 2024-03-21 04:35:10 --> Helper loaded: url_helper
INFO - 2024-03-21 04:35:10 --> Helper loaded: file_helper
INFO - 2024-03-21 04:35:10 --> Helper loaded: html_helper
INFO - 2024-03-21 04:35:10 --> Helper loaded: text_helper
INFO - 2024-03-21 04:35:10 --> Helper loaded: form_helper
INFO - 2024-03-21 04:35:10 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:35:10 --> Helper loaded: security_helper
INFO - 2024-03-21 04:35:10 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:35:10 --> Database Driver Class Initialized
INFO - 2024-03-21 04:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:35:10 --> Parser Class Initialized
INFO - 2024-03-21 04:35:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:35:10 --> Pagination Class Initialized
INFO - 2024-03-21 04:35:10 --> Form Validation Class Initialized
INFO - 2024-03-21 04:35:10 --> Controller Class Initialized
INFO - 2024-03-21 04:35:10 --> Model Class Initialized
DEBUG - 2024-03-21 04:35:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:35:10 --> Model Class Initialized
DEBUG - 2024-03-21 04:35:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:35:10 --> Model Class Initialized
INFO - 2024-03-21 04:35:10 --> Model Class Initialized
INFO - 2024-03-21 04:35:10 --> Model Class Initialized
INFO - 2024-03-21 04:35:10 --> Model Class Initialized
DEBUG - 2024-03-21 04:35:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:35:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:35:10 --> Model Class Initialized
INFO - 2024-03-21 04:35:10 --> Model Class Initialized
INFO - 2024-03-21 04:35:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-21 04:35:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:35:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 04:35:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 04:35:10 --> Model Class Initialized
INFO - 2024-03-21 04:35:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-21 04:35:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-21 04:35:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 04:35:11 --> Final output sent to browser
DEBUG - 2024-03-21 04:35:11 --> Total execution time: 0.2529
ERROR - 2024-03-21 04:35:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:35:17 --> Config Class Initialized
INFO - 2024-03-21 04:35:17 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:35:17 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:35:17 --> Utf8 Class Initialized
INFO - 2024-03-21 04:35:17 --> URI Class Initialized
INFO - 2024-03-21 04:35:17 --> Router Class Initialized
INFO - 2024-03-21 04:35:17 --> Output Class Initialized
INFO - 2024-03-21 04:35:17 --> Security Class Initialized
DEBUG - 2024-03-21 04:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:35:17 --> Input Class Initialized
INFO - 2024-03-21 04:35:17 --> Language Class Initialized
INFO - 2024-03-21 04:35:17 --> Loader Class Initialized
INFO - 2024-03-21 04:35:17 --> Helper loaded: url_helper
INFO - 2024-03-21 04:35:17 --> Helper loaded: file_helper
INFO - 2024-03-21 04:35:17 --> Helper loaded: html_helper
INFO - 2024-03-21 04:35:17 --> Helper loaded: text_helper
INFO - 2024-03-21 04:35:17 --> Helper loaded: form_helper
INFO - 2024-03-21 04:35:17 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:35:17 --> Helper loaded: security_helper
INFO - 2024-03-21 04:35:17 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:35:17 --> Database Driver Class Initialized
INFO - 2024-03-21 04:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:35:17 --> Parser Class Initialized
INFO - 2024-03-21 04:35:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:35:17 --> Pagination Class Initialized
INFO - 2024-03-21 04:35:17 --> Form Validation Class Initialized
INFO - 2024-03-21 04:35:17 --> Controller Class Initialized
INFO - 2024-03-21 04:35:17 --> Model Class Initialized
DEBUG - 2024-03-21 04:35:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:35:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:35:17 --> Model Class Initialized
DEBUG - 2024-03-21 04:35:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:35:17 --> Model Class Initialized
INFO - 2024-03-21 04:35:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-21 04:35:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:35:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 04:35:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 04:35:17 --> Model Class Initialized
INFO - 2024-03-21 04:35:17 --> Model Class Initialized
INFO - 2024-03-21 04:35:17 --> Model Class Initialized
INFO - 2024-03-21 04:35:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-21 04:35:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-21 04:35:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 04:35:17 --> Final output sent to browser
DEBUG - 2024-03-21 04:35:17 --> Total execution time: 0.1632
ERROR - 2024-03-21 04:35:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:35:18 --> Config Class Initialized
INFO - 2024-03-21 04:35:18 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:35:18 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:35:18 --> Utf8 Class Initialized
INFO - 2024-03-21 04:35:18 --> URI Class Initialized
INFO - 2024-03-21 04:35:18 --> Router Class Initialized
INFO - 2024-03-21 04:35:18 --> Output Class Initialized
INFO - 2024-03-21 04:35:18 --> Security Class Initialized
DEBUG - 2024-03-21 04:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:35:18 --> Input Class Initialized
INFO - 2024-03-21 04:35:18 --> Language Class Initialized
INFO - 2024-03-21 04:35:18 --> Loader Class Initialized
INFO - 2024-03-21 04:35:18 --> Helper loaded: url_helper
INFO - 2024-03-21 04:35:18 --> Helper loaded: file_helper
INFO - 2024-03-21 04:35:18 --> Helper loaded: html_helper
INFO - 2024-03-21 04:35:18 --> Helper loaded: text_helper
INFO - 2024-03-21 04:35:18 --> Helper loaded: form_helper
INFO - 2024-03-21 04:35:18 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:35:18 --> Helper loaded: security_helper
INFO - 2024-03-21 04:35:18 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:35:18 --> Database Driver Class Initialized
INFO - 2024-03-21 04:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:35:18 --> Parser Class Initialized
INFO - 2024-03-21 04:35:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:35:18 --> Pagination Class Initialized
INFO - 2024-03-21 04:35:18 --> Form Validation Class Initialized
INFO - 2024-03-21 04:35:18 --> Controller Class Initialized
INFO - 2024-03-21 04:35:18 --> Model Class Initialized
DEBUG - 2024-03-21 04:35:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:35:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:35:18 --> Model Class Initialized
DEBUG - 2024-03-21 04:35:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:35:18 --> Model Class Initialized
INFO - 2024-03-21 04:35:18 --> Final output sent to browser
DEBUG - 2024-03-21 04:35:18 --> Total execution time: 0.0421
ERROR - 2024-03-21 04:35:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:35:46 --> Config Class Initialized
INFO - 2024-03-21 04:35:46 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:35:46 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:35:46 --> Utf8 Class Initialized
INFO - 2024-03-21 04:35:46 --> URI Class Initialized
INFO - 2024-03-21 04:35:46 --> Router Class Initialized
INFO - 2024-03-21 04:35:46 --> Output Class Initialized
INFO - 2024-03-21 04:35:46 --> Security Class Initialized
DEBUG - 2024-03-21 04:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:35:46 --> Input Class Initialized
INFO - 2024-03-21 04:35:46 --> Language Class Initialized
INFO - 2024-03-21 04:35:46 --> Loader Class Initialized
INFO - 2024-03-21 04:35:46 --> Helper loaded: url_helper
INFO - 2024-03-21 04:35:46 --> Helper loaded: file_helper
INFO - 2024-03-21 04:35:46 --> Helper loaded: html_helper
INFO - 2024-03-21 04:35:46 --> Helper loaded: text_helper
INFO - 2024-03-21 04:35:46 --> Helper loaded: form_helper
INFO - 2024-03-21 04:35:46 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:35:46 --> Helper loaded: security_helper
INFO - 2024-03-21 04:35:46 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:35:46 --> Database Driver Class Initialized
INFO - 2024-03-21 04:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:35:46 --> Parser Class Initialized
INFO - 2024-03-21 04:35:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:35:46 --> Pagination Class Initialized
INFO - 2024-03-21 04:35:46 --> Form Validation Class Initialized
INFO - 2024-03-21 04:35:46 --> Controller Class Initialized
INFO - 2024-03-21 04:35:46 --> Model Class Initialized
DEBUG - 2024-03-21 04:35:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:35:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:35:46 --> Model Class Initialized
DEBUG - 2024-03-21 04:35:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:35:46 --> Model Class Initialized
INFO - 2024-03-21 04:35:46 --> Final output sent to browser
DEBUG - 2024-03-21 04:35:46 --> Total execution time: 0.0744
ERROR - 2024-03-21 04:39:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:39:35 --> Config Class Initialized
INFO - 2024-03-21 04:39:35 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:39:35 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:39:35 --> Utf8 Class Initialized
INFO - 2024-03-21 04:39:35 --> URI Class Initialized
INFO - 2024-03-21 04:39:35 --> Router Class Initialized
INFO - 2024-03-21 04:39:35 --> Output Class Initialized
INFO - 2024-03-21 04:39:35 --> Security Class Initialized
DEBUG - 2024-03-21 04:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:39:35 --> Input Class Initialized
INFO - 2024-03-21 04:39:35 --> Language Class Initialized
INFO - 2024-03-21 04:39:35 --> Loader Class Initialized
INFO - 2024-03-21 04:39:35 --> Helper loaded: url_helper
INFO - 2024-03-21 04:39:35 --> Helper loaded: file_helper
INFO - 2024-03-21 04:39:35 --> Helper loaded: html_helper
INFO - 2024-03-21 04:39:35 --> Helper loaded: text_helper
INFO - 2024-03-21 04:39:35 --> Helper loaded: form_helper
INFO - 2024-03-21 04:39:35 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:39:35 --> Helper loaded: security_helper
INFO - 2024-03-21 04:39:35 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:39:35 --> Database Driver Class Initialized
INFO - 2024-03-21 04:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:39:35 --> Parser Class Initialized
INFO - 2024-03-21 04:39:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:39:35 --> Pagination Class Initialized
INFO - 2024-03-21 04:39:35 --> Form Validation Class Initialized
INFO - 2024-03-21 04:39:35 --> Controller Class Initialized
INFO - 2024-03-21 04:39:35 --> Model Class Initialized
DEBUG - 2024-03-21 04:39:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:39:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:39:35 --> Model Class Initialized
DEBUG - 2024-03-21 04:39:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:39:35 --> Model Class Initialized
INFO - 2024-03-21 04:39:35 --> Final output sent to browser
DEBUG - 2024-03-21 04:39:35 --> Total execution time: 0.0249
ERROR - 2024-03-21 04:39:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:39:47 --> Config Class Initialized
INFO - 2024-03-21 04:39:47 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:39:47 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:39:47 --> Utf8 Class Initialized
INFO - 2024-03-21 04:39:47 --> URI Class Initialized
INFO - 2024-03-21 04:39:47 --> Router Class Initialized
INFO - 2024-03-21 04:39:47 --> Output Class Initialized
INFO - 2024-03-21 04:39:47 --> Security Class Initialized
DEBUG - 2024-03-21 04:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:39:47 --> Input Class Initialized
INFO - 2024-03-21 04:39:47 --> Language Class Initialized
INFO - 2024-03-21 04:39:47 --> Loader Class Initialized
INFO - 2024-03-21 04:39:47 --> Helper loaded: url_helper
INFO - 2024-03-21 04:39:47 --> Helper loaded: file_helper
INFO - 2024-03-21 04:39:47 --> Helper loaded: html_helper
INFO - 2024-03-21 04:39:47 --> Helper loaded: text_helper
INFO - 2024-03-21 04:39:47 --> Helper loaded: form_helper
INFO - 2024-03-21 04:39:47 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:39:47 --> Helper loaded: security_helper
INFO - 2024-03-21 04:39:47 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:39:47 --> Database Driver Class Initialized
INFO - 2024-03-21 04:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:39:47 --> Parser Class Initialized
INFO - 2024-03-21 04:39:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:39:47 --> Pagination Class Initialized
INFO - 2024-03-21 04:39:47 --> Form Validation Class Initialized
INFO - 2024-03-21 04:39:47 --> Controller Class Initialized
INFO - 2024-03-21 04:39:47 --> Model Class Initialized
DEBUG - 2024-03-21 04:39:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:39:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:39:47 --> Model Class Initialized
DEBUG - 2024-03-21 04:39:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:39:47 --> Model Class Initialized
INFO - 2024-03-21 04:39:47 --> Final output sent to browser
DEBUG - 2024-03-21 04:39:47 --> Total execution time: 0.0486
ERROR - 2024-03-21 04:40:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:40:00 --> Config Class Initialized
INFO - 2024-03-21 04:40:00 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:40:00 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:40:00 --> Utf8 Class Initialized
INFO - 2024-03-21 04:40:00 --> URI Class Initialized
DEBUG - 2024-03-21 04:40:00 --> No URI present. Default controller set.
INFO - 2024-03-21 04:40:00 --> Router Class Initialized
INFO - 2024-03-21 04:40:00 --> Output Class Initialized
INFO - 2024-03-21 04:40:00 --> Security Class Initialized
DEBUG - 2024-03-21 04:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:40:00 --> Input Class Initialized
INFO - 2024-03-21 04:40:00 --> Language Class Initialized
INFO - 2024-03-21 04:40:00 --> Loader Class Initialized
INFO - 2024-03-21 04:40:00 --> Helper loaded: url_helper
INFO - 2024-03-21 04:40:00 --> Helper loaded: file_helper
INFO - 2024-03-21 04:40:00 --> Helper loaded: html_helper
INFO - 2024-03-21 04:40:00 --> Helper loaded: text_helper
INFO - 2024-03-21 04:40:00 --> Helper loaded: form_helper
INFO - 2024-03-21 04:40:00 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:40:00 --> Helper loaded: security_helper
INFO - 2024-03-21 04:40:00 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:40:00 --> Database Driver Class Initialized
INFO - 2024-03-21 04:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:40:00 --> Parser Class Initialized
INFO - 2024-03-21 04:40:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:40:00 --> Pagination Class Initialized
INFO - 2024-03-21 04:40:00 --> Form Validation Class Initialized
INFO - 2024-03-21 04:40:00 --> Controller Class Initialized
INFO - 2024-03-21 04:40:00 --> Model Class Initialized
DEBUG - 2024-03-21 04:40:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:40:00 --> Model Class Initialized
DEBUG - 2024-03-21 04:40:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:40:00 --> Model Class Initialized
INFO - 2024-03-21 04:40:00 --> Model Class Initialized
INFO - 2024-03-21 04:40:00 --> Model Class Initialized
INFO - 2024-03-21 04:40:00 --> Model Class Initialized
DEBUG - 2024-03-21 04:40:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:40:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:40:00 --> Model Class Initialized
INFO - 2024-03-21 04:40:00 --> Model Class Initialized
INFO - 2024-03-21 04:40:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-21 04:40:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:40:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 04:40:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 04:40:00 --> Model Class Initialized
INFO - 2024-03-21 04:40:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-21 04:40:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-21 04:40:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 04:40:00 --> Final output sent to browser
DEBUG - 2024-03-21 04:40:00 --> Total execution time: 0.2533
ERROR - 2024-03-21 04:41:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:41:36 --> Config Class Initialized
INFO - 2024-03-21 04:41:36 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:41:36 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:41:36 --> Utf8 Class Initialized
INFO - 2024-03-21 04:41:36 --> URI Class Initialized
INFO - 2024-03-21 04:41:36 --> Router Class Initialized
INFO - 2024-03-21 04:41:36 --> Output Class Initialized
INFO - 2024-03-21 04:41:36 --> Security Class Initialized
DEBUG - 2024-03-21 04:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:41:36 --> Input Class Initialized
INFO - 2024-03-21 04:41:36 --> Language Class Initialized
INFO - 2024-03-21 04:41:36 --> Loader Class Initialized
INFO - 2024-03-21 04:41:36 --> Helper loaded: url_helper
INFO - 2024-03-21 04:41:36 --> Helper loaded: file_helper
INFO - 2024-03-21 04:41:36 --> Helper loaded: html_helper
INFO - 2024-03-21 04:41:36 --> Helper loaded: text_helper
INFO - 2024-03-21 04:41:36 --> Helper loaded: form_helper
INFO - 2024-03-21 04:41:36 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:41:36 --> Helper loaded: security_helper
INFO - 2024-03-21 04:41:36 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:41:36 --> Database Driver Class Initialized
INFO - 2024-03-21 04:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:41:36 --> Parser Class Initialized
INFO - 2024-03-21 04:41:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:41:36 --> Pagination Class Initialized
INFO - 2024-03-21 04:41:36 --> Form Validation Class Initialized
INFO - 2024-03-21 04:41:36 --> Controller Class Initialized
INFO - 2024-03-21 04:41:36 --> Model Class Initialized
DEBUG - 2024-03-21 04:41:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:41:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:41:36 --> Model Class Initialized
DEBUG - 2024-03-21 04:41:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:41:36 --> Model Class Initialized
INFO - 2024-03-21 04:41:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-21 04:41:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:41:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 04:41:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 04:41:36 --> Model Class Initialized
INFO - 2024-03-21 04:41:37 --> Model Class Initialized
INFO - 2024-03-21 04:41:37 --> Model Class Initialized
INFO - 2024-03-21 04:41:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-21 04:41:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-21 04:41:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 04:41:37 --> Final output sent to browser
DEBUG - 2024-03-21 04:41:37 --> Total execution time: 0.1651
ERROR - 2024-03-21 04:41:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:41:38 --> Config Class Initialized
INFO - 2024-03-21 04:41:38 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:41:38 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:41:38 --> Utf8 Class Initialized
INFO - 2024-03-21 04:41:38 --> URI Class Initialized
INFO - 2024-03-21 04:41:38 --> Router Class Initialized
INFO - 2024-03-21 04:41:38 --> Output Class Initialized
INFO - 2024-03-21 04:41:38 --> Security Class Initialized
DEBUG - 2024-03-21 04:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:41:38 --> Input Class Initialized
INFO - 2024-03-21 04:41:38 --> Language Class Initialized
INFO - 2024-03-21 04:41:38 --> Loader Class Initialized
INFO - 2024-03-21 04:41:38 --> Helper loaded: url_helper
INFO - 2024-03-21 04:41:38 --> Helper loaded: file_helper
INFO - 2024-03-21 04:41:38 --> Helper loaded: html_helper
INFO - 2024-03-21 04:41:38 --> Helper loaded: text_helper
INFO - 2024-03-21 04:41:38 --> Helper loaded: form_helper
INFO - 2024-03-21 04:41:38 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:41:38 --> Helper loaded: security_helper
INFO - 2024-03-21 04:41:38 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:41:38 --> Database Driver Class Initialized
INFO - 2024-03-21 04:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:41:38 --> Parser Class Initialized
INFO - 2024-03-21 04:41:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:41:38 --> Pagination Class Initialized
INFO - 2024-03-21 04:41:38 --> Form Validation Class Initialized
INFO - 2024-03-21 04:41:38 --> Controller Class Initialized
INFO - 2024-03-21 04:41:38 --> Model Class Initialized
DEBUG - 2024-03-21 04:41:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:41:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:41:38 --> Model Class Initialized
DEBUG - 2024-03-21 04:41:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:41:38 --> Model Class Initialized
INFO - 2024-03-21 04:41:38 --> Final output sent to browser
DEBUG - 2024-03-21 04:41:38 --> Total execution time: 0.0425
ERROR - 2024-03-21 04:41:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:41:53 --> Config Class Initialized
INFO - 2024-03-21 04:41:53 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:41:53 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:41:53 --> Utf8 Class Initialized
INFO - 2024-03-21 04:41:53 --> URI Class Initialized
INFO - 2024-03-21 04:41:53 --> Router Class Initialized
INFO - 2024-03-21 04:41:53 --> Output Class Initialized
INFO - 2024-03-21 04:41:53 --> Security Class Initialized
DEBUG - 2024-03-21 04:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:41:53 --> Input Class Initialized
INFO - 2024-03-21 04:41:53 --> Language Class Initialized
INFO - 2024-03-21 04:41:53 --> Loader Class Initialized
INFO - 2024-03-21 04:41:53 --> Helper loaded: url_helper
INFO - 2024-03-21 04:41:54 --> Helper loaded: file_helper
INFO - 2024-03-21 04:41:54 --> Helper loaded: html_helper
INFO - 2024-03-21 04:41:54 --> Helper loaded: text_helper
INFO - 2024-03-21 04:41:54 --> Helper loaded: form_helper
INFO - 2024-03-21 04:41:54 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:41:54 --> Helper loaded: security_helper
INFO - 2024-03-21 04:41:54 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:41:54 --> Database Driver Class Initialized
INFO - 2024-03-21 04:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:41:54 --> Parser Class Initialized
INFO - 2024-03-21 04:41:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:41:54 --> Pagination Class Initialized
INFO - 2024-03-21 04:41:54 --> Form Validation Class Initialized
INFO - 2024-03-21 04:41:54 --> Controller Class Initialized
INFO - 2024-03-21 04:41:54 --> Model Class Initialized
DEBUG - 2024-03-21 04:41:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:41:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:41:54 --> Model Class Initialized
DEBUG - 2024-03-21 04:41:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:41:54 --> Model Class Initialized
INFO - 2024-03-21 04:41:54 --> Final output sent to browser
DEBUG - 2024-03-21 04:41:54 --> Total execution time: 0.0473
ERROR - 2024-03-21 04:42:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:42:01 --> Config Class Initialized
INFO - 2024-03-21 04:42:01 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:42:01 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:42:01 --> Utf8 Class Initialized
INFO - 2024-03-21 04:42:01 --> URI Class Initialized
INFO - 2024-03-21 04:42:01 --> Router Class Initialized
INFO - 2024-03-21 04:42:01 --> Output Class Initialized
INFO - 2024-03-21 04:42:01 --> Security Class Initialized
DEBUG - 2024-03-21 04:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:42:01 --> Input Class Initialized
INFO - 2024-03-21 04:42:01 --> Language Class Initialized
INFO - 2024-03-21 04:42:01 --> Loader Class Initialized
INFO - 2024-03-21 04:42:01 --> Helper loaded: url_helper
INFO - 2024-03-21 04:42:01 --> Helper loaded: file_helper
INFO - 2024-03-21 04:42:01 --> Helper loaded: html_helper
INFO - 2024-03-21 04:42:01 --> Helper loaded: text_helper
INFO - 2024-03-21 04:42:01 --> Helper loaded: form_helper
INFO - 2024-03-21 04:42:01 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:42:01 --> Helper loaded: security_helper
INFO - 2024-03-21 04:42:01 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:42:01 --> Database Driver Class Initialized
INFO - 2024-03-21 04:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:42:01 --> Parser Class Initialized
INFO - 2024-03-21 04:42:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:42:01 --> Pagination Class Initialized
INFO - 2024-03-21 04:42:01 --> Form Validation Class Initialized
INFO - 2024-03-21 04:42:01 --> Controller Class Initialized
INFO - 2024-03-21 04:42:01 --> Model Class Initialized
DEBUG - 2024-03-21 04:42:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:42:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:42:01 --> Model Class Initialized
DEBUG - 2024-03-21 04:42:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:42:01 --> Model Class Initialized
INFO - 2024-03-21 04:42:01 --> Final output sent to browser
DEBUG - 2024-03-21 04:42:01 --> Total execution time: 0.0681
ERROR - 2024-03-21 04:43:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:43:05 --> Config Class Initialized
INFO - 2024-03-21 04:43:05 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:43:05 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:43:05 --> Utf8 Class Initialized
INFO - 2024-03-21 04:43:05 --> URI Class Initialized
DEBUG - 2024-03-21 04:43:05 --> No URI present. Default controller set.
INFO - 2024-03-21 04:43:05 --> Router Class Initialized
INFO - 2024-03-21 04:43:05 --> Output Class Initialized
INFO - 2024-03-21 04:43:05 --> Security Class Initialized
DEBUG - 2024-03-21 04:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:43:05 --> Input Class Initialized
INFO - 2024-03-21 04:43:05 --> Language Class Initialized
INFO - 2024-03-21 04:43:05 --> Loader Class Initialized
INFO - 2024-03-21 04:43:05 --> Helper loaded: url_helper
INFO - 2024-03-21 04:43:05 --> Helper loaded: file_helper
INFO - 2024-03-21 04:43:05 --> Helper loaded: html_helper
INFO - 2024-03-21 04:43:05 --> Helper loaded: text_helper
INFO - 2024-03-21 04:43:05 --> Helper loaded: form_helper
INFO - 2024-03-21 04:43:05 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:43:05 --> Helper loaded: security_helper
INFO - 2024-03-21 04:43:05 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:43:05 --> Database Driver Class Initialized
INFO - 2024-03-21 04:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:43:05 --> Parser Class Initialized
INFO - 2024-03-21 04:43:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:43:05 --> Pagination Class Initialized
INFO - 2024-03-21 04:43:05 --> Form Validation Class Initialized
INFO - 2024-03-21 04:43:05 --> Controller Class Initialized
INFO - 2024-03-21 04:43:05 --> Model Class Initialized
DEBUG - 2024-03-21 04:43:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:43:05 --> Model Class Initialized
DEBUG - 2024-03-21 04:43:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:43:05 --> Model Class Initialized
INFO - 2024-03-21 04:43:05 --> Model Class Initialized
INFO - 2024-03-21 04:43:05 --> Model Class Initialized
INFO - 2024-03-21 04:43:05 --> Model Class Initialized
DEBUG - 2024-03-21 04:43:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:43:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:43:05 --> Model Class Initialized
INFO - 2024-03-21 04:43:05 --> Model Class Initialized
INFO - 2024-03-21 04:43:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-21 04:43:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:43:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 04:43:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 04:43:05 --> Model Class Initialized
INFO - 2024-03-21 04:43:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-21 04:43:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-21 04:43:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 04:43:05 --> Final output sent to browser
DEBUG - 2024-03-21 04:43:05 --> Total execution time: 0.2626
ERROR - 2024-03-21 04:43:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:43:10 --> Config Class Initialized
INFO - 2024-03-21 04:43:10 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:43:10 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:43:10 --> Utf8 Class Initialized
INFO - 2024-03-21 04:43:10 --> URI Class Initialized
INFO - 2024-03-21 04:43:10 --> Router Class Initialized
INFO - 2024-03-21 04:43:10 --> Output Class Initialized
INFO - 2024-03-21 04:43:10 --> Security Class Initialized
DEBUG - 2024-03-21 04:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:43:10 --> Input Class Initialized
INFO - 2024-03-21 04:43:10 --> Language Class Initialized
INFO - 2024-03-21 04:43:10 --> Loader Class Initialized
INFO - 2024-03-21 04:43:10 --> Helper loaded: url_helper
INFO - 2024-03-21 04:43:10 --> Helper loaded: file_helper
INFO - 2024-03-21 04:43:10 --> Helper loaded: html_helper
INFO - 2024-03-21 04:43:10 --> Helper loaded: text_helper
INFO - 2024-03-21 04:43:10 --> Helper loaded: form_helper
INFO - 2024-03-21 04:43:10 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:43:10 --> Helper loaded: security_helper
INFO - 2024-03-21 04:43:10 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:43:10 --> Database Driver Class Initialized
INFO - 2024-03-21 04:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:43:10 --> Parser Class Initialized
INFO - 2024-03-21 04:43:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:43:10 --> Pagination Class Initialized
INFO - 2024-03-21 04:43:10 --> Form Validation Class Initialized
INFO - 2024-03-21 04:43:10 --> Controller Class Initialized
INFO - 2024-03-21 04:43:10 --> Model Class Initialized
DEBUG - 2024-03-21 04:43:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:43:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:43:10 --> Model Class Initialized
INFO - 2024-03-21 04:43:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2024-03-21 04:43:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:43:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 04:43:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 04:43:10 --> Model Class Initialized
INFO - 2024-03-21 04:43:10 --> Model Class Initialized
INFO - 2024-03-21 04:43:10 --> Model Class Initialized
INFO - 2024-03-21 04:43:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-21 04:43:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-21 04:43:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 04:43:10 --> Final output sent to browser
DEBUG - 2024-03-21 04:43:10 --> Total execution time: 0.1601
ERROR - 2024-03-21 04:43:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:43:11 --> Config Class Initialized
INFO - 2024-03-21 04:43:11 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:43:11 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:43:11 --> Utf8 Class Initialized
INFO - 2024-03-21 04:43:11 --> URI Class Initialized
INFO - 2024-03-21 04:43:11 --> Router Class Initialized
INFO - 2024-03-21 04:43:11 --> Output Class Initialized
INFO - 2024-03-21 04:43:11 --> Security Class Initialized
DEBUG - 2024-03-21 04:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:43:11 --> Input Class Initialized
INFO - 2024-03-21 04:43:11 --> Language Class Initialized
INFO - 2024-03-21 04:43:11 --> Loader Class Initialized
INFO - 2024-03-21 04:43:11 --> Helper loaded: url_helper
INFO - 2024-03-21 04:43:11 --> Helper loaded: file_helper
INFO - 2024-03-21 04:43:11 --> Helper loaded: html_helper
INFO - 2024-03-21 04:43:11 --> Helper loaded: text_helper
INFO - 2024-03-21 04:43:11 --> Helper loaded: form_helper
INFO - 2024-03-21 04:43:11 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:43:11 --> Helper loaded: security_helper
INFO - 2024-03-21 04:43:11 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:43:11 --> Database Driver Class Initialized
INFO - 2024-03-21 04:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:43:11 --> Parser Class Initialized
INFO - 2024-03-21 04:43:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:43:11 --> Pagination Class Initialized
INFO - 2024-03-21 04:43:11 --> Form Validation Class Initialized
INFO - 2024-03-21 04:43:11 --> Controller Class Initialized
INFO - 2024-03-21 04:43:11 --> Model Class Initialized
DEBUG - 2024-03-21 04:43:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:43:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:43:11 --> Model Class Initialized
INFO - 2024-03-21 04:43:12 --> Final output sent to browser
DEBUG - 2024-03-21 04:43:12 --> Total execution time: 0.3538
ERROR - 2024-03-21 04:43:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:43:17 --> Config Class Initialized
INFO - 2024-03-21 04:43:17 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:43:17 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:43:17 --> Utf8 Class Initialized
INFO - 2024-03-21 04:43:17 --> URI Class Initialized
INFO - 2024-03-21 04:43:17 --> Router Class Initialized
INFO - 2024-03-21 04:43:17 --> Output Class Initialized
INFO - 2024-03-21 04:43:17 --> Security Class Initialized
DEBUG - 2024-03-21 04:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:43:17 --> Input Class Initialized
INFO - 2024-03-21 04:43:17 --> Language Class Initialized
INFO - 2024-03-21 04:43:17 --> Loader Class Initialized
INFO - 2024-03-21 04:43:17 --> Helper loaded: url_helper
INFO - 2024-03-21 04:43:17 --> Helper loaded: file_helper
INFO - 2024-03-21 04:43:17 --> Helper loaded: html_helper
INFO - 2024-03-21 04:43:17 --> Helper loaded: text_helper
INFO - 2024-03-21 04:43:17 --> Helper loaded: form_helper
INFO - 2024-03-21 04:43:17 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:43:17 --> Helper loaded: security_helper
INFO - 2024-03-21 04:43:17 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:43:17 --> Database Driver Class Initialized
INFO - 2024-03-21 04:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:43:17 --> Parser Class Initialized
INFO - 2024-03-21 04:43:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:43:17 --> Pagination Class Initialized
INFO - 2024-03-21 04:43:17 --> Form Validation Class Initialized
INFO - 2024-03-21 04:43:17 --> Controller Class Initialized
INFO - 2024-03-21 04:43:17 --> Model Class Initialized
DEBUG - 2024-03-21 04:43:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:43:17 --> Model Class Initialized
INFO - 2024-03-21 04:43:18 --> Final output sent to browser
DEBUG - 2024-03-21 04:43:18 --> Total execution time: 0.3744
ERROR - 2024-03-21 04:43:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:43:20 --> Config Class Initialized
INFO - 2024-03-21 04:43:20 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:43:20 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:43:20 --> Utf8 Class Initialized
INFO - 2024-03-21 04:43:20 --> URI Class Initialized
INFO - 2024-03-21 04:43:20 --> Router Class Initialized
INFO - 2024-03-21 04:43:20 --> Output Class Initialized
INFO - 2024-03-21 04:43:20 --> Security Class Initialized
DEBUG - 2024-03-21 04:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:43:20 --> Input Class Initialized
INFO - 2024-03-21 04:43:20 --> Language Class Initialized
INFO - 2024-03-21 04:43:20 --> Loader Class Initialized
INFO - 2024-03-21 04:43:20 --> Helper loaded: url_helper
INFO - 2024-03-21 04:43:20 --> Helper loaded: file_helper
INFO - 2024-03-21 04:43:20 --> Helper loaded: html_helper
INFO - 2024-03-21 04:43:20 --> Helper loaded: text_helper
INFO - 2024-03-21 04:43:20 --> Helper loaded: form_helper
INFO - 2024-03-21 04:43:20 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:43:20 --> Helper loaded: security_helper
INFO - 2024-03-21 04:43:20 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:43:20 --> Database Driver Class Initialized
INFO - 2024-03-21 04:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:43:20 --> Parser Class Initialized
INFO - 2024-03-21 04:43:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:43:20 --> Pagination Class Initialized
INFO - 2024-03-21 04:43:20 --> Form Validation Class Initialized
INFO - 2024-03-21 04:43:20 --> Controller Class Initialized
INFO - 2024-03-21 04:43:20 --> Model Class Initialized
DEBUG - 2024-03-21 04:43:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:43:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:43:20 --> Model Class Initialized
INFO - 2024-03-21 04:43:20 --> Final output sent to browser
DEBUG - 2024-03-21 04:43:20 --> Total execution time: 0.3780
ERROR - 2024-03-21 04:46:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:46:16 --> Config Class Initialized
INFO - 2024-03-21 04:46:16 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:46:16 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:46:16 --> Utf8 Class Initialized
INFO - 2024-03-21 04:46:16 --> URI Class Initialized
DEBUG - 2024-03-21 04:46:16 --> No URI present. Default controller set.
INFO - 2024-03-21 04:46:16 --> Router Class Initialized
INFO - 2024-03-21 04:46:16 --> Output Class Initialized
INFO - 2024-03-21 04:46:16 --> Security Class Initialized
DEBUG - 2024-03-21 04:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:46:16 --> Input Class Initialized
INFO - 2024-03-21 04:46:16 --> Language Class Initialized
INFO - 2024-03-21 04:46:16 --> Loader Class Initialized
INFO - 2024-03-21 04:46:16 --> Helper loaded: url_helper
INFO - 2024-03-21 04:46:16 --> Helper loaded: file_helper
INFO - 2024-03-21 04:46:16 --> Helper loaded: html_helper
INFO - 2024-03-21 04:46:16 --> Helper loaded: text_helper
INFO - 2024-03-21 04:46:16 --> Helper loaded: form_helper
INFO - 2024-03-21 04:46:16 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:46:16 --> Helper loaded: security_helper
INFO - 2024-03-21 04:46:16 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:46:16 --> Database Driver Class Initialized
INFO - 2024-03-21 04:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:46:16 --> Parser Class Initialized
INFO - 2024-03-21 04:46:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:46:16 --> Pagination Class Initialized
INFO - 2024-03-21 04:46:16 --> Form Validation Class Initialized
INFO - 2024-03-21 04:46:16 --> Controller Class Initialized
INFO - 2024-03-21 04:46:16 --> Model Class Initialized
DEBUG - 2024-03-21 04:46:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:46:16 --> Model Class Initialized
DEBUG - 2024-03-21 04:46:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:46:16 --> Model Class Initialized
INFO - 2024-03-21 04:46:16 --> Model Class Initialized
INFO - 2024-03-21 04:46:16 --> Model Class Initialized
INFO - 2024-03-21 04:46:16 --> Model Class Initialized
DEBUG - 2024-03-21 04:46:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:46:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:46:16 --> Model Class Initialized
INFO - 2024-03-21 04:46:16 --> Model Class Initialized
INFO - 2024-03-21 04:46:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-21 04:46:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:46:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 04:46:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 04:46:16 --> Model Class Initialized
INFO - 2024-03-21 04:46:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-21 04:46:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-21 04:46:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 04:46:16 --> Final output sent to browser
DEBUG - 2024-03-21 04:46:16 --> Total execution time: 0.2856
ERROR - 2024-03-21 04:46:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:46:41 --> Config Class Initialized
INFO - 2024-03-21 04:46:41 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:46:41 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:46:41 --> Utf8 Class Initialized
INFO - 2024-03-21 04:46:41 --> URI Class Initialized
INFO - 2024-03-21 04:46:41 --> Router Class Initialized
INFO - 2024-03-21 04:46:41 --> Output Class Initialized
INFO - 2024-03-21 04:46:41 --> Security Class Initialized
DEBUG - 2024-03-21 04:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:46:41 --> Input Class Initialized
INFO - 2024-03-21 04:46:41 --> Language Class Initialized
INFO - 2024-03-21 04:46:41 --> Loader Class Initialized
INFO - 2024-03-21 04:46:41 --> Helper loaded: url_helper
INFO - 2024-03-21 04:46:41 --> Helper loaded: file_helper
INFO - 2024-03-21 04:46:41 --> Helper loaded: html_helper
INFO - 2024-03-21 04:46:41 --> Helper loaded: text_helper
INFO - 2024-03-21 04:46:41 --> Helper loaded: form_helper
INFO - 2024-03-21 04:46:41 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:46:41 --> Helper loaded: security_helper
INFO - 2024-03-21 04:46:41 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:46:41 --> Database Driver Class Initialized
INFO - 2024-03-21 04:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:46:41 --> Parser Class Initialized
INFO - 2024-03-21 04:46:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:46:41 --> Pagination Class Initialized
INFO - 2024-03-21 04:46:41 --> Form Validation Class Initialized
INFO - 2024-03-21 04:46:41 --> Controller Class Initialized
INFO - 2024-03-21 04:46:41 --> Model Class Initialized
DEBUG - 2024-03-21 04:46:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:46:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:46:41 --> Model Class Initialized
DEBUG - 2024-03-21 04:46:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:46:41 --> Model Class Initialized
INFO - 2024-03-21 04:46:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-21 04:46:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:46:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 04:46:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 04:46:41 --> Model Class Initialized
INFO - 2024-03-21 04:46:41 --> Model Class Initialized
INFO - 2024-03-21 04:46:41 --> Model Class Initialized
INFO - 2024-03-21 04:46:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-21 04:46:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-21 04:46:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 04:46:41 --> Final output sent to browser
DEBUG - 2024-03-21 04:46:41 --> Total execution time: 0.1617
ERROR - 2024-03-21 04:46:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:46:43 --> Config Class Initialized
INFO - 2024-03-21 04:46:43 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:46:43 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:46:43 --> Utf8 Class Initialized
INFO - 2024-03-21 04:46:43 --> URI Class Initialized
INFO - 2024-03-21 04:46:43 --> Router Class Initialized
INFO - 2024-03-21 04:46:43 --> Output Class Initialized
INFO - 2024-03-21 04:46:43 --> Security Class Initialized
DEBUG - 2024-03-21 04:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:46:43 --> Input Class Initialized
INFO - 2024-03-21 04:46:43 --> Language Class Initialized
INFO - 2024-03-21 04:46:43 --> Loader Class Initialized
INFO - 2024-03-21 04:46:43 --> Helper loaded: url_helper
INFO - 2024-03-21 04:46:43 --> Helper loaded: file_helper
INFO - 2024-03-21 04:46:43 --> Helper loaded: html_helper
INFO - 2024-03-21 04:46:43 --> Helper loaded: text_helper
INFO - 2024-03-21 04:46:43 --> Helper loaded: form_helper
INFO - 2024-03-21 04:46:43 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:46:43 --> Helper loaded: security_helper
INFO - 2024-03-21 04:46:43 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:46:43 --> Database Driver Class Initialized
INFO - 2024-03-21 04:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:46:43 --> Parser Class Initialized
INFO - 2024-03-21 04:46:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:46:43 --> Pagination Class Initialized
INFO - 2024-03-21 04:46:43 --> Form Validation Class Initialized
INFO - 2024-03-21 04:46:43 --> Controller Class Initialized
INFO - 2024-03-21 04:46:43 --> Model Class Initialized
DEBUG - 2024-03-21 04:46:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:46:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:46:43 --> Model Class Initialized
DEBUG - 2024-03-21 04:46:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:46:43 --> Model Class Initialized
INFO - 2024-03-21 04:46:43 --> Final output sent to browser
DEBUG - 2024-03-21 04:46:43 --> Total execution time: 0.0470
ERROR - 2024-03-21 04:46:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:46:54 --> Config Class Initialized
INFO - 2024-03-21 04:46:54 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:46:54 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:46:54 --> Utf8 Class Initialized
INFO - 2024-03-21 04:46:54 --> URI Class Initialized
INFO - 2024-03-21 04:46:54 --> Router Class Initialized
INFO - 2024-03-21 04:46:54 --> Output Class Initialized
INFO - 2024-03-21 04:46:54 --> Security Class Initialized
DEBUG - 2024-03-21 04:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:46:54 --> Input Class Initialized
INFO - 2024-03-21 04:46:54 --> Language Class Initialized
INFO - 2024-03-21 04:46:54 --> Loader Class Initialized
INFO - 2024-03-21 04:46:54 --> Helper loaded: url_helper
INFO - 2024-03-21 04:46:54 --> Helper loaded: file_helper
INFO - 2024-03-21 04:46:54 --> Helper loaded: html_helper
INFO - 2024-03-21 04:46:54 --> Helper loaded: text_helper
INFO - 2024-03-21 04:46:54 --> Helper loaded: form_helper
INFO - 2024-03-21 04:46:54 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:46:54 --> Helper loaded: security_helper
INFO - 2024-03-21 04:46:54 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:46:54 --> Database Driver Class Initialized
INFO - 2024-03-21 04:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:46:54 --> Parser Class Initialized
INFO - 2024-03-21 04:46:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:46:54 --> Pagination Class Initialized
INFO - 2024-03-21 04:46:54 --> Form Validation Class Initialized
INFO - 2024-03-21 04:46:54 --> Controller Class Initialized
INFO - 2024-03-21 04:46:54 --> Model Class Initialized
DEBUG - 2024-03-21 04:46:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:46:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:46:54 --> Model Class Initialized
DEBUG - 2024-03-21 04:46:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:46:54 --> Model Class Initialized
DEBUG - 2024-03-21 04:46:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:46:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-03-21 04:46:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:46:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 04:46:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 04:46:54 --> Model Class Initialized
INFO - 2024-03-21 04:46:54 --> Model Class Initialized
INFO - 2024-03-21 04:46:54 --> Model Class Initialized
INFO - 2024-03-21 04:46:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-21 04:46:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-21 04:46:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 04:46:54 --> Final output sent to browser
DEBUG - 2024-03-21 04:46:54 --> Total execution time: 0.1779
ERROR - 2024-03-21 04:46:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:46:58 --> Config Class Initialized
INFO - 2024-03-21 04:46:58 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:46:58 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:46:58 --> Utf8 Class Initialized
INFO - 2024-03-21 04:46:58 --> URI Class Initialized
INFO - 2024-03-21 04:46:58 --> Router Class Initialized
INFO - 2024-03-21 04:46:58 --> Output Class Initialized
INFO - 2024-03-21 04:46:58 --> Security Class Initialized
DEBUG - 2024-03-21 04:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:46:58 --> Input Class Initialized
INFO - 2024-03-21 04:46:58 --> Language Class Initialized
INFO - 2024-03-21 04:46:58 --> Loader Class Initialized
INFO - 2024-03-21 04:46:58 --> Helper loaded: url_helper
INFO - 2024-03-21 04:46:58 --> Helper loaded: file_helper
INFO - 2024-03-21 04:46:58 --> Helper loaded: html_helper
INFO - 2024-03-21 04:46:58 --> Helper loaded: text_helper
INFO - 2024-03-21 04:46:58 --> Helper loaded: form_helper
INFO - 2024-03-21 04:46:58 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:46:58 --> Helper loaded: security_helper
INFO - 2024-03-21 04:46:58 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:46:58 --> Database Driver Class Initialized
INFO - 2024-03-21 04:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:46:58 --> Parser Class Initialized
INFO - 2024-03-21 04:46:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:46:58 --> Pagination Class Initialized
INFO - 2024-03-21 04:46:58 --> Form Validation Class Initialized
INFO - 2024-03-21 04:46:58 --> Controller Class Initialized
INFO - 2024-03-21 04:46:58 --> Model Class Initialized
DEBUG - 2024-03-21 04:46:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:46:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:46:58 --> Model Class Initialized
DEBUG - 2024-03-21 04:46:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:46:58 --> Model Class Initialized
INFO - 2024-03-21 04:46:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-21 04:46:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:46:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 04:46:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 04:46:58 --> Model Class Initialized
INFO - 2024-03-21 04:46:58 --> Model Class Initialized
INFO - 2024-03-21 04:46:58 --> Model Class Initialized
INFO - 2024-03-21 04:46:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-21 04:46:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-21 04:46:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 04:46:58 --> Final output sent to browser
DEBUG - 2024-03-21 04:46:58 --> Total execution time: 0.1659
ERROR - 2024-03-21 04:47:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:47:00 --> Config Class Initialized
INFO - 2024-03-21 04:47:00 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:47:00 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:47:00 --> Utf8 Class Initialized
INFO - 2024-03-21 04:47:00 --> URI Class Initialized
INFO - 2024-03-21 04:47:00 --> Router Class Initialized
INFO - 2024-03-21 04:47:00 --> Output Class Initialized
INFO - 2024-03-21 04:47:00 --> Security Class Initialized
DEBUG - 2024-03-21 04:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:47:00 --> Input Class Initialized
INFO - 2024-03-21 04:47:00 --> Language Class Initialized
INFO - 2024-03-21 04:47:00 --> Loader Class Initialized
INFO - 2024-03-21 04:47:00 --> Helper loaded: url_helper
INFO - 2024-03-21 04:47:00 --> Helper loaded: file_helper
INFO - 2024-03-21 04:47:00 --> Helper loaded: html_helper
INFO - 2024-03-21 04:47:00 --> Helper loaded: text_helper
INFO - 2024-03-21 04:47:00 --> Helper loaded: form_helper
INFO - 2024-03-21 04:47:00 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:47:00 --> Helper loaded: security_helper
INFO - 2024-03-21 04:47:00 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:47:00 --> Database Driver Class Initialized
INFO - 2024-03-21 04:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:47:00 --> Parser Class Initialized
INFO - 2024-03-21 04:47:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:47:00 --> Pagination Class Initialized
INFO - 2024-03-21 04:47:00 --> Form Validation Class Initialized
INFO - 2024-03-21 04:47:00 --> Controller Class Initialized
INFO - 2024-03-21 04:47:00 --> Model Class Initialized
DEBUG - 2024-03-21 04:47:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:47:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:47:00 --> Model Class Initialized
DEBUG - 2024-03-21 04:47:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:47:00 --> Model Class Initialized
INFO - 2024-03-21 04:47:00 --> Final output sent to browser
DEBUG - 2024-03-21 04:47:00 --> Total execution time: 0.0416
ERROR - 2024-03-21 04:47:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:47:04 --> Config Class Initialized
INFO - 2024-03-21 04:47:04 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:47:04 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:47:04 --> Utf8 Class Initialized
INFO - 2024-03-21 04:47:04 --> URI Class Initialized
INFO - 2024-03-21 04:47:04 --> Router Class Initialized
INFO - 2024-03-21 04:47:04 --> Output Class Initialized
INFO - 2024-03-21 04:47:04 --> Security Class Initialized
DEBUG - 2024-03-21 04:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:47:04 --> Input Class Initialized
INFO - 2024-03-21 04:47:04 --> Language Class Initialized
INFO - 2024-03-21 04:47:04 --> Loader Class Initialized
INFO - 2024-03-21 04:47:04 --> Helper loaded: url_helper
INFO - 2024-03-21 04:47:04 --> Helper loaded: file_helper
INFO - 2024-03-21 04:47:04 --> Helper loaded: html_helper
INFO - 2024-03-21 04:47:04 --> Helper loaded: text_helper
INFO - 2024-03-21 04:47:04 --> Helper loaded: form_helper
INFO - 2024-03-21 04:47:04 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:47:04 --> Helper loaded: security_helper
INFO - 2024-03-21 04:47:04 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:47:04 --> Database Driver Class Initialized
INFO - 2024-03-21 04:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:47:04 --> Parser Class Initialized
INFO - 2024-03-21 04:47:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:47:04 --> Pagination Class Initialized
INFO - 2024-03-21 04:47:04 --> Form Validation Class Initialized
INFO - 2024-03-21 04:47:04 --> Controller Class Initialized
INFO - 2024-03-21 04:47:04 --> Model Class Initialized
DEBUG - 2024-03-21 04:47:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:47:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:47:04 --> Model Class Initialized
DEBUG - 2024-03-21 04:47:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:47:04 --> Model Class Initialized
DEBUG - 2024-03-21 04:47:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:47:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-03-21 04:47:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:47:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 04:47:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 04:47:04 --> Model Class Initialized
INFO - 2024-03-21 04:47:04 --> Model Class Initialized
INFO - 2024-03-21 04:47:04 --> Model Class Initialized
INFO - 2024-03-21 04:47:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-21 04:47:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-21 04:47:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 04:47:04 --> Final output sent to browser
DEBUG - 2024-03-21 04:47:04 --> Total execution time: 0.1878
ERROR - 2024-03-21 04:47:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:47:11 --> Config Class Initialized
INFO - 2024-03-21 04:47:11 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:47:11 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:47:11 --> Utf8 Class Initialized
INFO - 2024-03-21 04:47:11 --> URI Class Initialized
INFO - 2024-03-21 04:47:11 --> Router Class Initialized
INFO - 2024-03-21 04:47:11 --> Output Class Initialized
INFO - 2024-03-21 04:47:11 --> Security Class Initialized
DEBUG - 2024-03-21 04:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:47:11 --> Input Class Initialized
INFO - 2024-03-21 04:47:11 --> Language Class Initialized
INFO - 2024-03-21 04:47:11 --> Loader Class Initialized
INFO - 2024-03-21 04:47:11 --> Helper loaded: url_helper
INFO - 2024-03-21 04:47:11 --> Helper loaded: file_helper
INFO - 2024-03-21 04:47:11 --> Helper loaded: html_helper
INFO - 2024-03-21 04:47:11 --> Helper loaded: text_helper
INFO - 2024-03-21 04:47:11 --> Helper loaded: form_helper
INFO - 2024-03-21 04:47:11 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:47:11 --> Helper loaded: security_helper
INFO - 2024-03-21 04:47:11 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:47:11 --> Database Driver Class Initialized
INFO - 2024-03-21 04:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:47:11 --> Parser Class Initialized
INFO - 2024-03-21 04:47:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:47:11 --> Pagination Class Initialized
INFO - 2024-03-21 04:47:11 --> Form Validation Class Initialized
INFO - 2024-03-21 04:47:11 --> Controller Class Initialized
INFO - 2024-03-21 04:47:11 --> Model Class Initialized
DEBUG - 2024-03-21 04:47:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:47:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:47:11 --> Model Class Initialized
DEBUG - 2024-03-21 04:47:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:47:11 --> Model Class Initialized
INFO - 2024-03-21 04:47:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-21 04:47:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:47:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 04:47:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 04:47:11 --> Model Class Initialized
INFO - 2024-03-21 04:47:11 --> Model Class Initialized
INFO - 2024-03-21 04:47:11 --> Model Class Initialized
INFO - 2024-03-21 04:47:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-21 04:47:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-21 04:47:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 04:47:12 --> Final output sent to browser
DEBUG - 2024-03-21 04:47:12 --> Total execution time: 0.1645
ERROR - 2024-03-21 04:47:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 04:47:13 --> Config Class Initialized
INFO - 2024-03-21 04:47:13 --> Hooks Class Initialized
DEBUG - 2024-03-21 04:47:13 --> UTF-8 Support Enabled
INFO - 2024-03-21 04:47:13 --> Utf8 Class Initialized
INFO - 2024-03-21 04:47:13 --> URI Class Initialized
INFO - 2024-03-21 04:47:13 --> Router Class Initialized
INFO - 2024-03-21 04:47:13 --> Output Class Initialized
INFO - 2024-03-21 04:47:13 --> Security Class Initialized
DEBUG - 2024-03-21 04:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 04:47:13 --> Input Class Initialized
INFO - 2024-03-21 04:47:13 --> Language Class Initialized
INFO - 2024-03-21 04:47:13 --> Loader Class Initialized
INFO - 2024-03-21 04:47:13 --> Helper loaded: url_helper
INFO - 2024-03-21 04:47:13 --> Helper loaded: file_helper
INFO - 2024-03-21 04:47:13 --> Helper loaded: html_helper
INFO - 2024-03-21 04:47:13 --> Helper loaded: text_helper
INFO - 2024-03-21 04:47:13 --> Helper loaded: form_helper
INFO - 2024-03-21 04:47:13 --> Helper loaded: lang_helper
INFO - 2024-03-21 04:47:13 --> Helper loaded: security_helper
INFO - 2024-03-21 04:47:13 --> Helper loaded: cookie_helper
INFO - 2024-03-21 04:47:13 --> Database Driver Class Initialized
INFO - 2024-03-21 04:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 04:47:13 --> Parser Class Initialized
INFO - 2024-03-21 04:47:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 04:47:13 --> Pagination Class Initialized
INFO - 2024-03-21 04:47:13 --> Form Validation Class Initialized
INFO - 2024-03-21 04:47:13 --> Controller Class Initialized
INFO - 2024-03-21 04:47:13 --> Model Class Initialized
DEBUG - 2024-03-21 04:47:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 04:47:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:47:13 --> Model Class Initialized
DEBUG - 2024-03-21 04:47:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 04:47:13 --> Model Class Initialized
INFO - 2024-03-21 04:47:13 --> Final output sent to browser
DEBUG - 2024-03-21 04:47:13 --> Total execution time: 0.0405
ERROR - 2024-03-21 06:05:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:05:43 --> Config Class Initialized
INFO - 2024-03-21 06:05:43 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:05:43 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:05:43 --> Utf8 Class Initialized
INFO - 2024-03-21 06:05:43 --> URI Class Initialized
DEBUG - 2024-03-21 06:05:43 --> No URI present. Default controller set.
INFO - 2024-03-21 06:05:43 --> Router Class Initialized
INFO - 2024-03-21 06:05:43 --> Output Class Initialized
INFO - 2024-03-21 06:05:43 --> Security Class Initialized
DEBUG - 2024-03-21 06:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:05:43 --> Input Class Initialized
INFO - 2024-03-21 06:05:43 --> Language Class Initialized
INFO - 2024-03-21 06:05:43 --> Loader Class Initialized
INFO - 2024-03-21 06:05:43 --> Helper loaded: url_helper
INFO - 2024-03-21 06:05:43 --> Helper loaded: file_helper
INFO - 2024-03-21 06:05:43 --> Helper loaded: html_helper
INFO - 2024-03-21 06:05:43 --> Helper loaded: text_helper
INFO - 2024-03-21 06:05:43 --> Helper loaded: form_helper
INFO - 2024-03-21 06:05:43 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:05:43 --> Helper loaded: security_helper
INFO - 2024-03-21 06:05:43 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:05:43 --> Database Driver Class Initialized
INFO - 2024-03-21 06:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:05:43 --> Parser Class Initialized
INFO - 2024-03-21 06:05:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:05:43 --> Pagination Class Initialized
INFO - 2024-03-21 06:05:43 --> Form Validation Class Initialized
INFO - 2024-03-21 06:05:43 --> Controller Class Initialized
INFO - 2024-03-21 06:05:43 --> Model Class Initialized
DEBUG - 2024-03-21 06:05:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-21 06:05:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:05:44 --> Config Class Initialized
INFO - 2024-03-21 06:05:44 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:05:44 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:05:44 --> Utf8 Class Initialized
INFO - 2024-03-21 06:05:44 --> URI Class Initialized
INFO - 2024-03-21 06:05:44 --> Router Class Initialized
INFO - 2024-03-21 06:05:44 --> Output Class Initialized
INFO - 2024-03-21 06:05:44 --> Security Class Initialized
DEBUG - 2024-03-21 06:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:05:44 --> Input Class Initialized
INFO - 2024-03-21 06:05:44 --> Language Class Initialized
INFO - 2024-03-21 06:05:44 --> Loader Class Initialized
INFO - 2024-03-21 06:05:44 --> Helper loaded: url_helper
INFO - 2024-03-21 06:05:44 --> Helper loaded: file_helper
INFO - 2024-03-21 06:05:44 --> Helper loaded: html_helper
INFO - 2024-03-21 06:05:44 --> Helper loaded: text_helper
INFO - 2024-03-21 06:05:44 --> Helper loaded: form_helper
INFO - 2024-03-21 06:05:44 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:05:44 --> Helper loaded: security_helper
INFO - 2024-03-21 06:05:44 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:05:44 --> Database Driver Class Initialized
INFO - 2024-03-21 06:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:05:44 --> Parser Class Initialized
INFO - 2024-03-21 06:05:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:05:44 --> Pagination Class Initialized
INFO - 2024-03-21 06:05:44 --> Form Validation Class Initialized
INFO - 2024-03-21 06:05:44 --> Controller Class Initialized
INFO - 2024-03-21 06:05:44 --> Model Class Initialized
DEBUG - 2024-03-21 06:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-21 06:05:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 06:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 06:05:44 --> Model Class Initialized
INFO - 2024-03-21 06:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 06:05:44 --> Final output sent to browser
DEBUG - 2024-03-21 06:05:44 --> Total execution time: 0.0375
ERROR - 2024-03-21 06:05:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:05:58 --> Config Class Initialized
INFO - 2024-03-21 06:05:58 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:05:58 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:05:58 --> Utf8 Class Initialized
INFO - 2024-03-21 06:05:58 --> URI Class Initialized
INFO - 2024-03-21 06:05:58 --> Router Class Initialized
INFO - 2024-03-21 06:05:58 --> Output Class Initialized
INFO - 2024-03-21 06:05:58 --> Security Class Initialized
DEBUG - 2024-03-21 06:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:05:58 --> Input Class Initialized
INFO - 2024-03-21 06:05:58 --> Language Class Initialized
INFO - 2024-03-21 06:05:58 --> Loader Class Initialized
INFO - 2024-03-21 06:05:58 --> Helper loaded: url_helper
INFO - 2024-03-21 06:05:58 --> Helper loaded: file_helper
INFO - 2024-03-21 06:05:58 --> Helper loaded: html_helper
INFO - 2024-03-21 06:05:58 --> Helper loaded: text_helper
INFO - 2024-03-21 06:05:58 --> Helper loaded: form_helper
INFO - 2024-03-21 06:05:58 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:05:58 --> Helper loaded: security_helper
INFO - 2024-03-21 06:05:58 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:05:58 --> Database Driver Class Initialized
INFO - 2024-03-21 06:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:05:58 --> Parser Class Initialized
INFO - 2024-03-21 06:05:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:05:58 --> Pagination Class Initialized
INFO - 2024-03-21 06:05:58 --> Form Validation Class Initialized
INFO - 2024-03-21 06:05:58 --> Controller Class Initialized
INFO - 2024-03-21 06:05:58 --> Model Class Initialized
DEBUG - 2024-03-21 06:05:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:05:58 --> Model Class Initialized
INFO - 2024-03-21 06:05:58 --> Final output sent to browser
DEBUG - 2024-03-21 06:05:58 --> Total execution time: 0.0198
ERROR - 2024-03-21 06:05:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:05:58 --> Config Class Initialized
INFO - 2024-03-21 06:05:58 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:05:58 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:05:58 --> Utf8 Class Initialized
INFO - 2024-03-21 06:05:58 --> URI Class Initialized
DEBUG - 2024-03-21 06:05:58 --> No URI present. Default controller set.
INFO - 2024-03-21 06:05:58 --> Router Class Initialized
INFO - 2024-03-21 06:05:58 --> Output Class Initialized
INFO - 2024-03-21 06:05:58 --> Security Class Initialized
DEBUG - 2024-03-21 06:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:05:58 --> Input Class Initialized
INFO - 2024-03-21 06:05:58 --> Language Class Initialized
INFO - 2024-03-21 06:05:58 --> Loader Class Initialized
INFO - 2024-03-21 06:05:58 --> Helper loaded: url_helper
INFO - 2024-03-21 06:05:58 --> Helper loaded: file_helper
INFO - 2024-03-21 06:05:58 --> Helper loaded: html_helper
INFO - 2024-03-21 06:05:58 --> Helper loaded: text_helper
INFO - 2024-03-21 06:05:58 --> Helper loaded: form_helper
INFO - 2024-03-21 06:05:58 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:05:58 --> Helper loaded: security_helper
INFO - 2024-03-21 06:05:58 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:05:58 --> Database Driver Class Initialized
INFO - 2024-03-21 06:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:05:58 --> Parser Class Initialized
INFO - 2024-03-21 06:05:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:05:58 --> Pagination Class Initialized
INFO - 2024-03-21 06:05:58 --> Form Validation Class Initialized
INFO - 2024-03-21 06:05:58 --> Controller Class Initialized
INFO - 2024-03-21 06:05:58 --> Model Class Initialized
DEBUG - 2024-03-21 06:05:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:05:58 --> Model Class Initialized
DEBUG - 2024-03-21 06:05:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:05:58 --> Model Class Initialized
INFO - 2024-03-21 06:05:59 --> Model Class Initialized
INFO - 2024-03-21 06:05:59 --> Model Class Initialized
INFO - 2024-03-21 06:05:59 --> Model Class Initialized
DEBUG - 2024-03-21 06:05:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 06:05:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:05:59 --> Model Class Initialized
INFO - 2024-03-21 06:05:59 --> Model Class Initialized
INFO - 2024-03-21 06:05:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-21 06:05:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:05:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 06:05:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 06:05:59 --> Model Class Initialized
INFO - 2024-03-21 06:05:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-21 06:05:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-21 06:05:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 06:05:59 --> Final output sent to browser
DEBUG - 2024-03-21 06:05:59 --> Total execution time: 0.4402
ERROR - 2024-03-21 06:06:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:06:00 --> Config Class Initialized
INFO - 2024-03-21 06:06:00 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:06:00 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:06:00 --> Utf8 Class Initialized
INFO - 2024-03-21 06:06:00 --> URI Class Initialized
INFO - 2024-03-21 06:06:00 --> Router Class Initialized
INFO - 2024-03-21 06:06:00 --> Output Class Initialized
INFO - 2024-03-21 06:06:00 --> Security Class Initialized
DEBUG - 2024-03-21 06:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:06:00 --> Input Class Initialized
INFO - 2024-03-21 06:06:00 --> Language Class Initialized
INFO - 2024-03-21 06:06:00 --> Loader Class Initialized
INFO - 2024-03-21 06:06:00 --> Helper loaded: url_helper
INFO - 2024-03-21 06:06:00 --> Helper loaded: file_helper
INFO - 2024-03-21 06:06:00 --> Helper loaded: html_helper
INFO - 2024-03-21 06:06:00 --> Helper loaded: text_helper
INFO - 2024-03-21 06:06:00 --> Helper loaded: form_helper
INFO - 2024-03-21 06:06:00 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:06:00 --> Helper loaded: security_helper
INFO - 2024-03-21 06:06:00 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:06:00 --> Database Driver Class Initialized
INFO - 2024-03-21 06:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:06:00 --> Parser Class Initialized
INFO - 2024-03-21 06:06:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:06:00 --> Pagination Class Initialized
INFO - 2024-03-21 06:06:00 --> Form Validation Class Initialized
INFO - 2024-03-21 06:06:00 --> Controller Class Initialized
DEBUG - 2024-03-21 06:06:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 06:06:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:06:00 --> Model Class Initialized
INFO - 2024-03-21 06:06:00 --> Final output sent to browser
DEBUG - 2024-03-21 06:06:00 --> Total execution time: 0.0131
ERROR - 2024-03-21 06:06:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:06:27 --> Config Class Initialized
INFO - 2024-03-21 06:06:27 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:06:27 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:06:27 --> Utf8 Class Initialized
INFO - 2024-03-21 06:06:27 --> URI Class Initialized
INFO - 2024-03-21 06:06:27 --> Router Class Initialized
INFO - 2024-03-21 06:06:27 --> Output Class Initialized
INFO - 2024-03-21 06:06:27 --> Security Class Initialized
DEBUG - 2024-03-21 06:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:06:27 --> Input Class Initialized
INFO - 2024-03-21 06:06:27 --> Language Class Initialized
INFO - 2024-03-21 06:06:27 --> Loader Class Initialized
INFO - 2024-03-21 06:06:27 --> Helper loaded: url_helper
INFO - 2024-03-21 06:06:27 --> Helper loaded: file_helper
INFO - 2024-03-21 06:06:27 --> Helper loaded: html_helper
INFO - 2024-03-21 06:06:27 --> Helper loaded: text_helper
INFO - 2024-03-21 06:06:27 --> Helper loaded: form_helper
INFO - 2024-03-21 06:06:27 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:06:27 --> Helper loaded: security_helper
INFO - 2024-03-21 06:06:27 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:06:27 --> Database Driver Class Initialized
INFO - 2024-03-21 06:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:06:27 --> Parser Class Initialized
INFO - 2024-03-21 06:06:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:06:27 --> Pagination Class Initialized
INFO - 2024-03-21 06:06:27 --> Form Validation Class Initialized
INFO - 2024-03-21 06:06:27 --> Controller Class Initialized
DEBUG - 2024-03-21 06:06:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 06:06:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:06:27 --> Model Class Initialized
DEBUG - 2024-03-21 06:06:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:06:27 --> Model Class Initialized
DEBUG - 2024-03-21 06:06:27 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:06:27 --> Model Class Initialized
INFO - 2024-03-21 06:06:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-03-21 06:06:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:06:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 06:06:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 06:06:27 --> Model Class Initialized
INFO - 2024-03-21 06:06:27 --> Model Class Initialized
INFO - 2024-03-21 06:06:27 --> Model Class Initialized
INFO - 2024-03-21 06:06:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-21 06:06:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-21 06:06:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 06:06:27 --> Final output sent to browser
DEBUG - 2024-03-21 06:06:27 --> Total execution time: 0.2486
ERROR - 2024-03-21 06:06:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:06:28 --> Config Class Initialized
INFO - 2024-03-21 06:06:28 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:06:28 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:06:28 --> Utf8 Class Initialized
INFO - 2024-03-21 06:06:28 --> URI Class Initialized
INFO - 2024-03-21 06:06:28 --> Router Class Initialized
INFO - 2024-03-21 06:06:28 --> Output Class Initialized
INFO - 2024-03-21 06:06:28 --> Security Class Initialized
DEBUG - 2024-03-21 06:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:06:28 --> Input Class Initialized
INFO - 2024-03-21 06:06:28 --> Language Class Initialized
INFO - 2024-03-21 06:06:28 --> Loader Class Initialized
INFO - 2024-03-21 06:06:28 --> Helper loaded: url_helper
INFO - 2024-03-21 06:06:28 --> Helper loaded: file_helper
INFO - 2024-03-21 06:06:28 --> Helper loaded: html_helper
INFO - 2024-03-21 06:06:28 --> Helper loaded: text_helper
INFO - 2024-03-21 06:06:28 --> Helper loaded: form_helper
INFO - 2024-03-21 06:06:28 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:06:28 --> Helper loaded: security_helper
INFO - 2024-03-21 06:06:28 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:06:28 --> Database Driver Class Initialized
INFO - 2024-03-21 06:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:06:28 --> Parser Class Initialized
INFO - 2024-03-21 06:06:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:06:28 --> Pagination Class Initialized
INFO - 2024-03-21 06:06:28 --> Form Validation Class Initialized
INFO - 2024-03-21 06:06:28 --> Controller Class Initialized
DEBUG - 2024-03-21 06:06:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 06:06:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:06:28 --> Model Class Initialized
DEBUG - 2024-03-21 06:06:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:06:28 --> Model Class Initialized
INFO - 2024-03-21 06:06:28 --> Final output sent to browser
DEBUG - 2024-03-21 06:06:28 --> Total execution time: 0.0326
ERROR - 2024-03-21 06:06:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:06:36 --> Config Class Initialized
INFO - 2024-03-21 06:06:36 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:06:36 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:06:36 --> Utf8 Class Initialized
INFO - 2024-03-21 06:06:36 --> URI Class Initialized
DEBUG - 2024-03-21 06:06:36 --> No URI present. Default controller set.
INFO - 2024-03-21 06:06:36 --> Router Class Initialized
INFO - 2024-03-21 06:06:36 --> Output Class Initialized
INFO - 2024-03-21 06:06:36 --> Security Class Initialized
DEBUG - 2024-03-21 06:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:06:36 --> Input Class Initialized
INFO - 2024-03-21 06:06:36 --> Language Class Initialized
INFO - 2024-03-21 06:06:36 --> Loader Class Initialized
INFO - 2024-03-21 06:06:36 --> Helper loaded: url_helper
INFO - 2024-03-21 06:06:36 --> Helper loaded: file_helper
INFO - 2024-03-21 06:06:36 --> Helper loaded: html_helper
INFO - 2024-03-21 06:06:36 --> Helper loaded: text_helper
INFO - 2024-03-21 06:06:36 --> Helper loaded: form_helper
INFO - 2024-03-21 06:06:36 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:06:36 --> Helper loaded: security_helper
INFO - 2024-03-21 06:06:36 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:06:36 --> Database Driver Class Initialized
INFO - 2024-03-21 06:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:06:36 --> Parser Class Initialized
INFO - 2024-03-21 06:06:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:06:36 --> Pagination Class Initialized
INFO - 2024-03-21 06:06:36 --> Form Validation Class Initialized
INFO - 2024-03-21 06:06:36 --> Controller Class Initialized
INFO - 2024-03-21 06:06:36 --> Model Class Initialized
DEBUG - 2024-03-21 06:06:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:06:36 --> Model Class Initialized
DEBUG - 2024-03-21 06:06:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:06:36 --> Model Class Initialized
INFO - 2024-03-21 06:06:36 --> Model Class Initialized
INFO - 2024-03-21 06:06:36 --> Model Class Initialized
INFO - 2024-03-21 06:06:36 --> Model Class Initialized
DEBUG - 2024-03-21 06:06:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 06:06:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:06:36 --> Model Class Initialized
INFO - 2024-03-21 06:06:36 --> Model Class Initialized
INFO - 2024-03-21 06:06:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-21 06:06:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:06:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 06:06:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 06:06:36 --> Model Class Initialized
INFO - 2024-03-21 06:06:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-21 06:06:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-21 06:06:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 06:06:36 --> Final output sent to browser
DEBUG - 2024-03-21 06:06:36 --> Total execution time: 0.4638
ERROR - 2024-03-21 06:07:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:07:16 --> Config Class Initialized
INFO - 2024-03-21 06:07:16 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:07:16 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:07:16 --> Utf8 Class Initialized
INFO - 2024-03-21 06:07:16 --> URI Class Initialized
INFO - 2024-03-21 06:07:16 --> Router Class Initialized
INFO - 2024-03-21 06:07:16 --> Output Class Initialized
INFO - 2024-03-21 06:07:16 --> Security Class Initialized
DEBUG - 2024-03-21 06:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:07:16 --> Input Class Initialized
INFO - 2024-03-21 06:07:16 --> Language Class Initialized
INFO - 2024-03-21 06:07:16 --> Loader Class Initialized
INFO - 2024-03-21 06:07:16 --> Helper loaded: url_helper
INFO - 2024-03-21 06:07:16 --> Helper loaded: file_helper
INFO - 2024-03-21 06:07:16 --> Helper loaded: html_helper
INFO - 2024-03-21 06:07:16 --> Helper loaded: text_helper
INFO - 2024-03-21 06:07:16 --> Helper loaded: form_helper
INFO - 2024-03-21 06:07:16 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:07:16 --> Helper loaded: security_helper
INFO - 2024-03-21 06:07:16 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:07:16 --> Database Driver Class Initialized
INFO - 2024-03-21 06:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:07:16 --> Parser Class Initialized
INFO - 2024-03-21 06:07:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:07:16 --> Pagination Class Initialized
INFO - 2024-03-21 06:07:16 --> Form Validation Class Initialized
INFO - 2024-03-21 06:07:16 --> Controller Class Initialized
INFO - 2024-03-21 06:07:16 --> Model Class Initialized
DEBUG - 2024-03-21 06:07:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 06:07:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:07:16 --> Model Class Initialized
DEBUG - 2024-03-21 06:07:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:07:16 --> Model Class Initialized
INFO - 2024-03-21 06:07:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-21 06:07:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:07:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 06:07:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 06:07:16 --> Model Class Initialized
INFO - 2024-03-21 06:07:16 --> Model Class Initialized
INFO - 2024-03-21 06:07:16 --> Model Class Initialized
INFO - 2024-03-21 06:07:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-21 06:07:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-21 06:07:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 06:07:17 --> Final output sent to browser
DEBUG - 2024-03-21 06:07:17 --> Total execution time: 0.2545
ERROR - 2024-03-21 06:07:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:07:18 --> Config Class Initialized
INFO - 2024-03-21 06:07:18 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:07:18 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:07:18 --> Utf8 Class Initialized
INFO - 2024-03-21 06:07:18 --> URI Class Initialized
INFO - 2024-03-21 06:07:18 --> Router Class Initialized
INFO - 2024-03-21 06:07:18 --> Output Class Initialized
INFO - 2024-03-21 06:07:18 --> Security Class Initialized
DEBUG - 2024-03-21 06:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:07:18 --> Input Class Initialized
INFO - 2024-03-21 06:07:18 --> Language Class Initialized
INFO - 2024-03-21 06:07:18 --> Loader Class Initialized
INFO - 2024-03-21 06:07:18 --> Helper loaded: url_helper
INFO - 2024-03-21 06:07:18 --> Helper loaded: file_helper
INFO - 2024-03-21 06:07:18 --> Helper loaded: html_helper
INFO - 2024-03-21 06:07:18 --> Helper loaded: text_helper
INFO - 2024-03-21 06:07:18 --> Helper loaded: form_helper
INFO - 2024-03-21 06:07:18 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:07:18 --> Helper loaded: security_helper
INFO - 2024-03-21 06:07:18 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:07:18 --> Database Driver Class Initialized
INFO - 2024-03-21 06:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:07:18 --> Parser Class Initialized
INFO - 2024-03-21 06:07:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:07:18 --> Pagination Class Initialized
INFO - 2024-03-21 06:07:18 --> Form Validation Class Initialized
INFO - 2024-03-21 06:07:18 --> Controller Class Initialized
INFO - 2024-03-21 06:07:18 --> Model Class Initialized
DEBUG - 2024-03-21 06:07:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 06:07:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:07:18 --> Model Class Initialized
DEBUG - 2024-03-21 06:07:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:07:18 --> Model Class Initialized
INFO - 2024-03-21 06:07:18 --> Final output sent to browser
DEBUG - 2024-03-21 06:07:18 --> Total execution time: 0.0644
ERROR - 2024-03-21 06:07:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:07:27 --> Config Class Initialized
INFO - 2024-03-21 06:07:27 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:07:27 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:07:27 --> Utf8 Class Initialized
INFO - 2024-03-21 06:07:27 --> URI Class Initialized
INFO - 2024-03-21 06:07:27 --> Router Class Initialized
INFO - 2024-03-21 06:07:27 --> Output Class Initialized
INFO - 2024-03-21 06:07:27 --> Security Class Initialized
DEBUG - 2024-03-21 06:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:07:27 --> Input Class Initialized
INFO - 2024-03-21 06:07:27 --> Language Class Initialized
INFO - 2024-03-21 06:07:27 --> Loader Class Initialized
INFO - 2024-03-21 06:07:27 --> Helper loaded: url_helper
INFO - 2024-03-21 06:07:27 --> Helper loaded: file_helper
INFO - 2024-03-21 06:07:27 --> Helper loaded: html_helper
INFO - 2024-03-21 06:07:27 --> Helper loaded: text_helper
INFO - 2024-03-21 06:07:27 --> Helper loaded: form_helper
INFO - 2024-03-21 06:07:27 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:07:27 --> Helper loaded: security_helper
INFO - 2024-03-21 06:07:27 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:07:27 --> Database Driver Class Initialized
INFO - 2024-03-21 06:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:07:27 --> Parser Class Initialized
INFO - 2024-03-21 06:07:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:07:27 --> Pagination Class Initialized
INFO - 2024-03-21 06:07:27 --> Form Validation Class Initialized
INFO - 2024-03-21 06:07:27 --> Controller Class Initialized
INFO - 2024-03-21 06:07:27 --> Model Class Initialized
DEBUG - 2024-03-21 06:07:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 06:07:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:07:27 --> Model Class Initialized
DEBUG - 2024-03-21 06:07:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:07:27 --> Model Class Initialized
INFO - 2024-03-21 06:07:27 --> Final output sent to browser
DEBUG - 2024-03-21 06:07:27 --> Total execution time: 0.0690
ERROR - 2024-03-21 06:07:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:07:28 --> Config Class Initialized
INFO - 2024-03-21 06:07:28 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:07:28 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:07:28 --> Utf8 Class Initialized
INFO - 2024-03-21 06:07:28 --> URI Class Initialized
INFO - 2024-03-21 06:07:28 --> Router Class Initialized
INFO - 2024-03-21 06:07:28 --> Output Class Initialized
INFO - 2024-03-21 06:07:28 --> Security Class Initialized
DEBUG - 2024-03-21 06:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:07:28 --> Input Class Initialized
INFO - 2024-03-21 06:07:28 --> Language Class Initialized
INFO - 2024-03-21 06:07:28 --> Loader Class Initialized
INFO - 2024-03-21 06:07:28 --> Helper loaded: url_helper
INFO - 2024-03-21 06:07:28 --> Helper loaded: file_helper
INFO - 2024-03-21 06:07:28 --> Helper loaded: html_helper
INFO - 2024-03-21 06:07:28 --> Helper loaded: text_helper
INFO - 2024-03-21 06:07:28 --> Helper loaded: form_helper
INFO - 2024-03-21 06:07:28 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:07:28 --> Helper loaded: security_helper
INFO - 2024-03-21 06:07:28 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:07:28 --> Database Driver Class Initialized
INFO - 2024-03-21 06:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:07:28 --> Parser Class Initialized
INFO - 2024-03-21 06:07:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:07:28 --> Pagination Class Initialized
INFO - 2024-03-21 06:07:28 --> Form Validation Class Initialized
INFO - 2024-03-21 06:07:28 --> Controller Class Initialized
INFO - 2024-03-21 06:07:28 --> Model Class Initialized
DEBUG - 2024-03-21 06:07:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 06:07:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:07:28 --> Model Class Initialized
DEBUG - 2024-03-21 06:07:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:07:28 --> Model Class Initialized
INFO - 2024-03-21 06:07:28 --> Final output sent to browser
DEBUG - 2024-03-21 06:07:28 --> Total execution time: 0.0613
ERROR - 2024-03-21 06:07:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:07:33 --> Config Class Initialized
INFO - 2024-03-21 06:07:33 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:07:33 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:07:33 --> Utf8 Class Initialized
INFO - 2024-03-21 06:07:33 --> URI Class Initialized
INFO - 2024-03-21 06:07:33 --> Router Class Initialized
INFO - 2024-03-21 06:07:33 --> Output Class Initialized
INFO - 2024-03-21 06:07:33 --> Security Class Initialized
DEBUG - 2024-03-21 06:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:07:33 --> Input Class Initialized
INFO - 2024-03-21 06:07:33 --> Language Class Initialized
INFO - 2024-03-21 06:07:33 --> Loader Class Initialized
INFO - 2024-03-21 06:07:33 --> Helper loaded: url_helper
INFO - 2024-03-21 06:07:33 --> Helper loaded: file_helper
INFO - 2024-03-21 06:07:33 --> Helper loaded: html_helper
INFO - 2024-03-21 06:07:33 --> Helper loaded: text_helper
INFO - 2024-03-21 06:07:33 --> Helper loaded: form_helper
INFO - 2024-03-21 06:07:33 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:07:33 --> Helper loaded: security_helper
INFO - 2024-03-21 06:07:33 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:07:33 --> Database Driver Class Initialized
INFO - 2024-03-21 06:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:07:33 --> Parser Class Initialized
INFO - 2024-03-21 06:07:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:07:33 --> Pagination Class Initialized
INFO - 2024-03-21 06:07:33 --> Form Validation Class Initialized
INFO - 2024-03-21 06:07:33 --> Controller Class Initialized
INFO - 2024-03-21 06:07:33 --> Model Class Initialized
DEBUG - 2024-03-21 06:07:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 06:07:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:07:33 --> Model Class Initialized
DEBUG - 2024-03-21 06:07:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:07:33 --> Model Class Initialized
INFO - 2024-03-21 06:07:33 --> Final output sent to browser
DEBUG - 2024-03-21 06:07:33 --> Total execution time: 0.0245
ERROR - 2024-03-21 06:07:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:07:34 --> Config Class Initialized
INFO - 2024-03-21 06:07:34 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:07:34 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:07:34 --> Utf8 Class Initialized
INFO - 2024-03-21 06:07:34 --> URI Class Initialized
DEBUG - 2024-03-21 06:07:34 --> No URI present. Default controller set.
INFO - 2024-03-21 06:07:34 --> Router Class Initialized
INFO - 2024-03-21 06:07:34 --> Output Class Initialized
INFO - 2024-03-21 06:07:34 --> Security Class Initialized
DEBUG - 2024-03-21 06:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:07:34 --> Input Class Initialized
INFO - 2024-03-21 06:07:34 --> Language Class Initialized
INFO - 2024-03-21 06:07:34 --> Loader Class Initialized
INFO - 2024-03-21 06:07:34 --> Helper loaded: url_helper
INFO - 2024-03-21 06:07:34 --> Helper loaded: file_helper
INFO - 2024-03-21 06:07:34 --> Helper loaded: html_helper
INFO - 2024-03-21 06:07:34 --> Helper loaded: text_helper
INFO - 2024-03-21 06:07:34 --> Helper loaded: form_helper
INFO - 2024-03-21 06:07:34 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:07:34 --> Helper loaded: security_helper
INFO - 2024-03-21 06:07:34 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:07:34 --> Database Driver Class Initialized
INFO - 2024-03-21 06:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:07:34 --> Parser Class Initialized
INFO - 2024-03-21 06:07:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:07:34 --> Pagination Class Initialized
INFO - 2024-03-21 06:07:34 --> Form Validation Class Initialized
INFO - 2024-03-21 06:07:34 --> Controller Class Initialized
INFO - 2024-03-21 06:07:34 --> Model Class Initialized
DEBUG - 2024-03-21 06:07:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:07:34 --> Model Class Initialized
DEBUG - 2024-03-21 06:07:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:07:34 --> Model Class Initialized
INFO - 2024-03-21 06:07:34 --> Model Class Initialized
INFO - 2024-03-21 06:07:34 --> Model Class Initialized
INFO - 2024-03-21 06:07:34 --> Model Class Initialized
DEBUG - 2024-03-21 06:07:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 06:07:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:07:34 --> Model Class Initialized
INFO - 2024-03-21 06:07:34 --> Model Class Initialized
INFO - 2024-03-21 06:07:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-21 06:07:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:07:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 06:07:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 06:07:34 --> Model Class Initialized
INFO - 2024-03-21 06:07:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-21 06:07:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-21 06:07:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 06:07:34 --> Final output sent to browser
DEBUG - 2024-03-21 06:07:34 --> Total execution time: 0.4534
ERROR - 2024-03-21 06:20:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:20:35 --> Config Class Initialized
INFO - 2024-03-21 06:20:35 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:20:35 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:20:35 --> Utf8 Class Initialized
INFO - 2024-03-21 06:20:35 --> URI Class Initialized
DEBUG - 2024-03-21 06:20:35 --> No URI present. Default controller set.
INFO - 2024-03-21 06:20:35 --> Router Class Initialized
INFO - 2024-03-21 06:20:35 --> Output Class Initialized
INFO - 2024-03-21 06:20:35 --> Security Class Initialized
DEBUG - 2024-03-21 06:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:20:35 --> Input Class Initialized
INFO - 2024-03-21 06:20:35 --> Language Class Initialized
INFO - 2024-03-21 06:20:35 --> Loader Class Initialized
INFO - 2024-03-21 06:20:35 --> Helper loaded: url_helper
INFO - 2024-03-21 06:20:35 --> Helper loaded: file_helper
INFO - 2024-03-21 06:20:35 --> Helper loaded: html_helper
INFO - 2024-03-21 06:20:35 --> Helper loaded: text_helper
INFO - 2024-03-21 06:20:35 --> Helper loaded: form_helper
INFO - 2024-03-21 06:20:35 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:20:35 --> Helper loaded: security_helper
INFO - 2024-03-21 06:20:35 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:20:35 --> Database Driver Class Initialized
INFO - 2024-03-21 06:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:20:35 --> Parser Class Initialized
INFO - 2024-03-21 06:20:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:20:35 --> Pagination Class Initialized
INFO - 2024-03-21 06:20:35 --> Form Validation Class Initialized
INFO - 2024-03-21 06:20:35 --> Controller Class Initialized
INFO - 2024-03-21 06:20:35 --> Model Class Initialized
DEBUG - 2024-03-21 06:20:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:20:35 --> Model Class Initialized
DEBUG - 2024-03-21 06:20:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:20:35 --> Model Class Initialized
INFO - 2024-03-21 06:20:35 --> Model Class Initialized
INFO - 2024-03-21 06:20:35 --> Model Class Initialized
INFO - 2024-03-21 06:20:35 --> Model Class Initialized
DEBUG - 2024-03-21 06:20:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 06:20:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:20:35 --> Model Class Initialized
INFO - 2024-03-21 06:20:35 --> Model Class Initialized
INFO - 2024-03-21 06:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-21 06:20:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 06:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 06:20:35 --> Model Class Initialized
INFO - 2024-03-21 06:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-21 06:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-21 06:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 06:20:35 --> Final output sent to browser
DEBUG - 2024-03-21 06:20:35 --> Total execution time: 0.2609
ERROR - 2024-03-21 06:21:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:21:10 --> Config Class Initialized
INFO - 2024-03-21 06:21:10 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:21:10 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:21:10 --> Utf8 Class Initialized
INFO - 2024-03-21 06:21:10 --> URI Class Initialized
INFO - 2024-03-21 06:21:10 --> Router Class Initialized
INFO - 2024-03-21 06:21:10 --> Output Class Initialized
INFO - 2024-03-21 06:21:10 --> Security Class Initialized
DEBUG - 2024-03-21 06:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:21:10 --> Input Class Initialized
INFO - 2024-03-21 06:21:10 --> Language Class Initialized
INFO - 2024-03-21 06:21:10 --> Loader Class Initialized
INFO - 2024-03-21 06:21:10 --> Helper loaded: url_helper
INFO - 2024-03-21 06:21:10 --> Helper loaded: file_helper
INFO - 2024-03-21 06:21:10 --> Helper loaded: html_helper
INFO - 2024-03-21 06:21:10 --> Helper loaded: text_helper
INFO - 2024-03-21 06:21:10 --> Helper loaded: form_helper
INFO - 2024-03-21 06:21:10 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:21:10 --> Helper loaded: security_helper
INFO - 2024-03-21 06:21:10 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:21:10 --> Database Driver Class Initialized
INFO - 2024-03-21 06:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:21:10 --> Parser Class Initialized
INFO - 2024-03-21 06:21:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:21:10 --> Pagination Class Initialized
INFO - 2024-03-21 06:21:10 --> Form Validation Class Initialized
INFO - 2024-03-21 06:21:10 --> Controller Class Initialized
INFO - 2024-03-21 06:21:10 --> Model Class Initialized
DEBUG - 2024-03-21 06:21:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 06:21:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:21:10 --> Model Class Initialized
DEBUG - 2024-03-21 06:21:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:21:10 --> Model Class Initialized
INFO - 2024-03-21 06:21:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-21 06:21:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:21:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 06:21:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 06:21:10 --> Model Class Initialized
INFO - 2024-03-21 06:21:10 --> Model Class Initialized
INFO - 2024-03-21 06:21:10 --> Model Class Initialized
INFO - 2024-03-21 06:21:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-21 06:21:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-21 06:21:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 06:21:10 --> Final output sent to browser
DEBUG - 2024-03-21 06:21:10 --> Total execution time: 0.1724
ERROR - 2024-03-21 06:21:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:21:11 --> Config Class Initialized
INFO - 2024-03-21 06:21:11 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:21:11 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:21:11 --> Utf8 Class Initialized
INFO - 2024-03-21 06:21:11 --> URI Class Initialized
INFO - 2024-03-21 06:21:11 --> Router Class Initialized
INFO - 2024-03-21 06:21:11 --> Output Class Initialized
INFO - 2024-03-21 06:21:11 --> Security Class Initialized
DEBUG - 2024-03-21 06:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:21:11 --> Input Class Initialized
INFO - 2024-03-21 06:21:11 --> Language Class Initialized
INFO - 2024-03-21 06:21:11 --> Loader Class Initialized
INFO - 2024-03-21 06:21:11 --> Helper loaded: url_helper
INFO - 2024-03-21 06:21:11 --> Helper loaded: file_helper
INFO - 2024-03-21 06:21:11 --> Helper loaded: html_helper
INFO - 2024-03-21 06:21:11 --> Helper loaded: text_helper
INFO - 2024-03-21 06:21:11 --> Helper loaded: form_helper
INFO - 2024-03-21 06:21:11 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:21:11 --> Helper loaded: security_helper
INFO - 2024-03-21 06:21:11 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:21:11 --> Database Driver Class Initialized
INFO - 2024-03-21 06:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:21:11 --> Parser Class Initialized
INFO - 2024-03-21 06:21:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:21:11 --> Pagination Class Initialized
INFO - 2024-03-21 06:21:11 --> Form Validation Class Initialized
INFO - 2024-03-21 06:21:11 --> Controller Class Initialized
INFO - 2024-03-21 06:21:11 --> Model Class Initialized
DEBUG - 2024-03-21 06:21:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 06:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:21:11 --> Model Class Initialized
DEBUG - 2024-03-21 06:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:21:11 --> Model Class Initialized
INFO - 2024-03-21 06:21:11 --> Final output sent to browser
DEBUG - 2024-03-21 06:21:11 --> Total execution time: 0.0539
ERROR - 2024-03-21 06:21:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:21:44 --> Config Class Initialized
INFO - 2024-03-21 06:21:44 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:21:44 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:21:44 --> Utf8 Class Initialized
INFO - 2024-03-21 06:21:44 --> URI Class Initialized
INFO - 2024-03-21 06:21:44 --> Router Class Initialized
INFO - 2024-03-21 06:21:44 --> Output Class Initialized
INFO - 2024-03-21 06:21:44 --> Security Class Initialized
DEBUG - 2024-03-21 06:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:21:44 --> Input Class Initialized
INFO - 2024-03-21 06:21:44 --> Language Class Initialized
INFO - 2024-03-21 06:21:44 --> Loader Class Initialized
INFO - 2024-03-21 06:21:44 --> Helper loaded: url_helper
INFO - 2024-03-21 06:21:44 --> Helper loaded: file_helper
INFO - 2024-03-21 06:21:44 --> Helper loaded: html_helper
INFO - 2024-03-21 06:21:44 --> Helper loaded: text_helper
INFO - 2024-03-21 06:21:44 --> Helper loaded: form_helper
INFO - 2024-03-21 06:21:44 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:21:44 --> Helper loaded: security_helper
INFO - 2024-03-21 06:21:44 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:21:44 --> Database Driver Class Initialized
INFO - 2024-03-21 06:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:21:44 --> Parser Class Initialized
INFO - 2024-03-21 06:21:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:21:44 --> Pagination Class Initialized
INFO - 2024-03-21 06:21:44 --> Form Validation Class Initialized
INFO - 2024-03-21 06:21:44 --> Controller Class Initialized
INFO - 2024-03-21 06:21:44 --> Model Class Initialized
DEBUG - 2024-03-21 06:21:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 06:21:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:21:44 --> Model Class Initialized
DEBUG - 2024-03-21 06:21:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:21:44 --> Model Class Initialized
INFO - 2024-03-21 06:21:44 --> Final output sent to browser
DEBUG - 2024-03-21 06:21:44 --> Total execution time: 0.0492
ERROR - 2024-03-21 06:21:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:21:44 --> Config Class Initialized
INFO - 2024-03-21 06:21:44 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:21:44 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:21:44 --> Utf8 Class Initialized
INFO - 2024-03-21 06:21:44 --> URI Class Initialized
INFO - 2024-03-21 06:21:44 --> Router Class Initialized
INFO - 2024-03-21 06:21:44 --> Output Class Initialized
INFO - 2024-03-21 06:21:44 --> Security Class Initialized
DEBUG - 2024-03-21 06:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:21:44 --> Input Class Initialized
INFO - 2024-03-21 06:21:44 --> Language Class Initialized
INFO - 2024-03-21 06:21:44 --> Loader Class Initialized
INFO - 2024-03-21 06:21:44 --> Helper loaded: url_helper
INFO - 2024-03-21 06:21:44 --> Helper loaded: file_helper
INFO - 2024-03-21 06:21:44 --> Helper loaded: html_helper
INFO - 2024-03-21 06:21:44 --> Helper loaded: text_helper
INFO - 2024-03-21 06:21:44 --> Helper loaded: form_helper
INFO - 2024-03-21 06:21:44 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:21:44 --> Helper loaded: security_helper
INFO - 2024-03-21 06:21:44 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:21:44 --> Database Driver Class Initialized
INFO - 2024-03-21 06:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:21:44 --> Parser Class Initialized
INFO - 2024-03-21 06:21:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:21:44 --> Pagination Class Initialized
INFO - 2024-03-21 06:21:44 --> Form Validation Class Initialized
INFO - 2024-03-21 06:21:44 --> Controller Class Initialized
INFO - 2024-03-21 06:21:44 --> Model Class Initialized
DEBUG - 2024-03-21 06:21:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 06:21:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:21:44 --> Model Class Initialized
DEBUG - 2024-03-21 06:21:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:21:44 --> Model Class Initialized
INFO - 2024-03-21 06:21:45 --> Final output sent to browser
DEBUG - 2024-03-21 06:21:45 --> Total execution time: 0.0564
ERROR - 2024-03-21 06:21:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:21:45 --> Config Class Initialized
INFO - 2024-03-21 06:21:45 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:21:45 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:21:45 --> Utf8 Class Initialized
INFO - 2024-03-21 06:21:45 --> URI Class Initialized
INFO - 2024-03-21 06:21:45 --> Router Class Initialized
INFO - 2024-03-21 06:21:45 --> Output Class Initialized
INFO - 2024-03-21 06:21:45 --> Security Class Initialized
DEBUG - 2024-03-21 06:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:21:45 --> Input Class Initialized
INFO - 2024-03-21 06:21:45 --> Language Class Initialized
INFO - 2024-03-21 06:21:45 --> Loader Class Initialized
INFO - 2024-03-21 06:21:45 --> Helper loaded: url_helper
INFO - 2024-03-21 06:21:45 --> Helper loaded: file_helper
INFO - 2024-03-21 06:21:45 --> Helper loaded: html_helper
INFO - 2024-03-21 06:21:45 --> Helper loaded: text_helper
INFO - 2024-03-21 06:21:45 --> Helper loaded: form_helper
INFO - 2024-03-21 06:21:45 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:21:45 --> Helper loaded: security_helper
INFO - 2024-03-21 06:21:45 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:21:45 --> Database Driver Class Initialized
INFO - 2024-03-21 06:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:21:45 --> Parser Class Initialized
INFO - 2024-03-21 06:21:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:21:45 --> Pagination Class Initialized
INFO - 2024-03-21 06:21:45 --> Form Validation Class Initialized
INFO - 2024-03-21 06:21:45 --> Controller Class Initialized
INFO - 2024-03-21 06:21:45 --> Model Class Initialized
DEBUG - 2024-03-21 06:21:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 06:21:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:21:45 --> Model Class Initialized
DEBUG - 2024-03-21 06:21:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:21:45 --> Model Class Initialized
INFO - 2024-03-21 06:21:45 --> Final output sent to browser
DEBUG - 2024-03-21 06:21:45 --> Total execution time: 0.0463
ERROR - 2024-03-21 06:21:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:21:46 --> Config Class Initialized
INFO - 2024-03-21 06:21:46 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:21:46 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:21:46 --> Utf8 Class Initialized
INFO - 2024-03-21 06:21:46 --> URI Class Initialized
INFO - 2024-03-21 06:21:46 --> Router Class Initialized
INFO - 2024-03-21 06:21:46 --> Output Class Initialized
INFO - 2024-03-21 06:21:46 --> Security Class Initialized
DEBUG - 2024-03-21 06:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:21:46 --> Input Class Initialized
INFO - 2024-03-21 06:21:46 --> Language Class Initialized
INFO - 2024-03-21 06:21:46 --> Loader Class Initialized
INFO - 2024-03-21 06:21:46 --> Helper loaded: url_helper
INFO - 2024-03-21 06:21:46 --> Helper loaded: file_helper
INFO - 2024-03-21 06:21:46 --> Helper loaded: html_helper
INFO - 2024-03-21 06:21:46 --> Helper loaded: text_helper
INFO - 2024-03-21 06:21:46 --> Helper loaded: form_helper
INFO - 2024-03-21 06:21:46 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:21:46 --> Helper loaded: security_helper
INFO - 2024-03-21 06:21:46 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:21:46 --> Database Driver Class Initialized
INFO - 2024-03-21 06:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:21:46 --> Parser Class Initialized
INFO - 2024-03-21 06:21:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:21:46 --> Pagination Class Initialized
INFO - 2024-03-21 06:21:46 --> Form Validation Class Initialized
INFO - 2024-03-21 06:21:46 --> Controller Class Initialized
INFO - 2024-03-21 06:21:46 --> Model Class Initialized
DEBUG - 2024-03-21 06:21:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 06:21:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:21:46 --> Model Class Initialized
DEBUG - 2024-03-21 06:21:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:21:46 --> Model Class Initialized
INFO - 2024-03-21 06:21:46 --> Final output sent to browser
DEBUG - 2024-03-21 06:21:46 --> Total execution time: 0.0452
ERROR - 2024-03-21 06:21:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:21:47 --> Config Class Initialized
INFO - 2024-03-21 06:21:47 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:21:47 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:21:47 --> Utf8 Class Initialized
INFO - 2024-03-21 06:21:47 --> URI Class Initialized
INFO - 2024-03-21 06:21:47 --> Router Class Initialized
INFO - 2024-03-21 06:21:47 --> Output Class Initialized
INFO - 2024-03-21 06:21:47 --> Security Class Initialized
DEBUG - 2024-03-21 06:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:21:47 --> Input Class Initialized
INFO - 2024-03-21 06:21:47 --> Language Class Initialized
INFO - 2024-03-21 06:21:47 --> Loader Class Initialized
INFO - 2024-03-21 06:21:47 --> Helper loaded: url_helper
INFO - 2024-03-21 06:21:47 --> Helper loaded: file_helper
INFO - 2024-03-21 06:21:47 --> Helper loaded: html_helper
INFO - 2024-03-21 06:21:47 --> Helper loaded: text_helper
INFO - 2024-03-21 06:21:47 --> Helper loaded: form_helper
INFO - 2024-03-21 06:21:47 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:21:47 --> Helper loaded: security_helper
INFO - 2024-03-21 06:21:47 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:21:47 --> Database Driver Class Initialized
INFO - 2024-03-21 06:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:21:47 --> Parser Class Initialized
INFO - 2024-03-21 06:21:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:21:47 --> Pagination Class Initialized
INFO - 2024-03-21 06:21:47 --> Form Validation Class Initialized
INFO - 2024-03-21 06:21:47 --> Controller Class Initialized
INFO - 2024-03-21 06:21:47 --> Model Class Initialized
DEBUG - 2024-03-21 06:21:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 06:21:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:21:47 --> Model Class Initialized
DEBUG - 2024-03-21 06:21:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:21:47 --> Model Class Initialized
INFO - 2024-03-21 06:21:47 --> Final output sent to browser
DEBUG - 2024-03-21 06:21:47 --> Total execution time: 0.0445
ERROR - 2024-03-21 06:21:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:21:47 --> Config Class Initialized
INFO - 2024-03-21 06:21:47 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:21:47 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:21:47 --> Utf8 Class Initialized
INFO - 2024-03-21 06:21:47 --> URI Class Initialized
INFO - 2024-03-21 06:21:47 --> Router Class Initialized
INFO - 2024-03-21 06:21:47 --> Output Class Initialized
INFO - 2024-03-21 06:21:47 --> Security Class Initialized
DEBUG - 2024-03-21 06:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:21:47 --> Input Class Initialized
INFO - 2024-03-21 06:21:47 --> Language Class Initialized
INFO - 2024-03-21 06:21:47 --> Loader Class Initialized
INFO - 2024-03-21 06:21:47 --> Helper loaded: url_helper
INFO - 2024-03-21 06:21:47 --> Helper loaded: file_helper
INFO - 2024-03-21 06:21:47 --> Helper loaded: html_helper
INFO - 2024-03-21 06:21:47 --> Helper loaded: text_helper
INFO - 2024-03-21 06:21:47 --> Helper loaded: form_helper
INFO - 2024-03-21 06:21:47 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:21:47 --> Helper loaded: security_helper
INFO - 2024-03-21 06:21:47 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:21:47 --> Database Driver Class Initialized
INFO - 2024-03-21 06:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:21:47 --> Parser Class Initialized
INFO - 2024-03-21 06:21:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:21:47 --> Pagination Class Initialized
INFO - 2024-03-21 06:21:47 --> Form Validation Class Initialized
INFO - 2024-03-21 06:21:47 --> Controller Class Initialized
INFO - 2024-03-21 06:21:47 --> Model Class Initialized
DEBUG - 2024-03-21 06:21:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 06:21:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:21:47 --> Model Class Initialized
DEBUG - 2024-03-21 06:21:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:21:47 --> Model Class Initialized
INFO - 2024-03-21 06:21:47 --> Final output sent to browser
DEBUG - 2024-03-21 06:21:47 --> Total execution time: 0.0516
ERROR - 2024-03-21 06:21:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:21:53 --> Config Class Initialized
INFO - 2024-03-21 06:21:53 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:21:53 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:21:53 --> Utf8 Class Initialized
INFO - 2024-03-21 06:21:53 --> URI Class Initialized
INFO - 2024-03-21 06:21:53 --> Router Class Initialized
INFO - 2024-03-21 06:21:53 --> Output Class Initialized
INFO - 2024-03-21 06:21:53 --> Security Class Initialized
DEBUG - 2024-03-21 06:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:21:53 --> Input Class Initialized
INFO - 2024-03-21 06:21:53 --> Language Class Initialized
INFO - 2024-03-21 06:21:53 --> Loader Class Initialized
INFO - 2024-03-21 06:21:53 --> Helper loaded: url_helper
INFO - 2024-03-21 06:21:53 --> Helper loaded: file_helper
INFO - 2024-03-21 06:21:53 --> Helper loaded: html_helper
INFO - 2024-03-21 06:21:53 --> Helper loaded: text_helper
INFO - 2024-03-21 06:21:53 --> Helper loaded: form_helper
INFO - 2024-03-21 06:21:53 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:21:53 --> Helper loaded: security_helper
INFO - 2024-03-21 06:21:53 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:21:53 --> Database Driver Class Initialized
INFO - 2024-03-21 06:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:21:53 --> Parser Class Initialized
INFO - 2024-03-21 06:21:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:21:53 --> Pagination Class Initialized
INFO - 2024-03-21 06:21:53 --> Form Validation Class Initialized
INFO - 2024-03-21 06:21:53 --> Controller Class Initialized
INFO - 2024-03-21 06:21:53 --> Model Class Initialized
DEBUG - 2024-03-21 06:21:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 06:21:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:21:53 --> Model Class Initialized
DEBUG - 2024-03-21 06:21:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:21:53 --> Model Class Initialized
INFO - 2024-03-21 06:21:53 --> Final output sent to browser
DEBUG - 2024-03-21 06:21:53 --> Total execution time: 0.1532
ERROR - 2024-03-21 06:29:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:29:22 --> Config Class Initialized
INFO - 2024-03-21 06:29:22 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:29:22 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:29:22 --> Utf8 Class Initialized
INFO - 2024-03-21 06:29:22 --> URI Class Initialized
DEBUG - 2024-03-21 06:29:22 --> No URI present. Default controller set.
INFO - 2024-03-21 06:29:22 --> Router Class Initialized
INFO - 2024-03-21 06:29:22 --> Output Class Initialized
INFO - 2024-03-21 06:29:22 --> Security Class Initialized
DEBUG - 2024-03-21 06:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:29:22 --> Input Class Initialized
INFO - 2024-03-21 06:29:22 --> Language Class Initialized
INFO - 2024-03-21 06:29:22 --> Loader Class Initialized
INFO - 2024-03-21 06:29:22 --> Helper loaded: url_helper
INFO - 2024-03-21 06:29:22 --> Helper loaded: file_helper
INFO - 2024-03-21 06:29:22 --> Helper loaded: html_helper
INFO - 2024-03-21 06:29:22 --> Helper loaded: text_helper
INFO - 2024-03-21 06:29:22 --> Helper loaded: form_helper
INFO - 2024-03-21 06:29:22 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:29:22 --> Helper loaded: security_helper
INFO - 2024-03-21 06:29:22 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:29:22 --> Database Driver Class Initialized
INFO - 2024-03-21 06:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:29:22 --> Parser Class Initialized
INFO - 2024-03-21 06:29:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:29:22 --> Pagination Class Initialized
INFO - 2024-03-21 06:29:22 --> Form Validation Class Initialized
INFO - 2024-03-21 06:29:22 --> Controller Class Initialized
INFO - 2024-03-21 06:29:22 --> Model Class Initialized
DEBUG - 2024-03-21 06:29:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-21 06:29:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:29:22 --> Config Class Initialized
INFO - 2024-03-21 06:29:22 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:29:22 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:29:22 --> Utf8 Class Initialized
INFO - 2024-03-21 06:29:22 --> URI Class Initialized
INFO - 2024-03-21 06:29:22 --> Router Class Initialized
INFO - 2024-03-21 06:29:22 --> Output Class Initialized
INFO - 2024-03-21 06:29:22 --> Security Class Initialized
DEBUG - 2024-03-21 06:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:29:22 --> Input Class Initialized
INFO - 2024-03-21 06:29:22 --> Language Class Initialized
INFO - 2024-03-21 06:29:22 --> Loader Class Initialized
INFO - 2024-03-21 06:29:22 --> Helper loaded: url_helper
INFO - 2024-03-21 06:29:22 --> Helper loaded: file_helper
INFO - 2024-03-21 06:29:22 --> Helper loaded: html_helper
INFO - 2024-03-21 06:29:22 --> Helper loaded: text_helper
INFO - 2024-03-21 06:29:22 --> Helper loaded: form_helper
INFO - 2024-03-21 06:29:22 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:29:22 --> Helper loaded: security_helper
INFO - 2024-03-21 06:29:22 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:29:22 --> Database Driver Class Initialized
INFO - 2024-03-21 06:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:29:22 --> Parser Class Initialized
INFO - 2024-03-21 06:29:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:29:22 --> Pagination Class Initialized
INFO - 2024-03-21 06:29:22 --> Form Validation Class Initialized
INFO - 2024-03-21 06:29:22 --> Controller Class Initialized
INFO - 2024-03-21 06:29:22 --> Model Class Initialized
DEBUG - 2024-03-21 06:29:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:29:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-21 06:29:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:29:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 06:29:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 06:29:22 --> Model Class Initialized
INFO - 2024-03-21 06:29:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 06:29:22 --> Final output sent to browser
DEBUG - 2024-03-21 06:29:22 --> Total execution time: 0.0327
ERROR - 2024-03-21 06:30:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:30:05 --> Config Class Initialized
INFO - 2024-03-21 06:30:05 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:30:05 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:30:05 --> Utf8 Class Initialized
INFO - 2024-03-21 06:30:05 --> URI Class Initialized
INFO - 2024-03-21 06:30:05 --> Router Class Initialized
INFO - 2024-03-21 06:30:05 --> Output Class Initialized
INFO - 2024-03-21 06:30:05 --> Security Class Initialized
DEBUG - 2024-03-21 06:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:30:05 --> Input Class Initialized
INFO - 2024-03-21 06:30:05 --> Language Class Initialized
INFO - 2024-03-21 06:30:05 --> Loader Class Initialized
INFO - 2024-03-21 06:30:05 --> Helper loaded: url_helper
INFO - 2024-03-21 06:30:05 --> Helper loaded: file_helper
INFO - 2024-03-21 06:30:05 --> Helper loaded: html_helper
INFO - 2024-03-21 06:30:05 --> Helper loaded: text_helper
INFO - 2024-03-21 06:30:05 --> Helper loaded: form_helper
INFO - 2024-03-21 06:30:05 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:30:05 --> Helper loaded: security_helper
INFO - 2024-03-21 06:30:05 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:30:05 --> Database Driver Class Initialized
INFO - 2024-03-21 06:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:30:05 --> Parser Class Initialized
INFO - 2024-03-21 06:30:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:30:05 --> Pagination Class Initialized
INFO - 2024-03-21 06:30:05 --> Form Validation Class Initialized
INFO - 2024-03-21 06:30:05 --> Controller Class Initialized
INFO - 2024-03-21 06:30:05 --> Model Class Initialized
DEBUG - 2024-03-21 06:30:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:30:05 --> Model Class Initialized
INFO - 2024-03-21 06:30:05 --> Final output sent to browser
DEBUG - 2024-03-21 06:30:05 --> Total execution time: 0.0199
ERROR - 2024-03-21 06:30:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:30:05 --> Config Class Initialized
INFO - 2024-03-21 06:30:05 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:30:05 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:30:05 --> Utf8 Class Initialized
INFO - 2024-03-21 06:30:05 --> URI Class Initialized
DEBUG - 2024-03-21 06:30:05 --> No URI present. Default controller set.
INFO - 2024-03-21 06:30:05 --> Router Class Initialized
INFO - 2024-03-21 06:30:05 --> Output Class Initialized
INFO - 2024-03-21 06:30:05 --> Security Class Initialized
DEBUG - 2024-03-21 06:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:30:05 --> Input Class Initialized
INFO - 2024-03-21 06:30:05 --> Language Class Initialized
INFO - 2024-03-21 06:30:05 --> Loader Class Initialized
INFO - 2024-03-21 06:30:05 --> Helper loaded: url_helper
INFO - 2024-03-21 06:30:05 --> Helper loaded: file_helper
INFO - 2024-03-21 06:30:05 --> Helper loaded: html_helper
INFO - 2024-03-21 06:30:05 --> Helper loaded: text_helper
INFO - 2024-03-21 06:30:05 --> Helper loaded: form_helper
INFO - 2024-03-21 06:30:05 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:30:05 --> Helper loaded: security_helper
INFO - 2024-03-21 06:30:05 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:30:05 --> Database Driver Class Initialized
INFO - 2024-03-21 06:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:30:05 --> Parser Class Initialized
INFO - 2024-03-21 06:30:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:30:05 --> Pagination Class Initialized
INFO - 2024-03-21 06:30:05 --> Form Validation Class Initialized
INFO - 2024-03-21 06:30:05 --> Controller Class Initialized
INFO - 2024-03-21 06:30:05 --> Model Class Initialized
DEBUG - 2024-03-21 06:30:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:30:05 --> Model Class Initialized
DEBUG - 2024-03-21 06:30:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:30:05 --> Model Class Initialized
INFO - 2024-03-21 06:30:05 --> Model Class Initialized
INFO - 2024-03-21 06:30:05 --> Model Class Initialized
INFO - 2024-03-21 06:30:05 --> Model Class Initialized
DEBUG - 2024-03-21 06:30:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 06:30:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:30:05 --> Model Class Initialized
INFO - 2024-03-21 06:30:05 --> Model Class Initialized
INFO - 2024-03-21 06:30:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-21 06:30:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:30:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 06:30:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 06:30:06 --> Model Class Initialized
INFO - 2024-03-21 06:30:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-21 06:30:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-21 06:30:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 06:30:06 --> Final output sent to browser
DEBUG - 2024-03-21 06:30:06 --> Total execution time: 0.4815
ERROR - 2024-03-21 06:30:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:30:07 --> Config Class Initialized
INFO - 2024-03-21 06:30:07 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:30:07 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:30:07 --> Utf8 Class Initialized
INFO - 2024-03-21 06:30:07 --> URI Class Initialized
INFO - 2024-03-21 06:30:07 --> Router Class Initialized
INFO - 2024-03-21 06:30:07 --> Output Class Initialized
INFO - 2024-03-21 06:30:07 --> Security Class Initialized
DEBUG - 2024-03-21 06:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:30:07 --> Input Class Initialized
INFO - 2024-03-21 06:30:07 --> Language Class Initialized
INFO - 2024-03-21 06:30:07 --> Loader Class Initialized
INFO - 2024-03-21 06:30:07 --> Helper loaded: url_helper
INFO - 2024-03-21 06:30:07 --> Helper loaded: file_helper
INFO - 2024-03-21 06:30:07 --> Helper loaded: html_helper
INFO - 2024-03-21 06:30:07 --> Helper loaded: text_helper
INFO - 2024-03-21 06:30:07 --> Helper loaded: form_helper
INFO - 2024-03-21 06:30:07 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:30:07 --> Helper loaded: security_helper
INFO - 2024-03-21 06:30:07 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:30:07 --> Database Driver Class Initialized
INFO - 2024-03-21 06:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:30:07 --> Parser Class Initialized
INFO - 2024-03-21 06:30:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:30:07 --> Pagination Class Initialized
INFO - 2024-03-21 06:30:07 --> Form Validation Class Initialized
INFO - 2024-03-21 06:30:07 --> Controller Class Initialized
DEBUG - 2024-03-21 06:30:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 06:30:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:30:07 --> Model Class Initialized
INFO - 2024-03-21 06:30:07 --> Final output sent to browser
DEBUG - 2024-03-21 06:30:07 --> Total execution time: 0.0137
ERROR - 2024-03-21 06:30:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:30:12 --> Config Class Initialized
INFO - 2024-03-21 06:30:12 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:30:12 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:30:12 --> Utf8 Class Initialized
INFO - 2024-03-21 06:30:12 --> URI Class Initialized
INFO - 2024-03-21 06:30:12 --> Router Class Initialized
INFO - 2024-03-21 06:30:12 --> Output Class Initialized
INFO - 2024-03-21 06:30:12 --> Security Class Initialized
DEBUG - 2024-03-21 06:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:30:12 --> Input Class Initialized
INFO - 2024-03-21 06:30:12 --> Language Class Initialized
INFO - 2024-03-21 06:30:12 --> Loader Class Initialized
INFO - 2024-03-21 06:30:12 --> Helper loaded: url_helper
INFO - 2024-03-21 06:30:12 --> Helper loaded: file_helper
INFO - 2024-03-21 06:30:12 --> Helper loaded: html_helper
INFO - 2024-03-21 06:30:12 --> Helper loaded: text_helper
INFO - 2024-03-21 06:30:12 --> Helper loaded: form_helper
INFO - 2024-03-21 06:30:12 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:30:12 --> Helper loaded: security_helper
INFO - 2024-03-21 06:30:12 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:30:12 --> Database Driver Class Initialized
INFO - 2024-03-21 06:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:30:12 --> Parser Class Initialized
INFO - 2024-03-21 06:30:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:30:12 --> Pagination Class Initialized
INFO - 2024-03-21 06:30:12 --> Form Validation Class Initialized
INFO - 2024-03-21 06:30:12 --> Controller Class Initialized
DEBUG - 2024-03-21 06:30:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 06:30:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:30:12 --> Model Class Initialized
DEBUG - 2024-03-21 06:30:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:30:12 --> Model Class Initialized
DEBUG - 2024-03-21 06:30:12 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:30:12 --> Model Class Initialized
INFO - 2024-03-21 06:30:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-03-21 06:30:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:30:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 06:30:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 06:30:12 --> Model Class Initialized
INFO - 2024-03-21 06:30:12 --> Model Class Initialized
INFO - 2024-03-21 06:30:12 --> Model Class Initialized
INFO - 2024-03-21 06:30:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-21 06:30:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-21 06:30:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 06:30:12 --> Final output sent to browser
DEBUG - 2024-03-21 06:30:12 --> Total execution time: 0.2587
ERROR - 2024-03-21 06:30:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:30:13 --> Config Class Initialized
INFO - 2024-03-21 06:30:13 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:30:13 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:30:13 --> Utf8 Class Initialized
INFO - 2024-03-21 06:30:13 --> URI Class Initialized
INFO - 2024-03-21 06:30:13 --> Router Class Initialized
INFO - 2024-03-21 06:30:13 --> Output Class Initialized
INFO - 2024-03-21 06:30:13 --> Security Class Initialized
DEBUG - 2024-03-21 06:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:30:13 --> Input Class Initialized
INFO - 2024-03-21 06:30:13 --> Language Class Initialized
INFO - 2024-03-21 06:30:13 --> Loader Class Initialized
INFO - 2024-03-21 06:30:13 --> Helper loaded: url_helper
INFO - 2024-03-21 06:30:13 --> Helper loaded: file_helper
INFO - 2024-03-21 06:30:13 --> Helper loaded: html_helper
INFO - 2024-03-21 06:30:13 --> Helper loaded: text_helper
INFO - 2024-03-21 06:30:13 --> Helper loaded: form_helper
INFO - 2024-03-21 06:30:13 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:30:13 --> Helper loaded: security_helper
INFO - 2024-03-21 06:30:13 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:30:13 --> Database Driver Class Initialized
INFO - 2024-03-21 06:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:30:13 --> Parser Class Initialized
INFO - 2024-03-21 06:30:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:30:13 --> Pagination Class Initialized
INFO - 2024-03-21 06:30:13 --> Form Validation Class Initialized
INFO - 2024-03-21 06:30:13 --> Controller Class Initialized
DEBUG - 2024-03-21 06:30:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 06:30:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:30:13 --> Model Class Initialized
DEBUG - 2024-03-21 06:30:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:30:13 --> Model Class Initialized
INFO - 2024-03-21 06:30:13 --> Final output sent to browser
DEBUG - 2024-03-21 06:30:13 --> Total execution time: 0.0420
ERROR - 2024-03-21 06:30:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:30:39 --> Config Class Initialized
INFO - 2024-03-21 06:30:39 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:30:39 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:30:39 --> Utf8 Class Initialized
INFO - 2024-03-21 06:30:39 --> URI Class Initialized
INFO - 2024-03-21 06:30:39 --> Router Class Initialized
INFO - 2024-03-21 06:30:39 --> Output Class Initialized
INFO - 2024-03-21 06:30:39 --> Security Class Initialized
DEBUG - 2024-03-21 06:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:30:39 --> Input Class Initialized
INFO - 2024-03-21 06:30:39 --> Language Class Initialized
INFO - 2024-03-21 06:30:39 --> Loader Class Initialized
INFO - 2024-03-21 06:30:39 --> Helper loaded: url_helper
INFO - 2024-03-21 06:30:39 --> Helper loaded: file_helper
INFO - 2024-03-21 06:30:39 --> Helper loaded: html_helper
INFO - 2024-03-21 06:30:39 --> Helper loaded: text_helper
INFO - 2024-03-21 06:30:39 --> Helper loaded: form_helper
INFO - 2024-03-21 06:30:39 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:30:39 --> Helper loaded: security_helper
INFO - 2024-03-21 06:30:39 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:30:39 --> Database Driver Class Initialized
INFO - 2024-03-21 06:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:30:39 --> Parser Class Initialized
INFO - 2024-03-21 06:30:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:30:39 --> Pagination Class Initialized
INFO - 2024-03-21 06:30:39 --> Form Validation Class Initialized
INFO - 2024-03-21 06:30:39 --> Controller Class Initialized
INFO - 2024-03-21 06:30:39 --> Model Class Initialized
DEBUG - 2024-03-21 06:30:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 06:30:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:30:39 --> Model Class Initialized
DEBUG - 2024-03-21 06:30:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:30:39 --> Model Class Initialized
INFO - 2024-03-21 06:30:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-21 06:30:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:30:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 06:30:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 06:30:39 --> Model Class Initialized
INFO - 2024-03-21 06:30:39 --> Model Class Initialized
INFO - 2024-03-21 06:30:39 --> Model Class Initialized
INFO - 2024-03-21 06:30:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-21 06:30:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-21 06:30:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 06:30:39 --> Final output sent to browser
DEBUG - 2024-03-21 06:30:39 --> Total execution time: 0.2777
ERROR - 2024-03-21 06:30:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 06:30:39 --> Config Class Initialized
INFO - 2024-03-21 06:30:39 --> Hooks Class Initialized
DEBUG - 2024-03-21 06:30:39 --> UTF-8 Support Enabled
INFO - 2024-03-21 06:30:39 --> Utf8 Class Initialized
INFO - 2024-03-21 06:30:39 --> URI Class Initialized
INFO - 2024-03-21 06:30:39 --> Router Class Initialized
INFO - 2024-03-21 06:30:39 --> Output Class Initialized
INFO - 2024-03-21 06:30:39 --> Security Class Initialized
DEBUG - 2024-03-21 06:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 06:30:39 --> Input Class Initialized
INFO - 2024-03-21 06:30:39 --> Language Class Initialized
INFO - 2024-03-21 06:30:39 --> Loader Class Initialized
INFO - 2024-03-21 06:30:39 --> Helper loaded: url_helper
INFO - 2024-03-21 06:30:39 --> Helper loaded: file_helper
INFO - 2024-03-21 06:30:39 --> Helper loaded: html_helper
INFO - 2024-03-21 06:30:39 --> Helper loaded: text_helper
INFO - 2024-03-21 06:30:39 --> Helper loaded: form_helper
INFO - 2024-03-21 06:30:39 --> Helper loaded: lang_helper
INFO - 2024-03-21 06:30:39 --> Helper loaded: security_helper
INFO - 2024-03-21 06:30:39 --> Helper loaded: cookie_helper
INFO - 2024-03-21 06:30:39 --> Database Driver Class Initialized
INFO - 2024-03-21 06:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 06:30:39 --> Parser Class Initialized
INFO - 2024-03-21 06:30:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 06:30:39 --> Pagination Class Initialized
INFO - 2024-03-21 06:30:39 --> Form Validation Class Initialized
INFO - 2024-03-21 06:30:39 --> Controller Class Initialized
INFO - 2024-03-21 06:30:39 --> Model Class Initialized
DEBUG - 2024-03-21 06:30:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 06:30:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:30:39 --> Model Class Initialized
DEBUG - 2024-03-21 06:30:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 06:30:39 --> Model Class Initialized
INFO - 2024-03-21 06:30:39 --> Final output sent to browser
DEBUG - 2024-03-21 06:30:39 --> Total execution time: 0.0856
ERROR - 2024-03-21 07:41:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 07:41:20 --> Config Class Initialized
INFO - 2024-03-21 07:41:20 --> Hooks Class Initialized
DEBUG - 2024-03-21 07:41:20 --> UTF-8 Support Enabled
INFO - 2024-03-21 07:41:20 --> Utf8 Class Initialized
INFO - 2024-03-21 07:41:20 --> URI Class Initialized
DEBUG - 2024-03-21 07:41:20 --> No URI present. Default controller set.
INFO - 2024-03-21 07:41:20 --> Router Class Initialized
INFO - 2024-03-21 07:41:20 --> Output Class Initialized
INFO - 2024-03-21 07:41:20 --> Security Class Initialized
DEBUG - 2024-03-21 07:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 07:41:20 --> Input Class Initialized
INFO - 2024-03-21 07:41:20 --> Language Class Initialized
INFO - 2024-03-21 07:41:20 --> Loader Class Initialized
INFO - 2024-03-21 07:41:20 --> Helper loaded: url_helper
INFO - 2024-03-21 07:41:20 --> Helper loaded: file_helper
INFO - 2024-03-21 07:41:20 --> Helper loaded: html_helper
INFO - 2024-03-21 07:41:20 --> Helper loaded: text_helper
INFO - 2024-03-21 07:41:20 --> Helper loaded: form_helper
INFO - 2024-03-21 07:41:20 --> Helper loaded: lang_helper
INFO - 2024-03-21 07:41:20 --> Helper loaded: security_helper
INFO - 2024-03-21 07:41:20 --> Helper loaded: cookie_helper
INFO - 2024-03-21 07:41:20 --> Database Driver Class Initialized
INFO - 2024-03-21 07:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 07:41:20 --> Parser Class Initialized
INFO - 2024-03-21 07:41:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 07:41:20 --> Pagination Class Initialized
INFO - 2024-03-21 07:41:20 --> Form Validation Class Initialized
INFO - 2024-03-21 07:41:20 --> Controller Class Initialized
INFO - 2024-03-21 07:41:20 --> Model Class Initialized
DEBUG - 2024-03-21 07:41:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:41:20 --> Model Class Initialized
DEBUG - 2024-03-21 07:41:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:41:20 --> Model Class Initialized
INFO - 2024-03-21 07:41:20 --> Model Class Initialized
INFO - 2024-03-21 07:41:20 --> Model Class Initialized
INFO - 2024-03-21 07:41:20 --> Model Class Initialized
DEBUG - 2024-03-21 07:41:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 07:41:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:41:20 --> Model Class Initialized
INFO - 2024-03-21 07:41:20 --> Model Class Initialized
INFO - 2024-03-21 07:41:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-21 07:41:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:41:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 07:41:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 07:41:21 --> Model Class Initialized
INFO - 2024-03-21 07:41:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-21 07:41:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-21 07:41:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 07:41:21 --> Final output sent to browser
DEBUG - 2024-03-21 07:41:21 --> Total execution time: 0.2657
ERROR - 2024-03-21 07:41:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 07:41:42 --> Config Class Initialized
INFO - 2024-03-21 07:41:42 --> Hooks Class Initialized
DEBUG - 2024-03-21 07:41:42 --> UTF-8 Support Enabled
INFO - 2024-03-21 07:41:42 --> Utf8 Class Initialized
INFO - 2024-03-21 07:41:42 --> URI Class Initialized
INFO - 2024-03-21 07:41:42 --> Router Class Initialized
INFO - 2024-03-21 07:41:42 --> Output Class Initialized
INFO - 2024-03-21 07:41:42 --> Security Class Initialized
DEBUG - 2024-03-21 07:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 07:41:42 --> Input Class Initialized
INFO - 2024-03-21 07:41:42 --> Language Class Initialized
INFO - 2024-03-21 07:41:42 --> Loader Class Initialized
INFO - 2024-03-21 07:41:42 --> Helper loaded: url_helper
INFO - 2024-03-21 07:41:42 --> Helper loaded: file_helper
INFO - 2024-03-21 07:41:42 --> Helper loaded: html_helper
INFO - 2024-03-21 07:41:42 --> Helper loaded: text_helper
INFO - 2024-03-21 07:41:42 --> Helper loaded: form_helper
INFO - 2024-03-21 07:41:42 --> Helper loaded: lang_helper
INFO - 2024-03-21 07:41:42 --> Helper loaded: security_helper
INFO - 2024-03-21 07:41:42 --> Helper loaded: cookie_helper
INFO - 2024-03-21 07:41:42 --> Database Driver Class Initialized
INFO - 2024-03-21 07:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 07:41:42 --> Parser Class Initialized
INFO - 2024-03-21 07:41:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 07:41:42 --> Pagination Class Initialized
INFO - 2024-03-21 07:41:42 --> Form Validation Class Initialized
INFO - 2024-03-21 07:41:42 --> Controller Class Initialized
INFO - 2024-03-21 07:41:42 --> Model Class Initialized
DEBUG - 2024-03-21 07:41:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 07:41:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:41:42 --> Model Class Initialized
DEBUG - 2024-03-21 07:41:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:41:42 --> Model Class Initialized
INFO - 2024-03-21 07:41:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-03-21 07:41:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:41:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 07:41:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 07:41:42 --> Model Class Initialized
INFO - 2024-03-21 07:41:42 --> Model Class Initialized
INFO - 2024-03-21 07:41:42 --> Model Class Initialized
INFO - 2024-03-21 07:41:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-21 07:41:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-21 07:41:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 07:41:42 --> Final output sent to browser
DEBUG - 2024-03-21 07:41:42 --> Total execution time: 0.2304
ERROR - 2024-03-21 07:41:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 07:41:49 --> Config Class Initialized
INFO - 2024-03-21 07:41:49 --> Hooks Class Initialized
DEBUG - 2024-03-21 07:41:49 --> UTF-8 Support Enabled
INFO - 2024-03-21 07:41:49 --> Utf8 Class Initialized
INFO - 2024-03-21 07:41:49 --> URI Class Initialized
INFO - 2024-03-21 07:41:49 --> Router Class Initialized
INFO - 2024-03-21 07:41:49 --> Output Class Initialized
INFO - 2024-03-21 07:41:49 --> Security Class Initialized
DEBUG - 2024-03-21 07:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 07:41:49 --> Input Class Initialized
INFO - 2024-03-21 07:41:49 --> Language Class Initialized
INFO - 2024-03-21 07:41:49 --> Loader Class Initialized
INFO - 2024-03-21 07:41:49 --> Helper loaded: url_helper
INFO - 2024-03-21 07:41:49 --> Helper loaded: file_helper
INFO - 2024-03-21 07:41:49 --> Helper loaded: html_helper
INFO - 2024-03-21 07:41:49 --> Helper loaded: text_helper
INFO - 2024-03-21 07:41:49 --> Helper loaded: form_helper
INFO - 2024-03-21 07:41:49 --> Helper loaded: lang_helper
INFO - 2024-03-21 07:41:49 --> Helper loaded: security_helper
INFO - 2024-03-21 07:41:49 --> Helper loaded: cookie_helper
INFO - 2024-03-21 07:41:49 --> Database Driver Class Initialized
INFO - 2024-03-21 07:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 07:41:49 --> Parser Class Initialized
INFO - 2024-03-21 07:41:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 07:41:49 --> Pagination Class Initialized
INFO - 2024-03-21 07:41:49 --> Form Validation Class Initialized
INFO - 2024-03-21 07:41:49 --> Controller Class Initialized
INFO - 2024-03-21 07:41:49 --> Model Class Initialized
DEBUG - 2024-03-21 07:41:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:41:49 --> Final output sent to browser
DEBUG - 2024-03-21 07:41:49 --> Total execution time: 0.0168
ERROR - 2024-03-21 07:41:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 07:41:51 --> Config Class Initialized
INFO - 2024-03-21 07:41:51 --> Hooks Class Initialized
DEBUG - 2024-03-21 07:41:51 --> UTF-8 Support Enabled
INFO - 2024-03-21 07:41:51 --> Utf8 Class Initialized
INFO - 2024-03-21 07:41:51 --> URI Class Initialized
INFO - 2024-03-21 07:41:51 --> Router Class Initialized
INFO - 2024-03-21 07:41:51 --> Output Class Initialized
INFO - 2024-03-21 07:41:51 --> Security Class Initialized
DEBUG - 2024-03-21 07:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 07:41:51 --> Input Class Initialized
INFO - 2024-03-21 07:41:51 --> Language Class Initialized
INFO - 2024-03-21 07:41:51 --> Loader Class Initialized
INFO - 2024-03-21 07:41:51 --> Helper loaded: url_helper
INFO - 2024-03-21 07:41:51 --> Helper loaded: file_helper
INFO - 2024-03-21 07:41:51 --> Helper loaded: html_helper
INFO - 2024-03-21 07:41:51 --> Helper loaded: text_helper
INFO - 2024-03-21 07:41:51 --> Helper loaded: form_helper
INFO - 2024-03-21 07:41:51 --> Helper loaded: lang_helper
INFO - 2024-03-21 07:41:51 --> Helper loaded: security_helper
INFO - 2024-03-21 07:41:51 --> Helper loaded: cookie_helper
INFO - 2024-03-21 07:41:51 --> Database Driver Class Initialized
INFO - 2024-03-21 07:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 07:41:51 --> Parser Class Initialized
INFO - 2024-03-21 07:41:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 07:41:51 --> Pagination Class Initialized
INFO - 2024-03-21 07:41:51 --> Form Validation Class Initialized
INFO - 2024-03-21 07:41:51 --> Controller Class Initialized
INFO - 2024-03-21 07:41:51 --> Model Class Initialized
DEBUG - 2024-03-21 07:41:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:41:51 --> Final output sent to browser
DEBUG - 2024-03-21 07:41:51 --> Total execution time: 0.0151
ERROR - 2024-03-21 07:41:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 07:41:52 --> Config Class Initialized
INFO - 2024-03-21 07:41:52 --> Hooks Class Initialized
DEBUG - 2024-03-21 07:41:52 --> UTF-8 Support Enabled
INFO - 2024-03-21 07:41:52 --> Utf8 Class Initialized
INFO - 2024-03-21 07:41:52 --> URI Class Initialized
INFO - 2024-03-21 07:41:52 --> Router Class Initialized
INFO - 2024-03-21 07:41:52 --> Output Class Initialized
INFO - 2024-03-21 07:41:52 --> Security Class Initialized
DEBUG - 2024-03-21 07:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 07:41:52 --> Input Class Initialized
INFO - 2024-03-21 07:41:52 --> Language Class Initialized
INFO - 2024-03-21 07:41:52 --> Loader Class Initialized
INFO - 2024-03-21 07:41:52 --> Helper loaded: url_helper
INFO - 2024-03-21 07:41:52 --> Helper loaded: file_helper
INFO - 2024-03-21 07:41:52 --> Helper loaded: html_helper
INFO - 2024-03-21 07:41:52 --> Helper loaded: text_helper
INFO - 2024-03-21 07:41:52 --> Helper loaded: form_helper
INFO - 2024-03-21 07:41:52 --> Helper loaded: lang_helper
INFO - 2024-03-21 07:41:52 --> Helper loaded: security_helper
INFO - 2024-03-21 07:41:52 --> Helper loaded: cookie_helper
INFO - 2024-03-21 07:41:52 --> Database Driver Class Initialized
INFO - 2024-03-21 07:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 07:41:52 --> Parser Class Initialized
INFO - 2024-03-21 07:41:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 07:41:52 --> Pagination Class Initialized
INFO - 2024-03-21 07:41:52 --> Form Validation Class Initialized
INFO - 2024-03-21 07:41:52 --> Controller Class Initialized
INFO - 2024-03-21 07:41:52 --> Final output sent to browser
DEBUG - 2024-03-21 07:41:52 --> Total execution time: 0.0134
ERROR - 2024-03-21 07:41:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 07:41:55 --> Config Class Initialized
INFO - 2024-03-21 07:41:55 --> Hooks Class Initialized
DEBUG - 2024-03-21 07:41:55 --> UTF-8 Support Enabled
INFO - 2024-03-21 07:41:55 --> Utf8 Class Initialized
INFO - 2024-03-21 07:41:55 --> URI Class Initialized
INFO - 2024-03-21 07:41:55 --> Router Class Initialized
INFO - 2024-03-21 07:41:55 --> Output Class Initialized
INFO - 2024-03-21 07:41:55 --> Security Class Initialized
DEBUG - 2024-03-21 07:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 07:41:55 --> Input Class Initialized
INFO - 2024-03-21 07:41:55 --> Language Class Initialized
INFO - 2024-03-21 07:41:55 --> Loader Class Initialized
INFO - 2024-03-21 07:41:55 --> Helper loaded: url_helper
INFO - 2024-03-21 07:41:55 --> Helper loaded: file_helper
INFO - 2024-03-21 07:41:55 --> Helper loaded: html_helper
INFO - 2024-03-21 07:41:55 --> Helper loaded: text_helper
INFO - 2024-03-21 07:41:55 --> Helper loaded: form_helper
INFO - 2024-03-21 07:41:55 --> Helper loaded: lang_helper
INFO - 2024-03-21 07:41:55 --> Helper loaded: security_helper
INFO - 2024-03-21 07:41:55 --> Helper loaded: cookie_helper
INFO - 2024-03-21 07:41:55 --> Database Driver Class Initialized
INFO - 2024-03-21 07:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 07:41:55 --> Parser Class Initialized
INFO - 2024-03-21 07:41:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 07:41:55 --> Pagination Class Initialized
INFO - 2024-03-21 07:41:55 --> Form Validation Class Initialized
INFO - 2024-03-21 07:41:55 --> Controller Class Initialized
INFO - 2024-03-21 07:41:55 --> Model Class Initialized
DEBUG - 2024-03-21 07:41:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 07:41:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:41:55 --> Model Class Initialized
DEBUG - 2024-03-21 07:41:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:41:55 --> Model Class Initialized
INFO - 2024-03-21 07:41:56 --> Final output sent to browser
DEBUG - 2024-03-21 07:41:56 --> Total execution time: 0.2084
ERROR - 2024-03-21 07:41:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 07:41:56 --> Config Class Initialized
INFO - 2024-03-21 07:41:56 --> Hooks Class Initialized
DEBUG - 2024-03-21 07:41:56 --> UTF-8 Support Enabled
INFO - 2024-03-21 07:41:56 --> Utf8 Class Initialized
INFO - 2024-03-21 07:41:56 --> URI Class Initialized
INFO - 2024-03-21 07:41:56 --> Router Class Initialized
INFO - 2024-03-21 07:41:56 --> Output Class Initialized
INFO - 2024-03-21 07:41:56 --> Security Class Initialized
DEBUG - 2024-03-21 07:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 07:41:56 --> Input Class Initialized
INFO - 2024-03-21 07:41:56 --> Language Class Initialized
INFO - 2024-03-21 07:41:56 --> Loader Class Initialized
INFO - 2024-03-21 07:41:56 --> Helper loaded: url_helper
INFO - 2024-03-21 07:41:56 --> Helper loaded: file_helper
INFO - 2024-03-21 07:41:56 --> Helper loaded: html_helper
INFO - 2024-03-21 07:41:56 --> Helper loaded: text_helper
INFO - 2024-03-21 07:41:56 --> Helper loaded: form_helper
INFO - 2024-03-21 07:41:56 --> Helper loaded: lang_helper
INFO - 2024-03-21 07:41:56 --> Helper loaded: security_helper
INFO - 2024-03-21 07:41:56 --> Helper loaded: cookie_helper
INFO - 2024-03-21 07:41:56 --> Database Driver Class Initialized
INFO - 2024-03-21 07:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 07:41:56 --> Parser Class Initialized
INFO - 2024-03-21 07:41:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 07:41:56 --> Pagination Class Initialized
INFO - 2024-03-21 07:41:56 --> Form Validation Class Initialized
INFO - 2024-03-21 07:41:56 --> Controller Class Initialized
INFO - 2024-03-21 07:41:56 --> Model Class Initialized
DEBUG - 2024-03-21 07:41:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 07:41:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:41:56 --> Model Class Initialized
DEBUG - 2024-03-21 07:41:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:41:56 --> Model Class Initialized
INFO - 2024-03-21 07:41:56 --> Final output sent to browser
DEBUG - 2024-03-21 07:41:56 --> Total execution time: 0.2198
ERROR - 2024-03-21 07:41:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 07:41:57 --> Config Class Initialized
INFO - 2024-03-21 07:41:57 --> Hooks Class Initialized
DEBUG - 2024-03-21 07:41:57 --> UTF-8 Support Enabled
INFO - 2024-03-21 07:41:57 --> Utf8 Class Initialized
INFO - 2024-03-21 07:41:57 --> URI Class Initialized
INFO - 2024-03-21 07:41:57 --> Router Class Initialized
INFO - 2024-03-21 07:41:57 --> Output Class Initialized
INFO - 2024-03-21 07:41:57 --> Security Class Initialized
DEBUG - 2024-03-21 07:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 07:41:57 --> Input Class Initialized
INFO - 2024-03-21 07:41:57 --> Language Class Initialized
INFO - 2024-03-21 07:41:57 --> Loader Class Initialized
INFO - 2024-03-21 07:41:57 --> Helper loaded: url_helper
INFO - 2024-03-21 07:41:57 --> Helper loaded: file_helper
INFO - 2024-03-21 07:41:57 --> Helper loaded: html_helper
INFO - 2024-03-21 07:41:57 --> Helper loaded: text_helper
INFO - 2024-03-21 07:41:57 --> Helper loaded: form_helper
INFO - 2024-03-21 07:41:57 --> Helper loaded: lang_helper
INFO - 2024-03-21 07:41:57 --> Helper loaded: security_helper
INFO - 2024-03-21 07:41:57 --> Helper loaded: cookie_helper
INFO - 2024-03-21 07:41:57 --> Database Driver Class Initialized
INFO - 2024-03-21 07:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 07:41:57 --> Parser Class Initialized
INFO - 2024-03-21 07:41:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 07:41:57 --> Pagination Class Initialized
INFO - 2024-03-21 07:41:57 --> Form Validation Class Initialized
INFO - 2024-03-21 07:41:57 --> Controller Class Initialized
INFO - 2024-03-21 07:41:57 --> Model Class Initialized
DEBUG - 2024-03-21 07:41:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 07:41:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:41:57 --> Model Class Initialized
DEBUG - 2024-03-21 07:41:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:41:57 --> Model Class Initialized
INFO - 2024-03-21 07:41:57 --> Final output sent to browser
DEBUG - 2024-03-21 07:41:57 --> Total execution time: 0.2081
ERROR - 2024-03-21 07:41:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 07:41:58 --> Config Class Initialized
INFO - 2024-03-21 07:41:58 --> Hooks Class Initialized
DEBUG - 2024-03-21 07:41:58 --> UTF-8 Support Enabled
INFO - 2024-03-21 07:41:58 --> Utf8 Class Initialized
INFO - 2024-03-21 07:41:58 --> URI Class Initialized
INFO - 2024-03-21 07:41:58 --> Router Class Initialized
INFO - 2024-03-21 07:41:58 --> Output Class Initialized
INFO - 2024-03-21 07:41:58 --> Security Class Initialized
DEBUG - 2024-03-21 07:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 07:41:58 --> Input Class Initialized
INFO - 2024-03-21 07:41:58 --> Language Class Initialized
INFO - 2024-03-21 07:41:58 --> Loader Class Initialized
INFO - 2024-03-21 07:41:58 --> Helper loaded: url_helper
INFO - 2024-03-21 07:41:58 --> Helper loaded: file_helper
INFO - 2024-03-21 07:41:58 --> Helper loaded: html_helper
INFO - 2024-03-21 07:41:58 --> Helper loaded: text_helper
INFO - 2024-03-21 07:41:58 --> Helper loaded: form_helper
INFO - 2024-03-21 07:41:58 --> Helper loaded: lang_helper
INFO - 2024-03-21 07:41:58 --> Helper loaded: security_helper
INFO - 2024-03-21 07:41:58 --> Helper loaded: cookie_helper
INFO - 2024-03-21 07:41:58 --> Database Driver Class Initialized
INFO - 2024-03-21 07:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 07:41:58 --> Parser Class Initialized
INFO - 2024-03-21 07:41:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 07:41:58 --> Pagination Class Initialized
INFO - 2024-03-21 07:41:58 --> Form Validation Class Initialized
INFO - 2024-03-21 07:41:58 --> Controller Class Initialized
INFO - 2024-03-21 07:41:58 --> Model Class Initialized
DEBUG - 2024-03-21 07:41:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 07:41:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:41:58 --> Model Class Initialized
DEBUG - 2024-03-21 07:41:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:41:58 --> Model Class Initialized
INFO - 2024-03-21 07:41:58 --> Final output sent to browser
DEBUG - 2024-03-21 07:41:58 --> Total execution time: 0.0266
ERROR - 2024-03-21 07:41:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 07:41:59 --> Config Class Initialized
INFO - 2024-03-21 07:41:59 --> Hooks Class Initialized
DEBUG - 2024-03-21 07:41:59 --> UTF-8 Support Enabled
INFO - 2024-03-21 07:41:59 --> Utf8 Class Initialized
INFO - 2024-03-21 07:41:59 --> URI Class Initialized
INFO - 2024-03-21 07:41:59 --> Router Class Initialized
INFO - 2024-03-21 07:41:59 --> Output Class Initialized
INFO - 2024-03-21 07:41:59 --> Security Class Initialized
DEBUG - 2024-03-21 07:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 07:41:59 --> Input Class Initialized
INFO - 2024-03-21 07:41:59 --> Language Class Initialized
INFO - 2024-03-21 07:41:59 --> Loader Class Initialized
INFO - 2024-03-21 07:41:59 --> Helper loaded: url_helper
INFO - 2024-03-21 07:41:59 --> Helper loaded: file_helper
INFO - 2024-03-21 07:41:59 --> Helper loaded: html_helper
INFO - 2024-03-21 07:41:59 --> Helper loaded: text_helper
INFO - 2024-03-21 07:41:59 --> Helper loaded: form_helper
INFO - 2024-03-21 07:41:59 --> Helper loaded: lang_helper
INFO - 2024-03-21 07:41:59 --> Helper loaded: security_helper
INFO - 2024-03-21 07:41:59 --> Helper loaded: cookie_helper
INFO - 2024-03-21 07:41:59 --> Database Driver Class Initialized
INFO - 2024-03-21 07:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 07:41:59 --> Parser Class Initialized
INFO - 2024-03-21 07:41:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 07:41:59 --> Pagination Class Initialized
INFO - 2024-03-21 07:41:59 --> Form Validation Class Initialized
INFO - 2024-03-21 07:41:59 --> Controller Class Initialized
INFO - 2024-03-21 07:41:59 --> Model Class Initialized
DEBUG - 2024-03-21 07:41:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 07:41:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:41:59 --> Model Class Initialized
INFO - 2024-03-21 07:41:59 --> Model Class Initialized
INFO - 2024-03-21 07:41:59 --> Final output sent to browser
DEBUG - 2024-03-21 07:41:59 --> Total execution time: 0.0193
ERROR - 2024-03-21 07:42:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 07:42:03 --> Config Class Initialized
INFO - 2024-03-21 07:42:03 --> Hooks Class Initialized
DEBUG - 2024-03-21 07:42:03 --> UTF-8 Support Enabled
INFO - 2024-03-21 07:42:03 --> Utf8 Class Initialized
INFO - 2024-03-21 07:42:03 --> URI Class Initialized
INFO - 2024-03-21 07:42:03 --> Router Class Initialized
INFO - 2024-03-21 07:42:03 --> Output Class Initialized
INFO - 2024-03-21 07:42:03 --> Security Class Initialized
DEBUG - 2024-03-21 07:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 07:42:03 --> Input Class Initialized
INFO - 2024-03-21 07:42:03 --> Language Class Initialized
INFO - 2024-03-21 07:42:03 --> Loader Class Initialized
INFO - 2024-03-21 07:42:03 --> Helper loaded: url_helper
INFO - 2024-03-21 07:42:03 --> Helper loaded: file_helper
INFO - 2024-03-21 07:42:03 --> Helper loaded: html_helper
INFO - 2024-03-21 07:42:03 --> Helper loaded: text_helper
INFO - 2024-03-21 07:42:03 --> Helper loaded: form_helper
INFO - 2024-03-21 07:42:03 --> Helper loaded: lang_helper
INFO - 2024-03-21 07:42:03 --> Helper loaded: security_helper
INFO - 2024-03-21 07:42:03 --> Helper loaded: cookie_helper
INFO - 2024-03-21 07:42:03 --> Database Driver Class Initialized
INFO - 2024-03-21 07:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 07:42:03 --> Parser Class Initialized
INFO - 2024-03-21 07:42:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 07:42:03 --> Pagination Class Initialized
INFO - 2024-03-21 07:42:03 --> Form Validation Class Initialized
INFO - 2024-03-21 07:42:03 --> Controller Class Initialized
INFO - 2024-03-21 07:42:03 --> Model Class Initialized
DEBUG - 2024-03-21 07:42:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 07:42:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:42:03 --> Model Class Initialized
INFO - 2024-03-21 07:42:03 --> Final output sent to browser
DEBUG - 2024-03-21 07:42:03 --> Total execution time: 0.0167
ERROR - 2024-03-21 07:42:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 07:42:15 --> Config Class Initialized
INFO - 2024-03-21 07:42:15 --> Hooks Class Initialized
DEBUG - 2024-03-21 07:42:15 --> UTF-8 Support Enabled
INFO - 2024-03-21 07:42:15 --> Utf8 Class Initialized
INFO - 2024-03-21 07:42:15 --> URI Class Initialized
INFO - 2024-03-21 07:42:15 --> Router Class Initialized
INFO - 2024-03-21 07:42:15 --> Output Class Initialized
INFO - 2024-03-21 07:42:15 --> Security Class Initialized
DEBUG - 2024-03-21 07:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 07:42:15 --> Input Class Initialized
INFO - 2024-03-21 07:42:15 --> Language Class Initialized
INFO - 2024-03-21 07:42:15 --> Loader Class Initialized
INFO - 2024-03-21 07:42:15 --> Helper loaded: url_helper
INFO - 2024-03-21 07:42:15 --> Helper loaded: file_helper
INFO - 2024-03-21 07:42:15 --> Helper loaded: html_helper
INFO - 2024-03-21 07:42:15 --> Helper loaded: text_helper
INFO - 2024-03-21 07:42:15 --> Helper loaded: form_helper
INFO - 2024-03-21 07:42:15 --> Helper loaded: lang_helper
INFO - 2024-03-21 07:42:15 --> Helper loaded: security_helper
INFO - 2024-03-21 07:42:15 --> Helper loaded: cookie_helper
INFO - 2024-03-21 07:42:15 --> Database Driver Class Initialized
INFO - 2024-03-21 07:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 07:42:15 --> Parser Class Initialized
INFO - 2024-03-21 07:42:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 07:42:15 --> Pagination Class Initialized
INFO - 2024-03-21 07:42:15 --> Form Validation Class Initialized
INFO - 2024-03-21 07:42:15 --> Controller Class Initialized
INFO - 2024-03-21 07:42:15 --> Model Class Initialized
DEBUG - 2024-03-21 07:42:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 07:42:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:42:15 --> Model Class Initialized
DEBUG - 2024-03-21 07:42:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:42:15 --> Model Class Initialized
INFO - 2024-03-21 07:42:15 --> Final output sent to browser
DEBUG - 2024-03-21 07:42:15 --> Total execution time: 0.2149
ERROR - 2024-03-21 07:42:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 07:42:16 --> Config Class Initialized
INFO - 2024-03-21 07:42:16 --> Hooks Class Initialized
DEBUG - 2024-03-21 07:42:16 --> UTF-8 Support Enabled
INFO - 2024-03-21 07:42:16 --> Utf8 Class Initialized
INFO - 2024-03-21 07:42:16 --> URI Class Initialized
INFO - 2024-03-21 07:42:16 --> Router Class Initialized
INFO - 2024-03-21 07:42:16 --> Output Class Initialized
INFO - 2024-03-21 07:42:16 --> Security Class Initialized
DEBUG - 2024-03-21 07:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 07:42:16 --> Input Class Initialized
INFO - 2024-03-21 07:42:16 --> Language Class Initialized
INFO - 2024-03-21 07:42:16 --> Loader Class Initialized
INFO - 2024-03-21 07:42:16 --> Helper loaded: url_helper
INFO - 2024-03-21 07:42:16 --> Helper loaded: file_helper
INFO - 2024-03-21 07:42:16 --> Helper loaded: html_helper
INFO - 2024-03-21 07:42:16 --> Helper loaded: text_helper
INFO - 2024-03-21 07:42:16 --> Helper loaded: form_helper
INFO - 2024-03-21 07:42:16 --> Helper loaded: lang_helper
INFO - 2024-03-21 07:42:16 --> Helper loaded: security_helper
INFO - 2024-03-21 07:42:16 --> Helper loaded: cookie_helper
INFO - 2024-03-21 07:42:16 --> Database Driver Class Initialized
INFO - 2024-03-21 07:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 07:42:16 --> Parser Class Initialized
INFO - 2024-03-21 07:42:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 07:42:16 --> Pagination Class Initialized
INFO - 2024-03-21 07:42:16 --> Form Validation Class Initialized
INFO - 2024-03-21 07:42:16 --> Controller Class Initialized
INFO - 2024-03-21 07:42:16 --> Model Class Initialized
DEBUG - 2024-03-21 07:42:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 07:42:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:42:16 --> Model Class Initialized
DEBUG - 2024-03-21 07:42:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:42:16 --> Model Class Initialized
INFO - 2024-03-21 07:42:16 --> Final output sent to browser
DEBUG - 2024-03-21 07:42:16 --> Total execution time: 0.2102
ERROR - 2024-03-21 07:42:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 07:42:16 --> Config Class Initialized
INFO - 2024-03-21 07:42:16 --> Hooks Class Initialized
DEBUG - 2024-03-21 07:42:16 --> UTF-8 Support Enabled
INFO - 2024-03-21 07:42:16 --> Utf8 Class Initialized
INFO - 2024-03-21 07:42:16 --> URI Class Initialized
INFO - 2024-03-21 07:42:16 --> Router Class Initialized
INFO - 2024-03-21 07:42:16 --> Output Class Initialized
INFO - 2024-03-21 07:42:16 --> Security Class Initialized
DEBUG - 2024-03-21 07:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 07:42:16 --> Input Class Initialized
INFO - 2024-03-21 07:42:16 --> Language Class Initialized
INFO - 2024-03-21 07:42:16 --> Loader Class Initialized
INFO - 2024-03-21 07:42:16 --> Helper loaded: url_helper
INFO - 2024-03-21 07:42:16 --> Helper loaded: file_helper
INFO - 2024-03-21 07:42:16 --> Helper loaded: html_helper
INFO - 2024-03-21 07:42:16 --> Helper loaded: text_helper
INFO - 2024-03-21 07:42:16 --> Helper loaded: form_helper
INFO - 2024-03-21 07:42:16 --> Helper loaded: lang_helper
INFO - 2024-03-21 07:42:16 --> Helper loaded: security_helper
INFO - 2024-03-21 07:42:16 --> Helper loaded: cookie_helper
INFO - 2024-03-21 07:42:16 --> Database Driver Class Initialized
INFO - 2024-03-21 07:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 07:42:16 --> Parser Class Initialized
INFO - 2024-03-21 07:42:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 07:42:16 --> Pagination Class Initialized
INFO - 2024-03-21 07:42:16 --> Form Validation Class Initialized
INFO - 2024-03-21 07:42:16 --> Controller Class Initialized
INFO - 2024-03-21 07:42:16 --> Model Class Initialized
DEBUG - 2024-03-21 07:42:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 07:42:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:42:16 --> Model Class Initialized
DEBUG - 2024-03-21 07:42:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:42:16 --> Model Class Initialized
INFO - 2024-03-21 07:42:16 --> Final output sent to browser
DEBUG - 2024-03-21 07:42:16 --> Total execution time: 0.2201
ERROR - 2024-03-21 07:42:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 07:42:17 --> Config Class Initialized
INFO - 2024-03-21 07:42:17 --> Hooks Class Initialized
DEBUG - 2024-03-21 07:42:17 --> UTF-8 Support Enabled
INFO - 2024-03-21 07:42:17 --> Utf8 Class Initialized
INFO - 2024-03-21 07:42:17 --> URI Class Initialized
INFO - 2024-03-21 07:42:17 --> Router Class Initialized
INFO - 2024-03-21 07:42:17 --> Output Class Initialized
INFO - 2024-03-21 07:42:17 --> Security Class Initialized
DEBUG - 2024-03-21 07:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 07:42:17 --> Input Class Initialized
INFO - 2024-03-21 07:42:17 --> Language Class Initialized
INFO - 2024-03-21 07:42:17 --> Loader Class Initialized
INFO - 2024-03-21 07:42:17 --> Helper loaded: url_helper
INFO - 2024-03-21 07:42:17 --> Helper loaded: file_helper
INFO - 2024-03-21 07:42:17 --> Helper loaded: html_helper
INFO - 2024-03-21 07:42:17 --> Helper loaded: text_helper
INFO - 2024-03-21 07:42:17 --> Helper loaded: form_helper
INFO - 2024-03-21 07:42:17 --> Helper loaded: lang_helper
INFO - 2024-03-21 07:42:17 --> Helper loaded: security_helper
INFO - 2024-03-21 07:42:17 --> Helper loaded: cookie_helper
INFO - 2024-03-21 07:42:17 --> Database Driver Class Initialized
INFO - 2024-03-21 07:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 07:42:17 --> Parser Class Initialized
INFO - 2024-03-21 07:42:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 07:42:17 --> Pagination Class Initialized
INFO - 2024-03-21 07:42:17 --> Form Validation Class Initialized
INFO - 2024-03-21 07:42:17 --> Controller Class Initialized
INFO - 2024-03-21 07:42:17 --> Model Class Initialized
DEBUG - 2024-03-21 07:42:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 07:42:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:42:17 --> Model Class Initialized
DEBUG - 2024-03-21 07:42:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:42:17 --> Model Class Initialized
INFO - 2024-03-21 07:42:17 --> Final output sent to browser
DEBUG - 2024-03-21 07:42:17 --> Total execution time: 0.0246
ERROR - 2024-03-21 07:42:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 07:42:19 --> Config Class Initialized
INFO - 2024-03-21 07:42:19 --> Hooks Class Initialized
DEBUG - 2024-03-21 07:42:19 --> UTF-8 Support Enabled
INFO - 2024-03-21 07:42:19 --> Utf8 Class Initialized
INFO - 2024-03-21 07:42:19 --> URI Class Initialized
INFO - 2024-03-21 07:42:19 --> Router Class Initialized
INFO - 2024-03-21 07:42:19 --> Output Class Initialized
INFO - 2024-03-21 07:42:19 --> Security Class Initialized
DEBUG - 2024-03-21 07:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 07:42:19 --> Input Class Initialized
INFO - 2024-03-21 07:42:19 --> Language Class Initialized
INFO - 2024-03-21 07:42:19 --> Loader Class Initialized
INFO - 2024-03-21 07:42:19 --> Helper loaded: url_helper
INFO - 2024-03-21 07:42:19 --> Helper loaded: file_helper
INFO - 2024-03-21 07:42:19 --> Helper loaded: html_helper
INFO - 2024-03-21 07:42:19 --> Helper loaded: text_helper
INFO - 2024-03-21 07:42:19 --> Helper loaded: form_helper
INFO - 2024-03-21 07:42:19 --> Helper loaded: lang_helper
INFO - 2024-03-21 07:42:19 --> Helper loaded: security_helper
INFO - 2024-03-21 07:42:19 --> Helper loaded: cookie_helper
INFO - 2024-03-21 07:42:19 --> Database Driver Class Initialized
INFO - 2024-03-21 07:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 07:42:19 --> Parser Class Initialized
INFO - 2024-03-21 07:42:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 07:42:19 --> Pagination Class Initialized
INFO - 2024-03-21 07:42:19 --> Form Validation Class Initialized
INFO - 2024-03-21 07:42:19 --> Controller Class Initialized
INFO - 2024-03-21 07:42:19 --> Model Class Initialized
DEBUG - 2024-03-21 07:42:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 07:42:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:42:19 --> Model Class Initialized
INFO - 2024-03-21 07:42:19 --> Model Class Initialized
INFO - 2024-03-21 07:42:19 --> Final output sent to browser
DEBUG - 2024-03-21 07:42:19 --> Total execution time: 0.0236
ERROR - 2024-03-21 07:42:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 07:42:21 --> Config Class Initialized
INFO - 2024-03-21 07:42:21 --> Hooks Class Initialized
DEBUG - 2024-03-21 07:42:21 --> UTF-8 Support Enabled
INFO - 2024-03-21 07:42:21 --> Utf8 Class Initialized
INFO - 2024-03-21 07:42:21 --> URI Class Initialized
INFO - 2024-03-21 07:42:21 --> Router Class Initialized
INFO - 2024-03-21 07:42:21 --> Output Class Initialized
INFO - 2024-03-21 07:42:21 --> Security Class Initialized
DEBUG - 2024-03-21 07:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 07:42:21 --> Input Class Initialized
INFO - 2024-03-21 07:42:21 --> Language Class Initialized
INFO - 2024-03-21 07:42:21 --> Loader Class Initialized
INFO - 2024-03-21 07:42:21 --> Helper loaded: url_helper
INFO - 2024-03-21 07:42:21 --> Helper loaded: file_helper
INFO - 2024-03-21 07:42:21 --> Helper loaded: html_helper
INFO - 2024-03-21 07:42:21 --> Helper loaded: text_helper
INFO - 2024-03-21 07:42:21 --> Helper loaded: form_helper
INFO - 2024-03-21 07:42:21 --> Helper loaded: lang_helper
INFO - 2024-03-21 07:42:21 --> Helper loaded: security_helper
INFO - 2024-03-21 07:42:21 --> Helper loaded: cookie_helper
INFO - 2024-03-21 07:42:21 --> Database Driver Class Initialized
INFO - 2024-03-21 07:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 07:42:21 --> Parser Class Initialized
INFO - 2024-03-21 07:42:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 07:42:21 --> Pagination Class Initialized
INFO - 2024-03-21 07:42:21 --> Form Validation Class Initialized
INFO - 2024-03-21 07:42:21 --> Controller Class Initialized
INFO - 2024-03-21 07:42:21 --> Model Class Initialized
DEBUG - 2024-03-21 07:42:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 07:42:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:42:21 --> Model Class Initialized
INFO - 2024-03-21 07:42:21 --> Final output sent to browser
DEBUG - 2024-03-21 07:42:21 --> Total execution time: 0.0169
ERROR - 2024-03-21 07:42:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 07:42:31 --> Config Class Initialized
INFO - 2024-03-21 07:42:31 --> Hooks Class Initialized
DEBUG - 2024-03-21 07:42:31 --> UTF-8 Support Enabled
INFO - 2024-03-21 07:42:31 --> Utf8 Class Initialized
INFO - 2024-03-21 07:42:31 --> URI Class Initialized
INFO - 2024-03-21 07:42:31 --> Router Class Initialized
INFO - 2024-03-21 07:42:31 --> Output Class Initialized
INFO - 2024-03-21 07:42:31 --> Security Class Initialized
DEBUG - 2024-03-21 07:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 07:42:31 --> Input Class Initialized
INFO - 2024-03-21 07:42:31 --> Language Class Initialized
INFO - 2024-03-21 07:42:31 --> Loader Class Initialized
INFO - 2024-03-21 07:42:31 --> Helper loaded: url_helper
INFO - 2024-03-21 07:42:31 --> Helper loaded: file_helper
INFO - 2024-03-21 07:42:31 --> Helper loaded: html_helper
INFO - 2024-03-21 07:42:31 --> Helper loaded: text_helper
INFO - 2024-03-21 07:42:31 --> Helper loaded: form_helper
INFO - 2024-03-21 07:42:31 --> Helper loaded: lang_helper
INFO - 2024-03-21 07:42:31 --> Helper loaded: security_helper
INFO - 2024-03-21 07:42:31 --> Helper loaded: cookie_helper
INFO - 2024-03-21 07:42:31 --> Database Driver Class Initialized
INFO - 2024-03-21 07:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 07:42:31 --> Parser Class Initialized
INFO - 2024-03-21 07:42:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 07:42:31 --> Pagination Class Initialized
INFO - 2024-03-21 07:42:31 --> Form Validation Class Initialized
INFO - 2024-03-21 07:42:31 --> Controller Class Initialized
INFO - 2024-03-21 07:42:31 --> Model Class Initialized
DEBUG - 2024-03-21 07:42:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 07:42:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:42:31 --> Model Class Initialized
DEBUG - 2024-03-21 07:42:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:42:31 --> Model Class Initialized
INFO - 2024-03-21 07:42:32 --> Final output sent to browser
DEBUG - 2024-03-21 07:42:32 --> Total execution time: 0.2175
ERROR - 2024-03-21 07:42:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 07:42:32 --> Config Class Initialized
INFO - 2024-03-21 07:42:32 --> Hooks Class Initialized
DEBUG - 2024-03-21 07:42:32 --> UTF-8 Support Enabled
INFO - 2024-03-21 07:42:32 --> Utf8 Class Initialized
INFO - 2024-03-21 07:42:32 --> URI Class Initialized
INFO - 2024-03-21 07:42:32 --> Router Class Initialized
INFO - 2024-03-21 07:42:32 --> Output Class Initialized
INFO - 2024-03-21 07:42:32 --> Security Class Initialized
DEBUG - 2024-03-21 07:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 07:42:32 --> Input Class Initialized
INFO - 2024-03-21 07:42:32 --> Language Class Initialized
INFO - 2024-03-21 07:42:32 --> Loader Class Initialized
INFO - 2024-03-21 07:42:32 --> Helper loaded: url_helper
INFO - 2024-03-21 07:42:32 --> Helper loaded: file_helper
INFO - 2024-03-21 07:42:32 --> Helper loaded: html_helper
INFO - 2024-03-21 07:42:32 --> Helper loaded: text_helper
INFO - 2024-03-21 07:42:32 --> Helper loaded: form_helper
INFO - 2024-03-21 07:42:32 --> Helper loaded: lang_helper
INFO - 2024-03-21 07:42:32 --> Helper loaded: security_helper
INFO - 2024-03-21 07:42:32 --> Helper loaded: cookie_helper
INFO - 2024-03-21 07:42:32 --> Database Driver Class Initialized
INFO - 2024-03-21 07:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 07:42:32 --> Parser Class Initialized
INFO - 2024-03-21 07:42:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 07:42:32 --> Pagination Class Initialized
INFO - 2024-03-21 07:42:32 --> Form Validation Class Initialized
INFO - 2024-03-21 07:42:32 --> Controller Class Initialized
INFO - 2024-03-21 07:42:32 --> Model Class Initialized
DEBUG - 2024-03-21 07:42:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 07:42:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:42:32 --> Model Class Initialized
DEBUG - 2024-03-21 07:42:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:42:32 --> Model Class Initialized
INFO - 2024-03-21 07:42:32 --> Final output sent to browser
DEBUG - 2024-03-21 07:42:32 --> Total execution time: 0.2078
ERROR - 2024-03-21 07:42:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 07:42:32 --> Config Class Initialized
INFO - 2024-03-21 07:42:32 --> Hooks Class Initialized
DEBUG - 2024-03-21 07:42:32 --> UTF-8 Support Enabled
INFO - 2024-03-21 07:42:32 --> Utf8 Class Initialized
INFO - 2024-03-21 07:42:32 --> URI Class Initialized
INFO - 2024-03-21 07:42:32 --> Router Class Initialized
INFO - 2024-03-21 07:42:32 --> Output Class Initialized
INFO - 2024-03-21 07:42:32 --> Security Class Initialized
DEBUG - 2024-03-21 07:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 07:42:32 --> Input Class Initialized
INFO - 2024-03-21 07:42:32 --> Language Class Initialized
INFO - 2024-03-21 07:42:32 --> Loader Class Initialized
INFO - 2024-03-21 07:42:32 --> Helper loaded: url_helper
INFO - 2024-03-21 07:42:32 --> Helper loaded: file_helper
INFO - 2024-03-21 07:42:32 --> Helper loaded: html_helper
INFO - 2024-03-21 07:42:32 --> Helper loaded: text_helper
INFO - 2024-03-21 07:42:32 --> Helper loaded: form_helper
INFO - 2024-03-21 07:42:32 --> Helper loaded: lang_helper
INFO - 2024-03-21 07:42:32 --> Helper loaded: security_helper
INFO - 2024-03-21 07:42:32 --> Helper loaded: cookie_helper
INFO - 2024-03-21 07:42:33 --> Database Driver Class Initialized
INFO - 2024-03-21 07:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 07:42:33 --> Parser Class Initialized
INFO - 2024-03-21 07:42:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 07:42:33 --> Pagination Class Initialized
INFO - 2024-03-21 07:42:33 --> Form Validation Class Initialized
INFO - 2024-03-21 07:42:33 --> Controller Class Initialized
INFO - 2024-03-21 07:42:33 --> Model Class Initialized
DEBUG - 2024-03-21 07:42:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 07:42:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:42:33 --> Model Class Initialized
DEBUG - 2024-03-21 07:42:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:42:33 --> Model Class Initialized
INFO - 2024-03-21 07:42:33 --> Final output sent to browser
DEBUG - 2024-03-21 07:42:33 --> Total execution time: 0.2135
ERROR - 2024-03-21 07:42:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 07:42:34 --> Config Class Initialized
INFO - 2024-03-21 07:42:34 --> Hooks Class Initialized
DEBUG - 2024-03-21 07:42:34 --> UTF-8 Support Enabled
INFO - 2024-03-21 07:42:34 --> Utf8 Class Initialized
INFO - 2024-03-21 07:42:34 --> URI Class Initialized
INFO - 2024-03-21 07:42:34 --> Router Class Initialized
INFO - 2024-03-21 07:42:34 --> Output Class Initialized
INFO - 2024-03-21 07:42:34 --> Security Class Initialized
DEBUG - 2024-03-21 07:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 07:42:34 --> Input Class Initialized
INFO - 2024-03-21 07:42:34 --> Language Class Initialized
INFO - 2024-03-21 07:42:34 --> Loader Class Initialized
INFO - 2024-03-21 07:42:34 --> Helper loaded: url_helper
INFO - 2024-03-21 07:42:34 --> Helper loaded: file_helper
INFO - 2024-03-21 07:42:34 --> Helper loaded: html_helper
INFO - 2024-03-21 07:42:34 --> Helper loaded: text_helper
INFO - 2024-03-21 07:42:34 --> Helper loaded: form_helper
INFO - 2024-03-21 07:42:34 --> Helper loaded: lang_helper
INFO - 2024-03-21 07:42:34 --> Helper loaded: security_helper
INFO - 2024-03-21 07:42:34 --> Helper loaded: cookie_helper
INFO - 2024-03-21 07:42:34 --> Database Driver Class Initialized
INFO - 2024-03-21 07:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 07:42:34 --> Parser Class Initialized
INFO - 2024-03-21 07:42:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 07:42:34 --> Pagination Class Initialized
INFO - 2024-03-21 07:42:34 --> Form Validation Class Initialized
INFO - 2024-03-21 07:42:34 --> Controller Class Initialized
INFO - 2024-03-21 07:42:34 --> Model Class Initialized
DEBUG - 2024-03-21 07:42:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 07:42:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:42:34 --> Model Class Initialized
DEBUG - 2024-03-21 07:42:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:42:34 --> Model Class Initialized
INFO - 2024-03-21 07:42:34 --> Final output sent to browser
DEBUG - 2024-03-21 07:42:34 --> Total execution time: 0.0317
ERROR - 2024-03-21 07:42:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 07:42:35 --> Config Class Initialized
INFO - 2024-03-21 07:42:35 --> Hooks Class Initialized
DEBUG - 2024-03-21 07:42:35 --> UTF-8 Support Enabled
INFO - 2024-03-21 07:42:35 --> Utf8 Class Initialized
INFO - 2024-03-21 07:42:35 --> URI Class Initialized
INFO - 2024-03-21 07:42:35 --> Router Class Initialized
INFO - 2024-03-21 07:42:35 --> Output Class Initialized
INFO - 2024-03-21 07:42:35 --> Security Class Initialized
DEBUG - 2024-03-21 07:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 07:42:35 --> Input Class Initialized
INFO - 2024-03-21 07:42:35 --> Language Class Initialized
INFO - 2024-03-21 07:42:35 --> Loader Class Initialized
INFO - 2024-03-21 07:42:35 --> Helper loaded: url_helper
INFO - 2024-03-21 07:42:35 --> Helper loaded: file_helper
INFO - 2024-03-21 07:42:35 --> Helper loaded: html_helper
INFO - 2024-03-21 07:42:35 --> Helper loaded: text_helper
INFO - 2024-03-21 07:42:35 --> Helper loaded: form_helper
INFO - 2024-03-21 07:42:35 --> Helper loaded: lang_helper
INFO - 2024-03-21 07:42:35 --> Helper loaded: security_helper
INFO - 2024-03-21 07:42:35 --> Helper loaded: cookie_helper
INFO - 2024-03-21 07:42:35 --> Database Driver Class Initialized
INFO - 2024-03-21 07:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 07:42:35 --> Parser Class Initialized
INFO - 2024-03-21 07:42:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 07:42:35 --> Pagination Class Initialized
INFO - 2024-03-21 07:42:35 --> Form Validation Class Initialized
INFO - 2024-03-21 07:42:35 --> Controller Class Initialized
INFO - 2024-03-21 07:42:35 --> Model Class Initialized
DEBUG - 2024-03-21 07:42:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 07:42:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:42:35 --> Model Class Initialized
INFO - 2024-03-21 07:42:35 --> Model Class Initialized
INFO - 2024-03-21 07:42:35 --> Final output sent to browser
DEBUG - 2024-03-21 07:42:35 --> Total execution time: 0.0217
ERROR - 2024-03-21 07:42:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 07:42:37 --> Config Class Initialized
INFO - 2024-03-21 07:42:37 --> Hooks Class Initialized
DEBUG - 2024-03-21 07:42:37 --> UTF-8 Support Enabled
INFO - 2024-03-21 07:42:37 --> Utf8 Class Initialized
INFO - 2024-03-21 07:42:37 --> URI Class Initialized
INFO - 2024-03-21 07:42:37 --> Router Class Initialized
INFO - 2024-03-21 07:42:37 --> Output Class Initialized
INFO - 2024-03-21 07:42:37 --> Security Class Initialized
DEBUG - 2024-03-21 07:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 07:42:37 --> Input Class Initialized
INFO - 2024-03-21 07:42:37 --> Language Class Initialized
INFO - 2024-03-21 07:42:37 --> Loader Class Initialized
INFO - 2024-03-21 07:42:37 --> Helper loaded: url_helper
INFO - 2024-03-21 07:42:37 --> Helper loaded: file_helper
INFO - 2024-03-21 07:42:37 --> Helper loaded: html_helper
INFO - 2024-03-21 07:42:37 --> Helper loaded: text_helper
INFO - 2024-03-21 07:42:37 --> Helper loaded: form_helper
INFO - 2024-03-21 07:42:37 --> Helper loaded: lang_helper
INFO - 2024-03-21 07:42:37 --> Helper loaded: security_helper
INFO - 2024-03-21 07:42:37 --> Helper loaded: cookie_helper
INFO - 2024-03-21 07:42:37 --> Database Driver Class Initialized
INFO - 2024-03-21 07:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 07:42:37 --> Parser Class Initialized
INFO - 2024-03-21 07:42:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 07:42:37 --> Pagination Class Initialized
INFO - 2024-03-21 07:42:37 --> Form Validation Class Initialized
INFO - 2024-03-21 07:42:37 --> Controller Class Initialized
INFO - 2024-03-21 07:42:37 --> Model Class Initialized
DEBUG - 2024-03-21 07:42:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 07:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:42:37 --> Model Class Initialized
INFO - 2024-03-21 07:42:37 --> Final output sent to browser
DEBUG - 2024-03-21 07:42:37 --> Total execution time: 0.0163
ERROR - 2024-03-21 07:42:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 07:42:47 --> Config Class Initialized
INFO - 2024-03-21 07:42:47 --> Hooks Class Initialized
DEBUG - 2024-03-21 07:42:47 --> UTF-8 Support Enabled
INFO - 2024-03-21 07:42:47 --> Utf8 Class Initialized
INFO - 2024-03-21 07:42:47 --> URI Class Initialized
INFO - 2024-03-21 07:42:47 --> Router Class Initialized
INFO - 2024-03-21 07:42:47 --> Output Class Initialized
INFO - 2024-03-21 07:42:47 --> Security Class Initialized
DEBUG - 2024-03-21 07:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 07:42:47 --> Input Class Initialized
INFO - 2024-03-21 07:42:47 --> Language Class Initialized
INFO - 2024-03-21 07:42:47 --> Loader Class Initialized
INFO - 2024-03-21 07:42:47 --> Helper loaded: url_helper
INFO - 2024-03-21 07:42:47 --> Helper loaded: file_helper
INFO - 2024-03-21 07:42:47 --> Helper loaded: html_helper
INFO - 2024-03-21 07:42:47 --> Helper loaded: text_helper
INFO - 2024-03-21 07:42:47 --> Helper loaded: form_helper
INFO - 2024-03-21 07:42:47 --> Helper loaded: lang_helper
INFO - 2024-03-21 07:42:47 --> Helper loaded: security_helper
INFO - 2024-03-21 07:42:47 --> Helper loaded: cookie_helper
INFO - 2024-03-21 07:42:47 --> Database Driver Class Initialized
INFO - 2024-03-21 07:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 07:42:47 --> Parser Class Initialized
INFO - 2024-03-21 07:42:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 07:42:47 --> Pagination Class Initialized
INFO - 2024-03-21 07:42:47 --> Form Validation Class Initialized
INFO - 2024-03-21 07:42:47 --> Controller Class Initialized
INFO - 2024-03-21 07:42:47 --> Model Class Initialized
DEBUG - 2024-03-21 07:42:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 07:42:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:42:47 --> Model Class Initialized
DEBUG - 2024-03-21 07:42:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:42:47 --> Model Class Initialized
INFO - 2024-03-21 07:42:47 --> Email Class Initialized
DEBUG - 2024-03-21 07:42:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:42:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-03-21 07:42:47 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-03-21 07:42:47 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-03-21 07:42:47 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-03-21 07:42:47 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-03-21 07:42:47 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-03-21 07:42:47 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-03-21 07:42:47 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-21 07:42:47 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-21 07:42:47 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-21 07:42:47 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-21 07:42:47 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-21 07:42:48 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-03-21 07:42:48 --> Language file loaded: language/english/email_lang.php
INFO - 2024-03-21 07:42:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-03-21 07:42:48 --> Final output sent to browser
DEBUG - 2024-03-21 07:42:48 --> Total execution time: 0.2460
ERROR - 2024-03-21 07:42:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 07:42:49 --> Config Class Initialized
INFO - 2024-03-21 07:42:49 --> Hooks Class Initialized
DEBUG - 2024-03-21 07:42:49 --> UTF-8 Support Enabled
INFO - 2024-03-21 07:42:49 --> Utf8 Class Initialized
INFO - 2024-03-21 07:42:49 --> URI Class Initialized
INFO - 2024-03-21 07:42:49 --> Router Class Initialized
INFO - 2024-03-21 07:42:49 --> Output Class Initialized
INFO - 2024-03-21 07:42:49 --> Security Class Initialized
DEBUG - 2024-03-21 07:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 07:42:49 --> Input Class Initialized
INFO - 2024-03-21 07:42:49 --> Language Class Initialized
INFO - 2024-03-21 07:42:49 --> Loader Class Initialized
INFO - 2024-03-21 07:42:49 --> Helper loaded: url_helper
INFO - 2024-03-21 07:42:49 --> Helper loaded: file_helper
INFO - 2024-03-21 07:42:49 --> Helper loaded: html_helper
INFO - 2024-03-21 07:42:49 --> Helper loaded: text_helper
INFO - 2024-03-21 07:42:49 --> Helper loaded: form_helper
INFO - 2024-03-21 07:42:49 --> Helper loaded: lang_helper
INFO - 2024-03-21 07:42:49 --> Helper loaded: security_helper
INFO - 2024-03-21 07:42:49 --> Helper loaded: cookie_helper
INFO - 2024-03-21 07:42:49 --> Database Driver Class Initialized
INFO - 2024-03-21 07:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 07:42:49 --> Parser Class Initialized
INFO - 2024-03-21 07:42:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 07:42:49 --> Pagination Class Initialized
INFO - 2024-03-21 07:42:49 --> Form Validation Class Initialized
INFO - 2024-03-21 07:42:49 --> Controller Class Initialized
INFO - 2024-03-21 07:42:49 --> Model Class Initialized
DEBUG - 2024-03-21 07:42:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-21 07:42:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:42:49 --> Model Class Initialized
DEBUG - 2024-03-21 07:42:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:42:49 --> Model Class Initialized
INFO - 2024-03-21 07:42:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-03-21 07:42:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 07:42:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 07:42:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 07:42:49 --> Model Class Initialized
INFO - 2024-03-21 07:42:49 --> Model Class Initialized
INFO - 2024-03-21 07:42:49 --> Model Class Initialized
INFO - 2024-03-21 07:42:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-21 07:42:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-21 07:42:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 07:42:49 --> Final output sent to browser
DEBUG - 2024-03-21 07:42:49 --> Total execution time: 0.1809
ERROR - 2024-03-21 11:36:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 11:36:28 --> Config Class Initialized
INFO - 2024-03-21 11:36:28 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:36:28 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:36:28 --> Utf8 Class Initialized
INFO - 2024-03-21 11:36:28 --> URI Class Initialized
DEBUG - 2024-03-21 11:36:28 --> No URI present. Default controller set.
INFO - 2024-03-21 11:36:28 --> Router Class Initialized
INFO - 2024-03-21 11:36:28 --> Output Class Initialized
INFO - 2024-03-21 11:36:28 --> Security Class Initialized
DEBUG - 2024-03-21 11:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:36:28 --> Input Class Initialized
INFO - 2024-03-21 11:36:28 --> Language Class Initialized
INFO - 2024-03-21 11:36:28 --> Loader Class Initialized
INFO - 2024-03-21 11:36:28 --> Helper loaded: url_helper
INFO - 2024-03-21 11:36:28 --> Helper loaded: file_helper
INFO - 2024-03-21 11:36:28 --> Helper loaded: html_helper
INFO - 2024-03-21 11:36:28 --> Helper loaded: text_helper
INFO - 2024-03-21 11:36:28 --> Helper loaded: form_helper
INFO - 2024-03-21 11:36:28 --> Helper loaded: lang_helper
INFO - 2024-03-21 11:36:28 --> Helper loaded: security_helper
INFO - 2024-03-21 11:36:28 --> Helper loaded: cookie_helper
INFO - 2024-03-21 11:36:28 --> Database Driver Class Initialized
INFO - 2024-03-21 11:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:36:28 --> Parser Class Initialized
INFO - 2024-03-21 11:36:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 11:36:28 --> Pagination Class Initialized
INFO - 2024-03-21 11:36:28 --> Form Validation Class Initialized
INFO - 2024-03-21 11:36:28 --> Controller Class Initialized
INFO - 2024-03-21 11:36:28 --> Model Class Initialized
DEBUG - 2024-03-21 11:36:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-21 11:36:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 11:36:28 --> Config Class Initialized
INFO - 2024-03-21 11:36:28 --> Hooks Class Initialized
DEBUG - 2024-03-21 11:36:28 --> UTF-8 Support Enabled
INFO - 2024-03-21 11:36:28 --> Utf8 Class Initialized
INFO - 2024-03-21 11:36:28 --> URI Class Initialized
INFO - 2024-03-21 11:36:28 --> Router Class Initialized
INFO - 2024-03-21 11:36:28 --> Output Class Initialized
INFO - 2024-03-21 11:36:28 --> Security Class Initialized
DEBUG - 2024-03-21 11:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 11:36:28 --> Input Class Initialized
INFO - 2024-03-21 11:36:28 --> Language Class Initialized
INFO - 2024-03-21 11:36:28 --> Loader Class Initialized
INFO - 2024-03-21 11:36:28 --> Helper loaded: url_helper
INFO - 2024-03-21 11:36:28 --> Helper loaded: file_helper
INFO - 2024-03-21 11:36:28 --> Helper loaded: html_helper
INFO - 2024-03-21 11:36:28 --> Helper loaded: text_helper
INFO - 2024-03-21 11:36:28 --> Helper loaded: form_helper
INFO - 2024-03-21 11:36:28 --> Helper loaded: lang_helper
INFO - 2024-03-21 11:36:28 --> Helper loaded: security_helper
INFO - 2024-03-21 11:36:28 --> Helper loaded: cookie_helper
INFO - 2024-03-21 11:36:28 --> Database Driver Class Initialized
INFO - 2024-03-21 11:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 11:36:28 --> Parser Class Initialized
INFO - 2024-03-21 11:36:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 11:36:28 --> Pagination Class Initialized
INFO - 2024-03-21 11:36:28 --> Form Validation Class Initialized
INFO - 2024-03-21 11:36:28 --> Controller Class Initialized
INFO - 2024-03-21 11:36:28 --> Model Class Initialized
DEBUG - 2024-03-21 11:36:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 11:36:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-21 11:36:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 11:36:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 11:36:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 11:36:28 --> Model Class Initialized
INFO - 2024-03-21 11:36:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 11:36:28 --> Final output sent to browser
DEBUG - 2024-03-21 11:36:28 --> Total execution time: 0.0333
ERROR - 2024-03-21 17:49:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 17:49:03 --> Config Class Initialized
INFO - 2024-03-21 17:49:03 --> Hooks Class Initialized
DEBUG - 2024-03-21 17:49:03 --> UTF-8 Support Enabled
INFO - 2024-03-21 17:49:03 --> Utf8 Class Initialized
INFO - 2024-03-21 17:49:03 --> URI Class Initialized
DEBUG - 2024-03-21 17:49:03 --> No URI present. Default controller set.
INFO - 2024-03-21 17:49:03 --> Router Class Initialized
INFO - 2024-03-21 17:49:03 --> Output Class Initialized
INFO - 2024-03-21 17:49:03 --> Security Class Initialized
DEBUG - 2024-03-21 17:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 17:49:03 --> Input Class Initialized
INFO - 2024-03-21 17:49:03 --> Language Class Initialized
INFO - 2024-03-21 17:49:03 --> Loader Class Initialized
INFO - 2024-03-21 17:49:03 --> Helper loaded: url_helper
INFO - 2024-03-21 17:49:03 --> Helper loaded: file_helper
INFO - 2024-03-21 17:49:03 --> Helper loaded: html_helper
INFO - 2024-03-21 17:49:03 --> Helper loaded: text_helper
INFO - 2024-03-21 17:49:03 --> Helper loaded: form_helper
INFO - 2024-03-21 17:49:03 --> Helper loaded: lang_helper
INFO - 2024-03-21 17:49:03 --> Helper loaded: security_helper
INFO - 2024-03-21 17:49:03 --> Helper loaded: cookie_helper
INFO - 2024-03-21 17:49:03 --> Database Driver Class Initialized
INFO - 2024-03-21 17:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 17:49:03 --> Parser Class Initialized
INFO - 2024-03-21 17:49:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 17:49:03 --> Pagination Class Initialized
INFO - 2024-03-21 17:49:03 --> Form Validation Class Initialized
INFO - 2024-03-21 17:49:03 --> Controller Class Initialized
INFO - 2024-03-21 17:49:03 --> Model Class Initialized
DEBUG - 2024-03-21 17:49:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-21 17:49:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 17:49:04 --> Config Class Initialized
INFO - 2024-03-21 17:49:04 --> Hooks Class Initialized
DEBUG - 2024-03-21 17:49:04 --> UTF-8 Support Enabled
INFO - 2024-03-21 17:49:04 --> Utf8 Class Initialized
INFO - 2024-03-21 17:49:04 --> URI Class Initialized
INFO - 2024-03-21 17:49:04 --> Router Class Initialized
INFO - 2024-03-21 17:49:04 --> Output Class Initialized
INFO - 2024-03-21 17:49:04 --> Security Class Initialized
DEBUG - 2024-03-21 17:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 17:49:04 --> Input Class Initialized
INFO - 2024-03-21 17:49:04 --> Language Class Initialized
INFO - 2024-03-21 17:49:04 --> Loader Class Initialized
INFO - 2024-03-21 17:49:04 --> Helper loaded: url_helper
INFO - 2024-03-21 17:49:04 --> Helper loaded: file_helper
INFO - 2024-03-21 17:49:04 --> Helper loaded: html_helper
INFO - 2024-03-21 17:49:04 --> Helper loaded: text_helper
INFO - 2024-03-21 17:49:04 --> Helper loaded: form_helper
INFO - 2024-03-21 17:49:04 --> Helper loaded: lang_helper
INFO - 2024-03-21 17:49:04 --> Helper loaded: security_helper
INFO - 2024-03-21 17:49:04 --> Helper loaded: cookie_helper
INFO - 2024-03-21 17:49:04 --> Database Driver Class Initialized
INFO - 2024-03-21 17:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 17:49:04 --> Parser Class Initialized
INFO - 2024-03-21 17:49:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-21 17:49:04 --> Pagination Class Initialized
INFO - 2024-03-21 17:49:04 --> Form Validation Class Initialized
INFO - 2024-03-21 17:49:04 --> Controller Class Initialized
INFO - 2024-03-21 17:49:04 --> Model Class Initialized
DEBUG - 2024-03-21 17:49:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-21 17:49:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-21 17:49:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-21 17:49:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-21 17:49:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-21 17:49:04 --> Model Class Initialized
INFO - 2024-03-21 17:49:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-21 17:49:04 --> Final output sent to browser
DEBUG - 2024-03-21 17:49:04 --> Total execution time: 0.0359
ERROR - 2024-03-21 18:54:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 18:54:24 --> Config Class Initialized
INFO - 2024-03-21 18:54:24 --> Hooks Class Initialized
DEBUG - 2024-03-21 18:54:24 --> UTF-8 Support Enabled
INFO - 2024-03-21 18:54:24 --> Utf8 Class Initialized
INFO - 2024-03-21 18:54:24 --> URI Class Initialized
INFO - 2024-03-21 18:54:24 --> Router Class Initialized
INFO - 2024-03-21 18:54:24 --> Output Class Initialized
INFO - 2024-03-21 18:54:24 --> Security Class Initialized
DEBUG - 2024-03-21 18:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 18:54:24 --> Input Class Initialized
INFO - 2024-03-21 18:54:24 --> Language Class Initialized
ERROR - 2024-03-21 18:54:24 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-03-21 23:41:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-21 23:41:39 --> Config Class Initialized
INFO - 2024-03-21 23:41:39 --> Hooks Class Initialized
DEBUG - 2024-03-21 23:41:39 --> UTF-8 Support Enabled
INFO - 2024-03-21 23:41:39 --> Utf8 Class Initialized
INFO - 2024-03-21 23:41:39 --> URI Class Initialized
INFO - 2024-03-21 23:41:39 --> Router Class Initialized
INFO - 2024-03-21 23:41:39 --> Output Class Initialized
INFO - 2024-03-21 23:41:39 --> Security Class Initialized
DEBUG - 2024-03-21 23:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 23:41:39 --> Input Class Initialized
INFO - 2024-03-21 23:41:39 --> Language Class Initialized
ERROR - 2024-03-21 23:41:39 --> 404 Page Not Found: Well-known/assetlinks.json
