<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-01 00:34:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:34:04 --> Config Class Initialized
INFO - 2024-01-01 00:34:04 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:34:04 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:34:04 --> Utf8 Class Initialized
INFO - 2024-01-01 00:34:04 --> URI Class Initialized
DEBUG - 2024-01-01 00:34:04 --> No URI present. Default controller set.
INFO - 2024-01-01 00:34:04 --> Router Class Initialized
INFO - 2024-01-01 00:34:04 --> Output Class Initialized
INFO - 2024-01-01 00:34:04 --> Security Class Initialized
DEBUG - 2024-01-01 00:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:34:04 --> Input Class Initialized
INFO - 2024-01-01 00:34:04 --> Language Class Initialized
INFO - 2024-01-01 00:34:04 --> Loader Class Initialized
INFO - 2024-01-01 00:34:04 --> Helper loaded: url_helper
INFO - 2024-01-01 00:34:04 --> Helper loaded: file_helper
INFO - 2024-01-01 00:34:04 --> Helper loaded: html_helper
INFO - 2024-01-01 00:34:04 --> Helper loaded: text_helper
INFO - 2024-01-01 00:34:04 --> Helper loaded: form_helper
INFO - 2024-01-01 00:34:04 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:34:04 --> Helper loaded: security_helper
INFO - 2024-01-01 00:34:04 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:34:04 --> Database Driver Class Initialized
INFO - 2024-01-01 00:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:34:04 --> Parser Class Initialized
INFO - 2024-01-01 00:34:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:34:04 --> Pagination Class Initialized
INFO - 2024-01-01 00:34:04 --> Form Validation Class Initialized
INFO - 2024-01-01 00:34:04 --> Controller Class Initialized
INFO - 2024-01-01 00:34:04 --> Model Class Initialized
DEBUG - 2024-01-01 00:34:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-01 00:34:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:34:11 --> Config Class Initialized
INFO - 2024-01-01 00:34:11 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:34:11 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:34:11 --> Utf8 Class Initialized
INFO - 2024-01-01 00:34:11 --> URI Class Initialized
INFO - 2024-01-01 00:34:11 --> Router Class Initialized
INFO - 2024-01-01 00:34:11 --> Output Class Initialized
INFO - 2024-01-01 00:34:11 --> Security Class Initialized
DEBUG - 2024-01-01 00:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:34:11 --> Input Class Initialized
INFO - 2024-01-01 00:34:11 --> Language Class Initialized
INFO - 2024-01-01 00:34:11 --> Loader Class Initialized
INFO - 2024-01-01 00:34:11 --> Helper loaded: url_helper
INFO - 2024-01-01 00:34:11 --> Helper loaded: file_helper
INFO - 2024-01-01 00:34:11 --> Helper loaded: html_helper
INFO - 2024-01-01 00:34:11 --> Helper loaded: text_helper
INFO - 2024-01-01 00:34:11 --> Helper loaded: form_helper
INFO - 2024-01-01 00:34:11 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:34:11 --> Helper loaded: security_helper
INFO - 2024-01-01 00:34:11 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:34:11 --> Database Driver Class Initialized
INFO - 2024-01-01 00:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:34:11 --> Parser Class Initialized
INFO - 2024-01-01 00:34:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:34:11 --> Pagination Class Initialized
INFO - 2024-01-01 00:34:11 --> Form Validation Class Initialized
INFO - 2024-01-01 00:34:11 --> Controller Class Initialized
INFO - 2024-01-01 00:34:11 --> Model Class Initialized
DEBUG - 2024-01-01 00:34:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:34:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-01 00:34:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:34:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 00:34:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 00:34:11 --> Model Class Initialized
INFO - 2024-01-01 00:34:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 00:34:11 --> Final output sent to browser
DEBUG - 2024-01-01 00:34:11 --> Total execution time: 0.0368
ERROR - 2024-01-01 00:35:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:35:43 --> Config Class Initialized
INFO - 2024-01-01 00:35:43 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:35:43 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:35:43 --> Utf8 Class Initialized
INFO - 2024-01-01 00:35:43 --> URI Class Initialized
DEBUG - 2024-01-01 00:35:43 --> No URI present. Default controller set.
INFO - 2024-01-01 00:35:43 --> Router Class Initialized
INFO - 2024-01-01 00:35:43 --> Output Class Initialized
INFO - 2024-01-01 00:35:43 --> Security Class Initialized
DEBUG - 2024-01-01 00:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:35:43 --> Input Class Initialized
INFO - 2024-01-01 00:35:43 --> Language Class Initialized
INFO - 2024-01-01 00:35:43 --> Loader Class Initialized
INFO - 2024-01-01 00:35:43 --> Helper loaded: url_helper
INFO - 2024-01-01 00:35:43 --> Helper loaded: file_helper
INFO - 2024-01-01 00:35:43 --> Helper loaded: html_helper
INFO - 2024-01-01 00:35:43 --> Helper loaded: text_helper
INFO - 2024-01-01 00:35:43 --> Helper loaded: form_helper
INFO - 2024-01-01 00:35:43 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:35:43 --> Helper loaded: security_helper
INFO - 2024-01-01 00:35:43 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:35:43 --> Database Driver Class Initialized
INFO - 2024-01-01 00:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:35:43 --> Parser Class Initialized
INFO - 2024-01-01 00:35:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:35:43 --> Pagination Class Initialized
INFO - 2024-01-01 00:35:43 --> Form Validation Class Initialized
INFO - 2024-01-01 00:35:43 --> Controller Class Initialized
INFO - 2024-01-01 00:35:43 --> Model Class Initialized
DEBUG - 2024-01-01 00:35:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-01 00:35:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:35:45 --> Config Class Initialized
INFO - 2024-01-01 00:35:45 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:35:45 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:35:45 --> Utf8 Class Initialized
INFO - 2024-01-01 00:35:45 --> URI Class Initialized
INFO - 2024-01-01 00:35:45 --> Router Class Initialized
INFO - 2024-01-01 00:35:45 --> Output Class Initialized
INFO - 2024-01-01 00:35:45 --> Security Class Initialized
DEBUG - 2024-01-01 00:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:35:45 --> Input Class Initialized
INFO - 2024-01-01 00:35:45 --> Language Class Initialized
INFO - 2024-01-01 00:35:45 --> Loader Class Initialized
INFO - 2024-01-01 00:35:45 --> Helper loaded: url_helper
INFO - 2024-01-01 00:35:45 --> Helper loaded: file_helper
INFO - 2024-01-01 00:35:45 --> Helper loaded: html_helper
INFO - 2024-01-01 00:35:45 --> Helper loaded: text_helper
INFO - 2024-01-01 00:35:45 --> Helper loaded: form_helper
INFO - 2024-01-01 00:35:45 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:35:45 --> Helper loaded: security_helper
INFO - 2024-01-01 00:35:45 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:35:45 --> Database Driver Class Initialized
INFO - 2024-01-01 00:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:35:45 --> Parser Class Initialized
INFO - 2024-01-01 00:35:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:35:45 --> Pagination Class Initialized
INFO - 2024-01-01 00:35:45 --> Form Validation Class Initialized
INFO - 2024-01-01 00:35:45 --> Controller Class Initialized
INFO - 2024-01-01 00:35:45 --> Model Class Initialized
DEBUG - 2024-01-01 00:35:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:35:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-01 00:35:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:35:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 00:35:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 00:35:45 --> Model Class Initialized
INFO - 2024-01-01 00:35:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 00:35:45 --> Final output sent to browser
DEBUG - 2024-01-01 00:35:45 --> Total execution time: 0.0317
ERROR - 2024-01-01 00:37:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:37:41 --> Config Class Initialized
INFO - 2024-01-01 00:37:41 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:37:41 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:37:41 --> Utf8 Class Initialized
INFO - 2024-01-01 00:37:41 --> URI Class Initialized
INFO - 2024-01-01 00:37:41 --> Router Class Initialized
INFO - 2024-01-01 00:37:41 --> Output Class Initialized
INFO - 2024-01-01 00:37:41 --> Security Class Initialized
DEBUG - 2024-01-01 00:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:37:41 --> Input Class Initialized
INFO - 2024-01-01 00:37:41 --> Language Class Initialized
INFO - 2024-01-01 00:37:41 --> Loader Class Initialized
INFO - 2024-01-01 00:37:41 --> Helper loaded: url_helper
INFO - 2024-01-01 00:37:41 --> Helper loaded: file_helper
INFO - 2024-01-01 00:37:41 --> Helper loaded: html_helper
INFO - 2024-01-01 00:37:41 --> Helper loaded: text_helper
INFO - 2024-01-01 00:37:41 --> Helper loaded: form_helper
INFO - 2024-01-01 00:37:41 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:37:41 --> Helper loaded: security_helper
INFO - 2024-01-01 00:37:41 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:37:41 --> Database Driver Class Initialized
INFO - 2024-01-01 00:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:37:41 --> Parser Class Initialized
INFO - 2024-01-01 00:37:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:37:41 --> Pagination Class Initialized
INFO - 2024-01-01 00:37:41 --> Form Validation Class Initialized
INFO - 2024-01-01 00:37:41 --> Controller Class Initialized
INFO - 2024-01-01 00:37:41 --> Model Class Initialized
DEBUG - 2024-01-01 00:37:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:37:41 --> Model Class Initialized
INFO - 2024-01-01 00:37:41 --> Final output sent to browser
DEBUG - 2024-01-01 00:37:41 --> Total execution time: 0.0220
ERROR - 2024-01-01 00:37:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:37:41 --> Config Class Initialized
INFO - 2024-01-01 00:37:41 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:37:41 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:37:41 --> Utf8 Class Initialized
INFO - 2024-01-01 00:37:41 --> URI Class Initialized
DEBUG - 2024-01-01 00:37:41 --> No URI present. Default controller set.
INFO - 2024-01-01 00:37:41 --> Router Class Initialized
INFO - 2024-01-01 00:37:41 --> Output Class Initialized
INFO - 2024-01-01 00:37:41 --> Security Class Initialized
DEBUG - 2024-01-01 00:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:37:41 --> Input Class Initialized
INFO - 2024-01-01 00:37:41 --> Language Class Initialized
INFO - 2024-01-01 00:37:41 --> Loader Class Initialized
INFO - 2024-01-01 00:37:41 --> Helper loaded: url_helper
INFO - 2024-01-01 00:37:41 --> Helper loaded: file_helper
INFO - 2024-01-01 00:37:41 --> Helper loaded: html_helper
INFO - 2024-01-01 00:37:41 --> Helper loaded: text_helper
INFO - 2024-01-01 00:37:41 --> Helper loaded: form_helper
INFO - 2024-01-01 00:37:41 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:37:41 --> Helper loaded: security_helper
INFO - 2024-01-01 00:37:41 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:37:41 --> Database Driver Class Initialized
INFO - 2024-01-01 00:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:37:41 --> Parser Class Initialized
INFO - 2024-01-01 00:37:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:37:41 --> Pagination Class Initialized
INFO - 2024-01-01 00:37:41 --> Form Validation Class Initialized
INFO - 2024-01-01 00:37:41 --> Controller Class Initialized
INFO - 2024-01-01 00:37:41 --> Model Class Initialized
DEBUG - 2024-01-01 00:37:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:37:41 --> Model Class Initialized
DEBUG - 2024-01-01 00:37:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:37:41 --> Model Class Initialized
INFO - 2024-01-01 00:37:41 --> Model Class Initialized
INFO - 2024-01-01 00:37:41 --> Model Class Initialized
INFO - 2024-01-01 00:37:41 --> Model Class Initialized
DEBUG - 2024-01-01 00:37:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:37:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:37:41 --> Model Class Initialized
INFO - 2024-01-01 00:37:41 --> Model Class Initialized
INFO - 2024-01-01 00:37:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-01 00:37:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:37:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 00:37:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 00:37:41 --> Model Class Initialized
INFO - 2024-01-01 00:37:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-01 00:37:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-01 00:37:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 00:37:41 --> Final output sent to browser
DEBUG - 2024-01-01 00:37:41 --> Total execution time: 0.2300
ERROR - 2024-01-01 00:37:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:37:53 --> Config Class Initialized
INFO - 2024-01-01 00:37:53 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:37:53 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:37:53 --> Utf8 Class Initialized
INFO - 2024-01-01 00:37:53 --> URI Class Initialized
INFO - 2024-01-01 00:37:53 --> Router Class Initialized
INFO - 2024-01-01 00:37:53 --> Output Class Initialized
INFO - 2024-01-01 00:37:53 --> Security Class Initialized
DEBUG - 2024-01-01 00:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:37:53 --> Input Class Initialized
INFO - 2024-01-01 00:37:53 --> Language Class Initialized
INFO - 2024-01-01 00:37:53 --> Loader Class Initialized
INFO - 2024-01-01 00:37:53 --> Helper loaded: url_helper
INFO - 2024-01-01 00:37:53 --> Helper loaded: file_helper
INFO - 2024-01-01 00:37:53 --> Helper loaded: html_helper
INFO - 2024-01-01 00:37:53 --> Helper loaded: text_helper
INFO - 2024-01-01 00:37:53 --> Helper loaded: form_helper
INFO - 2024-01-01 00:37:53 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:37:53 --> Helper loaded: security_helper
INFO - 2024-01-01 00:37:53 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:37:53 --> Database Driver Class Initialized
INFO - 2024-01-01 00:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:37:53 --> Parser Class Initialized
INFO - 2024-01-01 00:37:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:37:53 --> Pagination Class Initialized
INFO - 2024-01-01 00:37:53 --> Form Validation Class Initialized
INFO - 2024-01-01 00:37:53 --> Controller Class Initialized
INFO - 2024-01-01 00:37:53 --> Model Class Initialized
DEBUG - 2024-01-01 00:37:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:37:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:37:53 --> Model Class Initialized
DEBUG - 2024-01-01 00:37:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:37:53 --> Model Class Initialized
INFO - 2024-01-01 00:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-01-01 00:37:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 00:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 00:37:53 --> Model Class Initialized
INFO - 2024-01-01 00:37:53 --> Model Class Initialized
INFO - 2024-01-01 00:37:53 --> Model Class Initialized
INFO - 2024-01-01 00:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-01 00:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-01 00:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 00:37:53 --> Final output sent to browser
DEBUG - 2024-01-01 00:37:53 --> Total execution time: 0.1809
ERROR - 2024-01-01 00:37:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:37:59 --> Config Class Initialized
INFO - 2024-01-01 00:37:59 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:37:59 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:37:59 --> Utf8 Class Initialized
INFO - 2024-01-01 00:37:59 --> URI Class Initialized
INFO - 2024-01-01 00:37:59 --> Router Class Initialized
INFO - 2024-01-01 00:37:59 --> Output Class Initialized
INFO - 2024-01-01 00:37:59 --> Security Class Initialized
DEBUG - 2024-01-01 00:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:37:59 --> Input Class Initialized
INFO - 2024-01-01 00:37:59 --> Language Class Initialized
INFO - 2024-01-01 00:37:59 --> Loader Class Initialized
INFO - 2024-01-01 00:37:59 --> Helper loaded: url_helper
INFO - 2024-01-01 00:37:59 --> Helper loaded: file_helper
INFO - 2024-01-01 00:37:59 --> Helper loaded: html_helper
INFO - 2024-01-01 00:37:59 --> Helper loaded: text_helper
INFO - 2024-01-01 00:37:59 --> Helper loaded: form_helper
INFO - 2024-01-01 00:37:59 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:37:59 --> Helper loaded: security_helper
INFO - 2024-01-01 00:37:59 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:37:59 --> Database Driver Class Initialized
INFO - 2024-01-01 00:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:37:59 --> Parser Class Initialized
INFO - 2024-01-01 00:37:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:37:59 --> Pagination Class Initialized
INFO - 2024-01-01 00:37:59 --> Form Validation Class Initialized
INFO - 2024-01-01 00:37:59 --> Controller Class Initialized
INFO - 2024-01-01 00:37:59 --> Model Class Initialized
DEBUG - 2024-01-01 00:37:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:37:59 --> Final output sent to browser
DEBUG - 2024-01-01 00:37:59 --> Total execution time: 0.0162
ERROR - 2024-01-01 00:38:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:38:01 --> Config Class Initialized
INFO - 2024-01-01 00:38:01 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:38:01 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:38:01 --> Utf8 Class Initialized
INFO - 2024-01-01 00:38:01 --> URI Class Initialized
INFO - 2024-01-01 00:38:01 --> Router Class Initialized
INFO - 2024-01-01 00:38:01 --> Output Class Initialized
INFO - 2024-01-01 00:38:01 --> Security Class Initialized
DEBUG - 2024-01-01 00:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:38:01 --> Input Class Initialized
INFO - 2024-01-01 00:38:01 --> Language Class Initialized
INFO - 2024-01-01 00:38:01 --> Loader Class Initialized
INFO - 2024-01-01 00:38:01 --> Helper loaded: url_helper
INFO - 2024-01-01 00:38:01 --> Helper loaded: file_helper
INFO - 2024-01-01 00:38:01 --> Helper loaded: html_helper
INFO - 2024-01-01 00:38:01 --> Helper loaded: text_helper
INFO - 2024-01-01 00:38:01 --> Helper loaded: form_helper
INFO - 2024-01-01 00:38:01 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:38:01 --> Helper loaded: security_helper
INFO - 2024-01-01 00:38:01 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:38:01 --> Database Driver Class Initialized
INFO - 2024-01-01 00:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:38:01 --> Parser Class Initialized
INFO - 2024-01-01 00:38:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:38:01 --> Pagination Class Initialized
INFO - 2024-01-01 00:38:01 --> Form Validation Class Initialized
INFO - 2024-01-01 00:38:01 --> Controller Class Initialized
INFO - 2024-01-01 00:38:01 --> Model Class Initialized
DEBUG - 2024-01-01 00:38:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-01 00:38:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-01-01 00:38:01 --> Final output sent to browser
DEBUG - 2024-01-01 00:38:01 --> Total execution time: 0.0195
ERROR - 2024-01-01 00:38:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:38:03 --> Config Class Initialized
INFO - 2024-01-01 00:38:03 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:38:03 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:38:03 --> Utf8 Class Initialized
INFO - 2024-01-01 00:38:03 --> URI Class Initialized
INFO - 2024-01-01 00:38:03 --> Router Class Initialized
INFO - 2024-01-01 00:38:03 --> Output Class Initialized
INFO - 2024-01-01 00:38:03 --> Security Class Initialized
DEBUG - 2024-01-01 00:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:38:03 --> Input Class Initialized
INFO - 2024-01-01 00:38:03 --> Language Class Initialized
INFO - 2024-01-01 00:38:03 --> Loader Class Initialized
INFO - 2024-01-01 00:38:03 --> Helper loaded: url_helper
INFO - 2024-01-01 00:38:03 --> Helper loaded: file_helper
INFO - 2024-01-01 00:38:03 --> Helper loaded: html_helper
INFO - 2024-01-01 00:38:03 --> Helper loaded: text_helper
INFO - 2024-01-01 00:38:03 --> Helper loaded: form_helper
INFO - 2024-01-01 00:38:03 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:38:03 --> Helper loaded: security_helper
INFO - 2024-01-01 00:38:03 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:38:03 --> Database Driver Class Initialized
INFO - 2024-01-01 00:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:38:03 --> Parser Class Initialized
INFO - 2024-01-01 00:38:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:38:03 --> Pagination Class Initialized
INFO - 2024-01-01 00:38:03 --> Form Validation Class Initialized
INFO - 2024-01-01 00:38:03 --> Controller Class Initialized
INFO - 2024-01-01 00:38:03 --> Model Class Initialized
DEBUG - 2024-01-01 00:38:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-01 00:38:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-01-01 00:38:03 --> Final output sent to browser
DEBUG - 2024-01-01 00:38:03 --> Total execution time: 0.0153
ERROR - 2024-01-01 00:38:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:38:06 --> Config Class Initialized
INFO - 2024-01-01 00:38:06 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:38:06 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:38:06 --> Utf8 Class Initialized
INFO - 2024-01-01 00:38:06 --> URI Class Initialized
INFO - 2024-01-01 00:38:06 --> Router Class Initialized
INFO - 2024-01-01 00:38:06 --> Output Class Initialized
INFO - 2024-01-01 00:38:06 --> Security Class Initialized
DEBUG - 2024-01-01 00:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:38:06 --> Input Class Initialized
INFO - 2024-01-01 00:38:06 --> Language Class Initialized
INFO - 2024-01-01 00:38:06 --> Loader Class Initialized
INFO - 2024-01-01 00:38:06 --> Helper loaded: url_helper
INFO - 2024-01-01 00:38:06 --> Helper loaded: file_helper
INFO - 2024-01-01 00:38:06 --> Helper loaded: html_helper
INFO - 2024-01-01 00:38:06 --> Helper loaded: text_helper
INFO - 2024-01-01 00:38:06 --> Helper loaded: form_helper
INFO - 2024-01-01 00:38:06 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:38:06 --> Helper loaded: security_helper
INFO - 2024-01-01 00:38:06 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:38:06 --> Database Driver Class Initialized
INFO - 2024-01-01 00:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:38:06 --> Parser Class Initialized
INFO - 2024-01-01 00:38:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:38:06 --> Pagination Class Initialized
INFO - 2024-01-01 00:38:06 --> Form Validation Class Initialized
INFO - 2024-01-01 00:38:06 --> Controller Class Initialized
INFO - 2024-01-01 00:38:06 --> Model Class Initialized
DEBUG - 2024-01-01 00:38:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:38:06 --> Final output sent to browser
DEBUG - 2024-01-01 00:38:06 --> Total execution time: 0.0157
ERROR - 2024-01-01 00:38:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:38:07 --> Config Class Initialized
INFO - 2024-01-01 00:38:07 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:38:07 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:38:07 --> Utf8 Class Initialized
INFO - 2024-01-01 00:38:07 --> URI Class Initialized
INFO - 2024-01-01 00:38:07 --> Router Class Initialized
INFO - 2024-01-01 00:38:07 --> Output Class Initialized
INFO - 2024-01-01 00:38:07 --> Security Class Initialized
DEBUG - 2024-01-01 00:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:38:07 --> Input Class Initialized
INFO - 2024-01-01 00:38:07 --> Language Class Initialized
INFO - 2024-01-01 00:38:07 --> Loader Class Initialized
INFO - 2024-01-01 00:38:07 --> Helper loaded: url_helper
INFO - 2024-01-01 00:38:07 --> Helper loaded: file_helper
INFO - 2024-01-01 00:38:07 --> Helper loaded: html_helper
INFO - 2024-01-01 00:38:07 --> Helper loaded: text_helper
INFO - 2024-01-01 00:38:07 --> Helper loaded: form_helper
INFO - 2024-01-01 00:38:07 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:38:07 --> Helper loaded: security_helper
INFO - 2024-01-01 00:38:07 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:38:07 --> Database Driver Class Initialized
INFO - 2024-01-01 00:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:38:07 --> Parser Class Initialized
INFO - 2024-01-01 00:38:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:38:07 --> Pagination Class Initialized
INFO - 2024-01-01 00:38:07 --> Form Validation Class Initialized
INFO - 2024-01-01 00:38:07 --> Controller Class Initialized
INFO - 2024-01-01 00:38:07 --> Model Class Initialized
DEBUG - 2024-01-01 00:38:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:38:07 --> Final output sent to browser
DEBUG - 2024-01-01 00:38:07 --> Total execution time: 0.0196
ERROR - 2024-01-01 00:38:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:38:13 --> Config Class Initialized
INFO - 2024-01-01 00:38:13 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:38:13 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:38:13 --> Utf8 Class Initialized
INFO - 2024-01-01 00:38:13 --> URI Class Initialized
INFO - 2024-01-01 00:38:13 --> Router Class Initialized
INFO - 2024-01-01 00:38:13 --> Output Class Initialized
INFO - 2024-01-01 00:38:13 --> Security Class Initialized
DEBUG - 2024-01-01 00:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:38:13 --> Input Class Initialized
INFO - 2024-01-01 00:38:13 --> Language Class Initialized
INFO - 2024-01-01 00:38:13 --> Loader Class Initialized
INFO - 2024-01-01 00:38:13 --> Helper loaded: url_helper
INFO - 2024-01-01 00:38:13 --> Helper loaded: file_helper
INFO - 2024-01-01 00:38:13 --> Helper loaded: html_helper
INFO - 2024-01-01 00:38:13 --> Helper loaded: text_helper
INFO - 2024-01-01 00:38:13 --> Helper loaded: form_helper
INFO - 2024-01-01 00:38:13 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:38:13 --> Helper loaded: security_helper
INFO - 2024-01-01 00:38:13 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:38:13 --> Database Driver Class Initialized
INFO - 2024-01-01 00:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:38:13 --> Parser Class Initialized
INFO - 2024-01-01 00:38:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:38:13 --> Pagination Class Initialized
INFO - 2024-01-01 00:38:13 --> Form Validation Class Initialized
INFO - 2024-01-01 00:38:13 --> Controller Class Initialized
INFO - 2024-01-01 00:38:13 --> Model Class Initialized
DEBUG - 2024-01-01 00:38:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:38:13 --> Final output sent to browser
DEBUG - 2024-01-01 00:38:13 --> Total execution time: 0.0151
ERROR - 2024-01-01 00:38:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:38:15 --> Config Class Initialized
INFO - 2024-01-01 00:38:15 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:38:15 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:38:15 --> Utf8 Class Initialized
INFO - 2024-01-01 00:38:15 --> URI Class Initialized
INFO - 2024-01-01 00:38:15 --> Router Class Initialized
INFO - 2024-01-01 00:38:15 --> Output Class Initialized
INFO - 2024-01-01 00:38:15 --> Security Class Initialized
DEBUG - 2024-01-01 00:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:38:15 --> Input Class Initialized
INFO - 2024-01-01 00:38:15 --> Language Class Initialized
INFO - 2024-01-01 00:38:15 --> Loader Class Initialized
INFO - 2024-01-01 00:38:15 --> Helper loaded: url_helper
INFO - 2024-01-01 00:38:15 --> Helper loaded: file_helper
INFO - 2024-01-01 00:38:15 --> Helper loaded: html_helper
INFO - 2024-01-01 00:38:15 --> Helper loaded: text_helper
INFO - 2024-01-01 00:38:15 --> Helper loaded: form_helper
INFO - 2024-01-01 00:38:15 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:38:15 --> Helper loaded: security_helper
INFO - 2024-01-01 00:38:15 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:38:15 --> Database Driver Class Initialized
INFO - 2024-01-01 00:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:38:15 --> Parser Class Initialized
INFO - 2024-01-01 00:38:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:38:15 --> Pagination Class Initialized
INFO - 2024-01-01 00:38:15 --> Form Validation Class Initialized
INFO - 2024-01-01 00:38:15 --> Controller Class Initialized
INFO - 2024-01-01 00:38:15 --> Model Class Initialized
DEBUG - 2024-01-01 00:38:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:38:15 --> Final output sent to browser
DEBUG - 2024-01-01 00:38:15 --> Total execution time: 0.0154
ERROR - 2024-01-01 00:38:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:38:17 --> Config Class Initialized
INFO - 2024-01-01 00:38:17 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:38:17 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:38:17 --> Utf8 Class Initialized
INFO - 2024-01-01 00:38:17 --> URI Class Initialized
INFO - 2024-01-01 00:38:17 --> Router Class Initialized
INFO - 2024-01-01 00:38:17 --> Output Class Initialized
INFO - 2024-01-01 00:38:17 --> Security Class Initialized
DEBUG - 2024-01-01 00:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:38:17 --> Input Class Initialized
INFO - 2024-01-01 00:38:17 --> Language Class Initialized
INFO - 2024-01-01 00:38:17 --> Loader Class Initialized
INFO - 2024-01-01 00:38:17 --> Helper loaded: url_helper
INFO - 2024-01-01 00:38:17 --> Helper loaded: file_helper
INFO - 2024-01-01 00:38:17 --> Helper loaded: html_helper
INFO - 2024-01-01 00:38:17 --> Helper loaded: text_helper
INFO - 2024-01-01 00:38:17 --> Helper loaded: form_helper
INFO - 2024-01-01 00:38:17 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:38:17 --> Helper loaded: security_helper
INFO - 2024-01-01 00:38:17 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:38:17 --> Database Driver Class Initialized
INFO - 2024-01-01 00:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:38:17 --> Parser Class Initialized
INFO - 2024-01-01 00:38:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:38:17 --> Pagination Class Initialized
INFO - 2024-01-01 00:38:17 --> Form Validation Class Initialized
INFO - 2024-01-01 00:38:17 --> Controller Class Initialized
INFO - 2024-01-01 00:38:17 --> Final output sent to browser
DEBUG - 2024-01-01 00:38:17 --> Total execution time: 0.0139
ERROR - 2024-01-01 00:38:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:38:23 --> Config Class Initialized
INFO - 2024-01-01 00:38:23 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:38:23 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:38:23 --> Utf8 Class Initialized
INFO - 2024-01-01 00:38:23 --> URI Class Initialized
INFO - 2024-01-01 00:38:23 --> Router Class Initialized
INFO - 2024-01-01 00:38:23 --> Output Class Initialized
INFO - 2024-01-01 00:38:23 --> Security Class Initialized
DEBUG - 2024-01-01 00:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:38:23 --> Input Class Initialized
INFO - 2024-01-01 00:38:23 --> Language Class Initialized
INFO - 2024-01-01 00:38:23 --> Loader Class Initialized
INFO - 2024-01-01 00:38:23 --> Helper loaded: url_helper
INFO - 2024-01-01 00:38:23 --> Helper loaded: file_helper
INFO - 2024-01-01 00:38:23 --> Helper loaded: html_helper
INFO - 2024-01-01 00:38:23 --> Helper loaded: text_helper
INFO - 2024-01-01 00:38:23 --> Helper loaded: form_helper
INFO - 2024-01-01 00:38:23 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:38:23 --> Helper loaded: security_helper
INFO - 2024-01-01 00:38:23 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:38:23 --> Database Driver Class Initialized
INFO - 2024-01-01 00:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:38:23 --> Parser Class Initialized
INFO - 2024-01-01 00:38:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:38:23 --> Pagination Class Initialized
INFO - 2024-01-01 00:38:23 --> Form Validation Class Initialized
INFO - 2024-01-01 00:38:23 --> Controller Class Initialized
INFO - 2024-01-01 00:38:23 --> Model Class Initialized
DEBUG - 2024-01-01 00:38:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:38:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:38:23 --> Model Class Initialized
DEBUG - 2024-01-01 00:38:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:38:23 --> Model Class Initialized
INFO - 2024-01-01 00:38:23 --> Final output sent to browser
DEBUG - 2024-01-01 00:38:23 --> Total execution time: 0.0983
ERROR - 2024-01-01 00:38:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:38:27 --> Config Class Initialized
INFO - 2024-01-01 00:38:27 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:38:27 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:38:27 --> Utf8 Class Initialized
INFO - 2024-01-01 00:38:27 --> URI Class Initialized
INFO - 2024-01-01 00:38:27 --> Router Class Initialized
INFO - 2024-01-01 00:38:27 --> Output Class Initialized
INFO - 2024-01-01 00:38:27 --> Security Class Initialized
DEBUG - 2024-01-01 00:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:38:27 --> Input Class Initialized
INFO - 2024-01-01 00:38:27 --> Language Class Initialized
INFO - 2024-01-01 00:38:27 --> Loader Class Initialized
INFO - 2024-01-01 00:38:27 --> Helper loaded: url_helper
INFO - 2024-01-01 00:38:27 --> Helper loaded: file_helper
INFO - 2024-01-01 00:38:27 --> Helper loaded: html_helper
INFO - 2024-01-01 00:38:27 --> Helper loaded: text_helper
INFO - 2024-01-01 00:38:27 --> Helper loaded: form_helper
INFO - 2024-01-01 00:38:27 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:38:27 --> Helper loaded: security_helper
INFO - 2024-01-01 00:38:27 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:38:27 --> Database Driver Class Initialized
INFO - 2024-01-01 00:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:38:27 --> Parser Class Initialized
INFO - 2024-01-01 00:38:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:38:27 --> Pagination Class Initialized
INFO - 2024-01-01 00:38:27 --> Form Validation Class Initialized
INFO - 2024-01-01 00:38:27 --> Controller Class Initialized
INFO - 2024-01-01 00:38:27 --> Model Class Initialized
DEBUG - 2024-01-01 00:38:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:38:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:38:27 --> Model Class Initialized
DEBUG - 2024-01-01 00:38:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:38:27 --> Model Class Initialized
INFO - 2024-01-01 00:38:28 --> Final output sent to browser
DEBUG - 2024-01-01 00:38:28 --> Total execution time: 0.0886
ERROR - 2024-01-01 00:38:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:38:28 --> Config Class Initialized
INFO - 2024-01-01 00:38:28 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:38:28 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:38:28 --> Utf8 Class Initialized
INFO - 2024-01-01 00:38:28 --> URI Class Initialized
INFO - 2024-01-01 00:38:28 --> Router Class Initialized
INFO - 2024-01-01 00:38:28 --> Output Class Initialized
INFO - 2024-01-01 00:38:28 --> Security Class Initialized
DEBUG - 2024-01-01 00:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:38:28 --> Input Class Initialized
INFO - 2024-01-01 00:38:28 --> Language Class Initialized
INFO - 2024-01-01 00:38:28 --> Loader Class Initialized
INFO - 2024-01-01 00:38:28 --> Helper loaded: url_helper
INFO - 2024-01-01 00:38:28 --> Helper loaded: file_helper
INFO - 2024-01-01 00:38:28 --> Helper loaded: html_helper
INFO - 2024-01-01 00:38:28 --> Helper loaded: text_helper
INFO - 2024-01-01 00:38:28 --> Helper loaded: form_helper
INFO - 2024-01-01 00:38:28 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:38:28 --> Helper loaded: security_helper
INFO - 2024-01-01 00:38:28 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:38:28 --> Database Driver Class Initialized
INFO - 2024-01-01 00:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:38:28 --> Parser Class Initialized
INFO - 2024-01-01 00:38:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:38:28 --> Pagination Class Initialized
INFO - 2024-01-01 00:38:28 --> Form Validation Class Initialized
INFO - 2024-01-01 00:38:28 --> Controller Class Initialized
INFO - 2024-01-01 00:38:28 --> Model Class Initialized
DEBUG - 2024-01-01 00:38:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:38:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:38:28 --> Model Class Initialized
DEBUG - 2024-01-01 00:38:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:38:28 --> Model Class Initialized
INFO - 2024-01-01 00:38:28 --> Final output sent to browser
DEBUG - 2024-01-01 00:38:28 --> Total execution time: 0.0885
ERROR - 2024-01-01 00:38:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:38:41 --> Config Class Initialized
INFO - 2024-01-01 00:38:41 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:38:41 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:38:41 --> Utf8 Class Initialized
INFO - 2024-01-01 00:38:41 --> URI Class Initialized
INFO - 2024-01-01 00:38:41 --> Router Class Initialized
INFO - 2024-01-01 00:38:41 --> Output Class Initialized
INFO - 2024-01-01 00:38:41 --> Security Class Initialized
DEBUG - 2024-01-01 00:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:38:41 --> Input Class Initialized
INFO - 2024-01-01 00:38:41 --> Language Class Initialized
INFO - 2024-01-01 00:38:41 --> Loader Class Initialized
INFO - 2024-01-01 00:38:41 --> Helper loaded: url_helper
INFO - 2024-01-01 00:38:41 --> Helper loaded: file_helper
INFO - 2024-01-01 00:38:41 --> Helper loaded: html_helper
INFO - 2024-01-01 00:38:41 --> Helper loaded: text_helper
INFO - 2024-01-01 00:38:41 --> Helper loaded: form_helper
INFO - 2024-01-01 00:38:41 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:38:41 --> Helper loaded: security_helper
INFO - 2024-01-01 00:38:41 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:38:41 --> Database Driver Class Initialized
INFO - 2024-01-01 00:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:38:41 --> Parser Class Initialized
INFO - 2024-01-01 00:38:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:38:41 --> Pagination Class Initialized
INFO - 2024-01-01 00:38:41 --> Form Validation Class Initialized
INFO - 2024-01-01 00:38:41 --> Controller Class Initialized
INFO - 2024-01-01 00:38:41 --> Model Class Initialized
DEBUG - 2024-01-01 00:38:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:38:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:38:41 --> Model Class Initialized
INFO - 2024-01-01 00:38:41 --> Model Class Initialized
INFO - 2024-01-01 00:38:41 --> Final output sent to browser
DEBUG - 2024-01-01 00:38:41 --> Total execution time: 0.0232
ERROR - 2024-01-01 00:38:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:38:44 --> Config Class Initialized
INFO - 2024-01-01 00:38:44 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:38:44 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:38:44 --> Utf8 Class Initialized
INFO - 2024-01-01 00:38:44 --> URI Class Initialized
INFO - 2024-01-01 00:38:44 --> Router Class Initialized
INFO - 2024-01-01 00:38:44 --> Output Class Initialized
INFO - 2024-01-01 00:38:44 --> Security Class Initialized
DEBUG - 2024-01-01 00:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:38:44 --> Input Class Initialized
INFO - 2024-01-01 00:38:44 --> Language Class Initialized
INFO - 2024-01-01 00:38:44 --> Loader Class Initialized
INFO - 2024-01-01 00:38:44 --> Helper loaded: url_helper
INFO - 2024-01-01 00:38:44 --> Helper loaded: file_helper
INFO - 2024-01-01 00:38:44 --> Helper loaded: html_helper
INFO - 2024-01-01 00:38:44 --> Helper loaded: text_helper
INFO - 2024-01-01 00:38:44 --> Helper loaded: form_helper
INFO - 2024-01-01 00:38:44 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:38:44 --> Helper loaded: security_helper
INFO - 2024-01-01 00:38:44 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:38:44 --> Database Driver Class Initialized
INFO - 2024-01-01 00:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:38:44 --> Parser Class Initialized
INFO - 2024-01-01 00:38:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:38:44 --> Pagination Class Initialized
INFO - 2024-01-01 00:38:44 --> Form Validation Class Initialized
INFO - 2024-01-01 00:38:44 --> Controller Class Initialized
INFO - 2024-01-01 00:38:44 --> Model Class Initialized
DEBUG - 2024-01-01 00:38:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:38:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:38:44 --> Model Class Initialized
INFO - 2024-01-01 00:38:44 --> Final output sent to browser
DEBUG - 2024-01-01 00:38:44 --> Total execution time: 0.0163
ERROR - 2024-01-01 00:38:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:38:46 --> Config Class Initialized
INFO - 2024-01-01 00:38:46 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:38:46 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:38:46 --> Utf8 Class Initialized
INFO - 2024-01-01 00:38:46 --> URI Class Initialized
INFO - 2024-01-01 00:38:46 --> Router Class Initialized
INFO - 2024-01-01 00:38:46 --> Output Class Initialized
INFO - 2024-01-01 00:38:46 --> Security Class Initialized
DEBUG - 2024-01-01 00:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:38:46 --> Input Class Initialized
INFO - 2024-01-01 00:38:46 --> Language Class Initialized
INFO - 2024-01-01 00:38:46 --> Loader Class Initialized
INFO - 2024-01-01 00:38:46 --> Helper loaded: url_helper
INFO - 2024-01-01 00:38:46 --> Helper loaded: file_helper
INFO - 2024-01-01 00:38:47 --> Helper loaded: html_helper
INFO - 2024-01-01 00:38:47 --> Helper loaded: text_helper
INFO - 2024-01-01 00:38:47 --> Helper loaded: form_helper
INFO - 2024-01-01 00:38:47 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:38:47 --> Helper loaded: security_helper
INFO - 2024-01-01 00:38:47 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:38:47 --> Database Driver Class Initialized
INFO - 2024-01-01 00:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:38:47 --> Parser Class Initialized
INFO - 2024-01-01 00:38:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:38:47 --> Pagination Class Initialized
INFO - 2024-01-01 00:38:47 --> Form Validation Class Initialized
INFO - 2024-01-01 00:38:47 --> Controller Class Initialized
INFO - 2024-01-01 00:38:47 --> Model Class Initialized
DEBUG - 2024-01-01 00:38:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:38:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:38:47 --> Model Class Initialized
INFO - 2024-01-01 00:38:47 --> Final output sent to browser
DEBUG - 2024-01-01 00:38:47 --> Total execution time: 0.0171
ERROR - 2024-01-01 00:39:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:39:10 --> Config Class Initialized
INFO - 2024-01-01 00:39:10 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:39:10 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:39:10 --> Utf8 Class Initialized
INFO - 2024-01-01 00:39:10 --> URI Class Initialized
INFO - 2024-01-01 00:39:10 --> Router Class Initialized
INFO - 2024-01-01 00:39:10 --> Output Class Initialized
INFO - 2024-01-01 00:39:10 --> Security Class Initialized
DEBUG - 2024-01-01 00:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:39:10 --> Input Class Initialized
INFO - 2024-01-01 00:39:10 --> Language Class Initialized
INFO - 2024-01-01 00:39:10 --> Loader Class Initialized
INFO - 2024-01-01 00:39:10 --> Helper loaded: url_helper
INFO - 2024-01-01 00:39:10 --> Helper loaded: file_helper
INFO - 2024-01-01 00:39:10 --> Helper loaded: html_helper
INFO - 2024-01-01 00:39:10 --> Helper loaded: text_helper
INFO - 2024-01-01 00:39:10 --> Helper loaded: form_helper
INFO - 2024-01-01 00:39:10 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:39:10 --> Helper loaded: security_helper
INFO - 2024-01-01 00:39:10 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:39:10 --> Database Driver Class Initialized
INFO - 2024-01-01 00:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:39:10 --> Parser Class Initialized
INFO - 2024-01-01 00:39:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:39:10 --> Pagination Class Initialized
INFO - 2024-01-01 00:39:10 --> Form Validation Class Initialized
INFO - 2024-01-01 00:39:10 --> Controller Class Initialized
INFO - 2024-01-01 00:39:10 --> Model Class Initialized
DEBUG - 2024-01-01 00:39:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:39:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:39:10 --> Model Class Initialized
DEBUG - 2024-01-01 00:39:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:39:10 --> Model Class Initialized
INFO - 2024-01-01 00:39:10 --> Email Class Initialized
DEBUG - 2024-01-01 00:39:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:39:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:39:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-01-01 00:39:10 --> Language file loaded: language/english/email_lang.php
INFO - 2024-01-01 00:39:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-01-01 00:39:11 --> Final output sent to browser
DEBUG - 2024-01-01 00:39:11 --> Total execution time: 0.5123
ERROR - 2024-01-01 00:39:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:39:18 --> Config Class Initialized
INFO - 2024-01-01 00:39:18 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:39:18 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:39:18 --> Utf8 Class Initialized
INFO - 2024-01-01 00:39:18 --> URI Class Initialized
INFO - 2024-01-01 00:39:18 --> Router Class Initialized
INFO - 2024-01-01 00:39:18 --> Output Class Initialized
INFO - 2024-01-01 00:39:18 --> Security Class Initialized
DEBUG - 2024-01-01 00:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:39:18 --> Input Class Initialized
INFO - 2024-01-01 00:39:18 --> Language Class Initialized
INFO - 2024-01-01 00:39:18 --> Loader Class Initialized
INFO - 2024-01-01 00:39:18 --> Helper loaded: url_helper
INFO - 2024-01-01 00:39:18 --> Helper loaded: file_helper
INFO - 2024-01-01 00:39:18 --> Helper loaded: html_helper
INFO - 2024-01-01 00:39:18 --> Helper loaded: text_helper
INFO - 2024-01-01 00:39:18 --> Helper loaded: form_helper
INFO - 2024-01-01 00:39:18 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:39:18 --> Helper loaded: security_helper
INFO - 2024-01-01 00:39:18 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:39:18 --> Database Driver Class Initialized
INFO - 2024-01-01 00:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:39:18 --> Parser Class Initialized
INFO - 2024-01-01 00:39:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:39:18 --> Pagination Class Initialized
INFO - 2024-01-01 00:39:18 --> Form Validation Class Initialized
INFO - 2024-01-01 00:39:18 --> Controller Class Initialized
INFO - 2024-01-01 00:39:18 --> Model Class Initialized
DEBUG - 2024-01-01 00:39:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:39:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:39:18 --> Model Class Initialized
DEBUG - 2024-01-01 00:39:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:39:18 --> Model Class Initialized
INFO - 2024-01-01 00:39:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-01-01 00:39:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:39:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 00:39:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 00:39:18 --> Model Class Initialized
INFO - 2024-01-01 00:39:18 --> Model Class Initialized
INFO - 2024-01-01 00:39:18 --> Model Class Initialized
INFO - 2024-01-01 00:39:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-01 00:39:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-01 00:39:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 00:39:19 --> Final output sent to browser
DEBUG - 2024-01-01 00:39:19 --> Total execution time: 0.1897
ERROR - 2024-01-01 00:39:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:39:28 --> Config Class Initialized
INFO - 2024-01-01 00:39:28 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:39:28 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:39:28 --> Utf8 Class Initialized
INFO - 2024-01-01 00:39:28 --> URI Class Initialized
INFO - 2024-01-01 00:39:28 --> Router Class Initialized
INFO - 2024-01-01 00:39:28 --> Output Class Initialized
INFO - 2024-01-01 00:39:28 --> Security Class Initialized
DEBUG - 2024-01-01 00:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:39:28 --> Input Class Initialized
INFO - 2024-01-01 00:39:28 --> Language Class Initialized
INFO - 2024-01-01 00:39:28 --> Loader Class Initialized
INFO - 2024-01-01 00:39:28 --> Helper loaded: url_helper
INFO - 2024-01-01 00:39:28 --> Helper loaded: file_helper
INFO - 2024-01-01 00:39:28 --> Helper loaded: html_helper
INFO - 2024-01-01 00:39:28 --> Helper loaded: text_helper
INFO - 2024-01-01 00:39:28 --> Helper loaded: form_helper
INFO - 2024-01-01 00:39:28 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:39:28 --> Helper loaded: security_helper
INFO - 2024-01-01 00:39:28 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:39:28 --> Database Driver Class Initialized
INFO - 2024-01-01 00:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:39:28 --> Parser Class Initialized
INFO - 2024-01-01 00:39:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:39:28 --> Pagination Class Initialized
INFO - 2024-01-01 00:39:28 --> Form Validation Class Initialized
INFO - 2024-01-01 00:39:28 --> Controller Class Initialized
INFO - 2024-01-01 00:39:28 --> Model Class Initialized
DEBUG - 2024-01-01 00:39:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:39:28 --> Final output sent to browser
DEBUG - 2024-01-01 00:39:28 --> Total execution time: 0.0155
ERROR - 2024-01-01 00:39:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:39:29 --> Config Class Initialized
INFO - 2024-01-01 00:39:29 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:39:29 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:39:29 --> Utf8 Class Initialized
INFO - 2024-01-01 00:39:29 --> URI Class Initialized
INFO - 2024-01-01 00:39:29 --> Router Class Initialized
INFO - 2024-01-01 00:39:29 --> Output Class Initialized
INFO - 2024-01-01 00:39:29 --> Security Class Initialized
DEBUG - 2024-01-01 00:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:39:29 --> Input Class Initialized
INFO - 2024-01-01 00:39:29 --> Language Class Initialized
INFO - 2024-01-01 00:39:29 --> Loader Class Initialized
INFO - 2024-01-01 00:39:29 --> Helper loaded: url_helper
INFO - 2024-01-01 00:39:29 --> Helper loaded: file_helper
INFO - 2024-01-01 00:39:29 --> Helper loaded: html_helper
INFO - 2024-01-01 00:39:29 --> Helper loaded: text_helper
INFO - 2024-01-01 00:39:29 --> Helper loaded: form_helper
INFO - 2024-01-01 00:39:29 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:39:29 --> Helper loaded: security_helper
INFO - 2024-01-01 00:39:29 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:39:29 --> Database Driver Class Initialized
INFO - 2024-01-01 00:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:39:29 --> Parser Class Initialized
INFO - 2024-01-01 00:39:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:39:29 --> Pagination Class Initialized
INFO - 2024-01-01 00:39:29 --> Form Validation Class Initialized
INFO - 2024-01-01 00:39:29 --> Controller Class Initialized
INFO - 2024-01-01 00:39:29 --> Model Class Initialized
DEBUG - 2024-01-01 00:39:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:39:29 --> Final output sent to browser
DEBUG - 2024-01-01 00:39:29 --> Total execution time: 0.0150
ERROR - 2024-01-01 00:39:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:39:31 --> Config Class Initialized
INFO - 2024-01-01 00:39:31 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:39:31 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:39:31 --> Utf8 Class Initialized
INFO - 2024-01-01 00:39:31 --> URI Class Initialized
INFO - 2024-01-01 00:39:31 --> Router Class Initialized
INFO - 2024-01-01 00:39:31 --> Output Class Initialized
INFO - 2024-01-01 00:39:31 --> Security Class Initialized
DEBUG - 2024-01-01 00:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:39:31 --> Input Class Initialized
INFO - 2024-01-01 00:39:31 --> Language Class Initialized
INFO - 2024-01-01 00:39:31 --> Loader Class Initialized
INFO - 2024-01-01 00:39:31 --> Helper loaded: url_helper
INFO - 2024-01-01 00:39:31 --> Helper loaded: file_helper
INFO - 2024-01-01 00:39:31 --> Helper loaded: html_helper
INFO - 2024-01-01 00:39:31 --> Helper loaded: text_helper
INFO - 2024-01-01 00:39:31 --> Helper loaded: form_helper
INFO - 2024-01-01 00:39:31 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:39:31 --> Helper loaded: security_helper
INFO - 2024-01-01 00:39:31 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:39:31 --> Database Driver Class Initialized
INFO - 2024-01-01 00:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:39:31 --> Parser Class Initialized
INFO - 2024-01-01 00:39:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:39:31 --> Pagination Class Initialized
INFO - 2024-01-01 00:39:31 --> Form Validation Class Initialized
INFO - 2024-01-01 00:39:31 --> Controller Class Initialized
INFO - 2024-01-01 00:39:31 --> Model Class Initialized
DEBUG - 2024-01-01 00:39:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:39:31 --> Final output sent to browser
DEBUG - 2024-01-01 00:39:31 --> Total execution time: 0.0151
ERROR - 2024-01-01 00:39:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:39:34 --> Config Class Initialized
INFO - 2024-01-01 00:39:34 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:39:34 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:39:34 --> Utf8 Class Initialized
INFO - 2024-01-01 00:39:34 --> URI Class Initialized
INFO - 2024-01-01 00:39:34 --> Router Class Initialized
INFO - 2024-01-01 00:39:34 --> Output Class Initialized
INFO - 2024-01-01 00:39:34 --> Security Class Initialized
DEBUG - 2024-01-01 00:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:39:34 --> Input Class Initialized
INFO - 2024-01-01 00:39:34 --> Language Class Initialized
INFO - 2024-01-01 00:39:34 --> Loader Class Initialized
INFO - 2024-01-01 00:39:34 --> Helper loaded: url_helper
INFO - 2024-01-01 00:39:34 --> Helper loaded: file_helper
INFO - 2024-01-01 00:39:34 --> Helper loaded: html_helper
INFO - 2024-01-01 00:39:34 --> Helper loaded: text_helper
INFO - 2024-01-01 00:39:34 --> Helper loaded: form_helper
INFO - 2024-01-01 00:39:34 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:39:34 --> Helper loaded: security_helper
INFO - 2024-01-01 00:39:34 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:39:34 --> Database Driver Class Initialized
INFO - 2024-01-01 00:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:39:34 --> Parser Class Initialized
INFO - 2024-01-01 00:39:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:39:34 --> Pagination Class Initialized
INFO - 2024-01-01 00:39:34 --> Form Validation Class Initialized
INFO - 2024-01-01 00:39:34 --> Controller Class Initialized
INFO - 2024-01-01 00:39:34 --> Model Class Initialized
DEBUG - 2024-01-01 00:39:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:39:34 --> Final output sent to browser
DEBUG - 2024-01-01 00:39:34 --> Total execution time: 0.0152
ERROR - 2024-01-01 00:39:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:39:37 --> Config Class Initialized
INFO - 2024-01-01 00:39:37 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:39:37 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:39:37 --> Utf8 Class Initialized
INFO - 2024-01-01 00:39:37 --> URI Class Initialized
INFO - 2024-01-01 00:39:37 --> Router Class Initialized
INFO - 2024-01-01 00:39:37 --> Output Class Initialized
INFO - 2024-01-01 00:39:37 --> Security Class Initialized
DEBUG - 2024-01-01 00:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:39:37 --> Input Class Initialized
INFO - 2024-01-01 00:39:37 --> Language Class Initialized
INFO - 2024-01-01 00:39:37 --> Loader Class Initialized
INFO - 2024-01-01 00:39:37 --> Helper loaded: url_helper
INFO - 2024-01-01 00:39:37 --> Helper loaded: file_helper
INFO - 2024-01-01 00:39:37 --> Helper loaded: html_helper
INFO - 2024-01-01 00:39:37 --> Helper loaded: text_helper
INFO - 2024-01-01 00:39:37 --> Helper loaded: form_helper
INFO - 2024-01-01 00:39:37 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:39:37 --> Helper loaded: security_helper
INFO - 2024-01-01 00:39:37 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:39:37 --> Database Driver Class Initialized
INFO - 2024-01-01 00:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:39:37 --> Parser Class Initialized
INFO - 2024-01-01 00:39:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:39:37 --> Pagination Class Initialized
INFO - 2024-01-01 00:39:37 --> Form Validation Class Initialized
INFO - 2024-01-01 00:39:37 --> Controller Class Initialized
INFO - 2024-01-01 00:39:37 --> Model Class Initialized
DEBUG - 2024-01-01 00:39:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:39:37 --> Final output sent to browser
DEBUG - 2024-01-01 00:39:37 --> Total execution time: 0.0159
ERROR - 2024-01-01 00:39:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:39:38 --> Config Class Initialized
INFO - 2024-01-01 00:39:38 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:39:38 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:39:38 --> Utf8 Class Initialized
INFO - 2024-01-01 00:39:38 --> URI Class Initialized
INFO - 2024-01-01 00:39:38 --> Router Class Initialized
INFO - 2024-01-01 00:39:38 --> Output Class Initialized
INFO - 2024-01-01 00:39:38 --> Security Class Initialized
DEBUG - 2024-01-01 00:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:39:38 --> Input Class Initialized
INFO - 2024-01-01 00:39:38 --> Language Class Initialized
INFO - 2024-01-01 00:39:38 --> Loader Class Initialized
INFO - 2024-01-01 00:39:38 --> Helper loaded: url_helper
INFO - 2024-01-01 00:39:38 --> Helper loaded: file_helper
INFO - 2024-01-01 00:39:38 --> Helper loaded: html_helper
INFO - 2024-01-01 00:39:38 --> Helper loaded: text_helper
INFO - 2024-01-01 00:39:38 --> Helper loaded: form_helper
INFO - 2024-01-01 00:39:38 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:39:38 --> Helper loaded: security_helper
INFO - 2024-01-01 00:39:38 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:39:38 --> Database Driver Class Initialized
INFO - 2024-01-01 00:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:39:38 --> Parser Class Initialized
INFO - 2024-01-01 00:39:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:39:38 --> Pagination Class Initialized
INFO - 2024-01-01 00:39:38 --> Form Validation Class Initialized
INFO - 2024-01-01 00:39:38 --> Controller Class Initialized
INFO - 2024-01-01 00:39:38 --> Model Class Initialized
DEBUG - 2024-01-01 00:39:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-01 00:39:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-01-01 00:39:38 --> Final output sent to browser
DEBUG - 2024-01-01 00:39:38 --> Total execution time: 0.0178
ERROR - 2024-01-01 00:39:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:39:41 --> Config Class Initialized
INFO - 2024-01-01 00:39:41 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:39:41 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:39:41 --> Utf8 Class Initialized
INFO - 2024-01-01 00:39:41 --> URI Class Initialized
INFO - 2024-01-01 00:39:41 --> Router Class Initialized
INFO - 2024-01-01 00:39:41 --> Output Class Initialized
INFO - 2024-01-01 00:39:41 --> Security Class Initialized
DEBUG - 2024-01-01 00:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:39:41 --> Input Class Initialized
INFO - 2024-01-01 00:39:41 --> Language Class Initialized
INFO - 2024-01-01 00:39:41 --> Loader Class Initialized
INFO - 2024-01-01 00:39:41 --> Helper loaded: url_helper
INFO - 2024-01-01 00:39:41 --> Helper loaded: file_helper
INFO - 2024-01-01 00:39:41 --> Helper loaded: html_helper
INFO - 2024-01-01 00:39:41 --> Helper loaded: text_helper
INFO - 2024-01-01 00:39:41 --> Helper loaded: form_helper
INFO - 2024-01-01 00:39:41 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:39:41 --> Helper loaded: security_helper
INFO - 2024-01-01 00:39:41 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:39:41 --> Database Driver Class Initialized
INFO - 2024-01-01 00:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:39:41 --> Parser Class Initialized
INFO - 2024-01-01 00:39:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:39:41 --> Pagination Class Initialized
INFO - 2024-01-01 00:39:41 --> Form Validation Class Initialized
INFO - 2024-01-01 00:39:41 --> Controller Class Initialized
INFO - 2024-01-01 00:39:41 --> Model Class Initialized
DEBUG - 2024-01-01 00:39:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:39:41 --> Final output sent to browser
DEBUG - 2024-01-01 00:39:41 --> Total execution time: 0.0144
ERROR - 2024-01-01 00:39:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:39:42 --> Config Class Initialized
INFO - 2024-01-01 00:39:42 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:39:42 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:39:42 --> Utf8 Class Initialized
INFO - 2024-01-01 00:39:42 --> URI Class Initialized
INFO - 2024-01-01 00:39:42 --> Router Class Initialized
INFO - 2024-01-01 00:39:42 --> Output Class Initialized
INFO - 2024-01-01 00:39:42 --> Security Class Initialized
DEBUG - 2024-01-01 00:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:39:42 --> Input Class Initialized
INFO - 2024-01-01 00:39:42 --> Language Class Initialized
INFO - 2024-01-01 00:39:42 --> Loader Class Initialized
INFO - 2024-01-01 00:39:42 --> Helper loaded: url_helper
INFO - 2024-01-01 00:39:42 --> Helper loaded: file_helper
INFO - 2024-01-01 00:39:42 --> Helper loaded: html_helper
INFO - 2024-01-01 00:39:42 --> Helper loaded: text_helper
INFO - 2024-01-01 00:39:42 --> Helper loaded: form_helper
INFO - 2024-01-01 00:39:42 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:39:42 --> Helper loaded: security_helper
INFO - 2024-01-01 00:39:42 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:39:42 --> Database Driver Class Initialized
INFO - 2024-01-01 00:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:39:42 --> Parser Class Initialized
INFO - 2024-01-01 00:39:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:39:42 --> Pagination Class Initialized
INFO - 2024-01-01 00:39:42 --> Form Validation Class Initialized
INFO - 2024-01-01 00:39:42 --> Controller Class Initialized
INFO - 2024-01-01 00:39:42 --> Model Class Initialized
DEBUG - 2024-01-01 00:39:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:39:42 --> Final output sent to browser
DEBUG - 2024-01-01 00:39:42 --> Total execution time: 0.0167
ERROR - 2024-01-01 00:39:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:39:45 --> Config Class Initialized
INFO - 2024-01-01 00:39:45 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:39:45 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:39:45 --> Utf8 Class Initialized
INFO - 2024-01-01 00:39:45 --> URI Class Initialized
INFO - 2024-01-01 00:39:45 --> Router Class Initialized
INFO - 2024-01-01 00:39:45 --> Output Class Initialized
INFO - 2024-01-01 00:39:45 --> Security Class Initialized
DEBUG - 2024-01-01 00:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:39:45 --> Input Class Initialized
INFO - 2024-01-01 00:39:45 --> Language Class Initialized
INFO - 2024-01-01 00:39:45 --> Loader Class Initialized
INFO - 2024-01-01 00:39:45 --> Helper loaded: url_helper
INFO - 2024-01-01 00:39:45 --> Helper loaded: file_helper
INFO - 2024-01-01 00:39:45 --> Helper loaded: html_helper
INFO - 2024-01-01 00:39:45 --> Helper loaded: text_helper
INFO - 2024-01-01 00:39:45 --> Helper loaded: form_helper
INFO - 2024-01-01 00:39:45 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:39:45 --> Helper loaded: security_helper
INFO - 2024-01-01 00:39:45 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:39:45 --> Database Driver Class Initialized
INFO - 2024-01-01 00:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:39:45 --> Parser Class Initialized
INFO - 2024-01-01 00:39:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:39:45 --> Pagination Class Initialized
INFO - 2024-01-01 00:39:45 --> Form Validation Class Initialized
INFO - 2024-01-01 00:39:45 --> Controller Class Initialized
INFO - 2024-01-01 00:39:45 --> Model Class Initialized
DEBUG - 2024-01-01 00:39:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:39:45 --> Final output sent to browser
DEBUG - 2024-01-01 00:39:45 --> Total execution time: 0.0148
ERROR - 2024-01-01 00:39:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:39:48 --> Config Class Initialized
INFO - 2024-01-01 00:39:48 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:39:48 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:39:48 --> Utf8 Class Initialized
INFO - 2024-01-01 00:39:48 --> URI Class Initialized
INFO - 2024-01-01 00:39:48 --> Router Class Initialized
INFO - 2024-01-01 00:39:48 --> Output Class Initialized
INFO - 2024-01-01 00:39:48 --> Security Class Initialized
DEBUG - 2024-01-01 00:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:39:48 --> Input Class Initialized
INFO - 2024-01-01 00:39:48 --> Language Class Initialized
INFO - 2024-01-01 00:39:48 --> Loader Class Initialized
INFO - 2024-01-01 00:39:48 --> Helper loaded: url_helper
INFO - 2024-01-01 00:39:48 --> Helper loaded: file_helper
INFO - 2024-01-01 00:39:48 --> Helper loaded: html_helper
INFO - 2024-01-01 00:39:48 --> Helper loaded: text_helper
INFO - 2024-01-01 00:39:48 --> Helper loaded: form_helper
INFO - 2024-01-01 00:39:48 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:39:48 --> Helper loaded: security_helper
INFO - 2024-01-01 00:39:48 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:39:48 --> Database Driver Class Initialized
INFO - 2024-01-01 00:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:39:48 --> Parser Class Initialized
INFO - 2024-01-01 00:39:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:39:48 --> Pagination Class Initialized
INFO - 2024-01-01 00:39:48 --> Form Validation Class Initialized
INFO - 2024-01-01 00:39:48 --> Controller Class Initialized
INFO - 2024-01-01 00:39:48 --> Final output sent to browser
DEBUG - 2024-01-01 00:39:48 --> Total execution time: 0.0181
ERROR - 2024-01-01 00:39:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:39:54 --> Config Class Initialized
INFO - 2024-01-01 00:39:54 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:39:54 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:39:54 --> Utf8 Class Initialized
INFO - 2024-01-01 00:39:54 --> URI Class Initialized
INFO - 2024-01-01 00:39:54 --> Router Class Initialized
INFO - 2024-01-01 00:39:54 --> Output Class Initialized
INFO - 2024-01-01 00:39:54 --> Security Class Initialized
DEBUG - 2024-01-01 00:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:39:54 --> Input Class Initialized
INFO - 2024-01-01 00:39:54 --> Language Class Initialized
INFO - 2024-01-01 00:39:54 --> Loader Class Initialized
INFO - 2024-01-01 00:39:54 --> Helper loaded: url_helper
INFO - 2024-01-01 00:39:54 --> Helper loaded: file_helper
INFO - 2024-01-01 00:39:54 --> Helper loaded: html_helper
INFO - 2024-01-01 00:39:54 --> Helper loaded: text_helper
INFO - 2024-01-01 00:39:54 --> Helper loaded: form_helper
INFO - 2024-01-01 00:39:54 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:39:54 --> Helper loaded: security_helper
INFO - 2024-01-01 00:39:54 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:39:54 --> Database Driver Class Initialized
INFO - 2024-01-01 00:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:39:54 --> Parser Class Initialized
INFO - 2024-01-01 00:39:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:39:54 --> Pagination Class Initialized
INFO - 2024-01-01 00:39:54 --> Form Validation Class Initialized
INFO - 2024-01-01 00:39:54 --> Controller Class Initialized
INFO - 2024-01-01 00:39:54 --> Model Class Initialized
DEBUG - 2024-01-01 00:39:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:39:54 --> Final output sent to browser
DEBUG - 2024-01-01 00:39:54 --> Total execution time: 0.0149
ERROR - 2024-01-01 00:39:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:39:55 --> Config Class Initialized
INFO - 2024-01-01 00:39:55 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:39:55 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:39:55 --> Utf8 Class Initialized
INFO - 2024-01-01 00:39:55 --> URI Class Initialized
INFO - 2024-01-01 00:39:55 --> Router Class Initialized
INFO - 2024-01-01 00:39:55 --> Output Class Initialized
INFO - 2024-01-01 00:39:55 --> Security Class Initialized
DEBUG - 2024-01-01 00:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:39:55 --> Input Class Initialized
INFO - 2024-01-01 00:39:55 --> Language Class Initialized
INFO - 2024-01-01 00:39:55 --> Loader Class Initialized
INFO - 2024-01-01 00:39:55 --> Helper loaded: url_helper
INFO - 2024-01-01 00:39:55 --> Helper loaded: file_helper
INFO - 2024-01-01 00:39:55 --> Helper loaded: html_helper
INFO - 2024-01-01 00:39:55 --> Helper loaded: text_helper
INFO - 2024-01-01 00:39:55 --> Helper loaded: form_helper
INFO - 2024-01-01 00:39:55 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:39:55 --> Helper loaded: security_helper
INFO - 2024-01-01 00:39:55 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:39:55 --> Database Driver Class Initialized
INFO - 2024-01-01 00:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:39:55 --> Parser Class Initialized
INFO - 2024-01-01 00:39:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:39:55 --> Pagination Class Initialized
INFO - 2024-01-01 00:39:55 --> Form Validation Class Initialized
INFO - 2024-01-01 00:39:55 --> Controller Class Initialized
INFO - 2024-01-01 00:39:55 --> Model Class Initialized
DEBUG - 2024-01-01 00:39:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:39:55 --> Final output sent to browser
DEBUG - 2024-01-01 00:39:55 --> Total execution time: 0.0152
ERROR - 2024-01-01 00:40:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:40:50 --> Config Class Initialized
INFO - 2024-01-01 00:40:50 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:40:50 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:40:50 --> Utf8 Class Initialized
INFO - 2024-01-01 00:40:50 --> URI Class Initialized
DEBUG - 2024-01-01 00:40:50 --> No URI present. Default controller set.
INFO - 2024-01-01 00:40:50 --> Router Class Initialized
INFO - 2024-01-01 00:40:50 --> Output Class Initialized
INFO - 2024-01-01 00:40:50 --> Security Class Initialized
DEBUG - 2024-01-01 00:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:40:50 --> Input Class Initialized
INFO - 2024-01-01 00:40:50 --> Language Class Initialized
INFO - 2024-01-01 00:40:50 --> Loader Class Initialized
INFO - 2024-01-01 00:40:50 --> Helper loaded: url_helper
INFO - 2024-01-01 00:40:50 --> Helper loaded: file_helper
INFO - 2024-01-01 00:40:50 --> Helper loaded: html_helper
INFO - 2024-01-01 00:40:50 --> Helper loaded: text_helper
INFO - 2024-01-01 00:40:50 --> Helper loaded: form_helper
INFO - 2024-01-01 00:40:50 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:40:50 --> Helper loaded: security_helper
INFO - 2024-01-01 00:40:50 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:40:50 --> Database Driver Class Initialized
INFO - 2024-01-01 00:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:40:50 --> Parser Class Initialized
INFO - 2024-01-01 00:40:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:40:50 --> Pagination Class Initialized
INFO - 2024-01-01 00:40:50 --> Form Validation Class Initialized
INFO - 2024-01-01 00:40:50 --> Controller Class Initialized
INFO - 2024-01-01 00:40:50 --> Model Class Initialized
DEBUG - 2024-01-01 00:40:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:40:50 --> Model Class Initialized
DEBUG - 2024-01-01 00:40:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:40:50 --> Model Class Initialized
INFO - 2024-01-01 00:40:50 --> Model Class Initialized
INFO - 2024-01-01 00:40:50 --> Model Class Initialized
INFO - 2024-01-01 00:40:50 --> Model Class Initialized
DEBUG - 2024-01-01 00:40:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:40:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:40:50 --> Model Class Initialized
INFO - 2024-01-01 00:40:50 --> Model Class Initialized
INFO - 2024-01-01 00:40:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-01 00:40:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:40:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 00:40:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 00:40:50 --> Model Class Initialized
INFO - 2024-01-01 00:40:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-01 00:40:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-01 00:40:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 00:40:50 --> Final output sent to browser
DEBUG - 2024-01-01 00:40:50 --> Total execution time: 0.2572
ERROR - 2024-01-01 00:41:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:41:05 --> Config Class Initialized
INFO - 2024-01-01 00:41:05 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:41:05 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:41:05 --> Utf8 Class Initialized
INFO - 2024-01-01 00:41:05 --> URI Class Initialized
INFO - 2024-01-01 00:41:05 --> Router Class Initialized
INFO - 2024-01-01 00:41:05 --> Output Class Initialized
INFO - 2024-01-01 00:41:05 --> Security Class Initialized
DEBUG - 2024-01-01 00:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:41:05 --> Input Class Initialized
INFO - 2024-01-01 00:41:05 --> Language Class Initialized
INFO - 2024-01-01 00:41:05 --> Loader Class Initialized
INFO - 2024-01-01 00:41:05 --> Helper loaded: url_helper
INFO - 2024-01-01 00:41:05 --> Helper loaded: file_helper
INFO - 2024-01-01 00:41:05 --> Helper loaded: html_helper
INFO - 2024-01-01 00:41:05 --> Helper loaded: text_helper
INFO - 2024-01-01 00:41:05 --> Helper loaded: form_helper
INFO - 2024-01-01 00:41:05 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:41:05 --> Helper loaded: security_helper
INFO - 2024-01-01 00:41:05 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:41:05 --> Database Driver Class Initialized
INFO - 2024-01-01 00:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:41:05 --> Parser Class Initialized
INFO - 2024-01-01 00:41:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:41:05 --> Pagination Class Initialized
INFO - 2024-01-01 00:41:05 --> Form Validation Class Initialized
INFO - 2024-01-01 00:41:05 --> Controller Class Initialized
INFO - 2024-01-01 00:41:05 --> Model Class Initialized
DEBUG - 2024-01-01 00:41:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:41:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:41:05 --> Model Class Initialized
DEBUG - 2024-01-01 00:41:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:41:05 --> Model Class Initialized
INFO - 2024-01-01 00:41:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-01 00:41:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:41:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 00:41:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 00:41:05 --> Model Class Initialized
INFO - 2024-01-01 00:41:05 --> Model Class Initialized
INFO - 2024-01-01 00:41:05 --> Model Class Initialized
INFO - 2024-01-01 00:41:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-01 00:41:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-01 00:41:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 00:41:05 --> Final output sent to browser
DEBUG - 2024-01-01 00:41:05 --> Total execution time: 0.1556
ERROR - 2024-01-01 00:41:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:41:06 --> Config Class Initialized
INFO - 2024-01-01 00:41:06 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:41:06 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:41:06 --> Utf8 Class Initialized
INFO - 2024-01-01 00:41:06 --> URI Class Initialized
INFO - 2024-01-01 00:41:06 --> Router Class Initialized
INFO - 2024-01-01 00:41:06 --> Output Class Initialized
INFO - 2024-01-01 00:41:06 --> Security Class Initialized
DEBUG - 2024-01-01 00:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:41:06 --> Input Class Initialized
INFO - 2024-01-01 00:41:06 --> Language Class Initialized
INFO - 2024-01-01 00:41:06 --> Loader Class Initialized
INFO - 2024-01-01 00:41:06 --> Helper loaded: url_helper
INFO - 2024-01-01 00:41:06 --> Helper loaded: file_helper
INFO - 2024-01-01 00:41:06 --> Helper loaded: html_helper
INFO - 2024-01-01 00:41:06 --> Helper loaded: text_helper
INFO - 2024-01-01 00:41:06 --> Helper loaded: form_helper
INFO - 2024-01-01 00:41:06 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:41:06 --> Helper loaded: security_helper
INFO - 2024-01-01 00:41:06 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:41:06 --> Database Driver Class Initialized
INFO - 2024-01-01 00:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:41:06 --> Parser Class Initialized
INFO - 2024-01-01 00:41:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:41:06 --> Pagination Class Initialized
INFO - 2024-01-01 00:41:06 --> Form Validation Class Initialized
INFO - 2024-01-01 00:41:06 --> Controller Class Initialized
INFO - 2024-01-01 00:41:06 --> Model Class Initialized
DEBUG - 2024-01-01 00:41:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:41:06 --> Model Class Initialized
DEBUG - 2024-01-01 00:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:41:06 --> Model Class Initialized
INFO - 2024-01-01 00:41:06 --> Final output sent to browser
DEBUG - 2024-01-01 00:41:06 --> Total execution time: 0.0401
ERROR - 2024-01-01 00:41:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:41:23 --> Config Class Initialized
INFO - 2024-01-01 00:41:23 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:41:23 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:41:23 --> Utf8 Class Initialized
INFO - 2024-01-01 00:41:23 --> URI Class Initialized
INFO - 2024-01-01 00:41:23 --> Router Class Initialized
INFO - 2024-01-01 00:41:23 --> Output Class Initialized
INFO - 2024-01-01 00:41:23 --> Security Class Initialized
DEBUG - 2024-01-01 00:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:41:23 --> Input Class Initialized
INFO - 2024-01-01 00:41:23 --> Language Class Initialized
INFO - 2024-01-01 00:41:23 --> Loader Class Initialized
INFO - 2024-01-01 00:41:23 --> Helper loaded: url_helper
INFO - 2024-01-01 00:41:23 --> Helper loaded: file_helper
INFO - 2024-01-01 00:41:23 --> Helper loaded: html_helper
INFO - 2024-01-01 00:41:23 --> Helper loaded: text_helper
INFO - 2024-01-01 00:41:23 --> Helper loaded: form_helper
INFO - 2024-01-01 00:41:23 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:41:23 --> Helper loaded: security_helper
INFO - 2024-01-01 00:41:23 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:41:23 --> Database Driver Class Initialized
INFO - 2024-01-01 00:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:41:23 --> Parser Class Initialized
INFO - 2024-01-01 00:41:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:41:23 --> Pagination Class Initialized
INFO - 2024-01-01 00:41:23 --> Form Validation Class Initialized
INFO - 2024-01-01 00:41:23 --> Controller Class Initialized
INFO - 2024-01-01 00:41:23 --> Model Class Initialized
DEBUG - 2024-01-01 00:41:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:41:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:41:23 --> Model Class Initialized
DEBUG - 2024-01-01 00:41:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:41:23 --> Model Class Initialized
INFO - 2024-01-01 00:41:23 --> Final output sent to browser
DEBUG - 2024-01-01 00:41:23 --> Total execution time: 0.0762
ERROR - 2024-01-01 00:41:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:41:43 --> Config Class Initialized
INFO - 2024-01-01 00:41:43 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:41:43 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:41:43 --> Utf8 Class Initialized
INFO - 2024-01-01 00:41:43 --> URI Class Initialized
INFO - 2024-01-01 00:41:43 --> Router Class Initialized
INFO - 2024-01-01 00:41:43 --> Output Class Initialized
INFO - 2024-01-01 00:41:43 --> Security Class Initialized
DEBUG - 2024-01-01 00:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:41:43 --> Input Class Initialized
INFO - 2024-01-01 00:41:43 --> Language Class Initialized
INFO - 2024-01-01 00:41:43 --> Loader Class Initialized
INFO - 2024-01-01 00:41:43 --> Helper loaded: url_helper
INFO - 2024-01-01 00:41:43 --> Helper loaded: file_helper
INFO - 2024-01-01 00:41:43 --> Helper loaded: html_helper
INFO - 2024-01-01 00:41:43 --> Helper loaded: text_helper
INFO - 2024-01-01 00:41:43 --> Helper loaded: form_helper
INFO - 2024-01-01 00:41:43 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:41:43 --> Helper loaded: security_helper
INFO - 2024-01-01 00:41:43 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:41:43 --> Database Driver Class Initialized
INFO - 2024-01-01 00:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:41:43 --> Parser Class Initialized
INFO - 2024-01-01 00:41:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:41:43 --> Pagination Class Initialized
INFO - 2024-01-01 00:41:43 --> Form Validation Class Initialized
INFO - 2024-01-01 00:41:43 --> Controller Class Initialized
INFO - 2024-01-01 00:41:43 --> Model Class Initialized
DEBUG - 2024-01-01 00:41:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:41:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:41:43 --> Model Class Initialized
DEBUG - 2024-01-01 00:41:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:41:43 --> Model Class Initialized
DEBUG - 2024-01-01 00:41:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:41:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-01 00:41:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:41:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 00:41:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 00:41:43 --> Model Class Initialized
INFO - 2024-01-01 00:41:43 --> Model Class Initialized
INFO - 2024-01-01 00:41:43 --> Model Class Initialized
ERROR - 2024-01-01 00:41:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:41:43 --> Config Class Initialized
INFO - 2024-01-01 00:41:43 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:41:43 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:41:43 --> Utf8 Class Initialized
INFO - 2024-01-01 00:41:43 --> URI Class Initialized
INFO - 2024-01-01 00:41:43 --> Router Class Initialized
INFO - 2024-01-01 00:41:43 --> Output Class Initialized
INFO - 2024-01-01 00:41:43 --> Security Class Initialized
DEBUG - 2024-01-01 00:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:41:43 --> Input Class Initialized
INFO - 2024-01-01 00:41:43 --> Language Class Initialized
INFO - 2024-01-01 00:41:43 --> Loader Class Initialized
INFO - 2024-01-01 00:41:43 --> Helper loaded: url_helper
INFO - 2024-01-01 00:41:43 --> Helper loaded: file_helper
INFO - 2024-01-01 00:41:43 --> Helper loaded: html_helper
INFO - 2024-01-01 00:41:43 --> Helper loaded: text_helper
INFO - 2024-01-01 00:41:43 --> Helper loaded: form_helper
INFO - 2024-01-01 00:41:43 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:41:43 --> Helper loaded: security_helper
INFO - 2024-01-01 00:41:43 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:41:43 --> Database Driver Class Initialized
INFO - 2024-01-01 00:41:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-01 00:41:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-01 00:41:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 00:41:43 --> Final output sent to browser
DEBUG - 2024-01-01 00:41:43 --> Total execution time: 0.1656
INFO - 2024-01-01 00:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:41:43 --> Parser Class Initialized
INFO - 2024-01-01 00:41:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:41:43 --> Pagination Class Initialized
INFO - 2024-01-01 00:41:43 --> Form Validation Class Initialized
INFO - 2024-01-01 00:41:43 --> Controller Class Initialized
INFO - 2024-01-01 00:41:43 --> Model Class Initialized
DEBUG - 2024-01-01 00:41:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:41:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:41:43 --> Model Class Initialized
DEBUG - 2024-01-01 00:41:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:41:43 --> Model Class Initialized
DEBUG - 2024-01-01 00:41:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:41:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-01 00:41:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:41:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 00:41:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 00:41:43 --> Model Class Initialized
INFO - 2024-01-01 00:41:43 --> Model Class Initialized
INFO - 2024-01-01 00:41:43 --> Model Class Initialized
INFO - 2024-01-01 00:41:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-01 00:41:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-01 00:41:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 00:41:43 --> Final output sent to browser
DEBUG - 2024-01-01 00:41:43 --> Total execution time: 0.2291
ERROR - 2024-01-01 00:42:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:42:13 --> Config Class Initialized
INFO - 2024-01-01 00:42:13 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:42:13 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:42:13 --> Utf8 Class Initialized
INFO - 2024-01-01 00:42:13 --> URI Class Initialized
INFO - 2024-01-01 00:42:13 --> Router Class Initialized
INFO - 2024-01-01 00:42:13 --> Output Class Initialized
INFO - 2024-01-01 00:42:13 --> Security Class Initialized
DEBUG - 2024-01-01 00:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:42:13 --> Input Class Initialized
INFO - 2024-01-01 00:42:13 --> Language Class Initialized
INFO - 2024-01-01 00:42:13 --> Loader Class Initialized
INFO - 2024-01-01 00:42:13 --> Helper loaded: url_helper
INFO - 2024-01-01 00:42:13 --> Helper loaded: file_helper
INFO - 2024-01-01 00:42:13 --> Helper loaded: html_helper
INFO - 2024-01-01 00:42:13 --> Helper loaded: text_helper
INFO - 2024-01-01 00:42:13 --> Helper loaded: form_helper
INFO - 2024-01-01 00:42:13 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:42:13 --> Helper loaded: security_helper
INFO - 2024-01-01 00:42:13 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:42:13 --> Database Driver Class Initialized
INFO - 2024-01-01 00:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:42:13 --> Parser Class Initialized
INFO - 2024-01-01 00:42:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:42:13 --> Pagination Class Initialized
INFO - 2024-01-01 00:42:13 --> Form Validation Class Initialized
INFO - 2024-01-01 00:42:13 --> Controller Class Initialized
INFO - 2024-01-01 00:42:13 --> Model Class Initialized
DEBUG - 2024-01-01 00:42:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:42:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:42:13 --> Model Class Initialized
DEBUG - 2024-01-01 00:42:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:42:13 --> Model Class Initialized
INFO - 2024-01-01 00:42:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-01 00:42:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:42:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 00:42:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 00:42:13 --> Model Class Initialized
INFO - 2024-01-01 00:42:13 --> Model Class Initialized
INFO - 2024-01-01 00:42:13 --> Model Class Initialized
INFO - 2024-01-01 00:42:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-01 00:42:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-01 00:42:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 00:42:14 --> Final output sent to browser
DEBUG - 2024-01-01 00:42:14 --> Total execution time: 0.1519
ERROR - 2024-01-01 00:42:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:42:15 --> Config Class Initialized
INFO - 2024-01-01 00:42:15 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:42:15 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:42:15 --> Utf8 Class Initialized
INFO - 2024-01-01 00:42:15 --> URI Class Initialized
INFO - 2024-01-01 00:42:15 --> Router Class Initialized
INFO - 2024-01-01 00:42:15 --> Output Class Initialized
INFO - 2024-01-01 00:42:15 --> Security Class Initialized
DEBUG - 2024-01-01 00:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:42:15 --> Input Class Initialized
INFO - 2024-01-01 00:42:15 --> Language Class Initialized
INFO - 2024-01-01 00:42:15 --> Loader Class Initialized
INFO - 2024-01-01 00:42:15 --> Helper loaded: url_helper
INFO - 2024-01-01 00:42:15 --> Helper loaded: file_helper
INFO - 2024-01-01 00:42:15 --> Helper loaded: html_helper
INFO - 2024-01-01 00:42:15 --> Helper loaded: text_helper
INFO - 2024-01-01 00:42:15 --> Helper loaded: form_helper
INFO - 2024-01-01 00:42:15 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:42:15 --> Helper loaded: security_helper
INFO - 2024-01-01 00:42:15 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:42:15 --> Database Driver Class Initialized
INFO - 2024-01-01 00:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:42:15 --> Parser Class Initialized
INFO - 2024-01-01 00:42:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:42:15 --> Pagination Class Initialized
INFO - 2024-01-01 00:42:15 --> Form Validation Class Initialized
INFO - 2024-01-01 00:42:15 --> Controller Class Initialized
INFO - 2024-01-01 00:42:15 --> Model Class Initialized
DEBUG - 2024-01-01 00:42:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:42:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:42:15 --> Model Class Initialized
DEBUG - 2024-01-01 00:42:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:42:15 --> Model Class Initialized
INFO - 2024-01-01 00:42:15 --> Final output sent to browser
DEBUG - 2024-01-01 00:42:15 --> Total execution time: 0.0422
ERROR - 2024-01-01 00:42:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:42:18 --> Config Class Initialized
INFO - 2024-01-01 00:42:18 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:42:18 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:42:18 --> Utf8 Class Initialized
INFO - 2024-01-01 00:42:18 --> URI Class Initialized
DEBUG - 2024-01-01 00:42:18 --> No URI present. Default controller set.
INFO - 2024-01-01 00:42:18 --> Router Class Initialized
INFO - 2024-01-01 00:42:18 --> Output Class Initialized
INFO - 2024-01-01 00:42:18 --> Security Class Initialized
DEBUG - 2024-01-01 00:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:42:18 --> Input Class Initialized
INFO - 2024-01-01 00:42:18 --> Language Class Initialized
INFO - 2024-01-01 00:42:18 --> Loader Class Initialized
INFO - 2024-01-01 00:42:18 --> Helper loaded: url_helper
INFO - 2024-01-01 00:42:18 --> Helper loaded: file_helper
INFO - 2024-01-01 00:42:18 --> Helper loaded: html_helper
INFO - 2024-01-01 00:42:18 --> Helper loaded: text_helper
INFO - 2024-01-01 00:42:18 --> Helper loaded: form_helper
INFO - 2024-01-01 00:42:18 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:42:18 --> Helper loaded: security_helper
INFO - 2024-01-01 00:42:18 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:42:18 --> Database Driver Class Initialized
INFO - 2024-01-01 00:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:42:18 --> Parser Class Initialized
INFO - 2024-01-01 00:42:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:42:18 --> Pagination Class Initialized
INFO - 2024-01-01 00:42:18 --> Form Validation Class Initialized
INFO - 2024-01-01 00:42:18 --> Controller Class Initialized
INFO - 2024-01-01 00:42:18 --> Model Class Initialized
DEBUG - 2024-01-01 00:42:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:42:18 --> Model Class Initialized
DEBUG - 2024-01-01 00:42:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:42:18 --> Model Class Initialized
INFO - 2024-01-01 00:42:18 --> Model Class Initialized
INFO - 2024-01-01 00:42:18 --> Model Class Initialized
INFO - 2024-01-01 00:42:18 --> Model Class Initialized
DEBUG - 2024-01-01 00:42:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:42:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:42:18 --> Model Class Initialized
INFO - 2024-01-01 00:42:18 --> Model Class Initialized
INFO - 2024-01-01 00:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-01 00:42:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 00:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 00:42:18 --> Model Class Initialized
INFO - 2024-01-01 00:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-01 00:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-01 00:42:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 00:42:18 --> Final output sent to browser
DEBUG - 2024-01-01 00:42:18 --> Total execution time: 0.2297
ERROR - 2024-01-01 00:42:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:42:34 --> Config Class Initialized
INFO - 2024-01-01 00:42:34 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:42:34 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:42:34 --> Utf8 Class Initialized
INFO - 2024-01-01 00:42:34 --> URI Class Initialized
INFO - 2024-01-01 00:42:34 --> Router Class Initialized
INFO - 2024-01-01 00:42:34 --> Output Class Initialized
INFO - 2024-01-01 00:42:34 --> Security Class Initialized
DEBUG - 2024-01-01 00:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:42:34 --> Input Class Initialized
INFO - 2024-01-01 00:42:34 --> Language Class Initialized
INFO - 2024-01-01 00:42:34 --> Loader Class Initialized
INFO - 2024-01-01 00:42:34 --> Helper loaded: url_helper
INFO - 2024-01-01 00:42:34 --> Helper loaded: file_helper
INFO - 2024-01-01 00:42:34 --> Helper loaded: html_helper
INFO - 2024-01-01 00:42:34 --> Helper loaded: text_helper
INFO - 2024-01-01 00:42:34 --> Helper loaded: form_helper
INFO - 2024-01-01 00:42:34 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:42:34 --> Helper loaded: security_helper
INFO - 2024-01-01 00:42:34 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:42:34 --> Database Driver Class Initialized
INFO - 2024-01-01 00:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:42:34 --> Parser Class Initialized
INFO - 2024-01-01 00:42:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:42:34 --> Pagination Class Initialized
INFO - 2024-01-01 00:42:34 --> Form Validation Class Initialized
INFO - 2024-01-01 00:42:34 --> Controller Class Initialized
DEBUG - 2024-01-01 00:42:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:42:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:42:34 --> Model Class Initialized
DEBUG - 2024-01-01 00:42:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:42:34 --> Model Class Initialized
DEBUG - 2024-01-01 00:42:34 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:42:34 --> Model Class Initialized
INFO - 2024-01-01 00:42:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-01-01 00:42:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:42:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 00:42:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 00:42:34 --> Model Class Initialized
INFO - 2024-01-01 00:42:34 --> Model Class Initialized
INFO - 2024-01-01 00:42:34 --> Model Class Initialized
INFO - 2024-01-01 00:42:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-01 00:42:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-01 00:42:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 00:42:34 --> Final output sent to browser
DEBUG - 2024-01-01 00:42:34 --> Total execution time: 0.1531
ERROR - 2024-01-01 00:42:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:42:35 --> Config Class Initialized
INFO - 2024-01-01 00:42:35 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:42:35 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:42:35 --> Utf8 Class Initialized
INFO - 2024-01-01 00:42:35 --> URI Class Initialized
INFO - 2024-01-01 00:42:35 --> Router Class Initialized
INFO - 2024-01-01 00:42:35 --> Output Class Initialized
INFO - 2024-01-01 00:42:35 --> Security Class Initialized
DEBUG - 2024-01-01 00:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:42:35 --> Input Class Initialized
INFO - 2024-01-01 00:42:35 --> Language Class Initialized
INFO - 2024-01-01 00:42:35 --> Loader Class Initialized
INFO - 2024-01-01 00:42:35 --> Helper loaded: url_helper
INFO - 2024-01-01 00:42:35 --> Helper loaded: file_helper
INFO - 2024-01-01 00:42:35 --> Helper loaded: html_helper
INFO - 2024-01-01 00:42:35 --> Helper loaded: text_helper
INFO - 2024-01-01 00:42:35 --> Helper loaded: form_helper
INFO - 2024-01-01 00:42:35 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:42:35 --> Helper loaded: security_helper
INFO - 2024-01-01 00:42:35 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:42:35 --> Database Driver Class Initialized
INFO - 2024-01-01 00:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:42:35 --> Parser Class Initialized
INFO - 2024-01-01 00:42:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:42:35 --> Pagination Class Initialized
INFO - 2024-01-01 00:42:35 --> Form Validation Class Initialized
INFO - 2024-01-01 00:42:35 --> Controller Class Initialized
DEBUG - 2024-01-01 00:42:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:42:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:42:35 --> Model Class Initialized
DEBUG - 2024-01-01 00:42:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:42:35 --> Model Class Initialized
INFO - 2024-01-01 00:42:35 --> Final output sent to browser
DEBUG - 2024-01-01 00:42:35 --> Total execution time: 0.0237
ERROR - 2024-01-01 00:42:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:42:57 --> Config Class Initialized
INFO - 2024-01-01 00:42:57 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:42:57 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:42:57 --> Utf8 Class Initialized
INFO - 2024-01-01 00:42:57 --> URI Class Initialized
INFO - 2024-01-01 00:42:57 --> Router Class Initialized
INFO - 2024-01-01 00:42:57 --> Output Class Initialized
INFO - 2024-01-01 00:42:57 --> Security Class Initialized
DEBUG - 2024-01-01 00:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:42:57 --> Input Class Initialized
INFO - 2024-01-01 00:42:57 --> Language Class Initialized
INFO - 2024-01-01 00:42:57 --> Loader Class Initialized
INFO - 2024-01-01 00:42:57 --> Helper loaded: url_helper
INFO - 2024-01-01 00:42:57 --> Helper loaded: file_helper
INFO - 2024-01-01 00:42:57 --> Helper loaded: html_helper
INFO - 2024-01-01 00:42:57 --> Helper loaded: text_helper
INFO - 2024-01-01 00:42:57 --> Helper loaded: form_helper
INFO - 2024-01-01 00:42:57 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:42:57 --> Helper loaded: security_helper
INFO - 2024-01-01 00:42:57 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:42:57 --> Database Driver Class Initialized
INFO - 2024-01-01 00:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:42:57 --> Parser Class Initialized
INFO - 2024-01-01 00:42:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:42:57 --> Pagination Class Initialized
INFO - 2024-01-01 00:42:57 --> Form Validation Class Initialized
INFO - 2024-01-01 00:42:57 --> Controller Class Initialized
DEBUG - 2024-01-01 00:42:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:42:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:42:57 --> Model Class Initialized
DEBUG - 2024-01-01 00:42:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:42:57 --> Model Class Initialized
INFO - 2024-01-01 00:42:57 --> Final output sent to browser
DEBUG - 2024-01-01 00:42:57 --> Total execution time: 0.0292
ERROR - 2024-01-01 00:43:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:43:16 --> Config Class Initialized
INFO - 2024-01-01 00:43:16 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:43:16 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:43:16 --> Utf8 Class Initialized
INFO - 2024-01-01 00:43:16 --> URI Class Initialized
DEBUG - 2024-01-01 00:43:16 --> No URI present. Default controller set.
INFO - 2024-01-01 00:43:16 --> Router Class Initialized
INFO - 2024-01-01 00:43:16 --> Output Class Initialized
INFO - 2024-01-01 00:43:16 --> Security Class Initialized
DEBUG - 2024-01-01 00:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:43:16 --> Input Class Initialized
INFO - 2024-01-01 00:43:16 --> Language Class Initialized
INFO - 2024-01-01 00:43:16 --> Loader Class Initialized
INFO - 2024-01-01 00:43:16 --> Helper loaded: url_helper
INFO - 2024-01-01 00:43:16 --> Helper loaded: file_helper
INFO - 2024-01-01 00:43:16 --> Helper loaded: html_helper
INFO - 2024-01-01 00:43:16 --> Helper loaded: text_helper
INFO - 2024-01-01 00:43:16 --> Helper loaded: form_helper
INFO - 2024-01-01 00:43:16 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:43:16 --> Helper loaded: security_helper
INFO - 2024-01-01 00:43:16 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:43:16 --> Database Driver Class Initialized
INFO - 2024-01-01 00:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:43:16 --> Parser Class Initialized
INFO - 2024-01-01 00:43:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:43:16 --> Pagination Class Initialized
INFO - 2024-01-01 00:43:16 --> Form Validation Class Initialized
INFO - 2024-01-01 00:43:16 --> Controller Class Initialized
INFO - 2024-01-01 00:43:16 --> Model Class Initialized
DEBUG - 2024-01-01 00:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:43:16 --> Model Class Initialized
DEBUG - 2024-01-01 00:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:43:16 --> Model Class Initialized
INFO - 2024-01-01 00:43:16 --> Model Class Initialized
INFO - 2024-01-01 00:43:16 --> Model Class Initialized
INFO - 2024-01-01 00:43:16 --> Model Class Initialized
DEBUG - 2024-01-01 00:43:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:43:16 --> Model Class Initialized
INFO - 2024-01-01 00:43:16 --> Model Class Initialized
INFO - 2024-01-01 00:43:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-01 00:43:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:43:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 00:43:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 00:43:16 --> Model Class Initialized
INFO - 2024-01-01 00:43:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-01 00:43:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-01 00:43:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 00:43:16 --> Final output sent to browser
DEBUG - 2024-01-01 00:43:16 --> Total execution time: 0.2370
ERROR - 2024-01-01 00:43:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:43:23 --> Config Class Initialized
INFO - 2024-01-01 00:43:23 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:43:23 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:43:23 --> Utf8 Class Initialized
INFO - 2024-01-01 00:43:23 --> URI Class Initialized
INFO - 2024-01-01 00:43:23 --> Router Class Initialized
INFO - 2024-01-01 00:43:23 --> Output Class Initialized
INFO - 2024-01-01 00:43:23 --> Security Class Initialized
DEBUG - 2024-01-01 00:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:43:23 --> Input Class Initialized
INFO - 2024-01-01 00:43:23 --> Language Class Initialized
INFO - 2024-01-01 00:43:23 --> Loader Class Initialized
INFO - 2024-01-01 00:43:23 --> Helper loaded: url_helper
INFO - 2024-01-01 00:43:23 --> Helper loaded: file_helper
INFO - 2024-01-01 00:43:23 --> Helper loaded: html_helper
INFO - 2024-01-01 00:43:23 --> Helper loaded: text_helper
INFO - 2024-01-01 00:43:23 --> Helper loaded: form_helper
INFO - 2024-01-01 00:43:23 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:43:23 --> Helper loaded: security_helper
INFO - 2024-01-01 00:43:23 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:43:23 --> Database Driver Class Initialized
INFO - 2024-01-01 00:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:43:23 --> Parser Class Initialized
INFO - 2024-01-01 00:43:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:43:23 --> Pagination Class Initialized
INFO - 2024-01-01 00:43:23 --> Form Validation Class Initialized
INFO - 2024-01-01 00:43:23 --> Controller Class Initialized
INFO - 2024-01-01 00:43:23 --> Model Class Initialized
DEBUG - 2024-01-01 00:43:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:43:23 --> Model Class Initialized
DEBUG - 2024-01-01 00:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:43:23 --> Model Class Initialized
INFO - 2024-01-01 00:43:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-01-01 00:43:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:43:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 00:43:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 00:43:23 --> Model Class Initialized
INFO - 2024-01-01 00:43:23 --> Model Class Initialized
INFO - 2024-01-01 00:43:23 --> Model Class Initialized
INFO - 2024-01-01 00:43:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-01 00:43:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-01 00:43:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 00:43:23 --> Final output sent to browser
DEBUG - 2024-01-01 00:43:23 --> Total execution time: 0.1747
ERROR - 2024-01-01 00:43:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:43:23 --> Config Class Initialized
INFO - 2024-01-01 00:43:23 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:43:23 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:43:23 --> Utf8 Class Initialized
INFO - 2024-01-01 00:43:23 --> URI Class Initialized
INFO - 2024-01-01 00:43:23 --> Router Class Initialized
INFO - 2024-01-01 00:43:23 --> Output Class Initialized
INFO - 2024-01-01 00:43:23 --> Security Class Initialized
DEBUG - 2024-01-01 00:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:43:23 --> Input Class Initialized
INFO - 2024-01-01 00:43:23 --> Language Class Initialized
INFO - 2024-01-01 00:43:23 --> Loader Class Initialized
INFO - 2024-01-01 00:43:23 --> Helper loaded: url_helper
INFO - 2024-01-01 00:43:23 --> Helper loaded: file_helper
INFO - 2024-01-01 00:43:23 --> Helper loaded: html_helper
INFO - 2024-01-01 00:43:23 --> Helper loaded: text_helper
INFO - 2024-01-01 00:43:23 --> Helper loaded: form_helper
INFO - 2024-01-01 00:43:23 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:43:23 --> Helper loaded: security_helper
INFO - 2024-01-01 00:43:23 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:43:23 --> Database Driver Class Initialized
INFO - 2024-01-01 00:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:43:23 --> Parser Class Initialized
INFO - 2024-01-01 00:43:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:43:23 --> Pagination Class Initialized
INFO - 2024-01-01 00:43:23 --> Form Validation Class Initialized
INFO - 2024-01-01 00:43:23 --> Controller Class Initialized
INFO - 2024-01-01 00:43:23 --> Model Class Initialized
DEBUG - 2024-01-01 00:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:43:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-01 00:43:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:43:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 00:43:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 00:43:23 --> Model Class Initialized
INFO - 2024-01-01 00:43:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 00:43:23 --> Final output sent to browser
DEBUG - 2024-01-01 00:43:23 --> Total execution time: 0.0294
ERROR - 2024-01-01 00:43:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:43:24 --> Config Class Initialized
INFO - 2024-01-01 00:43:24 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:43:24 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:43:24 --> Utf8 Class Initialized
INFO - 2024-01-01 00:43:24 --> URI Class Initialized
INFO - 2024-01-01 00:43:24 --> Router Class Initialized
INFO - 2024-01-01 00:43:24 --> Output Class Initialized
INFO - 2024-01-01 00:43:24 --> Security Class Initialized
DEBUG - 2024-01-01 00:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:43:24 --> Input Class Initialized
INFO - 2024-01-01 00:43:24 --> Language Class Initialized
INFO - 2024-01-01 00:43:24 --> Loader Class Initialized
INFO - 2024-01-01 00:43:24 --> Helper loaded: url_helper
INFO - 2024-01-01 00:43:24 --> Helper loaded: file_helper
INFO - 2024-01-01 00:43:24 --> Helper loaded: html_helper
INFO - 2024-01-01 00:43:24 --> Helper loaded: text_helper
INFO - 2024-01-01 00:43:24 --> Helper loaded: form_helper
INFO - 2024-01-01 00:43:24 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:43:24 --> Helper loaded: security_helper
INFO - 2024-01-01 00:43:24 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:43:24 --> Database Driver Class Initialized
INFO - 2024-01-01 00:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:43:24 --> Parser Class Initialized
INFO - 2024-01-01 00:43:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:43:24 --> Pagination Class Initialized
INFO - 2024-01-01 00:43:24 --> Form Validation Class Initialized
INFO - 2024-01-01 00:43:24 --> Controller Class Initialized
INFO - 2024-01-01 00:43:24 --> Model Class Initialized
DEBUG - 2024-01-01 00:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:43:24 --> Model Class Initialized
DEBUG - 2024-01-01 00:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:43:24 --> Model Class Initialized
INFO - 2024-01-01 00:43:24 --> Model Class Initialized
INFO - 2024-01-01 00:43:24 --> Model Class Initialized
INFO - 2024-01-01 00:43:24 --> Model Class Initialized
DEBUG - 2024-01-01 00:43:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:43:24 --> Model Class Initialized
INFO - 2024-01-01 00:43:24 --> Model Class Initialized
INFO - 2024-01-01 00:43:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-01 00:43:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:43:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 00:43:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 00:43:24 --> Model Class Initialized
INFO - 2024-01-01 00:43:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-01 00:43:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-01 00:43:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 00:43:24 --> Final output sent to browser
DEBUG - 2024-01-01 00:43:24 --> Total execution time: 0.2278
ERROR - 2024-01-01 00:43:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:43:32 --> Config Class Initialized
INFO - 2024-01-01 00:43:32 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:43:32 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:43:32 --> Utf8 Class Initialized
INFO - 2024-01-01 00:43:32 --> URI Class Initialized
INFO - 2024-01-01 00:43:32 --> Router Class Initialized
INFO - 2024-01-01 00:43:32 --> Output Class Initialized
INFO - 2024-01-01 00:43:32 --> Security Class Initialized
DEBUG - 2024-01-01 00:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:43:32 --> Input Class Initialized
INFO - 2024-01-01 00:43:32 --> Language Class Initialized
INFO - 2024-01-01 00:43:32 --> Loader Class Initialized
INFO - 2024-01-01 00:43:32 --> Helper loaded: url_helper
INFO - 2024-01-01 00:43:32 --> Helper loaded: file_helper
INFO - 2024-01-01 00:43:32 --> Helper loaded: html_helper
INFO - 2024-01-01 00:43:32 --> Helper loaded: text_helper
INFO - 2024-01-01 00:43:32 --> Helper loaded: form_helper
INFO - 2024-01-01 00:43:32 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:43:32 --> Helper loaded: security_helper
INFO - 2024-01-01 00:43:32 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:43:32 --> Database Driver Class Initialized
INFO - 2024-01-01 00:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:43:32 --> Parser Class Initialized
INFO - 2024-01-01 00:43:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:43:32 --> Pagination Class Initialized
INFO - 2024-01-01 00:43:32 --> Form Validation Class Initialized
INFO - 2024-01-01 00:43:32 --> Controller Class Initialized
INFO - 2024-01-01 00:43:32 --> Model Class Initialized
DEBUG - 2024-01-01 00:43:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:43:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:43:32 --> Model Class Initialized
DEBUG - 2024-01-01 00:43:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:43:32 --> Model Class Initialized
INFO - 2024-01-01 00:43:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-01-01 00:43:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:43:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 00:43:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 00:43:32 --> Model Class Initialized
INFO - 2024-01-01 00:43:32 --> Model Class Initialized
INFO - 2024-01-01 00:43:32 --> Model Class Initialized
INFO - 2024-01-01 00:43:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-01 00:43:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-01 00:43:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 00:43:32 --> Final output sent to browser
DEBUG - 2024-01-01 00:43:32 --> Total execution time: 0.1844
ERROR - 2024-01-01 00:43:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:43:42 --> Config Class Initialized
INFO - 2024-01-01 00:43:42 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:43:42 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:43:42 --> Utf8 Class Initialized
INFO - 2024-01-01 00:43:42 --> URI Class Initialized
INFO - 2024-01-01 00:43:42 --> Router Class Initialized
INFO - 2024-01-01 00:43:42 --> Output Class Initialized
INFO - 2024-01-01 00:43:42 --> Security Class Initialized
DEBUG - 2024-01-01 00:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:43:42 --> Input Class Initialized
INFO - 2024-01-01 00:43:42 --> Language Class Initialized
INFO - 2024-01-01 00:43:42 --> Loader Class Initialized
INFO - 2024-01-01 00:43:42 --> Helper loaded: url_helper
INFO - 2024-01-01 00:43:42 --> Helper loaded: file_helper
INFO - 2024-01-01 00:43:42 --> Helper loaded: html_helper
INFO - 2024-01-01 00:43:42 --> Helper loaded: text_helper
INFO - 2024-01-01 00:43:42 --> Helper loaded: form_helper
INFO - 2024-01-01 00:43:42 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:43:42 --> Helper loaded: security_helper
INFO - 2024-01-01 00:43:42 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:43:42 --> Database Driver Class Initialized
INFO - 2024-01-01 00:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:43:42 --> Parser Class Initialized
INFO - 2024-01-01 00:43:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:43:42 --> Pagination Class Initialized
INFO - 2024-01-01 00:43:42 --> Form Validation Class Initialized
INFO - 2024-01-01 00:43:42 --> Controller Class Initialized
INFO - 2024-01-01 00:43:42 --> Model Class Initialized
DEBUG - 2024-01-01 00:43:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-01 00:43:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-01-01 00:43:42 --> Final output sent to browser
DEBUG - 2024-01-01 00:43:42 --> Total execution time: 0.0160
ERROR - 2024-01-01 00:43:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:43:44 --> Config Class Initialized
INFO - 2024-01-01 00:43:44 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:43:44 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:43:44 --> Utf8 Class Initialized
INFO - 2024-01-01 00:43:44 --> URI Class Initialized
INFO - 2024-01-01 00:43:44 --> Router Class Initialized
INFO - 2024-01-01 00:43:44 --> Output Class Initialized
INFO - 2024-01-01 00:43:44 --> Security Class Initialized
DEBUG - 2024-01-01 00:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:43:44 --> Input Class Initialized
INFO - 2024-01-01 00:43:44 --> Language Class Initialized
INFO - 2024-01-01 00:43:44 --> Loader Class Initialized
INFO - 2024-01-01 00:43:44 --> Helper loaded: url_helper
INFO - 2024-01-01 00:43:44 --> Helper loaded: file_helper
INFO - 2024-01-01 00:43:44 --> Helper loaded: html_helper
INFO - 2024-01-01 00:43:44 --> Helper loaded: text_helper
INFO - 2024-01-01 00:43:44 --> Helper loaded: form_helper
INFO - 2024-01-01 00:43:44 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:43:44 --> Helper loaded: security_helper
INFO - 2024-01-01 00:43:44 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:43:44 --> Database Driver Class Initialized
INFO - 2024-01-01 00:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:43:44 --> Parser Class Initialized
INFO - 2024-01-01 00:43:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:43:44 --> Pagination Class Initialized
INFO - 2024-01-01 00:43:44 --> Form Validation Class Initialized
INFO - 2024-01-01 00:43:44 --> Controller Class Initialized
INFO - 2024-01-01 00:43:44 --> Model Class Initialized
DEBUG - 2024-01-01 00:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:43:44 --> Final output sent to browser
DEBUG - 2024-01-01 00:43:44 --> Total execution time: 0.0192
ERROR - 2024-01-01 00:43:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:43:45 --> Config Class Initialized
INFO - 2024-01-01 00:43:45 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:43:45 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:43:45 --> Utf8 Class Initialized
INFO - 2024-01-01 00:43:45 --> URI Class Initialized
INFO - 2024-01-01 00:43:45 --> Router Class Initialized
INFO - 2024-01-01 00:43:45 --> Output Class Initialized
INFO - 2024-01-01 00:43:45 --> Security Class Initialized
DEBUG - 2024-01-01 00:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:43:45 --> Input Class Initialized
INFO - 2024-01-01 00:43:45 --> Language Class Initialized
INFO - 2024-01-01 00:43:45 --> Loader Class Initialized
INFO - 2024-01-01 00:43:45 --> Helper loaded: url_helper
INFO - 2024-01-01 00:43:45 --> Helper loaded: file_helper
INFO - 2024-01-01 00:43:45 --> Helper loaded: html_helper
INFO - 2024-01-01 00:43:45 --> Helper loaded: text_helper
INFO - 2024-01-01 00:43:45 --> Helper loaded: form_helper
INFO - 2024-01-01 00:43:45 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:43:45 --> Helper loaded: security_helper
INFO - 2024-01-01 00:43:45 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:43:45 --> Database Driver Class Initialized
INFO - 2024-01-01 00:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:43:45 --> Parser Class Initialized
INFO - 2024-01-01 00:43:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:43:45 --> Pagination Class Initialized
INFO - 2024-01-01 00:43:45 --> Form Validation Class Initialized
INFO - 2024-01-01 00:43:45 --> Controller Class Initialized
INFO - 2024-01-01 00:43:45 --> Model Class Initialized
DEBUG - 2024-01-01 00:43:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:43:45 --> Final output sent to browser
DEBUG - 2024-01-01 00:43:45 --> Total execution time: 0.0156
ERROR - 2024-01-01 00:43:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:43:47 --> Config Class Initialized
INFO - 2024-01-01 00:43:47 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:43:47 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:43:47 --> Utf8 Class Initialized
INFO - 2024-01-01 00:43:47 --> URI Class Initialized
INFO - 2024-01-01 00:43:47 --> Router Class Initialized
INFO - 2024-01-01 00:43:47 --> Output Class Initialized
INFO - 2024-01-01 00:43:47 --> Security Class Initialized
DEBUG - 2024-01-01 00:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:43:47 --> Input Class Initialized
INFO - 2024-01-01 00:43:47 --> Language Class Initialized
INFO - 2024-01-01 00:43:47 --> Loader Class Initialized
INFO - 2024-01-01 00:43:47 --> Helper loaded: url_helper
INFO - 2024-01-01 00:43:47 --> Helper loaded: file_helper
INFO - 2024-01-01 00:43:47 --> Helper loaded: html_helper
INFO - 2024-01-01 00:43:47 --> Helper loaded: text_helper
INFO - 2024-01-01 00:43:47 --> Helper loaded: form_helper
INFO - 2024-01-01 00:43:47 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:43:47 --> Helper loaded: security_helper
INFO - 2024-01-01 00:43:47 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:43:47 --> Database Driver Class Initialized
INFO - 2024-01-01 00:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:43:47 --> Parser Class Initialized
INFO - 2024-01-01 00:43:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:43:47 --> Pagination Class Initialized
INFO - 2024-01-01 00:43:47 --> Form Validation Class Initialized
INFO - 2024-01-01 00:43:47 --> Controller Class Initialized
INFO - 2024-01-01 00:43:47 --> Model Class Initialized
DEBUG - 2024-01-01 00:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:43:47 --> Final output sent to browser
DEBUG - 2024-01-01 00:43:47 --> Total execution time: 0.0153
ERROR - 2024-01-01 00:43:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:43:52 --> Config Class Initialized
INFO - 2024-01-01 00:43:52 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:43:52 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:43:52 --> Utf8 Class Initialized
INFO - 2024-01-01 00:43:52 --> URI Class Initialized
INFO - 2024-01-01 00:43:52 --> Router Class Initialized
INFO - 2024-01-01 00:43:52 --> Output Class Initialized
INFO - 2024-01-01 00:43:52 --> Security Class Initialized
DEBUG - 2024-01-01 00:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:43:52 --> Input Class Initialized
INFO - 2024-01-01 00:43:52 --> Language Class Initialized
INFO - 2024-01-01 00:43:52 --> Loader Class Initialized
INFO - 2024-01-01 00:43:52 --> Helper loaded: url_helper
INFO - 2024-01-01 00:43:52 --> Helper loaded: file_helper
INFO - 2024-01-01 00:43:52 --> Helper loaded: html_helper
INFO - 2024-01-01 00:43:52 --> Helper loaded: text_helper
INFO - 2024-01-01 00:43:52 --> Helper loaded: form_helper
INFO - 2024-01-01 00:43:52 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:43:52 --> Helper loaded: security_helper
INFO - 2024-01-01 00:43:52 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:43:52 --> Database Driver Class Initialized
INFO - 2024-01-01 00:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:43:52 --> Parser Class Initialized
INFO - 2024-01-01 00:43:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:43:52 --> Pagination Class Initialized
INFO - 2024-01-01 00:43:52 --> Form Validation Class Initialized
INFO - 2024-01-01 00:43:52 --> Controller Class Initialized
INFO - 2024-01-01 00:43:52 --> Final output sent to browser
DEBUG - 2024-01-01 00:43:52 --> Total execution time: 0.0135
ERROR - 2024-01-01 00:43:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:43:59 --> Config Class Initialized
INFO - 2024-01-01 00:43:59 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:43:59 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:43:59 --> Utf8 Class Initialized
INFO - 2024-01-01 00:43:59 --> URI Class Initialized
INFO - 2024-01-01 00:43:59 --> Router Class Initialized
INFO - 2024-01-01 00:43:59 --> Output Class Initialized
INFO - 2024-01-01 00:43:59 --> Security Class Initialized
DEBUG - 2024-01-01 00:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:43:59 --> Input Class Initialized
INFO - 2024-01-01 00:43:59 --> Language Class Initialized
INFO - 2024-01-01 00:43:59 --> Loader Class Initialized
INFO - 2024-01-01 00:43:59 --> Helper loaded: url_helper
INFO - 2024-01-01 00:43:59 --> Helper loaded: file_helper
INFO - 2024-01-01 00:43:59 --> Helper loaded: html_helper
INFO - 2024-01-01 00:43:59 --> Helper loaded: text_helper
INFO - 2024-01-01 00:43:59 --> Helper loaded: form_helper
INFO - 2024-01-01 00:43:59 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:43:59 --> Helper loaded: security_helper
INFO - 2024-01-01 00:43:59 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:43:59 --> Database Driver Class Initialized
INFO - 2024-01-01 00:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:43:59 --> Parser Class Initialized
INFO - 2024-01-01 00:43:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:43:59 --> Pagination Class Initialized
INFO - 2024-01-01 00:43:59 --> Form Validation Class Initialized
INFO - 2024-01-01 00:43:59 --> Controller Class Initialized
INFO - 2024-01-01 00:43:59 --> Model Class Initialized
DEBUG - 2024-01-01 00:43:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:43:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:43:59 --> Model Class Initialized
DEBUG - 2024-01-01 00:43:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:43:59 --> Model Class Initialized
INFO - 2024-01-01 00:43:59 --> Final output sent to browser
DEBUG - 2024-01-01 00:43:59 --> Total execution time: 0.0184
ERROR - 2024-01-01 00:44:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:44:03 --> Config Class Initialized
INFO - 2024-01-01 00:44:03 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:44:03 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:44:03 --> Utf8 Class Initialized
INFO - 2024-01-01 00:44:03 --> URI Class Initialized
INFO - 2024-01-01 00:44:03 --> Router Class Initialized
INFO - 2024-01-01 00:44:03 --> Output Class Initialized
INFO - 2024-01-01 00:44:03 --> Security Class Initialized
DEBUG - 2024-01-01 00:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:44:03 --> Input Class Initialized
INFO - 2024-01-01 00:44:03 --> Language Class Initialized
INFO - 2024-01-01 00:44:03 --> Loader Class Initialized
INFO - 2024-01-01 00:44:03 --> Helper loaded: url_helper
INFO - 2024-01-01 00:44:03 --> Helper loaded: file_helper
INFO - 2024-01-01 00:44:03 --> Helper loaded: html_helper
INFO - 2024-01-01 00:44:03 --> Helper loaded: text_helper
INFO - 2024-01-01 00:44:03 --> Helper loaded: form_helper
INFO - 2024-01-01 00:44:03 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:44:03 --> Helper loaded: security_helper
INFO - 2024-01-01 00:44:03 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:44:03 --> Database Driver Class Initialized
INFO - 2024-01-01 00:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:44:03 --> Parser Class Initialized
INFO - 2024-01-01 00:44:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:44:03 --> Pagination Class Initialized
INFO - 2024-01-01 00:44:03 --> Form Validation Class Initialized
INFO - 2024-01-01 00:44:03 --> Controller Class Initialized
INFO - 2024-01-01 00:44:03 --> Model Class Initialized
DEBUG - 2024-01-01 00:44:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:44:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:44:03 --> Model Class Initialized
DEBUG - 2024-01-01 00:44:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:44:03 --> Model Class Initialized
INFO - 2024-01-01 00:44:03 --> Final output sent to browser
DEBUG - 2024-01-01 00:44:03 --> Total execution time: 0.0206
ERROR - 2024-01-01 00:44:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:44:05 --> Config Class Initialized
INFO - 2024-01-01 00:44:05 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:44:05 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:44:05 --> Utf8 Class Initialized
INFO - 2024-01-01 00:44:05 --> URI Class Initialized
INFO - 2024-01-01 00:44:05 --> Router Class Initialized
INFO - 2024-01-01 00:44:05 --> Output Class Initialized
INFO - 2024-01-01 00:44:05 --> Security Class Initialized
DEBUG - 2024-01-01 00:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:44:05 --> Input Class Initialized
INFO - 2024-01-01 00:44:05 --> Language Class Initialized
INFO - 2024-01-01 00:44:05 --> Loader Class Initialized
INFO - 2024-01-01 00:44:05 --> Helper loaded: url_helper
INFO - 2024-01-01 00:44:05 --> Helper loaded: file_helper
INFO - 2024-01-01 00:44:05 --> Helper loaded: html_helper
INFO - 2024-01-01 00:44:05 --> Helper loaded: text_helper
INFO - 2024-01-01 00:44:05 --> Helper loaded: form_helper
INFO - 2024-01-01 00:44:05 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:44:05 --> Helper loaded: security_helper
INFO - 2024-01-01 00:44:05 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:44:05 --> Database Driver Class Initialized
INFO - 2024-01-01 00:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:44:05 --> Parser Class Initialized
INFO - 2024-01-01 00:44:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:44:05 --> Pagination Class Initialized
INFO - 2024-01-01 00:44:05 --> Form Validation Class Initialized
INFO - 2024-01-01 00:44:05 --> Controller Class Initialized
INFO - 2024-01-01 00:44:05 --> Model Class Initialized
DEBUG - 2024-01-01 00:44:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:44:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:44:05 --> Model Class Initialized
DEBUG - 2024-01-01 00:44:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:44:05 --> Model Class Initialized
INFO - 2024-01-01 00:44:05 --> Final output sent to browser
DEBUG - 2024-01-01 00:44:05 --> Total execution time: 0.0203
ERROR - 2024-01-01 00:44:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:44:14 --> Config Class Initialized
INFO - 2024-01-01 00:44:14 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:44:14 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:44:14 --> Utf8 Class Initialized
INFO - 2024-01-01 00:44:14 --> URI Class Initialized
INFO - 2024-01-01 00:44:14 --> Router Class Initialized
INFO - 2024-01-01 00:44:14 --> Output Class Initialized
INFO - 2024-01-01 00:44:14 --> Security Class Initialized
DEBUG - 2024-01-01 00:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:44:14 --> Input Class Initialized
INFO - 2024-01-01 00:44:14 --> Language Class Initialized
INFO - 2024-01-01 00:44:14 --> Loader Class Initialized
INFO - 2024-01-01 00:44:14 --> Helper loaded: url_helper
INFO - 2024-01-01 00:44:14 --> Helper loaded: file_helper
INFO - 2024-01-01 00:44:14 --> Helper loaded: html_helper
INFO - 2024-01-01 00:44:14 --> Helper loaded: text_helper
INFO - 2024-01-01 00:44:14 --> Helper loaded: form_helper
INFO - 2024-01-01 00:44:14 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:44:14 --> Helper loaded: security_helper
INFO - 2024-01-01 00:44:14 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:44:14 --> Database Driver Class Initialized
INFO - 2024-01-01 00:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:44:14 --> Parser Class Initialized
INFO - 2024-01-01 00:44:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:44:14 --> Pagination Class Initialized
INFO - 2024-01-01 00:44:14 --> Form Validation Class Initialized
INFO - 2024-01-01 00:44:14 --> Controller Class Initialized
INFO - 2024-01-01 00:44:14 --> Model Class Initialized
DEBUG - 2024-01-01 00:44:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:44:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:44:14 --> Model Class Initialized
DEBUG - 2024-01-01 00:44:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:44:14 --> Model Class Initialized
INFO - 2024-01-01 00:44:14 --> Final output sent to browser
DEBUG - 2024-01-01 00:44:14 --> Total execution time: 0.0202
ERROR - 2024-01-01 00:44:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:44:15 --> Config Class Initialized
INFO - 2024-01-01 00:44:15 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:44:15 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:44:15 --> Utf8 Class Initialized
INFO - 2024-01-01 00:44:15 --> URI Class Initialized
INFO - 2024-01-01 00:44:15 --> Router Class Initialized
INFO - 2024-01-01 00:44:15 --> Output Class Initialized
INFO - 2024-01-01 00:44:15 --> Security Class Initialized
DEBUG - 2024-01-01 00:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:44:15 --> Input Class Initialized
INFO - 2024-01-01 00:44:15 --> Language Class Initialized
INFO - 2024-01-01 00:44:15 --> Loader Class Initialized
INFO - 2024-01-01 00:44:15 --> Helper loaded: url_helper
INFO - 2024-01-01 00:44:15 --> Helper loaded: file_helper
INFO - 2024-01-01 00:44:15 --> Helper loaded: html_helper
INFO - 2024-01-01 00:44:15 --> Helper loaded: text_helper
INFO - 2024-01-01 00:44:15 --> Helper loaded: form_helper
INFO - 2024-01-01 00:44:15 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:44:15 --> Helper loaded: security_helper
INFO - 2024-01-01 00:44:15 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:44:15 --> Database Driver Class Initialized
INFO - 2024-01-01 00:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:44:15 --> Parser Class Initialized
INFO - 2024-01-01 00:44:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:44:15 --> Pagination Class Initialized
INFO - 2024-01-01 00:44:15 --> Form Validation Class Initialized
INFO - 2024-01-01 00:44:15 --> Controller Class Initialized
INFO - 2024-01-01 00:44:15 --> Model Class Initialized
DEBUG - 2024-01-01 00:44:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:44:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:44:15 --> Model Class Initialized
DEBUG - 2024-01-01 00:44:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:44:15 --> Model Class Initialized
INFO - 2024-01-01 00:44:15 --> Final output sent to browser
DEBUG - 2024-01-01 00:44:15 --> Total execution time: 0.0857
ERROR - 2024-01-01 00:44:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:44:23 --> Config Class Initialized
INFO - 2024-01-01 00:44:23 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:44:23 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:44:23 --> Utf8 Class Initialized
INFO - 2024-01-01 00:44:23 --> URI Class Initialized
INFO - 2024-01-01 00:44:23 --> Router Class Initialized
INFO - 2024-01-01 00:44:23 --> Output Class Initialized
INFO - 2024-01-01 00:44:23 --> Security Class Initialized
DEBUG - 2024-01-01 00:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:44:23 --> Input Class Initialized
INFO - 2024-01-01 00:44:23 --> Language Class Initialized
INFO - 2024-01-01 00:44:23 --> Loader Class Initialized
INFO - 2024-01-01 00:44:23 --> Helper loaded: url_helper
INFO - 2024-01-01 00:44:23 --> Helper loaded: file_helper
INFO - 2024-01-01 00:44:23 --> Helper loaded: html_helper
INFO - 2024-01-01 00:44:23 --> Helper loaded: text_helper
INFO - 2024-01-01 00:44:23 --> Helper loaded: form_helper
INFO - 2024-01-01 00:44:23 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:44:23 --> Helper loaded: security_helper
INFO - 2024-01-01 00:44:23 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:44:23 --> Database Driver Class Initialized
INFO - 2024-01-01 00:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:44:23 --> Parser Class Initialized
INFO - 2024-01-01 00:44:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:44:23 --> Pagination Class Initialized
INFO - 2024-01-01 00:44:23 --> Form Validation Class Initialized
INFO - 2024-01-01 00:44:23 --> Controller Class Initialized
INFO - 2024-01-01 00:44:23 --> Model Class Initialized
DEBUG - 2024-01-01 00:44:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:44:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:44:23 --> Model Class Initialized
INFO - 2024-01-01 00:44:23 --> Model Class Initialized
INFO - 2024-01-01 00:44:23 --> Final output sent to browser
DEBUG - 2024-01-01 00:44:23 --> Total execution time: 0.0192
ERROR - 2024-01-01 00:44:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:44:26 --> Config Class Initialized
INFO - 2024-01-01 00:44:26 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:44:26 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:44:26 --> Utf8 Class Initialized
INFO - 2024-01-01 00:44:26 --> URI Class Initialized
INFO - 2024-01-01 00:44:26 --> Router Class Initialized
INFO - 2024-01-01 00:44:26 --> Output Class Initialized
INFO - 2024-01-01 00:44:26 --> Security Class Initialized
DEBUG - 2024-01-01 00:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:44:26 --> Input Class Initialized
INFO - 2024-01-01 00:44:26 --> Language Class Initialized
INFO - 2024-01-01 00:44:26 --> Loader Class Initialized
INFO - 2024-01-01 00:44:26 --> Helper loaded: url_helper
INFO - 2024-01-01 00:44:26 --> Helper loaded: file_helper
INFO - 2024-01-01 00:44:26 --> Helper loaded: html_helper
INFO - 2024-01-01 00:44:26 --> Helper loaded: text_helper
INFO - 2024-01-01 00:44:26 --> Helper loaded: form_helper
INFO - 2024-01-01 00:44:26 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:44:26 --> Helper loaded: security_helper
INFO - 2024-01-01 00:44:26 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:44:26 --> Database Driver Class Initialized
INFO - 2024-01-01 00:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:44:26 --> Parser Class Initialized
INFO - 2024-01-01 00:44:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:44:26 --> Pagination Class Initialized
INFO - 2024-01-01 00:44:26 --> Form Validation Class Initialized
INFO - 2024-01-01 00:44:26 --> Controller Class Initialized
INFO - 2024-01-01 00:44:26 --> Model Class Initialized
DEBUG - 2024-01-01 00:44:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:44:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:44:26 --> Model Class Initialized
INFO - 2024-01-01 00:44:26 --> Final output sent to browser
DEBUG - 2024-01-01 00:44:26 --> Total execution time: 0.0163
ERROR - 2024-01-01 00:44:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:44:27 --> Config Class Initialized
INFO - 2024-01-01 00:44:27 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:44:27 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:44:27 --> Utf8 Class Initialized
INFO - 2024-01-01 00:44:27 --> URI Class Initialized
INFO - 2024-01-01 00:44:27 --> Router Class Initialized
INFO - 2024-01-01 00:44:27 --> Output Class Initialized
INFO - 2024-01-01 00:44:27 --> Security Class Initialized
DEBUG - 2024-01-01 00:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:44:27 --> Input Class Initialized
INFO - 2024-01-01 00:44:27 --> Language Class Initialized
INFO - 2024-01-01 00:44:27 --> Loader Class Initialized
INFO - 2024-01-01 00:44:27 --> Helper loaded: url_helper
INFO - 2024-01-01 00:44:27 --> Helper loaded: file_helper
INFO - 2024-01-01 00:44:27 --> Helper loaded: html_helper
INFO - 2024-01-01 00:44:27 --> Helper loaded: text_helper
INFO - 2024-01-01 00:44:27 --> Helper loaded: form_helper
INFO - 2024-01-01 00:44:27 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:44:27 --> Helper loaded: security_helper
INFO - 2024-01-01 00:44:27 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:44:27 --> Database Driver Class Initialized
INFO - 2024-01-01 00:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:44:27 --> Parser Class Initialized
INFO - 2024-01-01 00:44:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:44:27 --> Pagination Class Initialized
INFO - 2024-01-01 00:44:27 --> Form Validation Class Initialized
INFO - 2024-01-01 00:44:27 --> Controller Class Initialized
INFO - 2024-01-01 00:44:27 --> Model Class Initialized
DEBUG - 2024-01-01 00:44:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:44:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:44:27 --> Model Class Initialized
INFO - 2024-01-01 00:44:27 --> Final output sent to browser
DEBUG - 2024-01-01 00:44:27 --> Total execution time: 0.0161
ERROR - 2024-01-01 00:44:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:44:56 --> Config Class Initialized
INFO - 2024-01-01 00:44:56 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:44:56 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:44:56 --> Utf8 Class Initialized
INFO - 2024-01-01 00:44:56 --> URI Class Initialized
INFO - 2024-01-01 00:44:56 --> Router Class Initialized
INFO - 2024-01-01 00:44:56 --> Output Class Initialized
INFO - 2024-01-01 00:44:56 --> Security Class Initialized
DEBUG - 2024-01-01 00:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:44:56 --> Input Class Initialized
INFO - 2024-01-01 00:44:56 --> Language Class Initialized
INFO - 2024-01-01 00:44:56 --> Loader Class Initialized
INFO - 2024-01-01 00:44:56 --> Helper loaded: url_helper
INFO - 2024-01-01 00:44:56 --> Helper loaded: file_helper
INFO - 2024-01-01 00:44:56 --> Helper loaded: html_helper
INFO - 2024-01-01 00:44:56 --> Helper loaded: text_helper
INFO - 2024-01-01 00:44:56 --> Helper loaded: form_helper
INFO - 2024-01-01 00:44:56 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:44:56 --> Helper loaded: security_helper
INFO - 2024-01-01 00:44:56 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:44:56 --> Database Driver Class Initialized
INFO - 2024-01-01 00:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:44:56 --> Parser Class Initialized
INFO - 2024-01-01 00:44:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:44:56 --> Pagination Class Initialized
INFO - 2024-01-01 00:44:56 --> Form Validation Class Initialized
INFO - 2024-01-01 00:44:56 --> Controller Class Initialized
INFO - 2024-01-01 00:44:56 --> Model Class Initialized
DEBUG - 2024-01-01 00:44:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:44:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:44:56 --> Model Class Initialized
DEBUG - 2024-01-01 00:44:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:44:56 --> Model Class Initialized
INFO - 2024-01-01 00:44:56 --> Email Class Initialized
DEBUG - 2024-01-01 00:44:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:44:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-01 00:44:56 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-01-01 00:44:56 --> Language file loaded: language/english/email_lang.php
INFO - 2024-01-01 00:44:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-01-01 00:44:57 --> Final output sent to browser
DEBUG - 2024-01-01 00:44:57 --> Total execution time: 0.4892
ERROR - 2024-01-01 00:45:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:45:06 --> Config Class Initialized
INFO - 2024-01-01 00:45:06 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:45:06 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:45:06 --> Utf8 Class Initialized
INFO - 2024-01-01 00:45:06 --> URI Class Initialized
INFO - 2024-01-01 00:45:06 --> Router Class Initialized
INFO - 2024-01-01 00:45:06 --> Output Class Initialized
INFO - 2024-01-01 00:45:06 --> Security Class Initialized
DEBUG - 2024-01-01 00:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:45:06 --> Input Class Initialized
INFO - 2024-01-01 00:45:06 --> Language Class Initialized
INFO - 2024-01-01 00:45:06 --> Loader Class Initialized
INFO - 2024-01-01 00:45:06 --> Helper loaded: url_helper
INFO - 2024-01-01 00:45:06 --> Helper loaded: file_helper
INFO - 2024-01-01 00:45:06 --> Helper loaded: html_helper
INFO - 2024-01-01 00:45:06 --> Helper loaded: text_helper
INFO - 2024-01-01 00:45:06 --> Helper loaded: form_helper
INFO - 2024-01-01 00:45:06 --> Helper loaded: lang_helper
INFO - 2024-01-01 00:45:06 --> Helper loaded: security_helper
INFO - 2024-01-01 00:45:06 --> Helper loaded: cookie_helper
INFO - 2024-01-01 00:45:06 --> Database Driver Class Initialized
INFO - 2024-01-01 00:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 00:45:06 --> Parser Class Initialized
INFO - 2024-01-01 00:45:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 00:45:06 --> Pagination Class Initialized
INFO - 2024-01-01 00:45:06 --> Form Validation Class Initialized
INFO - 2024-01-01 00:45:06 --> Controller Class Initialized
INFO - 2024-01-01 00:45:06 --> Model Class Initialized
DEBUG - 2024-01-01 00:45:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:45:06 --> Model Class Initialized
DEBUG - 2024-01-01 00:45:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:45:06 --> Model Class Initialized
INFO - 2024-01-01 00:45:06 --> Model Class Initialized
INFO - 2024-01-01 00:45:06 --> Model Class Initialized
INFO - 2024-01-01 00:45:06 --> Model Class Initialized
DEBUG - 2024-01-01 00:45:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 00:45:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:45:06 --> Model Class Initialized
INFO - 2024-01-01 00:45:06 --> Model Class Initialized
INFO - 2024-01-01 00:45:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-01 00:45:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 00:45:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 00:45:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 00:45:06 --> Model Class Initialized
INFO - 2024-01-01 00:45:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-01 00:45:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-01 00:45:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 00:45:06 --> Final output sent to browser
DEBUG - 2024-01-01 00:45:06 --> Total execution time: 0.2410
ERROR - 2024-01-01 00:52:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 00:52:54 --> Config Class Initialized
INFO - 2024-01-01 00:52:54 --> Hooks Class Initialized
DEBUG - 2024-01-01 00:52:54 --> UTF-8 Support Enabled
INFO - 2024-01-01 00:52:54 --> Utf8 Class Initialized
INFO - 2024-01-01 00:52:54 --> URI Class Initialized
INFO - 2024-01-01 00:52:54 --> Router Class Initialized
INFO - 2024-01-01 00:52:54 --> Output Class Initialized
INFO - 2024-01-01 00:52:54 --> Security Class Initialized
DEBUG - 2024-01-01 00:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 00:52:54 --> Input Class Initialized
INFO - 2024-01-01 00:52:54 --> Language Class Initialized
ERROR - 2024-01-01 00:52:54 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-01-01 01:08:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 01:08:01 --> Config Class Initialized
INFO - 2024-01-01 01:08:01 --> Hooks Class Initialized
DEBUG - 2024-01-01 01:08:01 --> UTF-8 Support Enabled
INFO - 2024-01-01 01:08:01 --> Utf8 Class Initialized
INFO - 2024-01-01 01:08:01 --> URI Class Initialized
DEBUG - 2024-01-01 01:08:01 --> No URI present. Default controller set.
INFO - 2024-01-01 01:08:01 --> Router Class Initialized
INFO - 2024-01-01 01:08:01 --> Output Class Initialized
INFO - 2024-01-01 01:08:01 --> Security Class Initialized
DEBUG - 2024-01-01 01:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 01:08:01 --> Input Class Initialized
INFO - 2024-01-01 01:08:01 --> Language Class Initialized
INFO - 2024-01-01 01:08:01 --> Loader Class Initialized
INFO - 2024-01-01 01:08:01 --> Helper loaded: url_helper
INFO - 2024-01-01 01:08:01 --> Helper loaded: file_helper
INFO - 2024-01-01 01:08:01 --> Helper loaded: html_helper
INFO - 2024-01-01 01:08:01 --> Helper loaded: text_helper
INFO - 2024-01-01 01:08:01 --> Helper loaded: form_helper
INFO - 2024-01-01 01:08:01 --> Helper loaded: lang_helper
INFO - 2024-01-01 01:08:01 --> Helper loaded: security_helper
INFO - 2024-01-01 01:08:01 --> Helper loaded: cookie_helper
INFO - 2024-01-01 01:08:01 --> Database Driver Class Initialized
INFO - 2024-01-01 01:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 01:08:01 --> Parser Class Initialized
INFO - 2024-01-01 01:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 01:08:01 --> Pagination Class Initialized
INFO - 2024-01-01 01:08:01 --> Form Validation Class Initialized
INFO - 2024-01-01 01:08:01 --> Controller Class Initialized
INFO - 2024-01-01 01:08:01 --> Model Class Initialized
DEBUG - 2024-01-01 01:08:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-01 01:08:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 01:08:01 --> Config Class Initialized
INFO - 2024-01-01 01:08:01 --> Hooks Class Initialized
DEBUG - 2024-01-01 01:08:01 --> UTF-8 Support Enabled
INFO - 2024-01-01 01:08:01 --> Utf8 Class Initialized
INFO - 2024-01-01 01:08:01 --> URI Class Initialized
DEBUG - 2024-01-01 01:08:01 --> No URI present. Default controller set.
INFO - 2024-01-01 01:08:01 --> Router Class Initialized
INFO - 2024-01-01 01:08:01 --> Output Class Initialized
INFO - 2024-01-01 01:08:01 --> Security Class Initialized
DEBUG - 2024-01-01 01:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 01:08:01 --> Input Class Initialized
INFO - 2024-01-01 01:08:01 --> Language Class Initialized
INFO - 2024-01-01 01:08:01 --> Loader Class Initialized
INFO - 2024-01-01 01:08:01 --> Helper loaded: url_helper
INFO - 2024-01-01 01:08:01 --> Helper loaded: file_helper
INFO - 2024-01-01 01:08:01 --> Helper loaded: html_helper
INFO - 2024-01-01 01:08:01 --> Helper loaded: text_helper
INFO - 2024-01-01 01:08:01 --> Helper loaded: form_helper
INFO - 2024-01-01 01:08:01 --> Helper loaded: lang_helper
INFO - 2024-01-01 01:08:01 --> Helper loaded: security_helper
INFO - 2024-01-01 01:08:01 --> Helper loaded: cookie_helper
INFO - 2024-01-01 01:08:01 --> Database Driver Class Initialized
INFO - 2024-01-01 01:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 01:08:01 --> Parser Class Initialized
INFO - 2024-01-01 01:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 01:08:01 --> Pagination Class Initialized
INFO - 2024-01-01 01:08:01 --> Form Validation Class Initialized
INFO - 2024-01-01 01:08:01 --> Controller Class Initialized
INFO - 2024-01-01 01:08:01 --> Model Class Initialized
DEBUG - 2024-01-01 01:08:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-01 01:08:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 01:08:02 --> Config Class Initialized
INFO - 2024-01-01 01:08:02 --> Hooks Class Initialized
DEBUG - 2024-01-01 01:08:02 --> UTF-8 Support Enabled
INFO - 2024-01-01 01:08:02 --> Utf8 Class Initialized
INFO - 2024-01-01 01:08:02 --> URI Class Initialized
DEBUG - 2024-01-01 01:08:02 --> No URI present. Default controller set.
INFO - 2024-01-01 01:08:02 --> Router Class Initialized
INFO - 2024-01-01 01:08:02 --> Output Class Initialized
INFO - 2024-01-01 01:08:02 --> Security Class Initialized
DEBUG - 2024-01-01 01:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 01:08:02 --> Input Class Initialized
INFO - 2024-01-01 01:08:02 --> Language Class Initialized
INFO - 2024-01-01 01:08:02 --> Loader Class Initialized
INFO - 2024-01-01 01:08:02 --> Helper loaded: url_helper
INFO - 2024-01-01 01:08:02 --> Helper loaded: file_helper
INFO - 2024-01-01 01:08:02 --> Helper loaded: html_helper
INFO - 2024-01-01 01:08:02 --> Helper loaded: text_helper
INFO - 2024-01-01 01:08:02 --> Helper loaded: form_helper
INFO - 2024-01-01 01:08:02 --> Helper loaded: lang_helper
INFO - 2024-01-01 01:08:02 --> Helper loaded: security_helper
INFO - 2024-01-01 01:08:02 --> Helper loaded: cookie_helper
INFO - 2024-01-01 01:08:02 --> Database Driver Class Initialized
INFO - 2024-01-01 01:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 01:08:02 --> Parser Class Initialized
INFO - 2024-01-01 01:08:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 01:08:02 --> Pagination Class Initialized
INFO - 2024-01-01 01:08:02 --> Form Validation Class Initialized
INFO - 2024-01-01 01:08:02 --> Controller Class Initialized
INFO - 2024-01-01 01:08:02 --> Model Class Initialized
DEBUG - 2024-01-01 01:08:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-01 01:08:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 01:08:03 --> Config Class Initialized
INFO - 2024-01-01 01:08:03 --> Hooks Class Initialized
DEBUG - 2024-01-01 01:08:03 --> UTF-8 Support Enabled
INFO - 2024-01-01 01:08:03 --> Utf8 Class Initialized
INFO - 2024-01-01 01:08:03 --> URI Class Initialized
DEBUG - 2024-01-01 01:08:03 --> No URI present. Default controller set.
INFO - 2024-01-01 01:08:03 --> Router Class Initialized
INFO - 2024-01-01 01:08:03 --> Output Class Initialized
INFO - 2024-01-01 01:08:03 --> Security Class Initialized
DEBUG - 2024-01-01 01:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 01:08:03 --> Input Class Initialized
INFO - 2024-01-01 01:08:03 --> Language Class Initialized
INFO - 2024-01-01 01:08:03 --> Loader Class Initialized
INFO - 2024-01-01 01:08:03 --> Helper loaded: url_helper
INFO - 2024-01-01 01:08:03 --> Helper loaded: file_helper
INFO - 2024-01-01 01:08:03 --> Helper loaded: html_helper
INFO - 2024-01-01 01:08:03 --> Helper loaded: text_helper
INFO - 2024-01-01 01:08:03 --> Helper loaded: form_helper
INFO - 2024-01-01 01:08:03 --> Helper loaded: lang_helper
INFO - 2024-01-01 01:08:03 --> Helper loaded: security_helper
INFO - 2024-01-01 01:08:03 --> Helper loaded: cookie_helper
INFO - 2024-01-01 01:08:03 --> Database Driver Class Initialized
INFO - 2024-01-01 01:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 01:08:03 --> Parser Class Initialized
INFO - 2024-01-01 01:08:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 01:08:03 --> Pagination Class Initialized
INFO - 2024-01-01 01:08:03 --> Form Validation Class Initialized
INFO - 2024-01-01 01:08:03 --> Controller Class Initialized
INFO - 2024-01-01 01:08:03 --> Model Class Initialized
DEBUG - 2024-01-01 01:08:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-01 05:22:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 05:22:55 --> Config Class Initialized
INFO - 2024-01-01 05:22:55 --> Hooks Class Initialized
DEBUG - 2024-01-01 05:22:55 --> UTF-8 Support Enabled
INFO - 2024-01-01 05:22:55 --> Utf8 Class Initialized
INFO - 2024-01-01 05:22:55 --> URI Class Initialized
INFO - 2024-01-01 05:22:55 --> Router Class Initialized
INFO - 2024-01-01 05:22:55 --> Output Class Initialized
INFO - 2024-01-01 05:22:55 --> Security Class Initialized
DEBUG - 2024-01-01 05:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 05:22:55 --> Input Class Initialized
INFO - 2024-01-01 05:22:55 --> Language Class Initialized
ERROR - 2024-01-01 05:22:55 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-01-01 11:22:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 11:22:47 --> Config Class Initialized
INFO - 2024-01-01 11:22:47 --> Hooks Class Initialized
DEBUG - 2024-01-01 11:22:47 --> UTF-8 Support Enabled
INFO - 2024-01-01 11:22:47 --> Utf8 Class Initialized
INFO - 2024-01-01 11:22:47 --> URI Class Initialized
DEBUG - 2024-01-01 11:22:47 --> No URI present. Default controller set.
INFO - 2024-01-01 11:22:47 --> Router Class Initialized
INFO - 2024-01-01 11:22:47 --> Output Class Initialized
INFO - 2024-01-01 11:22:47 --> Security Class Initialized
DEBUG - 2024-01-01 11:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 11:22:47 --> Input Class Initialized
INFO - 2024-01-01 11:22:47 --> Language Class Initialized
INFO - 2024-01-01 11:22:47 --> Loader Class Initialized
INFO - 2024-01-01 11:22:47 --> Helper loaded: url_helper
INFO - 2024-01-01 11:22:47 --> Helper loaded: file_helper
INFO - 2024-01-01 11:22:47 --> Helper loaded: html_helper
INFO - 2024-01-01 11:22:47 --> Helper loaded: text_helper
INFO - 2024-01-01 11:22:47 --> Helper loaded: form_helper
INFO - 2024-01-01 11:22:47 --> Helper loaded: lang_helper
INFO - 2024-01-01 11:22:47 --> Helper loaded: security_helper
INFO - 2024-01-01 11:22:47 --> Helper loaded: cookie_helper
INFO - 2024-01-01 11:22:47 --> Database Driver Class Initialized
INFO - 2024-01-01 11:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 11:22:47 --> Parser Class Initialized
INFO - 2024-01-01 11:22:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 11:22:47 --> Pagination Class Initialized
INFO - 2024-01-01 11:22:47 --> Form Validation Class Initialized
INFO - 2024-01-01 11:22:47 --> Controller Class Initialized
INFO - 2024-01-01 11:22:47 --> Model Class Initialized
DEBUG - 2024-01-01 11:22:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-01 11:22:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 11:22:47 --> Config Class Initialized
INFO - 2024-01-01 11:22:47 --> Hooks Class Initialized
DEBUG - 2024-01-01 11:22:47 --> UTF-8 Support Enabled
INFO - 2024-01-01 11:22:47 --> Utf8 Class Initialized
INFO - 2024-01-01 11:22:47 --> URI Class Initialized
INFO - 2024-01-01 11:22:47 --> Router Class Initialized
INFO - 2024-01-01 11:22:47 --> Output Class Initialized
INFO - 2024-01-01 11:22:47 --> Security Class Initialized
DEBUG - 2024-01-01 11:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 11:22:47 --> Input Class Initialized
INFO - 2024-01-01 11:22:47 --> Language Class Initialized
INFO - 2024-01-01 11:22:47 --> Loader Class Initialized
INFO - 2024-01-01 11:22:47 --> Helper loaded: url_helper
INFO - 2024-01-01 11:22:47 --> Helper loaded: file_helper
INFO - 2024-01-01 11:22:47 --> Helper loaded: html_helper
INFO - 2024-01-01 11:22:47 --> Helper loaded: text_helper
INFO - 2024-01-01 11:22:47 --> Helper loaded: form_helper
INFO - 2024-01-01 11:22:47 --> Helper loaded: lang_helper
INFO - 2024-01-01 11:22:47 --> Helper loaded: security_helper
INFO - 2024-01-01 11:22:47 --> Helper loaded: cookie_helper
INFO - 2024-01-01 11:22:47 --> Database Driver Class Initialized
INFO - 2024-01-01 11:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 11:22:47 --> Parser Class Initialized
INFO - 2024-01-01 11:22:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 11:22:47 --> Pagination Class Initialized
INFO - 2024-01-01 11:22:47 --> Form Validation Class Initialized
INFO - 2024-01-01 11:22:47 --> Controller Class Initialized
INFO - 2024-01-01 11:22:47 --> Model Class Initialized
DEBUG - 2024-01-01 11:22:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 11:22:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-01 11:22:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 11:22:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 11:22:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 11:22:47 --> Model Class Initialized
INFO - 2024-01-01 11:22:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 11:22:47 --> Final output sent to browser
DEBUG - 2024-01-01 11:22:47 --> Total execution time: 0.0367
ERROR - 2024-01-01 11:23:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 11:23:07 --> Config Class Initialized
INFO - 2024-01-01 11:23:07 --> Hooks Class Initialized
DEBUG - 2024-01-01 11:23:07 --> UTF-8 Support Enabled
INFO - 2024-01-01 11:23:07 --> Utf8 Class Initialized
INFO - 2024-01-01 11:23:07 --> URI Class Initialized
INFO - 2024-01-01 11:23:07 --> Router Class Initialized
INFO - 2024-01-01 11:23:07 --> Output Class Initialized
INFO - 2024-01-01 11:23:07 --> Security Class Initialized
DEBUG - 2024-01-01 11:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 11:23:07 --> Input Class Initialized
INFO - 2024-01-01 11:23:07 --> Language Class Initialized
INFO - 2024-01-01 11:23:07 --> Loader Class Initialized
INFO - 2024-01-01 11:23:07 --> Helper loaded: url_helper
INFO - 2024-01-01 11:23:07 --> Helper loaded: file_helper
INFO - 2024-01-01 11:23:07 --> Helper loaded: html_helper
INFO - 2024-01-01 11:23:07 --> Helper loaded: text_helper
INFO - 2024-01-01 11:23:07 --> Helper loaded: form_helper
INFO - 2024-01-01 11:23:07 --> Helper loaded: lang_helper
INFO - 2024-01-01 11:23:07 --> Helper loaded: security_helper
INFO - 2024-01-01 11:23:07 --> Helper loaded: cookie_helper
INFO - 2024-01-01 11:23:07 --> Database Driver Class Initialized
INFO - 2024-01-01 11:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 11:23:07 --> Parser Class Initialized
INFO - 2024-01-01 11:23:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 11:23:07 --> Pagination Class Initialized
INFO - 2024-01-01 11:23:07 --> Form Validation Class Initialized
INFO - 2024-01-01 11:23:07 --> Controller Class Initialized
INFO - 2024-01-01 11:23:07 --> Model Class Initialized
DEBUG - 2024-01-01 11:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 11:23:07 --> Model Class Initialized
INFO - 2024-01-01 11:23:07 --> Final output sent to browser
DEBUG - 2024-01-01 11:23:07 --> Total execution time: 0.0234
ERROR - 2024-01-01 11:23:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 11:23:07 --> Config Class Initialized
INFO - 2024-01-01 11:23:07 --> Hooks Class Initialized
DEBUG - 2024-01-01 11:23:07 --> UTF-8 Support Enabled
INFO - 2024-01-01 11:23:07 --> Utf8 Class Initialized
INFO - 2024-01-01 11:23:07 --> URI Class Initialized
DEBUG - 2024-01-01 11:23:07 --> No URI present. Default controller set.
INFO - 2024-01-01 11:23:07 --> Router Class Initialized
INFO - 2024-01-01 11:23:07 --> Output Class Initialized
INFO - 2024-01-01 11:23:07 --> Security Class Initialized
DEBUG - 2024-01-01 11:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 11:23:07 --> Input Class Initialized
INFO - 2024-01-01 11:23:07 --> Language Class Initialized
INFO - 2024-01-01 11:23:07 --> Loader Class Initialized
INFO - 2024-01-01 11:23:07 --> Helper loaded: url_helper
INFO - 2024-01-01 11:23:07 --> Helper loaded: file_helper
INFO - 2024-01-01 11:23:07 --> Helper loaded: html_helper
INFO - 2024-01-01 11:23:07 --> Helper loaded: text_helper
INFO - 2024-01-01 11:23:07 --> Helper loaded: form_helper
INFO - 2024-01-01 11:23:07 --> Helper loaded: lang_helper
INFO - 2024-01-01 11:23:07 --> Helper loaded: security_helper
INFO - 2024-01-01 11:23:07 --> Helper loaded: cookie_helper
INFO - 2024-01-01 11:23:07 --> Database Driver Class Initialized
INFO - 2024-01-01 11:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 11:23:07 --> Parser Class Initialized
INFO - 2024-01-01 11:23:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 11:23:07 --> Pagination Class Initialized
INFO - 2024-01-01 11:23:07 --> Form Validation Class Initialized
INFO - 2024-01-01 11:23:07 --> Controller Class Initialized
INFO - 2024-01-01 11:23:07 --> Model Class Initialized
DEBUG - 2024-01-01 11:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 11:23:07 --> Model Class Initialized
DEBUG - 2024-01-01 11:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 11:23:07 --> Model Class Initialized
INFO - 2024-01-01 11:23:07 --> Model Class Initialized
INFO - 2024-01-01 11:23:07 --> Model Class Initialized
INFO - 2024-01-01 11:23:07 --> Model Class Initialized
DEBUG - 2024-01-01 11:23:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 11:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 11:23:07 --> Model Class Initialized
INFO - 2024-01-01 11:23:07 --> Model Class Initialized
INFO - 2024-01-01 11:23:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-01 11:23:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 11:23:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 11:23:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 11:23:07 --> Model Class Initialized
INFO - 2024-01-01 11:23:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-01 11:23:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-01 11:23:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 11:23:08 --> Final output sent to browser
DEBUG - 2024-01-01 11:23:08 --> Total execution time: 0.2488
ERROR - 2024-01-01 11:23:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 11:23:16 --> Config Class Initialized
INFO - 2024-01-01 11:23:16 --> Hooks Class Initialized
DEBUG - 2024-01-01 11:23:16 --> UTF-8 Support Enabled
INFO - 2024-01-01 11:23:16 --> Utf8 Class Initialized
INFO - 2024-01-01 11:23:16 --> URI Class Initialized
INFO - 2024-01-01 11:23:16 --> Router Class Initialized
INFO - 2024-01-01 11:23:16 --> Output Class Initialized
INFO - 2024-01-01 11:23:16 --> Security Class Initialized
DEBUG - 2024-01-01 11:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 11:23:16 --> Input Class Initialized
INFO - 2024-01-01 11:23:16 --> Language Class Initialized
INFO - 2024-01-01 11:23:16 --> Loader Class Initialized
INFO - 2024-01-01 11:23:16 --> Helper loaded: url_helper
INFO - 2024-01-01 11:23:16 --> Helper loaded: file_helper
INFO - 2024-01-01 11:23:16 --> Helper loaded: html_helper
INFO - 2024-01-01 11:23:16 --> Helper loaded: text_helper
INFO - 2024-01-01 11:23:16 --> Helper loaded: form_helper
INFO - 2024-01-01 11:23:16 --> Helper loaded: lang_helper
INFO - 2024-01-01 11:23:16 --> Helper loaded: security_helper
INFO - 2024-01-01 11:23:16 --> Helper loaded: cookie_helper
INFO - 2024-01-01 11:23:16 --> Database Driver Class Initialized
INFO - 2024-01-01 11:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 11:23:16 --> Parser Class Initialized
INFO - 2024-01-01 11:23:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 11:23:16 --> Pagination Class Initialized
INFO - 2024-01-01 11:23:16 --> Form Validation Class Initialized
INFO - 2024-01-01 11:23:16 --> Controller Class Initialized
INFO - 2024-01-01 11:23:16 --> Model Class Initialized
DEBUG - 2024-01-01 11:23:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 11:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 11:23:16 --> Model Class Initialized
DEBUG - 2024-01-01 11:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 11:23:16 --> Model Class Initialized
INFO - 2024-01-01 11:23:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-01 11:23:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 11:23:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 11:23:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 11:23:16 --> Model Class Initialized
INFO - 2024-01-01 11:23:17 --> Model Class Initialized
INFO - 2024-01-01 11:23:17 --> Model Class Initialized
INFO - 2024-01-01 11:23:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-01 11:23:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-01 11:23:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 11:23:17 --> Final output sent to browser
DEBUG - 2024-01-01 11:23:17 --> Total execution time: 0.1543
ERROR - 2024-01-01 11:23:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 11:23:17 --> Config Class Initialized
INFO - 2024-01-01 11:23:17 --> Hooks Class Initialized
DEBUG - 2024-01-01 11:23:17 --> UTF-8 Support Enabled
INFO - 2024-01-01 11:23:17 --> Utf8 Class Initialized
INFO - 2024-01-01 11:23:17 --> URI Class Initialized
INFO - 2024-01-01 11:23:17 --> Router Class Initialized
INFO - 2024-01-01 11:23:17 --> Output Class Initialized
INFO - 2024-01-01 11:23:17 --> Security Class Initialized
DEBUG - 2024-01-01 11:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 11:23:17 --> Input Class Initialized
INFO - 2024-01-01 11:23:17 --> Language Class Initialized
INFO - 2024-01-01 11:23:17 --> Loader Class Initialized
INFO - 2024-01-01 11:23:17 --> Helper loaded: url_helper
INFO - 2024-01-01 11:23:17 --> Helper loaded: file_helper
INFO - 2024-01-01 11:23:17 --> Helper loaded: html_helper
INFO - 2024-01-01 11:23:17 --> Helper loaded: text_helper
INFO - 2024-01-01 11:23:17 --> Helper loaded: form_helper
INFO - 2024-01-01 11:23:17 --> Helper loaded: lang_helper
INFO - 2024-01-01 11:23:17 --> Helper loaded: security_helper
INFO - 2024-01-01 11:23:17 --> Helper loaded: cookie_helper
INFO - 2024-01-01 11:23:17 --> Database Driver Class Initialized
INFO - 2024-01-01 11:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 11:23:17 --> Parser Class Initialized
INFO - 2024-01-01 11:23:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 11:23:17 --> Pagination Class Initialized
INFO - 2024-01-01 11:23:17 --> Form Validation Class Initialized
INFO - 2024-01-01 11:23:17 --> Controller Class Initialized
INFO - 2024-01-01 11:23:17 --> Model Class Initialized
DEBUG - 2024-01-01 11:23:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 11:23:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 11:23:17 --> Model Class Initialized
DEBUG - 2024-01-01 11:23:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 11:23:17 --> Model Class Initialized
INFO - 2024-01-01 11:23:17 --> Final output sent to browser
DEBUG - 2024-01-01 11:23:17 --> Total execution time: 0.0395
ERROR - 2024-01-01 11:23:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 11:23:21 --> Config Class Initialized
INFO - 2024-01-01 11:23:21 --> Hooks Class Initialized
DEBUG - 2024-01-01 11:23:21 --> UTF-8 Support Enabled
INFO - 2024-01-01 11:23:21 --> Utf8 Class Initialized
INFO - 2024-01-01 11:23:21 --> URI Class Initialized
INFO - 2024-01-01 11:23:21 --> Router Class Initialized
INFO - 2024-01-01 11:23:21 --> Output Class Initialized
INFO - 2024-01-01 11:23:21 --> Security Class Initialized
DEBUG - 2024-01-01 11:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 11:23:21 --> Input Class Initialized
INFO - 2024-01-01 11:23:21 --> Language Class Initialized
INFO - 2024-01-01 11:23:21 --> Loader Class Initialized
INFO - 2024-01-01 11:23:21 --> Helper loaded: url_helper
INFO - 2024-01-01 11:23:21 --> Helper loaded: file_helper
INFO - 2024-01-01 11:23:21 --> Helper loaded: html_helper
INFO - 2024-01-01 11:23:21 --> Helper loaded: text_helper
INFO - 2024-01-01 11:23:21 --> Helper loaded: form_helper
INFO - 2024-01-01 11:23:21 --> Helper loaded: lang_helper
INFO - 2024-01-01 11:23:21 --> Helper loaded: security_helper
INFO - 2024-01-01 11:23:21 --> Helper loaded: cookie_helper
INFO - 2024-01-01 11:23:21 --> Database Driver Class Initialized
INFO - 2024-01-01 11:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 11:23:21 --> Parser Class Initialized
INFO - 2024-01-01 11:23:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 11:23:21 --> Pagination Class Initialized
INFO - 2024-01-01 11:23:21 --> Form Validation Class Initialized
INFO - 2024-01-01 11:23:21 --> Controller Class Initialized
INFO - 2024-01-01 11:23:21 --> Model Class Initialized
DEBUG - 2024-01-01 11:23:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 11:23:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 11:23:21 --> Model Class Initialized
DEBUG - 2024-01-01 11:23:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 11:23:21 --> Model Class Initialized
INFO - 2024-01-01 11:23:21 --> Final output sent to browser
DEBUG - 2024-01-01 11:23:21 --> Total execution time: 0.0446
ERROR - 2024-01-01 11:23:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 11:23:22 --> Config Class Initialized
INFO - 2024-01-01 11:23:22 --> Hooks Class Initialized
DEBUG - 2024-01-01 11:23:22 --> UTF-8 Support Enabled
INFO - 2024-01-01 11:23:22 --> Utf8 Class Initialized
INFO - 2024-01-01 11:23:22 --> URI Class Initialized
INFO - 2024-01-01 11:23:22 --> Router Class Initialized
INFO - 2024-01-01 11:23:22 --> Output Class Initialized
INFO - 2024-01-01 11:23:22 --> Security Class Initialized
DEBUG - 2024-01-01 11:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 11:23:22 --> Input Class Initialized
INFO - 2024-01-01 11:23:22 --> Language Class Initialized
INFO - 2024-01-01 11:23:22 --> Loader Class Initialized
INFO - 2024-01-01 11:23:22 --> Helper loaded: url_helper
INFO - 2024-01-01 11:23:22 --> Helper loaded: file_helper
INFO - 2024-01-01 11:23:22 --> Helper loaded: html_helper
INFO - 2024-01-01 11:23:22 --> Helper loaded: text_helper
INFO - 2024-01-01 11:23:22 --> Helper loaded: form_helper
INFO - 2024-01-01 11:23:22 --> Helper loaded: lang_helper
INFO - 2024-01-01 11:23:22 --> Helper loaded: security_helper
INFO - 2024-01-01 11:23:22 --> Helper loaded: cookie_helper
INFO - 2024-01-01 11:23:22 --> Database Driver Class Initialized
INFO - 2024-01-01 11:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 11:23:22 --> Parser Class Initialized
INFO - 2024-01-01 11:23:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 11:23:22 --> Pagination Class Initialized
INFO - 2024-01-01 11:23:22 --> Form Validation Class Initialized
INFO - 2024-01-01 11:23:22 --> Controller Class Initialized
INFO - 2024-01-01 11:23:22 --> Model Class Initialized
DEBUG - 2024-01-01 11:23:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 11:23:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 11:23:22 --> Model Class Initialized
DEBUG - 2024-01-01 11:23:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 11:23:22 --> Model Class Initialized
INFO - 2024-01-01 11:23:22 --> Final output sent to browser
DEBUG - 2024-01-01 11:23:22 --> Total execution time: 0.0437
ERROR - 2024-01-01 11:23:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 11:23:30 --> Config Class Initialized
INFO - 2024-01-01 11:23:30 --> Hooks Class Initialized
DEBUG - 2024-01-01 11:23:30 --> UTF-8 Support Enabled
INFO - 2024-01-01 11:23:30 --> Utf8 Class Initialized
INFO - 2024-01-01 11:23:30 --> URI Class Initialized
INFO - 2024-01-01 11:23:30 --> Router Class Initialized
INFO - 2024-01-01 11:23:30 --> Output Class Initialized
INFO - 2024-01-01 11:23:30 --> Security Class Initialized
DEBUG - 2024-01-01 11:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 11:23:30 --> Input Class Initialized
INFO - 2024-01-01 11:23:30 --> Language Class Initialized
INFO - 2024-01-01 11:23:30 --> Loader Class Initialized
INFO - 2024-01-01 11:23:30 --> Helper loaded: url_helper
INFO - 2024-01-01 11:23:30 --> Helper loaded: file_helper
INFO - 2024-01-01 11:23:30 --> Helper loaded: html_helper
INFO - 2024-01-01 11:23:30 --> Helper loaded: text_helper
INFO - 2024-01-01 11:23:30 --> Helper loaded: form_helper
INFO - 2024-01-01 11:23:30 --> Helper loaded: lang_helper
INFO - 2024-01-01 11:23:30 --> Helper loaded: security_helper
INFO - 2024-01-01 11:23:30 --> Helper loaded: cookie_helper
INFO - 2024-01-01 11:23:30 --> Database Driver Class Initialized
INFO - 2024-01-01 11:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 11:23:30 --> Parser Class Initialized
INFO - 2024-01-01 11:23:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 11:23:30 --> Pagination Class Initialized
INFO - 2024-01-01 11:23:30 --> Form Validation Class Initialized
INFO - 2024-01-01 11:23:30 --> Controller Class Initialized
INFO - 2024-01-01 11:23:30 --> Model Class Initialized
DEBUG - 2024-01-01 11:23:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 11:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 11:23:30 --> Model Class Initialized
DEBUG - 2024-01-01 11:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 11:23:30 --> Model Class Initialized
DEBUG - 2024-01-01 11:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 11:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-01 11:23:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 11:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 11:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 11:23:30 --> Model Class Initialized
INFO - 2024-01-01 11:23:30 --> Model Class Initialized
INFO - 2024-01-01 11:23:30 --> Model Class Initialized
INFO - 2024-01-01 11:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-01 11:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-01 11:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 11:23:30 --> Final output sent to browser
DEBUG - 2024-01-01 11:23:30 --> Total execution time: 0.1746
ERROR - 2024-01-01 16:10:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 16:10:15 --> Config Class Initialized
INFO - 2024-01-01 16:10:15 --> Hooks Class Initialized
DEBUG - 2024-01-01 16:10:15 --> UTF-8 Support Enabled
INFO - 2024-01-01 16:10:15 --> Utf8 Class Initialized
INFO - 2024-01-01 16:10:15 --> URI Class Initialized
DEBUG - 2024-01-01 16:10:15 --> No URI present. Default controller set.
INFO - 2024-01-01 16:10:15 --> Router Class Initialized
INFO - 2024-01-01 16:10:15 --> Output Class Initialized
INFO - 2024-01-01 16:10:15 --> Security Class Initialized
DEBUG - 2024-01-01 16:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 16:10:15 --> Input Class Initialized
INFO - 2024-01-01 16:10:15 --> Language Class Initialized
INFO - 2024-01-01 16:10:15 --> Loader Class Initialized
INFO - 2024-01-01 16:10:15 --> Helper loaded: url_helper
INFO - 2024-01-01 16:10:15 --> Helper loaded: file_helper
INFO - 2024-01-01 16:10:15 --> Helper loaded: html_helper
INFO - 2024-01-01 16:10:15 --> Helper loaded: text_helper
INFO - 2024-01-01 16:10:15 --> Helper loaded: form_helper
INFO - 2024-01-01 16:10:15 --> Helper loaded: lang_helper
INFO - 2024-01-01 16:10:15 --> Helper loaded: security_helper
INFO - 2024-01-01 16:10:15 --> Helper loaded: cookie_helper
INFO - 2024-01-01 16:10:15 --> Database Driver Class Initialized
INFO - 2024-01-01 16:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 16:10:15 --> Parser Class Initialized
INFO - 2024-01-01 16:10:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 16:10:15 --> Pagination Class Initialized
INFO - 2024-01-01 16:10:15 --> Form Validation Class Initialized
INFO - 2024-01-01 16:10:15 --> Controller Class Initialized
INFO - 2024-01-01 16:10:15 --> Model Class Initialized
DEBUG - 2024-01-01 16:10:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-01 16:10:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 16:10:15 --> Config Class Initialized
INFO - 2024-01-01 16:10:15 --> Hooks Class Initialized
DEBUG - 2024-01-01 16:10:15 --> UTF-8 Support Enabled
INFO - 2024-01-01 16:10:15 --> Utf8 Class Initialized
INFO - 2024-01-01 16:10:15 --> URI Class Initialized
INFO - 2024-01-01 16:10:15 --> Router Class Initialized
INFO - 2024-01-01 16:10:15 --> Output Class Initialized
INFO - 2024-01-01 16:10:15 --> Security Class Initialized
DEBUG - 2024-01-01 16:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 16:10:15 --> Input Class Initialized
INFO - 2024-01-01 16:10:15 --> Language Class Initialized
INFO - 2024-01-01 16:10:15 --> Loader Class Initialized
INFO - 2024-01-01 16:10:15 --> Helper loaded: url_helper
INFO - 2024-01-01 16:10:15 --> Helper loaded: file_helper
INFO - 2024-01-01 16:10:15 --> Helper loaded: html_helper
INFO - 2024-01-01 16:10:15 --> Helper loaded: text_helper
INFO - 2024-01-01 16:10:15 --> Helper loaded: form_helper
INFO - 2024-01-01 16:10:15 --> Helper loaded: lang_helper
INFO - 2024-01-01 16:10:15 --> Helper loaded: security_helper
INFO - 2024-01-01 16:10:15 --> Helper loaded: cookie_helper
INFO - 2024-01-01 16:10:15 --> Database Driver Class Initialized
INFO - 2024-01-01 16:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 16:10:15 --> Parser Class Initialized
INFO - 2024-01-01 16:10:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 16:10:15 --> Pagination Class Initialized
INFO - 2024-01-01 16:10:15 --> Form Validation Class Initialized
INFO - 2024-01-01 16:10:15 --> Controller Class Initialized
INFO - 2024-01-01 16:10:15 --> Model Class Initialized
DEBUG - 2024-01-01 16:10:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 16:10:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-01 16:10:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 16:10:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 16:10:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 16:10:15 --> Model Class Initialized
INFO - 2024-01-01 16:10:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 16:10:15 --> Final output sent to browser
DEBUG - 2024-01-01 16:10:15 --> Total execution time: 0.0373
ERROR - 2024-01-01 16:10:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 16:10:22 --> Config Class Initialized
INFO - 2024-01-01 16:10:22 --> Hooks Class Initialized
DEBUG - 2024-01-01 16:10:22 --> UTF-8 Support Enabled
INFO - 2024-01-01 16:10:22 --> Utf8 Class Initialized
INFO - 2024-01-01 16:10:22 --> URI Class Initialized
INFO - 2024-01-01 16:10:22 --> Router Class Initialized
INFO - 2024-01-01 16:10:22 --> Output Class Initialized
INFO - 2024-01-01 16:10:22 --> Security Class Initialized
DEBUG - 2024-01-01 16:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 16:10:22 --> Input Class Initialized
INFO - 2024-01-01 16:10:22 --> Language Class Initialized
INFO - 2024-01-01 16:10:22 --> Loader Class Initialized
INFO - 2024-01-01 16:10:22 --> Helper loaded: url_helper
INFO - 2024-01-01 16:10:22 --> Helper loaded: file_helper
INFO - 2024-01-01 16:10:22 --> Helper loaded: html_helper
INFO - 2024-01-01 16:10:22 --> Helper loaded: text_helper
INFO - 2024-01-01 16:10:22 --> Helper loaded: form_helper
INFO - 2024-01-01 16:10:22 --> Helper loaded: lang_helper
INFO - 2024-01-01 16:10:22 --> Helper loaded: security_helper
INFO - 2024-01-01 16:10:22 --> Helper loaded: cookie_helper
INFO - 2024-01-01 16:10:22 --> Database Driver Class Initialized
INFO - 2024-01-01 16:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 16:10:22 --> Parser Class Initialized
INFO - 2024-01-01 16:10:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 16:10:22 --> Pagination Class Initialized
INFO - 2024-01-01 16:10:22 --> Form Validation Class Initialized
INFO - 2024-01-01 16:10:22 --> Controller Class Initialized
INFO - 2024-01-01 16:10:22 --> Model Class Initialized
DEBUG - 2024-01-01 16:10:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 16:10:22 --> Model Class Initialized
INFO - 2024-01-01 16:10:22 --> Final output sent to browser
DEBUG - 2024-01-01 16:10:22 --> Total execution time: 0.0193
ERROR - 2024-01-01 16:10:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 16:10:22 --> Config Class Initialized
INFO - 2024-01-01 16:10:22 --> Hooks Class Initialized
DEBUG - 2024-01-01 16:10:22 --> UTF-8 Support Enabled
INFO - 2024-01-01 16:10:22 --> Utf8 Class Initialized
INFO - 2024-01-01 16:10:22 --> URI Class Initialized
DEBUG - 2024-01-01 16:10:22 --> No URI present. Default controller set.
INFO - 2024-01-01 16:10:22 --> Router Class Initialized
INFO - 2024-01-01 16:10:22 --> Output Class Initialized
INFO - 2024-01-01 16:10:22 --> Security Class Initialized
DEBUG - 2024-01-01 16:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 16:10:22 --> Input Class Initialized
INFO - 2024-01-01 16:10:22 --> Language Class Initialized
INFO - 2024-01-01 16:10:22 --> Loader Class Initialized
INFO - 2024-01-01 16:10:22 --> Helper loaded: url_helper
INFO - 2024-01-01 16:10:22 --> Helper loaded: file_helper
INFO - 2024-01-01 16:10:22 --> Helper loaded: html_helper
INFO - 2024-01-01 16:10:22 --> Helper loaded: text_helper
INFO - 2024-01-01 16:10:22 --> Helper loaded: form_helper
INFO - 2024-01-01 16:10:22 --> Helper loaded: lang_helper
INFO - 2024-01-01 16:10:22 --> Helper loaded: security_helper
INFO - 2024-01-01 16:10:22 --> Helper loaded: cookie_helper
INFO - 2024-01-01 16:10:22 --> Database Driver Class Initialized
INFO - 2024-01-01 16:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 16:10:22 --> Parser Class Initialized
INFO - 2024-01-01 16:10:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 16:10:22 --> Pagination Class Initialized
INFO - 2024-01-01 16:10:22 --> Form Validation Class Initialized
INFO - 2024-01-01 16:10:22 --> Controller Class Initialized
INFO - 2024-01-01 16:10:22 --> Model Class Initialized
DEBUG - 2024-01-01 16:10:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 16:10:22 --> Model Class Initialized
DEBUG - 2024-01-01 16:10:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 16:10:22 --> Model Class Initialized
INFO - 2024-01-01 16:10:22 --> Model Class Initialized
INFO - 2024-01-01 16:10:22 --> Model Class Initialized
INFO - 2024-01-01 16:10:22 --> Model Class Initialized
DEBUG - 2024-01-01 16:10:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 16:10:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 16:10:22 --> Model Class Initialized
INFO - 2024-01-01 16:10:22 --> Model Class Initialized
INFO - 2024-01-01 16:10:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-01 16:10:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 16:10:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 16:10:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 16:10:22 --> Model Class Initialized
INFO - 2024-01-01 16:10:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-01 16:10:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-01 16:10:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 16:10:23 --> Final output sent to browser
DEBUG - 2024-01-01 16:10:23 --> Total execution time: 0.4747
ERROR - 2024-01-01 16:10:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 16:10:23 --> Config Class Initialized
INFO - 2024-01-01 16:10:23 --> Hooks Class Initialized
DEBUG - 2024-01-01 16:10:23 --> UTF-8 Support Enabled
INFO - 2024-01-01 16:10:23 --> Utf8 Class Initialized
INFO - 2024-01-01 16:10:23 --> URI Class Initialized
INFO - 2024-01-01 16:10:23 --> Router Class Initialized
INFO - 2024-01-01 16:10:23 --> Output Class Initialized
INFO - 2024-01-01 16:10:23 --> Security Class Initialized
DEBUG - 2024-01-01 16:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 16:10:23 --> Input Class Initialized
INFO - 2024-01-01 16:10:23 --> Language Class Initialized
INFO - 2024-01-01 16:10:23 --> Loader Class Initialized
INFO - 2024-01-01 16:10:23 --> Helper loaded: url_helper
INFO - 2024-01-01 16:10:23 --> Helper loaded: file_helper
INFO - 2024-01-01 16:10:23 --> Helper loaded: html_helper
INFO - 2024-01-01 16:10:23 --> Helper loaded: text_helper
INFO - 2024-01-01 16:10:23 --> Helper loaded: form_helper
INFO - 2024-01-01 16:10:23 --> Helper loaded: lang_helper
INFO - 2024-01-01 16:10:23 --> Helper loaded: security_helper
INFO - 2024-01-01 16:10:23 --> Helper loaded: cookie_helper
INFO - 2024-01-01 16:10:23 --> Database Driver Class Initialized
INFO - 2024-01-01 16:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 16:10:23 --> Parser Class Initialized
INFO - 2024-01-01 16:10:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 16:10:23 --> Pagination Class Initialized
INFO - 2024-01-01 16:10:23 --> Form Validation Class Initialized
INFO - 2024-01-01 16:10:23 --> Controller Class Initialized
DEBUG - 2024-01-01 16:10:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 16:10:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 16:10:23 --> Model Class Initialized
INFO - 2024-01-01 16:10:23 --> Final output sent to browser
DEBUG - 2024-01-01 16:10:23 --> Total execution time: 0.0149
ERROR - 2024-01-01 16:10:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 16:10:48 --> Config Class Initialized
INFO - 2024-01-01 16:10:48 --> Hooks Class Initialized
DEBUG - 2024-01-01 16:10:48 --> UTF-8 Support Enabled
INFO - 2024-01-01 16:10:48 --> Utf8 Class Initialized
INFO - 2024-01-01 16:10:48 --> URI Class Initialized
INFO - 2024-01-01 16:10:48 --> Router Class Initialized
INFO - 2024-01-01 16:10:48 --> Output Class Initialized
INFO - 2024-01-01 16:10:48 --> Security Class Initialized
DEBUG - 2024-01-01 16:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 16:10:48 --> Input Class Initialized
INFO - 2024-01-01 16:10:48 --> Language Class Initialized
INFO - 2024-01-01 16:10:48 --> Loader Class Initialized
INFO - 2024-01-01 16:10:48 --> Helper loaded: url_helper
INFO - 2024-01-01 16:10:48 --> Helper loaded: file_helper
INFO - 2024-01-01 16:10:48 --> Helper loaded: html_helper
INFO - 2024-01-01 16:10:48 --> Helper loaded: text_helper
INFO - 2024-01-01 16:10:48 --> Helper loaded: form_helper
INFO - 2024-01-01 16:10:48 --> Helper loaded: lang_helper
INFO - 2024-01-01 16:10:48 --> Helper loaded: security_helper
INFO - 2024-01-01 16:10:48 --> Helper loaded: cookie_helper
INFO - 2024-01-01 16:10:48 --> Database Driver Class Initialized
INFO - 2024-01-01 16:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 16:10:48 --> Parser Class Initialized
INFO - 2024-01-01 16:10:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 16:10:48 --> Pagination Class Initialized
INFO - 2024-01-01 16:10:48 --> Form Validation Class Initialized
INFO - 2024-01-01 16:10:48 --> Controller Class Initialized
INFO - 2024-01-01 16:10:48 --> Model Class Initialized
DEBUG - 2024-01-01 16:10:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 16:10:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-01 16:10:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 16:10:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 16:10:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 16:10:48 --> Model Class Initialized
INFO - 2024-01-01 16:10:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 16:10:48 --> Final output sent to browser
DEBUG - 2024-01-01 16:10:48 --> Total execution time: 0.0325
ERROR - 2024-01-01 16:10:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 16:10:48 --> Config Class Initialized
INFO - 2024-01-01 16:10:48 --> Hooks Class Initialized
DEBUG - 2024-01-01 16:10:48 --> UTF-8 Support Enabled
INFO - 2024-01-01 16:10:48 --> Utf8 Class Initialized
INFO - 2024-01-01 16:10:48 --> URI Class Initialized
INFO - 2024-01-01 16:10:48 --> Router Class Initialized
INFO - 2024-01-01 16:10:48 --> Output Class Initialized
INFO - 2024-01-01 16:10:48 --> Security Class Initialized
DEBUG - 2024-01-01 16:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 16:10:48 --> Input Class Initialized
INFO - 2024-01-01 16:10:48 --> Language Class Initialized
INFO - 2024-01-01 16:10:48 --> Loader Class Initialized
INFO - 2024-01-01 16:10:48 --> Helper loaded: url_helper
INFO - 2024-01-01 16:10:48 --> Helper loaded: file_helper
INFO - 2024-01-01 16:10:48 --> Helper loaded: html_helper
INFO - 2024-01-01 16:10:48 --> Helper loaded: text_helper
INFO - 2024-01-01 16:10:48 --> Helper loaded: form_helper
INFO - 2024-01-01 16:10:48 --> Helper loaded: lang_helper
INFO - 2024-01-01 16:10:48 --> Helper loaded: security_helper
INFO - 2024-01-01 16:10:48 --> Helper loaded: cookie_helper
INFO - 2024-01-01 16:10:48 --> Database Driver Class Initialized
INFO - 2024-01-01 16:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 16:10:48 --> Parser Class Initialized
INFO - 2024-01-01 16:10:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 16:10:48 --> Pagination Class Initialized
INFO - 2024-01-01 16:10:48 --> Form Validation Class Initialized
INFO - 2024-01-01 16:10:48 --> Controller Class Initialized
INFO - 2024-01-01 16:10:48 --> Model Class Initialized
DEBUG - 2024-01-01 16:10:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 16:10:48 --> Model Class Initialized
DEBUG - 2024-01-01 16:10:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 16:10:48 --> Model Class Initialized
INFO - 2024-01-01 16:10:48 --> Model Class Initialized
INFO - 2024-01-01 16:10:48 --> Model Class Initialized
INFO - 2024-01-01 16:10:48 --> Model Class Initialized
DEBUG - 2024-01-01 16:10:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 16:10:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 16:10:48 --> Model Class Initialized
INFO - 2024-01-01 16:10:48 --> Model Class Initialized
INFO - 2024-01-01 16:10:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-01 16:10:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 16:10:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 16:10:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 16:10:49 --> Model Class Initialized
INFO - 2024-01-01 16:10:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-01 16:10:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-01 16:10:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 16:10:49 --> Final output sent to browser
DEBUG - 2024-01-01 16:10:49 --> Total execution time: 0.4254
ERROR - 2024-01-01 17:58:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 17:58:16 --> Config Class Initialized
INFO - 2024-01-01 17:58:16 --> Hooks Class Initialized
DEBUG - 2024-01-01 17:58:16 --> UTF-8 Support Enabled
INFO - 2024-01-01 17:58:16 --> Utf8 Class Initialized
INFO - 2024-01-01 17:58:16 --> URI Class Initialized
DEBUG - 2024-01-01 17:58:16 --> No URI present. Default controller set.
INFO - 2024-01-01 17:58:16 --> Router Class Initialized
INFO - 2024-01-01 17:58:16 --> Output Class Initialized
INFO - 2024-01-01 17:58:16 --> Security Class Initialized
DEBUG - 2024-01-01 17:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 17:58:16 --> Input Class Initialized
INFO - 2024-01-01 17:58:16 --> Language Class Initialized
INFO - 2024-01-01 17:58:16 --> Loader Class Initialized
INFO - 2024-01-01 17:58:16 --> Helper loaded: url_helper
INFO - 2024-01-01 17:58:16 --> Helper loaded: file_helper
INFO - 2024-01-01 17:58:16 --> Helper loaded: html_helper
INFO - 2024-01-01 17:58:16 --> Helper loaded: text_helper
INFO - 2024-01-01 17:58:16 --> Helper loaded: form_helper
INFO - 2024-01-01 17:58:16 --> Helper loaded: lang_helper
INFO - 2024-01-01 17:58:16 --> Helper loaded: security_helper
INFO - 2024-01-01 17:58:16 --> Helper loaded: cookie_helper
INFO - 2024-01-01 17:58:16 --> Database Driver Class Initialized
INFO - 2024-01-01 17:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 17:58:16 --> Parser Class Initialized
INFO - 2024-01-01 17:58:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 17:58:16 --> Pagination Class Initialized
INFO - 2024-01-01 17:58:16 --> Form Validation Class Initialized
INFO - 2024-01-01 17:58:16 --> Controller Class Initialized
INFO - 2024-01-01 17:58:16 --> Model Class Initialized
DEBUG - 2024-01-01 17:58:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-01 17:58:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 17:58:16 --> Config Class Initialized
INFO - 2024-01-01 17:58:16 --> Hooks Class Initialized
DEBUG - 2024-01-01 17:58:16 --> UTF-8 Support Enabled
INFO - 2024-01-01 17:58:16 --> Utf8 Class Initialized
INFO - 2024-01-01 17:58:16 --> URI Class Initialized
INFO - 2024-01-01 17:58:16 --> Router Class Initialized
INFO - 2024-01-01 17:58:16 --> Output Class Initialized
INFO - 2024-01-01 17:58:16 --> Security Class Initialized
DEBUG - 2024-01-01 17:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 17:58:16 --> Input Class Initialized
INFO - 2024-01-01 17:58:16 --> Language Class Initialized
INFO - 2024-01-01 17:58:16 --> Loader Class Initialized
INFO - 2024-01-01 17:58:16 --> Helper loaded: url_helper
INFO - 2024-01-01 17:58:16 --> Helper loaded: file_helper
INFO - 2024-01-01 17:58:16 --> Helper loaded: html_helper
INFO - 2024-01-01 17:58:16 --> Helper loaded: text_helper
INFO - 2024-01-01 17:58:16 --> Helper loaded: form_helper
INFO - 2024-01-01 17:58:16 --> Helper loaded: lang_helper
INFO - 2024-01-01 17:58:16 --> Helper loaded: security_helper
INFO - 2024-01-01 17:58:16 --> Helper loaded: cookie_helper
INFO - 2024-01-01 17:58:16 --> Database Driver Class Initialized
INFO - 2024-01-01 17:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 17:58:16 --> Parser Class Initialized
INFO - 2024-01-01 17:58:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 17:58:16 --> Pagination Class Initialized
INFO - 2024-01-01 17:58:16 --> Form Validation Class Initialized
INFO - 2024-01-01 17:58:16 --> Controller Class Initialized
INFO - 2024-01-01 17:58:16 --> Model Class Initialized
DEBUG - 2024-01-01 17:58:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 17:58:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-01 17:58:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 17:58:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 17:58:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 17:58:16 --> Model Class Initialized
INFO - 2024-01-01 17:58:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 17:58:16 --> Final output sent to browser
DEBUG - 2024-01-01 17:58:16 --> Total execution time: 0.0313
ERROR - 2024-01-01 17:58:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 17:58:36 --> Config Class Initialized
INFO - 2024-01-01 17:58:36 --> Hooks Class Initialized
DEBUG - 2024-01-01 17:58:36 --> UTF-8 Support Enabled
INFO - 2024-01-01 17:58:36 --> Utf8 Class Initialized
INFO - 2024-01-01 17:58:36 --> URI Class Initialized
INFO - 2024-01-01 17:58:36 --> Router Class Initialized
INFO - 2024-01-01 17:58:36 --> Output Class Initialized
INFO - 2024-01-01 17:58:36 --> Security Class Initialized
DEBUG - 2024-01-01 17:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 17:58:36 --> Input Class Initialized
INFO - 2024-01-01 17:58:36 --> Language Class Initialized
INFO - 2024-01-01 17:58:36 --> Loader Class Initialized
INFO - 2024-01-01 17:58:36 --> Helper loaded: url_helper
INFO - 2024-01-01 17:58:36 --> Helper loaded: file_helper
INFO - 2024-01-01 17:58:36 --> Helper loaded: html_helper
INFO - 2024-01-01 17:58:36 --> Helper loaded: text_helper
INFO - 2024-01-01 17:58:36 --> Helper loaded: form_helper
INFO - 2024-01-01 17:58:36 --> Helper loaded: lang_helper
INFO - 2024-01-01 17:58:36 --> Helper loaded: security_helper
INFO - 2024-01-01 17:58:36 --> Helper loaded: cookie_helper
INFO - 2024-01-01 17:58:36 --> Database Driver Class Initialized
INFO - 2024-01-01 17:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 17:58:36 --> Parser Class Initialized
INFO - 2024-01-01 17:58:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 17:58:36 --> Pagination Class Initialized
INFO - 2024-01-01 17:58:36 --> Form Validation Class Initialized
INFO - 2024-01-01 17:58:36 --> Controller Class Initialized
INFO - 2024-01-01 17:58:36 --> Model Class Initialized
DEBUG - 2024-01-01 17:58:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 17:58:36 --> Model Class Initialized
INFO - 2024-01-01 17:58:36 --> Final output sent to browser
DEBUG - 2024-01-01 17:58:36 --> Total execution time: 0.0206
ERROR - 2024-01-01 17:58:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 17:58:37 --> Config Class Initialized
INFO - 2024-01-01 17:58:37 --> Hooks Class Initialized
DEBUG - 2024-01-01 17:58:37 --> UTF-8 Support Enabled
INFO - 2024-01-01 17:58:37 --> Utf8 Class Initialized
INFO - 2024-01-01 17:58:37 --> URI Class Initialized
DEBUG - 2024-01-01 17:58:37 --> No URI present. Default controller set.
INFO - 2024-01-01 17:58:37 --> Router Class Initialized
INFO - 2024-01-01 17:58:37 --> Output Class Initialized
INFO - 2024-01-01 17:58:37 --> Security Class Initialized
DEBUG - 2024-01-01 17:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 17:58:37 --> Input Class Initialized
INFO - 2024-01-01 17:58:37 --> Language Class Initialized
INFO - 2024-01-01 17:58:37 --> Loader Class Initialized
INFO - 2024-01-01 17:58:37 --> Helper loaded: url_helper
INFO - 2024-01-01 17:58:37 --> Helper loaded: file_helper
INFO - 2024-01-01 17:58:37 --> Helper loaded: html_helper
INFO - 2024-01-01 17:58:37 --> Helper loaded: text_helper
INFO - 2024-01-01 17:58:37 --> Helper loaded: form_helper
INFO - 2024-01-01 17:58:37 --> Helper loaded: lang_helper
INFO - 2024-01-01 17:58:37 --> Helper loaded: security_helper
INFO - 2024-01-01 17:58:37 --> Helper loaded: cookie_helper
INFO - 2024-01-01 17:58:37 --> Database Driver Class Initialized
INFO - 2024-01-01 17:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 17:58:37 --> Parser Class Initialized
INFO - 2024-01-01 17:58:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 17:58:37 --> Pagination Class Initialized
INFO - 2024-01-01 17:58:37 --> Form Validation Class Initialized
INFO - 2024-01-01 17:58:37 --> Controller Class Initialized
INFO - 2024-01-01 17:58:37 --> Model Class Initialized
DEBUG - 2024-01-01 17:58:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-01 17:58:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 17:58:37 --> Config Class Initialized
INFO - 2024-01-01 17:58:37 --> Hooks Class Initialized
DEBUG - 2024-01-01 17:58:37 --> UTF-8 Support Enabled
INFO - 2024-01-01 17:58:37 --> Utf8 Class Initialized
INFO - 2024-01-01 17:58:37 --> URI Class Initialized
INFO - 2024-01-01 17:58:37 --> Router Class Initialized
INFO - 2024-01-01 17:58:37 --> Output Class Initialized
INFO - 2024-01-01 17:58:37 --> Security Class Initialized
DEBUG - 2024-01-01 17:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 17:58:37 --> Input Class Initialized
INFO - 2024-01-01 17:58:37 --> Language Class Initialized
INFO - 2024-01-01 17:58:37 --> Loader Class Initialized
INFO - 2024-01-01 17:58:37 --> Helper loaded: url_helper
INFO - 2024-01-01 17:58:37 --> Helper loaded: file_helper
INFO - 2024-01-01 17:58:37 --> Helper loaded: html_helper
INFO - 2024-01-01 17:58:37 --> Helper loaded: text_helper
INFO - 2024-01-01 17:58:37 --> Helper loaded: form_helper
INFO - 2024-01-01 17:58:37 --> Helper loaded: lang_helper
INFO - 2024-01-01 17:58:37 --> Helper loaded: security_helper
INFO - 2024-01-01 17:58:37 --> Helper loaded: cookie_helper
INFO - 2024-01-01 17:58:37 --> Database Driver Class Initialized
INFO - 2024-01-01 17:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 17:58:37 --> Parser Class Initialized
INFO - 2024-01-01 17:58:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 17:58:37 --> Pagination Class Initialized
INFO - 2024-01-01 17:58:37 --> Form Validation Class Initialized
INFO - 2024-01-01 17:58:37 --> Controller Class Initialized
INFO - 2024-01-01 17:58:37 --> Model Class Initialized
DEBUG - 2024-01-01 17:58:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 17:58:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-01 17:58:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 17:58:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 17:58:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 17:58:37 --> Model Class Initialized
INFO - 2024-01-01 17:58:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 17:58:37 --> Final output sent to browser
DEBUG - 2024-01-01 17:58:37 --> Total execution time: 0.0320
ERROR - 2024-01-01 17:58:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 17:58:48 --> Config Class Initialized
INFO - 2024-01-01 17:58:48 --> Hooks Class Initialized
DEBUG - 2024-01-01 17:58:48 --> UTF-8 Support Enabled
INFO - 2024-01-01 17:58:48 --> Utf8 Class Initialized
INFO - 2024-01-01 17:58:48 --> URI Class Initialized
INFO - 2024-01-01 17:58:48 --> Router Class Initialized
INFO - 2024-01-01 17:58:48 --> Output Class Initialized
INFO - 2024-01-01 17:58:48 --> Security Class Initialized
DEBUG - 2024-01-01 17:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 17:58:48 --> Input Class Initialized
INFO - 2024-01-01 17:58:48 --> Language Class Initialized
INFO - 2024-01-01 17:58:48 --> Loader Class Initialized
INFO - 2024-01-01 17:58:48 --> Helper loaded: url_helper
INFO - 2024-01-01 17:58:48 --> Helper loaded: file_helper
INFO - 2024-01-01 17:58:48 --> Helper loaded: html_helper
INFO - 2024-01-01 17:58:48 --> Helper loaded: text_helper
INFO - 2024-01-01 17:58:48 --> Helper loaded: form_helper
INFO - 2024-01-01 17:58:48 --> Helper loaded: lang_helper
INFO - 2024-01-01 17:58:48 --> Helper loaded: security_helper
INFO - 2024-01-01 17:58:48 --> Helper loaded: cookie_helper
INFO - 2024-01-01 17:58:48 --> Database Driver Class Initialized
INFO - 2024-01-01 17:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 17:58:48 --> Parser Class Initialized
INFO - 2024-01-01 17:58:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 17:58:48 --> Pagination Class Initialized
INFO - 2024-01-01 17:58:48 --> Form Validation Class Initialized
INFO - 2024-01-01 17:58:48 --> Controller Class Initialized
INFO - 2024-01-01 17:58:48 --> Model Class Initialized
DEBUG - 2024-01-01 17:58:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 17:58:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-01 17:58:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 17:58:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 17:58:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 17:58:48 --> Model Class Initialized
INFO - 2024-01-01 17:58:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 17:58:48 --> Final output sent to browser
DEBUG - 2024-01-01 17:58:48 --> Total execution time: 0.0293
ERROR - 2024-01-01 17:58:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 17:58:52 --> Config Class Initialized
INFO - 2024-01-01 17:58:52 --> Hooks Class Initialized
DEBUG - 2024-01-01 17:58:52 --> UTF-8 Support Enabled
INFO - 2024-01-01 17:58:52 --> Utf8 Class Initialized
INFO - 2024-01-01 17:58:52 --> URI Class Initialized
INFO - 2024-01-01 17:58:52 --> Router Class Initialized
INFO - 2024-01-01 17:58:52 --> Output Class Initialized
INFO - 2024-01-01 17:58:52 --> Security Class Initialized
DEBUG - 2024-01-01 17:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 17:58:52 --> Input Class Initialized
INFO - 2024-01-01 17:58:52 --> Language Class Initialized
INFO - 2024-01-01 17:58:52 --> Loader Class Initialized
INFO - 2024-01-01 17:58:52 --> Helper loaded: url_helper
INFO - 2024-01-01 17:58:52 --> Helper loaded: file_helper
INFO - 2024-01-01 17:58:52 --> Helper loaded: html_helper
INFO - 2024-01-01 17:58:52 --> Helper loaded: text_helper
INFO - 2024-01-01 17:58:52 --> Helper loaded: form_helper
INFO - 2024-01-01 17:58:52 --> Helper loaded: lang_helper
INFO - 2024-01-01 17:58:52 --> Helper loaded: security_helper
INFO - 2024-01-01 17:58:52 --> Helper loaded: cookie_helper
INFO - 2024-01-01 17:58:52 --> Database Driver Class Initialized
INFO - 2024-01-01 17:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 17:58:52 --> Parser Class Initialized
INFO - 2024-01-01 17:58:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 17:58:52 --> Pagination Class Initialized
INFO - 2024-01-01 17:58:52 --> Form Validation Class Initialized
INFO - 2024-01-01 17:58:52 --> Controller Class Initialized
INFO - 2024-01-01 17:58:52 --> Model Class Initialized
DEBUG - 2024-01-01 17:58:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 17:58:52 --> Model Class Initialized
INFO - 2024-01-01 17:58:52 --> Final output sent to browser
DEBUG - 2024-01-01 17:58:52 --> Total execution time: 0.0150
ERROR - 2024-01-01 17:58:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 17:58:52 --> Config Class Initialized
INFO - 2024-01-01 17:58:52 --> Hooks Class Initialized
DEBUG - 2024-01-01 17:58:52 --> UTF-8 Support Enabled
INFO - 2024-01-01 17:58:52 --> Utf8 Class Initialized
INFO - 2024-01-01 17:58:52 --> URI Class Initialized
DEBUG - 2024-01-01 17:58:52 --> No URI present. Default controller set.
INFO - 2024-01-01 17:58:52 --> Router Class Initialized
INFO - 2024-01-01 17:58:52 --> Output Class Initialized
INFO - 2024-01-01 17:58:52 --> Security Class Initialized
DEBUG - 2024-01-01 17:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 17:58:52 --> Input Class Initialized
INFO - 2024-01-01 17:58:52 --> Language Class Initialized
INFO - 2024-01-01 17:58:52 --> Loader Class Initialized
INFO - 2024-01-01 17:58:52 --> Helper loaded: url_helper
INFO - 2024-01-01 17:58:52 --> Helper loaded: file_helper
INFO - 2024-01-01 17:58:52 --> Helper loaded: html_helper
INFO - 2024-01-01 17:58:52 --> Helper loaded: text_helper
INFO - 2024-01-01 17:58:52 --> Helper loaded: form_helper
INFO - 2024-01-01 17:58:52 --> Helper loaded: lang_helper
INFO - 2024-01-01 17:58:52 --> Helper loaded: security_helper
INFO - 2024-01-01 17:58:52 --> Helper loaded: cookie_helper
INFO - 2024-01-01 17:58:52 --> Database Driver Class Initialized
INFO - 2024-01-01 17:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 17:58:52 --> Parser Class Initialized
INFO - 2024-01-01 17:58:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 17:58:52 --> Pagination Class Initialized
INFO - 2024-01-01 17:58:52 --> Form Validation Class Initialized
INFO - 2024-01-01 17:58:52 --> Controller Class Initialized
INFO - 2024-01-01 17:58:52 --> Model Class Initialized
DEBUG - 2024-01-01 17:58:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-01 17:58:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 17:58:53 --> Config Class Initialized
INFO - 2024-01-01 17:58:53 --> Hooks Class Initialized
DEBUG - 2024-01-01 17:58:53 --> UTF-8 Support Enabled
INFO - 2024-01-01 17:58:53 --> Utf8 Class Initialized
INFO - 2024-01-01 17:58:53 --> URI Class Initialized
INFO - 2024-01-01 17:58:53 --> Router Class Initialized
INFO - 2024-01-01 17:58:53 --> Output Class Initialized
INFO - 2024-01-01 17:58:53 --> Security Class Initialized
DEBUG - 2024-01-01 17:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 17:58:53 --> Input Class Initialized
INFO - 2024-01-01 17:58:53 --> Language Class Initialized
INFO - 2024-01-01 17:58:53 --> Loader Class Initialized
INFO - 2024-01-01 17:58:53 --> Helper loaded: url_helper
INFO - 2024-01-01 17:58:53 --> Helper loaded: file_helper
INFO - 2024-01-01 17:58:53 --> Helper loaded: html_helper
INFO - 2024-01-01 17:58:53 --> Helper loaded: text_helper
INFO - 2024-01-01 17:58:53 --> Helper loaded: form_helper
INFO - 2024-01-01 17:58:53 --> Helper loaded: lang_helper
INFO - 2024-01-01 17:58:53 --> Helper loaded: security_helper
INFO - 2024-01-01 17:58:53 --> Helper loaded: cookie_helper
INFO - 2024-01-01 17:58:53 --> Database Driver Class Initialized
INFO - 2024-01-01 17:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 17:58:53 --> Parser Class Initialized
INFO - 2024-01-01 17:58:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 17:58:53 --> Pagination Class Initialized
INFO - 2024-01-01 17:58:53 --> Form Validation Class Initialized
INFO - 2024-01-01 17:58:53 --> Controller Class Initialized
INFO - 2024-01-01 17:58:53 --> Model Class Initialized
DEBUG - 2024-01-01 17:58:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 17:58:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-01 17:58:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 17:58:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 17:58:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 17:58:53 --> Model Class Initialized
INFO - 2024-01-01 17:58:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 17:58:53 --> Final output sent to browser
DEBUG - 2024-01-01 17:58:53 --> Total execution time: 0.0310
ERROR - 2024-01-01 18:00:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 18:00:31 --> Config Class Initialized
INFO - 2024-01-01 18:00:31 --> Hooks Class Initialized
DEBUG - 2024-01-01 18:00:31 --> UTF-8 Support Enabled
INFO - 2024-01-01 18:00:31 --> Utf8 Class Initialized
INFO - 2024-01-01 18:00:31 --> URI Class Initialized
DEBUG - 2024-01-01 18:00:31 --> No URI present. Default controller set.
INFO - 2024-01-01 18:00:31 --> Router Class Initialized
INFO - 2024-01-01 18:00:31 --> Output Class Initialized
INFO - 2024-01-01 18:00:31 --> Security Class Initialized
DEBUG - 2024-01-01 18:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 18:00:31 --> Input Class Initialized
INFO - 2024-01-01 18:00:31 --> Language Class Initialized
INFO - 2024-01-01 18:00:31 --> Loader Class Initialized
INFO - 2024-01-01 18:00:31 --> Helper loaded: url_helper
INFO - 2024-01-01 18:00:31 --> Helper loaded: file_helper
INFO - 2024-01-01 18:00:31 --> Helper loaded: html_helper
INFO - 2024-01-01 18:00:31 --> Helper loaded: text_helper
INFO - 2024-01-01 18:00:31 --> Helper loaded: form_helper
INFO - 2024-01-01 18:00:31 --> Helper loaded: lang_helper
INFO - 2024-01-01 18:00:31 --> Helper loaded: security_helper
INFO - 2024-01-01 18:00:31 --> Helper loaded: cookie_helper
INFO - 2024-01-01 18:00:31 --> Database Driver Class Initialized
INFO - 2024-01-01 18:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 18:00:31 --> Parser Class Initialized
INFO - 2024-01-01 18:00:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 18:00:31 --> Pagination Class Initialized
INFO - 2024-01-01 18:00:31 --> Form Validation Class Initialized
INFO - 2024-01-01 18:00:31 --> Controller Class Initialized
INFO - 2024-01-01 18:00:31 --> Model Class Initialized
DEBUG - 2024-01-01 18:00:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-01 18:00:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 18:00:31 --> Config Class Initialized
INFO - 2024-01-01 18:00:31 --> Hooks Class Initialized
DEBUG - 2024-01-01 18:00:31 --> UTF-8 Support Enabled
INFO - 2024-01-01 18:00:31 --> Utf8 Class Initialized
INFO - 2024-01-01 18:00:31 --> URI Class Initialized
INFO - 2024-01-01 18:00:31 --> Router Class Initialized
INFO - 2024-01-01 18:00:31 --> Output Class Initialized
INFO - 2024-01-01 18:00:31 --> Security Class Initialized
DEBUG - 2024-01-01 18:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 18:00:31 --> Input Class Initialized
INFO - 2024-01-01 18:00:31 --> Language Class Initialized
INFO - 2024-01-01 18:00:31 --> Loader Class Initialized
INFO - 2024-01-01 18:00:31 --> Helper loaded: url_helper
INFO - 2024-01-01 18:00:31 --> Helper loaded: file_helper
INFO - 2024-01-01 18:00:31 --> Helper loaded: html_helper
INFO - 2024-01-01 18:00:31 --> Helper loaded: text_helper
INFO - 2024-01-01 18:00:31 --> Helper loaded: form_helper
INFO - 2024-01-01 18:00:31 --> Helper loaded: lang_helper
INFO - 2024-01-01 18:00:31 --> Helper loaded: security_helper
INFO - 2024-01-01 18:00:31 --> Helper loaded: cookie_helper
INFO - 2024-01-01 18:00:31 --> Database Driver Class Initialized
INFO - 2024-01-01 18:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 18:00:31 --> Parser Class Initialized
INFO - 2024-01-01 18:00:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 18:00:31 --> Pagination Class Initialized
INFO - 2024-01-01 18:00:31 --> Form Validation Class Initialized
INFO - 2024-01-01 18:00:31 --> Controller Class Initialized
INFO - 2024-01-01 18:00:31 --> Model Class Initialized
DEBUG - 2024-01-01 18:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 18:00:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-01 18:00:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 18:00:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 18:00:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 18:00:31 --> Model Class Initialized
INFO - 2024-01-01 18:00:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 18:00:31 --> Final output sent to browser
DEBUG - 2024-01-01 18:00:31 --> Total execution time: 0.0303
ERROR - 2024-01-01 18:00:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 18:00:39 --> Config Class Initialized
INFO - 2024-01-01 18:00:39 --> Hooks Class Initialized
DEBUG - 2024-01-01 18:00:39 --> UTF-8 Support Enabled
INFO - 2024-01-01 18:00:39 --> Utf8 Class Initialized
INFO - 2024-01-01 18:00:39 --> URI Class Initialized
INFO - 2024-01-01 18:00:39 --> Router Class Initialized
INFO - 2024-01-01 18:00:39 --> Output Class Initialized
INFO - 2024-01-01 18:00:39 --> Security Class Initialized
DEBUG - 2024-01-01 18:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 18:00:39 --> Input Class Initialized
INFO - 2024-01-01 18:00:39 --> Language Class Initialized
INFO - 2024-01-01 18:00:39 --> Loader Class Initialized
INFO - 2024-01-01 18:00:39 --> Helper loaded: url_helper
INFO - 2024-01-01 18:00:39 --> Helper loaded: file_helper
INFO - 2024-01-01 18:00:39 --> Helper loaded: html_helper
INFO - 2024-01-01 18:00:39 --> Helper loaded: text_helper
INFO - 2024-01-01 18:00:39 --> Helper loaded: form_helper
INFO - 2024-01-01 18:00:39 --> Helper loaded: lang_helper
INFO - 2024-01-01 18:00:39 --> Helper loaded: security_helper
INFO - 2024-01-01 18:00:39 --> Helper loaded: cookie_helper
INFO - 2024-01-01 18:00:39 --> Database Driver Class Initialized
INFO - 2024-01-01 18:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 18:00:39 --> Parser Class Initialized
INFO - 2024-01-01 18:00:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 18:00:39 --> Pagination Class Initialized
INFO - 2024-01-01 18:00:39 --> Form Validation Class Initialized
INFO - 2024-01-01 18:00:39 --> Controller Class Initialized
INFO - 2024-01-01 18:00:39 --> Model Class Initialized
DEBUG - 2024-01-01 18:00:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 18:00:39 --> Model Class Initialized
INFO - 2024-01-01 18:00:39 --> Final output sent to browser
DEBUG - 2024-01-01 18:00:39 --> Total execution time: 0.0273
ERROR - 2024-01-01 18:00:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 18:00:40 --> Config Class Initialized
INFO - 2024-01-01 18:00:40 --> Hooks Class Initialized
DEBUG - 2024-01-01 18:00:40 --> UTF-8 Support Enabled
INFO - 2024-01-01 18:00:40 --> Utf8 Class Initialized
INFO - 2024-01-01 18:00:40 --> URI Class Initialized
DEBUG - 2024-01-01 18:00:40 --> No URI present. Default controller set.
INFO - 2024-01-01 18:00:40 --> Router Class Initialized
INFO - 2024-01-01 18:00:40 --> Output Class Initialized
INFO - 2024-01-01 18:00:40 --> Security Class Initialized
DEBUG - 2024-01-01 18:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 18:00:40 --> Input Class Initialized
INFO - 2024-01-01 18:00:40 --> Language Class Initialized
INFO - 2024-01-01 18:00:40 --> Loader Class Initialized
INFO - 2024-01-01 18:00:40 --> Helper loaded: url_helper
INFO - 2024-01-01 18:00:40 --> Helper loaded: file_helper
INFO - 2024-01-01 18:00:40 --> Helper loaded: html_helper
INFO - 2024-01-01 18:00:40 --> Helper loaded: text_helper
INFO - 2024-01-01 18:00:40 --> Helper loaded: form_helper
INFO - 2024-01-01 18:00:40 --> Helper loaded: lang_helper
INFO - 2024-01-01 18:00:40 --> Helper loaded: security_helper
INFO - 2024-01-01 18:00:40 --> Helper loaded: cookie_helper
INFO - 2024-01-01 18:00:40 --> Database Driver Class Initialized
INFO - 2024-01-01 18:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 18:00:40 --> Parser Class Initialized
INFO - 2024-01-01 18:00:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 18:00:40 --> Pagination Class Initialized
INFO - 2024-01-01 18:00:40 --> Form Validation Class Initialized
INFO - 2024-01-01 18:00:40 --> Controller Class Initialized
INFO - 2024-01-01 18:00:40 --> Model Class Initialized
DEBUG - 2024-01-01 18:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 18:00:40 --> Model Class Initialized
DEBUG - 2024-01-01 18:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 18:00:40 --> Model Class Initialized
INFO - 2024-01-01 18:00:40 --> Model Class Initialized
INFO - 2024-01-01 18:00:40 --> Model Class Initialized
INFO - 2024-01-01 18:00:40 --> Model Class Initialized
DEBUG - 2024-01-01 18:00:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 18:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 18:00:40 --> Model Class Initialized
INFO - 2024-01-01 18:00:40 --> Model Class Initialized
INFO - 2024-01-01 18:00:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-01 18:00:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 18:00:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 18:00:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 18:00:40 --> Model Class Initialized
INFO - 2024-01-01 18:00:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-01 18:00:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-01 18:00:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 18:00:41 --> Final output sent to browser
DEBUG - 2024-01-01 18:00:41 --> Total execution time: 0.4113
ERROR - 2024-01-01 18:00:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 18:00:42 --> Config Class Initialized
INFO - 2024-01-01 18:00:42 --> Hooks Class Initialized
DEBUG - 2024-01-01 18:00:42 --> UTF-8 Support Enabled
INFO - 2024-01-01 18:00:42 --> Utf8 Class Initialized
INFO - 2024-01-01 18:00:42 --> URI Class Initialized
INFO - 2024-01-01 18:00:42 --> Router Class Initialized
INFO - 2024-01-01 18:00:42 --> Output Class Initialized
INFO - 2024-01-01 18:00:42 --> Security Class Initialized
DEBUG - 2024-01-01 18:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 18:00:42 --> Input Class Initialized
INFO - 2024-01-01 18:00:42 --> Language Class Initialized
INFO - 2024-01-01 18:00:42 --> Loader Class Initialized
INFO - 2024-01-01 18:00:42 --> Helper loaded: url_helper
INFO - 2024-01-01 18:00:42 --> Helper loaded: file_helper
INFO - 2024-01-01 18:00:42 --> Helper loaded: html_helper
INFO - 2024-01-01 18:00:42 --> Helper loaded: text_helper
INFO - 2024-01-01 18:00:42 --> Helper loaded: form_helper
INFO - 2024-01-01 18:00:42 --> Helper loaded: lang_helper
INFO - 2024-01-01 18:00:42 --> Helper loaded: security_helper
INFO - 2024-01-01 18:00:42 --> Helper loaded: cookie_helper
INFO - 2024-01-01 18:00:42 --> Database Driver Class Initialized
INFO - 2024-01-01 18:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 18:00:42 --> Parser Class Initialized
INFO - 2024-01-01 18:00:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 18:00:42 --> Pagination Class Initialized
INFO - 2024-01-01 18:00:42 --> Form Validation Class Initialized
INFO - 2024-01-01 18:00:42 --> Controller Class Initialized
DEBUG - 2024-01-01 18:00:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-01 18:00:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 18:00:42 --> Model Class Initialized
INFO - 2024-01-01 18:00:42 --> Final output sent to browser
DEBUG - 2024-01-01 18:00:42 --> Total execution time: 0.0131
ERROR - 2024-01-01 18:01:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 18:01:06 --> Config Class Initialized
INFO - 2024-01-01 18:01:06 --> Hooks Class Initialized
DEBUG - 2024-01-01 18:01:06 --> UTF-8 Support Enabled
INFO - 2024-01-01 18:01:06 --> Utf8 Class Initialized
INFO - 2024-01-01 18:01:06 --> URI Class Initialized
INFO - 2024-01-01 18:01:06 --> Router Class Initialized
INFO - 2024-01-01 18:01:06 --> Output Class Initialized
INFO - 2024-01-01 18:01:06 --> Security Class Initialized
DEBUG - 2024-01-01 18:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 18:01:06 --> Input Class Initialized
INFO - 2024-01-01 18:01:06 --> Language Class Initialized
INFO - 2024-01-01 18:01:06 --> Loader Class Initialized
INFO - 2024-01-01 18:01:06 --> Helper loaded: url_helper
INFO - 2024-01-01 18:01:06 --> Helper loaded: file_helper
INFO - 2024-01-01 18:01:06 --> Helper loaded: html_helper
INFO - 2024-01-01 18:01:06 --> Helper loaded: text_helper
INFO - 2024-01-01 18:01:06 --> Helper loaded: form_helper
INFO - 2024-01-01 18:01:06 --> Helper loaded: lang_helper
INFO - 2024-01-01 18:01:06 --> Helper loaded: security_helper
INFO - 2024-01-01 18:01:06 --> Helper loaded: cookie_helper
INFO - 2024-01-01 18:01:06 --> Database Driver Class Initialized
INFO - 2024-01-01 18:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 18:01:06 --> Parser Class Initialized
INFO - 2024-01-01 18:01:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 18:01:06 --> Pagination Class Initialized
INFO - 2024-01-01 18:01:06 --> Form Validation Class Initialized
INFO - 2024-01-01 18:01:06 --> Controller Class Initialized
INFO - 2024-01-01 18:01:06 --> Model Class Initialized
DEBUG - 2024-01-01 18:01:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 18:01:06 --> Final output sent to browser
DEBUG - 2024-01-01 18:01:06 --> Total execution time: 0.0153
ERROR - 2024-01-01 18:01:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 18:01:07 --> Config Class Initialized
INFO - 2024-01-01 18:01:07 --> Hooks Class Initialized
DEBUG - 2024-01-01 18:01:07 --> UTF-8 Support Enabled
INFO - 2024-01-01 18:01:07 --> Utf8 Class Initialized
INFO - 2024-01-01 18:01:07 --> URI Class Initialized
INFO - 2024-01-01 18:01:07 --> Router Class Initialized
INFO - 2024-01-01 18:01:07 --> Output Class Initialized
INFO - 2024-01-01 18:01:07 --> Security Class Initialized
DEBUG - 2024-01-01 18:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 18:01:07 --> Input Class Initialized
INFO - 2024-01-01 18:01:07 --> Language Class Initialized
INFO - 2024-01-01 18:01:07 --> Loader Class Initialized
INFO - 2024-01-01 18:01:07 --> Helper loaded: url_helper
INFO - 2024-01-01 18:01:07 --> Helper loaded: file_helper
INFO - 2024-01-01 18:01:07 --> Helper loaded: html_helper
INFO - 2024-01-01 18:01:07 --> Helper loaded: text_helper
INFO - 2024-01-01 18:01:07 --> Helper loaded: form_helper
INFO - 2024-01-01 18:01:07 --> Helper loaded: lang_helper
INFO - 2024-01-01 18:01:07 --> Helper loaded: security_helper
INFO - 2024-01-01 18:01:07 --> Helper loaded: cookie_helper
INFO - 2024-01-01 18:01:07 --> Database Driver Class Initialized
INFO - 2024-01-01 18:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 18:01:07 --> Parser Class Initialized
INFO - 2024-01-01 18:01:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 18:01:07 --> Pagination Class Initialized
INFO - 2024-01-01 18:01:07 --> Form Validation Class Initialized
INFO - 2024-01-01 18:01:07 --> Controller Class Initialized
INFO - 2024-01-01 18:01:07 --> Model Class Initialized
DEBUG - 2024-01-01 18:01:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 18:01:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-01 18:01:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 18:01:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 18:01:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 18:01:07 --> Model Class Initialized
INFO - 2024-01-01 18:01:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 18:01:07 --> Final output sent to browser
DEBUG - 2024-01-01 18:01:07 --> Total execution time: 0.0314
ERROR - 2024-01-01 18:01:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 18:01:34 --> Config Class Initialized
INFO - 2024-01-01 18:01:34 --> Hooks Class Initialized
DEBUG - 2024-01-01 18:01:34 --> UTF-8 Support Enabled
INFO - 2024-01-01 18:01:34 --> Utf8 Class Initialized
INFO - 2024-01-01 18:01:34 --> URI Class Initialized
DEBUG - 2024-01-01 18:01:34 --> No URI present. Default controller set.
INFO - 2024-01-01 18:01:34 --> Router Class Initialized
INFO - 2024-01-01 18:01:34 --> Output Class Initialized
INFO - 2024-01-01 18:01:34 --> Security Class Initialized
DEBUG - 2024-01-01 18:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 18:01:34 --> Input Class Initialized
INFO - 2024-01-01 18:01:34 --> Language Class Initialized
INFO - 2024-01-01 18:01:34 --> Loader Class Initialized
INFO - 2024-01-01 18:01:34 --> Helper loaded: url_helper
INFO - 2024-01-01 18:01:34 --> Helper loaded: file_helper
INFO - 2024-01-01 18:01:34 --> Helper loaded: html_helper
INFO - 2024-01-01 18:01:34 --> Helper loaded: text_helper
INFO - 2024-01-01 18:01:34 --> Helper loaded: form_helper
INFO - 2024-01-01 18:01:34 --> Helper loaded: lang_helper
INFO - 2024-01-01 18:01:34 --> Helper loaded: security_helper
INFO - 2024-01-01 18:01:34 --> Helper loaded: cookie_helper
INFO - 2024-01-01 18:01:34 --> Database Driver Class Initialized
INFO - 2024-01-01 18:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 18:01:34 --> Parser Class Initialized
INFO - 2024-01-01 18:01:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 18:01:34 --> Pagination Class Initialized
INFO - 2024-01-01 18:01:34 --> Form Validation Class Initialized
INFO - 2024-01-01 18:01:34 --> Controller Class Initialized
INFO - 2024-01-01 18:01:34 --> Model Class Initialized
DEBUG - 2024-01-01 18:01:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-01 18:01:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-01 18:01:35 --> Config Class Initialized
INFO - 2024-01-01 18:01:35 --> Hooks Class Initialized
DEBUG - 2024-01-01 18:01:35 --> UTF-8 Support Enabled
INFO - 2024-01-01 18:01:35 --> Utf8 Class Initialized
INFO - 2024-01-01 18:01:35 --> URI Class Initialized
INFO - 2024-01-01 18:01:35 --> Router Class Initialized
INFO - 2024-01-01 18:01:35 --> Output Class Initialized
INFO - 2024-01-01 18:01:35 --> Security Class Initialized
DEBUG - 2024-01-01 18:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-01 18:01:35 --> Input Class Initialized
INFO - 2024-01-01 18:01:35 --> Language Class Initialized
INFO - 2024-01-01 18:01:35 --> Loader Class Initialized
INFO - 2024-01-01 18:01:35 --> Helper loaded: url_helper
INFO - 2024-01-01 18:01:35 --> Helper loaded: file_helper
INFO - 2024-01-01 18:01:35 --> Helper loaded: html_helper
INFO - 2024-01-01 18:01:35 --> Helper loaded: text_helper
INFO - 2024-01-01 18:01:35 --> Helper loaded: form_helper
INFO - 2024-01-01 18:01:35 --> Helper loaded: lang_helper
INFO - 2024-01-01 18:01:35 --> Helper loaded: security_helper
INFO - 2024-01-01 18:01:35 --> Helper loaded: cookie_helper
INFO - 2024-01-01 18:01:35 --> Database Driver Class Initialized
INFO - 2024-01-01 18:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-01 18:01:35 --> Parser Class Initialized
INFO - 2024-01-01 18:01:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-01 18:01:35 --> Pagination Class Initialized
INFO - 2024-01-01 18:01:35 --> Form Validation Class Initialized
INFO - 2024-01-01 18:01:35 --> Controller Class Initialized
INFO - 2024-01-01 18:01:35 --> Model Class Initialized
DEBUG - 2024-01-01 18:01:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-01 18:01:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-01 18:01:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-01 18:01:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-01 18:01:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-01 18:01:35 --> Model Class Initialized
INFO - 2024-01-01 18:01:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-01 18:01:35 --> Final output sent to browser
DEBUG - 2024-01-01 18:01:35 --> Total execution time: 0.0325
