<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-08 00:16:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 00:16:52 --> Config Class Initialized
INFO - 2023-10-08 00:16:52 --> Hooks Class Initialized
DEBUG - 2023-10-08 00:16:52 --> UTF-8 Support Enabled
INFO - 2023-10-08 00:16:52 --> Utf8 Class Initialized
INFO - 2023-10-08 00:16:52 --> URI Class Initialized
DEBUG - 2023-10-08 00:16:52 --> No URI present. Default controller set.
INFO - 2023-10-08 00:16:52 --> Router Class Initialized
INFO - 2023-10-08 00:16:52 --> Output Class Initialized
INFO - 2023-10-08 00:16:52 --> Security Class Initialized
DEBUG - 2023-10-08 00:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 00:16:52 --> Input Class Initialized
INFO - 2023-10-08 00:16:52 --> Language Class Initialized
INFO - 2023-10-08 00:16:52 --> Loader Class Initialized
INFO - 2023-10-08 00:16:52 --> Helper loaded: url_helper
INFO - 2023-10-08 00:16:52 --> Helper loaded: file_helper
INFO - 2023-10-08 00:16:52 --> Helper loaded: html_helper
INFO - 2023-10-08 00:16:52 --> Helper loaded: text_helper
INFO - 2023-10-08 00:16:52 --> Helper loaded: form_helper
INFO - 2023-10-08 00:16:52 --> Helper loaded: lang_helper
INFO - 2023-10-08 00:16:52 --> Helper loaded: security_helper
INFO - 2023-10-08 00:16:52 --> Helper loaded: cookie_helper
INFO - 2023-10-08 00:16:52 --> Database Driver Class Initialized
INFO - 2023-10-08 00:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 00:16:52 --> Parser Class Initialized
INFO - 2023-10-08 00:16:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 00:16:52 --> Pagination Class Initialized
INFO - 2023-10-08 00:16:52 --> Form Validation Class Initialized
INFO - 2023-10-08 00:16:52 --> Controller Class Initialized
INFO - 2023-10-08 00:16:52 --> Model Class Initialized
DEBUG - 2023-10-08 00:16:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 00:16:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 00:16:52 --> Config Class Initialized
INFO - 2023-10-08 00:16:52 --> Hooks Class Initialized
DEBUG - 2023-10-08 00:16:52 --> UTF-8 Support Enabled
INFO - 2023-10-08 00:16:52 --> Utf8 Class Initialized
INFO - 2023-10-08 00:16:52 --> URI Class Initialized
INFO - 2023-10-08 00:16:52 --> Router Class Initialized
INFO - 2023-10-08 00:16:52 --> Output Class Initialized
INFO - 2023-10-08 00:16:52 --> Security Class Initialized
DEBUG - 2023-10-08 00:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 00:16:52 --> Input Class Initialized
INFO - 2023-10-08 00:16:52 --> Language Class Initialized
INFO - 2023-10-08 00:16:52 --> Loader Class Initialized
INFO - 2023-10-08 00:16:52 --> Helper loaded: url_helper
INFO - 2023-10-08 00:16:52 --> Helper loaded: file_helper
INFO - 2023-10-08 00:16:52 --> Helper loaded: html_helper
INFO - 2023-10-08 00:16:52 --> Helper loaded: text_helper
INFO - 2023-10-08 00:16:52 --> Helper loaded: form_helper
INFO - 2023-10-08 00:16:52 --> Helper loaded: lang_helper
INFO - 2023-10-08 00:16:52 --> Helper loaded: security_helper
INFO - 2023-10-08 00:16:52 --> Helper loaded: cookie_helper
INFO - 2023-10-08 00:16:52 --> Database Driver Class Initialized
INFO - 2023-10-08 00:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 00:16:52 --> Parser Class Initialized
INFO - 2023-10-08 00:16:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 00:16:52 --> Pagination Class Initialized
INFO - 2023-10-08 00:16:52 --> Form Validation Class Initialized
INFO - 2023-10-08 00:16:52 --> Controller Class Initialized
INFO - 2023-10-08 00:16:52 --> Model Class Initialized
DEBUG - 2023-10-08 00:16:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:16:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-08 00:16:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:16:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 00:16:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 00:16:52 --> Model Class Initialized
INFO - 2023-10-08 00:16:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 00:16:52 --> Final output sent to browser
DEBUG - 2023-10-08 00:16:52 --> Total execution time: 0.0335
ERROR - 2023-10-08 00:17:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 00:17:48 --> Config Class Initialized
INFO - 2023-10-08 00:17:48 --> Hooks Class Initialized
DEBUG - 2023-10-08 00:17:48 --> UTF-8 Support Enabled
INFO - 2023-10-08 00:17:48 --> Utf8 Class Initialized
INFO - 2023-10-08 00:17:48 --> URI Class Initialized
INFO - 2023-10-08 00:17:48 --> Router Class Initialized
INFO - 2023-10-08 00:17:48 --> Output Class Initialized
INFO - 2023-10-08 00:17:48 --> Security Class Initialized
DEBUG - 2023-10-08 00:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 00:17:48 --> Input Class Initialized
INFO - 2023-10-08 00:17:48 --> Language Class Initialized
INFO - 2023-10-08 00:17:48 --> Loader Class Initialized
INFO - 2023-10-08 00:17:48 --> Helper loaded: url_helper
INFO - 2023-10-08 00:17:48 --> Helper loaded: file_helper
INFO - 2023-10-08 00:17:48 --> Helper loaded: html_helper
INFO - 2023-10-08 00:17:48 --> Helper loaded: text_helper
INFO - 2023-10-08 00:17:48 --> Helper loaded: form_helper
INFO - 2023-10-08 00:17:48 --> Helper loaded: lang_helper
INFO - 2023-10-08 00:17:48 --> Helper loaded: security_helper
INFO - 2023-10-08 00:17:48 --> Helper loaded: cookie_helper
INFO - 2023-10-08 00:17:48 --> Database Driver Class Initialized
INFO - 2023-10-08 00:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 00:17:48 --> Parser Class Initialized
INFO - 2023-10-08 00:17:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 00:17:48 --> Pagination Class Initialized
INFO - 2023-10-08 00:17:48 --> Form Validation Class Initialized
INFO - 2023-10-08 00:17:48 --> Controller Class Initialized
INFO - 2023-10-08 00:17:48 --> Model Class Initialized
DEBUG - 2023-10-08 00:17:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:17:48 --> Model Class Initialized
INFO - 2023-10-08 00:17:48 --> Final output sent to browser
DEBUG - 2023-10-08 00:17:48 --> Total execution time: 0.0222
ERROR - 2023-10-08 00:17:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 00:17:49 --> Config Class Initialized
INFO - 2023-10-08 00:17:49 --> Hooks Class Initialized
DEBUG - 2023-10-08 00:17:49 --> UTF-8 Support Enabled
INFO - 2023-10-08 00:17:49 --> Utf8 Class Initialized
INFO - 2023-10-08 00:17:49 --> URI Class Initialized
DEBUG - 2023-10-08 00:17:49 --> No URI present. Default controller set.
INFO - 2023-10-08 00:17:49 --> Router Class Initialized
INFO - 2023-10-08 00:17:49 --> Output Class Initialized
INFO - 2023-10-08 00:17:49 --> Security Class Initialized
DEBUG - 2023-10-08 00:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 00:17:49 --> Input Class Initialized
INFO - 2023-10-08 00:17:49 --> Language Class Initialized
INFO - 2023-10-08 00:17:49 --> Loader Class Initialized
INFO - 2023-10-08 00:17:49 --> Helper loaded: url_helper
INFO - 2023-10-08 00:17:49 --> Helper loaded: file_helper
INFO - 2023-10-08 00:17:49 --> Helper loaded: html_helper
INFO - 2023-10-08 00:17:49 --> Helper loaded: text_helper
INFO - 2023-10-08 00:17:49 --> Helper loaded: form_helper
INFO - 2023-10-08 00:17:49 --> Helper loaded: lang_helper
INFO - 2023-10-08 00:17:49 --> Helper loaded: security_helper
INFO - 2023-10-08 00:17:49 --> Helper loaded: cookie_helper
INFO - 2023-10-08 00:17:49 --> Database Driver Class Initialized
INFO - 2023-10-08 00:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 00:17:49 --> Parser Class Initialized
INFO - 2023-10-08 00:17:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 00:17:49 --> Pagination Class Initialized
INFO - 2023-10-08 00:17:49 --> Form Validation Class Initialized
INFO - 2023-10-08 00:17:49 --> Controller Class Initialized
INFO - 2023-10-08 00:17:49 --> Model Class Initialized
DEBUG - 2023-10-08 00:17:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:17:49 --> Model Class Initialized
DEBUG - 2023-10-08 00:17:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:17:49 --> Model Class Initialized
INFO - 2023-10-08 00:17:49 --> Model Class Initialized
INFO - 2023-10-08 00:17:49 --> Model Class Initialized
INFO - 2023-10-08 00:17:49 --> Model Class Initialized
DEBUG - 2023-10-08 00:17:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 00:17:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:17:49 --> Model Class Initialized
INFO - 2023-10-08 00:17:49 --> Model Class Initialized
INFO - 2023-10-08 00:17:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-08 00:17:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:17:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 00:17:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 00:17:49 --> Model Class Initialized
INFO - 2023-10-08 00:17:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 00:17:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 00:17:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 00:17:49 --> Final output sent to browser
DEBUG - 2023-10-08 00:17:49 --> Total execution time: 0.1238
ERROR - 2023-10-08 00:18:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 00:18:00 --> Config Class Initialized
INFO - 2023-10-08 00:18:00 --> Hooks Class Initialized
DEBUG - 2023-10-08 00:18:00 --> UTF-8 Support Enabled
INFO - 2023-10-08 00:18:00 --> Utf8 Class Initialized
INFO - 2023-10-08 00:18:00 --> URI Class Initialized
INFO - 2023-10-08 00:18:00 --> Router Class Initialized
INFO - 2023-10-08 00:18:00 --> Output Class Initialized
INFO - 2023-10-08 00:18:00 --> Security Class Initialized
DEBUG - 2023-10-08 00:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 00:18:00 --> Input Class Initialized
INFO - 2023-10-08 00:18:00 --> Language Class Initialized
INFO - 2023-10-08 00:18:00 --> Loader Class Initialized
INFO - 2023-10-08 00:18:00 --> Helper loaded: url_helper
INFO - 2023-10-08 00:18:00 --> Helper loaded: file_helper
INFO - 2023-10-08 00:18:00 --> Helper loaded: html_helper
INFO - 2023-10-08 00:18:00 --> Helper loaded: text_helper
INFO - 2023-10-08 00:18:00 --> Helper loaded: form_helper
INFO - 2023-10-08 00:18:00 --> Helper loaded: lang_helper
INFO - 2023-10-08 00:18:00 --> Helper loaded: security_helper
INFO - 2023-10-08 00:18:00 --> Helper loaded: cookie_helper
INFO - 2023-10-08 00:18:00 --> Database Driver Class Initialized
INFO - 2023-10-08 00:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 00:18:00 --> Parser Class Initialized
INFO - 2023-10-08 00:18:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 00:18:00 --> Pagination Class Initialized
INFO - 2023-10-08 00:18:00 --> Form Validation Class Initialized
INFO - 2023-10-08 00:18:00 --> Controller Class Initialized
INFO - 2023-10-08 00:18:00 --> Model Class Initialized
DEBUG - 2023-10-08 00:18:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 00:18:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:18:00 --> Model Class Initialized
DEBUG - 2023-10-08 00:18:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:18:00 --> Model Class Initialized
INFO - 2023-10-08 00:18:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-08 00:18:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:18:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 00:18:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 00:18:00 --> Model Class Initialized
INFO - 2023-10-08 00:18:00 --> Model Class Initialized
INFO - 2023-10-08 00:18:00 --> Model Class Initialized
INFO - 2023-10-08 00:18:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 00:18:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 00:18:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 00:18:00 --> Final output sent to browser
DEBUG - 2023-10-08 00:18:00 --> Total execution time: 0.0951
ERROR - 2023-10-08 00:18:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 00:18:01 --> Config Class Initialized
INFO - 2023-10-08 00:18:01 --> Hooks Class Initialized
DEBUG - 2023-10-08 00:18:01 --> UTF-8 Support Enabled
INFO - 2023-10-08 00:18:01 --> Utf8 Class Initialized
INFO - 2023-10-08 00:18:01 --> URI Class Initialized
INFO - 2023-10-08 00:18:01 --> Router Class Initialized
INFO - 2023-10-08 00:18:01 --> Output Class Initialized
INFO - 2023-10-08 00:18:01 --> Security Class Initialized
DEBUG - 2023-10-08 00:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 00:18:01 --> Input Class Initialized
INFO - 2023-10-08 00:18:01 --> Language Class Initialized
INFO - 2023-10-08 00:18:01 --> Loader Class Initialized
INFO - 2023-10-08 00:18:01 --> Helper loaded: url_helper
INFO - 2023-10-08 00:18:01 --> Helper loaded: file_helper
INFO - 2023-10-08 00:18:01 --> Helper loaded: html_helper
INFO - 2023-10-08 00:18:01 --> Helper loaded: text_helper
INFO - 2023-10-08 00:18:01 --> Helper loaded: form_helper
INFO - 2023-10-08 00:18:01 --> Helper loaded: lang_helper
INFO - 2023-10-08 00:18:01 --> Helper loaded: security_helper
INFO - 2023-10-08 00:18:01 --> Helper loaded: cookie_helper
INFO - 2023-10-08 00:18:01 --> Database Driver Class Initialized
INFO - 2023-10-08 00:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 00:18:01 --> Parser Class Initialized
INFO - 2023-10-08 00:18:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 00:18:01 --> Pagination Class Initialized
INFO - 2023-10-08 00:18:01 --> Form Validation Class Initialized
INFO - 2023-10-08 00:18:01 --> Controller Class Initialized
INFO - 2023-10-08 00:18:01 --> Model Class Initialized
DEBUG - 2023-10-08 00:18:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 00:18:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:18:01 --> Model Class Initialized
DEBUG - 2023-10-08 00:18:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:18:01 --> Model Class Initialized
INFO - 2023-10-08 00:18:01 --> Final output sent to browser
DEBUG - 2023-10-08 00:18:01 --> Total execution time: 0.0546
ERROR - 2023-10-08 00:18:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 00:18:32 --> Config Class Initialized
INFO - 2023-10-08 00:18:32 --> Hooks Class Initialized
DEBUG - 2023-10-08 00:18:32 --> UTF-8 Support Enabled
INFO - 2023-10-08 00:18:32 --> Utf8 Class Initialized
INFO - 2023-10-08 00:18:32 --> URI Class Initialized
INFO - 2023-10-08 00:18:32 --> Router Class Initialized
INFO - 2023-10-08 00:18:32 --> Output Class Initialized
INFO - 2023-10-08 00:18:32 --> Security Class Initialized
DEBUG - 2023-10-08 00:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 00:18:32 --> Input Class Initialized
INFO - 2023-10-08 00:18:32 --> Language Class Initialized
INFO - 2023-10-08 00:18:32 --> Loader Class Initialized
INFO - 2023-10-08 00:18:32 --> Helper loaded: url_helper
INFO - 2023-10-08 00:18:32 --> Helper loaded: file_helper
INFO - 2023-10-08 00:18:32 --> Helper loaded: html_helper
INFO - 2023-10-08 00:18:32 --> Helper loaded: text_helper
INFO - 2023-10-08 00:18:32 --> Helper loaded: form_helper
INFO - 2023-10-08 00:18:32 --> Helper loaded: lang_helper
INFO - 2023-10-08 00:18:32 --> Helper loaded: security_helper
INFO - 2023-10-08 00:18:32 --> Helper loaded: cookie_helper
INFO - 2023-10-08 00:18:32 --> Database Driver Class Initialized
INFO - 2023-10-08 00:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 00:18:32 --> Parser Class Initialized
INFO - 2023-10-08 00:18:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 00:18:32 --> Pagination Class Initialized
INFO - 2023-10-08 00:18:32 --> Form Validation Class Initialized
INFO - 2023-10-08 00:18:32 --> Controller Class Initialized
INFO - 2023-10-08 00:18:32 --> Model Class Initialized
DEBUG - 2023-10-08 00:18:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 00:18:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:18:32 --> Model Class Initialized
DEBUG - 2023-10-08 00:18:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:18:32 --> Model Class Initialized
INFO - 2023-10-08 00:18:32 --> Final output sent to browser
DEBUG - 2023-10-08 00:18:32 --> Total execution time: 0.0451
ERROR - 2023-10-08 00:18:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 00:18:41 --> Config Class Initialized
INFO - 2023-10-08 00:18:41 --> Hooks Class Initialized
DEBUG - 2023-10-08 00:18:41 --> UTF-8 Support Enabled
INFO - 2023-10-08 00:18:41 --> Utf8 Class Initialized
INFO - 2023-10-08 00:18:41 --> URI Class Initialized
INFO - 2023-10-08 00:18:41 --> Router Class Initialized
INFO - 2023-10-08 00:18:41 --> Output Class Initialized
INFO - 2023-10-08 00:18:41 --> Security Class Initialized
DEBUG - 2023-10-08 00:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 00:18:41 --> Input Class Initialized
INFO - 2023-10-08 00:18:41 --> Language Class Initialized
INFO - 2023-10-08 00:18:41 --> Loader Class Initialized
INFO - 2023-10-08 00:18:41 --> Helper loaded: url_helper
INFO - 2023-10-08 00:18:41 --> Helper loaded: file_helper
INFO - 2023-10-08 00:18:41 --> Helper loaded: html_helper
INFO - 2023-10-08 00:18:41 --> Helper loaded: text_helper
INFO - 2023-10-08 00:18:41 --> Helper loaded: form_helper
INFO - 2023-10-08 00:18:41 --> Helper loaded: lang_helper
INFO - 2023-10-08 00:18:41 --> Helper loaded: security_helper
INFO - 2023-10-08 00:18:41 --> Helper loaded: cookie_helper
INFO - 2023-10-08 00:18:41 --> Database Driver Class Initialized
INFO - 2023-10-08 00:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 00:18:41 --> Parser Class Initialized
INFO - 2023-10-08 00:18:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 00:18:41 --> Pagination Class Initialized
INFO - 2023-10-08 00:18:41 --> Form Validation Class Initialized
INFO - 2023-10-08 00:18:41 --> Controller Class Initialized
INFO - 2023-10-08 00:18:41 --> Model Class Initialized
DEBUG - 2023-10-08 00:18:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 00:18:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:18:41 --> Model Class Initialized
DEBUG - 2023-10-08 00:18:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:18:41 --> Model Class Initialized
INFO - 2023-10-08 00:18:41 --> Final output sent to browser
DEBUG - 2023-10-08 00:18:41 --> Total execution time: 0.0214
ERROR - 2023-10-08 00:18:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 00:18:46 --> Config Class Initialized
INFO - 2023-10-08 00:18:46 --> Hooks Class Initialized
DEBUG - 2023-10-08 00:18:46 --> UTF-8 Support Enabled
INFO - 2023-10-08 00:18:46 --> Utf8 Class Initialized
INFO - 2023-10-08 00:18:46 --> URI Class Initialized
INFO - 2023-10-08 00:18:46 --> Router Class Initialized
INFO - 2023-10-08 00:18:46 --> Output Class Initialized
INFO - 2023-10-08 00:18:46 --> Security Class Initialized
DEBUG - 2023-10-08 00:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 00:18:46 --> Input Class Initialized
INFO - 2023-10-08 00:18:46 --> Language Class Initialized
INFO - 2023-10-08 00:18:46 --> Loader Class Initialized
INFO - 2023-10-08 00:18:46 --> Helper loaded: url_helper
INFO - 2023-10-08 00:18:46 --> Helper loaded: file_helper
INFO - 2023-10-08 00:18:46 --> Helper loaded: html_helper
INFO - 2023-10-08 00:18:46 --> Helper loaded: text_helper
INFO - 2023-10-08 00:18:46 --> Helper loaded: form_helper
INFO - 2023-10-08 00:18:46 --> Helper loaded: lang_helper
INFO - 2023-10-08 00:18:46 --> Helper loaded: security_helper
INFO - 2023-10-08 00:18:46 --> Helper loaded: cookie_helper
INFO - 2023-10-08 00:18:46 --> Database Driver Class Initialized
INFO - 2023-10-08 00:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 00:18:46 --> Parser Class Initialized
INFO - 2023-10-08 00:18:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 00:18:46 --> Pagination Class Initialized
INFO - 2023-10-08 00:18:46 --> Form Validation Class Initialized
INFO - 2023-10-08 00:18:46 --> Controller Class Initialized
INFO - 2023-10-08 00:18:46 --> Model Class Initialized
DEBUG - 2023-10-08 00:18:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 00:18:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:18:46 --> Model Class Initialized
DEBUG - 2023-10-08 00:18:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:18:46 --> Model Class Initialized
INFO - 2023-10-08 00:18:46 --> Final output sent to browser
DEBUG - 2023-10-08 00:18:46 --> Total execution time: 0.0230
ERROR - 2023-10-08 00:19:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 00:19:04 --> Config Class Initialized
INFO - 2023-10-08 00:19:04 --> Hooks Class Initialized
DEBUG - 2023-10-08 00:19:04 --> UTF-8 Support Enabled
INFO - 2023-10-08 00:19:04 --> Utf8 Class Initialized
INFO - 2023-10-08 00:19:04 --> URI Class Initialized
DEBUG - 2023-10-08 00:19:04 --> No URI present. Default controller set.
INFO - 2023-10-08 00:19:04 --> Router Class Initialized
INFO - 2023-10-08 00:19:04 --> Output Class Initialized
INFO - 2023-10-08 00:19:04 --> Security Class Initialized
DEBUG - 2023-10-08 00:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 00:19:04 --> Input Class Initialized
INFO - 2023-10-08 00:19:04 --> Language Class Initialized
INFO - 2023-10-08 00:19:04 --> Loader Class Initialized
INFO - 2023-10-08 00:19:04 --> Helper loaded: url_helper
INFO - 2023-10-08 00:19:04 --> Helper loaded: file_helper
INFO - 2023-10-08 00:19:04 --> Helper loaded: html_helper
INFO - 2023-10-08 00:19:04 --> Helper loaded: text_helper
INFO - 2023-10-08 00:19:04 --> Helper loaded: form_helper
INFO - 2023-10-08 00:19:04 --> Helper loaded: lang_helper
INFO - 2023-10-08 00:19:04 --> Helper loaded: security_helper
INFO - 2023-10-08 00:19:04 --> Helper loaded: cookie_helper
INFO - 2023-10-08 00:19:04 --> Database Driver Class Initialized
INFO - 2023-10-08 00:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 00:19:04 --> Parser Class Initialized
INFO - 2023-10-08 00:19:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 00:19:04 --> Pagination Class Initialized
INFO - 2023-10-08 00:19:04 --> Form Validation Class Initialized
INFO - 2023-10-08 00:19:04 --> Controller Class Initialized
INFO - 2023-10-08 00:19:04 --> Model Class Initialized
DEBUG - 2023-10-08 00:19:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:19:04 --> Model Class Initialized
DEBUG - 2023-10-08 00:19:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:19:04 --> Model Class Initialized
INFO - 2023-10-08 00:19:04 --> Model Class Initialized
INFO - 2023-10-08 00:19:04 --> Model Class Initialized
INFO - 2023-10-08 00:19:04 --> Model Class Initialized
DEBUG - 2023-10-08 00:19:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 00:19:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:19:04 --> Model Class Initialized
INFO - 2023-10-08 00:19:04 --> Model Class Initialized
INFO - 2023-10-08 00:19:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-08 00:19:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:19:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 00:19:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 00:19:04 --> Model Class Initialized
INFO - 2023-10-08 00:19:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 00:19:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 00:19:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 00:19:04 --> Final output sent to browser
DEBUG - 2023-10-08 00:19:04 --> Total execution time: 0.1222
ERROR - 2023-10-08 00:19:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 00:19:10 --> Config Class Initialized
INFO - 2023-10-08 00:19:10 --> Hooks Class Initialized
DEBUG - 2023-10-08 00:19:10 --> UTF-8 Support Enabled
INFO - 2023-10-08 00:19:10 --> Utf8 Class Initialized
INFO - 2023-10-08 00:19:10 --> URI Class Initialized
INFO - 2023-10-08 00:19:10 --> Router Class Initialized
INFO - 2023-10-08 00:19:10 --> Output Class Initialized
INFO - 2023-10-08 00:19:10 --> Security Class Initialized
DEBUG - 2023-10-08 00:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 00:19:10 --> Input Class Initialized
INFO - 2023-10-08 00:19:10 --> Language Class Initialized
INFO - 2023-10-08 00:19:10 --> Loader Class Initialized
INFO - 2023-10-08 00:19:10 --> Helper loaded: url_helper
INFO - 2023-10-08 00:19:10 --> Helper loaded: file_helper
INFO - 2023-10-08 00:19:10 --> Helper loaded: html_helper
INFO - 2023-10-08 00:19:10 --> Helper loaded: text_helper
INFO - 2023-10-08 00:19:10 --> Helper loaded: form_helper
INFO - 2023-10-08 00:19:10 --> Helper loaded: lang_helper
INFO - 2023-10-08 00:19:10 --> Helper loaded: security_helper
INFO - 2023-10-08 00:19:10 --> Helper loaded: cookie_helper
INFO - 2023-10-08 00:19:10 --> Database Driver Class Initialized
INFO - 2023-10-08 00:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 00:19:10 --> Parser Class Initialized
INFO - 2023-10-08 00:19:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 00:19:10 --> Pagination Class Initialized
INFO - 2023-10-08 00:19:10 --> Form Validation Class Initialized
INFO - 2023-10-08 00:19:10 --> Controller Class Initialized
INFO - 2023-10-08 00:19:10 --> Model Class Initialized
DEBUG - 2023-10-08 00:19:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 00:19:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:19:10 --> Model Class Initialized
DEBUG - 2023-10-08 00:19:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:19:10 --> Model Class Initialized
INFO - 2023-10-08 00:19:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-08 00:19:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:19:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 00:19:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 00:19:10 --> Model Class Initialized
INFO - 2023-10-08 00:19:10 --> Model Class Initialized
INFO - 2023-10-08 00:19:10 --> Model Class Initialized
INFO - 2023-10-08 00:19:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 00:19:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 00:19:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 00:19:10 --> Final output sent to browser
DEBUG - 2023-10-08 00:19:10 --> Total execution time: 0.1026
ERROR - 2023-10-08 00:19:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 00:19:10 --> Config Class Initialized
INFO - 2023-10-08 00:19:10 --> Hooks Class Initialized
DEBUG - 2023-10-08 00:19:10 --> UTF-8 Support Enabled
INFO - 2023-10-08 00:19:10 --> Utf8 Class Initialized
INFO - 2023-10-08 00:19:10 --> URI Class Initialized
INFO - 2023-10-08 00:19:10 --> Router Class Initialized
INFO - 2023-10-08 00:19:10 --> Output Class Initialized
INFO - 2023-10-08 00:19:10 --> Security Class Initialized
DEBUG - 2023-10-08 00:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 00:19:10 --> Input Class Initialized
INFO - 2023-10-08 00:19:10 --> Language Class Initialized
INFO - 2023-10-08 00:19:10 --> Loader Class Initialized
INFO - 2023-10-08 00:19:10 --> Helper loaded: url_helper
INFO - 2023-10-08 00:19:10 --> Helper loaded: file_helper
INFO - 2023-10-08 00:19:10 --> Helper loaded: html_helper
INFO - 2023-10-08 00:19:10 --> Helper loaded: text_helper
INFO - 2023-10-08 00:19:10 --> Helper loaded: form_helper
INFO - 2023-10-08 00:19:10 --> Helper loaded: lang_helper
INFO - 2023-10-08 00:19:10 --> Helper loaded: security_helper
INFO - 2023-10-08 00:19:10 --> Helper loaded: cookie_helper
INFO - 2023-10-08 00:19:10 --> Database Driver Class Initialized
INFO - 2023-10-08 00:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 00:19:10 --> Parser Class Initialized
INFO - 2023-10-08 00:19:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 00:19:10 --> Pagination Class Initialized
INFO - 2023-10-08 00:19:10 --> Form Validation Class Initialized
INFO - 2023-10-08 00:19:10 --> Controller Class Initialized
INFO - 2023-10-08 00:19:10 --> Model Class Initialized
DEBUG - 2023-10-08 00:19:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 00:19:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:19:10 --> Model Class Initialized
DEBUG - 2023-10-08 00:19:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:19:10 --> Model Class Initialized
INFO - 2023-10-08 00:19:10 --> Final output sent to browser
DEBUG - 2023-10-08 00:19:10 --> Total execution time: 0.0417
ERROR - 2023-10-08 00:19:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 00:19:16 --> Config Class Initialized
INFO - 2023-10-08 00:19:16 --> Hooks Class Initialized
DEBUG - 2023-10-08 00:19:16 --> UTF-8 Support Enabled
INFO - 2023-10-08 00:19:16 --> Utf8 Class Initialized
INFO - 2023-10-08 00:19:16 --> URI Class Initialized
DEBUG - 2023-10-08 00:19:16 --> No URI present. Default controller set.
INFO - 2023-10-08 00:19:16 --> Router Class Initialized
INFO - 2023-10-08 00:19:16 --> Output Class Initialized
INFO - 2023-10-08 00:19:16 --> Security Class Initialized
DEBUG - 2023-10-08 00:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 00:19:16 --> Input Class Initialized
INFO - 2023-10-08 00:19:16 --> Language Class Initialized
INFO - 2023-10-08 00:19:16 --> Loader Class Initialized
INFO - 2023-10-08 00:19:16 --> Helper loaded: url_helper
INFO - 2023-10-08 00:19:16 --> Helper loaded: file_helper
INFO - 2023-10-08 00:19:16 --> Helper loaded: html_helper
INFO - 2023-10-08 00:19:16 --> Helper loaded: text_helper
INFO - 2023-10-08 00:19:16 --> Helper loaded: form_helper
INFO - 2023-10-08 00:19:16 --> Helper loaded: lang_helper
INFO - 2023-10-08 00:19:16 --> Helper loaded: security_helper
INFO - 2023-10-08 00:19:16 --> Helper loaded: cookie_helper
INFO - 2023-10-08 00:19:16 --> Database Driver Class Initialized
INFO - 2023-10-08 00:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 00:19:16 --> Parser Class Initialized
INFO - 2023-10-08 00:19:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 00:19:16 --> Pagination Class Initialized
INFO - 2023-10-08 00:19:16 --> Form Validation Class Initialized
INFO - 2023-10-08 00:19:16 --> Controller Class Initialized
INFO - 2023-10-08 00:19:16 --> Model Class Initialized
DEBUG - 2023-10-08 00:19:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:19:16 --> Model Class Initialized
DEBUG - 2023-10-08 00:19:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:19:16 --> Model Class Initialized
INFO - 2023-10-08 00:19:16 --> Model Class Initialized
INFO - 2023-10-08 00:19:16 --> Model Class Initialized
INFO - 2023-10-08 00:19:16 --> Model Class Initialized
DEBUG - 2023-10-08 00:19:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 00:19:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:19:16 --> Model Class Initialized
INFO - 2023-10-08 00:19:16 --> Model Class Initialized
INFO - 2023-10-08 00:19:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-08 00:19:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:19:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 00:19:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 00:19:16 --> Model Class Initialized
INFO - 2023-10-08 00:19:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 00:19:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 00:19:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 00:19:16 --> Final output sent to browser
DEBUG - 2023-10-08 00:19:16 --> Total execution time: 0.1115
ERROR - 2023-10-08 00:19:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 00:19:22 --> Config Class Initialized
INFO - 2023-10-08 00:19:22 --> Hooks Class Initialized
DEBUG - 2023-10-08 00:19:22 --> UTF-8 Support Enabled
INFO - 2023-10-08 00:19:22 --> Utf8 Class Initialized
INFO - 2023-10-08 00:19:22 --> URI Class Initialized
INFO - 2023-10-08 00:19:22 --> Router Class Initialized
INFO - 2023-10-08 00:19:22 --> Output Class Initialized
INFO - 2023-10-08 00:19:22 --> Security Class Initialized
DEBUG - 2023-10-08 00:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 00:19:22 --> Input Class Initialized
INFO - 2023-10-08 00:19:22 --> Language Class Initialized
INFO - 2023-10-08 00:19:22 --> Loader Class Initialized
INFO - 2023-10-08 00:19:22 --> Helper loaded: url_helper
INFO - 2023-10-08 00:19:22 --> Helper loaded: file_helper
INFO - 2023-10-08 00:19:22 --> Helper loaded: html_helper
INFO - 2023-10-08 00:19:22 --> Helper loaded: text_helper
INFO - 2023-10-08 00:19:22 --> Helper loaded: form_helper
INFO - 2023-10-08 00:19:22 --> Helper loaded: lang_helper
INFO - 2023-10-08 00:19:22 --> Helper loaded: security_helper
INFO - 2023-10-08 00:19:22 --> Helper loaded: cookie_helper
INFO - 2023-10-08 00:19:22 --> Database Driver Class Initialized
INFO - 2023-10-08 00:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 00:19:22 --> Parser Class Initialized
INFO - 2023-10-08 00:19:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 00:19:22 --> Pagination Class Initialized
INFO - 2023-10-08 00:19:22 --> Form Validation Class Initialized
INFO - 2023-10-08 00:19:22 --> Controller Class Initialized
INFO - 2023-10-08 00:19:22 --> Model Class Initialized
DEBUG - 2023-10-08 00:19:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 00:19:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:19:22 --> Model Class Initialized
DEBUG - 2023-10-08 00:19:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:19:22 --> Model Class Initialized
INFO - 2023-10-08 00:19:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-10-08 00:19:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 00:19:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 00:19:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 00:19:22 --> Model Class Initialized
INFO - 2023-10-08 00:19:22 --> Model Class Initialized
INFO - 2023-10-08 00:19:22 --> Model Class Initialized
INFO - 2023-10-08 00:19:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 00:19:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 00:19:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 00:19:22 --> Final output sent to browser
DEBUG - 2023-10-08 00:19:22 --> Total execution time: 0.1218
ERROR - 2023-10-08 01:58:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 01:58:49 --> Config Class Initialized
INFO - 2023-10-08 01:58:49 --> Hooks Class Initialized
DEBUG - 2023-10-08 01:58:49 --> UTF-8 Support Enabled
INFO - 2023-10-08 01:58:49 --> Utf8 Class Initialized
INFO - 2023-10-08 01:58:49 --> URI Class Initialized
DEBUG - 2023-10-08 01:58:49 --> No URI present. Default controller set.
INFO - 2023-10-08 01:58:49 --> Router Class Initialized
INFO - 2023-10-08 01:58:49 --> Output Class Initialized
INFO - 2023-10-08 01:58:49 --> Security Class Initialized
DEBUG - 2023-10-08 01:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 01:58:49 --> Input Class Initialized
INFO - 2023-10-08 01:58:49 --> Language Class Initialized
INFO - 2023-10-08 01:58:49 --> Loader Class Initialized
INFO - 2023-10-08 01:58:49 --> Helper loaded: url_helper
INFO - 2023-10-08 01:58:49 --> Helper loaded: file_helper
INFO - 2023-10-08 01:58:49 --> Helper loaded: html_helper
INFO - 2023-10-08 01:58:49 --> Helper loaded: text_helper
INFO - 2023-10-08 01:58:49 --> Helper loaded: form_helper
INFO - 2023-10-08 01:58:49 --> Helper loaded: lang_helper
INFO - 2023-10-08 01:58:49 --> Helper loaded: security_helper
INFO - 2023-10-08 01:58:49 --> Helper loaded: cookie_helper
INFO - 2023-10-08 01:58:49 --> Database Driver Class Initialized
INFO - 2023-10-08 01:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 01:58:49 --> Parser Class Initialized
INFO - 2023-10-08 01:58:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 01:58:49 --> Pagination Class Initialized
INFO - 2023-10-08 01:58:49 --> Form Validation Class Initialized
INFO - 2023-10-08 01:58:49 --> Controller Class Initialized
INFO - 2023-10-08 01:58:49 --> Model Class Initialized
DEBUG - 2023-10-08 01:58:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 01:58:49 --> Model Class Initialized
DEBUG - 2023-10-08 01:58:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 01:58:49 --> Model Class Initialized
INFO - 2023-10-08 01:58:49 --> Model Class Initialized
INFO - 2023-10-08 01:58:49 --> Model Class Initialized
INFO - 2023-10-08 01:58:49 --> Model Class Initialized
DEBUG - 2023-10-08 01:58:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 01:58:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 01:58:49 --> Model Class Initialized
INFO - 2023-10-08 01:58:49 --> Model Class Initialized
INFO - 2023-10-08 01:58:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-08 01:58:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 01:58:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 01:58:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 01:58:49 --> Model Class Initialized
INFO - 2023-10-08 01:58:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 01:58:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 01:58:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 01:58:49 --> Final output sent to browser
DEBUG - 2023-10-08 01:58:49 --> Total execution time: 0.1228
ERROR - 2023-10-08 01:58:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 01:58:59 --> Config Class Initialized
INFO - 2023-10-08 01:58:59 --> Hooks Class Initialized
DEBUG - 2023-10-08 01:58:59 --> UTF-8 Support Enabled
INFO - 2023-10-08 01:58:59 --> Utf8 Class Initialized
INFO - 2023-10-08 01:58:59 --> URI Class Initialized
INFO - 2023-10-08 01:58:59 --> Router Class Initialized
INFO - 2023-10-08 01:58:59 --> Output Class Initialized
INFO - 2023-10-08 01:58:59 --> Security Class Initialized
DEBUG - 2023-10-08 01:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 01:58:59 --> Input Class Initialized
INFO - 2023-10-08 01:58:59 --> Language Class Initialized
INFO - 2023-10-08 01:58:59 --> Loader Class Initialized
INFO - 2023-10-08 01:58:59 --> Helper loaded: url_helper
INFO - 2023-10-08 01:58:59 --> Helper loaded: file_helper
INFO - 2023-10-08 01:58:59 --> Helper loaded: html_helper
INFO - 2023-10-08 01:58:59 --> Helper loaded: text_helper
INFO - 2023-10-08 01:58:59 --> Helper loaded: form_helper
INFO - 2023-10-08 01:58:59 --> Helper loaded: lang_helper
INFO - 2023-10-08 01:58:59 --> Helper loaded: security_helper
INFO - 2023-10-08 01:58:59 --> Helper loaded: cookie_helper
INFO - 2023-10-08 01:58:59 --> Database Driver Class Initialized
INFO - 2023-10-08 01:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 01:58:59 --> Parser Class Initialized
INFO - 2023-10-08 01:58:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 01:58:59 --> Pagination Class Initialized
INFO - 2023-10-08 01:58:59 --> Form Validation Class Initialized
INFO - 2023-10-08 01:58:59 --> Controller Class Initialized
INFO - 2023-10-08 01:58:59 --> Model Class Initialized
DEBUG - 2023-10-08 01:58:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 01:58:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 01:58:59 --> Model Class Initialized
DEBUG - 2023-10-08 01:58:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 01:58:59 --> Model Class Initialized
INFO - 2023-10-08 01:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-10-08 01:58:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 01:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 01:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 01:58:59 --> Model Class Initialized
INFO - 2023-10-08 01:58:59 --> Model Class Initialized
INFO - 2023-10-08 01:58:59 --> Model Class Initialized
INFO - 2023-10-08 01:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 01:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 01:58:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 01:58:59 --> Final output sent to browser
DEBUG - 2023-10-08 01:58:59 --> Total execution time: 0.1279
ERROR - 2023-10-08 01:59:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 01:59:17 --> Config Class Initialized
INFO - 2023-10-08 01:59:17 --> Hooks Class Initialized
DEBUG - 2023-10-08 01:59:17 --> UTF-8 Support Enabled
INFO - 2023-10-08 01:59:17 --> Utf8 Class Initialized
INFO - 2023-10-08 01:59:17 --> URI Class Initialized
INFO - 2023-10-08 01:59:17 --> Router Class Initialized
INFO - 2023-10-08 01:59:17 --> Output Class Initialized
INFO - 2023-10-08 01:59:17 --> Security Class Initialized
DEBUG - 2023-10-08 01:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 01:59:17 --> Input Class Initialized
INFO - 2023-10-08 01:59:17 --> Language Class Initialized
INFO - 2023-10-08 01:59:17 --> Loader Class Initialized
INFO - 2023-10-08 01:59:17 --> Helper loaded: url_helper
INFO - 2023-10-08 01:59:17 --> Helper loaded: file_helper
INFO - 2023-10-08 01:59:17 --> Helper loaded: html_helper
INFO - 2023-10-08 01:59:17 --> Helper loaded: text_helper
INFO - 2023-10-08 01:59:17 --> Helper loaded: form_helper
INFO - 2023-10-08 01:59:17 --> Helper loaded: lang_helper
INFO - 2023-10-08 01:59:17 --> Helper loaded: security_helper
INFO - 2023-10-08 01:59:17 --> Helper loaded: cookie_helper
INFO - 2023-10-08 01:59:17 --> Database Driver Class Initialized
INFO - 2023-10-08 01:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 01:59:17 --> Parser Class Initialized
INFO - 2023-10-08 01:59:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 01:59:17 --> Pagination Class Initialized
INFO - 2023-10-08 01:59:17 --> Form Validation Class Initialized
INFO - 2023-10-08 01:59:17 --> Controller Class Initialized
INFO - 2023-10-08 01:59:17 --> Model Class Initialized
DEBUG - 2023-10-08 01:59:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 01:59:17 --> Final output sent to browser
DEBUG - 2023-10-08 01:59:17 --> Total execution time: 0.0179
ERROR - 2023-10-08 01:59:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 01:59:35 --> Config Class Initialized
INFO - 2023-10-08 01:59:35 --> Hooks Class Initialized
DEBUG - 2023-10-08 01:59:35 --> UTF-8 Support Enabled
INFO - 2023-10-08 01:59:35 --> Utf8 Class Initialized
INFO - 2023-10-08 01:59:35 --> URI Class Initialized
INFO - 2023-10-08 01:59:35 --> Router Class Initialized
INFO - 2023-10-08 01:59:35 --> Output Class Initialized
INFO - 2023-10-08 01:59:35 --> Security Class Initialized
DEBUG - 2023-10-08 01:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 01:59:35 --> Input Class Initialized
INFO - 2023-10-08 01:59:35 --> Language Class Initialized
INFO - 2023-10-08 01:59:35 --> Loader Class Initialized
INFO - 2023-10-08 01:59:35 --> Helper loaded: url_helper
INFO - 2023-10-08 01:59:35 --> Helper loaded: file_helper
INFO - 2023-10-08 01:59:35 --> Helper loaded: html_helper
INFO - 2023-10-08 01:59:35 --> Helper loaded: text_helper
INFO - 2023-10-08 01:59:35 --> Helper loaded: form_helper
INFO - 2023-10-08 01:59:35 --> Helper loaded: lang_helper
INFO - 2023-10-08 01:59:35 --> Helper loaded: security_helper
INFO - 2023-10-08 01:59:35 --> Helper loaded: cookie_helper
INFO - 2023-10-08 01:59:35 --> Database Driver Class Initialized
INFO - 2023-10-08 01:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 01:59:35 --> Parser Class Initialized
INFO - 2023-10-08 01:59:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 01:59:35 --> Pagination Class Initialized
INFO - 2023-10-08 01:59:35 --> Form Validation Class Initialized
INFO - 2023-10-08 01:59:35 --> Controller Class Initialized
INFO - 2023-10-08 01:59:35 --> Model Class Initialized
DEBUG - 2023-10-08 01:59:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 01:59:35 --> Final output sent to browser
DEBUG - 2023-10-08 01:59:35 --> Total execution time: 0.0188
ERROR - 2023-10-08 01:59:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 01:59:38 --> Config Class Initialized
INFO - 2023-10-08 01:59:38 --> Hooks Class Initialized
DEBUG - 2023-10-08 01:59:38 --> UTF-8 Support Enabled
INFO - 2023-10-08 01:59:38 --> Utf8 Class Initialized
INFO - 2023-10-08 01:59:38 --> URI Class Initialized
INFO - 2023-10-08 01:59:38 --> Router Class Initialized
INFO - 2023-10-08 01:59:38 --> Output Class Initialized
INFO - 2023-10-08 01:59:38 --> Security Class Initialized
DEBUG - 2023-10-08 01:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 01:59:38 --> Input Class Initialized
INFO - 2023-10-08 01:59:38 --> Language Class Initialized
INFO - 2023-10-08 01:59:38 --> Loader Class Initialized
INFO - 2023-10-08 01:59:38 --> Helper loaded: url_helper
INFO - 2023-10-08 01:59:38 --> Helper loaded: file_helper
INFO - 2023-10-08 01:59:38 --> Helper loaded: html_helper
INFO - 2023-10-08 01:59:38 --> Helper loaded: text_helper
INFO - 2023-10-08 01:59:38 --> Helper loaded: form_helper
INFO - 2023-10-08 01:59:38 --> Helper loaded: lang_helper
INFO - 2023-10-08 01:59:38 --> Helper loaded: security_helper
INFO - 2023-10-08 01:59:38 --> Helper loaded: cookie_helper
INFO - 2023-10-08 01:59:38 --> Database Driver Class Initialized
INFO - 2023-10-08 01:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 01:59:38 --> Parser Class Initialized
INFO - 2023-10-08 01:59:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 01:59:38 --> Pagination Class Initialized
INFO - 2023-10-08 01:59:38 --> Form Validation Class Initialized
INFO - 2023-10-08 01:59:38 --> Controller Class Initialized
INFO - 2023-10-08 01:59:38 --> Model Class Initialized
DEBUG - 2023-10-08 01:59:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 01:59:38 --> Final output sent to browser
DEBUG - 2023-10-08 01:59:38 --> Total execution time: 0.0163
ERROR - 2023-10-08 01:59:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 01:59:48 --> Config Class Initialized
INFO - 2023-10-08 01:59:48 --> Hooks Class Initialized
DEBUG - 2023-10-08 01:59:48 --> UTF-8 Support Enabled
INFO - 2023-10-08 01:59:48 --> Utf8 Class Initialized
INFO - 2023-10-08 01:59:48 --> URI Class Initialized
INFO - 2023-10-08 01:59:48 --> Router Class Initialized
INFO - 2023-10-08 01:59:48 --> Output Class Initialized
INFO - 2023-10-08 01:59:48 --> Security Class Initialized
DEBUG - 2023-10-08 01:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 01:59:48 --> Input Class Initialized
INFO - 2023-10-08 01:59:48 --> Language Class Initialized
INFO - 2023-10-08 01:59:48 --> Loader Class Initialized
INFO - 2023-10-08 01:59:48 --> Helper loaded: url_helper
INFO - 2023-10-08 01:59:48 --> Helper loaded: file_helper
INFO - 2023-10-08 01:59:48 --> Helper loaded: html_helper
INFO - 2023-10-08 01:59:48 --> Helper loaded: text_helper
INFO - 2023-10-08 01:59:48 --> Helper loaded: form_helper
INFO - 2023-10-08 01:59:48 --> Helper loaded: lang_helper
INFO - 2023-10-08 01:59:48 --> Helper loaded: security_helper
INFO - 2023-10-08 01:59:48 --> Helper loaded: cookie_helper
INFO - 2023-10-08 01:59:48 --> Database Driver Class Initialized
INFO - 2023-10-08 01:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 01:59:48 --> Parser Class Initialized
INFO - 2023-10-08 01:59:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 01:59:48 --> Pagination Class Initialized
INFO - 2023-10-08 01:59:48 --> Form Validation Class Initialized
INFO - 2023-10-08 01:59:48 --> Controller Class Initialized
INFO - 2023-10-08 01:59:48 --> Model Class Initialized
DEBUG - 2023-10-08 01:59:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 01:59:49 --> Final output sent to browser
DEBUG - 2023-10-08 01:59:49 --> Total execution time: 0.0178
ERROR - 2023-10-08 01:59:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 01:59:52 --> Config Class Initialized
INFO - 2023-10-08 01:59:52 --> Hooks Class Initialized
DEBUG - 2023-10-08 01:59:52 --> UTF-8 Support Enabled
INFO - 2023-10-08 01:59:52 --> Utf8 Class Initialized
INFO - 2023-10-08 01:59:52 --> URI Class Initialized
INFO - 2023-10-08 01:59:52 --> Router Class Initialized
INFO - 2023-10-08 01:59:52 --> Output Class Initialized
INFO - 2023-10-08 01:59:52 --> Security Class Initialized
DEBUG - 2023-10-08 01:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 01:59:52 --> Input Class Initialized
INFO - 2023-10-08 01:59:52 --> Language Class Initialized
INFO - 2023-10-08 01:59:52 --> Loader Class Initialized
INFO - 2023-10-08 01:59:52 --> Helper loaded: url_helper
INFO - 2023-10-08 01:59:52 --> Helper loaded: file_helper
INFO - 2023-10-08 01:59:52 --> Helper loaded: html_helper
INFO - 2023-10-08 01:59:52 --> Helper loaded: text_helper
INFO - 2023-10-08 01:59:52 --> Helper loaded: form_helper
INFO - 2023-10-08 01:59:52 --> Helper loaded: lang_helper
INFO - 2023-10-08 01:59:52 --> Helper loaded: security_helper
INFO - 2023-10-08 01:59:52 --> Helper loaded: cookie_helper
INFO - 2023-10-08 01:59:52 --> Database Driver Class Initialized
INFO - 2023-10-08 01:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 01:59:52 --> Parser Class Initialized
INFO - 2023-10-08 01:59:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 01:59:52 --> Pagination Class Initialized
INFO - 2023-10-08 01:59:52 --> Form Validation Class Initialized
INFO - 2023-10-08 01:59:52 --> Controller Class Initialized
INFO - 2023-10-08 01:59:52 --> Model Class Initialized
DEBUG - 2023-10-08 01:59:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 01:59:52 --> Final output sent to browser
DEBUG - 2023-10-08 01:59:52 --> Total execution time: 0.0168
ERROR - 2023-10-08 01:59:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 01:59:58 --> Config Class Initialized
INFO - 2023-10-08 01:59:58 --> Hooks Class Initialized
DEBUG - 2023-10-08 01:59:58 --> UTF-8 Support Enabled
INFO - 2023-10-08 01:59:58 --> Utf8 Class Initialized
INFO - 2023-10-08 01:59:58 --> URI Class Initialized
INFO - 2023-10-08 01:59:58 --> Router Class Initialized
INFO - 2023-10-08 01:59:58 --> Output Class Initialized
INFO - 2023-10-08 01:59:58 --> Security Class Initialized
DEBUG - 2023-10-08 01:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 01:59:58 --> Input Class Initialized
INFO - 2023-10-08 01:59:58 --> Language Class Initialized
INFO - 2023-10-08 01:59:58 --> Loader Class Initialized
INFO - 2023-10-08 01:59:58 --> Helper loaded: url_helper
INFO - 2023-10-08 01:59:58 --> Helper loaded: file_helper
INFO - 2023-10-08 01:59:58 --> Helper loaded: html_helper
INFO - 2023-10-08 01:59:58 --> Helper loaded: text_helper
INFO - 2023-10-08 01:59:58 --> Helper loaded: form_helper
INFO - 2023-10-08 01:59:58 --> Helper loaded: lang_helper
INFO - 2023-10-08 01:59:58 --> Helper loaded: security_helper
INFO - 2023-10-08 01:59:58 --> Helper loaded: cookie_helper
INFO - 2023-10-08 01:59:58 --> Database Driver Class Initialized
INFO - 2023-10-08 01:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 01:59:58 --> Parser Class Initialized
INFO - 2023-10-08 01:59:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 01:59:58 --> Pagination Class Initialized
INFO - 2023-10-08 01:59:58 --> Form Validation Class Initialized
INFO - 2023-10-08 01:59:58 --> Controller Class Initialized
INFO - 2023-10-08 01:59:58 --> Model Class Initialized
DEBUG - 2023-10-08 01:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 01:59:58 --> Final output sent to browser
DEBUG - 2023-10-08 01:59:58 --> Total execution time: 0.0158
ERROR - 2023-10-08 02:00:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:00:01 --> Config Class Initialized
INFO - 2023-10-08 02:00:01 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:00:01 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:00:01 --> Utf8 Class Initialized
INFO - 2023-10-08 02:00:01 --> URI Class Initialized
INFO - 2023-10-08 02:00:01 --> Router Class Initialized
INFO - 2023-10-08 02:00:01 --> Output Class Initialized
INFO - 2023-10-08 02:00:01 --> Security Class Initialized
DEBUG - 2023-10-08 02:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:00:01 --> Input Class Initialized
INFO - 2023-10-08 02:00:01 --> Language Class Initialized
INFO - 2023-10-08 02:00:01 --> Loader Class Initialized
INFO - 2023-10-08 02:00:01 --> Helper loaded: url_helper
INFO - 2023-10-08 02:00:01 --> Helper loaded: file_helper
INFO - 2023-10-08 02:00:01 --> Helper loaded: html_helper
INFO - 2023-10-08 02:00:01 --> Helper loaded: text_helper
INFO - 2023-10-08 02:00:01 --> Helper loaded: form_helper
INFO - 2023-10-08 02:00:01 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:00:01 --> Helper loaded: security_helper
INFO - 2023-10-08 02:00:01 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:00:01 --> Database Driver Class Initialized
INFO - 2023-10-08 02:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:00:01 --> Parser Class Initialized
INFO - 2023-10-08 02:00:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:00:01 --> Pagination Class Initialized
INFO - 2023-10-08 02:00:01 --> Form Validation Class Initialized
INFO - 2023-10-08 02:00:01 --> Controller Class Initialized
INFO - 2023-10-08 02:00:01 --> Model Class Initialized
DEBUG - 2023-10-08 02:00:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 02:00:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-08 02:00:01 --> Final output sent to browser
DEBUG - 2023-10-08 02:00:01 --> Total execution time: 0.0147
ERROR - 2023-10-08 02:00:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:00:02 --> Config Class Initialized
INFO - 2023-10-08 02:00:02 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:00:02 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:00:02 --> Utf8 Class Initialized
INFO - 2023-10-08 02:00:02 --> URI Class Initialized
INFO - 2023-10-08 02:00:02 --> Router Class Initialized
INFO - 2023-10-08 02:00:02 --> Output Class Initialized
INFO - 2023-10-08 02:00:02 --> Security Class Initialized
DEBUG - 2023-10-08 02:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:00:02 --> Input Class Initialized
INFO - 2023-10-08 02:00:02 --> Language Class Initialized
INFO - 2023-10-08 02:00:02 --> Loader Class Initialized
INFO - 2023-10-08 02:00:02 --> Helper loaded: url_helper
INFO - 2023-10-08 02:00:02 --> Helper loaded: file_helper
INFO - 2023-10-08 02:00:02 --> Helper loaded: html_helper
INFO - 2023-10-08 02:00:02 --> Helper loaded: text_helper
INFO - 2023-10-08 02:00:02 --> Helper loaded: form_helper
INFO - 2023-10-08 02:00:02 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:00:02 --> Helper loaded: security_helper
INFO - 2023-10-08 02:00:02 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:00:02 --> Database Driver Class Initialized
INFO - 2023-10-08 02:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:00:02 --> Parser Class Initialized
INFO - 2023-10-08 02:00:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:00:02 --> Pagination Class Initialized
INFO - 2023-10-08 02:00:02 --> Form Validation Class Initialized
INFO - 2023-10-08 02:00:02 --> Controller Class Initialized
INFO - 2023-10-08 02:00:02 --> Model Class Initialized
DEBUG - 2023-10-08 02:00:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:00:02 --> Final output sent to browser
DEBUG - 2023-10-08 02:00:02 --> Total execution time: 0.0194
ERROR - 2023-10-08 02:00:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:00:02 --> Config Class Initialized
INFO - 2023-10-08 02:00:02 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:00:02 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:00:02 --> Utf8 Class Initialized
INFO - 2023-10-08 02:00:02 --> URI Class Initialized
INFO - 2023-10-08 02:00:02 --> Router Class Initialized
INFO - 2023-10-08 02:00:02 --> Output Class Initialized
INFO - 2023-10-08 02:00:02 --> Security Class Initialized
DEBUG - 2023-10-08 02:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:00:02 --> Input Class Initialized
INFO - 2023-10-08 02:00:02 --> Language Class Initialized
INFO - 2023-10-08 02:00:02 --> Loader Class Initialized
INFO - 2023-10-08 02:00:02 --> Helper loaded: url_helper
INFO - 2023-10-08 02:00:02 --> Helper loaded: file_helper
INFO - 2023-10-08 02:00:02 --> Helper loaded: html_helper
INFO - 2023-10-08 02:00:02 --> Helper loaded: text_helper
INFO - 2023-10-08 02:00:02 --> Helper loaded: form_helper
INFO - 2023-10-08 02:00:02 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:00:02 --> Helper loaded: security_helper
INFO - 2023-10-08 02:00:02 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:00:02 --> Database Driver Class Initialized
INFO - 2023-10-08 02:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:00:02 --> Parser Class Initialized
INFO - 2023-10-08 02:00:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:00:02 --> Pagination Class Initialized
INFO - 2023-10-08 02:00:02 --> Form Validation Class Initialized
INFO - 2023-10-08 02:00:02 --> Controller Class Initialized
INFO - 2023-10-08 02:00:02 --> Model Class Initialized
DEBUG - 2023-10-08 02:00:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:00:02 --> Final output sent to browser
DEBUG - 2023-10-08 02:00:02 --> Total execution time: 0.0195
ERROR - 2023-10-08 02:00:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:00:07 --> Config Class Initialized
INFO - 2023-10-08 02:00:07 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:00:07 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:00:07 --> Utf8 Class Initialized
INFO - 2023-10-08 02:00:07 --> URI Class Initialized
INFO - 2023-10-08 02:00:07 --> Router Class Initialized
INFO - 2023-10-08 02:00:07 --> Output Class Initialized
INFO - 2023-10-08 02:00:07 --> Security Class Initialized
DEBUG - 2023-10-08 02:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:00:07 --> Input Class Initialized
INFO - 2023-10-08 02:00:07 --> Language Class Initialized
INFO - 2023-10-08 02:00:07 --> Loader Class Initialized
INFO - 2023-10-08 02:00:07 --> Helper loaded: url_helper
INFO - 2023-10-08 02:00:07 --> Helper loaded: file_helper
INFO - 2023-10-08 02:00:07 --> Helper loaded: html_helper
INFO - 2023-10-08 02:00:07 --> Helper loaded: text_helper
INFO - 2023-10-08 02:00:07 --> Helper loaded: form_helper
INFO - 2023-10-08 02:00:07 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:00:07 --> Helper loaded: security_helper
INFO - 2023-10-08 02:00:07 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:00:07 --> Database Driver Class Initialized
INFO - 2023-10-08 02:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:00:07 --> Parser Class Initialized
INFO - 2023-10-08 02:00:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:00:07 --> Pagination Class Initialized
INFO - 2023-10-08 02:00:07 --> Form Validation Class Initialized
INFO - 2023-10-08 02:00:07 --> Controller Class Initialized
INFO - 2023-10-08 02:00:07 --> Model Class Initialized
DEBUG - 2023-10-08 02:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:00:07 --> Final output sent to browser
DEBUG - 2023-10-08 02:00:07 --> Total execution time: 0.0156
ERROR - 2023-10-08 02:00:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:00:08 --> Config Class Initialized
INFO - 2023-10-08 02:00:08 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:00:08 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:00:08 --> Utf8 Class Initialized
INFO - 2023-10-08 02:00:08 --> URI Class Initialized
INFO - 2023-10-08 02:00:08 --> Router Class Initialized
INFO - 2023-10-08 02:00:08 --> Output Class Initialized
INFO - 2023-10-08 02:00:08 --> Security Class Initialized
DEBUG - 2023-10-08 02:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:00:08 --> Input Class Initialized
INFO - 2023-10-08 02:00:08 --> Language Class Initialized
INFO - 2023-10-08 02:00:08 --> Loader Class Initialized
INFO - 2023-10-08 02:00:08 --> Helper loaded: url_helper
INFO - 2023-10-08 02:00:08 --> Helper loaded: file_helper
INFO - 2023-10-08 02:00:08 --> Helper loaded: html_helper
INFO - 2023-10-08 02:00:08 --> Helper loaded: text_helper
INFO - 2023-10-08 02:00:08 --> Helper loaded: form_helper
INFO - 2023-10-08 02:00:08 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:00:08 --> Helper loaded: security_helper
INFO - 2023-10-08 02:00:08 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:00:08 --> Database Driver Class Initialized
INFO - 2023-10-08 02:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:00:08 --> Parser Class Initialized
INFO - 2023-10-08 02:00:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:00:08 --> Pagination Class Initialized
INFO - 2023-10-08 02:00:08 --> Form Validation Class Initialized
INFO - 2023-10-08 02:00:08 --> Controller Class Initialized
INFO - 2023-10-08 02:00:08 --> Model Class Initialized
DEBUG - 2023-10-08 02:00:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 02:00:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-08 02:00:08 --> Final output sent to browser
DEBUG - 2023-10-08 02:00:08 --> Total execution time: 0.0164
ERROR - 2023-10-08 02:00:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:00:14 --> Config Class Initialized
INFO - 2023-10-08 02:00:14 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:00:14 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:00:14 --> Utf8 Class Initialized
INFO - 2023-10-08 02:00:14 --> URI Class Initialized
INFO - 2023-10-08 02:00:14 --> Router Class Initialized
INFO - 2023-10-08 02:00:14 --> Output Class Initialized
INFO - 2023-10-08 02:00:14 --> Security Class Initialized
DEBUG - 2023-10-08 02:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:00:14 --> Input Class Initialized
INFO - 2023-10-08 02:00:14 --> Language Class Initialized
INFO - 2023-10-08 02:00:14 --> Loader Class Initialized
INFO - 2023-10-08 02:00:14 --> Helper loaded: url_helper
INFO - 2023-10-08 02:00:14 --> Helper loaded: file_helper
INFO - 2023-10-08 02:00:14 --> Helper loaded: html_helper
INFO - 2023-10-08 02:00:14 --> Helper loaded: text_helper
INFO - 2023-10-08 02:00:14 --> Helper loaded: form_helper
INFO - 2023-10-08 02:00:14 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:00:14 --> Helper loaded: security_helper
INFO - 2023-10-08 02:00:14 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:00:14 --> Database Driver Class Initialized
INFO - 2023-10-08 02:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:00:14 --> Parser Class Initialized
INFO - 2023-10-08 02:00:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:00:14 --> Pagination Class Initialized
INFO - 2023-10-08 02:00:14 --> Form Validation Class Initialized
INFO - 2023-10-08 02:00:14 --> Controller Class Initialized
INFO - 2023-10-08 02:00:14 --> Model Class Initialized
DEBUG - 2023-10-08 02:00:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 02:00:14 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-08 02:00:14 --> Final output sent to browser
DEBUG - 2023-10-08 02:00:14 --> Total execution time: 0.0158
ERROR - 2023-10-08 02:00:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:00:16 --> Config Class Initialized
INFO - 2023-10-08 02:00:16 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:00:16 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:00:16 --> Utf8 Class Initialized
INFO - 2023-10-08 02:00:16 --> URI Class Initialized
INFO - 2023-10-08 02:00:16 --> Router Class Initialized
INFO - 2023-10-08 02:00:16 --> Output Class Initialized
INFO - 2023-10-08 02:00:16 --> Security Class Initialized
DEBUG - 2023-10-08 02:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:00:16 --> Input Class Initialized
INFO - 2023-10-08 02:00:16 --> Language Class Initialized
INFO - 2023-10-08 02:00:16 --> Loader Class Initialized
INFO - 2023-10-08 02:00:16 --> Helper loaded: url_helper
INFO - 2023-10-08 02:00:16 --> Helper loaded: file_helper
INFO - 2023-10-08 02:00:16 --> Helper loaded: html_helper
INFO - 2023-10-08 02:00:16 --> Helper loaded: text_helper
INFO - 2023-10-08 02:00:16 --> Helper loaded: form_helper
INFO - 2023-10-08 02:00:16 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:00:16 --> Helper loaded: security_helper
INFO - 2023-10-08 02:00:16 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:00:16 --> Database Driver Class Initialized
INFO - 2023-10-08 02:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:00:16 --> Parser Class Initialized
INFO - 2023-10-08 02:00:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:00:16 --> Pagination Class Initialized
INFO - 2023-10-08 02:00:16 --> Form Validation Class Initialized
INFO - 2023-10-08 02:00:16 --> Controller Class Initialized
INFO - 2023-10-08 02:00:16 --> Model Class Initialized
DEBUG - 2023-10-08 02:00:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 02:00:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-08 02:00:16 --> Final output sent to browser
DEBUG - 2023-10-08 02:00:16 --> Total execution time: 0.0155
ERROR - 2023-10-08 02:00:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:00:19 --> Config Class Initialized
INFO - 2023-10-08 02:00:19 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:00:19 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:00:19 --> Utf8 Class Initialized
INFO - 2023-10-08 02:00:19 --> URI Class Initialized
INFO - 2023-10-08 02:00:19 --> Router Class Initialized
INFO - 2023-10-08 02:00:19 --> Output Class Initialized
INFO - 2023-10-08 02:00:19 --> Security Class Initialized
DEBUG - 2023-10-08 02:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:00:19 --> Input Class Initialized
INFO - 2023-10-08 02:00:19 --> Language Class Initialized
INFO - 2023-10-08 02:00:19 --> Loader Class Initialized
INFO - 2023-10-08 02:00:19 --> Helper loaded: url_helper
INFO - 2023-10-08 02:00:19 --> Helper loaded: file_helper
INFO - 2023-10-08 02:00:19 --> Helper loaded: html_helper
INFO - 2023-10-08 02:00:19 --> Helper loaded: text_helper
INFO - 2023-10-08 02:00:19 --> Helper loaded: form_helper
INFO - 2023-10-08 02:00:19 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:00:19 --> Helper loaded: security_helper
INFO - 2023-10-08 02:00:19 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:00:19 --> Database Driver Class Initialized
INFO - 2023-10-08 02:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:00:19 --> Parser Class Initialized
INFO - 2023-10-08 02:00:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:00:19 --> Pagination Class Initialized
INFO - 2023-10-08 02:00:19 --> Form Validation Class Initialized
INFO - 2023-10-08 02:00:19 --> Controller Class Initialized
INFO - 2023-10-08 02:00:19 --> Model Class Initialized
DEBUG - 2023-10-08 02:00:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 02:00:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-08 02:00:19 --> Final output sent to browser
DEBUG - 2023-10-08 02:00:19 --> Total execution time: 0.0153
ERROR - 2023-10-08 02:00:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:00:33 --> Config Class Initialized
INFO - 2023-10-08 02:00:33 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:00:33 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:00:33 --> Utf8 Class Initialized
INFO - 2023-10-08 02:00:33 --> URI Class Initialized
INFO - 2023-10-08 02:00:33 --> Router Class Initialized
INFO - 2023-10-08 02:00:33 --> Output Class Initialized
INFO - 2023-10-08 02:00:33 --> Security Class Initialized
DEBUG - 2023-10-08 02:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:00:33 --> Input Class Initialized
INFO - 2023-10-08 02:00:33 --> Language Class Initialized
INFO - 2023-10-08 02:00:33 --> Loader Class Initialized
INFO - 2023-10-08 02:00:33 --> Helper loaded: url_helper
INFO - 2023-10-08 02:00:33 --> Helper loaded: file_helper
INFO - 2023-10-08 02:00:33 --> Helper loaded: html_helper
INFO - 2023-10-08 02:00:33 --> Helper loaded: text_helper
INFO - 2023-10-08 02:00:33 --> Helper loaded: form_helper
INFO - 2023-10-08 02:00:33 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:00:33 --> Helper loaded: security_helper
INFO - 2023-10-08 02:00:33 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:00:33 --> Database Driver Class Initialized
INFO - 2023-10-08 02:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:00:33 --> Parser Class Initialized
INFO - 2023-10-08 02:00:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:00:33 --> Pagination Class Initialized
INFO - 2023-10-08 02:00:33 --> Form Validation Class Initialized
INFO - 2023-10-08 02:00:33 --> Controller Class Initialized
INFO - 2023-10-08 02:00:33 --> Model Class Initialized
DEBUG - 2023-10-08 02:00:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 02:00:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-08 02:00:33 --> Final output sent to browser
DEBUG - 2023-10-08 02:00:33 --> Total execution time: 0.0177
ERROR - 2023-10-08 02:00:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:00:35 --> Config Class Initialized
INFO - 2023-10-08 02:00:35 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:00:35 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:00:35 --> Utf8 Class Initialized
INFO - 2023-10-08 02:00:35 --> URI Class Initialized
INFO - 2023-10-08 02:00:35 --> Router Class Initialized
INFO - 2023-10-08 02:00:35 --> Output Class Initialized
INFO - 2023-10-08 02:00:35 --> Security Class Initialized
DEBUG - 2023-10-08 02:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:00:35 --> Input Class Initialized
INFO - 2023-10-08 02:00:35 --> Language Class Initialized
INFO - 2023-10-08 02:00:35 --> Loader Class Initialized
INFO - 2023-10-08 02:00:35 --> Helper loaded: url_helper
INFO - 2023-10-08 02:00:35 --> Helper loaded: file_helper
INFO - 2023-10-08 02:00:35 --> Helper loaded: html_helper
INFO - 2023-10-08 02:00:35 --> Helper loaded: text_helper
INFO - 2023-10-08 02:00:35 --> Helper loaded: form_helper
INFO - 2023-10-08 02:00:35 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:00:35 --> Helper loaded: security_helper
INFO - 2023-10-08 02:00:35 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:00:35 --> Database Driver Class Initialized
INFO - 2023-10-08 02:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:00:35 --> Parser Class Initialized
INFO - 2023-10-08 02:00:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:00:35 --> Pagination Class Initialized
INFO - 2023-10-08 02:00:35 --> Form Validation Class Initialized
INFO - 2023-10-08 02:00:35 --> Controller Class Initialized
INFO - 2023-10-08 02:00:35 --> Model Class Initialized
DEBUG - 2023-10-08 02:00:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 02:00:35 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-08 02:00:35 --> Final output sent to browser
DEBUG - 2023-10-08 02:00:35 --> Total execution time: 0.0166
ERROR - 2023-10-08 02:00:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:00:38 --> Config Class Initialized
INFO - 2023-10-08 02:00:38 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:00:38 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:00:38 --> Utf8 Class Initialized
INFO - 2023-10-08 02:00:38 --> URI Class Initialized
INFO - 2023-10-08 02:00:38 --> Router Class Initialized
INFO - 2023-10-08 02:00:38 --> Output Class Initialized
INFO - 2023-10-08 02:00:38 --> Security Class Initialized
DEBUG - 2023-10-08 02:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:00:38 --> Input Class Initialized
INFO - 2023-10-08 02:00:38 --> Language Class Initialized
INFO - 2023-10-08 02:00:38 --> Loader Class Initialized
INFO - 2023-10-08 02:00:38 --> Helper loaded: url_helper
INFO - 2023-10-08 02:00:38 --> Helper loaded: file_helper
INFO - 2023-10-08 02:00:38 --> Helper loaded: html_helper
INFO - 2023-10-08 02:00:38 --> Helper loaded: text_helper
INFO - 2023-10-08 02:00:38 --> Helper loaded: form_helper
INFO - 2023-10-08 02:00:38 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:00:38 --> Helper loaded: security_helper
INFO - 2023-10-08 02:00:38 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:00:38 --> Database Driver Class Initialized
INFO - 2023-10-08 02:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:00:38 --> Parser Class Initialized
INFO - 2023-10-08 02:00:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:00:38 --> Pagination Class Initialized
INFO - 2023-10-08 02:00:38 --> Form Validation Class Initialized
INFO - 2023-10-08 02:00:38 --> Controller Class Initialized
INFO - 2023-10-08 02:00:38 --> Model Class Initialized
DEBUG - 2023-10-08 02:00:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 02:00:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-08 02:00:38 --> Final output sent to browser
DEBUG - 2023-10-08 02:00:38 --> Total execution time: 0.0161
ERROR - 2023-10-08 02:00:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:00:39 --> Config Class Initialized
INFO - 2023-10-08 02:00:39 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:00:39 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:00:39 --> Utf8 Class Initialized
INFO - 2023-10-08 02:00:39 --> URI Class Initialized
INFO - 2023-10-08 02:00:39 --> Router Class Initialized
INFO - 2023-10-08 02:00:39 --> Output Class Initialized
INFO - 2023-10-08 02:00:39 --> Security Class Initialized
DEBUG - 2023-10-08 02:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:00:39 --> Input Class Initialized
INFO - 2023-10-08 02:00:39 --> Language Class Initialized
INFO - 2023-10-08 02:00:39 --> Loader Class Initialized
INFO - 2023-10-08 02:00:39 --> Helper loaded: url_helper
INFO - 2023-10-08 02:00:39 --> Helper loaded: file_helper
INFO - 2023-10-08 02:00:39 --> Helper loaded: html_helper
INFO - 2023-10-08 02:00:39 --> Helper loaded: text_helper
INFO - 2023-10-08 02:00:39 --> Helper loaded: form_helper
INFO - 2023-10-08 02:00:39 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:00:39 --> Helper loaded: security_helper
INFO - 2023-10-08 02:00:39 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:00:39 --> Database Driver Class Initialized
INFO - 2023-10-08 02:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:00:39 --> Parser Class Initialized
INFO - 2023-10-08 02:00:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:00:39 --> Pagination Class Initialized
INFO - 2023-10-08 02:00:39 --> Form Validation Class Initialized
INFO - 2023-10-08 02:00:39 --> Controller Class Initialized
INFO - 2023-10-08 02:00:39 --> Model Class Initialized
DEBUG - 2023-10-08 02:00:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 02:00:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-08 02:00:39 --> Final output sent to browser
DEBUG - 2023-10-08 02:00:39 --> Total execution time: 0.0150
ERROR - 2023-10-08 02:01:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:01:12 --> Config Class Initialized
INFO - 2023-10-08 02:01:12 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:01:12 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:01:12 --> Utf8 Class Initialized
INFO - 2023-10-08 02:01:12 --> URI Class Initialized
INFO - 2023-10-08 02:01:12 --> Router Class Initialized
INFO - 2023-10-08 02:01:12 --> Output Class Initialized
INFO - 2023-10-08 02:01:12 --> Security Class Initialized
DEBUG - 2023-10-08 02:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:01:12 --> Input Class Initialized
INFO - 2023-10-08 02:01:12 --> Language Class Initialized
INFO - 2023-10-08 02:01:12 --> Loader Class Initialized
INFO - 2023-10-08 02:01:12 --> Helper loaded: url_helper
INFO - 2023-10-08 02:01:12 --> Helper loaded: file_helper
INFO - 2023-10-08 02:01:12 --> Helper loaded: html_helper
INFO - 2023-10-08 02:01:12 --> Helper loaded: text_helper
INFO - 2023-10-08 02:01:12 --> Helper loaded: form_helper
INFO - 2023-10-08 02:01:12 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:01:12 --> Helper loaded: security_helper
INFO - 2023-10-08 02:01:12 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:01:12 --> Database Driver Class Initialized
INFO - 2023-10-08 02:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:01:12 --> Parser Class Initialized
INFO - 2023-10-08 02:01:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:01:12 --> Pagination Class Initialized
INFO - 2023-10-08 02:01:12 --> Form Validation Class Initialized
INFO - 2023-10-08 02:01:12 --> Controller Class Initialized
INFO - 2023-10-08 02:01:12 --> Model Class Initialized
DEBUG - 2023-10-08 02:01:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 02:01:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-08 02:01:12 --> Final output sent to browser
DEBUG - 2023-10-08 02:01:12 --> Total execution time: 0.0179
ERROR - 2023-10-08 02:01:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:01:16 --> Config Class Initialized
INFO - 2023-10-08 02:01:16 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:01:16 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:01:16 --> Utf8 Class Initialized
INFO - 2023-10-08 02:01:16 --> URI Class Initialized
INFO - 2023-10-08 02:01:16 --> Router Class Initialized
INFO - 2023-10-08 02:01:16 --> Output Class Initialized
INFO - 2023-10-08 02:01:16 --> Security Class Initialized
DEBUG - 2023-10-08 02:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:01:16 --> Input Class Initialized
INFO - 2023-10-08 02:01:16 --> Language Class Initialized
INFO - 2023-10-08 02:01:16 --> Loader Class Initialized
INFO - 2023-10-08 02:01:16 --> Helper loaded: url_helper
INFO - 2023-10-08 02:01:16 --> Helper loaded: file_helper
INFO - 2023-10-08 02:01:16 --> Helper loaded: html_helper
INFO - 2023-10-08 02:01:16 --> Helper loaded: text_helper
INFO - 2023-10-08 02:01:16 --> Helper loaded: form_helper
INFO - 2023-10-08 02:01:16 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:01:16 --> Helper loaded: security_helper
INFO - 2023-10-08 02:01:16 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:01:16 --> Database Driver Class Initialized
INFO - 2023-10-08 02:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:01:16 --> Parser Class Initialized
INFO - 2023-10-08 02:01:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:01:16 --> Pagination Class Initialized
INFO - 2023-10-08 02:01:16 --> Form Validation Class Initialized
INFO - 2023-10-08 02:01:16 --> Controller Class Initialized
INFO - 2023-10-08 02:01:16 --> Model Class Initialized
DEBUG - 2023-10-08 02:01:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 02:01:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-08 02:01:16 --> Final output sent to browser
DEBUG - 2023-10-08 02:01:16 --> Total execution time: 0.0162
ERROR - 2023-10-08 02:01:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:01:50 --> Config Class Initialized
INFO - 2023-10-08 02:01:50 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:01:50 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:01:50 --> Utf8 Class Initialized
INFO - 2023-10-08 02:01:50 --> URI Class Initialized
INFO - 2023-10-08 02:01:50 --> Router Class Initialized
INFO - 2023-10-08 02:01:50 --> Output Class Initialized
INFO - 2023-10-08 02:01:50 --> Security Class Initialized
DEBUG - 2023-10-08 02:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:01:50 --> Input Class Initialized
INFO - 2023-10-08 02:01:50 --> Language Class Initialized
INFO - 2023-10-08 02:01:50 --> Loader Class Initialized
INFO - 2023-10-08 02:01:50 --> Helper loaded: url_helper
INFO - 2023-10-08 02:01:50 --> Helper loaded: file_helper
INFO - 2023-10-08 02:01:50 --> Helper loaded: html_helper
INFO - 2023-10-08 02:01:50 --> Helper loaded: text_helper
INFO - 2023-10-08 02:01:50 --> Helper loaded: form_helper
INFO - 2023-10-08 02:01:50 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:01:50 --> Helper loaded: security_helper
INFO - 2023-10-08 02:01:50 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:01:50 --> Database Driver Class Initialized
INFO - 2023-10-08 02:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:01:50 --> Parser Class Initialized
INFO - 2023-10-08 02:01:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:01:50 --> Pagination Class Initialized
INFO - 2023-10-08 02:01:50 --> Form Validation Class Initialized
INFO - 2023-10-08 02:01:50 --> Controller Class Initialized
INFO - 2023-10-08 02:01:50 --> Model Class Initialized
DEBUG - 2023-10-08 02:01:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 02:01:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-08 02:01:50 --> Final output sent to browser
DEBUG - 2023-10-08 02:01:50 --> Total execution time: 0.0189
ERROR - 2023-10-08 02:01:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:01:50 --> Config Class Initialized
INFO - 2023-10-08 02:01:50 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:01:50 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:01:50 --> Utf8 Class Initialized
INFO - 2023-10-08 02:01:50 --> URI Class Initialized
INFO - 2023-10-08 02:01:50 --> Router Class Initialized
INFO - 2023-10-08 02:01:50 --> Output Class Initialized
INFO - 2023-10-08 02:01:50 --> Security Class Initialized
DEBUG - 2023-10-08 02:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:01:50 --> Input Class Initialized
INFO - 2023-10-08 02:01:50 --> Language Class Initialized
INFO - 2023-10-08 02:01:50 --> Loader Class Initialized
INFO - 2023-10-08 02:01:50 --> Helper loaded: url_helper
INFO - 2023-10-08 02:01:50 --> Helper loaded: file_helper
INFO - 2023-10-08 02:01:50 --> Helper loaded: html_helper
INFO - 2023-10-08 02:01:50 --> Helper loaded: text_helper
INFO - 2023-10-08 02:01:50 --> Helper loaded: form_helper
INFO - 2023-10-08 02:01:50 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:01:50 --> Helper loaded: security_helper
INFO - 2023-10-08 02:01:50 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:01:50 --> Database Driver Class Initialized
INFO - 2023-10-08 02:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:01:50 --> Parser Class Initialized
INFO - 2023-10-08 02:01:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:01:50 --> Pagination Class Initialized
INFO - 2023-10-08 02:01:50 --> Form Validation Class Initialized
INFO - 2023-10-08 02:01:50 --> Controller Class Initialized
INFO - 2023-10-08 02:01:50 --> Model Class Initialized
DEBUG - 2023-10-08 02:01:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 02:01:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-08 02:01:50 --> Final output sent to browser
DEBUG - 2023-10-08 02:01:50 --> Total execution time: 0.0156
ERROR - 2023-10-08 02:01:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:01:55 --> Config Class Initialized
INFO - 2023-10-08 02:01:55 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:01:55 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:01:55 --> Utf8 Class Initialized
INFO - 2023-10-08 02:01:55 --> URI Class Initialized
INFO - 2023-10-08 02:01:55 --> Router Class Initialized
INFO - 2023-10-08 02:01:55 --> Output Class Initialized
INFO - 2023-10-08 02:01:55 --> Security Class Initialized
DEBUG - 2023-10-08 02:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:01:55 --> Input Class Initialized
INFO - 2023-10-08 02:01:55 --> Language Class Initialized
INFO - 2023-10-08 02:01:55 --> Loader Class Initialized
INFO - 2023-10-08 02:01:55 --> Helper loaded: url_helper
INFO - 2023-10-08 02:01:55 --> Helper loaded: file_helper
INFO - 2023-10-08 02:01:55 --> Helper loaded: html_helper
INFO - 2023-10-08 02:01:55 --> Helper loaded: text_helper
INFO - 2023-10-08 02:01:55 --> Helper loaded: form_helper
INFO - 2023-10-08 02:01:55 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:01:55 --> Helper loaded: security_helper
INFO - 2023-10-08 02:01:55 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:01:55 --> Database Driver Class Initialized
INFO - 2023-10-08 02:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:01:55 --> Parser Class Initialized
INFO - 2023-10-08 02:01:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:01:55 --> Pagination Class Initialized
INFO - 2023-10-08 02:01:55 --> Form Validation Class Initialized
INFO - 2023-10-08 02:01:55 --> Controller Class Initialized
INFO - 2023-10-08 02:01:55 --> Model Class Initialized
DEBUG - 2023-10-08 02:01:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 02:01:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-08 02:01:55 --> Final output sent to browser
DEBUG - 2023-10-08 02:01:55 --> Total execution time: 0.0164
ERROR - 2023-10-08 02:01:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:01:56 --> Config Class Initialized
INFO - 2023-10-08 02:01:56 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:01:56 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:01:56 --> Utf8 Class Initialized
INFO - 2023-10-08 02:01:56 --> URI Class Initialized
INFO - 2023-10-08 02:01:56 --> Router Class Initialized
INFO - 2023-10-08 02:01:56 --> Output Class Initialized
INFO - 2023-10-08 02:01:56 --> Security Class Initialized
DEBUG - 2023-10-08 02:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:01:56 --> Input Class Initialized
INFO - 2023-10-08 02:01:56 --> Language Class Initialized
INFO - 2023-10-08 02:01:56 --> Loader Class Initialized
INFO - 2023-10-08 02:01:56 --> Helper loaded: url_helper
INFO - 2023-10-08 02:01:56 --> Helper loaded: file_helper
INFO - 2023-10-08 02:01:56 --> Helper loaded: html_helper
INFO - 2023-10-08 02:01:56 --> Helper loaded: text_helper
INFO - 2023-10-08 02:01:56 --> Helper loaded: form_helper
INFO - 2023-10-08 02:01:56 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:01:56 --> Helper loaded: security_helper
INFO - 2023-10-08 02:01:56 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:01:56 --> Database Driver Class Initialized
INFO - 2023-10-08 02:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:01:56 --> Parser Class Initialized
INFO - 2023-10-08 02:01:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:01:56 --> Pagination Class Initialized
INFO - 2023-10-08 02:01:56 --> Form Validation Class Initialized
INFO - 2023-10-08 02:01:56 --> Controller Class Initialized
INFO - 2023-10-08 02:01:56 --> Model Class Initialized
DEBUG - 2023-10-08 02:01:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 02:01:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-08 02:01:56 --> Final output sent to browser
DEBUG - 2023-10-08 02:01:56 --> Total execution time: 0.0153
ERROR - 2023-10-08 02:01:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:01:57 --> Config Class Initialized
INFO - 2023-10-08 02:01:57 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:01:57 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:01:57 --> Utf8 Class Initialized
INFO - 2023-10-08 02:01:57 --> URI Class Initialized
INFO - 2023-10-08 02:01:57 --> Router Class Initialized
INFO - 2023-10-08 02:01:57 --> Output Class Initialized
INFO - 2023-10-08 02:01:57 --> Security Class Initialized
DEBUG - 2023-10-08 02:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:01:57 --> Input Class Initialized
INFO - 2023-10-08 02:01:57 --> Language Class Initialized
INFO - 2023-10-08 02:01:57 --> Loader Class Initialized
INFO - 2023-10-08 02:01:57 --> Helper loaded: url_helper
INFO - 2023-10-08 02:01:57 --> Helper loaded: file_helper
INFO - 2023-10-08 02:01:57 --> Helper loaded: html_helper
INFO - 2023-10-08 02:01:57 --> Helper loaded: text_helper
INFO - 2023-10-08 02:01:57 --> Helper loaded: form_helper
INFO - 2023-10-08 02:01:57 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:01:57 --> Helper loaded: security_helper
INFO - 2023-10-08 02:01:57 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:01:57 --> Database Driver Class Initialized
INFO - 2023-10-08 02:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:01:57 --> Parser Class Initialized
INFO - 2023-10-08 02:01:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:01:57 --> Pagination Class Initialized
INFO - 2023-10-08 02:01:57 --> Form Validation Class Initialized
INFO - 2023-10-08 02:01:57 --> Controller Class Initialized
INFO - 2023-10-08 02:01:57 --> Model Class Initialized
DEBUG - 2023-10-08 02:01:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 02:01:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-08 02:01:57 --> Final output sent to browser
DEBUG - 2023-10-08 02:01:57 --> Total execution time: 0.0171
ERROR - 2023-10-08 02:02:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:02:00 --> Config Class Initialized
INFO - 2023-10-08 02:02:00 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:02:00 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:02:00 --> Utf8 Class Initialized
INFO - 2023-10-08 02:02:00 --> URI Class Initialized
INFO - 2023-10-08 02:02:00 --> Router Class Initialized
INFO - 2023-10-08 02:02:00 --> Output Class Initialized
INFO - 2023-10-08 02:02:00 --> Security Class Initialized
DEBUG - 2023-10-08 02:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:02:00 --> Input Class Initialized
INFO - 2023-10-08 02:02:00 --> Language Class Initialized
INFO - 2023-10-08 02:02:00 --> Loader Class Initialized
INFO - 2023-10-08 02:02:00 --> Helper loaded: url_helper
INFO - 2023-10-08 02:02:00 --> Helper loaded: file_helper
INFO - 2023-10-08 02:02:00 --> Helper loaded: html_helper
INFO - 2023-10-08 02:02:00 --> Helper loaded: text_helper
INFO - 2023-10-08 02:02:00 --> Helper loaded: form_helper
INFO - 2023-10-08 02:02:00 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:02:00 --> Helper loaded: security_helper
INFO - 2023-10-08 02:02:00 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:02:00 --> Database Driver Class Initialized
INFO - 2023-10-08 02:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:02:00 --> Parser Class Initialized
INFO - 2023-10-08 02:02:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:02:00 --> Pagination Class Initialized
INFO - 2023-10-08 02:02:00 --> Form Validation Class Initialized
INFO - 2023-10-08 02:02:00 --> Controller Class Initialized
INFO - 2023-10-08 02:02:00 --> Model Class Initialized
DEBUG - 2023-10-08 02:02:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 02:02:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-08 02:02:00 --> Final output sent to browser
DEBUG - 2023-10-08 02:02:00 --> Total execution time: 0.0151
ERROR - 2023-10-08 02:02:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:02:16 --> Config Class Initialized
INFO - 2023-10-08 02:02:16 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:02:16 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:02:16 --> Utf8 Class Initialized
INFO - 2023-10-08 02:02:16 --> URI Class Initialized
INFO - 2023-10-08 02:02:16 --> Router Class Initialized
INFO - 2023-10-08 02:02:16 --> Output Class Initialized
INFO - 2023-10-08 02:02:16 --> Security Class Initialized
DEBUG - 2023-10-08 02:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:02:16 --> Input Class Initialized
INFO - 2023-10-08 02:02:16 --> Language Class Initialized
INFO - 2023-10-08 02:02:16 --> Loader Class Initialized
INFO - 2023-10-08 02:02:16 --> Helper loaded: url_helper
INFO - 2023-10-08 02:02:16 --> Helper loaded: file_helper
INFO - 2023-10-08 02:02:16 --> Helper loaded: html_helper
INFO - 2023-10-08 02:02:16 --> Helper loaded: text_helper
INFO - 2023-10-08 02:02:16 --> Helper loaded: form_helper
INFO - 2023-10-08 02:02:16 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:02:16 --> Helper loaded: security_helper
INFO - 2023-10-08 02:02:16 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:02:16 --> Database Driver Class Initialized
INFO - 2023-10-08 02:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:02:16 --> Parser Class Initialized
INFO - 2023-10-08 02:02:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:02:16 --> Pagination Class Initialized
INFO - 2023-10-08 02:02:16 --> Form Validation Class Initialized
INFO - 2023-10-08 02:02:16 --> Controller Class Initialized
INFO - 2023-10-08 02:02:16 --> Model Class Initialized
DEBUG - 2023-10-08 02:02:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 02:02:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-08 02:02:16 --> Final output sent to browser
DEBUG - 2023-10-08 02:02:16 --> Total execution time: 0.0190
ERROR - 2023-10-08 02:02:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:02:18 --> Config Class Initialized
INFO - 2023-10-08 02:02:18 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:02:18 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:02:18 --> Utf8 Class Initialized
INFO - 2023-10-08 02:02:18 --> URI Class Initialized
INFO - 2023-10-08 02:02:18 --> Router Class Initialized
INFO - 2023-10-08 02:02:18 --> Output Class Initialized
INFO - 2023-10-08 02:02:18 --> Security Class Initialized
DEBUG - 2023-10-08 02:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:02:18 --> Input Class Initialized
INFO - 2023-10-08 02:02:18 --> Language Class Initialized
INFO - 2023-10-08 02:02:18 --> Loader Class Initialized
INFO - 2023-10-08 02:02:18 --> Helper loaded: url_helper
INFO - 2023-10-08 02:02:18 --> Helper loaded: file_helper
INFO - 2023-10-08 02:02:18 --> Helper loaded: html_helper
INFO - 2023-10-08 02:02:18 --> Helper loaded: text_helper
INFO - 2023-10-08 02:02:18 --> Helper loaded: form_helper
INFO - 2023-10-08 02:02:18 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:02:18 --> Helper loaded: security_helper
INFO - 2023-10-08 02:02:18 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:02:18 --> Database Driver Class Initialized
INFO - 2023-10-08 02:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:02:18 --> Parser Class Initialized
INFO - 2023-10-08 02:02:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:02:18 --> Pagination Class Initialized
INFO - 2023-10-08 02:02:18 --> Form Validation Class Initialized
INFO - 2023-10-08 02:02:18 --> Controller Class Initialized
INFO - 2023-10-08 02:02:18 --> Model Class Initialized
DEBUG - 2023-10-08 02:02:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:02:18 --> Final output sent to browser
DEBUG - 2023-10-08 02:02:18 --> Total execution time: 0.0167
ERROR - 2023-10-08 02:02:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:02:31 --> Config Class Initialized
INFO - 2023-10-08 02:02:31 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:02:31 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:02:31 --> Utf8 Class Initialized
INFO - 2023-10-08 02:02:31 --> URI Class Initialized
INFO - 2023-10-08 02:02:31 --> Router Class Initialized
INFO - 2023-10-08 02:02:31 --> Output Class Initialized
INFO - 2023-10-08 02:02:31 --> Security Class Initialized
DEBUG - 2023-10-08 02:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:02:31 --> Input Class Initialized
INFO - 2023-10-08 02:02:31 --> Language Class Initialized
INFO - 2023-10-08 02:02:31 --> Loader Class Initialized
INFO - 2023-10-08 02:02:31 --> Helper loaded: url_helper
INFO - 2023-10-08 02:02:31 --> Helper loaded: file_helper
INFO - 2023-10-08 02:02:31 --> Helper loaded: html_helper
INFO - 2023-10-08 02:02:31 --> Helper loaded: text_helper
INFO - 2023-10-08 02:02:31 --> Helper loaded: form_helper
INFO - 2023-10-08 02:02:31 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:02:31 --> Helper loaded: security_helper
INFO - 2023-10-08 02:02:31 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:02:31 --> Database Driver Class Initialized
INFO - 2023-10-08 02:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:02:31 --> Parser Class Initialized
INFO - 2023-10-08 02:02:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:02:31 --> Pagination Class Initialized
INFO - 2023-10-08 02:02:31 --> Form Validation Class Initialized
INFO - 2023-10-08 02:02:31 --> Controller Class Initialized
INFO - 2023-10-08 02:02:31 --> Final output sent to browser
DEBUG - 2023-10-08 02:02:31 --> Total execution time: 0.0173
ERROR - 2023-10-08 02:02:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:02:39 --> Config Class Initialized
INFO - 2023-10-08 02:02:39 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:02:39 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:02:39 --> Utf8 Class Initialized
INFO - 2023-10-08 02:02:39 --> URI Class Initialized
INFO - 2023-10-08 02:02:39 --> Router Class Initialized
INFO - 2023-10-08 02:02:39 --> Output Class Initialized
INFO - 2023-10-08 02:02:39 --> Security Class Initialized
DEBUG - 2023-10-08 02:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:02:39 --> Input Class Initialized
INFO - 2023-10-08 02:02:39 --> Language Class Initialized
INFO - 2023-10-08 02:02:39 --> Loader Class Initialized
INFO - 2023-10-08 02:02:39 --> Helper loaded: url_helper
INFO - 2023-10-08 02:02:39 --> Helper loaded: file_helper
INFO - 2023-10-08 02:02:39 --> Helper loaded: html_helper
INFO - 2023-10-08 02:02:39 --> Helper loaded: text_helper
INFO - 2023-10-08 02:02:39 --> Helper loaded: form_helper
INFO - 2023-10-08 02:02:39 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:02:39 --> Helper loaded: security_helper
INFO - 2023-10-08 02:02:39 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:02:39 --> Database Driver Class Initialized
INFO - 2023-10-08 02:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:02:39 --> Parser Class Initialized
INFO - 2023-10-08 02:02:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:02:39 --> Pagination Class Initialized
INFO - 2023-10-08 02:02:39 --> Form Validation Class Initialized
INFO - 2023-10-08 02:02:39 --> Controller Class Initialized
INFO - 2023-10-08 02:02:39 --> Model Class Initialized
DEBUG - 2023-10-08 02:02:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:02:39 --> Final output sent to browser
DEBUG - 2023-10-08 02:02:39 --> Total execution time: 0.0201
ERROR - 2023-10-08 02:03:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:03:33 --> Config Class Initialized
INFO - 2023-10-08 02:03:33 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:03:33 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:03:33 --> Utf8 Class Initialized
INFO - 2023-10-08 02:03:33 --> URI Class Initialized
INFO - 2023-10-08 02:03:33 --> Router Class Initialized
INFO - 2023-10-08 02:03:33 --> Output Class Initialized
INFO - 2023-10-08 02:03:33 --> Security Class Initialized
DEBUG - 2023-10-08 02:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:03:33 --> Input Class Initialized
INFO - 2023-10-08 02:03:33 --> Language Class Initialized
INFO - 2023-10-08 02:03:33 --> Loader Class Initialized
INFO - 2023-10-08 02:03:33 --> Helper loaded: url_helper
INFO - 2023-10-08 02:03:33 --> Helper loaded: file_helper
INFO - 2023-10-08 02:03:33 --> Helper loaded: html_helper
INFO - 2023-10-08 02:03:33 --> Helper loaded: text_helper
INFO - 2023-10-08 02:03:33 --> Helper loaded: form_helper
INFO - 2023-10-08 02:03:33 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:03:33 --> Helper loaded: security_helper
INFO - 2023-10-08 02:03:33 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:03:33 --> Database Driver Class Initialized
INFO - 2023-10-08 02:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:03:33 --> Parser Class Initialized
INFO - 2023-10-08 02:03:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:03:33 --> Pagination Class Initialized
INFO - 2023-10-08 02:03:33 --> Form Validation Class Initialized
INFO - 2023-10-08 02:03:33 --> Controller Class Initialized
INFO - 2023-10-08 02:03:33 --> Model Class Initialized
DEBUG - 2023-10-08 02:03:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:03:33 --> Final output sent to browser
DEBUG - 2023-10-08 02:03:33 --> Total execution time: 0.0199
ERROR - 2023-10-08 02:03:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:03:39 --> Config Class Initialized
INFO - 2023-10-08 02:03:39 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:03:39 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:03:39 --> Utf8 Class Initialized
INFO - 2023-10-08 02:03:39 --> URI Class Initialized
INFO - 2023-10-08 02:03:39 --> Router Class Initialized
INFO - 2023-10-08 02:03:39 --> Output Class Initialized
INFO - 2023-10-08 02:03:39 --> Security Class Initialized
DEBUG - 2023-10-08 02:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:03:39 --> Input Class Initialized
INFO - 2023-10-08 02:03:39 --> Language Class Initialized
INFO - 2023-10-08 02:03:39 --> Loader Class Initialized
INFO - 2023-10-08 02:03:39 --> Helper loaded: url_helper
INFO - 2023-10-08 02:03:39 --> Helper loaded: file_helper
INFO - 2023-10-08 02:03:39 --> Helper loaded: html_helper
INFO - 2023-10-08 02:03:39 --> Helper loaded: text_helper
INFO - 2023-10-08 02:03:39 --> Helper loaded: form_helper
INFO - 2023-10-08 02:03:39 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:03:39 --> Helper loaded: security_helper
INFO - 2023-10-08 02:03:39 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:03:39 --> Database Driver Class Initialized
INFO - 2023-10-08 02:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:03:39 --> Parser Class Initialized
INFO - 2023-10-08 02:03:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:03:39 --> Pagination Class Initialized
INFO - 2023-10-08 02:03:39 --> Form Validation Class Initialized
INFO - 2023-10-08 02:03:39 --> Controller Class Initialized
INFO - 2023-10-08 02:03:39 --> Model Class Initialized
DEBUG - 2023-10-08 02:03:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:03:39 --> Final output sent to browser
DEBUG - 2023-10-08 02:03:39 --> Total execution time: 0.0164
ERROR - 2023-10-08 02:03:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:03:43 --> Config Class Initialized
INFO - 2023-10-08 02:03:43 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:03:43 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:03:43 --> Utf8 Class Initialized
INFO - 2023-10-08 02:03:43 --> URI Class Initialized
INFO - 2023-10-08 02:03:43 --> Router Class Initialized
INFO - 2023-10-08 02:03:43 --> Output Class Initialized
INFO - 2023-10-08 02:03:43 --> Security Class Initialized
DEBUG - 2023-10-08 02:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:03:43 --> Input Class Initialized
INFO - 2023-10-08 02:03:43 --> Language Class Initialized
INFO - 2023-10-08 02:03:43 --> Loader Class Initialized
INFO - 2023-10-08 02:03:43 --> Helper loaded: url_helper
INFO - 2023-10-08 02:03:43 --> Helper loaded: file_helper
INFO - 2023-10-08 02:03:43 --> Helper loaded: html_helper
INFO - 2023-10-08 02:03:43 --> Helper loaded: text_helper
INFO - 2023-10-08 02:03:43 --> Helper loaded: form_helper
INFO - 2023-10-08 02:03:43 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:03:43 --> Helper loaded: security_helper
INFO - 2023-10-08 02:03:43 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:03:43 --> Database Driver Class Initialized
INFO - 2023-10-08 02:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:03:43 --> Parser Class Initialized
INFO - 2023-10-08 02:03:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:03:43 --> Pagination Class Initialized
INFO - 2023-10-08 02:03:43 --> Form Validation Class Initialized
INFO - 2023-10-08 02:03:43 --> Controller Class Initialized
INFO - 2023-10-08 02:03:43 --> Model Class Initialized
DEBUG - 2023-10-08 02:03:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:03:43 --> Final output sent to browser
DEBUG - 2023-10-08 02:03:43 --> Total execution time: 0.0214
ERROR - 2023-10-08 02:03:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:03:44 --> Config Class Initialized
INFO - 2023-10-08 02:03:44 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:03:44 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:03:44 --> Utf8 Class Initialized
INFO - 2023-10-08 02:03:44 --> URI Class Initialized
INFO - 2023-10-08 02:03:44 --> Router Class Initialized
INFO - 2023-10-08 02:03:44 --> Output Class Initialized
INFO - 2023-10-08 02:03:44 --> Security Class Initialized
DEBUG - 2023-10-08 02:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:03:44 --> Input Class Initialized
INFO - 2023-10-08 02:03:44 --> Language Class Initialized
INFO - 2023-10-08 02:03:44 --> Loader Class Initialized
INFO - 2023-10-08 02:03:44 --> Helper loaded: url_helper
INFO - 2023-10-08 02:03:44 --> Helper loaded: file_helper
INFO - 2023-10-08 02:03:44 --> Helper loaded: html_helper
INFO - 2023-10-08 02:03:44 --> Helper loaded: text_helper
INFO - 2023-10-08 02:03:44 --> Helper loaded: form_helper
INFO - 2023-10-08 02:03:44 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:03:44 --> Helper loaded: security_helper
INFO - 2023-10-08 02:03:44 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:03:44 --> Database Driver Class Initialized
INFO - 2023-10-08 02:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:03:44 --> Parser Class Initialized
INFO - 2023-10-08 02:03:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:03:44 --> Pagination Class Initialized
INFO - 2023-10-08 02:03:44 --> Form Validation Class Initialized
INFO - 2023-10-08 02:03:44 --> Controller Class Initialized
INFO - 2023-10-08 02:03:44 --> Model Class Initialized
DEBUG - 2023-10-08 02:03:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 02:03:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-08 02:03:44 --> Final output sent to browser
DEBUG - 2023-10-08 02:03:44 --> Total execution time: 0.0201
ERROR - 2023-10-08 02:03:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:03:49 --> Config Class Initialized
INFO - 2023-10-08 02:03:49 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:03:49 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:03:49 --> Utf8 Class Initialized
INFO - 2023-10-08 02:03:49 --> URI Class Initialized
INFO - 2023-10-08 02:03:49 --> Router Class Initialized
INFO - 2023-10-08 02:03:49 --> Output Class Initialized
INFO - 2023-10-08 02:03:49 --> Security Class Initialized
DEBUG - 2023-10-08 02:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:03:49 --> Input Class Initialized
INFO - 2023-10-08 02:03:49 --> Language Class Initialized
INFO - 2023-10-08 02:03:49 --> Loader Class Initialized
INFO - 2023-10-08 02:03:49 --> Helper loaded: url_helper
INFO - 2023-10-08 02:03:49 --> Helper loaded: file_helper
INFO - 2023-10-08 02:03:49 --> Helper loaded: html_helper
INFO - 2023-10-08 02:03:49 --> Helper loaded: text_helper
INFO - 2023-10-08 02:03:49 --> Helper loaded: form_helper
INFO - 2023-10-08 02:03:49 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:03:49 --> Helper loaded: security_helper
INFO - 2023-10-08 02:03:49 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:03:49 --> Database Driver Class Initialized
INFO - 2023-10-08 02:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:03:49 --> Parser Class Initialized
INFO - 2023-10-08 02:03:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:03:49 --> Pagination Class Initialized
INFO - 2023-10-08 02:03:49 --> Form Validation Class Initialized
INFO - 2023-10-08 02:03:49 --> Controller Class Initialized
INFO - 2023-10-08 02:03:49 --> Model Class Initialized
DEBUG - 2023-10-08 02:03:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 02:03:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-08 02:03:49 --> Final output sent to browser
DEBUG - 2023-10-08 02:03:49 --> Total execution time: 0.0195
ERROR - 2023-10-08 02:03:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:03:52 --> Config Class Initialized
INFO - 2023-10-08 02:03:52 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:03:52 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:03:52 --> Utf8 Class Initialized
INFO - 2023-10-08 02:03:52 --> URI Class Initialized
INFO - 2023-10-08 02:03:52 --> Router Class Initialized
INFO - 2023-10-08 02:03:52 --> Output Class Initialized
INFO - 2023-10-08 02:03:52 --> Security Class Initialized
DEBUG - 2023-10-08 02:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:03:52 --> Input Class Initialized
INFO - 2023-10-08 02:03:52 --> Language Class Initialized
INFO - 2023-10-08 02:03:52 --> Loader Class Initialized
INFO - 2023-10-08 02:03:52 --> Helper loaded: url_helper
INFO - 2023-10-08 02:03:52 --> Helper loaded: file_helper
INFO - 2023-10-08 02:03:52 --> Helper loaded: html_helper
INFO - 2023-10-08 02:03:52 --> Helper loaded: text_helper
INFO - 2023-10-08 02:03:52 --> Helper loaded: form_helper
INFO - 2023-10-08 02:03:52 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:03:52 --> Helper loaded: security_helper
INFO - 2023-10-08 02:03:52 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:03:52 --> Database Driver Class Initialized
INFO - 2023-10-08 02:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:03:52 --> Parser Class Initialized
INFO - 2023-10-08 02:03:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:03:52 --> Pagination Class Initialized
INFO - 2023-10-08 02:03:52 --> Form Validation Class Initialized
INFO - 2023-10-08 02:03:52 --> Controller Class Initialized
INFO - 2023-10-08 02:03:52 --> Model Class Initialized
DEBUG - 2023-10-08 02:03:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 02:03:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-08 02:03:52 --> Final output sent to browser
DEBUG - 2023-10-08 02:03:52 --> Total execution time: 0.0169
ERROR - 2023-10-08 02:03:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:03:55 --> Config Class Initialized
INFO - 2023-10-08 02:03:55 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:03:55 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:03:55 --> Utf8 Class Initialized
INFO - 2023-10-08 02:03:55 --> URI Class Initialized
INFO - 2023-10-08 02:03:55 --> Router Class Initialized
INFO - 2023-10-08 02:03:55 --> Output Class Initialized
INFO - 2023-10-08 02:03:55 --> Security Class Initialized
DEBUG - 2023-10-08 02:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:03:55 --> Input Class Initialized
INFO - 2023-10-08 02:03:55 --> Language Class Initialized
INFO - 2023-10-08 02:03:55 --> Loader Class Initialized
INFO - 2023-10-08 02:03:55 --> Helper loaded: url_helper
INFO - 2023-10-08 02:03:55 --> Helper loaded: file_helper
INFO - 2023-10-08 02:03:55 --> Helper loaded: html_helper
INFO - 2023-10-08 02:03:55 --> Helper loaded: text_helper
INFO - 2023-10-08 02:03:55 --> Helper loaded: form_helper
INFO - 2023-10-08 02:03:55 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:03:55 --> Helper loaded: security_helper
INFO - 2023-10-08 02:03:55 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:03:55 --> Database Driver Class Initialized
INFO - 2023-10-08 02:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:03:55 --> Parser Class Initialized
INFO - 2023-10-08 02:03:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:03:55 --> Pagination Class Initialized
INFO - 2023-10-08 02:03:55 --> Form Validation Class Initialized
INFO - 2023-10-08 02:03:55 --> Controller Class Initialized
INFO - 2023-10-08 02:03:55 --> Model Class Initialized
DEBUG - 2023-10-08 02:03:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 02:03:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-08 02:03:55 --> Final output sent to browser
DEBUG - 2023-10-08 02:03:55 --> Total execution time: 0.0163
ERROR - 2023-10-08 02:03:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:03:57 --> Config Class Initialized
INFO - 2023-10-08 02:03:57 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:03:57 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:03:57 --> Utf8 Class Initialized
INFO - 2023-10-08 02:03:57 --> URI Class Initialized
INFO - 2023-10-08 02:03:57 --> Router Class Initialized
INFO - 2023-10-08 02:03:58 --> Output Class Initialized
INFO - 2023-10-08 02:03:58 --> Security Class Initialized
DEBUG - 2023-10-08 02:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:03:58 --> Input Class Initialized
INFO - 2023-10-08 02:03:58 --> Language Class Initialized
INFO - 2023-10-08 02:03:58 --> Loader Class Initialized
INFO - 2023-10-08 02:03:58 --> Helper loaded: url_helper
INFO - 2023-10-08 02:03:58 --> Helper loaded: file_helper
INFO - 2023-10-08 02:03:58 --> Helper loaded: html_helper
INFO - 2023-10-08 02:03:58 --> Helper loaded: text_helper
INFO - 2023-10-08 02:03:58 --> Helper loaded: form_helper
INFO - 2023-10-08 02:03:58 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:03:58 --> Helper loaded: security_helper
INFO - 2023-10-08 02:03:58 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:03:58 --> Database Driver Class Initialized
INFO - 2023-10-08 02:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:03:58 --> Parser Class Initialized
INFO - 2023-10-08 02:03:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:03:58 --> Pagination Class Initialized
INFO - 2023-10-08 02:03:58 --> Form Validation Class Initialized
INFO - 2023-10-08 02:03:58 --> Controller Class Initialized
INFO - 2023-10-08 02:03:58 --> Model Class Initialized
DEBUG - 2023-10-08 02:03:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 02:03:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-08 02:03:58 --> Final output sent to browser
DEBUG - 2023-10-08 02:03:58 --> Total execution time: 0.0159
ERROR - 2023-10-08 02:03:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:03:59 --> Config Class Initialized
INFO - 2023-10-08 02:03:59 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:03:59 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:03:59 --> Utf8 Class Initialized
INFO - 2023-10-08 02:03:59 --> URI Class Initialized
INFO - 2023-10-08 02:03:59 --> Router Class Initialized
INFO - 2023-10-08 02:03:59 --> Output Class Initialized
INFO - 2023-10-08 02:03:59 --> Security Class Initialized
DEBUG - 2023-10-08 02:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:03:59 --> Input Class Initialized
INFO - 2023-10-08 02:03:59 --> Language Class Initialized
INFO - 2023-10-08 02:04:00 --> Loader Class Initialized
INFO - 2023-10-08 02:04:00 --> Helper loaded: url_helper
INFO - 2023-10-08 02:04:00 --> Helper loaded: file_helper
INFO - 2023-10-08 02:04:00 --> Helper loaded: html_helper
INFO - 2023-10-08 02:04:00 --> Helper loaded: text_helper
INFO - 2023-10-08 02:04:00 --> Helper loaded: form_helper
INFO - 2023-10-08 02:04:00 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:04:00 --> Helper loaded: security_helper
INFO - 2023-10-08 02:04:00 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:04:00 --> Database Driver Class Initialized
INFO - 2023-10-08 02:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:04:00 --> Parser Class Initialized
INFO - 2023-10-08 02:04:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:04:00 --> Pagination Class Initialized
INFO - 2023-10-08 02:04:00 --> Form Validation Class Initialized
INFO - 2023-10-08 02:04:00 --> Controller Class Initialized
INFO - 2023-10-08 02:04:00 --> Model Class Initialized
DEBUG - 2023-10-08 02:04:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 02:04:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-08 02:04:00 --> Final output sent to browser
DEBUG - 2023-10-08 02:04:00 --> Total execution time: 0.0163
ERROR - 2023-10-08 02:04:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:04:00 --> Config Class Initialized
INFO - 2023-10-08 02:04:00 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:04:00 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:04:00 --> Utf8 Class Initialized
INFO - 2023-10-08 02:04:00 --> URI Class Initialized
INFO - 2023-10-08 02:04:00 --> Router Class Initialized
INFO - 2023-10-08 02:04:00 --> Output Class Initialized
INFO - 2023-10-08 02:04:00 --> Security Class Initialized
DEBUG - 2023-10-08 02:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:04:00 --> Input Class Initialized
INFO - 2023-10-08 02:04:00 --> Language Class Initialized
INFO - 2023-10-08 02:04:00 --> Loader Class Initialized
INFO - 2023-10-08 02:04:00 --> Helper loaded: url_helper
INFO - 2023-10-08 02:04:00 --> Helper loaded: file_helper
INFO - 2023-10-08 02:04:00 --> Helper loaded: html_helper
INFO - 2023-10-08 02:04:00 --> Helper loaded: text_helper
INFO - 2023-10-08 02:04:00 --> Helper loaded: form_helper
INFO - 2023-10-08 02:04:00 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:04:00 --> Helper loaded: security_helper
INFO - 2023-10-08 02:04:00 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:04:00 --> Database Driver Class Initialized
INFO - 2023-10-08 02:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:04:00 --> Parser Class Initialized
INFO - 2023-10-08 02:04:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:04:00 --> Pagination Class Initialized
INFO - 2023-10-08 02:04:00 --> Form Validation Class Initialized
INFO - 2023-10-08 02:04:00 --> Controller Class Initialized
INFO - 2023-10-08 02:04:00 --> Model Class Initialized
DEBUG - 2023-10-08 02:04:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 02:04:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-08 02:04:00 --> Final output sent to browser
DEBUG - 2023-10-08 02:04:00 --> Total execution time: 0.0170
ERROR - 2023-10-08 02:04:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:04:25 --> Config Class Initialized
INFO - 2023-10-08 02:04:25 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:04:25 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:04:25 --> Utf8 Class Initialized
INFO - 2023-10-08 02:04:25 --> URI Class Initialized
INFO - 2023-10-08 02:04:25 --> Router Class Initialized
INFO - 2023-10-08 02:04:25 --> Output Class Initialized
INFO - 2023-10-08 02:04:25 --> Security Class Initialized
DEBUG - 2023-10-08 02:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:04:25 --> Input Class Initialized
INFO - 2023-10-08 02:04:25 --> Language Class Initialized
INFO - 2023-10-08 02:04:25 --> Loader Class Initialized
INFO - 2023-10-08 02:04:25 --> Helper loaded: url_helper
INFO - 2023-10-08 02:04:25 --> Helper loaded: file_helper
INFO - 2023-10-08 02:04:25 --> Helper loaded: html_helper
INFO - 2023-10-08 02:04:25 --> Helper loaded: text_helper
INFO - 2023-10-08 02:04:25 --> Helper loaded: form_helper
INFO - 2023-10-08 02:04:25 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:04:25 --> Helper loaded: security_helper
INFO - 2023-10-08 02:04:25 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:04:25 --> Database Driver Class Initialized
INFO - 2023-10-08 02:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:04:25 --> Parser Class Initialized
INFO - 2023-10-08 02:04:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:04:25 --> Pagination Class Initialized
INFO - 2023-10-08 02:04:25 --> Form Validation Class Initialized
INFO - 2023-10-08 02:04:25 --> Controller Class Initialized
INFO - 2023-10-08 02:04:25 --> Model Class Initialized
DEBUG - 2023-10-08 02:04:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 02:04:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-08 02:04:25 --> Final output sent to browser
DEBUG - 2023-10-08 02:04:25 --> Total execution time: 0.0194
ERROR - 2023-10-08 02:04:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:04:26 --> Config Class Initialized
INFO - 2023-10-08 02:04:26 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:04:26 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:04:26 --> Utf8 Class Initialized
INFO - 2023-10-08 02:04:26 --> URI Class Initialized
INFO - 2023-10-08 02:04:26 --> Router Class Initialized
INFO - 2023-10-08 02:04:26 --> Output Class Initialized
INFO - 2023-10-08 02:04:26 --> Security Class Initialized
DEBUG - 2023-10-08 02:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:04:26 --> Input Class Initialized
INFO - 2023-10-08 02:04:26 --> Language Class Initialized
INFO - 2023-10-08 02:04:26 --> Loader Class Initialized
INFO - 2023-10-08 02:04:26 --> Helper loaded: url_helper
INFO - 2023-10-08 02:04:26 --> Helper loaded: file_helper
INFO - 2023-10-08 02:04:26 --> Helper loaded: html_helper
INFO - 2023-10-08 02:04:26 --> Helper loaded: text_helper
INFO - 2023-10-08 02:04:26 --> Helper loaded: form_helper
INFO - 2023-10-08 02:04:26 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:04:26 --> Helper loaded: security_helper
INFO - 2023-10-08 02:04:26 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:04:26 --> Database Driver Class Initialized
INFO - 2023-10-08 02:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:04:26 --> Parser Class Initialized
INFO - 2023-10-08 02:04:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:04:26 --> Pagination Class Initialized
INFO - 2023-10-08 02:04:26 --> Form Validation Class Initialized
INFO - 2023-10-08 02:04:26 --> Controller Class Initialized
INFO - 2023-10-08 02:04:26 --> Model Class Initialized
DEBUG - 2023-10-08 02:04:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 02:04:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-08 02:04:26 --> Final output sent to browser
DEBUG - 2023-10-08 02:04:26 --> Total execution time: 0.0194
ERROR - 2023-10-08 02:04:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:04:28 --> Config Class Initialized
INFO - 2023-10-08 02:04:28 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:04:28 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:04:28 --> Utf8 Class Initialized
INFO - 2023-10-08 02:04:28 --> URI Class Initialized
INFO - 2023-10-08 02:04:28 --> Router Class Initialized
INFO - 2023-10-08 02:04:28 --> Output Class Initialized
INFO - 2023-10-08 02:04:28 --> Security Class Initialized
DEBUG - 2023-10-08 02:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:04:28 --> Input Class Initialized
INFO - 2023-10-08 02:04:28 --> Language Class Initialized
INFO - 2023-10-08 02:04:28 --> Loader Class Initialized
INFO - 2023-10-08 02:04:28 --> Helper loaded: url_helper
INFO - 2023-10-08 02:04:28 --> Helper loaded: file_helper
INFO - 2023-10-08 02:04:28 --> Helper loaded: html_helper
INFO - 2023-10-08 02:04:28 --> Helper loaded: text_helper
INFO - 2023-10-08 02:04:28 --> Helper loaded: form_helper
INFO - 2023-10-08 02:04:28 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:04:28 --> Helper loaded: security_helper
INFO - 2023-10-08 02:04:28 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:04:28 --> Database Driver Class Initialized
INFO - 2023-10-08 02:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:04:28 --> Parser Class Initialized
INFO - 2023-10-08 02:04:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:04:28 --> Pagination Class Initialized
INFO - 2023-10-08 02:04:28 --> Form Validation Class Initialized
INFO - 2023-10-08 02:04:28 --> Controller Class Initialized
INFO - 2023-10-08 02:04:28 --> Model Class Initialized
DEBUG - 2023-10-08 02:04:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 02:04:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:04:28 --> Model Class Initialized
DEBUG - 2023-10-08 02:04:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:04:28 --> Model Class Initialized
INFO - 2023-10-08 02:04:28 --> Final output sent to browser
DEBUG - 2023-10-08 02:04:28 --> Total execution time: 0.0480
ERROR - 2023-10-08 02:04:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:04:33 --> Config Class Initialized
INFO - 2023-10-08 02:04:33 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:04:33 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:04:33 --> Utf8 Class Initialized
INFO - 2023-10-08 02:04:33 --> URI Class Initialized
INFO - 2023-10-08 02:04:33 --> Router Class Initialized
INFO - 2023-10-08 02:04:33 --> Output Class Initialized
INFO - 2023-10-08 02:04:33 --> Security Class Initialized
DEBUG - 2023-10-08 02:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:04:33 --> Input Class Initialized
INFO - 2023-10-08 02:04:33 --> Language Class Initialized
INFO - 2023-10-08 02:04:33 --> Loader Class Initialized
INFO - 2023-10-08 02:04:33 --> Helper loaded: url_helper
INFO - 2023-10-08 02:04:33 --> Helper loaded: file_helper
INFO - 2023-10-08 02:04:33 --> Helper loaded: html_helper
INFO - 2023-10-08 02:04:33 --> Helper loaded: text_helper
INFO - 2023-10-08 02:04:33 --> Helper loaded: form_helper
INFO - 2023-10-08 02:04:33 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:04:33 --> Helper loaded: security_helper
INFO - 2023-10-08 02:04:33 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:04:33 --> Database Driver Class Initialized
INFO - 2023-10-08 02:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:04:33 --> Parser Class Initialized
INFO - 2023-10-08 02:04:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:04:33 --> Pagination Class Initialized
INFO - 2023-10-08 02:04:33 --> Form Validation Class Initialized
INFO - 2023-10-08 02:04:33 --> Controller Class Initialized
INFO - 2023-10-08 02:04:33 --> Model Class Initialized
DEBUG - 2023-10-08 02:04:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 02:04:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:04:33 --> Model Class Initialized
DEBUG - 2023-10-08 02:04:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:04:33 --> Model Class Initialized
INFO - 2023-10-08 02:04:33 --> Final output sent to browser
DEBUG - 2023-10-08 02:04:33 --> Total execution time: 0.0463
ERROR - 2023-10-08 02:04:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:04:34 --> Config Class Initialized
INFO - 2023-10-08 02:04:34 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:04:34 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:04:34 --> Utf8 Class Initialized
INFO - 2023-10-08 02:04:34 --> URI Class Initialized
INFO - 2023-10-08 02:04:34 --> Router Class Initialized
INFO - 2023-10-08 02:04:34 --> Output Class Initialized
INFO - 2023-10-08 02:04:34 --> Security Class Initialized
DEBUG - 2023-10-08 02:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:04:34 --> Input Class Initialized
INFO - 2023-10-08 02:04:34 --> Language Class Initialized
INFO - 2023-10-08 02:04:34 --> Loader Class Initialized
INFO - 2023-10-08 02:04:34 --> Helper loaded: url_helper
INFO - 2023-10-08 02:04:34 --> Helper loaded: file_helper
INFO - 2023-10-08 02:04:34 --> Helper loaded: html_helper
INFO - 2023-10-08 02:04:34 --> Helper loaded: text_helper
INFO - 2023-10-08 02:04:34 --> Helper loaded: form_helper
INFO - 2023-10-08 02:04:34 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:04:34 --> Helper loaded: security_helper
INFO - 2023-10-08 02:04:34 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:04:34 --> Database Driver Class Initialized
INFO - 2023-10-08 02:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:04:34 --> Parser Class Initialized
INFO - 2023-10-08 02:04:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:04:34 --> Pagination Class Initialized
INFO - 2023-10-08 02:04:34 --> Form Validation Class Initialized
INFO - 2023-10-08 02:04:34 --> Controller Class Initialized
INFO - 2023-10-08 02:04:34 --> Model Class Initialized
DEBUG - 2023-10-08 02:04:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 02:04:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:04:34 --> Model Class Initialized
DEBUG - 2023-10-08 02:04:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:04:34 --> Model Class Initialized
INFO - 2023-10-08 02:04:34 --> Final output sent to browser
DEBUG - 2023-10-08 02:04:34 --> Total execution time: 0.0564
ERROR - 2023-10-08 02:04:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:04:38 --> Config Class Initialized
INFO - 2023-10-08 02:04:38 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:04:38 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:04:38 --> Utf8 Class Initialized
INFO - 2023-10-08 02:04:38 --> URI Class Initialized
INFO - 2023-10-08 02:04:38 --> Router Class Initialized
INFO - 2023-10-08 02:04:38 --> Output Class Initialized
INFO - 2023-10-08 02:04:38 --> Security Class Initialized
DEBUG - 2023-10-08 02:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:04:38 --> Input Class Initialized
INFO - 2023-10-08 02:04:38 --> Language Class Initialized
INFO - 2023-10-08 02:04:38 --> Loader Class Initialized
INFO - 2023-10-08 02:04:38 --> Helper loaded: url_helper
INFO - 2023-10-08 02:04:38 --> Helper loaded: file_helper
INFO - 2023-10-08 02:04:38 --> Helper loaded: html_helper
INFO - 2023-10-08 02:04:38 --> Helper loaded: text_helper
INFO - 2023-10-08 02:04:38 --> Helper loaded: form_helper
INFO - 2023-10-08 02:04:38 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:04:38 --> Helper loaded: security_helper
INFO - 2023-10-08 02:04:38 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:04:38 --> Database Driver Class Initialized
INFO - 2023-10-08 02:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:04:38 --> Parser Class Initialized
INFO - 2023-10-08 02:04:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:04:38 --> Pagination Class Initialized
INFO - 2023-10-08 02:04:38 --> Form Validation Class Initialized
INFO - 2023-10-08 02:04:38 --> Controller Class Initialized
INFO - 2023-10-08 02:04:38 --> Model Class Initialized
DEBUG - 2023-10-08 02:04:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 02:04:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:04:38 --> Model Class Initialized
DEBUG - 2023-10-08 02:04:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:04:38 --> Model Class Initialized
INFO - 2023-10-08 02:04:38 --> Final output sent to browser
DEBUG - 2023-10-08 02:04:38 --> Total execution time: 0.0208
ERROR - 2023-10-08 02:04:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:04:40 --> Config Class Initialized
INFO - 2023-10-08 02:04:40 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:04:40 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:04:40 --> Utf8 Class Initialized
INFO - 2023-10-08 02:04:40 --> URI Class Initialized
INFO - 2023-10-08 02:04:40 --> Router Class Initialized
INFO - 2023-10-08 02:04:40 --> Output Class Initialized
INFO - 2023-10-08 02:04:40 --> Security Class Initialized
DEBUG - 2023-10-08 02:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:04:40 --> Input Class Initialized
INFO - 2023-10-08 02:04:40 --> Language Class Initialized
INFO - 2023-10-08 02:04:40 --> Loader Class Initialized
INFO - 2023-10-08 02:04:40 --> Helper loaded: url_helper
INFO - 2023-10-08 02:04:40 --> Helper loaded: file_helper
INFO - 2023-10-08 02:04:40 --> Helper loaded: html_helper
INFO - 2023-10-08 02:04:40 --> Helper loaded: text_helper
INFO - 2023-10-08 02:04:40 --> Helper loaded: form_helper
INFO - 2023-10-08 02:04:40 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:04:40 --> Helper loaded: security_helper
INFO - 2023-10-08 02:04:40 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:04:40 --> Database Driver Class Initialized
INFO - 2023-10-08 02:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:04:40 --> Parser Class Initialized
INFO - 2023-10-08 02:04:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:04:40 --> Pagination Class Initialized
INFO - 2023-10-08 02:04:40 --> Form Validation Class Initialized
INFO - 2023-10-08 02:04:40 --> Controller Class Initialized
INFO - 2023-10-08 02:04:40 --> Model Class Initialized
DEBUG - 2023-10-08 02:04:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 02:04:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:04:40 --> Model Class Initialized
INFO - 2023-10-08 02:04:40 --> Model Class Initialized
INFO - 2023-10-08 02:04:40 --> Final output sent to browser
DEBUG - 2023-10-08 02:04:40 --> Total execution time: 0.0237
ERROR - 2023-10-08 02:06:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:06:16 --> Config Class Initialized
INFO - 2023-10-08 02:06:16 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:06:16 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:06:16 --> Utf8 Class Initialized
INFO - 2023-10-08 02:06:16 --> URI Class Initialized
DEBUG - 2023-10-08 02:06:16 --> No URI present. Default controller set.
INFO - 2023-10-08 02:06:16 --> Router Class Initialized
INFO - 2023-10-08 02:06:16 --> Output Class Initialized
INFO - 2023-10-08 02:06:16 --> Security Class Initialized
DEBUG - 2023-10-08 02:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:06:16 --> Input Class Initialized
INFO - 2023-10-08 02:06:16 --> Language Class Initialized
INFO - 2023-10-08 02:06:16 --> Loader Class Initialized
INFO - 2023-10-08 02:06:16 --> Helper loaded: url_helper
INFO - 2023-10-08 02:06:16 --> Helper loaded: file_helper
INFO - 2023-10-08 02:06:16 --> Helper loaded: html_helper
INFO - 2023-10-08 02:06:16 --> Helper loaded: text_helper
INFO - 2023-10-08 02:06:16 --> Helper loaded: form_helper
INFO - 2023-10-08 02:06:16 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:06:16 --> Helper loaded: security_helper
INFO - 2023-10-08 02:06:16 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:06:16 --> Database Driver Class Initialized
INFO - 2023-10-08 02:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:06:16 --> Parser Class Initialized
INFO - 2023-10-08 02:06:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:06:16 --> Pagination Class Initialized
INFO - 2023-10-08 02:06:16 --> Form Validation Class Initialized
INFO - 2023-10-08 02:06:16 --> Controller Class Initialized
INFO - 2023-10-08 02:06:16 --> Model Class Initialized
DEBUG - 2023-10-08 02:06:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:06:16 --> Model Class Initialized
DEBUG - 2023-10-08 02:06:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:06:16 --> Model Class Initialized
INFO - 2023-10-08 02:06:16 --> Model Class Initialized
INFO - 2023-10-08 02:06:16 --> Model Class Initialized
INFO - 2023-10-08 02:06:16 --> Model Class Initialized
DEBUG - 2023-10-08 02:06:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 02:06:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:06:16 --> Model Class Initialized
INFO - 2023-10-08 02:06:16 --> Model Class Initialized
INFO - 2023-10-08 02:06:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-08 02:06:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:06:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 02:06:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 02:06:16 --> Model Class Initialized
INFO - 2023-10-08 02:06:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 02:06:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 02:06:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 02:06:16 --> Final output sent to browser
DEBUG - 2023-10-08 02:06:16 --> Total execution time: 0.1191
ERROR - 2023-10-08 02:06:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:06:28 --> Config Class Initialized
INFO - 2023-10-08 02:06:28 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:06:28 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:06:28 --> Utf8 Class Initialized
INFO - 2023-10-08 02:06:28 --> URI Class Initialized
INFO - 2023-10-08 02:06:28 --> Router Class Initialized
INFO - 2023-10-08 02:06:28 --> Output Class Initialized
INFO - 2023-10-08 02:06:28 --> Security Class Initialized
DEBUG - 2023-10-08 02:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:06:28 --> Input Class Initialized
INFO - 2023-10-08 02:06:28 --> Language Class Initialized
INFO - 2023-10-08 02:06:28 --> Loader Class Initialized
INFO - 2023-10-08 02:06:28 --> Helper loaded: url_helper
INFO - 2023-10-08 02:06:28 --> Helper loaded: file_helper
INFO - 2023-10-08 02:06:28 --> Helper loaded: html_helper
INFO - 2023-10-08 02:06:28 --> Helper loaded: text_helper
INFO - 2023-10-08 02:06:28 --> Helper loaded: form_helper
INFO - 2023-10-08 02:06:28 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:06:28 --> Helper loaded: security_helper
INFO - 2023-10-08 02:06:28 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:06:28 --> Database Driver Class Initialized
INFO - 2023-10-08 02:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:06:28 --> Parser Class Initialized
INFO - 2023-10-08 02:06:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:06:28 --> Pagination Class Initialized
INFO - 2023-10-08 02:06:28 --> Form Validation Class Initialized
INFO - 2023-10-08 02:06:28 --> Controller Class Initialized
DEBUG - 2023-10-08 02:06:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 02:06:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:06:28 --> Model Class Initialized
DEBUG - 2023-10-08 02:06:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:06:28 --> Model Class Initialized
DEBUG - 2023-10-08 02:06:28 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:06:28 --> Model Class Initialized
INFO - 2023-10-08 02:06:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-10-08 02:06:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:06:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 02:06:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 02:06:28 --> Model Class Initialized
INFO - 2023-10-08 02:06:28 --> Model Class Initialized
INFO - 2023-10-08 02:06:28 --> Model Class Initialized
INFO - 2023-10-08 02:06:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 02:06:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 02:06:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 02:06:28 --> Final output sent to browser
DEBUG - 2023-10-08 02:06:28 --> Total execution time: 0.1010
ERROR - 2023-10-08 02:06:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:06:29 --> Config Class Initialized
INFO - 2023-10-08 02:06:29 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:06:29 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:06:29 --> Utf8 Class Initialized
INFO - 2023-10-08 02:06:29 --> URI Class Initialized
INFO - 2023-10-08 02:06:29 --> Router Class Initialized
INFO - 2023-10-08 02:06:29 --> Output Class Initialized
INFO - 2023-10-08 02:06:29 --> Security Class Initialized
DEBUG - 2023-10-08 02:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:06:29 --> Input Class Initialized
INFO - 2023-10-08 02:06:29 --> Language Class Initialized
INFO - 2023-10-08 02:06:29 --> Loader Class Initialized
INFO - 2023-10-08 02:06:29 --> Helper loaded: url_helper
INFO - 2023-10-08 02:06:29 --> Helper loaded: file_helper
INFO - 2023-10-08 02:06:29 --> Helper loaded: html_helper
INFO - 2023-10-08 02:06:29 --> Helper loaded: text_helper
INFO - 2023-10-08 02:06:29 --> Helper loaded: form_helper
INFO - 2023-10-08 02:06:29 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:06:29 --> Helper loaded: security_helper
INFO - 2023-10-08 02:06:29 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:06:29 --> Database Driver Class Initialized
INFO - 2023-10-08 02:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:06:29 --> Parser Class Initialized
INFO - 2023-10-08 02:06:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:06:29 --> Pagination Class Initialized
INFO - 2023-10-08 02:06:29 --> Form Validation Class Initialized
INFO - 2023-10-08 02:06:29 --> Controller Class Initialized
DEBUG - 2023-10-08 02:06:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 02:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:06:29 --> Model Class Initialized
DEBUG - 2023-10-08 02:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:06:29 --> Model Class Initialized
INFO - 2023-10-08 02:06:29 --> Final output sent to browser
DEBUG - 2023-10-08 02:06:29 --> Total execution time: 0.0263
ERROR - 2023-10-08 02:06:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:06:52 --> Config Class Initialized
INFO - 2023-10-08 02:06:52 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:06:52 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:06:52 --> Utf8 Class Initialized
INFO - 2023-10-08 02:06:52 --> URI Class Initialized
INFO - 2023-10-08 02:06:52 --> Router Class Initialized
INFO - 2023-10-08 02:06:52 --> Output Class Initialized
INFO - 2023-10-08 02:06:52 --> Security Class Initialized
DEBUG - 2023-10-08 02:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:06:52 --> Input Class Initialized
INFO - 2023-10-08 02:06:52 --> Language Class Initialized
INFO - 2023-10-08 02:06:52 --> Loader Class Initialized
INFO - 2023-10-08 02:06:52 --> Helper loaded: url_helper
INFO - 2023-10-08 02:06:52 --> Helper loaded: file_helper
INFO - 2023-10-08 02:06:52 --> Helper loaded: html_helper
INFO - 2023-10-08 02:06:52 --> Helper loaded: text_helper
INFO - 2023-10-08 02:06:52 --> Helper loaded: form_helper
INFO - 2023-10-08 02:06:52 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:06:52 --> Helper loaded: security_helper
INFO - 2023-10-08 02:06:52 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:06:52 --> Database Driver Class Initialized
INFO - 2023-10-08 02:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:06:52 --> Parser Class Initialized
INFO - 2023-10-08 02:06:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:06:52 --> Pagination Class Initialized
INFO - 2023-10-08 02:06:52 --> Form Validation Class Initialized
INFO - 2023-10-08 02:06:52 --> Controller Class Initialized
DEBUG - 2023-10-08 02:06:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 02:06:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:06:52 --> Model Class Initialized
DEBUG - 2023-10-08 02:06:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:06:52 --> Model Class Initialized
INFO - 2023-10-08 02:06:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2023-10-08 02:06:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:06:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 02:06:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 02:06:52 --> Model Class Initialized
INFO - 2023-10-08 02:06:52 --> Model Class Initialized
INFO - 2023-10-08 02:06:52 --> Model Class Initialized
INFO - 2023-10-08 02:06:52 --> Model Class Initialized
INFO - 2023-10-08 02:06:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 02:06:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 02:06:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 02:06:52 --> Final output sent to browser
DEBUG - 2023-10-08 02:06:52 --> Total execution time: 0.1333
ERROR - 2023-10-08 02:07:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:07:23 --> Config Class Initialized
INFO - 2023-10-08 02:07:23 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:07:23 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:07:23 --> Utf8 Class Initialized
INFO - 2023-10-08 02:07:23 --> URI Class Initialized
DEBUG - 2023-10-08 02:07:23 --> No URI present. Default controller set.
INFO - 2023-10-08 02:07:23 --> Router Class Initialized
INFO - 2023-10-08 02:07:23 --> Output Class Initialized
INFO - 2023-10-08 02:07:23 --> Security Class Initialized
DEBUG - 2023-10-08 02:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:07:23 --> Input Class Initialized
INFO - 2023-10-08 02:07:23 --> Language Class Initialized
INFO - 2023-10-08 02:07:23 --> Loader Class Initialized
INFO - 2023-10-08 02:07:23 --> Helper loaded: url_helper
INFO - 2023-10-08 02:07:23 --> Helper loaded: file_helper
INFO - 2023-10-08 02:07:23 --> Helper loaded: html_helper
INFO - 2023-10-08 02:07:23 --> Helper loaded: text_helper
INFO - 2023-10-08 02:07:23 --> Helper loaded: form_helper
INFO - 2023-10-08 02:07:23 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:07:23 --> Helper loaded: security_helper
INFO - 2023-10-08 02:07:23 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:07:23 --> Database Driver Class Initialized
INFO - 2023-10-08 02:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:07:23 --> Parser Class Initialized
INFO - 2023-10-08 02:07:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:07:23 --> Pagination Class Initialized
INFO - 2023-10-08 02:07:23 --> Form Validation Class Initialized
INFO - 2023-10-08 02:07:23 --> Controller Class Initialized
INFO - 2023-10-08 02:07:23 --> Model Class Initialized
DEBUG - 2023-10-08 02:07:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:07:23 --> Model Class Initialized
DEBUG - 2023-10-08 02:07:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:07:23 --> Model Class Initialized
INFO - 2023-10-08 02:07:23 --> Model Class Initialized
INFO - 2023-10-08 02:07:23 --> Model Class Initialized
INFO - 2023-10-08 02:07:23 --> Model Class Initialized
DEBUG - 2023-10-08 02:07:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 02:07:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:07:23 --> Model Class Initialized
INFO - 2023-10-08 02:07:23 --> Model Class Initialized
INFO - 2023-10-08 02:07:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-08 02:07:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:07:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 02:07:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 02:07:24 --> Model Class Initialized
INFO - 2023-10-08 02:07:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 02:07:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 02:07:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 02:07:24 --> Final output sent to browser
DEBUG - 2023-10-08 02:07:24 --> Total execution time: 0.1152
ERROR - 2023-10-08 02:07:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:07:40 --> Config Class Initialized
INFO - 2023-10-08 02:07:40 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:07:40 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:07:40 --> Utf8 Class Initialized
INFO - 2023-10-08 02:07:40 --> URI Class Initialized
INFO - 2023-10-08 02:07:40 --> Router Class Initialized
INFO - 2023-10-08 02:07:40 --> Output Class Initialized
INFO - 2023-10-08 02:07:40 --> Security Class Initialized
DEBUG - 2023-10-08 02:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:07:40 --> Input Class Initialized
INFO - 2023-10-08 02:07:40 --> Language Class Initialized
INFO - 2023-10-08 02:07:40 --> Loader Class Initialized
INFO - 2023-10-08 02:07:40 --> Helper loaded: url_helper
INFO - 2023-10-08 02:07:40 --> Helper loaded: file_helper
INFO - 2023-10-08 02:07:40 --> Helper loaded: html_helper
INFO - 2023-10-08 02:07:40 --> Helper loaded: text_helper
INFO - 2023-10-08 02:07:40 --> Helper loaded: form_helper
INFO - 2023-10-08 02:07:40 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:07:40 --> Helper loaded: security_helper
INFO - 2023-10-08 02:07:40 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:07:40 --> Database Driver Class Initialized
INFO - 2023-10-08 02:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:07:40 --> Parser Class Initialized
INFO - 2023-10-08 02:07:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:07:40 --> Pagination Class Initialized
INFO - 2023-10-08 02:07:40 --> Form Validation Class Initialized
INFO - 2023-10-08 02:07:40 --> Controller Class Initialized
INFO - 2023-10-08 02:07:40 --> Model Class Initialized
DEBUG - 2023-10-08 02:07:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 02:07:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:07:40 --> Model Class Initialized
DEBUG - 2023-10-08 02:07:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:07:40 --> Model Class Initialized
INFO - 2023-10-08 02:07:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-10-08 02:07:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:07:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 02:07:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 02:07:40 --> Model Class Initialized
INFO - 2023-10-08 02:07:40 --> Model Class Initialized
INFO - 2023-10-08 02:07:40 --> Model Class Initialized
INFO - 2023-10-08 02:07:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 02:07:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 02:07:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 02:07:40 --> Final output sent to browser
DEBUG - 2023-10-08 02:07:40 --> Total execution time: 0.1221
ERROR - 2023-10-08 02:07:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:07:54 --> Config Class Initialized
INFO - 2023-10-08 02:07:54 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:07:54 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:07:54 --> Utf8 Class Initialized
INFO - 2023-10-08 02:07:54 --> URI Class Initialized
DEBUG - 2023-10-08 02:07:54 --> No URI present. Default controller set.
INFO - 2023-10-08 02:07:54 --> Router Class Initialized
INFO - 2023-10-08 02:07:54 --> Output Class Initialized
INFO - 2023-10-08 02:07:54 --> Security Class Initialized
DEBUG - 2023-10-08 02:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:07:54 --> Input Class Initialized
INFO - 2023-10-08 02:07:54 --> Language Class Initialized
INFO - 2023-10-08 02:07:54 --> Loader Class Initialized
INFO - 2023-10-08 02:07:54 --> Helper loaded: url_helper
INFO - 2023-10-08 02:07:54 --> Helper loaded: file_helper
INFO - 2023-10-08 02:07:54 --> Helper loaded: html_helper
INFO - 2023-10-08 02:07:54 --> Helper loaded: text_helper
INFO - 2023-10-08 02:07:54 --> Helper loaded: form_helper
INFO - 2023-10-08 02:07:54 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:07:54 --> Helper loaded: security_helper
INFO - 2023-10-08 02:07:54 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:07:54 --> Database Driver Class Initialized
INFO - 2023-10-08 02:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:07:54 --> Parser Class Initialized
INFO - 2023-10-08 02:07:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:07:54 --> Pagination Class Initialized
INFO - 2023-10-08 02:07:54 --> Form Validation Class Initialized
INFO - 2023-10-08 02:07:54 --> Controller Class Initialized
INFO - 2023-10-08 02:07:54 --> Model Class Initialized
DEBUG - 2023-10-08 02:07:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:07:54 --> Model Class Initialized
DEBUG - 2023-10-08 02:07:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:07:54 --> Model Class Initialized
INFO - 2023-10-08 02:07:54 --> Model Class Initialized
INFO - 2023-10-08 02:07:54 --> Model Class Initialized
INFO - 2023-10-08 02:07:54 --> Model Class Initialized
DEBUG - 2023-10-08 02:07:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 02:07:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:07:54 --> Model Class Initialized
INFO - 2023-10-08 02:07:54 --> Model Class Initialized
INFO - 2023-10-08 02:07:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-08 02:07:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:07:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 02:07:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 02:07:54 --> Model Class Initialized
INFO - 2023-10-08 02:07:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 02:07:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 02:07:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 02:07:54 --> Final output sent to browser
DEBUG - 2023-10-08 02:07:54 --> Total execution time: 0.1240
ERROR - 2023-10-08 02:09:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:09:16 --> Config Class Initialized
INFO - 2023-10-08 02:09:16 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:09:16 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:09:16 --> Utf8 Class Initialized
INFO - 2023-10-08 02:09:16 --> URI Class Initialized
INFO - 2023-10-08 02:09:16 --> Router Class Initialized
INFO - 2023-10-08 02:09:16 --> Output Class Initialized
INFO - 2023-10-08 02:09:16 --> Security Class Initialized
DEBUG - 2023-10-08 02:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:09:16 --> Input Class Initialized
INFO - 2023-10-08 02:09:16 --> Language Class Initialized
INFO - 2023-10-08 02:09:16 --> Loader Class Initialized
INFO - 2023-10-08 02:09:16 --> Helper loaded: url_helper
INFO - 2023-10-08 02:09:16 --> Helper loaded: file_helper
INFO - 2023-10-08 02:09:16 --> Helper loaded: html_helper
INFO - 2023-10-08 02:09:16 --> Helper loaded: text_helper
INFO - 2023-10-08 02:09:16 --> Helper loaded: form_helper
INFO - 2023-10-08 02:09:16 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:09:16 --> Helper loaded: security_helper
INFO - 2023-10-08 02:09:16 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:09:16 --> Database Driver Class Initialized
INFO - 2023-10-08 02:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:09:16 --> Parser Class Initialized
INFO - 2023-10-08 02:09:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:09:16 --> Pagination Class Initialized
INFO - 2023-10-08 02:09:16 --> Form Validation Class Initialized
INFO - 2023-10-08 02:09:16 --> Controller Class Initialized
INFO - 2023-10-08 02:09:16 --> Model Class Initialized
DEBUG - 2023-10-08 02:09:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 02:09:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:09:16 --> Model Class Initialized
DEBUG - 2023-10-08 02:09:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:09:16 --> Model Class Initialized
INFO - 2023-10-08 02:09:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-10-08 02:09:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:09:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 02:09:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 02:09:16 --> Model Class Initialized
INFO - 2023-10-08 02:09:16 --> Model Class Initialized
INFO - 2023-10-08 02:09:16 --> Model Class Initialized
INFO - 2023-10-08 02:09:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 02:09:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 02:09:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 02:09:16 --> Final output sent to browser
DEBUG - 2023-10-08 02:09:16 --> Total execution time: 0.1208
ERROR - 2023-10-08 02:09:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:09:47 --> Config Class Initialized
INFO - 2023-10-08 02:09:47 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:09:47 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:09:47 --> Utf8 Class Initialized
INFO - 2023-10-08 02:09:47 --> URI Class Initialized
DEBUG - 2023-10-08 02:09:47 --> No URI present. Default controller set.
INFO - 2023-10-08 02:09:47 --> Router Class Initialized
INFO - 2023-10-08 02:09:47 --> Output Class Initialized
INFO - 2023-10-08 02:09:47 --> Security Class Initialized
DEBUG - 2023-10-08 02:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:09:47 --> Input Class Initialized
INFO - 2023-10-08 02:09:47 --> Language Class Initialized
INFO - 2023-10-08 02:09:47 --> Loader Class Initialized
INFO - 2023-10-08 02:09:47 --> Helper loaded: url_helper
INFO - 2023-10-08 02:09:47 --> Helper loaded: file_helper
INFO - 2023-10-08 02:09:47 --> Helper loaded: html_helper
INFO - 2023-10-08 02:09:47 --> Helper loaded: text_helper
INFO - 2023-10-08 02:09:47 --> Helper loaded: form_helper
INFO - 2023-10-08 02:09:47 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:09:47 --> Helper loaded: security_helper
INFO - 2023-10-08 02:09:47 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:09:47 --> Database Driver Class Initialized
INFO - 2023-10-08 02:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:09:47 --> Parser Class Initialized
INFO - 2023-10-08 02:09:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:09:47 --> Pagination Class Initialized
INFO - 2023-10-08 02:09:47 --> Form Validation Class Initialized
INFO - 2023-10-08 02:09:47 --> Controller Class Initialized
INFO - 2023-10-08 02:09:47 --> Model Class Initialized
DEBUG - 2023-10-08 02:09:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:09:47 --> Model Class Initialized
DEBUG - 2023-10-08 02:09:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:09:47 --> Model Class Initialized
INFO - 2023-10-08 02:09:47 --> Model Class Initialized
INFO - 2023-10-08 02:09:47 --> Model Class Initialized
INFO - 2023-10-08 02:09:47 --> Model Class Initialized
DEBUG - 2023-10-08 02:09:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 02:09:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:09:47 --> Model Class Initialized
INFO - 2023-10-08 02:09:47 --> Model Class Initialized
INFO - 2023-10-08 02:09:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-08 02:09:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:09:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 02:09:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 02:09:48 --> Model Class Initialized
INFO - 2023-10-08 02:09:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 02:09:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 02:09:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 02:09:48 --> Final output sent to browser
DEBUG - 2023-10-08 02:09:48 --> Total execution time: 0.1287
ERROR - 2023-10-08 02:09:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:09:59 --> Config Class Initialized
INFO - 2023-10-08 02:09:59 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:09:59 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:09:59 --> Utf8 Class Initialized
INFO - 2023-10-08 02:09:59 --> URI Class Initialized
INFO - 2023-10-08 02:09:59 --> Router Class Initialized
INFO - 2023-10-08 02:09:59 --> Output Class Initialized
INFO - 2023-10-08 02:09:59 --> Security Class Initialized
DEBUG - 2023-10-08 02:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:09:59 --> Input Class Initialized
INFO - 2023-10-08 02:09:59 --> Language Class Initialized
INFO - 2023-10-08 02:09:59 --> Loader Class Initialized
INFO - 2023-10-08 02:09:59 --> Helper loaded: url_helper
INFO - 2023-10-08 02:09:59 --> Helper loaded: file_helper
INFO - 2023-10-08 02:09:59 --> Helper loaded: html_helper
INFO - 2023-10-08 02:09:59 --> Helper loaded: text_helper
INFO - 2023-10-08 02:09:59 --> Helper loaded: form_helper
INFO - 2023-10-08 02:09:59 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:09:59 --> Helper loaded: security_helper
INFO - 2023-10-08 02:09:59 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:09:59 --> Database Driver Class Initialized
INFO - 2023-10-08 02:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:09:59 --> Parser Class Initialized
INFO - 2023-10-08 02:09:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:09:59 --> Pagination Class Initialized
INFO - 2023-10-08 02:09:59 --> Form Validation Class Initialized
INFO - 2023-10-08 02:09:59 --> Controller Class Initialized
DEBUG - 2023-10-08 02:09:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 02:09:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:09:59 --> Model Class Initialized
DEBUG - 2023-10-08 02:09:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:09:59 --> Model Class Initialized
INFO - 2023-10-08 02:09:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2023-10-08 02:09:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:09:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 02:09:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 02:09:59 --> Model Class Initialized
INFO - 2023-10-08 02:09:59 --> Model Class Initialized
INFO - 2023-10-08 02:09:59 --> Model Class Initialized
INFO - 2023-10-08 02:09:59 --> Model Class Initialized
INFO - 2023-10-08 02:09:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 02:09:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 02:09:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 02:09:59 --> Final output sent to browser
DEBUG - 2023-10-08 02:09:59 --> Total execution time: 0.1256
ERROR - 2023-10-08 02:10:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 02:10:54 --> Config Class Initialized
INFO - 2023-10-08 02:10:54 --> Hooks Class Initialized
DEBUG - 2023-10-08 02:10:54 --> UTF-8 Support Enabled
INFO - 2023-10-08 02:10:54 --> Utf8 Class Initialized
INFO - 2023-10-08 02:10:54 --> URI Class Initialized
DEBUG - 2023-10-08 02:10:54 --> No URI present. Default controller set.
INFO - 2023-10-08 02:10:54 --> Router Class Initialized
INFO - 2023-10-08 02:10:54 --> Output Class Initialized
INFO - 2023-10-08 02:10:54 --> Security Class Initialized
DEBUG - 2023-10-08 02:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 02:10:54 --> Input Class Initialized
INFO - 2023-10-08 02:10:54 --> Language Class Initialized
INFO - 2023-10-08 02:10:54 --> Loader Class Initialized
INFO - 2023-10-08 02:10:54 --> Helper loaded: url_helper
INFO - 2023-10-08 02:10:54 --> Helper loaded: file_helper
INFO - 2023-10-08 02:10:54 --> Helper loaded: html_helper
INFO - 2023-10-08 02:10:54 --> Helper loaded: text_helper
INFO - 2023-10-08 02:10:54 --> Helper loaded: form_helper
INFO - 2023-10-08 02:10:54 --> Helper loaded: lang_helper
INFO - 2023-10-08 02:10:54 --> Helper loaded: security_helper
INFO - 2023-10-08 02:10:54 --> Helper loaded: cookie_helper
INFO - 2023-10-08 02:10:54 --> Database Driver Class Initialized
INFO - 2023-10-08 02:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 02:10:54 --> Parser Class Initialized
INFO - 2023-10-08 02:10:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 02:10:54 --> Pagination Class Initialized
INFO - 2023-10-08 02:10:54 --> Form Validation Class Initialized
INFO - 2023-10-08 02:10:54 --> Controller Class Initialized
INFO - 2023-10-08 02:10:54 --> Model Class Initialized
DEBUG - 2023-10-08 02:10:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:10:54 --> Model Class Initialized
DEBUG - 2023-10-08 02:10:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:10:54 --> Model Class Initialized
INFO - 2023-10-08 02:10:54 --> Model Class Initialized
INFO - 2023-10-08 02:10:54 --> Model Class Initialized
INFO - 2023-10-08 02:10:54 --> Model Class Initialized
DEBUG - 2023-10-08 02:10:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 02:10:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:10:54 --> Model Class Initialized
INFO - 2023-10-08 02:10:54 --> Model Class Initialized
INFO - 2023-10-08 02:10:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-08 02:10:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 02:10:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 02:10:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 02:10:54 --> Model Class Initialized
INFO - 2023-10-08 02:10:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 02:10:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 02:10:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 02:10:54 --> Final output sent to browser
DEBUG - 2023-10-08 02:10:54 --> Total execution time: 0.1151
ERROR - 2023-10-08 03:25:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 03:25:36 --> Config Class Initialized
INFO - 2023-10-08 03:25:36 --> Hooks Class Initialized
DEBUG - 2023-10-08 03:25:36 --> UTF-8 Support Enabled
INFO - 2023-10-08 03:25:36 --> Utf8 Class Initialized
INFO - 2023-10-08 03:25:36 --> URI Class Initialized
DEBUG - 2023-10-08 03:25:36 --> No URI present. Default controller set.
INFO - 2023-10-08 03:25:36 --> Router Class Initialized
INFO - 2023-10-08 03:25:36 --> Output Class Initialized
INFO - 2023-10-08 03:25:36 --> Security Class Initialized
DEBUG - 2023-10-08 03:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 03:25:36 --> Input Class Initialized
INFO - 2023-10-08 03:25:36 --> Language Class Initialized
INFO - 2023-10-08 03:25:36 --> Loader Class Initialized
INFO - 2023-10-08 03:25:36 --> Helper loaded: url_helper
INFO - 2023-10-08 03:25:36 --> Helper loaded: file_helper
INFO - 2023-10-08 03:25:36 --> Helper loaded: html_helper
INFO - 2023-10-08 03:25:36 --> Helper loaded: text_helper
INFO - 2023-10-08 03:25:36 --> Helper loaded: form_helper
INFO - 2023-10-08 03:25:36 --> Helper loaded: lang_helper
INFO - 2023-10-08 03:25:36 --> Helper loaded: security_helper
INFO - 2023-10-08 03:25:36 --> Helper loaded: cookie_helper
INFO - 2023-10-08 03:25:36 --> Database Driver Class Initialized
INFO - 2023-10-08 03:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 03:25:36 --> Parser Class Initialized
INFO - 2023-10-08 03:25:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 03:25:36 --> Pagination Class Initialized
INFO - 2023-10-08 03:25:36 --> Form Validation Class Initialized
INFO - 2023-10-08 03:25:36 --> Controller Class Initialized
INFO - 2023-10-08 03:25:36 --> Model Class Initialized
DEBUG - 2023-10-08 03:25:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 03:25:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 03:25:36 --> Config Class Initialized
INFO - 2023-10-08 03:25:36 --> Hooks Class Initialized
DEBUG - 2023-10-08 03:25:36 --> UTF-8 Support Enabled
INFO - 2023-10-08 03:25:36 --> Utf8 Class Initialized
INFO - 2023-10-08 03:25:36 --> URI Class Initialized
INFO - 2023-10-08 03:25:36 --> Router Class Initialized
INFO - 2023-10-08 03:25:36 --> Output Class Initialized
INFO - 2023-10-08 03:25:36 --> Security Class Initialized
DEBUG - 2023-10-08 03:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 03:25:36 --> Input Class Initialized
INFO - 2023-10-08 03:25:36 --> Language Class Initialized
INFO - 2023-10-08 03:25:36 --> Loader Class Initialized
INFO - 2023-10-08 03:25:36 --> Helper loaded: url_helper
INFO - 2023-10-08 03:25:36 --> Helper loaded: file_helper
INFO - 2023-10-08 03:25:36 --> Helper loaded: html_helper
INFO - 2023-10-08 03:25:36 --> Helper loaded: text_helper
INFO - 2023-10-08 03:25:36 --> Helper loaded: form_helper
INFO - 2023-10-08 03:25:36 --> Helper loaded: lang_helper
INFO - 2023-10-08 03:25:36 --> Helper loaded: security_helper
INFO - 2023-10-08 03:25:36 --> Helper loaded: cookie_helper
INFO - 2023-10-08 03:25:36 --> Database Driver Class Initialized
INFO - 2023-10-08 03:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 03:25:36 --> Parser Class Initialized
INFO - 2023-10-08 03:25:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 03:25:36 --> Pagination Class Initialized
INFO - 2023-10-08 03:25:36 --> Form Validation Class Initialized
INFO - 2023-10-08 03:25:36 --> Controller Class Initialized
INFO - 2023-10-08 03:25:36 --> Model Class Initialized
DEBUG - 2023-10-08 03:25:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 03:25:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-08 03:25:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 03:25:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 03:25:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 03:25:36 --> Model Class Initialized
INFO - 2023-10-08 03:25:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 03:25:36 --> Final output sent to browser
DEBUG - 2023-10-08 03:25:36 --> Total execution time: 0.0382
ERROR - 2023-10-08 04:02:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:02:41 --> Config Class Initialized
INFO - 2023-10-08 04:02:41 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:02:41 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:02:41 --> Utf8 Class Initialized
INFO - 2023-10-08 04:02:41 --> URI Class Initialized
DEBUG - 2023-10-08 04:02:41 --> No URI present. Default controller set.
INFO - 2023-10-08 04:02:41 --> Router Class Initialized
INFO - 2023-10-08 04:02:41 --> Output Class Initialized
INFO - 2023-10-08 04:02:41 --> Security Class Initialized
DEBUG - 2023-10-08 04:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:02:41 --> Input Class Initialized
INFO - 2023-10-08 04:02:41 --> Language Class Initialized
INFO - 2023-10-08 04:02:41 --> Loader Class Initialized
INFO - 2023-10-08 04:02:41 --> Helper loaded: url_helper
INFO - 2023-10-08 04:02:41 --> Helper loaded: file_helper
INFO - 2023-10-08 04:02:41 --> Helper loaded: html_helper
INFO - 2023-10-08 04:02:41 --> Helper loaded: text_helper
INFO - 2023-10-08 04:02:41 --> Helper loaded: form_helper
INFO - 2023-10-08 04:02:41 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:02:41 --> Helper loaded: security_helper
INFO - 2023-10-08 04:02:41 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:02:41 --> Database Driver Class Initialized
INFO - 2023-10-08 04:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:02:41 --> Parser Class Initialized
INFO - 2023-10-08 04:02:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:02:41 --> Pagination Class Initialized
INFO - 2023-10-08 04:02:41 --> Form Validation Class Initialized
INFO - 2023-10-08 04:02:41 --> Controller Class Initialized
INFO - 2023-10-08 04:02:41 --> Model Class Initialized
DEBUG - 2023-10-08 04:02:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 04:02:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:02:41 --> Config Class Initialized
INFO - 2023-10-08 04:02:41 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:02:41 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:02:41 --> Utf8 Class Initialized
INFO - 2023-10-08 04:02:41 --> URI Class Initialized
INFO - 2023-10-08 04:02:41 --> Router Class Initialized
INFO - 2023-10-08 04:02:41 --> Output Class Initialized
INFO - 2023-10-08 04:02:41 --> Security Class Initialized
DEBUG - 2023-10-08 04:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:02:41 --> Input Class Initialized
INFO - 2023-10-08 04:02:41 --> Language Class Initialized
INFO - 2023-10-08 04:02:41 --> Loader Class Initialized
INFO - 2023-10-08 04:02:41 --> Helper loaded: url_helper
INFO - 2023-10-08 04:02:41 --> Helper loaded: file_helper
INFO - 2023-10-08 04:02:41 --> Helper loaded: html_helper
INFO - 2023-10-08 04:02:41 --> Helper loaded: text_helper
INFO - 2023-10-08 04:02:41 --> Helper loaded: form_helper
INFO - 2023-10-08 04:02:41 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:02:41 --> Helper loaded: security_helper
INFO - 2023-10-08 04:02:41 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:02:41 --> Database Driver Class Initialized
INFO - 2023-10-08 04:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:02:41 --> Parser Class Initialized
INFO - 2023-10-08 04:02:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:02:41 --> Pagination Class Initialized
INFO - 2023-10-08 04:02:41 --> Form Validation Class Initialized
INFO - 2023-10-08 04:02:41 --> Controller Class Initialized
INFO - 2023-10-08 04:02:41 --> Model Class Initialized
DEBUG - 2023-10-08 04:02:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:02:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-08 04:02:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:02:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:02:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:02:41 --> Model Class Initialized
INFO - 2023-10-08 04:02:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:02:41 --> Final output sent to browser
DEBUG - 2023-10-08 04:02:41 --> Total execution time: 0.0322
ERROR - 2023-10-08 04:02:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:02:45 --> Config Class Initialized
INFO - 2023-10-08 04:02:45 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:02:45 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:02:45 --> Utf8 Class Initialized
INFO - 2023-10-08 04:02:45 --> URI Class Initialized
INFO - 2023-10-08 04:02:45 --> Router Class Initialized
INFO - 2023-10-08 04:02:45 --> Output Class Initialized
INFO - 2023-10-08 04:02:45 --> Security Class Initialized
DEBUG - 2023-10-08 04:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:02:45 --> Input Class Initialized
INFO - 2023-10-08 04:02:45 --> Language Class Initialized
INFO - 2023-10-08 04:02:45 --> Loader Class Initialized
INFO - 2023-10-08 04:02:45 --> Helper loaded: url_helper
INFO - 2023-10-08 04:02:45 --> Helper loaded: file_helper
INFO - 2023-10-08 04:02:45 --> Helper loaded: html_helper
INFO - 2023-10-08 04:02:45 --> Helper loaded: text_helper
INFO - 2023-10-08 04:02:45 --> Helper loaded: form_helper
INFO - 2023-10-08 04:02:45 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:02:45 --> Helper loaded: security_helper
INFO - 2023-10-08 04:02:45 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:02:45 --> Database Driver Class Initialized
INFO - 2023-10-08 04:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:02:45 --> Parser Class Initialized
INFO - 2023-10-08 04:02:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:02:45 --> Pagination Class Initialized
INFO - 2023-10-08 04:02:45 --> Form Validation Class Initialized
INFO - 2023-10-08 04:02:45 --> Controller Class Initialized
INFO - 2023-10-08 04:02:45 --> Model Class Initialized
DEBUG - 2023-10-08 04:02:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:02:45 --> Model Class Initialized
INFO - 2023-10-08 04:02:45 --> Final output sent to browser
DEBUG - 2023-10-08 04:02:45 --> Total execution time: 0.0196
ERROR - 2023-10-08 04:02:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:02:45 --> Config Class Initialized
INFO - 2023-10-08 04:02:45 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:02:45 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:02:45 --> Utf8 Class Initialized
INFO - 2023-10-08 04:02:45 --> URI Class Initialized
DEBUG - 2023-10-08 04:02:45 --> No URI present. Default controller set.
INFO - 2023-10-08 04:02:45 --> Router Class Initialized
INFO - 2023-10-08 04:02:45 --> Output Class Initialized
INFO - 2023-10-08 04:02:45 --> Security Class Initialized
DEBUG - 2023-10-08 04:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:02:45 --> Input Class Initialized
INFO - 2023-10-08 04:02:45 --> Language Class Initialized
INFO - 2023-10-08 04:02:45 --> Loader Class Initialized
INFO - 2023-10-08 04:02:45 --> Helper loaded: url_helper
INFO - 2023-10-08 04:02:45 --> Helper loaded: file_helper
INFO - 2023-10-08 04:02:45 --> Helper loaded: html_helper
INFO - 2023-10-08 04:02:45 --> Helper loaded: text_helper
INFO - 2023-10-08 04:02:45 --> Helper loaded: form_helper
INFO - 2023-10-08 04:02:45 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:02:45 --> Helper loaded: security_helper
INFO - 2023-10-08 04:02:45 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:02:45 --> Database Driver Class Initialized
INFO - 2023-10-08 04:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:02:45 --> Parser Class Initialized
INFO - 2023-10-08 04:02:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:02:45 --> Pagination Class Initialized
INFO - 2023-10-08 04:02:45 --> Form Validation Class Initialized
INFO - 2023-10-08 04:02:45 --> Controller Class Initialized
INFO - 2023-10-08 04:02:45 --> Model Class Initialized
DEBUG - 2023-10-08 04:02:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:02:45 --> Model Class Initialized
DEBUG - 2023-10-08 04:02:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:02:45 --> Model Class Initialized
INFO - 2023-10-08 04:02:45 --> Model Class Initialized
INFO - 2023-10-08 04:02:45 --> Model Class Initialized
INFO - 2023-10-08 04:02:45 --> Model Class Initialized
DEBUG - 2023-10-08 04:02:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:02:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:02:45 --> Model Class Initialized
INFO - 2023-10-08 04:02:45 --> Model Class Initialized
INFO - 2023-10-08 04:02:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-08 04:02:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:02:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:02:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:02:45 --> Model Class Initialized
INFO - 2023-10-08 04:02:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:02:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:02:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:02:45 --> Final output sent to browser
DEBUG - 2023-10-08 04:02:45 --> Total execution time: 0.1206
ERROR - 2023-10-08 04:02:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:02:57 --> Config Class Initialized
INFO - 2023-10-08 04:02:57 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:02:57 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:02:57 --> Utf8 Class Initialized
INFO - 2023-10-08 04:02:57 --> URI Class Initialized
INFO - 2023-10-08 04:02:57 --> Router Class Initialized
INFO - 2023-10-08 04:02:57 --> Output Class Initialized
INFO - 2023-10-08 04:02:57 --> Security Class Initialized
DEBUG - 2023-10-08 04:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:02:57 --> Input Class Initialized
INFO - 2023-10-08 04:02:57 --> Language Class Initialized
INFO - 2023-10-08 04:02:57 --> Loader Class Initialized
INFO - 2023-10-08 04:02:57 --> Helper loaded: url_helper
INFO - 2023-10-08 04:02:57 --> Helper loaded: file_helper
INFO - 2023-10-08 04:02:57 --> Helper loaded: html_helper
INFO - 2023-10-08 04:02:57 --> Helper loaded: text_helper
INFO - 2023-10-08 04:02:57 --> Helper loaded: form_helper
INFO - 2023-10-08 04:02:57 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:02:57 --> Helper loaded: security_helper
INFO - 2023-10-08 04:02:57 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:02:57 --> Database Driver Class Initialized
INFO - 2023-10-08 04:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:02:57 --> Parser Class Initialized
INFO - 2023-10-08 04:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:02:57 --> Pagination Class Initialized
INFO - 2023-10-08 04:02:57 --> Form Validation Class Initialized
INFO - 2023-10-08 04:02:57 --> Controller Class Initialized
INFO - 2023-10-08 04:02:57 --> Model Class Initialized
DEBUG - 2023-10-08 04:02:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:02:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:02:57 --> Model Class Initialized
DEBUG - 2023-10-08 04:02:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:02:57 --> Model Class Initialized
INFO - 2023-10-08 04:02:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-08 04:02:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:02:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:02:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:02:57 --> Model Class Initialized
INFO - 2023-10-08 04:02:57 --> Model Class Initialized
INFO - 2023-10-08 04:02:57 --> Model Class Initialized
INFO - 2023-10-08 04:02:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:02:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:02:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:02:57 --> Final output sent to browser
DEBUG - 2023-10-08 04:02:57 --> Total execution time: 0.0965
ERROR - 2023-10-08 04:02:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:02:57 --> Config Class Initialized
INFO - 2023-10-08 04:02:57 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:02:57 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:02:57 --> Utf8 Class Initialized
INFO - 2023-10-08 04:02:57 --> URI Class Initialized
INFO - 2023-10-08 04:02:57 --> Router Class Initialized
INFO - 2023-10-08 04:02:57 --> Output Class Initialized
INFO - 2023-10-08 04:02:57 --> Security Class Initialized
DEBUG - 2023-10-08 04:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:02:57 --> Input Class Initialized
INFO - 2023-10-08 04:02:57 --> Language Class Initialized
INFO - 2023-10-08 04:02:57 --> Loader Class Initialized
INFO - 2023-10-08 04:02:57 --> Helper loaded: url_helper
INFO - 2023-10-08 04:02:57 --> Helper loaded: file_helper
INFO - 2023-10-08 04:02:57 --> Helper loaded: html_helper
INFO - 2023-10-08 04:02:57 --> Helper loaded: text_helper
INFO - 2023-10-08 04:02:57 --> Helper loaded: form_helper
INFO - 2023-10-08 04:02:57 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:02:57 --> Helper loaded: security_helper
INFO - 2023-10-08 04:02:57 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:02:57 --> Database Driver Class Initialized
INFO - 2023-10-08 04:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:02:57 --> Parser Class Initialized
INFO - 2023-10-08 04:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:02:57 --> Pagination Class Initialized
INFO - 2023-10-08 04:02:57 --> Form Validation Class Initialized
INFO - 2023-10-08 04:02:57 --> Controller Class Initialized
INFO - 2023-10-08 04:02:57 --> Model Class Initialized
DEBUG - 2023-10-08 04:02:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:02:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:02:57 --> Model Class Initialized
DEBUG - 2023-10-08 04:02:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:02:57 --> Model Class Initialized
INFO - 2023-10-08 04:02:57 --> Final output sent to browser
DEBUG - 2023-10-08 04:02:57 --> Total execution time: 0.0420
ERROR - 2023-10-08 04:03:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:03:12 --> Config Class Initialized
INFO - 2023-10-08 04:03:12 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:03:12 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:03:12 --> Utf8 Class Initialized
INFO - 2023-10-08 04:03:12 --> URI Class Initialized
INFO - 2023-10-08 04:03:12 --> Router Class Initialized
INFO - 2023-10-08 04:03:12 --> Output Class Initialized
INFO - 2023-10-08 04:03:12 --> Security Class Initialized
DEBUG - 2023-10-08 04:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:03:12 --> Input Class Initialized
INFO - 2023-10-08 04:03:12 --> Language Class Initialized
INFO - 2023-10-08 04:03:12 --> Loader Class Initialized
INFO - 2023-10-08 04:03:12 --> Helper loaded: url_helper
INFO - 2023-10-08 04:03:12 --> Helper loaded: file_helper
INFO - 2023-10-08 04:03:12 --> Helper loaded: html_helper
INFO - 2023-10-08 04:03:12 --> Helper loaded: text_helper
INFO - 2023-10-08 04:03:12 --> Helper loaded: form_helper
INFO - 2023-10-08 04:03:12 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:03:12 --> Helper loaded: security_helper
INFO - 2023-10-08 04:03:12 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:03:12 --> Database Driver Class Initialized
INFO - 2023-10-08 04:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:03:12 --> Parser Class Initialized
INFO - 2023-10-08 04:03:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:03:12 --> Pagination Class Initialized
INFO - 2023-10-08 04:03:12 --> Form Validation Class Initialized
INFO - 2023-10-08 04:03:12 --> Controller Class Initialized
DEBUG - 2023-10-08 04:03:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:03:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:03:12 --> Model Class Initialized
DEBUG - 2023-10-08 04:03:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:03:12 --> Model Class Initialized
DEBUG - 2023-10-08 04:03:12 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:03:12 --> Model Class Initialized
INFO - 2023-10-08 04:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-10-08 04:03:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:03:12 --> Model Class Initialized
INFO - 2023-10-08 04:03:12 --> Model Class Initialized
INFO - 2023-10-08 04:03:12 --> Model Class Initialized
INFO - 2023-10-08 04:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:03:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:03:12 --> Final output sent to browser
DEBUG - 2023-10-08 04:03:12 --> Total execution time: 0.1007
ERROR - 2023-10-08 04:03:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:03:12 --> Config Class Initialized
INFO - 2023-10-08 04:03:12 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:03:12 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:03:12 --> Utf8 Class Initialized
INFO - 2023-10-08 04:03:12 --> URI Class Initialized
INFO - 2023-10-08 04:03:12 --> Router Class Initialized
INFO - 2023-10-08 04:03:12 --> Output Class Initialized
INFO - 2023-10-08 04:03:12 --> Security Class Initialized
DEBUG - 2023-10-08 04:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:03:12 --> Input Class Initialized
INFO - 2023-10-08 04:03:12 --> Language Class Initialized
INFO - 2023-10-08 04:03:12 --> Loader Class Initialized
INFO - 2023-10-08 04:03:12 --> Helper loaded: url_helper
INFO - 2023-10-08 04:03:12 --> Helper loaded: file_helper
INFO - 2023-10-08 04:03:12 --> Helper loaded: html_helper
INFO - 2023-10-08 04:03:12 --> Helper loaded: text_helper
INFO - 2023-10-08 04:03:12 --> Helper loaded: form_helper
INFO - 2023-10-08 04:03:12 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:03:12 --> Helper loaded: security_helper
INFO - 2023-10-08 04:03:12 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:03:12 --> Database Driver Class Initialized
INFO - 2023-10-08 04:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:03:12 --> Parser Class Initialized
INFO - 2023-10-08 04:03:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:03:12 --> Pagination Class Initialized
INFO - 2023-10-08 04:03:12 --> Form Validation Class Initialized
INFO - 2023-10-08 04:03:12 --> Controller Class Initialized
DEBUG - 2023-10-08 04:03:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:03:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:03:12 --> Model Class Initialized
DEBUG - 2023-10-08 04:03:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:03:12 --> Model Class Initialized
INFO - 2023-10-08 04:03:12 --> Final output sent to browser
DEBUG - 2023-10-08 04:03:12 --> Total execution time: 0.0218
ERROR - 2023-10-08 04:03:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:03:18 --> Config Class Initialized
INFO - 2023-10-08 04:03:18 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:03:18 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:03:18 --> Utf8 Class Initialized
INFO - 2023-10-08 04:03:18 --> URI Class Initialized
INFO - 2023-10-08 04:03:18 --> Router Class Initialized
INFO - 2023-10-08 04:03:18 --> Output Class Initialized
INFO - 2023-10-08 04:03:18 --> Security Class Initialized
DEBUG - 2023-10-08 04:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:03:18 --> Input Class Initialized
INFO - 2023-10-08 04:03:18 --> Language Class Initialized
INFO - 2023-10-08 04:03:18 --> Loader Class Initialized
INFO - 2023-10-08 04:03:18 --> Helper loaded: url_helper
INFO - 2023-10-08 04:03:18 --> Helper loaded: file_helper
INFO - 2023-10-08 04:03:18 --> Helper loaded: html_helper
INFO - 2023-10-08 04:03:18 --> Helper loaded: text_helper
INFO - 2023-10-08 04:03:18 --> Helper loaded: form_helper
INFO - 2023-10-08 04:03:18 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:03:18 --> Helper loaded: security_helper
INFO - 2023-10-08 04:03:18 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:03:18 --> Database Driver Class Initialized
INFO - 2023-10-08 04:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:03:18 --> Parser Class Initialized
INFO - 2023-10-08 04:03:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:03:18 --> Pagination Class Initialized
INFO - 2023-10-08 04:03:18 --> Form Validation Class Initialized
INFO - 2023-10-08 04:03:18 --> Controller Class Initialized
DEBUG - 2023-10-08 04:03:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:03:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:03:18 --> Model Class Initialized
DEBUG - 2023-10-08 04:03:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:03:18 --> Model Class Initialized
INFO - 2023-10-08 04:03:18 --> Final output sent to browser
DEBUG - 2023-10-08 04:03:18 --> Total execution time: 0.0209
ERROR - 2023-10-08 04:03:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:03:30 --> Config Class Initialized
INFO - 2023-10-08 04:03:30 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:03:30 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:03:30 --> Utf8 Class Initialized
INFO - 2023-10-08 04:03:30 --> URI Class Initialized
INFO - 2023-10-08 04:03:30 --> Router Class Initialized
INFO - 2023-10-08 04:03:30 --> Output Class Initialized
INFO - 2023-10-08 04:03:30 --> Security Class Initialized
DEBUG - 2023-10-08 04:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:03:30 --> Input Class Initialized
INFO - 2023-10-08 04:03:30 --> Language Class Initialized
INFO - 2023-10-08 04:03:30 --> Loader Class Initialized
INFO - 2023-10-08 04:03:30 --> Helper loaded: url_helper
INFO - 2023-10-08 04:03:30 --> Helper loaded: file_helper
INFO - 2023-10-08 04:03:30 --> Helper loaded: html_helper
INFO - 2023-10-08 04:03:30 --> Helper loaded: text_helper
INFO - 2023-10-08 04:03:30 --> Helper loaded: form_helper
INFO - 2023-10-08 04:03:30 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:03:30 --> Helper loaded: security_helper
INFO - 2023-10-08 04:03:30 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:03:30 --> Database Driver Class Initialized
INFO - 2023-10-08 04:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:03:30 --> Parser Class Initialized
INFO - 2023-10-08 04:03:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:03:30 --> Pagination Class Initialized
INFO - 2023-10-08 04:03:30 --> Form Validation Class Initialized
INFO - 2023-10-08 04:03:30 --> Controller Class Initialized
INFO - 2023-10-08 04:03:30 --> Model Class Initialized
DEBUG - 2023-10-08 04:03:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:03:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:03:30 --> Model Class Initialized
DEBUG - 2023-10-08 04:03:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:03:30 --> Model Class Initialized
INFO - 2023-10-08 04:03:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-10-08 04:03:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:03:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:03:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:03:30 --> Model Class Initialized
INFO - 2023-10-08 04:03:30 --> Model Class Initialized
INFO - 2023-10-08 04:03:30 --> Model Class Initialized
INFO - 2023-10-08 04:03:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:03:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:03:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:03:30 --> Final output sent to browser
DEBUG - 2023-10-08 04:03:30 --> Total execution time: 0.0991
ERROR - 2023-10-08 04:03:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:03:31 --> Config Class Initialized
INFO - 2023-10-08 04:03:31 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:03:31 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:03:31 --> Utf8 Class Initialized
INFO - 2023-10-08 04:03:31 --> URI Class Initialized
INFO - 2023-10-08 04:03:31 --> Router Class Initialized
INFO - 2023-10-08 04:03:31 --> Output Class Initialized
INFO - 2023-10-08 04:03:31 --> Security Class Initialized
DEBUG - 2023-10-08 04:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:03:31 --> Input Class Initialized
INFO - 2023-10-08 04:03:31 --> Language Class Initialized
INFO - 2023-10-08 04:03:31 --> Loader Class Initialized
INFO - 2023-10-08 04:03:31 --> Helper loaded: url_helper
INFO - 2023-10-08 04:03:31 --> Helper loaded: file_helper
INFO - 2023-10-08 04:03:31 --> Helper loaded: html_helper
INFO - 2023-10-08 04:03:31 --> Helper loaded: text_helper
INFO - 2023-10-08 04:03:31 --> Helper loaded: form_helper
INFO - 2023-10-08 04:03:31 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:03:31 --> Helper loaded: security_helper
INFO - 2023-10-08 04:03:31 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:03:31 --> Database Driver Class Initialized
INFO - 2023-10-08 04:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:03:31 --> Parser Class Initialized
INFO - 2023-10-08 04:03:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:03:31 --> Pagination Class Initialized
INFO - 2023-10-08 04:03:31 --> Form Validation Class Initialized
INFO - 2023-10-08 04:03:31 --> Controller Class Initialized
INFO - 2023-10-08 04:03:31 --> Model Class Initialized
DEBUG - 2023-10-08 04:03:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:03:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:03:31 --> Model Class Initialized
DEBUG - 2023-10-08 04:03:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:03:31 --> Model Class Initialized
INFO - 2023-10-08 04:03:31 --> Final output sent to browser
DEBUG - 2023-10-08 04:03:31 --> Total execution time: 0.0307
ERROR - 2023-10-08 04:03:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:03:47 --> Config Class Initialized
INFO - 2023-10-08 04:03:47 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:03:47 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:03:47 --> Utf8 Class Initialized
INFO - 2023-10-08 04:03:47 --> URI Class Initialized
INFO - 2023-10-08 04:03:47 --> Router Class Initialized
INFO - 2023-10-08 04:03:47 --> Output Class Initialized
INFO - 2023-10-08 04:03:47 --> Security Class Initialized
DEBUG - 2023-10-08 04:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:03:47 --> Input Class Initialized
INFO - 2023-10-08 04:03:47 --> Language Class Initialized
INFO - 2023-10-08 04:03:47 --> Loader Class Initialized
INFO - 2023-10-08 04:03:47 --> Helper loaded: url_helper
INFO - 2023-10-08 04:03:47 --> Helper loaded: file_helper
INFO - 2023-10-08 04:03:47 --> Helper loaded: html_helper
INFO - 2023-10-08 04:03:47 --> Helper loaded: text_helper
INFO - 2023-10-08 04:03:47 --> Helper loaded: form_helper
INFO - 2023-10-08 04:03:47 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:03:47 --> Helper loaded: security_helper
INFO - 2023-10-08 04:03:47 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:03:47 --> Database Driver Class Initialized
INFO - 2023-10-08 04:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:03:47 --> Parser Class Initialized
INFO - 2023-10-08 04:03:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:03:47 --> Pagination Class Initialized
INFO - 2023-10-08 04:03:47 --> Form Validation Class Initialized
INFO - 2023-10-08 04:03:47 --> Controller Class Initialized
INFO - 2023-10-08 04:03:47 --> Model Class Initialized
DEBUG - 2023-10-08 04:03:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:03:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:03:47 --> Model Class Initialized
INFO - 2023-10-08 04:03:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-10-08 04:03:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:03:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:03:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:03:47 --> Model Class Initialized
INFO - 2023-10-08 04:03:47 --> Model Class Initialized
INFO - 2023-10-08 04:03:47 --> Model Class Initialized
INFO - 2023-10-08 04:03:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:03:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:03:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:03:48 --> Final output sent to browser
DEBUG - 2023-10-08 04:03:48 --> Total execution time: 0.0953
ERROR - 2023-10-08 04:03:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:03:48 --> Config Class Initialized
INFO - 2023-10-08 04:03:48 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:03:48 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:03:48 --> Utf8 Class Initialized
INFO - 2023-10-08 04:03:48 --> URI Class Initialized
INFO - 2023-10-08 04:03:48 --> Router Class Initialized
INFO - 2023-10-08 04:03:48 --> Output Class Initialized
INFO - 2023-10-08 04:03:48 --> Security Class Initialized
DEBUG - 2023-10-08 04:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:03:48 --> Input Class Initialized
INFO - 2023-10-08 04:03:48 --> Language Class Initialized
INFO - 2023-10-08 04:03:48 --> Loader Class Initialized
INFO - 2023-10-08 04:03:48 --> Helper loaded: url_helper
INFO - 2023-10-08 04:03:48 --> Helper loaded: file_helper
INFO - 2023-10-08 04:03:48 --> Helper loaded: html_helper
INFO - 2023-10-08 04:03:48 --> Helper loaded: text_helper
INFO - 2023-10-08 04:03:48 --> Helper loaded: form_helper
INFO - 2023-10-08 04:03:48 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:03:48 --> Helper loaded: security_helper
INFO - 2023-10-08 04:03:48 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:03:48 --> Database Driver Class Initialized
INFO - 2023-10-08 04:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:03:48 --> Parser Class Initialized
INFO - 2023-10-08 04:03:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:03:48 --> Pagination Class Initialized
INFO - 2023-10-08 04:03:48 --> Form Validation Class Initialized
INFO - 2023-10-08 04:03:48 --> Controller Class Initialized
INFO - 2023-10-08 04:03:48 --> Model Class Initialized
DEBUG - 2023-10-08 04:03:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:03:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:03:48 --> Model Class Initialized
INFO - 2023-10-08 04:03:48 --> Final output sent to browser
DEBUG - 2023-10-08 04:03:48 --> Total execution time: 0.0204
ERROR - 2023-10-08 04:03:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:03:51 --> Config Class Initialized
INFO - 2023-10-08 04:03:51 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:03:51 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:03:51 --> Utf8 Class Initialized
INFO - 2023-10-08 04:03:51 --> URI Class Initialized
INFO - 2023-10-08 04:03:51 --> Router Class Initialized
INFO - 2023-10-08 04:03:51 --> Output Class Initialized
INFO - 2023-10-08 04:03:51 --> Security Class Initialized
DEBUG - 2023-10-08 04:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:03:51 --> Input Class Initialized
INFO - 2023-10-08 04:03:51 --> Language Class Initialized
INFO - 2023-10-08 04:03:51 --> Loader Class Initialized
INFO - 2023-10-08 04:03:51 --> Helper loaded: url_helper
INFO - 2023-10-08 04:03:51 --> Helper loaded: file_helper
INFO - 2023-10-08 04:03:51 --> Helper loaded: html_helper
INFO - 2023-10-08 04:03:51 --> Helper loaded: text_helper
INFO - 2023-10-08 04:03:51 --> Helper loaded: form_helper
INFO - 2023-10-08 04:03:51 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:03:51 --> Helper loaded: security_helper
INFO - 2023-10-08 04:03:51 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:03:51 --> Database Driver Class Initialized
INFO - 2023-10-08 04:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:03:51 --> Parser Class Initialized
INFO - 2023-10-08 04:03:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:03:51 --> Pagination Class Initialized
INFO - 2023-10-08 04:03:51 --> Form Validation Class Initialized
INFO - 2023-10-08 04:03:51 --> Controller Class Initialized
INFO - 2023-10-08 04:03:51 --> Model Class Initialized
DEBUG - 2023-10-08 04:03:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:03:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:03:51 --> Model Class Initialized
INFO - 2023-10-08 04:03:51 --> Final output sent to browser
DEBUG - 2023-10-08 04:03:51 --> Total execution time: 0.0190
ERROR - 2023-10-08 04:03:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:03:56 --> Config Class Initialized
INFO - 2023-10-08 04:03:56 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:03:56 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:03:56 --> Utf8 Class Initialized
INFO - 2023-10-08 04:03:56 --> URI Class Initialized
DEBUG - 2023-10-08 04:03:56 --> No URI present. Default controller set.
INFO - 2023-10-08 04:03:56 --> Router Class Initialized
INFO - 2023-10-08 04:03:56 --> Output Class Initialized
INFO - 2023-10-08 04:03:56 --> Security Class Initialized
DEBUG - 2023-10-08 04:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:03:56 --> Input Class Initialized
INFO - 2023-10-08 04:03:56 --> Language Class Initialized
INFO - 2023-10-08 04:03:56 --> Loader Class Initialized
INFO - 2023-10-08 04:03:56 --> Helper loaded: url_helper
INFO - 2023-10-08 04:03:56 --> Helper loaded: file_helper
INFO - 2023-10-08 04:03:56 --> Helper loaded: html_helper
INFO - 2023-10-08 04:03:56 --> Helper loaded: text_helper
INFO - 2023-10-08 04:03:56 --> Helper loaded: form_helper
INFO - 2023-10-08 04:03:56 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:03:56 --> Helper loaded: security_helper
INFO - 2023-10-08 04:03:56 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:03:56 --> Database Driver Class Initialized
INFO - 2023-10-08 04:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:03:56 --> Parser Class Initialized
INFO - 2023-10-08 04:03:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:03:56 --> Pagination Class Initialized
INFO - 2023-10-08 04:03:56 --> Form Validation Class Initialized
INFO - 2023-10-08 04:03:56 --> Controller Class Initialized
INFO - 2023-10-08 04:03:56 --> Model Class Initialized
DEBUG - 2023-10-08 04:03:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:03:56 --> Model Class Initialized
DEBUG - 2023-10-08 04:03:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:03:56 --> Model Class Initialized
INFO - 2023-10-08 04:03:56 --> Model Class Initialized
INFO - 2023-10-08 04:03:56 --> Model Class Initialized
INFO - 2023-10-08 04:03:56 --> Model Class Initialized
DEBUG - 2023-10-08 04:03:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:03:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:03:56 --> Model Class Initialized
INFO - 2023-10-08 04:03:56 --> Model Class Initialized
INFO - 2023-10-08 04:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-08 04:03:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:03:56 --> Model Class Initialized
INFO - 2023-10-08 04:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:03:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:03:56 --> Final output sent to browser
DEBUG - 2023-10-08 04:03:56 --> Total execution time: 0.1267
ERROR - 2023-10-08 04:07:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:07:52 --> Config Class Initialized
INFO - 2023-10-08 04:07:52 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:07:52 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:07:52 --> Utf8 Class Initialized
INFO - 2023-10-08 04:07:52 --> URI Class Initialized
DEBUG - 2023-10-08 04:07:52 --> No URI present. Default controller set.
INFO - 2023-10-08 04:07:52 --> Router Class Initialized
INFO - 2023-10-08 04:07:52 --> Output Class Initialized
INFO - 2023-10-08 04:07:52 --> Security Class Initialized
DEBUG - 2023-10-08 04:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:07:52 --> Input Class Initialized
INFO - 2023-10-08 04:07:52 --> Language Class Initialized
INFO - 2023-10-08 04:07:52 --> Loader Class Initialized
INFO - 2023-10-08 04:07:52 --> Helper loaded: url_helper
INFO - 2023-10-08 04:07:52 --> Helper loaded: file_helper
INFO - 2023-10-08 04:07:52 --> Helper loaded: html_helper
INFO - 2023-10-08 04:07:52 --> Helper loaded: text_helper
INFO - 2023-10-08 04:07:52 --> Helper loaded: form_helper
INFO - 2023-10-08 04:07:52 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:07:52 --> Helper loaded: security_helper
INFO - 2023-10-08 04:07:52 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:07:52 --> Database Driver Class Initialized
INFO - 2023-10-08 04:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:07:52 --> Parser Class Initialized
INFO - 2023-10-08 04:07:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:07:52 --> Pagination Class Initialized
INFO - 2023-10-08 04:07:52 --> Form Validation Class Initialized
INFO - 2023-10-08 04:07:52 --> Controller Class Initialized
INFO - 2023-10-08 04:07:52 --> Model Class Initialized
DEBUG - 2023-10-08 04:07:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:07:52 --> Model Class Initialized
DEBUG - 2023-10-08 04:07:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:07:52 --> Model Class Initialized
INFO - 2023-10-08 04:07:52 --> Model Class Initialized
INFO - 2023-10-08 04:07:52 --> Model Class Initialized
INFO - 2023-10-08 04:07:52 --> Model Class Initialized
DEBUG - 2023-10-08 04:07:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:07:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:07:52 --> Model Class Initialized
INFO - 2023-10-08 04:07:52 --> Model Class Initialized
INFO - 2023-10-08 04:07:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-08 04:07:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:07:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:07:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:07:52 --> Model Class Initialized
INFO - 2023-10-08 04:07:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:07:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:07:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:07:52 --> Final output sent to browser
DEBUG - 2023-10-08 04:07:52 --> Total execution time: 0.1211
ERROR - 2023-10-08 04:11:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:11:01 --> Config Class Initialized
INFO - 2023-10-08 04:11:01 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:11:01 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:11:01 --> Utf8 Class Initialized
INFO - 2023-10-08 04:11:01 --> URI Class Initialized
DEBUG - 2023-10-08 04:11:01 --> No URI present. Default controller set.
INFO - 2023-10-08 04:11:01 --> Router Class Initialized
INFO - 2023-10-08 04:11:01 --> Output Class Initialized
INFO - 2023-10-08 04:11:01 --> Security Class Initialized
DEBUG - 2023-10-08 04:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:11:01 --> Input Class Initialized
INFO - 2023-10-08 04:11:01 --> Language Class Initialized
INFO - 2023-10-08 04:11:01 --> Loader Class Initialized
INFO - 2023-10-08 04:11:01 --> Helper loaded: url_helper
INFO - 2023-10-08 04:11:01 --> Helper loaded: file_helper
INFO - 2023-10-08 04:11:01 --> Helper loaded: html_helper
INFO - 2023-10-08 04:11:01 --> Helper loaded: text_helper
INFO - 2023-10-08 04:11:01 --> Helper loaded: form_helper
INFO - 2023-10-08 04:11:01 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:11:01 --> Helper loaded: security_helper
INFO - 2023-10-08 04:11:01 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:11:01 --> Database Driver Class Initialized
INFO - 2023-10-08 04:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:11:01 --> Parser Class Initialized
INFO - 2023-10-08 04:11:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:11:01 --> Pagination Class Initialized
INFO - 2023-10-08 04:11:01 --> Form Validation Class Initialized
INFO - 2023-10-08 04:11:01 --> Controller Class Initialized
INFO - 2023-10-08 04:11:01 --> Model Class Initialized
DEBUG - 2023-10-08 04:11:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:11:01 --> Model Class Initialized
DEBUG - 2023-10-08 04:11:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:11:01 --> Model Class Initialized
INFO - 2023-10-08 04:11:01 --> Model Class Initialized
INFO - 2023-10-08 04:11:01 --> Model Class Initialized
INFO - 2023-10-08 04:11:01 --> Model Class Initialized
DEBUG - 2023-10-08 04:11:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:11:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:11:01 --> Model Class Initialized
INFO - 2023-10-08 04:11:01 --> Model Class Initialized
INFO - 2023-10-08 04:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-08 04:11:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:11:01 --> Model Class Initialized
INFO - 2023-10-08 04:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:11:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:11:01 --> Final output sent to browser
DEBUG - 2023-10-08 04:11:01 --> Total execution time: 0.1301
ERROR - 2023-10-08 04:11:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:11:08 --> Config Class Initialized
INFO - 2023-10-08 04:11:08 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:11:08 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:11:08 --> Utf8 Class Initialized
INFO - 2023-10-08 04:11:08 --> URI Class Initialized
INFO - 2023-10-08 04:11:08 --> Router Class Initialized
INFO - 2023-10-08 04:11:08 --> Output Class Initialized
INFO - 2023-10-08 04:11:08 --> Security Class Initialized
DEBUG - 2023-10-08 04:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:11:08 --> Input Class Initialized
INFO - 2023-10-08 04:11:08 --> Language Class Initialized
INFO - 2023-10-08 04:11:08 --> Loader Class Initialized
INFO - 2023-10-08 04:11:08 --> Helper loaded: url_helper
INFO - 2023-10-08 04:11:08 --> Helper loaded: file_helper
INFO - 2023-10-08 04:11:08 --> Helper loaded: html_helper
INFO - 2023-10-08 04:11:08 --> Helper loaded: text_helper
INFO - 2023-10-08 04:11:08 --> Helper loaded: form_helper
INFO - 2023-10-08 04:11:08 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:11:08 --> Helper loaded: security_helper
INFO - 2023-10-08 04:11:08 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:11:08 --> Database Driver Class Initialized
INFO - 2023-10-08 04:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:11:08 --> Parser Class Initialized
INFO - 2023-10-08 04:11:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:11:08 --> Pagination Class Initialized
INFO - 2023-10-08 04:11:08 --> Form Validation Class Initialized
INFO - 2023-10-08 04:11:08 --> Controller Class Initialized
INFO - 2023-10-08 04:11:08 --> Model Class Initialized
DEBUG - 2023-10-08 04:11:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:11:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:11:08 --> Model Class Initialized
DEBUG - 2023-10-08 04:11:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:11:08 --> Model Class Initialized
INFO - 2023-10-08 04:11:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-10-08 04:11:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:11:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:11:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:11:09 --> Model Class Initialized
INFO - 2023-10-08 04:11:09 --> Model Class Initialized
INFO - 2023-10-08 04:11:09 --> Model Class Initialized
INFO - 2023-10-08 04:11:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:11:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:11:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:11:09 --> Final output sent to browser
DEBUG - 2023-10-08 04:11:09 --> Total execution time: 0.1283
ERROR - 2023-10-08 04:11:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:11:10 --> Config Class Initialized
INFO - 2023-10-08 04:11:10 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:11:10 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:11:10 --> Utf8 Class Initialized
INFO - 2023-10-08 04:11:10 --> URI Class Initialized
INFO - 2023-10-08 04:11:10 --> Router Class Initialized
INFO - 2023-10-08 04:11:10 --> Output Class Initialized
INFO - 2023-10-08 04:11:10 --> Security Class Initialized
DEBUG - 2023-10-08 04:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:11:10 --> Input Class Initialized
INFO - 2023-10-08 04:11:10 --> Language Class Initialized
INFO - 2023-10-08 04:11:10 --> Loader Class Initialized
INFO - 2023-10-08 04:11:10 --> Helper loaded: url_helper
INFO - 2023-10-08 04:11:10 --> Helper loaded: file_helper
INFO - 2023-10-08 04:11:10 --> Helper loaded: html_helper
INFO - 2023-10-08 04:11:10 --> Helper loaded: text_helper
INFO - 2023-10-08 04:11:10 --> Helper loaded: form_helper
INFO - 2023-10-08 04:11:10 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:11:10 --> Helper loaded: security_helper
INFO - 2023-10-08 04:11:10 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:11:10 --> Database Driver Class Initialized
INFO - 2023-10-08 04:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:11:10 --> Parser Class Initialized
INFO - 2023-10-08 04:11:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:11:10 --> Pagination Class Initialized
INFO - 2023-10-08 04:11:10 --> Form Validation Class Initialized
INFO - 2023-10-08 04:11:10 --> Controller Class Initialized
INFO - 2023-10-08 04:11:10 --> Model Class Initialized
DEBUG - 2023-10-08 04:11:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:11:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:11:10 --> Model Class Initialized
DEBUG - 2023-10-08 04:11:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:11:10 --> Model Class Initialized
INFO - 2023-10-08 04:11:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-08 04:11:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:11:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:11:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:11:10 --> Model Class Initialized
INFO - 2023-10-08 04:11:10 --> Model Class Initialized
INFO - 2023-10-08 04:11:10 --> Model Class Initialized
INFO - 2023-10-08 04:11:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:11:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:11:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:11:10 --> Final output sent to browser
DEBUG - 2023-10-08 04:11:10 --> Total execution time: 0.0961
ERROR - 2023-10-08 04:11:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:11:11 --> Config Class Initialized
INFO - 2023-10-08 04:11:11 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:11:11 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:11:11 --> Utf8 Class Initialized
INFO - 2023-10-08 04:11:11 --> URI Class Initialized
INFO - 2023-10-08 04:11:11 --> Router Class Initialized
INFO - 2023-10-08 04:11:11 --> Output Class Initialized
INFO - 2023-10-08 04:11:11 --> Security Class Initialized
DEBUG - 2023-10-08 04:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:11:11 --> Input Class Initialized
INFO - 2023-10-08 04:11:11 --> Language Class Initialized
INFO - 2023-10-08 04:11:11 --> Loader Class Initialized
INFO - 2023-10-08 04:11:11 --> Helper loaded: url_helper
INFO - 2023-10-08 04:11:11 --> Helper loaded: file_helper
INFO - 2023-10-08 04:11:11 --> Helper loaded: html_helper
INFO - 2023-10-08 04:11:11 --> Helper loaded: text_helper
INFO - 2023-10-08 04:11:11 --> Helper loaded: form_helper
INFO - 2023-10-08 04:11:11 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:11:11 --> Helper loaded: security_helper
INFO - 2023-10-08 04:11:11 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:11:11 --> Database Driver Class Initialized
INFO - 2023-10-08 04:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:11:11 --> Parser Class Initialized
INFO - 2023-10-08 04:11:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:11:11 --> Pagination Class Initialized
INFO - 2023-10-08 04:11:11 --> Form Validation Class Initialized
INFO - 2023-10-08 04:11:11 --> Controller Class Initialized
INFO - 2023-10-08 04:11:11 --> Model Class Initialized
DEBUG - 2023-10-08 04:11:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:11:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:11:11 --> Model Class Initialized
DEBUG - 2023-10-08 04:11:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:11:11 --> Model Class Initialized
INFO - 2023-10-08 04:11:11 --> Final output sent to browser
DEBUG - 2023-10-08 04:11:11 --> Total execution time: 0.0880
ERROR - 2023-10-08 04:11:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:11:12 --> Config Class Initialized
INFO - 2023-10-08 04:11:12 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:11:12 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:11:12 --> Utf8 Class Initialized
INFO - 2023-10-08 04:11:12 --> URI Class Initialized
INFO - 2023-10-08 04:11:12 --> Router Class Initialized
INFO - 2023-10-08 04:11:12 --> Output Class Initialized
INFO - 2023-10-08 04:11:12 --> Security Class Initialized
DEBUG - 2023-10-08 04:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:11:12 --> Input Class Initialized
INFO - 2023-10-08 04:11:12 --> Language Class Initialized
INFO - 2023-10-08 04:11:12 --> Loader Class Initialized
INFO - 2023-10-08 04:11:12 --> Helper loaded: url_helper
INFO - 2023-10-08 04:11:12 --> Helper loaded: file_helper
INFO - 2023-10-08 04:11:12 --> Helper loaded: html_helper
INFO - 2023-10-08 04:11:12 --> Helper loaded: text_helper
INFO - 2023-10-08 04:11:12 --> Helper loaded: form_helper
INFO - 2023-10-08 04:11:12 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:11:12 --> Helper loaded: security_helper
INFO - 2023-10-08 04:11:12 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:11:12 --> Database Driver Class Initialized
INFO - 2023-10-08 04:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:11:12 --> Parser Class Initialized
INFO - 2023-10-08 04:11:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:11:12 --> Pagination Class Initialized
INFO - 2023-10-08 04:11:12 --> Form Validation Class Initialized
INFO - 2023-10-08 04:11:12 --> Controller Class Initialized
INFO - 2023-10-08 04:11:12 --> Model Class Initialized
DEBUG - 2023-10-08 04:11:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:11:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:11:12 --> Model Class Initialized
DEBUG - 2023-10-08 04:11:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:11:12 --> Model Class Initialized
INFO - 2023-10-08 04:11:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-08 04:11:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:11:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:11:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:11:12 --> Model Class Initialized
INFO - 2023-10-08 04:11:12 --> Model Class Initialized
INFO - 2023-10-08 04:11:12 --> Model Class Initialized
INFO - 2023-10-08 04:11:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:11:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:11:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:11:12 --> Final output sent to browser
DEBUG - 2023-10-08 04:11:12 --> Total execution time: 0.0985
ERROR - 2023-10-08 04:11:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:11:15 --> Config Class Initialized
INFO - 2023-10-08 04:11:15 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:11:15 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:11:15 --> Utf8 Class Initialized
INFO - 2023-10-08 04:11:15 --> URI Class Initialized
INFO - 2023-10-08 04:11:15 --> Router Class Initialized
INFO - 2023-10-08 04:11:15 --> Output Class Initialized
INFO - 2023-10-08 04:11:15 --> Security Class Initialized
DEBUG - 2023-10-08 04:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:11:15 --> Input Class Initialized
INFO - 2023-10-08 04:11:15 --> Language Class Initialized
INFO - 2023-10-08 04:11:15 --> Loader Class Initialized
INFO - 2023-10-08 04:11:15 --> Helper loaded: url_helper
INFO - 2023-10-08 04:11:15 --> Helper loaded: file_helper
INFO - 2023-10-08 04:11:15 --> Helper loaded: html_helper
INFO - 2023-10-08 04:11:15 --> Helper loaded: text_helper
INFO - 2023-10-08 04:11:15 --> Helper loaded: form_helper
INFO - 2023-10-08 04:11:15 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:11:15 --> Helper loaded: security_helper
INFO - 2023-10-08 04:11:15 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:11:15 --> Database Driver Class Initialized
INFO - 2023-10-08 04:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:11:15 --> Parser Class Initialized
INFO - 2023-10-08 04:11:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:11:15 --> Pagination Class Initialized
INFO - 2023-10-08 04:11:15 --> Form Validation Class Initialized
INFO - 2023-10-08 04:11:15 --> Controller Class Initialized
INFO - 2023-10-08 04:11:15 --> Model Class Initialized
DEBUG - 2023-10-08 04:11:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:11:15 --> Model Class Initialized
DEBUG - 2023-10-08 04:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:11:15 --> Model Class Initialized
DEBUG - 2023-10-08 04:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:11:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-08 04:11:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:11:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:11:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:11:15 --> Model Class Initialized
INFO - 2023-10-08 04:11:15 --> Model Class Initialized
INFO - 2023-10-08 04:11:15 --> Model Class Initialized
INFO - 2023-10-08 04:11:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:11:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:11:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:11:16 --> Final output sent to browser
DEBUG - 2023-10-08 04:11:16 --> Total execution time: 0.1885
ERROR - 2023-10-08 04:11:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:11:34 --> Config Class Initialized
INFO - 2023-10-08 04:11:34 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:11:34 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:11:34 --> Utf8 Class Initialized
INFO - 2023-10-08 04:11:34 --> URI Class Initialized
INFO - 2023-10-08 04:11:34 --> Router Class Initialized
INFO - 2023-10-08 04:11:34 --> Output Class Initialized
INFO - 2023-10-08 04:11:34 --> Security Class Initialized
DEBUG - 2023-10-08 04:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:11:34 --> Input Class Initialized
INFO - 2023-10-08 04:11:34 --> Language Class Initialized
INFO - 2023-10-08 04:11:34 --> Loader Class Initialized
INFO - 2023-10-08 04:11:34 --> Helper loaded: url_helper
INFO - 2023-10-08 04:11:34 --> Helper loaded: file_helper
INFO - 2023-10-08 04:11:34 --> Helper loaded: html_helper
INFO - 2023-10-08 04:11:34 --> Helper loaded: text_helper
INFO - 2023-10-08 04:11:34 --> Helper loaded: form_helper
INFO - 2023-10-08 04:11:34 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:11:34 --> Helper loaded: security_helper
INFO - 2023-10-08 04:11:34 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:11:34 --> Database Driver Class Initialized
INFO - 2023-10-08 04:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:11:34 --> Parser Class Initialized
INFO - 2023-10-08 04:11:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:11:34 --> Pagination Class Initialized
INFO - 2023-10-08 04:11:34 --> Form Validation Class Initialized
INFO - 2023-10-08 04:11:34 --> Controller Class Initialized
DEBUG - 2023-10-08 04:11:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:11:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:11:34 --> Model Class Initialized
DEBUG - 2023-10-08 04:11:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:11:34 --> Model Class Initialized
DEBUG - 2023-10-08 04:11:34 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:11:34 --> Model Class Initialized
INFO - 2023-10-08 04:11:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-10-08 04:11:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:11:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:11:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:11:34 --> Model Class Initialized
INFO - 2023-10-08 04:11:34 --> Model Class Initialized
INFO - 2023-10-08 04:11:34 --> Model Class Initialized
INFO - 2023-10-08 04:11:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:11:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:11:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:11:34 --> Final output sent to browser
DEBUG - 2023-10-08 04:11:34 --> Total execution time: 0.1098
ERROR - 2023-10-08 04:11:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:11:35 --> Config Class Initialized
INFO - 2023-10-08 04:11:35 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:11:35 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:11:35 --> Utf8 Class Initialized
INFO - 2023-10-08 04:11:35 --> URI Class Initialized
INFO - 2023-10-08 04:11:35 --> Router Class Initialized
INFO - 2023-10-08 04:11:35 --> Output Class Initialized
INFO - 2023-10-08 04:11:35 --> Security Class Initialized
DEBUG - 2023-10-08 04:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:11:35 --> Input Class Initialized
INFO - 2023-10-08 04:11:35 --> Language Class Initialized
INFO - 2023-10-08 04:11:35 --> Loader Class Initialized
INFO - 2023-10-08 04:11:35 --> Helper loaded: url_helper
INFO - 2023-10-08 04:11:35 --> Helper loaded: file_helper
INFO - 2023-10-08 04:11:35 --> Helper loaded: html_helper
INFO - 2023-10-08 04:11:35 --> Helper loaded: text_helper
INFO - 2023-10-08 04:11:35 --> Helper loaded: form_helper
INFO - 2023-10-08 04:11:35 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:11:35 --> Helper loaded: security_helper
INFO - 2023-10-08 04:11:35 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:11:35 --> Database Driver Class Initialized
INFO - 2023-10-08 04:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:11:35 --> Parser Class Initialized
INFO - 2023-10-08 04:11:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:11:35 --> Pagination Class Initialized
INFO - 2023-10-08 04:11:35 --> Form Validation Class Initialized
INFO - 2023-10-08 04:11:35 --> Controller Class Initialized
DEBUG - 2023-10-08 04:11:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:11:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:11:35 --> Model Class Initialized
DEBUG - 2023-10-08 04:11:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:11:35 --> Model Class Initialized
INFO - 2023-10-08 04:11:35 --> Final output sent to browser
DEBUG - 2023-10-08 04:11:35 --> Total execution time: 0.0218
ERROR - 2023-10-08 04:11:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:11:43 --> Config Class Initialized
INFO - 2023-10-08 04:11:43 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:11:43 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:11:43 --> Utf8 Class Initialized
INFO - 2023-10-08 04:11:43 --> URI Class Initialized
INFO - 2023-10-08 04:11:43 --> Router Class Initialized
INFO - 2023-10-08 04:11:43 --> Output Class Initialized
INFO - 2023-10-08 04:11:43 --> Security Class Initialized
DEBUG - 2023-10-08 04:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:11:43 --> Input Class Initialized
INFO - 2023-10-08 04:11:43 --> Language Class Initialized
INFO - 2023-10-08 04:11:43 --> Loader Class Initialized
INFO - 2023-10-08 04:11:43 --> Helper loaded: url_helper
INFO - 2023-10-08 04:11:43 --> Helper loaded: file_helper
INFO - 2023-10-08 04:11:43 --> Helper loaded: html_helper
INFO - 2023-10-08 04:11:43 --> Helper loaded: text_helper
INFO - 2023-10-08 04:11:43 --> Helper loaded: form_helper
INFO - 2023-10-08 04:11:43 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:11:43 --> Helper loaded: security_helper
INFO - 2023-10-08 04:11:43 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:11:43 --> Database Driver Class Initialized
INFO - 2023-10-08 04:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:11:43 --> Parser Class Initialized
INFO - 2023-10-08 04:11:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:11:43 --> Pagination Class Initialized
INFO - 2023-10-08 04:11:43 --> Form Validation Class Initialized
INFO - 2023-10-08 04:11:43 --> Controller Class Initialized
DEBUG - 2023-10-08 04:11:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:11:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:11:43 --> Model Class Initialized
DEBUG - 2023-10-08 04:11:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:11:43 --> Model Class Initialized
INFO - 2023-10-08 04:11:43 --> Final output sent to browser
DEBUG - 2023-10-08 04:11:43 --> Total execution time: 0.0210
ERROR - 2023-10-08 04:12:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:12:08 --> Config Class Initialized
INFO - 2023-10-08 04:12:08 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:12:08 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:12:08 --> Utf8 Class Initialized
INFO - 2023-10-08 04:12:08 --> URI Class Initialized
DEBUG - 2023-10-08 04:12:08 --> No URI present. Default controller set.
INFO - 2023-10-08 04:12:08 --> Router Class Initialized
INFO - 2023-10-08 04:12:08 --> Output Class Initialized
INFO - 2023-10-08 04:12:08 --> Security Class Initialized
DEBUG - 2023-10-08 04:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:12:08 --> Input Class Initialized
INFO - 2023-10-08 04:12:08 --> Language Class Initialized
INFO - 2023-10-08 04:12:08 --> Loader Class Initialized
INFO - 2023-10-08 04:12:08 --> Helper loaded: url_helper
INFO - 2023-10-08 04:12:08 --> Helper loaded: file_helper
INFO - 2023-10-08 04:12:08 --> Helper loaded: html_helper
INFO - 2023-10-08 04:12:08 --> Helper loaded: text_helper
INFO - 2023-10-08 04:12:08 --> Helper loaded: form_helper
INFO - 2023-10-08 04:12:08 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:12:08 --> Helper loaded: security_helper
INFO - 2023-10-08 04:12:08 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:12:08 --> Database Driver Class Initialized
INFO - 2023-10-08 04:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:12:08 --> Parser Class Initialized
INFO - 2023-10-08 04:12:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:12:08 --> Pagination Class Initialized
INFO - 2023-10-08 04:12:08 --> Form Validation Class Initialized
INFO - 2023-10-08 04:12:08 --> Controller Class Initialized
INFO - 2023-10-08 04:12:08 --> Model Class Initialized
DEBUG - 2023-10-08 04:12:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:12:08 --> Model Class Initialized
DEBUG - 2023-10-08 04:12:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:12:08 --> Model Class Initialized
INFO - 2023-10-08 04:12:08 --> Model Class Initialized
INFO - 2023-10-08 04:12:08 --> Model Class Initialized
INFO - 2023-10-08 04:12:08 --> Model Class Initialized
DEBUG - 2023-10-08 04:12:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:12:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:12:08 --> Model Class Initialized
INFO - 2023-10-08 04:12:08 --> Model Class Initialized
INFO - 2023-10-08 04:12:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-08 04:12:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:12:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:12:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:12:08 --> Model Class Initialized
INFO - 2023-10-08 04:12:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:12:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:12:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:12:08 --> Final output sent to browser
DEBUG - 2023-10-08 04:12:08 --> Total execution time: 0.1235
ERROR - 2023-10-08 04:12:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:12:26 --> Config Class Initialized
INFO - 2023-10-08 04:12:26 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:12:26 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:12:26 --> Utf8 Class Initialized
INFO - 2023-10-08 04:12:26 --> URI Class Initialized
INFO - 2023-10-08 04:12:26 --> Router Class Initialized
INFO - 2023-10-08 04:12:26 --> Output Class Initialized
INFO - 2023-10-08 04:12:26 --> Security Class Initialized
DEBUG - 2023-10-08 04:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:12:26 --> Input Class Initialized
INFO - 2023-10-08 04:12:26 --> Language Class Initialized
INFO - 2023-10-08 04:12:26 --> Loader Class Initialized
INFO - 2023-10-08 04:12:26 --> Helper loaded: url_helper
INFO - 2023-10-08 04:12:26 --> Helper loaded: file_helper
INFO - 2023-10-08 04:12:26 --> Helper loaded: html_helper
INFO - 2023-10-08 04:12:26 --> Helper loaded: text_helper
INFO - 2023-10-08 04:12:26 --> Helper loaded: form_helper
INFO - 2023-10-08 04:12:26 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:12:26 --> Helper loaded: security_helper
INFO - 2023-10-08 04:12:26 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:12:26 --> Database Driver Class Initialized
INFO - 2023-10-08 04:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:12:26 --> Parser Class Initialized
INFO - 2023-10-08 04:12:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:12:26 --> Pagination Class Initialized
INFO - 2023-10-08 04:12:26 --> Form Validation Class Initialized
INFO - 2023-10-08 04:12:26 --> Controller Class Initialized
INFO - 2023-10-08 04:12:26 --> Model Class Initialized
DEBUG - 2023-10-08 04:12:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:12:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:12:26 --> Model Class Initialized
INFO - 2023-10-08 04:12:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-10-08 04:12:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:12:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:12:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:12:26 --> Model Class Initialized
INFO - 2023-10-08 04:12:26 --> Model Class Initialized
INFO - 2023-10-08 04:12:26 --> Model Class Initialized
INFO - 2023-10-08 04:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:12:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:12:27 --> Final output sent to browser
DEBUG - 2023-10-08 04:12:27 --> Total execution time: 0.1012
ERROR - 2023-10-08 04:12:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:12:27 --> Config Class Initialized
INFO - 2023-10-08 04:12:27 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:12:27 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:12:27 --> Utf8 Class Initialized
INFO - 2023-10-08 04:12:27 --> URI Class Initialized
INFO - 2023-10-08 04:12:27 --> Router Class Initialized
INFO - 2023-10-08 04:12:27 --> Output Class Initialized
INFO - 2023-10-08 04:12:27 --> Security Class Initialized
DEBUG - 2023-10-08 04:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:12:27 --> Input Class Initialized
INFO - 2023-10-08 04:12:27 --> Language Class Initialized
INFO - 2023-10-08 04:12:27 --> Loader Class Initialized
INFO - 2023-10-08 04:12:27 --> Helper loaded: url_helper
INFO - 2023-10-08 04:12:27 --> Helper loaded: file_helper
INFO - 2023-10-08 04:12:27 --> Helper loaded: html_helper
INFO - 2023-10-08 04:12:27 --> Helper loaded: text_helper
INFO - 2023-10-08 04:12:27 --> Helper loaded: form_helper
INFO - 2023-10-08 04:12:27 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:12:27 --> Helper loaded: security_helper
INFO - 2023-10-08 04:12:27 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:12:27 --> Database Driver Class Initialized
INFO - 2023-10-08 04:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:12:27 --> Parser Class Initialized
INFO - 2023-10-08 04:12:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:12:27 --> Pagination Class Initialized
INFO - 2023-10-08 04:12:27 --> Form Validation Class Initialized
INFO - 2023-10-08 04:12:27 --> Controller Class Initialized
INFO - 2023-10-08 04:12:27 --> Model Class Initialized
DEBUG - 2023-10-08 04:12:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:12:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:12:27 --> Model Class Initialized
INFO - 2023-10-08 04:12:27 --> Final output sent to browser
DEBUG - 2023-10-08 04:12:27 --> Total execution time: 0.0242
ERROR - 2023-10-08 04:12:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:12:30 --> Config Class Initialized
INFO - 2023-10-08 04:12:30 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:12:30 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:12:30 --> Utf8 Class Initialized
INFO - 2023-10-08 04:12:30 --> URI Class Initialized
INFO - 2023-10-08 04:12:30 --> Router Class Initialized
INFO - 2023-10-08 04:12:30 --> Output Class Initialized
INFO - 2023-10-08 04:12:30 --> Security Class Initialized
DEBUG - 2023-10-08 04:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:12:30 --> Input Class Initialized
INFO - 2023-10-08 04:12:30 --> Language Class Initialized
INFO - 2023-10-08 04:12:30 --> Loader Class Initialized
INFO - 2023-10-08 04:12:30 --> Helper loaded: url_helper
INFO - 2023-10-08 04:12:30 --> Helper loaded: file_helper
INFO - 2023-10-08 04:12:30 --> Helper loaded: html_helper
INFO - 2023-10-08 04:12:30 --> Helper loaded: text_helper
INFO - 2023-10-08 04:12:30 --> Helper loaded: form_helper
INFO - 2023-10-08 04:12:30 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:12:30 --> Helper loaded: security_helper
INFO - 2023-10-08 04:12:30 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:12:30 --> Database Driver Class Initialized
INFO - 2023-10-08 04:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:12:30 --> Parser Class Initialized
INFO - 2023-10-08 04:12:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:12:30 --> Pagination Class Initialized
INFO - 2023-10-08 04:12:30 --> Form Validation Class Initialized
INFO - 2023-10-08 04:12:30 --> Controller Class Initialized
INFO - 2023-10-08 04:12:30 --> Model Class Initialized
DEBUG - 2023-10-08 04:12:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:12:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:12:30 --> Model Class Initialized
INFO - 2023-10-08 04:12:30 --> Final output sent to browser
DEBUG - 2023-10-08 04:12:30 --> Total execution time: 0.0281
ERROR - 2023-10-08 04:26:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:26:47 --> Config Class Initialized
INFO - 2023-10-08 04:26:47 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:26:47 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:26:47 --> Utf8 Class Initialized
INFO - 2023-10-08 04:26:47 --> URI Class Initialized
DEBUG - 2023-10-08 04:26:47 --> No URI present. Default controller set.
INFO - 2023-10-08 04:26:47 --> Router Class Initialized
INFO - 2023-10-08 04:26:47 --> Output Class Initialized
INFO - 2023-10-08 04:26:47 --> Security Class Initialized
DEBUG - 2023-10-08 04:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:26:47 --> Input Class Initialized
INFO - 2023-10-08 04:26:47 --> Language Class Initialized
INFO - 2023-10-08 04:26:47 --> Loader Class Initialized
INFO - 2023-10-08 04:26:47 --> Helper loaded: url_helper
INFO - 2023-10-08 04:26:47 --> Helper loaded: file_helper
INFO - 2023-10-08 04:26:47 --> Helper loaded: html_helper
INFO - 2023-10-08 04:26:47 --> Helper loaded: text_helper
INFO - 2023-10-08 04:26:47 --> Helper loaded: form_helper
INFO - 2023-10-08 04:26:47 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:26:47 --> Helper loaded: security_helper
INFO - 2023-10-08 04:26:47 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:26:47 --> Database Driver Class Initialized
INFO - 2023-10-08 04:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:26:47 --> Parser Class Initialized
INFO - 2023-10-08 04:26:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:26:47 --> Pagination Class Initialized
INFO - 2023-10-08 04:26:47 --> Form Validation Class Initialized
INFO - 2023-10-08 04:26:47 --> Controller Class Initialized
INFO - 2023-10-08 04:26:47 --> Model Class Initialized
DEBUG - 2023-10-08 04:26:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:47 --> Model Class Initialized
DEBUG - 2023-10-08 04:26:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:47 --> Model Class Initialized
INFO - 2023-10-08 04:26:47 --> Model Class Initialized
INFO - 2023-10-08 04:26:47 --> Model Class Initialized
INFO - 2023-10-08 04:26:47 --> Model Class Initialized
DEBUG - 2023-10-08 04:26:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:26:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:47 --> Model Class Initialized
INFO - 2023-10-08 04:26:47 --> Model Class Initialized
INFO - 2023-10-08 04:26:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-08 04:26:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:26:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:26:47 --> Model Class Initialized
INFO - 2023-10-08 04:26:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:26:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:26:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:26:47 --> Final output sent to browser
DEBUG - 2023-10-08 04:26:47 --> Total execution time: 0.1325
ERROR - 2023-10-08 04:26:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:26:48 --> Config Class Initialized
INFO - 2023-10-08 04:26:48 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:26:48 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:26:48 --> Utf8 Class Initialized
INFO - 2023-10-08 04:26:48 --> URI Class Initialized
DEBUG - 2023-10-08 04:26:48 --> No URI present. Default controller set.
INFO - 2023-10-08 04:26:48 --> Router Class Initialized
INFO - 2023-10-08 04:26:48 --> Output Class Initialized
INFO - 2023-10-08 04:26:48 --> Security Class Initialized
DEBUG - 2023-10-08 04:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:26:48 --> Input Class Initialized
INFO - 2023-10-08 04:26:48 --> Language Class Initialized
INFO - 2023-10-08 04:26:48 --> Loader Class Initialized
INFO - 2023-10-08 04:26:48 --> Helper loaded: url_helper
INFO - 2023-10-08 04:26:48 --> Helper loaded: file_helper
INFO - 2023-10-08 04:26:48 --> Helper loaded: html_helper
INFO - 2023-10-08 04:26:48 --> Helper loaded: text_helper
INFO - 2023-10-08 04:26:48 --> Helper loaded: form_helper
INFO - 2023-10-08 04:26:48 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:26:48 --> Helper loaded: security_helper
INFO - 2023-10-08 04:26:48 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:26:48 --> Database Driver Class Initialized
INFO - 2023-10-08 04:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:26:48 --> Parser Class Initialized
INFO - 2023-10-08 04:26:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:26:48 --> Pagination Class Initialized
INFO - 2023-10-08 04:26:48 --> Form Validation Class Initialized
INFO - 2023-10-08 04:26:48 --> Controller Class Initialized
INFO - 2023-10-08 04:26:48 --> Model Class Initialized
DEBUG - 2023-10-08 04:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:48 --> Model Class Initialized
DEBUG - 2023-10-08 04:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:48 --> Model Class Initialized
INFO - 2023-10-08 04:26:48 --> Model Class Initialized
INFO - 2023-10-08 04:26:48 --> Model Class Initialized
INFO - 2023-10-08 04:26:48 --> Model Class Initialized
DEBUG - 2023-10-08 04:26:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:48 --> Model Class Initialized
INFO - 2023-10-08 04:26:48 --> Model Class Initialized
INFO - 2023-10-08 04:26:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-08 04:26:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:26:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:26:48 --> Model Class Initialized
INFO - 2023-10-08 04:26:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:26:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:26:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:26:48 --> Final output sent to browser
DEBUG - 2023-10-08 04:26:48 --> Total execution time: 0.1253
ERROR - 2023-10-08 04:26:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:26:48 --> Config Class Initialized
INFO - 2023-10-08 04:26:48 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:26:48 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:26:48 --> Utf8 Class Initialized
INFO - 2023-10-08 04:26:48 --> URI Class Initialized
DEBUG - 2023-10-08 04:26:48 --> No URI present. Default controller set.
INFO - 2023-10-08 04:26:48 --> Router Class Initialized
INFO - 2023-10-08 04:26:48 --> Output Class Initialized
INFO - 2023-10-08 04:26:48 --> Security Class Initialized
DEBUG - 2023-10-08 04:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:26:48 --> Input Class Initialized
INFO - 2023-10-08 04:26:48 --> Language Class Initialized
INFO - 2023-10-08 04:26:48 --> Loader Class Initialized
INFO - 2023-10-08 04:26:48 --> Helper loaded: url_helper
INFO - 2023-10-08 04:26:48 --> Helper loaded: file_helper
INFO - 2023-10-08 04:26:48 --> Helper loaded: html_helper
INFO - 2023-10-08 04:26:48 --> Helper loaded: text_helper
INFO - 2023-10-08 04:26:48 --> Helper loaded: form_helper
INFO - 2023-10-08 04:26:48 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:26:48 --> Helper loaded: security_helper
INFO - 2023-10-08 04:26:48 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:26:48 --> Database Driver Class Initialized
INFO - 2023-10-08 04:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:26:48 --> Parser Class Initialized
INFO - 2023-10-08 04:26:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:26:48 --> Pagination Class Initialized
INFO - 2023-10-08 04:26:48 --> Form Validation Class Initialized
INFO - 2023-10-08 04:26:48 --> Controller Class Initialized
INFO - 2023-10-08 04:26:48 --> Model Class Initialized
DEBUG - 2023-10-08 04:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:48 --> Model Class Initialized
DEBUG - 2023-10-08 04:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:48 --> Model Class Initialized
INFO - 2023-10-08 04:26:48 --> Model Class Initialized
INFO - 2023-10-08 04:26:48 --> Model Class Initialized
INFO - 2023-10-08 04:26:48 --> Model Class Initialized
DEBUG - 2023-10-08 04:26:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:48 --> Model Class Initialized
INFO - 2023-10-08 04:26:48 --> Model Class Initialized
INFO - 2023-10-08 04:26:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-08 04:26:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:26:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:26:48 --> Model Class Initialized
INFO - 2023-10-08 04:26:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:26:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:26:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:26:48 --> Final output sent to browser
DEBUG - 2023-10-08 04:26:48 --> Total execution time: 0.1157
ERROR - 2023-10-08 04:26:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:26:48 --> Config Class Initialized
INFO - 2023-10-08 04:26:48 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:26:48 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:26:48 --> Utf8 Class Initialized
INFO - 2023-10-08 04:26:48 --> URI Class Initialized
DEBUG - 2023-10-08 04:26:48 --> No URI present. Default controller set.
INFO - 2023-10-08 04:26:48 --> Router Class Initialized
INFO - 2023-10-08 04:26:48 --> Output Class Initialized
INFO - 2023-10-08 04:26:48 --> Security Class Initialized
DEBUG - 2023-10-08 04:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:26:48 --> Input Class Initialized
INFO - 2023-10-08 04:26:48 --> Language Class Initialized
INFO - 2023-10-08 04:26:48 --> Loader Class Initialized
INFO - 2023-10-08 04:26:48 --> Helper loaded: url_helper
INFO - 2023-10-08 04:26:48 --> Helper loaded: file_helper
INFO - 2023-10-08 04:26:48 --> Helper loaded: html_helper
INFO - 2023-10-08 04:26:48 --> Helper loaded: text_helper
INFO - 2023-10-08 04:26:48 --> Helper loaded: form_helper
INFO - 2023-10-08 04:26:48 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:26:48 --> Helper loaded: security_helper
INFO - 2023-10-08 04:26:48 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:26:48 --> Database Driver Class Initialized
INFO - 2023-10-08 04:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:26:48 --> Parser Class Initialized
INFO - 2023-10-08 04:26:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:26:48 --> Pagination Class Initialized
INFO - 2023-10-08 04:26:48 --> Form Validation Class Initialized
INFO - 2023-10-08 04:26:48 --> Controller Class Initialized
INFO - 2023-10-08 04:26:48 --> Model Class Initialized
DEBUG - 2023-10-08 04:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:48 --> Model Class Initialized
DEBUG - 2023-10-08 04:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:48 --> Model Class Initialized
INFO - 2023-10-08 04:26:48 --> Model Class Initialized
INFO - 2023-10-08 04:26:48 --> Model Class Initialized
INFO - 2023-10-08 04:26:48 --> Model Class Initialized
DEBUG - 2023-10-08 04:26:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:48 --> Model Class Initialized
INFO - 2023-10-08 04:26:48 --> Model Class Initialized
INFO - 2023-10-08 04:26:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-08 04:26:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:26:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:26:48 --> Model Class Initialized
INFO - 2023-10-08 04:26:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:26:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:26:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:26:48 --> Final output sent to browser
DEBUG - 2023-10-08 04:26:48 --> Total execution time: 0.1197
ERROR - 2023-10-08 04:26:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:26:51 --> Config Class Initialized
INFO - 2023-10-08 04:26:51 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:26:51 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:26:51 --> Utf8 Class Initialized
INFO - 2023-10-08 04:26:51 --> URI Class Initialized
DEBUG - 2023-10-08 04:26:51 --> No URI present. Default controller set.
INFO - 2023-10-08 04:26:51 --> Router Class Initialized
INFO - 2023-10-08 04:26:51 --> Output Class Initialized
INFO - 2023-10-08 04:26:51 --> Security Class Initialized
DEBUG - 2023-10-08 04:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:26:51 --> Input Class Initialized
INFO - 2023-10-08 04:26:51 --> Language Class Initialized
INFO - 2023-10-08 04:26:51 --> Loader Class Initialized
INFO - 2023-10-08 04:26:51 --> Helper loaded: url_helper
INFO - 2023-10-08 04:26:51 --> Helper loaded: file_helper
INFO - 2023-10-08 04:26:51 --> Helper loaded: html_helper
INFO - 2023-10-08 04:26:51 --> Helper loaded: text_helper
INFO - 2023-10-08 04:26:51 --> Helper loaded: form_helper
INFO - 2023-10-08 04:26:51 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:26:51 --> Helper loaded: security_helper
INFO - 2023-10-08 04:26:51 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:26:52 --> Database Driver Class Initialized
INFO - 2023-10-08 04:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:26:52 --> Parser Class Initialized
INFO - 2023-10-08 04:26:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:26:52 --> Pagination Class Initialized
INFO - 2023-10-08 04:26:52 --> Form Validation Class Initialized
INFO - 2023-10-08 04:26:52 --> Controller Class Initialized
INFO - 2023-10-08 04:26:52 --> Model Class Initialized
DEBUG - 2023-10-08 04:26:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:52 --> Model Class Initialized
DEBUG - 2023-10-08 04:26:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:52 --> Model Class Initialized
INFO - 2023-10-08 04:26:52 --> Model Class Initialized
INFO - 2023-10-08 04:26:52 --> Model Class Initialized
INFO - 2023-10-08 04:26:52 --> Model Class Initialized
DEBUG - 2023-10-08 04:26:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:26:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:52 --> Model Class Initialized
INFO - 2023-10-08 04:26:52 --> Model Class Initialized
INFO - 2023-10-08 04:26:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-08 04:26:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:26:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:26:52 --> Model Class Initialized
INFO - 2023-10-08 04:26:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:26:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:26:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:26:52 --> Final output sent to browser
DEBUG - 2023-10-08 04:26:52 --> Total execution time: 0.1172
ERROR - 2023-10-08 04:26:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:26:53 --> Config Class Initialized
INFO - 2023-10-08 04:26:53 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:26:53 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:26:53 --> Utf8 Class Initialized
INFO - 2023-10-08 04:26:53 --> URI Class Initialized
DEBUG - 2023-10-08 04:26:53 --> No URI present. Default controller set.
INFO - 2023-10-08 04:26:53 --> Router Class Initialized
INFO - 2023-10-08 04:26:53 --> Output Class Initialized
INFO - 2023-10-08 04:26:53 --> Security Class Initialized
DEBUG - 2023-10-08 04:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:26:53 --> Input Class Initialized
INFO - 2023-10-08 04:26:53 --> Language Class Initialized
INFO - 2023-10-08 04:26:53 --> Loader Class Initialized
INFO - 2023-10-08 04:26:53 --> Helper loaded: url_helper
INFO - 2023-10-08 04:26:53 --> Helper loaded: file_helper
INFO - 2023-10-08 04:26:53 --> Helper loaded: html_helper
INFO - 2023-10-08 04:26:53 --> Helper loaded: text_helper
INFO - 2023-10-08 04:26:53 --> Helper loaded: form_helper
INFO - 2023-10-08 04:26:53 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:26:53 --> Helper loaded: security_helper
INFO - 2023-10-08 04:26:53 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:26:53 --> Database Driver Class Initialized
INFO - 2023-10-08 04:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:26:53 --> Parser Class Initialized
INFO - 2023-10-08 04:26:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:26:53 --> Pagination Class Initialized
INFO - 2023-10-08 04:26:53 --> Form Validation Class Initialized
INFO - 2023-10-08 04:26:53 --> Controller Class Initialized
INFO - 2023-10-08 04:26:53 --> Model Class Initialized
DEBUG - 2023-10-08 04:26:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:53 --> Model Class Initialized
DEBUG - 2023-10-08 04:26:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:53 --> Model Class Initialized
INFO - 2023-10-08 04:26:53 --> Model Class Initialized
INFO - 2023-10-08 04:26:53 --> Model Class Initialized
INFO - 2023-10-08 04:26:53 --> Model Class Initialized
DEBUG - 2023-10-08 04:26:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:26:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:53 --> Model Class Initialized
INFO - 2023-10-08 04:26:53 --> Model Class Initialized
INFO - 2023-10-08 04:26:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-08 04:26:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:26:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:26:53 --> Model Class Initialized
INFO - 2023-10-08 04:26:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:26:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:26:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:26:53 --> Final output sent to browser
DEBUG - 2023-10-08 04:26:53 --> Total execution time: 0.1228
ERROR - 2023-10-08 04:26:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:26:54 --> Config Class Initialized
INFO - 2023-10-08 04:26:54 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:26:54 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:26:54 --> Utf8 Class Initialized
INFO - 2023-10-08 04:26:54 --> URI Class Initialized
INFO - 2023-10-08 04:26:54 --> Router Class Initialized
INFO - 2023-10-08 04:26:54 --> Output Class Initialized
INFO - 2023-10-08 04:26:54 --> Security Class Initialized
DEBUG - 2023-10-08 04:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:26:54 --> Input Class Initialized
INFO - 2023-10-08 04:26:54 --> Language Class Initialized
INFO - 2023-10-08 04:26:54 --> Loader Class Initialized
INFO - 2023-10-08 04:26:54 --> Helper loaded: url_helper
INFO - 2023-10-08 04:26:54 --> Helper loaded: file_helper
INFO - 2023-10-08 04:26:54 --> Helper loaded: html_helper
INFO - 2023-10-08 04:26:54 --> Helper loaded: text_helper
INFO - 2023-10-08 04:26:54 --> Helper loaded: form_helper
INFO - 2023-10-08 04:26:54 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:26:54 --> Helper loaded: security_helper
INFO - 2023-10-08 04:26:54 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:26:54 --> Database Driver Class Initialized
INFO - 2023-10-08 04:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:26:54 --> Parser Class Initialized
INFO - 2023-10-08 04:26:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:26:54 --> Pagination Class Initialized
INFO - 2023-10-08 04:26:54 --> Form Validation Class Initialized
INFO - 2023-10-08 04:26:54 --> Controller Class Initialized
INFO - 2023-10-08 04:26:54 --> Model Class Initialized
DEBUG - 2023-10-08 04:26:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:26:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:54 --> Model Class Initialized
DEBUG - 2023-10-08 04:26:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:54 --> Model Class Initialized
INFO - 2023-10-08 04:26:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-10-08 04:26:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:26:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:26:54 --> Model Class Initialized
INFO - 2023-10-08 04:26:54 --> Model Class Initialized
INFO - 2023-10-08 04:26:54 --> Model Class Initialized
INFO - 2023-10-08 04:26:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:26:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:26:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:26:55 --> Final output sent to browser
DEBUG - 2023-10-08 04:26:55 --> Total execution time: 0.1033
ERROR - 2023-10-08 04:26:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:26:57 --> Config Class Initialized
INFO - 2023-10-08 04:26:57 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:26:57 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:26:57 --> Utf8 Class Initialized
INFO - 2023-10-08 04:26:57 --> URI Class Initialized
INFO - 2023-10-08 04:26:57 --> Router Class Initialized
INFO - 2023-10-08 04:26:57 --> Output Class Initialized
INFO - 2023-10-08 04:26:57 --> Security Class Initialized
DEBUG - 2023-10-08 04:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:26:57 --> Input Class Initialized
INFO - 2023-10-08 04:26:57 --> Language Class Initialized
INFO - 2023-10-08 04:26:57 --> Loader Class Initialized
INFO - 2023-10-08 04:26:57 --> Helper loaded: url_helper
INFO - 2023-10-08 04:26:57 --> Helper loaded: file_helper
INFO - 2023-10-08 04:26:57 --> Helper loaded: html_helper
INFO - 2023-10-08 04:26:57 --> Helper loaded: text_helper
INFO - 2023-10-08 04:26:57 --> Helper loaded: form_helper
INFO - 2023-10-08 04:26:57 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:26:57 --> Helper loaded: security_helper
INFO - 2023-10-08 04:26:57 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:26:57 --> Database Driver Class Initialized
INFO - 2023-10-08 04:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:26:57 --> Parser Class Initialized
INFO - 2023-10-08 04:26:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:26:57 --> Pagination Class Initialized
INFO - 2023-10-08 04:26:57 --> Form Validation Class Initialized
INFO - 2023-10-08 04:26:57 --> Controller Class Initialized
INFO - 2023-10-08 04:26:57 --> Model Class Initialized
DEBUG - 2023-10-08 04:26:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:26:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:57 --> Model Class Initialized
DEBUG - 2023-10-08 04:26:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:57 --> Model Class Initialized
INFO - 2023-10-08 04:26:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-10-08 04:26:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:26:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:26:57 --> Model Class Initialized
INFO - 2023-10-08 04:26:57 --> Model Class Initialized
INFO - 2023-10-08 04:26:57 --> Model Class Initialized
INFO - 2023-10-08 04:26:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:26:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:26:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:26:57 --> Final output sent to browser
DEBUG - 2023-10-08 04:26:57 --> Total execution time: 0.0995
ERROR - 2023-10-08 04:26:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:26:57 --> Config Class Initialized
INFO - 2023-10-08 04:26:57 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:26:57 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:26:57 --> Utf8 Class Initialized
INFO - 2023-10-08 04:26:57 --> URI Class Initialized
DEBUG - 2023-10-08 04:26:57 --> No URI present. Default controller set.
INFO - 2023-10-08 04:26:57 --> Router Class Initialized
INFO - 2023-10-08 04:26:57 --> Output Class Initialized
INFO - 2023-10-08 04:26:57 --> Security Class Initialized
DEBUG - 2023-10-08 04:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:26:57 --> Input Class Initialized
INFO - 2023-10-08 04:26:57 --> Language Class Initialized
INFO - 2023-10-08 04:26:57 --> Loader Class Initialized
INFO - 2023-10-08 04:26:57 --> Helper loaded: url_helper
INFO - 2023-10-08 04:26:57 --> Helper loaded: file_helper
INFO - 2023-10-08 04:26:57 --> Helper loaded: html_helper
INFO - 2023-10-08 04:26:57 --> Helper loaded: text_helper
INFO - 2023-10-08 04:26:57 --> Helper loaded: form_helper
INFO - 2023-10-08 04:26:57 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:26:57 --> Helper loaded: security_helper
INFO - 2023-10-08 04:26:57 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:26:57 --> Database Driver Class Initialized
INFO - 2023-10-08 04:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:26:57 --> Parser Class Initialized
INFO - 2023-10-08 04:26:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:26:57 --> Pagination Class Initialized
INFO - 2023-10-08 04:26:57 --> Form Validation Class Initialized
INFO - 2023-10-08 04:26:57 --> Controller Class Initialized
INFO - 2023-10-08 04:26:57 --> Model Class Initialized
DEBUG - 2023-10-08 04:26:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:57 --> Model Class Initialized
DEBUG - 2023-10-08 04:26:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:57 --> Model Class Initialized
INFO - 2023-10-08 04:26:57 --> Model Class Initialized
INFO - 2023-10-08 04:26:57 --> Model Class Initialized
INFO - 2023-10-08 04:26:57 --> Model Class Initialized
DEBUG - 2023-10-08 04:26:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:26:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:57 --> Model Class Initialized
INFO - 2023-10-08 04:26:57 --> Model Class Initialized
INFO - 2023-10-08 04:26:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-08 04:26:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:26:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:26:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:26:57 --> Model Class Initialized
INFO - 2023-10-08 04:26:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:26:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:26:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:26:57 --> Final output sent to browser
DEBUG - 2023-10-08 04:26:57 --> Total execution time: 0.1137
ERROR - 2023-10-08 04:27:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:27:10 --> Config Class Initialized
INFO - 2023-10-08 04:27:10 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:27:10 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:27:10 --> Utf8 Class Initialized
INFO - 2023-10-08 04:27:10 --> URI Class Initialized
DEBUG - 2023-10-08 04:27:10 --> No URI present. Default controller set.
INFO - 2023-10-08 04:27:10 --> Router Class Initialized
INFO - 2023-10-08 04:27:10 --> Output Class Initialized
INFO - 2023-10-08 04:27:10 --> Security Class Initialized
DEBUG - 2023-10-08 04:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:27:10 --> Input Class Initialized
INFO - 2023-10-08 04:27:10 --> Language Class Initialized
INFO - 2023-10-08 04:27:10 --> Loader Class Initialized
INFO - 2023-10-08 04:27:10 --> Helper loaded: url_helper
INFO - 2023-10-08 04:27:10 --> Helper loaded: file_helper
INFO - 2023-10-08 04:27:10 --> Helper loaded: html_helper
INFO - 2023-10-08 04:27:10 --> Helper loaded: text_helper
INFO - 2023-10-08 04:27:10 --> Helper loaded: form_helper
INFO - 2023-10-08 04:27:10 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:27:10 --> Helper loaded: security_helper
INFO - 2023-10-08 04:27:10 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:27:10 --> Database Driver Class Initialized
INFO - 2023-10-08 04:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:27:10 --> Parser Class Initialized
INFO - 2023-10-08 04:27:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:27:10 --> Pagination Class Initialized
INFO - 2023-10-08 04:27:10 --> Form Validation Class Initialized
INFO - 2023-10-08 04:27:10 --> Controller Class Initialized
INFO - 2023-10-08 04:27:10 --> Model Class Initialized
DEBUG - 2023-10-08 04:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:27:10 --> Model Class Initialized
DEBUG - 2023-10-08 04:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:27:10 --> Model Class Initialized
INFO - 2023-10-08 04:27:10 --> Model Class Initialized
INFO - 2023-10-08 04:27:10 --> Model Class Initialized
INFO - 2023-10-08 04:27:10 --> Model Class Initialized
DEBUG - 2023-10-08 04:27:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:27:10 --> Model Class Initialized
INFO - 2023-10-08 04:27:10 --> Model Class Initialized
INFO - 2023-10-08 04:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-08 04:27:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:27:10 --> Model Class Initialized
INFO - 2023-10-08 04:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:27:10 --> Final output sent to browser
DEBUG - 2023-10-08 04:27:10 --> Total execution time: 0.1288
ERROR - 2023-10-08 04:27:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:27:10 --> Config Class Initialized
INFO - 2023-10-08 04:27:10 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:27:10 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:27:10 --> Utf8 Class Initialized
INFO - 2023-10-08 04:27:10 --> URI Class Initialized
DEBUG - 2023-10-08 04:27:10 --> No URI present. Default controller set.
INFO - 2023-10-08 04:27:10 --> Router Class Initialized
INFO - 2023-10-08 04:27:10 --> Output Class Initialized
INFO - 2023-10-08 04:27:10 --> Security Class Initialized
DEBUG - 2023-10-08 04:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:27:10 --> Input Class Initialized
INFO - 2023-10-08 04:27:10 --> Language Class Initialized
INFO - 2023-10-08 04:27:10 --> Loader Class Initialized
INFO - 2023-10-08 04:27:10 --> Helper loaded: url_helper
INFO - 2023-10-08 04:27:10 --> Helper loaded: file_helper
INFO - 2023-10-08 04:27:10 --> Helper loaded: html_helper
INFO - 2023-10-08 04:27:10 --> Helper loaded: text_helper
INFO - 2023-10-08 04:27:10 --> Helper loaded: form_helper
INFO - 2023-10-08 04:27:10 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:27:10 --> Helper loaded: security_helper
INFO - 2023-10-08 04:27:10 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:27:10 --> Database Driver Class Initialized
INFO - 2023-10-08 04:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:27:10 --> Parser Class Initialized
INFO - 2023-10-08 04:27:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:27:10 --> Pagination Class Initialized
INFO - 2023-10-08 04:27:10 --> Form Validation Class Initialized
INFO - 2023-10-08 04:27:10 --> Controller Class Initialized
INFO - 2023-10-08 04:27:10 --> Model Class Initialized
DEBUG - 2023-10-08 04:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:27:10 --> Model Class Initialized
DEBUG - 2023-10-08 04:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:27:10 --> Model Class Initialized
INFO - 2023-10-08 04:27:10 --> Model Class Initialized
INFO - 2023-10-08 04:27:10 --> Model Class Initialized
INFO - 2023-10-08 04:27:10 --> Model Class Initialized
DEBUG - 2023-10-08 04:27:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:27:10 --> Model Class Initialized
INFO - 2023-10-08 04:27:10 --> Model Class Initialized
INFO - 2023-10-08 04:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-08 04:27:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:27:10 --> Model Class Initialized
INFO - 2023-10-08 04:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:27:10 --> Final output sent to browser
DEBUG - 2023-10-08 04:27:10 --> Total execution time: 0.1177
ERROR - 2023-10-08 04:28:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:28:11 --> Config Class Initialized
INFO - 2023-10-08 04:28:11 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:28:11 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:28:11 --> Utf8 Class Initialized
INFO - 2023-10-08 04:28:11 --> URI Class Initialized
DEBUG - 2023-10-08 04:28:11 --> No URI present. Default controller set.
INFO - 2023-10-08 04:28:11 --> Router Class Initialized
INFO - 2023-10-08 04:28:11 --> Output Class Initialized
INFO - 2023-10-08 04:28:11 --> Security Class Initialized
DEBUG - 2023-10-08 04:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:28:11 --> Input Class Initialized
INFO - 2023-10-08 04:28:11 --> Language Class Initialized
INFO - 2023-10-08 04:28:11 --> Loader Class Initialized
INFO - 2023-10-08 04:28:11 --> Helper loaded: url_helper
INFO - 2023-10-08 04:28:11 --> Helper loaded: file_helper
INFO - 2023-10-08 04:28:11 --> Helper loaded: html_helper
INFO - 2023-10-08 04:28:11 --> Helper loaded: text_helper
INFO - 2023-10-08 04:28:11 --> Helper loaded: form_helper
INFO - 2023-10-08 04:28:11 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:28:11 --> Helper loaded: security_helper
INFO - 2023-10-08 04:28:11 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:28:11 --> Database Driver Class Initialized
INFO - 2023-10-08 04:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:28:11 --> Parser Class Initialized
INFO - 2023-10-08 04:28:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:28:11 --> Pagination Class Initialized
INFO - 2023-10-08 04:28:11 --> Form Validation Class Initialized
INFO - 2023-10-08 04:28:11 --> Controller Class Initialized
INFO - 2023-10-08 04:28:11 --> Model Class Initialized
DEBUG - 2023-10-08 04:28:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:28:11 --> Model Class Initialized
DEBUG - 2023-10-08 04:28:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:28:11 --> Model Class Initialized
INFO - 2023-10-08 04:28:11 --> Model Class Initialized
INFO - 2023-10-08 04:28:11 --> Model Class Initialized
INFO - 2023-10-08 04:28:11 --> Model Class Initialized
DEBUG - 2023-10-08 04:28:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:28:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:28:11 --> Model Class Initialized
INFO - 2023-10-08 04:28:11 --> Model Class Initialized
INFO - 2023-10-08 04:28:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-08 04:28:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:28:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:28:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:28:11 --> Model Class Initialized
INFO - 2023-10-08 04:28:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:28:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:28:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:28:11 --> Final output sent to browser
DEBUG - 2023-10-08 04:28:11 --> Total execution time: 0.1212
ERROR - 2023-10-08 04:28:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:28:17 --> Config Class Initialized
INFO - 2023-10-08 04:28:17 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:28:17 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:28:17 --> Utf8 Class Initialized
INFO - 2023-10-08 04:28:17 --> URI Class Initialized
DEBUG - 2023-10-08 04:28:17 --> No URI present. Default controller set.
INFO - 2023-10-08 04:28:17 --> Router Class Initialized
INFO - 2023-10-08 04:28:17 --> Output Class Initialized
INFO - 2023-10-08 04:28:17 --> Security Class Initialized
DEBUG - 2023-10-08 04:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:28:17 --> Input Class Initialized
INFO - 2023-10-08 04:28:17 --> Language Class Initialized
INFO - 2023-10-08 04:28:17 --> Loader Class Initialized
INFO - 2023-10-08 04:28:17 --> Helper loaded: url_helper
INFO - 2023-10-08 04:28:17 --> Helper loaded: file_helper
INFO - 2023-10-08 04:28:17 --> Helper loaded: html_helper
INFO - 2023-10-08 04:28:17 --> Helper loaded: text_helper
INFO - 2023-10-08 04:28:17 --> Helper loaded: form_helper
INFO - 2023-10-08 04:28:17 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:28:17 --> Helper loaded: security_helper
INFO - 2023-10-08 04:28:17 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:28:17 --> Database Driver Class Initialized
INFO - 2023-10-08 04:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:28:17 --> Parser Class Initialized
INFO - 2023-10-08 04:28:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:28:17 --> Pagination Class Initialized
INFO - 2023-10-08 04:28:17 --> Form Validation Class Initialized
INFO - 2023-10-08 04:28:17 --> Controller Class Initialized
INFO - 2023-10-08 04:28:17 --> Model Class Initialized
DEBUG - 2023-10-08 04:28:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 04:28:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:28:18 --> Config Class Initialized
INFO - 2023-10-08 04:28:18 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:28:18 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:28:18 --> Utf8 Class Initialized
INFO - 2023-10-08 04:28:18 --> URI Class Initialized
INFO - 2023-10-08 04:28:18 --> Router Class Initialized
INFO - 2023-10-08 04:28:18 --> Output Class Initialized
INFO - 2023-10-08 04:28:18 --> Security Class Initialized
DEBUG - 2023-10-08 04:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:28:18 --> Input Class Initialized
INFO - 2023-10-08 04:28:18 --> Language Class Initialized
INFO - 2023-10-08 04:28:18 --> Loader Class Initialized
INFO - 2023-10-08 04:28:18 --> Helper loaded: url_helper
INFO - 2023-10-08 04:28:18 --> Helper loaded: file_helper
INFO - 2023-10-08 04:28:18 --> Helper loaded: html_helper
INFO - 2023-10-08 04:28:18 --> Helper loaded: text_helper
INFO - 2023-10-08 04:28:18 --> Helper loaded: form_helper
INFO - 2023-10-08 04:28:18 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:28:18 --> Helper loaded: security_helper
INFO - 2023-10-08 04:28:18 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:28:18 --> Database Driver Class Initialized
INFO - 2023-10-08 04:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:28:18 --> Parser Class Initialized
INFO - 2023-10-08 04:28:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:28:18 --> Pagination Class Initialized
INFO - 2023-10-08 04:28:18 --> Form Validation Class Initialized
INFO - 2023-10-08 04:28:18 --> Controller Class Initialized
INFO - 2023-10-08 04:28:18 --> Model Class Initialized
DEBUG - 2023-10-08 04:28:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:28:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-08 04:28:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:28:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:28:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:28:18 --> Model Class Initialized
INFO - 2023-10-08 04:28:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:28:18 --> Final output sent to browser
DEBUG - 2023-10-08 04:28:18 --> Total execution time: 0.0344
ERROR - 2023-10-08 04:28:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:28:59 --> Config Class Initialized
INFO - 2023-10-08 04:28:59 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:28:59 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:28:59 --> Utf8 Class Initialized
INFO - 2023-10-08 04:28:59 --> URI Class Initialized
INFO - 2023-10-08 04:28:59 --> Router Class Initialized
INFO - 2023-10-08 04:28:59 --> Output Class Initialized
INFO - 2023-10-08 04:28:59 --> Security Class Initialized
DEBUG - 2023-10-08 04:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:28:59 --> Input Class Initialized
INFO - 2023-10-08 04:28:59 --> Language Class Initialized
INFO - 2023-10-08 04:28:59 --> Loader Class Initialized
INFO - 2023-10-08 04:28:59 --> Helper loaded: url_helper
INFO - 2023-10-08 04:28:59 --> Helper loaded: file_helper
INFO - 2023-10-08 04:28:59 --> Helper loaded: html_helper
INFO - 2023-10-08 04:28:59 --> Helper loaded: text_helper
INFO - 2023-10-08 04:28:59 --> Helper loaded: form_helper
INFO - 2023-10-08 04:28:59 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:28:59 --> Helper loaded: security_helper
INFO - 2023-10-08 04:28:59 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:28:59 --> Database Driver Class Initialized
INFO - 2023-10-08 04:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:28:59 --> Parser Class Initialized
INFO - 2023-10-08 04:28:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:28:59 --> Pagination Class Initialized
INFO - 2023-10-08 04:28:59 --> Form Validation Class Initialized
INFO - 2023-10-08 04:28:59 --> Controller Class Initialized
INFO - 2023-10-08 04:28:59 --> Model Class Initialized
DEBUG - 2023-10-08 04:28:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:28:59 --> Model Class Initialized
INFO - 2023-10-08 04:28:59 --> Final output sent to browser
DEBUG - 2023-10-08 04:28:59 --> Total execution time: 0.0211
ERROR - 2023-10-08 04:29:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:29:00 --> Config Class Initialized
INFO - 2023-10-08 04:29:00 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:29:00 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:29:00 --> Utf8 Class Initialized
INFO - 2023-10-08 04:29:00 --> URI Class Initialized
DEBUG - 2023-10-08 04:29:00 --> No URI present. Default controller set.
INFO - 2023-10-08 04:29:00 --> Router Class Initialized
INFO - 2023-10-08 04:29:00 --> Output Class Initialized
INFO - 2023-10-08 04:29:00 --> Security Class Initialized
DEBUG - 2023-10-08 04:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:29:00 --> Input Class Initialized
INFO - 2023-10-08 04:29:00 --> Language Class Initialized
INFO - 2023-10-08 04:29:00 --> Loader Class Initialized
INFO - 2023-10-08 04:29:00 --> Helper loaded: url_helper
INFO - 2023-10-08 04:29:00 --> Helper loaded: file_helper
INFO - 2023-10-08 04:29:00 --> Helper loaded: html_helper
INFO - 2023-10-08 04:29:00 --> Helper loaded: text_helper
INFO - 2023-10-08 04:29:00 --> Helper loaded: form_helper
INFO - 2023-10-08 04:29:00 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:29:00 --> Helper loaded: security_helper
INFO - 2023-10-08 04:29:00 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:29:00 --> Database Driver Class Initialized
INFO - 2023-10-08 04:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:29:00 --> Parser Class Initialized
INFO - 2023-10-08 04:29:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:29:00 --> Pagination Class Initialized
INFO - 2023-10-08 04:29:00 --> Form Validation Class Initialized
INFO - 2023-10-08 04:29:00 --> Controller Class Initialized
INFO - 2023-10-08 04:29:00 --> Model Class Initialized
DEBUG - 2023-10-08 04:29:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:29:00 --> Model Class Initialized
DEBUG - 2023-10-08 04:29:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:29:00 --> Model Class Initialized
INFO - 2023-10-08 04:29:00 --> Model Class Initialized
INFO - 2023-10-08 04:29:00 --> Model Class Initialized
INFO - 2023-10-08 04:29:00 --> Model Class Initialized
DEBUG - 2023-10-08 04:29:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:29:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:29:00 --> Model Class Initialized
INFO - 2023-10-08 04:29:00 --> Model Class Initialized
INFO - 2023-10-08 04:29:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-08 04:29:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:29:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:29:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:29:00 --> Model Class Initialized
INFO - 2023-10-08 04:29:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:29:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:29:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:29:00 --> Final output sent to browser
DEBUG - 2023-10-08 04:29:00 --> Total execution time: 0.1271
ERROR - 2023-10-08 04:29:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:29:14 --> Config Class Initialized
INFO - 2023-10-08 04:29:14 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:29:14 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:29:14 --> Utf8 Class Initialized
INFO - 2023-10-08 04:29:14 --> URI Class Initialized
INFO - 2023-10-08 04:29:14 --> Router Class Initialized
INFO - 2023-10-08 04:29:14 --> Output Class Initialized
INFO - 2023-10-08 04:29:14 --> Security Class Initialized
DEBUG - 2023-10-08 04:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:29:14 --> Input Class Initialized
INFO - 2023-10-08 04:29:14 --> Language Class Initialized
INFO - 2023-10-08 04:29:14 --> Loader Class Initialized
INFO - 2023-10-08 04:29:14 --> Helper loaded: url_helper
INFO - 2023-10-08 04:29:14 --> Helper loaded: file_helper
INFO - 2023-10-08 04:29:14 --> Helper loaded: html_helper
INFO - 2023-10-08 04:29:14 --> Helper loaded: text_helper
INFO - 2023-10-08 04:29:14 --> Helper loaded: form_helper
INFO - 2023-10-08 04:29:14 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:29:14 --> Helper loaded: security_helper
INFO - 2023-10-08 04:29:14 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:29:14 --> Database Driver Class Initialized
INFO - 2023-10-08 04:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:29:14 --> Parser Class Initialized
INFO - 2023-10-08 04:29:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:29:14 --> Pagination Class Initialized
INFO - 2023-10-08 04:29:14 --> Form Validation Class Initialized
INFO - 2023-10-08 04:29:14 --> Controller Class Initialized
DEBUG - 2023-10-08 04:29:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:29:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:29:14 --> Model Class Initialized
DEBUG - 2023-10-08 04:29:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:29:14 --> Model Class Initialized
DEBUG - 2023-10-08 04:29:14 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:29:14 --> Model Class Initialized
INFO - 2023-10-08 04:29:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-10-08 04:29:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:29:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:29:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:29:14 --> Model Class Initialized
INFO - 2023-10-08 04:29:14 --> Model Class Initialized
INFO - 2023-10-08 04:29:14 --> Model Class Initialized
INFO - 2023-10-08 04:29:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:29:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:29:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:29:14 --> Final output sent to browser
DEBUG - 2023-10-08 04:29:14 --> Total execution time: 0.0936
ERROR - 2023-10-08 04:29:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:29:15 --> Config Class Initialized
INFO - 2023-10-08 04:29:15 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:29:15 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:29:15 --> Utf8 Class Initialized
INFO - 2023-10-08 04:29:15 --> URI Class Initialized
INFO - 2023-10-08 04:29:15 --> Router Class Initialized
INFO - 2023-10-08 04:29:15 --> Output Class Initialized
INFO - 2023-10-08 04:29:15 --> Security Class Initialized
DEBUG - 2023-10-08 04:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:29:15 --> Input Class Initialized
INFO - 2023-10-08 04:29:15 --> Language Class Initialized
INFO - 2023-10-08 04:29:15 --> Loader Class Initialized
INFO - 2023-10-08 04:29:15 --> Helper loaded: url_helper
INFO - 2023-10-08 04:29:15 --> Helper loaded: file_helper
INFO - 2023-10-08 04:29:15 --> Helper loaded: html_helper
INFO - 2023-10-08 04:29:15 --> Helper loaded: text_helper
INFO - 2023-10-08 04:29:15 --> Helper loaded: form_helper
INFO - 2023-10-08 04:29:15 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:29:15 --> Helper loaded: security_helper
INFO - 2023-10-08 04:29:15 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:29:15 --> Database Driver Class Initialized
INFO - 2023-10-08 04:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:29:15 --> Parser Class Initialized
INFO - 2023-10-08 04:29:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:29:15 --> Pagination Class Initialized
INFO - 2023-10-08 04:29:15 --> Form Validation Class Initialized
INFO - 2023-10-08 04:29:15 --> Controller Class Initialized
DEBUG - 2023-10-08 04:29:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:29:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:29:15 --> Model Class Initialized
DEBUG - 2023-10-08 04:29:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:29:15 --> Model Class Initialized
INFO - 2023-10-08 04:29:15 --> Final output sent to browser
DEBUG - 2023-10-08 04:29:15 --> Total execution time: 0.0219
ERROR - 2023-10-08 04:29:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:29:20 --> Config Class Initialized
INFO - 2023-10-08 04:29:20 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:29:20 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:29:20 --> Utf8 Class Initialized
INFO - 2023-10-08 04:29:20 --> URI Class Initialized
INFO - 2023-10-08 04:29:20 --> Router Class Initialized
INFO - 2023-10-08 04:29:20 --> Output Class Initialized
INFO - 2023-10-08 04:29:20 --> Security Class Initialized
DEBUG - 2023-10-08 04:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:29:20 --> Input Class Initialized
INFO - 2023-10-08 04:29:20 --> Language Class Initialized
INFO - 2023-10-08 04:29:20 --> Loader Class Initialized
INFO - 2023-10-08 04:29:20 --> Helper loaded: url_helper
INFO - 2023-10-08 04:29:20 --> Helper loaded: file_helper
INFO - 2023-10-08 04:29:20 --> Helper loaded: html_helper
INFO - 2023-10-08 04:29:20 --> Helper loaded: text_helper
INFO - 2023-10-08 04:29:20 --> Helper loaded: form_helper
INFO - 2023-10-08 04:29:20 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:29:20 --> Helper loaded: security_helper
INFO - 2023-10-08 04:29:20 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:29:20 --> Database Driver Class Initialized
INFO - 2023-10-08 04:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:29:20 --> Parser Class Initialized
INFO - 2023-10-08 04:29:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:29:20 --> Pagination Class Initialized
INFO - 2023-10-08 04:29:20 --> Form Validation Class Initialized
INFO - 2023-10-08 04:29:20 --> Controller Class Initialized
DEBUG - 2023-10-08 04:29:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:29:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:29:20 --> Model Class Initialized
DEBUG - 2023-10-08 04:29:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:29:20 --> Model Class Initialized
INFO - 2023-10-08 04:29:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2023-10-08 04:29:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:29:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:29:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:29:20 --> Model Class Initialized
INFO - 2023-10-08 04:29:20 --> Model Class Initialized
INFO - 2023-10-08 04:29:20 --> Model Class Initialized
INFO - 2023-10-08 04:29:20 --> Model Class Initialized
INFO - 2023-10-08 04:29:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:29:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:29:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:29:20 --> Final output sent to browser
DEBUG - 2023-10-08 04:29:20 --> Total execution time: 0.1346
ERROR - 2023-10-08 04:30:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:30:20 --> Config Class Initialized
INFO - 2023-10-08 04:30:20 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:30:20 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:30:20 --> Utf8 Class Initialized
INFO - 2023-10-08 04:30:20 --> URI Class Initialized
INFO - 2023-10-08 04:30:20 --> Router Class Initialized
INFO - 2023-10-08 04:30:20 --> Output Class Initialized
INFO - 2023-10-08 04:30:20 --> Security Class Initialized
DEBUG - 2023-10-08 04:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:30:20 --> Input Class Initialized
INFO - 2023-10-08 04:30:20 --> Language Class Initialized
INFO - 2023-10-08 04:30:20 --> Loader Class Initialized
INFO - 2023-10-08 04:30:20 --> Helper loaded: url_helper
INFO - 2023-10-08 04:30:20 --> Helper loaded: file_helper
INFO - 2023-10-08 04:30:20 --> Helper loaded: html_helper
INFO - 2023-10-08 04:30:20 --> Helper loaded: text_helper
INFO - 2023-10-08 04:30:20 --> Helper loaded: form_helper
INFO - 2023-10-08 04:30:20 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:30:20 --> Helper loaded: security_helper
INFO - 2023-10-08 04:30:20 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:30:20 --> Database Driver Class Initialized
INFO - 2023-10-08 04:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:30:20 --> Parser Class Initialized
INFO - 2023-10-08 04:30:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:30:20 --> Pagination Class Initialized
INFO - 2023-10-08 04:30:20 --> Form Validation Class Initialized
INFO - 2023-10-08 04:30:20 --> Controller Class Initialized
DEBUG - 2023-10-08 04:30:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:30:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:30:20 --> Model Class Initialized
DEBUG - 2023-10-08 04:30:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:30:20 --> Model Class Initialized
DEBUG - 2023-10-08 04:30:20 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:30:20 --> Model Class Initialized
INFO - 2023-10-08 04:30:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-10-08 04:30:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:30:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 04:30:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 04:30:20 --> Model Class Initialized
INFO - 2023-10-08 04:30:20 --> Model Class Initialized
INFO - 2023-10-08 04:30:20 --> Model Class Initialized
INFO - 2023-10-08 04:30:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-08 04:30:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-08 04:30:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 04:30:20 --> Final output sent to browser
DEBUG - 2023-10-08 04:30:20 --> Total execution time: 0.1029
ERROR - 2023-10-08 04:30:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 04:30:20 --> Config Class Initialized
INFO - 2023-10-08 04:30:20 --> Hooks Class Initialized
DEBUG - 2023-10-08 04:30:20 --> UTF-8 Support Enabled
INFO - 2023-10-08 04:30:20 --> Utf8 Class Initialized
INFO - 2023-10-08 04:30:20 --> URI Class Initialized
INFO - 2023-10-08 04:30:20 --> Router Class Initialized
INFO - 2023-10-08 04:30:20 --> Output Class Initialized
INFO - 2023-10-08 04:30:20 --> Security Class Initialized
DEBUG - 2023-10-08 04:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 04:30:20 --> Input Class Initialized
INFO - 2023-10-08 04:30:20 --> Language Class Initialized
INFO - 2023-10-08 04:30:21 --> Loader Class Initialized
INFO - 2023-10-08 04:30:21 --> Helper loaded: url_helper
INFO - 2023-10-08 04:30:21 --> Helper loaded: file_helper
INFO - 2023-10-08 04:30:21 --> Helper loaded: html_helper
INFO - 2023-10-08 04:30:21 --> Helper loaded: text_helper
INFO - 2023-10-08 04:30:21 --> Helper loaded: form_helper
INFO - 2023-10-08 04:30:21 --> Helper loaded: lang_helper
INFO - 2023-10-08 04:30:21 --> Helper loaded: security_helper
INFO - 2023-10-08 04:30:21 --> Helper loaded: cookie_helper
INFO - 2023-10-08 04:30:21 --> Database Driver Class Initialized
INFO - 2023-10-08 04:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 04:30:21 --> Parser Class Initialized
INFO - 2023-10-08 04:30:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 04:30:21 --> Pagination Class Initialized
INFO - 2023-10-08 04:30:21 --> Form Validation Class Initialized
INFO - 2023-10-08 04:30:21 --> Controller Class Initialized
DEBUG - 2023-10-08 04:30:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-08 04:30:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:30:21 --> Model Class Initialized
DEBUG - 2023-10-08 04:30:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 04:30:21 --> Model Class Initialized
INFO - 2023-10-08 04:30:21 --> Final output sent to browser
DEBUG - 2023-10-08 04:30:21 --> Total execution time: 0.0218
ERROR - 2023-10-08 06:20:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 06:20:47 --> Config Class Initialized
INFO - 2023-10-08 06:20:47 --> Hooks Class Initialized
DEBUG - 2023-10-08 06:20:47 --> UTF-8 Support Enabled
INFO - 2023-10-08 06:20:47 --> Utf8 Class Initialized
INFO - 2023-10-08 06:20:47 --> URI Class Initialized
DEBUG - 2023-10-08 06:20:47 --> No URI present. Default controller set.
INFO - 2023-10-08 06:20:47 --> Router Class Initialized
INFO - 2023-10-08 06:20:47 --> Output Class Initialized
INFO - 2023-10-08 06:20:47 --> Security Class Initialized
DEBUG - 2023-10-08 06:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 06:20:47 --> Input Class Initialized
INFO - 2023-10-08 06:20:47 --> Language Class Initialized
INFO - 2023-10-08 06:20:47 --> Loader Class Initialized
INFO - 2023-10-08 06:20:47 --> Helper loaded: url_helper
INFO - 2023-10-08 06:20:47 --> Helper loaded: file_helper
INFO - 2023-10-08 06:20:47 --> Helper loaded: html_helper
INFO - 2023-10-08 06:20:47 --> Helper loaded: text_helper
INFO - 2023-10-08 06:20:47 --> Helper loaded: form_helper
INFO - 2023-10-08 06:20:47 --> Helper loaded: lang_helper
INFO - 2023-10-08 06:20:47 --> Helper loaded: security_helper
INFO - 2023-10-08 06:20:47 --> Helper loaded: cookie_helper
INFO - 2023-10-08 06:20:47 --> Database Driver Class Initialized
INFO - 2023-10-08 06:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 06:20:47 --> Parser Class Initialized
INFO - 2023-10-08 06:20:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 06:20:47 --> Pagination Class Initialized
INFO - 2023-10-08 06:20:47 --> Form Validation Class Initialized
INFO - 2023-10-08 06:20:47 --> Controller Class Initialized
INFO - 2023-10-08 06:20:47 --> Model Class Initialized
DEBUG - 2023-10-08 06:20:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-08 06:20:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-08 06:20:47 --> Config Class Initialized
INFO - 2023-10-08 06:20:47 --> Hooks Class Initialized
DEBUG - 2023-10-08 06:20:47 --> UTF-8 Support Enabled
INFO - 2023-10-08 06:20:47 --> Utf8 Class Initialized
INFO - 2023-10-08 06:20:47 --> URI Class Initialized
INFO - 2023-10-08 06:20:47 --> Router Class Initialized
INFO - 2023-10-08 06:20:47 --> Output Class Initialized
INFO - 2023-10-08 06:20:47 --> Security Class Initialized
DEBUG - 2023-10-08 06:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-08 06:20:47 --> Input Class Initialized
INFO - 2023-10-08 06:20:47 --> Language Class Initialized
INFO - 2023-10-08 06:20:47 --> Loader Class Initialized
INFO - 2023-10-08 06:20:47 --> Helper loaded: url_helper
INFO - 2023-10-08 06:20:47 --> Helper loaded: file_helper
INFO - 2023-10-08 06:20:47 --> Helper loaded: html_helper
INFO - 2023-10-08 06:20:47 --> Helper loaded: text_helper
INFO - 2023-10-08 06:20:47 --> Helper loaded: form_helper
INFO - 2023-10-08 06:20:47 --> Helper loaded: lang_helper
INFO - 2023-10-08 06:20:47 --> Helper loaded: security_helper
INFO - 2023-10-08 06:20:47 --> Helper loaded: cookie_helper
INFO - 2023-10-08 06:20:47 --> Database Driver Class Initialized
INFO - 2023-10-08 06:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-08 06:20:47 --> Parser Class Initialized
INFO - 2023-10-08 06:20:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-08 06:20:47 --> Pagination Class Initialized
INFO - 2023-10-08 06:20:47 --> Form Validation Class Initialized
INFO - 2023-10-08 06:20:47 --> Controller Class Initialized
INFO - 2023-10-08 06:20:47 --> Model Class Initialized
DEBUG - 2023-10-08 06:20:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-08 06:20:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-08 06:20:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-08 06:20:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-08 06:20:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-08 06:20:47 --> Model Class Initialized
INFO - 2023-10-08 06:20:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-08 06:20:47 --> Final output sent to browser
DEBUG - 2023-10-08 06:20:47 --> Total execution time: 0.0359
