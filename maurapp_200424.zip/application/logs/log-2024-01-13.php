<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-13 00:25:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 00:25:41 --> Config Class Initialized
INFO - 2024-01-13 00:25:41 --> Hooks Class Initialized
DEBUG - 2024-01-13 00:25:41 --> UTF-8 Support Enabled
INFO - 2024-01-13 00:25:41 --> Utf8 Class Initialized
INFO - 2024-01-13 00:25:41 --> URI Class Initialized
INFO - 2024-01-13 00:25:41 --> Router Class Initialized
INFO - 2024-01-13 00:25:41 --> Output Class Initialized
INFO - 2024-01-13 00:25:41 --> Security Class Initialized
DEBUG - 2024-01-13 00:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 00:25:41 --> Input Class Initialized
INFO - 2024-01-13 00:25:41 --> Language Class Initialized
ERROR - 2024-01-13 00:25:41 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-01-13 00:55:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 00:55:42 --> Config Class Initialized
INFO - 2024-01-13 00:55:42 --> Hooks Class Initialized
DEBUG - 2024-01-13 00:55:42 --> UTF-8 Support Enabled
INFO - 2024-01-13 00:55:42 --> Utf8 Class Initialized
INFO - 2024-01-13 00:55:42 --> URI Class Initialized
INFO - 2024-01-13 00:55:42 --> Router Class Initialized
INFO - 2024-01-13 00:55:42 --> Output Class Initialized
INFO - 2024-01-13 00:55:42 --> Security Class Initialized
DEBUG - 2024-01-13 00:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 00:55:42 --> Input Class Initialized
INFO - 2024-01-13 00:55:42 --> Language Class Initialized
ERROR - 2024-01-13 00:55:42 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-01-13 15:01:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 15:01:30 --> Config Class Initialized
INFO - 2024-01-13 15:01:30 --> Hooks Class Initialized
DEBUG - 2024-01-13 15:01:30 --> UTF-8 Support Enabled
INFO - 2024-01-13 15:01:30 --> Utf8 Class Initialized
INFO - 2024-01-13 15:01:30 --> URI Class Initialized
DEBUG - 2024-01-13 15:01:30 --> No URI present. Default controller set.
INFO - 2024-01-13 15:01:30 --> Router Class Initialized
INFO - 2024-01-13 15:01:30 --> Output Class Initialized
INFO - 2024-01-13 15:01:30 --> Security Class Initialized
DEBUG - 2024-01-13 15:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 15:01:30 --> Input Class Initialized
INFO - 2024-01-13 15:01:30 --> Language Class Initialized
INFO - 2024-01-13 15:01:30 --> Loader Class Initialized
INFO - 2024-01-13 15:01:30 --> Helper loaded: url_helper
INFO - 2024-01-13 15:01:30 --> Helper loaded: file_helper
INFO - 2024-01-13 15:01:30 --> Helper loaded: html_helper
INFO - 2024-01-13 15:01:30 --> Helper loaded: text_helper
INFO - 2024-01-13 15:01:30 --> Helper loaded: form_helper
INFO - 2024-01-13 15:01:30 --> Helper loaded: lang_helper
INFO - 2024-01-13 15:01:30 --> Helper loaded: security_helper
INFO - 2024-01-13 15:01:30 --> Helper loaded: cookie_helper
INFO - 2024-01-13 15:01:30 --> Database Driver Class Initialized
INFO - 2024-01-13 15:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 15:01:30 --> Parser Class Initialized
INFO - 2024-01-13 15:01:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 15:01:30 --> Pagination Class Initialized
INFO - 2024-01-13 15:01:30 --> Form Validation Class Initialized
INFO - 2024-01-13 15:01:30 --> Controller Class Initialized
INFO - 2024-01-13 15:01:30 --> Model Class Initialized
DEBUG - 2024-01-13 15:01:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-13 15:01:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 15:01:32 --> Config Class Initialized
INFO - 2024-01-13 15:01:32 --> Hooks Class Initialized
DEBUG - 2024-01-13 15:01:32 --> UTF-8 Support Enabled
INFO - 2024-01-13 15:01:32 --> Utf8 Class Initialized
INFO - 2024-01-13 15:01:32 --> URI Class Initialized
INFO - 2024-01-13 15:01:32 --> Router Class Initialized
INFO - 2024-01-13 15:01:32 --> Output Class Initialized
INFO - 2024-01-13 15:01:32 --> Security Class Initialized
DEBUG - 2024-01-13 15:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 15:01:32 --> Input Class Initialized
INFO - 2024-01-13 15:01:32 --> Language Class Initialized
INFO - 2024-01-13 15:01:32 --> Loader Class Initialized
INFO - 2024-01-13 15:01:32 --> Helper loaded: url_helper
INFO - 2024-01-13 15:01:32 --> Helper loaded: file_helper
INFO - 2024-01-13 15:01:32 --> Helper loaded: html_helper
INFO - 2024-01-13 15:01:32 --> Helper loaded: text_helper
INFO - 2024-01-13 15:01:32 --> Helper loaded: form_helper
INFO - 2024-01-13 15:01:32 --> Helper loaded: lang_helper
INFO - 2024-01-13 15:01:32 --> Helper loaded: security_helper
INFO - 2024-01-13 15:01:32 --> Helper loaded: cookie_helper
INFO - 2024-01-13 15:01:32 --> Database Driver Class Initialized
INFO - 2024-01-13 15:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 15:01:32 --> Parser Class Initialized
INFO - 2024-01-13 15:01:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 15:01:32 --> Pagination Class Initialized
INFO - 2024-01-13 15:01:32 --> Form Validation Class Initialized
INFO - 2024-01-13 15:01:32 --> Controller Class Initialized
INFO - 2024-01-13 15:01:32 --> Model Class Initialized
DEBUG - 2024-01-13 15:01:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 15:01:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-13 15:01:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-13 15:01:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-13 15:01:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-13 15:01:32 --> Model Class Initialized
INFO - 2024-01-13 15:01:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-13 15:01:32 --> Final output sent to browser
DEBUG - 2024-01-13 15:01:32 --> Total execution time: 0.0366
ERROR - 2024-01-13 15:03:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 15:03:44 --> Config Class Initialized
INFO - 2024-01-13 15:03:44 --> Hooks Class Initialized
DEBUG - 2024-01-13 15:03:44 --> UTF-8 Support Enabled
INFO - 2024-01-13 15:03:44 --> Utf8 Class Initialized
INFO - 2024-01-13 15:03:44 --> URI Class Initialized
DEBUG - 2024-01-13 15:03:44 --> No URI present. Default controller set.
INFO - 2024-01-13 15:03:44 --> Router Class Initialized
INFO - 2024-01-13 15:03:44 --> Output Class Initialized
INFO - 2024-01-13 15:03:44 --> Security Class Initialized
DEBUG - 2024-01-13 15:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 15:03:44 --> Input Class Initialized
INFO - 2024-01-13 15:03:44 --> Language Class Initialized
INFO - 2024-01-13 15:03:44 --> Loader Class Initialized
INFO - 2024-01-13 15:03:44 --> Helper loaded: url_helper
INFO - 2024-01-13 15:03:44 --> Helper loaded: file_helper
INFO - 2024-01-13 15:03:44 --> Helper loaded: html_helper
INFO - 2024-01-13 15:03:44 --> Helper loaded: text_helper
INFO - 2024-01-13 15:03:44 --> Helper loaded: form_helper
INFO - 2024-01-13 15:03:44 --> Helper loaded: lang_helper
INFO - 2024-01-13 15:03:44 --> Helper loaded: security_helper
INFO - 2024-01-13 15:03:44 --> Helper loaded: cookie_helper
INFO - 2024-01-13 15:03:44 --> Database Driver Class Initialized
INFO - 2024-01-13 15:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 15:03:44 --> Parser Class Initialized
INFO - 2024-01-13 15:03:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 15:03:44 --> Pagination Class Initialized
INFO - 2024-01-13 15:03:44 --> Form Validation Class Initialized
INFO - 2024-01-13 15:03:44 --> Controller Class Initialized
INFO - 2024-01-13 15:03:44 --> Model Class Initialized
DEBUG - 2024-01-13 15:03:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-13 15:03:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 15:03:44 --> Config Class Initialized
INFO - 2024-01-13 15:03:44 --> Hooks Class Initialized
DEBUG - 2024-01-13 15:03:44 --> UTF-8 Support Enabled
INFO - 2024-01-13 15:03:44 --> Utf8 Class Initialized
INFO - 2024-01-13 15:03:44 --> URI Class Initialized
INFO - 2024-01-13 15:03:44 --> Router Class Initialized
INFO - 2024-01-13 15:03:44 --> Output Class Initialized
INFO - 2024-01-13 15:03:44 --> Security Class Initialized
DEBUG - 2024-01-13 15:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 15:03:44 --> Input Class Initialized
INFO - 2024-01-13 15:03:44 --> Language Class Initialized
INFO - 2024-01-13 15:03:44 --> Loader Class Initialized
INFO - 2024-01-13 15:03:44 --> Helper loaded: url_helper
INFO - 2024-01-13 15:03:44 --> Helper loaded: file_helper
INFO - 2024-01-13 15:03:44 --> Helper loaded: html_helper
INFO - 2024-01-13 15:03:44 --> Helper loaded: text_helper
INFO - 2024-01-13 15:03:44 --> Helper loaded: form_helper
INFO - 2024-01-13 15:03:44 --> Helper loaded: lang_helper
INFO - 2024-01-13 15:03:44 --> Helper loaded: security_helper
INFO - 2024-01-13 15:03:44 --> Helper loaded: cookie_helper
INFO - 2024-01-13 15:03:44 --> Database Driver Class Initialized
INFO - 2024-01-13 15:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 15:03:44 --> Parser Class Initialized
INFO - 2024-01-13 15:03:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 15:03:44 --> Pagination Class Initialized
INFO - 2024-01-13 15:03:44 --> Form Validation Class Initialized
INFO - 2024-01-13 15:03:44 --> Controller Class Initialized
INFO - 2024-01-13 15:03:44 --> Model Class Initialized
DEBUG - 2024-01-13 15:03:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 15:03:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-13 15:03:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-13 15:03:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-13 15:03:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-13 15:03:44 --> Model Class Initialized
INFO - 2024-01-13 15:03:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-13 15:03:44 --> Final output sent to browser
DEBUG - 2024-01-13 15:03:44 --> Total execution time: 0.0370
ERROR - 2024-01-13 15:07:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 15:07:34 --> Config Class Initialized
INFO - 2024-01-13 15:07:34 --> Hooks Class Initialized
DEBUG - 2024-01-13 15:07:34 --> UTF-8 Support Enabled
INFO - 2024-01-13 15:07:34 --> Utf8 Class Initialized
INFO - 2024-01-13 15:07:34 --> URI Class Initialized
DEBUG - 2024-01-13 15:07:34 --> No URI present. Default controller set.
INFO - 2024-01-13 15:07:34 --> Router Class Initialized
INFO - 2024-01-13 15:07:34 --> Output Class Initialized
INFO - 2024-01-13 15:07:34 --> Security Class Initialized
DEBUG - 2024-01-13 15:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 15:07:34 --> Input Class Initialized
INFO - 2024-01-13 15:07:34 --> Language Class Initialized
INFO - 2024-01-13 15:07:34 --> Loader Class Initialized
INFO - 2024-01-13 15:07:34 --> Helper loaded: url_helper
INFO - 2024-01-13 15:07:34 --> Helper loaded: file_helper
INFO - 2024-01-13 15:07:34 --> Helper loaded: html_helper
INFO - 2024-01-13 15:07:34 --> Helper loaded: text_helper
INFO - 2024-01-13 15:07:34 --> Helper loaded: form_helper
INFO - 2024-01-13 15:07:34 --> Helper loaded: lang_helper
INFO - 2024-01-13 15:07:34 --> Helper loaded: security_helper
INFO - 2024-01-13 15:07:34 --> Helper loaded: cookie_helper
INFO - 2024-01-13 15:07:34 --> Database Driver Class Initialized
INFO - 2024-01-13 15:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 15:07:34 --> Parser Class Initialized
INFO - 2024-01-13 15:07:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 15:07:34 --> Pagination Class Initialized
INFO - 2024-01-13 15:07:34 --> Form Validation Class Initialized
INFO - 2024-01-13 15:07:34 --> Controller Class Initialized
INFO - 2024-01-13 15:07:34 --> Model Class Initialized
DEBUG - 2024-01-13 15:07:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-13 15:07:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 15:07:54 --> Config Class Initialized
INFO - 2024-01-13 15:07:54 --> Hooks Class Initialized
DEBUG - 2024-01-13 15:07:54 --> UTF-8 Support Enabled
INFO - 2024-01-13 15:07:54 --> Utf8 Class Initialized
INFO - 2024-01-13 15:07:54 --> URI Class Initialized
INFO - 2024-01-13 15:07:54 --> Router Class Initialized
INFO - 2024-01-13 15:07:54 --> Output Class Initialized
INFO - 2024-01-13 15:07:54 --> Security Class Initialized
DEBUG - 2024-01-13 15:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 15:07:54 --> Input Class Initialized
INFO - 2024-01-13 15:07:54 --> Language Class Initialized
INFO - 2024-01-13 15:07:54 --> Loader Class Initialized
INFO - 2024-01-13 15:07:54 --> Helper loaded: url_helper
INFO - 2024-01-13 15:07:54 --> Helper loaded: file_helper
INFO - 2024-01-13 15:07:54 --> Helper loaded: html_helper
INFO - 2024-01-13 15:07:54 --> Helper loaded: text_helper
INFO - 2024-01-13 15:07:54 --> Helper loaded: form_helper
INFO - 2024-01-13 15:07:54 --> Helper loaded: lang_helper
INFO - 2024-01-13 15:07:54 --> Helper loaded: security_helper
INFO - 2024-01-13 15:07:54 --> Helper loaded: cookie_helper
INFO - 2024-01-13 15:07:54 --> Database Driver Class Initialized
INFO - 2024-01-13 15:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 15:07:54 --> Parser Class Initialized
INFO - 2024-01-13 15:07:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 15:07:54 --> Pagination Class Initialized
INFO - 2024-01-13 15:07:54 --> Form Validation Class Initialized
INFO - 2024-01-13 15:07:54 --> Controller Class Initialized
INFO - 2024-01-13 15:07:54 --> Model Class Initialized
DEBUG - 2024-01-13 15:07:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 15:07:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-13 15:07:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-13 15:07:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-13 15:07:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-13 15:07:54 --> Model Class Initialized
INFO - 2024-01-13 15:07:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-13 15:07:54 --> Final output sent to browser
DEBUG - 2024-01-13 15:07:54 --> Total execution time: 0.0329
ERROR - 2024-01-13 15:08:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 15:08:52 --> Config Class Initialized
INFO - 2024-01-13 15:08:52 --> Hooks Class Initialized
DEBUG - 2024-01-13 15:08:52 --> UTF-8 Support Enabled
INFO - 2024-01-13 15:08:52 --> Utf8 Class Initialized
INFO - 2024-01-13 15:08:52 --> URI Class Initialized
DEBUG - 2024-01-13 15:08:52 --> No URI present. Default controller set.
INFO - 2024-01-13 15:08:52 --> Router Class Initialized
INFO - 2024-01-13 15:08:52 --> Output Class Initialized
INFO - 2024-01-13 15:08:52 --> Security Class Initialized
DEBUG - 2024-01-13 15:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 15:08:52 --> Input Class Initialized
INFO - 2024-01-13 15:08:52 --> Language Class Initialized
INFO - 2024-01-13 15:08:52 --> Loader Class Initialized
INFO - 2024-01-13 15:08:52 --> Helper loaded: url_helper
INFO - 2024-01-13 15:08:52 --> Helper loaded: file_helper
INFO - 2024-01-13 15:08:52 --> Helper loaded: html_helper
INFO - 2024-01-13 15:08:52 --> Helper loaded: text_helper
INFO - 2024-01-13 15:08:52 --> Helper loaded: form_helper
INFO - 2024-01-13 15:08:52 --> Helper loaded: lang_helper
INFO - 2024-01-13 15:08:52 --> Helper loaded: security_helper
INFO - 2024-01-13 15:08:52 --> Helper loaded: cookie_helper
INFO - 2024-01-13 15:08:52 --> Database Driver Class Initialized
INFO - 2024-01-13 15:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 15:08:52 --> Parser Class Initialized
INFO - 2024-01-13 15:08:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 15:08:52 --> Pagination Class Initialized
INFO - 2024-01-13 15:08:52 --> Form Validation Class Initialized
INFO - 2024-01-13 15:08:52 --> Controller Class Initialized
INFO - 2024-01-13 15:08:52 --> Model Class Initialized
DEBUG - 2024-01-13 15:08:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-13 15:08:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 15:08:56 --> Config Class Initialized
INFO - 2024-01-13 15:08:56 --> Hooks Class Initialized
DEBUG - 2024-01-13 15:08:56 --> UTF-8 Support Enabled
INFO - 2024-01-13 15:08:56 --> Utf8 Class Initialized
INFO - 2024-01-13 15:08:56 --> URI Class Initialized
INFO - 2024-01-13 15:08:56 --> Router Class Initialized
INFO - 2024-01-13 15:08:56 --> Output Class Initialized
INFO - 2024-01-13 15:08:56 --> Security Class Initialized
DEBUG - 2024-01-13 15:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 15:08:56 --> Input Class Initialized
INFO - 2024-01-13 15:08:56 --> Language Class Initialized
INFO - 2024-01-13 15:08:56 --> Loader Class Initialized
INFO - 2024-01-13 15:08:56 --> Helper loaded: url_helper
INFO - 2024-01-13 15:08:56 --> Helper loaded: file_helper
INFO - 2024-01-13 15:08:56 --> Helper loaded: html_helper
INFO - 2024-01-13 15:08:56 --> Helper loaded: text_helper
INFO - 2024-01-13 15:08:56 --> Helper loaded: form_helper
INFO - 2024-01-13 15:08:56 --> Helper loaded: lang_helper
INFO - 2024-01-13 15:08:56 --> Helper loaded: security_helper
INFO - 2024-01-13 15:08:56 --> Helper loaded: cookie_helper
INFO - 2024-01-13 15:08:56 --> Database Driver Class Initialized
INFO - 2024-01-13 15:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 15:08:56 --> Parser Class Initialized
INFO - 2024-01-13 15:08:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 15:08:56 --> Pagination Class Initialized
INFO - 2024-01-13 15:08:56 --> Form Validation Class Initialized
INFO - 2024-01-13 15:08:56 --> Controller Class Initialized
INFO - 2024-01-13 15:08:56 --> Model Class Initialized
DEBUG - 2024-01-13 15:08:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 15:08:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-13 15:08:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-13 15:08:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-13 15:08:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-13 15:08:56 --> Model Class Initialized
INFO - 2024-01-13 15:08:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-13 15:08:56 --> Final output sent to browser
DEBUG - 2024-01-13 15:08:56 --> Total execution time: 0.0319
ERROR - 2024-01-13 15:09:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 15:09:05 --> Config Class Initialized
INFO - 2024-01-13 15:09:05 --> Hooks Class Initialized
DEBUG - 2024-01-13 15:09:05 --> UTF-8 Support Enabled
INFO - 2024-01-13 15:09:05 --> Utf8 Class Initialized
INFO - 2024-01-13 15:09:05 --> URI Class Initialized
DEBUG - 2024-01-13 15:09:05 --> No URI present. Default controller set.
INFO - 2024-01-13 15:09:05 --> Router Class Initialized
INFO - 2024-01-13 15:09:05 --> Output Class Initialized
INFO - 2024-01-13 15:09:05 --> Security Class Initialized
DEBUG - 2024-01-13 15:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 15:09:05 --> Input Class Initialized
INFO - 2024-01-13 15:09:05 --> Language Class Initialized
INFO - 2024-01-13 15:09:05 --> Loader Class Initialized
INFO - 2024-01-13 15:09:05 --> Helper loaded: url_helper
INFO - 2024-01-13 15:09:05 --> Helper loaded: file_helper
INFO - 2024-01-13 15:09:05 --> Helper loaded: html_helper
INFO - 2024-01-13 15:09:05 --> Helper loaded: text_helper
INFO - 2024-01-13 15:09:05 --> Helper loaded: form_helper
INFO - 2024-01-13 15:09:05 --> Helper loaded: lang_helper
INFO - 2024-01-13 15:09:05 --> Helper loaded: security_helper
INFO - 2024-01-13 15:09:05 --> Helper loaded: cookie_helper
INFO - 2024-01-13 15:09:05 --> Database Driver Class Initialized
INFO - 2024-01-13 15:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 15:09:05 --> Parser Class Initialized
INFO - 2024-01-13 15:09:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 15:09:05 --> Pagination Class Initialized
INFO - 2024-01-13 15:09:05 --> Form Validation Class Initialized
INFO - 2024-01-13 15:09:05 --> Controller Class Initialized
INFO - 2024-01-13 15:09:05 --> Model Class Initialized
DEBUG - 2024-01-13 15:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-13 15:09:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 15:09:15 --> Config Class Initialized
INFO - 2024-01-13 15:09:15 --> Hooks Class Initialized
DEBUG - 2024-01-13 15:09:15 --> UTF-8 Support Enabled
INFO - 2024-01-13 15:09:15 --> Utf8 Class Initialized
INFO - 2024-01-13 15:09:15 --> URI Class Initialized
INFO - 2024-01-13 15:09:15 --> Router Class Initialized
INFO - 2024-01-13 15:09:15 --> Output Class Initialized
INFO - 2024-01-13 15:09:15 --> Security Class Initialized
DEBUG - 2024-01-13 15:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 15:09:15 --> Input Class Initialized
INFO - 2024-01-13 15:09:15 --> Language Class Initialized
INFO - 2024-01-13 15:09:15 --> Loader Class Initialized
INFO - 2024-01-13 15:09:15 --> Helper loaded: url_helper
INFO - 2024-01-13 15:09:15 --> Helper loaded: file_helper
INFO - 2024-01-13 15:09:15 --> Helper loaded: html_helper
INFO - 2024-01-13 15:09:15 --> Helper loaded: text_helper
INFO - 2024-01-13 15:09:15 --> Helper loaded: form_helper
INFO - 2024-01-13 15:09:15 --> Helper loaded: lang_helper
INFO - 2024-01-13 15:09:15 --> Helper loaded: security_helper
INFO - 2024-01-13 15:09:15 --> Helper loaded: cookie_helper
INFO - 2024-01-13 15:09:15 --> Database Driver Class Initialized
INFO - 2024-01-13 15:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 15:09:15 --> Parser Class Initialized
INFO - 2024-01-13 15:09:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 15:09:15 --> Pagination Class Initialized
INFO - 2024-01-13 15:09:15 --> Form Validation Class Initialized
INFO - 2024-01-13 15:09:15 --> Controller Class Initialized
INFO - 2024-01-13 15:09:15 --> Model Class Initialized
DEBUG - 2024-01-13 15:09:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 15:09:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-13 15:09:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-13 15:09:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-13 15:09:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-13 15:09:15 --> Model Class Initialized
INFO - 2024-01-13 15:09:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-13 15:09:15 --> Final output sent to browser
DEBUG - 2024-01-13 15:09:15 --> Total execution time: 0.0304
ERROR - 2024-01-13 15:14:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 15:14:23 --> Config Class Initialized
INFO - 2024-01-13 15:14:23 --> Hooks Class Initialized
DEBUG - 2024-01-13 15:14:23 --> UTF-8 Support Enabled
INFO - 2024-01-13 15:14:23 --> Utf8 Class Initialized
INFO - 2024-01-13 15:14:23 --> URI Class Initialized
DEBUG - 2024-01-13 15:14:23 --> No URI present. Default controller set.
INFO - 2024-01-13 15:14:23 --> Router Class Initialized
INFO - 2024-01-13 15:14:23 --> Output Class Initialized
INFO - 2024-01-13 15:14:23 --> Security Class Initialized
DEBUG - 2024-01-13 15:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 15:14:23 --> Input Class Initialized
INFO - 2024-01-13 15:14:23 --> Language Class Initialized
INFO - 2024-01-13 15:14:23 --> Loader Class Initialized
INFO - 2024-01-13 15:14:23 --> Helper loaded: url_helper
INFO - 2024-01-13 15:14:23 --> Helper loaded: file_helper
INFO - 2024-01-13 15:14:23 --> Helper loaded: html_helper
INFO - 2024-01-13 15:14:23 --> Helper loaded: text_helper
INFO - 2024-01-13 15:14:23 --> Helper loaded: form_helper
INFO - 2024-01-13 15:14:23 --> Helper loaded: lang_helper
INFO - 2024-01-13 15:14:23 --> Helper loaded: security_helper
INFO - 2024-01-13 15:14:23 --> Helper loaded: cookie_helper
INFO - 2024-01-13 15:14:23 --> Database Driver Class Initialized
INFO - 2024-01-13 15:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 15:14:23 --> Parser Class Initialized
INFO - 2024-01-13 15:14:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 15:14:23 --> Pagination Class Initialized
INFO - 2024-01-13 15:14:23 --> Form Validation Class Initialized
INFO - 2024-01-13 15:14:23 --> Controller Class Initialized
INFO - 2024-01-13 15:14:23 --> Model Class Initialized
DEBUG - 2024-01-13 15:14:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-13 15:14:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 15:14:46 --> Config Class Initialized
INFO - 2024-01-13 15:14:46 --> Hooks Class Initialized
DEBUG - 2024-01-13 15:14:46 --> UTF-8 Support Enabled
INFO - 2024-01-13 15:14:46 --> Utf8 Class Initialized
INFO - 2024-01-13 15:14:46 --> URI Class Initialized
DEBUG - 2024-01-13 15:14:46 --> No URI present. Default controller set.
INFO - 2024-01-13 15:14:46 --> Router Class Initialized
INFO - 2024-01-13 15:14:46 --> Output Class Initialized
INFO - 2024-01-13 15:14:46 --> Security Class Initialized
DEBUG - 2024-01-13 15:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 15:14:46 --> Input Class Initialized
INFO - 2024-01-13 15:14:46 --> Language Class Initialized
INFO - 2024-01-13 15:14:46 --> Loader Class Initialized
INFO - 2024-01-13 15:14:46 --> Helper loaded: url_helper
INFO - 2024-01-13 15:14:46 --> Helper loaded: file_helper
INFO - 2024-01-13 15:14:46 --> Helper loaded: html_helper
INFO - 2024-01-13 15:14:46 --> Helper loaded: text_helper
INFO - 2024-01-13 15:14:46 --> Helper loaded: form_helper
INFO - 2024-01-13 15:14:46 --> Helper loaded: lang_helper
INFO - 2024-01-13 15:14:46 --> Helper loaded: security_helper
INFO - 2024-01-13 15:14:46 --> Helper loaded: cookie_helper
INFO - 2024-01-13 15:14:46 --> Database Driver Class Initialized
INFO - 2024-01-13 15:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 15:14:46 --> Parser Class Initialized
INFO - 2024-01-13 15:14:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 15:14:46 --> Pagination Class Initialized
INFO - 2024-01-13 15:14:46 --> Form Validation Class Initialized
INFO - 2024-01-13 15:14:46 --> Controller Class Initialized
INFO - 2024-01-13 15:14:46 --> Model Class Initialized
DEBUG - 2024-01-13 15:14:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-13 15:14:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 15:14:53 --> Config Class Initialized
INFO - 2024-01-13 15:14:53 --> Hooks Class Initialized
DEBUG - 2024-01-13 15:14:53 --> UTF-8 Support Enabled
INFO - 2024-01-13 15:14:53 --> Utf8 Class Initialized
INFO - 2024-01-13 15:14:53 --> URI Class Initialized
INFO - 2024-01-13 15:14:53 --> Router Class Initialized
INFO - 2024-01-13 15:14:53 --> Output Class Initialized
INFO - 2024-01-13 15:14:53 --> Security Class Initialized
DEBUG - 2024-01-13 15:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 15:14:53 --> Input Class Initialized
INFO - 2024-01-13 15:14:53 --> Language Class Initialized
INFO - 2024-01-13 15:14:53 --> Loader Class Initialized
INFO - 2024-01-13 15:14:53 --> Helper loaded: url_helper
INFO - 2024-01-13 15:14:53 --> Helper loaded: file_helper
INFO - 2024-01-13 15:14:53 --> Helper loaded: html_helper
INFO - 2024-01-13 15:14:53 --> Helper loaded: text_helper
INFO - 2024-01-13 15:14:53 --> Helper loaded: form_helper
INFO - 2024-01-13 15:14:53 --> Helper loaded: lang_helper
INFO - 2024-01-13 15:14:53 --> Helper loaded: security_helper
INFO - 2024-01-13 15:14:53 --> Helper loaded: cookie_helper
INFO - 2024-01-13 15:14:53 --> Database Driver Class Initialized
INFO - 2024-01-13 15:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 15:14:53 --> Parser Class Initialized
INFO - 2024-01-13 15:14:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 15:14:53 --> Pagination Class Initialized
INFO - 2024-01-13 15:14:53 --> Form Validation Class Initialized
INFO - 2024-01-13 15:14:53 --> Controller Class Initialized
INFO - 2024-01-13 15:14:53 --> Model Class Initialized
DEBUG - 2024-01-13 15:14:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 15:14:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-13 15:14:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-13 15:14:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-13 15:14:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-13 15:14:53 --> Model Class Initialized
INFO - 2024-01-13 15:14:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-13 15:14:53 --> Final output sent to browser
DEBUG - 2024-01-13 15:14:53 --> Total execution time: 0.0325
ERROR - 2024-01-13 15:35:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
ERROR - 2024-01-13 15:35:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 15:35:40 --> Config Class Initialized
INFO - 2024-01-13 15:35:40 --> Hooks Class Initialized
INFO - 2024-01-13 15:35:40 --> Config Class Initialized
INFO - 2024-01-13 15:35:40 --> Hooks Class Initialized
DEBUG - 2024-01-13 15:35:40 --> UTF-8 Support Enabled
INFO - 2024-01-13 15:35:40 --> Utf8 Class Initialized
DEBUG - 2024-01-13 15:35:40 --> UTF-8 Support Enabled
INFO - 2024-01-13 15:35:40 --> Utf8 Class Initialized
INFO - 2024-01-13 15:35:40 --> URI Class Initialized
INFO - 2024-01-13 15:35:40 --> Router Class Initialized
INFO - 2024-01-13 15:35:40 --> URI Class Initialized
DEBUG - 2024-01-13 15:35:40 --> No URI present. Default controller set.
INFO - 2024-01-13 15:35:40 --> Router Class Initialized
INFO - 2024-01-13 15:35:40 --> Output Class Initialized
INFO - 2024-01-13 15:35:40 --> Output Class Initialized
INFO - 2024-01-13 15:35:40 --> Security Class Initialized
INFO - 2024-01-13 15:35:40 --> Security Class Initialized
DEBUG - 2024-01-13 15:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 15:35:40 --> Input Class Initialized
INFO - 2024-01-13 15:35:40 --> Language Class Initialized
DEBUG - 2024-01-13 15:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 15:35:40 --> Input Class Initialized
INFO - 2024-01-13 15:35:40 --> Language Class Initialized
INFO - 2024-01-13 15:35:40 --> Loader Class Initialized
INFO - 2024-01-13 15:35:40 --> Loader Class Initialized
INFO - 2024-01-13 15:35:40 --> Helper loaded: url_helper
INFO - 2024-01-13 15:35:40 --> Helper loaded: file_helper
INFO - 2024-01-13 15:35:40 --> Helper loaded: url_helper
INFO - 2024-01-13 15:35:40 --> Helper loaded: html_helper
INFO - 2024-01-13 15:35:40 --> Helper loaded: file_helper
INFO - 2024-01-13 15:35:40 --> Helper loaded: text_helper
INFO - 2024-01-13 15:35:40 --> Helper loaded: html_helper
INFO - 2024-01-13 15:35:40 --> Helper loaded: text_helper
INFO - 2024-01-13 15:35:40 --> Helper loaded: form_helper
INFO - 2024-01-13 15:35:40 --> Helper loaded: lang_helper
INFO - 2024-01-13 15:35:40 --> Helper loaded: security_helper
INFO - 2024-01-13 15:35:40 --> Helper loaded: cookie_helper
INFO - 2024-01-13 15:35:40 --> Helper loaded: form_helper
INFO - 2024-01-13 15:35:40 --> Helper loaded: lang_helper
INFO - 2024-01-13 15:35:40 --> Helper loaded: security_helper
INFO - 2024-01-13 15:35:40 --> Helper loaded: cookie_helper
INFO - 2024-01-13 15:35:40 --> Database Driver Class Initialized
INFO - 2024-01-13 15:35:40 --> Database Driver Class Initialized
INFO - 2024-01-13 15:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 15:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 15:35:40 --> Parser Class Initialized
INFO - 2024-01-13 15:35:40 --> Parser Class Initialized
INFO - 2024-01-13 15:35:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 15:35:40 --> Pagination Class Initialized
INFO - 2024-01-13 15:35:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 15:35:40 --> Pagination Class Initialized
INFO - 2024-01-13 15:35:40 --> Form Validation Class Initialized
INFO - 2024-01-13 15:35:40 --> Form Validation Class Initialized
INFO - 2024-01-13 15:35:40 --> Controller Class Initialized
INFO - 2024-01-13 15:35:40 --> Model Class Initialized
INFO - 2024-01-13 15:35:40 --> Controller Class Initialized
DEBUG - 2024-01-13 15:35:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 15:35:40 --> Model Class Initialized
DEBUG - 2024-01-13 15:35:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 15:35:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-13 15:35:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-13 15:35:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-13 15:35:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-13 15:35:40 --> Model Class Initialized
INFO - 2024-01-13 15:35:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-13 15:35:40 --> Final output sent to browser
DEBUG - 2024-01-13 15:35:40 --> Total execution time: 0.0341
ERROR - 2024-01-13 15:35:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 15:35:53 --> Config Class Initialized
INFO - 2024-01-13 15:35:53 --> Hooks Class Initialized
DEBUG - 2024-01-13 15:35:53 --> UTF-8 Support Enabled
INFO - 2024-01-13 15:35:53 --> Utf8 Class Initialized
INFO - 2024-01-13 15:35:53 --> URI Class Initialized
INFO - 2024-01-13 15:35:53 --> Router Class Initialized
INFO - 2024-01-13 15:35:53 --> Output Class Initialized
INFO - 2024-01-13 15:35:53 --> Security Class Initialized
DEBUG - 2024-01-13 15:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 15:35:53 --> Input Class Initialized
INFO - 2024-01-13 15:35:53 --> Language Class Initialized
INFO - 2024-01-13 15:35:53 --> Loader Class Initialized
INFO - 2024-01-13 15:35:53 --> Helper loaded: url_helper
INFO - 2024-01-13 15:35:53 --> Helper loaded: file_helper
INFO - 2024-01-13 15:35:53 --> Helper loaded: html_helper
INFO - 2024-01-13 15:35:53 --> Helper loaded: text_helper
INFO - 2024-01-13 15:35:53 --> Helper loaded: form_helper
INFO - 2024-01-13 15:35:53 --> Helper loaded: lang_helper
INFO - 2024-01-13 15:35:53 --> Helper loaded: security_helper
INFO - 2024-01-13 15:35:53 --> Helper loaded: cookie_helper
INFO - 2024-01-13 15:35:53 --> Database Driver Class Initialized
INFO - 2024-01-13 15:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 15:35:53 --> Parser Class Initialized
INFO - 2024-01-13 15:35:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 15:35:53 --> Pagination Class Initialized
INFO - 2024-01-13 15:35:53 --> Form Validation Class Initialized
INFO - 2024-01-13 15:35:53 --> Controller Class Initialized
INFO - 2024-01-13 15:35:53 --> Model Class Initialized
DEBUG - 2024-01-13 15:35:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 15:35:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-13 15:35:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-13 15:35:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-13 15:35:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-13 15:35:53 --> Model Class Initialized
INFO - 2024-01-13 15:35:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-13 15:35:53 --> Final output sent to browser
DEBUG - 2024-01-13 15:35:53 --> Total execution time: 0.0302
ERROR - 2024-01-13 16:45:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:45:34 --> Config Class Initialized
INFO - 2024-01-13 16:45:34 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:45:34 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:45:34 --> Utf8 Class Initialized
INFO - 2024-01-13 16:45:34 --> URI Class Initialized
DEBUG - 2024-01-13 16:45:34 --> No URI present. Default controller set.
INFO - 2024-01-13 16:45:34 --> Router Class Initialized
INFO - 2024-01-13 16:45:34 --> Output Class Initialized
INFO - 2024-01-13 16:45:34 --> Security Class Initialized
DEBUG - 2024-01-13 16:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:45:34 --> Input Class Initialized
INFO - 2024-01-13 16:45:34 --> Language Class Initialized
INFO - 2024-01-13 16:45:34 --> Loader Class Initialized
INFO - 2024-01-13 16:45:34 --> Helper loaded: url_helper
INFO - 2024-01-13 16:45:34 --> Helper loaded: file_helper
INFO - 2024-01-13 16:45:34 --> Helper loaded: html_helper
INFO - 2024-01-13 16:45:34 --> Helper loaded: text_helper
INFO - 2024-01-13 16:45:34 --> Helper loaded: form_helper
INFO - 2024-01-13 16:45:34 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:45:34 --> Helper loaded: security_helper
INFO - 2024-01-13 16:45:34 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:45:34 --> Database Driver Class Initialized
INFO - 2024-01-13 16:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:45:34 --> Parser Class Initialized
INFO - 2024-01-13 16:45:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:45:34 --> Pagination Class Initialized
INFO - 2024-01-13 16:45:34 --> Form Validation Class Initialized
INFO - 2024-01-13 16:45:34 --> Controller Class Initialized
INFO - 2024-01-13 16:45:34 --> Model Class Initialized
DEBUG - 2024-01-13 16:45:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-13 16:45:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:45:34 --> Config Class Initialized
INFO - 2024-01-13 16:45:34 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:45:34 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:45:34 --> Utf8 Class Initialized
INFO - 2024-01-13 16:45:34 --> URI Class Initialized
INFO - 2024-01-13 16:45:34 --> Router Class Initialized
INFO - 2024-01-13 16:45:34 --> Output Class Initialized
INFO - 2024-01-13 16:45:34 --> Security Class Initialized
DEBUG - 2024-01-13 16:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:45:34 --> Input Class Initialized
INFO - 2024-01-13 16:45:34 --> Language Class Initialized
INFO - 2024-01-13 16:45:34 --> Loader Class Initialized
INFO - 2024-01-13 16:45:34 --> Helper loaded: url_helper
INFO - 2024-01-13 16:45:34 --> Helper loaded: file_helper
INFO - 2024-01-13 16:45:34 --> Helper loaded: html_helper
INFO - 2024-01-13 16:45:34 --> Helper loaded: text_helper
INFO - 2024-01-13 16:45:34 --> Helper loaded: form_helper
INFO - 2024-01-13 16:45:34 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:45:34 --> Helper loaded: security_helper
INFO - 2024-01-13 16:45:34 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:45:34 --> Database Driver Class Initialized
INFO - 2024-01-13 16:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:45:34 --> Parser Class Initialized
INFO - 2024-01-13 16:45:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:45:34 --> Pagination Class Initialized
INFO - 2024-01-13 16:45:34 --> Form Validation Class Initialized
INFO - 2024-01-13 16:45:34 --> Controller Class Initialized
INFO - 2024-01-13 16:45:34 --> Model Class Initialized
DEBUG - 2024-01-13 16:45:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:45:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-13 16:45:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:45:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-13 16:45:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-13 16:45:34 --> Model Class Initialized
INFO - 2024-01-13 16:45:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-13 16:45:34 --> Final output sent to browser
DEBUG - 2024-01-13 16:45:34 --> Total execution time: 0.0371
ERROR - 2024-01-13 16:45:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:45:43 --> Config Class Initialized
INFO - 2024-01-13 16:45:43 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:45:43 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:45:43 --> Utf8 Class Initialized
INFO - 2024-01-13 16:45:43 --> URI Class Initialized
INFO - 2024-01-13 16:45:43 --> Router Class Initialized
INFO - 2024-01-13 16:45:43 --> Output Class Initialized
INFO - 2024-01-13 16:45:43 --> Security Class Initialized
DEBUG - 2024-01-13 16:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:45:43 --> Input Class Initialized
INFO - 2024-01-13 16:45:43 --> Language Class Initialized
INFO - 2024-01-13 16:45:43 --> Loader Class Initialized
INFO - 2024-01-13 16:45:43 --> Helper loaded: url_helper
INFO - 2024-01-13 16:45:43 --> Helper loaded: file_helper
INFO - 2024-01-13 16:45:43 --> Helper loaded: html_helper
INFO - 2024-01-13 16:45:43 --> Helper loaded: text_helper
INFO - 2024-01-13 16:45:43 --> Helper loaded: form_helper
INFO - 2024-01-13 16:45:43 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:45:43 --> Helper loaded: security_helper
INFO - 2024-01-13 16:45:43 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:45:43 --> Database Driver Class Initialized
INFO - 2024-01-13 16:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:45:43 --> Parser Class Initialized
INFO - 2024-01-13 16:45:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:45:43 --> Pagination Class Initialized
INFO - 2024-01-13 16:45:43 --> Form Validation Class Initialized
INFO - 2024-01-13 16:45:43 --> Controller Class Initialized
INFO - 2024-01-13 16:45:43 --> Model Class Initialized
DEBUG - 2024-01-13 16:45:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:45:43 --> Model Class Initialized
INFO - 2024-01-13 16:45:43 --> Final output sent to browser
DEBUG - 2024-01-13 16:45:43 --> Total execution time: 0.0193
ERROR - 2024-01-13 16:45:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:45:43 --> Config Class Initialized
INFO - 2024-01-13 16:45:43 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:45:43 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:45:43 --> Utf8 Class Initialized
INFO - 2024-01-13 16:45:43 --> URI Class Initialized
DEBUG - 2024-01-13 16:45:43 --> No URI present. Default controller set.
INFO - 2024-01-13 16:45:43 --> Router Class Initialized
INFO - 2024-01-13 16:45:43 --> Output Class Initialized
INFO - 2024-01-13 16:45:43 --> Security Class Initialized
DEBUG - 2024-01-13 16:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:45:43 --> Input Class Initialized
INFO - 2024-01-13 16:45:43 --> Language Class Initialized
INFO - 2024-01-13 16:45:43 --> Loader Class Initialized
INFO - 2024-01-13 16:45:43 --> Helper loaded: url_helper
INFO - 2024-01-13 16:45:43 --> Helper loaded: file_helper
INFO - 2024-01-13 16:45:43 --> Helper loaded: html_helper
INFO - 2024-01-13 16:45:43 --> Helper loaded: text_helper
INFO - 2024-01-13 16:45:43 --> Helper loaded: form_helper
INFO - 2024-01-13 16:45:43 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:45:43 --> Helper loaded: security_helper
INFO - 2024-01-13 16:45:43 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:45:43 --> Database Driver Class Initialized
INFO - 2024-01-13 16:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:45:43 --> Parser Class Initialized
INFO - 2024-01-13 16:45:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:45:43 --> Pagination Class Initialized
INFO - 2024-01-13 16:45:43 --> Form Validation Class Initialized
INFO - 2024-01-13 16:45:43 --> Controller Class Initialized
INFO - 2024-01-13 16:45:43 --> Model Class Initialized
DEBUG - 2024-01-13 16:45:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:45:43 --> Model Class Initialized
DEBUG - 2024-01-13 16:45:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:45:43 --> Model Class Initialized
INFO - 2024-01-13 16:45:43 --> Model Class Initialized
INFO - 2024-01-13 16:45:43 --> Model Class Initialized
INFO - 2024-01-13 16:45:43 --> Model Class Initialized
DEBUG - 2024-01-13 16:45:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:45:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:45:43 --> Model Class Initialized
INFO - 2024-01-13 16:45:43 --> Model Class Initialized
INFO - 2024-01-13 16:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-13 16:45:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-13 16:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-13 16:45:44 --> Model Class Initialized
INFO - 2024-01-13 16:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-13 16:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-13 16:45:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-13 16:45:44 --> Final output sent to browser
DEBUG - 2024-01-13 16:45:44 --> Total execution time: 0.3932
ERROR - 2024-01-13 16:45:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:45:44 --> Config Class Initialized
INFO - 2024-01-13 16:45:44 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:45:44 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:45:44 --> Utf8 Class Initialized
INFO - 2024-01-13 16:45:44 --> URI Class Initialized
INFO - 2024-01-13 16:45:44 --> Router Class Initialized
INFO - 2024-01-13 16:45:44 --> Output Class Initialized
INFO - 2024-01-13 16:45:44 --> Security Class Initialized
DEBUG - 2024-01-13 16:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:45:44 --> Input Class Initialized
INFO - 2024-01-13 16:45:44 --> Language Class Initialized
INFO - 2024-01-13 16:45:44 --> Loader Class Initialized
INFO - 2024-01-13 16:45:44 --> Helper loaded: url_helper
INFO - 2024-01-13 16:45:44 --> Helper loaded: file_helper
INFO - 2024-01-13 16:45:44 --> Helper loaded: html_helper
INFO - 2024-01-13 16:45:44 --> Helper loaded: text_helper
INFO - 2024-01-13 16:45:44 --> Helper loaded: form_helper
INFO - 2024-01-13 16:45:44 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:45:44 --> Helper loaded: security_helper
INFO - 2024-01-13 16:45:44 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:45:44 --> Database Driver Class Initialized
INFO - 2024-01-13 16:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:45:44 --> Parser Class Initialized
INFO - 2024-01-13 16:45:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:45:44 --> Pagination Class Initialized
INFO - 2024-01-13 16:45:44 --> Form Validation Class Initialized
INFO - 2024-01-13 16:45:44 --> Controller Class Initialized
DEBUG - 2024-01-13 16:45:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:45:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:45:44 --> Model Class Initialized
INFO - 2024-01-13 16:45:44 --> Final output sent to browser
DEBUG - 2024-01-13 16:45:44 --> Total execution time: 0.0132
ERROR - 2024-01-13 16:45:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:45:54 --> Config Class Initialized
INFO - 2024-01-13 16:45:54 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:45:54 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:45:54 --> Utf8 Class Initialized
INFO - 2024-01-13 16:45:54 --> URI Class Initialized
INFO - 2024-01-13 16:45:54 --> Router Class Initialized
INFO - 2024-01-13 16:45:54 --> Output Class Initialized
INFO - 2024-01-13 16:45:54 --> Security Class Initialized
DEBUG - 2024-01-13 16:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:45:54 --> Input Class Initialized
INFO - 2024-01-13 16:45:54 --> Language Class Initialized
INFO - 2024-01-13 16:45:54 --> Loader Class Initialized
INFO - 2024-01-13 16:45:54 --> Helper loaded: url_helper
INFO - 2024-01-13 16:45:54 --> Helper loaded: file_helper
INFO - 2024-01-13 16:45:54 --> Helper loaded: html_helper
INFO - 2024-01-13 16:45:54 --> Helper loaded: text_helper
INFO - 2024-01-13 16:45:54 --> Helper loaded: form_helper
INFO - 2024-01-13 16:45:54 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:45:54 --> Helper loaded: security_helper
INFO - 2024-01-13 16:45:54 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:45:54 --> Database Driver Class Initialized
INFO - 2024-01-13 16:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:45:54 --> Parser Class Initialized
INFO - 2024-01-13 16:45:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:45:54 --> Pagination Class Initialized
INFO - 2024-01-13 16:45:54 --> Form Validation Class Initialized
INFO - 2024-01-13 16:45:54 --> Controller Class Initialized
INFO - 2024-01-13 16:45:54 --> Model Class Initialized
DEBUG - 2024-01-13 16:45:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:45:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:45:54 --> Model Class Initialized
DEBUG - 2024-01-13 16:45:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:45:54 --> Model Class Initialized
INFO - 2024-01-13 16:45:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-13 16:45:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:45:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-13 16:45:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-13 16:45:54 --> Model Class Initialized
INFO - 2024-01-13 16:45:54 --> Model Class Initialized
INFO - 2024-01-13 16:45:54 --> Model Class Initialized
INFO - 2024-01-13 16:45:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-13 16:45:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-13 16:45:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-13 16:45:54 --> Final output sent to browser
DEBUG - 2024-01-13 16:45:54 --> Total execution time: 0.2241
ERROR - 2024-01-13 16:45:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:45:54 --> Config Class Initialized
INFO - 2024-01-13 16:45:54 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:45:54 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:45:54 --> Utf8 Class Initialized
INFO - 2024-01-13 16:45:54 --> URI Class Initialized
INFO - 2024-01-13 16:45:54 --> Router Class Initialized
INFO - 2024-01-13 16:45:54 --> Output Class Initialized
INFO - 2024-01-13 16:45:54 --> Security Class Initialized
DEBUG - 2024-01-13 16:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:45:54 --> Input Class Initialized
INFO - 2024-01-13 16:45:54 --> Language Class Initialized
INFO - 2024-01-13 16:45:55 --> Loader Class Initialized
INFO - 2024-01-13 16:45:55 --> Helper loaded: url_helper
INFO - 2024-01-13 16:45:55 --> Helper loaded: file_helper
INFO - 2024-01-13 16:45:55 --> Helper loaded: html_helper
INFO - 2024-01-13 16:45:55 --> Helper loaded: text_helper
INFO - 2024-01-13 16:45:55 --> Helper loaded: form_helper
INFO - 2024-01-13 16:45:55 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:45:55 --> Helper loaded: security_helper
INFO - 2024-01-13 16:45:55 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:45:55 --> Database Driver Class Initialized
INFO - 2024-01-13 16:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:45:55 --> Parser Class Initialized
INFO - 2024-01-13 16:45:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:45:55 --> Pagination Class Initialized
INFO - 2024-01-13 16:45:55 --> Form Validation Class Initialized
INFO - 2024-01-13 16:45:55 --> Controller Class Initialized
INFO - 2024-01-13 16:45:55 --> Model Class Initialized
DEBUG - 2024-01-13 16:45:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:45:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:45:55 --> Model Class Initialized
DEBUG - 2024-01-13 16:45:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:45:55 --> Model Class Initialized
INFO - 2024-01-13 16:45:55 --> Final output sent to browser
DEBUG - 2024-01-13 16:45:55 --> Total execution time: 0.0630
ERROR - 2024-01-13 16:46:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:46:00 --> Config Class Initialized
INFO - 2024-01-13 16:46:00 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:46:00 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:46:00 --> Utf8 Class Initialized
INFO - 2024-01-13 16:46:00 --> URI Class Initialized
DEBUG - 2024-01-13 16:46:00 --> No URI present. Default controller set.
INFO - 2024-01-13 16:46:00 --> Router Class Initialized
INFO - 2024-01-13 16:46:00 --> Output Class Initialized
INFO - 2024-01-13 16:46:00 --> Security Class Initialized
DEBUG - 2024-01-13 16:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:46:00 --> Input Class Initialized
INFO - 2024-01-13 16:46:00 --> Language Class Initialized
INFO - 2024-01-13 16:46:00 --> Loader Class Initialized
INFO - 2024-01-13 16:46:00 --> Helper loaded: url_helper
INFO - 2024-01-13 16:46:00 --> Helper loaded: file_helper
INFO - 2024-01-13 16:46:00 --> Helper loaded: html_helper
INFO - 2024-01-13 16:46:00 --> Helper loaded: text_helper
INFO - 2024-01-13 16:46:00 --> Helper loaded: form_helper
INFO - 2024-01-13 16:46:00 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:46:00 --> Helper loaded: security_helper
INFO - 2024-01-13 16:46:00 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:46:00 --> Database Driver Class Initialized
INFO - 2024-01-13 16:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:46:00 --> Parser Class Initialized
INFO - 2024-01-13 16:46:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:46:00 --> Pagination Class Initialized
INFO - 2024-01-13 16:46:00 --> Form Validation Class Initialized
INFO - 2024-01-13 16:46:00 --> Controller Class Initialized
INFO - 2024-01-13 16:46:00 --> Model Class Initialized
DEBUG - 2024-01-13 16:46:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:46:00 --> Model Class Initialized
DEBUG - 2024-01-13 16:46:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:46:00 --> Model Class Initialized
INFO - 2024-01-13 16:46:00 --> Model Class Initialized
INFO - 2024-01-13 16:46:00 --> Model Class Initialized
INFO - 2024-01-13 16:46:00 --> Model Class Initialized
DEBUG - 2024-01-13 16:46:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:46:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:46:00 --> Model Class Initialized
INFO - 2024-01-13 16:46:00 --> Model Class Initialized
INFO - 2024-01-13 16:46:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-13 16:46:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:46:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-13 16:46:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-13 16:46:00 --> Model Class Initialized
INFO - 2024-01-13 16:46:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-13 16:46:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-13 16:46:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-13 16:46:00 --> Final output sent to browser
DEBUG - 2024-01-13 16:46:00 --> Total execution time: 0.3814
ERROR - 2024-01-13 16:46:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:46:01 --> Config Class Initialized
INFO - 2024-01-13 16:46:01 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:46:01 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:46:01 --> Utf8 Class Initialized
INFO - 2024-01-13 16:46:01 --> URI Class Initialized
INFO - 2024-01-13 16:46:01 --> Router Class Initialized
INFO - 2024-01-13 16:46:01 --> Output Class Initialized
INFO - 2024-01-13 16:46:01 --> Security Class Initialized
DEBUG - 2024-01-13 16:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:46:01 --> Input Class Initialized
INFO - 2024-01-13 16:46:01 --> Language Class Initialized
INFO - 2024-01-13 16:46:01 --> Loader Class Initialized
INFO - 2024-01-13 16:46:01 --> Helper loaded: url_helper
INFO - 2024-01-13 16:46:01 --> Helper loaded: file_helper
INFO - 2024-01-13 16:46:01 --> Helper loaded: html_helper
INFO - 2024-01-13 16:46:01 --> Helper loaded: text_helper
INFO - 2024-01-13 16:46:01 --> Helper loaded: form_helper
INFO - 2024-01-13 16:46:01 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:46:01 --> Helper loaded: security_helper
INFO - 2024-01-13 16:46:01 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:46:01 --> Database Driver Class Initialized
INFO - 2024-01-13 16:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:46:01 --> Parser Class Initialized
INFO - 2024-01-13 16:46:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:46:01 --> Pagination Class Initialized
INFO - 2024-01-13 16:46:01 --> Form Validation Class Initialized
INFO - 2024-01-13 16:46:01 --> Controller Class Initialized
INFO - 2024-01-13 16:46:01 --> Model Class Initialized
DEBUG - 2024-01-13 16:46:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:46:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-13 16:46:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:46:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-13 16:46:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-13 16:46:01 --> Model Class Initialized
INFO - 2024-01-13 16:46:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-13 16:46:01 --> Final output sent to browser
DEBUG - 2024-01-13 16:46:01 --> Total execution time: 0.0268
ERROR - 2024-01-13 16:46:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:46:02 --> Config Class Initialized
INFO - 2024-01-13 16:46:02 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:46:02 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:46:02 --> Utf8 Class Initialized
INFO - 2024-01-13 16:46:02 --> URI Class Initialized
INFO - 2024-01-13 16:46:02 --> Router Class Initialized
INFO - 2024-01-13 16:46:02 --> Output Class Initialized
INFO - 2024-01-13 16:46:02 --> Security Class Initialized
DEBUG - 2024-01-13 16:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:46:02 --> Input Class Initialized
INFO - 2024-01-13 16:46:02 --> Language Class Initialized
INFO - 2024-01-13 16:46:02 --> Loader Class Initialized
INFO - 2024-01-13 16:46:02 --> Helper loaded: url_helper
INFO - 2024-01-13 16:46:02 --> Helper loaded: file_helper
INFO - 2024-01-13 16:46:02 --> Helper loaded: html_helper
INFO - 2024-01-13 16:46:02 --> Helper loaded: text_helper
INFO - 2024-01-13 16:46:02 --> Helper loaded: form_helper
INFO - 2024-01-13 16:46:02 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:46:02 --> Helper loaded: security_helper
INFO - 2024-01-13 16:46:02 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:46:02 --> Database Driver Class Initialized
INFO - 2024-01-13 16:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:46:02 --> Parser Class Initialized
INFO - 2024-01-13 16:46:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:46:02 --> Pagination Class Initialized
INFO - 2024-01-13 16:46:02 --> Form Validation Class Initialized
INFO - 2024-01-13 16:46:02 --> Controller Class Initialized
INFO - 2024-01-13 16:46:02 --> Model Class Initialized
DEBUG - 2024-01-13 16:46:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:46:02 --> Model Class Initialized
DEBUG - 2024-01-13 16:46:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:46:02 --> Model Class Initialized
INFO - 2024-01-13 16:46:02 --> Model Class Initialized
INFO - 2024-01-13 16:46:02 --> Model Class Initialized
INFO - 2024-01-13 16:46:02 --> Model Class Initialized
DEBUG - 2024-01-13 16:46:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:46:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:46:02 --> Model Class Initialized
INFO - 2024-01-13 16:46:02 --> Model Class Initialized
INFO - 2024-01-13 16:46:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-13 16:46:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:46:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-13 16:46:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-13 16:46:02 --> Model Class Initialized
INFO - 2024-01-13 16:46:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-13 16:46:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-13 16:46:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-13 16:46:02 --> Final output sent to browser
DEBUG - 2024-01-13 16:46:02 --> Total execution time: 0.3824
ERROR - 2024-01-13 16:46:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:46:07 --> Config Class Initialized
INFO - 2024-01-13 16:46:07 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:46:07 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:46:07 --> Utf8 Class Initialized
INFO - 2024-01-13 16:46:07 --> URI Class Initialized
INFO - 2024-01-13 16:46:07 --> Router Class Initialized
INFO - 2024-01-13 16:46:07 --> Output Class Initialized
INFO - 2024-01-13 16:46:07 --> Security Class Initialized
DEBUG - 2024-01-13 16:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:46:07 --> Input Class Initialized
INFO - 2024-01-13 16:46:07 --> Language Class Initialized
INFO - 2024-01-13 16:46:07 --> Loader Class Initialized
INFO - 2024-01-13 16:46:07 --> Helper loaded: url_helper
INFO - 2024-01-13 16:46:07 --> Helper loaded: file_helper
INFO - 2024-01-13 16:46:07 --> Helper loaded: html_helper
INFO - 2024-01-13 16:46:07 --> Helper loaded: text_helper
INFO - 2024-01-13 16:46:07 --> Helper loaded: form_helper
INFO - 2024-01-13 16:46:07 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:46:07 --> Helper loaded: security_helper
INFO - 2024-01-13 16:46:07 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:46:07 --> Database Driver Class Initialized
INFO - 2024-01-13 16:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:46:07 --> Parser Class Initialized
INFO - 2024-01-13 16:46:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:46:07 --> Pagination Class Initialized
INFO - 2024-01-13 16:46:07 --> Form Validation Class Initialized
INFO - 2024-01-13 16:46:07 --> Controller Class Initialized
DEBUG - 2024-01-13 16:46:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:46:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:46:07 --> Model Class Initialized
DEBUG - 2024-01-13 16:46:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:46:07 --> Model Class Initialized
DEBUG - 2024-01-13 16:46:07 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:46:07 --> Model Class Initialized
INFO - 2024-01-13 16:46:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-01-13 16:46:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:46:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-13 16:46:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-13 16:46:07 --> Model Class Initialized
INFO - 2024-01-13 16:46:07 --> Model Class Initialized
INFO - 2024-01-13 16:46:07 --> Model Class Initialized
INFO - 2024-01-13 16:46:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-13 16:46:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-13 16:46:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-13 16:46:07 --> Final output sent to browser
DEBUG - 2024-01-13 16:46:07 --> Total execution time: 0.2200
ERROR - 2024-01-13 16:46:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:46:08 --> Config Class Initialized
INFO - 2024-01-13 16:46:08 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:46:08 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:46:08 --> Utf8 Class Initialized
INFO - 2024-01-13 16:46:08 --> URI Class Initialized
INFO - 2024-01-13 16:46:08 --> Router Class Initialized
INFO - 2024-01-13 16:46:08 --> Output Class Initialized
INFO - 2024-01-13 16:46:08 --> Security Class Initialized
DEBUG - 2024-01-13 16:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:46:08 --> Input Class Initialized
INFO - 2024-01-13 16:46:08 --> Language Class Initialized
INFO - 2024-01-13 16:46:08 --> Loader Class Initialized
INFO - 2024-01-13 16:46:08 --> Helper loaded: url_helper
INFO - 2024-01-13 16:46:08 --> Helper loaded: file_helper
INFO - 2024-01-13 16:46:08 --> Helper loaded: html_helper
INFO - 2024-01-13 16:46:08 --> Helper loaded: text_helper
INFO - 2024-01-13 16:46:08 --> Helper loaded: form_helper
INFO - 2024-01-13 16:46:08 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:46:08 --> Helper loaded: security_helper
INFO - 2024-01-13 16:46:08 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:46:08 --> Database Driver Class Initialized
INFO - 2024-01-13 16:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:46:08 --> Parser Class Initialized
INFO - 2024-01-13 16:46:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:46:08 --> Pagination Class Initialized
INFO - 2024-01-13 16:46:08 --> Form Validation Class Initialized
INFO - 2024-01-13 16:46:08 --> Controller Class Initialized
DEBUG - 2024-01-13 16:46:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:46:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:46:08 --> Model Class Initialized
DEBUG - 2024-01-13 16:46:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:46:08 --> Model Class Initialized
INFO - 2024-01-13 16:46:08 --> Final output sent to browser
DEBUG - 2024-01-13 16:46:08 --> Total execution time: 0.0301
ERROR - 2024-01-13 16:46:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:46:18 --> Config Class Initialized
INFO - 2024-01-13 16:46:18 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:46:18 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:46:18 --> Utf8 Class Initialized
INFO - 2024-01-13 16:46:18 --> URI Class Initialized
INFO - 2024-01-13 16:46:18 --> Router Class Initialized
INFO - 2024-01-13 16:46:18 --> Output Class Initialized
INFO - 2024-01-13 16:46:18 --> Security Class Initialized
DEBUG - 2024-01-13 16:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:46:18 --> Input Class Initialized
INFO - 2024-01-13 16:46:18 --> Language Class Initialized
INFO - 2024-01-13 16:46:18 --> Loader Class Initialized
INFO - 2024-01-13 16:46:18 --> Helper loaded: url_helper
INFO - 2024-01-13 16:46:18 --> Helper loaded: file_helper
INFO - 2024-01-13 16:46:18 --> Helper loaded: html_helper
INFO - 2024-01-13 16:46:18 --> Helper loaded: text_helper
INFO - 2024-01-13 16:46:18 --> Helper loaded: form_helper
INFO - 2024-01-13 16:46:18 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:46:18 --> Helper loaded: security_helper
INFO - 2024-01-13 16:46:18 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:46:18 --> Database Driver Class Initialized
INFO - 2024-01-13 16:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:46:18 --> Parser Class Initialized
INFO - 2024-01-13 16:46:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:46:18 --> Pagination Class Initialized
INFO - 2024-01-13 16:46:18 --> Form Validation Class Initialized
INFO - 2024-01-13 16:46:18 --> Controller Class Initialized
DEBUG - 2024-01-13 16:46:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:46:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:46:18 --> Model Class Initialized
DEBUG - 2024-01-13 16:46:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:46:18 --> Model Class Initialized
INFO - 2024-01-13 16:46:18 --> Final output sent to browser
DEBUG - 2024-01-13 16:46:18 --> Total execution time: 0.1787
ERROR - 2024-01-13 16:47:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:47:15 --> Config Class Initialized
INFO - 2024-01-13 16:47:15 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:47:15 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:47:15 --> Utf8 Class Initialized
INFO - 2024-01-13 16:47:15 --> URI Class Initialized
INFO - 2024-01-13 16:47:15 --> Router Class Initialized
INFO - 2024-01-13 16:47:15 --> Output Class Initialized
INFO - 2024-01-13 16:47:15 --> Security Class Initialized
DEBUG - 2024-01-13 16:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:47:15 --> Input Class Initialized
INFO - 2024-01-13 16:47:15 --> Language Class Initialized
INFO - 2024-01-13 16:47:15 --> Loader Class Initialized
INFO - 2024-01-13 16:47:15 --> Helper loaded: url_helper
INFO - 2024-01-13 16:47:15 --> Helper loaded: file_helper
INFO - 2024-01-13 16:47:15 --> Helper loaded: html_helper
INFO - 2024-01-13 16:47:15 --> Helper loaded: text_helper
INFO - 2024-01-13 16:47:15 --> Helper loaded: form_helper
INFO - 2024-01-13 16:47:15 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:47:15 --> Helper loaded: security_helper
INFO - 2024-01-13 16:47:15 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:47:15 --> Database Driver Class Initialized
INFO - 2024-01-13 16:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:47:15 --> Parser Class Initialized
INFO - 2024-01-13 16:47:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:47:15 --> Pagination Class Initialized
INFO - 2024-01-13 16:47:15 --> Form Validation Class Initialized
INFO - 2024-01-13 16:47:15 --> Controller Class Initialized
DEBUG - 2024-01-13 16:47:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:47:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:47:15 --> Model Class Initialized
DEBUG - 2024-01-13 16:47:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:47:15 --> Model Class Initialized
INFO - 2024-01-13 16:47:15 --> Final output sent to browser
DEBUG - 2024-01-13 16:47:15 --> Total execution time: 0.0325
ERROR - 2024-01-13 16:50:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:50:26 --> Config Class Initialized
INFO - 2024-01-13 16:50:26 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:50:26 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:50:26 --> Utf8 Class Initialized
INFO - 2024-01-13 16:50:26 --> URI Class Initialized
DEBUG - 2024-01-13 16:50:26 --> No URI present. Default controller set.
INFO - 2024-01-13 16:50:26 --> Router Class Initialized
INFO - 2024-01-13 16:50:26 --> Output Class Initialized
INFO - 2024-01-13 16:50:26 --> Security Class Initialized
DEBUG - 2024-01-13 16:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:50:26 --> Input Class Initialized
INFO - 2024-01-13 16:50:26 --> Language Class Initialized
INFO - 2024-01-13 16:50:26 --> Loader Class Initialized
INFO - 2024-01-13 16:50:26 --> Helper loaded: url_helper
INFO - 2024-01-13 16:50:26 --> Helper loaded: file_helper
INFO - 2024-01-13 16:50:26 --> Helper loaded: html_helper
INFO - 2024-01-13 16:50:26 --> Helper loaded: text_helper
INFO - 2024-01-13 16:50:26 --> Helper loaded: form_helper
INFO - 2024-01-13 16:50:26 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:50:26 --> Helper loaded: security_helper
INFO - 2024-01-13 16:50:26 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:50:26 --> Database Driver Class Initialized
INFO - 2024-01-13 16:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:50:26 --> Parser Class Initialized
INFO - 2024-01-13 16:50:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:50:26 --> Pagination Class Initialized
INFO - 2024-01-13 16:50:26 --> Form Validation Class Initialized
INFO - 2024-01-13 16:50:26 --> Controller Class Initialized
INFO - 2024-01-13 16:50:26 --> Model Class Initialized
DEBUG - 2024-01-13 16:50:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:50:26 --> Model Class Initialized
DEBUG - 2024-01-13 16:50:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:50:26 --> Model Class Initialized
INFO - 2024-01-13 16:50:26 --> Model Class Initialized
INFO - 2024-01-13 16:50:26 --> Model Class Initialized
INFO - 2024-01-13 16:50:26 --> Model Class Initialized
DEBUG - 2024-01-13 16:50:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:50:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:50:26 --> Model Class Initialized
INFO - 2024-01-13 16:50:26 --> Model Class Initialized
INFO - 2024-01-13 16:50:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-13 16:50:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:50:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-13 16:50:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-13 16:50:27 --> Model Class Initialized
INFO - 2024-01-13 16:50:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-13 16:50:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-13 16:50:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-13 16:50:27 --> Final output sent to browser
DEBUG - 2024-01-13 16:50:27 --> Total execution time: 0.4127
ERROR - 2024-01-13 16:50:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:50:36 --> Config Class Initialized
INFO - 2024-01-13 16:50:36 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:50:36 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:50:36 --> Utf8 Class Initialized
INFO - 2024-01-13 16:50:36 --> URI Class Initialized
INFO - 2024-01-13 16:50:36 --> Router Class Initialized
INFO - 2024-01-13 16:50:36 --> Output Class Initialized
INFO - 2024-01-13 16:50:36 --> Security Class Initialized
DEBUG - 2024-01-13 16:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:50:36 --> Input Class Initialized
INFO - 2024-01-13 16:50:36 --> Language Class Initialized
INFO - 2024-01-13 16:50:36 --> Loader Class Initialized
INFO - 2024-01-13 16:50:36 --> Helper loaded: url_helper
INFO - 2024-01-13 16:50:36 --> Helper loaded: file_helper
INFO - 2024-01-13 16:50:36 --> Helper loaded: html_helper
INFO - 2024-01-13 16:50:36 --> Helper loaded: text_helper
INFO - 2024-01-13 16:50:36 --> Helper loaded: form_helper
INFO - 2024-01-13 16:50:36 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:50:36 --> Helper loaded: security_helper
INFO - 2024-01-13 16:50:36 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:50:36 --> Database Driver Class Initialized
INFO - 2024-01-13 16:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:50:36 --> Parser Class Initialized
INFO - 2024-01-13 16:50:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:50:36 --> Pagination Class Initialized
INFO - 2024-01-13 16:50:36 --> Form Validation Class Initialized
INFO - 2024-01-13 16:50:36 --> Controller Class Initialized
INFO - 2024-01-13 16:50:36 --> Model Class Initialized
DEBUG - 2024-01-13 16:50:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:50:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:50:36 --> Model Class Initialized
DEBUG - 2024-01-13 16:50:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:50:36 --> Model Class Initialized
INFO - 2024-01-13 16:50:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-13 16:50:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:50:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-13 16:50:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-13 16:50:36 --> Model Class Initialized
INFO - 2024-01-13 16:50:36 --> Model Class Initialized
INFO - 2024-01-13 16:50:36 --> Model Class Initialized
INFO - 2024-01-13 16:50:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-13 16:50:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-13 16:50:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-13 16:50:36 --> Final output sent to browser
DEBUG - 2024-01-13 16:50:36 --> Total execution time: 0.2093
ERROR - 2024-01-13 16:50:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:50:37 --> Config Class Initialized
INFO - 2024-01-13 16:50:37 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:50:37 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:50:37 --> Utf8 Class Initialized
INFO - 2024-01-13 16:50:37 --> URI Class Initialized
INFO - 2024-01-13 16:50:37 --> Router Class Initialized
INFO - 2024-01-13 16:50:37 --> Output Class Initialized
INFO - 2024-01-13 16:50:37 --> Security Class Initialized
DEBUG - 2024-01-13 16:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:50:37 --> Input Class Initialized
INFO - 2024-01-13 16:50:37 --> Language Class Initialized
INFO - 2024-01-13 16:50:37 --> Loader Class Initialized
INFO - 2024-01-13 16:50:37 --> Helper loaded: url_helper
INFO - 2024-01-13 16:50:37 --> Helper loaded: file_helper
INFO - 2024-01-13 16:50:37 --> Helper loaded: html_helper
INFO - 2024-01-13 16:50:37 --> Helper loaded: text_helper
INFO - 2024-01-13 16:50:37 --> Helper loaded: form_helper
INFO - 2024-01-13 16:50:37 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:50:37 --> Helper loaded: security_helper
INFO - 2024-01-13 16:50:37 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:50:37 --> Database Driver Class Initialized
INFO - 2024-01-13 16:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:50:37 --> Parser Class Initialized
INFO - 2024-01-13 16:50:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:50:37 --> Pagination Class Initialized
INFO - 2024-01-13 16:50:37 --> Form Validation Class Initialized
INFO - 2024-01-13 16:50:37 --> Controller Class Initialized
INFO - 2024-01-13 16:50:37 --> Model Class Initialized
DEBUG - 2024-01-13 16:50:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:50:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:50:37 --> Model Class Initialized
DEBUG - 2024-01-13 16:50:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:50:37 --> Model Class Initialized
INFO - 2024-01-13 16:50:37 --> Final output sent to browser
DEBUG - 2024-01-13 16:50:37 --> Total execution time: 0.0565
ERROR - 2024-01-13 16:51:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:51:22 --> Config Class Initialized
INFO - 2024-01-13 16:51:22 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:51:22 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:51:22 --> Utf8 Class Initialized
INFO - 2024-01-13 16:51:22 --> URI Class Initialized
INFO - 2024-01-13 16:51:22 --> Router Class Initialized
INFO - 2024-01-13 16:51:22 --> Output Class Initialized
INFO - 2024-01-13 16:51:22 --> Security Class Initialized
DEBUG - 2024-01-13 16:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:51:22 --> Input Class Initialized
INFO - 2024-01-13 16:51:22 --> Language Class Initialized
INFO - 2024-01-13 16:51:22 --> Loader Class Initialized
INFO - 2024-01-13 16:51:22 --> Helper loaded: url_helper
INFO - 2024-01-13 16:51:22 --> Helper loaded: file_helper
INFO - 2024-01-13 16:51:22 --> Helper loaded: html_helper
INFO - 2024-01-13 16:51:22 --> Helper loaded: text_helper
INFO - 2024-01-13 16:51:22 --> Helper loaded: form_helper
INFO - 2024-01-13 16:51:22 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:51:22 --> Helper loaded: security_helper
INFO - 2024-01-13 16:51:22 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:51:22 --> Database Driver Class Initialized
INFO - 2024-01-13 16:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:51:22 --> Parser Class Initialized
INFO - 2024-01-13 16:51:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:51:22 --> Pagination Class Initialized
INFO - 2024-01-13 16:51:22 --> Form Validation Class Initialized
INFO - 2024-01-13 16:51:22 --> Controller Class Initialized
INFO - 2024-01-13 16:51:22 --> Model Class Initialized
DEBUG - 2024-01-13 16:51:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:51:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:51:22 --> Model Class Initialized
DEBUG - 2024-01-13 16:51:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:51:22 --> Model Class Initialized
INFO - 2024-01-13 16:51:23 --> Final output sent to browser
DEBUG - 2024-01-13 16:51:23 --> Total execution time: 1.0041
ERROR - 2024-01-13 16:55:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:55:34 --> Config Class Initialized
INFO - 2024-01-13 16:55:34 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:55:34 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:55:34 --> Utf8 Class Initialized
INFO - 2024-01-13 16:55:34 --> URI Class Initialized
INFO - 2024-01-13 16:55:34 --> Router Class Initialized
INFO - 2024-01-13 16:55:34 --> Output Class Initialized
INFO - 2024-01-13 16:55:34 --> Security Class Initialized
DEBUG - 2024-01-13 16:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:55:34 --> Input Class Initialized
INFO - 2024-01-13 16:55:34 --> Language Class Initialized
INFO - 2024-01-13 16:55:34 --> Loader Class Initialized
INFO - 2024-01-13 16:55:34 --> Helper loaded: url_helper
INFO - 2024-01-13 16:55:34 --> Helper loaded: file_helper
INFO - 2024-01-13 16:55:34 --> Helper loaded: html_helper
INFO - 2024-01-13 16:55:34 --> Helper loaded: text_helper
INFO - 2024-01-13 16:55:34 --> Helper loaded: form_helper
INFO - 2024-01-13 16:55:34 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:55:34 --> Helper loaded: security_helper
INFO - 2024-01-13 16:55:34 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:55:34 --> Database Driver Class Initialized
INFO - 2024-01-13 16:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:55:34 --> Parser Class Initialized
INFO - 2024-01-13 16:55:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:55:34 --> Pagination Class Initialized
INFO - 2024-01-13 16:55:34 --> Form Validation Class Initialized
INFO - 2024-01-13 16:55:34 --> Controller Class Initialized
DEBUG - 2024-01-13 16:55:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:55:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:55:34 --> Model Class Initialized
DEBUG - 2024-01-13 16:55:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:55:34 --> Model Class Initialized
DEBUG - 2024-01-13 16:55:34 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:55:34 --> Model Class Initialized
INFO - 2024-01-13 16:55:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-01-13 16:55:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:55:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-13 16:55:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-13 16:55:34 --> Model Class Initialized
INFO - 2024-01-13 16:55:34 --> Model Class Initialized
INFO - 2024-01-13 16:55:34 --> Model Class Initialized
INFO - 2024-01-13 16:55:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-13 16:55:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-13 16:55:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-13 16:55:34 --> Final output sent to browser
DEBUG - 2024-01-13 16:55:34 --> Total execution time: 0.2220
ERROR - 2024-01-13 16:55:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:55:35 --> Config Class Initialized
INFO - 2024-01-13 16:55:35 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:55:35 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:55:35 --> Utf8 Class Initialized
INFO - 2024-01-13 16:55:35 --> URI Class Initialized
INFO - 2024-01-13 16:55:35 --> Router Class Initialized
INFO - 2024-01-13 16:55:35 --> Output Class Initialized
INFO - 2024-01-13 16:55:35 --> Security Class Initialized
DEBUG - 2024-01-13 16:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:55:35 --> Input Class Initialized
INFO - 2024-01-13 16:55:35 --> Language Class Initialized
INFO - 2024-01-13 16:55:35 --> Loader Class Initialized
INFO - 2024-01-13 16:55:35 --> Helper loaded: url_helper
INFO - 2024-01-13 16:55:35 --> Helper loaded: file_helper
INFO - 2024-01-13 16:55:35 --> Helper loaded: html_helper
INFO - 2024-01-13 16:55:35 --> Helper loaded: text_helper
INFO - 2024-01-13 16:55:35 --> Helper loaded: form_helper
INFO - 2024-01-13 16:55:35 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:55:35 --> Helper loaded: security_helper
INFO - 2024-01-13 16:55:35 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:55:35 --> Database Driver Class Initialized
INFO - 2024-01-13 16:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:55:35 --> Parser Class Initialized
INFO - 2024-01-13 16:55:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:55:35 --> Pagination Class Initialized
INFO - 2024-01-13 16:55:35 --> Form Validation Class Initialized
INFO - 2024-01-13 16:55:35 --> Controller Class Initialized
DEBUG - 2024-01-13 16:55:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:55:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:55:35 --> Model Class Initialized
DEBUG - 2024-01-13 16:55:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:55:35 --> Model Class Initialized
INFO - 2024-01-13 16:55:35 --> Final output sent to browser
DEBUG - 2024-01-13 16:55:35 --> Total execution time: 0.0365
ERROR - 2024-01-13 16:55:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:55:54 --> Config Class Initialized
INFO - 2024-01-13 16:55:54 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:55:54 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:55:54 --> Utf8 Class Initialized
INFO - 2024-01-13 16:55:54 --> URI Class Initialized
INFO - 2024-01-13 16:55:54 --> Router Class Initialized
INFO - 2024-01-13 16:55:54 --> Output Class Initialized
INFO - 2024-01-13 16:55:54 --> Security Class Initialized
DEBUG - 2024-01-13 16:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:55:54 --> Input Class Initialized
INFO - 2024-01-13 16:55:54 --> Language Class Initialized
INFO - 2024-01-13 16:55:54 --> Loader Class Initialized
INFO - 2024-01-13 16:55:54 --> Helper loaded: url_helper
INFO - 2024-01-13 16:55:54 --> Helper loaded: file_helper
INFO - 2024-01-13 16:55:54 --> Helper loaded: html_helper
INFO - 2024-01-13 16:55:54 --> Helper loaded: text_helper
INFO - 2024-01-13 16:55:54 --> Helper loaded: form_helper
INFO - 2024-01-13 16:55:54 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:55:54 --> Helper loaded: security_helper
INFO - 2024-01-13 16:55:54 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:55:54 --> Database Driver Class Initialized
INFO - 2024-01-13 16:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:55:54 --> Parser Class Initialized
INFO - 2024-01-13 16:55:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:55:54 --> Pagination Class Initialized
INFO - 2024-01-13 16:55:54 --> Form Validation Class Initialized
INFO - 2024-01-13 16:55:54 --> Controller Class Initialized
DEBUG - 2024-01-13 16:55:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:55:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:55:54 --> Model Class Initialized
INFO - 2024-01-13 16:55:54 --> Model Class Initialized
DEBUG - 2024-01-13 16:55:54 --> Lmr class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:55:54 --> Model Class Initialized
INFO - 2024-01-13 16:55:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/mr/mr.php
DEBUG - 2024-01-13 16:55:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:55:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-13 16:55:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-13 16:55:54 --> Model Class Initialized
INFO - 2024-01-13 16:55:54 --> Model Class Initialized
INFO - 2024-01-13 16:55:54 --> Model Class Initialized
INFO - 2024-01-13 16:55:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-13 16:55:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-13 16:55:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-13 16:55:54 --> Final output sent to browser
DEBUG - 2024-01-13 16:55:54 --> Total execution time: 0.2082
ERROR - 2024-01-13 16:55:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:55:55 --> Config Class Initialized
INFO - 2024-01-13 16:55:55 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:55:55 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:55:55 --> Utf8 Class Initialized
INFO - 2024-01-13 16:55:55 --> URI Class Initialized
INFO - 2024-01-13 16:55:55 --> Router Class Initialized
INFO - 2024-01-13 16:55:55 --> Output Class Initialized
INFO - 2024-01-13 16:55:55 --> Security Class Initialized
DEBUG - 2024-01-13 16:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:55:55 --> Input Class Initialized
INFO - 2024-01-13 16:55:55 --> Language Class Initialized
INFO - 2024-01-13 16:55:55 --> Loader Class Initialized
INFO - 2024-01-13 16:55:55 --> Helper loaded: url_helper
INFO - 2024-01-13 16:55:55 --> Helper loaded: file_helper
INFO - 2024-01-13 16:55:55 --> Helper loaded: html_helper
INFO - 2024-01-13 16:55:55 --> Helper loaded: text_helper
INFO - 2024-01-13 16:55:55 --> Helper loaded: form_helper
INFO - 2024-01-13 16:55:55 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:55:55 --> Helper loaded: security_helper
INFO - 2024-01-13 16:55:55 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:55:55 --> Database Driver Class Initialized
INFO - 2024-01-13 16:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:55:55 --> Parser Class Initialized
INFO - 2024-01-13 16:55:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:55:55 --> Pagination Class Initialized
INFO - 2024-01-13 16:55:55 --> Form Validation Class Initialized
INFO - 2024-01-13 16:55:55 --> Controller Class Initialized
DEBUG - 2024-01-13 16:55:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:55:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:55:55 --> Model Class Initialized
INFO - 2024-01-13 16:55:55 --> Model Class Initialized
INFO - 2024-01-13 16:55:55 --> Final output sent to browser
DEBUG - 2024-01-13 16:55:55 --> Total execution time: 0.0241
ERROR - 2024-01-13 16:57:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:57:01 --> Config Class Initialized
INFO - 2024-01-13 16:57:01 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:57:01 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:57:01 --> Utf8 Class Initialized
INFO - 2024-01-13 16:57:01 --> URI Class Initialized
INFO - 2024-01-13 16:57:01 --> Router Class Initialized
INFO - 2024-01-13 16:57:01 --> Output Class Initialized
INFO - 2024-01-13 16:57:01 --> Security Class Initialized
DEBUG - 2024-01-13 16:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:57:01 --> Input Class Initialized
INFO - 2024-01-13 16:57:01 --> Language Class Initialized
INFO - 2024-01-13 16:57:01 --> Loader Class Initialized
INFO - 2024-01-13 16:57:01 --> Helper loaded: url_helper
INFO - 2024-01-13 16:57:01 --> Helper loaded: file_helper
INFO - 2024-01-13 16:57:01 --> Helper loaded: html_helper
INFO - 2024-01-13 16:57:01 --> Helper loaded: text_helper
INFO - 2024-01-13 16:57:01 --> Helper loaded: form_helper
INFO - 2024-01-13 16:57:01 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:57:01 --> Helper loaded: security_helper
INFO - 2024-01-13 16:57:01 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:57:01 --> Database Driver Class Initialized
INFO - 2024-01-13 16:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:57:01 --> Parser Class Initialized
INFO - 2024-01-13 16:57:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:57:01 --> Pagination Class Initialized
INFO - 2024-01-13 16:57:01 --> Form Validation Class Initialized
INFO - 2024-01-13 16:57:01 --> Controller Class Initialized
DEBUG - 2024-01-13 16:57:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:57:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:57:01 --> Model Class Initialized
INFO - 2024-01-13 16:57:01 --> Model Class Initialized
INFO - 2024-01-13 16:57:01 --> Final output sent to browser
DEBUG - 2024-01-13 16:57:01 --> Total execution time: 0.0237
ERROR - 2024-01-13 16:57:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:57:21 --> Config Class Initialized
INFO - 2024-01-13 16:57:21 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:57:21 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:57:21 --> Utf8 Class Initialized
INFO - 2024-01-13 16:57:21 --> URI Class Initialized
INFO - 2024-01-13 16:57:21 --> Router Class Initialized
INFO - 2024-01-13 16:57:21 --> Output Class Initialized
INFO - 2024-01-13 16:57:21 --> Security Class Initialized
DEBUG - 2024-01-13 16:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:57:21 --> Input Class Initialized
INFO - 2024-01-13 16:57:21 --> Language Class Initialized
INFO - 2024-01-13 16:57:21 --> Loader Class Initialized
INFO - 2024-01-13 16:57:21 --> Helper loaded: url_helper
INFO - 2024-01-13 16:57:21 --> Helper loaded: file_helper
INFO - 2024-01-13 16:57:21 --> Helper loaded: html_helper
INFO - 2024-01-13 16:57:21 --> Helper loaded: text_helper
INFO - 2024-01-13 16:57:21 --> Helper loaded: form_helper
INFO - 2024-01-13 16:57:21 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:57:21 --> Helper loaded: security_helper
INFO - 2024-01-13 16:57:21 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:57:21 --> Database Driver Class Initialized
INFO - 2024-01-13 16:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:57:21 --> Parser Class Initialized
INFO - 2024-01-13 16:57:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:57:21 --> Pagination Class Initialized
INFO - 2024-01-13 16:57:21 --> Form Validation Class Initialized
INFO - 2024-01-13 16:57:21 --> Controller Class Initialized
DEBUG - 2024-01-13 16:57:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:57:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:57:21 --> Model Class Initialized
INFO - 2024-01-13 16:57:21 --> Model Class Initialized
INFO - 2024-01-13 16:57:21 --> Final output sent to browser
DEBUG - 2024-01-13 16:57:21 --> Total execution time: 0.0245
ERROR - 2024-01-13 16:57:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:57:31 --> Config Class Initialized
INFO - 2024-01-13 16:57:31 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:57:31 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:57:31 --> Utf8 Class Initialized
INFO - 2024-01-13 16:57:31 --> URI Class Initialized
DEBUG - 2024-01-13 16:57:31 --> No URI present. Default controller set.
INFO - 2024-01-13 16:57:31 --> Router Class Initialized
INFO - 2024-01-13 16:57:31 --> Output Class Initialized
INFO - 2024-01-13 16:57:31 --> Security Class Initialized
DEBUG - 2024-01-13 16:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:57:31 --> Input Class Initialized
INFO - 2024-01-13 16:57:31 --> Language Class Initialized
INFO - 2024-01-13 16:57:31 --> Loader Class Initialized
INFO - 2024-01-13 16:57:31 --> Helper loaded: url_helper
INFO - 2024-01-13 16:57:31 --> Helper loaded: file_helper
INFO - 2024-01-13 16:57:31 --> Helper loaded: html_helper
INFO - 2024-01-13 16:57:31 --> Helper loaded: text_helper
INFO - 2024-01-13 16:57:31 --> Helper loaded: form_helper
INFO - 2024-01-13 16:57:31 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:57:31 --> Helper loaded: security_helper
INFO - 2024-01-13 16:57:31 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:57:31 --> Database Driver Class Initialized
INFO - 2024-01-13 16:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:57:31 --> Parser Class Initialized
INFO - 2024-01-13 16:57:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:57:31 --> Pagination Class Initialized
INFO - 2024-01-13 16:57:31 --> Form Validation Class Initialized
INFO - 2024-01-13 16:57:31 --> Controller Class Initialized
INFO - 2024-01-13 16:57:31 --> Model Class Initialized
DEBUG - 2024-01-13 16:57:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:57:31 --> Model Class Initialized
DEBUG - 2024-01-13 16:57:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:57:31 --> Model Class Initialized
INFO - 2024-01-13 16:57:31 --> Model Class Initialized
INFO - 2024-01-13 16:57:31 --> Model Class Initialized
INFO - 2024-01-13 16:57:31 --> Model Class Initialized
DEBUG - 2024-01-13 16:57:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:57:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:57:31 --> Model Class Initialized
INFO - 2024-01-13 16:57:31 --> Model Class Initialized
INFO - 2024-01-13 16:57:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-13 16:57:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:57:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-13 16:57:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-13 16:57:31 --> Model Class Initialized
INFO - 2024-01-13 16:57:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-13 16:57:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-13 16:57:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-13 16:57:31 --> Final output sent to browser
DEBUG - 2024-01-13 16:57:31 --> Total execution time: 0.4320
ERROR - 2024-01-13 16:57:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:57:53 --> Config Class Initialized
INFO - 2024-01-13 16:57:53 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:57:53 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:57:53 --> Utf8 Class Initialized
INFO - 2024-01-13 16:57:53 --> URI Class Initialized
INFO - 2024-01-13 16:57:53 --> Router Class Initialized
INFO - 2024-01-13 16:57:53 --> Output Class Initialized
INFO - 2024-01-13 16:57:53 --> Security Class Initialized
DEBUG - 2024-01-13 16:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:57:53 --> Input Class Initialized
INFO - 2024-01-13 16:57:53 --> Language Class Initialized
INFO - 2024-01-13 16:57:53 --> Loader Class Initialized
INFO - 2024-01-13 16:57:53 --> Helper loaded: url_helper
INFO - 2024-01-13 16:57:53 --> Helper loaded: file_helper
INFO - 2024-01-13 16:57:53 --> Helper loaded: html_helper
INFO - 2024-01-13 16:57:53 --> Helper loaded: text_helper
INFO - 2024-01-13 16:57:53 --> Helper loaded: form_helper
INFO - 2024-01-13 16:57:53 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:57:53 --> Helper loaded: security_helper
INFO - 2024-01-13 16:57:53 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:57:53 --> Database Driver Class Initialized
INFO - 2024-01-13 16:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:57:53 --> Parser Class Initialized
INFO - 2024-01-13 16:57:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:57:53 --> Pagination Class Initialized
INFO - 2024-01-13 16:57:53 --> Form Validation Class Initialized
INFO - 2024-01-13 16:57:53 --> Controller Class Initialized
INFO - 2024-01-13 16:57:53 --> Model Class Initialized
DEBUG - 2024-01-13 16:57:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:57:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:57:53 --> Model Class Initialized
DEBUG - 2024-01-13 16:57:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:57:53 --> Model Class Initialized
INFO - 2024-01-13 16:57:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-13 16:57:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:57:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-13 16:57:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-13 16:57:53 --> Model Class Initialized
INFO - 2024-01-13 16:57:53 --> Model Class Initialized
INFO - 2024-01-13 16:57:53 --> Model Class Initialized
INFO - 2024-01-13 16:57:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-13 16:57:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-13 16:57:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-13 16:57:53 --> Final output sent to browser
DEBUG - 2024-01-13 16:57:53 --> Total execution time: 0.2471
ERROR - 2024-01-13 16:57:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:57:54 --> Config Class Initialized
INFO - 2024-01-13 16:57:54 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:57:54 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:57:54 --> Utf8 Class Initialized
INFO - 2024-01-13 16:57:54 --> URI Class Initialized
INFO - 2024-01-13 16:57:54 --> Router Class Initialized
INFO - 2024-01-13 16:57:54 --> Output Class Initialized
INFO - 2024-01-13 16:57:54 --> Security Class Initialized
DEBUG - 2024-01-13 16:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:57:54 --> Input Class Initialized
INFO - 2024-01-13 16:57:54 --> Language Class Initialized
INFO - 2024-01-13 16:57:54 --> Loader Class Initialized
INFO - 2024-01-13 16:57:54 --> Helper loaded: url_helper
INFO - 2024-01-13 16:57:54 --> Helper loaded: file_helper
INFO - 2024-01-13 16:57:54 --> Helper loaded: html_helper
INFO - 2024-01-13 16:57:54 --> Helper loaded: text_helper
INFO - 2024-01-13 16:57:54 --> Helper loaded: form_helper
INFO - 2024-01-13 16:57:54 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:57:54 --> Helper loaded: security_helper
INFO - 2024-01-13 16:57:54 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:57:54 --> Database Driver Class Initialized
INFO - 2024-01-13 16:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:57:54 --> Parser Class Initialized
INFO - 2024-01-13 16:57:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:57:54 --> Pagination Class Initialized
INFO - 2024-01-13 16:57:54 --> Form Validation Class Initialized
INFO - 2024-01-13 16:57:54 --> Controller Class Initialized
INFO - 2024-01-13 16:57:54 --> Model Class Initialized
DEBUG - 2024-01-13 16:57:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:57:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:57:54 --> Model Class Initialized
DEBUG - 2024-01-13 16:57:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:57:54 --> Model Class Initialized
INFO - 2024-01-13 16:57:54 --> Final output sent to browser
DEBUG - 2024-01-13 16:57:54 --> Total execution time: 0.0633
ERROR - 2024-01-13 16:58:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:58:05 --> Config Class Initialized
INFO - 2024-01-13 16:58:05 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:58:05 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:58:05 --> Utf8 Class Initialized
INFO - 2024-01-13 16:58:05 --> URI Class Initialized
INFO - 2024-01-13 16:58:05 --> Router Class Initialized
INFO - 2024-01-13 16:58:05 --> Output Class Initialized
INFO - 2024-01-13 16:58:05 --> Security Class Initialized
DEBUG - 2024-01-13 16:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:58:05 --> Input Class Initialized
INFO - 2024-01-13 16:58:05 --> Language Class Initialized
INFO - 2024-01-13 16:58:05 --> Loader Class Initialized
INFO - 2024-01-13 16:58:05 --> Helper loaded: url_helper
INFO - 2024-01-13 16:58:05 --> Helper loaded: file_helper
INFO - 2024-01-13 16:58:05 --> Helper loaded: html_helper
INFO - 2024-01-13 16:58:05 --> Helper loaded: text_helper
INFO - 2024-01-13 16:58:05 --> Helper loaded: form_helper
INFO - 2024-01-13 16:58:05 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:58:05 --> Helper loaded: security_helper
INFO - 2024-01-13 16:58:05 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:58:05 --> Database Driver Class Initialized
INFO - 2024-01-13 16:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:58:05 --> Parser Class Initialized
INFO - 2024-01-13 16:58:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:58:05 --> Pagination Class Initialized
INFO - 2024-01-13 16:58:05 --> Form Validation Class Initialized
INFO - 2024-01-13 16:58:05 --> Controller Class Initialized
INFO - 2024-01-13 16:58:05 --> Model Class Initialized
DEBUG - 2024-01-13 16:58:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:58:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:58:05 --> Model Class Initialized
DEBUG - 2024-01-13 16:58:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:58:05 --> Model Class Initialized
INFO - 2024-01-13 16:58:05 --> Final output sent to browser
DEBUG - 2024-01-13 16:58:05 --> Total execution time: 0.0686
ERROR - 2024-01-13 16:58:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:58:11 --> Config Class Initialized
INFO - 2024-01-13 16:58:11 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:58:11 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:58:11 --> Utf8 Class Initialized
INFO - 2024-01-13 16:58:11 --> URI Class Initialized
INFO - 2024-01-13 16:58:11 --> Router Class Initialized
INFO - 2024-01-13 16:58:11 --> Output Class Initialized
INFO - 2024-01-13 16:58:11 --> Security Class Initialized
DEBUG - 2024-01-13 16:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:58:11 --> Input Class Initialized
INFO - 2024-01-13 16:58:11 --> Language Class Initialized
INFO - 2024-01-13 16:58:11 --> Loader Class Initialized
INFO - 2024-01-13 16:58:11 --> Helper loaded: url_helper
INFO - 2024-01-13 16:58:11 --> Helper loaded: file_helper
INFO - 2024-01-13 16:58:11 --> Helper loaded: html_helper
INFO - 2024-01-13 16:58:11 --> Helper loaded: text_helper
INFO - 2024-01-13 16:58:11 --> Helper loaded: form_helper
INFO - 2024-01-13 16:58:11 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:58:11 --> Helper loaded: security_helper
INFO - 2024-01-13 16:58:11 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:58:11 --> Database Driver Class Initialized
INFO - 2024-01-13 16:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:58:11 --> Parser Class Initialized
INFO - 2024-01-13 16:58:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:58:11 --> Pagination Class Initialized
INFO - 2024-01-13 16:58:11 --> Form Validation Class Initialized
INFO - 2024-01-13 16:58:11 --> Controller Class Initialized
INFO - 2024-01-13 16:58:11 --> Model Class Initialized
DEBUG - 2024-01-13 16:58:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:58:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:58:11 --> Model Class Initialized
DEBUG - 2024-01-13 16:58:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:58:11 --> Model Class Initialized
INFO - 2024-01-13 16:58:11 --> Final output sent to browser
DEBUG - 2024-01-13 16:58:11 --> Total execution time: 0.0902
ERROR - 2024-01-13 16:59:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:59:01 --> Config Class Initialized
INFO - 2024-01-13 16:59:01 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:59:01 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:59:01 --> Utf8 Class Initialized
INFO - 2024-01-13 16:59:01 --> URI Class Initialized
DEBUG - 2024-01-13 16:59:01 --> No URI present. Default controller set.
INFO - 2024-01-13 16:59:01 --> Router Class Initialized
INFO - 2024-01-13 16:59:01 --> Output Class Initialized
INFO - 2024-01-13 16:59:01 --> Security Class Initialized
DEBUG - 2024-01-13 16:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:59:01 --> Input Class Initialized
INFO - 2024-01-13 16:59:01 --> Language Class Initialized
INFO - 2024-01-13 16:59:01 --> Loader Class Initialized
INFO - 2024-01-13 16:59:01 --> Helper loaded: url_helper
INFO - 2024-01-13 16:59:01 --> Helper loaded: file_helper
INFO - 2024-01-13 16:59:01 --> Helper loaded: html_helper
INFO - 2024-01-13 16:59:01 --> Helper loaded: text_helper
INFO - 2024-01-13 16:59:01 --> Helper loaded: form_helper
INFO - 2024-01-13 16:59:01 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:59:01 --> Helper loaded: security_helper
INFO - 2024-01-13 16:59:01 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:59:01 --> Database Driver Class Initialized
INFO - 2024-01-13 16:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:59:01 --> Parser Class Initialized
INFO - 2024-01-13 16:59:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:59:01 --> Pagination Class Initialized
INFO - 2024-01-13 16:59:01 --> Form Validation Class Initialized
INFO - 2024-01-13 16:59:01 --> Controller Class Initialized
INFO - 2024-01-13 16:59:01 --> Model Class Initialized
DEBUG - 2024-01-13 16:59:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:59:01 --> Model Class Initialized
DEBUG - 2024-01-13 16:59:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:59:01 --> Model Class Initialized
INFO - 2024-01-13 16:59:01 --> Model Class Initialized
INFO - 2024-01-13 16:59:01 --> Model Class Initialized
INFO - 2024-01-13 16:59:01 --> Model Class Initialized
DEBUG - 2024-01-13 16:59:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:59:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:59:01 --> Model Class Initialized
INFO - 2024-01-13 16:59:01 --> Model Class Initialized
INFO - 2024-01-13 16:59:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-13 16:59:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:59:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-13 16:59:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-13 16:59:02 --> Model Class Initialized
INFO - 2024-01-13 16:59:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-13 16:59:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-13 16:59:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-13 16:59:02 --> Final output sent to browser
DEBUG - 2024-01-13 16:59:02 --> Total execution time: 0.4055
ERROR - 2024-01-13 16:59:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:59:36 --> Config Class Initialized
INFO - 2024-01-13 16:59:36 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:59:36 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:59:36 --> Utf8 Class Initialized
INFO - 2024-01-13 16:59:36 --> URI Class Initialized
INFO - 2024-01-13 16:59:36 --> Router Class Initialized
INFO - 2024-01-13 16:59:36 --> Output Class Initialized
INFO - 2024-01-13 16:59:36 --> Security Class Initialized
DEBUG - 2024-01-13 16:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:59:36 --> Input Class Initialized
INFO - 2024-01-13 16:59:36 --> Language Class Initialized
INFO - 2024-01-13 16:59:36 --> Loader Class Initialized
INFO - 2024-01-13 16:59:36 --> Helper loaded: url_helper
INFO - 2024-01-13 16:59:36 --> Helper loaded: file_helper
INFO - 2024-01-13 16:59:36 --> Helper loaded: html_helper
INFO - 2024-01-13 16:59:36 --> Helper loaded: text_helper
INFO - 2024-01-13 16:59:36 --> Helper loaded: form_helper
INFO - 2024-01-13 16:59:36 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:59:36 --> Helper loaded: security_helper
INFO - 2024-01-13 16:59:36 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:59:36 --> Database Driver Class Initialized
INFO - 2024-01-13 16:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:59:36 --> Parser Class Initialized
INFO - 2024-01-13 16:59:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:59:36 --> Pagination Class Initialized
INFO - 2024-01-13 16:59:36 --> Form Validation Class Initialized
INFO - 2024-01-13 16:59:36 --> Controller Class Initialized
DEBUG - 2024-01-13 16:59:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:59:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:59:36 --> Model Class Initialized
INFO - 2024-01-13 16:59:36 --> Model Class Initialized
DEBUG - 2024-01-13 16:59:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:59:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:59:36 --> Model Class Initialized
DEBUG - 2024-01-13 16:59:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:59:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gst/list.php
DEBUG - 2024-01-13 16:59:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:59:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-13 16:59:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-13 16:59:36 --> Model Class Initialized
INFO - 2024-01-13 16:59:36 --> Model Class Initialized
INFO - 2024-01-13 16:59:36 --> Model Class Initialized
INFO - 2024-01-13 16:59:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-13 16:59:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-13 16:59:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-13 16:59:37 --> Final output sent to browser
DEBUG - 2024-01-13 16:59:37 --> Total execution time: 0.2077
ERROR - 2024-01-13 16:59:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 16:59:44 --> Config Class Initialized
INFO - 2024-01-13 16:59:44 --> Hooks Class Initialized
DEBUG - 2024-01-13 16:59:44 --> UTF-8 Support Enabled
INFO - 2024-01-13 16:59:44 --> Utf8 Class Initialized
INFO - 2024-01-13 16:59:44 --> URI Class Initialized
DEBUG - 2024-01-13 16:59:44 --> No URI present. Default controller set.
INFO - 2024-01-13 16:59:44 --> Router Class Initialized
INFO - 2024-01-13 16:59:44 --> Output Class Initialized
INFO - 2024-01-13 16:59:44 --> Security Class Initialized
DEBUG - 2024-01-13 16:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 16:59:44 --> Input Class Initialized
INFO - 2024-01-13 16:59:44 --> Language Class Initialized
INFO - 2024-01-13 16:59:44 --> Loader Class Initialized
INFO - 2024-01-13 16:59:44 --> Helper loaded: url_helper
INFO - 2024-01-13 16:59:44 --> Helper loaded: file_helper
INFO - 2024-01-13 16:59:44 --> Helper loaded: html_helper
INFO - 2024-01-13 16:59:44 --> Helper loaded: text_helper
INFO - 2024-01-13 16:59:44 --> Helper loaded: form_helper
INFO - 2024-01-13 16:59:44 --> Helper loaded: lang_helper
INFO - 2024-01-13 16:59:44 --> Helper loaded: security_helper
INFO - 2024-01-13 16:59:44 --> Helper loaded: cookie_helper
INFO - 2024-01-13 16:59:44 --> Database Driver Class Initialized
INFO - 2024-01-13 16:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-13 16:59:44 --> Parser Class Initialized
INFO - 2024-01-13 16:59:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-13 16:59:44 --> Pagination Class Initialized
INFO - 2024-01-13 16:59:44 --> Form Validation Class Initialized
INFO - 2024-01-13 16:59:44 --> Controller Class Initialized
INFO - 2024-01-13 16:59:44 --> Model Class Initialized
DEBUG - 2024-01-13 16:59:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:59:44 --> Model Class Initialized
DEBUG - 2024-01-13 16:59:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:59:44 --> Model Class Initialized
INFO - 2024-01-13 16:59:44 --> Model Class Initialized
INFO - 2024-01-13 16:59:44 --> Model Class Initialized
INFO - 2024-01-13 16:59:44 --> Model Class Initialized
DEBUG - 2024-01-13 16:59:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-13 16:59:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:59:44 --> Model Class Initialized
INFO - 2024-01-13 16:59:44 --> Model Class Initialized
INFO - 2024-01-13 16:59:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-13 16:59:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-13 16:59:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-13 16:59:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-13 16:59:45 --> Model Class Initialized
INFO - 2024-01-13 16:59:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-13 16:59:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-13 16:59:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-13 16:59:45 --> Final output sent to browser
DEBUG - 2024-01-13 16:59:45 --> Total execution time: 0.4096
ERROR - 2024-01-13 23:55:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-13 23:55:50 --> Config Class Initialized
INFO - 2024-01-13 23:55:50 --> Hooks Class Initialized
DEBUG - 2024-01-13 23:55:50 --> UTF-8 Support Enabled
INFO - 2024-01-13 23:55:50 --> Utf8 Class Initialized
INFO - 2024-01-13 23:55:50 --> URI Class Initialized
INFO - 2024-01-13 23:55:50 --> Router Class Initialized
INFO - 2024-01-13 23:55:50 --> Output Class Initialized
INFO - 2024-01-13 23:55:50 --> Security Class Initialized
DEBUG - 2024-01-13 23:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-13 23:55:50 --> Input Class Initialized
INFO - 2024-01-13 23:55:50 --> Language Class Initialized
ERROR - 2024-01-13 23:55:50 --> 404 Page Not Found: Well-known/assetlinks.json
