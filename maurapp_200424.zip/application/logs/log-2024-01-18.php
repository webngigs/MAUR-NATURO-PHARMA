<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-18 00:27:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 00:27:27 --> Config Class Initialized
INFO - 2024-01-18 00:27:27 --> Hooks Class Initialized
DEBUG - 2024-01-18 00:27:27 --> UTF-8 Support Enabled
INFO - 2024-01-18 00:27:27 --> Utf8 Class Initialized
INFO - 2024-01-18 00:27:27 --> URI Class Initialized
INFO - 2024-01-18 00:27:27 --> Router Class Initialized
INFO - 2024-01-18 00:27:27 --> Output Class Initialized
INFO - 2024-01-18 00:27:27 --> Security Class Initialized
DEBUG - 2024-01-18 00:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 00:27:27 --> Input Class Initialized
INFO - 2024-01-18 00:27:27 --> Language Class Initialized
ERROR - 2024-01-18 00:27:27 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-01-18 06:42:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 06:42:26 --> Config Class Initialized
INFO - 2024-01-18 06:42:26 --> Hooks Class Initialized
DEBUG - 2024-01-18 06:42:26 --> UTF-8 Support Enabled
INFO - 2024-01-18 06:42:26 --> Utf8 Class Initialized
INFO - 2024-01-18 06:42:26 --> URI Class Initialized
DEBUG - 2024-01-18 06:42:26 --> No URI present. Default controller set.
INFO - 2024-01-18 06:42:26 --> Router Class Initialized
INFO - 2024-01-18 06:42:26 --> Output Class Initialized
INFO - 2024-01-18 06:42:26 --> Security Class Initialized
DEBUG - 2024-01-18 06:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 06:42:26 --> Input Class Initialized
INFO - 2024-01-18 06:42:26 --> Language Class Initialized
INFO - 2024-01-18 06:42:26 --> Loader Class Initialized
INFO - 2024-01-18 06:42:26 --> Helper loaded: url_helper
INFO - 2024-01-18 06:42:26 --> Helper loaded: file_helper
INFO - 2024-01-18 06:42:26 --> Helper loaded: html_helper
INFO - 2024-01-18 06:42:26 --> Helper loaded: text_helper
INFO - 2024-01-18 06:42:26 --> Helper loaded: form_helper
INFO - 2024-01-18 06:42:26 --> Helper loaded: lang_helper
INFO - 2024-01-18 06:42:26 --> Helper loaded: security_helper
INFO - 2024-01-18 06:42:26 --> Helper loaded: cookie_helper
INFO - 2024-01-18 06:42:26 --> Database Driver Class Initialized
INFO - 2024-01-18 06:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 06:42:26 --> Parser Class Initialized
INFO - 2024-01-18 06:42:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 06:42:26 --> Pagination Class Initialized
INFO - 2024-01-18 06:42:26 --> Form Validation Class Initialized
INFO - 2024-01-18 06:42:26 --> Controller Class Initialized
INFO - 2024-01-18 06:42:26 --> Model Class Initialized
DEBUG - 2024-01-18 06:42:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-18 06:42:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 06:42:26 --> Config Class Initialized
INFO - 2024-01-18 06:42:26 --> Hooks Class Initialized
DEBUG - 2024-01-18 06:42:26 --> UTF-8 Support Enabled
INFO - 2024-01-18 06:42:26 --> Utf8 Class Initialized
INFO - 2024-01-18 06:42:26 --> URI Class Initialized
INFO - 2024-01-18 06:42:26 --> Router Class Initialized
INFO - 2024-01-18 06:42:26 --> Output Class Initialized
INFO - 2024-01-18 06:42:26 --> Security Class Initialized
DEBUG - 2024-01-18 06:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 06:42:26 --> Input Class Initialized
INFO - 2024-01-18 06:42:26 --> Language Class Initialized
INFO - 2024-01-18 06:42:26 --> Loader Class Initialized
INFO - 2024-01-18 06:42:26 --> Helper loaded: url_helper
INFO - 2024-01-18 06:42:26 --> Helper loaded: file_helper
INFO - 2024-01-18 06:42:26 --> Helper loaded: html_helper
INFO - 2024-01-18 06:42:26 --> Helper loaded: text_helper
INFO - 2024-01-18 06:42:26 --> Helper loaded: form_helper
INFO - 2024-01-18 06:42:26 --> Helper loaded: lang_helper
INFO - 2024-01-18 06:42:26 --> Helper loaded: security_helper
INFO - 2024-01-18 06:42:26 --> Helper loaded: cookie_helper
INFO - 2024-01-18 06:42:26 --> Database Driver Class Initialized
INFO - 2024-01-18 06:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 06:42:26 --> Parser Class Initialized
INFO - 2024-01-18 06:42:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 06:42:26 --> Pagination Class Initialized
INFO - 2024-01-18 06:42:26 --> Form Validation Class Initialized
INFO - 2024-01-18 06:42:26 --> Controller Class Initialized
INFO - 2024-01-18 06:42:26 --> Model Class Initialized
DEBUG - 2024-01-18 06:42:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 06:42:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-18 06:42:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 06:42:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 06:42:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 06:42:26 --> Model Class Initialized
INFO - 2024-01-18 06:42:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 06:42:26 --> Final output sent to browser
DEBUG - 2024-01-18 06:42:26 --> Total execution time: 0.0335
ERROR - 2024-01-18 06:42:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 06:42:44 --> Config Class Initialized
INFO - 2024-01-18 06:42:44 --> Hooks Class Initialized
DEBUG - 2024-01-18 06:42:44 --> UTF-8 Support Enabled
INFO - 2024-01-18 06:42:44 --> Utf8 Class Initialized
INFO - 2024-01-18 06:42:44 --> URI Class Initialized
INFO - 2024-01-18 06:42:44 --> Router Class Initialized
INFO - 2024-01-18 06:42:44 --> Output Class Initialized
INFO - 2024-01-18 06:42:44 --> Security Class Initialized
DEBUG - 2024-01-18 06:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 06:42:44 --> Input Class Initialized
INFO - 2024-01-18 06:42:44 --> Language Class Initialized
INFO - 2024-01-18 06:42:44 --> Loader Class Initialized
INFO - 2024-01-18 06:42:44 --> Helper loaded: url_helper
INFO - 2024-01-18 06:42:44 --> Helper loaded: file_helper
INFO - 2024-01-18 06:42:44 --> Helper loaded: html_helper
INFO - 2024-01-18 06:42:44 --> Helper loaded: text_helper
INFO - 2024-01-18 06:42:44 --> Helper loaded: form_helper
INFO - 2024-01-18 06:42:44 --> Helper loaded: lang_helper
INFO - 2024-01-18 06:42:44 --> Helper loaded: security_helper
INFO - 2024-01-18 06:42:44 --> Helper loaded: cookie_helper
INFO - 2024-01-18 06:42:44 --> Database Driver Class Initialized
INFO - 2024-01-18 06:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 06:42:44 --> Parser Class Initialized
INFO - 2024-01-18 06:42:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 06:42:44 --> Pagination Class Initialized
INFO - 2024-01-18 06:42:44 --> Form Validation Class Initialized
INFO - 2024-01-18 06:42:44 --> Controller Class Initialized
INFO - 2024-01-18 06:42:44 --> Model Class Initialized
DEBUG - 2024-01-18 06:42:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 06:42:44 --> Model Class Initialized
INFO - 2024-01-18 06:42:44 --> Final output sent to browser
DEBUG - 2024-01-18 06:42:44 --> Total execution time: 0.0206
ERROR - 2024-01-18 06:42:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 06:42:44 --> Config Class Initialized
INFO - 2024-01-18 06:42:44 --> Hooks Class Initialized
DEBUG - 2024-01-18 06:42:44 --> UTF-8 Support Enabled
INFO - 2024-01-18 06:42:44 --> Utf8 Class Initialized
INFO - 2024-01-18 06:42:44 --> URI Class Initialized
DEBUG - 2024-01-18 06:42:44 --> No URI present. Default controller set.
INFO - 2024-01-18 06:42:44 --> Router Class Initialized
INFO - 2024-01-18 06:42:44 --> Output Class Initialized
INFO - 2024-01-18 06:42:44 --> Security Class Initialized
DEBUG - 2024-01-18 06:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 06:42:44 --> Input Class Initialized
INFO - 2024-01-18 06:42:44 --> Language Class Initialized
INFO - 2024-01-18 06:42:44 --> Loader Class Initialized
INFO - 2024-01-18 06:42:44 --> Helper loaded: url_helper
INFO - 2024-01-18 06:42:44 --> Helper loaded: file_helper
INFO - 2024-01-18 06:42:44 --> Helper loaded: html_helper
INFO - 2024-01-18 06:42:44 --> Helper loaded: text_helper
INFO - 2024-01-18 06:42:44 --> Helper loaded: form_helper
INFO - 2024-01-18 06:42:44 --> Helper loaded: lang_helper
INFO - 2024-01-18 06:42:44 --> Helper loaded: security_helper
INFO - 2024-01-18 06:42:44 --> Helper loaded: cookie_helper
INFO - 2024-01-18 06:42:44 --> Database Driver Class Initialized
INFO - 2024-01-18 06:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 06:42:44 --> Parser Class Initialized
INFO - 2024-01-18 06:42:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 06:42:44 --> Pagination Class Initialized
INFO - 2024-01-18 06:42:44 --> Form Validation Class Initialized
INFO - 2024-01-18 06:42:44 --> Controller Class Initialized
INFO - 2024-01-18 06:42:44 --> Model Class Initialized
DEBUG - 2024-01-18 06:42:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 06:42:44 --> Model Class Initialized
DEBUG - 2024-01-18 06:42:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 06:42:44 --> Model Class Initialized
INFO - 2024-01-18 06:42:44 --> Model Class Initialized
INFO - 2024-01-18 06:42:44 --> Model Class Initialized
INFO - 2024-01-18 06:42:44 --> Model Class Initialized
DEBUG - 2024-01-18 06:42:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 06:42:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 06:42:44 --> Model Class Initialized
INFO - 2024-01-18 06:42:44 --> Model Class Initialized
INFO - 2024-01-18 06:42:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-18 06:42:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 06:42:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 06:42:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 06:42:45 --> Model Class Initialized
INFO - 2024-01-18 06:42:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 06:42:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 06:42:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 06:42:45 --> Final output sent to browser
DEBUG - 2024-01-18 06:42:45 --> Total execution time: 0.2350
ERROR - 2024-01-18 06:43:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 06:43:07 --> Config Class Initialized
INFO - 2024-01-18 06:43:07 --> Hooks Class Initialized
DEBUG - 2024-01-18 06:43:07 --> UTF-8 Support Enabled
INFO - 2024-01-18 06:43:07 --> Utf8 Class Initialized
INFO - 2024-01-18 06:43:07 --> URI Class Initialized
INFO - 2024-01-18 06:43:07 --> Router Class Initialized
INFO - 2024-01-18 06:43:07 --> Output Class Initialized
INFO - 2024-01-18 06:43:07 --> Security Class Initialized
DEBUG - 2024-01-18 06:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 06:43:07 --> Input Class Initialized
INFO - 2024-01-18 06:43:07 --> Language Class Initialized
INFO - 2024-01-18 06:43:07 --> Loader Class Initialized
INFO - 2024-01-18 06:43:07 --> Helper loaded: url_helper
INFO - 2024-01-18 06:43:07 --> Helper loaded: file_helper
INFO - 2024-01-18 06:43:07 --> Helper loaded: html_helper
INFO - 2024-01-18 06:43:07 --> Helper loaded: text_helper
INFO - 2024-01-18 06:43:07 --> Helper loaded: form_helper
INFO - 2024-01-18 06:43:07 --> Helper loaded: lang_helper
INFO - 2024-01-18 06:43:07 --> Helper loaded: security_helper
INFO - 2024-01-18 06:43:07 --> Helper loaded: cookie_helper
INFO - 2024-01-18 06:43:07 --> Database Driver Class Initialized
INFO - 2024-01-18 06:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 06:43:07 --> Parser Class Initialized
INFO - 2024-01-18 06:43:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 06:43:07 --> Pagination Class Initialized
INFO - 2024-01-18 06:43:07 --> Form Validation Class Initialized
INFO - 2024-01-18 06:43:07 --> Controller Class Initialized
INFO - 2024-01-18 06:43:07 --> Model Class Initialized
DEBUG - 2024-01-18 06:43:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 06:43:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 06:43:07 --> Model Class Initialized
DEBUG - 2024-01-18 06:43:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 06:43:07 --> Model Class Initialized
INFO - 2024-01-18 06:43:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-18 06:43:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 06:43:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 06:43:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 06:43:07 --> Model Class Initialized
INFO - 2024-01-18 06:43:07 --> Model Class Initialized
INFO - 2024-01-18 06:43:07 --> Model Class Initialized
INFO - 2024-01-18 06:43:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 06:43:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 06:43:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 06:43:07 --> Final output sent to browser
DEBUG - 2024-01-18 06:43:07 --> Total execution time: 0.1491
ERROR - 2024-01-18 06:43:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 06:43:07 --> Config Class Initialized
INFO - 2024-01-18 06:43:07 --> Hooks Class Initialized
DEBUG - 2024-01-18 06:43:08 --> UTF-8 Support Enabled
INFO - 2024-01-18 06:43:08 --> Utf8 Class Initialized
INFO - 2024-01-18 06:43:08 --> URI Class Initialized
INFO - 2024-01-18 06:43:08 --> Router Class Initialized
INFO - 2024-01-18 06:43:08 --> Output Class Initialized
INFO - 2024-01-18 06:43:08 --> Security Class Initialized
DEBUG - 2024-01-18 06:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 06:43:08 --> Input Class Initialized
INFO - 2024-01-18 06:43:08 --> Language Class Initialized
INFO - 2024-01-18 06:43:08 --> Loader Class Initialized
INFO - 2024-01-18 06:43:08 --> Helper loaded: url_helper
INFO - 2024-01-18 06:43:08 --> Helper loaded: file_helper
INFO - 2024-01-18 06:43:08 --> Helper loaded: html_helper
INFO - 2024-01-18 06:43:08 --> Helper loaded: text_helper
INFO - 2024-01-18 06:43:08 --> Helper loaded: form_helper
INFO - 2024-01-18 06:43:08 --> Helper loaded: lang_helper
INFO - 2024-01-18 06:43:08 --> Helper loaded: security_helper
INFO - 2024-01-18 06:43:08 --> Helper loaded: cookie_helper
INFO - 2024-01-18 06:43:08 --> Database Driver Class Initialized
INFO - 2024-01-18 06:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 06:43:08 --> Parser Class Initialized
INFO - 2024-01-18 06:43:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 06:43:08 --> Pagination Class Initialized
INFO - 2024-01-18 06:43:08 --> Form Validation Class Initialized
INFO - 2024-01-18 06:43:08 --> Controller Class Initialized
INFO - 2024-01-18 06:43:08 --> Model Class Initialized
DEBUG - 2024-01-18 06:43:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 06:43:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 06:43:08 --> Model Class Initialized
DEBUG - 2024-01-18 06:43:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 06:43:08 --> Model Class Initialized
INFO - 2024-01-18 06:43:08 --> Final output sent to browser
DEBUG - 2024-01-18 06:43:08 --> Total execution time: 0.0528
ERROR - 2024-01-18 06:43:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 06:43:15 --> Config Class Initialized
INFO - 2024-01-18 06:43:15 --> Hooks Class Initialized
DEBUG - 2024-01-18 06:43:15 --> UTF-8 Support Enabled
INFO - 2024-01-18 06:43:15 --> Utf8 Class Initialized
INFO - 2024-01-18 06:43:15 --> URI Class Initialized
INFO - 2024-01-18 06:43:15 --> Router Class Initialized
INFO - 2024-01-18 06:43:15 --> Output Class Initialized
INFO - 2024-01-18 06:43:15 --> Security Class Initialized
DEBUG - 2024-01-18 06:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 06:43:15 --> Input Class Initialized
INFO - 2024-01-18 06:43:15 --> Language Class Initialized
INFO - 2024-01-18 06:43:15 --> Loader Class Initialized
INFO - 2024-01-18 06:43:15 --> Helper loaded: url_helper
INFO - 2024-01-18 06:43:15 --> Helper loaded: file_helper
INFO - 2024-01-18 06:43:15 --> Helper loaded: html_helper
INFO - 2024-01-18 06:43:15 --> Helper loaded: text_helper
INFO - 2024-01-18 06:43:15 --> Helper loaded: form_helper
INFO - 2024-01-18 06:43:15 --> Helper loaded: lang_helper
INFO - 2024-01-18 06:43:15 --> Helper loaded: security_helper
INFO - 2024-01-18 06:43:15 --> Helper loaded: cookie_helper
INFO - 2024-01-18 06:43:15 --> Database Driver Class Initialized
INFO - 2024-01-18 06:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 06:43:15 --> Parser Class Initialized
INFO - 2024-01-18 06:43:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 06:43:15 --> Pagination Class Initialized
INFO - 2024-01-18 06:43:15 --> Form Validation Class Initialized
INFO - 2024-01-18 06:43:15 --> Controller Class Initialized
INFO - 2024-01-18 06:43:15 --> Model Class Initialized
DEBUG - 2024-01-18 06:43:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 06:43:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 06:43:15 --> Model Class Initialized
DEBUG - 2024-01-18 06:43:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 06:43:15 --> Model Class Initialized
INFO - 2024-01-18 06:43:16 --> Final output sent to browser
DEBUG - 2024-01-18 06:43:16 --> Total execution time: 0.0435
ERROR - 2024-01-18 06:43:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 06:43:32 --> Config Class Initialized
INFO - 2024-01-18 06:43:32 --> Hooks Class Initialized
DEBUG - 2024-01-18 06:43:32 --> UTF-8 Support Enabled
INFO - 2024-01-18 06:43:32 --> Utf8 Class Initialized
INFO - 2024-01-18 06:43:32 --> URI Class Initialized
INFO - 2024-01-18 06:43:32 --> Router Class Initialized
INFO - 2024-01-18 06:43:32 --> Output Class Initialized
INFO - 2024-01-18 06:43:32 --> Security Class Initialized
DEBUG - 2024-01-18 06:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 06:43:32 --> Input Class Initialized
INFO - 2024-01-18 06:43:32 --> Language Class Initialized
INFO - 2024-01-18 06:43:32 --> Loader Class Initialized
INFO - 2024-01-18 06:43:32 --> Helper loaded: url_helper
INFO - 2024-01-18 06:43:32 --> Helper loaded: file_helper
INFO - 2024-01-18 06:43:32 --> Helper loaded: html_helper
INFO - 2024-01-18 06:43:32 --> Helper loaded: text_helper
INFO - 2024-01-18 06:43:32 --> Helper loaded: form_helper
INFO - 2024-01-18 06:43:32 --> Helper loaded: lang_helper
INFO - 2024-01-18 06:43:32 --> Helper loaded: security_helper
INFO - 2024-01-18 06:43:32 --> Helper loaded: cookie_helper
INFO - 2024-01-18 06:43:32 --> Database Driver Class Initialized
INFO - 2024-01-18 06:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 06:43:32 --> Parser Class Initialized
INFO - 2024-01-18 06:43:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 06:43:32 --> Pagination Class Initialized
INFO - 2024-01-18 06:43:32 --> Form Validation Class Initialized
INFO - 2024-01-18 06:43:32 --> Controller Class Initialized
INFO - 2024-01-18 06:43:32 --> Model Class Initialized
DEBUG - 2024-01-18 06:43:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 06:43:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 06:43:32 --> Model Class Initialized
DEBUG - 2024-01-18 06:43:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 06:43:32 --> Model Class Initialized
DEBUG - 2024-01-18 06:43:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 06:43:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-18 06:43:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 06:43:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 06:43:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 06:43:32 --> Model Class Initialized
INFO - 2024-01-18 06:43:32 --> Model Class Initialized
INFO - 2024-01-18 06:43:32 --> Model Class Initialized
INFO - 2024-01-18 06:43:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 06:43:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 06:43:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 06:43:32 --> Final output sent to browser
DEBUG - 2024-01-18 06:43:32 --> Total execution time: 0.1658
ERROR - 2024-01-18 07:19:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 07:19:07 --> Config Class Initialized
INFO - 2024-01-18 07:19:07 --> Hooks Class Initialized
DEBUG - 2024-01-18 07:19:07 --> UTF-8 Support Enabled
INFO - 2024-01-18 07:19:07 --> Utf8 Class Initialized
INFO - 2024-01-18 07:19:07 --> URI Class Initialized
DEBUG - 2024-01-18 07:19:07 --> No URI present. Default controller set.
INFO - 2024-01-18 07:19:07 --> Router Class Initialized
INFO - 2024-01-18 07:19:07 --> Output Class Initialized
INFO - 2024-01-18 07:19:07 --> Security Class Initialized
DEBUG - 2024-01-18 07:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 07:19:07 --> Input Class Initialized
INFO - 2024-01-18 07:19:07 --> Language Class Initialized
INFO - 2024-01-18 07:19:07 --> Loader Class Initialized
INFO - 2024-01-18 07:19:07 --> Helper loaded: url_helper
INFO - 2024-01-18 07:19:07 --> Helper loaded: file_helper
INFO - 2024-01-18 07:19:07 --> Helper loaded: html_helper
INFO - 2024-01-18 07:19:07 --> Helper loaded: text_helper
INFO - 2024-01-18 07:19:07 --> Helper loaded: form_helper
INFO - 2024-01-18 07:19:07 --> Helper loaded: lang_helper
INFO - 2024-01-18 07:19:07 --> Helper loaded: security_helper
INFO - 2024-01-18 07:19:07 --> Helper loaded: cookie_helper
INFO - 2024-01-18 07:19:07 --> Database Driver Class Initialized
INFO - 2024-01-18 07:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 07:19:07 --> Parser Class Initialized
INFO - 2024-01-18 07:19:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 07:19:07 --> Pagination Class Initialized
INFO - 2024-01-18 07:19:07 --> Form Validation Class Initialized
INFO - 2024-01-18 07:19:07 --> Controller Class Initialized
INFO - 2024-01-18 07:19:07 --> Model Class Initialized
DEBUG - 2024-01-18 07:19:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 07:19:07 --> Model Class Initialized
DEBUG - 2024-01-18 07:19:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 07:19:07 --> Model Class Initialized
INFO - 2024-01-18 07:19:07 --> Model Class Initialized
INFO - 2024-01-18 07:19:07 --> Model Class Initialized
INFO - 2024-01-18 07:19:07 --> Model Class Initialized
DEBUG - 2024-01-18 07:19:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 07:19:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 07:19:07 --> Model Class Initialized
INFO - 2024-01-18 07:19:07 --> Model Class Initialized
INFO - 2024-01-18 07:19:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-18 07:19:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 07:19:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 07:19:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 07:19:07 --> Model Class Initialized
INFO - 2024-01-18 07:19:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 07:19:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 07:19:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 07:19:07 --> Final output sent to browser
DEBUG - 2024-01-18 07:19:07 --> Total execution time: 0.2488
ERROR - 2024-01-18 07:19:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 07:19:15 --> Config Class Initialized
INFO - 2024-01-18 07:19:15 --> Hooks Class Initialized
DEBUG - 2024-01-18 07:19:15 --> UTF-8 Support Enabled
INFO - 2024-01-18 07:19:15 --> Utf8 Class Initialized
INFO - 2024-01-18 07:19:15 --> URI Class Initialized
INFO - 2024-01-18 07:19:15 --> Router Class Initialized
INFO - 2024-01-18 07:19:15 --> Output Class Initialized
INFO - 2024-01-18 07:19:15 --> Security Class Initialized
DEBUG - 2024-01-18 07:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 07:19:15 --> Input Class Initialized
INFO - 2024-01-18 07:19:15 --> Language Class Initialized
INFO - 2024-01-18 07:19:15 --> Loader Class Initialized
INFO - 2024-01-18 07:19:15 --> Helper loaded: url_helper
INFO - 2024-01-18 07:19:15 --> Helper loaded: file_helper
INFO - 2024-01-18 07:19:15 --> Helper loaded: html_helper
INFO - 2024-01-18 07:19:15 --> Helper loaded: text_helper
INFO - 2024-01-18 07:19:15 --> Helper loaded: form_helper
INFO - 2024-01-18 07:19:15 --> Helper loaded: lang_helper
INFO - 2024-01-18 07:19:15 --> Helper loaded: security_helper
INFO - 2024-01-18 07:19:15 --> Helper loaded: cookie_helper
INFO - 2024-01-18 07:19:15 --> Database Driver Class Initialized
INFO - 2024-01-18 07:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 07:19:15 --> Parser Class Initialized
INFO - 2024-01-18 07:19:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 07:19:15 --> Pagination Class Initialized
INFO - 2024-01-18 07:19:15 --> Form Validation Class Initialized
INFO - 2024-01-18 07:19:15 --> Controller Class Initialized
INFO - 2024-01-18 07:19:15 --> Model Class Initialized
DEBUG - 2024-01-18 07:19:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 07:19:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 07:19:15 --> Model Class Initialized
DEBUG - 2024-01-18 07:19:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 07:19:15 --> Model Class Initialized
INFO - 2024-01-18 07:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-01-18 07:19:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 07:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 07:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 07:19:15 --> Model Class Initialized
INFO - 2024-01-18 07:19:15 --> Model Class Initialized
INFO - 2024-01-18 07:19:15 --> Model Class Initialized
INFO - 2024-01-18 07:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 07:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 07:19:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 07:19:15 --> Final output sent to browser
DEBUG - 2024-01-18 07:19:15 --> Total execution time: 0.1830
ERROR - 2024-01-18 07:19:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 07:19:19 --> Config Class Initialized
INFO - 2024-01-18 07:19:19 --> Hooks Class Initialized
DEBUG - 2024-01-18 07:19:19 --> UTF-8 Support Enabled
INFO - 2024-01-18 07:19:19 --> Utf8 Class Initialized
INFO - 2024-01-18 07:19:19 --> URI Class Initialized
DEBUG - 2024-01-18 07:19:19 --> No URI present. Default controller set.
INFO - 2024-01-18 07:19:19 --> Router Class Initialized
INFO - 2024-01-18 07:19:19 --> Output Class Initialized
INFO - 2024-01-18 07:19:19 --> Security Class Initialized
DEBUG - 2024-01-18 07:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 07:19:19 --> Input Class Initialized
INFO - 2024-01-18 07:19:19 --> Language Class Initialized
INFO - 2024-01-18 07:19:19 --> Loader Class Initialized
INFO - 2024-01-18 07:19:19 --> Helper loaded: url_helper
INFO - 2024-01-18 07:19:19 --> Helper loaded: file_helper
INFO - 2024-01-18 07:19:19 --> Helper loaded: html_helper
INFO - 2024-01-18 07:19:19 --> Helper loaded: text_helper
INFO - 2024-01-18 07:19:19 --> Helper loaded: form_helper
INFO - 2024-01-18 07:19:19 --> Helper loaded: lang_helper
INFO - 2024-01-18 07:19:19 --> Helper loaded: security_helper
INFO - 2024-01-18 07:19:19 --> Helper loaded: cookie_helper
INFO - 2024-01-18 07:19:19 --> Database Driver Class Initialized
INFO - 2024-01-18 07:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 07:19:19 --> Parser Class Initialized
INFO - 2024-01-18 07:19:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 07:19:19 --> Pagination Class Initialized
INFO - 2024-01-18 07:19:19 --> Form Validation Class Initialized
INFO - 2024-01-18 07:19:19 --> Controller Class Initialized
INFO - 2024-01-18 07:19:19 --> Model Class Initialized
DEBUG - 2024-01-18 07:19:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 07:19:19 --> Model Class Initialized
DEBUG - 2024-01-18 07:19:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 07:19:19 --> Model Class Initialized
INFO - 2024-01-18 07:19:19 --> Model Class Initialized
INFO - 2024-01-18 07:19:19 --> Model Class Initialized
INFO - 2024-01-18 07:19:19 --> Model Class Initialized
DEBUG - 2024-01-18 07:19:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 07:19:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 07:19:19 --> Model Class Initialized
INFO - 2024-01-18 07:19:19 --> Model Class Initialized
INFO - 2024-01-18 07:19:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-18 07:19:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 07:19:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 07:19:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 07:19:19 --> Model Class Initialized
INFO - 2024-01-18 07:19:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 07:19:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 07:19:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 07:19:19 --> Final output sent to browser
DEBUG - 2024-01-18 07:19:19 --> Total execution time: 0.2241
ERROR - 2024-01-18 07:19:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 07:19:23 --> Config Class Initialized
INFO - 2024-01-18 07:19:23 --> Hooks Class Initialized
DEBUG - 2024-01-18 07:19:23 --> UTF-8 Support Enabled
INFO - 2024-01-18 07:19:23 --> Utf8 Class Initialized
INFO - 2024-01-18 07:19:23 --> URI Class Initialized
INFO - 2024-01-18 07:19:23 --> Router Class Initialized
INFO - 2024-01-18 07:19:23 --> Output Class Initialized
INFO - 2024-01-18 07:19:23 --> Security Class Initialized
DEBUG - 2024-01-18 07:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 07:19:23 --> Input Class Initialized
INFO - 2024-01-18 07:19:23 --> Language Class Initialized
INFO - 2024-01-18 07:19:23 --> Loader Class Initialized
INFO - 2024-01-18 07:19:23 --> Helper loaded: url_helper
INFO - 2024-01-18 07:19:23 --> Helper loaded: file_helper
INFO - 2024-01-18 07:19:23 --> Helper loaded: html_helper
INFO - 2024-01-18 07:19:23 --> Helper loaded: text_helper
INFO - 2024-01-18 07:19:23 --> Helper loaded: form_helper
INFO - 2024-01-18 07:19:23 --> Helper loaded: lang_helper
INFO - 2024-01-18 07:19:23 --> Helper loaded: security_helper
INFO - 2024-01-18 07:19:23 --> Helper loaded: cookie_helper
INFO - 2024-01-18 07:19:23 --> Database Driver Class Initialized
INFO - 2024-01-18 07:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 07:19:23 --> Parser Class Initialized
INFO - 2024-01-18 07:19:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 07:19:23 --> Pagination Class Initialized
INFO - 2024-01-18 07:19:23 --> Form Validation Class Initialized
INFO - 2024-01-18 07:19:23 --> Controller Class Initialized
INFO - 2024-01-18 07:19:23 --> Model Class Initialized
DEBUG - 2024-01-18 07:19:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 07:19:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 07:19:23 --> Model Class Initialized
DEBUG - 2024-01-18 07:19:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 07:19:23 --> Model Class Initialized
INFO - 2024-01-18 07:19:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-18 07:19:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 07:19:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 07:19:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 07:19:23 --> Model Class Initialized
INFO - 2024-01-18 07:19:23 --> Model Class Initialized
INFO - 2024-01-18 07:19:23 --> Model Class Initialized
INFO - 2024-01-18 07:19:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 07:19:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 07:19:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 07:19:24 --> Final output sent to browser
DEBUG - 2024-01-18 07:19:24 --> Total execution time: 0.1427
ERROR - 2024-01-18 07:19:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 07:19:24 --> Config Class Initialized
INFO - 2024-01-18 07:19:24 --> Hooks Class Initialized
DEBUG - 2024-01-18 07:19:24 --> UTF-8 Support Enabled
INFO - 2024-01-18 07:19:24 --> Utf8 Class Initialized
INFO - 2024-01-18 07:19:24 --> URI Class Initialized
INFO - 2024-01-18 07:19:24 --> Router Class Initialized
INFO - 2024-01-18 07:19:24 --> Output Class Initialized
INFO - 2024-01-18 07:19:24 --> Security Class Initialized
DEBUG - 2024-01-18 07:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 07:19:24 --> Input Class Initialized
INFO - 2024-01-18 07:19:24 --> Language Class Initialized
INFO - 2024-01-18 07:19:24 --> Loader Class Initialized
INFO - 2024-01-18 07:19:24 --> Helper loaded: url_helper
INFO - 2024-01-18 07:19:24 --> Helper loaded: file_helper
INFO - 2024-01-18 07:19:24 --> Helper loaded: html_helper
INFO - 2024-01-18 07:19:24 --> Helper loaded: text_helper
INFO - 2024-01-18 07:19:24 --> Helper loaded: form_helper
INFO - 2024-01-18 07:19:24 --> Helper loaded: lang_helper
INFO - 2024-01-18 07:19:24 --> Helper loaded: security_helper
INFO - 2024-01-18 07:19:24 --> Helper loaded: cookie_helper
INFO - 2024-01-18 07:19:24 --> Database Driver Class Initialized
INFO - 2024-01-18 07:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 07:19:24 --> Parser Class Initialized
INFO - 2024-01-18 07:19:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 07:19:24 --> Pagination Class Initialized
INFO - 2024-01-18 07:19:24 --> Form Validation Class Initialized
INFO - 2024-01-18 07:19:24 --> Controller Class Initialized
INFO - 2024-01-18 07:19:24 --> Model Class Initialized
DEBUG - 2024-01-18 07:19:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 07:19:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 07:19:24 --> Model Class Initialized
DEBUG - 2024-01-18 07:19:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 07:19:24 --> Model Class Initialized
INFO - 2024-01-18 07:19:24 --> Final output sent to browser
DEBUG - 2024-01-18 07:19:24 --> Total execution time: 0.0402
ERROR - 2024-01-18 07:19:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 07:19:28 --> Config Class Initialized
INFO - 2024-01-18 07:19:28 --> Hooks Class Initialized
DEBUG - 2024-01-18 07:19:28 --> UTF-8 Support Enabled
INFO - 2024-01-18 07:19:28 --> Utf8 Class Initialized
INFO - 2024-01-18 07:19:28 --> URI Class Initialized
INFO - 2024-01-18 07:19:28 --> Router Class Initialized
INFO - 2024-01-18 07:19:28 --> Output Class Initialized
INFO - 2024-01-18 07:19:28 --> Security Class Initialized
DEBUG - 2024-01-18 07:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 07:19:28 --> Input Class Initialized
INFO - 2024-01-18 07:19:28 --> Language Class Initialized
INFO - 2024-01-18 07:19:28 --> Loader Class Initialized
INFO - 2024-01-18 07:19:28 --> Helper loaded: url_helper
INFO - 2024-01-18 07:19:28 --> Helper loaded: file_helper
INFO - 2024-01-18 07:19:28 --> Helper loaded: html_helper
INFO - 2024-01-18 07:19:28 --> Helper loaded: text_helper
INFO - 2024-01-18 07:19:28 --> Helper loaded: form_helper
INFO - 2024-01-18 07:19:28 --> Helper loaded: lang_helper
INFO - 2024-01-18 07:19:28 --> Helper loaded: security_helper
INFO - 2024-01-18 07:19:28 --> Helper loaded: cookie_helper
INFO - 2024-01-18 07:19:28 --> Database Driver Class Initialized
INFO - 2024-01-18 07:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 07:19:28 --> Parser Class Initialized
INFO - 2024-01-18 07:19:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 07:19:28 --> Pagination Class Initialized
INFO - 2024-01-18 07:19:28 --> Form Validation Class Initialized
INFO - 2024-01-18 07:19:28 --> Controller Class Initialized
INFO - 2024-01-18 07:19:28 --> Model Class Initialized
DEBUG - 2024-01-18 07:19:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 07:19:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 07:19:28 --> Model Class Initialized
DEBUG - 2024-01-18 07:19:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 07:19:28 --> Model Class Initialized
INFO - 2024-01-18 07:19:28 --> Final output sent to browser
DEBUG - 2024-01-18 07:19:28 --> Total execution time: 0.0395
ERROR - 2024-01-18 07:19:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 07:19:29 --> Config Class Initialized
INFO - 2024-01-18 07:19:29 --> Hooks Class Initialized
DEBUG - 2024-01-18 07:19:29 --> UTF-8 Support Enabled
INFO - 2024-01-18 07:19:29 --> Utf8 Class Initialized
INFO - 2024-01-18 07:19:29 --> URI Class Initialized
INFO - 2024-01-18 07:19:29 --> Router Class Initialized
INFO - 2024-01-18 07:19:29 --> Output Class Initialized
INFO - 2024-01-18 07:19:29 --> Security Class Initialized
DEBUG - 2024-01-18 07:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 07:19:29 --> Input Class Initialized
INFO - 2024-01-18 07:19:29 --> Language Class Initialized
INFO - 2024-01-18 07:19:29 --> Loader Class Initialized
INFO - 2024-01-18 07:19:29 --> Helper loaded: url_helper
INFO - 2024-01-18 07:19:29 --> Helper loaded: file_helper
INFO - 2024-01-18 07:19:29 --> Helper loaded: html_helper
INFO - 2024-01-18 07:19:29 --> Helper loaded: text_helper
INFO - 2024-01-18 07:19:29 --> Helper loaded: form_helper
INFO - 2024-01-18 07:19:29 --> Helper loaded: lang_helper
INFO - 2024-01-18 07:19:29 --> Helper loaded: security_helper
INFO - 2024-01-18 07:19:29 --> Helper loaded: cookie_helper
INFO - 2024-01-18 07:19:29 --> Database Driver Class Initialized
INFO - 2024-01-18 07:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 07:19:29 --> Parser Class Initialized
INFO - 2024-01-18 07:19:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 07:19:29 --> Pagination Class Initialized
INFO - 2024-01-18 07:19:29 --> Form Validation Class Initialized
INFO - 2024-01-18 07:19:29 --> Controller Class Initialized
INFO - 2024-01-18 07:19:29 --> Model Class Initialized
DEBUG - 2024-01-18 07:19:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 07:19:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 07:19:29 --> Model Class Initialized
DEBUG - 2024-01-18 07:19:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 07:19:29 --> Model Class Initialized
INFO - 2024-01-18 07:19:29 --> Final output sent to browser
DEBUG - 2024-01-18 07:19:29 --> Total execution time: 0.0406
ERROR - 2024-01-18 07:19:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 07:19:29 --> Config Class Initialized
INFO - 2024-01-18 07:19:29 --> Hooks Class Initialized
DEBUG - 2024-01-18 07:19:29 --> UTF-8 Support Enabled
INFO - 2024-01-18 07:19:29 --> Utf8 Class Initialized
INFO - 2024-01-18 07:19:29 --> URI Class Initialized
INFO - 2024-01-18 07:19:29 --> Router Class Initialized
INFO - 2024-01-18 07:19:29 --> Output Class Initialized
INFO - 2024-01-18 07:19:29 --> Security Class Initialized
DEBUG - 2024-01-18 07:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 07:19:29 --> Input Class Initialized
INFO - 2024-01-18 07:19:29 --> Language Class Initialized
INFO - 2024-01-18 07:19:29 --> Loader Class Initialized
INFO - 2024-01-18 07:19:29 --> Helper loaded: url_helper
INFO - 2024-01-18 07:19:29 --> Helper loaded: file_helper
INFO - 2024-01-18 07:19:29 --> Helper loaded: html_helper
INFO - 2024-01-18 07:19:29 --> Helper loaded: text_helper
INFO - 2024-01-18 07:19:29 --> Helper loaded: form_helper
INFO - 2024-01-18 07:19:29 --> Helper loaded: lang_helper
INFO - 2024-01-18 07:19:29 --> Helper loaded: security_helper
INFO - 2024-01-18 07:19:29 --> Helper loaded: cookie_helper
INFO - 2024-01-18 07:19:29 --> Database Driver Class Initialized
INFO - 2024-01-18 07:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 07:19:29 --> Parser Class Initialized
INFO - 2024-01-18 07:19:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 07:19:29 --> Pagination Class Initialized
INFO - 2024-01-18 07:19:29 --> Form Validation Class Initialized
INFO - 2024-01-18 07:19:29 --> Controller Class Initialized
INFO - 2024-01-18 07:19:29 --> Model Class Initialized
DEBUG - 2024-01-18 07:19:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 07:19:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 07:19:29 --> Model Class Initialized
DEBUG - 2024-01-18 07:19:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 07:19:29 --> Model Class Initialized
INFO - 2024-01-18 07:19:29 --> Final output sent to browser
DEBUG - 2024-01-18 07:19:29 --> Total execution time: 0.0368
ERROR - 2024-01-18 07:20:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 07:20:08 --> Config Class Initialized
INFO - 2024-01-18 07:20:08 --> Hooks Class Initialized
DEBUG - 2024-01-18 07:20:08 --> UTF-8 Support Enabled
INFO - 2024-01-18 07:20:08 --> Utf8 Class Initialized
INFO - 2024-01-18 07:20:08 --> URI Class Initialized
INFO - 2024-01-18 07:20:08 --> Router Class Initialized
INFO - 2024-01-18 07:20:08 --> Output Class Initialized
INFO - 2024-01-18 07:20:08 --> Security Class Initialized
DEBUG - 2024-01-18 07:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 07:20:08 --> Input Class Initialized
INFO - 2024-01-18 07:20:08 --> Language Class Initialized
INFO - 2024-01-18 07:20:08 --> Loader Class Initialized
INFO - 2024-01-18 07:20:08 --> Helper loaded: url_helper
INFO - 2024-01-18 07:20:08 --> Helper loaded: file_helper
INFO - 2024-01-18 07:20:08 --> Helper loaded: html_helper
INFO - 2024-01-18 07:20:08 --> Helper loaded: text_helper
INFO - 2024-01-18 07:20:08 --> Helper loaded: form_helper
INFO - 2024-01-18 07:20:08 --> Helper loaded: lang_helper
INFO - 2024-01-18 07:20:08 --> Helper loaded: security_helper
INFO - 2024-01-18 07:20:08 --> Helper loaded: cookie_helper
INFO - 2024-01-18 07:20:08 --> Database Driver Class Initialized
INFO - 2024-01-18 07:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 07:20:08 --> Parser Class Initialized
INFO - 2024-01-18 07:20:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 07:20:08 --> Pagination Class Initialized
INFO - 2024-01-18 07:20:08 --> Form Validation Class Initialized
INFO - 2024-01-18 07:20:08 --> Controller Class Initialized
INFO - 2024-01-18 07:20:08 --> Model Class Initialized
DEBUG - 2024-01-18 07:20:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 07:20:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 07:20:08 --> Model Class Initialized
DEBUG - 2024-01-18 07:20:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 07:20:08 --> Model Class Initialized
DEBUG - 2024-01-18 07:20:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 07:20:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-18 07:20:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 07:20:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 07:20:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 07:20:08 --> Model Class Initialized
INFO - 2024-01-18 07:20:08 --> Model Class Initialized
INFO - 2024-01-18 07:20:08 --> Model Class Initialized
INFO - 2024-01-18 07:20:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 07:20:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 07:20:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 07:20:08 --> Final output sent to browser
DEBUG - 2024-01-18 07:20:08 --> Total execution time: 0.1641
ERROR - 2024-01-18 07:45:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 07:45:30 --> Config Class Initialized
INFO - 2024-01-18 07:45:30 --> Hooks Class Initialized
DEBUG - 2024-01-18 07:45:30 --> UTF-8 Support Enabled
INFO - 2024-01-18 07:45:30 --> Utf8 Class Initialized
INFO - 2024-01-18 07:45:30 --> URI Class Initialized
INFO - 2024-01-18 07:45:30 --> Router Class Initialized
INFO - 2024-01-18 07:45:30 --> Output Class Initialized
INFO - 2024-01-18 07:45:30 --> Security Class Initialized
DEBUG - 2024-01-18 07:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 07:45:30 --> Input Class Initialized
INFO - 2024-01-18 07:45:30 --> Language Class Initialized
ERROR - 2024-01-18 07:45:30 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2024-01-18 07:45:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 07:45:31 --> Config Class Initialized
INFO - 2024-01-18 07:45:31 --> Hooks Class Initialized
DEBUG - 2024-01-18 07:45:31 --> UTF-8 Support Enabled
INFO - 2024-01-18 07:45:31 --> Utf8 Class Initialized
INFO - 2024-01-18 07:45:31 --> URI Class Initialized
DEBUG - 2024-01-18 07:45:31 --> No URI present. Default controller set.
INFO - 2024-01-18 07:45:31 --> Router Class Initialized
INFO - 2024-01-18 07:45:31 --> Output Class Initialized
INFO - 2024-01-18 07:45:31 --> Security Class Initialized
DEBUG - 2024-01-18 07:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 07:45:31 --> Input Class Initialized
INFO - 2024-01-18 07:45:31 --> Language Class Initialized
INFO - 2024-01-18 07:45:31 --> Loader Class Initialized
INFO - 2024-01-18 07:45:31 --> Helper loaded: url_helper
INFO - 2024-01-18 07:45:31 --> Helper loaded: file_helper
INFO - 2024-01-18 07:45:31 --> Helper loaded: html_helper
INFO - 2024-01-18 07:45:31 --> Helper loaded: text_helper
INFO - 2024-01-18 07:45:31 --> Helper loaded: form_helper
INFO - 2024-01-18 07:45:31 --> Helper loaded: lang_helper
INFO - 2024-01-18 07:45:31 --> Helper loaded: security_helper
INFO - 2024-01-18 07:45:31 --> Helper loaded: cookie_helper
INFO - 2024-01-18 07:45:31 --> Database Driver Class Initialized
INFO - 2024-01-18 07:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 07:45:31 --> Parser Class Initialized
INFO - 2024-01-18 07:45:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 07:45:31 --> Pagination Class Initialized
INFO - 2024-01-18 07:45:31 --> Form Validation Class Initialized
INFO - 2024-01-18 07:45:31 --> Controller Class Initialized
INFO - 2024-01-18 07:45:31 --> Model Class Initialized
DEBUG - 2024-01-18 07:45:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-18 07:45:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 07:45:32 --> Config Class Initialized
INFO - 2024-01-18 07:45:32 --> Hooks Class Initialized
DEBUG - 2024-01-18 07:45:32 --> UTF-8 Support Enabled
INFO - 2024-01-18 07:45:32 --> Utf8 Class Initialized
INFO - 2024-01-18 07:45:32 --> URI Class Initialized
INFO - 2024-01-18 07:45:32 --> Router Class Initialized
INFO - 2024-01-18 07:45:32 --> Output Class Initialized
INFO - 2024-01-18 07:45:32 --> Security Class Initialized
DEBUG - 2024-01-18 07:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 07:45:32 --> Input Class Initialized
INFO - 2024-01-18 07:45:32 --> Language Class Initialized
ERROR - 2024-01-18 07:45:32 --> 404 Page Not Found: Wp-cronphp/index
ERROR - 2024-01-18 09:10:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 09:10:40 --> Config Class Initialized
INFO - 2024-01-18 09:10:40 --> Hooks Class Initialized
DEBUG - 2024-01-18 09:10:40 --> UTF-8 Support Enabled
INFO - 2024-01-18 09:10:40 --> Utf8 Class Initialized
INFO - 2024-01-18 09:10:40 --> URI Class Initialized
DEBUG - 2024-01-18 09:10:40 --> No URI present. Default controller set.
INFO - 2024-01-18 09:10:40 --> Router Class Initialized
INFO - 2024-01-18 09:10:40 --> Output Class Initialized
INFO - 2024-01-18 09:10:40 --> Security Class Initialized
DEBUG - 2024-01-18 09:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 09:10:40 --> Input Class Initialized
INFO - 2024-01-18 09:10:40 --> Language Class Initialized
INFO - 2024-01-18 09:10:40 --> Loader Class Initialized
INFO - 2024-01-18 09:10:40 --> Helper loaded: url_helper
INFO - 2024-01-18 09:10:40 --> Helper loaded: file_helper
INFO - 2024-01-18 09:10:40 --> Helper loaded: html_helper
INFO - 2024-01-18 09:10:40 --> Helper loaded: text_helper
INFO - 2024-01-18 09:10:40 --> Helper loaded: form_helper
INFO - 2024-01-18 09:10:40 --> Helper loaded: lang_helper
INFO - 2024-01-18 09:10:40 --> Helper loaded: security_helper
INFO - 2024-01-18 09:10:40 --> Helper loaded: cookie_helper
INFO - 2024-01-18 09:10:40 --> Database Driver Class Initialized
INFO - 2024-01-18 09:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 09:10:40 --> Parser Class Initialized
INFO - 2024-01-18 09:10:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 09:10:40 --> Pagination Class Initialized
INFO - 2024-01-18 09:10:40 --> Form Validation Class Initialized
INFO - 2024-01-18 09:10:40 --> Controller Class Initialized
INFO - 2024-01-18 09:10:40 --> Model Class Initialized
DEBUG - 2024-01-18 09:10:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:10:40 --> Model Class Initialized
DEBUG - 2024-01-18 09:10:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:10:40 --> Model Class Initialized
INFO - 2024-01-18 09:10:40 --> Model Class Initialized
INFO - 2024-01-18 09:10:40 --> Model Class Initialized
INFO - 2024-01-18 09:10:40 --> Model Class Initialized
DEBUG - 2024-01-18 09:10:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 09:10:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:10:40 --> Model Class Initialized
INFO - 2024-01-18 09:10:40 --> Model Class Initialized
INFO - 2024-01-18 09:10:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-18 09:10:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:10:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 09:10:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 09:10:40 --> Model Class Initialized
INFO - 2024-01-18 09:10:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 09:10:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 09:10:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 09:10:40 --> Final output sent to browser
DEBUG - 2024-01-18 09:10:40 --> Total execution time: 0.2304
ERROR - 2024-01-18 09:10:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 09:10:45 --> Config Class Initialized
INFO - 2024-01-18 09:10:45 --> Hooks Class Initialized
DEBUG - 2024-01-18 09:10:45 --> UTF-8 Support Enabled
INFO - 2024-01-18 09:10:45 --> Utf8 Class Initialized
INFO - 2024-01-18 09:10:45 --> URI Class Initialized
INFO - 2024-01-18 09:10:45 --> Router Class Initialized
INFO - 2024-01-18 09:10:45 --> Output Class Initialized
INFO - 2024-01-18 09:10:45 --> Security Class Initialized
DEBUG - 2024-01-18 09:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 09:10:45 --> Input Class Initialized
INFO - 2024-01-18 09:10:45 --> Language Class Initialized
INFO - 2024-01-18 09:10:45 --> Loader Class Initialized
INFO - 2024-01-18 09:10:45 --> Helper loaded: url_helper
INFO - 2024-01-18 09:10:45 --> Helper loaded: file_helper
INFO - 2024-01-18 09:10:45 --> Helper loaded: html_helper
INFO - 2024-01-18 09:10:45 --> Helper loaded: text_helper
INFO - 2024-01-18 09:10:45 --> Helper loaded: form_helper
INFO - 2024-01-18 09:10:45 --> Helper loaded: lang_helper
INFO - 2024-01-18 09:10:45 --> Helper loaded: security_helper
INFO - 2024-01-18 09:10:45 --> Helper loaded: cookie_helper
INFO - 2024-01-18 09:10:45 --> Database Driver Class Initialized
INFO - 2024-01-18 09:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 09:10:45 --> Parser Class Initialized
INFO - 2024-01-18 09:10:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 09:10:45 --> Pagination Class Initialized
INFO - 2024-01-18 09:10:45 --> Form Validation Class Initialized
INFO - 2024-01-18 09:10:45 --> Controller Class Initialized
INFO - 2024-01-18 09:10:45 --> Model Class Initialized
DEBUG - 2024-01-18 09:10:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 09:10:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:10:45 --> Model Class Initialized
DEBUG - 2024-01-18 09:10:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:10:45 --> Model Class Initialized
INFO - 2024-01-18 09:10:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-01-18 09:10:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:10:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 09:10:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 09:10:45 --> Model Class Initialized
INFO - 2024-01-18 09:10:45 --> Model Class Initialized
INFO - 2024-01-18 09:10:45 --> Model Class Initialized
INFO - 2024-01-18 09:10:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 09:10:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 09:10:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 09:10:45 --> Final output sent to browser
DEBUG - 2024-01-18 09:10:45 --> Total execution time: 0.1658
ERROR - 2024-01-18 09:10:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 09:10:51 --> Config Class Initialized
INFO - 2024-01-18 09:10:51 --> Hooks Class Initialized
DEBUG - 2024-01-18 09:10:51 --> UTF-8 Support Enabled
INFO - 2024-01-18 09:10:51 --> Utf8 Class Initialized
INFO - 2024-01-18 09:10:51 --> URI Class Initialized
INFO - 2024-01-18 09:10:51 --> Router Class Initialized
INFO - 2024-01-18 09:10:51 --> Output Class Initialized
INFO - 2024-01-18 09:10:51 --> Security Class Initialized
DEBUG - 2024-01-18 09:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 09:10:51 --> Input Class Initialized
INFO - 2024-01-18 09:10:51 --> Language Class Initialized
INFO - 2024-01-18 09:10:51 --> Loader Class Initialized
INFO - 2024-01-18 09:10:51 --> Helper loaded: url_helper
INFO - 2024-01-18 09:10:51 --> Helper loaded: file_helper
INFO - 2024-01-18 09:10:51 --> Helper loaded: html_helper
INFO - 2024-01-18 09:10:51 --> Helper loaded: text_helper
INFO - 2024-01-18 09:10:51 --> Helper loaded: form_helper
INFO - 2024-01-18 09:10:51 --> Helper loaded: lang_helper
INFO - 2024-01-18 09:10:51 --> Helper loaded: security_helper
INFO - 2024-01-18 09:10:51 --> Helper loaded: cookie_helper
INFO - 2024-01-18 09:10:51 --> Database Driver Class Initialized
INFO - 2024-01-18 09:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 09:10:51 --> Parser Class Initialized
INFO - 2024-01-18 09:10:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 09:10:51 --> Pagination Class Initialized
INFO - 2024-01-18 09:10:51 --> Form Validation Class Initialized
INFO - 2024-01-18 09:10:51 --> Controller Class Initialized
INFO - 2024-01-18 09:10:51 --> Model Class Initialized
DEBUG - 2024-01-18 09:10:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:10:51 --> Final output sent to browser
DEBUG - 2024-01-18 09:10:51 --> Total execution time: 0.0184
ERROR - 2024-01-18 09:10:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 09:10:52 --> Config Class Initialized
INFO - 2024-01-18 09:10:52 --> Hooks Class Initialized
DEBUG - 2024-01-18 09:10:52 --> UTF-8 Support Enabled
INFO - 2024-01-18 09:10:52 --> Utf8 Class Initialized
INFO - 2024-01-18 09:10:52 --> URI Class Initialized
INFO - 2024-01-18 09:10:52 --> Router Class Initialized
INFO - 2024-01-18 09:10:52 --> Output Class Initialized
INFO - 2024-01-18 09:10:52 --> Security Class Initialized
DEBUG - 2024-01-18 09:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 09:10:52 --> Input Class Initialized
INFO - 2024-01-18 09:10:52 --> Language Class Initialized
INFO - 2024-01-18 09:10:52 --> Loader Class Initialized
INFO - 2024-01-18 09:10:52 --> Helper loaded: url_helper
INFO - 2024-01-18 09:10:52 --> Helper loaded: file_helper
INFO - 2024-01-18 09:10:52 --> Helper loaded: html_helper
INFO - 2024-01-18 09:10:52 --> Helper loaded: text_helper
INFO - 2024-01-18 09:10:52 --> Helper loaded: form_helper
INFO - 2024-01-18 09:10:52 --> Helper loaded: lang_helper
INFO - 2024-01-18 09:10:52 --> Helper loaded: security_helper
INFO - 2024-01-18 09:10:52 --> Helper loaded: cookie_helper
INFO - 2024-01-18 09:10:52 --> Database Driver Class Initialized
INFO - 2024-01-18 09:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 09:10:52 --> Parser Class Initialized
INFO - 2024-01-18 09:10:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 09:10:52 --> Pagination Class Initialized
INFO - 2024-01-18 09:10:52 --> Form Validation Class Initialized
INFO - 2024-01-18 09:10:52 --> Controller Class Initialized
INFO - 2024-01-18 09:10:52 --> Model Class Initialized
DEBUG - 2024-01-18 09:10:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:10:52 --> Final output sent to browser
DEBUG - 2024-01-18 09:10:52 --> Total execution time: 0.0165
ERROR - 2024-01-18 09:10:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 09:10:55 --> Config Class Initialized
INFO - 2024-01-18 09:10:55 --> Hooks Class Initialized
DEBUG - 2024-01-18 09:10:55 --> UTF-8 Support Enabled
INFO - 2024-01-18 09:10:55 --> Utf8 Class Initialized
INFO - 2024-01-18 09:10:55 --> URI Class Initialized
INFO - 2024-01-18 09:10:55 --> Router Class Initialized
INFO - 2024-01-18 09:10:55 --> Output Class Initialized
INFO - 2024-01-18 09:10:55 --> Security Class Initialized
DEBUG - 2024-01-18 09:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 09:10:55 --> Input Class Initialized
INFO - 2024-01-18 09:10:55 --> Language Class Initialized
INFO - 2024-01-18 09:10:55 --> Loader Class Initialized
INFO - 2024-01-18 09:10:55 --> Helper loaded: url_helper
INFO - 2024-01-18 09:10:55 --> Helper loaded: file_helper
INFO - 2024-01-18 09:10:55 --> Helper loaded: html_helper
INFO - 2024-01-18 09:10:55 --> Helper loaded: text_helper
INFO - 2024-01-18 09:10:55 --> Helper loaded: form_helper
INFO - 2024-01-18 09:10:55 --> Helper loaded: lang_helper
INFO - 2024-01-18 09:10:55 --> Helper loaded: security_helper
INFO - 2024-01-18 09:10:55 --> Helper loaded: cookie_helper
INFO - 2024-01-18 09:10:55 --> Database Driver Class Initialized
INFO - 2024-01-18 09:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 09:10:55 --> Parser Class Initialized
INFO - 2024-01-18 09:10:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 09:10:55 --> Pagination Class Initialized
INFO - 2024-01-18 09:10:55 --> Form Validation Class Initialized
INFO - 2024-01-18 09:10:55 --> Controller Class Initialized
INFO - 2024-01-18 09:10:55 --> Final output sent to browser
DEBUG - 2024-01-18 09:10:55 --> Total execution time: 0.0139
ERROR - 2024-01-18 09:11:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 09:11:01 --> Config Class Initialized
INFO - 2024-01-18 09:11:01 --> Hooks Class Initialized
DEBUG - 2024-01-18 09:11:01 --> UTF-8 Support Enabled
INFO - 2024-01-18 09:11:01 --> Utf8 Class Initialized
INFO - 2024-01-18 09:11:01 --> URI Class Initialized
INFO - 2024-01-18 09:11:01 --> Router Class Initialized
INFO - 2024-01-18 09:11:01 --> Output Class Initialized
INFO - 2024-01-18 09:11:01 --> Security Class Initialized
DEBUG - 2024-01-18 09:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 09:11:01 --> Input Class Initialized
INFO - 2024-01-18 09:11:01 --> Language Class Initialized
INFO - 2024-01-18 09:11:01 --> Loader Class Initialized
INFO - 2024-01-18 09:11:01 --> Helper loaded: url_helper
INFO - 2024-01-18 09:11:01 --> Helper loaded: file_helper
INFO - 2024-01-18 09:11:01 --> Helper loaded: html_helper
INFO - 2024-01-18 09:11:01 --> Helper loaded: text_helper
INFO - 2024-01-18 09:11:01 --> Helper loaded: form_helper
INFO - 2024-01-18 09:11:01 --> Helper loaded: lang_helper
INFO - 2024-01-18 09:11:01 --> Helper loaded: security_helper
INFO - 2024-01-18 09:11:01 --> Helper loaded: cookie_helper
INFO - 2024-01-18 09:11:01 --> Database Driver Class Initialized
INFO - 2024-01-18 09:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 09:11:01 --> Parser Class Initialized
INFO - 2024-01-18 09:11:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 09:11:01 --> Pagination Class Initialized
INFO - 2024-01-18 09:11:01 --> Form Validation Class Initialized
INFO - 2024-01-18 09:11:01 --> Controller Class Initialized
INFO - 2024-01-18 09:11:01 --> Model Class Initialized
DEBUG - 2024-01-18 09:11:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 09:11:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:11:01 --> Model Class Initialized
DEBUG - 2024-01-18 09:11:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:11:01 --> Model Class Initialized
INFO - 2024-01-18 09:11:01 --> Final output sent to browser
DEBUG - 2024-01-18 09:11:01 --> Total execution time: 0.1728
ERROR - 2024-01-18 09:11:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 09:11:02 --> Config Class Initialized
INFO - 2024-01-18 09:11:02 --> Hooks Class Initialized
DEBUG - 2024-01-18 09:11:02 --> UTF-8 Support Enabled
INFO - 2024-01-18 09:11:02 --> Utf8 Class Initialized
INFO - 2024-01-18 09:11:02 --> URI Class Initialized
INFO - 2024-01-18 09:11:02 --> Router Class Initialized
INFO - 2024-01-18 09:11:02 --> Output Class Initialized
INFO - 2024-01-18 09:11:02 --> Security Class Initialized
DEBUG - 2024-01-18 09:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 09:11:02 --> Input Class Initialized
INFO - 2024-01-18 09:11:02 --> Language Class Initialized
INFO - 2024-01-18 09:11:02 --> Loader Class Initialized
INFO - 2024-01-18 09:11:02 --> Helper loaded: url_helper
INFO - 2024-01-18 09:11:02 --> Helper loaded: file_helper
INFO - 2024-01-18 09:11:02 --> Helper loaded: html_helper
INFO - 2024-01-18 09:11:02 --> Helper loaded: text_helper
INFO - 2024-01-18 09:11:02 --> Helper loaded: form_helper
INFO - 2024-01-18 09:11:02 --> Helper loaded: lang_helper
INFO - 2024-01-18 09:11:02 --> Helper loaded: security_helper
INFO - 2024-01-18 09:11:02 --> Helper loaded: cookie_helper
INFO - 2024-01-18 09:11:02 --> Database Driver Class Initialized
INFO - 2024-01-18 09:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 09:11:02 --> Parser Class Initialized
INFO - 2024-01-18 09:11:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 09:11:02 --> Pagination Class Initialized
INFO - 2024-01-18 09:11:02 --> Form Validation Class Initialized
INFO - 2024-01-18 09:11:02 --> Controller Class Initialized
INFO - 2024-01-18 09:11:02 --> Model Class Initialized
DEBUG - 2024-01-18 09:11:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 09:11:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:11:02 --> Model Class Initialized
DEBUG - 2024-01-18 09:11:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:11:02 --> Model Class Initialized
INFO - 2024-01-18 09:11:02 --> Final output sent to browser
DEBUG - 2024-01-18 09:11:02 --> Total execution time: 0.1871
ERROR - 2024-01-18 09:11:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 09:11:02 --> Config Class Initialized
INFO - 2024-01-18 09:11:02 --> Hooks Class Initialized
DEBUG - 2024-01-18 09:11:02 --> UTF-8 Support Enabled
INFO - 2024-01-18 09:11:02 --> Utf8 Class Initialized
INFO - 2024-01-18 09:11:02 --> URI Class Initialized
INFO - 2024-01-18 09:11:02 --> Router Class Initialized
INFO - 2024-01-18 09:11:02 --> Output Class Initialized
INFO - 2024-01-18 09:11:02 --> Security Class Initialized
DEBUG - 2024-01-18 09:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 09:11:02 --> Input Class Initialized
INFO - 2024-01-18 09:11:02 --> Language Class Initialized
INFO - 2024-01-18 09:11:02 --> Loader Class Initialized
INFO - 2024-01-18 09:11:02 --> Helper loaded: url_helper
INFO - 2024-01-18 09:11:02 --> Helper loaded: file_helper
INFO - 2024-01-18 09:11:02 --> Helper loaded: html_helper
INFO - 2024-01-18 09:11:02 --> Helper loaded: text_helper
INFO - 2024-01-18 09:11:02 --> Helper loaded: form_helper
INFO - 2024-01-18 09:11:02 --> Helper loaded: lang_helper
INFO - 2024-01-18 09:11:02 --> Helper loaded: security_helper
INFO - 2024-01-18 09:11:02 --> Helper loaded: cookie_helper
INFO - 2024-01-18 09:11:02 --> Database Driver Class Initialized
INFO - 2024-01-18 09:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 09:11:02 --> Parser Class Initialized
INFO - 2024-01-18 09:11:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 09:11:02 --> Pagination Class Initialized
INFO - 2024-01-18 09:11:02 --> Form Validation Class Initialized
INFO - 2024-01-18 09:11:02 --> Controller Class Initialized
INFO - 2024-01-18 09:11:02 --> Model Class Initialized
DEBUG - 2024-01-18 09:11:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 09:11:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:11:02 --> Model Class Initialized
DEBUG - 2024-01-18 09:11:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:11:02 --> Model Class Initialized
INFO - 2024-01-18 09:11:02 --> Final output sent to browser
DEBUG - 2024-01-18 09:11:02 --> Total execution time: 0.1731
ERROR - 2024-01-18 09:11:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 09:11:04 --> Config Class Initialized
INFO - 2024-01-18 09:11:04 --> Hooks Class Initialized
DEBUG - 2024-01-18 09:11:04 --> UTF-8 Support Enabled
INFO - 2024-01-18 09:11:04 --> Utf8 Class Initialized
INFO - 2024-01-18 09:11:04 --> URI Class Initialized
INFO - 2024-01-18 09:11:04 --> Router Class Initialized
INFO - 2024-01-18 09:11:04 --> Output Class Initialized
INFO - 2024-01-18 09:11:04 --> Security Class Initialized
DEBUG - 2024-01-18 09:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 09:11:04 --> Input Class Initialized
INFO - 2024-01-18 09:11:04 --> Language Class Initialized
INFO - 2024-01-18 09:11:04 --> Loader Class Initialized
INFO - 2024-01-18 09:11:04 --> Helper loaded: url_helper
INFO - 2024-01-18 09:11:04 --> Helper loaded: file_helper
INFO - 2024-01-18 09:11:04 --> Helper loaded: html_helper
INFO - 2024-01-18 09:11:04 --> Helper loaded: text_helper
INFO - 2024-01-18 09:11:04 --> Helper loaded: form_helper
INFO - 2024-01-18 09:11:04 --> Helper loaded: lang_helper
INFO - 2024-01-18 09:11:04 --> Helper loaded: security_helper
INFO - 2024-01-18 09:11:04 --> Helper loaded: cookie_helper
INFO - 2024-01-18 09:11:04 --> Database Driver Class Initialized
INFO - 2024-01-18 09:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 09:11:04 --> Parser Class Initialized
INFO - 2024-01-18 09:11:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 09:11:04 --> Pagination Class Initialized
INFO - 2024-01-18 09:11:04 --> Form Validation Class Initialized
INFO - 2024-01-18 09:11:04 --> Controller Class Initialized
INFO - 2024-01-18 09:11:04 --> Model Class Initialized
DEBUG - 2024-01-18 09:11:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 09:11:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:11:04 --> Model Class Initialized
DEBUG - 2024-01-18 09:11:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:11:04 --> Model Class Initialized
INFO - 2024-01-18 09:11:04 --> Final output sent to browser
DEBUG - 2024-01-18 09:11:04 --> Total execution time: 0.0339
ERROR - 2024-01-18 09:11:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 09:11:06 --> Config Class Initialized
INFO - 2024-01-18 09:11:06 --> Hooks Class Initialized
DEBUG - 2024-01-18 09:11:06 --> UTF-8 Support Enabled
INFO - 2024-01-18 09:11:06 --> Utf8 Class Initialized
INFO - 2024-01-18 09:11:06 --> URI Class Initialized
INFO - 2024-01-18 09:11:06 --> Router Class Initialized
INFO - 2024-01-18 09:11:06 --> Output Class Initialized
INFO - 2024-01-18 09:11:06 --> Security Class Initialized
DEBUG - 2024-01-18 09:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 09:11:06 --> Input Class Initialized
INFO - 2024-01-18 09:11:06 --> Language Class Initialized
INFO - 2024-01-18 09:11:06 --> Loader Class Initialized
INFO - 2024-01-18 09:11:06 --> Helper loaded: url_helper
INFO - 2024-01-18 09:11:06 --> Helper loaded: file_helper
INFO - 2024-01-18 09:11:06 --> Helper loaded: html_helper
INFO - 2024-01-18 09:11:06 --> Helper loaded: text_helper
INFO - 2024-01-18 09:11:06 --> Helper loaded: form_helper
INFO - 2024-01-18 09:11:06 --> Helper loaded: lang_helper
INFO - 2024-01-18 09:11:06 --> Helper loaded: security_helper
INFO - 2024-01-18 09:11:06 --> Helper loaded: cookie_helper
INFO - 2024-01-18 09:11:06 --> Database Driver Class Initialized
INFO - 2024-01-18 09:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 09:11:06 --> Parser Class Initialized
INFO - 2024-01-18 09:11:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 09:11:06 --> Pagination Class Initialized
INFO - 2024-01-18 09:11:06 --> Form Validation Class Initialized
INFO - 2024-01-18 09:11:06 --> Controller Class Initialized
INFO - 2024-01-18 09:11:06 --> Model Class Initialized
DEBUG - 2024-01-18 09:11:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 09:11:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:11:06 --> Model Class Initialized
INFO - 2024-01-18 09:11:06 --> Model Class Initialized
INFO - 2024-01-18 09:11:06 --> Final output sent to browser
DEBUG - 2024-01-18 09:11:06 --> Total execution time: 0.0226
ERROR - 2024-01-18 09:11:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 09:11:10 --> Config Class Initialized
INFO - 2024-01-18 09:11:10 --> Hooks Class Initialized
DEBUG - 2024-01-18 09:11:10 --> UTF-8 Support Enabled
INFO - 2024-01-18 09:11:10 --> Utf8 Class Initialized
INFO - 2024-01-18 09:11:10 --> URI Class Initialized
INFO - 2024-01-18 09:11:10 --> Router Class Initialized
INFO - 2024-01-18 09:11:10 --> Output Class Initialized
INFO - 2024-01-18 09:11:10 --> Security Class Initialized
DEBUG - 2024-01-18 09:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 09:11:10 --> Input Class Initialized
INFO - 2024-01-18 09:11:10 --> Language Class Initialized
INFO - 2024-01-18 09:11:10 --> Loader Class Initialized
INFO - 2024-01-18 09:11:10 --> Helper loaded: url_helper
INFO - 2024-01-18 09:11:10 --> Helper loaded: file_helper
INFO - 2024-01-18 09:11:10 --> Helper loaded: html_helper
INFO - 2024-01-18 09:11:10 --> Helper loaded: text_helper
INFO - 2024-01-18 09:11:10 --> Helper loaded: form_helper
INFO - 2024-01-18 09:11:10 --> Helper loaded: lang_helper
INFO - 2024-01-18 09:11:10 --> Helper loaded: security_helper
INFO - 2024-01-18 09:11:10 --> Helper loaded: cookie_helper
INFO - 2024-01-18 09:11:10 --> Database Driver Class Initialized
INFO - 2024-01-18 09:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 09:11:10 --> Parser Class Initialized
INFO - 2024-01-18 09:11:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 09:11:10 --> Pagination Class Initialized
INFO - 2024-01-18 09:11:10 --> Form Validation Class Initialized
INFO - 2024-01-18 09:11:10 --> Controller Class Initialized
INFO - 2024-01-18 09:11:10 --> Model Class Initialized
DEBUG - 2024-01-18 09:11:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 09:11:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:11:10 --> Model Class Initialized
INFO - 2024-01-18 09:11:10 --> Final output sent to browser
DEBUG - 2024-01-18 09:11:10 --> Total execution time: 0.0180
ERROR - 2024-01-18 09:11:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 09:11:19 --> Config Class Initialized
INFO - 2024-01-18 09:11:19 --> Hooks Class Initialized
DEBUG - 2024-01-18 09:11:19 --> UTF-8 Support Enabled
INFO - 2024-01-18 09:11:19 --> Utf8 Class Initialized
INFO - 2024-01-18 09:11:19 --> URI Class Initialized
INFO - 2024-01-18 09:11:19 --> Router Class Initialized
INFO - 2024-01-18 09:11:19 --> Output Class Initialized
INFO - 2024-01-18 09:11:19 --> Security Class Initialized
DEBUG - 2024-01-18 09:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 09:11:19 --> Input Class Initialized
INFO - 2024-01-18 09:11:19 --> Language Class Initialized
INFO - 2024-01-18 09:11:19 --> Loader Class Initialized
INFO - 2024-01-18 09:11:19 --> Helper loaded: url_helper
INFO - 2024-01-18 09:11:19 --> Helper loaded: file_helper
INFO - 2024-01-18 09:11:19 --> Helper loaded: html_helper
INFO - 2024-01-18 09:11:19 --> Helper loaded: text_helper
INFO - 2024-01-18 09:11:19 --> Helper loaded: form_helper
INFO - 2024-01-18 09:11:19 --> Helper loaded: lang_helper
INFO - 2024-01-18 09:11:19 --> Helper loaded: security_helper
INFO - 2024-01-18 09:11:19 --> Helper loaded: cookie_helper
INFO - 2024-01-18 09:11:19 --> Database Driver Class Initialized
INFO - 2024-01-18 09:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 09:11:19 --> Parser Class Initialized
INFO - 2024-01-18 09:11:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 09:11:19 --> Pagination Class Initialized
INFO - 2024-01-18 09:11:19 --> Form Validation Class Initialized
INFO - 2024-01-18 09:11:19 --> Controller Class Initialized
INFO - 2024-01-18 09:11:19 --> Model Class Initialized
DEBUG - 2024-01-18 09:11:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 09:11:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:11:19 --> Model Class Initialized
DEBUG - 2024-01-18 09:11:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:11:19 --> Model Class Initialized
INFO - 2024-01-18 09:11:19 --> Final output sent to browser
DEBUG - 2024-01-18 09:11:19 --> Total execution time: 0.0182
ERROR - 2024-01-18 09:11:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 09:11:20 --> Config Class Initialized
INFO - 2024-01-18 09:11:20 --> Hooks Class Initialized
DEBUG - 2024-01-18 09:11:20 --> UTF-8 Support Enabled
INFO - 2024-01-18 09:11:20 --> Utf8 Class Initialized
INFO - 2024-01-18 09:11:20 --> URI Class Initialized
INFO - 2024-01-18 09:11:20 --> Router Class Initialized
INFO - 2024-01-18 09:11:20 --> Output Class Initialized
INFO - 2024-01-18 09:11:20 --> Security Class Initialized
DEBUG - 2024-01-18 09:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 09:11:20 --> Input Class Initialized
INFO - 2024-01-18 09:11:20 --> Language Class Initialized
INFO - 2024-01-18 09:11:20 --> Loader Class Initialized
INFO - 2024-01-18 09:11:20 --> Helper loaded: url_helper
INFO - 2024-01-18 09:11:20 --> Helper loaded: file_helper
INFO - 2024-01-18 09:11:20 --> Helper loaded: html_helper
INFO - 2024-01-18 09:11:20 --> Helper loaded: text_helper
INFO - 2024-01-18 09:11:20 --> Helper loaded: form_helper
INFO - 2024-01-18 09:11:20 --> Helper loaded: lang_helper
INFO - 2024-01-18 09:11:20 --> Helper loaded: security_helper
INFO - 2024-01-18 09:11:20 --> Helper loaded: cookie_helper
INFO - 2024-01-18 09:11:20 --> Database Driver Class Initialized
INFO - 2024-01-18 09:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 09:11:20 --> Parser Class Initialized
INFO - 2024-01-18 09:11:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 09:11:20 --> Pagination Class Initialized
INFO - 2024-01-18 09:11:20 --> Form Validation Class Initialized
INFO - 2024-01-18 09:11:20 --> Controller Class Initialized
INFO - 2024-01-18 09:11:20 --> Model Class Initialized
DEBUG - 2024-01-18 09:11:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 09:11:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:11:20 --> Model Class Initialized
DEBUG - 2024-01-18 09:11:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:11:20 --> Model Class Initialized
INFO - 2024-01-18 09:11:20 --> Final output sent to browser
DEBUG - 2024-01-18 09:11:20 --> Total execution time: 0.0290
ERROR - 2024-01-18 09:11:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 09:11:22 --> Config Class Initialized
INFO - 2024-01-18 09:11:22 --> Hooks Class Initialized
DEBUG - 2024-01-18 09:11:22 --> UTF-8 Support Enabled
INFO - 2024-01-18 09:11:22 --> Utf8 Class Initialized
INFO - 2024-01-18 09:11:22 --> URI Class Initialized
INFO - 2024-01-18 09:11:22 --> Router Class Initialized
INFO - 2024-01-18 09:11:22 --> Output Class Initialized
INFO - 2024-01-18 09:11:22 --> Security Class Initialized
DEBUG - 2024-01-18 09:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 09:11:22 --> Input Class Initialized
INFO - 2024-01-18 09:11:22 --> Language Class Initialized
INFO - 2024-01-18 09:11:22 --> Loader Class Initialized
INFO - 2024-01-18 09:11:22 --> Helper loaded: url_helper
INFO - 2024-01-18 09:11:22 --> Helper loaded: file_helper
INFO - 2024-01-18 09:11:22 --> Helper loaded: html_helper
INFO - 2024-01-18 09:11:22 --> Helper loaded: text_helper
INFO - 2024-01-18 09:11:22 --> Helper loaded: form_helper
INFO - 2024-01-18 09:11:22 --> Helper loaded: lang_helper
INFO - 2024-01-18 09:11:22 --> Helper loaded: security_helper
INFO - 2024-01-18 09:11:22 --> Helper loaded: cookie_helper
INFO - 2024-01-18 09:11:22 --> Database Driver Class Initialized
INFO - 2024-01-18 09:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 09:11:22 --> Parser Class Initialized
INFO - 2024-01-18 09:11:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 09:11:22 --> Pagination Class Initialized
INFO - 2024-01-18 09:11:22 --> Form Validation Class Initialized
INFO - 2024-01-18 09:11:22 --> Controller Class Initialized
INFO - 2024-01-18 09:11:22 --> Model Class Initialized
DEBUG - 2024-01-18 09:11:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 09:11:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:11:22 --> Model Class Initialized
INFO - 2024-01-18 09:11:22 --> Model Class Initialized
INFO - 2024-01-18 09:11:22 --> Final output sent to browser
DEBUG - 2024-01-18 09:11:22 --> Total execution time: 0.0207
ERROR - 2024-01-18 09:11:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 09:11:25 --> Config Class Initialized
INFO - 2024-01-18 09:11:25 --> Hooks Class Initialized
DEBUG - 2024-01-18 09:11:25 --> UTF-8 Support Enabled
INFO - 2024-01-18 09:11:25 --> Utf8 Class Initialized
INFO - 2024-01-18 09:11:25 --> URI Class Initialized
INFO - 2024-01-18 09:11:25 --> Router Class Initialized
INFO - 2024-01-18 09:11:25 --> Output Class Initialized
INFO - 2024-01-18 09:11:25 --> Security Class Initialized
DEBUG - 2024-01-18 09:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 09:11:25 --> Input Class Initialized
INFO - 2024-01-18 09:11:25 --> Language Class Initialized
INFO - 2024-01-18 09:11:25 --> Loader Class Initialized
INFO - 2024-01-18 09:11:25 --> Helper loaded: url_helper
INFO - 2024-01-18 09:11:25 --> Helper loaded: file_helper
INFO - 2024-01-18 09:11:25 --> Helper loaded: html_helper
INFO - 2024-01-18 09:11:25 --> Helper loaded: text_helper
INFO - 2024-01-18 09:11:25 --> Helper loaded: form_helper
INFO - 2024-01-18 09:11:25 --> Helper loaded: lang_helper
INFO - 2024-01-18 09:11:25 --> Helper loaded: security_helper
INFO - 2024-01-18 09:11:25 --> Helper loaded: cookie_helper
INFO - 2024-01-18 09:11:25 --> Database Driver Class Initialized
INFO - 2024-01-18 09:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 09:11:25 --> Parser Class Initialized
INFO - 2024-01-18 09:11:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 09:11:25 --> Pagination Class Initialized
INFO - 2024-01-18 09:11:25 --> Form Validation Class Initialized
INFO - 2024-01-18 09:11:25 --> Controller Class Initialized
INFO - 2024-01-18 09:11:25 --> Model Class Initialized
DEBUG - 2024-01-18 09:11:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 09:11:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:11:25 --> Model Class Initialized
INFO - 2024-01-18 09:11:25 --> Final output sent to browser
DEBUG - 2024-01-18 09:11:25 --> Total execution time: 0.0201
ERROR - 2024-01-18 09:11:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 09:11:38 --> Config Class Initialized
INFO - 2024-01-18 09:11:38 --> Hooks Class Initialized
DEBUG - 2024-01-18 09:11:38 --> UTF-8 Support Enabled
INFO - 2024-01-18 09:11:38 --> Utf8 Class Initialized
INFO - 2024-01-18 09:11:38 --> URI Class Initialized
INFO - 2024-01-18 09:11:38 --> Router Class Initialized
INFO - 2024-01-18 09:11:38 --> Output Class Initialized
INFO - 2024-01-18 09:11:38 --> Security Class Initialized
DEBUG - 2024-01-18 09:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 09:11:38 --> Input Class Initialized
INFO - 2024-01-18 09:11:38 --> Language Class Initialized
INFO - 2024-01-18 09:11:38 --> Loader Class Initialized
INFO - 2024-01-18 09:11:38 --> Helper loaded: url_helper
INFO - 2024-01-18 09:11:38 --> Helper loaded: file_helper
INFO - 2024-01-18 09:11:38 --> Helper loaded: html_helper
INFO - 2024-01-18 09:11:38 --> Helper loaded: text_helper
INFO - 2024-01-18 09:11:38 --> Helper loaded: form_helper
INFO - 2024-01-18 09:11:38 --> Helper loaded: lang_helper
INFO - 2024-01-18 09:11:38 --> Helper loaded: security_helper
INFO - 2024-01-18 09:11:38 --> Helper loaded: cookie_helper
INFO - 2024-01-18 09:11:38 --> Database Driver Class Initialized
INFO - 2024-01-18 09:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 09:11:38 --> Parser Class Initialized
INFO - 2024-01-18 09:11:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 09:11:38 --> Pagination Class Initialized
INFO - 2024-01-18 09:11:38 --> Form Validation Class Initialized
INFO - 2024-01-18 09:11:38 --> Controller Class Initialized
INFO - 2024-01-18 09:11:38 --> Model Class Initialized
DEBUG - 2024-01-18 09:11:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 09:11:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:11:38 --> Model Class Initialized
DEBUG - 2024-01-18 09:11:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:11:38 --> Model Class Initialized
INFO - 2024-01-18 09:11:38 --> Email Class Initialized
DEBUG - 2024-01-18 09:11:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:11:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-01-18 09:11:38 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-01-18 09:11:38 --> Language file loaded: language/english/email_lang.php
INFO - 2024-01-18 09:11:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-01-18 09:11:38 --> Final output sent to browser
DEBUG - 2024-01-18 09:11:38 --> Total execution time: 0.2419
ERROR - 2024-01-18 09:11:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 09:11:41 --> Config Class Initialized
INFO - 2024-01-18 09:11:41 --> Hooks Class Initialized
DEBUG - 2024-01-18 09:11:41 --> UTF-8 Support Enabled
INFO - 2024-01-18 09:11:41 --> Utf8 Class Initialized
INFO - 2024-01-18 09:11:41 --> URI Class Initialized
INFO - 2024-01-18 09:11:41 --> Router Class Initialized
INFO - 2024-01-18 09:11:41 --> Output Class Initialized
INFO - 2024-01-18 09:11:41 --> Security Class Initialized
DEBUG - 2024-01-18 09:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 09:11:41 --> Input Class Initialized
INFO - 2024-01-18 09:11:41 --> Language Class Initialized
INFO - 2024-01-18 09:11:41 --> Loader Class Initialized
INFO - 2024-01-18 09:11:41 --> Helper loaded: url_helper
INFO - 2024-01-18 09:11:41 --> Helper loaded: file_helper
INFO - 2024-01-18 09:11:41 --> Helper loaded: html_helper
INFO - 2024-01-18 09:11:41 --> Helper loaded: text_helper
INFO - 2024-01-18 09:11:41 --> Helper loaded: form_helper
INFO - 2024-01-18 09:11:41 --> Helper loaded: lang_helper
INFO - 2024-01-18 09:11:41 --> Helper loaded: security_helper
INFO - 2024-01-18 09:11:41 --> Helper loaded: cookie_helper
INFO - 2024-01-18 09:11:41 --> Database Driver Class Initialized
INFO - 2024-01-18 09:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 09:11:41 --> Parser Class Initialized
INFO - 2024-01-18 09:11:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 09:11:41 --> Pagination Class Initialized
INFO - 2024-01-18 09:11:41 --> Form Validation Class Initialized
INFO - 2024-01-18 09:11:41 --> Controller Class Initialized
INFO - 2024-01-18 09:11:41 --> Model Class Initialized
DEBUG - 2024-01-18 09:11:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 09:11:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:11:41 --> Model Class Initialized
DEBUG - 2024-01-18 09:11:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:11:41 --> Model Class Initialized
INFO - 2024-01-18 09:11:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-01-18 09:11:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:11:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 09:11:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 09:11:41 --> Model Class Initialized
INFO - 2024-01-18 09:11:41 --> Model Class Initialized
INFO - 2024-01-18 09:11:41 --> Model Class Initialized
INFO - 2024-01-18 09:11:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 09:11:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 09:11:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 09:11:41 --> Final output sent to browser
DEBUG - 2024-01-18 09:11:41 --> Total execution time: 0.1861
ERROR - 2024-01-18 09:11:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 09:11:43 --> Config Class Initialized
INFO - 2024-01-18 09:11:43 --> Hooks Class Initialized
DEBUG - 2024-01-18 09:11:43 --> UTF-8 Support Enabled
INFO - 2024-01-18 09:11:43 --> Utf8 Class Initialized
INFO - 2024-01-18 09:11:43 --> URI Class Initialized
DEBUG - 2024-01-18 09:11:43 --> No URI present. Default controller set.
INFO - 2024-01-18 09:11:43 --> Router Class Initialized
INFO - 2024-01-18 09:11:43 --> Output Class Initialized
INFO - 2024-01-18 09:11:43 --> Security Class Initialized
DEBUG - 2024-01-18 09:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 09:11:43 --> Input Class Initialized
INFO - 2024-01-18 09:11:43 --> Language Class Initialized
INFO - 2024-01-18 09:11:43 --> Loader Class Initialized
INFO - 2024-01-18 09:11:43 --> Helper loaded: url_helper
INFO - 2024-01-18 09:11:43 --> Helper loaded: file_helper
INFO - 2024-01-18 09:11:43 --> Helper loaded: html_helper
INFO - 2024-01-18 09:11:43 --> Helper loaded: text_helper
INFO - 2024-01-18 09:11:43 --> Helper loaded: form_helper
INFO - 2024-01-18 09:11:43 --> Helper loaded: lang_helper
INFO - 2024-01-18 09:11:43 --> Helper loaded: security_helper
INFO - 2024-01-18 09:11:43 --> Helper loaded: cookie_helper
INFO - 2024-01-18 09:11:43 --> Database Driver Class Initialized
INFO - 2024-01-18 09:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 09:11:43 --> Parser Class Initialized
INFO - 2024-01-18 09:11:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 09:11:43 --> Pagination Class Initialized
INFO - 2024-01-18 09:11:43 --> Form Validation Class Initialized
INFO - 2024-01-18 09:11:43 --> Controller Class Initialized
INFO - 2024-01-18 09:11:43 --> Model Class Initialized
DEBUG - 2024-01-18 09:11:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:11:43 --> Model Class Initialized
DEBUG - 2024-01-18 09:11:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:11:43 --> Model Class Initialized
INFO - 2024-01-18 09:11:43 --> Model Class Initialized
INFO - 2024-01-18 09:11:43 --> Model Class Initialized
INFO - 2024-01-18 09:11:43 --> Model Class Initialized
DEBUG - 2024-01-18 09:11:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 09:11:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:11:43 --> Model Class Initialized
INFO - 2024-01-18 09:11:43 --> Model Class Initialized
INFO - 2024-01-18 09:11:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-18 09:11:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:11:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 09:11:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 09:11:43 --> Model Class Initialized
INFO - 2024-01-18 09:11:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 09:11:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 09:11:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 09:11:43 --> Final output sent to browser
DEBUG - 2024-01-18 09:11:43 --> Total execution time: 0.2382
ERROR - 2024-01-18 09:11:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 09:11:47 --> Config Class Initialized
INFO - 2024-01-18 09:11:47 --> Hooks Class Initialized
DEBUG - 2024-01-18 09:11:47 --> UTF-8 Support Enabled
INFO - 2024-01-18 09:11:47 --> Utf8 Class Initialized
INFO - 2024-01-18 09:11:47 --> URI Class Initialized
INFO - 2024-01-18 09:11:47 --> Router Class Initialized
INFO - 2024-01-18 09:11:47 --> Output Class Initialized
INFO - 2024-01-18 09:11:47 --> Security Class Initialized
DEBUG - 2024-01-18 09:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 09:11:47 --> Input Class Initialized
INFO - 2024-01-18 09:11:47 --> Language Class Initialized
INFO - 2024-01-18 09:11:47 --> Loader Class Initialized
INFO - 2024-01-18 09:11:47 --> Helper loaded: url_helper
INFO - 2024-01-18 09:11:47 --> Helper loaded: file_helper
INFO - 2024-01-18 09:11:47 --> Helper loaded: html_helper
INFO - 2024-01-18 09:11:47 --> Helper loaded: text_helper
INFO - 2024-01-18 09:11:47 --> Helper loaded: form_helper
INFO - 2024-01-18 09:11:47 --> Helper loaded: lang_helper
INFO - 2024-01-18 09:11:47 --> Helper loaded: security_helper
INFO - 2024-01-18 09:11:47 --> Helper loaded: cookie_helper
INFO - 2024-01-18 09:11:47 --> Database Driver Class Initialized
INFO - 2024-01-18 09:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 09:11:47 --> Parser Class Initialized
INFO - 2024-01-18 09:11:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 09:11:47 --> Pagination Class Initialized
INFO - 2024-01-18 09:11:47 --> Form Validation Class Initialized
INFO - 2024-01-18 09:11:47 --> Controller Class Initialized
INFO - 2024-01-18 09:11:47 --> Model Class Initialized
INFO - 2024-01-18 09:11:47 --> Model Class Initialized
INFO - 2024-01-18 09:11:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2024-01-18 09:11:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 09:11:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 09:11:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 09:11:47 --> Model Class Initialized
INFO - 2024-01-18 09:11:47 --> Model Class Initialized
INFO - 2024-01-18 09:11:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 09:11:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 09:11:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 09:11:48 --> Final output sent to browser
DEBUG - 2024-01-18 09:11:48 --> Total execution time: 0.1593
ERROR - 2024-01-18 09:11:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 09:11:48 --> Config Class Initialized
INFO - 2024-01-18 09:11:48 --> Hooks Class Initialized
DEBUG - 2024-01-18 09:11:48 --> UTF-8 Support Enabled
INFO - 2024-01-18 09:11:48 --> Utf8 Class Initialized
INFO - 2024-01-18 09:11:48 --> URI Class Initialized
INFO - 2024-01-18 09:11:48 --> Router Class Initialized
INFO - 2024-01-18 09:11:48 --> Output Class Initialized
INFO - 2024-01-18 09:11:48 --> Security Class Initialized
DEBUG - 2024-01-18 09:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 09:11:48 --> Input Class Initialized
INFO - 2024-01-18 09:11:48 --> Language Class Initialized
INFO - 2024-01-18 09:11:48 --> Loader Class Initialized
INFO - 2024-01-18 09:11:48 --> Helper loaded: url_helper
INFO - 2024-01-18 09:11:48 --> Helper loaded: file_helper
INFO - 2024-01-18 09:11:48 --> Helper loaded: html_helper
INFO - 2024-01-18 09:11:48 --> Helper loaded: text_helper
INFO - 2024-01-18 09:11:48 --> Helper loaded: form_helper
INFO - 2024-01-18 09:11:48 --> Helper loaded: lang_helper
INFO - 2024-01-18 09:11:48 --> Helper loaded: security_helper
INFO - 2024-01-18 09:11:48 --> Helper loaded: cookie_helper
INFO - 2024-01-18 09:11:48 --> Database Driver Class Initialized
INFO - 2024-01-18 09:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 09:11:48 --> Parser Class Initialized
INFO - 2024-01-18 09:11:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 09:11:48 --> Pagination Class Initialized
INFO - 2024-01-18 09:11:48 --> Form Validation Class Initialized
INFO - 2024-01-18 09:11:48 --> Controller Class Initialized
INFO - 2024-01-18 09:11:48 --> Model Class Initialized
INFO - 2024-01-18 09:11:48 --> Model Class Initialized
INFO - 2024-01-18 09:11:48 --> Final output sent to browser
DEBUG - 2024-01-18 09:11:48 --> Total execution time: 0.0795
ERROR - 2024-01-18 10:39:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 10:39:08 --> Config Class Initialized
INFO - 2024-01-18 10:39:08 --> Hooks Class Initialized
DEBUG - 2024-01-18 10:39:08 --> UTF-8 Support Enabled
INFO - 2024-01-18 10:39:08 --> Utf8 Class Initialized
INFO - 2024-01-18 10:39:08 --> URI Class Initialized
DEBUG - 2024-01-18 10:39:08 --> No URI present. Default controller set.
INFO - 2024-01-18 10:39:08 --> Router Class Initialized
INFO - 2024-01-18 10:39:08 --> Output Class Initialized
INFO - 2024-01-18 10:39:08 --> Security Class Initialized
DEBUG - 2024-01-18 10:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 10:39:08 --> Input Class Initialized
INFO - 2024-01-18 10:39:08 --> Language Class Initialized
INFO - 2024-01-18 10:39:08 --> Loader Class Initialized
INFO - 2024-01-18 10:39:08 --> Helper loaded: url_helper
INFO - 2024-01-18 10:39:08 --> Helper loaded: file_helper
INFO - 2024-01-18 10:39:08 --> Helper loaded: html_helper
INFO - 2024-01-18 10:39:08 --> Helper loaded: text_helper
INFO - 2024-01-18 10:39:08 --> Helper loaded: form_helper
INFO - 2024-01-18 10:39:08 --> Helper loaded: lang_helper
INFO - 2024-01-18 10:39:08 --> Helper loaded: security_helper
INFO - 2024-01-18 10:39:08 --> Helper loaded: cookie_helper
INFO - 2024-01-18 10:39:08 --> Database Driver Class Initialized
INFO - 2024-01-18 10:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 10:39:08 --> Parser Class Initialized
INFO - 2024-01-18 10:39:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 10:39:08 --> Pagination Class Initialized
INFO - 2024-01-18 10:39:08 --> Form Validation Class Initialized
INFO - 2024-01-18 10:39:08 --> Controller Class Initialized
INFO - 2024-01-18 10:39:08 --> Model Class Initialized
DEBUG - 2024-01-18 10:39:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-18 10:39:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 10:39:09 --> Config Class Initialized
INFO - 2024-01-18 10:39:09 --> Hooks Class Initialized
DEBUG - 2024-01-18 10:39:09 --> UTF-8 Support Enabled
INFO - 2024-01-18 10:39:09 --> Utf8 Class Initialized
INFO - 2024-01-18 10:39:09 --> URI Class Initialized
INFO - 2024-01-18 10:39:09 --> Router Class Initialized
INFO - 2024-01-18 10:39:09 --> Output Class Initialized
INFO - 2024-01-18 10:39:09 --> Security Class Initialized
DEBUG - 2024-01-18 10:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 10:39:09 --> Input Class Initialized
INFO - 2024-01-18 10:39:09 --> Language Class Initialized
INFO - 2024-01-18 10:39:09 --> Loader Class Initialized
INFO - 2024-01-18 10:39:09 --> Helper loaded: url_helper
INFO - 2024-01-18 10:39:09 --> Helper loaded: file_helper
INFO - 2024-01-18 10:39:09 --> Helper loaded: html_helper
INFO - 2024-01-18 10:39:09 --> Helper loaded: text_helper
INFO - 2024-01-18 10:39:09 --> Helper loaded: form_helper
INFO - 2024-01-18 10:39:09 --> Helper loaded: lang_helper
INFO - 2024-01-18 10:39:09 --> Helper loaded: security_helper
INFO - 2024-01-18 10:39:09 --> Helper loaded: cookie_helper
INFO - 2024-01-18 10:39:09 --> Database Driver Class Initialized
INFO - 2024-01-18 10:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 10:39:09 --> Parser Class Initialized
INFO - 2024-01-18 10:39:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 10:39:09 --> Pagination Class Initialized
INFO - 2024-01-18 10:39:09 --> Form Validation Class Initialized
INFO - 2024-01-18 10:39:09 --> Controller Class Initialized
INFO - 2024-01-18 10:39:09 --> Model Class Initialized
DEBUG - 2024-01-18 10:39:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:39:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-18 10:39:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:39:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 10:39:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 10:39:09 --> Model Class Initialized
INFO - 2024-01-18 10:39:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 10:39:09 --> Final output sent to browser
DEBUG - 2024-01-18 10:39:09 --> Total execution time: 0.0323
ERROR - 2024-01-18 10:39:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 10:39:12 --> Config Class Initialized
INFO - 2024-01-18 10:39:12 --> Hooks Class Initialized
DEBUG - 2024-01-18 10:39:12 --> UTF-8 Support Enabled
INFO - 2024-01-18 10:39:12 --> Utf8 Class Initialized
INFO - 2024-01-18 10:39:12 --> URI Class Initialized
INFO - 2024-01-18 10:39:12 --> Router Class Initialized
INFO - 2024-01-18 10:39:12 --> Output Class Initialized
INFO - 2024-01-18 10:39:12 --> Security Class Initialized
DEBUG - 2024-01-18 10:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 10:39:12 --> Input Class Initialized
INFO - 2024-01-18 10:39:12 --> Language Class Initialized
INFO - 2024-01-18 10:39:12 --> Loader Class Initialized
INFO - 2024-01-18 10:39:12 --> Helper loaded: url_helper
INFO - 2024-01-18 10:39:12 --> Helper loaded: file_helper
INFO - 2024-01-18 10:39:12 --> Helper loaded: html_helper
INFO - 2024-01-18 10:39:12 --> Helper loaded: text_helper
INFO - 2024-01-18 10:39:12 --> Helper loaded: form_helper
INFO - 2024-01-18 10:39:12 --> Helper loaded: lang_helper
INFO - 2024-01-18 10:39:12 --> Helper loaded: security_helper
INFO - 2024-01-18 10:39:12 --> Helper loaded: cookie_helper
INFO - 2024-01-18 10:39:12 --> Database Driver Class Initialized
INFO - 2024-01-18 10:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 10:39:12 --> Parser Class Initialized
INFO - 2024-01-18 10:39:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 10:39:12 --> Pagination Class Initialized
INFO - 2024-01-18 10:39:12 --> Form Validation Class Initialized
INFO - 2024-01-18 10:39:12 --> Controller Class Initialized
INFO - 2024-01-18 10:39:12 --> Model Class Initialized
DEBUG - 2024-01-18 10:39:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:39:12 --> Model Class Initialized
INFO - 2024-01-18 10:39:12 --> Final output sent to browser
DEBUG - 2024-01-18 10:39:12 --> Total execution time: 0.0208
ERROR - 2024-01-18 10:39:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 10:39:13 --> Config Class Initialized
INFO - 2024-01-18 10:39:13 --> Hooks Class Initialized
DEBUG - 2024-01-18 10:39:13 --> UTF-8 Support Enabled
INFO - 2024-01-18 10:39:13 --> Utf8 Class Initialized
INFO - 2024-01-18 10:39:13 --> URI Class Initialized
DEBUG - 2024-01-18 10:39:13 --> No URI present. Default controller set.
INFO - 2024-01-18 10:39:13 --> Router Class Initialized
INFO - 2024-01-18 10:39:13 --> Output Class Initialized
INFO - 2024-01-18 10:39:13 --> Security Class Initialized
DEBUG - 2024-01-18 10:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 10:39:13 --> Input Class Initialized
INFO - 2024-01-18 10:39:13 --> Language Class Initialized
INFO - 2024-01-18 10:39:13 --> Loader Class Initialized
INFO - 2024-01-18 10:39:13 --> Helper loaded: url_helper
INFO - 2024-01-18 10:39:13 --> Helper loaded: file_helper
INFO - 2024-01-18 10:39:13 --> Helper loaded: html_helper
INFO - 2024-01-18 10:39:13 --> Helper loaded: text_helper
INFO - 2024-01-18 10:39:13 --> Helper loaded: form_helper
INFO - 2024-01-18 10:39:13 --> Helper loaded: lang_helper
INFO - 2024-01-18 10:39:13 --> Helper loaded: security_helper
INFO - 2024-01-18 10:39:13 --> Helper loaded: cookie_helper
INFO - 2024-01-18 10:39:13 --> Database Driver Class Initialized
INFO - 2024-01-18 10:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 10:39:13 --> Parser Class Initialized
INFO - 2024-01-18 10:39:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 10:39:13 --> Pagination Class Initialized
INFO - 2024-01-18 10:39:13 --> Form Validation Class Initialized
INFO - 2024-01-18 10:39:13 --> Controller Class Initialized
INFO - 2024-01-18 10:39:13 --> Model Class Initialized
DEBUG - 2024-01-18 10:39:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:39:13 --> Model Class Initialized
DEBUG - 2024-01-18 10:39:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:39:13 --> Model Class Initialized
INFO - 2024-01-18 10:39:13 --> Model Class Initialized
INFO - 2024-01-18 10:39:13 --> Model Class Initialized
INFO - 2024-01-18 10:39:13 --> Model Class Initialized
DEBUG - 2024-01-18 10:39:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 10:39:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:39:13 --> Model Class Initialized
INFO - 2024-01-18 10:39:13 --> Model Class Initialized
INFO - 2024-01-18 10:39:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-18 10:39:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:39:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 10:39:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 10:39:13 --> Model Class Initialized
INFO - 2024-01-18 10:39:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 10:39:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 10:39:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 10:39:13 --> Final output sent to browser
DEBUG - 2024-01-18 10:39:13 --> Total execution time: 0.3925
ERROR - 2024-01-18 10:39:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 10:39:13 --> Config Class Initialized
INFO - 2024-01-18 10:39:13 --> Hooks Class Initialized
DEBUG - 2024-01-18 10:39:13 --> UTF-8 Support Enabled
INFO - 2024-01-18 10:39:13 --> Utf8 Class Initialized
INFO - 2024-01-18 10:39:13 --> URI Class Initialized
INFO - 2024-01-18 10:39:13 --> Router Class Initialized
INFO - 2024-01-18 10:39:13 --> Output Class Initialized
INFO - 2024-01-18 10:39:13 --> Security Class Initialized
DEBUG - 2024-01-18 10:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 10:39:13 --> Input Class Initialized
INFO - 2024-01-18 10:39:13 --> Language Class Initialized
INFO - 2024-01-18 10:39:13 --> Loader Class Initialized
INFO - 2024-01-18 10:39:13 --> Helper loaded: url_helper
INFO - 2024-01-18 10:39:13 --> Helper loaded: file_helper
INFO - 2024-01-18 10:39:13 --> Helper loaded: html_helper
INFO - 2024-01-18 10:39:13 --> Helper loaded: text_helper
INFO - 2024-01-18 10:39:13 --> Helper loaded: form_helper
INFO - 2024-01-18 10:39:13 --> Helper loaded: lang_helper
INFO - 2024-01-18 10:39:13 --> Helper loaded: security_helper
INFO - 2024-01-18 10:39:13 --> Helper loaded: cookie_helper
INFO - 2024-01-18 10:39:13 --> Database Driver Class Initialized
INFO - 2024-01-18 10:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 10:39:13 --> Parser Class Initialized
INFO - 2024-01-18 10:39:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 10:39:13 --> Pagination Class Initialized
INFO - 2024-01-18 10:39:13 --> Form Validation Class Initialized
INFO - 2024-01-18 10:39:13 --> Controller Class Initialized
DEBUG - 2024-01-18 10:39:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 10:39:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:39:13 --> Model Class Initialized
INFO - 2024-01-18 10:39:13 --> Final output sent to browser
DEBUG - 2024-01-18 10:39:13 --> Total execution time: 0.0133
ERROR - 2024-01-18 10:39:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 10:39:17 --> Config Class Initialized
INFO - 2024-01-18 10:39:17 --> Hooks Class Initialized
DEBUG - 2024-01-18 10:39:17 --> UTF-8 Support Enabled
INFO - 2024-01-18 10:39:17 --> Utf8 Class Initialized
INFO - 2024-01-18 10:39:17 --> URI Class Initialized
INFO - 2024-01-18 10:39:17 --> Router Class Initialized
INFO - 2024-01-18 10:39:17 --> Output Class Initialized
INFO - 2024-01-18 10:39:17 --> Security Class Initialized
DEBUG - 2024-01-18 10:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 10:39:17 --> Input Class Initialized
INFO - 2024-01-18 10:39:17 --> Language Class Initialized
INFO - 2024-01-18 10:39:17 --> Loader Class Initialized
INFO - 2024-01-18 10:39:17 --> Helper loaded: url_helper
INFO - 2024-01-18 10:39:17 --> Helper loaded: file_helper
INFO - 2024-01-18 10:39:17 --> Helper loaded: html_helper
INFO - 2024-01-18 10:39:17 --> Helper loaded: text_helper
INFO - 2024-01-18 10:39:17 --> Helper loaded: form_helper
INFO - 2024-01-18 10:39:17 --> Helper loaded: lang_helper
INFO - 2024-01-18 10:39:17 --> Helper loaded: security_helper
INFO - 2024-01-18 10:39:17 --> Helper loaded: cookie_helper
INFO - 2024-01-18 10:39:17 --> Database Driver Class Initialized
INFO - 2024-01-18 10:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 10:39:17 --> Parser Class Initialized
INFO - 2024-01-18 10:39:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 10:39:17 --> Pagination Class Initialized
INFO - 2024-01-18 10:39:17 --> Form Validation Class Initialized
INFO - 2024-01-18 10:39:17 --> Controller Class Initialized
DEBUG - 2024-01-18 10:39:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 10:39:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:39:17 --> Model Class Initialized
INFO - 2024-01-18 10:39:17 --> Model Class Initialized
DEBUG - 2024-01-18 10:39:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 10:39:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:39:17 --> Model Class Initialized
DEBUG - 2024-01-18 10:39:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:39:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gst/list.php
DEBUG - 2024-01-18 10:39:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:39:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 10:39:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 10:39:17 --> Model Class Initialized
INFO - 2024-01-18 10:39:17 --> Model Class Initialized
INFO - 2024-01-18 10:39:17 --> Model Class Initialized
INFO - 2024-01-18 10:39:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 10:39:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 10:39:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 10:39:17 --> Final output sent to browser
DEBUG - 2024-01-18 10:39:17 --> Total execution time: 0.2053
ERROR - 2024-01-18 10:39:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 10:39:34 --> Config Class Initialized
INFO - 2024-01-18 10:39:34 --> Hooks Class Initialized
DEBUG - 2024-01-18 10:39:34 --> UTF-8 Support Enabled
INFO - 2024-01-18 10:39:34 --> Utf8 Class Initialized
INFO - 2024-01-18 10:39:34 --> URI Class Initialized
INFO - 2024-01-18 10:39:34 --> Router Class Initialized
INFO - 2024-01-18 10:39:34 --> Output Class Initialized
INFO - 2024-01-18 10:39:34 --> Security Class Initialized
DEBUG - 2024-01-18 10:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 10:39:34 --> Input Class Initialized
INFO - 2024-01-18 10:39:34 --> Language Class Initialized
INFO - 2024-01-18 10:39:34 --> Loader Class Initialized
INFO - 2024-01-18 10:39:34 --> Helper loaded: url_helper
INFO - 2024-01-18 10:39:34 --> Helper loaded: file_helper
INFO - 2024-01-18 10:39:34 --> Helper loaded: html_helper
INFO - 2024-01-18 10:39:34 --> Helper loaded: text_helper
INFO - 2024-01-18 10:39:34 --> Helper loaded: form_helper
INFO - 2024-01-18 10:39:34 --> Helper loaded: lang_helper
INFO - 2024-01-18 10:39:34 --> Helper loaded: security_helper
INFO - 2024-01-18 10:39:34 --> Helper loaded: cookie_helper
INFO - 2024-01-18 10:39:34 --> Database Driver Class Initialized
INFO - 2024-01-18 10:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 10:39:34 --> Parser Class Initialized
INFO - 2024-01-18 10:39:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 10:39:34 --> Pagination Class Initialized
INFO - 2024-01-18 10:39:34 --> Form Validation Class Initialized
INFO - 2024-01-18 10:39:34 --> Controller Class Initialized
DEBUG - 2024-01-18 10:39:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 10:39:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:39:34 --> Model Class Initialized
DEBUG - 2024-01-18 10:39:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 10:39:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:39:34 --> Model Class Initialized
DEBUG - 2024-01-18 10:39:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:39:34 --> Model Class Initialized
INFO - 2024-01-18 10:39:34 --> Final output sent to browser
DEBUG - 2024-01-18 10:39:34 --> Total execution time: 0.0175
ERROR - 2024-01-18 10:39:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 10:39:50 --> Config Class Initialized
INFO - 2024-01-18 10:39:50 --> Hooks Class Initialized
DEBUG - 2024-01-18 10:39:50 --> UTF-8 Support Enabled
INFO - 2024-01-18 10:39:50 --> Utf8 Class Initialized
INFO - 2024-01-18 10:39:50 --> URI Class Initialized
INFO - 2024-01-18 10:39:50 --> Router Class Initialized
INFO - 2024-01-18 10:39:50 --> Output Class Initialized
INFO - 2024-01-18 10:39:50 --> Security Class Initialized
DEBUG - 2024-01-18 10:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 10:39:50 --> Input Class Initialized
INFO - 2024-01-18 10:39:50 --> Language Class Initialized
INFO - 2024-01-18 10:39:50 --> Loader Class Initialized
INFO - 2024-01-18 10:39:50 --> Helper loaded: url_helper
INFO - 2024-01-18 10:39:50 --> Helper loaded: file_helper
INFO - 2024-01-18 10:39:50 --> Helper loaded: html_helper
INFO - 2024-01-18 10:39:50 --> Helper loaded: text_helper
INFO - 2024-01-18 10:39:50 --> Helper loaded: form_helper
INFO - 2024-01-18 10:39:50 --> Helper loaded: lang_helper
INFO - 2024-01-18 10:39:50 --> Helper loaded: security_helper
INFO - 2024-01-18 10:39:50 --> Helper loaded: cookie_helper
INFO - 2024-01-18 10:39:50 --> Database Driver Class Initialized
INFO - 2024-01-18 10:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 10:39:50 --> Parser Class Initialized
INFO - 2024-01-18 10:39:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 10:39:50 --> Pagination Class Initialized
INFO - 2024-01-18 10:39:50 --> Form Validation Class Initialized
INFO - 2024-01-18 10:39:50 --> Controller Class Initialized
DEBUG - 2024-01-18 10:39:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 10:39:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:39:50 --> Model Class Initialized
DEBUG - 2024-01-18 10:39:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 10:39:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:39:50 --> Model Class Initialized
DEBUG - 2024-01-18 10:39:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:39:50 --> Model Class Initialized
INFO - 2024-01-18 10:39:50 --> Final output sent to browser
DEBUG - 2024-01-18 10:39:50 --> Total execution time: 0.0193
ERROR - 2024-01-18 10:40:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 10:40:30 --> Config Class Initialized
INFO - 2024-01-18 10:40:30 --> Hooks Class Initialized
DEBUG - 2024-01-18 10:40:30 --> UTF-8 Support Enabled
INFO - 2024-01-18 10:40:30 --> Utf8 Class Initialized
INFO - 2024-01-18 10:40:30 --> URI Class Initialized
INFO - 2024-01-18 10:40:30 --> Router Class Initialized
INFO - 2024-01-18 10:40:30 --> Output Class Initialized
INFO - 2024-01-18 10:40:30 --> Security Class Initialized
DEBUG - 2024-01-18 10:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 10:40:30 --> Input Class Initialized
INFO - 2024-01-18 10:40:30 --> Language Class Initialized
INFO - 2024-01-18 10:40:30 --> Loader Class Initialized
INFO - 2024-01-18 10:40:30 --> Helper loaded: url_helper
INFO - 2024-01-18 10:40:30 --> Helper loaded: file_helper
INFO - 2024-01-18 10:40:30 --> Helper loaded: html_helper
INFO - 2024-01-18 10:40:30 --> Helper loaded: text_helper
INFO - 2024-01-18 10:40:30 --> Helper loaded: form_helper
INFO - 2024-01-18 10:40:30 --> Helper loaded: lang_helper
INFO - 2024-01-18 10:40:30 --> Helper loaded: security_helper
INFO - 2024-01-18 10:40:30 --> Helper loaded: cookie_helper
INFO - 2024-01-18 10:40:30 --> Database Driver Class Initialized
INFO - 2024-01-18 10:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 10:40:30 --> Parser Class Initialized
INFO - 2024-01-18 10:40:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 10:40:30 --> Pagination Class Initialized
INFO - 2024-01-18 10:40:30 --> Form Validation Class Initialized
INFO - 2024-01-18 10:40:30 --> Controller Class Initialized
DEBUG - 2024-01-18 10:40:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 10:40:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:40:30 --> Model Class Initialized
DEBUG - 2024-01-18 10:40:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 10:40:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:40:30 --> Model Class Initialized
DEBUG - 2024-01-18 10:40:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:40:30 --> Model Class Initialized
INFO - 2024-01-18 10:40:30 --> Final output sent to browser
DEBUG - 2024-01-18 10:40:30 --> Total execution time: 0.0181
ERROR - 2024-01-18 10:41:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 10:41:10 --> Config Class Initialized
INFO - 2024-01-18 10:41:10 --> Hooks Class Initialized
DEBUG - 2024-01-18 10:41:10 --> UTF-8 Support Enabled
INFO - 2024-01-18 10:41:10 --> Utf8 Class Initialized
INFO - 2024-01-18 10:41:10 --> URI Class Initialized
INFO - 2024-01-18 10:41:10 --> Router Class Initialized
INFO - 2024-01-18 10:41:10 --> Output Class Initialized
INFO - 2024-01-18 10:41:10 --> Security Class Initialized
DEBUG - 2024-01-18 10:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 10:41:10 --> Input Class Initialized
INFO - 2024-01-18 10:41:10 --> Language Class Initialized
INFO - 2024-01-18 10:41:10 --> Loader Class Initialized
INFO - 2024-01-18 10:41:10 --> Helper loaded: url_helper
INFO - 2024-01-18 10:41:10 --> Helper loaded: file_helper
INFO - 2024-01-18 10:41:10 --> Helper loaded: html_helper
INFO - 2024-01-18 10:41:10 --> Helper loaded: text_helper
INFO - 2024-01-18 10:41:10 --> Helper loaded: form_helper
INFO - 2024-01-18 10:41:10 --> Helper loaded: lang_helper
INFO - 2024-01-18 10:41:10 --> Helper loaded: security_helper
INFO - 2024-01-18 10:41:10 --> Helper loaded: cookie_helper
INFO - 2024-01-18 10:41:10 --> Database Driver Class Initialized
INFO - 2024-01-18 10:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 10:41:10 --> Parser Class Initialized
INFO - 2024-01-18 10:41:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 10:41:10 --> Pagination Class Initialized
INFO - 2024-01-18 10:41:10 --> Form Validation Class Initialized
INFO - 2024-01-18 10:41:10 --> Controller Class Initialized
DEBUG - 2024-01-18 10:41:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 10:41:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:41:10 --> Model Class Initialized
DEBUG - 2024-01-18 10:41:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 10:41:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:41:10 --> Model Class Initialized
DEBUG - 2024-01-18 10:41:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:41:10 --> Model Class Initialized
INFO - 2024-01-18 10:41:10 --> Final output sent to browser
DEBUG - 2024-01-18 10:41:10 --> Total execution time: 0.0336
ERROR - 2024-01-18 10:41:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 10:41:16 --> Config Class Initialized
INFO - 2024-01-18 10:41:16 --> Hooks Class Initialized
DEBUG - 2024-01-18 10:41:16 --> UTF-8 Support Enabled
INFO - 2024-01-18 10:41:16 --> Utf8 Class Initialized
INFO - 2024-01-18 10:41:16 --> URI Class Initialized
INFO - 2024-01-18 10:41:16 --> Router Class Initialized
INFO - 2024-01-18 10:41:16 --> Output Class Initialized
INFO - 2024-01-18 10:41:16 --> Security Class Initialized
DEBUG - 2024-01-18 10:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 10:41:16 --> Input Class Initialized
INFO - 2024-01-18 10:41:16 --> Language Class Initialized
INFO - 2024-01-18 10:41:16 --> Loader Class Initialized
INFO - 2024-01-18 10:41:16 --> Helper loaded: url_helper
INFO - 2024-01-18 10:41:16 --> Helper loaded: file_helper
INFO - 2024-01-18 10:41:16 --> Helper loaded: html_helper
INFO - 2024-01-18 10:41:16 --> Helper loaded: text_helper
INFO - 2024-01-18 10:41:16 --> Helper loaded: form_helper
INFO - 2024-01-18 10:41:16 --> Helper loaded: lang_helper
INFO - 2024-01-18 10:41:16 --> Helper loaded: security_helper
INFO - 2024-01-18 10:41:16 --> Helper loaded: cookie_helper
INFO - 2024-01-18 10:41:16 --> Database Driver Class Initialized
INFO - 2024-01-18 10:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 10:41:16 --> Parser Class Initialized
INFO - 2024-01-18 10:41:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 10:41:16 --> Pagination Class Initialized
INFO - 2024-01-18 10:41:16 --> Form Validation Class Initialized
INFO - 2024-01-18 10:41:16 --> Controller Class Initialized
DEBUG - 2024-01-18 10:41:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 10:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:41:16 --> Model Class Initialized
DEBUG - 2024-01-18 10:41:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 10:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:41:16 --> Model Class Initialized
DEBUG - 2024-01-18 10:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:41:16 --> Model Class Initialized
INFO - 2024-01-18 10:41:16 --> Final output sent to browser
DEBUG - 2024-01-18 10:41:16 --> Total execution time: 0.0351
ERROR - 2024-01-18 10:41:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 10:41:24 --> Config Class Initialized
INFO - 2024-01-18 10:41:24 --> Hooks Class Initialized
DEBUG - 2024-01-18 10:41:24 --> UTF-8 Support Enabled
INFO - 2024-01-18 10:41:24 --> Utf8 Class Initialized
INFO - 2024-01-18 10:41:24 --> URI Class Initialized
INFO - 2024-01-18 10:41:24 --> Router Class Initialized
INFO - 2024-01-18 10:41:24 --> Output Class Initialized
INFO - 2024-01-18 10:41:24 --> Security Class Initialized
DEBUG - 2024-01-18 10:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 10:41:24 --> Input Class Initialized
INFO - 2024-01-18 10:41:24 --> Language Class Initialized
INFO - 2024-01-18 10:41:24 --> Loader Class Initialized
INFO - 2024-01-18 10:41:24 --> Helper loaded: url_helper
INFO - 2024-01-18 10:41:24 --> Helper loaded: file_helper
INFO - 2024-01-18 10:41:24 --> Helper loaded: html_helper
INFO - 2024-01-18 10:41:24 --> Helper loaded: text_helper
INFO - 2024-01-18 10:41:24 --> Helper loaded: form_helper
INFO - 2024-01-18 10:41:24 --> Helper loaded: lang_helper
INFO - 2024-01-18 10:41:24 --> Helper loaded: security_helper
INFO - 2024-01-18 10:41:24 --> Helper loaded: cookie_helper
INFO - 2024-01-18 10:41:24 --> Database Driver Class Initialized
INFO - 2024-01-18 10:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 10:41:24 --> Parser Class Initialized
INFO - 2024-01-18 10:41:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 10:41:24 --> Pagination Class Initialized
INFO - 2024-01-18 10:41:24 --> Form Validation Class Initialized
INFO - 2024-01-18 10:41:24 --> Controller Class Initialized
DEBUG - 2024-01-18 10:41:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 10:41:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:41:24 --> Model Class Initialized
DEBUG - 2024-01-18 10:41:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 10:41:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:41:24 --> Model Class Initialized
DEBUG - 2024-01-18 10:41:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 10:41:24 --> Model Class Initialized
INFO - 2024-01-18 10:41:24 --> Final output sent to browser
DEBUG - 2024-01-18 10:41:24 --> Total execution time: 0.0364
ERROR - 2024-01-18 11:13:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:13:34 --> Config Class Initialized
INFO - 2024-01-18 11:13:34 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:13:34 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:13:34 --> Utf8 Class Initialized
INFO - 2024-01-18 11:13:34 --> URI Class Initialized
DEBUG - 2024-01-18 11:13:34 --> No URI present. Default controller set.
INFO - 2024-01-18 11:13:34 --> Router Class Initialized
INFO - 2024-01-18 11:13:34 --> Output Class Initialized
INFO - 2024-01-18 11:13:34 --> Security Class Initialized
DEBUG - 2024-01-18 11:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:13:34 --> Input Class Initialized
INFO - 2024-01-18 11:13:34 --> Language Class Initialized
INFO - 2024-01-18 11:13:34 --> Loader Class Initialized
INFO - 2024-01-18 11:13:34 --> Helper loaded: url_helper
INFO - 2024-01-18 11:13:34 --> Helper loaded: file_helper
INFO - 2024-01-18 11:13:34 --> Helper loaded: html_helper
INFO - 2024-01-18 11:13:34 --> Helper loaded: text_helper
INFO - 2024-01-18 11:13:34 --> Helper loaded: form_helper
INFO - 2024-01-18 11:13:34 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:13:34 --> Helper loaded: security_helper
INFO - 2024-01-18 11:13:34 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:13:34 --> Database Driver Class Initialized
INFO - 2024-01-18 11:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:13:34 --> Parser Class Initialized
INFO - 2024-01-18 11:13:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:13:34 --> Pagination Class Initialized
INFO - 2024-01-18 11:13:34 --> Form Validation Class Initialized
INFO - 2024-01-18 11:13:34 --> Controller Class Initialized
INFO - 2024-01-18 11:13:34 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:34 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:34 --> Model Class Initialized
INFO - 2024-01-18 11:13:34 --> Model Class Initialized
INFO - 2024-01-18 11:13:34 --> Model Class Initialized
INFO - 2024-01-18 11:13:34 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:13:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:34 --> Model Class Initialized
INFO - 2024-01-18 11:13:34 --> Model Class Initialized
INFO - 2024-01-18 11:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-18 11:13:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 11:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 11:13:34 --> Model Class Initialized
INFO - 2024-01-18 11:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 11:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 11:13:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 11:13:34 --> Final output sent to browser
DEBUG - 2024-01-18 11:13:34 --> Total execution time: 0.4173
ERROR - 2024-01-18 11:13:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:13:37 --> Config Class Initialized
INFO - 2024-01-18 11:13:37 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:13:37 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:13:37 --> Utf8 Class Initialized
INFO - 2024-01-18 11:13:37 --> URI Class Initialized
DEBUG - 2024-01-18 11:13:37 --> No URI present. Default controller set.
INFO - 2024-01-18 11:13:37 --> Router Class Initialized
INFO - 2024-01-18 11:13:37 --> Output Class Initialized
INFO - 2024-01-18 11:13:37 --> Security Class Initialized
DEBUG - 2024-01-18 11:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:13:37 --> Input Class Initialized
INFO - 2024-01-18 11:13:37 --> Language Class Initialized
INFO - 2024-01-18 11:13:37 --> Loader Class Initialized
INFO - 2024-01-18 11:13:37 --> Helper loaded: url_helper
INFO - 2024-01-18 11:13:37 --> Helper loaded: file_helper
INFO - 2024-01-18 11:13:37 --> Helper loaded: html_helper
INFO - 2024-01-18 11:13:37 --> Helper loaded: text_helper
INFO - 2024-01-18 11:13:37 --> Helper loaded: form_helper
INFO - 2024-01-18 11:13:37 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:13:37 --> Helper loaded: security_helper
INFO - 2024-01-18 11:13:37 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:13:37 --> Database Driver Class Initialized
INFO - 2024-01-18 11:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:13:37 --> Parser Class Initialized
INFO - 2024-01-18 11:13:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:13:37 --> Pagination Class Initialized
INFO - 2024-01-18 11:13:37 --> Form Validation Class Initialized
INFO - 2024-01-18 11:13:37 --> Controller Class Initialized
INFO - 2024-01-18 11:13:37 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:37 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:37 --> Model Class Initialized
INFO - 2024-01-18 11:13:37 --> Model Class Initialized
INFO - 2024-01-18 11:13:37 --> Model Class Initialized
INFO - 2024-01-18 11:13:37 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:13:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:37 --> Model Class Initialized
INFO - 2024-01-18 11:13:37 --> Model Class Initialized
INFO - 2024-01-18 11:13:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-18 11:13:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 11:13:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 11:13:37 --> Model Class Initialized
INFO - 2024-01-18 11:13:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 11:13:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 11:13:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 11:13:37 --> Final output sent to browser
DEBUG - 2024-01-18 11:13:37 --> Total execution time: 0.4070
ERROR - 2024-01-18 11:13:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:13:43 --> Config Class Initialized
INFO - 2024-01-18 11:13:43 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:13:43 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:13:43 --> Utf8 Class Initialized
INFO - 2024-01-18 11:13:43 --> URI Class Initialized
INFO - 2024-01-18 11:13:43 --> Router Class Initialized
INFO - 2024-01-18 11:13:43 --> Output Class Initialized
INFO - 2024-01-18 11:13:43 --> Security Class Initialized
DEBUG - 2024-01-18 11:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:13:43 --> Input Class Initialized
INFO - 2024-01-18 11:13:43 --> Language Class Initialized
INFO - 2024-01-18 11:13:43 --> Loader Class Initialized
INFO - 2024-01-18 11:13:43 --> Helper loaded: url_helper
INFO - 2024-01-18 11:13:43 --> Helper loaded: file_helper
INFO - 2024-01-18 11:13:43 --> Helper loaded: html_helper
INFO - 2024-01-18 11:13:43 --> Helper loaded: text_helper
INFO - 2024-01-18 11:13:43 --> Helper loaded: form_helper
INFO - 2024-01-18 11:13:43 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:13:43 --> Helper loaded: security_helper
INFO - 2024-01-18 11:13:43 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:13:43 --> Database Driver Class Initialized
INFO - 2024-01-18 11:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:13:43 --> Parser Class Initialized
INFO - 2024-01-18 11:13:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:13:43 --> Pagination Class Initialized
INFO - 2024-01-18 11:13:43 --> Form Validation Class Initialized
INFO - 2024-01-18 11:13:43 --> Controller Class Initialized
INFO - 2024-01-18 11:13:43 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:13:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:43 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:43 --> Model Class Initialized
INFO - 2024-01-18 11:13:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-18 11:13:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 11:13:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 11:13:43 --> Model Class Initialized
INFO - 2024-01-18 11:13:43 --> Model Class Initialized
INFO - 2024-01-18 11:13:43 --> Model Class Initialized
INFO - 2024-01-18 11:13:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 11:13:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 11:13:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 11:13:43 --> Final output sent to browser
DEBUG - 2024-01-18 11:13:43 --> Total execution time: 0.2119
ERROR - 2024-01-18 11:13:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:13:44 --> Config Class Initialized
INFO - 2024-01-18 11:13:44 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:13:44 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:13:44 --> Utf8 Class Initialized
INFO - 2024-01-18 11:13:44 --> URI Class Initialized
INFO - 2024-01-18 11:13:44 --> Router Class Initialized
INFO - 2024-01-18 11:13:44 --> Output Class Initialized
INFO - 2024-01-18 11:13:44 --> Security Class Initialized
DEBUG - 2024-01-18 11:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:13:44 --> Input Class Initialized
INFO - 2024-01-18 11:13:44 --> Language Class Initialized
INFO - 2024-01-18 11:13:44 --> Loader Class Initialized
INFO - 2024-01-18 11:13:44 --> Helper loaded: url_helper
INFO - 2024-01-18 11:13:44 --> Helper loaded: file_helper
INFO - 2024-01-18 11:13:44 --> Helper loaded: html_helper
INFO - 2024-01-18 11:13:44 --> Helper loaded: text_helper
INFO - 2024-01-18 11:13:44 --> Helper loaded: form_helper
INFO - 2024-01-18 11:13:44 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:13:44 --> Helper loaded: security_helper
INFO - 2024-01-18 11:13:44 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:13:44 --> Database Driver Class Initialized
INFO - 2024-01-18 11:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:13:44 --> Parser Class Initialized
INFO - 2024-01-18 11:13:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:13:44 --> Pagination Class Initialized
INFO - 2024-01-18 11:13:44 --> Form Validation Class Initialized
INFO - 2024-01-18 11:13:44 --> Controller Class Initialized
INFO - 2024-01-18 11:13:44 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:13:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:44 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:44 --> Model Class Initialized
INFO - 2024-01-18 11:13:44 --> Final output sent to browser
DEBUG - 2024-01-18 11:13:44 --> Total execution time: 0.0630
ERROR - 2024-01-18 11:13:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:13:51 --> Config Class Initialized
INFO - 2024-01-18 11:13:51 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:13:51 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:13:51 --> Utf8 Class Initialized
INFO - 2024-01-18 11:13:51 --> URI Class Initialized
INFO - 2024-01-18 11:13:51 --> Router Class Initialized
INFO - 2024-01-18 11:13:51 --> Output Class Initialized
INFO - 2024-01-18 11:13:51 --> Security Class Initialized
DEBUG - 2024-01-18 11:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:13:51 --> Input Class Initialized
INFO - 2024-01-18 11:13:51 --> Language Class Initialized
INFO - 2024-01-18 11:13:51 --> Loader Class Initialized
INFO - 2024-01-18 11:13:51 --> Helper loaded: url_helper
INFO - 2024-01-18 11:13:51 --> Helper loaded: file_helper
INFO - 2024-01-18 11:13:51 --> Helper loaded: html_helper
INFO - 2024-01-18 11:13:51 --> Helper loaded: text_helper
INFO - 2024-01-18 11:13:51 --> Helper loaded: form_helper
INFO - 2024-01-18 11:13:51 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:13:51 --> Helper loaded: security_helper
INFO - 2024-01-18 11:13:51 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:13:51 --> Database Driver Class Initialized
INFO - 2024-01-18 11:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:13:51 --> Parser Class Initialized
INFO - 2024-01-18 11:13:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:13:51 --> Pagination Class Initialized
INFO - 2024-01-18 11:13:51 --> Form Validation Class Initialized
INFO - 2024-01-18 11:13:51 --> Controller Class Initialized
INFO - 2024-01-18 11:13:51 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:13:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:51 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:51 --> Model Class Initialized
INFO - 2024-01-18 11:13:51 --> Final output sent to browser
DEBUG - 2024-01-18 11:13:51 --> Total execution time: 0.0642
ERROR - 2024-01-18 11:13:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:13:52 --> Config Class Initialized
INFO - 2024-01-18 11:13:52 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:13:52 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:13:52 --> Utf8 Class Initialized
INFO - 2024-01-18 11:13:52 --> URI Class Initialized
INFO - 2024-01-18 11:13:52 --> Router Class Initialized
INFO - 2024-01-18 11:13:52 --> Output Class Initialized
INFO - 2024-01-18 11:13:52 --> Security Class Initialized
DEBUG - 2024-01-18 11:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:13:52 --> Input Class Initialized
INFO - 2024-01-18 11:13:52 --> Language Class Initialized
INFO - 2024-01-18 11:13:52 --> Loader Class Initialized
INFO - 2024-01-18 11:13:52 --> Helper loaded: url_helper
INFO - 2024-01-18 11:13:52 --> Helper loaded: file_helper
INFO - 2024-01-18 11:13:52 --> Helper loaded: html_helper
INFO - 2024-01-18 11:13:52 --> Helper loaded: text_helper
INFO - 2024-01-18 11:13:52 --> Helper loaded: form_helper
INFO - 2024-01-18 11:13:52 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:13:52 --> Helper loaded: security_helper
INFO - 2024-01-18 11:13:52 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:13:52 --> Database Driver Class Initialized
INFO - 2024-01-18 11:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:13:52 --> Parser Class Initialized
INFO - 2024-01-18 11:13:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:13:52 --> Pagination Class Initialized
INFO - 2024-01-18 11:13:52 --> Form Validation Class Initialized
INFO - 2024-01-18 11:13:52 --> Controller Class Initialized
INFO - 2024-01-18 11:13:52 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:13:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:52 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:52 --> Model Class Initialized
INFO - 2024-01-18 11:13:52 --> Final output sent to browser
DEBUG - 2024-01-18 11:13:52 --> Total execution time: 0.0640
ERROR - 2024-01-18 11:13:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:13:52 --> Config Class Initialized
INFO - 2024-01-18 11:13:52 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:13:52 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:13:52 --> Utf8 Class Initialized
INFO - 2024-01-18 11:13:52 --> URI Class Initialized
INFO - 2024-01-18 11:13:52 --> Router Class Initialized
INFO - 2024-01-18 11:13:52 --> Output Class Initialized
INFO - 2024-01-18 11:13:52 --> Security Class Initialized
DEBUG - 2024-01-18 11:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:13:52 --> Input Class Initialized
INFO - 2024-01-18 11:13:52 --> Language Class Initialized
INFO - 2024-01-18 11:13:52 --> Loader Class Initialized
INFO - 2024-01-18 11:13:52 --> Helper loaded: url_helper
INFO - 2024-01-18 11:13:52 --> Helper loaded: file_helper
INFO - 2024-01-18 11:13:52 --> Helper loaded: html_helper
INFO - 2024-01-18 11:13:52 --> Helper loaded: text_helper
INFO - 2024-01-18 11:13:52 --> Helper loaded: form_helper
INFO - 2024-01-18 11:13:52 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:13:52 --> Helper loaded: security_helper
INFO - 2024-01-18 11:13:52 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:13:52 --> Database Driver Class Initialized
INFO - 2024-01-18 11:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:13:52 --> Parser Class Initialized
INFO - 2024-01-18 11:13:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:13:52 --> Pagination Class Initialized
INFO - 2024-01-18 11:13:52 --> Form Validation Class Initialized
INFO - 2024-01-18 11:13:52 --> Controller Class Initialized
INFO - 2024-01-18 11:13:52 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:13:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:52 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:52 --> Model Class Initialized
INFO - 2024-01-18 11:13:52 --> Final output sent to browser
DEBUG - 2024-01-18 11:13:52 --> Total execution time: 0.0690
ERROR - 2024-01-18 11:13:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:13:53 --> Config Class Initialized
INFO - 2024-01-18 11:13:53 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:13:53 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:13:53 --> Utf8 Class Initialized
INFO - 2024-01-18 11:13:53 --> URI Class Initialized
INFO - 2024-01-18 11:13:53 --> Router Class Initialized
INFO - 2024-01-18 11:13:53 --> Output Class Initialized
INFO - 2024-01-18 11:13:53 --> Security Class Initialized
DEBUG - 2024-01-18 11:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:13:53 --> Input Class Initialized
INFO - 2024-01-18 11:13:53 --> Language Class Initialized
INFO - 2024-01-18 11:13:53 --> Loader Class Initialized
INFO - 2024-01-18 11:13:53 --> Helper loaded: url_helper
INFO - 2024-01-18 11:13:53 --> Helper loaded: file_helper
INFO - 2024-01-18 11:13:53 --> Helper loaded: html_helper
INFO - 2024-01-18 11:13:53 --> Helper loaded: text_helper
INFO - 2024-01-18 11:13:53 --> Helper loaded: form_helper
INFO - 2024-01-18 11:13:53 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:13:53 --> Helper loaded: security_helper
INFO - 2024-01-18 11:13:53 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:13:53 --> Database Driver Class Initialized
INFO - 2024-01-18 11:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:13:53 --> Parser Class Initialized
INFO - 2024-01-18 11:13:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:13:53 --> Pagination Class Initialized
INFO - 2024-01-18 11:13:53 --> Form Validation Class Initialized
INFO - 2024-01-18 11:13:53 --> Controller Class Initialized
INFO - 2024-01-18 11:13:53 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:13:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:53 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:53 --> Model Class Initialized
INFO - 2024-01-18 11:13:53 --> Final output sent to browser
DEBUG - 2024-01-18 11:13:53 --> Total execution time: 0.0668
ERROR - 2024-01-18 11:13:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:13:53 --> Config Class Initialized
INFO - 2024-01-18 11:13:53 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:13:53 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:13:53 --> Utf8 Class Initialized
INFO - 2024-01-18 11:13:53 --> URI Class Initialized
INFO - 2024-01-18 11:13:53 --> Router Class Initialized
INFO - 2024-01-18 11:13:53 --> Output Class Initialized
INFO - 2024-01-18 11:13:53 --> Security Class Initialized
DEBUG - 2024-01-18 11:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:13:53 --> Input Class Initialized
INFO - 2024-01-18 11:13:53 --> Language Class Initialized
INFO - 2024-01-18 11:13:53 --> Loader Class Initialized
INFO - 2024-01-18 11:13:53 --> Helper loaded: url_helper
INFO - 2024-01-18 11:13:53 --> Helper loaded: file_helper
INFO - 2024-01-18 11:13:53 --> Helper loaded: html_helper
INFO - 2024-01-18 11:13:53 --> Helper loaded: text_helper
INFO - 2024-01-18 11:13:53 --> Helper loaded: form_helper
INFO - 2024-01-18 11:13:53 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:13:53 --> Helper loaded: security_helper
INFO - 2024-01-18 11:13:53 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:13:53 --> Database Driver Class Initialized
INFO - 2024-01-18 11:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:13:53 --> Parser Class Initialized
INFO - 2024-01-18 11:13:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:13:53 --> Pagination Class Initialized
INFO - 2024-01-18 11:13:53 --> Form Validation Class Initialized
INFO - 2024-01-18 11:13:53 --> Controller Class Initialized
INFO - 2024-01-18 11:13:53 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:13:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:53 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:53 --> Model Class Initialized
INFO - 2024-01-18 11:13:53 --> Final output sent to browser
DEBUG - 2024-01-18 11:13:53 --> Total execution time: 0.0581
ERROR - 2024-01-18 11:13:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:13:54 --> Config Class Initialized
INFO - 2024-01-18 11:13:54 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:13:54 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:13:54 --> Utf8 Class Initialized
INFO - 2024-01-18 11:13:54 --> URI Class Initialized
INFO - 2024-01-18 11:13:54 --> Router Class Initialized
INFO - 2024-01-18 11:13:54 --> Output Class Initialized
INFO - 2024-01-18 11:13:54 --> Security Class Initialized
DEBUG - 2024-01-18 11:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:13:54 --> Input Class Initialized
INFO - 2024-01-18 11:13:54 --> Language Class Initialized
INFO - 2024-01-18 11:13:54 --> Loader Class Initialized
INFO - 2024-01-18 11:13:54 --> Helper loaded: url_helper
INFO - 2024-01-18 11:13:54 --> Helper loaded: file_helper
INFO - 2024-01-18 11:13:54 --> Helper loaded: html_helper
INFO - 2024-01-18 11:13:54 --> Helper loaded: text_helper
INFO - 2024-01-18 11:13:54 --> Helper loaded: form_helper
INFO - 2024-01-18 11:13:54 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:13:54 --> Helper loaded: security_helper
INFO - 2024-01-18 11:13:54 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:13:54 --> Database Driver Class Initialized
INFO - 2024-01-18 11:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:13:54 --> Parser Class Initialized
INFO - 2024-01-18 11:13:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:13:54 --> Pagination Class Initialized
INFO - 2024-01-18 11:13:54 --> Form Validation Class Initialized
INFO - 2024-01-18 11:13:54 --> Controller Class Initialized
INFO - 2024-01-18 11:13:54 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:13:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:54 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:54 --> Model Class Initialized
INFO - 2024-01-18 11:13:54 --> Final output sent to browser
DEBUG - 2024-01-18 11:13:54 --> Total execution time: 0.0573
ERROR - 2024-01-18 11:13:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:13:54 --> Config Class Initialized
INFO - 2024-01-18 11:13:54 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:13:54 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:13:54 --> Utf8 Class Initialized
INFO - 2024-01-18 11:13:54 --> URI Class Initialized
INFO - 2024-01-18 11:13:54 --> Router Class Initialized
INFO - 2024-01-18 11:13:54 --> Output Class Initialized
INFO - 2024-01-18 11:13:54 --> Security Class Initialized
DEBUG - 2024-01-18 11:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:13:54 --> Input Class Initialized
INFO - 2024-01-18 11:13:54 --> Language Class Initialized
INFO - 2024-01-18 11:13:54 --> Loader Class Initialized
INFO - 2024-01-18 11:13:54 --> Helper loaded: url_helper
INFO - 2024-01-18 11:13:54 --> Helper loaded: file_helper
INFO - 2024-01-18 11:13:54 --> Helper loaded: html_helper
INFO - 2024-01-18 11:13:54 --> Helper loaded: text_helper
INFO - 2024-01-18 11:13:54 --> Helper loaded: form_helper
INFO - 2024-01-18 11:13:54 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:13:54 --> Helper loaded: security_helper
INFO - 2024-01-18 11:13:54 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:13:54 --> Database Driver Class Initialized
INFO - 2024-01-18 11:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:13:54 --> Parser Class Initialized
INFO - 2024-01-18 11:13:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:13:54 --> Pagination Class Initialized
INFO - 2024-01-18 11:13:54 --> Form Validation Class Initialized
INFO - 2024-01-18 11:13:54 --> Controller Class Initialized
INFO - 2024-01-18 11:13:54 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:13:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:54 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:54 --> Model Class Initialized
INFO - 2024-01-18 11:13:55 --> Final output sent to browser
DEBUG - 2024-01-18 11:13:55 --> Total execution time: 0.0539
ERROR - 2024-01-18 11:13:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:13:55 --> Config Class Initialized
INFO - 2024-01-18 11:13:55 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:13:55 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:13:55 --> Utf8 Class Initialized
INFO - 2024-01-18 11:13:55 --> URI Class Initialized
INFO - 2024-01-18 11:13:55 --> Router Class Initialized
INFO - 2024-01-18 11:13:55 --> Output Class Initialized
INFO - 2024-01-18 11:13:55 --> Security Class Initialized
DEBUG - 2024-01-18 11:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:13:55 --> Input Class Initialized
INFO - 2024-01-18 11:13:55 --> Language Class Initialized
INFO - 2024-01-18 11:13:55 --> Loader Class Initialized
INFO - 2024-01-18 11:13:55 --> Helper loaded: url_helper
INFO - 2024-01-18 11:13:55 --> Helper loaded: file_helper
INFO - 2024-01-18 11:13:55 --> Helper loaded: html_helper
INFO - 2024-01-18 11:13:55 --> Helper loaded: text_helper
INFO - 2024-01-18 11:13:55 --> Helper loaded: form_helper
INFO - 2024-01-18 11:13:55 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:13:55 --> Helper loaded: security_helper
INFO - 2024-01-18 11:13:55 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:13:55 --> Database Driver Class Initialized
INFO - 2024-01-18 11:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:13:55 --> Parser Class Initialized
INFO - 2024-01-18 11:13:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:13:55 --> Pagination Class Initialized
INFO - 2024-01-18 11:13:55 --> Form Validation Class Initialized
INFO - 2024-01-18 11:13:55 --> Controller Class Initialized
INFO - 2024-01-18 11:13:55 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:13:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:55 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:55 --> Model Class Initialized
INFO - 2024-01-18 11:13:55 --> Final output sent to browser
DEBUG - 2024-01-18 11:13:55 --> Total execution time: 0.0227
ERROR - 2024-01-18 11:13:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:13:56 --> Config Class Initialized
INFO - 2024-01-18 11:13:56 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:13:56 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:13:56 --> Utf8 Class Initialized
INFO - 2024-01-18 11:13:56 --> URI Class Initialized
INFO - 2024-01-18 11:13:56 --> Router Class Initialized
INFO - 2024-01-18 11:13:56 --> Output Class Initialized
INFO - 2024-01-18 11:13:56 --> Security Class Initialized
DEBUG - 2024-01-18 11:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:13:56 --> Input Class Initialized
INFO - 2024-01-18 11:13:56 --> Language Class Initialized
INFO - 2024-01-18 11:13:56 --> Loader Class Initialized
INFO - 2024-01-18 11:13:56 --> Helper loaded: url_helper
INFO - 2024-01-18 11:13:56 --> Helper loaded: file_helper
INFO - 2024-01-18 11:13:56 --> Helper loaded: html_helper
INFO - 2024-01-18 11:13:56 --> Helper loaded: text_helper
INFO - 2024-01-18 11:13:56 --> Helper loaded: form_helper
INFO - 2024-01-18 11:13:56 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:13:56 --> Helper loaded: security_helper
INFO - 2024-01-18 11:13:56 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:13:56 --> Database Driver Class Initialized
INFO - 2024-01-18 11:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:13:56 --> Parser Class Initialized
INFO - 2024-01-18 11:13:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:13:56 --> Pagination Class Initialized
INFO - 2024-01-18 11:13:56 --> Form Validation Class Initialized
INFO - 2024-01-18 11:13:56 --> Controller Class Initialized
INFO - 2024-01-18 11:13:56 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:13:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:56 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:56 --> Model Class Initialized
INFO - 2024-01-18 11:13:56 --> Final output sent to browser
DEBUG - 2024-01-18 11:13:56 --> Total execution time: 0.0263
ERROR - 2024-01-18 11:13:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:13:58 --> Config Class Initialized
INFO - 2024-01-18 11:13:58 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:13:58 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:13:58 --> Utf8 Class Initialized
INFO - 2024-01-18 11:13:58 --> URI Class Initialized
INFO - 2024-01-18 11:13:58 --> Router Class Initialized
INFO - 2024-01-18 11:13:58 --> Output Class Initialized
INFO - 2024-01-18 11:13:58 --> Security Class Initialized
DEBUG - 2024-01-18 11:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:13:58 --> Input Class Initialized
INFO - 2024-01-18 11:13:58 --> Language Class Initialized
INFO - 2024-01-18 11:13:58 --> Loader Class Initialized
INFO - 2024-01-18 11:13:58 --> Helper loaded: url_helper
INFO - 2024-01-18 11:13:58 --> Helper loaded: file_helper
INFO - 2024-01-18 11:13:58 --> Helper loaded: html_helper
INFO - 2024-01-18 11:13:58 --> Helper loaded: text_helper
INFO - 2024-01-18 11:13:58 --> Helper loaded: form_helper
INFO - 2024-01-18 11:13:58 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:13:58 --> Helper loaded: security_helper
INFO - 2024-01-18 11:13:58 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:13:58 --> Database Driver Class Initialized
INFO - 2024-01-18 11:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:13:58 --> Parser Class Initialized
INFO - 2024-01-18 11:13:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:13:58 --> Pagination Class Initialized
INFO - 2024-01-18 11:13:58 --> Form Validation Class Initialized
INFO - 2024-01-18 11:13:58 --> Controller Class Initialized
INFO - 2024-01-18 11:13:58 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:13:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:58 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:58 --> Model Class Initialized
INFO - 2024-01-18 11:13:58 --> Final output sent to browser
DEBUG - 2024-01-18 11:13:58 --> Total execution time: 0.0226
ERROR - 2024-01-18 11:13:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:13:59 --> Config Class Initialized
INFO - 2024-01-18 11:13:59 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:13:59 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:13:59 --> Utf8 Class Initialized
INFO - 2024-01-18 11:13:59 --> URI Class Initialized
INFO - 2024-01-18 11:13:59 --> Router Class Initialized
INFO - 2024-01-18 11:13:59 --> Output Class Initialized
INFO - 2024-01-18 11:13:59 --> Security Class Initialized
DEBUG - 2024-01-18 11:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:13:59 --> Input Class Initialized
INFO - 2024-01-18 11:13:59 --> Language Class Initialized
INFO - 2024-01-18 11:13:59 --> Loader Class Initialized
INFO - 2024-01-18 11:13:59 --> Helper loaded: url_helper
INFO - 2024-01-18 11:13:59 --> Helper loaded: file_helper
INFO - 2024-01-18 11:13:59 --> Helper loaded: html_helper
INFO - 2024-01-18 11:13:59 --> Helper loaded: text_helper
INFO - 2024-01-18 11:13:59 --> Helper loaded: form_helper
INFO - 2024-01-18 11:13:59 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:13:59 --> Helper loaded: security_helper
INFO - 2024-01-18 11:13:59 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:13:59 --> Database Driver Class Initialized
INFO - 2024-01-18 11:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:13:59 --> Parser Class Initialized
INFO - 2024-01-18 11:13:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:13:59 --> Pagination Class Initialized
INFO - 2024-01-18 11:13:59 --> Form Validation Class Initialized
INFO - 2024-01-18 11:13:59 --> Controller Class Initialized
INFO - 2024-01-18 11:13:59 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:13:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:59 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:59 --> Model Class Initialized
INFO - 2024-01-18 11:13:59 --> Final output sent to browser
DEBUG - 2024-01-18 11:13:59 --> Total execution time: 0.0237
ERROR - 2024-01-18 11:13:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:13:59 --> Config Class Initialized
INFO - 2024-01-18 11:13:59 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:13:59 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:13:59 --> Utf8 Class Initialized
INFO - 2024-01-18 11:13:59 --> URI Class Initialized
INFO - 2024-01-18 11:13:59 --> Router Class Initialized
INFO - 2024-01-18 11:13:59 --> Output Class Initialized
INFO - 2024-01-18 11:13:59 --> Security Class Initialized
DEBUG - 2024-01-18 11:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:13:59 --> Input Class Initialized
INFO - 2024-01-18 11:13:59 --> Language Class Initialized
INFO - 2024-01-18 11:13:59 --> Loader Class Initialized
INFO - 2024-01-18 11:13:59 --> Helper loaded: url_helper
INFO - 2024-01-18 11:13:59 --> Helper loaded: file_helper
INFO - 2024-01-18 11:13:59 --> Helper loaded: html_helper
INFO - 2024-01-18 11:13:59 --> Helper loaded: text_helper
INFO - 2024-01-18 11:13:59 --> Helper loaded: form_helper
INFO - 2024-01-18 11:13:59 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:13:59 --> Helper loaded: security_helper
INFO - 2024-01-18 11:13:59 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:13:59 --> Database Driver Class Initialized
INFO - 2024-01-18 11:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:13:59 --> Parser Class Initialized
INFO - 2024-01-18 11:13:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:13:59 --> Pagination Class Initialized
INFO - 2024-01-18 11:13:59 --> Form Validation Class Initialized
INFO - 2024-01-18 11:13:59 --> Controller Class Initialized
INFO - 2024-01-18 11:13:59 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:13:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:59 --> Model Class Initialized
DEBUG - 2024-01-18 11:13:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:13:59 --> Model Class Initialized
INFO - 2024-01-18 11:13:59 --> Final output sent to browser
DEBUG - 2024-01-18 11:13:59 --> Total execution time: 0.0241
ERROR - 2024-01-18 11:14:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:14:00 --> Config Class Initialized
INFO - 2024-01-18 11:14:00 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:14:00 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:14:00 --> Utf8 Class Initialized
INFO - 2024-01-18 11:14:00 --> URI Class Initialized
INFO - 2024-01-18 11:14:00 --> Router Class Initialized
INFO - 2024-01-18 11:14:00 --> Output Class Initialized
INFO - 2024-01-18 11:14:00 --> Security Class Initialized
DEBUG - 2024-01-18 11:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:14:00 --> Input Class Initialized
INFO - 2024-01-18 11:14:00 --> Language Class Initialized
INFO - 2024-01-18 11:14:00 --> Loader Class Initialized
INFO - 2024-01-18 11:14:00 --> Helper loaded: url_helper
INFO - 2024-01-18 11:14:00 --> Helper loaded: file_helper
INFO - 2024-01-18 11:14:00 --> Helper loaded: html_helper
INFO - 2024-01-18 11:14:00 --> Helper loaded: text_helper
INFO - 2024-01-18 11:14:00 --> Helper loaded: form_helper
INFO - 2024-01-18 11:14:00 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:14:00 --> Helper loaded: security_helper
INFO - 2024-01-18 11:14:00 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:14:00 --> Database Driver Class Initialized
INFO - 2024-01-18 11:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:14:00 --> Parser Class Initialized
INFO - 2024-01-18 11:14:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:14:00 --> Pagination Class Initialized
INFO - 2024-01-18 11:14:00 --> Form Validation Class Initialized
INFO - 2024-01-18 11:14:00 --> Controller Class Initialized
INFO - 2024-01-18 11:14:00 --> Model Class Initialized
DEBUG - 2024-01-18 11:14:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:14:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:14:00 --> Model Class Initialized
DEBUG - 2024-01-18 11:14:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:14:00 --> Model Class Initialized
INFO - 2024-01-18 11:14:00 --> Final output sent to browser
DEBUG - 2024-01-18 11:14:00 --> Total execution time: 0.0556
ERROR - 2024-01-18 11:14:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:14:03 --> Config Class Initialized
INFO - 2024-01-18 11:14:03 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:14:03 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:14:03 --> Utf8 Class Initialized
INFO - 2024-01-18 11:14:03 --> URI Class Initialized
INFO - 2024-01-18 11:14:03 --> Router Class Initialized
INFO - 2024-01-18 11:14:03 --> Output Class Initialized
INFO - 2024-01-18 11:14:03 --> Security Class Initialized
DEBUG - 2024-01-18 11:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:14:03 --> Input Class Initialized
INFO - 2024-01-18 11:14:03 --> Language Class Initialized
INFO - 2024-01-18 11:14:03 --> Loader Class Initialized
INFO - 2024-01-18 11:14:03 --> Helper loaded: url_helper
INFO - 2024-01-18 11:14:03 --> Helper loaded: file_helper
INFO - 2024-01-18 11:14:03 --> Helper loaded: html_helper
INFO - 2024-01-18 11:14:03 --> Helper loaded: text_helper
INFO - 2024-01-18 11:14:03 --> Helper loaded: form_helper
INFO - 2024-01-18 11:14:03 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:14:03 --> Helper loaded: security_helper
INFO - 2024-01-18 11:14:03 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:14:03 --> Database Driver Class Initialized
INFO - 2024-01-18 11:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:14:03 --> Parser Class Initialized
INFO - 2024-01-18 11:14:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:14:03 --> Pagination Class Initialized
INFO - 2024-01-18 11:14:03 --> Form Validation Class Initialized
INFO - 2024-01-18 11:14:03 --> Controller Class Initialized
INFO - 2024-01-18 11:14:03 --> Model Class Initialized
DEBUG - 2024-01-18 11:14:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:14:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:14:03 --> Model Class Initialized
DEBUG - 2024-01-18 11:14:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:14:03 --> Model Class Initialized
INFO - 2024-01-18 11:14:03 --> Final output sent to browser
DEBUG - 2024-01-18 11:14:03 --> Total execution time: 0.0563
ERROR - 2024-01-18 11:14:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:14:04 --> Config Class Initialized
INFO - 2024-01-18 11:14:04 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:14:04 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:14:04 --> Utf8 Class Initialized
INFO - 2024-01-18 11:14:04 --> URI Class Initialized
INFO - 2024-01-18 11:14:04 --> Router Class Initialized
INFO - 2024-01-18 11:14:04 --> Output Class Initialized
INFO - 2024-01-18 11:14:04 --> Security Class Initialized
DEBUG - 2024-01-18 11:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:14:04 --> Input Class Initialized
INFO - 2024-01-18 11:14:04 --> Language Class Initialized
INFO - 2024-01-18 11:14:04 --> Loader Class Initialized
INFO - 2024-01-18 11:14:04 --> Helper loaded: url_helper
INFO - 2024-01-18 11:14:04 --> Helper loaded: file_helper
INFO - 2024-01-18 11:14:04 --> Helper loaded: html_helper
INFO - 2024-01-18 11:14:04 --> Helper loaded: text_helper
INFO - 2024-01-18 11:14:04 --> Helper loaded: form_helper
INFO - 2024-01-18 11:14:04 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:14:04 --> Helper loaded: security_helper
INFO - 2024-01-18 11:14:04 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:14:04 --> Database Driver Class Initialized
INFO - 2024-01-18 11:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:14:04 --> Parser Class Initialized
INFO - 2024-01-18 11:14:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:14:04 --> Pagination Class Initialized
INFO - 2024-01-18 11:14:04 --> Form Validation Class Initialized
INFO - 2024-01-18 11:14:04 --> Controller Class Initialized
INFO - 2024-01-18 11:14:04 --> Model Class Initialized
DEBUG - 2024-01-18 11:14:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:14:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:14:04 --> Model Class Initialized
DEBUG - 2024-01-18 11:14:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:14:04 --> Model Class Initialized
INFO - 2024-01-18 11:14:04 --> Final output sent to browser
DEBUG - 2024-01-18 11:14:04 --> Total execution time: 0.0598
ERROR - 2024-01-18 11:14:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:14:05 --> Config Class Initialized
INFO - 2024-01-18 11:14:05 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:14:05 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:14:05 --> Utf8 Class Initialized
INFO - 2024-01-18 11:14:05 --> URI Class Initialized
INFO - 2024-01-18 11:14:05 --> Router Class Initialized
INFO - 2024-01-18 11:14:05 --> Output Class Initialized
INFO - 2024-01-18 11:14:05 --> Security Class Initialized
DEBUG - 2024-01-18 11:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:14:05 --> Input Class Initialized
INFO - 2024-01-18 11:14:05 --> Language Class Initialized
INFO - 2024-01-18 11:14:05 --> Loader Class Initialized
INFO - 2024-01-18 11:14:05 --> Helper loaded: url_helper
INFO - 2024-01-18 11:14:05 --> Helper loaded: file_helper
INFO - 2024-01-18 11:14:05 --> Helper loaded: html_helper
INFO - 2024-01-18 11:14:05 --> Helper loaded: text_helper
INFO - 2024-01-18 11:14:05 --> Helper loaded: form_helper
INFO - 2024-01-18 11:14:05 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:14:05 --> Helper loaded: security_helper
INFO - 2024-01-18 11:14:05 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:14:05 --> Database Driver Class Initialized
INFO - 2024-01-18 11:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:14:05 --> Parser Class Initialized
INFO - 2024-01-18 11:14:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:14:05 --> Pagination Class Initialized
INFO - 2024-01-18 11:14:05 --> Form Validation Class Initialized
INFO - 2024-01-18 11:14:05 --> Controller Class Initialized
INFO - 2024-01-18 11:14:05 --> Model Class Initialized
DEBUG - 2024-01-18 11:14:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:14:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:14:05 --> Model Class Initialized
DEBUG - 2024-01-18 11:14:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:14:05 --> Model Class Initialized
INFO - 2024-01-18 11:14:05 --> Final output sent to browser
DEBUG - 2024-01-18 11:14:05 --> Total execution time: 0.0574
ERROR - 2024-01-18 11:14:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:14:05 --> Config Class Initialized
INFO - 2024-01-18 11:14:05 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:14:05 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:14:05 --> Utf8 Class Initialized
INFO - 2024-01-18 11:14:05 --> URI Class Initialized
INFO - 2024-01-18 11:14:05 --> Router Class Initialized
INFO - 2024-01-18 11:14:05 --> Output Class Initialized
INFO - 2024-01-18 11:14:05 --> Security Class Initialized
DEBUG - 2024-01-18 11:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:14:05 --> Input Class Initialized
INFO - 2024-01-18 11:14:05 --> Language Class Initialized
INFO - 2024-01-18 11:14:05 --> Loader Class Initialized
INFO - 2024-01-18 11:14:05 --> Helper loaded: url_helper
INFO - 2024-01-18 11:14:05 --> Helper loaded: file_helper
INFO - 2024-01-18 11:14:05 --> Helper loaded: html_helper
INFO - 2024-01-18 11:14:05 --> Helper loaded: text_helper
INFO - 2024-01-18 11:14:05 --> Helper loaded: form_helper
INFO - 2024-01-18 11:14:05 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:14:05 --> Helper loaded: security_helper
INFO - 2024-01-18 11:14:05 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:14:05 --> Database Driver Class Initialized
INFO - 2024-01-18 11:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:14:05 --> Parser Class Initialized
INFO - 2024-01-18 11:14:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:14:05 --> Pagination Class Initialized
INFO - 2024-01-18 11:14:05 --> Form Validation Class Initialized
INFO - 2024-01-18 11:14:05 --> Controller Class Initialized
INFO - 2024-01-18 11:14:05 --> Model Class Initialized
DEBUG - 2024-01-18 11:14:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:14:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:14:05 --> Model Class Initialized
DEBUG - 2024-01-18 11:14:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:14:05 --> Model Class Initialized
INFO - 2024-01-18 11:14:05 --> Final output sent to browser
DEBUG - 2024-01-18 11:14:05 --> Total execution time: 0.0551
ERROR - 2024-01-18 11:14:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:14:13 --> Config Class Initialized
INFO - 2024-01-18 11:14:13 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:14:13 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:14:13 --> Utf8 Class Initialized
INFO - 2024-01-18 11:14:13 --> URI Class Initialized
INFO - 2024-01-18 11:14:13 --> Router Class Initialized
INFO - 2024-01-18 11:14:13 --> Output Class Initialized
INFO - 2024-01-18 11:14:13 --> Security Class Initialized
DEBUG - 2024-01-18 11:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:14:13 --> Input Class Initialized
INFO - 2024-01-18 11:14:13 --> Language Class Initialized
INFO - 2024-01-18 11:14:13 --> Loader Class Initialized
INFO - 2024-01-18 11:14:13 --> Helper loaded: url_helper
INFO - 2024-01-18 11:14:13 --> Helper loaded: file_helper
INFO - 2024-01-18 11:14:13 --> Helper loaded: html_helper
INFO - 2024-01-18 11:14:13 --> Helper loaded: text_helper
INFO - 2024-01-18 11:14:13 --> Helper loaded: form_helper
INFO - 2024-01-18 11:14:13 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:14:13 --> Helper loaded: security_helper
INFO - 2024-01-18 11:14:13 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:14:13 --> Database Driver Class Initialized
INFO - 2024-01-18 11:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:14:13 --> Parser Class Initialized
INFO - 2024-01-18 11:14:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:14:13 --> Pagination Class Initialized
INFO - 2024-01-18 11:14:13 --> Form Validation Class Initialized
INFO - 2024-01-18 11:14:13 --> Controller Class Initialized
INFO - 2024-01-18 11:14:13 --> Model Class Initialized
DEBUG - 2024-01-18 11:14:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:14:13 --> Model Class Initialized
DEBUG - 2024-01-18 11:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:14:13 --> Model Class Initialized
INFO - 2024-01-18 11:14:13 --> Final output sent to browser
DEBUG - 2024-01-18 11:14:13 --> Total execution time: 0.0650
ERROR - 2024-01-18 11:15:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:15:01 --> Config Class Initialized
INFO - 2024-01-18 11:15:01 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:15:01 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:15:01 --> Utf8 Class Initialized
INFO - 2024-01-18 11:15:01 --> URI Class Initialized
INFO - 2024-01-18 11:15:01 --> Router Class Initialized
INFO - 2024-01-18 11:15:01 --> Output Class Initialized
INFO - 2024-01-18 11:15:01 --> Security Class Initialized
DEBUG - 2024-01-18 11:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:15:01 --> Input Class Initialized
INFO - 2024-01-18 11:15:01 --> Language Class Initialized
INFO - 2024-01-18 11:15:02 --> Loader Class Initialized
INFO - 2024-01-18 11:15:02 --> Helper loaded: url_helper
INFO - 2024-01-18 11:15:02 --> Helper loaded: file_helper
INFO - 2024-01-18 11:15:02 --> Helper loaded: html_helper
INFO - 2024-01-18 11:15:02 --> Helper loaded: text_helper
INFO - 2024-01-18 11:15:02 --> Helper loaded: form_helper
INFO - 2024-01-18 11:15:02 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:15:02 --> Helper loaded: security_helper
INFO - 2024-01-18 11:15:02 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:15:02 --> Database Driver Class Initialized
INFO - 2024-01-18 11:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:15:02 --> Parser Class Initialized
INFO - 2024-01-18 11:15:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:15:02 --> Pagination Class Initialized
INFO - 2024-01-18 11:15:02 --> Form Validation Class Initialized
INFO - 2024-01-18 11:15:02 --> Controller Class Initialized
INFO - 2024-01-18 11:15:02 --> Model Class Initialized
DEBUG - 2024-01-18 11:15:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:15:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:15:02 --> Model Class Initialized
DEBUG - 2024-01-18 11:15:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:15:02 --> Model Class Initialized
DEBUG - 2024-01-18 11:15:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:15:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-18 11:15:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:15:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 11:15:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 11:15:02 --> Model Class Initialized
INFO - 2024-01-18 11:15:02 --> Model Class Initialized
INFO - 2024-01-18 11:15:02 --> Model Class Initialized
INFO - 2024-01-18 11:15:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 11:15:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 11:15:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 11:15:02 --> Final output sent to browser
DEBUG - 2024-01-18 11:15:02 --> Total execution time: 0.2889
ERROR - 2024-01-18 11:15:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:15:14 --> Config Class Initialized
INFO - 2024-01-18 11:15:14 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:15:14 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:15:14 --> Utf8 Class Initialized
INFO - 2024-01-18 11:15:14 --> URI Class Initialized
INFO - 2024-01-18 11:15:14 --> Router Class Initialized
INFO - 2024-01-18 11:15:14 --> Output Class Initialized
INFO - 2024-01-18 11:15:14 --> Security Class Initialized
DEBUG - 2024-01-18 11:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:15:14 --> Input Class Initialized
INFO - 2024-01-18 11:15:14 --> Language Class Initialized
INFO - 2024-01-18 11:15:14 --> Loader Class Initialized
INFO - 2024-01-18 11:15:14 --> Helper loaded: url_helper
INFO - 2024-01-18 11:15:14 --> Helper loaded: file_helper
INFO - 2024-01-18 11:15:14 --> Helper loaded: html_helper
INFO - 2024-01-18 11:15:14 --> Helper loaded: text_helper
INFO - 2024-01-18 11:15:14 --> Helper loaded: form_helper
INFO - 2024-01-18 11:15:14 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:15:14 --> Helper loaded: security_helper
INFO - 2024-01-18 11:15:14 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:15:14 --> Database Driver Class Initialized
INFO - 2024-01-18 11:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:15:14 --> Parser Class Initialized
INFO - 2024-01-18 11:15:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:15:14 --> Pagination Class Initialized
INFO - 2024-01-18 11:15:14 --> Form Validation Class Initialized
INFO - 2024-01-18 11:15:14 --> Controller Class Initialized
INFO - 2024-01-18 11:15:14 --> Model Class Initialized
DEBUG - 2024-01-18 11:15:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:15:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:15:14 --> Model Class Initialized
DEBUG - 2024-01-18 11:15:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:15:14 --> Model Class Initialized
INFO - 2024-01-18 11:15:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-18 11:15:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:15:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 11:15:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 11:15:14 --> Model Class Initialized
INFO - 2024-01-18 11:15:14 --> Model Class Initialized
INFO - 2024-01-18 11:15:14 --> Model Class Initialized
INFO - 2024-01-18 11:15:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 11:15:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 11:15:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 11:15:15 --> Final output sent to browser
DEBUG - 2024-01-18 11:15:15 --> Total execution time: 0.2328
ERROR - 2024-01-18 11:15:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:15:15 --> Config Class Initialized
INFO - 2024-01-18 11:15:15 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:15:15 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:15:15 --> Utf8 Class Initialized
INFO - 2024-01-18 11:15:15 --> URI Class Initialized
INFO - 2024-01-18 11:15:15 --> Router Class Initialized
INFO - 2024-01-18 11:15:15 --> Output Class Initialized
INFO - 2024-01-18 11:15:15 --> Security Class Initialized
DEBUG - 2024-01-18 11:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:15:15 --> Input Class Initialized
INFO - 2024-01-18 11:15:15 --> Language Class Initialized
INFO - 2024-01-18 11:15:15 --> Loader Class Initialized
INFO - 2024-01-18 11:15:15 --> Helper loaded: url_helper
INFO - 2024-01-18 11:15:15 --> Helper loaded: file_helper
INFO - 2024-01-18 11:15:15 --> Helper loaded: html_helper
INFO - 2024-01-18 11:15:15 --> Helper loaded: text_helper
INFO - 2024-01-18 11:15:15 --> Helper loaded: form_helper
INFO - 2024-01-18 11:15:15 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:15:15 --> Helper loaded: security_helper
INFO - 2024-01-18 11:15:15 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:15:15 --> Database Driver Class Initialized
INFO - 2024-01-18 11:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:15:15 --> Parser Class Initialized
INFO - 2024-01-18 11:15:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:15:15 --> Pagination Class Initialized
INFO - 2024-01-18 11:15:15 --> Form Validation Class Initialized
INFO - 2024-01-18 11:15:15 --> Controller Class Initialized
INFO - 2024-01-18 11:15:15 --> Model Class Initialized
DEBUG - 2024-01-18 11:15:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:15:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:15:15 --> Model Class Initialized
DEBUG - 2024-01-18 11:15:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:15:15 --> Model Class Initialized
INFO - 2024-01-18 11:15:15 --> Final output sent to browser
DEBUG - 2024-01-18 11:15:15 --> Total execution time: 0.0564
ERROR - 2024-01-18 11:15:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:15:18 --> Config Class Initialized
INFO - 2024-01-18 11:15:18 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:15:18 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:15:18 --> Utf8 Class Initialized
INFO - 2024-01-18 11:15:18 --> URI Class Initialized
INFO - 2024-01-18 11:15:18 --> Router Class Initialized
INFO - 2024-01-18 11:15:18 --> Output Class Initialized
INFO - 2024-01-18 11:15:18 --> Security Class Initialized
DEBUG - 2024-01-18 11:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:15:18 --> Input Class Initialized
INFO - 2024-01-18 11:15:18 --> Language Class Initialized
INFO - 2024-01-18 11:15:18 --> Loader Class Initialized
INFO - 2024-01-18 11:15:18 --> Helper loaded: url_helper
INFO - 2024-01-18 11:15:18 --> Helper loaded: file_helper
INFO - 2024-01-18 11:15:18 --> Helper loaded: html_helper
INFO - 2024-01-18 11:15:18 --> Helper loaded: text_helper
INFO - 2024-01-18 11:15:18 --> Helper loaded: form_helper
INFO - 2024-01-18 11:15:18 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:15:18 --> Helper loaded: security_helper
INFO - 2024-01-18 11:15:18 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:15:18 --> Database Driver Class Initialized
INFO - 2024-01-18 11:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:15:18 --> Parser Class Initialized
INFO - 2024-01-18 11:15:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:15:18 --> Pagination Class Initialized
INFO - 2024-01-18 11:15:18 --> Form Validation Class Initialized
INFO - 2024-01-18 11:15:18 --> Controller Class Initialized
INFO - 2024-01-18 11:15:18 --> Model Class Initialized
DEBUG - 2024-01-18 11:15:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:15:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:15:18 --> Model Class Initialized
DEBUG - 2024-01-18 11:15:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:15:18 --> Model Class Initialized
INFO - 2024-01-18 11:15:18 --> Final output sent to browser
DEBUG - 2024-01-18 11:15:18 --> Total execution time: 0.0628
ERROR - 2024-01-18 11:15:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:15:19 --> Config Class Initialized
INFO - 2024-01-18 11:15:19 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:15:19 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:15:19 --> Utf8 Class Initialized
INFO - 2024-01-18 11:15:19 --> URI Class Initialized
INFO - 2024-01-18 11:15:19 --> Router Class Initialized
INFO - 2024-01-18 11:15:19 --> Output Class Initialized
INFO - 2024-01-18 11:15:19 --> Security Class Initialized
DEBUG - 2024-01-18 11:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:15:19 --> Input Class Initialized
INFO - 2024-01-18 11:15:19 --> Language Class Initialized
INFO - 2024-01-18 11:15:19 --> Loader Class Initialized
INFO - 2024-01-18 11:15:19 --> Helper loaded: url_helper
INFO - 2024-01-18 11:15:19 --> Helper loaded: file_helper
INFO - 2024-01-18 11:15:19 --> Helper loaded: html_helper
INFO - 2024-01-18 11:15:19 --> Helper loaded: text_helper
INFO - 2024-01-18 11:15:19 --> Helper loaded: form_helper
INFO - 2024-01-18 11:15:19 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:15:19 --> Helper loaded: security_helper
INFO - 2024-01-18 11:15:19 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:15:19 --> Database Driver Class Initialized
INFO - 2024-01-18 11:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:15:19 --> Parser Class Initialized
INFO - 2024-01-18 11:15:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:15:19 --> Pagination Class Initialized
INFO - 2024-01-18 11:15:19 --> Form Validation Class Initialized
INFO - 2024-01-18 11:15:19 --> Controller Class Initialized
INFO - 2024-01-18 11:15:19 --> Model Class Initialized
DEBUG - 2024-01-18 11:15:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:15:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:15:19 --> Model Class Initialized
DEBUG - 2024-01-18 11:15:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:15:19 --> Model Class Initialized
INFO - 2024-01-18 11:15:19 --> Final output sent to browser
DEBUG - 2024-01-18 11:15:19 --> Total execution time: 0.0630
ERROR - 2024-01-18 11:15:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:15:19 --> Config Class Initialized
INFO - 2024-01-18 11:15:19 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:15:19 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:15:19 --> Utf8 Class Initialized
INFO - 2024-01-18 11:15:19 --> URI Class Initialized
INFO - 2024-01-18 11:15:19 --> Router Class Initialized
INFO - 2024-01-18 11:15:19 --> Output Class Initialized
INFO - 2024-01-18 11:15:19 --> Security Class Initialized
DEBUG - 2024-01-18 11:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:15:19 --> Input Class Initialized
INFO - 2024-01-18 11:15:19 --> Language Class Initialized
INFO - 2024-01-18 11:15:19 --> Loader Class Initialized
INFO - 2024-01-18 11:15:19 --> Helper loaded: url_helper
INFO - 2024-01-18 11:15:19 --> Helper loaded: file_helper
INFO - 2024-01-18 11:15:19 --> Helper loaded: html_helper
INFO - 2024-01-18 11:15:19 --> Helper loaded: text_helper
INFO - 2024-01-18 11:15:19 --> Helper loaded: form_helper
INFO - 2024-01-18 11:15:19 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:15:19 --> Helper loaded: security_helper
INFO - 2024-01-18 11:15:19 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:15:19 --> Database Driver Class Initialized
INFO - 2024-01-18 11:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:15:19 --> Parser Class Initialized
INFO - 2024-01-18 11:15:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:15:19 --> Pagination Class Initialized
INFO - 2024-01-18 11:15:19 --> Form Validation Class Initialized
INFO - 2024-01-18 11:15:19 --> Controller Class Initialized
INFO - 2024-01-18 11:15:19 --> Model Class Initialized
DEBUG - 2024-01-18 11:15:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:15:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:15:19 --> Model Class Initialized
DEBUG - 2024-01-18 11:15:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:15:19 --> Model Class Initialized
INFO - 2024-01-18 11:15:19 --> Final output sent to browser
DEBUG - 2024-01-18 11:15:19 --> Total execution time: 0.0559
ERROR - 2024-01-18 11:15:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:15:25 --> Config Class Initialized
INFO - 2024-01-18 11:15:25 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:15:25 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:15:25 --> Utf8 Class Initialized
INFO - 2024-01-18 11:15:25 --> URI Class Initialized
INFO - 2024-01-18 11:15:25 --> Router Class Initialized
INFO - 2024-01-18 11:15:25 --> Output Class Initialized
INFO - 2024-01-18 11:15:25 --> Security Class Initialized
DEBUG - 2024-01-18 11:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:15:25 --> Input Class Initialized
INFO - 2024-01-18 11:15:25 --> Language Class Initialized
INFO - 2024-01-18 11:15:25 --> Loader Class Initialized
INFO - 2024-01-18 11:15:25 --> Helper loaded: url_helper
INFO - 2024-01-18 11:15:25 --> Helper loaded: file_helper
INFO - 2024-01-18 11:15:25 --> Helper loaded: html_helper
INFO - 2024-01-18 11:15:25 --> Helper loaded: text_helper
INFO - 2024-01-18 11:15:25 --> Helper loaded: form_helper
INFO - 2024-01-18 11:15:25 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:15:25 --> Helper loaded: security_helper
INFO - 2024-01-18 11:15:25 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:15:25 --> Database Driver Class Initialized
INFO - 2024-01-18 11:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:15:25 --> Parser Class Initialized
INFO - 2024-01-18 11:15:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:15:25 --> Pagination Class Initialized
INFO - 2024-01-18 11:15:25 --> Form Validation Class Initialized
INFO - 2024-01-18 11:15:25 --> Controller Class Initialized
INFO - 2024-01-18 11:15:25 --> Model Class Initialized
DEBUG - 2024-01-18 11:15:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:15:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:15:25 --> Model Class Initialized
DEBUG - 2024-01-18 11:15:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:15:25 --> Model Class Initialized
INFO - 2024-01-18 11:15:25 --> Final output sent to browser
DEBUG - 2024-01-18 11:15:25 --> Total execution time: 0.0758
ERROR - 2024-01-18 11:16:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:16:05 --> Config Class Initialized
INFO - 2024-01-18 11:16:05 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:16:05 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:16:05 --> Utf8 Class Initialized
INFO - 2024-01-18 11:16:05 --> URI Class Initialized
INFO - 2024-01-18 11:16:05 --> Router Class Initialized
INFO - 2024-01-18 11:16:05 --> Output Class Initialized
INFO - 2024-01-18 11:16:05 --> Security Class Initialized
DEBUG - 2024-01-18 11:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:16:05 --> Input Class Initialized
INFO - 2024-01-18 11:16:05 --> Language Class Initialized
INFO - 2024-01-18 11:16:05 --> Loader Class Initialized
INFO - 2024-01-18 11:16:05 --> Helper loaded: url_helper
INFO - 2024-01-18 11:16:05 --> Helper loaded: file_helper
INFO - 2024-01-18 11:16:05 --> Helper loaded: html_helper
INFO - 2024-01-18 11:16:05 --> Helper loaded: text_helper
INFO - 2024-01-18 11:16:05 --> Helper loaded: form_helper
INFO - 2024-01-18 11:16:05 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:16:05 --> Helper loaded: security_helper
INFO - 2024-01-18 11:16:05 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:16:05 --> Database Driver Class Initialized
INFO - 2024-01-18 11:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:16:05 --> Parser Class Initialized
INFO - 2024-01-18 11:16:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:16:05 --> Pagination Class Initialized
INFO - 2024-01-18 11:16:05 --> Form Validation Class Initialized
INFO - 2024-01-18 11:16:05 --> Controller Class Initialized
INFO - 2024-01-18 11:16:05 --> Model Class Initialized
DEBUG - 2024-01-18 11:16:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:16:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:16:05 --> Model Class Initialized
DEBUG - 2024-01-18 11:16:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:16:05 --> Model Class Initialized
ERROR - 2024-01-18 11:16:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:16:06 --> Config Class Initialized
INFO - 2024-01-18 11:16:06 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:16:06 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:16:06 --> Utf8 Class Initialized
INFO - 2024-01-18 11:16:06 --> URI Class Initialized
INFO - 2024-01-18 11:16:06 --> Router Class Initialized
INFO - 2024-01-18 11:16:06 --> Output Class Initialized
INFO - 2024-01-18 11:16:06 --> Security Class Initialized
DEBUG - 2024-01-18 11:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:16:06 --> Input Class Initialized
INFO - 2024-01-18 11:16:06 --> Language Class Initialized
INFO - 2024-01-18 11:16:06 --> Loader Class Initialized
INFO - 2024-01-18 11:16:06 --> Helper loaded: url_helper
INFO - 2024-01-18 11:16:06 --> Helper loaded: file_helper
INFO - 2024-01-18 11:16:06 --> Helper loaded: html_helper
INFO - 2024-01-18 11:16:06 --> Helper loaded: text_helper
INFO - 2024-01-18 11:16:06 --> Helper loaded: form_helper
INFO - 2024-01-18 11:16:06 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:16:06 --> Helper loaded: security_helper
INFO - 2024-01-18 11:16:06 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:16:06 --> Database Driver Class Initialized
INFO - 2024-01-18 11:16:06 --> Final output sent to browser
DEBUG - 2024-01-18 11:16:06 --> Total execution time: 0.5157
INFO - 2024-01-18 11:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:16:06 --> Parser Class Initialized
INFO - 2024-01-18 11:16:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:16:06 --> Pagination Class Initialized
INFO - 2024-01-18 11:16:06 --> Form Validation Class Initialized
INFO - 2024-01-18 11:16:06 --> Controller Class Initialized
INFO - 2024-01-18 11:16:06 --> Model Class Initialized
DEBUG - 2024-01-18 11:16:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:16:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:16:06 --> Model Class Initialized
DEBUG - 2024-01-18 11:16:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:16:06 --> Model Class Initialized
ERROR - 2024-01-18 11:16:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:16:07 --> Config Class Initialized
INFO - 2024-01-18 11:16:07 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:16:07 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:16:07 --> Utf8 Class Initialized
INFO - 2024-01-18 11:16:07 --> URI Class Initialized
INFO - 2024-01-18 11:16:07 --> Router Class Initialized
INFO - 2024-01-18 11:16:07 --> Output Class Initialized
INFO - 2024-01-18 11:16:07 --> Security Class Initialized
DEBUG - 2024-01-18 11:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:16:07 --> Input Class Initialized
INFO - 2024-01-18 11:16:07 --> Language Class Initialized
INFO - 2024-01-18 11:16:07 --> Loader Class Initialized
INFO - 2024-01-18 11:16:07 --> Helper loaded: url_helper
INFO - 2024-01-18 11:16:07 --> Helper loaded: file_helper
INFO - 2024-01-18 11:16:07 --> Helper loaded: html_helper
INFO - 2024-01-18 11:16:07 --> Helper loaded: text_helper
INFO - 2024-01-18 11:16:07 --> Helper loaded: form_helper
INFO - 2024-01-18 11:16:07 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:16:07 --> Helper loaded: security_helper
INFO - 2024-01-18 11:16:07 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:16:07 --> Database Driver Class Initialized
INFO - 2024-01-18 11:16:07 --> Final output sent to browser
DEBUG - 2024-01-18 11:16:07 --> Total execution time: 1.1400
INFO - 2024-01-18 11:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:16:07 --> Parser Class Initialized
INFO - 2024-01-18 11:16:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:16:07 --> Pagination Class Initialized
INFO - 2024-01-18 11:16:07 --> Form Validation Class Initialized
INFO - 2024-01-18 11:16:07 --> Controller Class Initialized
INFO - 2024-01-18 11:16:07 --> Model Class Initialized
DEBUG - 2024-01-18 11:16:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:16:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:16:07 --> Model Class Initialized
DEBUG - 2024-01-18 11:16:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:16:07 --> Model Class Initialized
ERROR - 2024-01-18 11:16:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:16:07 --> Config Class Initialized
INFO - 2024-01-18 11:16:07 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:16:07 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:16:07 --> Utf8 Class Initialized
INFO - 2024-01-18 11:16:07 --> URI Class Initialized
INFO - 2024-01-18 11:16:07 --> Router Class Initialized
INFO - 2024-01-18 11:16:07 --> Output Class Initialized
INFO - 2024-01-18 11:16:07 --> Security Class Initialized
DEBUG - 2024-01-18 11:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:16:07 --> Input Class Initialized
INFO - 2024-01-18 11:16:07 --> Language Class Initialized
INFO - 2024-01-18 11:16:07 --> Loader Class Initialized
INFO - 2024-01-18 11:16:07 --> Helper loaded: url_helper
INFO - 2024-01-18 11:16:07 --> Helper loaded: file_helper
INFO - 2024-01-18 11:16:07 --> Helper loaded: html_helper
INFO - 2024-01-18 11:16:07 --> Helper loaded: text_helper
INFO - 2024-01-18 11:16:07 --> Helper loaded: form_helper
INFO - 2024-01-18 11:16:07 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:16:07 --> Helper loaded: security_helper
INFO - 2024-01-18 11:16:07 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:16:07 --> Database Driver Class Initialized
ERROR - 2024-01-18 11:16:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:16:07 --> Config Class Initialized
INFO - 2024-01-18 11:16:07 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:16:07 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:16:07 --> Utf8 Class Initialized
INFO - 2024-01-18 11:16:07 --> URI Class Initialized
INFO - 2024-01-18 11:16:07 --> Router Class Initialized
INFO - 2024-01-18 11:16:07 --> Output Class Initialized
INFO - 2024-01-18 11:16:07 --> Security Class Initialized
DEBUG - 2024-01-18 11:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:16:07 --> Input Class Initialized
INFO - 2024-01-18 11:16:07 --> Language Class Initialized
INFO - 2024-01-18 11:16:07 --> Loader Class Initialized
INFO - 2024-01-18 11:16:07 --> Helper loaded: url_helper
INFO - 2024-01-18 11:16:07 --> Helper loaded: file_helper
INFO - 2024-01-18 11:16:07 --> Helper loaded: html_helper
INFO - 2024-01-18 11:16:07 --> Helper loaded: text_helper
INFO - 2024-01-18 11:16:07 --> Helper loaded: form_helper
INFO - 2024-01-18 11:16:07 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:16:07 --> Helper loaded: security_helper
INFO - 2024-01-18 11:16:07 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:16:07 --> Database Driver Class Initialized
INFO - 2024-01-18 11:16:08 --> Final output sent to browser
DEBUG - 2024-01-18 11:16:08 --> Total execution time: 1.1956
INFO - 2024-01-18 11:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:16:08 --> Parser Class Initialized
INFO - 2024-01-18 11:16:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:16:08 --> Pagination Class Initialized
INFO - 2024-01-18 11:16:08 --> Form Validation Class Initialized
INFO - 2024-01-18 11:16:08 --> Controller Class Initialized
INFO - 2024-01-18 11:16:08 --> Model Class Initialized
DEBUG - 2024-01-18 11:16:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:16:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:16:08 --> Model Class Initialized
DEBUG - 2024-01-18 11:16:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:16:08 --> Model Class Initialized
ERROR - 2024-01-18 11:16:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:16:08 --> Config Class Initialized
INFO - 2024-01-18 11:16:08 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:16:08 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:16:08 --> Utf8 Class Initialized
INFO - 2024-01-18 11:16:08 --> URI Class Initialized
INFO - 2024-01-18 11:16:08 --> Router Class Initialized
INFO - 2024-01-18 11:16:08 --> Output Class Initialized
INFO - 2024-01-18 11:16:08 --> Security Class Initialized
DEBUG - 2024-01-18 11:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:16:08 --> Input Class Initialized
INFO - 2024-01-18 11:16:08 --> Language Class Initialized
INFO - 2024-01-18 11:16:08 --> Loader Class Initialized
INFO - 2024-01-18 11:16:08 --> Helper loaded: url_helper
INFO - 2024-01-18 11:16:08 --> Helper loaded: file_helper
INFO - 2024-01-18 11:16:08 --> Helper loaded: html_helper
INFO - 2024-01-18 11:16:08 --> Helper loaded: text_helper
INFO - 2024-01-18 11:16:08 --> Helper loaded: form_helper
INFO - 2024-01-18 11:16:08 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:16:08 --> Helper loaded: security_helper
INFO - 2024-01-18 11:16:08 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:16:08 --> Database Driver Class Initialized
INFO - 2024-01-18 11:16:08 --> Final output sent to browser
DEBUG - 2024-01-18 11:16:08 --> Total execution time: 0.8026
INFO - 2024-01-18 11:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:16:08 --> Parser Class Initialized
INFO - 2024-01-18 11:16:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:16:08 --> Pagination Class Initialized
INFO - 2024-01-18 11:16:08 --> Form Validation Class Initialized
INFO - 2024-01-18 11:16:08 --> Controller Class Initialized
INFO - 2024-01-18 11:16:08 --> Model Class Initialized
DEBUG - 2024-01-18 11:16:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:16:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:16:08 --> Model Class Initialized
DEBUG - 2024-01-18 11:16:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:16:08 --> Model Class Initialized
INFO - 2024-01-18 11:16:09 --> Final output sent to browser
DEBUG - 2024-01-18 11:16:09 --> Total execution time: 0.5247
INFO - 2024-01-18 11:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:16:09 --> Parser Class Initialized
INFO - 2024-01-18 11:16:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:16:09 --> Pagination Class Initialized
INFO - 2024-01-18 11:16:09 --> Form Validation Class Initialized
INFO - 2024-01-18 11:16:09 --> Controller Class Initialized
INFO - 2024-01-18 11:16:09 --> Model Class Initialized
DEBUG - 2024-01-18 11:16:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:16:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:16:09 --> Model Class Initialized
DEBUG - 2024-01-18 11:16:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:16:09 --> Model Class Initialized
INFO - 2024-01-18 11:16:09 --> Final output sent to browser
DEBUG - 2024-01-18 11:16:09 --> Total execution time: 2.2497
ERROR - 2024-01-18 11:16:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:16:10 --> Config Class Initialized
INFO - 2024-01-18 11:16:10 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:16:10 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:16:10 --> Utf8 Class Initialized
INFO - 2024-01-18 11:16:10 --> URI Class Initialized
INFO - 2024-01-18 11:16:10 --> Router Class Initialized
INFO - 2024-01-18 11:16:10 --> Output Class Initialized
INFO - 2024-01-18 11:16:10 --> Security Class Initialized
DEBUG - 2024-01-18 11:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:16:10 --> Input Class Initialized
INFO - 2024-01-18 11:16:10 --> Language Class Initialized
INFO - 2024-01-18 11:16:10 --> Loader Class Initialized
INFO - 2024-01-18 11:16:10 --> Helper loaded: url_helper
INFO - 2024-01-18 11:16:10 --> Helper loaded: file_helper
INFO - 2024-01-18 11:16:10 --> Helper loaded: html_helper
INFO - 2024-01-18 11:16:10 --> Helper loaded: text_helper
INFO - 2024-01-18 11:16:10 --> Helper loaded: form_helper
INFO - 2024-01-18 11:16:10 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:16:10 --> Helper loaded: security_helper
INFO - 2024-01-18 11:16:10 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:16:10 --> Database Driver Class Initialized
INFO - 2024-01-18 11:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:16:10 --> Parser Class Initialized
INFO - 2024-01-18 11:16:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:16:10 --> Pagination Class Initialized
INFO - 2024-01-18 11:16:10 --> Form Validation Class Initialized
INFO - 2024-01-18 11:16:10 --> Controller Class Initialized
INFO - 2024-01-18 11:16:10 --> Model Class Initialized
DEBUG - 2024-01-18 11:16:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:16:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:16:10 --> Model Class Initialized
DEBUG - 2024-01-18 11:16:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:16:10 --> Model Class Initialized
INFO - 2024-01-18 11:16:10 --> Final output sent to browser
DEBUG - 2024-01-18 11:16:10 --> Total execution time: 0.0765
ERROR - 2024-01-18 11:16:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:16:10 --> Config Class Initialized
INFO - 2024-01-18 11:16:10 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:16:10 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:16:10 --> Utf8 Class Initialized
INFO - 2024-01-18 11:16:10 --> URI Class Initialized
INFO - 2024-01-18 11:16:10 --> Router Class Initialized
INFO - 2024-01-18 11:16:10 --> Output Class Initialized
INFO - 2024-01-18 11:16:10 --> Security Class Initialized
DEBUG - 2024-01-18 11:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:16:10 --> Input Class Initialized
INFO - 2024-01-18 11:16:10 --> Language Class Initialized
INFO - 2024-01-18 11:16:10 --> Loader Class Initialized
INFO - 2024-01-18 11:16:10 --> Helper loaded: url_helper
INFO - 2024-01-18 11:16:10 --> Helper loaded: file_helper
INFO - 2024-01-18 11:16:10 --> Helper loaded: html_helper
INFO - 2024-01-18 11:16:10 --> Helper loaded: text_helper
INFO - 2024-01-18 11:16:10 --> Helper loaded: form_helper
INFO - 2024-01-18 11:16:10 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:16:10 --> Helper loaded: security_helper
INFO - 2024-01-18 11:16:10 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:16:10 --> Database Driver Class Initialized
INFO - 2024-01-18 11:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:16:10 --> Parser Class Initialized
INFO - 2024-01-18 11:16:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:16:10 --> Pagination Class Initialized
INFO - 2024-01-18 11:16:10 --> Form Validation Class Initialized
INFO - 2024-01-18 11:16:10 --> Controller Class Initialized
INFO - 2024-01-18 11:16:10 --> Model Class Initialized
DEBUG - 2024-01-18 11:16:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:16:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:16:10 --> Model Class Initialized
DEBUG - 2024-01-18 11:16:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:16:10 --> Model Class Initialized
INFO - 2024-01-18 11:16:10 --> Final output sent to browser
DEBUG - 2024-01-18 11:16:10 --> Total execution time: 0.0633
ERROR - 2024-01-18 11:16:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:16:11 --> Config Class Initialized
INFO - 2024-01-18 11:16:11 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:16:11 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:16:11 --> Utf8 Class Initialized
INFO - 2024-01-18 11:16:11 --> URI Class Initialized
INFO - 2024-01-18 11:16:11 --> Router Class Initialized
INFO - 2024-01-18 11:16:11 --> Output Class Initialized
INFO - 2024-01-18 11:16:11 --> Security Class Initialized
DEBUG - 2024-01-18 11:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:16:11 --> Input Class Initialized
INFO - 2024-01-18 11:16:11 --> Language Class Initialized
INFO - 2024-01-18 11:16:11 --> Loader Class Initialized
INFO - 2024-01-18 11:16:11 --> Helper loaded: url_helper
INFO - 2024-01-18 11:16:11 --> Helper loaded: file_helper
INFO - 2024-01-18 11:16:11 --> Helper loaded: html_helper
INFO - 2024-01-18 11:16:11 --> Helper loaded: text_helper
INFO - 2024-01-18 11:16:11 --> Helper loaded: form_helper
INFO - 2024-01-18 11:16:11 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:16:11 --> Helper loaded: security_helper
INFO - 2024-01-18 11:16:11 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:16:11 --> Database Driver Class Initialized
INFO - 2024-01-18 11:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:16:11 --> Parser Class Initialized
INFO - 2024-01-18 11:16:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:16:11 --> Pagination Class Initialized
INFO - 2024-01-18 11:16:11 --> Form Validation Class Initialized
INFO - 2024-01-18 11:16:11 --> Controller Class Initialized
INFO - 2024-01-18 11:16:11 --> Model Class Initialized
DEBUG - 2024-01-18 11:16:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:16:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:16:11 --> Model Class Initialized
DEBUG - 2024-01-18 11:16:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:16:11 --> Model Class Initialized
INFO - 2024-01-18 11:16:11 --> Final output sent to browser
DEBUG - 2024-01-18 11:16:11 --> Total execution time: 0.0513
ERROR - 2024-01-18 11:16:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:16:12 --> Config Class Initialized
INFO - 2024-01-18 11:16:12 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:16:12 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:16:12 --> Utf8 Class Initialized
INFO - 2024-01-18 11:16:12 --> URI Class Initialized
INFO - 2024-01-18 11:16:12 --> Router Class Initialized
INFO - 2024-01-18 11:16:12 --> Output Class Initialized
INFO - 2024-01-18 11:16:12 --> Security Class Initialized
DEBUG - 2024-01-18 11:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:16:12 --> Input Class Initialized
INFO - 2024-01-18 11:16:12 --> Language Class Initialized
INFO - 2024-01-18 11:16:12 --> Loader Class Initialized
INFO - 2024-01-18 11:16:12 --> Helper loaded: url_helper
INFO - 2024-01-18 11:16:12 --> Helper loaded: file_helper
INFO - 2024-01-18 11:16:12 --> Helper loaded: html_helper
INFO - 2024-01-18 11:16:12 --> Helper loaded: text_helper
INFO - 2024-01-18 11:16:12 --> Helper loaded: form_helper
INFO - 2024-01-18 11:16:12 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:16:12 --> Helper loaded: security_helper
INFO - 2024-01-18 11:16:12 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:16:12 --> Database Driver Class Initialized
INFO - 2024-01-18 11:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:16:12 --> Parser Class Initialized
INFO - 2024-01-18 11:16:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:16:12 --> Pagination Class Initialized
INFO - 2024-01-18 11:16:12 --> Form Validation Class Initialized
INFO - 2024-01-18 11:16:12 --> Controller Class Initialized
INFO - 2024-01-18 11:16:12 --> Model Class Initialized
DEBUG - 2024-01-18 11:16:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:16:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:16:12 --> Model Class Initialized
DEBUG - 2024-01-18 11:16:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:16:12 --> Model Class Initialized
INFO - 2024-01-18 11:16:12 --> Final output sent to browser
DEBUG - 2024-01-18 11:16:12 --> Total execution time: 0.0542
ERROR - 2024-01-18 11:17:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:17:49 --> Config Class Initialized
INFO - 2024-01-18 11:17:49 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:17:49 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:17:49 --> Utf8 Class Initialized
INFO - 2024-01-18 11:17:49 --> URI Class Initialized
INFO - 2024-01-18 11:17:49 --> Router Class Initialized
INFO - 2024-01-18 11:17:49 --> Output Class Initialized
INFO - 2024-01-18 11:17:49 --> Security Class Initialized
DEBUG - 2024-01-18 11:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:17:49 --> Input Class Initialized
INFO - 2024-01-18 11:17:49 --> Language Class Initialized
INFO - 2024-01-18 11:17:49 --> Loader Class Initialized
INFO - 2024-01-18 11:17:49 --> Helper loaded: url_helper
INFO - 2024-01-18 11:17:49 --> Helper loaded: file_helper
INFO - 2024-01-18 11:17:49 --> Helper loaded: html_helper
INFO - 2024-01-18 11:17:49 --> Helper loaded: text_helper
INFO - 2024-01-18 11:17:49 --> Helper loaded: form_helper
INFO - 2024-01-18 11:17:49 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:17:49 --> Helper loaded: security_helper
INFO - 2024-01-18 11:17:49 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:17:49 --> Database Driver Class Initialized
INFO - 2024-01-18 11:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:17:49 --> Parser Class Initialized
INFO - 2024-01-18 11:17:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:17:49 --> Pagination Class Initialized
INFO - 2024-01-18 11:17:49 --> Form Validation Class Initialized
INFO - 2024-01-18 11:17:49 --> Controller Class Initialized
INFO - 2024-01-18 11:17:49 --> Model Class Initialized
DEBUG - 2024-01-18 11:17:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:17:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:17:49 --> Model Class Initialized
DEBUG - 2024-01-18 11:17:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:17:49 --> Model Class Initialized
INFO - 2024-01-18 11:17:49 --> Final output sent to browser
DEBUG - 2024-01-18 11:17:49 --> Total execution time: 0.0547
ERROR - 2024-01-18 11:17:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:17:49 --> Config Class Initialized
INFO - 2024-01-18 11:17:49 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:17:49 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:17:49 --> Utf8 Class Initialized
INFO - 2024-01-18 11:17:49 --> URI Class Initialized
INFO - 2024-01-18 11:17:49 --> Router Class Initialized
INFO - 2024-01-18 11:17:49 --> Output Class Initialized
INFO - 2024-01-18 11:17:49 --> Security Class Initialized
DEBUG - 2024-01-18 11:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:17:49 --> Input Class Initialized
INFO - 2024-01-18 11:17:49 --> Language Class Initialized
INFO - 2024-01-18 11:17:49 --> Loader Class Initialized
INFO - 2024-01-18 11:17:49 --> Helper loaded: url_helper
INFO - 2024-01-18 11:17:49 --> Helper loaded: file_helper
INFO - 2024-01-18 11:17:49 --> Helper loaded: html_helper
INFO - 2024-01-18 11:17:49 --> Helper loaded: text_helper
INFO - 2024-01-18 11:17:49 --> Helper loaded: form_helper
INFO - 2024-01-18 11:17:49 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:17:49 --> Helper loaded: security_helper
INFO - 2024-01-18 11:17:49 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:17:49 --> Database Driver Class Initialized
INFO - 2024-01-18 11:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:17:49 --> Parser Class Initialized
INFO - 2024-01-18 11:17:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:17:49 --> Pagination Class Initialized
INFO - 2024-01-18 11:17:49 --> Form Validation Class Initialized
INFO - 2024-01-18 11:17:49 --> Controller Class Initialized
INFO - 2024-01-18 11:17:49 --> Model Class Initialized
DEBUG - 2024-01-18 11:17:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:17:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:17:49 --> Model Class Initialized
DEBUG - 2024-01-18 11:17:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:17:49 --> Model Class Initialized
INFO - 2024-01-18 11:17:49 --> Final output sent to browser
DEBUG - 2024-01-18 11:17:49 --> Total execution time: 0.0736
ERROR - 2024-01-18 11:17:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:17:50 --> Config Class Initialized
INFO - 2024-01-18 11:17:50 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:17:50 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:17:50 --> Utf8 Class Initialized
INFO - 2024-01-18 11:17:50 --> URI Class Initialized
INFO - 2024-01-18 11:17:50 --> Router Class Initialized
INFO - 2024-01-18 11:17:50 --> Output Class Initialized
INFO - 2024-01-18 11:17:50 --> Security Class Initialized
DEBUG - 2024-01-18 11:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:17:50 --> Input Class Initialized
INFO - 2024-01-18 11:17:50 --> Language Class Initialized
INFO - 2024-01-18 11:17:50 --> Loader Class Initialized
INFO - 2024-01-18 11:17:50 --> Helper loaded: url_helper
INFO - 2024-01-18 11:17:50 --> Helper loaded: file_helper
INFO - 2024-01-18 11:17:50 --> Helper loaded: html_helper
INFO - 2024-01-18 11:17:50 --> Helper loaded: text_helper
INFO - 2024-01-18 11:17:50 --> Helper loaded: form_helper
INFO - 2024-01-18 11:17:50 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:17:50 --> Helper loaded: security_helper
INFO - 2024-01-18 11:17:50 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:17:50 --> Database Driver Class Initialized
INFO - 2024-01-18 11:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:17:50 --> Parser Class Initialized
INFO - 2024-01-18 11:17:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:17:50 --> Pagination Class Initialized
INFO - 2024-01-18 11:17:50 --> Form Validation Class Initialized
INFO - 2024-01-18 11:17:50 --> Controller Class Initialized
INFO - 2024-01-18 11:17:50 --> Model Class Initialized
DEBUG - 2024-01-18 11:17:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:17:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:17:50 --> Model Class Initialized
DEBUG - 2024-01-18 11:17:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:17:50 --> Model Class Initialized
ERROR - 2024-01-18 11:17:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:17:50 --> Config Class Initialized
INFO - 2024-01-18 11:17:50 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:17:50 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:17:50 --> Utf8 Class Initialized
INFO - 2024-01-18 11:17:50 --> URI Class Initialized
INFO - 2024-01-18 11:17:50 --> Router Class Initialized
INFO - 2024-01-18 11:17:50 --> Output Class Initialized
INFO - 2024-01-18 11:17:50 --> Security Class Initialized
DEBUG - 2024-01-18 11:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:17:50 --> Input Class Initialized
INFO - 2024-01-18 11:17:50 --> Language Class Initialized
INFO - 2024-01-18 11:17:50 --> Loader Class Initialized
INFO - 2024-01-18 11:17:50 --> Helper loaded: url_helper
INFO - 2024-01-18 11:17:50 --> Helper loaded: file_helper
INFO - 2024-01-18 11:17:50 --> Helper loaded: html_helper
INFO - 2024-01-18 11:17:50 --> Helper loaded: text_helper
INFO - 2024-01-18 11:17:50 --> Helper loaded: form_helper
INFO - 2024-01-18 11:17:50 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:17:50 --> Helper loaded: security_helper
INFO - 2024-01-18 11:17:50 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:17:50 --> Database Driver Class Initialized
INFO - 2024-01-18 11:17:50 --> Final output sent to browser
DEBUG - 2024-01-18 11:17:50 --> Total execution time: 0.4917
INFO - 2024-01-18 11:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:17:50 --> Parser Class Initialized
INFO - 2024-01-18 11:17:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:17:50 --> Pagination Class Initialized
INFO - 2024-01-18 11:17:50 --> Form Validation Class Initialized
INFO - 2024-01-18 11:17:50 --> Controller Class Initialized
INFO - 2024-01-18 11:17:50 --> Model Class Initialized
DEBUG - 2024-01-18 11:17:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:17:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:17:50 --> Model Class Initialized
DEBUG - 2024-01-18 11:17:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:17:50 --> Model Class Initialized
INFO - 2024-01-18 11:17:51 --> Final output sent to browser
DEBUG - 2024-01-18 11:17:51 --> Total execution time: 1.0188
ERROR - 2024-01-18 11:17:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:17:51 --> Config Class Initialized
INFO - 2024-01-18 11:17:51 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:17:51 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:17:51 --> Utf8 Class Initialized
INFO - 2024-01-18 11:17:51 --> URI Class Initialized
INFO - 2024-01-18 11:17:51 --> Router Class Initialized
INFO - 2024-01-18 11:17:51 --> Output Class Initialized
INFO - 2024-01-18 11:17:51 --> Security Class Initialized
DEBUG - 2024-01-18 11:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:17:51 --> Input Class Initialized
INFO - 2024-01-18 11:17:51 --> Language Class Initialized
INFO - 2024-01-18 11:17:51 --> Loader Class Initialized
INFO - 2024-01-18 11:17:51 --> Helper loaded: url_helper
INFO - 2024-01-18 11:17:51 --> Helper loaded: file_helper
INFO - 2024-01-18 11:17:51 --> Helper loaded: html_helper
INFO - 2024-01-18 11:17:51 --> Helper loaded: text_helper
INFO - 2024-01-18 11:17:51 --> Helper loaded: form_helper
INFO - 2024-01-18 11:17:51 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:17:51 --> Helper loaded: security_helper
INFO - 2024-01-18 11:17:51 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:17:51 --> Database Driver Class Initialized
INFO - 2024-01-18 11:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:17:51 --> Parser Class Initialized
INFO - 2024-01-18 11:17:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:17:51 --> Pagination Class Initialized
INFO - 2024-01-18 11:17:51 --> Form Validation Class Initialized
INFO - 2024-01-18 11:17:51 --> Controller Class Initialized
INFO - 2024-01-18 11:17:51 --> Model Class Initialized
DEBUG - 2024-01-18 11:17:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:17:51 --> Model Class Initialized
DEBUG - 2024-01-18 11:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:17:51 --> Model Class Initialized
ERROR - 2024-01-18 11:17:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:17:51 --> Config Class Initialized
INFO - 2024-01-18 11:17:51 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:17:51 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:17:51 --> Utf8 Class Initialized
INFO - 2024-01-18 11:17:51 --> URI Class Initialized
INFO - 2024-01-18 11:17:51 --> Router Class Initialized
INFO - 2024-01-18 11:17:51 --> Output Class Initialized
INFO - 2024-01-18 11:17:51 --> Security Class Initialized
DEBUG - 2024-01-18 11:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:17:51 --> Input Class Initialized
INFO - 2024-01-18 11:17:51 --> Language Class Initialized
INFO - 2024-01-18 11:17:51 --> Loader Class Initialized
INFO - 2024-01-18 11:17:51 --> Helper loaded: url_helper
INFO - 2024-01-18 11:17:51 --> Helper loaded: file_helper
INFO - 2024-01-18 11:17:51 --> Helper loaded: html_helper
INFO - 2024-01-18 11:17:51 --> Helper loaded: text_helper
INFO - 2024-01-18 11:17:51 --> Helper loaded: form_helper
INFO - 2024-01-18 11:17:51 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:17:51 --> Helper loaded: security_helper
INFO - 2024-01-18 11:17:51 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:17:51 --> Database Driver Class Initialized
INFO - 2024-01-18 11:17:52 --> Final output sent to browser
DEBUG - 2024-01-18 11:17:52 --> Total execution time: 0.8185
INFO - 2024-01-18 11:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:17:52 --> Parser Class Initialized
INFO - 2024-01-18 11:17:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:17:52 --> Pagination Class Initialized
INFO - 2024-01-18 11:17:52 --> Form Validation Class Initialized
INFO - 2024-01-18 11:17:52 --> Controller Class Initialized
INFO - 2024-01-18 11:17:52 --> Model Class Initialized
DEBUG - 2024-01-18 11:17:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:17:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:17:52 --> Model Class Initialized
DEBUG - 2024-01-18 11:17:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:17:52 --> Model Class Initialized
INFO - 2024-01-18 11:17:52 --> Final output sent to browser
DEBUG - 2024-01-18 11:17:52 --> Total execution time: 0.9231
ERROR - 2024-01-18 11:17:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:17:52 --> Config Class Initialized
INFO - 2024-01-18 11:17:52 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:17:52 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:17:52 --> Utf8 Class Initialized
INFO - 2024-01-18 11:17:53 --> URI Class Initialized
INFO - 2024-01-18 11:17:53 --> Router Class Initialized
INFO - 2024-01-18 11:17:53 --> Output Class Initialized
INFO - 2024-01-18 11:17:53 --> Security Class Initialized
DEBUG - 2024-01-18 11:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:17:53 --> Input Class Initialized
INFO - 2024-01-18 11:17:53 --> Language Class Initialized
INFO - 2024-01-18 11:17:53 --> Loader Class Initialized
INFO - 2024-01-18 11:17:53 --> Helper loaded: url_helper
INFO - 2024-01-18 11:17:53 --> Helper loaded: file_helper
INFO - 2024-01-18 11:17:53 --> Helper loaded: html_helper
INFO - 2024-01-18 11:17:53 --> Helper loaded: text_helper
INFO - 2024-01-18 11:17:53 --> Helper loaded: form_helper
INFO - 2024-01-18 11:17:53 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:17:53 --> Helper loaded: security_helper
INFO - 2024-01-18 11:17:53 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:17:53 --> Database Driver Class Initialized
INFO - 2024-01-18 11:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:17:53 --> Parser Class Initialized
INFO - 2024-01-18 11:17:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:17:53 --> Pagination Class Initialized
INFO - 2024-01-18 11:17:53 --> Form Validation Class Initialized
INFO - 2024-01-18 11:17:53 --> Controller Class Initialized
INFO - 2024-01-18 11:17:53 --> Model Class Initialized
DEBUG - 2024-01-18 11:17:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:17:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:17:53 --> Model Class Initialized
DEBUG - 2024-01-18 11:17:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:17:53 --> Model Class Initialized
INFO - 2024-01-18 11:17:53 --> Final output sent to browser
DEBUG - 2024-01-18 11:17:53 --> Total execution time: 0.4871
ERROR - 2024-01-18 11:17:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:17:53 --> Config Class Initialized
INFO - 2024-01-18 11:17:53 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:17:53 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:17:53 --> Utf8 Class Initialized
INFO - 2024-01-18 11:17:53 --> URI Class Initialized
INFO - 2024-01-18 11:17:53 --> Router Class Initialized
INFO - 2024-01-18 11:17:53 --> Output Class Initialized
INFO - 2024-01-18 11:17:53 --> Security Class Initialized
DEBUG - 2024-01-18 11:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:17:53 --> Input Class Initialized
INFO - 2024-01-18 11:17:53 --> Language Class Initialized
INFO - 2024-01-18 11:17:53 --> Loader Class Initialized
INFO - 2024-01-18 11:17:53 --> Helper loaded: url_helper
INFO - 2024-01-18 11:17:53 --> Helper loaded: file_helper
INFO - 2024-01-18 11:17:53 --> Helper loaded: html_helper
INFO - 2024-01-18 11:17:53 --> Helper loaded: text_helper
INFO - 2024-01-18 11:17:53 --> Helper loaded: form_helper
INFO - 2024-01-18 11:17:53 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:17:53 --> Helper loaded: security_helper
INFO - 2024-01-18 11:17:53 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:17:53 --> Database Driver Class Initialized
INFO - 2024-01-18 11:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:17:53 --> Parser Class Initialized
INFO - 2024-01-18 11:17:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:17:53 --> Pagination Class Initialized
INFO - 2024-01-18 11:17:53 --> Form Validation Class Initialized
INFO - 2024-01-18 11:17:53 --> Controller Class Initialized
INFO - 2024-01-18 11:17:53 --> Model Class Initialized
DEBUG - 2024-01-18 11:17:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:17:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:17:53 --> Model Class Initialized
DEBUG - 2024-01-18 11:17:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:17:53 --> Model Class Initialized
INFO - 2024-01-18 11:17:54 --> Final output sent to browser
DEBUG - 2024-01-18 11:17:54 --> Total execution time: 0.4908
ERROR - 2024-01-18 11:17:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:17:54 --> Config Class Initialized
INFO - 2024-01-18 11:17:54 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:17:54 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:17:54 --> Utf8 Class Initialized
INFO - 2024-01-18 11:17:54 --> URI Class Initialized
INFO - 2024-01-18 11:17:54 --> Router Class Initialized
INFO - 2024-01-18 11:17:54 --> Output Class Initialized
INFO - 2024-01-18 11:17:54 --> Security Class Initialized
DEBUG - 2024-01-18 11:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:17:54 --> Input Class Initialized
INFO - 2024-01-18 11:17:54 --> Language Class Initialized
INFO - 2024-01-18 11:17:54 --> Loader Class Initialized
INFO - 2024-01-18 11:17:54 --> Helper loaded: url_helper
INFO - 2024-01-18 11:17:54 --> Helper loaded: file_helper
INFO - 2024-01-18 11:17:54 --> Helper loaded: html_helper
INFO - 2024-01-18 11:17:54 --> Helper loaded: text_helper
INFO - 2024-01-18 11:17:54 --> Helper loaded: form_helper
INFO - 2024-01-18 11:17:54 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:17:54 --> Helper loaded: security_helper
INFO - 2024-01-18 11:17:54 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:17:54 --> Database Driver Class Initialized
INFO - 2024-01-18 11:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:17:54 --> Parser Class Initialized
INFO - 2024-01-18 11:17:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:17:54 --> Pagination Class Initialized
INFO - 2024-01-18 11:17:54 --> Form Validation Class Initialized
INFO - 2024-01-18 11:17:54 --> Controller Class Initialized
INFO - 2024-01-18 11:17:54 --> Model Class Initialized
DEBUG - 2024-01-18 11:17:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:17:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:17:54 --> Model Class Initialized
DEBUG - 2024-01-18 11:17:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:17:54 --> Model Class Initialized
ERROR - 2024-01-18 11:17:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:17:55 --> Config Class Initialized
INFO - 2024-01-18 11:17:55 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:17:55 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:17:55 --> Utf8 Class Initialized
INFO - 2024-01-18 11:17:55 --> URI Class Initialized
INFO - 2024-01-18 11:17:55 --> Router Class Initialized
INFO - 2024-01-18 11:17:55 --> Output Class Initialized
INFO - 2024-01-18 11:17:55 --> Security Class Initialized
DEBUG - 2024-01-18 11:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:17:55 --> Input Class Initialized
INFO - 2024-01-18 11:17:55 --> Language Class Initialized
INFO - 2024-01-18 11:17:55 --> Loader Class Initialized
INFO - 2024-01-18 11:17:55 --> Helper loaded: url_helper
INFO - 2024-01-18 11:17:55 --> Helper loaded: file_helper
INFO - 2024-01-18 11:17:55 --> Helper loaded: html_helper
INFO - 2024-01-18 11:17:55 --> Helper loaded: text_helper
INFO - 2024-01-18 11:17:55 --> Helper loaded: form_helper
INFO - 2024-01-18 11:17:55 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:17:55 --> Helper loaded: security_helper
INFO - 2024-01-18 11:17:55 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:17:55 --> Database Driver Class Initialized
INFO - 2024-01-18 11:17:55 --> Final output sent to browser
DEBUG - 2024-01-18 11:17:55 --> Total execution time: 0.4728
INFO - 2024-01-18 11:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:17:55 --> Parser Class Initialized
INFO - 2024-01-18 11:17:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:17:55 --> Pagination Class Initialized
INFO - 2024-01-18 11:17:55 --> Form Validation Class Initialized
INFO - 2024-01-18 11:17:55 --> Controller Class Initialized
INFO - 2024-01-18 11:17:55 --> Model Class Initialized
DEBUG - 2024-01-18 11:17:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:17:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:17:55 --> Model Class Initialized
DEBUG - 2024-01-18 11:17:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:17:55 --> Model Class Initialized
INFO - 2024-01-18 11:17:56 --> Final output sent to browser
DEBUG - 2024-01-18 11:17:56 --> Total execution time: 1.0693
ERROR - 2024-01-18 11:28:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:28:22 --> Config Class Initialized
INFO - 2024-01-18 11:28:22 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:28:22 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:28:22 --> Utf8 Class Initialized
INFO - 2024-01-18 11:28:22 --> URI Class Initialized
DEBUG - 2024-01-18 11:28:22 --> No URI present. Default controller set.
INFO - 2024-01-18 11:28:22 --> Router Class Initialized
INFO - 2024-01-18 11:28:22 --> Output Class Initialized
INFO - 2024-01-18 11:28:22 --> Security Class Initialized
DEBUG - 2024-01-18 11:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:28:22 --> Input Class Initialized
INFO - 2024-01-18 11:28:22 --> Language Class Initialized
INFO - 2024-01-18 11:28:22 --> Loader Class Initialized
INFO - 2024-01-18 11:28:22 --> Helper loaded: url_helper
INFO - 2024-01-18 11:28:22 --> Helper loaded: file_helper
INFO - 2024-01-18 11:28:22 --> Helper loaded: html_helper
INFO - 2024-01-18 11:28:22 --> Helper loaded: text_helper
INFO - 2024-01-18 11:28:22 --> Helper loaded: form_helper
INFO - 2024-01-18 11:28:22 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:28:22 --> Helper loaded: security_helper
INFO - 2024-01-18 11:28:22 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:28:22 --> Database Driver Class Initialized
INFO - 2024-01-18 11:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:28:22 --> Parser Class Initialized
INFO - 2024-01-18 11:28:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:28:22 --> Pagination Class Initialized
INFO - 2024-01-18 11:28:22 --> Form Validation Class Initialized
INFO - 2024-01-18 11:28:22 --> Controller Class Initialized
INFO - 2024-01-18 11:28:22 --> Model Class Initialized
DEBUG - 2024-01-18 11:28:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:28:22 --> Model Class Initialized
DEBUG - 2024-01-18 11:28:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:28:22 --> Model Class Initialized
INFO - 2024-01-18 11:28:22 --> Model Class Initialized
INFO - 2024-01-18 11:28:22 --> Model Class Initialized
INFO - 2024-01-18 11:28:22 --> Model Class Initialized
DEBUG - 2024-01-18 11:28:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:28:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:28:22 --> Model Class Initialized
INFO - 2024-01-18 11:28:22 --> Model Class Initialized
INFO - 2024-01-18 11:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-18 11:28:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 11:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 11:28:23 --> Model Class Initialized
INFO - 2024-01-18 11:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 11:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 11:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 11:28:23 --> Final output sent to browser
DEBUG - 2024-01-18 11:28:23 --> Total execution time: 0.4128
ERROR - 2024-01-18 11:42:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:42:19 --> Config Class Initialized
INFO - 2024-01-18 11:42:19 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:42:19 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:42:19 --> Utf8 Class Initialized
INFO - 2024-01-18 11:42:19 --> URI Class Initialized
INFO - 2024-01-18 11:42:19 --> Router Class Initialized
INFO - 2024-01-18 11:42:19 --> Output Class Initialized
INFO - 2024-01-18 11:42:19 --> Security Class Initialized
DEBUG - 2024-01-18 11:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:42:19 --> Input Class Initialized
INFO - 2024-01-18 11:42:19 --> Language Class Initialized
INFO - 2024-01-18 11:42:19 --> Loader Class Initialized
INFO - 2024-01-18 11:42:19 --> Helper loaded: url_helper
INFO - 2024-01-18 11:42:19 --> Helper loaded: file_helper
INFO - 2024-01-18 11:42:19 --> Helper loaded: html_helper
INFO - 2024-01-18 11:42:19 --> Helper loaded: text_helper
INFO - 2024-01-18 11:42:19 --> Helper loaded: form_helper
INFO - 2024-01-18 11:42:19 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:42:19 --> Helper loaded: security_helper
INFO - 2024-01-18 11:42:19 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:42:19 --> Database Driver Class Initialized
INFO - 2024-01-18 11:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:42:19 --> Parser Class Initialized
INFO - 2024-01-18 11:42:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:42:19 --> Pagination Class Initialized
INFO - 2024-01-18 11:42:19 --> Form Validation Class Initialized
INFO - 2024-01-18 11:42:19 --> Controller Class Initialized
DEBUG - 2024-01-18 11:42:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:42:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:42:19 --> Model Class Initialized
INFO - 2024-01-18 11:42:19 --> Model Class Initialized
DEBUG - 2024-01-18 11:42:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:42:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:42:19 --> Model Class Initialized
DEBUG - 2024-01-18 11:42:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:42:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gst/list.php
DEBUG - 2024-01-18 11:42:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:42:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 11:42:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 11:42:19 --> Model Class Initialized
INFO - 2024-01-18 11:42:19 --> Model Class Initialized
INFO - 2024-01-18 11:42:19 --> Model Class Initialized
INFO - 2024-01-18 11:42:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 11:42:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 11:42:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 11:42:19 --> Final output sent to browser
DEBUG - 2024-01-18 11:42:19 --> Total execution time: 0.2104
ERROR - 2024-01-18 11:42:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:42:35 --> Config Class Initialized
INFO - 2024-01-18 11:42:35 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:42:35 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:42:35 --> Utf8 Class Initialized
INFO - 2024-01-18 11:42:35 --> URI Class Initialized
INFO - 2024-01-18 11:42:35 --> Router Class Initialized
INFO - 2024-01-18 11:42:35 --> Output Class Initialized
INFO - 2024-01-18 11:42:35 --> Security Class Initialized
DEBUG - 2024-01-18 11:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:42:35 --> Input Class Initialized
INFO - 2024-01-18 11:42:35 --> Language Class Initialized
INFO - 2024-01-18 11:42:35 --> Loader Class Initialized
INFO - 2024-01-18 11:42:35 --> Helper loaded: url_helper
INFO - 2024-01-18 11:42:35 --> Helper loaded: file_helper
INFO - 2024-01-18 11:42:35 --> Helper loaded: html_helper
INFO - 2024-01-18 11:42:35 --> Helper loaded: text_helper
INFO - 2024-01-18 11:42:35 --> Helper loaded: form_helper
INFO - 2024-01-18 11:42:35 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:42:35 --> Helper loaded: security_helper
INFO - 2024-01-18 11:42:35 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:42:35 --> Database Driver Class Initialized
INFO - 2024-01-18 11:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:42:35 --> Parser Class Initialized
INFO - 2024-01-18 11:42:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:42:35 --> Pagination Class Initialized
INFO - 2024-01-18 11:42:35 --> Form Validation Class Initialized
INFO - 2024-01-18 11:42:35 --> Controller Class Initialized
DEBUG - 2024-01-18 11:42:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:42:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:42:35 --> Model Class Initialized
DEBUG - 2024-01-18 11:42:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:42:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:42:35 --> Model Class Initialized
DEBUG - 2024-01-18 11:42:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:42:35 --> Model Class Initialized
INFO - 2024-01-18 11:42:35 --> Final output sent to browser
DEBUG - 2024-01-18 11:42:35 --> Total execution time: 0.0176
ERROR - 2024-01-18 11:45:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:45:20 --> Config Class Initialized
INFO - 2024-01-18 11:45:20 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:45:20 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:45:20 --> Utf8 Class Initialized
INFO - 2024-01-18 11:45:20 --> URI Class Initialized
INFO - 2024-01-18 11:45:20 --> Router Class Initialized
INFO - 2024-01-18 11:45:20 --> Output Class Initialized
INFO - 2024-01-18 11:45:20 --> Security Class Initialized
DEBUG - 2024-01-18 11:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:45:20 --> Input Class Initialized
INFO - 2024-01-18 11:45:20 --> Language Class Initialized
INFO - 2024-01-18 11:45:20 --> Loader Class Initialized
INFO - 2024-01-18 11:45:20 --> Helper loaded: url_helper
INFO - 2024-01-18 11:45:20 --> Helper loaded: file_helper
INFO - 2024-01-18 11:45:20 --> Helper loaded: html_helper
INFO - 2024-01-18 11:45:20 --> Helper loaded: text_helper
INFO - 2024-01-18 11:45:20 --> Helper loaded: form_helper
INFO - 2024-01-18 11:45:20 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:45:20 --> Helper loaded: security_helper
INFO - 2024-01-18 11:45:20 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:45:20 --> Database Driver Class Initialized
INFO - 2024-01-18 11:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:45:20 --> Parser Class Initialized
INFO - 2024-01-18 11:45:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:45:20 --> Pagination Class Initialized
INFO - 2024-01-18 11:45:20 --> Form Validation Class Initialized
INFO - 2024-01-18 11:45:20 --> Controller Class Initialized
DEBUG - 2024-01-18 11:45:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:45:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:45:20 --> Model Class Initialized
DEBUG - 2024-01-18 11:45:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:45:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:45:20 --> Model Class Initialized
DEBUG - 2024-01-18 11:45:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:45:20 --> Model Class Initialized
INFO - 2024-01-18 11:45:20 --> Final output sent to browser
DEBUG - 2024-01-18 11:45:20 --> Total execution time: 0.0336
ERROR - 2024-01-18 11:46:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:46:31 --> Config Class Initialized
INFO - 2024-01-18 11:46:31 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:46:31 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:46:31 --> Utf8 Class Initialized
INFO - 2024-01-18 11:46:31 --> URI Class Initialized
INFO - 2024-01-18 11:46:31 --> Router Class Initialized
INFO - 2024-01-18 11:46:31 --> Output Class Initialized
INFO - 2024-01-18 11:46:31 --> Security Class Initialized
DEBUG - 2024-01-18 11:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:46:31 --> Input Class Initialized
INFO - 2024-01-18 11:46:31 --> Language Class Initialized
INFO - 2024-01-18 11:46:31 --> Loader Class Initialized
INFO - 2024-01-18 11:46:31 --> Helper loaded: url_helper
INFO - 2024-01-18 11:46:31 --> Helper loaded: file_helper
INFO - 2024-01-18 11:46:31 --> Helper loaded: html_helper
INFO - 2024-01-18 11:46:31 --> Helper loaded: text_helper
INFO - 2024-01-18 11:46:31 --> Helper loaded: form_helper
INFO - 2024-01-18 11:46:31 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:46:31 --> Helper loaded: security_helper
INFO - 2024-01-18 11:46:31 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:46:31 --> Database Driver Class Initialized
INFO - 2024-01-18 11:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:46:31 --> Parser Class Initialized
INFO - 2024-01-18 11:46:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:46:31 --> Pagination Class Initialized
INFO - 2024-01-18 11:46:31 --> Form Validation Class Initialized
INFO - 2024-01-18 11:46:31 --> Controller Class Initialized
DEBUG - 2024-01-18 11:46:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:46:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:46:31 --> Model Class Initialized
DEBUG - 2024-01-18 11:46:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:46:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:46:31 --> Model Class Initialized
DEBUG - 2024-01-18 11:46:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:46:31 --> Model Class Initialized
INFO - 2024-01-18 11:46:31 --> Final output sent to browser
DEBUG - 2024-01-18 11:46:31 --> Total execution time: 0.0341
ERROR - 2024-01-18 11:49:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:49:49 --> Config Class Initialized
INFO - 2024-01-18 11:49:49 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:49:49 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:49:49 --> Utf8 Class Initialized
INFO - 2024-01-18 11:49:49 --> URI Class Initialized
INFO - 2024-01-18 11:49:49 --> Router Class Initialized
INFO - 2024-01-18 11:49:49 --> Output Class Initialized
INFO - 2024-01-18 11:49:49 --> Security Class Initialized
DEBUG - 2024-01-18 11:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:49:49 --> Input Class Initialized
INFO - 2024-01-18 11:49:49 --> Language Class Initialized
INFO - 2024-01-18 11:49:49 --> Loader Class Initialized
INFO - 2024-01-18 11:49:49 --> Helper loaded: url_helper
INFO - 2024-01-18 11:49:49 --> Helper loaded: file_helper
INFO - 2024-01-18 11:49:49 --> Helper loaded: html_helper
INFO - 2024-01-18 11:49:49 --> Helper loaded: text_helper
INFO - 2024-01-18 11:49:49 --> Helper loaded: form_helper
INFO - 2024-01-18 11:49:49 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:49:49 --> Helper loaded: security_helper
INFO - 2024-01-18 11:49:49 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:49:49 --> Database Driver Class Initialized
INFO - 2024-01-18 11:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:49:49 --> Parser Class Initialized
INFO - 2024-01-18 11:49:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:49:49 --> Pagination Class Initialized
INFO - 2024-01-18 11:49:49 --> Form Validation Class Initialized
INFO - 2024-01-18 11:49:49 --> Controller Class Initialized
DEBUG - 2024-01-18 11:49:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:49:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:49:49 --> Model Class Initialized
DEBUG - 2024-01-18 11:49:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:49:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:49:49 --> Model Class Initialized
DEBUG - 2024-01-18 11:49:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:49:49 --> Model Class Initialized
INFO - 2024-01-18 11:49:49 --> Final output sent to browser
DEBUG - 2024-01-18 11:49:49 --> Total execution time: 0.0384
ERROR - 2024-01-18 11:49:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 11:49:49 --> Config Class Initialized
INFO - 2024-01-18 11:49:49 --> Hooks Class Initialized
DEBUG - 2024-01-18 11:49:49 --> UTF-8 Support Enabled
INFO - 2024-01-18 11:49:49 --> Utf8 Class Initialized
INFO - 2024-01-18 11:49:49 --> URI Class Initialized
INFO - 2024-01-18 11:49:49 --> Router Class Initialized
INFO - 2024-01-18 11:49:49 --> Output Class Initialized
INFO - 2024-01-18 11:49:49 --> Security Class Initialized
DEBUG - 2024-01-18 11:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 11:49:49 --> Input Class Initialized
INFO - 2024-01-18 11:49:49 --> Language Class Initialized
INFO - 2024-01-18 11:49:49 --> Loader Class Initialized
INFO - 2024-01-18 11:49:49 --> Helper loaded: url_helper
INFO - 2024-01-18 11:49:49 --> Helper loaded: file_helper
INFO - 2024-01-18 11:49:49 --> Helper loaded: html_helper
INFO - 2024-01-18 11:49:49 --> Helper loaded: text_helper
INFO - 2024-01-18 11:49:49 --> Helper loaded: form_helper
INFO - 2024-01-18 11:49:49 --> Helper loaded: lang_helper
INFO - 2024-01-18 11:49:49 --> Helper loaded: security_helper
INFO - 2024-01-18 11:49:49 --> Helper loaded: cookie_helper
INFO - 2024-01-18 11:49:49 --> Database Driver Class Initialized
INFO - 2024-01-18 11:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 11:49:49 --> Parser Class Initialized
INFO - 2024-01-18 11:49:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 11:49:49 --> Pagination Class Initialized
INFO - 2024-01-18 11:49:49 --> Form Validation Class Initialized
INFO - 2024-01-18 11:49:49 --> Controller Class Initialized
DEBUG - 2024-01-18 11:49:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:49:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:49:49 --> Model Class Initialized
DEBUG - 2024-01-18 11:49:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 11:49:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:49:49 --> Model Class Initialized
DEBUG - 2024-01-18 11:49:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 11:49:49 --> Model Class Initialized
INFO - 2024-01-18 11:49:49 --> Final output sent to browser
DEBUG - 2024-01-18 11:49:49 --> Total execution time: 0.0341
ERROR - 2024-01-18 12:03:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 12:03:45 --> Config Class Initialized
INFO - 2024-01-18 12:03:45 --> Hooks Class Initialized
DEBUG - 2024-01-18 12:03:45 --> UTF-8 Support Enabled
INFO - 2024-01-18 12:03:45 --> Utf8 Class Initialized
INFO - 2024-01-18 12:03:45 --> URI Class Initialized
INFO - 2024-01-18 12:03:45 --> Router Class Initialized
INFO - 2024-01-18 12:03:45 --> Output Class Initialized
INFO - 2024-01-18 12:03:45 --> Security Class Initialized
DEBUG - 2024-01-18 12:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 12:03:45 --> Input Class Initialized
INFO - 2024-01-18 12:03:45 --> Language Class Initialized
INFO - 2024-01-18 12:03:45 --> Loader Class Initialized
INFO - 2024-01-18 12:03:45 --> Helper loaded: url_helper
INFO - 2024-01-18 12:03:45 --> Helper loaded: file_helper
INFO - 2024-01-18 12:03:45 --> Helper loaded: html_helper
INFO - 2024-01-18 12:03:45 --> Helper loaded: text_helper
INFO - 2024-01-18 12:03:45 --> Helper loaded: form_helper
INFO - 2024-01-18 12:03:45 --> Helper loaded: lang_helper
INFO - 2024-01-18 12:03:45 --> Helper loaded: security_helper
INFO - 2024-01-18 12:03:45 --> Helper loaded: cookie_helper
INFO - 2024-01-18 12:03:45 --> Database Driver Class Initialized
INFO - 2024-01-18 12:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 12:03:45 --> Parser Class Initialized
INFO - 2024-01-18 12:03:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 12:03:45 --> Pagination Class Initialized
INFO - 2024-01-18 12:03:45 --> Form Validation Class Initialized
INFO - 2024-01-18 12:03:45 --> Controller Class Initialized
DEBUG - 2024-01-18 12:03:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 12:03:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:03:45 --> Model Class Initialized
DEBUG - 2024-01-18 12:03:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 12:03:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:03:45 --> Model Class Initialized
DEBUG - 2024-01-18 12:03:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:03:45 --> Model Class Initialized
INFO - 2024-01-18 12:03:45 --> Final output sent to browser
DEBUG - 2024-01-18 12:03:45 --> Total execution time: 0.0229
ERROR - 2024-01-18 12:03:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 12:03:56 --> Config Class Initialized
INFO - 2024-01-18 12:03:56 --> Hooks Class Initialized
DEBUG - 2024-01-18 12:03:56 --> UTF-8 Support Enabled
INFO - 2024-01-18 12:03:56 --> Utf8 Class Initialized
INFO - 2024-01-18 12:03:56 --> URI Class Initialized
INFO - 2024-01-18 12:03:56 --> Router Class Initialized
INFO - 2024-01-18 12:03:56 --> Output Class Initialized
INFO - 2024-01-18 12:03:56 --> Security Class Initialized
DEBUG - 2024-01-18 12:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 12:03:56 --> Input Class Initialized
INFO - 2024-01-18 12:03:56 --> Language Class Initialized
INFO - 2024-01-18 12:03:56 --> Loader Class Initialized
INFO - 2024-01-18 12:03:56 --> Helper loaded: url_helper
INFO - 2024-01-18 12:03:56 --> Helper loaded: file_helper
INFO - 2024-01-18 12:03:56 --> Helper loaded: html_helper
INFO - 2024-01-18 12:03:56 --> Helper loaded: text_helper
INFO - 2024-01-18 12:03:56 --> Helper loaded: form_helper
INFO - 2024-01-18 12:03:56 --> Helper loaded: lang_helper
INFO - 2024-01-18 12:03:56 --> Helper loaded: security_helper
INFO - 2024-01-18 12:03:56 --> Helper loaded: cookie_helper
INFO - 2024-01-18 12:03:56 --> Database Driver Class Initialized
INFO - 2024-01-18 12:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 12:03:56 --> Parser Class Initialized
INFO - 2024-01-18 12:03:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 12:03:56 --> Pagination Class Initialized
INFO - 2024-01-18 12:03:56 --> Form Validation Class Initialized
INFO - 2024-01-18 12:03:56 --> Controller Class Initialized
DEBUG - 2024-01-18 12:03:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 12:03:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:03:56 --> Model Class Initialized
DEBUG - 2024-01-18 12:03:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 12:03:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:03:56 --> Model Class Initialized
DEBUG - 2024-01-18 12:03:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:03:56 --> Model Class Initialized
INFO - 2024-01-18 12:03:56 --> Final output sent to browser
DEBUG - 2024-01-18 12:03:56 --> Total execution time: 0.0362
ERROR - 2024-01-18 12:04:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 12:04:05 --> Config Class Initialized
INFO - 2024-01-18 12:04:05 --> Hooks Class Initialized
DEBUG - 2024-01-18 12:04:05 --> UTF-8 Support Enabled
INFO - 2024-01-18 12:04:05 --> Utf8 Class Initialized
INFO - 2024-01-18 12:04:05 --> URI Class Initialized
INFO - 2024-01-18 12:04:05 --> Router Class Initialized
INFO - 2024-01-18 12:04:05 --> Output Class Initialized
INFO - 2024-01-18 12:04:05 --> Security Class Initialized
DEBUG - 2024-01-18 12:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 12:04:05 --> Input Class Initialized
INFO - 2024-01-18 12:04:05 --> Language Class Initialized
INFO - 2024-01-18 12:04:05 --> Loader Class Initialized
INFO - 2024-01-18 12:04:05 --> Helper loaded: url_helper
INFO - 2024-01-18 12:04:05 --> Helper loaded: file_helper
INFO - 2024-01-18 12:04:05 --> Helper loaded: html_helper
INFO - 2024-01-18 12:04:05 --> Helper loaded: text_helper
INFO - 2024-01-18 12:04:05 --> Helper loaded: form_helper
INFO - 2024-01-18 12:04:05 --> Helper loaded: lang_helper
INFO - 2024-01-18 12:04:05 --> Helper loaded: security_helper
INFO - 2024-01-18 12:04:05 --> Helper loaded: cookie_helper
INFO - 2024-01-18 12:04:05 --> Database Driver Class Initialized
INFO - 2024-01-18 12:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 12:04:05 --> Parser Class Initialized
INFO - 2024-01-18 12:04:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 12:04:05 --> Pagination Class Initialized
INFO - 2024-01-18 12:04:05 --> Form Validation Class Initialized
INFO - 2024-01-18 12:04:05 --> Controller Class Initialized
DEBUG - 2024-01-18 12:04:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 12:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:04:05 --> Model Class Initialized
DEBUG - 2024-01-18 12:04:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 12:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:04:05 --> Model Class Initialized
DEBUG - 2024-01-18 12:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:04:05 --> Model Class Initialized
INFO - 2024-01-18 12:04:05 --> Final output sent to browser
DEBUG - 2024-01-18 12:04:05 --> Total execution time: 0.0352
ERROR - 2024-01-18 12:06:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 12:06:19 --> Config Class Initialized
INFO - 2024-01-18 12:06:19 --> Hooks Class Initialized
DEBUG - 2024-01-18 12:06:19 --> UTF-8 Support Enabled
INFO - 2024-01-18 12:06:19 --> Utf8 Class Initialized
INFO - 2024-01-18 12:06:19 --> URI Class Initialized
INFO - 2024-01-18 12:06:19 --> Router Class Initialized
INFO - 2024-01-18 12:06:19 --> Output Class Initialized
INFO - 2024-01-18 12:06:19 --> Security Class Initialized
DEBUG - 2024-01-18 12:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 12:06:19 --> Input Class Initialized
INFO - 2024-01-18 12:06:19 --> Language Class Initialized
INFO - 2024-01-18 12:06:19 --> Loader Class Initialized
INFO - 2024-01-18 12:06:19 --> Helper loaded: url_helper
INFO - 2024-01-18 12:06:19 --> Helper loaded: file_helper
INFO - 2024-01-18 12:06:19 --> Helper loaded: html_helper
INFO - 2024-01-18 12:06:19 --> Helper loaded: text_helper
INFO - 2024-01-18 12:06:19 --> Helper loaded: form_helper
INFO - 2024-01-18 12:06:19 --> Helper loaded: lang_helper
INFO - 2024-01-18 12:06:19 --> Helper loaded: security_helper
INFO - 2024-01-18 12:06:19 --> Helper loaded: cookie_helper
INFO - 2024-01-18 12:06:19 --> Database Driver Class Initialized
INFO - 2024-01-18 12:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 12:06:19 --> Parser Class Initialized
INFO - 2024-01-18 12:06:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 12:06:19 --> Pagination Class Initialized
INFO - 2024-01-18 12:06:19 --> Form Validation Class Initialized
INFO - 2024-01-18 12:06:19 --> Controller Class Initialized
DEBUG - 2024-01-18 12:06:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 12:06:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:06:19 --> Model Class Initialized
DEBUG - 2024-01-18 12:06:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 12:06:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:06:19 --> Model Class Initialized
DEBUG - 2024-01-18 12:06:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:06:19 --> Model Class Initialized
INFO - 2024-01-18 12:06:19 --> Final output sent to browser
DEBUG - 2024-01-18 12:06:19 --> Total execution time: 0.0397
ERROR - 2024-01-18 12:31:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 12:31:11 --> Config Class Initialized
INFO - 2024-01-18 12:31:11 --> Hooks Class Initialized
DEBUG - 2024-01-18 12:31:11 --> UTF-8 Support Enabled
INFO - 2024-01-18 12:31:11 --> Utf8 Class Initialized
INFO - 2024-01-18 12:31:11 --> URI Class Initialized
INFO - 2024-01-18 12:31:11 --> Router Class Initialized
INFO - 2024-01-18 12:31:11 --> Output Class Initialized
INFO - 2024-01-18 12:31:11 --> Security Class Initialized
DEBUG - 2024-01-18 12:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 12:31:11 --> Input Class Initialized
INFO - 2024-01-18 12:31:11 --> Language Class Initialized
INFO - 2024-01-18 12:31:11 --> Loader Class Initialized
INFO - 2024-01-18 12:31:11 --> Helper loaded: url_helper
INFO - 2024-01-18 12:31:11 --> Helper loaded: file_helper
INFO - 2024-01-18 12:31:11 --> Helper loaded: html_helper
INFO - 2024-01-18 12:31:11 --> Helper loaded: text_helper
INFO - 2024-01-18 12:31:11 --> Helper loaded: form_helper
INFO - 2024-01-18 12:31:11 --> Helper loaded: lang_helper
INFO - 2024-01-18 12:31:11 --> Helper loaded: security_helper
INFO - 2024-01-18 12:31:11 --> Helper loaded: cookie_helper
INFO - 2024-01-18 12:31:11 --> Database Driver Class Initialized
INFO - 2024-01-18 12:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 12:31:11 --> Parser Class Initialized
INFO - 2024-01-18 12:31:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 12:31:11 --> Pagination Class Initialized
INFO - 2024-01-18 12:31:11 --> Form Validation Class Initialized
INFO - 2024-01-18 12:31:11 --> Controller Class Initialized
ERROR - 2024-01-18 12:31:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 12:31:11 --> Config Class Initialized
INFO - 2024-01-18 12:31:11 --> Hooks Class Initialized
DEBUG - 2024-01-18 12:31:11 --> UTF-8 Support Enabled
INFO - 2024-01-18 12:31:11 --> Utf8 Class Initialized
INFO - 2024-01-18 12:31:11 --> URI Class Initialized
INFO - 2024-01-18 12:31:11 --> Router Class Initialized
INFO - 2024-01-18 12:31:11 --> Output Class Initialized
INFO - 2024-01-18 12:31:11 --> Security Class Initialized
DEBUG - 2024-01-18 12:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 12:31:11 --> Input Class Initialized
INFO - 2024-01-18 12:31:11 --> Language Class Initialized
INFO - 2024-01-18 12:31:11 --> Loader Class Initialized
INFO - 2024-01-18 12:31:11 --> Helper loaded: url_helper
INFO - 2024-01-18 12:31:11 --> Helper loaded: file_helper
INFO - 2024-01-18 12:31:11 --> Helper loaded: html_helper
INFO - 2024-01-18 12:31:11 --> Helper loaded: text_helper
INFO - 2024-01-18 12:31:11 --> Helper loaded: form_helper
INFO - 2024-01-18 12:31:11 --> Helper loaded: lang_helper
INFO - 2024-01-18 12:31:11 --> Helper loaded: security_helper
INFO - 2024-01-18 12:31:11 --> Helper loaded: cookie_helper
INFO - 2024-01-18 12:31:11 --> Database Driver Class Initialized
INFO - 2024-01-18 12:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 12:31:11 --> Parser Class Initialized
INFO - 2024-01-18 12:31:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 12:31:11 --> Pagination Class Initialized
INFO - 2024-01-18 12:31:11 --> Form Validation Class Initialized
INFO - 2024-01-18 12:31:11 --> Controller Class Initialized
INFO - 2024-01-18 12:31:11 --> Model Class Initialized
DEBUG - 2024-01-18 12:31:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:31:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-18 12:31:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:31:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 12:31:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 12:31:11 --> Model Class Initialized
INFO - 2024-01-18 12:31:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 12:31:11 --> Final output sent to browser
DEBUG - 2024-01-18 12:31:11 --> Total execution time: 0.0354
ERROR - 2024-01-18 12:33:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 12:33:47 --> Config Class Initialized
INFO - 2024-01-18 12:33:47 --> Hooks Class Initialized
DEBUG - 2024-01-18 12:33:47 --> UTF-8 Support Enabled
INFO - 2024-01-18 12:33:47 --> Utf8 Class Initialized
INFO - 2024-01-18 12:33:47 --> URI Class Initialized
DEBUG - 2024-01-18 12:33:47 --> No URI present. Default controller set.
INFO - 2024-01-18 12:33:47 --> Router Class Initialized
INFO - 2024-01-18 12:33:47 --> Output Class Initialized
INFO - 2024-01-18 12:33:47 --> Security Class Initialized
DEBUG - 2024-01-18 12:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 12:33:47 --> Input Class Initialized
INFO - 2024-01-18 12:33:47 --> Language Class Initialized
INFO - 2024-01-18 12:33:47 --> Loader Class Initialized
INFO - 2024-01-18 12:33:47 --> Helper loaded: url_helper
INFO - 2024-01-18 12:33:47 --> Helper loaded: file_helper
INFO - 2024-01-18 12:33:47 --> Helper loaded: html_helper
INFO - 2024-01-18 12:33:47 --> Helper loaded: text_helper
INFO - 2024-01-18 12:33:47 --> Helper loaded: form_helper
INFO - 2024-01-18 12:33:47 --> Helper loaded: lang_helper
INFO - 2024-01-18 12:33:47 --> Helper loaded: security_helper
INFO - 2024-01-18 12:33:47 --> Helper loaded: cookie_helper
INFO - 2024-01-18 12:33:47 --> Database Driver Class Initialized
INFO - 2024-01-18 12:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 12:33:47 --> Parser Class Initialized
INFO - 2024-01-18 12:33:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 12:33:47 --> Pagination Class Initialized
INFO - 2024-01-18 12:33:47 --> Form Validation Class Initialized
INFO - 2024-01-18 12:33:47 --> Controller Class Initialized
INFO - 2024-01-18 12:33:47 --> Model Class Initialized
DEBUG - 2024-01-18 12:33:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:33:47 --> Model Class Initialized
DEBUG - 2024-01-18 12:33:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:33:47 --> Model Class Initialized
INFO - 2024-01-18 12:33:47 --> Model Class Initialized
INFO - 2024-01-18 12:33:47 --> Model Class Initialized
INFO - 2024-01-18 12:33:47 --> Model Class Initialized
DEBUG - 2024-01-18 12:33:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 12:33:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:33:47 --> Model Class Initialized
INFO - 2024-01-18 12:33:47 --> Model Class Initialized
INFO - 2024-01-18 12:33:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-18 12:33:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:33:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 12:33:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 12:33:47 --> Model Class Initialized
INFO - 2024-01-18 12:33:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 12:33:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 12:33:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 12:33:47 --> Final output sent to browser
DEBUG - 2024-01-18 12:33:47 --> Total execution time: 0.4118
ERROR - 2024-01-18 12:34:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 12:34:02 --> Config Class Initialized
INFO - 2024-01-18 12:34:02 --> Hooks Class Initialized
DEBUG - 2024-01-18 12:34:02 --> UTF-8 Support Enabled
INFO - 2024-01-18 12:34:02 --> Utf8 Class Initialized
INFO - 2024-01-18 12:34:02 --> URI Class Initialized
INFO - 2024-01-18 12:34:02 --> Router Class Initialized
INFO - 2024-01-18 12:34:02 --> Output Class Initialized
INFO - 2024-01-18 12:34:02 --> Security Class Initialized
DEBUG - 2024-01-18 12:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 12:34:02 --> Input Class Initialized
INFO - 2024-01-18 12:34:02 --> Language Class Initialized
INFO - 2024-01-18 12:34:02 --> Loader Class Initialized
INFO - 2024-01-18 12:34:02 --> Helper loaded: url_helper
INFO - 2024-01-18 12:34:02 --> Helper loaded: file_helper
INFO - 2024-01-18 12:34:02 --> Helper loaded: html_helper
INFO - 2024-01-18 12:34:02 --> Helper loaded: text_helper
INFO - 2024-01-18 12:34:02 --> Helper loaded: form_helper
INFO - 2024-01-18 12:34:02 --> Helper loaded: lang_helper
INFO - 2024-01-18 12:34:02 --> Helper loaded: security_helper
INFO - 2024-01-18 12:34:02 --> Helper loaded: cookie_helper
INFO - 2024-01-18 12:34:02 --> Database Driver Class Initialized
INFO - 2024-01-18 12:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 12:34:02 --> Parser Class Initialized
INFO - 2024-01-18 12:34:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 12:34:02 --> Pagination Class Initialized
INFO - 2024-01-18 12:34:02 --> Form Validation Class Initialized
INFO - 2024-01-18 12:34:02 --> Controller Class Initialized
INFO - 2024-01-18 12:34:02 --> Model Class Initialized
DEBUG - 2024-01-18 12:34:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 12:34:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:34:02 --> Model Class Initialized
DEBUG - 2024-01-18 12:34:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:34:02 --> Model Class Initialized
INFO - 2024-01-18 12:34:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-18 12:34:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:34:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 12:34:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 12:34:02 --> Model Class Initialized
INFO - 2024-01-18 12:34:02 --> Model Class Initialized
INFO - 2024-01-18 12:34:02 --> Model Class Initialized
INFO - 2024-01-18 12:34:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 12:34:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 12:34:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 12:34:02 --> Final output sent to browser
DEBUG - 2024-01-18 12:34:02 --> Total execution time: 0.2182
ERROR - 2024-01-18 12:34:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 12:34:03 --> Config Class Initialized
INFO - 2024-01-18 12:34:03 --> Hooks Class Initialized
DEBUG - 2024-01-18 12:34:03 --> UTF-8 Support Enabled
INFO - 2024-01-18 12:34:03 --> Utf8 Class Initialized
INFO - 2024-01-18 12:34:03 --> URI Class Initialized
INFO - 2024-01-18 12:34:03 --> Router Class Initialized
INFO - 2024-01-18 12:34:03 --> Output Class Initialized
INFO - 2024-01-18 12:34:03 --> Security Class Initialized
DEBUG - 2024-01-18 12:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 12:34:03 --> Input Class Initialized
INFO - 2024-01-18 12:34:03 --> Language Class Initialized
INFO - 2024-01-18 12:34:03 --> Loader Class Initialized
INFO - 2024-01-18 12:34:03 --> Helper loaded: url_helper
INFO - 2024-01-18 12:34:03 --> Helper loaded: file_helper
INFO - 2024-01-18 12:34:03 --> Helper loaded: html_helper
INFO - 2024-01-18 12:34:03 --> Helper loaded: text_helper
INFO - 2024-01-18 12:34:03 --> Helper loaded: form_helper
INFO - 2024-01-18 12:34:03 --> Helper loaded: lang_helper
INFO - 2024-01-18 12:34:03 --> Helper loaded: security_helper
INFO - 2024-01-18 12:34:03 --> Helper loaded: cookie_helper
INFO - 2024-01-18 12:34:03 --> Database Driver Class Initialized
INFO - 2024-01-18 12:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 12:34:03 --> Parser Class Initialized
INFO - 2024-01-18 12:34:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 12:34:03 --> Pagination Class Initialized
INFO - 2024-01-18 12:34:03 --> Form Validation Class Initialized
INFO - 2024-01-18 12:34:03 --> Controller Class Initialized
INFO - 2024-01-18 12:34:03 --> Model Class Initialized
DEBUG - 2024-01-18 12:34:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 12:34:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:34:03 --> Model Class Initialized
DEBUG - 2024-01-18 12:34:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:34:03 --> Model Class Initialized
INFO - 2024-01-18 12:34:03 --> Final output sent to browser
DEBUG - 2024-01-18 12:34:03 --> Total execution time: 0.0646
ERROR - 2024-01-18 12:34:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 12:34:20 --> Config Class Initialized
INFO - 2024-01-18 12:34:20 --> Hooks Class Initialized
DEBUG - 2024-01-18 12:34:20 --> UTF-8 Support Enabled
INFO - 2024-01-18 12:34:20 --> Utf8 Class Initialized
INFO - 2024-01-18 12:34:20 --> URI Class Initialized
DEBUG - 2024-01-18 12:34:20 --> No URI present. Default controller set.
INFO - 2024-01-18 12:34:20 --> Router Class Initialized
INFO - 2024-01-18 12:34:20 --> Output Class Initialized
INFO - 2024-01-18 12:34:20 --> Security Class Initialized
DEBUG - 2024-01-18 12:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 12:34:20 --> Input Class Initialized
INFO - 2024-01-18 12:34:20 --> Language Class Initialized
INFO - 2024-01-18 12:34:20 --> Loader Class Initialized
INFO - 2024-01-18 12:34:20 --> Helper loaded: url_helper
INFO - 2024-01-18 12:34:20 --> Helper loaded: file_helper
INFO - 2024-01-18 12:34:20 --> Helper loaded: html_helper
INFO - 2024-01-18 12:34:20 --> Helper loaded: text_helper
INFO - 2024-01-18 12:34:20 --> Helper loaded: form_helper
INFO - 2024-01-18 12:34:20 --> Helper loaded: lang_helper
INFO - 2024-01-18 12:34:20 --> Helper loaded: security_helper
INFO - 2024-01-18 12:34:20 --> Helper loaded: cookie_helper
INFO - 2024-01-18 12:34:20 --> Database Driver Class Initialized
INFO - 2024-01-18 12:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 12:34:20 --> Parser Class Initialized
INFO - 2024-01-18 12:34:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 12:34:20 --> Pagination Class Initialized
INFO - 2024-01-18 12:34:20 --> Form Validation Class Initialized
INFO - 2024-01-18 12:34:20 --> Controller Class Initialized
INFO - 2024-01-18 12:34:20 --> Model Class Initialized
DEBUG - 2024-01-18 12:34:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:34:20 --> Model Class Initialized
DEBUG - 2024-01-18 12:34:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:34:20 --> Model Class Initialized
INFO - 2024-01-18 12:34:20 --> Model Class Initialized
INFO - 2024-01-18 12:34:20 --> Model Class Initialized
INFO - 2024-01-18 12:34:20 --> Model Class Initialized
DEBUG - 2024-01-18 12:34:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 12:34:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:34:20 --> Model Class Initialized
INFO - 2024-01-18 12:34:20 --> Model Class Initialized
INFO - 2024-01-18 12:34:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-18 12:34:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:34:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 12:34:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 12:34:20 --> Model Class Initialized
INFO - 2024-01-18 12:34:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 12:34:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 12:34:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 12:34:20 --> Final output sent to browser
DEBUG - 2024-01-18 12:34:20 --> Total execution time: 0.4157
ERROR - 2024-01-18 12:34:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 12:34:54 --> Config Class Initialized
INFO - 2024-01-18 12:34:54 --> Hooks Class Initialized
DEBUG - 2024-01-18 12:34:54 --> UTF-8 Support Enabled
INFO - 2024-01-18 12:34:54 --> Utf8 Class Initialized
INFO - 2024-01-18 12:34:54 --> URI Class Initialized
INFO - 2024-01-18 12:34:54 --> Router Class Initialized
INFO - 2024-01-18 12:34:54 --> Output Class Initialized
INFO - 2024-01-18 12:34:54 --> Security Class Initialized
DEBUG - 2024-01-18 12:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 12:34:54 --> Input Class Initialized
INFO - 2024-01-18 12:34:54 --> Language Class Initialized
INFO - 2024-01-18 12:34:54 --> Loader Class Initialized
INFO - 2024-01-18 12:34:54 --> Helper loaded: url_helper
INFO - 2024-01-18 12:34:54 --> Helper loaded: file_helper
INFO - 2024-01-18 12:34:54 --> Helper loaded: html_helper
INFO - 2024-01-18 12:34:54 --> Helper loaded: text_helper
INFO - 2024-01-18 12:34:54 --> Helper loaded: form_helper
INFO - 2024-01-18 12:34:54 --> Helper loaded: lang_helper
INFO - 2024-01-18 12:34:54 --> Helper loaded: security_helper
INFO - 2024-01-18 12:34:54 --> Helper loaded: cookie_helper
INFO - 2024-01-18 12:34:54 --> Database Driver Class Initialized
INFO - 2024-01-18 12:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 12:34:54 --> Parser Class Initialized
INFO - 2024-01-18 12:34:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 12:34:54 --> Pagination Class Initialized
INFO - 2024-01-18 12:34:54 --> Form Validation Class Initialized
INFO - 2024-01-18 12:34:54 --> Controller Class Initialized
DEBUG - 2024-01-18 12:34:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 12:34:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:34:54 --> Model Class Initialized
INFO - 2024-01-18 12:34:54 --> Model Class Initialized
DEBUG - 2024-01-18 12:34:54 --> Lmr class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:34:54 --> Model Class Initialized
INFO - 2024-01-18 12:34:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/mr/mr.php
DEBUG - 2024-01-18 12:34:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:34:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 12:34:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 12:34:54 --> Model Class Initialized
INFO - 2024-01-18 12:34:54 --> Model Class Initialized
INFO - 2024-01-18 12:34:54 --> Model Class Initialized
INFO - 2024-01-18 12:34:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 12:34:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 12:34:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 12:34:54 --> Final output sent to browser
DEBUG - 2024-01-18 12:34:54 --> Total execution time: 0.2091
ERROR - 2024-01-18 12:34:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 12:34:55 --> Config Class Initialized
INFO - 2024-01-18 12:34:55 --> Hooks Class Initialized
DEBUG - 2024-01-18 12:34:55 --> UTF-8 Support Enabled
INFO - 2024-01-18 12:34:55 --> Utf8 Class Initialized
INFO - 2024-01-18 12:34:55 --> URI Class Initialized
INFO - 2024-01-18 12:34:55 --> Router Class Initialized
INFO - 2024-01-18 12:34:55 --> Output Class Initialized
INFO - 2024-01-18 12:34:55 --> Security Class Initialized
DEBUG - 2024-01-18 12:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 12:34:55 --> Input Class Initialized
INFO - 2024-01-18 12:34:55 --> Language Class Initialized
INFO - 2024-01-18 12:34:55 --> Loader Class Initialized
INFO - 2024-01-18 12:34:55 --> Helper loaded: url_helper
INFO - 2024-01-18 12:34:55 --> Helper loaded: file_helper
INFO - 2024-01-18 12:34:55 --> Helper loaded: html_helper
INFO - 2024-01-18 12:34:55 --> Helper loaded: text_helper
INFO - 2024-01-18 12:34:55 --> Helper loaded: form_helper
INFO - 2024-01-18 12:34:55 --> Helper loaded: lang_helper
INFO - 2024-01-18 12:34:55 --> Helper loaded: security_helper
INFO - 2024-01-18 12:34:55 --> Helper loaded: cookie_helper
INFO - 2024-01-18 12:34:55 --> Database Driver Class Initialized
INFO - 2024-01-18 12:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 12:34:55 --> Parser Class Initialized
INFO - 2024-01-18 12:34:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 12:34:55 --> Pagination Class Initialized
INFO - 2024-01-18 12:34:55 --> Form Validation Class Initialized
INFO - 2024-01-18 12:34:55 --> Controller Class Initialized
DEBUG - 2024-01-18 12:34:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 12:34:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:34:55 --> Model Class Initialized
INFO - 2024-01-18 12:34:55 --> Model Class Initialized
INFO - 2024-01-18 12:34:55 --> Final output sent to browser
DEBUG - 2024-01-18 12:34:55 --> Total execution time: 0.0207
ERROR - 2024-01-18 12:35:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 12:35:10 --> Config Class Initialized
INFO - 2024-01-18 12:35:10 --> Hooks Class Initialized
DEBUG - 2024-01-18 12:35:10 --> UTF-8 Support Enabled
INFO - 2024-01-18 12:35:10 --> Utf8 Class Initialized
INFO - 2024-01-18 12:35:10 --> URI Class Initialized
INFO - 2024-01-18 12:35:10 --> Router Class Initialized
INFO - 2024-01-18 12:35:10 --> Output Class Initialized
INFO - 2024-01-18 12:35:10 --> Security Class Initialized
DEBUG - 2024-01-18 12:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 12:35:10 --> Input Class Initialized
INFO - 2024-01-18 12:35:10 --> Language Class Initialized
INFO - 2024-01-18 12:35:10 --> Loader Class Initialized
INFO - 2024-01-18 12:35:10 --> Helper loaded: url_helper
INFO - 2024-01-18 12:35:10 --> Helper loaded: file_helper
INFO - 2024-01-18 12:35:10 --> Helper loaded: html_helper
INFO - 2024-01-18 12:35:10 --> Helper loaded: text_helper
INFO - 2024-01-18 12:35:10 --> Helper loaded: form_helper
INFO - 2024-01-18 12:35:10 --> Helper loaded: lang_helper
INFO - 2024-01-18 12:35:10 --> Helper loaded: security_helper
INFO - 2024-01-18 12:35:10 --> Helper loaded: cookie_helper
INFO - 2024-01-18 12:35:10 --> Database Driver Class Initialized
INFO - 2024-01-18 12:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 12:35:10 --> Parser Class Initialized
INFO - 2024-01-18 12:35:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 12:35:10 --> Pagination Class Initialized
INFO - 2024-01-18 12:35:10 --> Form Validation Class Initialized
INFO - 2024-01-18 12:35:10 --> Controller Class Initialized
DEBUG - 2024-01-18 12:35:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 12:35:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:35:10 --> Model Class Initialized
INFO - 2024-01-18 12:35:10 --> Model Class Initialized
DEBUG - 2024-01-18 12:35:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 12:35:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:35:10 --> Model Class Initialized
DEBUG - 2024-01-18 12:35:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:35:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gst/list.php
DEBUG - 2024-01-18 12:35:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:35:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 12:35:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 12:35:10 --> Model Class Initialized
INFO - 2024-01-18 12:35:10 --> Model Class Initialized
INFO - 2024-01-18 12:35:10 --> Model Class Initialized
INFO - 2024-01-18 12:35:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 12:35:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 12:35:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 12:35:10 --> Final output sent to browser
DEBUG - 2024-01-18 12:35:10 --> Total execution time: 0.2084
ERROR - 2024-01-18 12:35:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 12:35:46 --> Config Class Initialized
INFO - 2024-01-18 12:35:46 --> Hooks Class Initialized
DEBUG - 2024-01-18 12:35:46 --> UTF-8 Support Enabled
INFO - 2024-01-18 12:35:46 --> Utf8 Class Initialized
INFO - 2024-01-18 12:35:46 --> URI Class Initialized
INFO - 2024-01-18 12:35:46 --> Router Class Initialized
INFO - 2024-01-18 12:35:46 --> Output Class Initialized
INFO - 2024-01-18 12:35:46 --> Security Class Initialized
DEBUG - 2024-01-18 12:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 12:35:46 --> Input Class Initialized
INFO - 2024-01-18 12:35:46 --> Language Class Initialized
INFO - 2024-01-18 12:35:46 --> Loader Class Initialized
INFO - 2024-01-18 12:35:46 --> Helper loaded: url_helper
INFO - 2024-01-18 12:35:46 --> Helper loaded: file_helper
INFO - 2024-01-18 12:35:46 --> Helper loaded: html_helper
INFO - 2024-01-18 12:35:46 --> Helper loaded: text_helper
INFO - 2024-01-18 12:35:46 --> Helper loaded: form_helper
INFO - 2024-01-18 12:35:46 --> Helper loaded: lang_helper
INFO - 2024-01-18 12:35:46 --> Helper loaded: security_helper
INFO - 2024-01-18 12:35:46 --> Helper loaded: cookie_helper
INFO - 2024-01-18 12:35:46 --> Database Driver Class Initialized
INFO - 2024-01-18 12:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 12:35:46 --> Parser Class Initialized
INFO - 2024-01-18 12:35:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 12:35:46 --> Pagination Class Initialized
INFO - 2024-01-18 12:35:46 --> Form Validation Class Initialized
INFO - 2024-01-18 12:35:46 --> Controller Class Initialized
INFO - 2024-01-18 12:35:46 --> Model Class Initialized
DEBUG - 2024-01-18 12:35:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 12:35:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:35:46 --> Model Class Initialized
DEBUG - 2024-01-18 12:35:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:35:46 --> Model Class Initialized
INFO - 2024-01-18 12:35:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-18 12:35:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:35:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 12:35:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 12:35:46 --> Model Class Initialized
INFO - 2024-01-18 12:35:46 --> Model Class Initialized
INFO - 2024-01-18 12:35:46 --> Model Class Initialized
INFO - 2024-01-18 12:35:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 12:35:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 12:35:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 12:35:46 --> Final output sent to browser
DEBUG - 2024-01-18 12:35:46 --> Total execution time: 0.2361
ERROR - 2024-01-18 12:35:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 12:35:47 --> Config Class Initialized
INFO - 2024-01-18 12:35:47 --> Hooks Class Initialized
DEBUG - 2024-01-18 12:35:47 --> UTF-8 Support Enabled
INFO - 2024-01-18 12:35:47 --> Utf8 Class Initialized
INFO - 2024-01-18 12:35:47 --> URI Class Initialized
INFO - 2024-01-18 12:35:47 --> Router Class Initialized
INFO - 2024-01-18 12:35:47 --> Output Class Initialized
INFO - 2024-01-18 12:35:47 --> Security Class Initialized
DEBUG - 2024-01-18 12:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 12:35:47 --> Input Class Initialized
INFO - 2024-01-18 12:35:47 --> Language Class Initialized
INFO - 2024-01-18 12:35:47 --> Loader Class Initialized
INFO - 2024-01-18 12:35:47 --> Helper loaded: url_helper
INFO - 2024-01-18 12:35:47 --> Helper loaded: file_helper
INFO - 2024-01-18 12:35:47 --> Helper loaded: html_helper
INFO - 2024-01-18 12:35:47 --> Helper loaded: text_helper
INFO - 2024-01-18 12:35:47 --> Helper loaded: form_helper
INFO - 2024-01-18 12:35:47 --> Helper loaded: lang_helper
INFO - 2024-01-18 12:35:47 --> Helper loaded: security_helper
INFO - 2024-01-18 12:35:47 --> Helper loaded: cookie_helper
INFO - 2024-01-18 12:35:47 --> Database Driver Class Initialized
INFO - 2024-01-18 12:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 12:35:47 --> Parser Class Initialized
INFO - 2024-01-18 12:35:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 12:35:47 --> Pagination Class Initialized
INFO - 2024-01-18 12:35:47 --> Form Validation Class Initialized
INFO - 2024-01-18 12:35:47 --> Controller Class Initialized
INFO - 2024-01-18 12:35:47 --> Model Class Initialized
DEBUG - 2024-01-18 12:35:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 12:35:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:35:47 --> Model Class Initialized
DEBUG - 2024-01-18 12:35:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:35:47 --> Model Class Initialized
INFO - 2024-01-18 12:35:47 --> Final output sent to browser
DEBUG - 2024-01-18 12:35:47 --> Total execution time: 0.0637
ERROR - 2024-01-18 12:36:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 12:36:01 --> Config Class Initialized
INFO - 2024-01-18 12:36:01 --> Hooks Class Initialized
DEBUG - 2024-01-18 12:36:01 --> UTF-8 Support Enabled
INFO - 2024-01-18 12:36:01 --> Utf8 Class Initialized
INFO - 2024-01-18 12:36:01 --> URI Class Initialized
INFO - 2024-01-18 12:36:01 --> Router Class Initialized
INFO - 2024-01-18 12:36:01 --> Output Class Initialized
INFO - 2024-01-18 12:36:01 --> Security Class Initialized
DEBUG - 2024-01-18 12:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 12:36:01 --> Input Class Initialized
INFO - 2024-01-18 12:36:01 --> Language Class Initialized
INFO - 2024-01-18 12:36:01 --> Loader Class Initialized
INFO - 2024-01-18 12:36:01 --> Helper loaded: url_helper
INFO - 2024-01-18 12:36:01 --> Helper loaded: file_helper
INFO - 2024-01-18 12:36:01 --> Helper loaded: html_helper
INFO - 2024-01-18 12:36:01 --> Helper loaded: text_helper
INFO - 2024-01-18 12:36:01 --> Helper loaded: form_helper
INFO - 2024-01-18 12:36:01 --> Helper loaded: lang_helper
INFO - 2024-01-18 12:36:01 --> Helper loaded: security_helper
INFO - 2024-01-18 12:36:01 --> Helper loaded: cookie_helper
INFO - 2024-01-18 12:36:01 --> Database Driver Class Initialized
INFO - 2024-01-18 12:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 12:36:01 --> Parser Class Initialized
INFO - 2024-01-18 12:36:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 12:36:01 --> Pagination Class Initialized
INFO - 2024-01-18 12:36:01 --> Form Validation Class Initialized
INFO - 2024-01-18 12:36:01 --> Controller Class Initialized
INFO - 2024-01-18 12:36:01 --> Model Class Initialized
DEBUG - 2024-01-18 12:36:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:36:01 --> Final output sent to browser
DEBUG - 2024-01-18 12:36:01 --> Total execution time: 0.0156
ERROR - 2024-01-18 12:36:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 12:36:02 --> Config Class Initialized
INFO - 2024-01-18 12:36:02 --> Hooks Class Initialized
DEBUG - 2024-01-18 12:36:02 --> UTF-8 Support Enabled
INFO - 2024-01-18 12:36:02 --> Utf8 Class Initialized
INFO - 2024-01-18 12:36:02 --> URI Class Initialized
INFO - 2024-01-18 12:36:02 --> Router Class Initialized
INFO - 2024-01-18 12:36:02 --> Output Class Initialized
INFO - 2024-01-18 12:36:02 --> Security Class Initialized
DEBUG - 2024-01-18 12:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 12:36:02 --> Input Class Initialized
INFO - 2024-01-18 12:36:02 --> Language Class Initialized
INFO - 2024-01-18 12:36:02 --> Loader Class Initialized
INFO - 2024-01-18 12:36:02 --> Helper loaded: url_helper
INFO - 2024-01-18 12:36:02 --> Helper loaded: file_helper
INFO - 2024-01-18 12:36:02 --> Helper loaded: html_helper
INFO - 2024-01-18 12:36:02 --> Helper loaded: text_helper
INFO - 2024-01-18 12:36:02 --> Helper loaded: form_helper
INFO - 2024-01-18 12:36:02 --> Helper loaded: lang_helper
INFO - 2024-01-18 12:36:02 --> Helper loaded: security_helper
INFO - 2024-01-18 12:36:02 --> Helper loaded: cookie_helper
INFO - 2024-01-18 12:36:02 --> Database Driver Class Initialized
INFO - 2024-01-18 12:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 12:36:02 --> Parser Class Initialized
INFO - 2024-01-18 12:36:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 12:36:02 --> Pagination Class Initialized
INFO - 2024-01-18 12:36:02 --> Form Validation Class Initialized
INFO - 2024-01-18 12:36:02 --> Controller Class Initialized
INFO - 2024-01-18 12:36:02 --> Model Class Initialized
DEBUG - 2024-01-18 12:36:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:36:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-18 12:36:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:36:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 12:36:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 12:36:02 --> Model Class Initialized
INFO - 2024-01-18 12:36:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 12:36:02 --> Final output sent to browser
DEBUG - 2024-01-18 12:36:02 --> Total execution time: 0.0448
ERROR - 2024-01-18 12:36:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 12:36:07 --> Config Class Initialized
INFO - 2024-01-18 12:36:07 --> Hooks Class Initialized
DEBUG - 2024-01-18 12:36:07 --> UTF-8 Support Enabled
INFO - 2024-01-18 12:36:07 --> Utf8 Class Initialized
INFO - 2024-01-18 12:36:07 --> URI Class Initialized
INFO - 2024-01-18 12:36:07 --> Router Class Initialized
INFO - 2024-01-18 12:36:07 --> Output Class Initialized
INFO - 2024-01-18 12:36:07 --> Security Class Initialized
DEBUG - 2024-01-18 12:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 12:36:07 --> Input Class Initialized
INFO - 2024-01-18 12:36:07 --> Language Class Initialized
INFO - 2024-01-18 12:36:07 --> Loader Class Initialized
INFO - 2024-01-18 12:36:07 --> Helper loaded: url_helper
INFO - 2024-01-18 12:36:07 --> Helper loaded: file_helper
INFO - 2024-01-18 12:36:07 --> Helper loaded: html_helper
INFO - 2024-01-18 12:36:07 --> Helper loaded: text_helper
INFO - 2024-01-18 12:36:07 --> Helper loaded: form_helper
INFO - 2024-01-18 12:36:07 --> Helper loaded: lang_helper
INFO - 2024-01-18 12:36:07 --> Helper loaded: security_helper
INFO - 2024-01-18 12:36:07 --> Helper loaded: cookie_helper
INFO - 2024-01-18 12:36:07 --> Database Driver Class Initialized
INFO - 2024-01-18 12:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 12:36:07 --> Parser Class Initialized
INFO - 2024-01-18 12:36:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 12:36:07 --> Pagination Class Initialized
INFO - 2024-01-18 12:36:07 --> Form Validation Class Initialized
INFO - 2024-01-18 12:36:07 --> Controller Class Initialized
INFO - 2024-01-18 12:36:07 --> Model Class Initialized
DEBUG - 2024-01-18 12:36:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:36:07 --> Model Class Initialized
INFO - 2024-01-18 12:36:07 --> Final output sent to browser
DEBUG - 2024-01-18 12:36:07 --> Total execution time: 0.0232
ERROR - 2024-01-18 12:36:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 12:36:07 --> Config Class Initialized
INFO - 2024-01-18 12:36:07 --> Hooks Class Initialized
DEBUG - 2024-01-18 12:36:07 --> UTF-8 Support Enabled
INFO - 2024-01-18 12:36:07 --> Utf8 Class Initialized
INFO - 2024-01-18 12:36:07 --> URI Class Initialized
DEBUG - 2024-01-18 12:36:07 --> No URI present. Default controller set.
INFO - 2024-01-18 12:36:07 --> Router Class Initialized
INFO - 2024-01-18 12:36:07 --> Output Class Initialized
INFO - 2024-01-18 12:36:07 --> Security Class Initialized
DEBUG - 2024-01-18 12:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 12:36:07 --> Input Class Initialized
INFO - 2024-01-18 12:36:07 --> Language Class Initialized
INFO - 2024-01-18 12:36:07 --> Loader Class Initialized
INFO - 2024-01-18 12:36:07 --> Helper loaded: url_helper
INFO - 2024-01-18 12:36:07 --> Helper loaded: file_helper
INFO - 2024-01-18 12:36:07 --> Helper loaded: html_helper
INFO - 2024-01-18 12:36:07 --> Helper loaded: text_helper
INFO - 2024-01-18 12:36:07 --> Helper loaded: form_helper
INFO - 2024-01-18 12:36:07 --> Helper loaded: lang_helper
INFO - 2024-01-18 12:36:07 --> Helper loaded: security_helper
INFO - 2024-01-18 12:36:07 --> Helper loaded: cookie_helper
INFO - 2024-01-18 12:36:07 --> Database Driver Class Initialized
INFO - 2024-01-18 12:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 12:36:07 --> Parser Class Initialized
INFO - 2024-01-18 12:36:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 12:36:07 --> Pagination Class Initialized
INFO - 2024-01-18 12:36:07 --> Form Validation Class Initialized
INFO - 2024-01-18 12:36:07 --> Controller Class Initialized
INFO - 2024-01-18 12:36:07 --> Model Class Initialized
DEBUG - 2024-01-18 12:36:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:36:07 --> Model Class Initialized
DEBUG - 2024-01-18 12:36:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:36:07 --> Model Class Initialized
INFO - 2024-01-18 12:36:07 --> Model Class Initialized
INFO - 2024-01-18 12:36:07 --> Model Class Initialized
INFO - 2024-01-18 12:36:07 --> Model Class Initialized
DEBUG - 2024-01-18 12:36:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 12:36:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:36:07 --> Model Class Initialized
INFO - 2024-01-18 12:36:07 --> Model Class Initialized
INFO - 2024-01-18 12:36:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-18 12:36:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:36:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 12:36:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 12:36:07 --> Model Class Initialized
INFO - 2024-01-18 12:36:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 12:36:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 12:36:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 12:36:08 --> Final output sent to browser
DEBUG - 2024-01-18 12:36:08 --> Total execution time: 0.2582
ERROR - 2024-01-18 12:36:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 12:36:16 --> Config Class Initialized
INFO - 2024-01-18 12:36:16 --> Hooks Class Initialized
DEBUG - 2024-01-18 12:36:16 --> UTF-8 Support Enabled
INFO - 2024-01-18 12:36:16 --> Utf8 Class Initialized
INFO - 2024-01-18 12:36:16 --> URI Class Initialized
INFO - 2024-01-18 12:36:16 --> Router Class Initialized
INFO - 2024-01-18 12:36:16 --> Output Class Initialized
INFO - 2024-01-18 12:36:16 --> Security Class Initialized
DEBUG - 2024-01-18 12:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 12:36:16 --> Input Class Initialized
INFO - 2024-01-18 12:36:16 --> Language Class Initialized
INFO - 2024-01-18 12:36:16 --> Loader Class Initialized
INFO - 2024-01-18 12:36:16 --> Helper loaded: url_helper
INFO - 2024-01-18 12:36:16 --> Helper loaded: file_helper
INFO - 2024-01-18 12:36:16 --> Helper loaded: html_helper
INFO - 2024-01-18 12:36:16 --> Helper loaded: text_helper
INFO - 2024-01-18 12:36:16 --> Helper loaded: form_helper
INFO - 2024-01-18 12:36:16 --> Helper loaded: lang_helper
INFO - 2024-01-18 12:36:16 --> Helper loaded: security_helper
INFO - 2024-01-18 12:36:16 --> Helper loaded: cookie_helper
INFO - 2024-01-18 12:36:16 --> Database Driver Class Initialized
INFO - 2024-01-18 12:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 12:36:16 --> Parser Class Initialized
INFO - 2024-01-18 12:36:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 12:36:16 --> Pagination Class Initialized
INFO - 2024-01-18 12:36:16 --> Form Validation Class Initialized
INFO - 2024-01-18 12:36:16 --> Controller Class Initialized
INFO - 2024-01-18 12:36:16 --> Model Class Initialized
DEBUG - 2024-01-18 12:36:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 12:36:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:36:16 --> Model Class Initialized
DEBUG - 2024-01-18 12:36:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:36:16 --> Model Class Initialized
INFO - 2024-01-18 12:36:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-18 12:36:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:36:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 12:36:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 12:36:16 --> Model Class Initialized
INFO - 2024-01-18 12:36:16 --> Model Class Initialized
INFO - 2024-01-18 12:36:16 --> Model Class Initialized
INFO - 2024-01-18 12:36:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 12:36:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 12:36:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 12:36:16 --> Final output sent to browser
DEBUG - 2024-01-18 12:36:16 --> Total execution time: 0.1452
ERROR - 2024-01-18 12:36:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 12:36:16 --> Config Class Initialized
INFO - 2024-01-18 12:36:16 --> Hooks Class Initialized
DEBUG - 2024-01-18 12:36:16 --> UTF-8 Support Enabled
INFO - 2024-01-18 12:36:16 --> Utf8 Class Initialized
INFO - 2024-01-18 12:36:16 --> URI Class Initialized
INFO - 2024-01-18 12:36:16 --> Router Class Initialized
INFO - 2024-01-18 12:36:16 --> Output Class Initialized
INFO - 2024-01-18 12:36:16 --> Security Class Initialized
DEBUG - 2024-01-18 12:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 12:36:16 --> Input Class Initialized
INFO - 2024-01-18 12:36:16 --> Language Class Initialized
INFO - 2024-01-18 12:36:16 --> Loader Class Initialized
INFO - 2024-01-18 12:36:16 --> Helper loaded: url_helper
INFO - 2024-01-18 12:36:16 --> Helper loaded: file_helper
INFO - 2024-01-18 12:36:16 --> Helper loaded: html_helper
INFO - 2024-01-18 12:36:16 --> Helper loaded: text_helper
INFO - 2024-01-18 12:36:16 --> Helper loaded: form_helper
INFO - 2024-01-18 12:36:16 --> Helper loaded: lang_helper
INFO - 2024-01-18 12:36:16 --> Helper loaded: security_helper
INFO - 2024-01-18 12:36:16 --> Helper loaded: cookie_helper
INFO - 2024-01-18 12:36:16 --> Database Driver Class Initialized
INFO - 2024-01-18 12:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 12:36:16 --> Parser Class Initialized
INFO - 2024-01-18 12:36:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 12:36:16 --> Pagination Class Initialized
INFO - 2024-01-18 12:36:16 --> Form Validation Class Initialized
INFO - 2024-01-18 12:36:16 --> Controller Class Initialized
INFO - 2024-01-18 12:36:16 --> Model Class Initialized
DEBUG - 2024-01-18 12:36:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 12:36:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:36:16 --> Model Class Initialized
DEBUG - 2024-01-18 12:36:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:36:16 --> Model Class Initialized
INFO - 2024-01-18 12:36:16 --> Final output sent to browser
DEBUG - 2024-01-18 12:36:16 --> Total execution time: 0.0401
ERROR - 2024-01-18 12:36:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 12:36:33 --> Config Class Initialized
INFO - 2024-01-18 12:36:33 --> Hooks Class Initialized
DEBUG - 2024-01-18 12:36:33 --> UTF-8 Support Enabled
INFO - 2024-01-18 12:36:33 --> Utf8 Class Initialized
INFO - 2024-01-18 12:36:33 --> URI Class Initialized
DEBUG - 2024-01-18 12:36:33 --> No URI present. Default controller set.
INFO - 2024-01-18 12:36:33 --> Router Class Initialized
INFO - 2024-01-18 12:36:33 --> Output Class Initialized
INFO - 2024-01-18 12:36:33 --> Security Class Initialized
DEBUG - 2024-01-18 12:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 12:36:33 --> Input Class Initialized
INFO - 2024-01-18 12:36:33 --> Language Class Initialized
INFO - 2024-01-18 12:36:33 --> Loader Class Initialized
INFO - 2024-01-18 12:36:33 --> Helper loaded: url_helper
INFO - 2024-01-18 12:36:33 --> Helper loaded: file_helper
INFO - 2024-01-18 12:36:33 --> Helper loaded: html_helper
INFO - 2024-01-18 12:36:33 --> Helper loaded: text_helper
INFO - 2024-01-18 12:36:33 --> Helper loaded: form_helper
INFO - 2024-01-18 12:36:33 --> Helper loaded: lang_helper
INFO - 2024-01-18 12:36:33 --> Helper loaded: security_helper
INFO - 2024-01-18 12:36:33 --> Helper loaded: cookie_helper
INFO - 2024-01-18 12:36:33 --> Database Driver Class Initialized
INFO - 2024-01-18 12:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 12:36:33 --> Parser Class Initialized
INFO - 2024-01-18 12:36:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 12:36:33 --> Pagination Class Initialized
INFO - 2024-01-18 12:36:33 --> Form Validation Class Initialized
INFO - 2024-01-18 12:36:33 --> Controller Class Initialized
INFO - 2024-01-18 12:36:33 --> Model Class Initialized
DEBUG - 2024-01-18 12:36:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:36:33 --> Model Class Initialized
DEBUG - 2024-01-18 12:36:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:36:33 --> Model Class Initialized
INFO - 2024-01-18 12:36:33 --> Model Class Initialized
INFO - 2024-01-18 12:36:33 --> Model Class Initialized
INFO - 2024-01-18 12:36:33 --> Model Class Initialized
DEBUG - 2024-01-18 12:36:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 12:36:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:36:33 --> Model Class Initialized
INFO - 2024-01-18 12:36:33 --> Model Class Initialized
INFO - 2024-01-18 12:36:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-18 12:36:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:36:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 12:36:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 12:36:33 --> Model Class Initialized
INFO - 2024-01-18 12:36:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 12:36:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 12:36:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 12:36:34 --> Final output sent to browser
DEBUG - 2024-01-18 12:36:34 --> Total execution time: 0.2363
ERROR - 2024-01-18 12:41:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 12:41:14 --> Config Class Initialized
INFO - 2024-01-18 12:41:14 --> Hooks Class Initialized
DEBUG - 2024-01-18 12:41:14 --> UTF-8 Support Enabled
INFO - 2024-01-18 12:41:14 --> Utf8 Class Initialized
INFO - 2024-01-18 12:41:14 --> URI Class Initialized
DEBUG - 2024-01-18 12:41:14 --> No URI present. Default controller set.
INFO - 2024-01-18 12:41:14 --> Router Class Initialized
INFO - 2024-01-18 12:41:14 --> Output Class Initialized
INFO - 2024-01-18 12:41:14 --> Security Class Initialized
DEBUG - 2024-01-18 12:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 12:41:14 --> Input Class Initialized
INFO - 2024-01-18 12:41:14 --> Language Class Initialized
INFO - 2024-01-18 12:41:14 --> Loader Class Initialized
INFO - 2024-01-18 12:41:14 --> Helper loaded: url_helper
INFO - 2024-01-18 12:41:14 --> Helper loaded: file_helper
INFO - 2024-01-18 12:41:14 --> Helper loaded: html_helper
INFO - 2024-01-18 12:41:14 --> Helper loaded: text_helper
INFO - 2024-01-18 12:41:14 --> Helper loaded: form_helper
INFO - 2024-01-18 12:41:14 --> Helper loaded: lang_helper
INFO - 2024-01-18 12:41:14 --> Helper loaded: security_helper
INFO - 2024-01-18 12:41:14 --> Helper loaded: cookie_helper
INFO - 2024-01-18 12:41:14 --> Database Driver Class Initialized
INFO - 2024-01-18 12:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 12:41:14 --> Parser Class Initialized
INFO - 2024-01-18 12:41:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 12:41:14 --> Pagination Class Initialized
INFO - 2024-01-18 12:41:14 --> Form Validation Class Initialized
INFO - 2024-01-18 12:41:14 --> Controller Class Initialized
INFO - 2024-01-18 12:41:14 --> Model Class Initialized
DEBUG - 2024-01-18 12:41:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-18 12:41:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 12:41:15 --> Config Class Initialized
INFO - 2024-01-18 12:41:15 --> Hooks Class Initialized
DEBUG - 2024-01-18 12:41:15 --> UTF-8 Support Enabled
INFO - 2024-01-18 12:41:15 --> Utf8 Class Initialized
INFO - 2024-01-18 12:41:15 --> URI Class Initialized
INFO - 2024-01-18 12:41:15 --> Router Class Initialized
INFO - 2024-01-18 12:41:15 --> Output Class Initialized
INFO - 2024-01-18 12:41:15 --> Security Class Initialized
DEBUG - 2024-01-18 12:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 12:41:15 --> Input Class Initialized
INFO - 2024-01-18 12:41:15 --> Language Class Initialized
INFO - 2024-01-18 12:41:15 --> Loader Class Initialized
INFO - 2024-01-18 12:41:15 --> Helper loaded: url_helper
INFO - 2024-01-18 12:41:15 --> Helper loaded: file_helper
INFO - 2024-01-18 12:41:15 --> Helper loaded: html_helper
INFO - 2024-01-18 12:41:15 --> Helper loaded: text_helper
INFO - 2024-01-18 12:41:15 --> Helper loaded: form_helper
INFO - 2024-01-18 12:41:15 --> Helper loaded: lang_helper
INFO - 2024-01-18 12:41:15 --> Helper loaded: security_helper
INFO - 2024-01-18 12:41:15 --> Helper loaded: cookie_helper
INFO - 2024-01-18 12:41:15 --> Database Driver Class Initialized
INFO - 2024-01-18 12:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 12:41:15 --> Parser Class Initialized
INFO - 2024-01-18 12:41:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 12:41:15 --> Pagination Class Initialized
INFO - 2024-01-18 12:41:15 --> Form Validation Class Initialized
INFO - 2024-01-18 12:41:15 --> Controller Class Initialized
INFO - 2024-01-18 12:41:15 --> Model Class Initialized
DEBUG - 2024-01-18 12:41:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:41:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-18 12:41:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 12:41:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 12:41:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 12:41:15 --> Model Class Initialized
INFO - 2024-01-18 12:41:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 12:41:15 --> Final output sent to browser
DEBUG - 2024-01-18 12:41:15 --> Total execution time: 0.0323
ERROR - 2024-01-18 14:07:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 14:07:59 --> Config Class Initialized
INFO - 2024-01-18 14:07:59 --> Hooks Class Initialized
DEBUG - 2024-01-18 14:07:59 --> UTF-8 Support Enabled
INFO - 2024-01-18 14:07:59 --> Utf8 Class Initialized
INFO - 2024-01-18 14:07:59 --> URI Class Initialized
DEBUG - 2024-01-18 14:07:59 --> No URI present. Default controller set.
INFO - 2024-01-18 14:07:59 --> Router Class Initialized
INFO - 2024-01-18 14:07:59 --> Output Class Initialized
INFO - 2024-01-18 14:07:59 --> Security Class Initialized
DEBUG - 2024-01-18 14:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 14:07:59 --> Input Class Initialized
INFO - 2024-01-18 14:07:59 --> Language Class Initialized
INFO - 2024-01-18 14:07:59 --> Loader Class Initialized
INFO - 2024-01-18 14:07:59 --> Helper loaded: url_helper
INFO - 2024-01-18 14:07:59 --> Helper loaded: file_helper
INFO - 2024-01-18 14:07:59 --> Helper loaded: html_helper
INFO - 2024-01-18 14:07:59 --> Helper loaded: text_helper
INFO - 2024-01-18 14:07:59 --> Helper loaded: form_helper
INFO - 2024-01-18 14:07:59 --> Helper loaded: lang_helper
INFO - 2024-01-18 14:07:59 --> Helper loaded: security_helper
INFO - 2024-01-18 14:07:59 --> Helper loaded: cookie_helper
INFO - 2024-01-18 14:07:59 --> Database Driver Class Initialized
INFO - 2024-01-18 14:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 14:07:59 --> Parser Class Initialized
INFO - 2024-01-18 14:07:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 14:07:59 --> Pagination Class Initialized
INFO - 2024-01-18 14:07:59 --> Form Validation Class Initialized
INFO - 2024-01-18 14:07:59 --> Controller Class Initialized
INFO - 2024-01-18 14:07:59 --> Model Class Initialized
DEBUG - 2024-01-18 14:07:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-18 14:08:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 14:08:00 --> Config Class Initialized
INFO - 2024-01-18 14:08:00 --> Hooks Class Initialized
DEBUG - 2024-01-18 14:08:00 --> UTF-8 Support Enabled
INFO - 2024-01-18 14:08:00 --> Utf8 Class Initialized
INFO - 2024-01-18 14:08:00 --> URI Class Initialized
INFO - 2024-01-18 14:08:00 --> Router Class Initialized
INFO - 2024-01-18 14:08:00 --> Output Class Initialized
INFO - 2024-01-18 14:08:00 --> Security Class Initialized
DEBUG - 2024-01-18 14:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 14:08:00 --> Input Class Initialized
INFO - 2024-01-18 14:08:00 --> Language Class Initialized
INFO - 2024-01-18 14:08:00 --> Loader Class Initialized
INFO - 2024-01-18 14:08:00 --> Helper loaded: url_helper
INFO - 2024-01-18 14:08:00 --> Helper loaded: file_helper
INFO - 2024-01-18 14:08:00 --> Helper loaded: html_helper
INFO - 2024-01-18 14:08:00 --> Helper loaded: text_helper
INFO - 2024-01-18 14:08:00 --> Helper loaded: form_helper
INFO - 2024-01-18 14:08:00 --> Helper loaded: lang_helper
INFO - 2024-01-18 14:08:00 --> Helper loaded: security_helper
INFO - 2024-01-18 14:08:00 --> Helper loaded: cookie_helper
INFO - 2024-01-18 14:08:00 --> Database Driver Class Initialized
INFO - 2024-01-18 14:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 14:08:00 --> Parser Class Initialized
INFO - 2024-01-18 14:08:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 14:08:00 --> Pagination Class Initialized
INFO - 2024-01-18 14:08:00 --> Form Validation Class Initialized
INFO - 2024-01-18 14:08:00 --> Controller Class Initialized
INFO - 2024-01-18 14:08:00 --> Model Class Initialized
DEBUG - 2024-01-18 14:08:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 14:08:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-18 14:08:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 14:08:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 14:08:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 14:08:00 --> Model Class Initialized
INFO - 2024-01-18 14:08:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 14:08:00 --> Final output sent to browser
DEBUG - 2024-01-18 14:08:00 --> Total execution time: 0.0402
ERROR - 2024-01-18 15:42:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 15:42:00 --> Config Class Initialized
INFO - 2024-01-18 15:42:00 --> Hooks Class Initialized
DEBUG - 2024-01-18 15:42:00 --> UTF-8 Support Enabled
INFO - 2024-01-18 15:42:00 --> Utf8 Class Initialized
INFO - 2024-01-18 15:42:00 --> URI Class Initialized
DEBUG - 2024-01-18 15:42:00 --> No URI present. Default controller set.
INFO - 2024-01-18 15:42:00 --> Router Class Initialized
INFO - 2024-01-18 15:42:00 --> Output Class Initialized
INFO - 2024-01-18 15:42:00 --> Security Class Initialized
DEBUG - 2024-01-18 15:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 15:42:00 --> Input Class Initialized
INFO - 2024-01-18 15:42:00 --> Language Class Initialized
INFO - 2024-01-18 15:42:00 --> Loader Class Initialized
INFO - 2024-01-18 15:42:00 --> Helper loaded: url_helper
INFO - 2024-01-18 15:42:00 --> Helper loaded: file_helper
INFO - 2024-01-18 15:42:00 --> Helper loaded: html_helper
INFO - 2024-01-18 15:42:00 --> Helper loaded: text_helper
INFO - 2024-01-18 15:42:00 --> Helper loaded: form_helper
INFO - 2024-01-18 15:42:00 --> Helper loaded: lang_helper
INFO - 2024-01-18 15:42:00 --> Helper loaded: security_helper
INFO - 2024-01-18 15:42:00 --> Helper loaded: cookie_helper
INFO - 2024-01-18 15:42:00 --> Database Driver Class Initialized
INFO - 2024-01-18 15:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 15:42:00 --> Parser Class Initialized
INFO - 2024-01-18 15:42:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 15:42:00 --> Pagination Class Initialized
INFO - 2024-01-18 15:42:00 --> Form Validation Class Initialized
INFO - 2024-01-18 15:42:00 --> Controller Class Initialized
INFO - 2024-01-18 15:42:00 --> Model Class Initialized
DEBUG - 2024-01-18 15:42:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-18 15:42:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 15:42:00 --> Config Class Initialized
INFO - 2024-01-18 15:42:00 --> Hooks Class Initialized
DEBUG - 2024-01-18 15:42:00 --> UTF-8 Support Enabled
INFO - 2024-01-18 15:42:00 --> Utf8 Class Initialized
INFO - 2024-01-18 15:42:00 --> URI Class Initialized
INFO - 2024-01-18 15:42:00 --> Router Class Initialized
INFO - 2024-01-18 15:42:00 --> Output Class Initialized
INFO - 2024-01-18 15:42:00 --> Security Class Initialized
DEBUG - 2024-01-18 15:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 15:42:00 --> Input Class Initialized
INFO - 2024-01-18 15:42:00 --> Language Class Initialized
INFO - 2024-01-18 15:42:00 --> Loader Class Initialized
INFO - 2024-01-18 15:42:00 --> Helper loaded: url_helper
INFO - 2024-01-18 15:42:00 --> Helper loaded: file_helper
INFO - 2024-01-18 15:42:00 --> Helper loaded: html_helper
INFO - 2024-01-18 15:42:00 --> Helper loaded: text_helper
INFO - 2024-01-18 15:42:00 --> Helper loaded: form_helper
INFO - 2024-01-18 15:42:00 --> Helper loaded: lang_helper
INFO - 2024-01-18 15:42:00 --> Helper loaded: security_helper
INFO - 2024-01-18 15:42:00 --> Helper loaded: cookie_helper
INFO - 2024-01-18 15:42:00 --> Database Driver Class Initialized
INFO - 2024-01-18 15:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 15:42:00 --> Parser Class Initialized
INFO - 2024-01-18 15:42:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 15:42:00 --> Pagination Class Initialized
INFO - 2024-01-18 15:42:00 --> Form Validation Class Initialized
INFO - 2024-01-18 15:42:00 --> Controller Class Initialized
INFO - 2024-01-18 15:42:00 --> Model Class Initialized
DEBUG - 2024-01-18 15:42:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 15:42:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-18 15:42:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 15:42:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 15:42:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 15:42:00 --> Model Class Initialized
INFO - 2024-01-18 15:42:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 15:42:00 --> Final output sent to browser
DEBUG - 2024-01-18 15:42:00 --> Total execution time: 0.0342
ERROR - 2024-01-18 17:31:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 17:31:04 --> Config Class Initialized
INFO - 2024-01-18 17:31:04 --> Hooks Class Initialized
DEBUG - 2024-01-18 17:31:04 --> UTF-8 Support Enabled
INFO - 2024-01-18 17:31:04 --> Utf8 Class Initialized
INFO - 2024-01-18 17:31:04 --> URI Class Initialized
DEBUG - 2024-01-18 17:31:04 --> No URI present. Default controller set.
INFO - 2024-01-18 17:31:04 --> Router Class Initialized
INFO - 2024-01-18 17:31:04 --> Output Class Initialized
INFO - 2024-01-18 17:31:04 --> Security Class Initialized
DEBUG - 2024-01-18 17:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 17:31:04 --> Input Class Initialized
INFO - 2024-01-18 17:31:04 --> Language Class Initialized
INFO - 2024-01-18 17:31:04 --> Loader Class Initialized
INFO - 2024-01-18 17:31:04 --> Helper loaded: url_helper
INFO - 2024-01-18 17:31:04 --> Helper loaded: file_helper
INFO - 2024-01-18 17:31:04 --> Helper loaded: html_helper
INFO - 2024-01-18 17:31:04 --> Helper loaded: text_helper
INFO - 2024-01-18 17:31:04 --> Helper loaded: form_helper
INFO - 2024-01-18 17:31:04 --> Helper loaded: lang_helper
INFO - 2024-01-18 17:31:04 --> Helper loaded: security_helper
INFO - 2024-01-18 17:31:04 --> Helper loaded: cookie_helper
INFO - 2024-01-18 17:31:04 --> Database Driver Class Initialized
INFO - 2024-01-18 17:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 17:31:04 --> Parser Class Initialized
INFO - 2024-01-18 17:31:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 17:31:04 --> Pagination Class Initialized
INFO - 2024-01-18 17:31:04 --> Form Validation Class Initialized
INFO - 2024-01-18 17:31:04 --> Controller Class Initialized
INFO - 2024-01-18 17:31:04 --> Model Class Initialized
DEBUG - 2024-01-18 17:31:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-18 17:31:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 17:31:05 --> Config Class Initialized
INFO - 2024-01-18 17:31:05 --> Hooks Class Initialized
DEBUG - 2024-01-18 17:31:05 --> UTF-8 Support Enabled
INFO - 2024-01-18 17:31:05 --> Utf8 Class Initialized
INFO - 2024-01-18 17:31:05 --> URI Class Initialized
INFO - 2024-01-18 17:31:05 --> Router Class Initialized
INFO - 2024-01-18 17:31:05 --> Output Class Initialized
INFO - 2024-01-18 17:31:05 --> Security Class Initialized
DEBUG - 2024-01-18 17:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 17:31:05 --> Input Class Initialized
INFO - 2024-01-18 17:31:05 --> Language Class Initialized
INFO - 2024-01-18 17:31:05 --> Loader Class Initialized
INFO - 2024-01-18 17:31:05 --> Helper loaded: url_helper
INFO - 2024-01-18 17:31:05 --> Helper loaded: file_helper
INFO - 2024-01-18 17:31:05 --> Helper loaded: html_helper
INFO - 2024-01-18 17:31:05 --> Helper loaded: text_helper
INFO - 2024-01-18 17:31:05 --> Helper loaded: form_helper
INFO - 2024-01-18 17:31:05 --> Helper loaded: lang_helper
INFO - 2024-01-18 17:31:05 --> Helper loaded: security_helper
INFO - 2024-01-18 17:31:05 --> Helper loaded: cookie_helper
INFO - 2024-01-18 17:31:05 --> Database Driver Class Initialized
INFO - 2024-01-18 17:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 17:31:05 --> Parser Class Initialized
INFO - 2024-01-18 17:31:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 17:31:05 --> Pagination Class Initialized
INFO - 2024-01-18 17:31:05 --> Form Validation Class Initialized
INFO - 2024-01-18 17:31:05 --> Controller Class Initialized
INFO - 2024-01-18 17:31:05 --> Model Class Initialized
DEBUG - 2024-01-18 17:31:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:31:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-18 17:31:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:31:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 17:31:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 17:31:05 --> Model Class Initialized
INFO - 2024-01-18 17:31:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 17:31:05 --> Final output sent to browser
DEBUG - 2024-01-18 17:31:05 --> Total execution time: 0.0292
ERROR - 2024-01-18 17:32:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 17:32:13 --> Config Class Initialized
INFO - 2024-01-18 17:32:13 --> Hooks Class Initialized
DEBUG - 2024-01-18 17:32:13 --> UTF-8 Support Enabled
INFO - 2024-01-18 17:32:13 --> Utf8 Class Initialized
INFO - 2024-01-18 17:32:13 --> URI Class Initialized
INFO - 2024-01-18 17:32:13 --> Router Class Initialized
INFO - 2024-01-18 17:32:13 --> Output Class Initialized
INFO - 2024-01-18 17:32:13 --> Security Class Initialized
DEBUG - 2024-01-18 17:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 17:32:13 --> Input Class Initialized
INFO - 2024-01-18 17:32:13 --> Language Class Initialized
INFO - 2024-01-18 17:32:13 --> Loader Class Initialized
INFO - 2024-01-18 17:32:13 --> Helper loaded: url_helper
INFO - 2024-01-18 17:32:13 --> Helper loaded: file_helper
INFO - 2024-01-18 17:32:13 --> Helper loaded: html_helper
INFO - 2024-01-18 17:32:13 --> Helper loaded: text_helper
INFO - 2024-01-18 17:32:13 --> Helper loaded: form_helper
INFO - 2024-01-18 17:32:13 --> Helper loaded: lang_helper
INFO - 2024-01-18 17:32:13 --> Helper loaded: security_helper
INFO - 2024-01-18 17:32:13 --> Helper loaded: cookie_helper
INFO - 2024-01-18 17:32:13 --> Database Driver Class Initialized
INFO - 2024-01-18 17:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 17:32:14 --> Parser Class Initialized
INFO - 2024-01-18 17:32:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 17:32:14 --> Pagination Class Initialized
INFO - 2024-01-18 17:32:14 --> Form Validation Class Initialized
INFO - 2024-01-18 17:32:14 --> Controller Class Initialized
INFO - 2024-01-18 17:32:14 --> Model Class Initialized
DEBUG - 2024-01-18 17:32:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:32:14 --> Model Class Initialized
INFO - 2024-01-18 17:32:14 --> Final output sent to browser
DEBUG - 2024-01-18 17:32:14 --> Total execution time: 0.3318
ERROR - 2024-01-18 17:32:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 17:32:14 --> Config Class Initialized
INFO - 2024-01-18 17:32:14 --> Hooks Class Initialized
DEBUG - 2024-01-18 17:32:14 --> UTF-8 Support Enabled
INFO - 2024-01-18 17:32:14 --> Utf8 Class Initialized
INFO - 2024-01-18 17:32:14 --> URI Class Initialized
DEBUG - 2024-01-18 17:32:14 --> No URI present. Default controller set.
INFO - 2024-01-18 17:32:14 --> Router Class Initialized
INFO - 2024-01-18 17:32:14 --> Output Class Initialized
INFO - 2024-01-18 17:32:14 --> Security Class Initialized
DEBUG - 2024-01-18 17:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 17:32:14 --> Input Class Initialized
INFO - 2024-01-18 17:32:14 --> Language Class Initialized
INFO - 2024-01-18 17:32:14 --> Loader Class Initialized
INFO - 2024-01-18 17:32:14 --> Helper loaded: url_helper
INFO - 2024-01-18 17:32:14 --> Helper loaded: file_helper
INFO - 2024-01-18 17:32:14 --> Helper loaded: html_helper
INFO - 2024-01-18 17:32:14 --> Helper loaded: text_helper
INFO - 2024-01-18 17:32:14 --> Helper loaded: form_helper
INFO - 2024-01-18 17:32:14 --> Helper loaded: lang_helper
INFO - 2024-01-18 17:32:14 --> Helper loaded: security_helper
INFO - 2024-01-18 17:32:14 --> Helper loaded: cookie_helper
INFO - 2024-01-18 17:32:14 --> Database Driver Class Initialized
INFO - 2024-01-18 17:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 17:32:14 --> Parser Class Initialized
INFO - 2024-01-18 17:32:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 17:32:14 --> Pagination Class Initialized
INFO - 2024-01-18 17:32:14 --> Form Validation Class Initialized
INFO - 2024-01-18 17:32:14 --> Controller Class Initialized
INFO - 2024-01-18 17:32:14 --> Model Class Initialized
DEBUG - 2024-01-18 17:32:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:32:14 --> Model Class Initialized
DEBUG - 2024-01-18 17:32:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:32:14 --> Model Class Initialized
INFO - 2024-01-18 17:32:14 --> Model Class Initialized
INFO - 2024-01-18 17:32:14 --> Model Class Initialized
INFO - 2024-01-18 17:32:14 --> Model Class Initialized
DEBUG - 2024-01-18 17:32:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 17:32:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:32:14 --> Model Class Initialized
INFO - 2024-01-18 17:32:14 --> Model Class Initialized
INFO - 2024-01-18 17:32:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-18 17:32:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:32:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 17:32:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 17:32:15 --> Model Class Initialized
INFO - 2024-01-18 17:32:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 17:32:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 17:32:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 17:32:15 --> Final output sent to browser
DEBUG - 2024-01-18 17:32:15 --> Total execution time: 0.6956
ERROR - 2024-01-18 17:32:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 17:32:16 --> Config Class Initialized
INFO - 2024-01-18 17:32:16 --> Hooks Class Initialized
DEBUG - 2024-01-18 17:32:16 --> UTF-8 Support Enabled
INFO - 2024-01-18 17:32:16 --> Utf8 Class Initialized
INFO - 2024-01-18 17:32:16 --> URI Class Initialized
INFO - 2024-01-18 17:32:16 --> Router Class Initialized
INFO - 2024-01-18 17:32:16 --> Output Class Initialized
INFO - 2024-01-18 17:32:16 --> Security Class Initialized
DEBUG - 2024-01-18 17:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 17:32:16 --> Input Class Initialized
INFO - 2024-01-18 17:32:16 --> Language Class Initialized
INFO - 2024-01-18 17:32:16 --> Loader Class Initialized
INFO - 2024-01-18 17:32:16 --> Helper loaded: url_helper
INFO - 2024-01-18 17:32:16 --> Helper loaded: file_helper
INFO - 2024-01-18 17:32:16 --> Helper loaded: html_helper
INFO - 2024-01-18 17:32:16 --> Helper loaded: text_helper
INFO - 2024-01-18 17:32:16 --> Helper loaded: form_helper
INFO - 2024-01-18 17:32:16 --> Helper loaded: lang_helper
INFO - 2024-01-18 17:32:16 --> Helper loaded: security_helper
INFO - 2024-01-18 17:32:16 --> Helper loaded: cookie_helper
INFO - 2024-01-18 17:32:16 --> Database Driver Class Initialized
INFO - 2024-01-18 17:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 17:32:16 --> Parser Class Initialized
INFO - 2024-01-18 17:32:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 17:32:16 --> Pagination Class Initialized
INFO - 2024-01-18 17:32:16 --> Form Validation Class Initialized
INFO - 2024-01-18 17:32:16 --> Controller Class Initialized
DEBUG - 2024-01-18 17:32:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 17:32:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:32:16 --> Model Class Initialized
INFO - 2024-01-18 17:32:16 --> Final output sent to browser
DEBUG - 2024-01-18 17:32:16 --> Total execution time: 0.0124
ERROR - 2024-01-18 17:32:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 17:32:27 --> Config Class Initialized
INFO - 2024-01-18 17:32:27 --> Hooks Class Initialized
DEBUG - 2024-01-18 17:32:27 --> UTF-8 Support Enabled
INFO - 2024-01-18 17:32:27 --> Utf8 Class Initialized
INFO - 2024-01-18 17:32:27 --> URI Class Initialized
INFO - 2024-01-18 17:32:27 --> Router Class Initialized
INFO - 2024-01-18 17:32:27 --> Output Class Initialized
INFO - 2024-01-18 17:32:27 --> Security Class Initialized
DEBUG - 2024-01-18 17:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 17:32:27 --> Input Class Initialized
INFO - 2024-01-18 17:32:27 --> Language Class Initialized
INFO - 2024-01-18 17:32:27 --> Loader Class Initialized
INFO - 2024-01-18 17:32:27 --> Helper loaded: url_helper
INFO - 2024-01-18 17:32:27 --> Helper loaded: file_helper
INFO - 2024-01-18 17:32:27 --> Helper loaded: html_helper
INFO - 2024-01-18 17:32:27 --> Helper loaded: text_helper
INFO - 2024-01-18 17:32:27 --> Helper loaded: form_helper
INFO - 2024-01-18 17:32:27 --> Helper loaded: lang_helper
INFO - 2024-01-18 17:32:27 --> Helper loaded: security_helper
INFO - 2024-01-18 17:32:27 --> Helper loaded: cookie_helper
INFO - 2024-01-18 17:32:27 --> Database Driver Class Initialized
INFO - 2024-01-18 17:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 17:32:27 --> Parser Class Initialized
INFO - 2024-01-18 17:32:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 17:32:27 --> Pagination Class Initialized
INFO - 2024-01-18 17:32:27 --> Form Validation Class Initialized
INFO - 2024-01-18 17:32:27 --> Controller Class Initialized
DEBUG - 2024-01-18 17:32:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 17:32:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:32:27 --> Model Class Initialized
DEBUG - 2024-01-18 17:32:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:32:27 --> Model Class Initialized
DEBUG - 2024-01-18 17:32:27 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:32:27 --> Model Class Initialized
INFO - 2024-01-18 17:32:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-01-18 17:32:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:32:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 17:32:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 17:32:28 --> Model Class Initialized
INFO - 2024-01-18 17:32:28 --> Model Class Initialized
INFO - 2024-01-18 17:32:28 --> Model Class Initialized
INFO - 2024-01-18 17:32:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 17:32:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 17:32:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 17:32:28 --> Final output sent to browser
DEBUG - 2024-01-18 17:32:28 --> Total execution time: 0.2164
ERROR - 2024-01-18 17:32:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 17:32:29 --> Config Class Initialized
INFO - 2024-01-18 17:32:29 --> Hooks Class Initialized
DEBUG - 2024-01-18 17:32:29 --> UTF-8 Support Enabled
INFO - 2024-01-18 17:32:29 --> Utf8 Class Initialized
INFO - 2024-01-18 17:32:29 --> URI Class Initialized
INFO - 2024-01-18 17:32:29 --> Router Class Initialized
INFO - 2024-01-18 17:32:29 --> Output Class Initialized
INFO - 2024-01-18 17:32:29 --> Security Class Initialized
DEBUG - 2024-01-18 17:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 17:32:29 --> Input Class Initialized
INFO - 2024-01-18 17:32:29 --> Language Class Initialized
INFO - 2024-01-18 17:32:29 --> Loader Class Initialized
INFO - 2024-01-18 17:32:29 --> Helper loaded: url_helper
INFO - 2024-01-18 17:32:29 --> Helper loaded: file_helper
INFO - 2024-01-18 17:32:29 --> Helper loaded: html_helper
INFO - 2024-01-18 17:32:29 --> Helper loaded: text_helper
INFO - 2024-01-18 17:32:29 --> Helper loaded: form_helper
INFO - 2024-01-18 17:32:29 --> Helper loaded: lang_helper
INFO - 2024-01-18 17:32:29 --> Helper loaded: security_helper
INFO - 2024-01-18 17:32:29 --> Helper loaded: cookie_helper
INFO - 2024-01-18 17:32:29 --> Database Driver Class Initialized
INFO - 2024-01-18 17:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 17:32:29 --> Parser Class Initialized
INFO - 2024-01-18 17:32:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 17:32:29 --> Pagination Class Initialized
INFO - 2024-01-18 17:32:29 --> Form Validation Class Initialized
INFO - 2024-01-18 17:32:29 --> Controller Class Initialized
DEBUG - 2024-01-18 17:32:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 17:32:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:32:29 --> Model Class Initialized
DEBUG - 2024-01-18 17:32:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:32:29 --> Model Class Initialized
INFO - 2024-01-18 17:32:29 --> Final output sent to browser
DEBUG - 2024-01-18 17:32:29 --> Total execution time: 0.0350
ERROR - 2024-01-18 17:32:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 17:32:37 --> Config Class Initialized
INFO - 2024-01-18 17:32:37 --> Hooks Class Initialized
DEBUG - 2024-01-18 17:32:37 --> UTF-8 Support Enabled
INFO - 2024-01-18 17:32:37 --> Utf8 Class Initialized
INFO - 2024-01-18 17:32:37 --> URI Class Initialized
INFO - 2024-01-18 17:32:37 --> Router Class Initialized
INFO - 2024-01-18 17:32:37 --> Output Class Initialized
INFO - 2024-01-18 17:32:37 --> Security Class Initialized
DEBUG - 2024-01-18 17:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 17:32:37 --> Input Class Initialized
INFO - 2024-01-18 17:32:37 --> Language Class Initialized
INFO - 2024-01-18 17:32:37 --> Loader Class Initialized
INFO - 2024-01-18 17:32:37 --> Helper loaded: url_helper
INFO - 2024-01-18 17:32:37 --> Helper loaded: file_helper
INFO - 2024-01-18 17:32:37 --> Helper loaded: html_helper
INFO - 2024-01-18 17:32:37 --> Helper loaded: text_helper
INFO - 2024-01-18 17:32:37 --> Helper loaded: form_helper
INFO - 2024-01-18 17:32:37 --> Helper loaded: lang_helper
INFO - 2024-01-18 17:32:37 --> Helper loaded: security_helper
INFO - 2024-01-18 17:32:37 --> Helper loaded: cookie_helper
INFO - 2024-01-18 17:32:37 --> Database Driver Class Initialized
INFO - 2024-01-18 17:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 17:32:37 --> Parser Class Initialized
INFO - 2024-01-18 17:32:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 17:32:37 --> Pagination Class Initialized
INFO - 2024-01-18 17:32:37 --> Form Validation Class Initialized
INFO - 2024-01-18 17:32:37 --> Controller Class Initialized
INFO - 2024-01-18 17:32:37 --> Model Class Initialized
DEBUG - 2024-01-18 17:32:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 17:32:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:32:37 --> Model Class Initialized
DEBUG - 2024-01-18 17:32:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:32:37 --> Model Class Initialized
INFO - 2024-01-18 17:32:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-18 17:32:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:32:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 17:32:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 17:32:37 --> Model Class Initialized
INFO - 2024-01-18 17:32:37 --> Model Class Initialized
INFO - 2024-01-18 17:32:37 --> Model Class Initialized
INFO - 2024-01-18 17:32:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 17:32:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 17:32:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 17:32:38 --> Final output sent to browser
DEBUG - 2024-01-18 17:32:38 --> Total execution time: 0.2451
ERROR - 2024-01-18 17:32:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 17:32:38 --> Config Class Initialized
INFO - 2024-01-18 17:32:38 --> Hooks Class Initialized
DEBUG - 2024-01-18 17:32:38 --> UTF-8 Support Enabled
INFO - 2024-01-18 17:32:38 --> Utf8 Class Initialized
INFO - 2024-01-18 17:32:38 --> URI Class Initialized
INFO - 2024-01-18 17:32:38 --> Router Class Initialized
INFO - 2024-01-18 17:32:38 --> Output Class Initialized
INFO - 2024-01-18 17:32:38 --> Security Class Initialized
DEBUG - 2024-01-18 17:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 17:32:38 --> Input Class Initialized
INFO - 2024-01-18 17:32:38 --> Language Class Initialized
INFO - 2024-01-18 17:32:38 --> Loader Class Initialized
INFO - 2024-01-18 17:32:38 --> Helper loaded: url_helper
INFO - 2024-01-18 17:32:38 --> Helper loaded: file_helper
INFO - 2024-01-18 17:32:38 --> Helper loaded: html_helper
INFO - 2024-01-18 17:32:38 --> Helper loaded: text_helper
INFO - 2024-01-18 17:32:38 --> Helper loaded: form_helper
INFO - 2024-01-18 17:32:38 --> Helper loaded: lang_helper
INFO - 2024-01-18 17:32:38 --> Helper loaded: security_helper
INFO - 2024-01-18 17:32:38 --> Helper loaded: cookie_helper
INFO - 2024-01-18 17:32:38 --> Database Driver Class Initialized
INFO - 2024-01-18 17:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 17:32:38 --> Parser Class Initialized
INFO - 2024-01-18 17:32:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 17:32:38 --> Pagination Class Initialized
INFO - 2024-01-18 17:32:38 --> Form Validation Class Initialized
INFO - 2024-01-18 17:32:38 --> Controller Class Initialized
INFO - 2024-01-18 17:32:38 --> Model Class Initialized
DEBUG - 2024-01-18 17:32:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 17:32:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:32:38 --> Model Class Initialized
DEBUG - 2024-01-18 17:32:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:32:38 --> Model Class Initialized
INFO - 2024-01-18 17:32:39 --> Final output sent to browser
DEBUG - 2024-01-18 17:32:39 --> Total execution time: 0.0569
ERROR - 2024-01-18 17:32:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 17:32:51 --> Config Class Initialized
INFO - 2024-01-18 17:32:51 --> Hooks Class Initialized
DEBUG - 2024-01-18 17:32:51 --> UTF-8 Support Enabled
INFO - 2024-01-18 17:32:51 --> Utf8 Class Initialized
INFO - 2024-01-18 17:32:51 --> URI Class Initialized
INFO - 2024-01-18 17:32:51 --> Router Class Initialized
INFO - 2024-01-18 17:32:51 --> Output Class Initialized
INFO - 2024-01-18 17:32:51 --> Security Class Initialized
DEBUG - 2024-01-18 17:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 17:32:51 --> Input Class Initialized
INFO - 2024-01-18 17:32:51 --> Language Class Initialized
INFO - 2024-01-18 17:32:51 --> Loader Class Initialized
INFO - 2024-01-18 17:32:51 --> Helper loaded: url_helper
INFO - 2024-01-18 17:32:51 --> Helper loaded: file_helper
INFO - 2024-01-18 17:32:51 --> Helper loaded: html_helper
INFO - 2024-01-18 17:32:51 --> Helper loaded: text_helper
INFO - 2024-01-18 17:32:51 --> Helper loaded: form_helper
INFO - 2024-01-18 17:32:51 --> Helper loaded: lang_helper
INFO - 2024-01-18 17:32:51 --> Helper loaded: security_helper
INFO - 2024-01-18 17:32:51 --> Helper loaded: cookie_helper
INFO - 2024-01-18 17:32:51 --> Database Driver Class Initialized
INFO - 2024-01-18 17:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 17:32:51 --> Parser Class Initialized
INFO - 2024-01-18 17:32:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 17:32:51 --> Pagination Class Initialized
INFO - 2024-01-18 17:32:51 --> Form Validation Class Initialized
INFO - 2024-01-18 17:32:51 --> Controller Class Initialized
DEBUG - 2024-01-18 17:32:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 17:32:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:32:51 --> Model Class Initialized
DEBUG - 2024-01-18 17:32:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:32:51 --> Model Class Initialized
DEBUG - 2024-01-18 17:32:51 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:32:51 --> Model Class Initialized
INFO - 2024-01-18 17:32:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-01-18 17:32:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:32:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 17:32:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 17:32:51 --> Model Class Initialized
INFO - 2024-01-18 17:32:51 --> Model Class Initialized
INFO - 2024-01-18 17:32:51 --> Model Class Initialized
INFO - 2024-01-18 17:32:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 17:32:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 17:32:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 17:32:51 --> Final output sent to browser
DEBUG - 2024-01-18 17:32:51 --> Total execution time: 0.2072
ERROR - 2024-01-18 17:32:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 17:32:52 --> Config Class Initialized
INFO - 2024-01-18 17:32:52 --> Hooks Class Initialized
DEBUG - 2024-01-18 17:32:52 --> UTF-8 Support Enabled
INFO - 2024-01-18 17:32:52 --> Utf8 Class Initialized
INFO - 2024-01-18 17:32:52 --> URI Class Initialized
INFO - 2024-01-18 17:32:52 --> Router Class Initialized
INFO - 2024-01-18 17:32:52 --> Output Class Initialized
INFO - 2024-01-18 17:32:52 --> Security Class Initialized
DEBUG - 2024-01-18 17:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 17:32:52 --> Input Class Initialized
INFO - 2024-01-18 17:32:52 --> Language Class Initialized
INFO - 2024-01-18 17:32:52 --> Loader Class Initialized
INFO - 2024-01-18 17:32:52 --> Helper loaded: url_helper
INFO - 2024-01-18 17:32:52 --> Helper loaded: file_helper
INFO - 2024-01-18 17:32:52 --> Helper loaded: html_helper
INFO - 2024-01-18 17:32:52 --> Helper loaded: text_helper
INFO - 2024-01-18 17:32:52 --> Helper loaded: form_helper
INFO - 2024-01-18 17:32:52 --> Helper loaded: lang_helper
INFO - 2024-01-18 17:32:52 --> Helper loaded: security_helper
INFO - 2024-01-18 17:32:52 --> Helper loaded: cookie_helper
INFO - 2024-01-18 17:32:52 --> Database Driver Class Initialized
INFO - 2024-01-18 17:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 17:32:52 --> Parser Class Initialized
INFO - 2024-01-18 17:32:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 17:32:52 --> Pagination Class Initialized
INFO - 2024-01-18 17:32:52 --> Form Validation Class Initialized
INFO - 2024-01-18 17:32:52 --> Controller Class Initialized
DEBUG - 2024-01-18 17:32:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 17:32:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:32:52 --> Model Class Initialized
DEBUG - 2024-01-18 17:32:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:32:52 --> Model Class Initialized
INFO - 2024-01-18 17:32:52 --> Final output sent to browser
DEBUG - 2024-01-18 17:32:52 --> Total execution time: 0.0340
ERROR - 2024-01-18 17:33:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 17:33:33 --> Config Class Initialized
INFO - 2024-01-18 17:33:33 --> Hooks Class Initialized
DEBUG - 2024-01-18 17:33:33 --> UTF-8 Support Enabled
INFO - 2024-01-18 17:33:33 --> Utf8 Class Initialized
INFO - 2024-01-18 17:33:33 --> URI Class Initialized
DEBUG - 2024-01-18 17:33:33 --> No URI present. Default controller set.
INFO - 2024-01-18 17:33:33 --> Router Class Initialized
INFO - 2024-01-18 17:33:33 --> Output Class Initialized
INFO - 2024-01-18 17:33:33 --> Security Class Initialized
DEBUG - 2024-01-18 17:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 17:33:33 --> Input Class Initialized
INFO - 2024-01-18 17:33:33 --> Language Class Initialized
INFO - 2024-01-18 17:33:33 --> Loader Class Initialized
INFO - 2024-01-18 17:33:33 --> Helper loaded: url_helper
INFO - 2024-01-18 17:33:33 --> Helper loaded: file_helper
INFO - 2024-01-18 17:33:33 --> Helper loaded: html_helper
INFO - 2024-01-18 17:33:33 --> Helper loaded: text_helper
INFO - 2024-01-18 17:33:33 --> Helper loaded: form_helper
INFO - 2024-01-18 17:33:33 --> Helper loaded: lang_helper
INFO - 2024-01-18 17:33:33 --> Helper loaded: security_helper
INFO - 2024-01-18 17:33:33 --> Helper loaded: cookie_helper
INFO - 2024-01-18 17:33:33 --> Database Driver Class Initialized
INFO - 2024-01-18 17:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 17:33:33 --> Parser Class Initialized
INFO - 2024-01-18 17:33:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 17:33:33 --> Pagination Class Initialized
INFO - 2024-01-18 17:33:33 --> Form Validation Class Initialized
INFO - 2024-01-18 17:33:33 --> Controller Class Initialized
INFO - 2024-01-18 17:33:33 --> Model Class Initialized
DEBUG - 2024-01-18 17:33:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:33:33 --> Model Class Initialized
DEBUG - 2024-01-18 17:33:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:33:33 --> Model Class Initialized
INFO - 2024-01-18 17:33:33 --> Model Class Initialized
INFO - 2024-01-18 17:33:33 --> Model Class Initialized
INFO - 2024-01-18 17:33:33 --> Model Class Initialized
DEBUG - 2024-01-18 17:33:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 17:33:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:33:33 --> Model Class Initialized
INFO - 2024-01-18 17:33:33 --> Model Class Initialized
INFO - 2024-01-18 17:33:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-18 17:33:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 17:33:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 17:33:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 17:33:34 --> Model Class Initialized
INFO - 2024-01-18 17:33:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 17:33:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 17:33:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 17:33:34 --> Final output sent to browser
DEBUG - 2024-01-18 17:33:34 --> Total execution time: 0.3900
ERROR - 2024-01-18 18:09:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 18:09:42 --> Config Class Initialized
INFO - 2024-01-18 18:09:42 --> Hooks Class Initialized
DEBUG - 2024-01-18 18:09:42 --> UTF-8 Support Enabled
INFO - 2024-01-18 18:09:42 --> Utf8 Class Initialized
INFO - 2024-01-18 18:09:42 --> URI Class Initialized
DEBUG - 2024-01-18 18:09:42 --> No URI present. Default controller set.
INFO - 2024-01-18 18:09:42 --> Router Class Initialized
INFO - 2024-01-18 18:09:42 --> Output Class Initialized
INFO - 2024-01-18 18:09:42 --> Security Class Initialized
DEBUG - 2024-01-18 18:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 18:09:42 --> Input Class Initialized
INFO - 2024-01-18 18:09:42 --> Language Class Initialized
INFO - 2024-01-18 18:09:42 --> Loader Class Initialized
INFO - 2024-01-18 18:09:42 --> Helper loaded: url_helper
INFO - 2024-01-18 18:09:42 --> Helper loaded: file_helper
INFO - 2024-01-18 18:09:42 --> Helper loaded: html_helper
INFO - 2024-01-18 18:09:42 --> Helper loaded: text_helper
INFO - 2024-01-18 18:09:42 --> Helper loaded: form_helper
INFO - 2024-01-18 18:09:42 --> Helper loaded: lang_helper
INFO - 2024-01-18 18:09:42 --> Helper loaded: security_helper
INFO - 2024-01-18 18:09:42 --> Helper loaded: cookie_helper
INFO - 2024-01-18 18:09:42 --> Database Driver Class Initialized
INFO - 2024-01-18 18:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 18:09:42 --> Parser Class Initialized
INFO - 2024-01-18 18:09:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 18:09:42 --> Pagination Class Initialized
INFO - 2024-01-18 18:09:42 --> Form Validation Class Initialized
INFO - 2024-01-18 18:09:42 --> Controller Class Initialized
INFO - 2024-01-18 18:09:42 --> Model Class Initialized
DEBUG - 2024-01-18 18:09:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 18:09:42 --> Model Class Initialized
DEBUG - 2024-01-18 18:09:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 18:09:42 --> Model Class Initialized
INFO - 2024-01-18 18:09:42 --> Model Class Initialized
INFO - 2024-01-18 18:09:42 --> Model Class Initialized
INFO - 2024-01-18 18:09:42 --> Model Class Initialized
DEBUG - 2024-01-18 18:09:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-18 18:09:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-18 18:09:42 --> Model Class Initialized
INFO - 2024-01-18 18:09:42 --> Model Class Initialized
INFO - 2024-01-18 18:09:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-18 18:09:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-18 18:09:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-18 18:09:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-18 18:09:42 --> Model Class Initialized
INFO - 2024-01-18 18:09:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-18 18:09:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-18 18:09:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-18 18:09:43 --> Final output sent to browser
DEBUG - 2024-01-18 18:09:43 --> Total execution time: 0.3966
ERROR - 2024-01-18 21:57:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 21:57:54 --> Config Class Initialized
INFO - 2024-01-18 21:57:54 --> Hooks Class Initialized
DEBUG - 2024-01-18 21:57:54 --> UTF-8 Support Enabled
INFO - 2024-01-18 21:57:54 --> Utf8 Class Initialized
INFO - 2024-01-18 21:57:54 --> URI Class Initialized
INFO - 2024-01-18 21:57:54 --> Router Class Initialized
INFO - 2024-01-18 21:57:54 --> Output Class Initialized
INFO - 2024-01-18 21:57:54 --> Security Class Initialized
DEBUG - 2024-01-18 21:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 21:57:54 --> Input Class Initialized
INFO - 2024-01-18 21:57:54 --> Language Class Initialized
ERROR - 2024-01-18 21:57:54 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-01-18 23:19:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 23:19:37 --> Config Class Initialized
INFO - 2024-01-18 23:19:37 --> Hooks Class Initialized
DEBUG - 2024-01-18 23:19:37 --> UTF-8 Support Enabled
INFO - 2024-01-18 23:19:37 --> Utf8 Class Initialized
INFO - 2024-01-18 23:19:37 --> URI Class Initialized
DEBUG - 2024-01-18 23:19:37 --> No URI present. Default controller set.
INFO - 2024-01-18 23:19:37 --> Router Class Initialized
INFO - 2024-01-18 23:19:37 --> Output Class Initialized
INFO - 2024-01-18 23:19:37 --> Security Class Initialized
DEBUG - 2024-01-18 23:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 23:19:37 --> Input Class Initialized
INFO - 2024-01-18 23:19:37 --> Language Class Initialized
INFO - 2024-01-18 23:19:37 --> Loader Class Initialized
INFO - 2024-01-18 23:19:37 --> Helper loaded: url_helper
INFO - 2024-01-18 23:19:37 --> Helper loaded: file_helper
INFO - 2024-01-18 23:19:37 --> Helper loaded: html_helper
INFO - 2024-01-18 23:19:37 --> Helper loaded: text_helper
INFO - 2024-01-18 23:19:37 --> Helper loaded: form_helper
INFO - 2024-01-18 23:19:37 --> Helper loaded: lang_helper
INFO - 2024-01-18 23:19:37 --> Helper loaded: security_helper
INFO - 2024-01-18 23:19:37 --> Helper loaded: cookie_helper
INFO - 2024-01-18 23:19:37 --> Database Driver Class Initialized
INFO - 2024-01-18 23:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 23:19:37 --> Parser Class Initialized
INFO - 2024-01-18 23:19:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 23:19:37 --> Pagination Class Initialized
INFO - 2024-01-18 23:19:37 --> Form Validation Class Initialized
INFO - 2024-01-18 23:19:37 --> Controller Class Initialized
INFO - 2024-01-18 23:19:37 --> Model Class Initialized
DEBUG - 2024-01-18 23:19:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-18 23:19:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-18 23:19:40 --> Config Class Initialized
INFO - 2024-01-18 23:19:40 --> Hooks Class Initialized
DEBUG - 2024-01-18 23:19:40 --> UTF-8 Support Enabled
INFO - 2024-01-18 23:19:40 --> Utf8 Class Initialized
INFO - 2024-01-18 23:19:40 --> URI Class Initialized
DEBUG - 2024-01-18 23:19:40 --> No URI present. Default controller set.
INFO - 2024-01-18 23:19:40 --> Router Class Initialized
INFO - 2024-01-18 23:19:40 --> Output Class Initialized
INFO - 2024-01-18 23:19:40 --> Security Class Initialized
DEBUG - 2024-01-18 23:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-18 23:19:40 --> Input Class Initialized
INFO - 2024-01-18 23:19:40 --> Language Class Initialized
INFO - 2024-01-18 23:19:40 --> Loader Class Initialized
INFO - 2024-01-18 23:19:40 --> Helper loaded: url_helper
INFO - 2024-01-18 23:19:40 --> Helper loaded: file_helper
INFO - 2024-01-18 23:19:40 --> Helper loaded: html_helper
INFO - 2024-01-18 23:19:40 --> Helper loaded: text_helper
INFO - 2024-01-18 23:19:40 --> Helper loaded: form_helper
INFO - 2024-01-18 23:19:40 --> Helper loaded: lang_helper
INFO - 2024-01-18 23:19:40 --> Helper loaded: security_helper
INFO - 2024-01-18 23:19:40 --> Helper loaded: cookie_helper
INFO - 2024-01-18 23:19:40 --> Database Driver Class Initialized
INFO - 2024-01-18 23:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-18 23:19:40 --> Parser Class Initialized
INFO - 2024-01-18 23:19:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-18 23:19:40 --> Pagination Class Initialized
INFO - 2024-01-18 23:19:40 --> Form Validation Class Initialized
INFO - 2024-01-18 23:19:40 --> Controller Class Initialized
INFO - 2024-01-18 23:19:40 --> Model Class Initialized
DEBUG - 2024-01-18 23:19:40 --> Session class already loaded. Second attempt ignored.
