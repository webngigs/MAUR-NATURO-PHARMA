<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-30 06:33:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 06:33:09 --> Config Class Initialized
INFO - 2023-07-30 06:33:09 --> Hooks Class Initialized
DEBUG - 2023-07-30 06:33:09 --> UTF-8 Support Enabled
INFO - 2023-07-30 06:33:09 --> Utf8 Class Initialized
INFO - 2023-07-30 06:33:09 --> URI Class Initialized
DEBUG - 2023-07-30 06:33:09 --> No URI present. Default controller set.
INFO - 2023-07-30 06:33:09 --> Router Class Initialized
INFO - 2023-07-30 06:33:09 --> Output Class Initialized
INFO - 2023-07-30 06:33:09 --> Security Class Initialized
DEBUG - 2023-07-30 06:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 06:33:09 --> Input Class Initialized
INFO - 2023-07-30 06:33:09 --> Language Class Initialized
INFO - 2023-07-30 06:33:09 --> Loader Class Initialized
INFO - 2023-07-30 06:33:09 --> Helper loaded: url_helper
INFO - 2023-07-30 06:33:09 --> Helper loaded: file_helper
INFO - 2023-07-30 06:33:09 --> Helper loaded: html_helper
INFO - 2023-07-30 06:33:09 --> Helper loaded: text_helper
INFO - 2023-07-30 06:33:09 --> Helper loaded: form_helper
INFO - 2023-07-30 06:33:09 --> Helper loaded: lang_helper
INFO - 2023-07-30 06:33:09 --> Helper loaded: security_helper
INFO - 2023-07-30 06:33:09 --> Helper loaded: cookie_helper
INFO - 2023-07-30 06:33:09 --> Database Driver Class Initialized
INFO - 2023-07-30 06:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 06:33:09 --> Parser Class Initialized
INFO - 2023-07-30 06:33:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 06:33:09 --> Pagination Class Initialized
INFO - 2023-07-30 06:33:09 --> Form Validation Class Initialized
INFO - 2023-07-30 06:33:09 --> Controller Class Initialized
INFO - 2023-07-30 06:33:09 --> Model Class Initialized
DEBUG - 2023-07-30 06:33:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-30 12:57:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 12:57:56 --> Config Class Initialized
INFO - 2023-07-30 12:57:56 --> Hooks Class Initialized
DEBUG - 2023-07-30 12:57:56 --> UTF-8 Support Enabled
INFO - 2023-07-30 12:57:56 --> Utf8 Class Initialized
INFO - 2023-07-30 12:57:56 --> URI Class Initialized
DEBUG - 2023-07-30 12:57:56 --> No URI present. Default controller set.
INFO - 2023-07-30 12:57:56 --> Router Class Initialized
INFO - 2023-07-30 12:57:56 --> Output Class Initialized
INFO - 2023-07-30 12:57:56 --> Security Class Initialized
DEBUG - 2023-07-30 12:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 12:57:56 --> Input Class Initialized
INFO - 2023-07-30 12:57:56 --> Language Class Initialized
INFO - 2023-07-30 12:57:56 --> Loader Class Initialized
INFO - 2023-07-30 12:57:56 --> Helper loaded: url_helper
INFO - 2023-07-30 12:57:56 --> Helper loaded: file_helper
INFO - 2023-07-30 12:57:56 --> Helper loaded: html_helper
INFO - 2023-07-30 12:57:56 --> Helper loaded: text_helper
INFO - 2023-07-30 12:57:56 --> Helper loaded: form_helper
INFO - 2023-07-30 12:57:56 --> Helper loaded: lang_helper
INFO - 2023-07-30 12:57:56 --> Helper loaded: security_helper
INFO - 2023-07-30 12:57:56 --> Helper loaded: cookie_helper
INFO - 2023-07-30 12:57:56 --> Database Driver Class Initialized
INFO - 2023-07-30 12:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 12:57:56 --> Parser Class Initialized
INFO - 2023-07-30 12:57:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 12:57:56 --> Pagination Class Initialized
INFO - 2023-07-30 12:57:56 --> Form Validation Class Initialized
INFO - 2023-07-30 12:57:56 --> Controller Class Initialized
INFO - 2023-07-30 12:57:56 --> Model Class Initialized
DEBUG - 2023-07-30 12:57:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-30 12:57:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 12:57:56 --> Config Class Initialized
INFO - 2023-07-30 12:57:56 --> Hooks Class Initialized
DEBUG - 2023-07-30 12:57:56 --> UTF-8 Support Enabled
INFO - 2023-07-30 12:57:56 --> Utf8 Class Initialized
INFO - 2023-07-30 12:57:56 --> URI Class Initialized
INFO - 2023-07-30 12:57:56 --> Router Class Initialized
INFO - 2023-07-30 12:57:56 --> Output Class Initialized
INFO - 2023-07-30 12:57:56 --> Security Class Initialized
DEBUG - 2023-07-30 12:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 12:57:56 --> Input Class Initialized
INFO - 2023-07-30 12:57:56 --> Language Class Initialized
INFO - 2023-07-30 12:57:56 --> Loader Class Initialized
INFO - 2023-07-30 12:57:56 --> Helper loaded: url_helper
INFO - 2023-07-30 12:57:56 --> Helper loaded: file_helper
INFO - 2023-07-30 12:57:56 --> Helper loaded: html_helper
INFO - 2023-07-30 12:57:56 --> Helper loaded: text_helper
INFO - 2023-07-30 12:57:56 --> Helper loaded: form_helper
INFO - 2023-07-30 12:57:56 --> Helper loaded: lang_helper
INFO - 2023-07-30 12:57:56 --> Helper loaded: security_helper
INFO - 2023-07-30 12:57:56 --> Helper loaded: cookie_helper
INFO - 2023-07-30 12:57:56 --> Database Driver Class Initialized
INFO - 2023-07-30 12:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 12:57:56 --> Parser Class Initialized
INFO - 2023-07-30 12:57:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 12:57:56 --> Pagination Class Initialized
INFO - 2023-07-30 12:57:56 --> Form Validation Class Initialized
INFO - 2023-07-30 12:57:56 --> Controller Class Initialized
INFO - 2023-07-30 12:57:56 --> Model Class Initialized
DEBUG - 2023-07-30 12:57:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 12:57:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-30 12:57:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 12:57:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 12:57:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 12:57:57 --> Model Class Initialized
INFO - 2023-07-30 12:57:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 12:57:57 --> Final output sent to browser
DEBUG - 2023-07-30 12:57:57 --> Total execution time: 0.0359
ERROR - 2023-07-30 12:58:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 12:58:20 --> Config Class Initialized
INFO - 2023-07-30 12:58:20 --> Hooks Class Initialized
DEBUG - 2023-07-30 12:58:20 --> UTF-8 Support Enabled
INFO - 2023-07-30 12:58:20 --> Utf8 Class Initialized
INFO - 2023-07-30 12:58:20 --> URI Class Initialized
INFO - 2023-07-30 12:58:20 --> Router Class Initialized
INFO - 2023-07-30 12:58:20 --> Output Class Initialized
INFO - 2023-07-30 12:58:20 --> Security Class Initialized
DEBUG - 2023-07-30 12:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 12:58:20 --> Input Class Initialized
INFO - 2023-07-30 12:58:20 --> Language Class Initialized
INFO - 2023-07-30 12:58:20 --> Loader Class Initialized
INFO - 2023-07-30 12:58:20 --> Helper loaded: url_helper
INFO - 2023-07-30 12:58:20 --> Helper loaded: file_helper
INFO - 2023-07-30 12:58:20 --> Helper loaded: html_helper
INFO - 2023-07-30 12:58:20 --> Helper loaded: text_helper
INFO - 2023-07-30 12:58:20 --> Helper loaded: form_helper
INFO - 2023-07-30 12:58:20 --> Helper loaded: lang_helper
INFO - 2023-07-30 12:58:20 --> Helper loaded: security_helper
INFO - 2023-07-30 12:58:20 --> Helper loaded: cookie_helper
INFO - 2023-07-30 12:58:20 --> Database Driver Class Initialized
INFO - 2023-07-30 12:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 12:58:20 --> Parser Class Initialized
INFO - 2023-07-30 12:58:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 12:58:20 --> Pagination Class Initialized
INFO - 2023-07-30 12:58:20 --> Form Validation Class Initialized
INFO - 2023-07-30 12:58:20 --> Controller Class Initialized
INFO - 2023-07-30 12:58:20 --> Model Class Initialized
DEBUG - 2023-07-30 12:58:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 12:58:20 --> Model Class Initialized
INFO - 2023-07-30 12:58:20 --> Final output sent to browser
DEBUG - 2023-07-30 12:58:20 --> Total execution time: 0.0204
ERROR - 2023-07-30 12:58:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 12:58:21 --> Config Class Initialized
INFO - 2023-07-30 12:58:21 --> Hooks Class Initialized
DEBUG - 2023-07-30 12:58:21 --> UTF-8 Support Enabled
INFO - 2023-07-30 12:58:21 --> Utf8 Class Initialized
INFO - 2023-07-30 12:58:21 --> URI Class Initialized
DEBUG - 2023-07-30 12:58:21 --> No URI present. Default controller set.
INFO - 2023-07-30 12:58:21 --> Router Class Initialized
INFO - 2023-07-30 12:58:21 --> Output Class Initialized
INFO - 2023-07-30 12:58:21 --> Security Class Initialized
DEBUG - 2023-07-30 12:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 12:58:21 --> Input Class Initialized
INFO - 2023-07-30 12:58:21 --> Language Class Initialized
INFO - 2023-07-30 12:58:21 --> Loader Class Initialized
INFO - 2023-07-30 12:58:21 --> Helper loaded: url_helper
INFO - 2023-07-30 12:58:21 --> Helper loaded: file_helper
INFO - 2023-07-30 12:58:21 --> Helper loaded: html_helper
INFO - 2023-07-30 12:58:21 --> Helper loaded: text_helper
INFO - 2023-07-30 12:58:21 --> Helper loaded: form_helper
INFO - 2023-07-30 12:58:21 --> Helper loaded: lang_helper
INFO - 2023-07-30 12:58:21 --> Helper loaded: security_helper
INFO - 2023-07-30 12:58:21 --> Helper loaded: cookie_helper
INFO - 2023-07-30 12:58:21 --> Database Driver Class Initialized
INFO - 2023-07-30 12:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 12:58:21 --> Parser Class Initialized
INFO - 2023-07-30 12:58:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 12:58:21 --> Pagination Class Initialized
INFO - 2023-07-30 12:58:21 --> Form Validation Class Initialized
INFO - 2023-07-30 12:58:21 --> Controller Class Initialized
INFO - 2023-07-30 12:58:21 --> Model Class Initialized
DEBUG - 2023-07-30 12:58:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 12:58:21 --> Model Class Initialized
DEBUG - 2023-07-30 12:58:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 12:58:21 --> Model Class Initialized
INFO - 2023-07-30 12:58:21 --> Model Class Initialized
INFO - 2023-07-30 12:58:21 --> Model Class Initialized
INFO - 2023-07-30 12:58:21 --> Model Class Initialized
DEBUG - 2023-07-30 12:58:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 12:58:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 12:58:21 --> Model Class Initialized
INFO - 2023-07-30 12:58:21 --> Model Class Initialized
INFO - 2023-07-30 12:58:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-30 12:58:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 12:58:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 12:58:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 12:58:21 --> Model Class Initialized
INFO - 2023-07-30 12:58:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 12:58:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 12:58:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 12:58:21 --> Final output sent to browser
DEBUG - 2023-07-30 12:58:21 --> Total execution time: 0.0934
ERROR - 2023-07-30 14:47:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 14:47:50 --> Config Class Initialized
INFO - 2023-07-30 14:47:50 --> Hooks Class Initialized
DEBUG - 2023-07-30 14:47:50 --> UTF-8 Support Enabled
INFO - 2023-07-30 14:47:50 --> Utf8 Class Initialized
INFO - 2023-07-30 14:47:50 --> URI Class Initialized
DEBUG - 2023-07-30 14:47:50 --> No URI present. Default controller set.
INFO - 2023-07-30 14:47:50 --> Router Class Initialized
INFO - 2023-07-30 14:47:50 --> Output Class Initialized
INFO - 2023-07-30 14:47:50 --> Security Class Initialized
DEBUG - 2023-07-30 14:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 14:47:50 --> Input Class Initialized
INFO - 2023-07-30 14:47:50 --> Language Class Initialized
INFO - 2023-07-30 14:47:50 --> Loader Class Initialized
INFO - 2023-07-30 14:47:50 --> Helper loaded: url_helper
INFO - 2023-07-30 14:47:50 --> Helper loaded: file_helper
INFO - 2023-07-30 14:47:50 --> Helper loaded: html_helper
INFO - 2023-07-30 14:47:50 --> Helper loaded: text_helper
INFO - 2023-07-30 14:47:50 --> Helper loaded: form_helper
INFO - 2023-07-30 14:47:50 --> Helper loaded: lang_helper
INFO - 2023-07-30 14:47:50 --> Helper loaded: security_helper
INFO - 2023-07-30 14:47:50 --> Helper loaded: cookie_helper
INFO - 2023-07-30 14:47:50 --> Database Driver Class Initialized
INFO - 2023-07-30 14:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 14:47:50 --> Parser Class Initialized
INFO - 2023-07-30 14:47:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 14:47:50 --> Pagination Class Initialized
INFO - 2023-07-30 14:47:50 --> Form Validation Class Initialized
INFO - 2023-07-30 14:47:50 --> Controller Class Initialized
INFO - 2023-07-30 14:47:50 --> Model Class Initialized
DEBUG - 2023-07-30 14:47:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-30 14:47:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 14:47:50 --> Config Class Initialized
INFO - 2023-07-30 14:47:50 --> Hooks Class Initialized
DEBUG - 2023-07-30 14:47:50 --> UTF-8 Support Enabled
INFO - 2023-07-30 14:47:50 --> Utf8 Class Initialized
INFO - 2023-07-30 14:47:50 --> URI Class Initialized
INFO - 2023-07-30 14:47:50 --> Router Class Initialized
INFO - 2023-07-30 14:47:50 --> Output Class Initialized
INFO - 2023-07-30 14:47:50 --> Security Class Initialized
DEBUG - 2023-07-30 14:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 14:47:50 --> Input Class Initialized
INFO - 2023-07-30 14:47:50 --> Language Class Initialized
INFO - 2023-07-30 14:47:50 --> Loader Class Initialized
INFO - 2023-07-30 14:47:50 --> Helper loaded: url_helper
INFO - 2023-07-30 14:47:50 --> Helper loaded: file_helper
INFO - 2023-07-30 14:47:50 --> Helper loaded: html_helper
INFO - 2023-07-30 14:47:50 --> Helper loaded: text_helper
INFO - 2023-07-30 14:47:50 --> Helper loaded: form_helper
INFO - 2023-07-30 14:47:50 --> Helper loaded: lang_helper
INFO - 2023-07-30 14:47:50 --> Helper loaded: security_helper
INFO - 2023-07-30 14:47:50 --> Helper loaded: cookie_helper
INFO - 2023-07-30 14:47:50 --> Database Driver Class Initialized
INFO - 2023-07-30 14:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 14:47:50 --> Parser Class Initialized
INFO - 2023-07-30 14:47:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 14:47:50 --> Pagination Class Initialized
INFO - 2023-07-30 14:47:50 --> Form Validation Class Initialized
INFO - 2023-07-30 14:47:50 --> Controller Class Initialized
INFO - 2023-07-30 14:47:50 --> Model Class Initialized
DEBUG - 2023-07-30 14:47:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 14:47:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-30 14:47:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 14:47:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 14:47:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 14:47:50 --> Model Class Initialized
INFO - 2023-07-30 14:47:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 14:47:50 --> Final output sent to browser
DEBUG - 2023-07-30 14:47:50 --> Total execution time: 0.0317
ERROR - 2023-07-30 14:48:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 14:48:01 --> Config Class Initialized
INFO - 2023-07-30 14:48:01 --> Hooks Class Initialized
DEBUG - 2023-07-30 14:48:01 --> UTF-8 Support Enabled
INFO - 2023-07-30 14:48:01 --> Utf8 Class Initialized
INFO - 2023-07-30 14:48:01 --> URI Class Initialized
DEBUG - 2023-07-30 14:48:01 --> No URI present. Default controller set.
INFO - 2023-07-30 14:48:01 --> Router Class Initialized
INFO - 2023-07-30 14:48:01 --> Output Class Initialized
INFO - 2023-07-30 14:48:01 --> Security Class Initialized
DEBUG - 2023-07-30 14:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 14:48:01 --> Input Class Initialized
INFO - 2023-07-30 14:48:01 --> Language Class Initialized
INFO - 2023-07-30 14:48:01 --> Loader Class Initialized
INFO - 2023-07-30 14:48:01 --> Helper loaded: url_helper
INFO - 2023-07-30 14:48:01 --> Helper loaded: file_helper
INFO - 2023-07-30 14:48:01 --> Helper loaded: html_helper
INFO - 2023-07-30 14:48:01 --> Helper loaded: text_helper
INFO - 2023-07-30 14:48:01 --> Helper loaded: form_helper
INFO - 2023-07-30 14:48:01 --> Helper loaded: lang_helper
INFO - 2023-07-30 14:48:01 --> Helper loaded: security_helper
INFO - 2023-07-30 14:48:01 --> Helper loaded: cookie_helper
INFO - 2023-07-30 14:48:01 --> Database Driver Class Initialized
INFO - 2023-07-30 14:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 14:48:01 --> Parser Class Initialized
INFO - 2023-07-30 14:48:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 14:48:01 --> Pagination Class Initialized
INFO - 2023-07-30 14:48:01 --> Form Validation Class Initialized
INFO - 2023-07-30 14:48:01 --> Controller Class Initialized
INFO - 2023-07-30 14:48:01 --> Model Class Initialized
DEBUG - 2023-07-30 14:48:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-30 14:48:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 14:48:01 --> Config Class Initialized
INFO - 2023-07-30 14:48:01 --> Hooks Class Initialized
DEBUG - 2023-07-30 14:48:01 --> UTF-8 Support Enabled
INFO - 2023-07-30 14:48:01 --> Utf8 Class Initialized
INFO - 2023-07-30 14:48:01 --> URI Class Initialized
INFO - 2023-07-30 14:48:01 --> Router Class Initialized
INFO - 2023-07-30 14:48:01 --> Output Class Initialized
INFO - 2023-07-30 14:48:01 --> Security Class Initialized
DEBUG - 2023-07-30 14:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 14:48:01 --> Input Class Initialized
INFO - 2023-07-30 14:48:01 --> Language Class Initialized
INFO - 2023-07-30 14:48:01 --> Loader Class Initialized
INFO - 2023-07-30 14:48:01 --> Helper loaded: url_helper
INFO - 2023-07-30 14:48:01 --> Helper loaded: file_helper
INFO - 2023-07-30 14:48:01 --> Helper loaded: html_helper
INFO - 2023-07-30 14:48:01 --> Helper loaded: text_helper
INFO - 2023-07-30 14:48:01 --> Helper loaded: form_helper
INFO - 2023-07-30 14:48:01 --> Helper loaded: lang_helper
INFO - 2023-07-30 14:48:01 --> Helper loaded: security_helper
INFO - 2023-07-30 14:48:01 --> Helper loaded: cookie_helper
INFO - 2023-07-30 14:48:01 --> Database Driver Class Initialized
INFO - 2023-07-30 14:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 14:48:01 --> Parser Class Initialized
INFO - 2023-07-30 14:48:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 14:48:01 --> Pagination Class Initialized
INFO - 2023-07-30 14:48:01 --> Form Validation Class Initialized
INFO - 2023-07-30 14:48:01 --> Controller Class Initialized
INFO - 2023-07-30 14:48:01 --> Model Class Initialized
DEBUG - 2023-07-30 14:48:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 14:48:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-30 14:48:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 14:48:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 14:48:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 14:48:01 --> Model Class Initialized
INFO - 2023-07-30 14:48:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 14:48:01 --> Final output sent to browser
DEBUG - 2023-07-30 14:48:01 --> Total execution time: 0.0350
ERROR - 2023-07-30 14:48:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 14:48:01 --> Config Class Initialized
INFO - 2023-07-30 14:48:01 --> Hooks Class Initialized
DEBUG - 2023-07-30 14:48:01 --> UTF-8 Support Enabled
INFO - 2023-07-30 14:48:01 --> Utf8 Class Initialized
INFO - 2023-07-30 14:48:01 --> URI Class Initialized
DEBUG - 2023-07-30 14:48:01 --> No URI present. Default controller set.
INFO - 2023-07-30 14:48:01 --> Router Class Initialized
INFO - 2023-07-30 14:48:01 --> Output Class Initialized
INFO - 2023-07-30 14:48:01 --> Security Class Initialized
DEBUG - 2023-07-30 14:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 14:48:01 --> Input Class Initialized
INFO - 2023-07-30 14:48:01 --> Language Class Initialized
INFO - 2023-07-30 14:48:01 --> Loader Class Initialized
INFO - 2023-07-30 14:48:01 --> Helper loaded: url_helper
INFO - 2023-07-30 14:48:01 --> Helper loaded: file_helper
INFO - 2023-07-30 14:48:01 --> Helper loaded: html_helper
INFO - 2023-07-30 14:48:01 --> Helper loaded: text_helper
INFO - 2023-07-30 14:48:01 --> Helper loaded: form_helper
INFO - 2023-07-30 14:48:01 --> Helper loaded: lang_helper
INFO - 2023-07-30 14:48:01 --> Helper loaded: security_helper
INFO - 2023-07-30 14:48:01 --> Helper loaded: cookie_helper
INFO - 2023-07-30 14:48:01 --> Database Driver Class Initialized
INFO - 2023-07-30 14:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 14:48:01 --> Parser Class Initialized
INFO - 2023-07-30 14:48:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 14:48:01 --> Pagination Class Initialized
INFO - 2023-07-30 14:48:01 --> Form Validation Class Initialized
INFO - 2023-07-30 14:48:01 --> Controller Class Initialized
INFO - 2023-07-30 14:48:01 --> Model Class Initialized
DEBUG - 2023-07-30 14:48:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-30 14:48:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 14:48:02 --> Config Class Initialized
INFO - 2023-07-30 14:48:02 --> Hooks Class Initialized
DEBUG - 2023-07-30 14:48:02 --> UTF-8 Support Enabled
INFO - 2023-07-30 14:48:02 --> Utf8 Class Initialized
INFO - 2023-07-30 14:48:02 --> URI Class Initialized
INFO - 2023-07-30 14:48:02 --> Router Class Initialized
INFO - 2023-07-30 14:48:02 --> Output Class Initialized
INFO - 2023-07-30 14:48:02 --> Security Class Initialized
DEBUG - 2023-07-30 14:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 14:48:02 --> Input Class Initialized
INFO - 2023-07-30 14:48:02 --> Language Class Initialized
INFO - 2023-07-30 14:48:02 --> Loader Class Initialized
INFO - 2023-07-30 14:48:02 --> Helper loaded: url_helper
INFO - 2023-07-30 14:48:02 --> Helper loaded: file_helper
INFO - 2023-07-30 14:48:02 --> Helper loaded: html_helper
INFO - 2023-07-30 14:48:02 --> Helper loaded: text_helper
INFO - 2023-07-30 14:48:02 --> Helper loaded: form_helper
INFO - 2023-07-30 14:48:02 --> Helper loaded: lang_helper
INFO - 2023-07-30 14:48:02 --> Helper loaded: security_helper
INFO - 2023-07-30 14:48:02 --> Helper loaded: cookie_helper
INFO - 2023-07-30 14:48:02 --> Database Driver Class Initialized
INFO - 2023-07-30 14:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 14:48:02 --> Parser Class Initialized
INFO - 2023-07-30 14:48:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 14:48:02 --> Pagination Class Initialized
INFO - 2023-07-30 14:48:02 --> Form Validation Class Initialized
INFO - 2023-07-30 14:48:02 --> Controller Class Initialized
INFO - 2023-07-30 14:48:02 --> Model Class Initialized
DEBUG - 2023-07-30 14:48:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 14:48:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-30 14:48:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 14:48:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 14:48:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 14:48:02 --> Model Class Initialized
INFO - 2023-07-30 14:48:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 14:48:02 --> Final output sent to browser
DEBUG - 2023-07-30 14:48:02 --> Total execution time: 0.0314
ERROR - 2023-07-30 15:25:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 15:25:57 --> Config Class Initialized
INFO - 2023-07-30 15:25:57 --> Hooks Class Initialized
DEBUG - 2023-07-30 15:25:57 --> UTF-8 Support Enabled
INFO - 2023-07-30 15:25:57 --> Utf8 Class Initialized
INFO - 2023-07-30 15:25:57 --> URI Class Initialized
DEBUG - 2023-07-30 15:25:57 --> No URI present. Default controller set.
INFO - 2023-07-30 15:25:57 --> Router Class Initialized
INFO - 2023-07-30 15:25:57 --> Output Class Initialized
INFO - 2023-07-30 15:25:57 --> Security Class Initialized
DEBUG - 2023-07-30 15:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 15:25:57 --> Input Class Initialized
INFO - 2023-07-30 15:25:57 --> Language Class Initialized
INFO - 2023-07-30 15:25:57 --> Loader Class Initialized
INFO - 2023-07-30 15:25:57 --> Helper loaded: url_helper
INFO - 2023-07-30 15:25:57 --> Helper loaded: file_helper
INFO - 2023-07-30 15:25:57 --> Helper loaded: html_helper
INFO - 2023-07-30 15:25:57 --> Helper loaded: text_helper
INFO - 2023-07-30 15:25:57 --> Helper loaded: form_helper
INFO - 2023-07-30 15:25:57 --> Helper loaded: lang_helper
INFO - 2023-07-30 15:25:57 --> Helper loaded: security_helper
INFO - 2023-07-30 15:25:57 --> Helper loaded: cookie_helper
INFO - 2023-07-30 15:25:57 --> Database Driver Class Initialized
INFO - 2023-07-30 15:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 15:25:57 --> Parser Class Initialized
INFO - 2023-07-30 15:25:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 15:25:57 --> Pagination Class Initialized
INFO - 2023-07-30 15:25:57 --> Form Validation Class Initialized
INFO - 2023-07-30 15:25:57 --> Controller Class Initialized
INFO - 2023-07-30 15:25:57 --> Model Class Initialized
DEBUG - 2023-07-30 15:25:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-30 15:25:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 15:25:57 --> Config Class Initialized
INFO - 2023-07-30 15:25:57 --> Hooks Class Initialized
DEBUG - 2023-07-30 15:25:57 --> UTF-8 Support Enabled
INFO - 2023-07-30 15:25:57 --> Utf8 Class Initialized
INFO - 2023-07-30 15:25:57 --> URI Class Initialized
INFO - 2023-07-30 15:25:57 --> Router Class Initialized
INFO - 2023-07-30 15:25:57 --> Output Class Initialized
INFO - 2023-07-30 15:25:57 --> Security Class Initialized
DEBUG - 2023-07-30 15:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 15:25:57 --> Input Class Initialized
INFO - 2023-07-30 15:25:57 --> Language Class Initialized
INFO - 2023-07-30 15:25:57 --> Loader Class Initialized
INFO - 2023-07-30 15:25:57 --> Helper loaded: url_helper
INFO - 2023-07-30 15:25:57 --> Helper loaded: file_helper
INFO - 2023-07-30 15:25:57 --> Helper loaded: html_helper
INFO - 2023-07-30 15:25:57 --> Helper loaded: text_helper
INFO - 2023-07-30 15:25:57 --> Helper loaded: form_helper
INFO - 2023-07-30 15:25:57 --> Helper loaded: lang_helper
INFO - 2023-07-30 15:25:57 --> Helper loaded: security_helper
INFO - 2023-07-30 15:25:57 --> Helper loaded: cookie_helper
INFO - 2023-07-30 15:25:57 --> Database Driver Class Initialized
INFO - 2023-07-30 15:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 15:25:57 --> Parser Class Initialized
INFO - 2023-07-30 15:25:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 15:25:57 --> Pagination Class Initialized
INFO - 2023-07-30 15:25:57 --> Form Validation Class Initialized
INFO - 2023-07-30 15:25:57 --> Controller Class Initialized
INFO - 2023-07-30 15:25:57 --> Model Class Initialized
DEBUG - 2023-07-30 15:25:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 15:25:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-30 15:25:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 15:25:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 15:25:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 15:25:57 --> Model Class Initialized
INFO - 2023-07-30 15:25:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 15:25:57 --> Final output sent to browser
DEBUG - 2023-07-30 15:25:57 --> Total execution time: 0.0292
ERROR - 2023-07-30 16:10:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:10:14 --> Config Class Initialized
INFO - 2023-07-30 16:10:14 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:10:14 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:10:14 --> Utf8 Class Initialized
INFO - 2023-07-30 16:10:14 --> URI Class Initialized
DEBUG - 2023-07-30 16:10:14 --> No URI present. Default controller set.
INFO - 2023-07-30 16:10:14 --> Router Class Initialized
INFO - 2023-07-30 16:10:14 --> Output Class Initialized
INFO - 2023-07-30 16:10:14 --> Security Class Initialized
DEBUG - 2023-07-30 16:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:10:14 --> Input Class Initialized
INFO - 2023-07-30 16:10:14 --> Language Class Initialized
INFO - 2023-07-30 16:10:14 --> Loader Class Initialized
INFO - 2023-07-30 16:10:14 --> Helper loaded: url_helper
INFO - 2023-07-30 16:10:14 --> Helper loaded: file_helper
INFO - 2023-07-30 16:10:14 --> Helper loaded: html_helper
INFO - 2023-07-30 16:10:14 --> Helper loaded: text_helper
INFO - 2023-07-30 16:10:14 --> Helper loaded: form_helper
INFO - 2023-07-30 16:10:14 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:10:14 --> Helper loaded: security_helper
INFO - 2023-07-30 16:10:14 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:10:14 --> Database Driver Class Initialized
INFO - 2023-07-30 16:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:10:14 --> Parser Class Initialized
INFO - 2023-07-30 16:10:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:10:14 --> Pagination Class Initialized
INFO - 2023-07-30 16:10:14 --> Form Validation Class Initialized
INFO - 2023-07-30 16:10:14 --> Controller Class Initialized
INFO - 2023-07-30 16:10:14 --> Model Class Initialized
DEBUG - 2023-07-30 16:10:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-30 16:10:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:10:15 --> Config Class Initialized
INFO - 2023-07-30 16:10:15 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:10:15 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:10:15 --> Utf8 Class Initialized
INFO - 2023-07-30 16:10:15 --> URI Class Initialized
INFO - 2023-07-30 16:10:15 --> Router Class Initialized
INFO - 2023-07-30 16:10:15 --> Output Class Initialized
INFO - 2023-07-30 16:10:15 --> Security Class Initialized
DEBUG - 2023-07-30 16:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:10:15 --> Input Class Initialized
INFO - 2023-07-30 16:10:15 --> Language Class Initialized
INFO - 2023-07-30 16:10:15 --> Loader Class Initialized
INFO - 2023-07-30 16:10:15 --> Helper loaded: url_helper
INFO - 2023-07-30 16:10:15 --> Helper loaded: file_helper
INFO - 2023-07-30 16:10:15 --> Helper loaded: html_helper
INFO - 2023-07-30 16:10:15 --> Helper loaded: text_helper
INFO - 2023-07-30 16:10:15 --> Helper loaded: form_helper
INFO - 2023-07-30 16:10:15 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:10:15 --> Helper loaded: security_helper
INFO - 2023-07-30 16:10:15 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:10:15 --> Database Driver Class Initialized
INFO - 2023-07-30 16:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:10:15 --> Parser Class Initialized
INFO - 2023-07-30 16:10:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:10:15 --> Pagination Class Initialized
INFO - 2023-07-30 16:10:15 --> Form Validation Class Initialized
INFO - 2023-07-30 16:10:15 --> Controller Class Initialized
INFO - 2023-07-30 16:10:15 --> Model Class Initialized
DEBUG - 2023-07-30 16:10:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:10:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-30 16:10:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:10:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:10:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:10:15 --> Model Class Initialized
INFO - 2023-07-30 16:10:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:10:15 --> Final output sent to browser
DEBUG - 2023-07-30 16:10:15 --> Total execution time: 0.0313
ERROR - 2023-07-30 16:10:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:10:15 --> Config Class Initialized
INFO - 2023-07-30 16:10:15 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:10:15 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:10:15 --> Utf8 Class Initialized
INFO - 2023-07-30 16:10:15 --> URI Class Initialized
INFO - 2023-07-30 16:10:15 --> Router Class Initialized
INFO - 2023-07-30 16:10:15 --> Output Class Initialized
INFO - 2023-07-30 16:10:15 --> Security Class Initialized
DEBUG - 2023-07-30 16:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:10:15 --> Input Class Initialized
INFO - 2023-07-30 16:10:15 --> Language Class Initialized
ERROR - 2023-07-30 16:10:15 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2023-07-30 16:10:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:10:16 --> Config Class Initialized
INFO - 2023-07-30 16:10:16 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:10:16 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:10:16 --> Utf8 Class Initialized
INFO - 2023-07-30 16:10:16 --> URI Class Initialized
INFO - 2023-07-30 16:10:16 --> Router Class Initialized
INFO - 2023-07-30 16:10:16 --> Output Class Initialized
INFO - 2023-07-30 16:10:16 --> Security Class Initialized
DEBUG - 2023-07-30 16:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:10:16 --> Input Class Initialized
INFO - 2023-07-30 16:10:16 --> Language Class Initialized
ERROR - 2023-07-30 16:10:16 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2023-07-30 16:10:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:10:55 --> Config Class Initialized
INFO - 2023-07-30 16:10:55 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:10:55 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:10:55 --> Utf8 Class Initialized
INFO - 2023-07-30 16:10:55 --> URI Class Initialized
INFO - 2023-07-30 16:10:55 --> Router Class Initialized
INFO - 2023-07-30 16:10:55 --> Output Class Initialized
INFO - 2023-07-30 16:10:55 --> Security Class Initialized
DEBUG - 2023-07-30 16:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:10:55 --> Input Class Initialized
INFO - 2023-07-30 16:10:55 --> Language Class Initialized
INFO - 2023-07-30 16:10:55 --> Loader Class Initialized
INFO - 2023-07-30 16:10:55 --> Helper loaded: url_helper
INFO - 2023-07-30 16:10:55 --> Helper loaded: file_helper
INFO - 2023-07-30 16:10:55 --> Helper loaded: html_helper
INFO - 2023-07-30 16:10:55 --> Helper loaded: text_helper
INFO - 2023-07-30 16:10:55 --> Helper loaded: form_helper
INFO - 2023-07-30 16:10:55 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:10:55 --> Helper loaded: security_helper
INFO - 2023-07-30 16:10:55 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:10:55 --> Database Driver Class Initialized
INFO - 2023-07-30 16:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:10:55 --> Parser Class Initialized
INFO - 2023-07-30 16:10:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:10:55 --> Pagination Class Initialized
INFO - 2023-07-30 16:10:55 --> Form Validation Class Initialized
INFO - 2023-07-30 16:10:55 --> Controller Class Initialized
INFO - 2023-07-30 16:10:55 --> Model Class Initialized
DEBUG - 2023-07-30 16:10:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:10:55 --> Model Class Initialized
INFO - 2023-07-30 16:10:55 --> Final output sent to browser
DEBUG - 2023-07-30 16:10:55 --> Total execution time: 0.0216
ERROR - 2023-07-30 16:10:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:10:55 --> Config Class Initialized
INFO - 2023-07-30 16:10:55 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:10:55 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:10:55 --> Utf8 Class Initialized
INFO - 2023-07-30 16:10:55 --> URI Class Initialized
DEBUG - 2023-07-30 16:10:55 --> No URI present. Default controller set.
INFO - 2023-07-30 16:10:55 --> Router Class Initialized
INFO - 2023-07-30 16:10:55 --> Output Class Initialized
INFO - 2023-07-30 16:10:55 --> Security Class Initialized
DEBUG - 2023-07-30 16:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:10:55 --> Input Class Initialized
INFO - 2023-07-30 16:10:55 --> Language Class Initialized
INFO - 2023-07-30 16:10:55 --> Loader Class Initialized
INFO - 2023-07-30 16:10:55 --> Helper loaded: url_helper
INFO - 2023-07-30 16:10:55 --> Helper loaded: file_helper
INFO - 2023-07-30 16:10:55 --> Helper loaded: html_helper
INFO - 2023-07-30 16:10:55 --> Helper loaded: text_helper
INFO - 2023-07-30 16:10:55 --> Helper loaded: form_helper
INFO - 2023-07-30 16:10:55 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:10:55 --> Helper loaded: security_helper
INFO - 2023-07-30 16:10:55 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:10:55 --> Database Driver Class Initialized
INFO - 2023-07-30 16:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:10:55 --> Parser Class Initialized
INFO - 2023-07-30 16:10:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:10:55 --> Pagination Class Initialized
INFO - 2023-07-30 16:10:55 --> Form Validation Class Initialized
INFO - 2023-07-30 16:10:55 --> Controller Class Initialized
INFO - 2023-07-30 16:10:55 --> Model Class Initialized
DEBUG - 2023-07-30 16:10:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:10:55 --> Model Class Initialized
DEBUG - 2023-07-30 16:10:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:10:55 --> Model Class Initialized
INFO - 2023-07-30 16:10:55 --> Model Class Initialized
INFO - 2023-07-30 16:10:55 --> Model Class Initialized
INFO - 2023-07-30 16:10:55 --> Model Class Initialized
DEBUG - 2023-07-30 16:10:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:10:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:10:55 --> Model Class Initialized
INFO - 2023-07-30 16:10:55 --> Model Class Initialized
INFO - 2023-07-30 16:10:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-30 16:10:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:10:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:10:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:10:55 --> Model Class Initialized
INFO - 2023-07-30 16:10:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:10:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:10:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:10:55 --> Final output sent to browser
DEBUG - 2023-07-30 16:10:55 --> Total execution time: 0.0895
ERROR - 2023-07-30 16:11:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:11:41 --> Config Class Initialized
INFO - 2023-07-30 16:11:41 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:11:41 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:11:41 --> Utf8 Class Initialized
INFO - 2023-07-30 16:11:41 --> URI Class Initialized
INFO - 2023-07-30 16:11:41 --> Router Class Initialized
INFO - 2023-07-30 16:11:41 --> Output Class Initialized
INFO - 2023-07-30 16:11:41 --> Security Class Initialized
DEBUG - 2023-07-30 16:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:11:41 --> Input Class Initialized
INFO - 2023-07-30 16:11:41 --> Language Class Initialized
INFO - 2023-07-30 16:11:41 --> Loader Class Initialized
INFO - 2023-07-30 16:11:41 --> Helper loaded: url_helper
INFO - 2023-07-30 16:11:41 --> Helper loaded: file_helper
INFO - 2023-07-30 16:11:41 --> Helper loaded: html_helper
INFO - 2023-07-30 16:11:41 --> Helper loaded: text_helper
INFO - 2023-07-30 16:11:41 --> Helper loaded: form_helper
INFO - 2023-07-30 16:11:41 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:11:41 --> Helper loaded: security_helper
INFO - 2023-07-30 16:11:41 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:11:41 --> Database Driver Class Initialized
INFO - 2023-07-30 16:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:11:41 --> Parser Class Initialized
INFO - 2023-07-30 16:11:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:11:41 --> Pagination Class Initialized
INFO - 2023-07-30 16:11:41 --> Form Validation Class Initialized
INFO - 2023-07-30 16:11:41 --> Controller Class Initialized
INFO - 2023-07-30 16:11:41 --> Model Class Initialized
DEBUG - 2023-07-30 16:11:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:11:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:11:41 --> Model Class Initialized
INFO - 2023-07-30 16:11:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-07-30 16:11:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:11:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:11:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:11:41 --> Model Class Initialized
INFO - 2023-07-30 16:11:41 --> Model Class Initialized
INFO - 2023-07-30 16:11:41 --> Model Class Initialized
INFO - 2023-07-30 16:11:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:11:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:11:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:11:41 --> Final output sent to browser
DEBUG - 2023-07-30 16:11:41 --> Total execution time: 0.0685
ERROR - 2023-07-30 16:11:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:11:42 --> Config Class Initialized
INFO - 2023-07-30 16:11:42 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:11:42 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:11:42 --> Utf8 Class Initialized
INFO - 2023-07-30 16:11:42 --> URI Class Initialized
INFO - 2023-07-30 16:11:42 --> Router Class Initialized
INFO - 2023-07-30 16:11:42 --> Output Class Initialized
INFO - 2023-07-30 16:11:42 --> Security Class Initialized
DEBUG - 2023-07-30 16:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:11:42 --> Input Class Initialized
INFO - 2023-07-30 16:11:42 --> Language Class Initialized
INFO - 2023-07-30 16:11:42 --> Loader Class Initialized
INFO - 2023-07-30 16:11:42 --> Helper loaded: url_helper
INFO - 2023-07-30 16:11:42 --> Helper loaded: file_helper
INFO - 2023-07-30 16:11:42 --> Helper loaded: html_helper
INFO - 2023-07-30 16:11:42 --> Helper loaded: text_helper
INFO - 2023-07-30 16:11:42 --> Helper loaded: form_helper
INFO - 2023-07-30 16:11:42 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:11:42 --> Helper loaded: security_helper
INFO - 2023-07-30 16:11:42 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:11:42 --> Database Driver Class Initialized
INFO - 2023-07-30 16:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:11:42 --> Parser Class Initialized
INFO - 2023-07-30 16:11:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:11:42 --> Pagination Class Initialized
INFO - 2023-07-30 16:11:42 --> Form Validation Class Initialized
INFO - 2023-07-30 16:11:42 --> Controller Class Initialized
INFO - 2023-07-30 16:11:42 --> Model Class Initialized
DEBUG - 2023-07-30 16:11:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:11:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:11:42 --> Model Class Initialized
INFO - 2023-07-30 16:11:42 --> Final output sent to browser
DEBUG - 2023-07-30 16:11:42 --> Total execution time: 0.0331
ERROR - 2023-07-30 16:11:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:11:48 --> Config Class Initialized
INFO - 2023-07-30 16:11:48 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:11:48 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:11:48 --> Utf8 Class Initialized
INFO - 2023-07-30 16:11:48 --> URI Class Initialized
INFO - 2023-07-30 16:11:48 --> Router Class Initialized
INFO - 2023-07-30 16:11:48 --> Output Class Initialized
INFO - 2023-07-30 16:11:48 --> Security Class Initialized
DEBUG - 2023-07-30 16:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:11:48 --> Input Class Initialized
INFO - 2023-07-30 16:11:48 --> Language Class Initialized
INFO - 2023-07-30 16:11:48 --> Loader Class Initialized
INFO - 2023-07-30 16:11:48 --> Helper loaded: url_helper
INFO - 2023-07-30 16:11:48 --> Helper loaded: file_helper
INFO - 2023-07-30 16:11:48 --> Helper loaded: html_helper
INFO - 2023-07-30 16:11:48 --> Helper loaded: text_helper
INFO - 2023-07-30 16:11:48 --> Helper loaded: form_helper
INFO - 2023-07-30 16:11:48 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:11:48 --> Helper loaded: security_helper
INFO - 2023-07-30 16:11:48 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:11:48 --> Database Driver Class Initialized
INFO - 2023-07-30 16:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:11:48 --> Parser Class Initialized
INFO - 2023-07-30 16:11:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:11:48 --> Pagination Class Initialized
INFO - 2023-07-30 16:11:48 --> Form Validation Class Initialized
INFO - 2023-07-30 16:11:48 --> Controller Class Initialized
INFO - 2023-07-30 16:11:48 --> Model Class Initialized
DEBUG - 2023-07-30 16:11:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:11:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:11:48 --> Model Class Initialized
INFO - 2023-07-30 16:11:48 --> Final output sent to browser
DEBUG - 2023-07-30 16:11:48 --> Total execution time: 0.0250
ERROR - 2023-07-30 16:12:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:12:25 --> Config Class Initialized
INFO - 2023-07-30 16:12:25 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:12:25 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:12:25 --> Utf8 Class Initialized
INFO - 2023-07-30 16:12:25 --> URI Class Initialized
DEBUG - 2023-07-30 16:12:25 --> No URI present. Default controller set.
INFO - 2023-07-30 16:12:25 --> Router Class Initialized
INFO - 2023-07-30 16:12:25 --> Output Class Initialized
INFO - 2023-07-30 16:12:25 --> Security Class Initialized
DEBUG - 2023-07-30 16:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:12:25 --> Input Class Initialized
INFO - 2023-07-30 16:12:25 --> Language Class Initialized
INFO - 2023-07-30 16:12:25 --> Loader Class Initialized
INFO - 2023-07-30 16:12:25 --> Helper loaded: url_helper
INFO - 2023-07-30 16:12:25 --> Helper loaded: file_helper
INFO - 2023-07-30 16:12:25 --> Helper loaded: html_helper
INFO - 2023-07-30 16:12:25 --> Helper loaded: text_helper
INFO - 2023-07-30 16:12:25 --> Helper loaded: form_helper
INFO - 2023-07-30 16:12:25 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:12:25 --> Helper loaded: security_helper
INFO - 2023-07-30 16:12:25 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:12:25 --> Database Driver Class Initialized
INFO - 2023-07-30 16:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:12:25 --> Parser Class Initialized
INFO - 2023-07-30 16:12:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:12:25 --> Pagination Class Initialized
INFO - 2023-07-30 16:12:25 --> Form Validation Class Initialized
INFO - 2023-07-30 16:12:25 --> Controller Class Initialized
INFO - 2023-07-30 16:12:25 --> Model Class Initialized
DEBUG - 2023-07-30 16:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:12:25 --> Model Class Initialized
DEBUG - 2023-07-30 16:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:12:25 --> Model Class Initialized
INFO - 2023-07-30 16:12:25 --> Model Class Initialized
INFO - 2023-07-30 16:12:25 --> Model Class Initialized
INFO - 2023-07-30 16:12:25 --> Model Class Initialized
DEBUG - 2023-07-30 16:12:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:12:25 --> Model Class Initialized
INFO - 2023-07-30 16:12:25 --> Model Class Initialized
INFO - 2023-07-30 16:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-30 16:12:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:12:25 --> Model Class Initialized
INFO - 2023-07-30 16:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:12:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:12:25 --> Final output sent to browser
DEBUG - 2023-07-30 16:12:25 --> Total execution time: 0.0851
ERROR - 2023-07-30 16:12:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:12:29 --> Config Class Initialized
INFO - 2023-07-30 16:12:29 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:12:29 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:12:29 --> Utf8 Class Initialized
INFO - 2023-07-30 16:12:29 --> URI Class Initialized
INFO - 2023-07-30 16:12:29 --> Router Class Initialized
INFO - 2023-07-30 16:12:29 --> Output Class Initialized
INFO - 2023-07-30 16:12:29 --> Security Class Initialized
DEBUG - 2023-07-30 16:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:12:29 --> Input Class Initialized
INFO - 2023-07-30 16:12:29 --> Language Class Initialized
INFO - 2023-07-30 16:12:29 --> Loader Class Initialized
INFO - 2023-07-30 16:12:29 --> Helper loaded: url_helper
INFO - 2023-07-30 16:12:29 --> Helper loaded: file_helper
INFO - 2023-07-30 16:12:29 --> Helper loaded: html_helper
INFO - 2023-07-30 16:12:29 --> Helper loaded: text_helper
INFO - 2023-07-30 16:12:29 --> Helper loaded: form_helper
INFO - 2023-07-30 16:12:29 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:12:29 --> Helper loaded: security_helper
INFO - 2023-07-30 16:12:29 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:12:29 --> Database Driver Class Initialized
INFO - 2023-07-30 16:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:12:29 --> Parser Class Initialized
INFO - 2023-07-30 16:12:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:12:29 --> Pagination Class Initialized
INFO - 2023-07-30 16:12:29 --> Form Validation Class Initialized
INFO - 2023-07-30 16:12:29 --> Controller Class Initialized
INFO - 2023-07-30 16:12:29 --> Model Class Initialized
DEBUG - 2023-07-30 16:12:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:12:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:12:29 --> Model Class Initialized
DEBUG - 2023-07-30 16:12:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:12:29 --> Model Class Initialized
INFO - 2023-07-30 16:12:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-30 16:12:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:12:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:12:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:12:29 --> Model Class Initialized
INFO - 2023-07-30 16:12:29 --> Model Class Initialized
INFO - 2023-07-30 16:12:29 --> Model Class Initialized
INFO - 2023-07-30 16:12:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:12:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:12:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:12:29 --> Final output sent to browser
DEBUG - 2023-07-30 16:12:29 --> Total execution time: 0.0850
ERROR - 2023-07-30 16:12:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:12:30 --> Config Class Initialized
INFO - 2023-07-30 16:12:30 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:12:30 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:12:30 --> Utf8 Class Initialized
INFO - 2023-07-30 16:12:30 --> URI Class Initialized
INFO - 2023-07-30 16:12:30 --> Router Class Initialized
INFO - 2023-07-30 16:12:30 --> Output Class Initialized
INFO - 2023-07-30 16:12:30 --> Security Class Initialized
DEBUG - 2023-07-30 16:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:12:30 --> Input Class Initialized
INFO - 2023-07-30 16:12:30 --> Language Class Initialized
INFO - 2023-07-30 16:12:30 --> Loader Class Initialized
INFO - 2023-07-30 16:12:30 --> Helper loaded: url_helper
INFO - 2023-07-30 16:12:30 --> Helper loaded: file_helper
INFO - 2023-07-30 16:12:30 --> Helper loaded: html_helper
INFO - 2023-07-30 16:12:30 --> Helper loaded: text_helper
INFO - 2023-07-30 16:12:30 --> Helper loaded: form_helper
INFO - 2023-07-30 16:12:30 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:12:30 --> Helper loaded: security_helper
INFO - 2023-07-30 16:12:30 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:12:30 --> Database Driver Class Initialized
INFO - 2023-07-30 16:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:12:30 --> Parser Class Initialized
INFO - 2023-07-30 16:12:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:12:30 --> Pagination Class Initialized
INFO - 2023-07-30 16:12:30 --> Form Validation Class Initialized
INFO - 2023-07-30 16:12:30 --> Controller Class Initialized
INFO - 2023-07-30 16:12:30 --> Model Class Initialized
DEBUG - 2023-07-30 16:12:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:12:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:12:30 --> Model Class Initialized
DEBUG - 2023-07-30 16:12:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:12:30 --> Model Class Initialized
INFO - 2023-07-30 16:12:30 --> Final output sent to browser
DEBUG - 2023-07-30 16:12:30 --> Total execution time: 0.0421
ERROR - 2023-07-30 16:12:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:12:41 --> Config Class Initialized
INFO - 2023-07-30 16:12:41 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:12:41 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:12:41 --> Utf8 Class Initialized
INFO - 2023-07-30 16:12:41 --> URI Class Initialized
INFO - 2023-07-30 16:12:41 --> Router Class Initialized
INFO - 2023-07-30 16:12:41 --> Output Class Initialized
INFO - 2023-07-30 16:12:41 --> Security Class Initialized
DEBUG - 2023-07-30 16:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:12:41 --> Input Class Initialized
INFO - 2023-07-30 16:12:41 --> Language Class Initialized
INFO - 2023-07-30 16:12:41 --> Loader Class Initialized
INFO - 2023-07-30 16:12:41 --> Helper loaded: url_helper
INFO - 2023-07-30 16:12:41 --> Helper loaded: file_helper
INFO - 2023-07-30 16:12:41 --> Helper loaded: html_helper
INFO - 2023-07-30 16:12:41 --> Helper loaded: text_helper
INFO - 2023-07-30 16:12:41 --> Helper loaded: form_helper
INFO - 2023-07-30 16:12:41 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:12:41 --> Helper loaded: security_helper
INFO - 2023-07-30 16:12:41 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:12:41 --> Database Driver Class Initialized
INFO - 2023-07-30 16:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:12:41 --> Parser Class Initialized
INFO - 2023-07-30 16:12:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:12:41 --> Pagination Class Initialized
INFO - 2023-07-30 16:12:41 --> Form Validation Class Initialized
INFO - 2023-07-30 16:12:41 --> Controller Class Initialized
INFO - 2023-07-30 16:12:41 --> Model Class Initialized
DEBUG - 2023-07-30 16:12:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:12:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:12:41 --> Model Class Initialized
DEBUG - 2023-07-30 16:12:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:12:41 --> Model Class Initialized
INFO - 2023-07-30 16:12:41 --> Final output sent to browser
DEBUG - 2023-07-30 16:12:41 --> Total execution time: 0.0258
ERROR - 2023-07-30 16:12:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:12:51 --> Config Class Initialized
INFO - 2023-07-30 16:12:51 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:12:51 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:12:51 --> Utf8 Class Initialized
INFO - 2023-07-30 16:12:51 --> URI Class Initialized
INFO - 2023-07-30 16:12:51 --> Router Class Initialized
INFO - 2023-07-30 16:12:51 --> Output Class Initialized
INFO - 2023-07-30 16:12:51 --> Security Class Initialized
DEBUG - 2023-07-30 16:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:12:51 --> Input Class Initialized
INFO - 2023-07-30 16:12:51 --> Language Class Initialized
INFO - 2023-07-30 16:12:51 --> Loader Class Initialized
INFO - 2023-07-30 16:12:51 --> Helper loaded: url_helper
INFO - 2023-07-30 16:12:51 --> Helper loaded: file_helper
INFO - 2023-07-30 16:12:51 --> Helper loaded: html_helper
INFO - 2023-07-30 16:12:51 --> Helper loaded: text_helper
INFO - 2023-07-30 16:12:51 --> Helper loaded: form_helper
INFO - 2023-07-30 16:12:51 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:12:51 --> Helper loaded: security_helper
INFO - 2023-07-30 16:12:51 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:12:51 --> Database Driver Class Initialized
INFO - 2023-07-30 16:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:12:51 --> Parser Class Initialized
INFO - 2023-07-30 16:12:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:12:51 --> Pagination Class Initialized
INFO - 2023-07-30 16:12:51 --> Form Validation Class Initialized
INFO - 2023-07-30 16:12:51 --> Controller Class Initialized
INFO - 2023-07-30 16:12:51 --> Model Class Initialized
DEBUG - 2023-07-30 16:12:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:12:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:12:51 --> Model Class Initialized
DEBUG - 2023-07-30 16:12:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:12:51 --> Model Class Initialized
DEBUG - 2023-07-30 16:12:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:12:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-07-30 16:12:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:12:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:12:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:12:51 --> Model Class Initialized
INFO - 2023-07-30 16:12:51 --> Model Class Initialized
INFO - 2023-07-30 16:12:51 --> Model Class Initialized
INFO - 2023-07-30 16:12:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:12:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:12:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:12:51 --> Final output sent to browser
DEBUG - 2023-07-30 16:12:51 --> Total execution time: 0.0943
ERROR - 2023-07-30 16:13:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:13:31 --> Config Class Initialized
INFO - 2023-07-30 16:13:31 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:13:31 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:13:31 --> Utf8 Class Initialized
INFO - 2023-07-30 16:13:31 --> URI Class Initialized
INFO - 2023-07-30 16:13:31 --> Router Class Initialized
INFO - 2023-07-30 16:13:31 --> Output Class Initialized
INFO - 2023-07-30 16:13:31 --> Security Class Initialized
DEBUG - 2023-07-30 16:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:13:31 --> Input Class Initialized
INFO - 2023-07-30 16:13:31 --> Language Class Initialized
INFO - 2023-07-30 16:13:31 --> Loader Class Initialized
INFO - 2023-07-30 16:13:31 --> Helper loaded: url_helper
INFO - 2023-07-30 16:13:31 --> Helper loaded: file_helper
INFO - 2023-07-30 16:13:31 --> Helper loaded: html_helper
INFO - 2023-07-30 16:13:31 --> Helper loaded: text_helper
INFO - 2023-07-30 16:13:31 --> Helper loaded: form_helper
INFO - 2023-07-30 16:13:31 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:13:31 --> Helper loaded: security_helper
INFO - 2023-07-30 16:13:31 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:13:31 --> Database Driver Class Initialized
INFO - 2023-07-30 16:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:13:31 --> Parser Class Initialized
INFO - 2023-07-30 16:13:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:13:31 --> Pagination Class Initialized
INFO - 2023-07-30 16:13:31 --> Form Validation Class Initialized
INFO - 2023-07-30 16:13:31 --> Controller Class Initialized
INFO - 2023-07-30 16:13:31 --> Model Class Initialized
DEBUG - 2023-07-30 16:13:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:13:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:13:31 --> Model Class Initialized
DEBUG - 2023-07-30 16:13:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:13:31 --> Model Class Initialized
INFO - 2023-07-30 16:13:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-30 16:13:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:13:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:13:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:13:31 --> Model Class Initialized
INFO - 2023-07-30 16:13:31 --> Model Class Initialized
INFO - 2023-07-30 16:13:31 --> Model Class Initialized
INFO - 2023-07-30 16:13:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:13:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:13:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:13:32 --> Final output sent to browser
DEBUG - 2023-07-30 16:13:32 --> Total execution time: 0.0968
ERROR - 2023-07-30 16:13:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:13:32 --> Config Class Initialized
INFO - 2023-07-30 16:13:32 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:13:32 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:13:32 --> Utf8 Class Initialized
INFO - 2023-07-30 16:13:32 --> URI Class Initialized
INFO - 2023-07-30 16:13:32 --> Router Class Initialized
INFO - 2023-07-30 16:13:32 --> Output Class Initialized
INFO - 2023-07-30 16:13:32 --> Security Class Initialized
DEBUG - 2023-07-30 16:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:13:32 --> Input Class Initialized
INFO - 2023-07-30 16:13:32 --> Language Class Initialized
INFO - 2023-07-30 16:13:32 --> Loader Class Initialized
INFO - 2023-07-30 16:13:32 --> Helper loaded: url_helper
INFO - 2023-07-30 16:13:32 --> Helper loaded: file_helper
INFO - 2023-07-30 16:13:32 --> Helper loaded: html_helper
INFO - 2023-07-30 16:13:32 --> Helper loaded: text_helper
INFO - 2023-07-30 16:13:32 --> Helper loaded: form_helper
INFO - 2023-07-30 16:13:32 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:13:32 --> Helper loaded: security_helper
INFO - 2023-07-30 16:13:32 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:13:32 --> Database Driver Class Initialized
INFO - 2023-07-30 16:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:13:32 --> Parser Class Initialized
INFO - 2023-07-30 16:13:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:13:32 --> Pagination Class Initialized
INFO - 2023-07-30 16:13:32 --> Form Validation Class Initialized
INFO - 2023-07-30 16:13:32 --> Controller Class Initialized
INFO - 2023-07-30 16:13:32 --> Model Class Initialized
DEBUG - 2023-07-30 16:13:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:13:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:13:32 --> Model Class Initialized
DEBUG - 2023-07-30 16:13:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:13:32 --> Model Class Initialized
INFO - 2023-07-30 16:13:32 --> Final output sent to browser
DEBUG - 2023-07-30 16:13:32 --> Total execution time: 0.0396
ERROR - 2023-07-30 16:13:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:13:41 --> Config Class Initialized
INFO - 2023-07-30 16:13:41 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:13:41 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:13:41 --> Utf8 Class Initialized
INFO - 2023-07-30 16:13:41 --> URI Class Initialized
INFO - 2023-07-30 16:13:41 --> Router Class Initialized
INFO - 2023-07-30 16:13:41 --> Output Class Initialized
INFO - 2023-07-30 16:13:41 --> Security Class Initialized
DEBUG - 2023-07-30 16:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:13:41 --> Input Class Initialized
INFO - 2023-07-30 16:13:41 --> Language Class Initialized
INFO - 2023-07-30 16:13:41 --> Loader Class Initialized
INFO - 2023-07-30 16:13:41 --> Helper loaded: url_helper
INFO - 2023-07-30 16:13:41 --> Helper loaded: file_helper
INFO - 2023-07-30 16:13:41 --> Helper loaded: html_helper
INFO - 2023-07-30 16:13:41 --> Helper loaded: text_helper
INFO - 2023-07-30 16:13:41 --> Helper loaded: form_helper
INFO - 2023-07-30 16:13:41 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:13:41 --> Helper loaded: security_helper
INFO - 2023-07-30 16:13:41 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:13:41 --> Database Driver Class Initialized
INFO - 2023-07-30 16:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:13:41 --> Parser Class Initialized
INFO - 2023-07-30 16:13:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:13:41 --> Pagination Class Initialized
INFO - 2023-07-30 16:13:41 --> Form Validation Class Initialized
INFO - 2023-07-30 16:13:41 --> Controller Class Initialized
INFO - 2023-07-30 16:13:41 --> Model Class Initialized
DEBUG - 2023-07-30 16:13:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:13:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:13:41 --> Model Class Initialized
DEBUG - 2023-07-30 16:13:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:13:41 --> Model Class Initialized
INFO - 2023-07-30 16:13:41 --> Final output sent to browser
DEBUG - 2023-07-30 16:13:41 --> Total execution time: 0.0250
ERROR - 2023-07-30 16:13:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:13:47 --> Config Class Initialized
INFO - 2023-07-30 16:13:47 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:13:47 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:13:47 --> Utf8 Class Initialized
INFO - 2023-07-30 16:13:47 --> URI Class Initialized
DEBUG - 2023-07-30 16:13:47 --> No URI present. Default controller set.
INFO - 2023-07-30 16:13:47 --> Router Class Initialized
INFO - 2023-07-30 16:13:47 --> Output Class Initialized
INFO - 2023-07-30 16:13:47 --> Security Class Initialized
DEBUG - 2023-07-30 16:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:13:47 --> Input Class Initialized
INFO - 2023-07-30 16:13:47 --> Language Class Initialized
INFO - 2023-07-30 16:13:47 --> Loader Class Initialized
INFO - 2023-07-30 16:13:47 --> Helper loaded: url_helper
INFO - 2023-07-30 16:13:47 --> Helper loaded: file_helper
INFO - 2023-07-30 16:13:47 --> Helper loaded: html_helper
INFO - 2023-07-30 16:13:47 --> Helper loaded: text_helper
INFO - 2023-07-30 16:13:47 --> Helper loaded: form_helper
INFO - 2023-07-30 16:13:47 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:13:47 --> Helper loaded: security_helper
INFO - 2023-07-30 16:13:47 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:13:47 --> Database Driver Class Initialized
INFO - 2023-07-30 16:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:13:47 --> Parser Class Initialized
INFO - 2023-07-30 16:13:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:13:47 --> Pagination Class Initialized
INFO - 2023-07-30 16:13:47 --> Form Validation Class Initialized
INFO - 2023-07-30 16:13:47 --> Controller Class Initialized
INFO - 2023-07-30 16:13:47 --> Model Class Initialized
DEBUG - 2023-07-30 16:13:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:13:47 --> Model Class Initialized
DEBUG - 2023-07-30 16:13:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:13:47 --> Model Class Initialized
INFO - 2023-07-30 16:13:47 --> Model Class Initialized
INFO - 2023-07-30 16:13:47 --> Model Class Initialized
INFO - 2023-07-30 16:13:47 --> Model Class Initialized
DEBUG - 2023-07-30 16:13:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:13:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:13:47 --> Model Class Initialized
INFO - 2023-07-30 16:13:47 --> Model Class Initialized
INFO - 2023-07-30 16:13:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-30 16:13:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:13:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:13:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:13:47 --> Model Class Initialized
INFO - 2023-07-30 16:13:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:13:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:13:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:13:47 --> Final output sent to browser
DEBUG - 2023-07-30 16:13:47 --> Total execution time: 0.0930
ERROR - 2023-07-30 16:14:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:14:27 --> Config Class Initialized
INFO - 2023-07-30 16:14:27 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:14:27 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:14:27 --> Utf8 Class Initialized
INFO - 2023-07-30 16:14:27 --> URI Class Initialized
INFO - 2023-07-30 16:14:27 --> Router Class Initialized
INFO - 2023-07-30 16:14:27 --> Output Class Initialized
INFO - 2023-07-30 16:14:27 --> Security Class Initialized
DEBUG - 2023-07-30 16:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:14:27 --> Input Class Initialized
INFO - 2023-07-30 16:14:27 --> Language Class Initialized
INFO - 2023-07-30 16:14:27 --> Loader Class Initialized
INFO - 2023-07-30 16:14:27 --> Helper loaded: url_helper
INFO - 2023-07-30 16:14:27 --> Helper loaded: file_helper
INFO - 2023-07-30 16:14:27 --> Helper loaded: html_helper
INFO - 2023-07-30 16:14:27 --> Helper loaded: text_helper
INFO - 2023-07-30 16:14:27 --> Helper loaded: form_helper
INFO - 2023-07-30 16:14:27 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:14:27 --> Helper loaded: security_helper
INFO - 2023-07-30 16:14:27 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:14:27 --> Database Driver Class Initialized
INFO - 2023-07-30 16:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:14:27 --> Parser Class Initialized
INFO - 2023-07-30 16:14:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:14:27 --> Pagination Class Initialized
INFO - 2023-07-30 16:14:27 --> Form Validation Class Initialized
INFO - 2023-07-30 16:14:27 --> Controller Class Initialized
INFO - 2023-07-30 16:14:27 --> Model Class Initialized
DEBUG - 2023-07-30 16:14:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:14:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:14:27 --> Model Class Initialized
DEBUG - 2023-07-30 16:14:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:14:27 --> Model Class Initialized
INFO - 2023-07-30 16:14:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-30 16:14:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:14:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:14:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:14:27 --> Model Class Initialized
INFO - 2023-07-30 16:14:28 --> Model Class Initialized
INFO - 2023-07-30 16:14:28 --> Model Class Initialized
INFO - 2023-07-30 16:14:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:14:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:14:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:14:28 --> Final output sent to browser
DEBUG - 2023-07-30 16:14:28 --> Total execution time: 0.0974
ERROR - 2023-07-30 16:14:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:14:28 --> Config Class Initialized
INFO - 2023-07-30 16:14:28 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:14:28 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:14:28 --> Utf8 Class Initialized
INFO - 2023-07-30 16:14:28 --> URI Class Initialized
INFO - 2023-07-30 16:14:28 --> Router Class Initialized
INFO - 2023-07-30 16:14:28 --> Output Class Initialized
INFO - 2023-07-30 16:14:28 --> Security Class Initialized
DEBUG - 2023-07-30 16:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:14:28 --> Input Class Initialized
INFO - 2023-07-30 16:14:28 --> Language Class Initialized
INFO - 2023-07-30 16:14:28 --> Loader Class Initialized
INFO - 2023-07-30 16:14:28 --> Helper loaded: url_helper
INFO - 2023-07-30 16:14:28 --> Helper loaded: file_helper
INFO - 2023-07-30 16:14:28 --> Helper loaded: html_helper
INFO - 2023-07-30 16:14:28 --> Helper loaded: text_helper
INFO - 2023-07-30 16:14:28 --> Helper loaded: form_helper
INFO - 2023-07-30 16:14:28 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:14:28 --> Helper loaded: security_helper
INFO - 2023-07-30 16:14:28 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:14:28 --> Database Driver Class Initialized
INFO - 2023-07-30 16:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:14:28 --> Parser Class Initialized
INFO - 2023-07-30 16:14:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:14:28 --> Pagination Class Initialized
INFO - 2023-07-30 16:14:28 --> Form Validation Class Initialized
INFO - 2023-07-30 16:14:28 --> Controller Class Initialized
INFO - 2023-07-30 16:14:28 --> Model Class Initialized
DEBUG - 2023-07-30 16:14:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:14:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:14:28 --> Model Class Initialized
DEBUG - 2023-07-30 16:14:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:14:28 --> Model Class Initialized
INFO - 2023-07-30 16:14:28 --> Final output sent to browser
DEBUG - 2023-07-30 16:14:28 --> Total execution time: 0.0423
ERROR - 2023-07-30 16:14:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:14:33 --> Config Class Initialized
INFO - 2023-07-30 16:14:33 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:14:33 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:14:33 --> Utf8 Class Initialized
INFO - 2023-07-30 16:14:33 --> URI Class Initialized
INFO - 2023-07-30 16:14:33 --> Router Class Initialized
INFO - 2023-07-30 16:14:33 --> Output Class Initialized
INFO - 2023-07-30 16:14:33 --> Security Class Initialized
DEBUG - 2023-07-30 16:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:14:33 --> Input Class Initialized
INFO - 2023-07-30 16:14:33 --> Language Class Initialized
INFO - 2023-07-30 16:14:33 --> Loader Class Initialized
INFO - 2023-07-30 16:14:33 --> Helper loaded: url_helper
INFO - 2023-07-30 16:14:33 --> Helper loaded: file_helper
INFO - 2023-07-30 16:14:33 --> Helper loaded: html_helper
INFO - 2023-07-30 16:14:33 --> Helper loaded: text_helper
INFO - 2023-07-30 16:14:33 --> Helper loaded: form_helper
INFO - 2023-07-30 16:14:33 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:14:33 --> Helper loaded: security_helper
INFO - 2023-07-30 16:14:33 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:14:33 --> Database Driver Class Initialized
INFO - 2023-07-30 16:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:14:33 --> Parser Class Initialized
INFO - 2023-07-30 16:14:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:14:33 --> Pagination Class Initialized
INFO - 2023-07-30 16:14:33 --> Form Validation Class Initialized
INFO - 2023-07-30 16:14:33 --> Controller Class Initialized
INFO - 2023-07-30 16:14:33 --> Model Class Initialized
DEBUG - 2023-07-30 16:14:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:14:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:14:33 --> Model Class Initialized
DEBUG - 2023-07-30 16:14:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:14:33 --> Model Class Initialized
INFO - 2023-07-30 16:14:33 --> Final output sent to browser
DEBUG - 2023-07-30 16:14:33 --> Total execution time: 0.1489
ERROR - 2023-07-30 16:15:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:15:06 --> Config Class Initialized
INFO - 2023-07-30 16:15:06 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:15:06 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:15:06 --> Utf8 Class Initialized
INFO - 2023-07-30 16:15:06 --> URI Class Initialized
DEBUG - 2023-07-30 16:15:06 --> No URI present. Default controller set.
INFO - 2023-07-30 16:15:06 --> Router Class Initialized
INFO - 2023-07-30 16:15:06 --> Output Class Initialized
INFO - 2023-07-30 16:15:06 --> Security Class Initialized
DEBUG - 2023-07-30 16:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:15:06 --> Input Class Initialized
INFO - 2023-07-30 16:15:06 --> Language Class Initialized
INFO - 2023-07-30 16:15:06 --> Loader Class Initialized
INFO - 2023-07-30 16:15:06 --> Helper loaded: url_helper
INFO - 2023-07-30 16:15:06 --> Helper loaded: file_helper
INFO - 2023-07-30 16:15:06 --> Helper loaded: html_helper
INFO - 2023-07-30 16:15:06 --> Helper loaded: text_helper
INFO - 2023-07-30 16:15:06 --> Helper loaded: form_helper
INFO - 2023-07-30 16:15:06 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:15:06 --> Helper loaded: security_helper
INFO - 2023-07-30 16:15:06 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:15:06 --> Database Driver Class Initialized
INFO - 2023-07-30 16:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:15:06 --> Parser Class Initialized
INFO - 2023-07-30 16:15:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:15:06 --> Pagination Class Initialized
INFO - 2023-07-30 16:15:06 --> Form Validation Class Initialized
INFO - 2023-07-30 16:15:06 --> Controller Class Initialized
INFO - 2023-07-30 16:15:06 --> Model Class Initialized
DEBUG - 2023-07-30 16:15:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-30 16:15:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:15:07 --> Config Class Initialized
INFO - 2023-07-30 16:15:07 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:15:07 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:15:07 --> Utf8 Class Initialized
INFO - 2023-07-30 16:15:07 --> URI Class Initialized
DEBUG - 2023-07-30 16:15:07 --> No URI present. Default controller set.
INFO - 2023-07-30 16:15:07 --> Router Class Initialized
INFO - 2023-07-30 16:15:07 --> Output Class Initialized
INFO - 2023-07-30 16:15:07 --> Security Class Initialized
DEBUG - 2023-07-30 16:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:15:07 --> Input Class Initialized
INFO - 2023-07-30 16:15:07 --> Language Class Initialized
INFO - 2023-07-30 16:15:07 --> Loader Class Initialized
INFO - 2023-07-30 16:15:07 --> Helper loaded: url_helper
INFO - 2023-07-30 16:15:07 --> Helper loaded: file_helper
INFO - 2023-07-30 16:15:07 --> Helper loaded: html_helper
INFO - 2023-07-30 16:15:07 --> Helper loaded: text_helper
INFO - 2023-07-30 16:15:07 --> Helper loaded: form_helper
INFO - 2023-07-30 16:15:07 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:15:07 --> Helper loaded: security_helper
INFO - 2023-07-30 16:15:07 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:15:07 --> Database Driver Class Initialized
INFO - 2023-07-30 16:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:15:07 --> Parser Class Initialized
INFO - 2023-07-30 16:15:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:15:07 --> Pagination Class Initialized
INFO - 2023-07-30 16:15:07 --> Form Validation Class Initialized
INFO - 2023-07-30 16:15:07 --> Controller Class Initialized
INFO - 2023-07-30 16:15:07 --> Model Class Initialized
DEBUG - 2023-07-30 16:15:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-30 16:15:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:15:07 --> Config Class Initialized
INFO - 2023-07-30 16:15:07 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:15:07 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:15:07 --> Utf8 Class Initialized
INFO - 2023-07-30 16:15:07 --> URI Class Initialized
INFO - 2023-07-30 16:15:07 --> Router Class Initialized
INFO - 2023-07-30 16:15:07 --> Output Class Initialized
INFO - 2023-07-30 16:15:07 --> Security Class Initialized
DEBUG - 2023-07-30 16:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:15:07 --> Input Class Initialized
INFO - 2023-07-30 16:15:07 --> Language Class Initialized
INFO - 2023-07-30 16:15:07 --> Loader Class Initialized
INFO - 2023-07-30 16:15:07 --> Helper loaded: url_helper
INFO - 2023-07-30 16:15:07 --> Helper loaded: file_helper
INFO - 2023-07-30 16:15:07 --> Helper loaded: html_helper
INFO - 2023-07-30 16:15:07 --> Helper loaded: text_helper
INFO - 2023-07-30 16:15:07 --> Helper loaded: form_helper
INFO - 2023-07-30 16:15:07 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:15:07 --> Helper loaded: security_helper
INFO - 2023-07-30 16:15:07 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:15:07 --> Database Driver Class Initialized
INFO - 2023-07-30 16:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:15:07 --> Parser Class Initialized
INFO - 2023-07-30 16:15:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:15:07 --> Pagination Class Initialized
INFO - 2023-07-30 16:15:07 --> Form Validation Class Initialized
INFO - 2023-07-30 16:15:07 --> Controller Class Initialized
INFO - 2023-07-30 16:15:07 --> Model Class Initialized
DEBUG - 2023-07-30 16:15:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:15:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-30 16:15:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:15:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:15:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:15:07 --> Model Class Initialized
INFO - 2023-07-30 16:15:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:15:07 --> Final output sent to browser
DEBUG - 2023-07-30 16:15:07 --> Total execution time: 0.0296
ERROR - 2023-07-30 16:15:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:15:10 --> Config Class Initialized
INFO - 2023-07-30 16:15:10 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:15:10 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:15:10 --> Utf8 Class Initialized
INFO - 2023-07-30 16:15:10 --> URI Class Initialized
INFO - 2023-07-30 16:15:10 --> Router Class Initialized
INFO - 2023-07-30 16:15:10 --> Output Class Initialized
INFO - 2023-07-30 16:15:10 --> Security Class Initialized
DEBUG - 2023-07-30 16:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:15:10 --> Input Class Initialized
INFO - 2023-07-30 16:15:10 --> Language Class Initialized
INFO - 2023-07-30 16:15:10 --> Loader Class Initialized
INFO - 2023-07-30 16:15:10 --> Helper loaded: url_helper
INFO - 2023-07-30 16:15:10 --> Helper loaded: file_helper
INFO - 2023-07-30 16:15:10 --> Helper loaded: html_helper
INFO - 2023-07-30 16:15:10 --> Helper loaded: text_helper
INFO - 2023-07-30 16:15:10 --> Helper loaded: form_helper
INFO - 2023-07-30 16:15:10 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:15:10 --> Helper loaded: security_helper
INFO - 2023-07-30 16:15:10 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:15:10 --> Database Driver Class Initialized
INFO - 2023-07-30 16:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:15:10 --> Parser Class Initialized
INFO - 2023-07-30 16:15:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:15:10 --> Pagination Class Initialized
INFO - 2023-07-30 16:15:10 --> Form Validation Class Initialized
INFO - 2023-07-30 16:15:10 --> Controller Class Initialized
INFO - 2023-07-30 16:15:10 --> Model Class Initialized
DEBUG - 2023-07-30 16:15:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:15:10 --> Model Class Initialized
INFO - 2023-07-30 16:15:10 --> Final output sent to browser
DEBUG - 2023-07-30 16:15:10 --> Total execution time: 0.0193
ERROR - 2023-07-30 16:15:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:15:11 --> Config Class Initialized
INFO - 2023-07-30 16:15:11 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:15:11 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:15:11 --> Utf8 Class Initialized
INFO - 2023-07-30 16:15:11 --> URI Class Initialized
DEBUG - 2023-07-30 16:15:11 --> No URI present. Default controller set.
INFO - 2023-07-30 16:15:11 --> Router Class Initialized
INFO - 2023-07-30 16:15:11 --> Output Class Initialized
INFO - 2023-07-30 16:15:11 --> Security Class Initialized
DEBUG - 2023-07-30 16:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:15:11 --> Input Class Initialized
INFO - 2023-07-30 16:15:11 --> Language Class Initialized
INFO - 2023-07-30 16:15:11 --> Loader Class Initialized
INFO - 2023-07-30 16:15:11 --> Helper loaded: url_helper
INFO - 2023-07-30 16:15:11 --> Helper loaded: file_helper
INFO - 2023-07-30 16:15:11 --> Helper loaded: html_helper
INFO - 2023-07-30 16:15:11 --> Helper loaded: text_helper
INFO - 2023-07-30 16:15:11 --> Helper loaded: form_helper
INFO - 2023-07-30 16:15:11 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:15:11 --> Helper loaded: security_helper
INFO - 2023-07-30 16:15:11 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:15:11 --> Database Driver Class Initialized
INFO - 2023-07-30 16:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:15:11 --> Parser Class Initialized
INFO - 2023-07-30 16:15:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:15:11 --> Pagination Class Initialized
INFO - 2023-07-30 16:15:11 --> Form Validation Class Initialized
INFO - 2023-07-30 16:15:11 --> Controller Class Initialized
INFO - 2023-07-30 16:15:11 --> Model Class Initialized
DEBUG - 2023-07-30 16:15:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:15:11 --> Model Class Initialized
DEBUG - 2023-07-30 16:15:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:15:11 --> Model Class Initialized
INFO - 2023-07-30 16:15:11 --> Model Class Initialized
INFO - 2023-07-30 16:15:11 --> Model Class Initialized
INFO - 2023-07-30 16:15:11 --> Model Class Initialized
DEBUG - 2023-07-30 16:15:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:15:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:15:11 --> Model Class Initialized
INFO - 2023-07-30 16:15:11 --> Model Class Initialized
INFO - 2023-07-30 16:15:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-30 16:15:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:15:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:15:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:15:11 --> Model Class Initialized
INFO - 2023-07-30 16:15:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:15:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:15:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:15:11 --> Final output sent to browser
DEBUG - 2023-07-30 16:15:11 --> Total execution time: 0.1904
ERROR - 2023-07-30 16:15:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:15:12 --> Config Class Initialized
INFO - 2023-07-30 16:15:12 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:15:12 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:15:12 --> Utf8 Class Initialized
INFO - 2023-07-30 16:15:12 --> URI Class Initialized
INFO - 2023-07-30 16:15:12 --> Router Class Initialized
INFO - 2023-07-30 16:15:12 --> Output Class Initialized
INFO - 2023-07-30 16:15:12 --> Security Class Initialized
DEBUG - 2023-07-30 16:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:15:12 --> Input Class Initialized
INFO - 2023-07-30 16:15:12 --> Language Class Initialized
INFO - 2023-07-30 16:15:12 --> Loader Class Initialized
INFO - 2023-07-30 16:15:12 --> Helper loaded: url_helper
INFO - 2023-07-30 16:15:12 --> Helper loaded: file_helper
INFO - 2023-07-30 16:15:12 --> Helper loaded: html_helper
INFO - 2023-07-30 16:15:12 --> Helper loaded: text_helper
INFO - 2023-07-30 16:15:12 --> Helper loaded: form_helper
INFO - 2023-07-30 16:15:12 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:15:12 --> Helper loaded: security_helper
INFO - 2023-07-30 16:15:12 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:15:12 --> Database Driver Class Initialized
INFO - 2023-07-30 16:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:15:12 --> Parser Class Initialized
INFO - 2023-07-30 16:15:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:15:12 --> Pagination Class Initialized
INFO - 2023-07-30 16:15:12 --> Form Validation Class Initialized
INFO - 2023-07-30 16:15:12 --> Controller Class Initialized
DEBUG - 2023-07-30 16:15:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:15:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:15:12 --> Model Class Initialized
INFO - 2023-07-30 16:15:12 --> Final output sent to browser
DEBUG - 2023-07-30 16:15:12 --> Total execution time: 0.0143
ERROR - 2023-07-30 16:15:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:15:20 --> Config Class Initialized
INFO - 2023-07-30 16:15:20 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:15:20 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:15:20 --> Utf8 Class Initialized
INFO - 2023-07-30 16:15:20 --> URI Class Initialized
INFO - 2023-07-30 16:15:20 --> Router Class Initialized
INFO - 2023-07-30 16:15:20 --> Output Class Initialized
INFO - 2023-07-30 16:15:20 --> Security Class Initialized
DEBUG - 2023-07-30 16:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:15:20 --> Input Class Initialized
INFO - 2023-07-30 16:15:20 --> Language Class Initialized
INFO - 2023-07-30 16:15:20 --> Loader Class Initialized
INFO - 2023-07-30 16:15:20 --> Helper loaded: url_helper
INFO - 2023-07-30 16:15:20 --> Helper loaded: file_helper
INFO - 2023-07-30 16:15:20 --> Helper loaded: html_helper
INFO - 2023-07-30 16:15:20 --> Helper loaded: text_helper
INFO - 2023-07-30 16:15:20 --> Helper loaded: form_helper
INFO - 2023-07-30 16:15:20 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:15:20 --> Helper loaded: security_helper
INFO - 2023-07-30 16:15:20 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:15:20 --> Database Driver Class Initialized
INFO - 2023-07-30 16:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:15:20 --> Parser Class Initialized
INFO - 2023-07-30 16:15:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:15:20 --> Pagination Class Initialized
INFO - 2023-07-30 16:15:20 --> Form Validation Class Initialized
INFO - 2023-07-30 16:15:20 --> Controller Class Initialized
DEBUG - 2023-07-30 16:15:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:15:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:15:20 --> Model Class Initialized
DEBUG - 2023-07-30 16:15:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:15:20 --> Model Class Initialized
DEBUG - 2023-07-30 16:15:20 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:15:20 --> Model Class Initialized
INFO - 2023-07-30 16:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-07-30 16:15:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:15:20 --> Model Class Initialized
INFO - 2023-07-30 16:15:20 --> Model Class Initialized
INFO - 2023-07-30 16:15:20 --> Model Class Initialized
INFO - 2023-07-30 16:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:15:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:15:20 --> Final output sent to browser
DEBUG - 2023-07-30 16:15:20 --> Total execution time: 0.1296
ERROR - 2023-07-30 16:15:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:15:21 --> Config Class Initialized
INFO - 2023-07-30 16:15:21 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:15:21 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:15:21 --> Utf8 Class Initialized
INFO - 2023-07-30 16:15:21 --> URI Class Initialized
INFO - 2023-07-30 16:15:21 --> Router Class Initialized
INFO - 2023-07-30 16:15:21 --> Output Class Initialized
INFO - 2023-07-30 16:15:21 --> Security Class Initialized
DEBUG - 2023-07-30 16:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:15:21 --> Input Class Initialized
INFO - 2023-07-30 16:15:21 --> Language Class Initialized
INFO - 2023-07-30 16:15:21 --> Loader Class Initialized
INFO - 2023-07-30 16:15:21 --> Helper loaded: url_helper
INFO - 2023-07-30 16:15:21 --> Helper loaded: file_helper
INFO - 2023-07-30 16:15:21 --> Helper loaded: html_helper
INFO - 2023-07-30 16:15:21 --> Helper loaded: text_helper
INFO - 2023-07-30 16:15:21 --> Helper loaded: form_helper
INFO - 2023-07-30 16:15:21 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:15:21 --> Helper loaded: security_helper
INFO - 2023-07-30 16:15:21 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:15:21 --> Database Driver Class Initialized
INFO - 2023-07-30 16:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:15:21 --> Parser Class Initialized
INFO - 2023-07-30 16:15:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:15:21 --> Pagination Class Initialized
INFO - 2023-07-30 16:15:21 --> Form Validation Class Initialized
INFO - 2023-07-30 16:15:21 --> Controller Class Initialized
DEBUG - 2023-07-30 16:15:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:15:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:15:21 --> Model Class Initialized
DEBUG - 2023-07-30 16:15:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:15:21 --> Model Class Initialized
INFO - 2023-07-30 16:15:21 --> Final output sent to browser
DEBUG - 2023-07-30 16:15:21 --> Total execution time: 0.0305
ERROR - 2023-07-30 16:15:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:15:31 --> Config Class Initialized
INFO - 2023-07-30 16:15:31 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:15:31 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:15:31 --> Utf8 Class Initialized
INFO - 2023-07-30 16:15:31 --> URI Class Initialized
INFO - 2023-07-30 16:15:31 --> Router Class Initialized
INFO - 2023-07-30 16:15:31 --> Output Class Initialized
INFO - 2023-07-30 16:15:31 --> Security Class Initialized
DEBUG - 2023-07-30 16:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:15:31 --> Input Class Initialized
INFO - 2023-07-30 16:15:31 --> Language Class Initialized
INFO - 2023-07-30 16:15:31 --> Loader Class Initialized
INFO - 2023-07-30 16:15:31 --> Helper loaded: url_helper
INFO - 2023-07-30 16:15:31 --> Helper loaded: file_helper
INFO - 2023-07-30 16:15:31 --> Helper loaded: html_helper
INFO - 2023-07-30 16:15:31 --> Helper loaded: text_helper
INFO - 2023-07-30 16:15:31 --> Helper loaded: form_helper
INFO - 2023-07-30 16:15:31 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:15:31 --> Helper loaded: security_helper
INFO - 2023-07-30 16:15:31 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:15:31 --> Database Driver Class Initialized
INFO - 2023-07-30 16:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:15:31 --> Parser Class Initialized
INFO - 2023-07-30 16:15:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:15:31 --> Pagination Class Initialized
INFO - 2023-07-30 16:15:31 --> Form Validation Class Initialized
INFO - 2023-07-30 16:15:31 --> Controller Class Initialized
DEBUG - 2023-07-30 16:15:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:15:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:15:31 --> Model Class Initialized
DEBUG - 2023-07-30 16:15:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:15:31 --> Model Class Initialized
INFO - 2023-07-30 16:15:32 --> Final output sent to browser
DEBUG - 2023-07-30 16:15:32 --> Total execution time: 0.1158
ERROR - 2023-07-30 16:16:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:16:40 --> Config Class Initialized
INFO - 2023-07-30 16:16:40 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:16:40 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:16:40 --> Utf8 Class Initialized
INFO - 2023-07-30 16:16:40 --> URI Class Initialized
DEBUG - 2023-07-30 16:16:40 --> No URI present. Default controller set.
INFO - 2023-07-30 16:16:40 --> Router Class Initialized
INFO - 2023-07-30 16:16:40 --> Output Class Initialized
INFO - 2023-07-30 16:16:40 --> Security Class Initialized
DEBUG - 2023-07-30 16:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:16:40 --> Input Class Initialized
INFO - 2023-07-30 16:16:40 --> Language Class Initialized
INFO - 2023-07-30 16:16:40 --> Loader Class Initialized
INFO - 2023-07-30 16:16:40 --> Helper loaded: url_helper
INFO - 2023-07-30 16:16:40 --> Helper loaded: file_helper
INFO - 2023-07-30 16:16:40 --> Helper loaded: html_helper
INFO - 2023-07-30 16:16:40 --> Helper loaded: text_helper
INFO - 2023-07-30 16:16:40 --> Helper loaded: form_helper
INFO - 2023-07-30 16:16:40 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:16:40 --> Helper loaded: security_helper
INFO - 2023-07-30 16:16:40 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:16:40 --> Database Driver Class Initialized
INFO - 2023-07-30 16:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:16:40 --> Parser Class Initialized
INFO - 2023-07-30 16:16:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:16:40 --> Pagination Class Initialized
INFO - 2023-07-30 16:16:40 --> Form Validation Class Initialized
INFO - 2023-07-30 16:16:40 --> Controller Class Initialized
INFO - 2023-07-30 16:16:40 --> Model Class Initialized
DEBUG - 2023-07-30 16:16:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:16:40 --> Model Class Initialized
DEBUG - 2023-07-30 16:16:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:16:40 --> Model Class Initialized
INFO - 2023-07-30 16:16:40 --> Model Class Initialized
INFO - 2023-07-30 16:16:40 --> Model Class Initialized
INFO - 2023-07-30 16:16:40 --> Model Class Initialized
DEBUG - 2023-07-30 16:16:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:16:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:16:40 --> Model Class Initialized
INFO - 2023-07-30 16:16:40 --> Model Class Initialized
INFO - 2023-07-30 16:16:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-30 16:16:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:16:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:16:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:16:41 --> Model Class Initialized
INFO - 2023-07-30 16:16:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:16:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:16:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:16:41 --> Final output sent to browser
DEBUG - 2023-07-30 16:16:41 --> Total execution time: 0.1834
ERROR - 2023-07-30 16:17:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:17:43 --> Config Class Initialized
INFO - 2023-07-30 16:17:43 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:17:43 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:17:43 --> Utf8 Class Initialized
INFO - 2023-07-30 16:17:43 --> URI Class Initialized
INFO - 2023-07-30 16:17:43 --> Router Class Initialized
INFO - 2023-07-30 16:17:43 --> Output Class Initialized
INFO - 2023-07-30 16:17:43 --> Security Class Initialized
DEBUG - 2023-07-30 16:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:17:43 --> Input Class Initialized
INFO - 2023-07-30 16:17:43 --> Language Class Initialized
INFO - 2023-07-30 16:17:43 --> Loader Class Initialized
INFO - 2023-07-30 16:17:43 --> Helper loaded: url_helper
INFO - 2023-07-30 16:17:43 --> Helper loaded: file_helper
INFO - 2023-07-30 16:17:43 --> Helper loaded: html_helper
INFO - 2023-07-30 16:17:43 --> Helper loaded: text_helper
INFO - 2023-07-30 16:17:43 --> Helper loaded: form_helper
INFO - 2023-07-30 16:17:43 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:17:43 --> Helper loaded: security_helper
INFO - 2023-07-30 16:17:43 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:17:43 --> Database Driver Class Initialized
INFO - 2023-07-30 16:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:17:43 --> Parser Class Initialized
INFO - 2023-07-30 16:17:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:17:43 --> Pagination Class Initialized
INFO - 2023-07-30 16:17:43 --> Form Validation Class Initialized
INFO - 2023-07-30 16:17:43 --> Controller Class Initialized
INFO - 2023-07-30 16:17:43 --> Model Class Initialized
INFO - 2023-07-30 16:17:43 --> Model Class Initialized
INFO - 2023-07-30 16:17:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report.php
DEBUG - 2023-07-30 16:17:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:17:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:17:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:17:43 --> Model Class Initialized
INFO - 2023-07-30 16:17:43 --> Model Class Initialized
INFO - 2023-07-30 16:17:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:17:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:17:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:17:43 --> Final output sent to browser
DEBUG - 2023-07-30 16:17:43 --> Total execution time: 0.1561
ERROR - 2023-07-30 16:17:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:17:43 --> Config Class Initialized
INFO - 2023-07-30 16:17:43 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:17:43 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:17:43 --> Utf8 Class Initialized
INFO - 2023-07-30 16:17:43 --> URI Class Initialized
INFO - 2023-07-30 16:17:43 --> Router Class Initialized
INFO - 2023-07-30 16:17:43 --> Output Class Initialized
INFO - 2023-07-30 16:17:43 --> Security Class Initialized
DEBUG - 2023-07-30 16:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:17:43 --> Input Class Initialized
INFO - 2023-07-30 16:17:43 --> Language Class Initialized
INFO - 2023-07-30 16:17:43 --> Loader Class Initialized
INFO - 2023-07-30 16:17:43 --> Helper loaded: url_helper
INFO - 2023-07-30 16:17:43 --> Helper loaded: file_helper
INFO - 2023-07-30 16:17:43 --> Helper loaded: html_helper
INFO - 2023-07-30 16:17:43 --> Helper loaded: text_helper
INFO - 2023-07-30 16:17:43 --> Helper loaded: form_helper
INFO - 2023-07-30 16:17:43 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:17:43 --> Helper loaded: security_helper
INFO - 2023-07-30 16:17:43 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:17:44 --> Database Driver Class Initialized
INFO - 2023-07-30 16:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:17:44 --> Parser Class Initialized
INFO - 2023-07-30 16:17:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:17:44 --> Pagination Class Initialized
INFO - 2023-07-30 16:17:44 --> Form Validation Class Initialized
INFO - 2023-07-30 16:17:44 --> Controller Class Initialized
INFO - 2023-07-30 16:17:44 --> Model Class Initialized
INFO - 2023-07-30 16:17:44 --> Model Class Initialized
INFO - 2023-07-30 16:17:44 --> Final output sent to browser
DEBUG - 2023-07-30 16:17:44 --> Total execution time: 0.0232
ERROR - 2023-07-30 16:17:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:17:52 --> Config Class Initialized
INFO - 2023-07-30 16:17:52 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:17:52 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:17:52 --> Utf8 Class Initialized
INFO - 2023-07-30 16:17:52 --> URI Class Initialized
INFO - 2023-07-30 16:17:52 --> Router Class Initialized
INFO - 2023-07-30 16:17:52 --> Output Class Initialized
INFO - 2023-07-30 16:17:52 --> Security Class Initialized
DEBUG - 2023-07-30 16:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:17:52 --> Input Class Initialized
INFO - 2023-07-30 16:17:52 --> Language Class Initialized
INFO - 2023-07-30 16:17:52 --> Loader Class Initialized
INFO - 2023-07-30 16:17:52 --> Helper loaded: url_helper
INFO - 2023-07-30 16:17:52 --> Helper loaded: file_helper
INFO - 2023-07-30 16:17:52 --> Helper loaded: html_helper
INFO - 2023-07-30 16:17:52 --> Helper loaded: text_helper
INFO - 2023-07-30 16:17:52 --> Helper loaded: form_helper
INFO - 2023-07-30 16:17:52 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:17:52 --> Helper loaded: security_helper
INFO - 2023-07-30 16:17:52 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:17:52 --> Database Driver Class Initialized
INFO - 2023-07-30 16:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:17:52 --> Parser Class Initialized
INFO - 2023-07-30 16:17:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:17:52 --> Pagination Class Initialized
INFO - 2023-07-30 16:17:52 --> Form Validation Class Initialized
INFO - 2023-07-30 16:17:52 --> Controller Class Initialized
INFO - 2023-07-30 16:17:52 --> Model Class Initialized
INFO - 2023-07-30 16:17:52 --> Model Class Initialized
INFO - 2023-07-30 16:17:52 --> Final output sent to browser
DEBUG - 2023-07-30 16:17:52 --> Total execution time: 0.0323
ERROR - 2023-07-30 16:18:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:18:40 --> Config Class Initialized
INFO - 2023-07-30 16:18:40 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:18:40 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:18:40 --> Utf8 Class Initialized
INFO - 2023-07-30 16:18:40 --> URI Class Initialized
INFO - 2023-07-30 16:18:40 --> Router Class Initialized
INFO - 2023-07-30 16:18:40 --> Output Class Initialized
INFO - 2023-07-30 16:18:40 --> Security Class Initialized
DEBUG - 2023-07-30 16:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:18:40 --> Input Class Initialized
INFO - 2023-07-30 16:18:40 --> Language Class Initialized
INFO - 2023-07-30 16:18:40 --> Loader Class Initialized
INFO - 2023-07-30 16:18:40 --> Helper loaded: url_helper
INFO - 2023-07-30 16:18:40 --> Helper loaded: file_helper
INFO - 2023-07-30 16:18:40 --> Helper loaded: html_helper
INFO - 2023-07-30 16:18:40 --> Helper loaded: text_helper
INFO - 2023-07-30 16:18:40 --> Helper loaded: form_helper
INFO - 2023-07-30 16:18:40 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:18:40 --> Helper loaded: security_helper
INFO - 2023-07-30 16:18:40 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:18:40 --> Database Driver Class Initialized
INFO - 2023-07-30 16:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:18:40 --> Parser Class Initialized
INFO - 2023-07-30 16:18:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:18:40 --> Pagination Class Initialized
INFO - 2023-07-30 16:18:40 --> Form Validation Class Initialized
INFO - 2023-07-30 16:18:40 --> Controller Class Initialized
DEBUG - 2023-07-30 16:18:40 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:18:40 --> Model Class Initialized
INFO - 2023-07-30 16:18:40 --> Model Class Initialized
INFO - 2023-07-30 16:18:40 --> Model Class Initialized
INFO - 2023-07-30 16:18:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-07-30 16:18:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:18:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:18:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:18:40 --> Model Class Initialized
INFO - 2023-07-30 16:18:40 --> Model Class Initialized
INFO - 2023-07-30 16:18:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:18:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:18:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:18:40 --> Final output sent to browser
DEBUG - 2023-07-30 16:18:40 --> Total execution time: 0.1900
ERROR - 2023-07-30 16:19:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:19:25 --> Config Class Initialized
INFO - 2023-07-30 16:19:25 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:19:25 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:19:25 --> Utf8 Class Initialized
INFO - 2023-07-30 16:19:25 --> URI Class Initialized
INFO - 2023-07-30 16:19:25 --> Router Class Initialized
INFO - 2023-07-30 16:19:25 --> Output Class Initialized
INFO - 2023-07-30 16:19:25 --> Security Class Initialized
DEBUG - 2023-07-30 16:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:19:25 --> Input Class Initialized
INFO - 2023-07-30 16:19:25 --> Language Class Initialized
INFO - 2023-07-30 16:19:25 --> Loader Class Initialized
INFO - 2023-07-30 16:19:25 --> Helper loaded: url_helper
INFO - 2023-07-30 16:19:25 --> Helper loaded: file_helper
INFO - 2023-07-30 16:19:25 --> Helper loaded: html_helper
INFO - 2023-07-30 16:19:25 --> Helper loaded: text_helper
INFO - 2023-07-30 16:19:25 --> Helper loaded: form_helper
INFO - 2023-07-30 16:19:25 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:19:25 --> Helper loaded: security_helper
INFO - 2023-07-30 16:19:25 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:19:25 --> Database Driver Class Initialized
INFO - 2023-07-30 16:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:19:25 --> Parser Class Initialized
INFO - 2023-07-30 16:19:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:19:25 --> Pagination Class Initialized
INFO - 2023-07-30 16:19:25 --> Form Validation Class Initialized
INFO - 2023-07-30 16:19:25 --> Controller Class Initialized
INFO - 2023-07-30 16:19:25 --> Model Class Initialized
DEBUG - 2023-07-30 16:19:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:19:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:19:25 --> Model Class Initialized
DEBUG - 2023-07-30 16:19:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:19:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-07-30 16:19:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:19:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:19:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:19:25 --> Model Class Initialized
INFO - 2023-07-30 16:19:25 --> Model Class Initialized
INFO - 2023-07-30 16:19:25 --> Model Class Initialized
INFO - 2023-07-30 16:19:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:19:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:19:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:19:25 --> Final output sent to browser
DEBUG - 2023-07-30 16:19:25 --> Total execution time: 0.1368
ERROR - 2023-07-30 16:19:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:19:33 --> Config Class Initialized
INFO - 2023-07-30 16:19:33 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:19:33 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:19:33 --> Utf8 Class Initialized
INFO - 2023-07-30 16:19:33 --> URI Class Initialized
INFO - 2023-07-30 16:19:33 --> Router Class Initialized
INFO - 2023-07-30 16:19:33 --> Output Class Initialized
INFO - 2023-07-30 16:19:33 --> Security Class Initialized
DEBUG - 2023-07-30 16:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:19:33 --> Input Class Initialized
INFO - 2023-07-30 16:19:33 --> Language Class Initialized
INFO - 2023-07-30 16:19:33 --> Loader Class Initialized
INFO - 2023-07-30 16:19:33 --> Helper loaded: url_helper
INFO - 2023-07-30 16:19:33 --> Helper loaded: file_helper
INFO - 2023-07-30 16:19:33 --> Helper loaded: html_helper
INFO - 2023-07-30 16:19:33 --> Helper loaded: text_helper
INFO - 2023-07-30 16:19:33 --> Helper loaded: form_helper
INFO - 2023-07-30 16:19:33 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:19:33 --> Helper loaded: security_helper
INFO - 2023-07-30 16:19:33 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:19:33 --> Database Driver Class Initialized
INFO - 2023-07-30 16:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:19:33 --> Parser Class Initialized
INFO - 2023-07-30 16:19:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:19:33 --> Pagination Class Initialized
INFO - 2023-07-30 16:19:33 --> Form Validation Class Initialized
INFO - 2023-07-30 16:19:33 --> Controller Class Initialized
DEBUG - 2023-07-30 16:19:33 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:19:33 --> Model Class Initialized
INFO - 2023-07-30 16:19:33 --> Model Class Initialized
INFO - 2023-07-30 16:19:33 --> Model Class Initialized
INFO - 2023-07-30 16:19:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-07-30 16:19:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:19:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:19:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:19:33 --> Model Class Initialized
INFO - 2023-07-30 16:19:33 --> Model Class Initialized
INFO - 2023-07-30 16:19:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:19:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:19:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:19:33 --> Final output sent to browser
DEBUG - 2023-07-30 16:19:33 --> Total execution time: 0.1734
ERROR - 2023-07-30 16:19:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:19:37 --> Config Class Initialized
INFO - 2023-07-30 16:19:37 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:19:37 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:19:37 --> Utf8 Class Initialized
INFO - 2023-07-30 16:19:37 --> URI Class Initialized
INFO - 2023-07-30 16:19:37 --> Router Class Initialized
INFO - 2023-07-30 16:19:37 --> Output Class Initialized
INFO - 2023-07-30 16:19:37 --> Security Class Initialized
DEBUG - 2023-07-30 16:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:19:37 --> Input Class Initialized
INFO - 2023-07-30 16:19:37 --> Language Class Initialized
INFO - 2023-07-30 16:19:37 --> Loader Class Initialized
INFO - 2023-07-30 16:19:37 --> Helper loaded: url_helper
INFO - 2023-07-30 16:19:37 --> Helper loaded: file_helper
INFO - 2023-07-30 16:19:37 --> Helper loaded: html_helper
INFO - 2023-07-30 16:19:37 --> Helper loaded: text_helper
INFO - 2023-07-30 16:19:37 --> Helper loaded: form_helper
INFO - 2023-07-30 16:19:37 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:19:37 --> Helper loaded: security_helper
INFO - 2023-07-30 16:19:37 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:19:37 --> Database Driver Class Initialized
INFO - 2023-07-30 16:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:19:37 --> Parser Class Initialized
INFO - 2023-07-30 16:19:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:19:37 --> Pagination Class Initialized
INFO - 2023-07-30 16:19:37 --> Form Validation Class Initialized
INFO - 2023-07-30 16:19:37 --> Controller Class Initialized
INFO - 2023-07-30 16:19:37 --> Model Class Initialized
DEBUG - 2023-07-30 16:19:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:19:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:19:37 --> Model Class Initialized
DEBUG - 2023-07-30 16:19:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:19:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-07-30 16:19:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:19:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:19:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:19:37 --> Model Class Initialized
INFO - 2023-07-30 16:19:37 --> Model Class Initialized
INFO - 2023-07-30 16:19:37 --> Model Class Initialized
INFO - 2023-07-30 16:19:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:19:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:19:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:19:37 --> Final output sent to browser
DEBUG - 2023-07-30 16:19:37 --> Total execution time: 0.1590
ERROR - 2023-07-30 16:19:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:19:41 --> Config Class Initialized
INFO - 2023-07-30 16:19:41 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:19:41 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:19:41 --> Utf8 Class Initialized
INFO - 2023-07-30 16:19:41 --> URI Class Initialized
INFO - 2023-07-30 16:19:41 --> Router Class Initialized
INFO - 2023-07-30 16:19:41 --> Output Class Initialized
INFO - 2023-07-30 16:19:41 --> Security Class Initialized
DEBUG - 2023-07-30 16:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:19:41 --> Input Class Initialized
INFO - 2023-07-30 16:19:41 --> Language Class Initialized
INFO - 2023-07-30 16:19:41 --> Loader Class Initialized
INFO - 2023-07-30 16:19:41 --> Helper loaded: url_helper
INFO - 2023-07-30 16:19:41 --> Helper loaded: file_helper
INFO - 2023-07-30 16:19:41 --> Helper loaded: html_helper
INFO - 2023-07-30 16:19:41 --> Helper loaded: text_helper
INFO - 2023-07-30 16:19:41 --> Helper loaded: form_helper
INFO - 2023-07-30 16:19:41 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:19:41 --> Helper loaded: security_helper
INFO - 2023-07-30 16:19:41 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:19:41 --> Database Driver Class Initialized
INFO - 2023-07-30 16:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:19:41 --> Parser Class Initialized
INFO - 2023-07-30 16:19:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:19:41 --> Pagination Class Initialized
INFO - 2023-07-30 16:19:41 --> Form Validation Class Initialized
INFO - 2023-07-30 16:19:41 --> Controller Class Initialized
DEBUG - 2023-07-30 16:19:41 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:19:41 --> Model Class Initialized
INFO - 2023-07-30 16:19:41 --> Model Class Initialized
INFO - 2023-07-30 16:19:41 --> Model Class Initialized
INFO - 2023-07-30 16:19:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-07-30 16:19:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:19:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:19:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:19:41 --> Model Class Initialized
INFO - 2023-07-30 16:19:41 --> Model Class Initialized
INFO - 2023-07-30 16:19:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:19:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:19:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:19:41 --> Final output sent to browser
DEBUG - 2023-07-30 16:19:41 --> Total execution time: 0.1686
ERROR - 2023-07-30 16:19:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:19:44 --> Config Class Initialized
INFO - 2023-07-30 16:19:44 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:19:44 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:19:44 --> Utf8 Class Initialized
INFO - 2023-07-30 16:19:44 --> URI Class Initialized
INFO - 2023-07-30 16:19:44 --> Router Class Initialized
INFO - 2023-07-30 16:19:44 --> Output Class Initialized
INFO - 2023-07-30 16:19:44 --> Security Class Initialized
DEBUG - 2023-07-30 16:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:19:44 --> Input Class Initialized
INFO - 2023-07-30 16:19:44 --> Language Class Initialized
INFO - 2023-07-30 16:19:44 --> Loader Class Initialized
INFO - 2023-07-30 16:19:44 --> Helper loaded: url_helper
INFO - 2023-07-30 16:19:44 --> Helper loaded: file_helper
INFO - 2023-07-30 16:19:44 --> Helper loaded: html_helper
INFO - 2023-07-30 16:19:44 --> Helper loaded: text_helper
INFO - 2023-07-30 16:19:44 --> Helper loaded: form_helper
INFO - 2023-07-30 16:19:44 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:19:44 --> Helper loaded: security_helper
INFO - 2023-07-30 16:19:44 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:19:44 --> Database Driver Class Initialized
INFO - 2023-07-30 16:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:19:44 --> Parser Class Initialized
INFO - 2023-07-30 16:19:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:19:44 --> Pagination Class Initialized
INFO - 2023-07-30 16:19:44 --> Form Validation Class Initialized
INFO - 2023-07-30 16:19:44 --> Controller Class Initialized
INFO - 2023-07-30 16:19:44 --> Model Class Initialized
DEBUG - 2023-07-30 16:19:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:19:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:19:44 --> Model Class Initialized
DEBUG - 2023-07-30 16:19:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:19:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-07-30 16:19:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:19:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:19:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:19:44 --> Model Class Initialized
INFO - 2023-07-30 16:19:44 --> Model Class Initialized
INFO - 2023-07-30 16:19:44 --> Model Class Initialized
INFO - 2023-07-30 16:19:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:19:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:19:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:19:44 --> Final output sent to browser
DEBUG - 2023-07-30 16:19:44 --> Total execution time: 0.1390
ERROR - 2023-07-30 16:20:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:20:09 --> Config Class Initialized
INFO - 2023-07-30 16:20:09 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:20:09 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:20:09 --> Utf8 Class Initialized
INFO - 2023-07-30 16:20:09 --> URI Class Initialized
INFO - 2023-07-30 16:20:09 --> Router Class Initialized
INFO - 2023-07-30 16:20:09 --> Output Class Initialized
INFO - 2023-07-30 16:20:09 --> Security Class Initialized
DEBUG - 2023-07-30 16:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:20:09 --> Input Class Initialized
INFO - 2023-07-30 16:20:09 --> Language Class Initialized
INFO - 2023-07-30 16:20:09 --> Loader Class Initialized
INFO - 2023-07-30 16:20:09 --> Helper loaded: url_helper
INFO - 2023-07-30 16:20:09 --> Helper loaded: file_helper
INFO - 2023-07-30 16:20:09 --> Helper loaded: html_helper
INFO - 2023-07-30 16:20:09 --> Helper loaded: text_helper
INFO - 2023-07-30 16:20:09 --> Helper loaded: form_helper
INFO - 2023-07-30 16:20:09 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:20:09 --> Helper loaded: security_helper
INFO - 2023-07-30 16:20:09 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:20:09 --> Database Driver Class Initialized
INFO - 2023-07-30 16:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:20:09 --> Parser Class Initialized
INFO - 2023-07-30 16:20:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:20:09 --> Pagination Class Initialized
INFO - 2023-07-30 16:20:09 --> Form Validation Class Initialized
INFO - 2023-07-30 16:20:09 --> Controller Class Initialized
DEBUG - 2023-07-30 16:20:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:20:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:20:09 --> Model Class Initialized
INFO - 2023-07-30 16:20:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gift/add_gift_form.php
DEBUG - 2023-07-30 16:20:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:20:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:20:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:20:09 --> Model Class Initialized
INFO - 2023-07-30 16:20:09 --> Model Class Initialized
INFO - 2023-07-30 16:20:09 --> Model Class Initialized
INFO - 2023-07-30 16:20:09 --> Model Class Initialized
INFO - 2023-07-30 16:20:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:20:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:20:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:20:09 --> Final output sent to browser
DEBUG - 2023-07-30 16:20:09 --> Total execution time: 0.1490
ERROR - 2023-07-30 16:20:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:20:24 --> Config Class Initialized
INFO - 2023-07-30 16:20:24 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:20:24 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:20:24 --> Utf8 Class Initialized
INFO - 2023-07-30 16:20:24 --> URI Class Initialized
INFO - 2023-07-30 16:20:24 --> Router Class Initialized
INFO - 2023-07-30 16:20:24 --> Output Class Initialized
INFO - 2023-07-30 16:20:24 --> Security Class Initialized
DEBUG - 2023-07-30 16:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:20:24 --> Input Class Initialized
INFO - 2023-07-30 16:20:24 --> Language Class Initialized
INFO - 2023-07-30 16:20:24 --> Loader Class Initialized
INFO - 2023-07-30 16:20:24 --> Helper loaded: url_helper
INFO - 2023-07-30 16:20:24 --> Helper loaded: file_helper
INFO - 2023-07-30 16:20:24 --> Helper loaded: html_helper
INFO - 2023-07-30 16:20:24 --> Helper loaded: text_helper
INFO - 2023-07-30 16:20:24 --> Helper loaded: form_helper
INFO - 2023-07-30 16:20:24 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:20:24 --> Helper loaded: security_helper
INFO - 2023-07-30 16:20:24 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:20:24 --> Database Driver Class Initialized
INFO - 2023-07-30 16:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:20:24 --> Parser Class Initialized
INFO - 2023-07-30 16:20:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:20:24 --> Pagination Class Initialized
INFO - 2023-07-30 16:20:24 --> Form Validation Class Initialized
INFO - 2023-07-30 16:20:24 --> Controller Class Initialized
DEBUG - 2023-07-30 16:20:24 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:20:24 --> Model Class Initialized
INFO - 2023-07-30 16:20:24 --> Model Class Initialized
INFO - 2023-07-30 16:20:24 --> Model Class Initialized
INFO - 2023-07-30 16:20:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-07-30 16:20:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:20:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:20:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:20:24 --> Model Class Initialized
INFO - 2023-07-30 16:20:24 --> Model Class Initialized
INFO - 2023-07-30 16:20:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:20:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:20:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:20:24 --> Final output sent to browser
DEBUG - 2023-07-30 16:20:24 --> Total execution time: 0.1641
ERROR - 2023-07-30 16:20:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:20:25 --> Config Class Initialized
INFO - 2023-07-30 16:20:25 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:20:25 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:20:25 --> Utf8 Class Initialized
INFO - 2023-07-30 16:20:25 --> URI Class Initialized
INFO - 2023-07-30 16:20:25 --> Router Class Initialized
INFO - 2023-07-30 16:20:25 --> Output Class Initialized
INFO - 2023-07-30 16:20:25 --> Security Class Initialized
DEBUG - 2023-07-30 16:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:20:25 --> Input Class Initialized
INFO - 2023-07-30 16:20:25 --> Language Class Initialized
INFO - 2023-07-30 16:20:25 --> Loader Class Initialized
INFO - 2023-07-30 16:20:25 --> Helper loaded: url_helper
INFO - 2023-07-30 16:20:25 --> Helper loaded: file_helper
INFO - 2023-07-30 16:20:25 --> Helper loaded: html_helper
INFO - 2023-07-30 16:20:25 --> Helper loaded: text_helper
INFO - 2023-07-30 16:20:25 --> Helper loaded: form_helper
INFO - 2023-07-30 16:20:25 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:20:25 --> Helper loaded: security_helper
INFO - 2023-07-30 16:20:25 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:20:25 --> Database Driver Class Initialized
INFO - 2023-07-30 16:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:20:25 --> Parser Class Initialized
INFO - 2023-07-30 16:20:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:20:25 --> Pagination Class Initialized
INFO - 2023-07-30 16:20:25 --> Form Validation Class Initialized
INFO - 2023-07-30 16:20:25 --> Controller Class Initialized
DEBUG - 2023-07-30 16:20:25 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:20:25 --> Model Class Initialized
INFO - 2023-07-30 16:20:25 --> Model Class Initialized
INFO - 2023-07-30 16:20:25 --> Final output sent to browser
DEBUG - 2023-07-30 16:20:25 --> Total execution time: 0.0476
ERROR - 2023-07-30 16:20:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:20:37 --> Config Class Initialized
INFO - 2023-07-30 16:20:37 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:20:37 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:20:37 --> Utf8 Class Initialized
INFO - 2023-07-30 16:20:37 --> URI Class Initialized
INFO - 2023-07-30 16:20:37 --> Router Class Initialized
INFO - 2023-07-30 16:20:37 --> Output Class Initialized
INFO - 2023-07-30 16:20:37 --> Security Class Initialized
DEBUG - 2023-07-30 16:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:20:37 --> Input Class Initialized
INFO - 2023-07-30 16:20:37 --> Language Class Initialized
INFO - 2023-07-30 16:20:37 --> Loader Class Initialized
INFO - 2023-07-30 16:20:37 --> Helper loaded: url_helper
INFO - 2023-07-30 16:20:37 --> Helper loaded: file_helper
INFO - 2023-07-30 16:20:37 --> Helper loaded: html_helper
INFO - 2023-07-30 16:20:37 --> Helper loaded: text_helper
INFO - 2023-07-30 16:20:37 --> Helper loaded: form_helper
INFO - 2023-07-30 16:20:37 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:20:37 --> Helper loaded: security_helper
INFO - 2023-07-30 16:20:37 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:20:37 --> Database Driver Class Initialized
INFO - 2023-07-30 16:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:20:37 --> Parser Class Initialized
INFO - 2023-07-30 16:20:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:20:37 --> Pagination Class Initialized
INFO - 2023-07-30 16:20:37 --> Form Validation Class Initialized
INFO - 2023-07-30 16:20:37 --> Controller Class Initialized
DEBUG - 2023-07-30 16:20:37 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:20:37 --> Model Class Initialized
INFO - 2023-07-30 16:20:37 --> Model Class Initialized
INFO - 2023-07-30 16:20:37 --> Model Class Initialized
INFO - 2023-07-30 16:20:37 --> Model Class Initialized
INFO - 2023-07-30 16:20:37 --> Model Class Initialized
INFO - 2023-07-30 16:20:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/edit_product_form.php
DEBUG - 2023-07-30 16:20:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:20:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:20:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:20:37 --> Model Class Initialized
INFO - 2023-07-30 16:20:37 --> Model Class Initialized
INFO - 2023-07-30 16:20:37 --> Model Class Initialized
INFO - 2023-07-30 16:20:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:20:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:20:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:20:37 --> Final output sent to browser
DEBUG - 2023-07-30 16:20:37 --> Total execution time: 0.1650
ERROR - 2023-07-30 16:20:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:20:49 --> Config Class Initialized
INFO - 2023-07-30 16:20:49 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:20:49 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:20:49 --> Utf8 Class Initialized
INFO - 2023-07-30 16:20:49 --> URI Class Initialized
INFO - 2023-07-30 16:20:49 --> Router Class Initialized
INFO - 2023-07-30 16:20:49 --> Output Class Initialized
INFO - 2023-07-30 16:20:49 --> Security Class Initialized
DEBUG - 2023-07-30 16:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:20:49 --> Input Class Initialized
INFO - 2023-07-30 16:20:49 --> Language Class Initialized
INFO - 2023-07-30 16:20:49 --> Loader Class Initialized
INFO - 2023-07-30 16:20:49 --> Helper loaded: url_helper
INFO - 2023-07-30 16:20:49 --> Helper loaded: file_helper
INFO - 2023-07-30 16:20:49 --> Helper loaded: html_helper
INFO - 2023-07-30 16:20:49 --> Helper loaded: text_helper
INFO - 2023-07-30 16:20:49 --> Helper loaded: form_helper
INFO - 2023-07-30 16:20:49 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:20:49 --> Helper loaded: security_helper
INFO - 2023-07-30 16:20:49 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:20:49 --> Database Driver Class Initialized
INFO - 2023-07-30 16:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:20:49 --> Parser Class Initialized
INFO - 2023-07-30 16:20:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:20:49 --> Pagination Class Initialized
INFO - 2023-07-30 16:20:49 --> Form Validation Class Initialized
INFO - 2023-07-30 16:20:49 --> Controller Class Initialized
DEBUG - 2023-07-30 16:20:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:20:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:20:49 --> Model Class Initialized
INFO - 2023-07-30 16:20:49 --> Model Class Initialized
INFO - 2023-07-30 16:20:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/manufacturer/manufacturer.php
DEBUG - 2023-07-30 16:20:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:20:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:20:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:20:49 --> Model Class Initialized
INFO - 2023-07-30 16:20:49 --> Model Class Initialized
INFO - 2023-07-30 16:20:49 --> Model Class Initialized
INFO - 2023-07-30 16:20:49 --> Model Class Initialized
INFO - 2023-07-30 16:20:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:20:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:20:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:20:49 --> Final output sent to browser
DEBUG - 2023-07-30 16:20:49 --> Total execution time: 0.1577
ERROR - 2023-07-30 16:21:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:21:03 --> Config Class Initialized
INFO - 2023-07-30 16:21:03 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:21:03 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:21:03 --> Utf8 Class Initialized
INFO - 2023-07-30 16:21:03 --> URI Class Initialized
INFO - 2023-07-30 16:21:03 --> Router Class Initialized
INFO - 2023-07-30 16:21:03 --> Output Class Initialized
INFO - 2023-07-30 16:21:03 --> Security Class Initialized
DEBUG - 2023-07-30 16:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:21:03 --> Input Class Initialized
INFO - 2023-07-30 16:21:03 --> Language Class Initialized
INFO - 2023-07-30 16:21:03 --> Loader Class Initialized
INFO - 2023-07-30 16:21:03 --> Helper loaded: url_helper
INFO - 2023-07-30 16:21:03 --> Helper loaded: file_helper
INFO - 2023-07-30 16:21:03 --> Helper loaded: html_helper
INFO - 2023-07-30 16:21:03 --> Helper loaded: text_helper
INFO - 2023-07-30 16:21:03 --> Helper loaded: form_helper
INFO - 2023-07-30 16:21:03 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:21:03 --> Helper loaded: security_helper
INFO - 2023-07-30 16:21:03 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:21:03 --> Database Driver Class Initialized
INFO - 2023-07-30 16:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:21:03 --> Parser Class Initialized
INFO - 2023-07-30 16:21:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:21:03 --> Pagination Class Initialized
INFO - 2023-07-30 16:21:03 --> Form Validation Class Initialized
INFO - 2023-07-30 16:21:03 --> Controller Class Initialized
INFO - 2023-07-30 16:21:03 --> Model Class Initialized
INFO - 2023-07-30 16:21:03 --> Model Class Initialized
INFO - 2023-07-30 16:21:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-07-30 16:21:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:21:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:21:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:21:03 --> Model Class Initialized
INFO - 2023-07-30 16:21:03 --> Model Class Initialized
INFO - 2023-07-30 16:21:03 --> Model Class Initialized
INFO - 2023-07-30 16:21:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:21:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:21:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:21:03 --> Final output sent to browser
DEBUG - 2023-07-30 16:21:03 --> Total execution time: 0.1598
ERROR - 2023-07-30 16:21:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:21:04 --> Config Class Initialized
INFO - 2023-07-30 16:21:04 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:21:04 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:21:04 --> Utf8 Class Initialized
INFO - 2023-07-30 16:21:04 --> URI Class Initialized
INFO - 2023-07-30 16:21:04 --> Router Class Initialized
INFO - 2023-07-30 16:21:04 --> Output Class Initialized
INFO - 2023-07-30 16:21:04 --> Security Class Initialized
DEBUG - 2023-07-30 16:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:21:04 --> Input Class Initialized
INFO - 2023-07-30 16:21:04 --> Language Class Initialized
INFO - 2023-07-30 16:21:04 --> Loader Class Initialized
INFO - 2023-07-30 16:21:04 --> Helper loaded: url_helper
INFO - 2023-07-30 16:21:04 --> Helper loaded: file_helper
INFO - 2023-07-30 16:21:04 --> Helper loaded: html_helper
INFO - 2023-07-30 16:21:04 --> Helper loaded: text_helper
INFO - 2023-07-30 16:21:04 --> Helper loaded: form_helper
INFO - 2023-07-30 16:21:04 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:21:04 --> Helper loaded: security_helper
INFO - 2023-07-30 16:21:04 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:21:04 --> Database Driver Class Initialized
INFO - 2023-07-30 16:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:21:04 --> Parser Class Initialized
INFO - 2023-07-30 16:21:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:21:04 --> Pagination Class Initialized
INFO - 2023-07-30 16:21:04 --> Form Validation Class Initialized
INFO - 2023-07-30 16:21:04 --> Controller Class Initialized
INFO - 2023-07-30 16:21:04 --> Model Class Initialized
INFO - 2023-07-30 16:21:04 --> Model Class Initialized
INFO - 2023-07-30 16:21:04 --> Final output sent to browser
DEBUG - 2023-07-30 16:21:04 --> Total execution time: 0.0526
ERROR - 2023-07-30 16:21:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:21:12 --> Config Class Initialized
INFO - 2023-07-30 16:21:12 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:21:12 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:21:12 --> Utf8 Class Initialized
INFO - 2023-07-30 16:21:12 --> URI Class Initialized
INFO - 2023-07-30 16:21:12 --> Router Class Initialized
INFO - 2023-07-30 16:21:12 --> Output Class Initialized
INFO - 2023-07-30 16:21:12 --> Security Class Initialized
DEBUG - 2023-07-30 16:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:21:12 --> Input Class Initialized
INFO - 2023-07-30 16:21:12 --> Language Class Initialized
INFO - 2023-07-30 16:21:12 --> Loader Class Initialized
INFO - 2023-07-30 16:21:12 --> Helper loaded: url_helper
INFO - 2023-07-30 16:21:12 --> Helper loaded: file_helper
INFO - 2023-07-30 16:21:12 --> Helper loaded: html_helper
INFO - 2023-07-30 16:21:12 --> Helper loaded: text_helper
INFO - 2023-07-30 16:21:12 --> Helper loaded: form_helper
INFO - 2023-07-30 16:21:12 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:21:12 --> Helper loaded: security_helper
INFO - 2023-07-30 16:21:12 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:21:12 --> Database Driver Class Initialized
INFO - 2023-07-30 16:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:21:12 --> Parser Class Initialized
INFO - 2023-07-30 16:21:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:21:12 --> Pagination Class Initialized
INFO - 2023-07-30 16:21:12 --> Form Validation Class Initialized
INFO - 2023-07-30 16:21:12 --> Controller Class Initialized
INFO - 2023-07-30 16:21:12 --> Model Class Initialized
INFO - 2023-07-30 16:21:12 --> Model Class Initialized
INFO - 2023-07-30 16:21:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2023-07-30 16:21:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:21:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:21:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:21:12 --> Model Class Initialized
INFO - 2023-07-30 16:21:12 --> Model Class Initialized
INFO - 2023-07-30 16:21:12 --> Model Class Initialized
INFO - 2023-07-30 16:21:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:21:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:21:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:21:12 --> Final output sent to browser
DEBUG - 2023-07-30 16:21:12 --> Total execution time: 0.1502
ERROR - 2023-07-30 16:21:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:21:47 --> Config Class Initialized
INFO - 2023-07-30 16:21:47 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:21:47 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:21:47 --> Utf8 Class Initialized
INFO - 2023-07-30 16:21:47 --> URI Class Initialized
INFO - 2023-07-30 16:21:47 --> Router Class Initialized
INFO - 2023-07-30 16:21:47 --> Output Class Initialized
INFO - 2023-07-30 16:21:47 --> Security Class Initialized
DEBUG - 2023-07-30 16:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:21:47 --> Input Class Initialized
INFO - 2023-07-30 16:21:47 --> Language Class Initialized
INFO - 2023-07-30 16:21:47 --> Loader Class Initialized
INFO - 2023-07-30 16:21:47 --> Helper loaded: url_helper
INFO - 2023-07-30 16:21:47 --> Helper loaded: file_helper
INFO - 2023-07-30 16:21:47 --> Helper loaded: html_helper
INFO - 2023-07-30 16:21:47 --> Helper loaded: text_helper
INFO - 2023-07-30 16:21:47 --> Helper loaded: form_helper
INFO - 2023-07-30 16:21:47 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:21:47 --> Helper loaded: security_helper
INFO - 2023-07-30 16:21:47 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:21:47 --> Database Driver Class Initialized
INFO - 2023-07-30 16:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:21:47 --> Parser Class Initialized
INFO - 2023-07-30 16:21:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:21:47 --> Pagination Class Initialized
INFO - 2023-07-30 16:21:47 --> Form Validation Class Initialized
INFO - 2023-07-30 16:21:47 --> Controller Class Initialized
INFO - 2023-07-30 16:21:47 --> Model Class Initialized
INFO - 2023-07-30 16:21:47 --> Model Class Initialized
INFO - 2023-07-30 16:21:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-07-30 16:21:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:21:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:21:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:21:47 --> Model Class Initialized
INFO - 2023-07-30 16:21:47 --> Model Class Initialized
INFO - 2023-07-30 16:21:47 --> Model Class Initialized
INFO - 2023-07-30 16:21:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:21:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:21:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:21:47 --> Final output sent to browser
DEBUG - 2023-07-30 16:21:47 --> Total execution time: 0.1518
ERROR - 2023-07-30 16:21:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:21:47 --> Config Class Initialized
INFO - 2023-07-30 16:21:47 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:21:47 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:21:47 --> Utf8 Class Initialized
INFO - 2023-07-30 16:21:47 --> URI Class Initialized
INFO - 2023-07-30 16:21:47 --> Router Class Initialized
INFO - 2023-07-30 16:21:47 --> Output Class Initialized
INFO - 2023-07-30 16:21:47 --> Security Class Initialized
DEBUG - 2023-07-30 16:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:21:47 --> Input Class Initialized
INFO - 2023-07-30 16:21:47 --> Language Class Initialized
INFO - 2023-07-30 16:21:47 --> Loader Class Initialized
INFO - 2023-07-30 16:21:47 --> Helper loaded: url_helper
INFO - 2023-07-30 16:21:47 --> Helper loaded: file_helper
INFO - 2023-07-30 16:21:47 --> Helper loaded: html_helper
INFO - 2023-07-30 16:21:47 --> Helper loaded: text_helper
INFO - 2023-07-30 16:21:47 --> Helper loaded: form_helper
INFO - 2023-07-30 16:21:47 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:21:47 --> Helper loaded: security_helper
INFO - 2023-07-30 16:21:47 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:21:47 --> Database Driver Class Initialized
INFO - 2023-07-30 16:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:21:47 --> Parser Class Initialized
INFO - 2023-07-30 16:21:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:21:47 --> Pagination Class Initialized
INFO - 2023-07-30 16:21:47 --> Form Validation Class Initialized
INFO - 2023-07-30 16:21:47 --> Controller Class Initialized
INFO - 2023-07-30 16:21:47 --> Model Class Initialized
INFO - 2023-07-30 16:21:47 --> Model Class Initialized
INFO - 2023-07-30 16:21:47 --> Final output sent to browser
DEBUG - 2023-07-30 16:21:47 --> Total execution time: 0.0524
ERROR - 2023-07-30 16:21:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:21:54 --> Config Class Initialized
INFO - 2023-07-30 16:21:54 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:21:54 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:21:54 --> Utf8 Class Initialized
INFO - 2023-07-30 16:21:54 --> URI Class Initialized
INFO - 2023-07-30 16:21:54 --> Router Class Initialized
INFO - 2023-07-30 16:21:54 --> Output Class Initialized
INFO - 2023-07-30 16:21:54 --> Security Class Initialized
DEBUG - 2023-07-30 16:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:21:54 --> Input Class Initialized
INFO - 2023-07-30 16:21:54 --> Language Class Initialized
INFO - 2023-07-30 16:21:54 --> Loader Class Initialized
INFO - 2023-07-30 16:21:54 --> Helper loaded: url_helper
INFO - 2023-07-30 16:21:54 --> Helper loaded: file_helper
INFO - 2023-07-30 16:21:54 --> Helper loaded: html_helper
INFO - 2023-07-30 16:21:54 --> Helper loaded: text_helper
INFO - 2023-07-30 16:21:54 --> Helper loaded: form_helper
INFO - 2023-07-30 16:21:54 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:21:54 --> Helper loaded: security_helper
INFO - 2023-07-30 16:21:54 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:21:54 --> Database Driver Class Initialized
INFO - 2023-07-30 16:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:21:54 --> Parser Class Initialized
INFO - 2023-07-30 16:21:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:21:54 --> Pagination Class Initialized
INFO - 2023-07-30 16:21:54 --> Form Validation Class Initialized
INFO - 2023-07-30 16:21:54 --> Controller Class Initialized
INFO - 2023-07-30 16:21:54 --> Model Class Initialized
INFO - 2023-07-30 16:21:54 --> Model Class Initialized
INFO - 2023-07-30 16:21:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2023-07-30 16:21:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:21:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:21:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:21:55 --> Model Class Initialized
INFO - 2023-07-30 16:21:55 --> Model Class Initialized
INFO - 2023-07-30 16:21:55 --> Model Class Initialized
INFO - 2023-07-30 16:21:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:21:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:21:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:21:55 --> Final output sent to browser
DEBUG - 2023-07-30 16:21:55 --> Total execution time: 0.1406
ERROR - 2023-07-30 16:22:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:22:12 --> Config Class Initialized
INFO - 2023-07-30 16:22:12 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:22:12 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:22:12 --> Utf8 Class Initialized
INFO - 2023-07-30 16:22:12 --> URI Class Initialized
INFO - 2023-07-30 16:22:12 --> Router Class Initialized
INFO - 2023-07-30 16:22:12 --> Output Class Initialized
INFO - 2023-07-30 16:22:12 --> Security Class Initialized
DEBUG - 2023-07-30 16:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:22:12 --> Input Class Initialized
INFO - 2023-07-30 16:22:12 --> Language Class Initialized
INFO - 2023-07-30 16:22:12 --> Loader Class Initialized
INFO - 2023-07-30 16:22:12 --> Helper loaded: url_helper
INFO - 2023-07-30 16:22:12 --> Helper loaded: file_helper
INFO - 2023-07-30 16:22:12 --> Helper loaded: html_helper
INFO - 2023-07-30 16:22:12 --> Helper loaded: text_helper
INFO - 2023-07-30 16:22:12 --> Helper loaded: form_helper
INFO - 2023-07-30 16:22:12 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:22:12 --> Helper loaded: security_helper
INFO - 2023-07-30 16:22:12 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:22:12 --> Database Driver Class Initialized
INFO - 2023-07-30 16:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:22:12 --> Parser Class Initialized
INFO - 2023-07-30 16:22:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:22:12 --> Pagination Class Initialized
INFO - 2023-07-30 16:22:12 --> Form Validation Class Initialized
INFO - 2023-07-30 16:22:12 --> Controller Class Initialized
DEBUG - 2023-07-30 16:22:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:22:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:22:12 --> Model Class Initialized
INFO - 2023-07-30 16:22:12 --> Model Class Initialized
INFO - 2023-07-30 16:22:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/manufacturer/manufacturer.php
DEBUG - 2023-07-30 16:22:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:22:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:22:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:22:12 --> Model Class Initialized
INFO - 2023-07-30 16:22:12 --> Model Class Initialized
INFO - 2023-07-30 16:22:12 --> Model Class Initialized
INFO - 2023-07-30 16:22:12 --> Model Class Initialized
INFO - 2023-07-30 16:22:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:22:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:22:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:22:12 --> Final output sent to browser
DEBUG - 2023-07-30 16:22:12 --> Total execution time: 0.1726
ERROR - 2023-07-30 16:22:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:22:21 --> Config Class Initialized
INFO - 2023-07-30 16:22:21 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:22:21 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:22:21 --> Utf8 Class Initialized
INFO - 2023-07-30 16:22:21 --> URI Class Initialized
INFO - 2023-07-30 16:22:21 --> Router Class Initialized
INFO - 2023-07-30 16:22:21 --> Output Class Initialized
INFO - 2023-07-30 16:22:21 --> Security Class Initialized
DEBUG - 2023-07-30 16:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:22:21 --> Input Class Initialized
INFO - 2023-07-30 16:22:21 --> Language Class Initialized
INFO - 2023-07-30 16:22:21 --> Loader Class Initialized
INFO - 2023-07-30 16:22:21 --> Helper loaded: url_helper
INFO - 2023-07-30 16:22:21 --> Helper loaded: file_helper
INFO - 2023-07-30 16:22:21 --> Helper loaded: html_helper
INFO - 2023-07-30 16:22:21 --> Helper loaded: text_helper
INFO - 2023-07-30 16:22:21 --> Helper loaded: form_helper
INFO - 2023-07-30 16:22:21 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:22:21 --> Helper loaded: security_helper
INFO - 2023-07-30 16:22:21 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:22:21 --> Database Driver Class Initialized
INFO - 2023-07-30 16:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:22:21 --> Parser Class Initialized
INFO - 2023-07-30 16:22:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:22:21 --> Pagination Class Initialized
INFO - 2023-07-30 16:22:21 --> Form Validation Class Initialized
INFO - 2023-07-30 16:22:21 --> Controller Class Initialized
DEBUG - 2023-07-30 16:22:21 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:22:21 --> Model Class Initialized
INFO - 2023-07-30 16:22:21 --> Model Class Initialized
INFO - 2023-07-30 16:22:21 --> Model Class Initialized
INFO - 2023-07-30 16:22:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-07-30 16:22:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:22:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:22:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:22:21 --> Model Class Initialized
INFO - 2023-07-30 16:22:21 --> Model Class Initialized
INFO - 2023-07-30 16:22:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:22:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:22:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:22:21 --> Final output sent to browser
DEBUG - 2023-07-30 16:22:21 --> Total execution time: 0.1391
ERROR - 2023-07-30 16:22:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:22:22 --> Config Class Initialized
INFO - 2023-07-30 16:22:22 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:22:22 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:22:22 --> Utf8 Class Initialized
INFO - 2023-07-30 16:22:22 --> URI Class Initialized
INFO - 2023-07-30 16:22:22 --> Router Class Initialized
INFO - 2023-07-30 16:22:22 --> Output Class Initialized
INFO - 2023-07-30 16:22:22 --> Security Class Initialized
DEBUG - 2023-07-30 16:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:22:22 --> Input Class Initialized
INFO - 2023-07-30 16:22:22 --> Language Class Initialized
INFO - 2023-07-30 16:22:22 --> Loader Class Initialized
INFO - 2023-07-30 16:22:22 --> Helper loaded: url_helper
INFO - 2023-07-30 16:22:22 --> Helper loaded: file_helper
INFO - 2023-07-30 16:22:22 --> Helper loaded: html_helper
INFO - 2023-07-30 16:22:22 --> Helper loaded: text_helper
INFO - 2023-07-30 16:22:22 --> Helper loaded: form_helper
INFO - 2023-07-30 16:22:22 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:22:22 --> Helper loaded: security_helper
INFO - 2023-07-30 16:22:22 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:22:22 --> Database Driver Class Initialized
INFO - 2023-07-30 16:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:22:22 --> Parser Class Initialized
INFO - 2023-07-30 16:22:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:22:22 --> Pagination Class Initialized
INFO - 2023-07-30 16:22:22 --> Form Validation Class Initialized
INFO - 2023-07-30 16:22:22 --> Controller Class Initialized
DEBUG - 2023-07-30 16:22:22 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:22:22 --> Model Class Initialized
INFO - 2023-07-30 16:22:22 --> Model Class Initialized
INFO - 2023-07-30 16:22:22 --> Final output sent to browser
DEBUG - 2023-07-30 16:22:22 --> Total execution time: 0.0456
ERROR - 2023-07-30 16:22:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:22:33 --> Config Class Initialized
INFO - 2023-07-30 16:22:33 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:22:33 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:22:33 --> Utf8 Class Initialized
INFO - 2023-07-30 16:22:33 --> URI Class Initialized
INFO - 2023-07-30 16:22:33 --> Router Class Initialized
INFO - 2023-07-30 16:22:33 --> Output Class Initialized
INFO - 2023-07-30 16:22:33 --> Security Class Initialized
DEBUG - 2023-07-30 16:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:22:33 --> Input Class Initialized
INFO - 2023-07-30 16:22:33 --> Language Class Initialized
INFO - 2023-07-30 16:22:33 --> Loader Class Initialized
INFO - 2023-07-30 16:22:33 --> Helper loaded: url_helper
INFO - 2023-07-30 16:22:33 --> Helper loaded: file_helper
INFO - 2023-07-30 16:22:33 --> Helper loaded: html_helper
INFO - 2023-07-30 16:22:33 --> Helper loaded: text_helper
INFO - 2023-07-30 16:22:33 --> Helper loaded: form_helper
INFO - 2023-07-30 16:22:33 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:22:33 --> Helper loaded: security_helper
INFO - 2023-07-30 16:22:33 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:22:33 --> Database Driver Class Initialized
INFO - 2023-07-30 16:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:22:33 --> Parser Class Initialized
INFO - 2023-07-30 16:22:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:22:33 --> Pagination Class Initialized
INFO - 2023-07-30 16:22:33 --> Form Validation Class Initialized
INFO - 2023-07-30 16:22:33 --> Controller Class Initialized
INFO - 2023-07-30 16:22:33 --> Model Class Initialized
INFO - 2023-07-30 16:22:33 --> Model Class Initialized
INFO - 2023-07-30 16:22:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-07-30 16:22:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:22:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:22:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:22:33 --> Model Class Initialized
INFO - 2023-07-30 16:22:33 --> Model Class Initialized
INFO - 2023-07-30 16:22:33 --> Model Class Initialized
INFO - 2023-07-30 16:22:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:22:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:22:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:22:33 --> Final output sent to browser
DEBUG - 2023-07-30 16:22:33 --> Total execution time: 0.1344
ERROR - 2023-07-30 16:22:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:22:34 --> Config Class Initialized
INFO - 2023-07-30 16:22:34 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:22:34 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:22:34 --> Utf8 Class Initialized
INFO - 2023-07-30 16:22:34 --> URI Class Initialized
INFO - 2023-07-30 16:22:34 --> Router Class Initialized
INFO - 2023-07-30 16:22:34 --> Output Class Initialized
INFO - 2023-07-30 16:22:34 --> Security Class Initialized
DEBUG - 2023-07-30 16:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:22:34 --> Input Class Initialized
INFO - 2023-07-30 16:22:34 --> Language Class Initialized
INFO - 2023-07-30 16:22:34 --> Loader Class Initialized
INFO - 2023-07-30 16:22:34 --> Helper loaded: url_helper
INFO - 2023-07-30 16:22:34 --> Helper loaded: file_helper
INFO - 2023-07-30 16:22:34 --> Helper loaded: html_helper
INFO - 2023-07-30 16:22:34 --> Helper loaded: text_helper
INFO - 2023-07-30 16:22:34 --> Helper loaded: form_helper
INFO - 2023-07-30 16:22:34 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:22:34 --> Helper loaded: security_helper
INFO - 2023-07-30 16:22:34 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:22:34 --> Database Driver Class Initialized
INFO - 2023-07-30 16:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:22:34 --> Parser Class Initialized
INFO - 2023-07-30 16:22:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:22:34 --> Pagination Class Initialized
INFO - 2023-07-30 16:22:34 --> Form Validation Class Initialized
INFO - 2023-07-30 16:22:34 --> Controller Class Initialized
INFO - 2023-07-30 16:22:34 --> Model Class Initialized
INFO - 2023-07-30 16:22:34 --> Model Class Initialized
INFO - 2023-07-30 16:22:34 --> Final output sent to browser
DEBUG - 2023-07-30 16:22:34 --> Total execution time: 0.0466
ERROR - 2023-07-30 16:22:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:22:44 --> Config Class Initialized
INFO - 2023-07-30 16:22:44 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:22:44 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:22:44 --> Utf8 Class Initialized
INFO - 2023-07-30 16:22:44 --> URI Class Initialized
INFO - 2023-07-30 16:22:44 --> Router Class Initialized
INFO - 2023-07-30 16:22:44 --> Output Class Initialized
INFO - 2023-07-30 16:22:44 --> Security Class Initialized
DEBUG - 2023-07-30 16:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:22:44 --> Input Class Initialized
INFO - 2023-07-30 16:22:44 --> Language Class Initialized
INFO - 2023-07-30 16:22:44 --> Loader Class Initialized
INFO - 2023-07-30 16:22:44 --> Helper loaded: url_helper
INFO - 2023-07-30 16:22:44 --> Helper loaded: file_helper
INFO - 2023-07-30 16:22:44 --> Helper loaded: html_helper
INFO - 2023-07-30 16:22:44 --> Helper loaded: text_helper
INFO - 2023-07-30 16:22:44 --> Helper loaded: form_helper
INFO - 2023-07-30 16:22:44 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:22:44 --> Helper loaded: security_helper
INFO - 2023-07-30 16:22:44 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:22:44 --> Database Driver Class Initialized
INFO - 2023-07-30 16:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:22:44 --> Parser Class Initialized
INFO - 2023-07-30 16:22:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:22:44 --> Pagination Class Initialized
INFO - 2023-07-30 16:22:44 --> Form Validation Class Initialized
INFO - 2023-07-30 16:22:44 --> Controller Class Initialized
INFO - 2023-07-30 16:22:44 --> Model Class Initialized
INFO - 2023-07-30 16:22:44 --> Model Class Initialized
INFO - 2023-07-30 16:22:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2023-07-30 16:22:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:22:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:22:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:22:44 --> Model Class Initialized
INFO - 2023-07-30 16:22:44 --> Model Class Initialized
INFO - 2023-07-30 16:22:44 --> Model Class Initialized
INFO - 2023-07-30 16:22:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:22:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:22:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:22:44 --> Final output sent to browser
DEBUG - 2023-07-30 16:22:44 --> Total execution time: 0.1303
ERROR - 2023-07-30 16:23:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:23:58 --> Config Class Initialized
INFO - 2023-07-30 16:23:58 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:23:58 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:23:58 --> Utf8 Class Initialized
INFO - 2023-07-30 16:23:58 --> URI Class Initialized
INFO - 2023-07-30 16:23:58 --> Router Class Initialized
INFO - 2023-07-30 16:23:58 --> Output Class Initialized
INFO - 2023-07-30 16:23:58 --> Security Class Initialized
DEBUG - 2023-07-30 16:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:23:58 --> Input Class Initialized
INFO - 2023-07-30 16:23:58 --> Language Class Initialized
INFO - 2023-07-30 16:23:58 --> Loader Class Initialized
INFO - 2023-07-30 16:23:58 --> Helper loaded: url_helper
INFO - 2023-07-30 16:23:58 --> Helper loaded: file_helper
INFO - 2023-07-30 16:23:58 --> Helper loaded: html_helper
INFO - 2023-07-30 16:23:58 --> Helper loaded: text_helper
INFO - 2023-07-30 16:23:58 --> Helper loaded: form_helper
INFO - 2023-07-30 16:23:58 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:23:58 --> Helper loaded: security_helper
INFO - 2023-07-30 16:23:58 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:23:58 --> Database Driver Class Initialized
INFO - 2023-07-30 16:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:23:58 --> Parser Class Initialized
INFO - 2023-07-30 16:23:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:23:58 --> Pagination Class Initialized
INFO - 2023-07-30 16:23:58 --> Form Validation Class Initialized
INFO - 2023-07-30 16:23:58 --> Controller Class Initialized
DEBUG - 2023-07-30 16:23:58 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:23:58 --> Model Class Initialized
INFO - 2023-07-30 16:23:58 --> Model Class Initialized
INFO - 2023-07-30 16:23:58 --> Model Class Initialized
INFO - 2023-07-30 16:23:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2023-07-30 16:23:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:23:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:23:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:23:58 --> Model Class Initialized
INFO - 2023-07-30 16:23:58 --> Model Class Initialized
INFO - 2023-07-30 16:23:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:23:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:23:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:23:58 --> Final output sent to browser
DEBUG - 2023-07-30 16:23:58 --> Total execution time: 0.1371
ERROR - 2023-07-30 16:23:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:23:59 --> Config Class Initialized
INFO - 2023-07-30 16:23:59 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:23:59 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:23:59 --> Utf8 Class Initialized
INFO - 2023-07-30 16:23:59 --> URI Class Initialized
INFO - 2023-07-30 16:23:59 --> Router Class Initialized
INFO - 2023-07-30 16:23:59 --> Output Class Initialized
INFO - 2023-07-30 16:23:59 --> Security Class Initialized
DEBUG - 2023-07-30 16:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:23:59 --> Input Class Initialized
INFO - 2023-07-30 16:23:59 --> Language Class Initialized
INFO - 2023-07-30 16:23:59 --> Loader Class Initialized
INFO - 2023-07-30 16:23:59 --> Helper loaded: url_helper
INFO - 2023-07-30 16:23:59 --> Helper loaded: file_helper
INFO - 2023-07-30 16:23:59 --> Helper loaded: html_helper
INFO - 2023-07-30 16:23:59 --> Helper loaded: text_helper
INFO - 2023-07-30 16:23:59 --> Helper loaded: form_helper
INFO - 2023-07-30 16:23:59 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:23:59 --> Helper loaded: security_helper
INFO - 2023-07-30 16:23:59 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:23:59 --> Database Driver Class Initialized
INFO - 2023-07-30 16:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:23:59 --> Parser Class Initialized
INFO - 2023-07-30 16:23:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:23:59 --> Pagination Class Initialized
INFO - 2023-07-30 16:23:59 --> Form Validation Class Initialized
INFO - 2023-07-30 16:23:59 --> Controller Class Initialized
DEBUG - 2023-07-30 16:23:59 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:23:59 --> Model Class Initialized
INFO - 2023-07-30 16:23:59 --> Model Class Initialized
INFO - 2023-07-30 16:23:59 --> Final output sent to browser
DEBUG - 2023-07-30 16:23:59 --> Total execution time: 0.0463
ERROR - 2023-07-30 16:24:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:24:08 --> Config Class Initialized
INFO - 2023-07-30 16:24:08 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:24:08 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:24:08 --> Utf8 Class Initialized
INFO - 2023-07-30 16:24:08 --> URI Class Initialized
INFO - 2023-07-30 16:24:08 --> Router Class Initialized
INFO - 2023-07-30 16:24:08 --> Output Class Initialized
INFO - 2023-07-30 16:24:08 --> Security Class Initialized
DEBUG - 2023-07-30 16:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:24:08 --> Input Class Initialized
INFO - 2023-07-30 16:24:08 --> Language Class Initialized
INFO - 2023-07-30 16:24:08 --> Loader Class Initialized
INFO - 2023-07-30 16:24:08 --> Helper loaded: url_helper
INFO - 2023-07-30 16:24:08 --> Helper loaded: file_helper
INFO - 2023-07-30 16:24:08 --> Helper loaded: html_helper
INFO - 2023-07-30 16:24:08 --> Helper loaded: text_helper
INFO - 2023-07-30 16:24:08 --> Helper loaded: form_helper
INFO - 2023-07-30 16:24:08 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:24:08 --> Helper loaded: security_helper
INFO - 2023-07-30 16:24:08 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:24:08 --> Database Driver Class Initialized
INFO - 2023-07-30 16:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:24:08 --> Parser Class Initialized
INFO - 2023-07-30 16:24:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:24:08 --> Pagination Class Initialized
INFO - 2023-07-30 16:24:08 --> Form Validation Class Initialized
INFO - 2023-07-30 16:24:08 --> Controller Class Initialized
DEBUG - 2023-07-30 16:24:08 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:24:08 --> Model Class Initialized
INFO - 2023-07-30 16:24:08 --> Model Class Initialized
INFO - 2023-07-30 16:24:08 --> Model Class Initialized
INFO - 2023-07-30 16:24:08 --> Model Class Initialized
INFO - 2023-07-30 16:24:08 --> Model Class Initialized
INFO - 2023-07-30 16:24:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/edit_product_form.php
DEBUG - 2023-07-30 16:24:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:24:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:24:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:24:08 --> Model Class Initialized
INFO - 2023-07-30 16:24:08 --> Model Class Initialized
INFO - 2023-07-30 16:24:08 --> Model Class Initialized
INFO - 2023-07-30 16:24:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:24:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:24:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:24:08 --> Final output sent to browser
DEBUG - 2023-07-30 16:24:08 --> Total execution time: 0.1529
ERROR - 2023-07-30 16:24:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:24:24 --> Config Class Initialized
INFO - 2023-07-30 16:24:24 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:24:24 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:24:24 --> Utf8 Class Initialized
INFO - 2023-07-30 16:24:24 --> URI Class Initialized
INFO - 2023-07-30 16:24:24 --> Router Class Initialized
INFO - 2023-07-30 16:24:24 --> Output Class Initialized
INFO - 2023-07-30 16:24:24 --> Security Class Initialized
DEBUG - 2023-07-30 16:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:24:24 --> Input Class Initialized
INFO - 2023-07-30 16:24:24 --> Language Class Initialized
INFO - 2023-07-30 16:24:24 --> Loader Class Initialized
INFO - 2023-07-30 16:24:24 --> Helper loaded: url_helper
INFO - 2023-07-30 16:24:24 --> Helper loaded: file_helper
INFO - 2023-07-30 16:24:24 --> Helper loaded: html_helper
INFO - 2023-07-30 16:24:24 --> Helper loaded: text_helper
INFO - 2023-07-30 16:24:24 --> Helper loaded: form_helper
INFO - 2023-07-30 16:24:24 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:24:24 --> Helper loaded: security_helper
INFO - 2023-07-30 16:24:24 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:24:24 --> Database Driver Class Initialized
INFO - 2023-07-30 16:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:24:24 --> Parser Class Initialized
INFO - 2023-07-30 16:24:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:24:24 --> Pagination Class Initialized
INFO - 2023-07-30 16:24:24 --> Form Validation Class Initialized
INFO - 2023-07-30 16:24:24 --> Controller Class Initialized
INFO - 2023-07-30 16:24:24 --> Model Class Initialized
INFO - 2023-07-30 16:24:24 --> Model Class Initialized
INFO - 2023-07-30 16:24:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-07-30 16:24:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:24:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:24:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:24:24 --> Model Class Initialized
INFO - 2023-07-30 16:24:24 --> Model Class Initialized
INFO - 2023-07-30 16:24:24 --> Model Class Initialized
INFO - 2023-07-30 16:24:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:24:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:24:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:24:24 --> Final output sent to browser
DEBUG - 2023-07-30 16:24:24 --> Total execution time: 0.1404
ERROR - 2023-07-30 16:24:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:24:25 --> Config Class Initialized
INFO - 2023-07-30 16:24:25 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:24:25 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:24:25 --> Utf8 Class Initialized
INFO - 2023-07-30 16:24:25 --> URI Class Initialized
INFO - 2023-07-30 16:24:25 --> Router Class Initialized
INFO - 2023-07-30 16:24:25 --> Output Class Initialized
INFO - 2023-07-30 16:24:25 --> Security Class Initialized
DEBUG - 2023-07-30 16:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:24:25 --> Input Class Initialized
INFO - 2023-07-30 16:24:25 --> Language Class Initialized
INFO - 2023-07-30 16:24:25 --> Loader Class Initialized
INFO - 2023-07-30 16:24:25 --> Helper loaded: url_helper
INFO - 2023-07-30 16:24:25 --> Helper loaded: file_helper
INFO - 2023-07-30 16:24:25 --> Helper loaded: html_helper
INFO - 2023-07-30 16:24:25 --> Helper loaded: text_helper
INFO - 2023-07-30 16:24:25 --> Helper loaded: form_helper
INFO - 2023-07-30 16:24:25 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:24:25 --> Helper loaded: security_helper
INFO - 2023-07-30 16:24:25 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:24:25 --> Database Driver Class Initialized
INFO - 2023-07-30 16:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:24:25 --> Parser Class Initialized
INFO - 2023-07-30 16:24:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:24:25 --> Pagination Class Initialized
INFO - 2023-07-30 16:24:25 --> Form Validation Class Initialized
INFO - 2023-07-30 16:24:25 --> Controller Class Initialized
INFO - 2023-07-30 16:24:25 --> Model Class Initialized
INFO - 2023-07-30 16:24:25 --> Model Class Initialized
INFO - 2023-07-30 16:24:25 --> Final output sent to browser
DEBUG - 2023-07-30 16:24:25 --> Total execution time: 0.0426
ERROR - 2023-07-30 16:24:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:24:28 --> Config Class Initialized
INFO - 2023-07-30 16:24:28 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:24:28 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:24:28 --> Utf8 Class Initialized
INFO - 2023-07-30 16:24:28 --> URI Class Initialized
INFO - 2023-07-30 16:24:28 --> Router Class Initialized
INFO - 2023-07-30 16:24:29 --> Output Class Initialized
INFO - 2023-07-30 16:24:29 --> Security Class Initialized
DEBUG - 2023-07-30 16:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:24:29 --> Input Class Initialized
INFO - 2023-07-30 16:24:29 --> Language Class Initialized
INFO - 2023-07-30 16:24:29 --> Loader Class Initialized
INFO - 2023-07-30 16:24:29 --> Helper loaded: url_helper
INFO - 2023-07-30 16:24:29 --> Helper loaded: file_helper
INFO - 2023-07-30 16:24:29 --> Helper loaded: html_helper
INFO - 2023-07-30 16:24:29 --> Helper loaded: text_helper
INFO - 2023-07-30 16:24:29 --> Helper loaded: form_helper
INFO - 2023-07-30 16:24:29 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:24:29 --> Helper loaded: security_helper
INFO - 2023-07-30 16:24:29 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:24:29 --> Database Driver Class Initialized
INFO - 2023-07-30 16:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:24:29 --> Parser Class Initialized
INFO - 2023-07-30 16:24:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:24:29 --> Pagination Class Initialized
INFO - 2023-07-30 16:24:29 --> Form Validation Class Initialized
INFO - 2023-07-30 16:24:29 --> Controller Class Initialized
INFO - 2023-07-30 16:24:29 --> Model Class Initialized
INFO - 2023-07-30 16:24:29 --> Model Class Initialized
INFO - 2023-07-30 16:24:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2023-07-30 16:24:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:24:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:24:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:24:29 --> Model Class Initialized
INFO - 2023-07-30 16:24:29 --> Model Class Initialized
INFO - 2023-07-30 16:24:29 --> Model Class Initialized
INFO - 2023-07-30 16:24:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:24:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:24:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:24:29 --> Final output sent to browser
DEBUG - 2023-07-30 16:24:29 --> Total execution time: 0.1609
ERROR - 2023-07-30 16:24:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:24:48 --> Config Class Initialized
INFO - 2023-07-30 16:24:48 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:24:48 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:24:48 --> Utf8 Class Initialized
INFO - 2023-07-30 16:24:48 --> URI Class Initialized
INFO - 2023-07-30 16:24:48 --> Router Class Initialized
INFO - 2023-07-30 16:24:48 --> Output Class Initialized
INFO - 2023-07-30 16:24:48 --> Security Class Initialized
DEBUG - 2023-07-30 16:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:24:48 --> Input Class Initialized
INFO - 2023-07-30 16:24:48 --> Language Class Initialized
INFO - 2023-07-30 16:24:48 --> Loader Class Initialized
INFO - 2023-07-30 16:24:48 --> Helper loaded: url_helper
INFO - 2023-07-30 16:24:48 --> Helper loaded: file_helper
INFO - 2023-07-30 16:24:48 --> Helper loaded: html_helper
INFO - 2023-07-30 16:24:48 --> Helper loaded: text_helper
INFO - 2023-07-30 16:24:48 --> Helper loaded: form_helper
INFO - 2023-07-30 16:24:48 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:24:48 --> Helper loaded: security_helper
INFO - 2023-07-30 16:24:48 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:24:48 --> Database Driver Class Initialized
INFO - 2023-07-30 16:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:24:48 --> Parser Class Initialized
INFO - 2023-07-30 16:24:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:24:48 --> Pagination Class Initialized
INFO - 2023-07-30 16:24:48 --> Form Validation Class Initialized
INFO - 2023-07-30 16:24:48 --> Controller Class Initialized
DEBUG - 2023-07-30 16:24:48 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:24:48 --> Model Class Initialized
INFO - 2023-07-30 16:24:48 --> Model Class Initialized
INFO - 2023-07-30 16:24:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/add_type_form.php
DEBUG - 2023-07-30 16:24:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:24:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:24:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:24:48 --> Model Class Initialized
INFO - 2023-07-30 16:24:48 --> Model Class Initialized
INFO - 2023-07-30 16:24:48 --> Model Class Initialized
INFO - 2023-07-30 16:24:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:24:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:24:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:24:49 --> Final output sent to browser
DEBUG - 2023-07-30 16:24:49 --> Total execution time: 0.1587
ERROR - 2023-07-30 16:25:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:25:02 --> Config Class Initialized
INFO - 2023-07-30 16:25:02 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:25:02 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:25:02 --> Utf8 Class Initialized
INFO - 2023-07-30 16:25:02 --> URI Class Initialized
INFO - 2023-07-30 16:25:02 --> Router Class Initialized
INFO - 2023-07-30 16:25:02 --> Output Class Initialized
INFO - 2023-07-30 16:25:02 --> Security Class Initialized
DEBUG - 2023-07-30 16:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:25:02 --> Input Class Initialized
INFO - 2023-07-30 16:25:02 --> Language Class Initialized
INFO - 2023-07-30 16:25:02 --> Loader Class Initialized
INFO - 2023-07-30 16:25:02 --> Helper loaded: url_helper
INFO - 2023-07-30 16:25:02 --> Helper loaded: file_helper
INFO - 2023-07-30 16:25:02 --> Helper loaded: html_helper
INFO - 2023-07-30 16:25:02 --> Helper loaded: text_helper
INFO - 2023-07-30 16:25:02 --> Helper loaded: form_helper
INFO - 2023-07-30 16:25:02 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:25:02 --> Helper loaded: security_helper
INFO - 2023-07-30 16:25:02 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:25:02 --> Database Driver Class Initialized
INFO - 2023-07-30 16:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:25:02 --> Parser Class Initialized
INFO - 2023-07-30 16:25:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:25:02 --> Pagination Class Initialized
INFO - 2023-07-30 16:25:02 --> Form Validation Class Initialized
INFO - 2023-07-30 16:25:02 --> Controller Class Initialized
INFO - 2023-07-30 16:25:02 --> Model Class Initialized
INFO - 2023-07-30 16:25:02 --> Model Class Initialized
INFO - 2023-07-30 16:25:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase.php
DEBUG - 2023-07-30 16:25:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:25:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:25:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:25:02 --> Model Class Initialized
INFO - 2023-07-30 16:25:02 --> Model Class Initialized
INFO - 2023-07-30 16:25:02 --> Model Class Initialized
INFO - 2023-07-30 16:25:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:25:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:25:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:25:02 --> Final output sent to browser
DEBUG - 2023-07-30 16:25:02 --> Total execution time: 0.1607
ERROR - 2023-07-30 16:25:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:25:03 --> Config Class Initialized
INFO - 2023-07-30 16:25:03 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:25:03 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:25:03 --> Utf8 Class Initialized
INFO - 2023-07-30 16:25:03 --> URI Class Initialized
INFO - 2023-07-30 16:25:03 --> Router Class Initialized
INFO - 2023-07-30 16:25:03 --> Output Class Initialized
INFO - 2023-07-30 16:25:03 --> Security Class Initialized
DEBUG - 2023-07-30 16:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:25:03 --> Input Class Initialized
INFO - 2023-07-30 16:25:03 --> Language Class Initialized
INFO - 2023-07-30 16:25:03 --> Loader Class Initialized
INFO - 2023-07-30 16:25:03 --> Helper loaded: url_helper
INFO - 2023-07-30 16:25:03 --> Helper loaded: file_helper
INFO - 2023-07-30 16:25:03 --> Helper loaded: html_helper
INFO - 2023-07-30 16:25:03 --> Helper loaded: text_helper
INFO - 2023-07-30 16:25:03 --> Helper loaded: form_helper
INFO - 2023-07-30 16:25:03 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:25:03 --> Helper loaded: security_helper
INFO - 2023-07-30 16:25:03 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:25:03 --> Database Driver Class Initialized
INFO - 2023-07-30 16:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:25:03 --> Parser Class Initialized
INFO - 2023-07-30 16:25:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:25:03 --> Pagination Class Initialized
INFO - 2023-07-30 16:25:03 --> Form Validation Class Initialized
INFO - 2023-07-30 16:25:03 --> Controller Class Initialized
INFO - 2023-07-30 16:25:03 --> Model Class Initialized
INFO - 2023-07-30 16:25:03 --> Model Class Initialized
INFO - 2023-07-30 16:25:03 --> Final output sent to browser
DEBUG - 2023-07-30 16:25:03 --> Total execution time: 0.0470
ERROR - 2023-07-30 16:25:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:25:09 --> Config Class Initialized
INFO - 2023-07-30 16:25:09 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:25:09 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:25:09 --> Utf8 Class Initialized
INFO - 2023-07-30 16:25:09 --> URI Class Initialized
INFO - 2023-07-30 16:25:09 --> Router Class Initialized
INFO - 2023-07-30 16:25:09 --> Output Class Initialized
INFO - 2023-07-30 16:25:09 --> Security Class Initialized
DEBUG - 2023-07-30 16:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:25:09 --> Input Class Initialized
INFO - 2023-07-30 16:25:09 --> Language Class Initialized
INFO - 2023-07-30 16:25:09 --> Loader Class Initialized
INFO - 2023-07-30 16:25:09 --> Helper loaded: url_helper
INFO - 2023-07-30 16:25:09 --> Helper loaded: file_helper
INFO - 2023-07-30 16:25:09 --> Helper loaded: html_helper
INFO - 2023-07-30 16:25:09 --> Helper loaded: text_helper
INFO - 2023-07-30 16:25:09 --> Helper loaded: form_helper
INFO - 2023-07-30 16:25:09 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:25:09 --> Helper loaded: security_helper
INFO - 2023-07-30 16:25:09 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:25:09 --> Database Driver Class Initialized
INFO - 2023-07-30 16:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:25:09 --> Parser Class Initialized
INFO - 2023-07-30 16:25:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:25:09 --> Pagination Class Initialized
INFO - 2023-07-30 16:25:09 --> Form Validation Class Initialized
INFO - 2023-07-30 16:25:09 --> Controller Class Initialized
INFO - 2023-07-30 16:25:09 --> Model Class Initialized
INFO - 2023-07-30 16:25:09 --> Model Class Initialized
DEBUG - 2023-07-30 16:25:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:25:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:25:09 --> Model Class Initialized
DEBUG - 2023-07-30 16:25:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:25:09 --> Model Class Initialized
INFO - 2023-07-30 16:25:09 --> Model Class Initialized
ERROR - 2023-07-30 16:25:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/views/purchase/edit_purchase_form.php 148
INFO - 2023-07-30 16:25:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/edit_purchase_form.php
DEBUG - 2023-07-30 16:25:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:25:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:25:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:25:09 --> Model Class Initialized
INFO - 2023-07-30 16:25:09 --> Model Class Initialized
INFO - 2023-07-30 16:25:09 --> Model Class Initialized
INFO - 2023-07-30 16:25:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:25:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:25:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:25:09 --> Final output sent to browser
DEBUG - 2023-07-30 16:25:09 --> Total execution time: 0.1878
ERROR - 2023-07-30 16:25:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:25:33 --> Config Class Initialized
INFO - 2023-07-30 16:25:33 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:25:33 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:25:33 --> Utf8 Class Initialized
INFO - 2023-07-30 16:25:33 --> URI Class Initialized
INFO - 2023-07-30 16:25:33 --> Router Class Initialized
INFO - 2023-07-30 16:25:33 --> Output Class Initialized
INFO - 2023-07-30 16:25:33 --> Security Class Initialized
DEBUG - 2023-07-30 16:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:25:33 --> Input Class Initialized
INFO - 2023-07-30 16:25:33 --> Language Class Initialized
INFO - 2023-07-30 16:25:33 --> Loader Class Initialized
INFO - 2023-07-30 16:25:33 --> Helper loaded: url_helper
INFO - 2023-07-30 16:25:33 --> Helper loaded: file_helper
INFO - 2023-07-30 16:25:33 --> Helper loaded: html_helper
INFO - 2023-07-30 16:25:33 --> Helper loaded: text_helper
INFO - 2023-07-30 16:25:33 --> Helper loaded: form_helper
INFO - 2023-07-30 16:25:33 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:25:33 --> Helper loaded: security_helper
INFO - 2023-07-30 16:25:33 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:25:33 --> Database Driver Class Initialized
INFO - 2023-07-30 16:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:25:33 --> Parser Class Initialized
INFO - 2023-07-30 16:25:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:25:33 --> Pagination Class Initialized
INFO - 2023-07-30 16:25:33 --> Form Validation Class Initialized
INFO - 2023-07-30 16:25:33 --> Controller Class Initialized
INFO - 2023-07-30 16:25:33 --> Model Class Initialized
ERROR - 2023-07-30 16:25:33 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('20230330174827', 'Purchase', '2023-03-30', NULL, 'Purchase No.20230330174827', 0, '74312.00', 1, '1', '2023-07-30', 1)
ERROR - 2023-07-30 16:25:33 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('20230330174827', 'Purchase', '2023-03-30', NULL, 'Purchase No.20230330174827', '74312.00', 0, 1, '1', '2023-07-30', 1)
ERROR - 2023-07-30 16:25:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:25:33 --> Config Class Initialized
INFO - 2023-07-30 16:25:33 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:25:33 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:25:33 --> Utf8 Class Initialized
INFO - 2023-07-30 16:25:33 --> URI Class Initialized
INFO - 2023-07-30 16:25:33 --> Router Class Initialized
INFO - 2023-07-30 16:25:33 --> Output Class Initialized
INFO - 2023-07-30 16:25:33 --> Security Class Initialized
DEBUG - 2023-07-30 16:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:25:33 --> Input Class Initialized
INFO - 2023-07-30 16:25:33 --> Language Class Initialized
INFO - 2023-07-30 16:25:33 --> Loader Class Initialized
INFO - 2023-07-30 16:25:33 --> Helper loaded: url_helper
INFO - 2023-07-30 16:25:33 --> Helper loaded: file_helper
INFO - 2023-07-30 16:25:33 --> Helper loaded: html_helper
INFO - 2023-07-30 16:25:33 --> Helper loaded: text_helper
INFO - 2023-07-30 16:25:33 --> Helper loaded: form_helper
INFO - 2023-07-30 16:25:33 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:25:33 --> Helper loaded: security_helper
INFO - 2023-07-30 16:25:33 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:25:33 --> Database Driver Class Initialized
INFO - 2023-07-30 16:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:25:33 --> Parser Class Initialized
INFO - 2023-07-30 16:25:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:25:33 --> Pagination Class Initialized
INFO - 2023-07-30 16:25:33 --> Form Validation Class Initialized
INFO - 2023-07-30 16:25:33 --> Controller Class Initialized
INFO - 2023-07-30 16:25:33 --> Model Class Initialized
INFO - 2023-07-30 16:25:33 --> Model Class Initialized
INFO - 2023-07-30 16:25:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/purchase/purchase_html.php
DEBUG - 2023-07-30 16:25:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:25:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:25:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:25:33 --> Model Class Initialized
INFO - 2023-07-30 16:25:33 --> Model Class Initialized
INFO - 2023-07-30 16:25:33 --> Model Class Initialized
INFO - 2023-07-30 16:25:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:25:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:25:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:25:33 --> Final output sent to browser
DEBUG - 2023-07-30 16:25:33 --> Total execution time: 0.1656
ERROR - 2023-07-30 16:25:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:25:42 --> Config Class Initialized
INFO - 2023-07-30 16:25:42 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:25:42 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:25:42 --> Utf8 Class Initialized
INFO - 2023-07-30 16:25:42 --> URI Class Initialized
INFO - 2023-07-30 16:25:42 --> Router Class Initialized
INFO - 2023-07-30 16:25:42 --> Output Class Initialized
INFO - 2023-07-30 16:25:42 --> Security Class Initialized
DEBUG - 2023-07-30 16:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:25:42 --> Input Class Initialized
INFO - 2023-07-30 16:25:42 --> Language Class Initialized
INFO - 2023-07-30 16:25:42 --> Loader Class Initialized
INFO - 2023-07-30 16:25:42 --> Helper loaded: url_helper
INFO - 2023-07-30 16:25:42 --> Helper loaded: file_helper
INFO - 2023-07-30 16:25:42 --> Helper loaded: html_helper
INFO - 2023-07-30 16:25:42 --> Helper loaded: text_helper
INFO - 2023-07-30 16:25:42 --> Helper loaded: form_helper
INFO - 2023-07-30 16:25:42 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:25:42 --> Helper loaded: security_helper
INFO - 2023-07-30 16:25:42 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:25:42 --> Database Driver Class Initialized
INFO - 2023-07-30 16:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:25:42 --> Parser Class Initialized
INFO - 2023-07-30 16:25:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:25:42 --> Pagination Class Initialized
INFO - 2023-07-30 16:25:42 --> Form Validation Class Initialized
INFO - 2023-07-30 16:25:42 --> Controller Class Initialized
INFO - 2023-07-30 16:25:42 --> Model Class Initialized
INFO - 2023-07-30 16:25:42 --> Model Class Initialized
INFO - 2023-07-30 16:25:42 --> Model Class Initialized
INFO - 2023-07-30 16:25:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-07-30 16:25:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:25:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:25:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:25:42 --> Model Class Initialized
INFO - 2023-07-30 16:25:42 --> Model Class Initialized
INFO - 2023-07-30 16:25:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:25:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:25:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:25:42 --> Final output sent to browser
DEBUG - 2023-07-30 16:25:42 --> Total execution time: 0.1419
ERROR - 2023-07-30 16:25:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:25:43 --> Config Class Initialized
INFO - 2023-07-30 16:25:43 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:25:43 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:25:43 --> Utf8 Class Initialized
INFO - 2023-07-30 16:25:43 --> URI Class Initialized
INFO - 2023-07-30 16:25:43 --> Router Class Initialized
INFO - 2023-07-30 16:25:43 --> Output Class Initialized
INFO - 2023-07-30 16:25:43 --> Security Class Initialized
DEBUG - 2023-07-30 16:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:25:43 --> Input Class Initialized
INFO - 2023-07-30 16:25:43 --> Language Class Initialized
INFO - 2023-07-30 16:25:43 --> Loader Class Initialized
INFO - 2023-07-30 16:25:43 --> Helper loaded: url_helper
INFO - 2023-07-30 16:25:43 --> Helper loaded: file_helper
INFO - 2023-07-30 16:25:43 --> Helper loaded: html_helper
INFO - 2023-07-30 16:25:43 --> Helper loaded: text_helper
INFO - 2023-07-30 16:25:43 --> Helper loaded: form_helper
INFO - 2023-07-30 16:25:43 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:25:43 --> Helper loaded: security_helper
INFO - 2023-07-30 16:25:43 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:25:43 --> Database Driver Class Initialized
INFO - 2023-07-30 16:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:25:43 --> Parser Class Initialized
INFO - 2023-07-30 16:25:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:25:43 --> Pagination Class Initialized
INFO - 2023-07-30 16:25:43 --> Form Validation Class Initialized
INFO - 2023-07-30 16:25:43 --> Controller Class Initialized
INFO - 2023-07-30 16:25:43 --> Model Class Initialized
INFO - 2023-07-30 16:25:43 --> Model Class Initialized
INFO - 2023-07-30 16:25:43 --> Final output sent to browser
DEBUG - 2023-07-30 16:25:43 --> Total execution time: 0.0288
ERROR - 2023-07-30 16:25:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:25:45 --> Config Class Initialized
INFO - 2023-07-30 16:25:45 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:25:45 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:25:45 --> Utf8 Class Initialized
INFO - 2023-07-30 16:25:45 --> URI Class Initialized
INFO - 2023-07-30 16:25:45 --> Router Class Initialized
INFO - 2023-07-30 16:25:45 --> Output Class Initialized
INFO - 2023-07-30 16:25:45 --> Security Class Initialized
DEBUG - 2023-07-30 16:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:25:45 --> Input Class Initialized
INFO - 2023-07-30 16:25:45 --> Language Class Initialized
INFO - 2023-07-30 16:25:45 --> Loader Class Initialized
INFO - 2023-07-30 16:25:45 --> Helper loaded: url_helper
INFO - 2023-07-30 16:25:45 --> Helper loaded: file_helper
INFO - 2023-07-30 16:25:45 --> Helper loaded: html_helper
INFO - 2023-07-30 16:25:45 --> Helper loaded: text_helper
INFO - 2023-07-30 16:25:45 --> Helper loaded: form_helper
INFO - 2023-07-30 16:25:45 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:25:45 --> Helper loaded: security_helper
INFO - 2023-07-30 16:25:45 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:25:45 --> Database Driver Class Initialized
INFO - 2023-07-30 16:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:25:45 --> Parser Class Initialized
INFO - 2023-07-30 16:25:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:25:45 --> Pagination Class Initialized
INFO - 2023-07-30 16:25:45 --> Form Validation Class Initialized
INFO - 2023-07-30 16:25:45 --> Controller Class Initialized
DEBUG - 2023-07-30 16:25:45 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:25:45 --> Model Class Initialized
INFO - 2023-07-30 16:25:45 --> Model Class Initialized
INFO - 2023-07-30 16:25:45 --> Model Class Initialized
INFO - 2023-07-30 16:25:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-07-30 16:25:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:25:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:25:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:25:45 --> Model Class Initialized
INFO - 2023-07-30 16:25:45 --> Model Class Initialized
INFO - 2023-07-30 16:25:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:25:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:25:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:25:45 --> Final output sent to browser
DEBUG - 2023-07-30 16:25:45 --> Total execution time: 0.1660
ERROR - 2023-07-30 16:26:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:26:10 --> Config Class Initialized
INFO - 2023-07-30 16:26:10 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:26:10 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:26:10 --> Utf8 Class Initialized
INFO - 2023-07-30 16:26:10 --> URI Class Initialized
DEBUG - 2023-07-30 16:26:10 --> No URI present. Default controller set.
INFO - 2023-07-30 16:26:10 --> Router Class Initialized
INFO - 2023-07-30 16:26:10 --> Output Class Initialized
INFO - 2023-07-30 16:26:10 --> Security Class Initialized
DEBUG - 2023-07-30 16:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:26:10 --> Input Class Initialized
INFO - 2023-07-30 16:26:10 --> Language Class Initialized
INFO - 2023-07-30 16:26:10 --> Loader Class Initialized
INFO - 2023-07-30 16:26:10 --> Helper loaded: url_helper
INFO - 2023-07-30 16:26:10 --> Helper loaded: file_helper
INFO - 2023-07-30 16:26:10 --> Helper loaded: html_helper
INFO - 2023-07-30 16:26:10 --> Helper loaded: text_helper
INFO - 2023-07-30 16:26:10 --> Helper loaded: form_helper
INFO - 2023-07-30 16:26:10 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:26:10 --> Helper loaded: security_helper
INFO - 2023-07-30 16:26:10 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:26:10 --> Database Driver Class Initialized
INFO - 2023-07-30 16:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:26:10 --> Parser Class Initialized
INFO - 2023-07-30 16:26:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:26:10 --> Pagination Class Initialized
INFO - 2023-07-30 16:26:10 --> Form Validation Class Initialized
INFO - 2023-07-30 16:26:10 --> Controller Class Initialized
INFO - 2023-07-30 16:26:10 --> Model Class Initialized
DEBUG - 2023-07-30 16:26:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-30 16:26:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:26:10 --> Config Class Initialized
INFO - 2023-07-30 16:26:10 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:26:10 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:26:10 --> Utf8 Class Initialized
INFO - 2023-07-30 16:26:10 --> URI Class Initialized
INFO - 2023-07-30 16:26:10 --> Router Class Initialized
INFO - 2023-07-30 16:26:10 --> Output Class Initialized
INFO - 2023-07-30 16:26:10 --> Security Class Initialized
DEBUG - 2023-07-30 16:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:26:10 --> Input Class Initialized
INFO - 2023-07-30 16:26:10 --> Language Class Initialized
INFO - 2023-07-30 16:26:10 --> Loader Class Initialized
INFO - 2023-07-30 16:26:10 --> Helper loaded: url_helper
INFO - 2023-07-30 16:26:10 --> Helper loaded: file_helper
INFO - 2023-07-30 16:26:10 --> Helper loaded: html_helper
INFO - 2023-07-30 16:26:10 --> Helper loaded: text_helper
INFO - 2023-07-30 16:26:10 --> Helper loaded: form_helper
INFO - 2023-07-30 16:26:10 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:26:10 --> Helper loaded: security_helper
INFO - 2023-07-30 16:26:10 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:26:10 --> Database Driver Class Initialized
INFO - 2023-07-30 16:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:26:10 --> Parser Class Initialized
INFO - 2023-07-30 16:26:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:26:10 --> Pagination Class Initialized
INFO - 2023-07-30 16:26:10 --> Form Validation Class Initialized
INFO - 2023-07-30 16:26:10 --> Controller Class Initialized
INFO - 2023-07-30 16:26:10 --> Model Class Initialized
DEBUG - 2023-07-30 16:26:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:26:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-30 16:26:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:26:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:26:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:26:10 --> Model Class Initialized
INFO - 2023-07-30 16:26:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:26:10 --> Final output sent to browser
DEBUG - 2023-07-30 16:26:10 --> Total execution time: 0.0306
ERROR - 2023-07-30 16:26:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:26:31 --> Config Class Initialized
INFO - 2023-07-30 16:26:31 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:26:31 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:26:31 --> Utf8 Class Initialized
INFO - 2023-07-30 16:26:31 --> URI Class Initialized
INFO - 2023-07-30 16:26:31 --> Router Class Initialized
INFO - 2023-07-30 16:26:31 --> Output Class Initialized
INFO - 2023-07-30 16:26:31 --> Security Class Initialized
DEBUG - 2023-07-30 16:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:26:31 --> Input Class Initialized
INFO - 2023-07-30 16:26:31 --> Language Class Initialized
INFO - 2023-07-30 16:26:31 --> Loader Class Initialized
INFO - 2023-07-30 16:26:31 --> Helper loaded: url_helper
INFO - 2023-07-30 16:26:31 --> Helper loaded: file_helper
INFO - 2023-07-30 16:26:31 --> Helper loaded: html_helper
INFO - 2023-07-30 16:26:31 --> Helper loaded: text_helper
INFO - 2023-07-30 16:26:31 --> Helper loaded: form_helper
INFO - 2023-07-30 16:26:31 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:26:31 --> Helper loaded: security_helper
INFO - 2023-07-30 16:26:31 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:26:31 --> Database Driver Class Initialized
INFO - 2023-07-30 16:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:26:31 --> Parser Class Initialized
INFO - 2023-07-30 16:26:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:26:31 --> Pagination Class Initialized
INFO - 2023-07-30 16:26:31 --> Form Validation Class Initialized
INFO - 2023-07-30 16:26:31 --> Controller Class Initialized
INFO - 2023-07-30 16:26:31 --> Model Class Initialized
DEBUG - 2023-07-30 16:26:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:26:31 --> Model Class Initialized
INFO - 2023-07-30 16:26:31 --> Final output sent to browser
DEBUG - 2023-07-30 16:26:31 --> Total execution time: 0.0211
ERROR - 2023-07-30 16:26:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:26:31 --> Config Class Initialized
INFO - 2023-07-30 16:26:31 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:26:31 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:26:31 --> Utf8 Class Initialized
INFO - 2023-07-30 16:26:31 --> URI Class Initialized
DEBUG - 2023-07-30 16:26:31 --> No URI present. Default controller set.
INFO - 2023-07-30 16:26:31 --> Router Class Initialized
INFO - 2023-07-30 16:26:31 --> Output Class Initialized
INFO - 2023-07-30 16:26:31 --> Security Class Initialized
DEBUG - 2023-07-30 16:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:26:31 --> Input Class Initialized
INFO - 2023-07-30 16:26:31 --> Language Class Initialized
INFO - 2023-07-30 16:26:31 --> Loader Class Initialized
INFO - 2023-07-30 16:26:31 --> Helper loaded: url_helper
INFO - 2023-07-30 16:26:31 --> Helper loaded: file_helper
INFO - 2023-07-30 16:26:31 --> Helper loaded: html_helper
INFO - 2023-07-30 16:26:31 --> Helper loaded: text_helper
INFO - 2023-07-30 16:26:31 --> Helper loaded: form_helper
INFO - 2023-07-30 16:26:31 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:26:31 --> Helper loaded: security_helper
INFO - 2023-07-30 16:26:31 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:26:31 --> Database Driver Class Initialized
INFO - 2023-07-30 16:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:26:31 --> Parser Class Initialized
INFO - 2023-07-30 16:26:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:26:31 --> Pagination Class Initialized
INFO - 2023-07-30 16:26:31 --> Form Validation Class Initialized
INFO - 2023-07-30 16:26:31 --> Controller Class Initialized
INFO - 2023-07-30 16:26:31 --> Model Class Initialized
DEBUG - 2023-07-30 16:26:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:26:31 --> Model Class Initialized
DEBUG - 2023-07-30 16:26:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:26:31 --> Model Class Initialized
INFO - 2023-07-30 16:26:31 --> Model Class Initialized
INFO - 2023-07-30 16:26:31 --> Model Class Initialized
INFO - 2023-07-30 16:26:31 --> Model Class Initialized
DEBUG - 2023-07-30 16:26:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:26:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:26:31 --> Model Class Initialized
INFO - 2023-07-30 16:26:31 --> Model Class Initialized
INFO - 2023-07-30 16:26:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-30 16:26:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:26:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:26:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:26:31 --> Model Class Initialized
INFO - 2023-07-30 16:26:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:26:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:26:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:26:31 --> Final output sent to browser
DEBUG - 2023-07-30 16:26:31 --> Total execution time: 0.0868
ERROR - 2023-07-30 16:26:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:26:40 --> Config Class Initialized
INFO - 2023-07-30 16:26:40 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:26:40 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:26:40 --> Utf8 Class Initialized
INFO - 2023-07-30 16:26:40 --> URI Class Initialized
INFO - 2023-07-30 16:26:40 --> Router Class Initialized
INFO - 2023-07-30 16:26:40 --> Output Class Initialized
INFO - 2023-07-30 16:26:40 --> Security Class Initialized
DEBUG - 2023-07-30 16:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:26:40 --> Input Class Initialized
INFO - 2023-07-30 16:26:40 --> Language Class Initialized
INFO - 2023-07-30 16:26:40 --> Loader Class Initialized
INFO - 2023-07-30 16:26:40 --> Helper loaded: url_helper
INFO - 2023-07-30 16:26:40 --> Helper loaded: file_helper
INFO - 2023-07-30 16:26:40 --> Helper loaded: html_helper
INFO - 2023-07-30 16:26:40 --> Helper loaded: text_helper
INFO - 2023-07-30 16:26:40 --> Helper loaded: form_helper
INFO - 2023-07-30 16:26:40 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:26:40 --> Helper loaded: security_helper
INFO - 2023-07-30 16:26:40 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:26:40 --> Database Driver Class Initialized
INFO - 2023-07-30 16:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:26:40 --> Parser Class Initialized
INFO - 2023-07-30 16:26:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:26:40 --> Pagination Class Initialized
INFO - 2023-07-30 16:26:40 --> Form Validation Class Initialized
INFO - 2023-07-30 16:26:40 --> Controller Class Initialized
INFO - 2023-07-30 16:26:40 --> Model Class Initialized
DEBUG - 2023-07-30 16:26:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:26:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:26:40 --> Model Class Initialized
INFO - 2023-07-30 16:26:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-07-30 16:26:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:26:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:26:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:26:40 --> Model Class Initialized
INFO - 2023-07-30 16:26:40 --> Model Class Initialized
INFO - 2023-07-30 16:26:40 --> Model Class Initialized
INFO - 2023-07-30 16:26:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:26:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:26:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:26:41 --> Final output sent to browser
DEBUG - 2023-07-30 16:26:41 --> Total execution time: 0.0779
ERROR - 2023-07-30 16:26:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:26:41 --> Config Class Initialized
INFO - 2023-07-30 16:26:41 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:26:41 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:26:41 --> Utf8 Class Initialized
INFO - 2023-07-30 16:26:41 --> URI Class Initialized
INFO - 2023-07-30 16:26:41 --> Router Class Initialized
INFO - 2023-07-30 16:26:41 --> Output Class Initialized
INFO - 2023-07-30 16:26:41 --> Security Class Initialized
DEBUG - 2023-07-30 16:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:26:41 --> Input Class Initialized
INFO - 2023-07-30 16:26:41 --> Language Class Initialized
INFO - 2023-07-30 16:26:41 --> Loader Class Initialized
INFO - 2023-07-30 16:26:41 --> Helper loaded: url_helper
INFO - 2023-07-30 16:26:41 --> Helper loaded: file_helper
INFO - 2023-07-30 16:26:41 --> Helper loaded: html_helper
INFO - 2023-07-30 16:26:41 --> Helper loaded: text_helper
INFO - 2023-07-30 16:26:41 --> Helper loaded: form_helper
INFO - 2023-07-30 16:26:41 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:26:41 --> Helper loaded: security_helper
INFO - 2023-07-30 16:26:41 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:26:41 --> Database Driver Class Initialized
INFO - 2023-07-30 16:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:26:41 --> Parser Class Initialized
INFO - 2023-07-30 16:26:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:26:41 --> Pagination Class Initialized
INFO - 2023-07-30 16:26:41 --> Form Validation Class Initialized
INFO - 2023-07-30 16:26:41 --> Controller Class Initialized
INFO - 2023-07-30 16:26:41 --> Model Class Initialized
DEBUG - 2023-07-30 16:26:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:26:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:26:41 --> Model Class Initialized
INFO - 2023-07-30 16:26:41 --> Final output sent to browser
DEBUG - 2023-07-30 16:26:41 --> Total execution time: 0.0199
ERROR - 2023-07-30 16:26:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:26:48 --> Config Class Initialized
INFO - 2023-07-30 16:26:48 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:26:48 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:26:48 --> Utf8 Class Initialized
INFO - 2023-07-30 16:26:48 --> URI Class Initialized
INFO - 2023-07-30 16:26:48 --> Router Class Initialized
INFO - 2023-07-30 16:26:48 --> Output Class Initialized
INFO - 2023-07-30 16:26:48 --> Security Class Initialized
DEBUG - 2023-07-30 16:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:26:48 --> Input Class Initialized
INFO - 2023-07-30 16:26:48 --> Language Class Initialized
INFO - 2023-07-30 16:26:48 --> Loader Class Initialized
INFO - 2023-07-30 16:26:48 --> Helper loaded: url_helper
INFO - 2023-07-30 16:26:48 --> Helper loaded: file_helper
INFO - 2023-07-30 16:26:48 --> Helper loaded: html_helper
INFO - 2023-07-30 16:26:48 --> Helper loaded: text_helper
INFO - 2023-07-30 16:26:48 --> Helper loaded: form_helper
INFO - 2023-07-30 16:26:48 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:26:48 --> Helper loaded: security_helper
INFO - 2023-07-30 16:26:48 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:26:48 --> Database Driver Class Initialized
INFO - 2023-07-30 16:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:26:48 --> Parser Class Initialized
INFO - 2023-07-30 16:26:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:26:48 --> Pagination Class Initialized
INFO - 2023-07-30 16:26:48 --> Form Validation Class Initialized
INFO - 2023-07-30 16:26:48 --> Controller Class Initialized
INFO - 2023-07-30 16:26:48 --> Model Class Initialized
DEBUG - 2023-07-30 16:26:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:26:48 --> Model Class Initialized
INFO - 2023-07-30 16:26:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-07-30 16:26:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:26:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:26:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:26:49 --> Model Class Initialized
INFO - 2023-07-30 16:26:49 --> Model Class Initialized
INFO - 2023-07-30 16:26:49 --> Model Class Initialized
INFO - 2023-07-30 16:26:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:26:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:26:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:26:49 --> Final output sent to browser
DEBUG - 2023-07-30 16:26:49 --> Total execution time: 0.0693
ERROR - 2023-07-30 16:26:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:26:49 --> Config Class Initialized
INFO - 2023-07-30 16:26:49 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:26:49 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:26:49 --> Utf8 Class Initialized
INFO - 2023-07-30 16:26:49 --> URI Class Initialized
INFO - 2023-07-30 16:26:49 --> Router Class Initialized
INFO - 2023-07-30 16:26:49 --> Output Class Initialized
INFO - 2023-07-30 16:26:49 --> Security Class Initialized
DEBUG - 2023-07-30 16:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:26:49 --> Input Class Initialized
INFO - 2023-07-30 16:26:49 --> Language Class Initialized
INFO - 2023-07-30 16:26:49 --> Loader Class Initialized
INFO - 2023-07-30 16:26:49 --> Helper loaded: url_helper
INFO - 2023-07-30 16:26:49 --> Helper loaded: file_helper
INFO - 2023-07-30 16:26:49 --> Helper loaded: html_helper
INFO - 2023-07-30 16:26:49 --> Helper loaded: text_helper
INFO - 2023-07-30 16:26:49 --> Helper loaded: form_helper
INFO - 2023-07-30 16:26:49 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:26:49 --> Helper loaded: security_helper
INFO - 2023-07-30 16:26:49 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:26:49 --> Database Driver Class Initialized
INFO - 2023-07-30 16:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:26:49 --> Parser Class Initialized
INFO - 2023-07-30 16:26:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:26:49 --> Pagination Class Initialized
INFO - 2023-07-30 16:26:49 --> Form Validation Class Initialized
INFO - 2023-07-30 16:26:49 --> Controller Class Initialized
INFO - 2023-07-30 16:26:49 --> Model Class Initialized
DEBUG - 2023-07-30 16:26:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:26:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:26:49 --> Model Class Initialized
INFO - 2023-07-30 16:26:49 --> Final output sent to browser
DEBUG - 2023-07-30 16:26:49 --> Total execution time: 0.0192
ERROR - 2023-07-30 16:26:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:26:53 --> Config Class Initialized
INFO - 2023-07-30 16:26:53 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:26:53 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:26:53 --> Utf8 Class Initialized
INFO - 2023-07-30 16:26:53 --> URI Class Initialized
INFO - 2023-07-30 16:26:53 --> Router Class Initialized
INFO - 2023-07-30 16:26:53 --> Output Class Initialized
INFO - 2023-07-30 16:26:53 --> Security Class Initialized
DEBUG - 2023-07-30 16:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:26:53 --> Input Class Initialized
INFO - 2023-07-30 16:26:53 --> Language Class Initialized
INFO - 2023-07-30 16:26:53 --> Loader Class Initialized
INFO - 2023-07-30 16:26:53 --> Helper loaded: url_helper
INFO - 2023-07-30 16:26:53 --> Helper loaded: file_helper
INFO - 2023-07-30 16:26:53 --> Helper loaded: html_helper
INFO - 2023-07-30 16:26:53 --> Helper loaded: text_helper
INFO - 2023-07-30 16:26:53 --> Helper loaded: form_helper
INFO - 2023-07-30 16:26:53 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:26:53 --> Helper loaded: security_helper
INFO - 2023-07-30 16:26:53 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:26:53 --> Database Driver Class Initialized
INFO - 2023-07-30 16:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:26:53 --> Parser Class Initialized
INFO - 2023-07-30 16:26:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:26:53 --> Pagination Class Initialized
INFO - 2023-07-30 16:26:53 --> Form Validation Class Initialized
INFO - 2023-07-30 16:26:53 --> Controller Class Initialized
INFO - 2023-07-30 16:26:53 --> Model Class Initialized
DEBUG - 2023-07-30 16:26:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:26:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:26:53 --> Model Class Initialized
INFO - 2023-07-30 16:26:53 --> Final output sent to browser
DEBUG - 2023-07-30 16:26:53 --> Total execution time: 0.0211
ERROR - 2023-07-30 16:27:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:27:15 --> Config Class Initialized
INFO - 2023-07-30 16:27:15 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:27:15 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:27:15 --> Utf8 Class Initialized
INFO - 2023-07-30 16:27:15 --> URI Class Initialized
INFO - 2023-07-30 16:27:15 --> Router Class Initialized
INFO - 2023-07-30 16:27:15 --> Output Class Initialized
INFO - 2023-07-30 16:27:15 --> Security Class Initialized
DEBUG - 2023-07-30 16:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:27:15 --> Input Class Initialized
INFO - 2023-07-30 16:27:15 --> Language Class Initialized
INFO - 2023-07-30 16:27:15 --> Loader Class Initialized
INFO - 2023-07-30 16:27:15 --> Helper loaded: url_helper
INFO - 2023-07-30 16:27:15 --> Helper loaded: file_helper
INFO - 2023-07-30 16:27:15 --> Helper loaded: html_helper
INFO - 2023-07-30 16:27:15 --> Helper loaded: text_helper
INFO - 2023-07-30 16:27:15 --> Helper loaded: form_helper
INFO - 2023-07-30 16:27:15 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:27:15 --> Helper loaded: security_helper
INFO - 2023-07-30 16:27:15 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:27:15 --> Database Driver Class Initialized
INFO - 2023-07-30 16:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:27:15 --> Parser Class Initialized
INFO - 2023-07-30 16:27:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:27:15 --> Pagination Class Initialized
INFO - 2023-07-30 16:27:15 --> Form Validation Class Initialized
INFO - 2023-07-30 16:27:15 --> Controller Class Initialized
INFO - 2023-07-30 16:27:15 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:27:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:15 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:15 --> Model Class Initialized
INFO - 2023-07-30 16:27:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-30 16:27:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:27:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:27:15 --> Model Class Initialized
INFO - 2023-07-30 16:27:15 --> Model Class Initialized
INFO - 2023-07-30 16:27:15 --> Model Class Initialized
INFO - 2023-07-30 16:27:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:27:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:27:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:27:15 --> Final output sent to browser
DEBUG - 2023-07-30 16:27:15 --> Total execution time: 0.0826
ERROR - 2023-07-30 16:27:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:27:15 --> Config Class Initialized
INFO - 2023-07-30 16:27:15 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:27:15 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:27:15 --> Utf8 Class Initialized
INFO - 2023-07-30 16:27:15 --> URI Class Initialized
INFO - 2023-07-30 16:27:15 --> Router Class Initialized
INFO - 2023-07-30 16:27:15 --> Output Class Initialized
INFO - 2023-07-30 16:27:15 --> Security Class Initialized
DEBUG - 2023-07-30 16:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:27:15 --> Input Class Initialized
INFO - 2023-07-30 16:27:15 --> Language Class Initialized
INFO - 2023-07-30 16:27:15 --> Loader Class Initialized
INFO - 2023-07-30 16:27:15 --> Helper loaded: url_helper
INFO - 2023-07-30 16:27:15 --> Helper loaded: file_helper
INFO - 2023-07-30 16:27:15 --> Helper loaded: html_helper
INFO - 2023-07-30 16:27:15 --> Helper loaded: text_helper
INFO - 2023-07-30 16:27:15 --> Helper loaded: form_helper
INFO - 2023-07-30 16:27:15 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:27:15 --> Helper loaded: security_helper
INFO - 2023-07-30 16:27:15 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:27:15 --> Database Driver Class Initialized
INFO - 2023-07-30 16:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:27:15 --> Parser Class Initialized
INFO - 2023-07-30 16:27:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:27:15 --> Pagination Class Initialized
INFO - 2023-07-30 16:27:15 --> Form Validation Class Initialized
INFO - 2023-07-30 16:27:15 --> Controller Class Initialized
INFO - 2023-07-30 16:27:15 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:27:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:15 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:15 --> Model Class Initialized
INFO - 2023-07-30 16:27:15 --> Final output sent to browser
DEBUG - 2023-07-30 16:27:15 --> Total execution time: 0.0271
ERROR - 2023-07-30 16:27:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:27:18 --> Config Class Initialized
INFO - 2023-07-30 16:27:18 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:27:18 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:27:18 --> Utf8 Class Initialized
INFO - 2023-07-30 16:27:18 --> URI Class Initialized
INFO - 2023-07-30 16:27:18 --> Router Class Initialized
INFO - 2023-07-30 16:27:18 --> Output Class Initialized
INFO - 2023-07-30 16:27:18 --> Security Class Initialized
DEBUG - 2023-07-30 16:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:27:18 --> Input Class Initialized
INFO - 2023-07-30 16:27:18 --> Language Class Initialized
INFO - 2023-07-30 16:27:18 --> Loader Class Initialized
INFO - 2023-07-30 16:27:18 --> Helper loaded: url_helper
INFO - 2023-07-30 16:27:18 --> Helper loaded: file_helper
INFO - 2023-07-30 16:27:18 --> Helper loaded: html_helper
INFO - 2023-07-30 16:27:18 --> Helper loaded: text_helper
INFO - 2023-07-30 16:27:18 --> Helper loaded: form_helper
INFO - 2023-07-30 16:27:18 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:27:18 --> Helper loaded: security_helper
INFO - 2023-07-30 16:27:18 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:27:18 --> Database Driver Class Initialized
INFO - 2023-07-30 16:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:27:18 --> Parser Class Initialized
INFO - 2023-07-30 16:27:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:27:18 --> Pagination Class Initialized
INFO - 2023-07-30 16:27:18 --> Form Validation Class Initialized
INFO - 2023-07-30 16:27:18 --> Controller Class Initialized
INFO - 2023-07-30 16:27:18 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:27:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:18 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:18 --> Model Class Initialized
INFO - 2023-07-30 16:27:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-30 16:27:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:27:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:27:18 --> Model Class Initialized
INFO - 2023-07-30 16:27:18 --> Model Class Initialized
INFO - 2023-07-30 16:27:18 --> Model Class Initialized
INFO - 2023-07-30 16:27:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:27:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:27:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:27:18 --> Final output sent to browser
DEBUG - 2023-07-30 16:27:18 --> Total execution time: 0.0821
ERROR - 2023-07-30 16:27:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:27:19 --> Config Class Initialized
INFO - 2023-07-30 16:27:19 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:27:19 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:27:19 --> Utf8 Class Initialized
INFO - 2023-07-30 16:27:19 --> URI Class Initialized
INFO - 2023-07-30 16:27:19 --> Router Class Initialized
INFO - 2023-07-30 16:27:19 --> Output Class Initialized
INFO - 2023-07-30 16:27:19 --> Security Class Initialized
DEBUG - 2023-07-30 16:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:27:19 --> Input Class Initialized
INFO - 2023-07-30 16:27:19 --> Language Class Initialized
INFO - 2023-07-30 16:27:19 --> Loader Class Initialized
INFO - 2023-07-30 16:27:19 --> Helper loaded: url_helper
INFO - 2023-07-30 16:27:19 --> Helper loaded: file_helper
INFO - 2023-07-30 16:27:19 --> Helper loaded: html_helper
INFO - 2023-07-30 16:27:19 --> Helper loaded: text_helper
INFO - 2023-07-30 16:27:19 --> Helper loaded: form_helper
INFO - 2023-07-30 16:27:19 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:27:19 --> Helper loaded: security_helper
INFO - 2023-07-30 16:27:19 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:27:19 --> Database Driver Class Initialized
INFO - 2023-07-30 16:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:27:19 --> Parser Class Initialized
INFO - 2023-07-30 16:27:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:27:19 --> Pagination Class Initialized
INFO - 2023-07-30 16:27:19 --> Form Validation Class Initialized
INFO - 2023-07-30 16:27:19 --> Controller Class Initialized
INFO - 2023-07-30 16:27:19 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:27:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:19 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:19 --> Model Class Initialized
INFO - 2023-07-30 16:27:19 --> Final output sent to browser
DEBUG - 2023-07-30 16:27:19 --> Total execution time: 0.0240
ERROR - 2023-07-30 16:27:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:27:21 --> Config Class Initialized
INFO - 2023-07-30 16:27:21 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:27:21 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:27:21 --> Utf8 Class Initialized
INFO - 2023-07-30 16:27:21 --> URI Class Initialized
INFO - 2023-07-30 16:27:21 --> Router Class Initialized
INFO - 2023-07-30 16:27:21 --> Output Class Initialized
INFO - 2023-07-30 16:27:21 --> Security Class Initialized
DEBUG - 2023-07-30 16:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:27:21 --> Input Class Initialized
INFO - 2023-07-30 16:27:21 --> Language Class Initialized
INFO - 2023-07-30 16:27:21 --> Loader Class Initialized
INFO - 2023-07-30 16:27:21 --> Helper loaded: url_helper
INFO - 2023-07-30 16:27:21 --> Helper loaded: file_helper
INFO - 2023-07-30 16:27:21 --> Helper loaded: html_helper
INFO - 2023-07-30 16:27:21 --> Helper loaded: text_helper
INFO - 2023-07-30 16:27:21 --> Helper loaded: form_helper
INFO - 2023-07-30 16:27:21 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:27:21 --> Helper loaded: security_helper
INFO - 2023-07-30 16:27:21 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:27:21 --> Database Driver Class Initialized
INFO - 2023-07-30 16:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:27:21 --> Parser Class Initialized
INFO - 2023-07-30 16:27:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:27:21 --> Pagination Class Initialized
INFO - 2023-07-30 16:27:21 --> Form Validation Class Initialized
INFO - 2023-07-30 16:27:21 --> Controller Class Initialized
INFO - 2023-07-30 16:27:21 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:27:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:21 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:21 --> Model Class Initialized
INFO - 2023-07-30 16:27:21 --> Final output sent to browser
DEBUG - 2023-07-30 16:27:21 --> Total execution time: 0.0289
ERROR - 2023-07-30 16:27:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:27:26 --> Config Class Initialized
INFO - 2023-07-30 16:27:26 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:27:26 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:27:26 --> Utf8 Class Initialized
INFO - 2023-07-30 16:27:26 --> URI Class Initialized
INFO - 2023-07-30 16:27:26 --> Router Class Initialized
INFO - 2023-07-30 16:27:26 --> Output Class Initialized
INFO - 2023-07-30 16:27:26 --> Security Class Initialized
DEBUG - 2023-07-30 16:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:27:26 --> Input Class Initialized
INFO - 2023-07-30 16:27:26 --> Language Class Initialized
INFO - 2023-07-30 16:27:26 --> Loader Class Initialized
INFO - 2023-07-30 16:27:26 --> Helper loaded: url_helper
INFO - 2023-07-30 16:27:26 --> Helper loaded: file_helper
INFO - 2023-07-30 16:27:26 --> Helper loaded: html_helper
INFO - 2023-07-30 16:27:26 --> Helper loaded: text_helper
INFO - 2023-07-30 16:27:26 --> Helper loaded: form_helper
INFO - 2023-07-30 16:27:26 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:27:26 --> Helper loaded: security_helper
INFO - 2023-07-30 16:27:26 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:27:26 --> Database Driver Class Initialized
INFO - 2023-07-30 16:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:27:26 --> Parser Class Initialized
INFO - 2023-07-30 16:27:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:27:26 --> Pagination Class Initialized
INFO - 2023-07-30 16:27:26 --> Form Validation Class Initialized
INFO - 2023-07-30 16:27:26 --> Controller Class Initialized
INFO - 2023-07-30 16:27:26 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:27:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:26 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:26 --> Model Class Initialized
INFO - 2023-07-30 16:27:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-30 16:27:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:27:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:27:26 --> Model Class Initialized
INFO - 2023-07-30 16:27:26 --> Model Class Initialized
INFO - 2023-07-30 16:27:26 --> Model Class Initialized
INFO - 2023-07-30 16:27:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:27:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:27:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:27:26 --> Final output sent to browser
DEBUG - 2023-07-30 16:27:26 --> Total execution time: 0.0806
ERROR - 2023-07-30 16:27:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:27:26 --> Config Class Initialized
INFO - 2023-07-30 16:27:26 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:27:26 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:27:26 --> Utf8 Class Initialized
INFO - 2023-07-30 16:27:26 --> URI Class Initialized
INFO - 2023-07-30 16:27:26 --> Router Class Initialized
INFO - 2023-07-30 16:27:26 --> Output Class Initialized
INFO - 2023-07-30 16:27:26 --> Security Class Initialized
DEBUG - 2023-07-30 16:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:27:26 --> Input Class Initialized
INFO - 2023-07-30 16:27:26 --> Language Class Initialized
INFO - 2023-07-30 16:27:26 --> Loader Class Initialized
INFO - 2023-07-30 16:27:26 --> Helper loaded: url_helper
INFO - 2023-07-30 16:27:26 --> Helper loaded: file_helper
INFO - 2023-07-30 16:27:26 --> Helper loaded: html_helper
INFO - 2023-07-30 16:27:26 --> Helper loaded: text_helper
INFO - 2023-07-30 16:27:26 --> Helper loaded: form_helper
INFO - 2023-07-30 16:27:26 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:27:26 --> Helper loaded: security_helper
INFO - 2023-07-30 16:27:26 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:27:26 --> Database Driver Class Initialized
INFO - 2023-07-30 16:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:27:26 --> Parser Class Initialized
INFO - 2023-07-30 16:27:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:27:26 --> Pagination Class Initialized
INFO - 2023-07-30 16:27:26 --> Form Validation Class Initialized
INFO - 2023-07-30 16:27:26 --> Controller Class Initialized
INFO - 2023-07-30 16:27:26 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:27:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:26 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:26 --> Model Class Initialized
INFO - 2023-07-30 16:27:26 --> Final output sent to browser
DEBUG - 2023-07-30 16:27:26 --> Total execution time: 0.0223
ERROR - 2023-07-30 16:27:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:27:34 --> Config Class Initialized
INFO - 2023-07-30 16:27:34 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:27:34 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:27:34 --> Utf8 Class Initialized
INFO - 2023-07-30 16:27:34 --> URI Class Initialized
DEBUG - 2023-07-30 16:27:34 --> No URI present. Default controller set.
INFO - 2023-07-30 16:27:34 --> Router Class Initialized
INFO - 2023-07-30 16:27:34 --> Output Class Initialized
INFO - 2023-07-30 16:27:34 --> Security Class Initialized
DEBUG - 2023-07-30 16:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:27:34 --> Input Class Initialized
INFO - 2023-07-30 16:27:34 --> Language Class Initialized
INFO - 2023-07-30 16:27:34 --> Loader Class Initialized
INFO - 2023-07-30 16:27:34 --> Helper loaded: url_helper
INFO - 2023-07-30 16:27:34 --> Helper loaded: file_helper
INFO - 2023-07-30 16:27:34 --> Helper loaded: html_helper
INFO - 2023-07-30 16:27:34 --> Helper loaded: text_helper
INFO - 2023-07-30 16:27:34 --> Helper loaded: form_helper
INFO - 2023-07-30 16:27:34 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:27:34 --> Helper loaded: security_helper
INFO - 2023-07-30 16:27:34 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:27:34 --> Database Driver Class Initialized
INFO - 2023-07-30 16:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:27:34 --> Parser Class Initialized
INFO - 2023-07-30 16:27:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:27:34 --> Pagination Class Initialized
INFO - 2023-07-30 16:27:34 --> Form Validation Class Initialized
INFO - 2023-07-30 16:27:34 --> Controller Class Initialized
INFO - 2023-07-30 16:27:34 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:34 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:34 --> Model Class Initialized
INFO - 2023-07-30 16:27:34 --> Model Class Initialized
INFO - 2023-07-30 16:27:34 --> Model Class Initialized
INFO - 2023-07-30 16:27:34 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:27:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:34 --> Model Class Initialized
INFO - 2023-07-30 16:27:34 --> Model Class Initialized
INFO - 2023-07-30 16:27:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-30 16:27:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:27:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:27:34 --> Model Class Initialized
INFO - 2023-07-30 16:27:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:27:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:27:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:27:34 --> Final output sent to browser
DEBUG - 2023-07-30 16:27:34 --> Total execution time: 0.0788
ERROR - 2023-07-30 16:27:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:27:44 --> Config Class Initialized
INFO - 2023-07-30 16:27:44 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:27:44 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:27:44 --> Utf8 Class Initialized
INFO - 2023-07-30 16:27:44 --> URI Class Initialized
INFO - 2023-07-30 16:27:44 --> Router Class Initialized
INFO - 2023-07-30 16:27:44 --> Output Class Initialized
INFO - 2023-07-30 16:27:44 --> Security Class Initialized
DEBUG - 2023-07-30 16:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:27:44 --> Input Class Initialized
INFO - 2023-07-30 16:27:44 --> Language Class Initialized
INFO - 2023-07-30 16:27:44 --> Loader Class Initialized
INFO - 2023-07-30 16:27:44 --> Helper loaded: url_helper
INFO - 2023-07-30 16:27:44 --> Helper loaded: file_helper
INFO - 2023-07-30 16:27:44 --> Helper loaded: html_helper
INFO - 2023-07-30 16:27:44 --> Helper loaded: text_helper
INFO - 2023-07-30 16:27:44 --> Helper loaded: form_helper
INFO - 2023-07-30 16:27:44 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:27:44 --> Helper loaded: security_helper
INFO - 2023-07-30 16:27:44 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:27:44 --> Database Driver Class Initialized
INFO - 2023-07-30 16:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:27:44 --> Parser Class Initialized
INFO - 2023-07-30 16:27:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:27:44 --> Pagination Class Initialized
INFO - 2023-07-30 16:27:44 --> Form Validation Class Initialized
INFO - 2023-07-30 16:27:44 --> Controller Class Initialized
INFO - 2023-07-30 16:27:44 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:27:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:44 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:44 --> Model Class Initialized
INFO - 2023-07-30 16:27:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-30 16:27:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:27:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:27:44 --> Model Class Initialized
INFO - 2023-07-30 16:27:44 --> Model Class Initialized
INFO - 2023-07-30 16:27:44 --> Model Class Initialized
INFO - 2023-07-30 16:27:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:27:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:27:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:27:44 --> Final output sent to browser
DEBUG - 2023-07-30 16:27:44 --> Total execution time: 0.0714
ERROR - 2023-07-30 16:27:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:27:44 --> Config Class Initialized
INFO - 2023-07-30 16:27:44 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:27:44 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:27:44 --> Utf8 Class Initialized
INFO - 2023-07-30 16:27:44 --> URI Class Initialized
INFO - 2023-07-30 16:27:44 --> Router Class Initialized
INFO - 2023-07-30 16:27:44 --> Output Class Initialized
INFO - 2023-07-30 16:27:44 --> Security Class Initialized
DEBUG - 2023-07-30 16:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:27:44 --> Input Class Initialized
INFO - 2023-07-30 16:27:44 --> Language Class Initialized
INFO - 2023-07-30 16:27:44 --> Loader Class Initialized
INFO - 2023-07-30 16:27:44 --> Helper loaded: url_helper
INFO - 2023-07-30 16:27:44 --> Helper loaded: file_helper
INFO - 2023-07-30 16:27:44 --> Helper loaded: html_helper
INFO - 2023-07-30 16:27:44 --> Helper loaded: text_helper
INFO - 2023-07-30 16:27:44 --> Helper loaded: form_helper
INFO - 2023-07-30 16:27:44 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:27:44 --> Helper loaded: security_helper
INFO - 2023-07-30 16:27:44 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:27:44 --> Database Driver Class Initialized
INFO - 2023-07-30 16:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:27:44 --> Parser Class Initialized
INFO - 2023-07-30 16:27:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:27:44 --> Pagination Class Initialized
INFO - 2023-07-30 16:27:44 --> Form Validation Class Initialized
INFO - 2023-07-30 16:27:44 --> Controller Class Initialized
INFO - 2023-07-30 16:27:44 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:27:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:44 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:44 --> Model Class Initialized
INFO - 2023-07-30 16:27:44 --> Final output sent to browser
DEBUG - 2023-07-30 16:27:44 --> Total execution time: 0.0236
ERROR - 2023-07-30 16:27:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:27:50 --> Config Class Initialized
INFO - 2023-07-30 16:27:50 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:27:50 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:27:50 --> Utf8 Class Initialized
INFO - 2023-07-30 16:27:50 --> URI Class Initialized
INFO - 2023-07-30 16:27:50 --> Router Class Initialized
INFO - 2023-07-30 16:27:50 --> Output Class Initialized
INFO - 2023-07-30 16:27:50 --> Security Class Initialized
DEBUG - 2023-07-30 16:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:27:50 --> Input Class Initialized
INFO - 2023-07-30 16:27:50 --> Language Class Initialized
INFO - 2023-07-30 16:27:50 --> Loader Class Initialized
INFO - 2023-07-30 16:27:50 --> Helper loaded: url_helper
INFO - 2023-07-30 16:27:50 --> Helper loaded: file_helper
INFO - 2023-07-30 16:27:50 --> Helper loaded: html_helper
INFO - 2023-07-30 16:27:50 --> Helper loaded: text_helper
INFO - 2023-07-30 16:27:50 --> Helper loaded: form_helper
INFO - 2023-07-30 16:27:50 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:27:50 --> Helper loaded: security_helper
INFO - 2023-07-30 16:27:50 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:27:50 --> Database Driver Class Initialized
INFO - 2023-07-30 16:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:27:50 --> Parser Class Initialized
INFO - 2023-07-30 16:27:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:27:50 --> Pagination Class Initialized
INFO - 2023-07-30 16:27:50 --> Form Validation Class Initialized
INFO - 2023-07-30 16:27:50 --> Controller Class Initialized
INFO - 2023-07-30 16:27:50 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:27:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:50 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:50 --> Model Class Initialized
INFO - 2023-07-30 16:27:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-30 16:27:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:27:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:27:50 --> Model Class Initialized
INFO - 2023-07-30 16:27:50 --> Model Class Initialized
INFO - 2023-07-30 16:27:50 --> Model Class Initialized
INFO - 2023-07-30 16:27:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:27:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:27:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:27:50 --> Final output sent to browser
DEBUG - 2023-07-30 16:27:50 --> Total execution time: 0.0766
ERROR - 2023-07-30 16:27:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:27:51 --> Config Class Initialized
INFO - 2023-07-30 16:27:51 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:27:51 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:27:51 --> Utf8 Class Initialized
INFO - 2023-07-30 16:27:51 --> URI Class Initialized
INFO - 2023-07-30 16:27:51 --> Router Class Initialized
INFO - 2023-07-30 16:27:51 --> Output Class Initialized
INFO - 2023-07-30 16:27:51 --> Security Class Initialized
DEBUG - 2023-07-30 16:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:27:51 --> Input Class Initialized
INFO - 2023-07-30 16:27:51 --> Language Class Initialized
INFO - 2023-07-30 16:27:51 --> Loader Class Initialized
INFO - 2023-07-30 16:27:51 --> Helper loaded: url_helper
INFO - 2023-07-30 16:27:51 --> Helper loaded: file_helper
INFO - 2023-07-30 16:27:51 --> Helper loaded: html_helper
INFO - 2023-07-30 16:27:51 --> Helper loaded: text_helper
INFO - 2023-07-30 16:27:51 --> Helper loaded: form_helper
INFO - 2023-07-30 16:27:51 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:27:51 --> Helper loaded: security_helper
INFO - 2023-07-30 16:27:51 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:27:51 --> Database Driver Class Initialized
INFO - 2023-07-30 16:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:27:51 --> Parser Class Initialized
INFO - 2023-07-30 16:27:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:27:51 --> Pagination Class Initialized
INFO - 2023-07-30 16:27:51 --> Form Validation Class Initialized
INFO - 2023-07-30 16:27:51 --> Controller Class Initialized
INFO - 2023-07-30 16:27:51 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:27:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:51 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:51 --> Model Class Initialized
INFO - 2023-07-30 16:27:51 --> Final output sent to browser
DEBUG - 2023-07-30 16:27:51 --> Total execution time: 0.0255
ERROR - 2023-07-30 16:27:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:27:55 --> Config Class Initialized
INFO - 2023-07-30 16:27:55 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:27:55 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:27:55 --> Utf8 Class Initialized
INFO - 2023-07-30 16:27:55 --> URI Class Initialized
INFO - 2023-07-30 16:27:55 --> Router Class Initialized
INFO - 2023-07-30 16:27:55 --> Output Class Initialized
INFO - 2023-07-30 16:27:55 --> Security Class Initialized
DEBUG - 2023-07-30 16:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:27:55 --> Input Class Initialized
INFO - 2023-07-30 16:27:55 --> Language Class Initialized
INFO - 2023-07-30 16:27:55 --> Loader Class Initialized
INFO - 2023-07-30 16:27:55 --> Helper loaded: url_helper
INFO - 2023-07-30 16:27:55 --> Helper loaded: file_helper
INFO - 2023-07-30 16:27:55 --> Helper loaded: html_helper
INFO - 2023-07-30 16:27:55 --> Helper loaded: text_helper
INFO - 2023-07-30 16:27:55 --> Helper loaded: form_helper
INFO - 2023-07-30 16:27:55 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:27:55 --> Helper loaded: security_helper
INFO - 2023-07-30 16:27:55 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:27:55 --> Database Driver Class Initialized
INFO - 2023-07-30 16:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:27:55 --> Parser Class Initialized
INFO - 2023-07-30 16:27:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:27:55 --> Pagination Class Initialized
INFO - 2023-07-30 16:27:55 --> Form Validation Class Initialized
INFO - 2023-07-30 16:27:55 --> Controller Class Initialized
INFO - 2023-07-30 16:27:55 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:27:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:55 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:55 --> Model Class Initialized
INFO - 2023-07-30 16:27:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-30 16:27:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:27:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:27:55 --> Model Class Initialized
INFO - 2023-07-30 16:27:55 --> Model Class Initialized
INFO - 2023-07-30 16:27:55 --> Model Class Initialized
INFO - 2023-07-30 16:27:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:27:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:27:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:27:55 --> Final output sent to browser
DEBUG - 2023-07-30 16:27:55 --> Total execution time: 0.0714
ERROR - 2023-07-30 16:27:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:27:55 --> Config Class Initialized
INFO - 2023-07-30 16:27:55 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:27:55 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:27:55 --> Utf8 Class Initialized
INFO - 2023-07-30 16:27:55 --> URI Class Initialized
INFO - 2023-07-30 16:27:55 --> Router Class Initialized
INFO - 2023-07-30 16:27:55 --> Output Class Initialized
INFO - 2023-07-30 16:27:55 --> Security Class Initialized
DEBUG - 2023-07-30 16:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:27:55 --> Input Class Initialized
INFO - 2023-07-30 16:27:55 --> Language Class Initialized
INFO - 2023-07-30 16:27:55 --> Loader Class Initialized
INFO - 2023-07-30 16:27:55 --> Helper loaded: url_helper
INFO - 2023-07-30 16:27:55 --> Helper loaded: file_helper
INFO - 2023-07-30 16:27:55 --> Helper loaded: html_helper
INFO - 2023-07-30 16:27:55 --> Helper loaded: text_helper
INFO - 2023-07-30 16:27:55 --> Helper loaded: form_helper
INFO - 2023-07-30 16:27:55 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:27:55 --> Helper loaded: security_helper
INFO - 2023-07-30 16:27:55 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:27:55 --> Database Driver Class Initialized
INFO - 2023-07-30 16:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:27:55 --> Parser Class Initialized
INFO - 2023-07-30 16:27:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:27:55 --> Pagination Class Initialized
INFO - 2023-07-30 16:27:55 --> Form Validation Class Initialized
INFO - 2023-07-30 16:27:55 --> Controller Class Initialized
INFO - 2023-07-30 16:27:55 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:27:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:55 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:55 --> Model Class Initialized
INFO - 2023-07-30 16:27:55 --> Final output sent to browser
DEBUG - 2023-07-30 16:27:55 --> Total execution time: 0.0231
ERROR - 2023-07-30 16:27:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:27:58 --> Config Class Initialized
INFO - 2023-07-30 16:27:58 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:27:58 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:27:58 --> Utf8 Class Initialized
INFO - 2023-07-30 16:27:58 --> URI Class Initialized
DEBUG - 2023-07-30 16:27:58 --> No URI present. Default controller set.
INFO - 2023-07-30 16:27:58 --> Router Class Initialized
INFO - 2023-07-30 16:27:58 --> Output Class Initialized
INFO - 2023-07-30 16:27:58 --> Security Class Initialized
DEBUG - 2023-07-30 16:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:27:58 --> Input Class Initialized
INFO - 2023-07-30 16:27:58 --> Language Class Initialized
INFO - 2023-07-30 16:27:58 --> Loader Class Initialized
INFO - 2023-07-30 16:27:58 --> Helper loaded: url_helper
INFO - 2023-07-30 16:27:58 --> Helper loaded: file_helper
INFO - 2023-07-30 16:27:58 --> Helper loaded: html_helper
INFO - 2023-07-30 16:27:58 --> Helper loaded: text_helper
INFO - 2023-07-30 16:27:58 --> Helper loaded: form_helper
INFO - 2023-07-30 16:27:58 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:27:58 --> Helper loaded: security_helper
INFO - 2023-07-30 16:27:58 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:27:58 --> Database Driver Class Initialized
INFO - 2023-07-30 16:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:27:58 --> Parser Class Initialized
INFO - 2023-07-30 16:27:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:27:58 --> Pagination Class Initialized
INFO - 2023-07-30 16:27:58 --> Form Validation Class Initialized
INFO - 2023-07-30 16:27:58 --> Controller Class Initialized
INFO - 2023-07-30 16:27:58 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:58 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:58 --> Model Class Initialized
INFO - 2023-07-30 16:27:58 --> Model Class Initialized
INFO - 2023-07-30 16:27:58 --> Model Class Initialized
INFO - 2023-07-30 16:27:58 --> Model Class Initialized
DEBUG - 2023-07-30 16:27:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:27:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:58 --> Model Class Initialized
INFO - 2023-07-30 16:27:58 --> Model Class Initialized
INFO - 2023-07-30 16:27:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-30 16:27:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:27:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:27:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:27:58 --> Model Class Initialized
INFO - 2023-07-30 16:27:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:27:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:27:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:27:58 --> Final output sent to browser
DEBUG - 2023-07-30 16:27:58 --> Total execution time: 0.0810
ERROR - 2023-07-30 16:28:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:28:09 --> Config Class Initialized
INFO - 2023-07-30 16:28:09 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:28:09 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:28:09 --> Utf8 Class Initialized
INFO - 2023-07-30 16:28:09 --> URI Class Initialized
INFO - 2023-07-30 16:28:09 --> Router Class Initialized
INFO - 2023-07-30 16:28:09 --> Output Class Initialized
INFO - 2023-07-30 16:28:09 --> Security Class Initialized
DEBUG - 2023-07-30 16:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:28:09 --> Input Class Initialized
INFO - 2023-07-30 16:28:09 --> Language Class Initialized
INFO - 2023-07-30 16:28:09 --> Loader Class Initialized
INFO - 2023-07-30 16:28:09 --> Helper loaded: url_helper
INFO - 2023-07-30 16:28:09 --> Helper loaded: file_helper
INFO - 2023-07-30 16:28:09 --> Helper loaded: html_helper
INFO - 2023-07-30 16:28:09 --> Helper loaded: text_helper
INFO - 2023-07-30 16:28:09 --> Helper loaded: form_helper
INFO - 2023-07-30 16:28:09 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:28:09 --> Helper loaded: security_helper
INFO - 2023-07-30 16:28:09 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:28:09 --> Database Driver Class Initialized
INFO - 2023-07-30 16:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:28:09 --> Parser Class Initialized
INFO - 2023-07-30 16:28:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:28:09 --> Pagination Class Initialized
INFO - 2023-07-30 16:28:09 --> Form Validation Class Initialized
INFO - 2023-07-30 16:28:09 --> Controller Class Initialized
INFO - 2023-07-30 16:28:09 --> Model Class Initialized
DEBUG - 2023-07-30 16:28:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:28:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:28:09 --> Model Class Initialized
DEBUG - 2023-07-30 16:28:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:28:09 --> Model Class Initialized
INFO - 2023-07-30 16:28:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-30 16:28:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:28:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:28:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:28:09 --> Model Class Initialized
INFO - 2023-07-30 16:28:09 --> Model Class Initialized
INFO - 2023-07-30 16:28:09 --> Model Class Initialized
INFO - 2023-07-30 16:28:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:28:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:28:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:28:09 --> Final output sent to browser
DEBUG - 2023-07-30 16:28:09 --> Total execution time: 0.0741
ERROR - 2023-07-30 16:28:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:28:09 --> Config Class Initialized
INFO - 2023-07-30 16:28:09 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:28:09 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:28:09 --> Utf8 Class Initialized
INFO - 2023-07-30 16:28:09 --> URI Class Initialized
INFO - 2023-07-30 16:28:09 --> Router Class Initialized
INFO - 2023-07-30 16:28:09 --> Output Class Initialized
INFO - 2023-07-30 16:28:09 --> Security Class Initialized
DEBUG - 2023-07-30 16:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:28:09 --> Input Class Initialized
INFO - 2023-07-30 16:28:09 --> Language Class Initialized
INFO - 2023-07-30 16:28:09 --> Loader Class Initialized
INFO - 2023-07-30 16:28:09 --> Helper loaded: url_helper
INFO - 2023-07-30 16:28:09 --> Helper loaded: file_helper
INFO - 2023-07-30 16:28:09 --> Helper loaded: html_helper
INFO - 2023-07-30 16:28:09 --> Helper loaded: text_helper
INFO - 2023-07-30 16:28:09 --> Helper loaded: form_helper
INFO - 2023-07-30 16:28:09 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:28:09 --> Helper loaded: security_helper
INFO - 2023-07-30 16:28:09 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:28:09 --> Database Driver Class Initialized
INFO - 2023-07-30 16:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:28:09 --> Parser Class Initialized
INFO - 2023-07-30 16:28:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:28:09 --> Pagination Class Initialized
INFO - 2023-07-30 16:28:09 --> Form Validation Class Initialized
INFO - 2023-07-30 16:28:09 --> Controller Class Initialized
INFO - 2023-07-30 16:28:09 --> Model Class Initialized
DEBUG - 2023-07-30 16:28:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:28:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:28:09 --> Model Class Initialized
DEBUG - 2023-07-30 16:28:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:28:09 --> Model Class Initialized
INFO - 2023-07-30 16:28:09 --> Final output sent to browser
DEBUG - 2023-07-30 16:28:09 --> Total execution time: 0.0225
ERROR - 2023-07-30 16:28:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:28:20 --> Config Class Initialized
INFO - 2023-07-30 16:28:20 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:28:20 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:28:20 --> Utf8 Class Initialized
INFO - 2023-07-30 16:28:20 --> URI Class Initialized
INFO - 2023-07-30 16:28:20 --> Router Class Initialized
INFO - 2023-07-30 16:28:20 --> Output Class Initialized
INFO - 2023-07-30 16:28:20 --> Security Class Initialized
DEBUG - 2023-07-30 16:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:28:20 --> Input Class Initialized
INFO - 2023-07-30 16:28:20 --> Language Class Initialized
INFO - 2023-07-30 16:28:20 --> Loader Class Initialized
INFO - 2023-07-30 16:28:20 --> Helper loaded: url_helper
INFO - 2023-07-30 16:28:20 --> Helper loaded: file_helper
INFO - 2023-07-30 16:28:20 --> Helper loaded: html_helper
INFO - 2023-07-30 16:28:20 --> Helper loaded: text_helper
INFO - 2023-07-30 16:28:20 --> Helper loaded: form_helper
INFO - 2023-07-30 16:28:20 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:28:20 --> Helper loaded: security_helper
INFO - 2023-07-30 16:28:20 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:28:20 --> Database Driver Class Initialized
INFO - 2023-07-30 16:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:28:20 --> Parser Class Initialized
INFO - 2023-07-30 16:28:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:28:20 --> Pagination Class Initialized
INFO - 2023-07-30 16:28:20 --> Form Validation Class Initialized
INFO - 2023-07-30 16:28:20 --> Controller Class Initialized
INFO - 2023-07-30 16:28:20 --> Model Class Initialized
DEBUG - 2023-07-30 16:28:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:28:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:28:20 --> Model Class Initialized
INFO - 2023-07-30 16:28:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-07-30 16:28:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:28:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:28:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:28:20 --> Model Class Initialized
INFO - 2023-07-30 16:28:20 --> Model Class Initialized
INFO - 2023-07-30 16:28:20 --> Model Class Initialized
INFO - 2023-07-30 16:28:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:28:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:28:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:28:20 --> Final output sent to browser
DEBUG - 2023-07-30 16:28:20 --> Total execution time: 0.0601
ERROR - 2023-07-30 16:28:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:28:21 --> Config Class Initialized
INFO - 2023-07-30 16:28:21 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:28:21 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:28:21 --> Utf8 Class Initialized
INFO - 2023-07-30 16:28:21 --> URI Class Initialized
INFO - 2023-07-30 16:28:21 --> Router Class Initialized
INFO - 2023-07-30 16:28:21 --> Output Class Initialized
INFO - 2023-07-30 16:28:21 --> Security Class Initialized
DEBUG - 2023-07-30 16:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:28:21 --> Input Class Initialized
INFO - 2023-07-30 16:28:21 --> Language Class Initialized
INFO - 2023-07-30 16:28:21 --> Loader Class Initialized
INFO - 2023-07-30 16:28:21 --> Helper loaded: url_helper
INFO - 2023-07-30 16:28:21 --> Helper loaded: file_helper
INFO - 2023-07-30 16:28:21 --> Helper loaded: html_helper
INFO - 2023-07-30 16:28:21 --> Helper loaded: text_helper
INFO - 2023-07-30 16:28:21 --> Helper loaded: form_helper
INFO - 2023-07-30 16:28:21 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:28:21 --> Helper loaded: security_helper
INFO - 2023-07-30 16:28:21 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:28:21 --> Database Driver Class Initialized
INFO - 2023-07-30 16:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:28:21 --> Parser Class Initialized
INFO - 2023-07-30 16:28:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:28:21 --> Pagination Class Initialized
INFO - 2023-07-30 16:28:21 --> Form Validation Class Initialized
INFO - 2023-07-30 16:28:21 --> Controller Class Initialized
INFO - 2023-07-30 16:28:21 --> Model Class Initialized
DEBUG - 2023-07-30 16:28:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:28:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:28:21 --> Model Class Initialized
INFO - 2023-07-30 16:28:21 --> Final output sent to browser
DEBUG - 2023-07-30 16:28:21 --> Total execution time: 0.0253
ERROR - 2023-07-30 16:28:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:28:25 --> Config Class Initialized
INFO - 2023-07-30 16:28:25 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:28:25 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:28:25 --> Utf8 Class Initialized
INFO - 2023-07-30 16:28:25 --> URI Class Initialized
INFO - 2023-07-30 16:28:25 --> Router Class Initialized
INFO - 2023-07-30 16:28:25 --> Output Class Initialized
INFO - 2023-07-30 16:28:25 --> Security Class Initialized
DEBUG - 2023-07-30 16:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:28:25 --> Input Class Initialized
INFO - 2023-07-30 16:28:25 --> Language Class Initialized
INFO - 2023-07-30 16:28:25 --> Loader Class Initialized
INFO - 2023-07-30 16:28:25 --> Helper loaded: url_helper
INFO - 2023-07-30 16:28:25 --> Helper loaded: file_helper
INFO - 2023-07-30 16:28:25 --> Helper loaded: html_helper
INFO - 2023-07-30 16:28:25 --> Helper loaded: text_helper
INFO - 2023-07-30 16:28:25 --> Helper loaded: form_helper
INFO - 2023-07-30 16:28:25 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:28:25 --> Helper loaded: security_helper
INFO - 2023-07-30 16:28:25 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:28:25 --> Database Driver Class Initialized
INFO - 2023-07-30 16:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:28:25 --> Parser Class Initialized
INFO - 2023-07-30 16:28:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:28:25 --> Pagination Class Initialized
INFO - 2023-07-30 16:28:25 --> Form Validation Class Initialized
INFO - 2023-07-30 16:28:25 --> Controller Class Initialized
INFO - 2023-07-30 16:28:25 --> Model Class Initialized
DEBUG - 2023-07-30 16:28:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:28:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:28:25 --> Model Class Initialized
INFO - 2023-07-30 16:28:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-07-30 16:28:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:28:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:28:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:28:25 --> Model Class Initialized
INFO - 2023-07-30 16:28:25 --> Model Class Initialized
INFO - 2023-07-30 16:28:25 --> Model Class Initialized
INFO - 2023-07-30 16:28:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:28:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:28:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:28:26 --> Final output sent to browser
DEBUG - 2023-07-30 16:28:26 --> Total execution time: 0.0752
ERROR - 2023-07-30 16:28:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:28:26 --> Config Class Initialized
INFO - 2023-07-30 16:28:26 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:28:26 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:28:26 --> Utf8 Class Initialized
INFO - 2023-07-30 16:28:26 --> URI Class Initialized
INFO - 2023-07-30 16:28:26 --> Router Class Initialized
INFO - 2023-07-30 16:28:26 --> Output Class Initialized
INFO - 2023-07-30 16:28:26 --> Security Class Initialized
DEBUG - 2023-07-30 16:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:28:26 --> Input Class Initialized
INFO - 2023-07-30 16:28:26 --> Language Class Initialized
INFO - 2023-07-30 16:28:26 --> Loader Class Initialized
INFO - 2023-07-30 16:28:26 --> Helper loaded: url_helper
INFO - 2023-07-30 16:28:26 --> Helper loaded: file_helper
INFO - 2023-07-30 16:28:26 --> Helper loaded: html_helper
INFO - 2023-07-30 16:28:26 --> Helper loaded: text_helper
INFO - 2023-07-30 16:28:26 --> Helper loaded: form_helper
INFO - 2023-07-30 16:28:26 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:28:26 --> Helper loaded: security_helper
INFO - 2023-07-30 16:28:26 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:28:26 --> Database Driver Class Initialized
INFO - 2023-07-30 16:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:28:26 --> Parser Class Initialized
INFO - 2023-07-30 16:28:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:28:26 --> Pagination Class Initialized
INFO - 2023-07-30 16:28:26 --> Form Validation Class Initialized
INFO - 2023-07-30 16:28:26 --> Controller Class Initialized
INFO - 2023-07-30 16:28:26 --> Model Class Initialized
DEBUG - 2023-07-30 16:28:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:28:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:28:26 --> Model Class Initialized
INFO - 2023-07-30 16:28:26 --> Final output sent to browser
DEBUG - 2023-07-30 16:28:26 --> Total execution time: 0.0196
ERROR - 2023-07-30 16:28:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:28:37 --> Config Class Initialized
INFO - 2023-07-30 16:28:37 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:28:37 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:28:37 --> Utf8 Class Initialized
INFO - 2023-07-30 16:28:37 --> URI Class Initialized
INFO - 2023-07-30 16:28:37 --> Router Class Initialized
INFO - 2023-07-30 16:28:37 --> Output Class Initialized
INFO - 2023-07-30 16:28:37 --> Security Class Initialized
DEBUG - 2023-07-30 16:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:28:37 --> Input Class Initialized
INFO - 2023-07-30 16:28:37 --> Language Class Initialized
INFO - 2023-07-30 16:28:37 --> Loader Class Initialized
INFO - 2023-07-30 16:28:37 --> Helper loaded: url_helper
INFO - 2023-07-30 16:28:37 --> Helper loaded: file_helper
INFO - 2023-07-30 16:28:37 --> Helper loaded: html_helper
INFO - 2023-07-30 16:28:37 --> Helper loaded: text_helper
INFO - 2023-07-30 16:28:37 --> Helper loaded: form_helper
INFO - 2023-07-30 16:28:37 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:28:37 --> Helper loaded: security_helper
INFO - 2023-07-30 16:28:37 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:28:37 --> Database Driver Class Initialized
INFO - 2023-07-30 16:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:28:37 --> Parser Class Initialized
INFO - 2023-07-30 16:28:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:28:37 --> Pagination Class Initialized
INFO - 2023-07-30 16:28:37 --> Form Validation Class Initialized
INFO - 2023-07-30 16:28:37 --> Controller Class Initialized
INFO - 2023-07-30 16:28:37 --> Model Class Initialized
DEBUG - 2023-07-30 16:28:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:28:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:28:37 --> Model Class Initialized
INFO - 2023-07-30 16:28:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-07-30 16:28:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:28:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:28:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:28:37 --> Model Class Initialized
INFO - 2023-07-30 16:28:37 --> Model Class Initialized
INFO - 2023-07-30 16:28:37 --> Model Class Initialized
INFO - 2023-07-30 16:28:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:28:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:28:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:28:37 --> Final output sent to browser
DEBUG - 2023-07-30 16:28:37 --> Total execution time: 0.0785
ERROR - 2023-07-30 16:28:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:28:37 --> Config Class Initialized
INFO - 2023-07-30 16:28:37 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:28:37 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:28:37 --> Utf8 Class Initialized
INFO - 2023-07-30 16:28:37 --> URI Class Initialized
INFO - 2023-07-30 16:28:37 --> Router Class Initialized
INFO - 2023-07-30 16:28:37 --> Output Class Initialized
INFO - 2023-07-30 16:28:37 --> Security Class Initialized
DEBUG - 2023-07-30 16:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:28:37 --> Input Class Initialized
INFO - 2023-07-30 16:28:37 --> Language Class Initialized
INFO - 2023-07-30 16:28:37 --> Loader Class Initialized
INFO - 2023-07-30 16:28:37 --> Helper loaded: url_helper
INFO - 2023-07-30 16:28:37 --> Helper loaded: file_helper
INFO - 2023-07-30 16:28:37 --> Helper loaded: html_helper
INFO - 2023-07-30 16:28:37 --> Helper loaded: text_helper
INFO - 2023-07-30 16:28:37 --> Helper loaded: form_helper
INFO - 2023-07-30 16:28:37 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:28:37 --> Helper loaded: security_helper
INFO - 2023-07-30 16:28:37 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:28:37 --> Database Driver Class Initialized
INFO - 2023-07-30 16:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:28:37 --> Parser Class Initialized
INFO - 2023-07-30 16:28:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:28:37 --> Pagination Class Initialized
INFO - 2023-07-30 16:28:37 --> Form Validation Class Initialized
INFO - 2023-07-30 16:28:37 --> Controller Class Initialized
INFO - 2023-07-30 16:28:37 --> Model Class Initialized
DEBUG - 2023-07-30 16:28:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:28:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:28:37 --> Model Class Initialized
INFO - 2023-07-30 16:28:37 --> Final output sent to browser
DEBUG - 2023-07-30 16:28:37 --> Total execution time: 0.0212
ERROR - 2023-07-30 16:28:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:28:56 --> Config Class Initialized
INFO - 2023-07-30 16:28:56 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:28:56 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:28:56 --> Utf8 Class Initialized
INFO - 2023-07-30 16:28:56 --> URI Class Initialized
INFO - 2023-07-30 16:28:56 --> Router Class Initialized
INFO - 2023-07-30 16:28:56 --> Output Class Initialized
INFO - 2023-07-30 16:28:56 --> Security Class Initialized
DEBUG - 2023-07-30 16:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:28:56 --> Input Class Initialized
INFO - 2023-07-30 16:28:56 --> Language Class Initialized
INFO - 2023-07-30 16:28:56 --> Loader Class Initialized
INFO - 2023-07-30 16:28:56 --> Helper loaded: url_helper
INFO - 2023-07-30 16:28:56 --> Helper loaded: file_helper
INFO - 2023-07-30 16:28:56 --> Helper loaded: html_helper
INFO - 2023-07-30 16:28:56 --> Helper loaded: text_helper
INFO - 2023-07-30 16:28:56 --> Helper loaded: form_helper
INFO - 2023-07-30 16:28:56 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:28:56 --> Helper loaded: security_helper
INFO - 2023-07-30 16:28:56 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:28:56 --> Database Driver Class Initialized
INFO - 2023-07-30 16:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:28:56 --> Parser Class Initialized
INFO - 2023-07-30 16:28:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:28:56 --> Pagination Class Initialized
INFO - 2023-07-30 16:28:56 --> Form Validation Class Initialized
INFO - 2023-07-30 16:28:56 --> Controller Class Initialized
DEBUG - 2023-07-30 16:28:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:28:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:28:56 --> Model Class Initialized
INFO - 2023-07-30 16:28:56 --> Model Class Initialized
DEBUG - 2023-07-30 16:28:56 --> Lmr class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:28:56 --> Model Class Initialized
INFO - 2023-07-30 16:28:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/mr/mr.php
DEBUG - 2023-07-30 16:28:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:28:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:28:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:28:56 --> Model Class Initialized
INFO - 2023-07-30 16:28:56 --> Model Class Initialized
INFO - 2023-07-30 16:28:56 --> Model Class Initialized
INFO - 2023-07-30 16:28:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:28:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:28:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:28:56 --> Final output sent to browser
DEBUG - 2023-07-30 16:28:56 --> Total execution time: 0.1343
ERROR - 2023-07-30 16:28:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:28:57 --> Config Class Initialized
INFO - 2023-07-30 16:28:57 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:28:57 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:28:57 --> Utf8 Class Initialized
INFO - 2023-07-30 16:28:57 --> URI Class Initialized
INFO - 2023-07-30 16:28:57 --> Router Class Initialized
INFO - 2023-07-30 16:28:57 --> Output Class Initialized
INFO - 2023-07-30 16:28:57 --> Security Class Initialized
DEBUG - 2023-07-30 16:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:28:57 --> Input Class Initialized
INFO - 2023-07-30 16:28:57 --> Language Class Initialized
INFO - 2023-07-30 16:28:57 --> Loader Class Initialized
INFO - 2023-07-30 16:28:57 --> Helper loaded: url_helper
INFO - 2023-07-30 16:28:57 --> Helper loaded: file_helper
INFO - 2023-07-30 16:28:57 --> Helper loaded: html_helper
INFO - 2023-07-30 16:28:57 --> Helper loaded: text_helper
INFO - 2023-07-30 16:28:57 --> Helper loaded: form_helper
INFO - 2023-07-30 16:28:57 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:28:57 --> Helper loaded: security_helper
INFO - 2023-07-30 16:28:57 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:28:57 --> Database Driver Class Initialized
INFO - 2023-07-30 16:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:28:57 --> Parser Class Initialized
INFO - 2023-07-30 16:28:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:28:57 --> Pagination Class Initialized
INFO - 2023-07-30 16:28:57 --> Form Validation Class Initialized
INFO - 2023-07-30 16:28:57 --> Controller Class Initialized
DEBUG - 2023-07-30 16:28:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:28:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:28:57 --> Model Class Initialized
INFO - 2023-07-30 16:28:57 --> Model Class Initialized
INFO - 2023-07-30 16:28:57 --> Final output sent to browser
DEBUG - 2023-07-30 16:28:57 --> Total execution time: 0.0204
ERROR - 2023-07-30 16:29:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:29:15 --> Config Class Initialized
INFO - 2023-07-30 16:29:15 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:29:15 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:29:15 --> Utf8 Class Initialized
INFO - 2023-07-30 16:29:15 --> URI Class Initialized
DEBUG - 2023-07-30 16:29:15 --> No URI present. Default controller set.
INFO - 2023-07-30 16:29:15 --> Router Class Initialized
INFO - 2023-07-30 16:29:15 --> Output Class Initialized
INFO - 2023-07-30 16:29:15 --> Security Class Initialized
DEBUG - 2023-07-30 16:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:29:15 --> Input Class Initialized
INFO - 2023-07-30 16:29:15 --> Language Class Initialized
INFO - 2023-07-30 16:29:15 --> Loader Class Initialized
INFO - 2023-07-30 16:29:15 --> Helper loaded: url_helper
INFO - 2023-07-30 16:29:15 --> Helper loaded: file_helper
INFO - 2023-07-30 16:29:15 --> Helper loaded: html_helper
INFO - 2023-07-30 16:29:15 --> Helper loaded: text_helper
INFO - 2023-07-30 16:29:15 --> Helper loaded: form_helper
INFO - 2023-07-30 16:29:15 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:29:15 --> Helper loaded: security_helper
INFO - 2023-07-30 16:29:15 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:29:15 --> Database Driver Class Initialized
INFO - 2023-07-30 16:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:29:15 --> Parser Class Initialized
INFO - 2023-07-30 16:29:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:29:15 --> Pagination Class Initialized
INFO - 2023-07-30 16:29:15 --> Form Validation Class Initialized
INFO - 2023-07-30 16:29:15 --> Controller Class Initialized
INFO - 2023-07-30 16:29:15 --> Model Class Initialized
DEBUG - 2023-07-30 16:29:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:29:15 --> Model Class Initialized
DEBUG - 2023-07-30 16:29:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:29:15 --> Model Class Initialized
INFO - 2023-07-30 16:29:15 --> Model Class Initialized
INFO - 2023-07-30 16:29:15 --> Model Class Initialized
INFO - 2023-07-30 16:29:15 --> Model Class Initialized
DEBUG - 2023-07-30 16:29:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:29:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:29:15 --> Model Class Initialized
INFO - 2023-07-30 16:29:15 --> Model Class Initialized
INFO - 2023-07-30 16:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-30 16:29:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:29:15 --> Model Class Initialized
INFO - 2023-07-30 16:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:29:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:29:15 --> Final output sent to browser
DEBUG - 2023-07-30 16:29:15 --> Total execution time: 0.0835
ERROR - 2023-07-30 16:29:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:29:34 --> Config Class Initialized
INFO - 2023-07-30 16:29:34 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:29:34 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:29:34 --> Utf8 Class Initialized
INFO - 2023-07-30 16:29:34 --> URI Class Initialized
DEBUG - 2023-07-30 16:29:34 --> No URI present. Default controller set.
INFO - 2023-07-30 16:29:34 --> Router Class Initialized
INFO - 2023-07-30 16:29:34 --> Output Class Initialized
INFO - 2023-07-30 16:29:34 --> Security Class Initialized
DEBUG - 2023-07-30 16:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:29:34 --> Input Class Initialized
INFO - 2023-07-30 16:29:34 --> Language Class Initialized
INFO - 2023-07-30 16:29:34 --> Loader Class Initialized
INFO - 2023-07-30 16:29:34 --> Helper loaded: url_helper
INFO - 2023-07-30 16:29:34 --> Helper loaded: file_helper
INFO - 2023-07-30 16:29:34 --> Helper loaded: html_helper
INFO - 2023-07-30 16:29:34 --> Helper loaded: text_helper
INFO - 2023-07-30 16:29:34 --> Helper loaded: form_helper
INFO - 2023-07-30 16:29:34 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:29:34 --> Helper loaded: security_helper
INFO - 2023-07-30 16:29:34 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:29:34 --> Database Driver Class Initialized
INFO - 2023-07-30 16:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:29:34 --> Parser Class Initialized
INFO - 2023-07-30 16:29:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:29:34 --> Pagination Class Initialized
INFO - 2023-07-30 16:29:34 --> Form Validation Class Initialized
INFO - 2023-07-30 16:29:34 --> Controller Class Initialized
INFO - 2023-07-30 16:29:34 --> Model Class Initialized
DEBUG - 2023-07-30 16:29:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:29:34 --> Model Class Initialized
DEBUG - 2023-07-30 16:29:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:29:34 --> Model Class Initialized
INFO - 2023-07-30 16:29:34 --> Model Class Initialized
INFO - 2023-07-30 16:29:34 --> Model Class Initialized
INFO - 2023-07-30 16:29:34 --> Model Class Initialized
DEBUG - 2023-07-30 16:29:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:29:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:29:34 --> Model Class Initialized
INFO - 2023-07-30 16:29:34 --> Model Class Initialized
INFO - 2023-07-30 16:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-30 16:29:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:29:34 --> Model Class Initialized
INFO - 2023-07-30 16:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:29:34 --> Final output sent to browser
DEBUG - 2023-07-30 16:29:34 --> Total execution time: 0.0851
ERROR - 2023-07-30 16:29:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:29:40 --> Config Class Initialized
INFO - 2023-07-30 16:29:40 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:29:40 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:29:40 --> Utf8 Class Initialized
INFO - 2023-07-30 16:29:40 --> URI Class Initialized
INFO - 2023-07-30 16:29:40 --> Router Class Initialized
INFO - 2023-07-30 16:29:40 --> Output Class Initialized
INFO - 2023-07-30 16:29:40 --> Security Class Initialized
DEBUG - 2023-07-30 16:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:29:40 --> Input Class Initialized
INFO - 2023-07-30 16:29:40 --> Language Class Initialized
INFO - 2023-07-30 16:29:40 --> Loader Class Initialized
INFO - 2023-07-30 16:29:40 --> Helper loaded: url_helper
INFO - 2023-07-30 16:29:40 --> Helper loaded: file_helper
INFO - 2023-07-30 16:29:40 --> Helper loaded: html_helper
INFO - 2023-07-30 16:29:40 --> Helper loaded: text_helper
INFO - 2023-07-30 16:29:40 --> Helper loaded: form_helper
INFO - 2023-07-30 16:29:40 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:29:40 --> Helper loaded: security_helper
INFO - 2023-07-30 16:29:40 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:29:40 --> Database Driver Class Initialized
INFO - 2023-07-30 16:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:29:40 --> Parser Class Initialized
INFO - 2023-07-30 16:29:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:29:40 --> Pagination Class Initialized
INFO - 2023-07-30 16:29:40 --> Form Validation Class Initialized
INFO - 2023-07-30 16:29:40 --> Controller Class Initialized
INFO - 2023-07-30 16:29:40 --> Model Class Initialized
DEBUG - 2023-07-30 16:29:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:29:40 --> Final output sent to browser
DEBUG - 2023-07-30 16:29:40 --> Total execution time: 0.0137
ERROR - 2023-07-30 16:29:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:29:40 --> Config Class Initialized
INFO - 2023-07-30 16:29:40 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:29:40 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:29:40 --> Utf8 Class Initialized
INFO - 2023-07-30 16:29:40 --> URI Class Initialized
INFO - 2023-07-30 16:29:40 --> Router Class Initialized
INFO - 2023-07-30 16:29:40 --> Output Class Initialized
INFO - 2023-07-30 16:29:40 --> Security Class Initialized
DEBUG - 2023-07-30 16:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:29:40 --> Input Class Initialized
INFO - 2023-07-30 16:29:40 --> Language Class Initialized
INFO - 2023-07-30 16:29:40 --> Loader Class Initialized
INFO - 2023-07-30 16:29:40 --> Helper loaded: url_helper
INFO - 2023-07-30 16:29:40 --> Helper loaded: file_helper
INFO - 2023-07-30 16:29:40 --> Helper loaded: html_helper
INFO - 2023-07-30 16:29:40 --> Helper loaded: text_helper
INFO - 2023-07-30 16:29:40 --> Helper loaded: form_helper
INFO - 2023-07-30 16:29:40 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:29:40 --> Helper loaded: security_helper
INFO - 2023-07-30 16:29:40 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:29:40 --> Database Driver Class Initialized
INFO - 2023-07-30 16:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:29:40 --> Parser Class Initialized
INFO - 2023-07-30 16:29:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:29:40 --> Pagination Class Initialized
INFO - 2023-07-30 16:29:40 --> Form Validation Class Initialized
INFO - 2023-07-30 16:29:40 --> Controller Class Initialized
INFO - 2023-07-30 16:29:40 --> Model Class Initialized
DEBUG - 2023-07-30 16:29:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:29:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-30 16:29:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:29:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:29:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:29:40 --> Model Class Initialized
INFO - 2023-07-30 16:29:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:29:40 --> Final output sent to browser
DEBUG - 2023-07-30 16:29:40 --> Total execution time: 0.0313
ERROR - 2023-07-30 16:30:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:30:02 --> Config Class Initialized
INFO - 2023-07-30 16:30:02 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:30:02 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:30:02 --> Utf8 Class Initialized
INFO - 2023-07-30 16:30:02 --> URI Class Initialized
INFO - 2023-07-30 16:30:02 --> Router Class Initialized
INFO - 2023-07-30 16:30:02 --> Output Class Initialized
INFO - 2023-07-30 16:30:02 --> Security Class Initialized
DEBUG - 2023-07-30 16:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:30:02 --> Input Class Initialized
INFO - 2023-07-30 16:30:02 --> Language Class Initialized
INFO - 2023-07-30 16:30:02 --> Loader Class Initialized
INFO - 2023-07-30 16:30:02 --> Helper loaded: url_helper
INFO - 2023-07-30 16:30:02 --> Helper loaded: file_helper
INFO - 2023-07-30 16:30:02 --> Helper loaded: html_helper
INFO - 2023-07-30 16:30:02 --> Helper loaded: text_helper
INFO - 2023-07-30 16:30:02 --> Helper loaded: form_helper
INFO - 2023-07-30 16:30:02 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:30:02 --> Helper loaded: security_helper
INFO - 2023-07-30 16:30:02 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:30:02 --> Database Driver Class Initialized
INFO - 2023-07-30 16:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:30:02 --> Parser Class Initialized
INFO - 2023-07-30 16:30:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:30:02 --> Pagination Class Initialized
INFO - 2023-07-30 16:30:02 --> Form Validation Class Initialized
INFO - 2023-07-30 16:30:02 --> Controller Class Initialized
INFO - 2023-07-30 16:30:02 --> Model Class Initialized
DEBUG - 2023-07-30 16:30:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:30:02 --> Model Class Initialized
INFO - 2023-07-30 16:30:02 --> Final output sent to browser
DEBUG - 2023-07-30 16:30:02 --> Total execution time: 0.0219
ERROR - 2023-07-30 16:30:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:30:02 --> Config Class Initialized
INFO - 2023-07-30 16:30:02 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:30:02 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:30:02 --> Utf8 Class Initialized
INFO - 2023-07-30 16:30:02 --> URI Class Initialized
INFO - 2023-07-30 16:30:02 --> Router Class Initialized
INFO - 2023-07-30 16:30:02 --> Output Class Initialized
INFO - 2023-07-30 16:30:02 --> Security Class Initialized
DEBUG - 2023-07-30 16:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:30:02 --> Input Class Initialized
INFO - 2023-07-30 16:30:02 --> Language Class Initialized
INFO - 2023-07-30 16:30:02 --> Loader Class Initialized
INFO - 2023-07-30 16:30:02 --> Helper loaded: url_helper
INFO - 2023-07-30 16:30:02 --> Helper loaded: file_helper
INFO - 2023-07-30 16:30:02 --> Helper loaded: html_helper
INFO - 2023-07-30 16:30:02 --> Helper loaded: text_helper
INFO - 2023-07-30 16:30:02 --> Helper loaded: form_helper
INFO - 2023-07-30 16:30:02 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:30:02 --> Helper loaded: security_helper
INFO - 2023-07-30 16:30:02 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:30:02 --> Database Driver Class Initialized
INFO - 2023-07-30 16:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:30:02 --> Parser Class Initialized
INFO - 2023-07-30 16:30:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:30:02 --> Pagination Class Initialized
INFO - 2023-07-30 16:30:02 --> Form Validation Class Initialized
INFO - 2023-07-30 16:30:02 --> Controller Class Initialized
INFO - 2023-07-30 16:30:02 --> Model Class Initialized
DEBUG - 2023-07-30 16:30:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:30:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-30 16:30:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:30:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:30:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:30:02 --> Model Class Initialized
INFO - 2023-07-30 16:30:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:30:02 --> Final output sent to browser
DEBUG - 2023-07-30 16:30:02 --> Total execution time: 0.0300
ERROR - 2023-07-30 16:30:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:30:21 --> Config Class Initialized
INFO - 2023-07-30 16:30:21 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:30:21 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:30:21 --> Utf8 Class Initialized
INFO - 2023-07-30 16:30:21 --> URI Class Initialized
INFO - 2023-07-30 16:30:21 --> Router Class Initialized
INFO - 2023-07-30 16:30:21 --> Output Class Initialized
INFO - 2023-07-30 16:30:21 --> Security Class Initialized
DEBUG - 2023-07-30 16:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:30:21 --> Input Class Initialized
INFO - 2023-07-30 16:30:21 --> Language Class Initialized
INFO - 2023-07-30 16:30:21 --> Loader Class Initialized
INFO - 2023-07-30 16:30:21 --> Helper loaded: url_helper
INFO - 2023-07-30 16:30:21 --> Helper loaded: file_helper
INFO - 2023-07-30 16:30:21 --> Helper loaded: html_helper
INFO - 2023-07-30 16:30:21 --> Helper loaded: text_helper
INFO - 2023-07-30 16:30:21 --> Helper loaded: form_helper
INFO - 2023-07-30 16:30:21 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:30:21 --> Helper loaded: security_helper
INFO - 2023-07-30 16:30:21 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:30:21 --> Database Driver Class Initialized
INFO - 2023-07-30 16:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:30:21 --> Parser Class Initialized
INFO - 2023-07-30 16:30:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:30:21 --> Pagination Class Initialized
INFO - 2023-07-30 16:30:21 --> Form Validation Class Initialized
INFO - 2023-07-30 16:30:21 --> Controller Class Initialized
INFO - 2023-07-30 16:30:21 --> Model Class Initialized
DEBUG - 2023-07-30 16:30:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:30:21 --> Model Class Initialized
INFO - 2023-07-30 16:30:21 --> Final output sent to browser
DEBUG - 2023-07-30 16:30:21 --> Total execution time: 0.0209
ERROR - 2023-07-30 16:30:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:30:22 --> Config Class Initialized
INFO - 2023-07-30 16:30:22 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:30:22 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:30:22 --> Utf8 Class Initialized
INFO - 2023-07-30 16:30:22 --> URI Class Initialized
DEBUG - 2023-07-30 16:30:22 --> No URI present. Default controller set.
INFO - 2023-07-30 16:30:22 --> Router Class Initialized
INFO - 2023-07-30 16:30:22 --> Output Class Initialized
INFO - 2023-07-30 16:30:22 --> Security Class Initialized
DEBUG - 2023-07-30 16:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:30:22 --> Input Class Initialized
INFO - 2023-07-30 16:30:22 --> Language Class Initialized
INFO - 2023-07-30 16:30:22 --> Loader Class Initialized
INFO - 2023-07-30 16:30:22 --> Helper loaded: url_helper
INFO - 2023-07-30 16:30:22 --> Helper loaded: file_helper
INFO - 2023-07-30 16:30:22 --> Helper loaded: html_helper
INFO - 2023-07-30 16:30:22 --> Helper loaded: text_helper
INFO - 2023-07-30 16:30:22 --> Helper loaded: form_helper
INFO - 2023-07-30 16:30:22 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:30:22 --> Helper loaded: security_helper
INFO - 2023-07-30 16:30:22 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:30:22 --> Database Driver Class Initialized
INFO - 2023-07-30 16:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:30:22 --> Parser Class Initialized
INFO - 2023-07-30 16:30:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:30:22 --> Pagination Class Initialized
INFO - 2023-07-30 16:30:22 --> Form Validation Class Initialized
INFO - 2023-07-30 16:30:22 --> Controller Class Initialized
INFO - 2023-07-30 16:30:22 --> Model Class Initialized
DEBUG - 2023-07-30 16:30:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:30:22 --> Model Class Initialized
DEBUG - 2023-07-30 16:30:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:30:22 --> Model Class Initialized
INFO - 2023-07-30 16:30:22 --> Model Class Initialized
INFO - 2023-07-30 16:30:22 --> Model Class Initialized
INFO - 2023-07-30 16:30:22 --> Model Class Initialized
DEBUG - 2023-07-30 16:30:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:30:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:30:22 --> Model Class Initialized
INFO - 2023-07-30 16:30:22 --> Model Class Initialized
INFO - 2023-07-30 16:30:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-30 16:30:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:30:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:30:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:30:22 --> Model Class Initialized
INFO - 2023-07-30 16:30:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:30:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:30:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:30:22 --> Final output sent to browser
DEBUG - 2023-07-30 16:30:22 --> Total execution time: 0.0900
ERROR - 2023-07-30 16:30:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:30:32 --> Config Class Initialized
INFO - 2023-07-30 16:30:32 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:30:32 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:30:32 --> Utf8 Class Initialized
INFO - 2023-07-30 16:30:32 --> URI Class Initialized
INFO - 2023-07-30 16:30:32 --> Router Class Initialized
INFO - 2023-07-30 16:30:32 --> Output Class Initialized
INFO - 2023-07-30 16:30:32 --> Security Class Initialized
DEBUG - 2023-07-30 16:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:30:32 --> Input Class Initialized
INFO - 2023-07-30 16:30:32 --> Language Class Initialized
INFO - 2023-07-30 16:30:32 --> Loader Class Initialized
INFO - 2023-07-30 16:30:32 --> Helper loaded: url_helper
INFO - 2023-07-30 16:30:32 --> Helper loaded: file_helper
INFO - 2023-07-30 16:30:32 --> Helper loaded: html_helper
INFO - 2023-07-30 16:30:32 --> Helper loaded: text_helper
INFO - 2023-07-30 16:30:32 --> Helper loaded: form_helper
INFO - 2023-07-30 16:30:32 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:30:32 --> Helper loaded: security_helper
INFO - 2023-07-30 16:30:32 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:30:32 --> Database Driver Class Initialized
INFO - 2023-07-30 16:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:30:32 --> Parser Class Initialized
INFO - 2023-07-30 16:30:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:30:32 --> Pagination Class Initialized
INFO - 2023-07-30 16:30:32 --> Form Validation Class Initialized
INFO - 2023-07-30 16:30:32 --> Controller Class Initialized
INFO - 2023-07-30 16:30:32 --> Model Class Initialized
DEBUG - 2023-07-30 16:30:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:30:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:30:32 --> Model Class Initialized
DEBUG - 2023-07-30 16:30:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:30:32 --> Model Class Initialized
INFO - 2023-07-30 16:30:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-30 16:30:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:30:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:30:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:30:32 --> Model Class Initialized
INFO - 2023-07-30 16:30:32 --> Model Class Initialized
INFO - 2023-07-30 16:30:32 --> Model Class Initialized
INFO - 2023-07-30 16:30:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:30:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:30:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:30:32 --> Final output sent to browser
DEBUG - 2023-07-30 16:30:32 --> Total execution time: 0.0755
ERROR - 2023-07-30 16:30:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:30:33 --> Config Class Initialized
INFO - 2023-07-30 16:30:33 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:30:33 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:30:33 --> Utf8 Class Initialized
INFO - 2023-07-30 16:30:33 --> URI Class Initialized
INFO - 2023-07-30 16:30:33 --> Router Class Initialized
INFO - 2023-07-30 16:30:33 --> Output Class Initialized
INFO - 2023-07-30 16:30:33 --> Security Class Initialized
DEBUG - 2023-07-30 16:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:30:33 --> Input Class Initialized
INFO - 2023-07-30 16:30:33 --> Language Class Initialized
INFO - 2023-07-30 16:30:33 --> Loader Class Initialized
INFO - 2023-07-30 16:30:33 --> Helper loaded: url_helper
INFO - 2023-07-30 16:30:33 --> Helper loaded: file_helper
INFO - 2023-07-30 16:30:33 --> Helper loaded: html_helper
INFO - 2023-07-30 16:30:33 --> Helper loaded: text_helper
INFO - 2023-07-30 16:30:33 --> Helper loaded: form_helper
INFO - 2023-07-30 16:30:33 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:30:33 --> Helper loaded: security_helper
INFO - 2023-07-30 16:30:33 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:30:33 --> Database Driver Class Initialized
INFO - 2023-07-30 16:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:30:33 --> Parser Class Initialized
INFO - 2023-07-30 16:30:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:30:33 --> Pagination Class Initialized
INFO - 2023-07-30 16:30:33 --> Form Validation Class Initialized
INFO - 2023-07-30 16:30:33 --> Controller Class Initialized
INFO - 2023-07-30 16:30:33 --> Model Class Initialized
DEBUG - 2023-07-30 16:30:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:30:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:30:33 --> Model Class Initialized
DEBUG - 2023-07-30 16:30:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:30:33 --> Model Class Initialized
INFO - 2023-07-30 16:30:33 --> Final output sent to browser
DEBUG - 2023-07-30 16:30:33 --> Total execution time: 0.0329
ERROR - 2023-07-30 16:31:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:31:41 --> Config Class Initialized
INFO - 2023-07-30 16:31:41 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:31:41 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:31:41 --> Utf8 Class Initialized
INFO - 2023-07-30 16:31:41 --> URI Class Initialized
INFO - 2023-07-30 16:31:41 --> Router Class Initialized
INFO - 2023-07-30 16:31:41 --> Output Class Initialized
INFO - 2023-07-30 16:31:41 --> Security Class Initialized
DEBUG - 2023-07-30 16:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:31:41 --> Input Class Initialized
INFO - 2023-07-30 16:31:41 --> Language Class Initialized
INFO - 2023-07-30 16:31:41 --> Loader Class Initialized
INFO - 2023-07-30 16:31:41 --> Helper loaded: url_helper
INFO - 2023-07-30 16:31:41 --> Helper loaded: file_helper
INFO - 2023-07-30 16:31:41 --> Helper loaded: html_helper
INFO - 2023-07-30 16:31:41 --> Helper loaded: text_helper
INFO - 2023-07-30 16:31:41 --> Helper loaded: form_helper
INFO - 2023-07-30 16:31:41 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:31:41 --> Helper loaded: security_helper
INFO - 2023-07-30 16:31:41 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:31:41 --> Database Driver Class Initialized
INFO - 2023-07-30 16:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:31:41 --> Parser Class Initialized
INFO - 2023-07-30 16:31:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:31:41 --> Pagination Class Initialized
INFO - 2023-07-30 16:31:41 --> Form Validation Class Initialized
INFO - 2023-07-30 16:31:41 --> Controller Class Initialized
INFO - 2023-07-30 16:31:41 --> Model Class Initialized
DEBUG - 2023-07-30 16:31:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:31:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:31:41 --> Model Class Initialized
INFO - 2023-07-30 16:31:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-07-30 16:31:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:31:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:31:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:31:41 --> Model Class Initialized
INFO - 2023-07-30 16:31:41 --> Model Class Initialized
INFO - 2023-07-30 16:31:41 --> Model Class Initialized
INFO - 2023-07-30 16:31:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:31:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:31:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:31:41 --> Final output sent to browser
DEBUG - 2023-07-30 16:31:41 --> Total execution time: 0.0699
ERROR - 2023-07-30 16:31:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:31:42 --> Config Class Initialized
INFO - 2023-07-30 16:31:42 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:31:42 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:31:42 --> Utf8 Class Initialized
INFO - 2023-07-30 16:31:42 --> URI Class Initialized
INFO - 2023-07-30 16:31:42 --> Router Class Initialized
INFO - 2023-07-30 16:31:42 --> Output Class Initialized
INFO - 2023-07-30 16:31:42 --> Security Class Initialized
DEBUG - 2023-07-30 16:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:31:42 --> Input Class Initialized
INFO - 2023-07-30 16:31:42 --> Language Class Initialized
INFO - 2023-07-30 16:31:42 --> Loader Class Initialized
INFO - 2023-07-30 16:31:42 --> Helper loaded: url_helper
INFO - 2023-07-30 16:31:42 --> Helper loaded: file_helper
INFO - 2023-07-30 16:31:42 --> Helper loaded: html_helper
INFO - 2023-07-30 16:31:42 --> Helper loaded: text_helper
INFO - 2023-07-30 16:31:42 --> Helper loaded: form_helper
INFO - 2023-07-30 16:31:42 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:31:42 --> Helper loaded: security_helper
INFO - 2023-07-30 16:31:42 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:31:42 --> Database Driver Class Initialized
INFO - 2023-07-30 16:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:31:42 --> Parser Class Initialized
INFO - 2023-07-30 16:31:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:31:42 --> Pagination Class Initialized
INFO - 2023-07-30 16:31:42 --> Form Validation Class Initialized
INFO - 2023-07-30 16:31:42 --> Controller Class Initialized
INFO - 2023-07-30 16:31:42 --> Model Class Initialized
DEBUG - 2023-07-30 16:31:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:31:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:31:42 --> Model Class Initialized
INFO - 2023-07-30 16:31:42 --> Final output sent to browser
DEBUG - 2023-07-30 16:31:42 --> Total execution time: 0.0218
ERROR - 2023-07-30 16:31:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:31:52 --> Config Class Initialized
INFO - 2023-07-30 16:31:52 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:31:52 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:31:52 --> Utf8 Class Initialized
INFO - 2023-07-30 16:31:52 --> URI Class Initialized
INFO - 2023-07-30 16:31:52 --> Router Class Initialized
INFO - 2023-07-30 16:31:52 --> Output Class Initialized
INFO - 2023-07-30 16:31:52 --> Security Class Initialized
DEBUG - 2023-07-30 16:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:31:52 --> Input Class Initialized
INFO - 2023-07-30 16:31:52 --> Language Class Initialized
INFO - 2023-07-30 16:31:52 --> Loader Class Initialized
INFO - 2023-07-30 16:31:52 --> Helper loaded: url_helper
INFO - 2023-07-30 16:31:52 --> Helper loaded: file_helper
INFO - 2023-07-30 16:31:52 --> Helper loaded: html_helper
INFO - 2023-07-30 16:31:52 --> Helper loaded: text_helper
INFO - 2023-07-30 16:31:52 --> Helper loaded: form_helper
INFO - 2023-07-30 16:31:52 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:31:52 --> Helper loaded: security_helper
INFO - 2023-07-30 16:31:52 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:31:52 --> Database Driver Class Initialized
INFO - 2023-07-30 16:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:31:52 --> Parser Class Initialized
INFO - 2023-07-30 16:31:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:31:52 --> Pagination Class Initialized
INFO - 2023-07-30 16:31:52 --> Form Validation Class Initialized
INFO - 2023-07-30 16:31:52 --> Controller Class Initialized
INFO - 2023-07-30 16:31:52 --> Model Class Initialized
DEBUG - 2023-07-30 16:31:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:31:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:31:52 --> Model Class Initialized
INFO - 2023-07-30 16:31:52 --> Final output sent to browser
DEBUG - 2023-07-30 16:31:52 --> Total execution time: 0.0232
ERROR - 2023-07-30 16:54:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:54:15 --> Config Class Initialized
INFO - 2023-07-30 16:54:15 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:54:15 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:54:15 --> Utf8 Class Initialized
INFO - 2023-07-30 16:54:15 --> URI Class Initialized
DEBUG - 2023-07-30 16:54:15 --> No URI present. Default controller set.
INFO - 2023-07-30 16:54:15 --> Router Class Initialized
INFO - 2023-07-30 16:54:15 --> Output Class Initialized
INFO - 2023-07-30 16:54:15 --> Security Class Initialized
DEBUG - 2023-07-30 16:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:54:15 --> Input Class Initialized
INFO - 2023-07-30 16:54:15 --> Language Class Initialized
INFO - 2023-07-30 16:54:15 --> Loader Class Initialized
INFO - 2023-07-30 16:54:15 --> Helper loaded: url_helper
INFO - 2023-07-30 16:54:15 --> Helper loaded: file_helper
INFO - 2023-07-30 16:54:15 --> Helper loaded: html_helper
INFO - 2023-07-30 16:54:15 --> Helper loaded: text_helper
INFO - 2023-07-30 16:54:15 --> Helper loaded: form_helper
INFO - 2023-07-30 16:54:15 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:54:15 --> Helper loaded: security_helper
INFO - 2023-07-30 16:54:15 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:54:15 --> Database Driver Class Initialized
INFO - 2023-07-30 16:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:54:15 --> Parser Class Initialized
INFO - 2023-07-30 16:54:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:54:15 --> Pagination Class Initialized
INFO - 2023-07-30 16:54:15 --> Form Validation Class Initialized
INFO - 2023-07-30 16:54:15 --> Controller Class Initialized
INFO - 2023-07-30 16:54:15 --> Model Class Initialized
DEBUG - 2023-07-30 16:54:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-30 16:54:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:54:16 --> Config Class Initialized
INFO - 2023-07-30 16:54:16 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:54:16 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:54:16 --> Utf8 Class Initialized
INFO - 2023-07-30 16:54:16 --> URI Class Initialized
INFO - 2023-07-30 16:54:16 --> Router Class Initialized
INFO - 2023-07-30 16:54:16 --> Output Class Initialized
INFO - 2023-07-30 16:54:16 --> Security Class Initialized
DEBUG - 2023-07-30 16:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:54:16 --> Input Class Initialized
INFO - 2023-07-30 16:54:16 --> Language Class Initialized
INFO - 2023-07-30 16:54:16 --> Loader Class Initialized
INFO - 2023-07-30 16:54:16 --> Helper loaded: url_helper
INFO - 2023-07-30 16:54:16 --> Helper loaded: file_helper
INFO - 2023-07-30 16:54:16 --> Helper loaded: html_helper
INFO - 2023-07-30 16:54:16 --> Helper loaded: text_helper
INFO - 2023-07-30 16:54:16 --> Helper loaded: form_helper
INFO - 2023-07-30 16:54:16 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:54:16 --> Helper loaded: security_helper
INFO - 2023-07-30 16:54:16 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:54:16 --> Database Driver Class Initialized
INFO - 2023-07-30 16:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:54:16 --> Parser Class Initialized
INFO - 2023-07-30 16:54:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:54:16 --> Pagination Class Initialized
INFO - 2023-07-30 16:54:16 --> Form Validation Class Initialized
INFO - 2023-07-30 16:54:16 --> Controller Class Initialized
INFO - 2023-07-30 16:54:16 --> Model Class Initialized
DEBUG - 2023-07-30 16:54:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:54:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-30 16:54:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:54:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:54:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:54:16 --> Model Class Initialized
INFO - 2023-07-30 16:54:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:54:16 --> Final output sent to browser
DEBUG - 2023-07-30 16:54:16 --> Total execution time: 0.0296
ERROR - 2023-07-30 16:54:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:54:41 --> Config Class Initialized
INFO - 2023-07-30 16:54:41 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:54:41 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:54:41 --> Utf8 Class Initialized
INFO - 2023-07-30 16:54:41 --> URI Class Initialized
INFO - 2023-07-30 16:54:41 --> Router Class Initialized
INFO - 2023-07-30 16:54:41 --> Output Class Initialized
INFO - 2023-07-30 16:54:41 --> Security Class Initialized
DEBUG - 2023-07-30 16:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:54:41 --> Input Class Initialized
INFO - 2023-07-30 16:54:41 --> Language Class Initialized
INFO - 2023-07-30 16:54:41 --> Loader Class Initialized
INFO - 2023-07-30 16:54:41 --> Helper loaded: url_helper
INFO - 2023-07-30 16:54:41 --> Helper loaded: file_helper
INFO - 2023-07-30 16:54:41 --> Helper loaded: html_helper
INFO - 2023-07-30 16:54:41 --> Helper loaded: text_helper
INFO - 2023-07-30 16:54:41 --> Helper loaded: form_helper
INFO - 2023-07-30 16:54:41 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:54:41 --> Helper loaded: security_helper
INFO - 2023-07-30 16:54:41 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:54:41 --> Database Driver Class Initialized
INFO - 2023-07-30 16:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:54:41 --> Parser Class Initialized
INFO - 2023-07-30 16:54:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:54:41 --> Pagination Class Initialized
INFO - 2023-07-30 16:54:41 --> Form Validation Class Initialized
INFO - 2023-07-30 16:54:41 --> Controller Class Initialized
INFO - 2023-07-30 16:54:41 --> Model Class Initialized
DEBUG - 2023-07-30 16:54:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:54:41 --> Model Class Initialized
INFO - 2023-07-30 16:54:41 --> Final output sent to browser
DEBUG - 2023-07-30 16:54:41 --> Total execution time: 0.0200
ERROR - 2023-07-30 16:54:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:54:42 --> Config Class Initialized
INFO - 2023-07-30 16:54:42 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:54:42 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:54:42 --> Utf8 Class Initialized
INFO - 2023-07-30 16:54:42 --> URI Class Initialized
DEBUG - 2023-07-30 16:54:42 --> No URI present. Default controller set.
INFO - 2023-07-30 16:54:42 --> Router Class Initialized
INFO - 2023-07-30 16:54:42 --> Output Class Initialized
INFO - 2023-07-30 16:54:42 --> Security Class Initialized
DEBUG - 2023-07-30 16:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:54:42 --> Input Class Initialized
INFO - 2023-07-30 16:54:42 --> Language Class Initialized
INFO - 2023-07-30 16:54:42 --> Loader Class Initialized
INFO - 2023-07-30 16:54:42 --> Helper loaded: url_helper
INFO - 2023-07-30 16:54:42 --> Helper loaded: file_helper
INFO - 2023-07-30 16:54:42 --> Helper loaded: html_helper
INFO - 2023-07-30 16:54:42 --> Helper loaded: text_helper
INFO - 2023-07-30 16:54:42 --> Helper loaded: form_helper
INFO - 2023-07-30 16:54:42 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:54:42 --> Helper loaded: security_helper
INFO - 2023-07-30 16:54:42 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:54:42 --> Database Driver Class Initialized
INFO - 2023-07-30 16:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:54:42 --> Parser Class Initialized
INFO - 2023-07-30 16:54:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:54:42 --> Pagination Class Initialized
INFO - 2023-07-30 16:54:42 --> Form Validation Class Initialized
INFO - 2023-07-30 16:54:42 --> Controller Class Initialized
INFO - 2023-07-30 16:54:42 --> Model Class Initialized
DEBUG - 2023-07-30 16:54:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:54:42 --> Model Class Initialized
DEBUG - 2023-07-30 16:54:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:54:42 --> Model Class Initialized
INFO - 2023-07-30 16:54:42 --> Model Class Initialized
INFO - 2023-07-30 16:54:42 --> Model Class Initialized
INFO - 2023-07-30 16:54:42 --> Model Class Initialized
DEBUG - 2023-07-30 16:54:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:54:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:54:42 --> Model Class Initialized
INFO - 2023-07-30 16:54:42 --> Model Class Initialized
INFO - 2023-07-30 16:54:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-30 16:54:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:54:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:54:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:54:42 --> Model Class Initialized
INFO - 2023-07-30 16:54:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:54:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:54:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:54:42 --> Final output sent to browser
DEBUG - 2023-07-30 16:54:42 --> Total execution time: 0.0749
ERROR - 2023-07-30 16:54:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:54:59 --> Config Class Initialized
INFO - 2023-07-30 16:54:59 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:54:59 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:54:59 --> Utf8 Class Initialized
INFO - 2023-07-30 16:54:59 --> URI Class Initialized
INFO - 2023-07-30 16:54:59 --> Router Class Initialized
INFO - 2023-07-30 16:54:59 --> Output Class Initialized
INFO - 2023-07-30 16:54:59 --> Security Class Initialized
DEBUG - 2023-07-30 16:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:54:59 --> Input Class Initialized
INFO - 2023-07-30 16:54:59 --> Language Class Initialized
INFO - 2023-07-30 16:54:59 --> Loader Class Initialized
INFO - 2023-07-30 16:54:59 --> Helper loaded: url_helper
INFO - 2023-07-30 16:54:59 --> Helper loaded: file_helper
INFO - 2023-07-30 16:54:59 --> Helper loaded: html_helper
INFO - 2023-07-30 16:54:59 --> Helper loaded: text_helper
INFO - 2023-07-30 16:54:59 --> Helper loaded: form_helper
INFO - 2023-07-30 16:54:59 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:54:59 --> Helper loaded: security_helper
INFO - 2023-07-30 16:54:59 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:54:59 --> Database Driver Class Initialized
INFO - 2023-07-30 16:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:54:59 --> Parser Class Initialized
INFO - 2023-07-30 16:54:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:54:59 --> Pagination Class Initialized
INFO - 2023-07-30 16:54:59 --> Form Validation Class Initialized
INFO - 2023-07-30 16:54:59 --> Controller Class Initialized
INFO - 2023-07-30 16:54:59 --> Model Class Initialized
DEBUG - 2023-07-30 16:54:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:54:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:54:59 --> Model Class Initialized
DEBUG - 2023-07-30 16:54:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:54:59 --> Model Class Initialized
INFO - 2023-07-30 16:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-07-30 16:54:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:54:59 --> Model Class Initialized
INFO - 2023-07-30 16:54:59 --> Model Class Initialized
INFO - 2023-07-30 16:54:59 --> Model Class Initialized
INFO - 2023-07-30 16:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:54:59 --> Final output sent to browser
DEBUG - 2023-07-30 16:54:59 --> Total execution time: 0.0690
ERROR - 2023-07-30 16:55:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:55:00 --> Config Class Initialized
INFO - 2023-07-30 16:55:00 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:55:00 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:55:00 --> Utf8 Class Initialized
INFO - 2023-07-30 16:55:00 --> URI Class Initialized
INFO - 2023-07-30 16:55:00 --> Router Class Initialized
INFO - 2023-07-30 16:55:00 --> Output Class Initialized
INFO - 2023-07-30 16:55:00 --> Security Class Initialized
DEBUG - 2023-07-30 16:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:55:00 --> Input Class Initialized
INFO - 2023-07-30 16:55:00 --> Language Class Initialized
INFO - 2023-07-30 16:55:00 --> Loader Class Initialized
INFO - 2023-07-30 16:55:00 --> Helper loaded: url_helper
INFO - 2023-07-30 16:55:00 --> Helper loaded: file_helper
INFO - 2023-07-30 16:55:00 --> Helper loaded: html_helper
INFO - 2023-07-30 16:55:00 --> Helper loaded: text_helper
INFO - 2023-07-30 16:55:00 --> Helper loaded: form_helper
INFO - 2023-07-30 16:55:00 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:55:00 --> Helper loaded: security_helper
INFO - 2023-07-30 16:55:00 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:55:00 --> Database Driver Class Initialized
INFO - 2023-07-30 16:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:55:00 --> Parser Class Initialized
INFO - 2023-07-30 16:55:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:55:00 --> Pagination Class Initialized
INFO - 2023-07-30 16:55:00 --> Form Validation Class Initialized
INFO - 2023-07-30 16:55:00 --> Controller Class Initialized
INFO - 2023-07-30 16:55:00 --> Model Class Initialized
DEBUG - 2023-07-30 16:55:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:55:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:55:00 --> Model Class Initialized
DEBUG - 2023-07-30 16:55:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:55:00 --> Model Class Initialized
INFO - 2023-07-30 16:55:00 --> Final output sent to browser
DEBUG - 2023-07-30 16:55:00 --> Total execution time: 0.0205
ERROR - 2023-07-30 16:55:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:55:23 --> Config Class Initialized
INFO - 2023-07-30 16:55:23 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:55:23 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:55:23 --> Utf8 Class Initialized
INFO - 2023-07-30 16:55:23 --> URI Class Initialized
DEBUG - 2023-07-30 16:55:23 --> No URI present. Default controller set.
INFO - 2023-07-30 16:55:23 --> Router Class Initialized
INFO - 2023-07-30 16:55:23 --> Output Class Initialized
INFO - 2023-07-30 16:55:23 --> Security Class Initialized
DEBUG - 2023-07-30 16:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:55:23 --> Input Class Initialized
INFO - 2023-07-30 16:55:23 --> Language Class Initialized
INFO - 2023-07-30 16:55:23 --> Loader Class Initialized
INFO - 2023-07-30 16:55:23 --> Helper loaded: url_helper
INFO - 2023-07-30 16:55:23 --> Helper loaded: file_helper
INFO - 2023-07-30 16:55:23 --> Helper loaded: html_helper
INFO - 2023-07-30 16:55:23 --> Helper loaded: text_helper
INFO - 2023-07-30 16:55:23 --> Helper loaded: form_helper
INFO - 2023-07-30 16:55:23 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:55:23 --> Helper loaded: security_helper
INFO - 2023-07-30 16:55:23 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:55:23 --> Database Driver Class Initialized
INFO - 2023-07-30 16:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:55:23 --> Parser Class Initialized
INFO - 2023-07-30 16:55:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:55:23 --> Pagination Class Initialized
INFO - 2023-07-30 16:55:23 --> Form Validation Class Initialized
INFO - 2023-07-30 16:55:23 --> Controller Class Initialized
INFO - 2023-07-30 16:55:23 --> Model Class Initialized
DEBUG - 2023-07-30 16:55:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:55:23 --> Model Class Initialized
DEBUG - 2023-07-30 16:55:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:55:23 --> Model Class Initialized
INFO - 2023-07-30 16:55:23 --> Model Class Initialized
INFO - 2023-07-30 16:55:23 --> Model Class Initialized
INFO - 2023-07-30 16:55:23 --> Model Class Initialized
DEBUG - 2023-07-30 16:55:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:55:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:55:23 --> Model Class Initialized
INFO - 2023-07-30 16:55:23 --> Model Class Initialized
INFO - 2023-07-30 16:55:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-30 16:55:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:55:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:55:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:55:23 --> Model Class Initialized
INFO - 2023-07-30 16:55:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:55:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:55:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:55:23 --> Final output sent to browser
DEBUG - 2023-07-30 16:55:23 --> Total execution time: 0.0796
ERROR - 2023-07-30 16:55:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:55:24 --> Config Class Initialized
INFO - 2023-07-30 16:55:24 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:55:24 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:55:24 --> Utf8 Class Initialized
INFO - 2023-07-30 16:55:24 --> URI Class Initialized
INFO - 2023-07-30 16:55:24 --> Router Class Initialized
INFO - 2023-07-30 16:55:24 --> Output Class Initialized
INFO - 2023-07-30 16:55:24 --> Security Class Initialized
DEBUG - 2023-07-30 16:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:55:24 --> Input Class Initialized
INFO - 2023-07-30 16:55:24 --> Language Class Initialized
INFO - 2023-07-30 16:55:24 --> Loader Class Initialized
INFO - 2023-07-30 16:55:24 --> Helper loaded: url_helper
INFO - 2023-07-30 16:55:24 --> Helper loaded: file_helper
INFO - 2023-07-30 16:55:24 --> Helper loaded: html_helper
INFO - 2023-07-30 16:55:24 --> Helper loaded: text_helper
INFO - 2023-07-30 16:55:24 --> Helper loaded: form_helper
INFO - 2023-07-30 16:55:24 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:55:24 --> Helper loaded: security_helper
INFO - 2023-07-30 16:55:24 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:55:24 --> Database Driver Class Initialized
INFO - 2023-07-30 16:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:55:24 --> Parser Class Initialized
INFO - 2023-07-30 16:55:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:55:24 --> Pagination Class Initialized
INFO - 2023-07-30 16:55:24 --> Form Validation Class Initialized
INFO - 2023-07-30 16:55:24 --> Controller Class Initialized
INFO - 2023-07-30 16:55:24 --> Model Class Initialized
DEBUG - 2023-07-30 16:55:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:55:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-30 16:55:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:55:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:55:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:55:24 --> Model Class Initialized
INFO - 2023-07-30 16:55:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:55:24 --> Final output sent to browser
DEBUG - 2023-07-30 16:55:24 --> Total execution time: 0.0297
ERROR - 2023-07-30 16:55:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:55:24 --> Config Class Initialized
INFO - 2023-07-30 16:55:24 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:55:24 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:55:24 --> Utf8 Class Initialized
INFO - 2023-07-30 16:55:24 --> URI Class Initialized
INFO - 2023-07-30 16:55:24 --> Router Class Initialized
INFO - 2023-07-30 16:55:24 --> Output Class Initialized
INFO - 2023-07-30 16:55:24 --> Security Class Initialized
DEBUG - 2023-07-30 16:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:55:24 --> Input Class Initialized
INFO - 2023-07-30 16:55:24 --> Language Class Initialized
INFO - 2023-07-30 16:55:24 --> Loader Class Initialized
INFO - 2023-07-30 16:55:24 --> Helper loaded: url_helper
INFO - 2023-07-30 16:55:24 --> Helper loaded: file_helper
INFO - 2023-07-30 16:55:24 --> Helper loaded: html_helper
INFO - 2023-07-30 16:55:24 --> Helper loaded: text_helper
INFO - 2023-07-30 16:55:24 --> Helper loaded: form_helper
INFO - 2023-07-30 16:55:24 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:55:24 --> Helper loaded: security_helper
INFO - 2023-07-30 16:55:24 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:55:24 --> Database Driver Class Initialized
INFO - 2023-07-30 16:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:55:24 --> Parser Class Initialized
INFO - 2023-07-30 16:55:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:55:24 --> Pagination Class Initialized
INFO - 2023-07-30 16:55:24 --> Form Validation Class Initialized
INFO - 2023-07-30 16:55:24 --> Controller Class Initialized
INFO - 2023-07-30 16:55:24 --> Model Class Initialized
DEBUG - 2023-07-30 16:55:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:55:24 --> Model Class Initialized
DEBUG - 2023-07-30 16:55:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:55:24 --> Model Class Initialized
INFO - 2023-07-30 16:55:24 --> Model Class Initialized
INFO - 2023-07-30 16:55:24 --> Model Class Initialized
INFO - 2023-07-30 16:55:24 --> Model Class Initialized
DEBUG - 2023-07-30 16:55:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:55:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:55:24 --> Model Class Initialized
INFO - 2023-07-30 16:55:24 --> Model Class Initialized
INFO - 2023-07-30 16:55:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-30 16:55:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:55:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:55:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:55:24 --> Model Class Initialized
INFO - 2023-07-30 16:55:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:55:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:55:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:55:24 --> Final output sent to browser
DEBUG - 2023-07-30 16:55:24 --> Total execution time: 0.0723
ERROR - 2023-07-30 16:56:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:56:01 --> Config Class Initialized
INFO - 2023-07-30 16:56:01 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:56:01 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:56:01 --> Utf8 Class Initialized
INFO - 2023-07-30 16:56:01 --> URI Class Initialized
INFO - 2023-07-30 16:56:01 --> Router Class Initialized
INFO - 2023-07-30 16:56:01 --> Output Class Initialized
INFO - 2023-07-30 16:56:01 --> Security Class Initialized
DEBUG - 2023-07-30 16:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:56:01 --> Input Class Initialized
INFO - 2023-07-30 16:56:01 --> Language Class Initialized
INFO - 2023-07-30 16:56:01 --> Loader Class Initialized
INFO - 2023-07-30 16:56:01 --> Helper loaded: url_helper
INFO - 2023-07-30 16:56:01 --> Helper loaded: file_helper
INFO - 2023-07-30 16:56:01 --> Helper loaded: html_helper
INFO - 2023-07-30 16:56:01 --> Helper loaded: text_helper
INFO - 2023-07-30 16:56:01 --> Helper loaded: form_helper
INFO - 2023-07-30 16:56:01 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:56:01 --> Helper loaded: security_helper
INFO - 2023-07-30 16:56:01 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:56:01 --> Database Driver Class Initialized
INFO - 2023-07-30 16:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:56:01 --> Parser Class Initialized
INFO - 2023-07-30 16:56:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:56:01 --> Pagination Class Initialized
INFO - 2023-07-30 16:56:01 --> Form Validation Class Initialized
INFO - 2023-07-30 16:56:01 --> Controller Class Initialized
INFO - 2023-07-30 16:56:01 --> Model Class Initialized
DEBUG - 2023-07-30 16:56:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:56:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:56:01 --> Model Class Initialized
DEBUG - 2023-07-30 16:56:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:56:01 --> Model Class Initialized
INFO - 2023-07-30 16:56:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-07-30 16:56:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:56:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:56:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:56:01 --> Model Class Initialized
INFO - 2023-07-30 16:56:01 --> Model Class Initialized
INFO - 2023-07-30 16:56:01 --> Model Class Initialized
INFO - 2023-07-30 16:56:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:56:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:56:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:56:01 --> Final output sent to browser
DEBUG - 2023-07-30 16:56:01 --> Total execution time: 0.0669
ERROR - 2023-07-30 16:56:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:56:02 --> Config Class Initialized
INFO - 2023-07-30 16:56:02 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:56:02 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:56:02 --> Utf8 Class Initialized
INFO - 2023-07-30 16:56:02 --> URI Class Initialized
INFO - 2023-07-30 16:56:02 --> Router Class Initialized
INFO - 2023-07-30 16:56:02 --> Output Class Initialized
INFO - 2023-07-30 16:56:02 --> Security Class Initialized
DEBUG - 2023-07-30 16:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:56:02 --> Input Class Initialized
INFO - 2023-07-30 16:56:02 --> Language Class Initialized
INFO - 2023-07-30 16:56:02 --> Loader Class Initialized
INFO - 2023-07-30 16:56:02 --> Helper loaded: url_helper
INFO - 2023-07-30 16:56:02 --> Helper loaded: file_helper
INFO - 2023-07-30 16:56:02 --> Helper loaded: html_helper
INFO - 2023-07-30 16:56:02 --> Helper loaded: text_helper
INFO - 2023-07-30 16:56:02 --> Helper loaded: form_helper
INFO - 2023-07-30 16:56:02 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:56:02 --> Helper loaded: security_helper
INFO - 2023-07-30 16:56:02 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:56:02 --> Database Driver Class Initialized
INFO - 2023-07-30 16:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:56:02 --> Parser Class Initialized
INFO - 2023-07-30 16:56:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:56:02 --> Pagination Class Initialized
INFO - 2023-07-30 16:56:02 --> Form Validation Class Initialized
INFO - 2023-07-30 16:56:02 --> Controller Class Initialized
INFO - 2023-07-30 16:56:02 --> Model Class Initialized
DEBUG - 2023-07-30 16:56:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:56:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:56:02 --> Model Class Initialized
DEBUG - 2023-07-30 16:56:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:56:02 --> Model Class Initialized
INFO - 2023-07-30 16:56:02 --> Final output sent to browser
DEBUG - 2023-07-30 16:56:02 --> Total execution time: 0.0239
ERROR - 2023-07-30 16:56:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:56:06 --> Config Class Initialized
INFO - 2023-07-30 16:56:06 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:56:06 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:56:06 --> Utf8 Class Initialized
INFO - 2023-07-30 16:56:06 --> URI Class Initialized
INFO - 2023-07-30 16:56:06 --> Router Class Initialized
INFO - 2023-07-30 16:56:06 --> Output Class Initialized
INFO - 2023-07-30 16:56:06 --> Security Class Initialized
DEBUG - 2023-07-30 16:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:56:06 --> Input Class Initialized
INFO - 2023-07-30 16:56:06 --> Language Class Initialized
INFO - 2023-07-30 16:56:06 --> Loader Class Initialized
INFO - 2023-07-30 16:56:06 --> Helper loaded: url_helper
INFO - 2023-07-30 16:56:06 --> Helper loaded: file_helper
INFO - 2023-07-30 16:56:06 --> Helper loaded: html_helper
INFO - 2023-07-30 16:56:06 --> Helper loaded: text_helper
INFO - 2023-07-30 16:56:06 --> Helper loaded: form_helper
INFO - 2023-07-30 16:56:06 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:56:06 --> Helper loaded: security_helper
INFO - 2023-07-30 16:56:06 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:56:06 --> Database Driver Class Initialized
INFO - 2023-07-30 16:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:56:06 --> Parser Class Initialized
INFO - 2023-07-30 16:56:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:56:06 --> Pagination Class Initialized
INFO - 2023-07-30 16:56:06 --> Form Validation Class Initialized
INFO - 2023-07-30 16:56:06 --> Controller Class Initialized
INFO - 2023-07-30 16:56:06 --> Model Class Initialized
DEBUG - 2023-07-30 16:56:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:56:06 --> Model Class Initialized
DEBUG - 2023-07-30 16:56:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:56:06 --> Model Class Initialized
INFO - 2023-07-30 16:56:06 --> Model Class Initialized
INFO - 2023-07-30 16:56:06 --> Model Class Initialized
INFO - 2023-07-30 16:56:06 --> Model Class Initialized
DEBUG - 2023-07-30 16:56:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:56:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:56:06 --> Model Class Initialized
INFO - 2023-07-30 16:56:06 --> Model Class Initialized
INFO - 2023-07-30 16:56:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-30 16:56:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:56:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:56:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:56:06 --> Model Class Initialized
INFO - 2023-07-30 16:56:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:56:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:56:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:56:06 --> Final output sent to browser
DEBUG - 2023-07-30 16:56:06 --> Total execution time: 0.0750
ERROR - 2023-07-30 16:56:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:56:12 --> Config Class Initialized
INFO - 2023-07-30 16:56:12 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:56:12 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:56:12 --> Utf8 Class Initialized
INFO - 2023-07-30 16:56:12 --> URI Class Initialized
INFO - 2023-07-30 16:56:12 --> Router Class Initialized
INFO - 2023-07-30 16:56:12 --> Output Class Initialized
INFO - 2023-07-30 16:56:12 --> Security Class Initialized
DEBUG - 2023-07-30 16:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:56:12 --> Input Class Initialized
INFO - 2023-07-30 16:56:12 --> Language Class Initialized
INFO - 2023-07-30 16:56:12 --> Loader Class Initialized
INFO - 2023-07-30 16:56:12 --> Helper loaded: url_helper
INFO - 2023-07-30 16:56:12 --> Helper loaded: file_helper
INFO - 2023-07-30 16:56:12 --> Helper loaded: html_helper
INFO - 2023-07-30 16:56:12 --> Helper loaded: text_helper
INFO - 2023-07-30 16:56:12 --> Helper loaded: form_helper
INFO - 2023-07-30 16:56:12 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:56:12 --> Helper loaded: security_helper
INFO - 2023-07-30 16:56:12 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:56:12 --> Database Driver Class Initialized
INFO - 2023-07-30 16:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:56:12 --> Parser Class Initialized
INFO - 2023-07-30 16:56:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:56:12 --> Pagination Class Initialized
INFO - 2023-07-30 16:56:12 --> Form Validation Class Initialized
INFO - 2023-07-30 16:56:12 --> Controller Class Initialized
INFO - 2023-07-30 16:56:12 --> Model Class Initialized
INFO - 2023-07-30 16:56:12 --> Model Class Initialized
INFO - 2023-07-30 16:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-07-30 16:56:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:56:12 --> Model Class Initialized
INFO - 2023-07-30 16:56:12 --> Model Class Initialized
INFO - 2023-07-30 16:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:56:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:56:12 --> Final output sent to browser
DEBUG - 2023-07-30 16:56:12 --> Total execution time: 0.0684
ERROR - 2023-07-30 16:56:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:56:13 --> Config Class Initialized
INFO - 2023-07-30 16:56:13 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:56:13 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:56:13 --> Utf8 Class Initialized
INFO - 2023-07-30 16:56:13 --> URI Class Initialized
INFO - 2023-07-30 16:56:13 --> Router Class Initialized
INFO - 2023-07-30 16:56:13 --> Output Class Initialized
INFO - 2023-07-30 16:56:13 --> Security Class Initialized
DEBUG - 2023-07-30 16:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:56:13 --> Input Class Initialized
INFO - 2023-07-30 16:56:13 --> Language Class Initialized
INFO - 2023-07-30 16:56:13 --> Loader Class Initialized
INFO - 2023-07-30 16:56:13 --> Helper loaded: url_helper
INFO - 2023-07-30 16:56:13 --> Helper loaded: file_helper
INFO - 2023-07-30 16:56:13 --> Helper loaded: html_helper
INFO - 2023-07-30 16:56:13 --> Helper loaded: text_helper
INFO - 2023-07-30 16:56:13 --> Helper loaded: form_helper
INFO - 2023-07-30 16:56:13 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:56:13 --> Helper loaded: security_helper
INFO - 2023-07-30 16:56:13 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:56:13 --> Database Driver Class Initialized
INFO - 2023-07-30 16:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:56:13 --> Parser Class Initialized
INFO - 2023-07-30 16:56:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:56:13 --> Pagination Class Initialized
INFO - 2023-07-30 16:56:13 --> Form Validation Class Initialized
INFO - 2023-07-30 16:56:13 --> Controller Class Initialized
INFO - 2023-07-30 16:56:13 --> Model Class Initialized
INFO - 2023-07-30 16:56:13 --> Model Class Initialized
INFO - 2023-07-30 16:56:13 --> Final output sent to browser
DEBUG - 2023-07-30 16:56:13 --> Total execution time: 0.0201
ERROR - 2023-07-30 16:56:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 16:56:30 --> Config Class Initialized
INFO - 2023-07-30 16:56:30 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:56:30 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:56:30 --> Utf8 Class Initialized
INFO - 2023-07-30 16:56:30 --> URI Class Initialized
INFO - 2023-07-30 16:56:30 --> Router Class Initialized
INFO - 2023-07-30 16:56:30 --> Output Class Initialized
INFO - 2023-07-30 16:56:30 --> Security Class Initialized
DEBUG - 2023-07-30 16:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:56:30 --> Input Class Initialized
INFO - 2023-07-30 16:56:30 --> Language Class Initialized
INFO - 2023-07-30 16:56:30 --> Loader Class Initialized
INFO - 2023-07-30 16:56:30 --> Helper loaded: url_helper
INFO - 2023-07-30 16:56:30 --> Helper loaded: file_helper
INFO - 2023-07-30 16:56:30 --> Helper loaded: html_helper
INFO - 2023-07-30 16:56:30 --> Helper loaded: text_helper
INFO - 2023-07-30 16:56:30 --> Helper loaded: form_helper
INFO - 2023-07-30 16:56:30 --> Helper loaded: lang_helper
INFO - 2023-07-30 16:56:30 --> Helper loaded: security_helper
INFO - 2023-07-30 16:56:30 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:56:30 --> Database Driver Class Initialized
INFO - 2023-07-30 16:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:56:30 --> Parser Class Initialized
INFO - 2023-07-30 16:56:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 16:56:30 --> Pagination Class Initialized
INFO - 2023-07-30 16:56:30 --> Form Validation Class Initialized
INFO - 2023-07-30 16:56:30 --> Controller Class Initialized
INFO - 2023-07-30 16:56:30 --> Model Class Initialized
DEBUG - 2023-07-30 16:56:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:56:30 --> Model Class Initialized
DEBUG - 2023-07-30 16:56:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:56:30 --> Model Class Initialized
INFO - 2023-07-30 16:56:30 --> Model Class Initialized
INFO - 2023-07-30 16:56:30 --> Model Class Initialized
INFO - 2023-07-30 16:56:30 --> Model Class Initialized
DEBUG - 2023-07-30 16:56:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 16:56:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:56:30 --> Model Class Initialized
INFO - 2023-07-30 16:56:30 --> Model Class Initialized
INFO - 2023-07-30 16:56:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-30 16:56:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 16:56:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 16:56:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 16:56:30 --> Model Class Initialized
INFO - 2023-07-30 16:56:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 16:56:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 16:56:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 16:56:30 --> Final output sent to browser
DEBUG - 2023-07-30 16:56:30 --> Total execution time: 0.0794
ERROR - 2023-07-30 17:01:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 17:01:35 --> Config Class Initialized
INFO - 2023-07-30 17:01:35 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:01:35 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:01:35 --> Utf8 Class Initialized
INFO - 2023-07-30 17:01:35 --> URI Class Initialized
DEBUG - 2023-07-30 17:01:35 --> No URI present. Default controller set.
INFO - 2023-07-30 17:01:35 --> Router Class Initialized
INFO - 2023-07-30 17:01:35 --> Output Class Initialized
INFO - 2023-07-30 17:01:35 --> Security Class Initialized
DEBUG - 2023-07-30 17:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:01:35 --> Input Class Initialized
INFO - 2023-07-30 17:01:35 --> Language Class Initialized
INFO - 2023-07-30 17:01:35 --> Loader Class Initialized
INFO - 2023-07-30 17:01:35 --> Helper loaded: url_helper
INFO - 2023-07-30 17:01:35 --> Helper loaded: file_helper
INFO - 2023-07-30 17:01:35 --> Helper loaded: html_helper
INFO - 2023-07-30 17:01:35 --> Helper loaded: text_helper
INFO - 2023-07-30 17:01:35 --> Helper loaded: form_helper
INFO - 2023-07-30 17:01:35 --> Helper loaded: lang_helper
INFO - 2023-07-30 17:01:35 --> Helper loaded: security_helper
INFO - 2023-07-30 17:01:35 --> Helper loaded: cookie_helper
INFO - 2023-07-30 17:01:35 --> Database Driver Class Initialized
INFO - 2023-07-30 17:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:01:35 --> Parser Class Initialized
INFO - 2023-07-30 17:01:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 17:01:35 --> Pagination Class Initialized
INFO - 2023-07-30 17:01:35 --> Form Validation Class Initialized
INFO - 2023-07-30 17:01:35 --> Controller Class Initialized
INFO - 2023-07-30 17:01:35 --> Model Class Initialized
DEBUG - 2023-07-30 17:01:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 17:01:35 --> Model Class Initialized
DEBUG - 2023-07-30 17:01:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 17:01:35 --> Model Class Initialized
INFO - 2023-07-30 17:01:35 --> Model Class Initialized
INFO - 2023-07-30 17:01:35 --> Model Class Initialized
INFO - 2023-07-30 17:01:35 --> Model Class Initialized
DEBUG - 2023-07-30 17:01:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 17:01:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 17:01:35 --> Model Class Initialized
INFO - 2023-07-30 17:01:35 --> Model Class Initialized
INFO - 2023-07-30 17:01:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-07-30 17:01:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 17:01:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 17:01:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 17:01:35 --> Model Class Initialized
INFO - 2023-07-30 17:01:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 17:01:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 17:01:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 17:01:35 --> Final output sent to browser
DEBUG - 2023-07-30 17:01:35 --> Total execution time: 0.2009
ERROR - 2023-07-30 17:01:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 17:01:42 --> Config Class Initialized
INFO - 2023-07-30 17:01:42 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:01:42 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:01:42 --> Utf8 Class Initialized
INFO - 2023-07-30 17:01:42 --> URI Class Initialized
INFO - 2023-07-30 17:01:42 --> Router Class Initialized
INFO - 2023-07-30 17:01:42 --> Output Class Initialized
INFO - 2023-07-30 17:01:42 --> Security Class Initialized
DEBUG - 2023-07-30 17:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:01:42 --> Input Class Initialized
INFO - 2023-07-30 17:01:42 --> Language Class Initialized
INFO - 2023-07-30 17:01:42 --> Loader Class Initialized
INFO - 2023-07-30 17:01:42 --> Helper loaded: url_helper
INFO - 2023-07-30 17:01:42 --> Helper loaded: file_helper
INFO - 2023-07-30 17:01:42 --> Helper loaded: html_helper
INFO - 2023-07-30 17:01:42 --> Helper loaded: text_helper
INFO - 2023-07-30 17:01:42 --> Helper loaded: form_helper
INFO - 2023-07-30 17:01:42 --> Helper loaded: lang_helper
INFO - 2023-07-30 17:01:42 --> Helper loaded: security_helper
INFO - 2023-07-30 17:01:42 --> Helper loaded: cookie_helper
INFO - 2023-07-30 17:01:42 --> Database Driver Class Initialized
INFO - 2023-07-30 17:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:01:42 --> Parser Class Initialized
INFO - 2023-07-30 17:01:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 17:01:42 --> Pagination Class Initialized
INFO - 2023-07-30 17:01:42 --> Form Validation Class Initialized
INFO - 2023-07-30 17:01:42 --> Controller Class Initialized
INFO - 2023-07-30 17:01:42 --> Model Class Initialized
INFO - 2023-07-30 17:01:43 --> Model Class Initialized
INFO - 2023-07-30 17:01:43 --> Model Class Initialized
INFO - 2023-07-30 17:01:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-07-30 17:01:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 17:01:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 17:01:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 17:01:43 --> Model Class Initialized
INFO - 2023-07-30 17:01:43 --> Model Class Initialized
INFO - 2023-07-30 17:01:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 17:01:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 17:01:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 17:01:43 --> Final output sent to browser
DEBUG - 2023-07-30 17:01:43 --> Total execution time: 0.1403
ERROR - 2023-07-30 17:01:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 17:01:43 --> Config Class Initialized
INFO - 2023-07-30 17:01:43 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:01:43 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:01:43 --> Utf8 Class Initialized
INFO - 2023-07-30 17:01:43 --> URI Class Initialized
INFO - 2023-07-30 17:01:43 --> Router Class Initialized
INFO - 2023-07-30 17:01:43 --> Output Class Initialized
INFO - 2023-07-30 17:01:43 --> Security Class Initialized
DEBUG - 2023-07-30 17:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:01:43 --> Input Class Initialized
INFO - 2023-07-30 17:01:43 --> Language Class Initialized
INFO - 2023-07-30 17:01:43 --> Loader Class Initialized
INFO - 2023-07-30 17:01:43 --> Helper loaded: url_helper
INFO - 2023-07-30 17:01:43 --> Helper loaded: file_helper
INFO - 2023-07-30 17:01:43 --> Helper loaded: html_helper
INFO - 2023-07-30 17:01:43 --> Helper loaded: text_helper
INFO - 2023-07-30 17:01:43 --> Helper loaded: form_helper
INFO - 2023-07-30 17:01:43 --> Helper loaded: lang_helper
INFO - 2023-07-30 17:01:43 --> Helper loaded: security_helper
INFO - 2023-07-30 17:01:43 --> Helper loaded: cookie_helper
INFO - 2023-07-30 17:01:43 --> Database Driver Class Initialized
INFO - 2023-07-30 17:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:01:43 --> Parser Class Initialized
INFO - 2023-07-30 17:01:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 17:01:43 --> Pagination Class Initialized
INFO - 2023-07-30 17:01:43 --> Form Validation Class Initialized
INFO - 2023-07-30 17:01:43 --> Controller Class Initialized
INFO - 2023-07-30 17:01:43 --> Model Class Initialized
INFO - 2023-07-30 17:01:43 --> Model Class Initialized
INFO - 2023-07-30 17:01:43 --> Final output sent to browser
DEBUG - 2023-07-30 17:01:43 --> Total execution time: 0.0269
ERROR - 2023-07-30 17:01:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 17:01:48 --> Config Class Initialized
INFO - 2023-07-30 17:01:48 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:01:48 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:01:48 --> Utf8 Class Initialized
INFO - 2023-07-30 17:01:48 --> URI Class Initialized
INFO - 2023-07-30 17:01:48 --> Router Class Initialized
INFO - 2023-07-30 17:01:48 --> Output Class Initialized
INFO - 2023-07-30 17:01:48 --> Security Class Initialized
DEBUG - 2023-07-30 17:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:01:48 --> Input Class Initialized
INFO - 2023-07-30 17:01:48 --> Language Class Initialized
INFO - 2023-07-30 17:01:48 --> Loader Class Initialized
INFO - 2023-07-30 17:01:48 --> Helper loaded: url_helper
INFO - 2023-07-30 17:01:48 --> Helper loaded: file_helper
INFO - 2023-07-30 17:01:48 --> Helper loaded: html_helper
INFO - 2023-07-30 17:01:48 --> Helper loaded: text_helper
INFO - 2023-07-30 17:01:48 --> Helper loaded: form_helper
INFO - 2023-07-30 17:01:48 --> Helper loaded: lang_helper
INFO - 2023-07-30 17:01:48 --> Helper loaded: security_helper
INFO - 2023-07-30 17:01:48 --> Helper loaded: cookie_helper
INFO - 2023-07-30 17:01:48 --> Database Driver Class Initialized
INFO - 2023-07-30 17:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:01:48 --> Parser Class Initialized
INFO - 2023-07-30 17:01:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 17:01:48 --> Pagination Class Initialized
INFO - 2023-07-30 17:01:48 --> Form Validation Class Initialized
INFO - 2023-07-30 17:01:48 --> Controller Class Initialized
INFO - 2023-07-30 17:01:48 --> Model Class Initialized
INFO - 2023-07-30 17:01:48 --> Model Class Initialized
INFO - 2023-07-30 17:01:48 --> Final output sent to browser
DEBUG - 2023-07-30 17:01:48 --> Total execution time: 0.0397
ERROR - 2023-07-30 17:04:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 17:04:07 --> Config Class Initialized
INFO - 2023-07-30 17:04:07 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:04:07 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:04:07 --> Utf8 Class Initialized
INFO - 2023-07-30 17:04:07 --> URI Class Initialized
INFO - 2023-07-30 17:04:07 --> Router Class Initialized
INFO - 2023-07-30 17:04:07 --> Output Class Initialized
INFO - 2023-07-30 17:04:07 --> Security Class Initialized
DEBUG - 2023-07-30 17:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:04:07 --> Input Class Initialized
INFO - 2023-07-30 17:04:07 --> Language Class Initialized
INFO - 2023-07-30 17:04:07 --> Loader Class Initialized
INFO - 2023-07-30 17:04:07 --> Helper loaded: url_helper
INFO - 2023-07-30 17:04:07 --> Helper loaded: file_helper
INFO - 2023-07-30 17:04:07 --> Helper loaded: html_helper
INFO - 2023-07-30 17:04:07 --> Helper loaded: text_helper
INFO - 2023-07-30 17:04:07 --> Helper loaded: form_helper
INFO - 2023-07-30 17:04:07 --> Helper loaded: lang_helper
INFO - 2023-07-30 17:04:07 --> Helper loaded: security_helper
INFO - 2023-07-30 17:04:07 --> Helper loaded: cookie_helper
INFO - 2023-07-30 17:04:07 --> Database Driver Class Initialized
INFO - 2023-07-30 17:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:04:07 --> Parser Class Initialized
INFO - 2023-07-30 17:04:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 17:04:07 --> Pagination Class Initialized
INFO - 2023-07-30 17:04:07 --> Form Validation Class Initialized
INFO - 2023-07-30 17:04:07 --> Controller Class Initialized
DEBUG - 2023-07-30 17:04:07 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-30 17:04:07 --> Model Class Initialized
INFO - 2023-07-30 17:04:07 --> Model Class Initialized
INFO - 2023-07-30 17:04:07 --> Model Class Initialized
INFO - 2023-07-30 17:04:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-07-30 17:04:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 17:04:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 17:04:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 17:04:07 --> Model Class Initialized
INFO - 2023-07-30 17:04:07 --> Model Class Initialized
INFO - 2023-07-30 17:04:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 17:04:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 17:04:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 17:04:07 --> Final output sent to browser
DEBUG - 2023-07-30 17:04:07 --> Total execution time: 0.1661
ERROR - 2023-07-30 17:04:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 17:04:16 --> Config Class Initialized
INFO - 2023-07-30 17:04:16 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:04:16 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:04:16 --> Utf8 Class Initialized
INFO - 2023-07-30 17:04:16 --> URI Class Initialized
INFO - 2023-07-30 17:04:16 --> Router Class Initialized
INFO - 2023-07-30 17:04:16 --> Output Class Initialized
INFO - 2023-07-30 17:04:16 --> Security Class Initialized
DEBUG - 2023-07-30 17:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:04:16 --> Input Class Initialized
INFO - 2023-07-30 17:04:16 --> Language Class Initialized
INFO - 2023-07-30 17:04:16 --> Loader Class Initialized
INFO - 2023-07-30 17:04:16 --> Helper loaded: url_helper
INFO - 2023-07-30 17:04:16 --> Helper loaded: file_helper
INFO - 2023-07-30 17:04:16 --> Helper loaded: html_helper
INFO - 2023-07-30 17:04:16 --> Helper loaded: text_helper
INFO - 2023-07-30 17:04:16 --> Helper loaded: form_helper
INFO - 2023-07-30 17:04:16 --> Helper loaded: lang_helper
INFO - 2023-07-30 17:04:16 --> Helper loaded: security_helper
INFO - 2023-07-30 17:04:16 --> Helper loaded: cookie_helper
INFO - 2023-07-30 17:04:16 --> Database Driver Class Initialized
INFO - 2023-07-30 17:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:04:16 --> Parser Class Initialized
INFO - 2023-07-30 17:04:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 17:04:16 --> Pagination Class Initialized
INFO - 2023-07-30 17:04:16 --> Form Validation Class Initialized
INFO - 2023-07-30 17:04:16 --> Controller Class Initialized
DEBUG - 2023-07-30 17:04:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-07-30 17:04:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-30 17:04:16 --> Model Class Initialized
INFO - 2023-07-30 17:04:16 --> Model Class Initialized
INFO - 2023-07-30 17:04:16 --> Model Class Initialized
INFO - 2023-07-30 17:04:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/manufacturer/manufacturer_details.php
DEBUG - 2023-07-30 17:04:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 17:04:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 17:04:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 17:04:16 --> Model Class Initialized
INFO - 2023-07-30 17:04:16 --> Model Class Initialized
INFO - 2023-07-30 17:04:16 --> Model Class Initialized
INFO - 2023-07-30 17:04:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 17:04:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 17:04:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 17:04:16 --> Final output sent to browser
DEBUG - 2023-07-30 17:04:16 --> Total execution time: 0.1428
ERROR - 2023-07-30 17:04:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 17:04:39 --> Config Class Initialized
INFO - 2023-07-30 17:04:39 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:04:39 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:04:39 --> Utf8 Class Initialized
INFO - 2023-07-30 17:04:39 --> URI Class Initialized
INFO - 2023-07-30 17:04:39 --> Router Class Initialized
INFO - 2023-07-30 17:04:39 --> Output Class Initialized
INFO - 2023-07-30 17:04:39 --> Security Class Initialized
DEBUG - 2023-07-30 17:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:04:39 --> Input Class Initialized
INFO - 2023-07-30 17:04:39 --> Language Class Initialized
INFO - 2023-07-30 17:04:39 --> Loader Class Initialized
INFO - 2023-07-30 17:04:39 --> Helper loaded: url_helper
INFO - 2023-07-30 17:04:39 --> Helper loaded: file_helper
INFO - 2023-07-30 17:04:39 --> Helper loaded: html_helper
INFO - 2023-07-30 17:04:39 --> Helper loaded: text_helper
INFO - 2023-07-30 17:04:39 --> Helper loaded: form_helper
INFO - 2023-07-30 17:04:39 --> Helper loaded: lang_helper
INFO - 2023-07-30 17:04:39 --> Helper loaded: security_helper
INFO - 2023-07-30 17:04:39 --> Helper loaded: cookie_helper
INFO - 2023-07-30 17:04:39 --> Database Driver Class Initialized
INFO - 2023-07-30 17:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:04:39 --> Parser Class Initialized
INFO - 2023-07-30 17:04:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 17:04:39 --> Pagination Class Initialized
INFO - 2023-07-30 17:04:39 --> Form Validation Class Initialized
INFO - 2023-07-30 17:04:39 --> Controller Class Initialized
INFO - 2023-07-30 17:04:39 --> Model Class Initialized
INFO - 2023-07-30 17:04:39 --> Model Class Initialized
INFO - 2023-07-30 17:04:39 --> Model Class Initialized
INFO - 2023-07-30 17:04:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-07-30 17:04:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 17:04:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 17:04:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 17:04:39 --> Model Class Initialized
INFO - 2023-07-30 17:04:39 --> Model Class Initialized
INFO - 2023-07-30 17:04:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 17:04:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 17:04:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 17:04:39 --> Final output sent to browser
DEBUG - 2023-07-30 17:04:39 --> Total execution time: 0.1338
ERROR - 2023-07-30 17:04:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 17:04:40 --> Config Class Initialized
INFO - 2023-07-30 17:04:40 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:04:40 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:04:40 --> Utf8 Class Initialized
INFO - 2023-07-30 17:04:40 --> URI Class Initialized
INFO - 2023-07-30 17:04:40 --> Router Class Initialized
INFO - 2023-07-30 17:04:40 --> Output Class Initialized
INFO - 2023-07-30 17:04:40 --> Security Class Initialized
DEBUG - 2023-07-30 17:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:04:40 --> Input Class Initialized
INFO - 2023-07-30 17:04:40 --> Language Class Initialized
INFO - 2023-07-30 17:04:40 --> Loader Class Initialized
INFO - 2023-07-30 17:04:40 --> Helper loaded: url_helper
INFO - 2023-07-30 17:04:40 --> Helper loaded: file_helper
INFO - 2023-07-30 17:04:40 --> Helper loaded: html_helper
INFO - 2023-07-30 17:04:40 --> Helper loaded: text_helper
INFO - 2023-07-30 17:04:40 --> Helper loaded: form_helper
INFO - 2023-07-30 17:04:40 --> Helper loaded: lang_helper
INFO - 2023-07-30 17:04:40 --> Helper loaded: security_helper
INFO - 2023-07-30 17:04:40 --> Helper loaded: cookie_helper
INFO - 2023-07-30 17:04:40 --> Database Driver Class Initialized
INFO - 2023-07-30 17:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:04:40 --> Parser Class Initialized
INFO - 2023-07-30 17:04:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 17:04:40 --> Pagination Class Initialized
INFO - 2023-07-30 17:04:40 --> Form Validation Class Initialized
INFO - 2023-07-30 17:04:40 --> Controller Class Initialized
INFO - 2023-07-30 17:04:40 --> Model Class Initialized
INFO - 2023-07-30 17:04:40 --> Model Class Initialized
INFO - 2023-07-30 17:04:40 --> Final output sent to browser
DEBUG - 2023-07-30 17:04:40 --> Total execution time: 0.0318
ERROR - 2023-07-30 17:04:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 17:04:44 --> Config Class Initialized
INFO - 2023-07-30 17:04:44 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:04:44 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:04:44 --> Utf8 Class Initialized
INFO - 2023-07-30 17:04:44 --> URI Class Initialized
INFO - 2023-07-30 17:04:44 --> Router Class Initialized
INFO - 2023-07-30 17:04:44 --> Output Class Initialized
INFO - 2023-07-30 17:04:44 --> Security Class Initialized
DEBUG - 2023-07-30 17:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:04:44 --> Input Class Initialized
INFO - 2023-07-30 17:04:44 --> Language Class Initialized
INFO - 2023-07-30 17:04:44 --> Loader Class Initialized
INFO - 2023-07-30 17:04:44 --> Helper loaded: url_helper
INFO - 2023-07-30 17:04:44 --> Helper loaded: file_helper
INFO - 2023-07-30 17:04:44 --> Helper loaded: html_helper
INFO - 2023-07-30 17:04:44 --> Helper loaded: text_helper
INFO - 2023-07-30 17:04:44 --> Helper loaded: form_helper
INFO - 2023-07-30 17:04:44 --> Helper loaded: lang_helper
INFO - 2023-07-30 17:04:44 --> Helper loaded: security_helper
INFO - 2023-07-30 17:04:44 --> Helper loaded: cookie_helper
INFO - 2023-07-30 17:04:44 --> Database Driver Class Initialized
INFO - 2023-07-30 17:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:04:44 --> Parser Class Initialized
INFO - 2023-07-30 17:04:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 17:04:44 --> Pagination Class Initialized
INFO - 2023-07-30 17:04:44 --> Form Validation Class Initialized
INFO - 2023-07-30 17:04:44 --> Controller Class Initialized
INFO - 2023-07-30 17:04:44 --> Model Class Initialized
INFO - 2023-07-30 17:04:44 --> Model Class Initialized
INFO - 2023-07-30 17:04:44 --> Final output sent to browser
DEBUG - 2023-07-30 17:04:44 --> Total execution time: 0.0433
ERROR - 2023-07-30 17:04:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-30 17:04:50 --> Config Class Initialized
INFO - 2023-07-30 17:04:50 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:04:50 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:04:50 --> Utf8 Class Initialized
INFO - 2023-07-30 17:04:50 --> URI Class Initialized
INFO - 2023-07-30 17:04:50 --> Router Class Initialized
INFO - 2023-07-30 17:04:50 --> Output Class Initialized
INFO - 2023-07-30 17:04:50 --> Security Class Initialized
DEBUG - 2023-07-30 17:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:04:50 --> Input Class Initialized
INFO - 2023-07-30 17:04:50 --> Language Class Initialized
INFO - 2023-07-30 17:04:50 --> Loader Class Initialized
INFO - 2023-07-30 17:04:50 --> Helper loaded: url_helper
INFO - 2023-07-30 17:04:50 --> Helper loaded: file_helper
INFO - 2023-07-30 17:04:50 --> Helper loaded: html_helper
INFO - 2023-07-30 17:04:50 --> Helper loaded: text_helper
INFO - 2023-07-30 17:04:50 --> Helper loaded: form_helper
INFO - 2023-07-30 17:04:50 --> Helper loaded: lang_helper
INFO - 2023-07-30 17:04:50 --> Helper loaded: security_helper
INFO - 2023-07-30 17:04:50 --> Helper loaded: cookie_helper
INFO - 2023-07-30 17:04:50 --> Database Driver Class Initialized
INFO - 2023-07-30 17:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:04:50 --> Parser Class Initialized
INFO - 2023-07-30 17:04:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-30 17:04:50 --> Pagination Class Initialized
INFO - 2023-07-30 17:04:50 --> Form Validation Class Initialized
INFO - 2023-07-30 17:04:50 --> Controller Class Initialized
DEBUG - 2023-07-30 17:04:50 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-07-30 17:04:50 --> Model Class Initialized
INFO - 2023-07-30 17:04:50 --> Model Class Initialized
INFO - 2023-07-30 17:04:50 --> Model Class Initialized
INFO - 2023-07-30 17:04:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-07-30 17:04:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-30 17:04:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-30 17:04:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-30 17:04:50 --> Model Class Initialized
INFO - 2023-07-30 17:04:50 --> Model Class Initialized
INFO - 2023-07-30 17:04:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-07-30 17:04:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-07-30 17:04:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-30 17:04:50 --> Final output sent to browser
DEBUG - 2023-07-30 17:04:50 --> Total execution time: 0.1633
