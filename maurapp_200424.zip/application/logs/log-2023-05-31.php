<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-31 05:18:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:18:53 --> Config Class Initialized
INFO - 2023-05-31 05:18:53 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:18:53 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:18:53 --> Utf8 Class Initialized
INFO - 2023-05-31 05:18:53 --> URI Class Initialized
DEBUG - 2023-05-31 05:18:53 --> No URI present. Default controller set.
INFO - 2023-05-31 05:18:53 --> Router Class Initialized
INFO - 2023-05-31 05:18:53 --> Output Class Initialized
INFO - 2023-05-31 05:18:53 --> Security Class Initialized
DEBUG - 2023-05-31 05:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:18:53 --> Input Class Initialized
INFO - 2023-05-31 05:18:53 --> Language Class Initialized
INFO - 2023-05-31 05:18:53 --> Loader Class Initialized
INFO - 2023-05-31 05:18:53 --> Helper loaded: url_helper
INFO - 2023-05-31 05:18:53 --> Helper loaded: file_helper
INFO - 2023-05-31 05:18:53 --> Helper loaded: html_helper
INFO - 2023-05-31 05:18:53 --> Helper loaded: text_helper
INFO - 2023-05-31 05:18:53 --> Helper loaded: form_helper
INFO - 2023-05-31 05:18:53 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:18:53 --> Helper loaded: security_helper
INFO - 2023-05-31 05:18:53 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:18:53 --> Database Driver Class Initialized
INFO - 2023-05-31 05:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:18:53 --> Parser Class Initialized
INFO - 2023-05-31 05:18:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:18:53 --> Pagination Class Initialized
INFO - 2023-05-31 05:18:53 --> Form Validation Class Initialized
INFO - 2023-05-31 05:18:53 --> Controller Class Initialized
INFO - 2023-05-31 05:18:53 --> Model Class Initialized
DEBUG - 2023-05-31 05:18:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-31 05:18:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:18:53 --> Config Class Initialized
INFO - 2023-05-31 05:18:53 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:18:53 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:18:53 --> Utf8 Class Initialized
INFO - 2023-05-31 05:18:53 --> URI Class Initialized
INFO - 2023-05-31 05:18:53 --> Router Class Initialized
INFO - 2023-05-31 05:18:53 --> Output Class Initialized
INFO - 2023-05-31 05:18:53 --> Security Class Initialized
DEBUG - 2023-05-31 05:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:18:53 --> Input Class Initialized
INFO - 2023-05-31 05:18:53 --> Language Class Initialized
INFO - 2023-05-31 05:18:53 --> Loader Class Initialized
INFO - 2023-05-31 05:18:53 --> Helper loaded: url_helper
INFO - 2023-05-31 05:18:53 --> Helper loaded: file_helper
INFO - 2023-05-31 05:18:53 --> Helper loaded: html_helper
INFO - 2023-05-31 05:18:53 --> Helper loaded: text_helper
INFO - 2023-05-31 05:18:53 --> Helper loaded: form_helper
INFO - 2023-05-31 05:18:53 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:18:53 --> Helper loaded: security_helper
INFO - 2023-05-31 05:18:53 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:18:53 --> Database Driver Class Initialized
INFO - 2023-05-31 05:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:18:53 --> Parser Class Initialized
INFO - 2023-05-31 05:18:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:18:53 --> Pagination Class Initialized
INFO - 2023-05-31 05:18:53 --> Form Validation Class Initialized
INFO - 2023-05-31 05:18:53 --> Controller Class Initialized
INFO - 2023-05-31 05:18:53 --> Model Class Initialized
DEBUG - 2023-05-31 05:18:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:18:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-31 05:18:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:18:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 05:18:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 05:18:53 --> Model Class Initialized
INFO - 2023-05-31 05:18:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 05:18:53 --> Final output sent to browser
DEBUG - 2023-05-31 05:18:53 --> Total execution time: 0.0290
ERROR - 2023-05-31 05:18:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:18:57 --> Config Class Initialized
INFO - 2023-05-31 05:18:57 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:18:57 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:18:57 --> Utf8 Class Initialized
INFO - 2023-05-31 05:18:57 --> URI Class Initialized
INFO - 2023-05-31 05:18:57 --> Router Class Initialized
INFO - 2023-05-31 05:18:57 --> Output Class Initialized
INFO - 2023-05-31 05:18:57 --> Security Class Initialized
DEBUG - 2023-05-31 05:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:18:57 --> Input Class Initialized
INFO - 2023-05-31 05:18:57 --> Language Class Initialized
INFO - 2023-05-31 05:18:57 --> Loader Class Initialized
INFO - 2023-05-31 05:18:57 --> Helper loaded: url_helper
INFO - 2023-05-31 05:18:57 --> Helper loaded: file_helper
INFO - 2023-05-31 05:18:57 --> Helper loaded: html_helper
INFO - 2023-05-31 05:18:57 --> Helper loaded: text_helper
INFO - 2023-05-31 05:18:57 --> Helper loaded: form_helper
INFO - 2023-05-31 05:18:57 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:18:57 --> Helper loaded: security_helper
INFO - 2023-05-31 05:18:57 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:18:57 --> Database Driver Class Initialized
INFO - 2023-05-31 05:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:18:57 --> Parser Class Initialized
INFO - 2023-05-31 05:18:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:18:57 --> Pagination Class Initialized
INFO - 2023-05-31 05:18:57 --> Form Validation Class Initialized
INFO - 2023-05-31 05:18:57 --> Controller Class Initialized
INFO - 2023-05-31 05:18:57 --> Model Class Initialized
DEBUG - 2023-05-31 05:18:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:18:57 --> Model Class Initialized
INFO - 2023-05-31 05:18:57 --> Final output sent to browser
DEBUG - 2023-05-31 05:18:57 --> Total execution time: 0.0178
ERROR - 2023-05-31 05:18:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:18:57 --> Config Class Initialized
INFO - 2023-05-31 05:18:57 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:18:57 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:18:57 --> Utf8 Class Initialized
INFO - 2023-05-31 05:18:57 --> URI Class Initialized
DEBUG - 2023-05-31 05:18:57 --> No URI present. Default controller set.
INFO - 2023-05-31 05:18:57 --> Router Class Initialized
INFO - 2023-05-31 05:18:57 --> Output Class Initialized
INFO - 2023-05-31 05:18:57 --> Security Class Initialized
DEBUG - 2023-05-31 05:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:18:57 --> Input Class Initialized
INFO - 2023-05-31 05:18:57 --> Language Class Initialized
INFO - 2023-05-31 05:18:57 --> Loader Class Initialized
INFO - 2023-05-31 05:18:57 --> Helper loaded: url_helper
INFO - 2023-05-31 05:18:57 --> Helper loaded: file_helper
INFO - 2023-05-31 05:18:57 --> Helper loaded: html_helper
INFO - 2023-05-31 05:18:57 --> Helper loaded: text_helper
INFO - 2023-05-31 05:18:57 --> Helper loaded: form_helper
INFO - 2023-05-31 05:18:57 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:18:57 --> Helper loaded: security_helper
INFO - 2023-05-31 05:18:57 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:18:57 --> Database Driver Class Initialized
INFO - 2023-05-31 05:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:18:57 --> Parser Class Initialized
INFO - 2023-05-31 05:18:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:18:57 --> Pagination Class Initialized
INFO - 2023-05-31 05:18:57 --> Form Validation Class Initialized
INFO - 2023-05-31 05:18:57 --> Controller Class Initialized
INFO - 2023-05-31 05:18:57 --> Model Class Initialized
DEBUG - 2023-05-31 05:18:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:18:57 --> Model Class Initialized
DEBUG - 2023-05-31 05:18:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:18:57 --> Model Class Initialized
INFO - 2023-05-31 05:18:57 --> Model Class Initialized
INFO - 2023-05-31 05:18:57 --> Model Class Initialized
INFO - 2023-05-31 05:18:57 --> Model Class Initialized
DEBUG - 2023-05-31 05:18:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 05:18:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:18:57 --> Model Class Initialized
INFO - 2023-05-31 05:18:57 --> Model Class Initialized
INFO - 2023-05-31 05:18:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-31 05:18:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:18:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 05:18:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 05:18:57 --> Model Class Initialized
INFO - 2023-05-31 05:18:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 05:18:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 05:18:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 05:18:57 --> Final output sent to browser
DEBUG - 2023-05-31 05:18:57 --> Total execution time: 0.1700
ERROR - 2023-05-31 05:18:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:18:58 --> Config Class Initialized
INFO - 2023-05-31 05:18:58 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:18:58 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:18:58 --> Utf8 Class Initialized
INFO - 2023-05-31 05:18:58 --> URI Class Initialized
INFO - 2023-05-31 05:18:58 --> Router Class Initialized
INFO - 2023-05-31 05:18:58 --> Output Class Initialized
INFO - 2023-05-31 05:18:58 --> Security Class Initialized
DEBUG - 2023-05-31 05:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:18:58 --> Input Class Initialized
INFO - 2023-05-31 05:18:58 --> Language Class Initialized
INFO - 2023-05-31 05:18:58 --> Loader Class Initialized
INFO - 2023-05-31 05:18:58 --> Helper loaded: url_helper
INFO - 2023-05-31 05:18:58 --> Helper loaded: file_helper
INFO - 2023-05-31 05:18:58 --> Helper loaded: html_helper
INFO - 2023-05-31 05:18:58 --> Helper loaded: text_helper
INFO - 2023-05-31 05:18:58 --> Helper loaded: form_helper
INFO - 2023-05-31 05:18:58 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:18:58 --> Helper loaded: security_helper
INFO - 2023-05-31 05:18:58 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:18:58 --> Database Driver Class Initialized
INFO - 2023-05-31 05:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:18:58 --> Parser Class Initialized
INFO - 2023-05-31 05:18:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:18:58 --> Pagination Class Initialized
INFO - 2023-05-31 05:18:58 --> Form Validation Class Initialized
INFO - 2023-05-31 05:18:58 --> Controller Class Initialized
DEBUG - 2023-05-31 05:18:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 05:18:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:18:58 --> Model Class Initialized
INFO - 2023-05-31 05:18:58 --> Final output sent to browser
DEBUG - 2023-05-31 05:18:58 --> Total execution time: 0.0132
ERROR - 2023-05-31 05:19:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:19:21 --> Config Class Initialized
INFO - 2023-05-31 05:19:21 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:19:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:19:21 --> Utf8 Class Initialized
INFO - 2023-05-31 05:19:21 --> URI Class Initialized
DEBUG - 2023-05-31 05:19:21 --> No URI present. Default controller set.
INFO - 2023-05-31 05:19:21 --> Router Class Initialized
INFO - 2023-05-31 05:19:21 --> Output Class Initialized
INFO - 2023-05-31 05:19:21 --> Security Class Initialized
DEBUG - 2023-05-31 05:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:19:21 --> Input Class Initialized
INFO - 2023-05-31 05:19:21 --> Language Class Initialized
INFO - 2023-05-31 05:19:21 --> Loader Class Initialized
INFO - 2023-05-31 05:19:21 --> Helper loaded: url_helper
INFO - 2023-05-31 05:19:21 --> Helper loaded: file_helper
INFO - 2023-05-31 05:19:21 --> Helper loaded: html_helper
INFO - 2023-05-31 05:19:21 --> Helper loaded: text_helper
INFO - 2023-05-31 05:19:21 --> Helper loaded: form_helper
INFO - 2023-05-31 05:19:21 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:19:21 --> Helper loaded: security_helper
INFO - 2023-05-31 05:19:21 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:19:21 --> Database Driver Class Initialized
INFO - 2023-05-31 05:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:19:21 --> Parser Class Initialized
INFO - 2023-05-31 05:19:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:19:21 --> Pagination Class Initialized
INFO - 2023-05-31 05:19:21 --> Form Validation Class Initialized
INFO - 2023-05-31 05:19:21 --> Controller Class Initialized
INFO - 2023-05-31 05:19:21 --> Model Class Initialized
DEBUG - 2023-05-31 05:19:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-31 05:19:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:19:21 --> Config Class Initialized
INFO - 2023-05-31 05:19:21 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:19:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:19:21 --> Utf8 Class Initialized
INFO - 2023-05-31 05:19:21 --> URI Class Initialized
INFO - 2023-05-31 05:19:21 --> Router Class Initialized
INFO - 2023-05-31 05:19:21 --> Output Class Initialized
INFO - 2023-05-31 05:19:21 --> Security Class Initialized
DEBUG - 2023-05-31 05:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:19:21 --> Input Class Initialized
INFO - 2023-05-31 05:19:21 --> Language Class Initialized
INFO - 2023-05-31 05:19:21 --> Loader Class Initialized
INFO - 2023-05-31 05:19:21 --> Helper loaded: url_helper
INFO - 2023-05-31 05:19:21 --> Helper loaded: file_helper
INFO - 2023-05-31 05:19:21 --> Helper loaded: html_helper
INFO - 2023-05-31 05:19:21 --> Helper loaded: text_helper
INFO - 2023-05-31 05:19:21 --> Helper loaded: form_helper
INFO - 2023-05-31 05:19:21 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:19:21 --> Helper loaded: security_helper
INFO - 2023-05-31 05:19:21 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:19:21 --> Database Driver Class Initialized
INFO - 2023-05-31 05:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:19:21 --> Parser Class Initialized
INFO - 2023-05-31 05:19:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:19:21 --> Pagination Class Initialized
INFO - 2023-05-31 05:19:21 --> Form Validation Class Initialized
INFO - 2023-05-31 05:19:21 --> Controller Class Initialized
INFO - 2023-05-31 05:19:21 --> Model Class Initialized
DEBUG - 2023-05-31 05:19:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:19:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-31 05:19:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:19:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 05:19:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 05:19:21 --> Model Class Initialized
INFO - 2023-05-31 05:19:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 05:19:21 --> Final output sent to browser
DEBUG - 2023-05-31 05:19:21 --> Total execution time: 0.0282
ERROR - 2023-05-31 05:19:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:19:26 --> Config Class Initialized
INFO - 2023-05-31 05:19:26 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:19:26 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:19:26 --> Utf8 Class Initialized
INFO - 2023-05-31 05:19:26 --> URI Class Initialized
INFO - 2023-05-31 05:19:26 --> Router Class Initialized
INFO - 2023-05-31 05:19:26 --> Output Class Initialized
INFO - 2023-05-31 05:19:26 --> Security Class Initialized
DEBUG - 2023-05-31 05:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:19:26 --> Input Class Initialized
INFO - 2023-05-31 05:19:26 --> Language Class Initialized
INFO - 2023-05-31 05:19:26 --> Loader Class Initialized
INFO - 2023-05-31 05:19:26 --> Helper loaded: url_helper
INFO - 2023-05-31 05:19:26 --> Helper loaded: file_helper
INFO - 2023-05-31 05:19:26 --> Helper loaded: html_helper
INFO - 2023-05-31 05:19:26 --> Helper loaded: text_helper
INFO - 2023-05-31 05:19:26 --> Helper loaded: form_helper
INFO - 2023-05-31 05:19:26 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:19:26 --> Helper loaded: security_helper
INFO - 2023-05-31 05:19:26 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:19:26 --> Database Driver Class Initialized
INFO - 2023-05-31 05:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:19:26 --> Parser Class Initialized
INFO - 2023-05-31 05:19:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:19:26 --> Pagination Class Initialized
INFO - 2023-05-31 05:19:26 --> Form Validation Class Initialized
INFO - 2023-05-31 05:19:26 --> Controller Class Initialized
INFO - 2023-05-31 05:19:26 --> Model Class Initialized
DEBUG - 2023-05-31 05:19:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:19:26 --> Model Class Initialized
INFO - 2023-05-31 05:19:26 --> Final output sent to browser
DEBUG - 2023-05-31 05:19:26 --> Total execution time: 0.0171
ERROR - 2023-05-31 05:19:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:19:26 --> Config Class Initialized
INFO - 2023-05-31 05:19:26 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:19:26 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:19:26 --> Utf8 Class Initialized
INFO - 2023-05-31 05:19:26 --> URI Class Initialized
DEBUG - 2023-05-31 05:19:26 --> No URI present. Default controller set.
INFO - 2023-05-31 05:19:26 --> Router Class Initialized
INFO - 2023-05-31 05:19:26 --> Output Class Initialized
INFO - 2023-05-31 05:19:26 --> Security Class Initialized
DEBUG - 2023-05-31 05:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:19:26 --> Input Class Initialized
INFO - 2023-05-31 05:19:26 --> Language Class Initialized
INFO - 2023-05-31 05:19:26 --> Loader Class Initialized
INFO - 2023-05-31 05:19:26 --> Helper loaded: url_helper
INFO - 2023-05-31 05:19:26 --> Helper loaded: file_helper
INFO - 2023-05-31 05:19:26 --> Helper loaded: html_helper
INFO - 2023-05-31 05:19:26 --> Helper loaded: text_helper
INFO - 2023-05-31 05:19:26 --> Helper loaded: form_helper
INFO - 2023-05-31 05:19:26 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:19:26 --> Helper loaded: security_helper
INFO - 2023-05-31 05:19:26 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:19:26 --> Database Driver Class Initialized
INFO - 2023-05-31 05:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:19:26 --> Parser Class Initialized
INFO - 2023-05-31 05:19:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:19:26 --> Pagination Class Initialized
INFO - 2023-05-31 05:19:26 --> Form Validation Class Initialized
INFO - 2023-05-31 05:19:26 --> Controller Class Initialized
INFO - 2023-05-31 05:19:26 --> Model Class Initialized
DEBUG - 2023-05-31 05:19:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:19:26 --> Model Class Initialized
DEBUG - 2023-05-31 05:19:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:19:26 --> Model Class Initialized
INFO - 2023-05-31 05:19:26 --> Model Class Initialized
INFO - 2023-05-31 05:19:26 --> Model Class Initialized
INFO - 2023-05-31 05:19:26 --> Model Class Initialized
DEBUG - 2023-05-31 05:19:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 05:19:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:19:26 --> Model Class Initialized
INFO - 2023-05-31 05:19:26 --> Model Class Initialized
INFO - 2023-05-31 05:19:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-31 05:19:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:19:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 05:19:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 05:19:26 --> Model Class Initialized
INFO - 2023-05-31 05:19:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 05:19:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 05:19:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 05:19:26 --> Final output sent to browser
DEBUG - 2023-05-31 05:19:26 --> Total execution time: 0.0719
ERROR - 2023-05-31 05:19:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:19:43 --> Config Class Initialized
INFO - 2023-05-31 05:19:43 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:19:43 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:19:43 --> Utf8 Class Initialized
INFO - 2023-05-31 05:19:43 --> URI Class Initialized
INFO - 2023-05-31 05:19:43 --> Router Class Initialized
INFO - 2023-05-31 05:19:43 --> Output Class Initialized
INFO - 2023-05-31 05:19:43 --> Security Class Initialized
DEBUG - 2023-05-31 05:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:19:43 --> Input Class Initialized
INFO - 2023-05-31 05:19:43 --> Language Class Initialized
INFO - 2023-05-31 05:19:43 --> Loader Class Initialized
INFO - 2023-05-31 05:19:43 --> Helper loaded: url_helper
INFO - 2023-05-31 05:19:43 --> Helper loaded: file_helper
INFO - 2023-05-31 05:19:43 --> Helper loaded: html_helper
INFO - 2023-05-31 05:19:43 --> Helper loaded: text_helper
INFO - 2023-05-31 05:19:43 --> Helper loaded: form_helper
INFO - 2023-05-31 05:19:43 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:19:43 --> Helper loaded: security_helper
INFO - 2023-05-31 05:19:43 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:19:43 --> Database Driver Class Initialized
INFO - 2023-05-31 05:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:19:43 --> Parser Class Initialized
INFO - 2023-05-31 05:19:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:19:43 --> Pagination Class Initialized
INFO - 2023-05-31 05:19:43 --> Form Validation Class Initialized
INFO - 2023-05-31 05:19:43 --> Controller Class Initialized
DEBUG - 2023-05-31 05:19:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 05:19:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:19:43 --> Model Class Initialized
DEBUG - 2023-05-31 05:19:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:19:43 --> Model Class Initialized
DEBUG - 2023-05-31 05:19:43 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:19:43 --> Model Class Initialized
INFO - 2023-05-31 05:19:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-05-31 05:19:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:19:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 05:19:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 05:19:43 --> Model Class Initialized
INFO - 2023-05-31 05:19:43 --> Model Class Initialized
INFO - 2023-05-31 05:19:43 --> Model Class Initialized
INFO - 2023-05-31 05:19:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 05:19:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 05:19:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 05:19:43 --> Final output sent to browser
DEBUG - 2023-05-31 05:19:43 --> Total execution time: 0.0694
ERROR - 2023-05-31 05:19:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:19:43 --> Config Class Initialized
INFO - 2023-05-31 05:19:43 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:19:43 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:19:43 --> Utf8 Class Initialized
INFO - 2023-05-31 05:19:43 --> URI Class Initialized
INFO - 2023-05-31 05:19:43 --> Router Class Initialized
INFO - 2023-05-31 05:19:43 --> Output Class Initialized
INFO - 2023-05-31 05:19:43 --> Security Class Initialized
DEBUG - 2023-05-31 05:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:19:43 --> Input Class Initialized
INFO - 2023-05-31 05:19:43 --> Language Class Initialized
INFO - 2023-05-31 05:19:43 --> Loader Class Initialized
INFO - 2023-05-31 05:19:43 --> Helper loaded: url_helper
INFO - 2023-05-31 05:19:43 --> Helper loaded: file_helper
INFO - 2023-05-31 05:19:43 --> Helper loaded: html_helper
INFO - 2023-05-31 05:19:43 --> Helper loaded: text_helper
INFO - 2023-05-31 05:19:43 --> Helper loaded: form_helper
INFO - 2023-05-31 05:19:43 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:19:43 --> Helper loaded: security_helper
INFO - 2023-05-31 05:19:43 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:19:43 --> Database Driver Class Initialized
INFO - 2023-05-31 05:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:19:43 --> Parser Class Initialized
INFO - 2023-05-31 05:19:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:19:43 --> Pagination Class Initialized
INFO - 2023-05-31 05:19:43 --> Form Validation Class Initialized
INFO - 2023-05-31 05:19:43 --> Controller Class Initialized
DEBUG - 2023-05-31 05:19:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 05:19:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:19:43 --> Model Class Initialized
DEBUG - 2023-05-31 05:19:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:19:43 --> Model Class Initialized
INFO - 2023-05-31 05:19:43 --> Final output sent to browser
DEBUG - 2023-05-31 05:19:43 --> Total execution time: 0.0246
ERROR - 2023-05-31 05:19:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:19:55 --> Config Class Initialized
INFO - 2023-05-31 05:19:55 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:19:55 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:19:55 --> Utf8 Class Initialized
INFO - 2023-05-31 05:19:55 --> URI Class Initialized
INFO - 2023-05-31 05:19:55 --> Router Class Initialized
INFO - 2023-05-31 05:19:55 --> Output Class Initialized
INFO - 2023-05-31 05:19:55 --> Security Class Initialized
DEBUG - 2023-05-31 05:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:19:55 --> Input Class Initialized
INFO - 2023-05-31 05:19:55 --> Language Class Initialized
INFO - 2023-05-31 05:19:55 --> Loader Class Initialized
INFO - 2023-05-31 05:19:55 --> Helper loaded: url_helper
INFO - 2023-05-31 05:19:55 --> Helper loaded: file_helper
INFO - 2023-05-31 05:19:55 --> Helper loaded: html_helper
INFO - 2023-05-31 05:19:55 --> Helper loaded: text_helper
INFO - 2023-05-31 05:19:55 --> Helper loaded: form_helper
INFO - 2023-05-31 05:19:55 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:19:55 --> Helper loaded: security_helper
INFO - 2023-05-31 05:19:55 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:19:55 --> Database Driver Class Initialized
INFO - 2023-05-31 05:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:19:55 --> Parser Class Initialized
INFO - 2023-05-31 05:19:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:19:55 --> Pagination Class Initialized
INFO - 2023-05-31 05:19:55 --> Form Validation Class Initialized
INFO - 2023-05-31 05:19:55 --> Controller Class Initialized
DEBUG - 2023-05-31 05:19:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 05:19:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:19:55 --> Model Class Initialized
DEBUG - 2023-05-31 05:19:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:19:55 --> Model Class Initialized
INFO - 2023-05-31 05:19:55 --> Final output sent to browser
DEBUG - 2023-05-31 05:19:55 --> Total execution time: 0.0310
ERROR - 2023-05-31 05:20:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:20:52 --> Config Class Initialized
INFO - 2023-05-31 05:20:52 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:20:52 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:20:52 --> Utf8 Class Initialized
INFO - 2023-05-31 05:20:52 --> URI Class Initialized
DEBUG - 2023-05-31 05:20:52 --> No URI present. Default controller set.
INFO - 2023-05-31 05:20:52 --> Router Class Initialized
INFO - 2023-05-31 05:20:52 --> Output Class Initialized
INFO - 2023-05-31 05:20:52 --> Security Class Initialized
DEBUG - 2023-05-31 05:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:20:52 --> Input Class Initialized
INFO - 2023-05-31 05:20:52 --> Language Class Initialized
INFO - 2023-05-31 05:20:52 --> Loader Class Initialized
INFO - 2023-05-31 05:20:52 --> Helper loaded: url_helper
INFO - 2023-05-31 05:20:52 --> Helper loaded: file_helper
INFO - 2023-05-31 05:20:52 --> Helper loaded: html_helper
INFO - 2023-05-31 05:20:52 --> Helper loaded: text_helper
INFO - 2023-05-31 05:20:52 --> Helper loaded: form_helper
INFO - 2023-05-31 05:20:52 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:20:52 --> Helper loaded: security_helper
INFO - 2023-05-31 05:20:52 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:20:52 --> Database Driver Class Initialized
INFO - 2023-05-31 05:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:20:52 --> Parser Class Initialized
INFO - 2023-05-31 05:20:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:20:52 --> Pagination Class Initialized
INFO - 2023-05-31 05:20:52 --> Form Validation Class Initialized
INFO - 2023-05-31 05:20:52 --> Controller Class Initialized
INFO - 2023-05-31 05:20:52 --> Model Class Initialized
DEBUG - 2023-05-31 05:20:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:20:52 --> Model Class Initialized
DEBUG - 2023-05-31 05:20:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:20:52 --> Model Class Initialized
INFO - 2023-05-31 05:20:52 --> Model Class Initialized
INFO - 2023-05-31 05:20:52 --> Model Class Initialized
INFO - 2023-05-31 05:20:52 --> Model Class Initialized
DEBUG - 2023-05-31 05:20:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 05:20:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:20:52 --> Model Class Initialized
INFO - 2023-05-31 05:20:52 --> Model Class Initialized
INFO - 2023-05-31 05:20:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-31 05:20:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:20:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 05:20:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 05:20:52 --> Model Class Initialized
INFO - 2023-05-31 05:20:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 05:20:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 05:20:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 05:20:52 --> Final output sent to browser
DEBUG - 2023-05-31 05:20:52 --> Total execution time: 0.0777
ERROR - 2023-05-31 05:26:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:26:04 --> Config Class Initialized
INFO - 2023-05-31 05:26:04 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:26:04 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:26:04 --> Utf8 Class Initialized
INFO - 2023-05-31 05:26:04 --> URI Class Initialized
INFO - 2023-05-31 05:26:04 --> Router Class Initialized
INFO - 2023-05-31 05:26:04 --> Output Class Initialized
INFO - 2023-05-31 05:26:04 --> Security Class Initialized
DEBUG - 2023-05-31 05:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:26:04 --> Input Class Initialized
INFO - 2023-05-31 05:26:04 --> Language Class Initialized
INFO - 2023-05-31 05:26:04 --> Loader Class Initialized
INFO - 2023-05-31 05:26:04 --> Helper loaded: url_helper
INFO - 2023-05-31 05:26:04 --> Helper loaded: file_helper
INFO - 2023-05-31 05:26:04 --> Helper loaded: html_helper
INFO - 2023-05-31 05:26:04 --> Helper loaded: text_helper
INFO - 2023-05-31 05:26:04 --> Helper loaded: form_helper
INFO - 2023-05-31 05:26:04 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:26:04 --> Helper loaded: security_helper
INFO - 2023-05-31 05:26:04 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:26:04 --> Database Driver Class Initialized
INFO - 2023-05-31 05:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:26:04 --> Parser Class Initialized
INFO - 2023-05-31 05:26:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:26:04 --> Pagination Class Initialized
INFO - 2023-05-31 05:26:04 --> Form Validation Class Initialized
INFO - 2023-05-31 05:26:04 --> Controller Class Initialized
DEBUG - 2023-05-31 05:26:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 05:26:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:26:04 --> Model Class Initialized
DEBUG - 2023-05-31 05:26:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:26:04 --> Model Class Initialized
DEBUG - 2023-05-31 05:26:04 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:26:04 --> Model Class Initialized
INFO - 2023-05-31 05:26:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-05-31 05:26:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:26:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 05:26:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 05:26:04 --> Model Class Initialized
INFO - 2023-05-31 05:26:04 --> Model Class Initialized
INFO - 2023-05-31 05:26:04 --> Model Class Initialized
INFO - 2023-05-31 05:26:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 05:26:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 05:26:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 05:26:04 --> Final output sent to browser
DEBUG - 2023-05-31 05:26:04 --> Total execution time: 0.0736
ERROR - 2023-05-31 05:26:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:26:04 --> Config Class Initialized
INFO - 2023-05-31 05:26:04 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:26:04 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:26:04 --> Utf8 Class Initialized
INFO - 2023-05-31 05:26:04 --> URI Class Initialized
INFO - 2023-05-31 05:26:04 --> Router Class Initialized
INFO - 2023-05-31 05:26:04 --> Output Class Initialized
INFO - 2023-05-31 05:26:04 --> Security Class Initialized
DEBUG - 2023-05-31 05:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:26:04 --> Input Class Initialized
INFO - 2023-05-31 05:26:04 --> Language Class Initialized
INFO - 2023-05-31 05:26:04 --> Loader Class Initialized
INFO - 2023-05-31 05:26:04 --> Helper loaded: url_helper
INFO - 2023-05-31 05:26:04 --> Helper loaded: file_helper
INFO - 2023-05-31 05:26:04 --> Helper loaded: html_helper
INFO - 2023-05-31 05:26:04 --> Helper loaded: text_helper
INFO - 2023-05-31 05:26:04 --> Helper loaded: form_helper
INFO - 2023-05-31 05:26:04 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:26:04 --> Helper loaded: security_helper
INFO - 2023-05-31 05:26:04 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:26:04 --> Database Driver Class Initialized
INFO - 2023-05-31 05:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:26:04 --> Parser Class Initialized
INFO - 2023-05-31 05:26:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:26:04 --> Pagination Class Initialized
INFO - 2023-05-31 05:26:04 --> Form Validation Class Initialized
INFO - 2023-05-31 05:26:04 --> Controller Class Initialized
DEBUG - 2023-05-31 05:26:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 05:26:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:26:04 --> Model Class Initialized
DEBUG - 2023-05-31 05:26:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:26:04 --> Model Class Initialized
INFO - 2023-05-31 05:26:04 --> Final output sent to browser
DEBUG - 2023-05-31 05:26:04 --> Total execution time: 0.0218
ERROR - 2023-05-31 05:26:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:26:14 --> Config Class Initialized
INFO - 2023-05-31 05:26:14 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:26:14 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:26:14 --> Utf8 Class Initialized
INFO - 2023-05-31 05:26:14 --> URI Class Initialized
INFO - 2023-05-31 05:26:14 --> Router Class Initialized
INFO - 2023-05-31 05:26:14 --> Output Class Initialized
INFO - 2023-05-31 05:26:14 --> Security Class Initialized
DEBUG - 2023-05-31 05:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:26:14 --> Input Class Initialized
INFO - 2023-05-31 05:26:14 --> Language Class Initialized
INFO - 2023-05-31 05:26:14 --> Loader Class Initialized
INFO - 2023-05-31 05:26:14 --> Helper loaded: url_helper
INFO - 2023-05-31 05:26:14 --> Helper loaded: file_helper
INFO - 2023-05-31 05:26:14 --> Helper loaded: html_helper
INFO - 2023-05-31 05:26:14 --> Helper loaded: text_helper
INFO - 2023-05-31 05:26:14 --> Helper loaded: form_helper
INFO - 2023-05-31 05:26:14 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:26:14 --> Helper loaded: security_helper
INFO - 2023-05-31 05:26:14 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:26:14 --> Database Driver Class Initialized
INFO - 2023-05-31 05:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:26:14 --> Parser Class Initialized
INFO - 2023-05-31 05:26:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:26:14 --> Pagination Class Initialized
INFO - 2023-05-31 05:26:14 --> Form Validation Class Initialized
INFO - 2023-05-31 05:26:14 --> Controller Class Initialized
DEBUG - 2023-05-31 05:26:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 05:26:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:26:14 --> Model Class Initialized
DEBUG - 2023-05-31 05:26:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:26:14 --> Model Class Initialized
INFO - 2023-05-31 05:26:14 --> Final output sent to browser
DEBUG - 2023-05-31 05:26:14 --> Total execution time: 0.0191
ERROR - 2023-05-31 05:26:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:26:17 --> Config Class Initialized
INFO - 2023-05-31 05:26:17 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:26:17 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:26:17 --> Utf8 Class Initialized
INFO - 2023-05-31 05:26:17 --> URI Class Initialized
INFO - 2023-05-31 05:26:17 --> Router Class Initialized
INFO - 2023-05-31 05:26:17 --> Output Class Initialized
INFO - 2023-05-31 05:26:17 --> Security Class Initialized
DEBUG - 2023-05-31 05:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:26:17 --> Input Class Initialized
INFO - 2023-05-31 05:26:17 --> Language Class Initialized
INFO - 2023-05-31 05:26:17 --> Loader Class Initialized
INFO - 2023-05-31 05:26:17 --> Helper loaded: url_helper
INFO - 2023-05-31 05:26:17 --> Helper loaded: file_helper
INFO - 2023-05-31 05:26:17 --> Helper loaded: html_helper
INFO - 2023-05-31 05:26:17 --> Helper loaded: text_helper
INFO - 2023-05-31 05:26:17 --> Helper loaded: form_helper
INFO - 2023-05-31 05:26:17 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:26:17 --> Helper loaded: security_helper
INFO - 2023-05-31 05:26:17 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:26:17 --> Database Driver Class Initialized
INFO - 2023-05-31 05:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:26:17 --> Parser Class Initialized
INFO - 2023-05-31 05:26:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:26:17 --> Pagination Class Initialized
INFO - 2023-05-31 05:26:17 --> Form Validation Class Initialized
INFO - 2023-05-31 05:26:17 --> Controller Class Initialized
DEBUG - 2023-05-31 05:26:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 05:26:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:26:17 --> Model Class Initialized
DEBUG - 2023-05-31 05:26:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:26:17 --> Model Class Initialized
INFO - 2023-05-31 05:26:17 --> Final output sent to browser
DEBUG - 2023-05-31 05:26:17 --> Total execution time: 0.0253
ERROR - 2023-05-31 05:26:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:26:26 --> Config Class Initialized
INFO - 2023-05-31 05:26:26 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:26:26 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:26:26 --> Utf8 Class Initialized
INFO - 2023-05-31 05:26:26 --> URI Class Initialized
INFO - 2023-05-31 05:26:26 --> Router Class Initialized
INFO - 2023-05-31 05:26:26 --> Output Class Initialized
INFO - 2023-05-31 05:26:26 --> Security Class Initialized
DEBUG - 2023-05-31 05:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:26:26 --> Input Class Initialized
INFO - 2023-05-31 05:26:26 --> Language Class Initialized
INFO - 2023-05-31 05:26:26 --> Loader Class Initialized
INFO - 2023-05-31 05:26:26 --> Helper loaded: url_helper
INFO - 2023-05-31 05:26:26 --> Helper loaded: file_helper
INFO - 2023-05-31 05:26:26 --> Helper loaded: html_helper
INFO - 2023-05-31 05:26:26 --> Helper loaded: text_helper
INFO - 2023-05-31 05:26:26 --> Helper loaded: form_helper
INFO - 2023-05-31 05:26:26 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:26:26 --> Helper loaded: security_helper
INFO - 2023-05-31 05:26:26 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:26:26 --> Database Driver Class Initialized
INFO - 2023-05-31 05:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:26:26 --> Parser Class Initialized
INFO - 2023-05-31 05:26:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:26:26 --> Pagination Class Initialized
INFO - 2023-05-31 05:26:26 --> Form Validation Class Initialized
INFO - 2023-05-31 05:26:26 --> Controller Class Initialized
DEBUG - 2023-05-31 05:26:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 05:26:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:26:26 --> Model Class Initialized
DEBUG - 2023-05-31 05:26:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:26:26 --> Model Class Initialized
INFO - 2023-05-31 05:26:26 --> Final output sent to browser
DEBUG - 2023-05-31 05:26:26 --> Total execution time: 0.0245
ERROR - 2023-05-31 05:26:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:26:30 --> Config Class Initialized
INFO - 2023-05-31 05:26:30 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:26:30 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:26:30 --> Utf8 Class Initialized
INFO - 2023-05-31 05:26:30 --> URI Class Initialized
INFO - 2023-05-31 05:26:30 --> Router Class Initialized
INFO - 2023-05-31 05:26:30 --> Output Class Initialized
INFO - 2023-05-31 05:26:30 --> Security Class Initialized
DEBUG - 2023-05-31 05:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:26:30 --> Input Class Initialized
INFO - 2023-05-31 05:26:30 --> Language Class Initialized
INFO - 2023-05-31 05:26:30 --> Loader Class Initialized
INFO - 2023-05-31 05:26:30 --> Helper loaded: url_helper
INFO - 2023-05-31 05:26:30 --> Helper loaded: file_helper
INFO - 2023-05-31 05:26:30 --> Helper loaded: html_helper
INFO - 2023-05-31 05:26:30 --> Helper loaded: text_helper
INFO - 2023-05-31 05:26:30 --> Helper loaded: form_helper
INFO - 2023-05-31 05:26:30 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:26:30 --> Helper loaded: security_helper
INFO - 2023-05-31 05:26:30 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:26:30 --> Database Driver Class Initialized
INFO - 2023-05-31 05:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:26:30 --> Parser Class Initialized
INFO - 2023-05-31 05:26:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:26:30 --> Pagination Class Initialized
INFO - 2023-05-31 05:26:30 --> Form Validation Class Initialized
INFO - 2023-05-31 05:26:30 --> Controller Class Initialized
DEBUG - 2023-05-31 05:26:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 05:26:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:26:30 --> Model Class Initialized
DEBUG - 2023-05-31 05:26:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:26:30 --> Model Class Initialized
INFO - 2023-05-31 05:26:30 --> Final output sent to browser
DEBUG - 2023-05-31 05:26:30 --> Total execution time: 0.0248
ERROR - 2023-05-31 05:27:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:27:32 --> Config Class Initialized
INFO - 2023-05-31 05:27:32 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:27:32 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:27:32 --> Utf8 Class Initialized
INFO - 2023-05-31 05:27:32 --> URI Class Initialized
DEBUG - 2023-05-31 05:27:32 --> No URI present. Default controller set.
INFO - 2023-05-31 05:27:32 --> Router Class Initialized
INFO - 2023-05-31 05:27:32 --> Output Class Initialized
INFO - 2023-05-31 05:27:32 --> Security Class Initialized
DEBUG - 2023-05-31 05:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:27:32 --> Input Class Initialized
INFO - 2023-05-31 05:27:32 --> Language Class Initialized
INFO - 2023-05-31 05:27:32 --> Loader Class Initialized
INFO - 2023-05-31 05:27:32 --> Helper loaded: url_helper
INFO - 2023-05-31 05:27:32 --> Helper loaded: file_helper
INFO - 2023-05-31 05:27:32 --> Helper loaded: html_helper
INFO - 2023-05-31 05:27:32 --> Helper loaded: text_helper
INFO - 2023-05-31 05:27:32 --> Helper loaded: form_helper
INFO - 2023-05-31 05:27:32 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:27:32 --> Helper loaded: security_helper
INFO - 2023-05-31 05:27:32 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:27:32 --> Database Driver Class Initialized
INFO - 2023-05-31 05:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:27:32 --> Parser Class Initialized
INFO - 2023-05-31 05:27:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:27:32 --> Pagination Class Initialized
INFO - 2023-05-31 05:27:32 --> Form Validation Class Initialized
INFO - 2023-05-31 05:27:32 --> Controller Class Initialized
INFO - 2023-05-31 05:27:32 --> Model Class Initialized
DEBUG - 2023-05-31 05:27:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:27:32 --> Model Class Initialized
DEBUG - 2023-05-31 05:27:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:27:32 --> Model Class Initialized
INFO - 2023-05-31 05:27:32 --> Model Class Initialized
INFO - 2023-05-31 05:27:32 --> Model Class Initialized
INFO - 2023-05-31 05:27:32 --> Model Class Initialized
DEBUG - 2023-05-31 05:27:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 05:27:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:27:32 --> Model Class Initialized
INFO - 2023-05-31 05:27:32 --> Model Class Initialized
INFO - 2023-05-31 05:27:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-31 05:27:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:27:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 05:27:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 05:27:32 --> Model Class Initialized
INFO - 2023-05-31 05:27:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 05:27:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 05:27:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 05:27:32 --> Final output sent to browser
DEBUG - 2023-05-31 05:27:32 --> Total execution time: 0.1732
ERROR - 2023-05-31 05:27:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:27:47 --> Config Class Initialized
INFO - 2023-05-31 05:27:47 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:27:47 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:27:47 --> Utf8 Class Initialized
INFO - 2023-05-31 05:27:47 --> URI Class Initialized
INFO - 2023-05-31 05:27:47 --> Router Class Initialized
INFO - 2023-05-31 05:27:47 --> Output Class Initialized
INFO - 2023-05-31 05:27:47 --> Security Class Initialized
DEBUG - 2023-05-31 05:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:27:47 --> Input Class Initialized
INFO - 2023-05-31 05:27:47 --> Language Class Initialized
INFO - 2023-05-31 05:27:47 --> Loader Class Initialized
INFO - 2023-05-31 05:27:47 --> Helper loaded: url_helper
INFO - 2023-05-31 05:27:47 --> Helper loaded: file_helper
INFO - 2023-05-31 05:27:47 --> Helper loaded: html_helper
INFO - 2023-05-31 05:27:47 --> Helper loaded: text_helper
INFO - 2023-05-31 05:27:47 --> Helper loaded: form_helper
INFO - 2023-05-31 05:27:47 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:27:47 --> Helper loaded: security_helper
INFO - 2023-05-31 05:27:47 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:27:47 --> Database Driver Class Initialized
INFO - 2023-05-31 05:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:27:47 --> Parser Class Initialized
INFO - 2023-05-31 05:27:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:27:47 --> Pagination Class Initialized
INFO - 2023-05-31 05:27:47 --> Form Validation Class Initialized
INFO - 2023-05-31 05:27:47 --> Controller Class Initialized
INFO - 2023-05-31 05:27:47 --> Model Class Initialized
DEBUG - 2023-05-31 05:27:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 05:27:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:27:47 --> Model Class Initialized
INFO - 2023-05-31 05:27:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-05-31 05:27:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:27:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 05:27:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 05:27:47 --> Model Class Initialized
INFO - 2023-05-31 05:27:47 --> Model Class Initialized
INFO - 2023-05-31 05:27:47 --> Model Class Initialized
INFO - 2023-05-31 05:27:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 05:27:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 05:27:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 05:27:47 --> Final output sent to browser
DEBUG - 2023-05-31 05:27:47 --> Total execution time: 0.1339
ERROR - 2023-05-31 05:27:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:27:48 --> Config Class Initialized
INFO - 2023-05-31 05:27:48 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:27:48 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:27:48 --> Utf8 Class Initialized
INFO - 2023-05-31 05:27:48 --> URI Class Initialized
INFO - 2023-05-31 05:27:48 --> Router Class Initialized
INFO - 2023-05-31 05:27:48 --> Output Class Initialized
INFO - 2023-05-31 05:27:48 --> Security Class Initialized
DEBUG - 2023-05-31 05:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:27:48 --> Input Class Initialized
INFO - 2023-05-31 05:27:48 --> Language Class Initialized
INFO - 2023-05-31 05:27:48 --> Loader Class Initialized
INFO - 2023-05-31 05:27:48 --> Helper loaded: url_helper
INFO - 2023-05-31 05:27:48 --> Helper loaded: file_helper
INFO - 2023-05-31 05:27:48 --> Helper loaded: html_helper
INFO - 2023-05-31 05:27:48 --> Helper loaded: text_helper
INFO - 2023-05-31 05:27:48 --> Helper loaded: form_helper
INFO - 2023-05-31 05:27:48 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:27:48 --> Helper loaded: security_helper
INFO - 2023-05-31 05:27:48 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:27:48 --> Database Driver Class Initialized
INFO - 2023-05-31 05:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:27:48 --> Parser Class Initialized
INFO - 2023-05-31 05:27:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:27:48 --> Pagination Class Initialized
INFO - 2023-05-31 05:27:48 --> Form Validation Class Initialized
INFO - 2023-05-31 05:27:48 --> Controller Class Initialized
INFO - 2023-05-31 05:27:48 --> Model Class Initialized
DEBUG - 2023-05-31 05:27:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 05:27:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:27:48 --> Model Class Initialized
INFO - 2023-05-31 05:27:48 --> Final output sent to browser
DEBUG - 2023-05-31 05:27:48 --> Total execution time: 0.0292
ERROR - 2023-05-31 05:28:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:28:00 --> Config Class Initialized
INFO - 2023-05-31 05:28:00 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:28:00 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:28:00 --> Utf8 Class Initialized
INFO - 2023-05-31 05:28:00 --> URI Class Initialized
INFO - 2023-05-31 05:28:00 --> Router Class Initialized
INFO - 2023-05-31 05:28:00 --> Output Class Initialized
INFO - 2023-05-31 05:28:00 --> Security Class Initialized
DEBUG - 2023-05-31 05:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:28:00 --> Input Class Initialized
INFO - 2023-05-31 05:28:00 --> Language Class Initialized
INFO - 2023-05-31 05:28:00 --> Loader Class Initialized
INFO - 2023-05-31 05:28:00 --> Helper loaded: url_helper
INFO - 2023-05-31 05:28:00 --> Helper loaded: file_helper
INFO - 2023-05-31 05:28:00 --> Helper loaded: html_helper
INFO - 2023-05-31 05:28:00 --> Helper loaded: text_helper
INFO - 2023-05-31 05:28:00 --> Helper loaded: form_helper
INFO - 2023-05-31 05:28:00 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:28:00 --> Helper loaded: security_helper
INFO - 2023-05-31 05:28:00 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:28:00 --> Database Driver Class Initialized
INFO - 2023-05-31 05:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:28:00 --> Parser Class Initialized
INFO - 2023-05-31 05:28:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:28:00 --> Pagination Class Initialized
INFO - 2023-05-31 05:28:00 --> Form Validation Class Initialized
INFO - 2023-05-31 05:28:00 --> Controller Class Initialized
INFO - 2023-05-31 05:28:00 --> Model Class Initialized
DEBUG - 2023-05-31 05:28:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 05:28:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:28:00 --> Model Class Initialized
INFO - 2023-05-31 05:28:00 --> Final output sent to browser
DEBUG - 2023-05-31 05:28:00 --> Total execution time: 0.0507
ERROR - 2023-05-31 05:28:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:28:38 --> Config Class Initialized
INFO - 2023-05-31 05:28:38 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:28:38 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:28:38 --> Utf8 Class Initialized
INFO - 2023-05-31 05:28:38 --> URI Class Initialized
INFO - 2023-05-31 05:28:38 --> Router Class Initialized
INFO - 2023-05-31 05:28:38 --> Output Class Initialized
INFO - 2023-05-31 05:28:38 --> Security Class Initialized
DEBUG - 2023-05-31 05:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:28:38 --> Input Class Initialized
INFO - 2023-05-31 05:28:38 --> Language Class Initialized
INFO - 2023-05-31 05:28:38 --> Loader Class Initialized
INFO - 2023-05-31 05:28:38 --> Helper loaded: url_helper
INFO - 2023-05-31 05:28:38 --> Helper loaded: file_helper
INFO - 2023-05-31 05:28:38 --> Helper loaded: html_helper
INFO - 2023-05-31 05:28:38 --> Helper loaded: text_helper
INFO - 2023-05-31 05:28:38 --> Helper loaded: form_helper
INFO - 2023-05-31 05:28:38 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:28:38 --> Helper loaded: security_helper
INFO - 2023-05-31 05:28:38 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:28:38 --> Database Driver Class Initialized
INFO - 2023-05-31 05:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:28:38 --> Parser Class Initialized
INFO - 2023-05-31 05:28:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:28:38 --> Pagination Class Initialized
INFO - 2023-05-31 05:28:38 --> Form Validation Class Initialized
INFO - 2023-05-31 05:28:38 --> Controller Class Initialized
INFO - 2023-05-31 05:28:38 --> Model Class Initialized
INFO - 2023-05-31 05:28:38 --> Model Class Initialized
INFO - 2023-05-31 05:28:38 --> Model Class Initialized
INFO - 2023-05-31 05:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-05-31 05:28:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 05:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 05:28:38 --> Model Class Initialized
INFO - 2023-05-31 05:28:38 --> Model Class Initialized
INFO - 2023-05-31 05:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 05:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 05:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 05:28:38 --> Final output sent to browser
DEBUG - 2023-05-31 05:28:38 --> Total execution time: 0.1459
ERROR - 2023-05-31 05:28:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:28:38 --> Config Class Initialized
INFO - 2023-05-31 05:28:38 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:28:38 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:28:38 --> Utf8 Class Initialized
INFO - 2023-05-31 05:28:38 --> URI Class Initialized
INFO - 2023-05-31 05:28:38 --> Router Class Initialized
INFO - 2023-05-31 05:28:38 --> Output Class Initialized
INFO - 2023-05-31 05:28:38 --> Security Class Initialized
DEBUG - 2023-05-31 05:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:28:38 --> Input Class Initialized
INFO - 2023-05-31 05:28:38 --> Language Class Initialized
INFO - 2023-05-31 05:28:38 --> Loader Class Initialized
INFO - 2023-05-31 05:28:38 --> Helper loaded: url_helper
INFO - 2023-05-31 05:28:38 --> Helper loaded: file_helper
INFO - 2023-05-31 05:28:38 --> Helper loaded: html_helper
INFO - 2023-05-31 05:28:38 --> Helper loaded: text_helper
INFO - 2023-05-31 05:28:38 --> Helper loaded: form_helper
INFO - 2023-05-31 05:28:38 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:28:38 --> Helper loaded: security_helper
INFO - 2023-05-31 05:28:38 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:28:38 --> Database Driver Class Initialized
INFO - 2023-05-31 05:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:28:38 --> Parser Class Initialized
INFO - 2023-05-31 05:28:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:28:38 --> Pagination Class Initialized
INFO - 2023-05-31 05:28:38 --> Form Validation Class Initialized
INFO - 2023-05-31 05:28:38 --> Controller Class Initialized
INFO - 2023-05-31 05:28:38 --> Model Class Initialized
INFO - 2023-05-31 05:28:38 --> Model Class Initialized
INFO - 2023-05-31 05:28:38 --> Final output sent to browser
DEBUG - 2023-05-31 05:28:38 --> Total execution time: 0.0227
ERROR - 2023-05-31 05:28:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:28:41 --> Config Class Initialized
INFO - 2023-05-31 05:28:41 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:28:41 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:28:41 --> Utf8 Class Initialized
INFO - 2023-05-31 05:28:41 --> URI Class Initialized
INFO - 2023-05-31 05:28:41 --> Router Class Initialized
INFO - 2023-05-31 05:28:41 --> Output Class Initialized
INFO - 2023-05-31 05:28:41 --> Security Class Initialized
DEBUG - 2023-05-31 05:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:28:41 --> Input Class Initialized
INFO - 2023-05-31 05:28:41 --> Language Class Initialized
INFO - 2023-05-31 05:28:41 --> Loader Class Initialized
INFO - 2023-05-31 05:28:41 --> Helper loaded: url_helper
INFO - 2023-05-31 05:28:41 --> Helper loaded: file_helper
INFO - 2023-05-31 05:28:41 --> Helper loaded: html_helper
INFO - 2023-05-31 05:28:41 --> Helper loaded: text_helper
INFO - 2023-05-31 05:28:41 --> Helper loaded: form_helper
INFO - 2023-05-31 05:28:41 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:28:41 --> Helper loaded: security_helper
INFO - 2023-05-31 05:28:41 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:28:41 --> Database Driver Class Initialized
INFO - 2023-05-31 05:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:28:41 --> Parser Class Initialized
INFO - 2023-05-31 05:28:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:28:41 --> Pagination Class Initialized
INFO - 2023-05-31 05:28:41 --> Form Validation Class Initialized
INFO - 2023-05-31 05:28:41 --> Controller Class Initialized
INFO - 2023-05-31 05:28:41 --> Model Class Initialized
INFO - 2023-05-31 05:28:41 --> Model Class Initialized
INFO - 2023-05-31 05:28:41 --> Final output sent to browser
DEBUG - 2023-05-31 05:28:41 --> Total execution time: 0.0320
ERROR - 2023-05-31 05:30:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:30:59 --> Config Class Initialized
INFO - 2023-05-31 05:30:59 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:30:59 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:30:59 --> Utf8 Class Initialized
INFO - 2023-05-31 05:30:59 --> URI Class Initialized
INFO - 2023-05-31 05:30:59 --> Router Class Initialized
INFO - 2023-05-31 05:30:59 --> Output Class Initialized
INFO - 2023-05-31 05:30:59 --> Security Class Initialized
DEBUG - 2023-05-31 05:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:30:59 --> Input Class Initialized
INFO - 2023-05-31 05:30:59 --> Language Class Initialized
INFO - 2023-05-31 05:30:59 --> Loader Class Initialized
INFO - 2023-05-31 05:30:59 --> Helper loaded: url_helper
INFO - 2023-05-31 05:30:59 --> Helper loaded: file_helper
INFO - 2023-05-31 05:30:59 --> Helper loaded: html_helper
INFO - 2023-05-31 05:30:59 --> Helper loaded: text_helper
INFO - 2023-05-31 05:30:59 --> Helper loaded: form_helper
INFO - 2023-05-31 05:30:59 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:30:59 --> Helper loaded: security_helper
INFO - 2023-05-31 05:30:59 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:30:59 --> Database Driver Class Initialized
INFO - 2023-05-31 05:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:30:59 --> Parser Class Initialized
INFO - 2023-05-31 05:30:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:30:59 --> Pagination Class Initialized
INFO - 2023-05-31 05:30:59 --> Form Validation Class Initialized
INFO - 2023-05-31 05:30:59 --> Controller Class Initialized
INFO - 2023-05-31 05:30:59 --> Model Class Initialized
DEBUG - 2023-05-31 05:30:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 05:30:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:30:59 --> Model Class Initialized
INFO - 2023-05-31 05:30:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-05-31 05:30:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:30:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 05:30:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 05:30:59 --> Model Class Initialized
INFO - 2023-05-31 05:30:59 --> Model Class Initialized
INFO - 2023-05-31 05:30:59 --> Model Class Initialized
INFO - 2023-05-31 05:30:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 05:30:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 05:30:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 05:30:59 --> Final output sent to browser
DEBUG - 2023-05-31 05:30:59 --> Total execution time: 0.1231
ERROR - 2023-05-31 05:31:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:31:00 --> Config Class Initialized
INFO - 2023-05-31 05:31:00 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:31:00 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:31:00 --> Utf8 Class Initialized
INFO - 2023-05-31 05:31:00 --> URI Class Initialized
INFO - 2023-05-31 05:31:00 --> Router Class Initialized
INFO - 2023-05-31 05:31:00 --> Output Class Initialized
INFO - 2023-05-31 05:31:00 --> Security Class Initialized
DEBUG - 2023-05-31 05:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:31:00 --> Input Class Initialized
INFO - 2023-05-31 05:31:00 --> Language Class Initialized
INFO - 2023-05-31 05:31:00 --> Loader Class Initialized
INFO - 2023-05-31 05:31:00 --> Helper loaded: url_helper
INFO - 2023-05-31 05:31:00 --> Helper loaded: file_helper
INFO - 2023-05-31 05:31:00 --> Helper loaded: html_helper
INFO - 2023-05-31 05:31:00 --> Helper loaded: text_helper
INFO - 2023-05-31 05:31:00 --> Helper loaded: form_helper
INFO - 2023-05-31 05:31:00 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:31:00 --> Helper loaded: security_helper
INFO - 2023-05-31 05:31:00 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:31:00 --> Database Driver Class Initialized
INFO - 2023-05-31 05:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:31:00 --> Parser Class Initialized
INFO - 2023-05-31 05:31:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:31:00 --> Pagination Class Initialized
INFO - 2023-05-31 05:31:00 --> Form Validation Class Initialized
INFO - 2023-05-31 05:31:00 --> Controller Class Initialized
INFO - 2023-05-31 05:31:00 --> Model Class Initialized
DEBUG - 2023-05-31 05:31:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 05:31:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:31:00 --> Model Class Initialized
INFO - 2023-05-31 05:31:00 --> Final output sent to browser
DEBUG - 2023-05-31 05:31:00 --> Total execution time: 0.0259
ERROR - 2023-05-31 05:31:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:31:05 --> Config Class Initialized
INFO - 2023-05-31 05:31:05 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:31:05 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:31:05 --> Utf8 Class Initialized
INFO - 2023-05-31 05:31:05 --> URI Class Initialized
INFO - 2023-05-31 05:31:05 --> Router Class Initialized
INFO - 2023-05-31 05:31:05 --> Output Class Initialized
INFO - 2023-05-31 05:31:05 --> Security Class Initialized
DEBUG - 2023-05-31 05:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:31:05 --> Input Class Initialized
INFO - 2023-05-31 05:31:05 --> Language Class Initialized
INFO - 2023-05-31 05:31:05 --> Loader Class Initialized
INFO - 2023-05-31 05:31:05 --> Helper loaded: url_helper
INFO - 2023-05-31 05:31:05 --> Helper loaded: file_helper
INFO - 2023-05-31 05:31:05 --> Helper loaded: html_helper
INFO - 2023-05-31 05:31:05 --> Helper loaded: text_helper
INFO - 2023-05-31 05:31:05 --> Helper loaded: form_helper
INFO - 2023-05-31 05:31:05 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:31:05 --> Helper loaded: security_helper
INFO - 2023-05-31 05:31:05 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:31:05 --> Database Driver Class Initialized
INFO - 2023-05-31 05:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:31:05 --> Parser Class Initialized
INFO - 2023-05-31 05:31:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:31:05 --> Pagination Class Initialized
INFO - 2023-05-31 05:31:05 --> Form Validation Class Initialized
INFO - 2023-05-31 05:31:05 --> Controller Class Initialized
INFO - 2023-05-31 05:31:05 --> Model Class Initialized
INFO - 2023-05-31 05:31:05 --> Model Class Initialized
INFO - 2023-05-31 05:31:05 --> Model Class Initialized
INFO - 2023-05-31 05:31:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-05-31 05:31:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:31:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 05:31:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 05:31:05 --> Model Class Initialized
INFO - 2023-05-31 05:31:05 --> Model Class Initialized
INFO - 2023-05-31 05:31:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 05:31:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 05:31:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 05:31:05 --> Final output sent to browser
DEBUG - 2023-05-31 05:31:05 --> Total execution time: 0.1137
ERROR - 2023-05-31 05:31:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:31:06 --> Config Class Initialized
INFO - 2023-05-31 05:31:06 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:31:06 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:31:06 --> Utf8 Class Initialized
INFO - 2023-05-31 05:31:06 --> URI Class Initialized
INFO - 2023-05-31 05:31:06 --> Router Class Initialized
INFO - 2023-05-31 05:31:06 --> Output Class Initialized
INFO - 2023-05-31 05:31:06 --> Security Class Initialized
DEBUG - 2023-05-31 05:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:31:06 --> Input Class Initialized
INFO - 2023-05-31 05:31:06 --> Language Class Initialized
INFO - 2023-05-31 05:31:06 --> Loader Class Initialized
INFO - 2023-05-31 05:31:06 --> Helper loaded: url_helper
INFO - 2023-05-31 05:31:06 --> Helper loaded: file_helper
INFO - 2023-05-31 05:31:06 --> Helper loaded: html_helper
INFO - 2023-05-31 05:31:06 --> Helper loaded: text_helper
INFO - 2023-05-31 05:31:06 --> Helper loaded: form_helper
INFO - 2023-05-31 05:31:06 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:31:06 --> Helper loaded: security_helper
INFO - 2023-05-31 05:31:06 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:31:06 --> Database Driver Class Initialized
INFO - 2023-05-31 05:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:31:06 --> Parser Class Initialized
INFO - 2023-05-31 05:31:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:31:06 --> Pagination Class Initialized
INFO - 2023-05-31 05:31:06 --> Form Validation Class Initialized
INFO - 2023-05-31 05:31:06 --> Controller Class Initialized
INFO - 2023-05-31 05:31:06 --> Model Class Initialized
INFO - 2023-05-31 05:31:06 --> Model Class Initialized
INFO - 2023-05-31 05:31:06 --> Final output sent to browser
DEBUG - 2023-05-31 05:31:06 --> Total execution time: 0.0219
ERROR - 2023-05-31 05:31:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:31:13 --> Config Class Initialized
INFO - 2023-05-31 05:31:13 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:31:13 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:31:13 --> Utf8 Class Initialized
INFO - 2023-05-31 05:31:13 --> URI Class Initialized
INFO - 2023-05-31 05:31:13 --> Router Class Initialized
INFO - 2023-05-31 05:31:13 --> Output Class Initialized
INFO - 2023-05-31 05:31:13 --> Security Class Initialized
DEBUG - 2023-05-31 05:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:31:13 --> Input Class Initialized
INFO - 2023-05-31 05:31:13 --> Language Class Initialized
INFO - 2023-05-31 05:31:13 --> Loader Class Initialized
INFO - 2023-05-31 05:31:13 --> Helper loaded: url_helper
INFO - 2023-05-31 05:31:13 --> Helper loaded: file_helper
INFO - 2023-05-31 05:31:13 --> Helper loaded: html_helper
INFO - 2023-05-31 05:31:13 --> Helper loaded: text_helper
INFO - 2023-05-31 05:31:13 --> Helper loaded: form_helper
INFO - 2023-05-31 05:31:13 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:31:13 --> Helper loaded: security_helper
INFO - 2023-05-31 05:31:13 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:31:13 --> Database Driver Class Initialized
INFO - 2023-05-31 05:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:31:13 --> Parser Class Initialized
INFO - 2023-05-31 05:31:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:31:13 --> Pagination Class Initialized
INFO - 2023-05-31 05:31:13 --> Form Validation Class Initialized
INFO - 2023-05-31 05:31:13 --> Controller Class Initialized
INFO - 2023-05-31 05:31:13 --> Model Class Initialized
INFO - 2023-05-31 05:31:13 --> Model Class Initialized
INFO - 2023-05-31 05:31:13 --> Final output sent to browser
DEBUG - 2023-05-31 05:31:13 --> Total execution time: 0.0309
ERROR - 2023-05-31 05:56:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:56:21 --> Config Class Initialized
INFO - 2023-05-31 05:56:21 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:56:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:56:21 --> Utf8 Class Initialized
INFO - 2023-05-31 05:56:21 --> URI Class Initialized
INFO - 2023-05-31 05:56:21 --> Router Class Initialized
INFO - 2023-05-31 05:56:21 --> Output Class Initialized
INFO - 2023-05-31 05:56:21 --> Security Class Initialized
DEBUG - 2023-05-31 05:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:56:21 --> Input Class Initialized
INFO - 2023-05-31 05:56:21 --> Language Class Initialized
INFO - 2023-05-31 05:56:21 --> Loader Class Initialized
INFO - 2023-05-31 05:56:21 --> Helper loaded: url_helper
INFO - 2023-05-31 05:56:21 --> Helper loaded: file_helper
INFO - 2023-05-31 05:56:21 --> Helper loaded: html_helper
INFO - 2023-05-31 05:56:21 --> Helper loaded: text_helper
INFO - 2023-05-31 05:56:21 --> Helper loaded: form_helper
INFO - 2023-05-31 05:56:21 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:56:21 --> Helper loaded: security_helper
INFO - 2023-05-31 05:56:21 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:56:21 --> Database Driver Class Initialized
INFO - 2023-05-31 05:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:56:21 --> Parser Class Initialized
INFO - 2023-05-31 05:56:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:56:21 --> Pagination Class Initialized
INFO - 2023-05-31 05:56:21 --> Form Validation Class Initialized
INFO - 2023-05-31 05:56:21 --> Controller Class Initialized
INFO - 2023-05-31 05:56:21 --> Model Class Initialized
DEBUG - 2023-05-31 05:56:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 05:56:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:56:21 --> Model Class Initialized
INFO - 2023-05-31 05:56:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-31 05:56:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:56:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 05:56:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 05:56:21 --> Model Class Initialized
INFO - 2023-05-31 05:56:21 --> Model Class Initialized
INFO - 2023-05-31 05:56:21 --> Model Class Initialized
INFO - 2023-05-31 05:56:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 05:56:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 05:56:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 05:56:21 --> Final output sent to browser
DEBUG - 2023-05-31 05:56:21 --> Total execution time: 0.0622
ERROR - 2023-05-31 05:56:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:56:21 --> Config Class Initialized
INFO - 2023-05-31 05:56:21 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:56:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:56:21 --> Utf8 Class Initialized
INFO - 2023-05-31 05:56:21 --> URI Class Initialized
INFO - 2023-05-31 05:56:21 --> Router Class Initialized
INFO - 2023-05-31 05:56:21 --> Output Class Initialized
INFO - 2023-05-31 05:56:21 --> Security Class Initialized
DEBUG - 2023-05-31 05:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:56:21 --> Input Class Initialized
INFO - 2023-05-31 05:56:21 --> Language Class Initialized
INFO - 2023-05-31 05:56:21 --> Loader Class Initialized
INFO - 2023-05-31 05:56:21 --> Helper loaded: url_helper
INFO - 2023-05-31 05:56:21 --> Helper loaded: file_helper
INFO - 2023-05-31 05:56:21 --> Helper loaded: html_helper
INFO - 2023-05-31 05:56:21 --> Helper loaded: text_helper
INFO - 2023-05-31 05:56:21 --> Helper loaded: form_helper
INFO - 2023-05-31 05:56:21 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:56:21 --> Helper loaded: security_helper
INFO - 2023-05-31 05:56:21 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:56:21 --> Database Driver Class Initialized
INFO - 2023-05-31 05:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:56:21 --> Parser Class Initialized
INFO - 2023-05-31 05:56:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:56:21 --> Pagination Class Initialized
INFO - 2023-05-31 05:56:21 --> Form Validation Class Initialized
INFO - 2023-05-31 05:56:21 --> Controller Class Initialized
INFO - 2023-05-31 05:56:21 --> Model Class Initialized
DEBUG - 2023-05-31 05:56:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 05:56:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:56:21 --> Model Class Initialized
INFO - 2023-05-31 05:56:21 --> Final output sent to browser
DEBUG - 2023-05-31 05:56:21 --> Total execution time: 0.0238
ERROR - 2023-05-31 05:56:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 05:56:27 --> Config Class Initialized
INFO - 2023-05-31 05:56:27 --> Hooks Class Initialized
DEBUG - 2023-05-31 05:56:27 --> UTF-8 Support Enabled
INFO - 2023-05-31 05:56:27 --> Utf8 Class Initialized
INFO - 2023-05-31 05:56:27 --> URI Class Initialized
INFO - 2023-05-31 05:56:27 --> Router Class Initialized
INFO - 2023-05-31 05:56:27 --> Output Class Initialized
INFO - 2023-05-31 05:56:27 --> Security Class Initialized
DEBUG - 2023-05-31 05:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 05:56:27 --> Input Class Initialized
INFO - 2023-05-31 05:56:27 --> Language Class Initialized
INFO - 2023-05-31 05:56:27 --> Loader Class Initialized
INFO - 2023-05-31 05:56:27 --> Helper loaded: url_helper
INFO - 2023-05-31 05:56:27 --> Helper loaded: file_helper
INFO - 2023-05-31 05:56:27 --> Helper loaded: html_helper
INFO - 2023-05-31 05:56:27 --> Helper loaded: text_helper
INFO - 2023-05-31 05:56:27 --> Helper loaded: form_helper
INFO - 2023-05-31 05:56:27 --> Helper loaded: lang_helper
INFO - 2023-05-31 05:56:27 --> Helper loaded: security_helper
INFO - 2023-05-31 05:56:27 --> Helper loaded: cookie_helper
INFO - 2023-05-31 05:56:27 --> Database Driver Class Initialized
INFO - 2023-05-31 05:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 05:56:27 --> Parser Class Initialized
INFO - 2023-05-31 05:56:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 05:56:27 --> Pagination Class Initialized
INFO - 2023-05-31 05:56:27 --> Form Validation Class Initialized
INFO - 2023-05-31 05:56:27 --> Controller Class Initialized
INFO - 2023-05-31 05:56:27 --> Model Class Initialized
DEBUG - 2023-05-31 05:56:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 05:56:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 05:56:27 --> Model Class Initialized
INFO - 2023-05-31 05:56:27 --> Final output sent to browser
DEBUG - 2023-05-31 05:56:27 --> Total execution time: 0.0225
ERROR - 2023-05-31 06:18:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 06:18:30 --> Config Class Initialized
INFO - 2023-05-31 06:18:30 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:18:30 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:18:30 --> Utf8 Class Initialized
INFO - 2023-05-31 06:18:30 --> URI Class Initialized
INFO - 2023-05-31 06:18:30 --> Router Class Initialized
INFO - 2023-05-31 06:18:30 --> Output Class Initialized
INFO - 2023-05-31 06:18:30 --> Security Class Initialized
DEBUG - 2023-05-31 06:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:18:30 --> Input Class Initialized
INFO - 2023-05-31 06:18:30 --> Language Class Initialized
INFO - 2023-05-31 06:18:30 --> Loader Class Initialized
INFO - 2023-05-31 06:18:30 --> Helper loaded: url_helper
INFO - 2023-05-31 06:18:30 --> Helper loaded: file_helper
INFO - 2023-05-31 06:18:30 --> Helper loaded: html_helper
INFO - 2023-05-31 06:18:30 --> Helper loaded: text_helper
INFO - 2023-05-31 06:18:30 --> Helper loaded: form_helper
INFO - 2023-05-31 06:18:30 --> Helper loaded: lang_helper
INFO - 2023-05-31 06:18:30 --> Helper loaded: security_helper
INFO - 2023-05-31 06:18:30 --> Helper loaded: cookie_helper
INFO - 2023-05-31 06:18:30 --> Database Driver Class Initialized
INFO - 2023-05-31 06:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 06:18:30 --> Parser Class Initialized
INFO - 2023-05-31 06:18:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 06:18:30 --> Pagination Class Initialized
INFO - 2023-05-31 06:18:30 --> Form Validation Class Initialized
INFO - 2023-05-31 06:18:30 --> Controller Class Initialized
INFO - 2023-05-31 06:18:30 --> Model Class Initialized
DEBUG - 2023-05-31 06:18:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 06:18:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 06:18:30 --> Model Class Initialized
INFO - 2023-05-31 06:18:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/upcoming.php
DEBUG - 2023-05-31 06:18:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 06:18:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 06:18:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 06:18:30 --> Model Class Initialized
INFO - 2023-05-31 06:18:30 --> Model Class Initialized
INFO - 2023-05-31 06:18:30 --> Model Class Initialized
INFO - 2023-05-31 06:18:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 06:18:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 06:18:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 06:18:30 --> Final output sent to browser
DEBUG - 2023-05-31 06:18:30 --> Total execution time: 0.0625
ERROR - 2023-05-31 06:18:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 06:18:31 --> Config Class Initialized
INFO - 2023-05-31 06:18:31 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:18:31 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:18:31 --> Utf8 Class Initialized
INFO - 2023-05-31 06:18:31 --> URI Class Initialized
INFO - 2023-05-31 06:18:31 --> Router Class Initialized
INFO - 2023-05-31 06:18:31 --> Output Class Initialized
INFO - 2023-05-31 06:18:31 --> Security Class Initialized
DEBUG - 2023-05-31 06:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:18:31 --> Input Class Initialized
INFO - 2023-05-31 06:18:31 --> Language Class Initialized
INFO - 2023-05-31 06:18:31 --> Loader Class Initialized
INFO - 2023-05-31 06:18:31 --> Helper loaded: url_helper
INFO - 2023-05-31 06:18:31 --> Helper loaded: file_helper
INFO - 2023-05-31 06:18:31 --> Helper loaded: html_helper
INFO - 2023-05-31 06:18:31 --> Helper loaded: text_helper
INFO - 2023-05-31 06:18:31 --> Helper loaded: form_helper
INFO - 2023-05-31 06:18:31 --> Helper loaded: lang_helper
INFO - 2023-05-31 06:18:31 --> Helper loaded: security_helper
INFO - 2023-05-31 06:18:31 --> Helper loaded: cookie_helper
INFO - 2023-05-31 06:18:31 --> Database Driver Class Initialized
INFO - 2023-05-31 06:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 06:18:31 --> Parser Class Initialized
INFO - 2023-05-31 06:18:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 06:18:31 --> Pagination Class Initialized
INFO - 2023-05-31 06:18:31 --> Form Validation Class Initialized
INFO - 2023-05-31 06:18:31 --> Controller Class Initialized
INFO - 2023-05-31 06:18:31 --> Model Class Initialized
DEBUG - 2023-05-31 06:18:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 06:18:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 06:18:31 --> Model Class Initialized
INFO - 2023-05-31 06:18:31 --> Final output sent to browser
DEBUG - 2023-05-31 06:18:31 --> Total execution time: 0.0169
ERROR - 2023-05-31 06:18:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 06:18:35 --> Config Class Initialized
INFO - 2023-05-31 06:18:35 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:18:35 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:18:35 --> Utf8 Class Initialized
INFO - 2023-05-31 06:18:35 --> URI Class Initialized
INFO - 2023-05-31 06:18:35 --> Router Class Initialized
INFO - 2023-05-31 06:18:35 --> Output Class Initialized
INFO - 2023-05-31 06:18:35 --> Security Class Initialized
DEBUG - 2023-05-31 06:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:18:35 --> Input Class Initialized
INFO - 2023-05-31 06:18:35 --> Language Class Initialized
INFO - 2023-05-31 06:18:35 --> Loader Class Initialized
INFO - 2023-05-31 06:18:35 --> Helper loaded: url_helper
INFO - 2023-05-31 06:18:35 --> Helper loaded: file_helper
INFO - 2023-05-31 06:18:35 --> Helper loaded: html_helper
INFO - 2023-05-31 06:18:35 --> Helper loaded: text_helper
INFO - 2023-05-31 06:18:35 --> Helper loaded: form_helper
INFO - 2023-05-31 06:18:35 --> Helper loaded: lang_helper
INFO - 2023-05-31 06:18:35 --> Helper loaded: security_helper
INFO - 2023-05-31 06:18:35 --> Helper loaded: cookie_helper
INFO - 2023-05-31 06:18:35 --> Database Driver Class Initialized
INFO - 2023-05-31 06:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 06:18:35 --> Parser Class Initialized
INFO - 2023-05-31 06:18:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 06:18:35 --> Pagination Class Initialized
INFO - 2023-05-31 06:18:35 --> Form Validation Class Initialized
INFO - 2023-05-31 06:18:35 --> Controller Class Initialized
INFO - 2023-05-31 06:18:35 --> Model Class Initialized
DEBUG - 2023-05-31 06:18:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 06:18:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 06:18:35 --> Model Class Initialized
INFO - 2023-05-31 06:18:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-31 06:18:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 06:18:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 06:18:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 06:18:35 --> Model Class Initialized
INFO - 2023-05-31 06:18:35 --> Model Class Initialized
INFO - 2023-05-31 06:18:35 --> Model Class Initialized
INFO - 2023-05-31 06:18:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 06:18:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 06:18:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 06:18:35 --> Final output sent to browser
DEBUG - 2023-05-31 06:18:35 --> Total execution time: 0.0632
ERROR - 2023-05-31 06:18:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 06:18:35 --> Config Class Initialized
INFO - 2023-05-31 06:18:35 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:18:35 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:18:35 --> Utf8 Class Initialized
INFO - 2023-05-31 06:18:35 --> URI Class Initialized
INFO - 2023-05-31 06:18:35 --> Router Class Initialized
INFO - 2023-05-31 06:18:35 --> Output Class Initialized
INFO - 2023-05-31 06:18:35 --> Security Class Initialized
DEBUG - 2023-05-31 06:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:18:35 --> Input Class Initialized
INFO - 2023-05-31 06:18:35 --> Language Class Initialized
INFO - 2023-05-31 06:18:35 --> Loader Class Initialized
INFO - 2023-05-31 06:18:35 --> Helper loaded: url_helper
INFO - 2023-05-31 06:18:35 --> Helper loaded: file_helper
INFO - 2023-05-31 06:18:35 --> Helper loaded: html_helper
INFO - 2023-05-31 06:18:35 --> Helper loaded: text_helper
INFO - 2023-05-31 06:18:35 --> Helper loaded: form_helper
INFO - 2023-05-31 06:18:35 --> Helper loaded: lang_helper
INFO - 2023-05-31 06:18:35 --> Helper loaded: security_helper
INFO - 2023-05-31 06:18:35 --> Helper loaded: cookie_helper
INFO - 2023-05-31 06:18:35 --> Database Driver Class Initialized
INFO - 2023-05-31 06:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 06:18:35 --> Parser Class Initialized
INFO - 2023-05-31 06:18:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 06:18:35 --> Pagination Class Initialized
INFO - 2023-05-31 06:18:35 --> Form Validation Class Initialized
INFO - 2023-05-31 06:18:35 --> Controller Class Initialized
INFO - 2023-05-31 06:18:35 --> Model Class Initialized
DEBUG - 2023-05-31 06:18:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 06:18:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 06:18:35 --> Model Class Initialized
INFO - 2023-05-31 06:18:35 --> Final output sent to browser
DEBUG - 2023-05-31 06:18:35 --> Total execution time: 0.0237
ERROR - 2023-05-31 06:18:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 06:18:48 --> Config Class Initialized
INFO - 2023-05-31 06:18:48 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:18:48 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:18:48 --> Utf8 Class Initialized
INFO - 2023-05-31 06:18:48 --> URI Class Initialized
DEBUG - 2023-05-31 06:18:48 --> No URI present. Default controller set.
INFO - 2023-05-31 06:18:48 --> Router Class Initialized
INFO - 2023-05-31 06:18:48 --> Output Class Initialized
INFO - 2023-05-31 06:18:48 --> Security Class Initialized
DEBUG - 2023-05-31 06:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:18:48 --> Input Class Initialized
INFO - 2023-05-31 06:18:48 --> Language Class Initialized
INFO - 2023-05-31 06:18:48 --> Loader Class Initialized
INFO - 2023-05-31 06:18:48 --> Helper loaded: url_helper
INFO - 2023-05-31 06:18:48 --> Helper loaded: file_helper
INFO - 2023-05-31 06:18:48 --> Helper loaded: html_helper
INFO - 2023-05-31 06:18:48 --> Helper loaded: text_helper
INFO - 2023-05-31 06:18:48 --> Helper loaded: form_helper
INFO - 2023-05-31 06:18:48 --> Helper loaded: lang_helper
INFO - 2023-05-31 06:18:48 --> Helper loaded: security_helper
INFO - 2023-05-31 06:18:48 --> Helper loaded: cookie_helper
INFO - 2023-05-31 06:18:48 --> Database Driver Class Initialized
INFO - 2023-05-31 06:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 06:18:48 --> Parser Class Initialized
INFO - 2023-05-31 06:18:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 06:18:48 --> Pagination Class Initialized
INFO - 2023-05-31 06:18:48 --> Form Validation Class Initialized
INFO - 2023-05-31 06:18:48 --> Controller Class Initialized
INFO - 2023-05-31 06:18:48 --> Model Class Initialized
DEBUG - 2023-05-31 06:18:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 06:18:48 --> Model Class Initialized
DEBUG - 2023-05-31 06:18:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 06:18:48 --> Model Class Initialized
INFO - 2023-05-31 06:18:48 --> Model Class Initialized
INFO - 2023-05-31 06:18:48 --> Model Class Initialized
INFO - 2023-05-31 06:18:48 --> Model Class Initialized
DEBUG - 2023-05-31 06:18:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 06:18:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 06:18:48 --> Model Class Initialized
INFO - 2023-05-31 06:18:48 --> Model Class Initialized
INFO - 2023-05-31 06:18:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-31 06:18:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 06:18:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 06:18:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 06:18:48 --> Model Class Initialized
INFO - 2023-05-31 06:18:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 06:18:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 06:18:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 06:18:48 --> Final output sent to browser
DEBUG - 2023-05-31 06:18:48 --> Total execution time: 0.1673
ERROR - 2023-05-31 07:36:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 07:36:51 --> Config Class Initialized
INFO - 2023-05-31 07:36:51 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:36:51 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:36:51 --> Utf8 Class Initialized
INFO - 2023-05-31 07:36:51 --> URI Class Initialized
DEBUG - 2023-05-31 07:36:51 --> No URI present. Default controller set.
INFO - 2023-05-31 07:36:51 --> Router Class Initialized
INFO - 2023-05-31 07:36:51 --> Output Class Initialized
INFO - 2023-05-31 07:36:51 --> Security Class Initialized
DEBUG - 2023-05-31 07:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:36:51 --> Input Class Initialized
INFO - 2023-05-31 07:36:51 --> Language Class Initialized
INFO - 2023-05-31 07:36:51 --> Loader Class Initialized
INFO - 2023-05-31 07:36:51 --> Helper loaded: url_helper
INFO - 2023-05-31 07:36:51 --> Helper loaded: file_helper
INFO - 2023-05-31 07:36:51 --> Helper loaded: html_helper
INFO - 2023-05-31 07:36:51 --> Helper loaded: text_helper
INFO - 2023-05-31 07:36:51 --> Helper loaded: form_helper
INFO - 2023-05-31 07:36:51 --> Helper loaded: lang_helper
INFO - 2023-05-31 07:36:51 --> Helper loaded: security_helper
INFO - 2023-05-31 07:36:51 --> Helper loaded: cookie_helper
INFO - 2023-05-31 07:36:51 --> Database Driver Class Initialized
INFO - 2023-05-31 07:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 07:36:51 --> Parser Class Initialized
INFO - 2023-05-31 07:36:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 07:36:51 --> Pagination Class Initialized
INFO - 2023-05-31 07:36:51 --> Form Validation Class Initialized
INFO - 2023-05-31 07:36:51 --> Controller Class Initialized
INFO - 2023-05-31 07:36:51 --> Model Class Initialized
DEBUG - 2023-05-31 07:36:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-31 07:37:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 07:37:09 --> Config Class Initialized
INFO - 2023-05-31 07:37:09 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:37:09 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:37:09 --> Utf8 Class Initialized
INFO - 2023-05-31 07:37:09 --> URI Class Initialized
INFO - 2023-05-31 07:37:09 --> Router Class Initialized
INFO - 2023-05-31 07:37:09 --> Output Class Initialized
INFO - 2023-05-31 07:37:09 --> Security Class Initialized
DEBUG - 2023-05-31 07:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:37:09 --> Input Class Initialized
INFO - 2023-05-31 07:37:09 --> Language Class Initialized
INFO - 2023-05-31 07:37:09 --> Loader Class Initialized
INFO - 2023-05-31 07:37:09 --> Helper loaded: url_helper
INFO - 2023-05-31 07:37:09 --> Helper loaded: file_helper
INFO - 2023-05-31 07:37:09 --> Helper loaded: html_helper
INFO - 2023-05-31 07:37:09 --> Helper loaded: text_helper
INFO - 2023-05-31 07:37:09 --> Helper loaded: form_helper
INFO - 2023-05-31 07:37:09 --> Helper loaded: lang_helper
INFO - 2023-05-31 07:37:09 --> Helper loaded: security_helper
INFO - 2023-05-31 07:37:09 --> Helper loaded: cookie_helper
INFO - 2023-05-31 07:37:09 --> Database Driver Class Initialized
INFO - 2023-05-31 07:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 07:37:09 --> Parser Class Initialized
INFO - 2023-05-31 07:37:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 07:37:09 --> Pagination Class Initialized
INFO - 2023-05-31 07:37:09 --> Form Validation Class Initialized
INFO - 2023-05-31 07:37:09 --> Controller Class Initialized
INFO - 2023-05-31 07:37:09 --> Model Class Initialized
DEBUG - 2023-05-31 07:37:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 07:37:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-31 07:37:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 07:37:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 07:37:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 07:37:09 --> Model Class Initialized
INFO - 2023-05-31 07:37:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 07:37:09 --> Final output sent to browser
DEBUG - 2023-05-31 07:37:09 --> Total execution time: 0.0301
ERROR - 2023-05-31 09:55:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 09:55:20 --> Config Class Initialized
INFO - 2023-05-31 09:55:20 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:55:20 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:55:20 --> Utf8 Class Initialized
INFO - 2023-05-31 09:55:20 --> URI Class Initialized
DEBUG - 2023-05-31 09:55:20 --> No URI present. Default controller set.
INFO - 2023-05-31 09:55:20 --> Router Class Initialized
INFO - 2023-05-31 09:55:20 --> Output Class Initialized
INFO - 2023-05-31 09:55:20 --> Security Class Initialized
DEBUG - 2023-05-31 09:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:55:20 --> Input Class Initialized
INFO - 2023-05-31 09:55:20 --> Language Class Initialized
INFO - 2023-05-31 09:55:20 --> Loader Class Initialized
INFO - 2023-05-31 09:55:20 --> Helper loaded: url_helper
INFO - 2023-05-31 09:55:20 --> Helper loaded: file_helper
INFO - 2023-05-31 09:55:20 --> Helper loaded: html_helper
INFO - 2023-05-31 09:55:20 --> Helper loaded: text_helper
INFO - 2023-05-31 09:55:20 --> Helper loaded: form_helper
INFO - 2023-05-31 09:55:20 --> Helper loaded: lang_helper
INFO - 2023-05-31 09:55:20 --> Helper loaded: security_helper
INFO - 2023-05-31 09:55:20 --> Helper loaded: cookie_helper
INFO - 2023-05-31 09:55:20 --> Database Driver Class Initialized
INFO - 2023-05-31 09:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 09:55:20 --> Parser Class Initialized
INFO - 2023-05-31 09:55:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 09:55:20 --> Pagination Class Initialized
INFO - 2023-05-31 09:55:20 --> Form Validation Class Initialized
INFO - 2023-05-31 09:55:20 --> Controller Class Initialized
INFO - 2023-05-31 09:55:20 --> Model Class Initialized
DEBUG - 2023-05-31 09:55:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-31 16:04:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:04:02 --> Config Class Initialized
INFO - 2023-05-31 16:04:02 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:04:02 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:04:02 --> Utf8 Class Initialized
INFO - 2023-05-31 16:04:02 --> URI Class Initialized
DEBUG - 2023-05-31 16:04:02 --> No URI present. Default controller set.
INFO - 2023-05-31 16:04:02 --> Router Class Initialized
INFO - 2023-05-31 16:04:02 --> Output Class Initialized
INFO - 2023-05-31 16:04:02 --> Security Class Initialized
DEBUG - 2023-05-31 16:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:04:02 --> Input Class Initialized
INFO - 2023-05-31 16:04:02 --> Language Class Initialized
INFO - 2023-05-31 16:04:02 --> Loader Class Initialized
INFO - 2023-05-31 16:04:02 --> Helper loaded: url_helper
INFO - 2023-05-31 16:04:02 --> Helper loaded: file_helper
INFO - 2023-05-31 16:04:02 --> Helper loaded: html_helper
INFO - 2023-05-31 16:04:02 --> Helper loaded: text_helper
INFO - 2023-05-31 16:04:02 --> Helper loaded: form_helper
INFO - 2023-05-31 16:04:02 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:04:02 --> Helper loaded: security_helper
INFO - 2023-05-31 16:04:02 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:04:02 --> Database Driver Class Initialized
INFO - 2023-05-31 16:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:04:02 --> Parser Class Initialized
INFO - 2023-05-31 16:04:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:04:02 --> Pagination Class Initialized
INFO - 2023-05-31 16:04:02 --> Form Validation Class Initialized
INFO - 2023-05-31 16:04:02 --> Controller Class Initialized
INFO - 2023-05-31 16:04:02 --> Model Class Initialized
DEBUG - 2023-05-31 16:04:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-31 16:04:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:04:04 --> Config Class Initialized
INFO - 2023-05-31 16:04:04 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:04:04 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:04:04 --> Utf8 Class Initialized
INFO - 2023-05-31 16:04:04 --> URI Class Initialized
INFO - 2023-05-31 16:04:04 --> Router Class Initialized
INFO - 2023-05-31 16:04:04 --> Output Class Initialized
INFO - 2023-05-31 16:04:04 --> Security Class Initialized
DEBUG - 2023-05-31 16:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:04:04 --> Input Class Initialized
INFO - 2023-05-31 16:04:04 --> Language Class Initialized
INFO - 2023-05-31 16:04:04 --> Loader Class Initialized
INFO - 2023-05-31 16:04:04 --> Helper loaded: url_helper
INFO - 2023-05-31 16:04:04 --> Helper loaded: file_helper
INFO - 2023-05-31 16:04:04 --> Helper loaded: html_helper
INFO - 2023-05-31 16:04:04 --> Helper loaded: text_helper
INFO - 2023-05-31 16:04:04 --> Helper loaded: form_helper
INFO - 2023-05-31 16:04:04 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:04:04 --> Helper loaded: security_helper
INFO - 2023-05-31 16:04:04 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:04:04 --> Database Driver Class Initialized
INFO - 2023-05-31 16:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:04:04 --> Parser Class Initialized
INFO - 2023-05-31 16:04:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:04:04 --> Pagination Class Initialized
INFO - 2023-05-31 16:04:04 --> Form Validation Class Initialized
INFO - 2023-05-31 16:04:04 --> Controller Class Initialized
INFO - 2023-05-31 16:04:04 --> Model Class Initialized
DEBUG - 2023-05-31 16:04:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:04:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-31 16:04:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:04:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:04:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:04:04 --> Model Class Initialized
INFO - 2023-05-31 16:04:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:04:04 --> Final output sent to browser
DEBUG - 2023-05-31 16:04:04 --> Total execution time: 0.0352
ERROR - 2023-05-31 16:04:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:04:28 --> Config Class Initialized
INFO - 2023-05-31 16:04:28 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:04:28 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:04:28 --> Utf8 Class Initialized
INFO - 2023-05-31 16:04:28 --> URI Class Initialized
INFO - 2023-05-31 16:04:28 --> Router Class Initialized
INFO - 2023-05-31 16:04:28 --> Output Class Initialized
INFO - 2023-05-31 16:04:28 --> Security Class Initialized
DEBUG - 2023-05-31 16:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:04:28 --> Input Class Initialized
INFO - 2023-05-31 16:04:28 --> Language Class Initialized
INFO - 2023-05-31 16:04:28 --> Loader Class Initialized
INFO - 2023-05-31 16:04:28 --> Helper loaded: url_helper
INFO - 2023-05-31 16:04:28 --> Helper loaded: file_helper
INFO - 2023-05-31 16:04:28 --> Helper loaded: html_helper
INFO - 2023-05-31 16:04:28 --> Helper loaded: text_helper
INFO - 2023-05-31 16:04:28 --> Helper loaded: form_helper
INFO - 2023-05-31 16:04:28 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:04:28 --> Helper loaded: security_helper
INFO - 2023-05-31 16:04:28 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:04:28 --> Database Driver Class Initialized
INFO - 2023-05-31 16:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:04:28 --> Parser Class Initialized
INFO - 2023-05-31 16:04:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:04:28 --> Pagination Class Initialized
INFO - 2023-05-31 16:04:28 --> Form Validation Class Initialized
INFO - 2023-05-31 16:04:28 --> Controller Class Initialized
INFO - 2023-05-31 16:04:28 --> Model Class Initialized
DEBUG - 2023-05-31 16:04:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:04:28 --> Model Class Initialized
INFO - 2023-05-31 16:04:28 --> Final output sent to browser
DEBUG - 2023-05-31 16:04:28 --> Total execution time: 0.0192
ERROR - 2023-05-31 16:04:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:04:29 --> Config Class Initialized
INFO - 2023-05-31 16:04:29 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:04:29 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:04:29 --> Utf8 Class Initialized
INFO - 2023-05-31 16:04:29 --> URI Class Initialized
DEBUG - 2023-05-31 16:04:29 --> No URI present. Default controller set.
INFO - 2023-05-31 16:04:29 --> Router Class Initialized
INFO - 2023-05-31 16:04:29 --> Output Class Initialized
INFO - 2023-05-31 16:04:29 --> Security Class Initialized
DEBUG - 2023-05-31 16:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:04:29 --> Input Class Initialized
INFO - 2023-05-31 16:04:29 --> Language Class Initialized
INFO - 2023-05-31 16:04:29 --> Loader Class Initialized
INFO - 2023-05-31 16:04:29 --> Helper loaded: url_helper
INFO - 2023-05-31 16:04:29 --> Helper loaded: file_helper
INFO - 2023-05-31 16:04:29 --> Helper loaded: html_helper
INFO - 2023-05-31 16:04:29 --> Helper loaded: text_helper
INFO - 2023-05-31 16:04:29 --> Helper loaded: form_helper
INFO - 2023-05-31 16:04:29 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:04:29 --> Helper loaded: security_helper
INFO - 2023-05-31 16:04:29 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:04:29 --> Database Driver Class Initialized
INFO - 2023-05-31 16:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:04:29 --> Parser Class Initialized
INFO - 2023-05-31 16:04:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:04:29 --> Pagination Class Initialized
INFO - 2023-05-31 16:04:29 --> Form Validation Class Initialized
INFO - 2023-05-31 16:04:29 --> Controller Class Initialized
INFO - 2023-05-31 16:04:29 --> Model Class Initialized
DEBUG - 2023-05-31 16:04:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:04:29 --> Model Class Initialized
DEBUG - 2023-05-31 16:04:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:04:29 --> Model Class Initialized
INFO - 2023-05-31 16:04:29 --> Model Class Initialized
INFO - 2023-05-31 16:04:29 --> Model Class Initialized
INFO - 2023-05-31 16:04:29 --> Model Class Initialized
DEBUG - 2023-05-31 16:04:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:04:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:04:29 --> Model Class Initialized
INFO - 2023-05-31 16:04:29 --> Model Class Initialized
INFO - 2023-05-31 16:04:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-31 16:04:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:04:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:04:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:04:29 --> Model Class Initialized
INFO - 2023-05-31 16:04:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:04:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:04:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:04:29 --> Final output sent to browser
DEBUG - 2023-05-31 16:04:29 --> Total execution time: 0.0752
ERROR - 2023-05-31 16:04:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:04:30 --> Config Class Initialized
INFO - 2023-05-31 16:04:30 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:04:30 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:04:30 --> Utf8 Class Initialized
INFO - 2023-05-31 16:04:30 --> URI Class Initialized
INFO - 2023-05-31 16:04:30 --> Router Class Initialized
INFO - 2023-05-31 16:04:30 --> Output Class Initialized
INFO - 2023-05-31 16:04:30 --> Security Class Initialized
DEBUG - 2023-05-31 16:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:04:30 --> Input Class Initialized
INFO - 2023-05-31 16:04:30 --> Language Class Initialized
INFO - 2023-05-31 16:04:30 --> Loader Class Initialized
INFO - 2023-05-31 16:04:30 --> Helper loaded: url_helper
INFO - 2023-05-31 16:04:30 --> Helper loaded: file_helper
INFO - 2023-05-31 16:04:30 --> Helper loaded: html_helper
INFO - 2023-05-31 16:04:30 --> Helper loaded: text_helper
INFO - 2023-05-31 16:04:30 --> Helper loaded: form_helper
INFO - 2023-05-31 16:04:30 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:04:30 --> Helper loaded: security_helper
INFO - 2023-05-31 16:04:30 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:04:30 --> Database Driver Class Initialized
INFO - 2023-05-31 16:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:04:30 --> Parser Class Initialized
INFO - 2023-05-31 16:04:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:04:30 --> Pagination Class Initialized
INFO - 2023-05-31 16:04:30 --> Form Validation Class Initialized
INFO - 2023-05-31 16:04:30 --> Controller Class Initialized
INFO - 2023-05-31 16:04:30 --> Model Class Initialized
DEBUG - 2023-05-31 16:04:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:04:30 --> Model Class Initialized
INFO - 2023-05-31 16:04:30 --> Final output sent to browser
DEBUG - 2023-05-31 16:04:30 --> Total execution time: 0.0143
ERROR - 2023-05-31 16:04:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:04:30 --> Config Class Initialized
INFO - 2023-05-31 16:04:30 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:04:30 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:04:30 --> Utf8 Class Initialized
INFO - 2023-05-31 16:04:30 --> URI Class Initialized
DEBUG - 2023-05-31 16:04:30 --> No URI present. Default controller set.
INFO - 2023-05-31 16:04:30 --> Router Class Initialized
INFO - 2023-05-31 16:04:30 --> Output Class Initialized
INFO - 2023-05-31 16:04:30 --> Security Class Initialized
DEBUG - 2023-05-31 16:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:04:30 --> Input Class Initialized
INFO - 2023-05-31 16:04:30 --> Language Class Initialized
INFO - 2023-05-31 16:04:30 --> Loader Class Initialized
INFO - 2023-05-31 16:04:30 --> Helper loaded: url_helper
INFO - 2023-05-31 16:04:30 --> Helper loaded: file_helper
INFO - 2023-05-31 16:04:30 --> Helper loaded: html_helper
INFO - 2023-05-31 16:04:30 --> Helper loaded: text_helper
INFO - 2023-05-31 16:04:30 --> Helper loaded: form_helper
INFO - 2023-05-31 16:04:30 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:04:30 --> Helper loaded: security_helper
INFO - 2023-05-31 16:04:30 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:04:30 --> Database Driver Class Initialized
INFO - 2023-05-31 16:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:04:31 --> Parser Class Initialized
INFO - 2023-05-31 16:04:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:04:31 --> Pagination Class Initialized
INFO - 2023-05-31 16:04:31 --> Form Validation Class Initialized
INFO - 2023-05-31 16:04:31 --> Controller Class Initialized
INFO - 2023-05-31 16:04:31 --> Model Class Initialized
DEBUG - 2023-05-31 16:04:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:04:31 --> Model Class Initialized
DEBUG - 2023-05-31 16:04:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:04:31 --> Model Class Initialized
INFO - 2023-05-31 16:04:31 --> Model Class Initialized
INFO - 2023-05-31 16:04:31 --> Model Class Initialized
INFO - 2023-05-31 16:04:31 --> Model Class Initialized
DEBUG - 2023-05-31 16:04:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:04:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:04:31 --> Model Class Initialized
INFO - 2023-05-31 16:04:31 --> Model Class Initialized
INFO - 2023-05-31 16:04:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-31 16:04:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:04:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:04:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:04:31 --> Model Class Initialized
INFO - 2023-05-31 16:04:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:04:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:04:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:04:31 --> Final output sent to browser
DEBUG - 2023-05-31 16:04:31 --> Total execution time: 0.0747
ERROR - 2023-05-31 16:04:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:04:57 --> Config Class Initialized
INFO - 2023-05-31 16:04:57 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:04:57 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:04:57 --> Utf8 Class Initialized
INFO - 2023-05-31 16:04:57 --> URI Class Initialized
INFO - 2023-05-31 16:04:57 --> Router Class Initialized
INFO - 2023-05-31 16:04:57 --> Output Class Initialized
INFO - 2023-05-31 16:04:57 --> Security Class Initialized
DEBUG - 2023-05-31 16:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:04:57 --> Input Class Initialized
INFO - 2023-05-31 16:04:57 --> Language Class Initialized
INFO - 2023-05-31 16:04:57 --> Loader Class Initialized
INFO - 2023-05-31 16:04:57 --> Helper loaded: url_helper
INFO - 2023-05-31 16:04:57 --> Helper loaded: file_helper
INFO - 2023-05-31 16:04:57 --> Helper loaded: html_helper
INFO - 2023-05-31 16:04:57 --> Helper loaded: text_helper
INFO - 2023-05-31 16:04:57 --> Helper loaded: form_helper
INFO - 2023-05-31 16:04:57 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:04:57 --> Helper loaded: security_helper
INFO - 2023-05-31 16:04:57 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:04:57 --> Database Driver Class Initialized
INFO - 2023-05-31 16:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:04:57 --> Parser Class Initialized
INFO - 2023-05-31 16:04:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:04:57 --> Pagination Class Initialized
INFO - 2023-05-31 16:04:57 --> Form Validation Class Initialized
INFO - 2023-05-31 16:04:57 --> Controller Class Initialized
INFO - 2023-05-31 16:04:57 --> Model Class Initialized
DEBUG - 2023-05-31 16:04:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:04:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:04:57 --> Model Class Initialized
DEBUG - 2023-05-31 16:04:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:04:57 --> Model Class Initialized
INFO - 2023-05-31 16:04:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-31 16:04:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:04:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:04:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:04:57 --> Model Class Initialized
INFO - 2023-05-31 16:04:57 --> Model Class Initialized
INFO - 2023-05-31 16:04:57 --> Model Class Initialized
ERROR - 2023-05-31 16:04:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:04:57 --> Config Class Initialized
INFO - 2023-05-31 16:04:57 --> Hooks Class Initialized
INFO - 2023-05-31 16:04:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
DEBUG - 2023-05-31 16:04:57 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:04:57 --> Utf8 Class Initialized
INFO - 2023-05-31 16:04:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:04:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:04:57 --> Final output sent to browser
DEBUG - 2023-05-31 16:04:57 --> Total execution time: 0.0719
INFO - 2023-05-31 16:04:57 --> URI Class Initialized
INFO - 2023-05-31 16:04:57 --> Router Class Initialized
INFO - 2023-05-31 16:04:57 --> Output Class Initialized
INFO - 2023-05-31 16:04:57 --> Security Class Initialized
DEBUG - 2023-05-31 16:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:04:57 --> Input Class Initialized
INFO - 2023-05-31 16:04:57 --> Language Class Initialized
INFO - 2023-05-31 16:04:57 --> Loader Class Initialized
INFO - 2023-05-31 16:04:57 --> Helper loaded: url_helper
INFO - 2023-05-31 16:04:57 --> Helper loaded: file_helper
INFO - 2023-05-31 16:04:57 --> Helper loaded: html_helper
INFO - 2023-05-31 16:04:57 --> Helper loaded: text_helper
INFO - 2023-05-31 16:04:57 --> Helper loaded: form_helper
INFO - 2023-05-31 16:04:57 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:04:57 --> Helper loaded: security_helper
INFO - 2023-05-31 16:04:57 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:04:57 --> Database Driver Class Initialized
INFO - 2023-05-31 16:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:04:57 --> Parser Class Initialized
INFO - 2023-05-31 16:04:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:04:57 --> Pagination Class Initialized
INFO - 2023-05-31 16:04:57 --> Form Validation Class Initialized
INFO - 2023-05-31 16:04:57 --> Controller Class Initialized
INFO - 2023-05-31 16:04:57 --> Model Class Initialized
DEBUG - 2023-05-31 16:04:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:04:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:04:57 --> Model Class Initialized
DEBUG - 2023-05-31 16:04:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:04:57 --> Model Class Initialized
INFO - 2023-05-31 16:04:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-31 16:04:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:04:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:04:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:04:57 --> Model Class Initialized
INFO - 2023-05-31 16:04:57 --> Model Class Initialized
INFO - 2023-05-31 16:04:57 --> Model Class Initialized
INFO - 2023-05-31 16:04:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:04:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:04:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:04:57 --> Final output sent to browser
DEBUG - 2023-05-31 16:04:57 --> Total execution time: 0.0707
ERROR - 2023-05-31 16:05:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:05:01 --> Config Class Initialized
INFO - 2023-05-31 16:05:01 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:05:01 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:05:01 --> Utf8 Class Initialized
INFO - 2023-05-31 16:05:01 --> URI Class Initialized
INFO - 2023-05-31 16:05:01 --> Router Class Initialized
INFO - 2023-05-31 16:05:01 --> Output Class Initialized
INFO - 2023-05-31 16:05:01 --> Security Class Initialized
DEBUG - 2023-05-31 16:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:05:01 --> Input Class Initialized
INFO - 2023-05-31 16:05:01 --> Language Class Initialized
INFO - 2023-05-31 16:05:01 --> Loader Class Initialized
INFO - 2023-05-31 16:05:01 --> Helper loaded: url_helper
INFO - 2023-05-31 16:05:01 --> Helper loaded: file_helper
INFO - 2023-05-31 16:05:01 --> Helper loaded: html_helper
INFO - 2023-05-31 16:05:01 --> Helper loaded: text_helper
INFO - 2023-05-31 16:05:01 --> Helper loaded: form_helper
INFO - 2023-05-31 16:05:01 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:05:01 --> Helper loaded: security_helper
INFO - 2023-05-31 16:05:01 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:05:01 --> Database Driver Class Initialized
INFO - 2023-05-31 16:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:05:01 --> Parser Class Initialized
INFO - 2023-05-31 16:05:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:05:01 --> Pagination Class Initialized
INFO - 2023-05-31 16:05:01 --> Form Validation Class Initialized
INFO - 2023-05-31 16:05:01 --> Controller Class Initialized
INFO - 2023-05-31 16:05:01 --> Model Class Initialized
DEBUG - 2023-05-31 16:05:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:05:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:05:01 --> Model Class Initialized
DEBUG - 2023-05-31 16:05:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:05:01 --> Model Class Initialized
INFO - 2023-05-31 16:05:01 --> Final output sent to browser
DEBUG - 2023-05-31 16:05:01 --> Total execution time: 0.0423
ERROR - 2023-05-31 16:05:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:05:21 --> Config Class Initialized
INFO - 2023-05-31 16:05:21 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:05:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:05:21 --> Utf8 Class Initialized
INFO - 2023-05-31 16:05:21 --> URI Class Initialized
DEBUG - 2023-05-31 16:05:21 --> No URI present. Default controller set.
INFO - 2023-05-31 16:05:21 --> Router Class Initialized
INFO - 2023-05-31 16:05:21 --> Output Class Initialized
INFO - 2023-05-31 16:05:21 --> Security Class Initialized
DEBUG - 2023-05-31 16:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:05:21 --> Input Class Initialized
INFO - 2023-05-31 16:05:21 --> Language Class Initialized
INFO - 2023-05-31 16:05:21 --> Loader Class Initialized
INFO - 2023-05-31 16:05:21 --> Helper loaded: url_helper
INFO - 2023-05-31 16:05:21 --> Helper loaded: file_helper
INFO - 2023-05-31 16:05:21 --> Helper loaded: html_helper
INFO - 2023-05-31 16:05:21 --> Helper loaded: text_helper
INFO - 2023-05-31 16:05:21 --> Helper loaded: form_helper
INFO - 2023-05-31 16:05:21 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:05:21 --> Helper loaded: security_helper
INFO - 2023-05-31 16:05:21 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:05:21 --> Database Driver Class Initialized
INFO - 2023-05-31 16:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:05:21 --> Parser Class Initialized
INFO - 2023-05-31 16:05:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:05:21 --> Pagination Class Initialized
INFO - 2023-05-31 16:05:21 --> Form Validation Class Initialized
INFO - 2023-05-31 16:05:21 --> Controller Class Initialized
INFO - 2023-05-31 16:05:21 --> Model Class Initialized
DEBUG - 2023-05-31 16:05:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:05:21 --> Model Class Initialized
DEBUG - 2023-05-31 16:05:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:05:21 --> Model Class Initialized
INFO - 2023-05-31 16:05:21 --> Model Class Initialized
INFO - 2023-05-31 16:05:21 --> Model Class Initialized
INFO - 2023-05-31 16:05:21 --> Model Class Initialized
DEBUG - 2023-05-31 16:05:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:05:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:05:21 --> Model Class Initialized
INFO - 2023-05-31 16:05:21 --> Model Class Initialized
INFO - 2023-05-31 16:05:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-31 16:05:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:05:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:05:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:05:21 --> Model Class Initialized
INFO - 2023-05-31 16:05:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:05:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:05:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:05:21 --> Final output sent to browser
DEBUG - 2023-05-31 16:05:21 --> Total execution time: 0.0760
ERROR - 2023-05-31 16:05:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:05:44 --> Config Class Initialized
INFO - 2023-05-31 16:05:44 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:05:44 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:05:44 --> Utf8 Class Initialized
INFO - 2023-05-31 16:05:44 --> URI Class Initialized
INFO - 2023-05-31 16:05:44 --> Router Class Initialized
INFO - 2023-05-31 16:05:44 --> Output Class Initialized
INFO - 2023-05-31 16:05:44 --> Security Class Initialized
DEBUG - 2023-05-31 16:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:05:44 --> Input Class Initialized
INFO - 2023-05-31 16:05:44 --> Language Class Initialized
INFO - 2023-05-31 16:05:44 --> Loader Class Initialized
INFO - 2023-05-31 16:05:44 --> Helper loaded: url_helper
INFO - 2023-05-31 16:05:44 --> Helper loaded: file_helper
INFO - 2023-05-31 16:05:44 --> Helper loaded: html_helper
INFO - 2023-05-31 16:05:44 --> Helper loaded: text_helper
INFO - 2023-05-31 16:05:44 --> Helper loaded: form_helper
INFO - 2023-05-31 16:05:44 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:05:44 --> Helper loaded: security_helper
INFO - 2023-05-31 16:05:44 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:05:44 --> Database Driver Class Initialized
INFO - 2023-05-31 16:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:05:44 --> Parser Class Initialized
INFO - 2023-05-31 16:05:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:05:44 --> Pagination Class Initialized
INFO - 2023-05-31 16:05:44 --> Form Validation Class Initialized
INFO - 2023-05-31 16:05:44 --> Controller Class Initialized
INFO - 2023-05-31 16:05:44 --> Model Class Initialized
DEBUG - 2023-05-31 16:05:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:05:44 --> Model Class Initialized
DEBUG - 2023-05-31 16:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:05:44 --> Model Class Initialized
INFO - 2023-05-31 16:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-31 16:05:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:05:44 --> Model Class Initialized
INFO - 2023-05-31 16:05:44 --> Model Class Initialized
INFO - 2023-05-31 16:05:44 --> Model Class Initialized
INFO - 2023-05-31 16:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:05:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:05:44 --> Final output sent to browser
DEBUG - 2023-05-31 16:05:44 --> Total execution time: 0.0882
ERROR - 2023-05-31 16:05:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:05:51 --> Config Class Initialized
INFO - 2023-05-31 16:05:51 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:05:51 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:05:51 --> Utf8 Class Initialized
INFO - 2023-05-31 16:05:51 --> URI Class Initialized
INFO - 2023-05-31 16:05:51 --> Router Class Initialized
INFO - 2023-05-31 16:05:51 --> Output Class Initialized
INFO - 2023-05-31 16:05:51 --> Security Class Initialized
DEBUG - 2023-05-31 16:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:05:51 --> Input Class Initialized
INFO - 2023-05-31 16:05:51 --> Language Class Initialized
INFO - 2023-05-31 16:05:51 --> Loader Class Initialized
INFO - 2023-05-31 16:05:51 --> Helper loaded: url_helper
INFO - 2023-05-31 16:05:51 --> Helper loaded: file_helper
INFO - 2023-05-31 16:05:51 --> Helper loaded: html_helper
INFO - 2023-05-31 16:05:51 --> Helper loaded: text_helper
INFO - 2023-05-31 16:05:51 --> Helper loaded: form_helper
INFO - 2023-05-31 16:05:51 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:05:51 --> Helper loaded: security_helper
INFO - 2023-05-31 16:05:51 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:05:51 --> Database Driver Class Initialized
INFO - 2023-05-31 16:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:05:51 --> Parser Class Initialized
INFO - 2023-05-31 16:05:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:05:51 --> Pagination Class Initialized
INFO - 2023-05-31 16:05:51 --> Form Validation Class Initialized
INFO - 2023-05-31 16:05:51 --> Controller Class Initialized
ERROR - 2023-05-31 16:05:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:05:51 --> Config Class Initialized
INFO - 2023-05-31 16:05:51 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:05:51 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:05:51 --> Utf8 Class Initialized
INFO - 2023-05-31 16:05:51 --> URI Class Initialized
INFO - 2023-05-31 16:05:51 --> Model Class Initialized
DEBUG - 2023-05-31 16:05:51 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:05:51 --> Router Class Initialized
DEBUG - 2023-05-31 16:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:05:51 --> Output Class Initialized
INFO - 2023-05-31 16:05:51 --> Model Class Initialized
DEBUG - 2023-05-31 16:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:05:51 --> Security Class Initialized
INFO - 2023-05-31 16:05:51 --> Model Class Initialized
DEBUG - 2023-05-31 16:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:05:51 --> Input Class Initialized
INFO - 2023-05-31 16:05:51 --> Language Class Initialized
INFO - 2023-05-31 16:05:51 --> Loader Class Initialized
INFO - 2023-05-31 16:05:51 --> Helper loaded: url_helper
INFO - 2023-05-31 16:05:51 --> Helper loaded: file_helper
INFO - 2023-05-31 16:05:51 --> Helper loaded: html_helper
INFO - 2023-05-31 16:05:51 --> Helper loaded: text_helper
INFO - 2023-05-31 16:05:51 --> Helper loaded: form_helper
INFO - 2023-05-31 16:05:51 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:05:51 --> Helper loaded: security_helper
INFO - 2023-05-31 16:05:51 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:05:51 --> Database Driver Class Initialized
INFO - 2023-05-31 16:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-31 16:05:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:05:51 --> Model Class Initialized
INFO - 2023-05-31 16:05:51 --> Model Class Initialized
INFO - 2023-05-31 16:05:51 --> Model Class Initialized
INFO - 2023-05-31 16:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:05:51 --> Final output sent to browser
DEBUG - 2023-05-31 16:05:51 --> Total execution time: 0.0737
INFO - 2023-05-31 16:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:05:51 --> Parser Class Initialized
INFO - 2023-05-31 16:05:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:05:51 --> Pagination Class Initialized
INFO - 2023-05-31 16:05:51 --> Form Validation Class Initialized
INFO - 2023-05-31 16:05:51 --> Controller Class Initialized
INFO - 2023-05-31 16:05:51 --> Model Class Initialized
DEBUG - 2023-05-31 16:05:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:05:51 --> Model Class Initialized
DEBUG - 2023-05-31 16:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:05:51 --> Model Class Initialized
INFO - 2023-05-31 16:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-31 16:05:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:05:51 --> Model Class Initialized
INFO - 2023-05-31 16:05:51 --> Model Class Initialized
INFO - 2023-05-31 16:05:51 --> Model Class Initialized
INFO - 2023-05-31 16:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:05:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:05:51 --> Final output sent to browser
DEBUG - 2023-05-31 16:05:51 --> Total execution time: 0.1194
ERROR - 2023-05-31 16:06:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:06:01 --> Config Class Initialized
INFO - 2023-05-31 16:06:01 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:06:01 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:06:01 --> Utf8 Class Initialized
INFO - 2023-05-31 16:06:01 --> URI Class Initialized
INFO - 2023-05-31 16:06:01 --> Router Class Initialized
INFO - 2023-05-31 16:06:01 --> Output Class Initialized
INFO - 2023-05-31 16:06:01 --> Security Class Initialized
DEBUG - 2023-05-31 16:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:06:01 --> Input Class Initialized
INFO - 2023-05-31 16:06:01 --> Language Class Initialized
INFO - 2023-05-31 16:06:01 --> Loader Class Initialized
INFO - 2023-05-31 16:06:01 --> Helper loaded: url_helper
INFO - 2023-05-31 16:06:01 --> Helper loaded: file_helper
INFO - 2023-05-31 16:06:01 --> Helper loaded: html_helper
INFO - 2023-05-31 16:06:01 --> Helper loaded: text_helper
INFO - 2023-05-31 16:06:01 --> Helper loaded: form_helper
INFO - 2023-05-31 16:06:01 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:06:01 --> Helper loaded: security_helper
INFO - 2023-05-31 16:06:01 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:06:01 --> Database Driver Class Initialized
INFO - 2023-05-31 16:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:06:01 --> Parser Class Initialized
INFO - 2023-05-31 16:06:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:06:01 --> Pagination Class Initialized
INFO - 2023-05-31 16:06:01 --> Form Validation Class Initialized
INFO - 2023-05-31 16:06:01 --> Controller Class Initialized
INFO - 2023-05-31 16:06:01 --> Model Class Initialized
DEBUG - 2023-05-31 16:06:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:06:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:06:01 --> Model Class Initialized
DEBUG - 2023-05-31 16:06:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:06:01 --> Model Class Initialized
INFO - 2023-05-31 16:06:01 --> Final output sent to browser
DEBUG - 2023-05-31 16:06:01 --> Total execution time: 0.0475
ERROR - 2023-05-31 16:06:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:06:15 --> Config Class Initialized
INFO - 2023-05-31 16:06:15 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:06:15 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:06:15 --> Utf8 Class Initialized
INFO - 2023-05-31 16:06:15 --> URI Class Initialized
INFO - 2023-05-31 16:06:15 --> Router Class Initialized
INFO - 2023-05-31 16:06:15 --> Output Class Initialized
INFO - 2023-05-31 16:06:15 --> Security Class Initialized
DEBUG - 2023-05-31 16:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:06:15 --> Input Class Initialized
INFO - 2023-05-31 16:06:15 --> Language Class Initialized
INFO - 2023-05-31 16:06:15 --> Loader Class Initialized
INFO - 2023-05-31 16:06:15 --> Helper loaded: url_helper
INFO - 2023-05-31 16:06:15 --> Helper loaded: file_helper
INFO - 2023-05-31 16:06:15 --> Helper loaded: html_helper
INFO - 2023-05-31 16:06:15 --> Helper loaded: text_helper
INFO - 2023-05-31 16:06:15 --> Helper loaded: form_helper
INFO - 2023-05-31 16:06:15 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:06:15 --> Helper loaded: security_helper
INFO - 2023-05-31 16:06:15 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:06:15 --> Database Driver Class Initialized
INFO - 2023-05-31 16:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:06:15 --> Parser Class Initialized
INFO - 2023-05-31 16:06:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:06:15 --> Pagination Class Initialized
INFO - 2023-05-31 16:06:15 --> Form Validation Class Initialized
INFO - 2023-05-31 16:06:15 --> Controller Class Initialized
INFO - 2023-05-31 16:06:15 --> Model Class Initialized
DEBUG - 2023-05-31 16:06:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:06:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:06:15 --> Model Class Initialized
INFO - 2023-05-31 16:06:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-05-31 16:06:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:06:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:06:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:06:16 --> Model Class Initialized
INFO - 2023-05-31 16:06:16 --> Model Class Initialized
INFO - 2023-05-31 16:06:16 --> Model Class Initialized
INFO - 2023-05-31 16:06:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:06:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:06:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:06:16 --> Final output sent to browser
DEBUG - 2023-05-31 16:06:16 --> Total execution time: 0.0775
ERROR - 2023-05-31 16:06:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:06:18 --> Config Class Initialized
INFO - 2023-05-31 16:06:18 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:06:18 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:06:18 --> Utf8 Class Initialized
INFO - 2023-05-31 16:06:18 --> URI Class Initialized
INFO - 2023-05-31 16:06:18 --> Router Class Initialized
INFO - 2023-05-31 16:06:18 --> Output Class Initialized
INFO - 2023-05-31 16:06:18 --> Security Class Initialized
DEBUG - 2023-05-31 16:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:06:18 --> Input Class Initialized
INFO - 2023-05-31 16:06:18 --> Language Class Initialized
INFO - 2023-05-31 16:06:18 --> Loader Class Initialized
INFO - 2023-05-31 16:06:18 --> Helper loaded: url_helper
INFO - 2023-05-31 16:06:18 --> Helper loaded: file_helper
INFO - 2023-05-31 16:06:18 --> Helper loaded: html_helper
INFO - 2023-05-31 16:06:18 --> Helper loaded: text_helper
INFO - 2023-05-31 16:06:18 --> Helper loaded: form_helper
INFO - 2023-05-31 16:06:18 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:06:18 --> Helper loaded: security_helper
INFO - 2023-05-31 16:06:18 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:06:18 --> Database Driver Class Initialized
INFO - 2023-05-31 16:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:06:18 --> Parser Class Initialized
INFO - 2023-05-31 16:06:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:06:18 --> Pagination Class Initialized
INFO - 2023-05-31 16:06:18 --> Form Validation Class Initialized
INFO - 2023-05-31 16:06:18 --> Controller Class Initialized
INFO - 2023-05-31 16:06:18 --> Model Class Initialized
DEBUG - 2023-05-31 16:06:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:06:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:06:18 --> Model Class Initialized
INFO - 2023-05-31 16:06:18 --> Final output sent to browser
DEBUG - 2023-05-31 16:06:18 --> Total execution time: 0.0282
ERROR - 2023-05-31 16:06:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:06:32 --> Config Class Initialized
INFO - 2023-05-31 16:06:32 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:06:32 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:06:32 --> Utf8 Class Initialized
INFO - 2023-05-31 16:06:32 --> URI Class Initialized
INFO - 2023-05-31 16:06:32 --> Router Class Initialized
INFO - 2023-05-31 16:06:32 --> Output Class Initialized
INFO - 2023-05-31 16:06:32 --> Security Class Initialized
DEBUG - 2023-05-31 16:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:06:32 --> Input Class Initialized
INFO - 2023-05-31 16:06:32 --> Language Class Initialized
INFO - 2023-05-31 16:06:32 --> Loader Class Initialized
INFO - 2023-05-31 16:06:32 --> Helper loaded: url_helper
INFO - 2023-05-31 16:06:32 --> Helper loaded: file_helper
INFO - 2023-05-31 16:06:32 --> Helper loaded: html_helper
INFO - 2023-05-31 16:06:32 --> Helper loaded: text_helper
INFO - 2023-05-31 16:06:32 --> Helper loaded: form_helper
INFO - 2023-05-31 16:06:32 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:06:32 --> Helper loaded: security_helper
INFO - 2023-05-31 16:06:32 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:06:32 --> Database Driver Class Initialized
INFO - 2023-05-31 16:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:06:32 --> Parser Class Initialized
INFO - 2023-05-31 16:06:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:06:32 --> Pagination Class Initialized
INFO - 2023-05-31 16:06:32 --> Form Validation Class Initialized
INFO - 2023-05-31 16:06:32 --> Controller Class Initialized
INFO - 2023-05-31 16:06:32 --> Model Class Initialized
DEBUG - 2023-05-31 16:06:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:06:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:06:32 --> Model Class Initialized
INFO - 2023-05-31 16:06:32 --> Final output sent to browser
DEBUG - 2023-05-31 16:06:32 --> Total execution time: 0.0247
ERROR - 2023-05-31 16:06:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:06:44 --> Config Class Initialized
INFO - 2023-05-31 16:06:44 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:06:44 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:06:44 --> Utf8 Class Initialized
INFO - 2023-05-31 16:06:44 --> URI Class Initialized
INFO - 2023-05-31 16:06:44 --> Router Class Initialized
INFO - 2023-05-31 16:06:44 --> Output Class Initialized
INFO - 2023-05-31 16:06:44 --> Security Class Initialized
DEBUG - 2023-05-31 16:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:06:44 --> Input Class Initialized
INFO - 2023-05-31 16:06:44 --> Language Class Initialized
INFO - 2023-05-31 16:06:44 --> Loader Class Initialized
INFO - 2023-05-31 16:06:44 --> Helper loaded: url_helper
INFO - 2023-05-31 16:06:44 --> Helper loaded: file_helper
INFO - 2023-05-31 16:06:44 --> Helper loaded: html_helper
INFO - 2023-05-31 16:06:44 --> Helper loaded: text_helper
INFO - 2023-05-31 16:06:44 --> Helper loaded: form_helper
INFO - 2023-05-31 16:06:44 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:06:44 --> Helper loaded: security_helper
INFO - 2023-05-31 16:06:44 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:06:44 --> Database Driver Class Initialized
INFO - 2023-05-31 16:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:06:44 --> Parser Class Initialized
INFO - 2023-05-31 16:06:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:06:44 --> Pagination Class Initialized
INFO - 2023-05-31 16:06:44 --> Form Validation Class Initialized
INFO - 2023-05-31 16:06:44 --> Controller Class Initialized
INFO - 2023-05-31 16:06:44 --> Model Class Initialized
DEBUG - 2023-05-31 16:06:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:06:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:06:44 --> Model Class Initialized
DEBUG - 2023-05-31 16:06:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:06:44 --> Model Class Initialized
INFO - 2023-05-31 16:06:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-05-31 16:06:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:06:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:06:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:06:44 --> Model Class Initialized
INFO - 2023-05-31 16:06:44 --> Model Class Initialized
INFO - 2023-05-31 16:06:44 --> Model Class Initialized
INFO - 2023-05-31 16:06:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:06:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:06:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:06:44 --> Final output sent to browser
DEBUG - 2023-05-31 16:06:44 --> Total execution time: 0.0734
ERROR - 2023-05-31 16:06:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:06:46 --> Config Class Initialized
INFO - 2023-05-31 16:06:46 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:06:46 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:06:46 --> Utf8 Class Initialized
INFO - 2023-05-31 16:06:46 --> URI Class Initialized
INFO - 2023-05-31 16:06:46 --> Router Class Initialized
INFO - 2023-05-31 16:06:46 --> Output Class Initialized
INFO - 2023-05-31 16:06:46 --> Security Class Initialized
DEBUG - 2023-05-31 16:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:06:46 --> Input Class Initialized
INFO - 2023-05-31 16:06:46 --> Language Class Initialized
INFO - 2023-05-31 16:06:46 --> Loader Class Initialized
INFO - 2023-05-31 16:06:46 --> Helper loaded: url_helper
INFO - 2023-05-31 16:06:46 --> Helper loaded: file_helper
INFO - 2023-05-31 16:06:46 --> Helper loaded: html_helper
INFO - 2023-05-31 16:06:46 --> Helper loaded: text_helper
INFO - 2023-05-31 16:06:46 --> Helper loaded: form_helper
INFO - 2023-05-31 16:06:46 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:06:46 --> Helper loaded: security_helper
INFO - 2023-05-31 16:06:46 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:06:46 --> Database Driver Class Initialized
INFO - 2023-05-31 16:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:06:46 --> Parser Class Initialized
INFO - 2023-05-31 16:06:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:06:46 --> Pagination Class Initialized
INFO - 2023-05-31 16:06:46 --> Form Validation Class Initialized
INFO - 2023-05-31 16:06:46 --> Controller Class Initialized
INFO - 2023-05-31 16:06:46 --> Model Class Initialized
DEBUG - 2023-05-31 16:06:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:06:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:06:46 --> Model Class Initialized
DEBUG - 2023-05-31 16:06:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:06:46 --> Model Class Initialized
INFO - 2023-05-31 16:06:46 --> Final output sent to browser
DEBUG - 2023-05-31 16:06:46 --> Total execution time: 0.0477
ERROR - 2023-05-31 16:07:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:07:25 --> Config Class Initialized
INFO - 2023-05-31 16:07:25 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:07:25 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:07:25 --> Utf8 Class Initialized
INFO - 2023-05-31 16:07:25 --> URI Class Initialized
INFO - 2023-05-31 16:07:25 --> Router Class Initialized
INFO - 2023-05-31 16:07:25 --> Output Class Initialized
INFO - 2023-05-31 16:07:25 --> Security Class Initialized
DEBUG - 2023-05-31 16:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:07:25 --> Input Class Initialized
INFO - 2023-05-31 16:07:25 --> Language Class Initialized
INFO - 2023-05-31 16:07:25 --> Loader Class Initialized
INFO - 2023-05-31 16:07:25 --> Helper loaded: url_helper
INFO - 2023-05-31 16:07:25 --> Helper loaded: file_helper
INFO - 2023-05-31 16:07:25 --> Helper loaded: html_helper
INFO - 2023-05-31 16:07:25 --> Helper loaded: text_helper
INFO - 2023-05-31 16:07:25 --> Helper loaded: form_helper
INFO - 2023-05-31 16:07:25 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:07:25 --> Helper loaded: security_helper
INFO - 2023-05-31 16:07:25 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:07:25 --> Database Driver Class Initialized
INFO - 2023-05-31 16:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:07:25 --> Parser Class Initialized
INFO - 2023-05-31 16:07:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:07:25 --> Pagination Class Initialized
INFO - 2023-05-31 16:07:25 --> Form Validation Class Initialized
INFO - 2023-05-31 16:07:25 --> Controller Class Initialized
INFO - 2023-05-31 16:07:25 --> Model Class Initialized
DEBUG - 2023-05-31 16:07:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:07:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:07:25 --> Model Class Initialized
DEBUG - 2023-05-31 16:07:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:07:25 --> Model Class Initialized
INFO - 2023-05-31 16:07:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2023-05-31 16:07:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:07:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:07:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:07:25 --> Model Class Initialized
INFO - 2023-05-31 16:07:25 --> Model Class Initialized
INFO - 2023-05-31 16:07:25 --> Model Class Initialized
INFO - 2023-05-31 16:07:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:07:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:07:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:07:25 --> Final output sent to browser
DEBUG - 2023-05-31 16:07:25 --> Total execution time: 0.0943
ERROR - 2023-05-31 16:08:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:08:26 --> Config Class Initialized
INFO - 2023-05-31 16:08:26 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:08:26 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:08:26 --> Utf8 Class Initialized
INFO - 2023-05-31 16:08:26 --> URI Class Initialized
INFO - 2023-05-31 16:08:27 --> Router Class Initialized
INFO - 2023-05-31 16:08:27 --> Output Class Initialized
INFO - 2023-05-31 16:08:27 --> Security Class Initialized
DEBUG - 2023-05-31 16:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:08:27 --> Input Class Initialized
INFO - 2023-05-31 16:08:27 --> Language Class Initialized
INFO - 2023-05-31 16:08:27 --> Loader Class Initialized
INFO - 2023-05-31 16:08:27 --> Helper loaded: url_helper
INFO - 2023-05-31 16:08:27 --> Helper loaded: file_helper
INFO - 2023-05-31 16:08:27 --> Helper loaded: html_helper
INFO - 2023-05-31 16:08:27 --> Helper loaded: text_helper
INFO - 2023-05-31 16:08:27 --> Helper loaded: form_helper
INFO - 2023-05-31 16:08:27 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:08:27 --> Helper loaded: security_helper
INFO - 2023-05-31 16:08:27 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:08:27 --> Database Driver Class Initialized
INFO - 2023-05-31 16:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:08:27 --> Parser Class Initialized
INFO - 2023-05-31 16:08:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:08:27 --> Pagination Class Initialized
INFO - 2023-05-31 16:08:27 --> Form Validation Class Initialized
INFO - 2023-05-31 16:08:27 --> Controller Class Initialized
INFO - 2023-05-31 16:08:27 --> Model Class Initialized
DEBUG - 2023-05-31 16:08:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:08:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:08:27 --> Model Class Initialized
DEBUG - 2023-05-31 16:08:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:08:27 --> Model Class Initialized
INFO - 2023-05-31 16:08:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-05-31 16:08:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:08:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:08:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:08:27 --> Model Class Initialized
INFO - 2023-05-31 16:08:27 --> Model Class Initialized
INFO - 2023-05-31 16:08:27 --> Model Class Initialized
INFO - 2023-05-31 16:08:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:08:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:08:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:08:27 --> Final output sent to browser
DEBUG - 2023-05-31 16:08:27 --> Total execution time: 0.0771
ERROR - 2023-05-31 16:08:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:08:31 --> Config Class Initialized
INFO - 2023-05-31 16:08:31 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:08:31 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:08:31 --> Utf8 Class Initialized
INFO - 2023-05-31 16:08:31 --> URI Class Initialized
INFO - 2023-05-31 16:08:31 --> Router Class Initialized
INFO - 2023-05-31 16:08:31 --> Output Class Initialized
INFO - 2023-05-31 16:08:31 --> Security Class Initialized
DEBUG - 2023-05-31 16:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:08:31 --> Input Class Initialized
INFO - 2023-05-31 16:08:31 --> Language Class Initialized
INFO - 2023-05-31 16:08:31 --> Loader Class Initialized
INFO - 2023-05-31 16:08:31 --> Helper loaded: url_helper
INFO - 2023-05-31 16:08:31 --> Helper loaded: file_helper
INFO - 2023-05-31 16:08:31 --> Helper loaded: html_helper
INFO - 2023-05-31 16:08:31 --> Helper loaded: text_helper
INFO - 2023-05-31 16:08:31 --> Helper loaded: form_helper
INFO - 2023-05-31 16:08:31 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:08:31 --> Helper loaded: security_helper
INFO - 2023-05-31 16:08:31 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:08:31 --> Database Driver Class Initialized
INFO - 2023-05-31 16:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:08:31 --> Parser Class Initialized
INFO - 2023-05-31 16:08:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:08:31 --> Pagination Class Initialized
INFO - 2023-05-31 16:08:31 --> Form Validation Class Initialized
INFO - 2023-05-31 16:08:31 --> Controller Class Initialized
INFO - 2023-05-31 16:08:31 --> Model Class Initialized
DEBUG - 2023-05-31 16:08:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:08:31 --> Model Class Initialized
DEBUG - 2023-05-31 16:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:08:31 --> Model Class Initialized
INFO - 2023-05-31 16:08:31 --> Final output sent to browser
DEBUG - 2023-05-31 16:08:31 --> Total execution time: 0.0510
ERROR - 2023-05-31 16:08:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:08:32 --> Config Class Initialized
INFO - 2023-05-31 16:08:32 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:08:32 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:08:32 --> Utf8 Class Initialized
INFO - 2023-05-31 16:08:32 --> URI Class Initialized
INFO - 2023-05-31 16:08:32 --> Router Class Initialized
INFO - 2023-05-31 16:08:32 --> Output Class Initialized
INFO - 2023-05-31 16:08:32 --> Security Class Initialized
DEBUG - 2023-05-31 16:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:08:32 --> Input Class Initialized
INFO - 2023-05-31 16:08:32 --> Language Class Initialized
INFO - 2023-05-31 16:08:32 --> Loader Class Initialized
INFO - 2023-05-31 16:08:32 --> Helper loaded: url_helper
INFO - 2023-05-31 16:08:32 --> Helper loaded: file_helper
INFO - 2023-05-31 16:08:32 --> Helper loaded: html_helper
INFO - 2023-05-31 16:08:32 --> Helper loaded: text_helper
INFO - 2023-05-31 16:08:32 --> Helper loaded: form_helper
INFO - 2023-05-31 16:08:32 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:08:32 --> Helper loaded: security_helper
INFO - 2023-05-31 16:08:32 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:08:32 --> Database Driver Class Initialized
INFO - 2023-05-31 16:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:08:32 --> Parser Class Initialized
INFO - 2023-05-31 16:08:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:08:32 --> Pagination Class Initialized
INFO - 2023-05-31 16:08:32 --> Form Validation Class Initialized
INFO - 2023-05-31 16:08:32 --> Controller Class Initialized
INFO - 2023-05-31 16:08:32 --> Model Class Initialized
DEBUG - 2023-05-31 16:08:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:08:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:08:32 --> Model Class Initialized
INFO - 2023-05-31 16:08:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-05-31 16:08:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:08:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:08:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:08:32 --> Model Class Initialized
INFO - 2023-05-31 16:08:32 --> Model Class Initialized
INFO - 2023-05-31 16:08:32 --> Model Class Initialized
INFO - 2023-05-31 16:08:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:08:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:08:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:08:32 --> Final output sent to browser
DEBUG - 2023-05-31 16:08:32 --> Total execution time: 0.0635
ERROR - 2023-05-31 16:08:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:08:34 --> Config Class Initialized
INFO - 2023-05-31 16:08:34 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:08:34 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:08:34 --> Utf8 Class Initialized
INFO - 2023-05-31 16:08:34 --> URI Class Initialized
INFO - 2023-05-31 16:08:34 --> Router Class Initialized
INFO - 2023-05-31 16:08:34 --> Output Class Initialized
INFO - 2023-05-31 16:08:34 --> Security Class Initialized
DEBUG - 2023-05-31 16:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:08:34 --> Input Class Initialized
INFO - 2023-05-31 16:08:34 --> Language Class Initialized
INFO - 2023-05-31 16:08:34 --> Loader Class Initialized
INFO - 2023-05-31 16:08:34 --> Helper loaded: url_helper
INFO - 2023-05-31 16:08:34 --> Helper loaded: file_helper
INFO - 2023-05-31 16:08:34 --> Helper loaded: html_helper
INFO - 2023-05-31 16:08:34 --> Helper loaded: text_helper
INFO - 2023-05-31 16:08:34 --> Helper loaded: form_helper
INFO - 2023-05-31 16:08:34 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:08:34 --> Helper loaded: security_helper
INFO - 2023-05-31 16:08:34 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:08:34 --> Database Driver Class Initialized
INFO - 2023-05-31 16:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:08:34 --> Parser Class Initialized
INFO - 2023-05-31 16:08:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:08:34 --> Pagination Class Initialized
INFO - 2023-05-31 16:08:34 --> Form Validation Class Initialized
INFO - 2023-05-31 16:08:34 --> Controller Class Initialized
INFO - 2023-05-31 16:08:34 --> Model Class Initialized
DEBUG - 2023-05-31 16:08:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:08:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:08:34 --> Model Class Initialized
INFO - 2023-05-31 16:08:34 --> Final output sent to browser
DEBUG - 2023-05-31 16:08:34 --> Total execution time: 0.0279
ERROR - 2023-05-31 16:09:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:09:06 --> Config Class Initialized
INFO - 2023-05-31 16:09:06 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:09:06 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:09:06 --> Utf8 Class Initialized
INFO - 2023-05-31 16:09:06 --> URI Class Initialized
INFO - 2023-05-31 16:09:06 --> Router Class Initialized
INFO - 2023-05-31 16:09:06 --> Output Class Initialized
INFO - 2023-05-31 16:09:06 --> Security Class Initialized
DEBUG - 2023-05-31 16:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:09:06 --> Input Class Initialized
INFO - 2023-05-31 16:09:06 --> Language Class Initialized
INFO - 2023-05-31 16:09:06 --> Loader Class Initialized
INFO - 2023-05-31 16:09:06 --> Helper loaded: url_helper
INFO - 2023-05-31 16:09:06 --> Helper loaded: file_helper
INFO - 2023-05-31 16:09:06 --> Helper loaded: html_helper
INFO - 2023-05-31 16:09:06 --> Helper loaded: text_helper
INFO - 2023-05-31 16:09:06 --> Helper loaded: form_helper
INFO - 2023-05-31 16:09:06 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:09:06 --> Helper loaded: security_helper
INFO - 2023-05-31 16:09:06 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:09:06 --> Database Driver Class Initialized
INFO - 2023-05-31 16:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:09:06 --> Parser Class Initialized
INFO - 2023-05-31 16:09:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:09:06 --> Pagination Class Initialized
INFO - 2023-05-31 16:09:06 --> Form Validation Class Initialized
INFO - 2023-05-31 16:09:06 --> Controller Class Initialized
INFO - 2023-05-31 16:09:06 --> Model Class Initialized
DEBUG - 2023-05-31 16:09:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:09:06 --> Model Class Initialized
INFO - 2023-05-31 16:09:06 --> Final output sent to browser
DEBUG - 2023-05-31 16:09:06 --> Total execution time: 0.0265
ERROR - 2023-05-31 16:09:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:09:25 --> Config Class Initialized
INFO - 2023-05-31 16:09:25 --> Hooks Class Initialized
ERROR - 2023-05-31 16:09:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:09:25 --> Config Class Initialized
INFO - 2023-05-31 16:09:25 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:09:25 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:09:25 --> Utf8 Class Initialized
INFO - 2023-05-31 16:09:25 --> URI Class Initialized
DEBUG - 2023-05-31 16:09:25 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:09:25 --> Utf8 Class Initialized
INFO - 2023-05-31 16:09:25 --> Router Class Initialized
INFO - 2023-05-31 16:09:25 --> URI Class Initialized
INFO - 2023-05-31 16:09:25 --> Output Class Initialized
INFO - 2023-05-31 16:09:25 --> Router Class Initialized
INFO - 2023-05-31 16:09:25 --> Security Class Initialized
INFO - 2023-05-31 16:09:25 --> Output Class Initialized
DEBUG - 2023-05-31 16:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:09:25 --> Input Class Initialized
INFO - 2023-05-31 16:09:25 --> Security Class Initialized
INFO - 2023-05-31 16:09:25 --> Language Class Initialized
DEBUG - 2023-05-31 16:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:09:25 --> Input Class Initialized
INFO - 2023-05-31 16:09:25 --> Language Class Initialized
INFO - 2023-05-31 16:09:25 --> Loader Class Initialized
INFO - 2023-05-31 16:09:25 --> Helper loaded: url_helper
INFO - 2023-05-31 16:09:25 --> Loader Class Initialized
INFO - 2023-05-31 16:09:25 --> Helper loaded: file_helper
INFO - 2023-05-31 16:09:25 --> Helper loaded: html_helper
INFO - 2023-05-31 16:09:25 --> Helper loaded: url_helper
INFO - 2023-05-31 16:09:25 --> Helper loaded: text_helper
INFO - 2023-05-31 16:09:25 --> Helper loaded: file_helper
INFO - 2023-05-31 16:09:25 --> Helper loaded: html_helper
INFO - 2023-05-31 16:09:25 --> Helper loaded: form_helper
INFO - 2023-05-31 16:09:25 --> Helper loaded: text_helper
INFO - 2023-05-31 16:09:25 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:09:25 --> Helper loaded: security_helper
INFO - 2023-05-31 16:09:25 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:09:25 --> Helper loaded: form_helper
INFO - 2023-05-31 16:09:25 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:09:25 --> Helper loaded: security_helper
INFO - 2023-05-31 16:09:25 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:09:25 --> Database Driver Class Initialized
INFO - 2023-05-31 16:09:25 --> Database Driver Class Initialized
INFO - 2023-05-31 16:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:09:25 --> Parser Class Initialized
INFO - 2023-05-31 16:09:25 --> Parser Class Initialized
INFO - 2023-05-31 16:09:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:09:25 --> Pagination Class Initialized
INFO - 2023-05-31 16:09:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:09:25 --> Pagination Class Initialized
INFO - 2023-05-31 16:09:25 --> Form Validation Class Initialized
INFO - 2023-05-31 16:09:25 --> Form Validation Class Initialized
INFO - 2023-05-31 16:09:25 --> Controller Class Initialized
INFO - 2023-05-31 16:09:25 --> Controller Class Initialized
INFO - 2023-05-31 16:09:25 --> Model Class Initialized
DEBUG - 2023-05-31 16:09:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:09:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:09:25 --> Model Class Initialized
INFO - 2023-05-31 16:09:25 --> Model Class Initialized
DEBUG - 2023-05-31 16:09:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:09:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:09:25 --> Model Class Initialized
INFO - 2023-05-31 16:09:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-05-31 16:09:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:09:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:09:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-05-31 16:09:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:09:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:09:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:09:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:09:25 --> Model Class Initialized
INFO - 2023-05-31 16:09:25 --> Model Class Initialized
INFO - 2023-05-31 16:09:25 --> Model Class Initialized
INFO - 2023-05-31 16:09:25 --> Model Class Initialized
INFO - 2023-05-31 16:09:25 --> Model Class Initialized
INFO - 2023-05-31 16:09:25 --> Model Class Initialized
INFO - 2023-05-31 16:09:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:09:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:09:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:09:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:09:25 --> Final output sent to browser
DEBUG - 2023-05-31 16:09:25 --> Total execution time: 0.0729
INFO - 2023-05-31 16:09:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:09:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:09:25 --> Final output sent to browser
DEBUG - 2023-05-31 16:09:25 --> Total execution time: 0.0739
ERROR - 2023-05-31 16:09:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:09:26 --> Config Class Initialized
INFO - 2023-05-31 16:09:26 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:09:26 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:09:26 --> Utf8 Class Initialized
INFO - 2023-05-31 16:09:26 --> URI Class Initialized
INFO - 2023-05-31 16:09:26 --> Router Class Initialized
INFO - 2023-05-31 16:09:26 --> Output Class Initialized
INFO - 2023-05-31 16:09:26 --> Security Class Initialized
DEBUG - 2023-05-31 16:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:09:26 --> Input Class Initialized
INFO - 2023-05-31 16:09:26 --> Language Class Initialized
INFO - 2023-05-31 16:09:26 --> Loader Class Initialized
INFO - 2023-05-31 16:09:26 --> Helper loaded: url_helper
INFO - 2023-05-31 16:09:26 --> Helper loaded: file_helper
INFO - 2023-05-31 16:09:26 --> Helper loaded: html_helper
INFO - 2023-05-31 16:09:26 --> Helper loaded: text_helper
INFO - 2023-05-31 16:09:26 --> Helper loaded: form_helper
INFO - 2023-05-31 16:09:26 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:09:26 --> Helper loaded: security_helper
INFO - 2023-05-31 16:09:26 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:09:26 --> Database Driver Class Initialized
INFO - 2023-05-31 16:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:09:26 --> Parser Class Initialized
INFO - 2023-05-31 16:09:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:09:26 --> Pagination Class Initialized
INFO - 2023-05-31 16:09:26 --> Form Validation Class Initialized
INFO - 2023-05-31 16:09:26 --> Controller Class Initialized
INFO - 2023-05-31 16:09:26 --> Model Class Initialized
DEBUG - 2023-05-31 16:09:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:09:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:09:26 --> Model Class Initialized
DEBUG - 2023-05-31 16:09:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:09:26 --> Model Class Initialized
INFO - 2023-05-31 16:09:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-05-31 16:09:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:09:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:09:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:09:26 --> Model Class Initialized
INFO - 2023-05-31 16:09:26 --> Model Class Initialized
INFO - 2023-05-31 16:09:26 --> Model Class Initialized
INFO - 2023-05-31 16:09:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:09:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:09:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:09:26 --> Final output sent to browser
DEBUG - 2023-05-31 16:09:26 --> Total execution time: 0.0886
ERROR - 2023-05-31 16:09:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:09:31 --> Config Class Initialized
INFO - 2023-05-31 16:09:31 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:09:31 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:09:31 --> Utf8 Class Initialized
INFO - 2023-05-31 16:09:31 --> URI Class Initialized
INFO - 2023-05-31 16:09:31 --> Router Class Initialized
INFO - 2023-05-31 16:09:31 --> Output Class Initialized
INFO - 2023-05-31 16:09:31 --> Security Class Initialized
DEBUG - 2023-05-31 16:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:09:31 --> Input Class Initialized
INFO - 2023-05-31 16:09:31 --> Language Class Initialized
INFO - 2023-05-31 16:09:31 --> Loader Class Initialized
INFO - 2023-05-31 16:09:31 --> Helper loaded: url_helper
INFO - 2023-05-31 16:09:31 --> Helper loaded: file_helper
INFO - 2023-05-31 16:09:31 --> Helper loaded: html_helper
INFO - 2023-05-31 16:09:31 --> Helper loaded: text_helper
INFO - 2023-05-31 16:09:31 --> Helper loaded: form_helper
INFO - 2023-05-31 16:09:31 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:09:31 --> Helper loaded: security_helper
INFO - 2023-05-31 16:09:31 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:09:31 --> Database Driver Class Initialized
INFO - 2023-05-31 16:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:09:31 --> Parser Class Initialized
INFO - 2023-05-31 16:09:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:09:31 --> Pagination Class Initialized
INFO - 2023-05-31 16:09:31 --> Form Validation Class Initialized
INFO - 2023-05-31 16:09:31 --> Controller Class Initialized
INFO - 2023-05-31 16:09:31 --> Model Class Initialized
DEBUG - 2023-05-31 16:09:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:09:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:09:31 --> Model Class Initialized
INFO - 2023-05-31 16:09:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-05-31 16:09:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:09:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:09:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:09:31 --> Model Class Initialized
INFO - 2023-05-31 16:09:31 --> Model Class Initialized
INFO - 2023-05-31 16:09:31 --> Model Class Initialized
INFO - 2023-05-31 16:09:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:09:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:09:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:09:31 --> Final output sent to browser
DEBUG - 2023-05-31 16:09:31 --> Total execution time: 0.0621
ERROR - 2023-05-31 16:09:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:09:34 --> Config Class Initialized
INFO - 2023-05-31 16:09:34 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:09:34 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:09:34 --> Utf8 Class Initialized
INFO - 2023-05-31 16:09:34 --> URI Class Initialized
INFO - 2023-05-31 16:09:34 --> Router Class Initialized
INFO - 2023-05-31 16:09:34 --> Output Class Initialized
INFO - 2023-05-31 16:09:34 --> Security Class Initialized
DEBUG - 2023-05-31 16:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:09:34 --> Input Class Initialized
INFO - 2023-05-31 16:09:34 --> Language Class Initialized
INFO - 2023-05-31 16:09:34 --> Loader Class Initialized
INFO - 2023-05-31 16:09:34 --> Helper loaded: url_helper
INFO - 2023-05-31 16:09:34 --> Helper loaded: file_helper
INFO - 2023-05-31 16:09:34 --> Helper loaded: html_helper
INFO - 2023-05-31 16:09:34 --> Helper loaded: text_helper
INFO - 2023-05-31 16:09:34 --> Helper loaded: form_helper
INFO - 2023-05-31 16:09:34 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:09:34 --> Helper loaded: security_helper
INFO - 2023-05-31 16:09:34 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:09:34 --> Database Driver Class Initialized
INFO - 2023-05-31 16:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:09:34 --> Parser Class Initialized
INFO - 2023-05-31 16:09:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:09:34 --> Pagination Class Initialized
INFO - 2023-05-31 16:09:34 --> Form Validation Class Initialized
INFO - 2023-05-31 16:09:34 --> Controller Class Initialized
INFO - 2023-05-31 16:09:34 --> Model Class Initialized
DEBUG - 2023-05-31 16:09:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:09:34 --> Model Class Initialized
INFO - 2023-05-31 16:09:34 --> Final output sent to browser
DEBUG - 2023-05-31 16:09:34 --> Total execution time: 0.0301
ERROR - 2023-05-31 16:09:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:09:38 --> Config Class Initialized
INFO - 2023-05-31 16:09:38 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:09:38 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:09:38 --> Utf8 Class Initialized
INFO - 2023-05-31 16:09:38 --> URI Class Initialized
INFO - 2023-05-31 16:09:38 --> Router Class Initialized
INFO - 2023-05-31 16:09:38 --> Output Class Initialized
INFO - 2023-05-31 16:09:38 --> Security Class Initialized
DEBUG - 2023-05-31 16:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:09:38 --> Input Class Initialized
INFO - 2023-05-31 16:09:38 --> Language Class Initialized
INFO - 2023-05-31 16:09:38 --> Loader Class Initialized
INFO - 2023-05-31 16:09:38 --> Helper loaded: url_helper
INFO - 2023-05-31 16:09:38 --> Helper loaded: file_helper
INFO - 2023-05-31 16:09:38 --> Helper loaded: html_helper
INFO - 2023-05-31 16:09:38 --> Helper loaded: text_helper
INFO - 2023-05-31 16:09:38 --> Helper loaded: form_helper
INFO - 2023-05-31 16:09:38 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:09:38 --> Helper loaded: security_helper
INFO - 2023-05-31 16:09:38 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:09:38 --> Database Driver Class Initialized
INFO - 2023-05-31 16:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:09:38 --> Parser Class Initialized
INFO - 2023-05-31 16:09:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:09:38 --> Pagination Class Initialized
INFO - 2023-05-31 16:09:38 --> Form Validation Class Initialized
INFO - 2023-05-31 16:09:38 --> Controller Class Initialized
INFO - 2023-05-31 16:09:38 --> Model Class Initialized
DEBUG - 2023-05-31 16:09:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:09:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:09:38 --> Model Class Initialized
DEBUG - 2023-05-31 16:09:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:09:38 --> Model Class Initialized
INFO - 2023-05-31 16:09:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-05-31 16:09:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:09:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:09:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:09:38 --> Model Class Initialized
INFO - 2023-05-31 16:09:38 --> Model Class Initialized
INFO - 2023-05-31 16:09:38 --> Model Class Initialized
INFO - 2023-05-31 16:09:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:09:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:09:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:09:38 --> Final output sent to browser
DEBUG - 2023-05-31 16:09:38 --> Total execution time: 0.0661
ERROR - 2023-05-31 16:09:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:09:41 --> Config Class Initialized
INFO - 2023-05-31 16:09:41 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:09:41 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:09:41 --> Utf8 Class Initialized
INFO - 2023-05-31 16:09:41 --> URI Class Initialized
INFO - 2023-05-31 16:09:41 --> Router Class Initialized
INFO - 2023-05-31 16:09:41 --> Output Class Initialized
INFO - 2023-05-31 16:09:41 --> Security Class Initialized
DEBUG - 2023-05-31 16:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:09:41 --> Input Class Initialized
INFO - 2023-05-31 16:09:41 --> Language Class Initialized
INFO - 2023-05-31 16:09:41 --> Loader Class Initialized
INFO - 2023-05-31 16:09:41 --> Helper loaded: url_helper
INFO - 2023-05-31 16:09:41 --> Helper loaded: file_helper
INFO - 2023-05-31 16:09:41 --> Helper loaded: html_helper
INFO - 2023-05-31 16:09:41 --> Helper loaded: text_helper
INFO - 2023-05-31 16:09:41 --> Helper loaded: form_helper
INFO - 2023-05-31 16:09:41 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:09:41 --> Helper loaded: security_helper
INFO - 2023-05-31 16:09:41 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:09:41 --> Database Driver Class Initialized
INFO - 2023-05-31 16:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:09:41 --> Parser Class Initialized
INFO - 2023-05-31 16:09:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:09:41 --> Pagination Class Initialized
INFO - 2023-05-31 16:09:41 --> Form Validation Class Initialized
INFO - 2023-05-31 16:09:41 --> Controller Class Initialized
INFO - 2023-05-31 16:09:41 --> Model Class Initialized
DEBUG - 2023-05-31 16:09:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:09:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:09:41 --> Model Class Initialized
DEBUG - 2023-05-31 16:09:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:09:41 --> Model Class Initialized
INFO - 2023-05-31 16:09:41 --> Final output sent to browser
DEBUG - 2023-05-31 16:09:41 --> Total execution time: 0.0441
ERROR - 2023-05-31 16:10:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:10:03 --> Config Class Initialized
INFO - 2023-05-31 16:10:03 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:10:03 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:10:03 --> Utf8 Class Initialized
INFO - 2023-05-31 16:10:03 --> URI Class Initialized
INFO - 2023-05-31 16:10:03 --> Router Class Initialized
INFO - 2023-05-31 16:10:03 --> Output Class Initialized
INFO - 2023-05-31 16:10:03 --> Security Class Initialized
DEBUG - 2023-05-31 16:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:10:03 --> Input Class Initialized
INFO - 2023-05-31 16:10:03 --> Language Class Initialized
INFO - 2023-05-31 16:10:03 --> Loader Class Initialized
INFO - 2023-05-31 16:10:03 --> Helper loaded: url_helper
INFO - 2023-05-31 16:10:03 --> Helper loaded: file_helper
INFO - 2023-05-31 16:10:03 --> Helper loaded: html_helper
INFO - 2023-05-31 16:10:03 --> Helper loaded: text_helper
INFO - 2023-05-31 16:10:03 --> Helper loaded: form_helper
INFO - 2023-05-31 16:10:03 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:10:03 --> Helper loaded: security_helper
INFO - 2023-05-31 16:10:03 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:10:03 --> Database Driver Class Initialized
INFO - 2023-05-31 16:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:10:03 --> Parser Class Initialized
INFO - 2023-05-31 16:10:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:10:03 --> Pagination Class Initialized
INFO - 2023-05-31 16:10:03 --> Form Validation Class Initialized
INFO - 2023-05-31 16:10:03 --> Controller Class Initialized
INFO - 2023-05-31 16:10:03 --> Model Class Initialized
DEBUG - 2023-05-31 16:10:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:10:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:10:03 --> Model Class Initialized
DEBUG - 2023-05-31 16:10:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:10:03 --> Model Class Initialized
INFO - 2023-05-31 16:10:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html_pdf.php
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 210
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 211
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:03 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/block_frame_reflower.cls.php 726
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:04 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-05-31 16:10:04 --> Final output sent to browser
DEBUG - 2023-05-31 16:10:04 --> Total execution time: 0.2778
ERROR - 2023-05-31 16:10:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:10:17 --> Config Class Initialized
INFO - 2023-05-31 16:10:17 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:10:17 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:10:17 --> Utf8 Class Initialized
INFO - 2023-05-31 16:10:17 --> URI Class Initialized
INFO - 2023-05-31 16:10:17 --> Router Class Initialized
INFO - 2023-05-31 16:10:17 --> Output Class Initialized
INFO - 2023-05-31 16:10:17 --> Security Class Initialized
DEBUG - 2023-05-31 16:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:10:17 --> Input Class Initialized
INFO - 2023-05-31 16:10:17 --> Language Class Initialized
INFO - 2023-05-31 16:10:17 --> Loader Class Initialized
INFO - 2023-05-31 16:10:17 --> Helper loaded: url_helper
INFO - 2023-05-31 16:10:17 --> Helper loaded: file_helper
INFO - 2023-05-31 16:10:17 --> Helper loaded: html_helper
INFO - 2023-05-31 16:10:17 --> Helper loaded: text_helper
INFO - 2023-05-31 16:10:17 --> Helper loaded: form_helper
INFO - 2023-05-31 16:10:17 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:10:17 --> Helper loaded: security_helper
INFO - 2023-05-31 16:10:17 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:10:17 --> Database Driver Class Initialized
INFO - 2023-05-31 16:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:10:17 --> Parser Class Initialized
INFO - 2023-05-31 16:10:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:10:17 --> Pagination Class Initialized
INFO - 2023-05-31 16:10:17 --> Form Validation Class Initialized
INFO - 2023-05-31 16:10:17 --> Controller Class Initialized
INFO - 2023-05-31 16:10:17 --> Model Class Initialized
DEBUG - 2023-05-31 16:10:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:10:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:10:17 --> Model Class Initialized
DEBUG - 2023-05-31 16:10:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:10:17 --> Model Class Initialized
INFO - 2023-05-31 16:10:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html_pdf.php
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 210
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 211
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/block_frame_reflower.cls.php 726
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:10:17 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-05-31 16:10:17 --> Final output sent to browser
DEBUG - 2023-05-31 16:10:17 --> Total execution time: 0.2709
ERROR - 2023-05-31 16:10:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:10:36 --> Config Class Initialized
INFO - 2023-05-31 16:10:36 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:10:36 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:10:36 --> Utf8 Class Initialized
INFO - 2023-05-31 16:10:36 --> URI Class Initialized
INFO - 2023-05-31 16:10:36 --> Router Class Initialized
INFO - 2023-05-31 16:10:36 --> Output Class Initialized
INFO - 2023-05-31 16:10:36 --> Security Class Initialized
DEBUG - 2023-05-31 16:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:10:36 --> Input Class Initialized
INFO - 2023-05-31 16:10:36 --> Language Class Initialized
INFO - 2023-05-31 16:10:36 --> Loader Class Initialized
INFO - 2023-05-31 16:10:36 --> Helper loaded: url_helper
INFO - 2023-05-31 16:10:36 --> Helper loaded: file_helper
INFO - 2023-05-31 16:10:36 --> Helper loaded: html_helper
INFO - 2023-05-31 16:10:36 --> Helper loaded: text_helper
INFO - 2023-05-31 16:10:36 --> Helper loaded: form_helper
INFO - 2023-05-31 16:10:36 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:10:36 --> Helper loaded: security_helper
INFO - 2023-05-31 16:10:36 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:10:36 --> Database Driver Class Initialized
INFO - 2023-05-31 16:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:10:36 --> Parser Class Initialized
INFO - 2023-05-31 16:10:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:10:36 --> Pagination Class Initialized
INFO - 2023-05-31 16:10:36 --> Form Validation Class Initialized
INFO - 2023-05-31 16:10:36 --> Controller Class Initialized
INFO - 2023-05-31 16:10:36 --> Model Class Initialized
DEBUG - 2023-05-31 16:10:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:10:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:10:36 --> Model Class Initialized
DEBUG - 2023-05-31 16:10:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:10:36 --> Model Class Initialized
INFO - 2023-05-31 16:10:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2023-05-31 16:10:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:10:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:10:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:10:36 --> Model Class Initialized
INFO - 2023-05-31 16:10:36 --> Model Class Initialized
INFO - 2023-05-31 16:10:36 --> Model Class Initialized
INFO - 2023-05-31 16:10:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:10:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:10:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:10:36 --> Final output sent to browser
DEBUG - 2023-05-31 16:10:36 --> Total execution time: 0.0838
ERROR - 2023-05-31 16:11:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:11:15 --> Config Class Initialized
INFO - 2023-05-31 16:11:15 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:11:15 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:11:15 --> Utf8 Class Initialized
INFO - 2023-05-31 16:11:15 --> URI Class Initialized
INFO - 2023-05-31 16:11:15 --> Router Class Initialized
INFO - 2023-05-31 16:11:15 --> Output Class Initialized
INFO - 2023-05-31 16:11:15 --> Security Class Initialized
DEBUG - 2023-05-31 16:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:11:15 --> Input Class Initialized
INFO - 2023-05-31 16:11:15 --> Language Class Initialized
INFO - 2023-05-31 16:11:15 --> Loader Class Initialized
INFO - 2023-05-31 16:11:15 --> Helper loaded: url_helper
INFO - 2023-05-31 16:11:15 --> Helper loaded: file_helper
INFO - 2023-05-31 16:11:15 --> Helper loaded: html_helper
INFO - 2023-05-31 16:11:15 --> Helper loaded: text_helper
INFO - 2023-05-31 16:11:15 --> Helper loaded: form_helper
INFO - 2023-05-31 16:11:15 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:11:15 --> Helper loaded: security_helper
INFO - 2023-05-31 16:11:15 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:11:15 --> Database Driver Class Initialized
INFO - 2023-05-31 16:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:11:15 --> Parser Class Initialized
INFO - 2023-05-31 16:11:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:11:15 --> Pagination Class Initialized
INFO - 2023-05-31 16:11:15 --> Form Validation Class Initialized
INFO - 2023-05-31 16:11:15 --> Controller Class Initialized
INFO - 2023-05-31 16:11:15 --> Model Class Initialized
DEBUG - 2023-05-31 16:11:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:11:15 --> Model Class Initialized
DEBUG - 2023-05-31 16:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:11:15 --> Model Class Initialized
INFO - 2023-05-31 16:11:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-05-31 16:11:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:11:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:11:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:11:15 --> Model Class Initialized
INFO - 2023-05-31 16:11:15 --> Model Class Initialized
INFO - 2023-05-31 16:11:15 --> Model Class Initialized
INFO - 2023-05-31 16:11:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:11:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:11:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:11:15 --> Final output sent to browser
DEBUG - 2023-05-31 16:11:15 --> Total execution time: 0.2031
ERROR - 2023-05-31 16:11:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:11:18 --> Config Class Initialized
INFO - 2023-05-31 16:11:18 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:11:18 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:11:18 --> Utf8 Class Initialized
INFO - 2023-05-31 16:11:18 --> URI Class Initialized
INFO - 2023-05-31 16:11:18 --> Router Class Initialized
INFO - 2023-05-31 16:11:18 --> Output Class Initialized
INFO - 2023-05-31 16:11:18 --> Security Class Initialized
DEBUG - 2023-05-31 16:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:11:18 --> Input Class Initialized
INFO - 2023-05-31 16:11:18 --> Language Class Initialized
INFO - 2023-05-31 16:11:18 --> Loader Class Initialized
INFO - 2023-05-31 16:11:18 --> Helper loaded: url_helper
INFO - 2023-05-31 16:11:18 --> Helper loaded: file_helper
INFO - 2023-05-31 16:11:18 --> Helper loaded: html_helper
INFO - 2023-05-31 16:11:18 --> Helper loaded: text_helper
INFO - 2023-05-31 16:11:18 --> Helper loaded: form_helper
INFO - 2023-05-31 16:11:18 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:11:18 --> Helper loaded: security_helper
INFO - 2023-05-31 16:11:18 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:11:18 --> Database Driver Class Initialized
INFO - 2023-05-31 16:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:11:18 --> Parser Class Initialized
INFO - 2023-05-31 16:11:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:11:18 --> Pagination Class Initialized
INFO - 2023-05-31 16:11:18 --> Form Validation Class Initialized
INFO - 2023-05-31 16:11:18 --> Controller Class Initialized
INFO - 2023-05-31 16:11:18 --> Model Class Initialized
DEBUG - 2023-05-31 16:11:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:11:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:11:18 --> Model Class Initialized
DEBUG - 2023-05-31 16:11:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:11:18 --> Model Class Initialized
INFO - 2023-05-31 16:11:18 --> Final output sent to browser
DEBUG - 2023-05-31 16:11:18 --> Total execution time: 0.0454
ERROR - 2023-05-31 16:11:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:11:20 --> Config Class Initialized
INFO - 2023-05-31 16:11:20 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:11:20 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:11:20 --> Utf8 Class Initialized
INFO - 2023-05-31 16:11:20 --> URI Class Initialized
INFO - 2023-05-31 16:11:20 --> Router Class Initialized
INFO - 2023-05-31 16:11:20 --> Output Class Initialized
INFO - 2023-05-31 16:11:20 --> Security Class Initialized
DEBUG - 2023-05-31 16:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:11:20 --> Input Class Initialized
INFO - 2023-05-31 16:11:20 --> Language Class Initialized
INFO - 2023-05-31 16:11:20 --> Loader Class Initialized
INFO - 2023-05-31 16:11:20 --> Helper loaded: url_helper
INFO - 2023-05-31 16:11:20 --> Helper loaded: file_helper
INFO - 2023-05-31 16:11:20 --> Helper loaded: html_helper
INFO - 2023-05-31 16:11:20 --> Helper loaded: text_helper
INFO - 2023-05-31 16:11:20 --> Helper loaded: form_helper
INFO - 2023-05-31 16:11:20 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:11:20 --> Helper loaded: security_helper
INFO - 2023-05-31 16:11:20 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:11:20 --> Database Driver Class Initialized
INFO - 2023-05-31 16:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:11:20 --> Parser Class Initialized
INFO - 2023-05-31 16:11:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:11:20 --> Pagination Class Initialized
INFO - 2023-05-31 16:11:20 --> Form Validation Class Initialized
INFO - 2023-05-31 16:11:20 --> Controller Class Initialized
INFO - 2023-05-31 16:11:20 --> Model Class Initialized
DEBUG - 2023-05-31 16:11:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:11:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:11:20 --> Model Class Initialized
INFO - 2023-05-31 16:11:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-05-31 16:11:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:11:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:11:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:11:20 --> Model Class Initialized
INFO - 2023-05-31 16:11:20 --> Model Class Initialized
INFO - 2023-05-31 16:11:20 --> Model Class Initialized
INFO - 2023-05-31 16:11:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:11:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:11:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:11:20 --> Final output sent to browser
DEBUG - 2023-05-31 16:11:20 --> Total execution time: 0.0678
ERROR - 2023-05-31 16:11:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:11:23 --> Config Class Initialized
INFO - 2023-05-31 16:11:23 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:11:23 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:11:23 --> Utf8 Class Initialized
INFO - 2023-05-31 16:11:23 --> URI Class Initialized
INFO - 2023-05-31 16:11:23 --> Router Class Initialized
INFO - 2023-05-31 16:11:23 --> Output Class Initialized
INFO - 2023-05-31 16:11:23 --> Security Class Initialized
DEBUG - 2023-05-31 16:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:11:23 --> Input Class Initialized
INFO - 2023-05-31 16:11:23 --> Language Class Initialized
INFO - 2023-05-31 16:11:23 --> Loader Class Initialized
INFO - 2023-05-31 16:11:23 --> Helper loaded: url_helper
INFO - 2023-05-31 16:11:23 --> Helper loaded: file_helper
INFO - 2023-05-31 16:11:23 --> Helper loaded: html_helper
INFO - 2023-05-31 16:11:23 --> Helper loaded: text_helper
INFO - 2023-05-31 16:11:23 --> Helper loaded: form_helper
INFO - 2023-05-31 16:11:23 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:11:23 --> Helper loaded: security_helper
INFO - 2023-05-31 16:11:23 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:11:23 --> Database Driver Class Initialized
INFO - 2023-05-31 16:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:11:23 --> Parser Class Initialized
INFO - 2023-05-31 16:11:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:11:23 --> Pagination Class Initialized
INFO - 2023-05-31 16:11:23 --> Form Validation Class Initialized
INFO - 2023-05-31 16:11:23 --> Controller Class Initialized
INFO - 2023-05-31 16:11:23 --> Model Class Initialized
DEBUG - 2023-05-31 16:11:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:11:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:11:23 --> Model Class Initialized
INFO - 2023-05-31 16:11:23 --> Final output sent to browser
DEBUG - 2023-05-31 16:11:23 --> Total execution time: 0.0320
ERROR - 2023-05-31 16:11:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:11:26 --> Config Class Initialized
INFO - 2023-05-31 16:11:26 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:11:26 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:11:26 --> Utf8 Class Initialized
INFO - 2023-05-31 16:11:26 --> URI Class Initialized
INFO - 2023-05-31 16:11:26 --> Router Class Initialized
INFO - 2023-05-31 16:11:26 --> Output Class Initialized
INFO - 2023-05-31 16:11:26 --> Security Class Initialized
DEBUG - 2023-05-31 16:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:11:26 --> Input Class Initialized
INFO - 2023-05-31 16:11:26 --> Language Class Initialized
INFO - 2023-05-31 16:11:26 --> Loader Class Initialized
INFO - 2023-05-31 16:11:26 --> Helper loaded: url_helper
INFO - 2023-05-31 16:11:26 --> Helper loaded: file_helper
INFO - 2023-05-31 16:11:26 --> Helper loaded: html_helper
INFO - 2023-05-31 16:11:26 --> Helper loaded: text_helper
INFO - 2023-05-31 16:11:26 --> Helper loaded: form_helper
INFO - 2023-05-31 16:11:26 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:11:26 --> Helper loaded: security_helper
INFO - 2023-05-31 16:11:26 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:11:26 --> Database Driver Class Initialized
INFO - 2023-05-31 16:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:11:26 --> Parser Class Initialized
INFO - 2023-05-31 16:11:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:11:26 --> Pagination Class Initialized
INFO - 2023-05-31 16:11:26 --> Form Validation Class Initialized
INFO - 2023-05-31 16:11:26 --> Controller Class Initialized
INFO - 2023-05-31 16:11:26 --> Model Class Initialized
DEBUG - 2023-05-31 16:11:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:11:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:11:26 --> Model Class Initialized
DEBUG - 2023-05-31 16:11:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:11:26 --> Model Class Initialized
INFO - 2023-05-31 16:11:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-31 16:11:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:11:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:11:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:11:26 --> Model Class Initialized
INFO - 2023-05-31 16:11:26 --> Model Class Initialized
INFO - 2023-05-31 16:11:26 --> Model Class Initialized
INFO - 2023-05-31 16:11:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:11:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:11:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:11:26 --> Final output sent to browser
DEBUG - 2023-05-31 16:11:26 --> Total execution time: 0.0731
ERROR - 2023-05-31 16:11:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:11:28 --> Config Class Initialized
INFO - 2023-05-31 16:11:28 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:11:28 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:11:28 --> Utf8 Class Initialized
INFO - 2023-05-31 16:11:28 --> URI Class Initialized
DEBUG - 2023-05-31 16:11:28 --> No URI present. Default controller set.
INFO - 2023-05-31 16:11:28 --> Router Class Initialized
INFO - 2023-05-31 16:11:28 --> Output Class Initialized
INFO - 2023-05-31 16:11:28 --> Security Class Initialized
DEBUG - 2023-05-31 16:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:11:28 --> Input Class Initialized
INFO - 2023-05-31 16:11:28 --> Language Class Initialized
INFO - 2023-05-31 16:11:28 --> Loader Class Initialized
INFO - 2023-05-31 16:11:28 --> Helper loaded: url_helper
INFO - 2023-05-31 16:11:28 --> Helper loaded: file_helper
INFO - 2023-05-31 16:11:28 --> Helper loaded: html_helper
INFO - 2023-05-31 16:11:28 --> Helper loaded: text_helper
INFO - 2023-05-31 16:11:28 --> Helper loaded: form_helper
INFO - 2023-05-31 16:11:28 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:11:28 --> Helper loaded: security_helper
INFO - 2023-05-31 16:11:28 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:11:28 --> Database Driver Class Initialized
INFO - 2023-05-31 16:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:11:28 --> Parser Class Initialized
INFO - 2023-05-31 16:11:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:11:28 --> Pagination Class Initialized
INFO - 2023-05-31 16:11:28 --> Form Validation Class Initialized
INFO - 2023-05-31 16:11:28 --> Controller Class Initialized
INFO - 2023-05-31 16:11:28 --> Model Class Initialized
DEBUG - 2023-05-31 16:11:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:11:28 --> Model Class Initialized
DEBUG - 2023-05-31 16:11:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:11:28 --> Model Class Initialized
INFO - 2023-05-31 16:11:28 --> Model Class Initialized
INFO - 2023-05-31 16:11:28 --> Model Class Initialized
INFO - 2023-05-31 16:11:28 --> Model Class Initialized
DEBUG - 2023-05-31 16:11:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:11:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:11:28 --> Model Class Initialized
INFO - 2023-05-31 16:11:28 --> Model Class Initialized
INFO - 2023-05-31 16:11:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-31 16:11:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:11:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:11:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:11:28 --> Model Class Initialized
INFO - 2023-05-31 16:11:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:11:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:11:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:11:28 --> Final output sent to browser
DEBUG - 2023-05-31 16:11:28 --> Total execution time: 0.0809
ERROR - 2023-05-31 16:11:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:11:31 --> Config Class Initialized
INFO - 2023-05-31 16:11:31 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:11:31 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:11:31 --> Utf8 Class Initialized
INFO - 2023-05-31 16:11:31 --> URI Class Initialized
INFO - 2023-05-31 16:11:31 --> Router Class Initialized
INFO - 2023-05-31 16:11:31 --> Output Class Initialized
INFO - 2023-05-31 16:11:31 --> Security Class Initialized
DEBUG - 2023-05-31 16:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:11:31 --> Input Class Initialized
INFO - 2023-05-31 16:11:31 --> Language Class Initialized
INFO - 2023-05-31 16:11:31 --> Loader Class Initialized
INFO - 2023-05-31 16:11:31 --> Helper loaded: url_helper
INFO - 2023-05-31 16:11:31 --> Helper loaded: file_helper
INFO - 2023-05-31 16:11:31 --> Helper loaded: html_helper
INFO - 2023-05-31 16:11:31 --> Helper loaded: text_helper
INFO - 2023-05-31 16:11:31 --> Helper loaded: form_helper
INFO - 2023-05-31 16:11:31 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:11:31 --> Helper loaded: security_helper
INFO - 2023-05-31 16:11:31 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:11:31 --> Database Driver Class Initialized
INFO - 2023-05-31 16:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:11:31 --> Parser Class Initialized
INFO - 2023-05-31 16:11:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:11:31 --> Pagination Class Initialized
INFO - 2023-05-31 16:11:31 --> Form Validation Class Initialized
INFO - 2023-05-31 16:11:31 --> Controller Class Initialized
INFO - 2023-05-31 16:11:31 --> Model Class Initialized
DEBUG - 2023-05-31 16:11:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:11:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:11:31 --> Model Class Initialized
DEBUG - 2023-05-31 16:11:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:11:31 --> Model Class Initialized
INFO - 2023-05-31 16:11:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-31 16:11:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:11:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:11:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:11:31 --> Model Class Initialized
INFO - 2023-05-31 16:11:31 --> Model Class Initialized
INFO - 2023-05-31 16:11:31 --> Model Class Initialized
INFO - 2023-05-31 16:11:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:11:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:11:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:11:31 --> Final output sent to browser
DEBUG - 2023-05-31 16:11:31 --> Total execution time: 0.0673
ERROR - 2023-05-31 16:11:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:11:33 --> Config Class Initialized
INFO - 2023-05-31 16:11:33 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:11:33 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:11:33 --> Utf8 Class Initialized
INFO - 2023-05-31 16:11:33 --> URI Class Initialized
INFO - 2023-05-31 16:11:33 --> Router Class Initialized
INFO - 2023-05-31 16:11:33 --> Output Class Initialized
INFO - 2023-05-31 16:11:33 --> Security Class Initialized
DEBUG - 2023-05-31 16:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:11:33 --> Input Class Initialized
INFO - 2023-05-31 16:11:33 --> Language Class Initialized
INFO - 2023-05-31 16:11:33 --> Loader Class Initialized
INFO - 2023-05-31 16:11:33 --> Helper loaded: url_helper
INFO - 2023-05-31 16:11:33 --> Helper loaded: file_helper
INFO - 2023-05-31 16:11:33 --> Helper loaded: html_helper
INFO - 2023-05-31 16:11:33 --> Helper loaded: text_helper
INFO - 2023-05-31 16:11:33 --> Helper loaded: form_helper
INFO - 2023-05-31 16:11:33 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:11:33 --> Helper loaded: security_helper
INFO - 2023-05-31 16:11:33 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:11:33 --> Database Driver Class Initialized
INFO - 2023-05-31 16:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:11:33 --> Parser Class Initialized
INFO - 2023-05-31 16:11:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:11:33 --> Pagination Class Initialized
INFO - 2023-05-31 16:11:33 --> Form Validation Class Initialized
INFO - 2023-05-31 16:11:33 --> Controller Class Initialized
INFO - 2023-05-31 16:11:33 --> Model Class Initialized
DEBUG - 2023-05-31 16:11:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:11:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:11:33 --> Model Class Initialized
DEBUG - 2023-05-31 16:11:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:11:33 --> Model Class Initialized
INFO - 2023-05-31 16:11:33 --> Final output sent to browser
DEBUG - 2023-05-31 16:11:33 --> Total execution time: 0.0449
ERROR - 2023-05-31 16:11:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:11:42 --> Config Class Initialized
INFO - 2023-05-31 16:11:42 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:11:42 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:11:42 --> Utf8 Class Initialized
INFO - 2023-05-31 16:11:42 --> URI Class Initialized
DEBUG - 2023-05-31 16:11:42 --> No URI present. Default controller set.
INFO - 2023-05-31 16:11:42 --> Router Class Initialized
INFO - 2023-05-31 16:11:42 --> Output Class Initialized
INFO - 2023-05-31 16:11:42 --> Security Class Initialized
DEBUG - 2023-05-31 16:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:11:42 --> Input Class Initialized
INFO - 2023-05-31 16:11:42 --> Language Class Initialized
INFO - 2023-05-31 16:11:42 --> Loader Class Initialized
INFO - 2023-05-31 16:11:42 --> Helper loaded: url_helper
INFO - 2023-05-31 16:11:42 --> Helper loaded: file_helper
INFO - 2023-05-31 16:11:42 --> Helper loaded: html_helper
INFO - 2023-05-31 16:11:42 --> Helper loaded: text_helper
INFO - 2023-05-31 16:11:42 --> Helper loaded: form_helper
INFO - 2023-05-31 16:11:42 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:11:42 --> Helper loaded: security_helper
INFO - 2023-05-31 16:11:42 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:11:42 --> Database Driver Class Initialized
INFO - 2023-05-31 16:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:11:42 --> Parser Class Initialized
INFO - 2023-05-31 16:11:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:11:42 --> Pagination Class Initialized
INFO - 2023-05-31 16:11:42 --> Form Validation Class Initialized
INFO - 2023-05-31 16:11:42 --> Controller Class Initialized
INFO - 2023-05-31 16:11:42 --> Model Class Initialized
DEBUG - 2023-05-31 16:11:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:11:42 --> Model Class Initialized
DEBUG - 2023-05-31 16:11:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:11:42 --> Model Class Initialized
INFO - 2023-05-31 16:11:42 --> Model Class Initialized
INFO - 2023-05-31 16:11:42 --> Model Class Initialized
INFO - 2023-05-31 16:11:42 --> Model Class Initialized
DEBUG - 2023-05-31 16:11:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:11:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:11:42 --> Model Class Initialized
INFO - 2023-05-31 16:11:42 --> Model Class Initialized
INFO - 2023-05-31 16:11:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-31 16:11:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:11:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:11:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:11:42 --> Model Class Initialized
INFO - 2023-05-31 16:11:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:11:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:11:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:11:42 --> Final output sent to browser
DEBUG - 2023-05-31 16:11:42 --> Total execution time: 0.0755
ERROR - 2023-05-31 16:12:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:12:00 --> Config Class Initialized
INFO - 2023-05-31 16:12:00 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:12:00 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:12:00 --> Utf8 Class Initialized
INFO - 2023-05-31 16:12:00 --> URI Class Initialized
INFO - 2023-05-31 16:12:00 --> Router Class Initialized
INFO - 2023-05-31 16:12:00 --> Output Class Initialized
INFO - 2023-05-31 16:12:00 --> Security Class Initialized
DEBUG - 2023-05-31 16:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:12:00 --> Input Class Initialized
INFO - 2023-05-31 16:12:00 --> Language Class Initialized
INFO - 2023-05-31 16:12:00 --> Loader Class Initialized
INFO - 2023-05-31 16:12:00 --> Helper loaded: url_helper
INFO - 2023-05-31 16:12:00 --> Helper loaded: file_helper
INFO - 2023-05-31 16:12:00 --> Helper loaded: html_helper
INFO - 2023-05-31 16:12:00 --> Helper loaded: text_helper
INFO - 2023-05-31 16:12:00 --> Helper loaded: form_helper
INFO - 2023-05-31 16:12:00 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:12:00 --> Helper loaded: security_helper
INFO - 2023-05-31 16:12:00 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:12:00 --> Database Driver Class Initialized
INFO - 2023-05-31 16:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:12:00 --> Parser Class Initialized
INFO - 2023-05-31 16:12:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:12:00 --> Pagination Class Initialized
INFO - 2023-05-31 16:12:00 --> Form Validation Class Initialized
INFO - 2023-05-31 16:12:00 --> Controller Class Initialized
INFO - 2023-05-31 16:12:00 --> Model Class Initialized
INFO - 2023-05-31 16:12:00 --> Model Class Initialized
INFO - 2023-05-31 16:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-05-31 16:12:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:12:00 --> Model Class Initialized
INFO - 2023-05-31 16:12:00 --> Model Class Initialized
INFO - 2023-05-31 16:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:12:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:12:00 --> Final output sent to browser
DEBUG - 2023-05-31 16:12:00 --> Total execution time: 0.0663
ERROR - 2023-05-31 16:12:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:12:19 --> Config Class Initialized
INFO - 2023-05-31 16:12:19 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:12:19 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:12:19 --> Utf8 Class Initialized
INFO - 2023-05-31 16:12:19 --> URI Class Initialized
INFO - 2023-05-31 16:12:19 --> Router Class Initialized
INFO - 2023-05-31 16:12:19 --> Output Class Initialized
INFO - 2023-05-31 16:12:19 --> Security Class Initialized
DEBUG - 2023-05-31 16:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:12:19 --> Input Class Initialized
INFO - 2023-05-31 16:12:19 --> Language Class Initialized
INFO - 2023-05-31 16:12:19 --> Loader Class Initialized
INFO - 2023-05-31 16:12:19 --> Helper loaded: url_helper
INFO - 2023-05-31 16:12:19 --> Helper loaded: file_helper
INFO - 2023-05-31 16:12:19 --> Helper loaded: html_helper
INFO - 2023-05-31 16:12:19 --> Helper loaded: text_helper
INFO - 2023-05-31 16:12:19 --> Helper loaded: form_helper
INFO - 2023-05-31 16:12:19 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:12:19 --> Helper loaded: security_helper
INFO - 2023-05-31 16:12:19 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:12:19 --> Database Driver Class Initialized
INFO - 2023-05-31 16:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:12:19 --> Parser Class Initialized
INFO - 2023-05-31 16:12:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:12:19 --> Pagination Class Initialized
INFO - 2023-05-31 16:12:19 --> Form Validation Class Initialized
INFO - 2023-05-31 16:12:19 --> Controller Class Initialized
INFO - 2023-05-31 16:12:19 --> Model Class Initialized
INFO - 2023-05-31 16:12:19 --> Model Class Initialized
INFO - 2023-05-31 16:12:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-05-31 16:12:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:12:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:12:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:12:19 --> Model Class Initialized
INFO - 2023-05-31 16:12:19 --> Model Class Initialized
INFO - 2023-05-31 16:12:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:12:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:12:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:12:19 --> Final output sent to browser
DEBUG - 2023-05-31 16:12:19 --> Total execution time: 0.0644
ERROR - 2023-05-31 16:12:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:12:26 --> Config Class Initialized
INFO - 2023-05-31 16:12:26 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:12:26 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:12:26 --> Utf8 Class Initialized
INFO - 2023-05-31 16:12:26 --> URI Class Initialized
INFO - 2023-05-31 16:12:26 --> Router Class Initialized
INFO - 2023-05-31 16:12:26 --> Output Class Initialized
INFO - 2023-05-31 16:12:26 --> Security Class Initialized
ERROR - 2023-05-31 16:12:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
DEBUG - 2023-05-31 16:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:12:26 --> Input Class Initialized
INFO - 2023-05-31 16:12:26 --> Language Class Initialized
INFO - 2023-05-31 16:12:26 --> Config Class Initialized
INFO - 2023-05-31 16:12:26 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:12:26 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:12:26 --> Utf8 Class Initialized
INFO - 2023-05-31 16:12:26 --> URI Class Initialized
INFO - 2023-05-31 16:12:26 --> Loader Class Initialized
INFO - 2023-05-31 16:12:26 --> Router Class Initialized
INFO - 2023-05-31 16:12:26 --> Helper loaded: url_helper
INFO - 2023-05-31 16:12:26 --> Helper loaded: file_helper
INFO - 2023-05-31 16:12:26 --> Helper loaded: html_helper
INFO - 2023-05-31 16:12:26 --> Output Class Initialized
INFO - 2023-05-31 16:12:26 --> Helper loaded: text_helper
INFO - 2023-05-31 16:12:26 --> Security Class Initialized
INFO - 2023-05-31 16:12:26 --> Helper loaded: form_helper
INFO - 2023-05-31 16:12:26 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:12:26 --> Helper loaded: security_helper
DEBUG - 2023-05-31 16:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:12:26 --> Input Class Initialized
INFO - 2023-05-31 16:12:26 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:12:26 --> Language Class Initialized
INFO - 2023-05-31 16:12:26 --> Loader Class Initialized
INFO - 2023-05-31 16:12:26 --> Helper loaded: url_helper
INFO - 2023-05-31 16:12:26 --> Helper loaded: file_helper
INFO - 2023-05-31 16:12:26 --> Database Driver Class Initialized
INFO - 2023-05-31 16:12:26 --> Helper loaded: html_helper
INFO - 2023-05-31 16:12:26 --> Helper loaded: text_helper
INFO - 2023-05-31 16:12:26 --> Helper loaded: form_helper
INFO - 2023-05-31 16:12:26 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:12:26 --> Helper loaded: security_helper
INFO - 2023-05-31 16:12:26 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:12:26 --> Parser Class Initialized
INFO - 2023-05-31 16:12:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:12:26 --> Pagination Class Initialized
INFO - 2023-05-31 16:12:26 --> Form Validation Class Initialized
INFO - 2023-05-31 16:12:26 --> Controller Class Initialized
INFO - 2023-05-31 16:12:26 --> Database Driver Class Initialized
INFO - 2023-05-31 16:12:26 --> Model Class Initialized
DEBUG - 2023-05-31 16:12:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:12:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:12:26 --> Model Class Initialized
DEBUG - 2023-05-31 16:12:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:12:26 --> Model Class Initialized
INFO - 2023-05-31 16:12:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-05-31 16:12:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:12:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:12:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:12:26 --> Model Class Initialized
INFO - 2023-05-31 16:12:26 --> Model Class Initialized
INFO - 2023-05-31 16:12:26 --> Model Class Initialized
INFO - 2023-05-31 16:12:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:12:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:12:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:12:26 --> Final output sent to browser
DEBUG - 2023-05-31 16:12:26 --> Total execution time: 0.0757
INFO - 2023-05-31 16:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:12:26 --> Parser Class Initialized
INFO - 2023-05-31 16:12:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:12:26 --> Pagination Class Initialized
INFO - 2023-05-31 16:12:26 --> Form Validation Class Initialized
INFO - 2023-05-31 16:12:26 --> Controller Class Initialized
INFO - 2023-05-31 16:12:26 --> Model Class Initialized
DEBUG - 2023-05-31 16:12:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:12:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:12:26 --> Model Class Initialized
DEBUG - 2023-05-31 16:12:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:12:26 --> Model Class Initialized
INFO - 2023-05-31 16:12:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-05-31 16:12:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:12:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:12:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:12:26 --> Model Class Initialized
INFO - 2023-05-31 16:12:26 --> Model Class Initialized
INFO - 2023-05-31 16:12:26 --> Model Class Initialized
INFO - 2023-05-31 16:12:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:12:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:12:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:12:26 --> Final output sent to browser
DEBUG - 2023-05-31 16:12:26 --> Total execution time: 0.1392
ERROR - 2023-05-31 16:12:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:12:27 --> Config Class Initialized
INFO - 2023-05-31 16:12:27 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:12:27 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:12:27 --> Utf8 Class Initialized
INFO - 2023-05-31 16:12:27 --> URI Class Initialized
INFO - 2023-05-31 16:12:27 --> Router Class Initialized
INFO - 2023-05-31 16:12:27 --> Output Class Initialized
INFO - 2023-05-31 16:12:27 --> Security Class Initialized
DEBUG - 2023-05-31 16:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:12:27 --> Input Class Initialized
INFO - 2023-05-31 16:12:27 --> Language Class Initialized
INFO - 2023-05-31 16:12:27 --> Loader Class Initialized
INFO - 2023-05-31 16:12:27 --> Helper loaded: url_helper
INFO - 2023-05-31 16:12:27 --> Helper loaded: file_helper
INFO - 2023-05-31 16:12:27 --> Helper loaded: html_helper
INFO - 2023-05-31 16:12:27 --> Helper loaded: text_helper
INFO - 2023-05-31 16:12:28 --> Helper loaded: form_helper
INFO - 2023-05-31 16:12:28 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:12:28 --> Helper loaded: security_helper
INFO - 2023-05-31 16:12:28 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:12:28 --> Database Driver Class Initialized
INFO - 2023-05-31 16:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:12:28 --> Parser Class Initialized
INFO - 2023-05-31 16:12:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:12:28 --> Pagination Class Initialized
INFO - 2023-05-31 16:12:28 --> Form Validation Class Initialized
INFO - 2023-05-31 16:12:28 --> Controller Class Initialized
INFO - 2023-05-31 16:12:28 --> Model Class Initialized
DEBUG - 2023-05-31 16:12:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:12:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:12:28 --> Model Class Initialized
DEBUG - 2023-05-31 16:12:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:12:28 --> Model Class Initialized
INFO - 2023-05-31 16:12:28 --> Final output sent to browser
DEBUG - 2023-05-31 16:12:28 --> Total execution time: 0.0580
ERROR - 2023-05-31 16:12:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:12:58 --> Config Class Initialized
INFO - 2023-05-31 16:12:58 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:12:58 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:12:58 --> Utf8 Class Initialized
INFO - 2023-05-31 16:12:58 --> URI Class Initialized
INFO - 2023-05-31 16:12:58 --> Router Class Initialized
INFO - 2023-05-31 16:12:58 --> Output Class Initialized
INFO - 2023-05-31 16:12:58 --> Security Class Initialized
DEBUG - 2023-05-31 16:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:12:58 --> Input Class Initialized
INFO - 2023-05-31 16:12:58 --> Language Class Initialized
INFO - 2023-05-31 16:12:58 --> Loader Class Initialized
INFO - 2023-05-31 16:12:58 --> Helper loaded: url_helper
INFO - 2023-05-31 16:12:58 --> Helper loaded: file_helper
INFO - 2023-05-31 16:12:58 --> Helper loaded: html_helper
INFO - 2023-05-31 16:12:58 --> Helper loaded: text_helper
INFO - 2023-05-31 16:12:58 --> Helper loaded: form_helper
INFO - 2023-05-31 16:12:58 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:12:58 --> Helper loaded: security_helper
INFO - 2023-05-31 16:12:58 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:12:58 --> Database Driver Class Initialized
INFO - 2023-05-31 16:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:12:58 --> Parser Class Initialized
INFO - 2023-05-31 16:12:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:12:58 --> Pagination Class Initialized
INFO - 2023-05-31 16:12:58 --> Form Validation Class Initialized
INFO - 2023-05-31 16:12:58 --> Controller Class Initialized
INFO - 2023-05-31 16:12:58 --> Model Class Initialized
DEBUG - 2023-05-31 16:12:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:12:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:12:58 --> Model Class Initialized
DEBUG - 2023-05-31 16:12:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:12:58 --> Model Class Initialized
INFO - 2023-05-31 16:12:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html_pdf.php
ERROR - 2023-05-31 16:12:58 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-05-31 16:12:58 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-05-31 16:12:58 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-05-31 16:12:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:12:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:12:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:12:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:12:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:12:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:58 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:12:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:12:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:12:58 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 210
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/frame_reflower.cls.php 211
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/block_frame_reflower.cls.php 726
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-05-31 16:12:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-05-31 16:12:59 --> Final output sent to browser
DEBUG - 2023-05-31 16:12:59 --> Total execution time: 0.2787
ERROR - 2023-05-31 16:13:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:13:04 --> Config Class Initialized
INFO - 2023-05-31 16:13:04 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:13:04 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:13:04 --> Utf8 Class Initialized
INFO - 2023-05-31 16:13:04 --> URI Class Initialized
INFO - 2023-05-31 16:13:04 --> Router Class Initialized
INFO - 2023-05-31 16:13:04 --> Output Class Initialized
INFO - 2023-05-31 16:13:04 --> Security Class Initialized
DEBUG - 2023-05-31 16:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:13:04 --> Input Class Initialized
INFO - 2023-05-31 16:13:04 --> Language Class Initialized
INFO - 2023-05-31 16:13:04 --> Loader Class Initialized
INFO - 2023-05-31 16:13:04 --> Helper loaded: url_helper
INFO - 2023-05-31 16:13:04 --> Helper loaded: file_helper
INFO - 2023-05-31 16:13:04 --> Helper loaded: html_helper
INFO - 2023-05-31 16:13:04 --> Helper loaded: text_helper
INFO - 2023-05-31 16:13:04 --> Helper loaded: form_helper
INFO - 2023-05-31 16:13:04 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:13:04 --> Helper loaded: security_helper
INFO - 2023-05-31 16:13:04 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:13:04 --> Database Driver Class Initialized
INFO - 2023-05-31 16:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:13:04 --> Parser Class Initialized
INFO - 2023-05-31 16:13:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:13:04 --> Pagination Class Initialized
INFO - 2023-05-31 16:13:04 --> Form Validation Class Initialized
INFO - 2023-05-31 16:13:04 --> Controller Class Initialized
INFO - 2023-05-31 16:13:04 --> Model Class Initialized
DEBUG - 2023-05-31 16:13:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:13:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:04 --> Model Class Initialized
DEBUG - 2023-05-31 16:13:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:04 --> Model Class Initialized
INFO - 2023-05-31 16:13:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2023-05-31 16:13:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:13:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:13:04 --> Model Class Initialized
INFO - 2023-05-31 16:13:04 --> Model Class Initialized
INFO - 2023-05-31 16:13:04 --> Model Class Initialized
INFO - 2023-05-31 16:13:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:13:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:13:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:13:04 --> Final output sent to browser
DEBUG - 2023-05-31 16:13:04 --> Total execution time: 0.0760
ERROR - 2023-05-31 16:13:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:13:09 --> Config Class Initialized
INFO - 2023-05-31 16:13:09 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:13:09 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:13:09 --> Utf8 Class Initialized
INFO - 2023-05-31 16:13:09 --> URI Class Initialized
INFO - 2023-05-31 16:13:09 --> Router Class Initialized
INFO - 2023-05-31 16:13:09 --> Output Class Initialized
INFO - 2023-05-31 16:13:09 --> Security Class Initialized
DEBUG - 2023-05-31 16:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:13:09 --> Input Class Initialized
INFO - 2023-05-31 16:13:09 --> Language Class Initialized
INFO - 2023-05-31 16:13:09 --> Loader Class Initialized
INFO - 2023-05-31 16:13:09 --> Helper loaded: url_helper
INFO - 2023-05-31 16:13:09 --> Helper loaded: file_helper
INFO - 2023-05-31 16:13:09 --> Helper loaded: html_helper
INFO - 2023-05-31 16:13:09 --> Helper loaded: text_helper
INFO - 2023-05-31 16:13:09 --> Helper loaded: form_helper
INFO - 2023-05-31 16:13:09 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:13:09 --> Helper loaded: security_helper
INFO - 2023-05-31 16:13:09 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:13:09 --> Database Driver Class Initialized
INFO - 2023-05-31 16:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:13:09 --> Parser Class Initialized
INFO - 2023-05-31 16:13:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:13:09 --> Pagination Class Initialized
INFO - 2023-05-31 16:13:09 --> Form Validation Class Initialized
INFO - 2023-05-31 16:13:09 --> Controller Class Initialized
INFO - 2023-05-31 16:13:09 --> Model Class Initialized
DEBUG - 2023-05-31 16:13:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:13:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:09 --> Model Class Initialized
DEBUG - 2023-05-31 16:13:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:09 --> Model Class Initialized
INFO - 2023-05-31 16:13:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-05-31 16:13:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:13:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:13:09 --> Model Class Initialized
INFO - 2023-05-31 16:13:09 --> Model Class Initialized
INFO - 2023-05-31 16:13:09 --> Model Class Initialized
INFO - 2023-05-31 16:13:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:13:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:13:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:13:09 --> Final output sent to browser
DEBUG - 2023-05-31 16:13:09 --> Total execution time: 0.0682
ERROR - 2023-05-31 16:13:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:13:10 --> Config Class Initialized
INFO - 2023-05-31 16:13:10 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:13:10 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:13:10 --> Utf8 Class Initialized
INFO - 2023-05-31 16:13:10 --> URI Class Initialized
INFO - 2023-05-31 16:13:10 --> Router Class Initialized
INFO - 2023-05-31 16:13:10 --> Output Class Initialized
INFO - 2023-05-31 16:13:10 --> Security Class Initialized
DEBUG - 2023-05-31 16:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:13:10 --> Input Class Initialized
INFO - 2023-05-31 16:13:10 --> Language Class Initialized
INFO - 2023-05-31 16:13:10 --> Loader Class Initialized
INFO - 2023-05-31 16:13:10 --> Helper loaded: url_helper
INFO - 2023-05-31 16:13:10 --> Helper loaded: file_helper
INFO - 2023-05-31 16:13:10 --> Helper loaded: html_helper
INFO - 2023-05-31 16:13:10 --> Helper loaded: text_helper
INFO - 2023-05-31 16:13:10 --> Helper loaded: form_helper
INFO - 2023-05-31 16:13:10 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:13:10 --> Helper loaded: security_helper
INFO - 2023-05-31 16:13:10 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:13:10 --> Database Driver Class Initialized
INFO - 2023-05-31 16:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:13:10 --> Parser Class Initialized
INFO - 2023-05-31 16:13:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:13:10 --> Pagination Class Initialized
INFO - 2023-05-31 16:13:10 --> Form Validation Class Initialized
INFO - 2023-05-31 16:13:10 --> Controller Class Initialized
INFO - 2023-05-31 16:13:10 --> Model Class Initialized
DEBUG - 2023-05-31 16:13:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:13:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:10 --> Model Class Initialized
DEBUG - 2023-05-31 16:13:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:10 --> Model Class Initialized
INFO - 2023-05-31 16:13:10 --> Final output sent to browser
DEBUG - 2023-05-31 16:13:10 --> Total execution time: 0.0588
ERROR - 2023-05-31 16:13:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:13:16 --> Config Class Initialized
INFO - 2023-05-31 16:13:16 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:13:16 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:13:16 --> Utf8 Class Initialized
INFO - 2023-05-31 16:13:16 --> URI Class Initialized
INFO - 2023-05-31 16:13:16 --> Router Class Initialized
INFO - 2023-05-31 16:13:16 --> Output Class Initialized
INFO - 2023-05-31 16:13:16 --> Security Class Initialized
DEBUG - 2023-05-31 16:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:13:16 --> Input Class Initialized
INFO - 2023-05-31 16:13:16 --> Language Class Initialized
INFO - 2023-05-31 16:13:16 --> Loader Class Initialized
INFO - 2023-05-31 16:13:16 --> Helper loaded: url_helper
INFO - 2023-05-31 16:13:16 --> Helper loaded: file_helper
INFO - 2023-05-31 16:13:16 --> Helper loaded: html_helper
INFO - 2023-05-31 16:13:16 --> Helper loaded: text_helper
INFO - 2023-05-31 16:13:16 --> Helper loaded: form_helper
INFO - 2023-05-31 16:13:16 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:13:16 --> Helper loaded: security_helper
INFO - 2023-05-31 16:13:16 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:13:16 --> Database Driver Class Initialized
INFO - 2023-05-31 16:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:13:16 --> Parser Class Initialized
INFO - 2023-05-31 16:13:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:13:16 --> Pagination Class Initialized
INFO - 2023-05-31 16:13:16 --> Form Validation Class Initialized
INFO - 2023-05-31 16:13:16 --> Controller Class Initialized
INFO - 2023-05-31 16:13:16 --> Model Class Initialized
DEBUG - 2023-05-31 16:13:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:13:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:16 --> Model Class Initialized
DEBUG - 2023-05-31 16:13:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:16 --> Model Class Initialized
INFO - 2023-05-31 16:13:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2023-05-31 16:13:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:13:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:13:16 --> Model Class Initialized
INFO - 2023-05-31 16:13:16 --> Model Class Initialized
INFO - 2023-05-31 16:13:16 --> Model Class Initialized
INFO - 2023-05-31 16:13:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:13:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:13:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:13:16 --> Final output sent to browser
DEBUG - 2023-05-31 16:13:16 --> Total execution time: 0.0721
ERROR - 2023-05-31 16:13:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:13:24 --> Config Class Initialized
INFO - 2023-05-31 16:13:24 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:13:24 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:13:24 --> Utf8 Class Initialized
INFO - 2023-05-31 16:13:24 --> URI Class Initialized
INFO - 2023-05-31 16:13:24 --> Router Class Initialized
INFO - 2023-05-31 16:13:24 --> Output Class Initialized
INFO - 2023-05-31 16:13:24 --> Security Class Initialized
DEBUG - 2023-05-31 16:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:13:24 --> Input Class Initialized
INFO - 2023-05-31 16:13:24 --> Language Class Initialized
INFO - 2023-05-31 16:13:24 --> Loader Class Initialized
INFO - 2023-05-31 16:13:24 --> Helper loaded: url_helper
INFO - 2023-05-31 16:13:24 --> Helper loaded: file_helper
INFO - 2023-05-31 16:13:24 --> Helper loaded: html_helper
INFO - 2023-05-31 16:13:24 --> Helper loaded: text_helper
INFO - 2023-05-31 16:13:24 --> Helper loaded: form_helper
INFO - 2023-05-31 16:13:24 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:13:24 --> Helper loaded: security_helper
INFO - 2023-05-31 16:13:24 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:13:24 --> Database Driver Class Initialized
INFO - 2023-05-31 16:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:13:24 --> Parser Class Initialized
INFO - 2023-05-31 16:13:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:13:24 --> Pagination Class Initialized
INFO - 2023-05-31 16:13:24 --> Form Validation Class Initialized
INFO - 2023-05-31 16:13:24 --> Controller Class Initialized
INFO - 2023-05-31 16:13:24 --> Model Class Initialized
DEBUG - 2023-05-31 16:13:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:13:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:24 --> Model Class Initialized
DEBUG - 2023-05-31 16:13:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:24 --> Model Class Initialized
INFO - 2023-05-31 16:13:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-05-31 16:13:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:13:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:13:24 --> Model Class Initialized
INFO - 2023-05-31 16:13:24 --> Model Class Initialized
INFO - 2023-05-31 16:13:24 --> Model Class Initialized
INFO - 2023-05-31 16:13:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:13:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:13:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:13:24 --> Final output sent to browser
DEBUG - 2023-05-31 16:13:24 --> Total execution time: 0.0762
ERROR - 2023-05-31 16:13:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:13:25 --> Config Class Initialized
INFO - 2023-05-31 16:13:25 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:13:25 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:13:25 --> Utf8 Class Initialized
INFO - 2023-05-31 16:13:25 --> URI Class Initialized
INFO - 2023-05-31 16:13:25 --> Router Class Initialized
INFO - 2023-05-31 16:13:25 --> Output Class Initialized
INFO - 2023-05-31 16:13:25 --> Security Class Initialized
DEBUG - 2023-05-31 16:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:13:25 --> Input Class Initialized
INFO - 2023-05-31 16:13:25 --> Language Class Initialized
INFO - 2023-05-31 16:13:25 --> Loader Class Initialized
INFO - 2023-05-31 16:13:25 --> Helper loaded: url_helper
INFO - 2023-05-31 16:13:25 --> Helper loaded: file_helper
INFO - 2023-05-31 16:13:25 --> Helper loaded: html_helper
INFO - 2023-05-31 16:13:25 --> Helper loaded: text_helper
INFO - 2023-05-31 16:13:25 --> Helper loaded: form_helper
INFO - 2023-05-31 16:13:25 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:13:25 --> Helper loaded: security_helper
INFO - 2023-05-31 16:13:25 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:13:25 --> Database Driver Class Initialized
INFO - 2023-05-31 16:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:13:25 --> Parser Class Initialized
INFO - 2023-05-31 16:13:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:13:25 --> Pagination Class Initialized
INFO - 2023-05-31 16:13:25 --> Form Validation Class Initialized
INFO - 2023-05-31 16:13:25 --> Controller Class Initialized
INFO - 2023-05-31 16:13:25 --> Model Class Initialized
DEBUG - 2023-05-31 16:13:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:13:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:25 --> Model Class Initialized
DEBUG - 2023-05-31 16:13:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:25 --> Model Class Initialized
INFO - 2023-05-31 16:13:25 --> Final output sent to browser
DEBUG - 2023-05-31 16:13:25 --> Total execution time: 0.0467
ERROR - 2023-05-31 16:13:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:13:38 --> Config Class Initialized
INFO - 2023-05-31 16:13:38 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:13:38 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:13:38 --> Utf8 Class Initialized
INFO - 2023-05-31 16:13:38 --> URI Class Initialized
INFO - 2023-05-31 16:13:38 --> Router Class Initialized
INFO - 2023-05-31 16:13:38 --> Output Class Initialized
INFO - 2023-05-31 16:13:38 --> Security Class Initialized
DEBUG - 2023-05-31 16:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:13:38 --> Input Class Initialized
INFO - 2023-05-31 16:13:38 --> Language Class Initialized
INFO - 2023-05-31 16:13:38 --> Loader Class Initialized
INFO - 2023-05-31 16:13:38 --> Helper loaded: url_helper
INFO - 2023-05-31 16:13:38 --> Helper loaded: file_helper
INFO - 2023-05-31 16:13:38 --> Helper loaded: html_helper
INFO - 2023-05-31 16:13:38 --> Helper loaded: text_helper
INFO - 2023-05-31 16:13:38 --> Helper loaded: form_helper
INFO - 2023-05-31 16:13:38 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:13:38 --> Helper loaded: security_helper
INFO - 2023-05-31 16:13:38 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:13:38 --> Database Driver Class Initialized
INFO - 2023-05-31 16:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:13:38 --> Parser Class Initialized
INFO - 2023-05-31 16:13:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:13:38 --> Pagination Class Initialized
INFO - 2023-05-31 16:13:38 --> Form Validation Class Initialized
INFO - 2023-05-31 16:13:38 --> Controller Class Initialized
INFO - 2023-05-31 16:13:38 --> Model Class Initialized
DEBUG - 2023-05-31 16:13:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:13:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:38 --> Model Class Initialized
DEBUG - 2023-05-31 16:13:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:38 --> Model Class Initialized
INFO - 2023-05-31 16:13:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2023-05-31 16:13:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:13:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:13:38 --> Model Class Initialized
INFO - 2023-05-31 16:13:38 --> Model Class Initialized
INFO - 2023-05-31 16:13:38 --> Model Class Initialized
INFO - 2023-05-31 16:13:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:13:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:13:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:13:38 --> Final output sent to browser
DEBUG - 2023-05-31 16:13:38 --> Total execution time: 0.0826
ERROR - 2023-05-31 16:13:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:13:42 --> Config Class Initialized
INFO - 2023-05-31 16:13:42 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:13:42 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:13:42 --> Utf8 Class Initialized
INFO - 2023-05-31 16:13:42 --> URI Class Initialized
INFO - 2023-05-31 16:13:42 --> Router Class Initialized
INFO - 2023-05-31 16:13:42 --> Output Class Initialized
INFO - 2023-05-31 16:13:42 --> Security Class Initialized
DEBUG - 2023-05-31 16:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:13:42 --> Input Class Initialized
INFO - 2023-05-31 16:13:42 --> Language Class Initialized
INFO - 2023-05-31 16:13:42 --> Loader Class Initialized
INFO - 2023-05-31 16:13:42 --> Helper loaded: url_helper
INFO - 2023-05-31 16:13:42 --> Helper loaded: file_helper
INFO - 2023-05-31 16:13:42 --> Helper loaded: html_helper
INFO - 2023-05-31 16:13:42 --> Helper loaded: text_helper
INFO - 2023-05-31 16:13:42 --> Helper loaded: form_helper
INFO - 2023-05-31 16:13:42 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:13:42 --> Helper loaded: security_helper
INFO - 2023-05-31 16:13:42 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:13:42 --> Database Driver Class Initialized
INFO - 2023-05-31 16:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:13:42 --> Parser Class Initialized
INFO - 2023-05-31 16:13:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:13:42 --> Pagination Class Initialized
INFO - 2023-05-31 16:13:42 --> Form Validation Class Initialized
INFO - 2023-05-31 16:13:42 --> Controller Class Initialized
INFO - 2023-05-31 16:13:42 --> Model Class Initialized
DEBUG - 2023-05-31 16:13:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:13:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:42 --> Model Class Initialized
DEBUG - 2023-05-31 16:13:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:42 --> Model Class Initialized
INFO - 2023-05-31 16:13:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-05-31 16:13:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:13:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:13:42 --> Model Class Initialized
INFO - 2023-05-31 16:13:42 --> Model Class Initialized
INFO - 2023-05-31 16:13:42 --> Model Class Initialized
INFO - 2023-05-31 16:13:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:13:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:13:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:13:42 --> Final output sent to browser
DEBUG - 2023-05-31 16:13:42 --> Total execution time: 0.0689
ERROR - 2023-05-31 16:13:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:13:44 --> Config Class Initialized
INFO - 2023-05-31 16:13:44 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:13:44 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:13:44 --> Utf8 Class Initialized
INFO - 2023-05-31 16:13:44 --> URI Class Initialized
INFO - 2023-05-31 16:13:44 --> Router Class Initialized
INFO - 2023-05-31 16:13:44 --> Output Class Initialized
INFO - 2023-05-31 16:13:44 --> Security Class Initialized
DEBUG - 2023-05-31 16:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:13:44 --> Input Class Initialized
INFO - 2023-05-31 16:13:44 --> Language Class Initialized
INFO - 2023-05-31 16:13:44 --> Loader Class Initialized
INFO - 2023-05-31 16:13:44 --> Helper loaded: url_helper
INFO - 2023-05-31 16:13:44 --> Helper loaded: file_helper
INFO - 2023-05-31 16:13:44 --> Helper loaded: html_helper
INFO - 2023-05-31 16:13:44 --> Helper loaded: text_helper
INFO - 2023-05-31 16:13:44 --> Helper loaded: form_helper
INFO - 2023-05-31 16:13:44 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:13:44 --> Helper loaded: security_helper
INFO - 2023-05-31 16:13:44 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:13:44 --> Database Driver Class Initialized
INFO - 2023-05-31 16:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:13:44 --> Parser Class Initialized
INFO - 2023-05-31 16:13:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:13:44 --> Pagination Class Initialized
INFO - 2023-05-31 16:13:44 --> Form Validation Class Initialized
INFO - 2023-05-31 16:13:44 --> Controller Class Initialized
INFO - 2023-05-31 16:13:44 --> Model Class Initialized
DEBUG - 2023-05-31 16:13:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:13:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:44 --> Model Class Initialized
DEBUG - 2023-05-31 16:13:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:44 --> Model Class Initialized
INFO - 2023-05-31 16:13:45 --> Final output sent to browser
DEBUG - 2023-05-31 16:13:45 --> Total execution time: 0.0445
ERROR - 2023-05-31 16:13:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:13:50 --> Config Class Initialized
INFO - 2023-05-31 16:13:50 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:13:50 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:13:50 --> Utf8 Class Initialized
INFO - 2023-05-31 16:13:50 --> URI Class Initialized
DEBUG - 2023-05-31 16:13:50 --> No URI present. Default controller set.
INFO - 2023-05-31 16:13:50 --> Router Class Initialized
INFO - 2023-05-31 16:13:50 --> Output Class Initialized
INFO - 2023-05-31 16:13:50 --> Security Class Initialized
DEBUG - 2023-05-31 16:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:13:50 --> Input Class Initialized
INFO - 2023-05-31 16:13:50 --> Language Class Initialized
INFO - 2023-05-31 16:13:50 --> Loader Class Initialized
INFO - 2023-05-31 16:13:50 --> Helper loaded: url_helper
INFO - 2023-05-31 16:13:50 --> Helper loaded: file_helper
INFO - 2023-05-31 16:13:50 --> Helper loaded: html_helper
INFO - 2023-05-31 16:13:50 --> Helper loaded: text_helper
INFO - 2023-05-31 16:13:50 --> Helper loaded: form_helper
INFO - 2023-05-31 16:13:50 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:13:50 --> Helper loaded: security_helper
INFO - 2023-05-31 16:13:50 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:13:50 --> Database Driver Class Initialized
INFO - 2023-05-31 16:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:13:50 --> Parser Class Initialized
INFO - 2023-05-31 16:13:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:13:50 --> Pagination Class Initialized
INFO - 2023-05-31 16:13:50 --> Form Validation Class Initialized
INFO - 2023-05-31 16:13:50 --> Controller Class Initialized
INFO - 2023-05-31 16:13:50 --> Model Class Initialized
DEBUG - 2023-05-31 16:13:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:50 --> Model Class Initialized
DEBUG - 2023-05-31 16:13:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:50 --> Model Class Initialized
INFO - 2023-05-31 16:13:50 --> Model Class Initialized
INFO - 2023-05-31 16:13:50 --> Model Class Initialized
INFO - 2023-05-31 16:13:50 --> Model Class Initialized
DEBUG - 2023-05-31 16:13:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:13:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:50 --> Model Class Initialized
INFO - 2023-05-31 16:13:50 --> Model Class Initialized
INFO - 2023-05-31 16:13:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-31 16:13:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:13:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:13:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:13:50 --> Model Class Initialized
INFO - 2023-05-31 16:13:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:13:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:13:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:13:50 --> Final output sent to browser
DEBUG - 2023-05-31 16:13:50 --> Total execution time: 0.0725
ERROR - 2023-05-31 16:14:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:14:07 --> Config Class Initialized
INFO - 2023-05-31 16:14:07 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:14:07 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:14:07 --> Utf8 Class Initialized
INFO - 2023-05-31 16:14:07 --> URI Class Initialized
INFO - 2023-05-31 16:14:07 --> Router Class Initialized
INFO - 2023-05-31 16:14:07 --> Output Class Initialized
INFO - 2023-05-31 16:14:07 --> Security Class Initialized
DEBUG - 2023-05-31 16:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:14:07 --> Input Class Initialized
INFO - 2023-05-31 16:14:07 --> Language Class Initialized
INFO - 2023-05-31 16:14:07 --> Loader Class Initialized
INFO - 2023-05-31 16:14:07 --> Helper loaded: url_helper
INFO - 2023-05-31 16:14:07 --> Helper loaded: file_helper
INFO - 2023-05-31 16:14:07 --> Helper loaded: html_helper
INFO - 2023-05-31 16:14:07 --> Helper loaded: text_helper
INFO - 2023-05-31 16:14:07 --> Helper loaded: form_helper
INFO - 2023-05-31 16:14:07 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:14:07 --> Helper loaded: security_helper
INFO - 2023-05-31 16:14:07 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:14:07 --> Database Driver Class Initialized
INFO - 2023-05-31 16:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:14:07 --> Parser Class Initialized
INFO - 2023-05-31 16:14:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:14:07 --> Pagination Class Initialized
INFO - 2023-05-31 16:14:07 --> Form Validation Class Initialized
INFO - 2023-05-31 16:14:07 --> Controller Class Initialized
INFO - 2023-05-31 16:14:07 --> Model Class Initialized
DEBUG - 2023-05-31 16:14:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:14:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:14:07 --> Model Class Initialized
INFO - 2023-05-31 16:14:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-05-31 16:14:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:14:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:14:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:14:07 --> Model Class Initialized
INFO - 2023-05-31 16:14:07 --> Model Class Initialized
INFO - 2023-05-31 16:14:07 --> Model Class Initialized
INFO - 2023-05-31 16:14:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:14:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:14:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:14:07 --> Final output sent to browser
DEBUG - 2023-05-31 16:14:07 --> Total execution time: 0.0673
ERROR - 2023-05-31 16:14:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:14:08 --> Config Class Initialized
INFO - 2023-05-31 16:14:08 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:14:08 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:14:08 --> Utf8 Class Initialized
INFO - 2023-05-31 16:14:08 --> URI Class Initialized
INFO - 2023-05-31 16:14:08 --> Router Class Initialized
INFO - 2023-05-31 16:14:08 --> Output Class Initialized
INFO - 2023-05-31 16:14:08 --> Security Class Initialized
DEBUG - 2023-05-31 16:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:14:08 --> Input Class Initialized
INFO - 2023-05-31 16:14:08 --> Language Class Initialized
INFO - 2023-05-31 16:14:08 --> Loader Class Initialized
INFO - 2023-05-31 16:14:08 --> Helper loaded: url_helper
INFO - 2023-05-31 16:14:08 --> Helper loaded: file_helper
INFO - 2023-05-31 16:14:08 --> Helper loaded: html_helper
INFO - 2023-05-31 16:14:08 --> Helper loaded: text_helper
INFO - 2023-05-31 16:14:08 --> Helper loaded: form_helper
INFO - 2023-05-31 16:14:08 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:14:08 --> Helper loaded: security_helper
INFO - 2023-05-31 16:14:08 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:14:08 --> Database Driver Class Initialized
INFO - 2023-05-31 16:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:14:08 --> Parser Class Initialized
INFO - 2023-05-31 16:14:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:14:08 --> Pagination Class Initialized
INFO - 2023-05-31 16:14:08 --> Form Validation Class Initialized
INFO - 2023-05-31 16:14:08 --> Controller Class Initialized
INFO - 2023-05-31 16:14:08 --> Model Class Initialized
DEBUG - 2023-05-31 16:14:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:14:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:14:08 --> Model Class Initialized
INFO - 2023-05-31 16:14:08 --> Final output sent to browser
DEBUG - 2023-05-31 16:14:08 --> Total execution time: 0.0264
ERROR - 2023-05-31 16:14:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:14:32 --> Config Class Initialized
INFO - 2023-05-31 16:14:32 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:14:32 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:14:32 --> Utf8 Class Initialized
INFO - 2023-05-31 16:14:32 --> URI Class Initialized
INFO - 2023-05-31 16:14:32 --> Router Class Initialized
INFO - 2023-05-31 16:14:32 --> Output Class Initialized
INFO - 2023-05-31 16:14:32 --> Security Class Initialized
DEBUG - 2023-05-31 16:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:14:32 --> Input Class Initialized
INFO - 2023-05-31 16:14:32 --> Language Class Initialized
INFO - 2023-05-31 16:14:32 --> Loader Class Initialized
INFO - 2023-05-31 16:14:32 --> Helper loaded: url_helper
INFO - 2023-05-31 16:14:32 --> Helper loaded: file_helper
INFO - 2023-05-31 16:14:32 --> Helper loaded: html_helper
INFO - 2023-05-31 16:14:32 --> Helper loaded: text_helper
INFO - 2023-05-31 16:14:32 --> Helper loaded: form_helper
INFO - 2023-05-31 16:14:32 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:14:32 --> Helper loaded: security_helper
INFO - 2023-05-31 16:14:32 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:14:32 --> Database Driver Class Initialized
INFO - 2023-05-31 16:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:14:32 --> Parser Class Initialized
INFO - 2023-05-31 16:14:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:14:32 --> Pagination Class Initialized
INFO - 2023-05-31 16:14:32 --> Form Validation Class Initialized
INFO - 2023-05-31 16:14:32 --> Controller Class Initialized
INFO - 2023-05-31 16:14:32 --> Model Class Initialized
DEBUG - 2023-05-31 16:14:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:14:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:14:32 --> Model Class Initialized
DEBUG - 2023-05-31 16:14:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:14:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-05-31 16:14:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:14:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:14:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:14:32 --> Model Class Initialized
INFO - 2023-05-31 16:14:32 --> Model Class Initialized
INFO - 2023-05-31 16:14:32 --> Model Class Initialized
INFO - 2023-05-31 16:14:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:14:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:14:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:14:32 --> Final output sent to browser
DEBUG - 2023-05-31 16:14:32 --> Total execution time: 0.0765
ERROR - 2023-05-31 16:15:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:15:24 --> Config Class Initialized
INFO - 2023-05-31 16:15:24 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:15:24 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:15:24 --> Utf8 Class Initialized
INFO - 2023-05-31 16:15:24 --> URI Class Initialized
INFO - 2023-05-31 16:15:24 --> Router Class Initialized
INFO - 2023-05-31 16:15:24 --> Output Class Initialized
INFO - 2023-05-31 16:15:24 --> Security Class Initialized
DEBUG - 2023-05-31 16:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:15:24 --> Input Class Initialized
INFO - 2023-05-31 16:15:24 --> Language Class Initialized
INFO - 2023-05-31 16:15:24 --> Loader Class Initialized
INFO - 2023-05-31 16:15:24 --> Helper loaded: url_helper
INFO - 2023-05-31 16:15:24 --> Helper loaded: file_helper
INFO - 2023-05-31 16:15:24 --> Helper loaded: html_helper
INFO - 2023-05-31 16:15:24 --> Helper loaded: text_helper
INFO - 2023-05-31 16:15:24 --> Helper loaded: form_helper
INFO - 2023-05-31 16:15:24 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:15:24 --> Helper loaded: security_helper
INFO - 2023-05-31 16:15:24 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:15:24 --> Database Driver Class Initialized
INFO - 2023-05-31 16:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:15:24 --> Parser Class Initialized
INFO - 2023-05-31 16:15:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:15:24 --> Pagination Class Initialized
INFO - 2023-05-31 16:15:24 --> Form Validation Class Initialized
INFO - 2023-05-31 16:15:24 --> Controller Class Initialized
INFO - 2023-05-31 16:15:24 --> Model Class Initialized
DEBUG - 2023-05-31 16:15:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:15:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:15:24 --> Model Class Initialized
INFO - 2023-05-31 16:15:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-05-31 16:15:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:15:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:15:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:15:24 --> Model Class Initialized
INFO - 2023-05-31 16:15:24 --> Model Class Initialized
INFO - 2023-05-31 16:15:24 --> Model Class Initialized
INFO - 2023-05-31 16:15:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:15:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:15:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:15:25 --> Final output sent to browser
DEBUG - 2023-05-31 16:15:25 --> Total execution time: 0.0656
ERROR - 2023-05-31 16:15:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:15:26 --> Config Class Initialized
INFO - 2023-05-31 16:15:26 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:15:26 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:15:26 --> Utf8 Class Initialized
INFO - 2023-05-31 16:15:26 --> URI Class Initialized
INFO - 2023-05-31 16:15:26 --> Router Class Initialized
INFO - 2023-05-31 16:15:26 --> Output Class Initialized
INFO - 2023-05-31 16:15:26 --> Security Class Initialized
DEBUG - 2023-05-31 16:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:15:26 --> Input Class Initialized
INFO - 2023-05-31 16:15:26 --> Language Class Initialized
INFO - 2023-05-31 16:15:26 --> Loader Class Initialized
INFO - 2023-05-31 16:15:26 --> Helper loaded: url_helper
INFO - 2023-05-31 16:15:26 --> Helper loaded: file_helper
INFO - 2023-05-31 16:15:26 --> Helper loaded: html_helper
INFO - 2023-05-31 16:15:26 --> Helper loaded: text_helper
INFO - 2023-05-31 16:15:26 --> Helper loaded: form_helper
INFO - 2023-05-31 16:15:26 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:15:26 --> Helper loaded: security_helper
INFO - 2023-05-31 16:15:26 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:15:26 --> Database Driver Class Initialized
INFO - 2023-05-31 16:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:15:26 --> Parser Class Initialized
INFO - 2023-05-31 16:15:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:15:26 --> Pagination Class Initialized
INFO - 2023-05-31 16:15:26 --> Form Validation Class Initialized
INFO - 2023-05-31 16:15:26 --> Controller Class Initialized
INFO - 2023-05-31 16:15:26 --> Model Class Initialized
DEBUG - 2023-05-31 16:15:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:15:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:15:26 --> Model Class Initialized
INFO - 2023-05-31 16:15:26 --> Final output sent to browser
DEBUG - 2023-05-31 16:15:26 --> Total execution time: 0.0282
ERROR - 2023-05-31 16:15:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:15:29 --> Config Class Initialized
INFO - 2023-05-31 16:15:29 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:15:29 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:15:29 --> Utf8 Class Initialized
INFO - 2023-05-31 16:15:29 --> URI Class Initialized
INFO - 2023-05-31 16:15:29 --> Router Class Initialized
INFO - 2023-05-31 16:15:29 --> Output Class Initialized
INFO - 2023-05-31 16:15:29 --> Security Class Initialized
DEBUG - 2023-05-31 16:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:15:29 --> Input Class Initialized
INFO - 2023-05-31 16:15:29 --> Language Class Initialized
INFO - 2023-05-31 16:15:29 --> Loader Class Initialized
INFO - 2023-05-31 16:15:29 --> Helper loaded: url_helper
INFO - 2023-05-31 16:15:29 --> Helper loaded: file_helper
INFO - 2023-05-31 16:15:29 --> Helper loaded: html_helper
INFO - 2023-05-31 16:15:29 --> Helper loaded: text_helper
INFO - 2023-05-31 16:15:29 --> Helper loaded: form_helper
INFO - 2023-05-31 16:15:29 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:15:29 --> Helper loaded: security_helper
INFO - 2023-05-31 16:15:29 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:15:29 --> Database Driver Class Initialized
INFO - 2023-05-31 16:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:15:29 --> Parser Class Initialized
INFO - 2023-05-31 16:15:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:15:29 --> Pagination Class Initialized
INFO - 2023-05-31 16:15:29 --> Form Validation Class Initialized
INFO - 2023-05-31 16:15:29 --> Controller Class Initialized
INFO - 2023-05-31 16:15:29 --> Model Class Initialized
DEBUG - 2023-05-31 16:15:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:15:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:15:29 --> Model Class Initialized
DEBUG - 2023-05-31 16:15:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:15:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-05-31 16:15:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:15:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:15:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:15:29 --> Model Class Initialized
INFO - 2023-05-31 16:15:29 --> Model Class Initialized
INFO - 2023-05-31 16:15:29 --> Model Class Initialized
INFO - 2023-05-31 16:15:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:15:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:15:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:15:29 --> Final output sent to browser
DEBUG - 2023-05-31 16:15:29 --> Total execution time: 0.0715
ERROR - 2023-05-31 16:15:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:15:38 --> Config Class Initialized
INFO - 2023-05-31 16:15:38 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:15:38 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:15:38 --> Utf8 Class Initialized
INFO - 2023-05-31 16:15:38 --> URI Class Initialized
INFO - 2023-05-31 16:15:38 --> Router Class Initialized
INFO - 2023-05-31 16:15:38 --> Output Class Initialized
INFO - 2023-05-31 16:15:38 --> Security Class Initialized
DEBUG - 2023-05-31 16:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:15:38 --> Input Class Initialized
INFO - 2023-05-31 16:15:38 --> Language Class Initialized
INFO - 2023-05-31 16:15:38 --> Loader Class Initialized
INFO - 2023-05-31 16:15:38 --> Helper loaded: url_helper
INFO - 2023-05-31 16:15:38 --> Helper loaded: file_helper
INFO - 2023-05-31 16:15:38 --> Helper loaded: html_helper
INFO - 2023-05-31 16:15:38 --> Helper loaded: text_helper
INFO - 2023-05-31 16:15:38 --> Helper loaded: form_helper
INFO - 2023-05-31 16:15:38 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:15:38 --> Helper loaded: security_helper
INFO - 2023-05-31 16:15:38 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:15:38 --> Database Driver Class Initialized
INFO - 2023-05-31 16:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:15:38 --> Parser Class Initialized
INFO - 2023-05-31 16:15:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:15:38 --> Pagination Class Initialized
INFO - 2023-05-31 16:15:38 --> Form Validation Class Initialized
INFO - 2023-05-31 16:15:38 --> Controller Class Initialized
INFO - 2023-05-31 16:15:38 --> Model Class Initialized
DEBUG - 2023-05-31 16:15:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:15:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:15:38 --> Model Class Initialized
INFO - 2023-05-31 16:15:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-05-31 16:15:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:15:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:15:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:15:38 --> Model Class Initialized
INFO - 2023-05-31 16:15:38 --> Model Class Initialized
INFO - 2023-05-31 16:15:38 --> Model Class Initialized
INFO - 2023-05-31 16:15:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:15:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:15:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:15:38 --> Final output sent to browser
DEBUG - 2023-05-31 16:15:38 --> Total execution time: 0.0650
ERROR - 2023-05-31 16:15:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:15:41 --> Config Class Initialized
INFO - 2023-05-31 16:15:41 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:15:41 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:15:41 --> Utf8 Class Initialized
INFO - 2023-05-31 16:15:41 --> URI Class Initialized
INFO - 2023-05-31 16:15:41 --> Router Class Initialized
INFO - 2023-05-31 16:15:41 --> Output Class Initialized
INFO - 2023-05-31 16:15:41 --> Security Class Initialized
DEBUG - 2023-05-31 16:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:15:41 --> Input Class Initialized
INFO - 2023-05-31 16:15:41 --> Language Class Initialized
INFO - 2023-05-31 16:15:41 --> Loader Class Initialized
INFO - 2023-05-31 16:15:41 --> Helper loaded: url_helper
INFO - 2023-05-31 16:15:41 --> Helper loaded: file_helper
INFO - 2023-05-31 16:15:41 --> Helper loaded: html_helper
INFO - 2023-05-31 16:15:41 --> Helper loaded: text_helper
INFO - 2023-05-31 16:15:41 --> Helper loaded: form_helper
INFO - 2023-05-31 16:15:41 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:15:41 --> Helper loaded: security_helper
INFO - 2023-05-31 16:15:41 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:15:41 --> Database Driver Class Initialized
INFO - 2023-05-31 16:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:15:41 --> Parser Class Initialized
INFO - 2023-05-31 16:15:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:15:41 --> Pagination Class Initialized
INFO - 2023-05-31 16:15:42 --> Form Validation Class Initialized
INFO - 2023-05-31 16:15:42 --> Controller Class Initialized
INFO - 2023-05-31 16:15:42 --> Model Class Initialized
DEBUG - 2023-05-31 16:15:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:15:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:15:42 --> Model Class Initialized
INFO - 2023-05-31 16:15:42 --> Final output sent to browser
DEBUG - 2023-05-31 16:15:42 --> Total execution time: 0.0264
ERROR - 2023-05-31 16:15:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:15:49 --> Config Class Initialized
INFO - 2023-05-31 16:15:49 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:15:49 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:15:49 --> Utf8 Class Initialized
INFO - 2023-05-31 16:15:49 --> URI Class Initialized
INFO - 2023-05-31 16:15:49 --> Router Class Initialized
INFO - 2023-05-31 16:15:49 --> Output Class Initialized
INFO - 2023-05-31 16:15:49 --> Security Class Initialized
DEBUG - 2023-05-31 16:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:15:49 --> Input Class Initialized
INFO - 2023-05-31 16:15:49 --> Language Class Initialized
INFO - 2023-05-31 16:15:49 --> Loader Class Initialized
INFO - 2023-05-31 16:15:49 --> Helper loaded: url_helper
INFO - 2023-05-31 16:15:49 --> Helper loaded: file_helper
INFO - 2023-05-31 16:15:49 --> Helper loaded: html_helper
INFO - 2023-05-31 16:15:49 --> Helper loaded: text_helper
INFO - 2023-05-31 16:15:49 --> Helper loaded: form_helper
INFO - 2023-05-31 16:15:49 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:15:49 --> Helper loaded: security_helper
INFO - 2023-05-31 16:15:49 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:15:49 --> Database Driver Class Initialized
INFO - 2023-05-31 16:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:15:49 --> Parser Class Initialized
INFO - 2023-05-31 16:15:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:15:49 --> Pagination Class Initialized
INFO - 2023-05-31 16:15:49 --> Form Validation Class Initialized
INFO - 2023-05-31 16:15:49 --> Controller Class Initialized
INFO - 2023-05-31 16:15:49 --> Model Class Initialized
DEBUG - 2023-05-31 16:15:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:15:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:15:49 --> Model Class Initialized
DEBUG - 2023-05-31 16:15:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:15:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-05-31 16:15:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:15:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:15:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:15:49 --> Model Class Initialized
INFO - 2023-05-31 16:15:49 --> Model Class Initialized
INFO - 2023-05-31 16:15:49 --> Model Class Initialized
INFO - 2023-05-31 16:15:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:15:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:15:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:15:49 --> Final output sent to browser
DEBUG - 2023-05-31 16:15:49 --> Total execution time: 0.0790
ERROR - 2023-05-31 16:15:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:15:58 --> Config Class Initialized
INFO - 2023-05-31 16:15:58 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:15:58 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:15:58 --> Utf8 Class Initialized
INFO - 2023-05-31 16:15:58 --> URI Class Initialized
INFO - 2023-05-31 16:15:58 --> Router Class Initialized
INFO - 2023-05-31 16:15:58 --> Output Class Initialized
INFO - 2023-05-31 16:15:58 --> Security Class Initialized
DEBUG - 2023-05-31 16:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:15:58 --> Input Class Initialized
INFO - 2023-05-31 16:15:58 --> Language Class Initialized
INFO - 2023-05-31 16:15:58 --> Loader Class Initialized
INFO - 2023-05-31 16:15:58 --> Helper loaded: url_helper
INFO - 2023-05-31 16:15:58 --> Helper loaded: file_helper
INFO - 2023-05-31 16:15:58 --> Helper loaded: html_helper
INFO - 2023-05-31 16:15:58 --> Helper loaded: text_helper
INFO - 2023-05-31 16:15:58 --> Helper loaded: form_helper
INFO - 2023-05-31 16:15:58 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:15:58 --> Helper loaded: security_helper
INFO - 2023-05-31 16:15:58 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:15:58 --> Database Driver Class Initialized
INFO - 2023-05-31 16:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:15:58 --> Parser Class Initialized
INFO - 2023-05-31 16:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:15:58 --> Pagination Class Initialized
INFO - 2023-05-31 16:15:58 --> Form Validation Class Initialized
INFO - 2023-05-31 16:15:58 --> Controller Class Initialized
INFO - 2023-05-31 16:15:58 --> Model Class Initialized
DEBUG - 2023-05-31 16:15:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:15:58 --> Model Class Initialized
INFO - 2023-05-31 16:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-05-31 16:15:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:15:58 --> Model Class Initialized
INFO - 2023-05-31 16:15:58 --> Model Class Initialized
INFO - 2023-05-31 16:15:58 --> Model Class Initialized
INFO - 2023-05-31 16:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:15:58 --> Final output sent to browser
DEBUG - 2023-05-31 16:15:58 --> Total execution time: 0.0681
ERROR - 2023-05-31 16:16:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:16:00 --> Config Class Initialized
INFO - 2023-05-31 16:16:00 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:16:00 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:16:00 --> Utf8 Class Initialized
INFO - 2023-05-31 16:16:00 --> URI Class Initialized
INFO - 2023-05-31 16:16:00 --> Router Class Initialized
INFO - 2023-05-31 16:16:00 --> Output Class Initialized
INFO - 2023-05-31 16:16:00 --> Security Class Initialized
DEBUG - 2023-05-31 16:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:16:00 --> Input Class Initialized
INFO - 2023-05-31 16:16:00 --> Language Class Initialized
INFO - 2023-05-31 16:16:00 --> Loader Class Initialized
INFO - 2023-05-31 16:16:00 --> Helper loaded: url_helper
INFO - 2023-05-31 16:16:00 --> Helper loaded: file_helper
INFO - 2023-05-31 16:16:00 --> Helper loaded: html_helper
INFO - 2023-05-31 16:16:00 --> Helper loaded: text_helper
INFO - 2023-05-31 16:16:00 --> Helper loaded: form_helper
INFO - 2023-05-31 16:16:00 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:16:00 --> Helper loaded: security_helper
INFO - 2023-05-31 16:16:00 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:16:00 --> Database Driver Class Initialized
INFO - 2023-05-31 16:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:16:00 --> Parser Class Initialized
INFO - 2023-05-31 16:16:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:16:00 --> Pagination Class Initialized
INFO - 2023-05-31 16:16:00 --> Form Validation Class Initialized
INFO - 2023-05-31 16:16:00 --> Controller Class Initialized
INFO - 2023-05-31 16:16:00 --> Model Class Initialized
DEBUG - 2023-05-31 16:16:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:16:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:16:00 --> Model Class Initialized
INFO - 2023-05-31 16:16:00 --> Final output sent to browser
DEBUG - 2023-05-31 16:16:00 --> Total execution time: 0.0260
ERROR - 2023-05-31 16:16:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:16:09 --> Config Class Initialized
INFO - 2023-05-31 16:16:09 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:16:09 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:16:09 --> Utf8 Class Initialized
INFO - 2023-05-31 16:16:09 --> URI Class Initialized
INFO - 2023-05-31 16:16:09 --> Router Class Initialized
INFO - 2023-05-31 16:16:09 --> Output Class Initialized
INFO - 2023-05-31 16:16:09 --> Security Class Initialized
DEBUG - 2023-05-31 16:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:16:09 --> Input Class Initialized
INFO - 2023-05-31 16:16:09 --> Language Class Initialized
INFO - 2023-05-31 16:16:09 --> Loader Class Initialized
INFO - 2023-05-31 16:16:09 --> Helper loaded: url_helper
INFO - 2023-05-31 16:16:09 --> Helper loaded: file_helper
INFO - 2023-05-31 16:16:09 --> Helper loaded: html_helper
INFO - 2023-05-31 16:16:09 --> Helper loaded: text_helper
INFO - 2023-05-31 16:16:09 --> Helper loaded: form_helper
INFO - 2023-05-31 16:16:09 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:16:09 --> Helper loaded: security_helper
INFO - 2023-05-31 16:16:09 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:16:09 --> Database Driver Class Initialized
INFO - 2023-05-31 16:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:16:09 --> Parser Class Initialized
INFO - 2023-05-31 16:16:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:16:09 --> Pagination Class Initialized
INFO - 2023-05-31 16:16:09 --> Form Validation Class Initialized
INFO - 2023-05-31 16:16:09 --> Controller Class Initialized
INFO - 2023-05-31 16:16:09 --> Model Class Initialized
DEBUG - 2023-05-31 16:16:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:16:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:16:09 --> Model Class Initialized
DEBUG - 2023-05-31 16:16:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:16:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-05-31 16:16:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:16:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:16:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:16:09 --> Model Class Initialized
INFO - 2023-05-31 16:16:09 --> Model Class Initialized
INFO - 2023-05-31 16:16:09 --> Model Class Initialized
INFO - 2023-05-31 16:16:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:16:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:16:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:16:09 --> Final output sent to browser
DEBUG - 2023-05-31 16:16:09 --> Total execution time: 0.0731
ERROR - 2023-05-31 16:16:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:16:20 --> Config Class Initialized
INFO - 2023-05-31 16:16:20 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:16:20 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:16:20 --> Utf8 Class Initialized
INFO - 2023-05-31 16:16:20 --> URI Class Initialized
INFO - 2023-05-31 16:16:20 --> Router Class Initialized
INFO - 2023-05-31 16:16:20 --> Output Class Initialized
INFO - 2023-05-31 16:16:20 --> Security Class Initialized
DEBUG - 2023-05-31 16:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:16:20 --> Input Class Initialized
INFO - 2023-05-31 16:16:20 --> Language Class Initialized
INFO - 2023-05-31 16:16:20 --> Loader Class Initialized
INFO - 2023-05-31 16:16:20 --> Helper loaded: url_helper
INFO - 2023-05-31 16:16:20 --> Helper loaded: file_helper
INFO - 2023-05-31 16:16:20 --> Helper loaded: html_helper
INFO - 2023-05-31 16:16:20 --> Helper loaded: text_helper
INFO - 2023-05-31 16:16:20 --> Helper loaded: form_helper
INFO - 2023-05-31 16:16:20 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:16:20 --> Helper loaded: security_helper
INFO - 2023-05-31 16:16:20 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:16:20 --> Database Driver Class Initialized
INFO - 2023-05-31 16:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:16:20 --> Parser Class Initialized
INFO - 2023-05-31 16:16:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:16:20 --> Pagination Class Initialized
INFO - 2023-05-31 16:16:20 --> Form Validation Class Initialized
INFO - 2023-05-31 16:16:20 --> Controller Class Initialized
INFO - 2023-05-31 16:16:20 --> Model Class Initialized
DEBUG - 2023-05-31 16:16:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:16:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:16:20 --> Model Class Initialized
INFO - 2023-05-31 16:16:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-05-31 16:16:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:16:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:16:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:16:20 --> Model Class Initialized
INFO - 2023-05-31 16:16:20 --> Model Class Initialized
INFO - 2023-05-31 16:16:20 --> Model Class Initialized
INFO - 2023-05-31 16:16:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:16:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:16:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:16:20 --> Final output sent to browser
DEBUG - 2023-05-31 16:16:20 --> Total execution time: 0.0643
ERROR - 2023-05-31 16:16:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:16:23 --> Config Class Initialized
INFO - 2023-05-31 16:16:23 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:16:23 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:16:23 --> Utf8 Class Initialized
INFO - 2023-05-31 16:16:23 --> URI Class Initialized
INFO - 2023-05-31 16:16:23 --> Router Class Initialized
INFO - 2023-05-31 16:16:23 --> Output Class Initialized
INFO - 2023-05-31 16:16:23 --> Security Class Initialized
DEBUG - 2023-05-31 16:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:16:23 --> Input Class Initialized
INFO - 2023-05-31 16:16:23 --> Language Class Initialized
INFO - 2023-05-31 16:16:23 --> Loader Class Initialized
INFO - 2023-05-31 16:16:23 --> Helper loaded: url_helper
INFO - 2023-05-31 16:16:23 --> Helper loaded: file_helper
INFO - 2023-05-31 16:16:23 --> Helper loaded: html_helper
INFO - 2023-05-31 16:16:23 --> Helper loaded: text_helper
INFO - 2023-05-31 16:16:23 --> Helper loaded: form_helper
INFO - 2023-05-31 16:16:23 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:16:23 --> Helper loaded: security_helper
INFO - 2023-05-31 16:16:23 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:16:23 --> Database Driver Class Initialized
INFO - 2023-05-31 16:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:16:23 --> Parser Class Initialized
INFO - 2023-05-31 16:16:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:16:23 --> Pagination Class Initialized
INFO - 2023-05-31 16:16:23 --> Form Validation Class Initialized
INFO - 2023-05-31 16:16:23 --> Controller Class Initialized
INFO - 2023-05-31 16:16:23 --> Model Class Initialized
DEBUG - 2023-05-31 16:16:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:16:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:16:23 --> Model Class Initialized
INFO - 2023-05-31 16:16:23 --> Final output sent to browser
DEBUG - 2023-05-31 16:16:23 --> Total execution time: 0.0296
ERROR - 2023-05-31 16:16:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:16:28 --> Config Class Initialized
INFO - 2023-05-31 16:16:28 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:16:28 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:16:28 --> Utf8 Class Initialized
INFO - 2023-05-31 16:16:28 --> URI Class Initialized
INFO - 2023-05-31 16:16:28 --> Router Class Initialized
INFO - 2023-05-31 16:16:28 --> Output Class Initialized
INFO - 2023-05-31 16:16:28 --> Security Class Initialized
DEBUG - 2023-05-31 16:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:16:28 --> Input Class Initialized
INFO - 2023-05-31 16:16:28 --> Language Class Initialized
INFO - 2023-05-31 16:16:28 --> Loader Class Initialized
INFO - 2023-05-31 16:16:28 --> Helper loaded: url_helper
INFO - 2023-05-31 16:16:28 --> Helper loaded: file_helper
INFO - 2023-05-31 16:16:28 --> Helper loaded: html_helper
INFO - 2023-05-31 16:16:28 --> Helper loaded: text_helper
INFO - 2023-05-31 16:16:28 --> Helper loaded: form_helper
INFO - 2023-05-31 16:16:28 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:16:28 --> Helper loaded: security_helper
INFO - 2023-05-31 16:16:28 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:16:28 --> Database Driver Class Initialized
INFO - 2023-05-31 16:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:16:28 --> Parser Class Initialized
INFO - 2023-05-31 16:16:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:16:28 --> Pagination Class Initialized
INFO - 2023-05-31 16:16:28 --> Form Validation Class Initialized
INFO - 2023-05-31 16:16:28 --> Controller Class Initialized
INFO - 2023-05-31 16:16:28 --> Model Class Initialized
DEBUG - 2023-05-31 16:16:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:16:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:16:28 --> Model Class Initialized
DEBUG - 2023-05-31 16:16:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:16:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-05-31 16:16:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:16:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:16:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:16:28 --> Model Class Initialized
INFO - 2023-05-31 16:16:28 --> Model Class Initialized
INFO - 2023-05-31 16:16:28 --> Model Class Initialized
INFO - 2023-05-31 16:16:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:16:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:16:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:16:28 --> Final output sent to browser
DEBUG - 2023-05-31 16:16:28 --> Total execution time: 0.0688
ERROR - 2023-05-31 16:16:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:16:36 --> Config Class Initialized
INFO - 2023-05-31 16:16:36 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:16:36 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:16:36 --> Utf8 Class Initialized
INFO - 2023-05-31 16:16:36 --> URI Class Initialized
INFO - 2023-05-31 16:16:36 --> Router Class Initialized
INFO - 2023-05-31 16:16:36 --> Output Class Initialized
INFO - 2023-05-31 16:16:36 --> Security Class Initialized
DEBUG - 2023-05-31 16:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:16:36 --> Input Class Initialized
INFO - 2023-05-31 16:16:36 --> Language Class Initialized
INFO - 2023-05-31 16:16:36 --> Loader Class Initialized
INFO - 2023-05-31 16:16:36 --> Helper loaded: url_helper
INFO - 2023-05-31 16:16:36 --> Helper loaded: file_helper
INFO - 2023-05-31 16:16:36 --> Helper loaded: html_helper
INFO - 2023-05-31 16:16:36 --> Helper loaded: text_helper
INFO - 2023-05-31 16:16:36 --> Helper loaded: form_helper
INFO - 2023-05-31 16:16:36 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:16:36 --> Helper loaded: security_helper
INFO - 2023-05-31 16:16:36 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:16:36 --> Database Driver Class Initialized
INFO - 2023-05-31 16:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:16:36 --> Parser Class Initialized
INFO - 2023-05-31 16:16:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:16:36 --> Pagination Class Initialized
INFO - 2023-05-31 16:16:36 --> Form Validation Class Initialized
INFO - 2023-05-31 16:16:36 --> Controller Class Initialized
INFO - 2023-05-31 16:16:36 --> Model Class Initialized
DEBUG - 2023-05-31 16:16:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:16:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:16:36 --> Model Class Initialized
INFO - 2023-05-31 16:16:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-05-31 16:16:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:16:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:16:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:16:36 --> Model Class Initialized
INFO - 2023-05-31 16:16:36 --> Model Class Initialized
INFO - 2023-05-31 16:16:36 --> Model Class Initialized
INFO - 2023-05-31 16:16:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:16:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:16:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:16:36 --> Final output sent to browser
DEBUG - 2023-05-31 16:16:36 --> Total execution time: 0.0649
ERROR - 2023-05-31 16:16:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:16:37 --> Config Class Initialized
INFO - 2023-05-31 16:16:37 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:16:37 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:16:37 --> Utf8 Class Initialized
INFO - 2023-05-31 16:16:37 --> URI Class Initialized
INFO - 2023-05-31 16:16:37 --> Router Class Initialized
INFO - 2023-05-31 16:16:37 --> Output Class Initialized
INFO - 2023-05-31 16:16:37 --> Security Class Initialized
DEBUG - 2023-05-31 16:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:16:37 --> Input Class Initialized
INFO - 2023-05-31 16:16:37 --> Language Class Initialized
INFO - 2023-05-31 16:16:37 --> Loader Class Initialized
INFO - 2023-05-31 16:16:37 --> Helper loaded: url_helper
INFO - 2023-05-31 16:16:37 --> Helper loaded: file_helper
INFO - 2023-05-31 16:16:37 --> Helper loaded: html_helper
INFO - 2023-05-31 16:16:37 --> Helper loaded: text_helper
INFO - 2023-05-31 16:16:37 --> Helper loaded: form_helper
INFO - 2023-05-31 16:16:37 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:16:37 --> Helper loaded: security_helper
INFO - 2023-05-31 16:16:37 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:16:37 --> Database Driver Class Initialized
INFO - 2023-05-31 16:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:16:37 --> Parser Class Initialized
INFO - 2023-05-31 16:16:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:16:37 --> Pagination Class Initialized
INFO - 2023-05-31 16:16:37 --> Form Validation Class Initialized
INFO - 2023-05-31 16:16:37 --> Controller Class Initialized
INFO - 2023-05-31 16:16:37 --> Model Class Initialized
DEBUG - 2023-05-31 16:16:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:16:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:16:37 --> Model Class Initialized
INFO - 2023-05-31 16:16:37 --> Final output sent to browser
DEBUG - 2023-05-31 16:16:37 --> Total execution time: 0.0262
ERROR - 2023-05-31 16:16:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:16:42 --> Config Class Initialized
INFO - 2023-05-31 16:16:42 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:16:42 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:16:42 --> Utf8 Class Initialized
INFO - 2023-05-31 16:16:42 --> URI Class Initialized
DEBUG - 2023-05-31 16:16:42 --> No URI present. Default controller set.
INFO - 2023-05-31 16:16:42 --> Router Class Initialized
INFO - 2023-05-31 16:16:42 --> Output Class Initialized
INFO - 2023-05-31 16:16:42 --> Security Class Initialized
DEBUG - 2023-05-31 16:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:16:42 --> Input Class Initialized
INFO - 2023-05-31 16:16:42 --> Language Class Initialized
INFO - 2023-05-31 16:16:42 --> Loader Class Initialized
INFO - 2023-05-31 16:16:42 --> Helper loaded: url_helper
INFO - 2023-05-31 16:16:42 --> Helper loaded: file_helper
INFO - 2023-05-31 16:16:42 --> Helper loaded: html_helper
INFO - 2023-05-31 16:16:42 --> Helper loaded: text_helper
INFO - 2023-05-31 16:16:42 --> Helper loaded: form_helper
INFO - 2023-05-31 16:16:42 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:16:42 --> Helper loaded: security_helper
INFO - 2023-05-31 16:16:42 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:16:42 --> Database Driver Class Initialized
INFO - 2023-05-31 16:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:16:42 --> Parser Class Initialized
INFO - 2023-05-31 16:16:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:16:42 --> Pagination Class Initialized
INFO - 2023-05-31 16:16:42 --> Form Validation Class Initialized
INFO - 2023-05-31 16:16:42 --> Controller Class Initialized
INFO - 2023-05-31 16:16:42 --> Model Class Initialized
DEBUG - 2023-05-31 16:16:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:16:42 --> Model Class Initialized
DEBUG - 2023-05-31 16:16:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:16:42 --> Model Class Initialized
INFO - 2023-05-31 16:16:42 --> Model Class Initialized
INFO - 2023-05-31 16:16:42 --> Model Class Initialized
INFO - 2023-05-31 16:16:42 --> Model Class Initialized
DEBUG - 2023-05-31 16:16:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:16:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:16:42 --> Model Class Initialized
INFO - 2023-05-31 16:16:42 --> Model Class Initialized
INFO - 2023-05-31 16:16:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-31 16:16:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:16:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:16:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:16:42 --> Model Class Initialized
INFO - 2023-05-31 16:16:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:16:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:16:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:16:42 --> Final output sent to browser
DEBUG - 2023-05-31 16:16:42 --> Total execution time: 0.0763
ERROR - 2023-05-31 16:20:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:20:45 --> Config Class Initialized
INFO - 2023-05-31 16:20:45 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:20:45 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:20:45 --> Utf8 Class Initialized
INFO - 2023-05-31 16:20:45 --> URI Class Initialized
DEBUG - 2023-05-31 16:20:45 --> No URI present. Default controller set.
INFO - 2023-05-31 16:20:45 --> Router Class Initialized
INFO - 2023-05-31 16:20:45 --> Output Class Initialized
INFO - 2023-05-31 16:20:45 --> Security Class Initialized
DEBUG - 2023-05-31 16:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:20:45 --> Input Class Initialized
INFO - 2023-05-31 16:20:45 --> Language Class Initialized
INFO - 2023-05-31 16:20:45 --> Loader Class Initialized
INFO - 2023-05-31 16:20:45 --> Helper loaded: url_helper
INFO - 2023-05-31 16:20:45 --> Helper loaded: file_helper
INFO - 2023-05-31 16:20:45 --> Helper loaded: html_helper
INFO - 2023-05-31 16:20:45 --> Helper loaded: text_helper
INFO - 2023-05-31 16:20:45 --> Helper loaded: form_helper
INFO - 2023-05-31 16:20:45 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:20:45 --> Helper loaded: security_helper
INFO - 2023-05-31 16:20:45 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:20:45 --> Database Driver Class Initialized
INFO - 2023-05-31 16:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:20:45 --> Parser Class Initialized
INFO - 2023-05-31 16:20:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:20:45 --> Pagination Class Initialized
INFO - 2023-05-31 16:20:45 --> Form Validation Class Initialized
INFO - 2023-05-31 16:20:45 --> Controller Class Initialized
INFO - 2023-05-31 16:20:45 --> Model Class Initialized
DEBUG - 2023-05-31 16:20:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-31 16:20:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:20:46 --> Config Class Initialized
INFO - 2023-05-31 16:20:46 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:20:46 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:20:46 --> Utf8 Class Initialized
INFO - 2023-05-31 16:20:46 --> URI Class Initialized
INFO - 2023-05-31 16:20:46 --> Router Class Initialized
INFO - 2023-05-31 16:20:46 --> Output Class Initialized
INFO - 2023-05-31 16:20:46 --> Security Class Initialized
DEBUG - 2023-05-31 16:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:20:46 --> Input Class Initialized
INFO - 2023-05-31 16:20:46 --> Language Class Initialized
INFO - 2023-05-31 16:20:46 --> Loader Class Initialized
INFO - 2023-05-31 16:20:46 --> Helper loaded: url_helper
INFO - 2023-05-31 16:20:46 --> Helper loaded: file_helper
INFO - 2023-05-31 16:20:46 --> Helper loaded: html_helper
INFO - 2023-05-31 16:20:46 --> Helper loaded: text_helper
INFO - 2023-05-31 16:20:46 --> Helper loaded: form_helper
INFO - 2023-05-31 16:20:46 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:20:46 --> Helper loaded: security_helper
INFO - 2023-05-31 16:20:46 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:20:46 --> Database Driver Class Initialized
INFO - 2023-05-31 16:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:20:46 --> Parser Class Initialized
INFO - 2023-05-31 16:20:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:20:46 --> Pagination Class Initialized
INFO - 2023-05-31 16:20:46 --> Form Validation Class Initialized
INFO - 2023-05-31 16:20:46 --> Controller Class Initialized
INFO - 2023-05-31 16:20:46 --> Model Class Initialized
DEBUG - 2023-05-31 16:20:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:20:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-31 16:20:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:20:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:20:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:20:46 --> Model Class Initialized
INFO - 2023-05-31 16:20:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:20:46 --> Final output sent to browser
DEBUG - 2023-05-31 16:20:46 --> Total execution time: 0.0332
ERROR - 2023-05-31 16:20:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:20:50 --> Config Class Initialized
INFO - 2023-05-31 16:20:50 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:20:50 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:20:50 --> Utf8 Class Initialized
INFO - 2023-05-31 16:20:50 --> URI Class Initialized
INFO - 2023-05-31 16:20:50 --> Router Class Initialized
INFO - 2023-05-31 16:20:50 --> Output Class Initialized
INFO - 2023-05-31 16:20:50 --> Security Class Initialized
DEBUG - 2023-05-31 16:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:20:50 --> Input Class Initialized
INFO - 2023-05-31 16:20:50 --> Language Class Initialized
INFO - 2023-05-31 16:20:50 --> Loader Class Initialized
INFO - 2023-05-31 16:20:50 --> Helper loaded: url_helper
INFO - 2023-05-31 16:20:50 --> Helper loaded: file_helper
INFO - 2023-05-31 16:20:50 --> Helper loaded: html_helper
INFO - 2023-05-31 16:20:50 --> Helper loaded: text_helper
INFO - 2023-05-31 16:20:50 --> Helper loaded: form_helper
INFO - 2023-05-31 16:20:50 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:20:50 --> Helper loaded: security_helper
INFO - 2023-05-31 16:20:50 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:20:50 --> Database Driver Class Initialized
INFO - 2023-05-31 16:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:20:50 --> Parser Class Initialized
INFO - 2023-05-31 16:20:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:20:50 --> Pagination Class Initialized
INFO - 2023-05-31 16:20:50 --> Form Validation Class Initialized
INFO - 2023-05-31 16:20:50 --> Controller Class Initialized
INFO - 2023-05-31 16:20:50 --> Model Class Initialized
DEBUG - 2023-05-31 16:20:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:20:50 --> Model Class Initialized
INFO - 2023-05-31 16:20:50 --> Final output sent to browser
DEBUG - 2023-05-31 16:20:50 --> Total execution time: 0.0178
ERROR - 2023-05-31 16:20:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:20:50 --> Config Class Initialized
INFO - 2023-05-31 16:20:50 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:20:50 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:20:50 --> Utf8 Class Initialized
INFO - 2023-05-31 16:20:50 --> URI Class Initialized
DEBUG - 2023-05-31 16:20:50 --> No URI present. Default controller set.
INFO - 2023-05-31 16:20:50 --> Router Class Initialized
INFO - 2023-05-31 16:20:50 --> Output Class Initialized
INFO - 2023-05-31 16:20:50 --> Security Class Initialized
DEBUG - 2023-05-31 16:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:20:50 --> Input Class Initialized
INFO - 2023-05-31 16:20:50 --> Language Class Initialized
INFO - 2023-05-31 16:20:50 --> Loader Class Initialized
INFO - 2023-05-31 16:20:50 --> Helper loaded: url_helper
INFO - 2023-05-31 16:20:50 --> Helper loaded: file_helper
INFO - 2023-05-31 16:20:50 --> Helper loaded: html_helper
INFO - 2023-05-31 16:20:50 --> Helper loaded: text_helper
INFO - 2023-05-31 16:20:50 --> Helper loaded: form_helper
INFO - 2023-05-31 16:20:50 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:20:50 --> Helper loaded: security_helper
INFO - 2023-05-31 16:20:50 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:20:50 --> Database Driver Class Initialized
INFO - 2023-05-31 16:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:20:50 --> Parser Class Initialized
INFO - 2023-05-31 16:20:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:20:50 --> Pagination Class Initialized
INFO - 2023-05-31 16:20:50 --> Form Validation Class Initialized
INFO - 2023-05-31 16:20:50 --> Controller Class Initialized
INFO - 2023-05-31 16:20:50 --> Model Class Initialized
DEBUG - 2023-05-31 16:20:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:20:50 --> Model Class Initialized
DEBUG - 2023-05-31 16:20:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:20:50 --> Model Class Initialized
INFO - 2023-05-31 16:20:50 --> Model Class Initialized
INFO - 2023-05-31 16:20:50 --> Model Class Initialized
INFO - 2023-05-31 16:20:50 --> Model Class Initialized
DEBUG - 2023-05-31 16:20:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:20:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:20:50 --> Model Class Initialized
INFO - 2023-05-31 16:20:50 --> Model Class Initialized
INFO - 2023-05-31 16:20:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-31 16:20:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:20:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:20:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:20:50 --> Model Class Initialized
INFO - 2023-05-31 16:20:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:20:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:20:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:20:51 --> Final output sent to browser
DEBUG - 2023-05-31 16:20:51 --> Total execution time: 0.1631
ERROR - 2023-05-31 16:20:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:20:52 --> Config Class Initialized
INFO - 2023-05-31 16:20:52 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:20:52 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:20:52 --> Utf8 Class Initialized
INFO - 2023-05-31 16:20:52 --> URI Class Initialized
INFO - 2023-05-31 16:20:52 --> Router Class Initialized
INFO - 2023-05-31 16:20:52 --> Output Class Initialized
INFO - 2023-05-31 16:20:52 --> Security Class Initialized
DEBUG - 2023-05-31 16:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:20:52 --> Input Class Initialized
INFO - 2023-05-31 16:20:52 --> Language Class Initialized
INFO - 2023-05-31 16:20:52 --> Loader Class Initialized
INFO - 2023-05-31 16:20:52 --> Helper loaded: url_helper
INFO - 2023-05-31 16:20:52 --> Helper loaded: file_helper
INFO - 2023-05-31 16:20:52 --> Helper loaded: html_helper
INFO - 2023-05-31 16:20:52 --> Helper loaded: text_helper
INFO - 2023-05-31 16:20:52 --> Helper loaded: form_helper
INFO - 2023-05-31 16:20:52 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:20:52 --> Helper loaded: security_helper
INFO - 2023-05-31 16:20:52 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:20:52 --> Database Driver Class Initialized
INFO - 2023-05-31 16:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:20:52 --> Parser Class Initialized
INFO - 2023-05-31 16:20:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:20:52 --> Pagination Class Initialized
INFO - 2023-05-31 16:20:52 --> Form Validation Class Initialized
INFO - 2023-05-31 16:20:52 --> Controller Class Initialized
DEBUG - 2023-05-31 16:20:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:20:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:20:52 --> Model Class Initialized
INFO - 2023-05-31 16:20:52 --> Final output sent to browser
DEBUG - 2023-05-31 16:20:52 --> Total execution time: 0.0132
ERROR - 2023-05-31 16:21:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:21:05 --> Config Class Initialized
INFO - 2023-05-31 16:21:05 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:21:05 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:21:05 --> Utf8 Class Initialized
INFO - 2023-05-31 16:21:05 --> URI Class Initialized
DEBUG - 2023-05-31 16:21:05 --> No URI present. Default controller set.
INFO - 2023-05-31 16:21:05 --> Router Class Initialized
INFO - 2023-05-31 16:21:05 --> Output Class Initialized
INFO - 2023-05-31 16:21:05 --> Security Class Initialized
DEBUG - 2023-05-31 16:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:21:05 --> Input Class Initialized
INFO - 2023-05-31 16:21:05 --> Language Class Initialized
INFO - 2023-05-31 16:21:05 --> Loader Class Initialized
INFO - 2023-05-31 16:21:05 --> Helper loaded: url_helper
INFO - 2023-05-31 16:21:05 --> Helper loaded: file_helper
INFO - 2023-05-31 16:21:05 --> Helper loaded: html_helper
INFO - 2023-05-31 16:21:05 --> Helper loaded: text_helper
INFO - 2023-05-31 16:21:05 --> Helper loaded: form_helper
INFO - 2023-05-31 16:21:05 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:21:05 --> Helper loaded: security_helper
INFO - 2023-05-31 16:21:05 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:21:05 --> Database Driver Class Initialized
INFO - 2023-05-31 16:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:21:05 --> Parser Class Initialized
INFO - 2023-05-31 16:21:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:21:05 --> Pagination Class Initialized
INFO - 2023-05-31 16:21:05 --> Form Validation Class Initialized
INFO - 2023-05-31 16:21:05 --> Controller Class Initialized
INFO - 2023-05-31 16:21:05 --> Model Class Initialized
DEBUG - 2023-05-31 16:21:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-31 16:21:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:21:06 --> Config Class Initialized
INFO - 2023-05-31 16:21:06 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:21:06 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:21:06 --> Utf8 Class Initialized
INFO - 2023-05-31 16:21:06 --> URI Class Initialized
INFO - 2023-05-31 16:21:06 --> Router Class Initialized
INFO - 2023-05-31 16:21:06 --> Output Class Initialized
INFO - 2023-05-31 16:21:06 --> Security Class Initialized
DEBUG - 2023-05-31 16:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:21:06 --> Input Class Initialized
INFO - 2023-05-31 16:21:06 --> Language Class Initialized
INFO - 2023-05-31 16:21:06 --> Loader Class Initialized
INFO - 2023-05-31 16:21:06 --> Helper loaded: url_helper
INFO - 2023-05-31 16:21:06 --> Helper loaded: file_helper
INFO - 2023-05-31 16:21:06 --> Helper loaded: html_helper
INFO - 2023-05-31 16:21:06 --> Helper loaded: text_helper
INFO - 2023-05-31 16:21:06 --> Helper loaded: form_helper
INFO - 2023-05-31 16:21:06 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:21:06 --> Helper loaded: security_helper
INFO - 2023-05-31 16:21:06 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:21:06 --> Database Driver Class Initialized
INFO - 2023-05-31 16:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:21:06 --> Parser Class Initialized
INFO - 2023-05-31 16:21:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:21:06 --> Pagination Class Initialized
INFO - 2023-05-31 16:21:06 --> Form Validation Class Initialized
INFO - 2023-05-31 16:21:06 --> Controller Class Initialized
INFO - 2023-05-31 16:21:06 --> Model Class Initialized
DEBUG - 2023-05-31 16:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:21:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-31 16:21:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:21:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:21:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:21:06 --> Model Class Initialized
INFO - 2023-05-31 16:21:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:21:06 --> Final output sent to browser
DEBUG - 2023-05-31 16:21:06 --> Total execution time: 0.0292
ERROR - 2023-05-31 16:21:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:21:10 --> Config Class Initialized
INFO - 2023-05-31 16:21:10 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:21:10 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:21:10 --> Utf8 Class Initialized
INFO - 2023-05-31 16:21:10 --> URI Class Initialized
INFO - 2023-05-31 16:21:10 --> Router Class Initialized
INFO - 2023-05-31 16:21:10 --> Output Class Initialized
INFO - 2023-05-31 16:21:10 --> Security Class Initialized
DEBUG - 2023-05-31 16:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:21:10 --> Input Class Initialized
INFO - 2023-05-31 16:21:10 --> Language Class Initialized
INFO - 2023-05-31 16:21:10 --> Loader Class Initialized
INFO - 2023-05-31 16:21:10 --> Helper loaded: url_helper
INFO - 2023-05-31 16:21:10 --> Helper loaded: file_helper
INFO - 2023-05-31 16:21:10 --> Helper loaded: html_helper
INFO - 2023-05-31 16:21:10 --> Helper loaded: text_helper
INFO - 2023-05-31 16:21:10 --> Helper loaded: form_helper
INFO - 2023-05-31 16:21:10 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:21:10 --> Helper loaded: security_helper
INFO - 2023-05-31 16:21:10 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:21:10 --> Database Driver Class Initialized
INFO - 2023-05-31 16:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:21:10 --> Parser Class Initialized
INFO - 2023-05-31 16:21:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:21:10 --> Pagination Class Initialized
INFO - 2023-05-31 16:21:10 --> Form Validation Class Initialized
INFO - 2023-05-31 16:21:10 --> Controller Class Initialized
INFO - 2023-05-31 16:21:10 --> Model Class Initialized
DEBUG - 2023-05-31 16:21:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:21:10 --> Model Class Initialized
INFO - 2023-05-31 16:21:10 --> Final output sent to browser
DEBUG - 2023-05-31 16:21:10 --> Total execution time: 0.0167
ERROR - 2023-05-31 16:21:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:21:11 --> Config Class Initialized
INFO - 2023-05-31 16:21:11 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:21:11 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:21:11 --> Utf8 Class Initialized
INFO - 2023-05-31 16:21:11 --> URI Class Initialized
DEBUG - 2023-05-31 16:21:11 --> No URI present. Default controller set.
INFO - 2023-05-31 16:21:11 --> Router Class Initialized
INFO - 2023-05-31 16:21:11 --> Output Class Initialized
INFO - 2023-05-31 16:21:11 --> Security Class Initialized
DEBUG - 2023-05-31 16:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:21:11 --> Input Class Initialized
INFO - 2023-05-31 16:21:11 --> Language Class Initialized
INFO - 2023-05-31 16:21:11 --> Loader Class Initialized
INFO - 2023-05-31 16:21:11 --> Helper loaded: url_helper
INFO - 2023-05-31 16:21:11 --> Helper loaded: file_helper
INFO - 2023-05-31 16:21:11 --> Helper loaded: html_helper
INFO - 2023-05-31 16:21:11 --> Helper loaded: text_helper
INFO - 2023-05-31 16:21:11 --> Helper loaded: form_helper
INFO - 2023-05-31 16:21:11 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:21:11 --> Helper loaded: security_helper
INFO - 2023-05-31 16:21:11 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:21:11 --> Database Driver Class Initialized
INFO - 2023-05-31 16:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:21:11 --> Parser Class Initialized
INFO - 2023-05-31 16:21:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:21:11 --> Pagination Class Initialized
INFO - 2023-05-31 16:21:11 --> Form Validation Class Initialized
INFO - 2023-05-31 16:21:11 --> Controller Class Initialized
INFO - 2023-05-31 16:21:11 --> Model Class Initialized
DEBUG - 2023-05-31 16:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:21:11 --> Model Class Initialized
DEBUG - 2023-05-31 16:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:21:11 --> Model Class Initialized
INFO - 2023-05-31 16:21:11 --> Model Class Initialized
INFO - 2023-05-31 16:21:11 --> Model Class Initialized
INFO - 2023-05-31 16:21:11 --> Model Class Initialized
DEBUG - 2023-05-31 16:21:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:21:11 --> Model Class Initialized
INFO - 2023-05-31 16:21:11 --> Model Class Initialized
INFO - 2023-05-31 16:21:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-31 16:21:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:21:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:21:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:21:11 --> Model Class Initialized
INFO - 2023-05-31 16:21:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:21:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:21:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:21:11 --> Final output sent to browser
DEBUG - 2023-05-31 16:21:11 --> Total execution time: 0.0821
ERROR - 2023-05-31 16:21:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:21:14 --> Config Class Initialized
INFO - 2023-05-31 16:21:14 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:21:14 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:21:14 --> Utf8 Class Initialized
INFO - 2023-05-31 16:21:14 --> URI Class Initialized
DEBUG - 2023-05-31 16:21:14 --> No URI present. Default controller set.
INFO - 2023-05-31 16:21:14 --> Router Class Initialized
INFO - 2023-05-31 16:21:14 --> Output Class Initialized
INFO - 2023-05-31 16:21:14 --> Security Class Initialized
DEBUG - 2023-05-31 16:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:21:14 --> Input Class Initialized
INFO - 2023-05-31 16:21:14 --> Language Class Initialized
INFO - 2023-05-31 16:21:14 --> Loader Class Initialized
INFO - 2023-05-31 16:21:14 --> Helper loaded: url_helper
INFO - 2023-05-31 16:21:14 --> Helper loaded: file_helper
INFO - 2023-05-31 16:21:14 --> Helper loaded: html_helper
INFO - 2023-05-31 16:21:14 --> Helper loaded: text_helper
INFO - 2023-05-31 16:21:14 --> Helper loaded: form_helper
INFO - 2023-05-31 16:21:14 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:21:14 --> Helper loaded: security_helper
INFO - 2023-05-31 16:21:14 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:21:14 --> Database Driver Class Initialized
INFO - 2023-05-31 16:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:21:14 --> Parser Class Initialized
INFO - 2023-05-31 16:21:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:21:14 --> Pagination Class Initialized
INFO - 2023-05-31 16:21:14 --> Form Validation Class Initialized
INFO - 2023-05-31 16:21:14 --> Controller Class Initialized
INFO - 2023-05-31 16:21:14 --> Model Class Initialized
DEBUG - 2023-05-31 16:21:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:21:14 --> Model Class Initialized
DEBUG - 2023-05-31 16:21:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:21:14 --> Model Class Initialized
INFO - 2023-05-31 16:21:14 --> Model Class Initialized
INFO - 2023-05-31 16:21:14 --> Model Class Initialized
INFO - 2023-05-31 16:21:14 --> Model Class Initialized
DEBUG - 2023-05-31 16:21:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:21:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:21:14 --> Model Class Initialized
INFO - 2023-05-31 16:21:14 --> Model Class Initialized
INFO - 2023-05-31 16:21:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-31 16:21:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:21:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:21:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:21:14 --> Model Class Initialized
INFO - 2023-05-31 16:21:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:21:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:21:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:21:14 --> Final output sent to browser
DEBUG - 2023-05-31 16:21:14 --> Total execution time: 0.0725
ERROR - 2023-05-31 16:24:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:24:13 --> Config Class Initialized
INFO - 2023-05-31 16:24:13 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:24:13 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:24:13 --> Utf8 Class Initialized
INFO - 2023-05-31 16:24:13 --> URI Class Initialized
INFO - 2023-05-31 16:24:13 --> Router Class Initialized
INFO - 2023-05-31 16:24:13 --> Output Class Initialized
INFO - 2023-05-31 16:24:13 --> Security Class Initialized
DEBUG - 2023-05-31 16:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:24:13 --> Input Class Initialized
INFO - 2023-05-31 16:24:13 --> Language Class Initialized
INFO - 2023-05-31 16:24:13 --> Loader Class Initialized
INFO - 2023-05-31 16:24:13 --> Helper loaded: url_helper
INFO - 2023-05-31 16:24:13 --> Helper loaded: file_helper
INFO - 2023-05-31 16:24:13 --> Helper loaded: html_helper
INFO - 2023-05-31 16:24:13 --> Helper loaded: text_helper
INFO - 2023-05-31 16:24:13 --> Helper loaded: form_helper
INFO - 2023-05-31 16:24:13 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:24:13 --> Helper loaded: security_helper
INFO - 2023-05-31 16:24:13 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:24:13 --> Database Driver Class Initialized
INFO - 2023-05-31 16:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:24:13 --> Parser Class Initialized
INFO - 2023-05-31 16:24:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:24:13 --> Pagination Class Initialized
INFO - 2023-05-31 16:24:13 --> Form Validation Class Initialized
INFO - 2023-05-31 16:24:13 --> Controller Class Initialized
DEBUG - 2023-05-31 16:24:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:24:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:24:13 --> Model Class Initialized
DEBUG - 2023-05-31 16:24:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:24:13 --> Model Class Initialized
DEBUG - 2023-05-31 16:24:13 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:24:13 --> Model Class Initialized
INFO - 2023-05-31 16:24:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-05-31 16:24:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:24:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:24:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:24:14 --> Model Class Initialized
INFO - 2023-05-31 16:24:14 --> Model Class Initialized
INFO - 2023-05-31 16:24:14 --> Model Class Initialized
INFO - 2023-05-31 16:24:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:24:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:24:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:24:14 --> Final output sent to browser
DEBUG - 2023-05-31 16:24:14 --> Total execution time: 0.1395
ERROR - 2023-05-31 16:24:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:24:15 --> Config Class Initialized
INFO - 2023-05-31 16:24:15 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:24:15 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:24:15 --> Utf8 Class Initialized
INFO - 2023-05-31 16:24:15 --> URI Class Initialized
INFO - 2023-05-31 16:24:15 --> Router Class Initialized
INFO - 2023-05-31 16:24:15 --> Output Class Initialized
INFO - 2023-05-31 16:24:15 --> Security Class Initialized
DEBUG - 2023-05-31 16:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:24:15 --> Input Class Initialized
INFO - 2023-05-31 16:24:15 --> Language Class Initialized
INFO - 2023-05-31 16:24:15 --> Loader Class Initialized
INFO - 2023-05-31 16:24:15 --> Helper loaded: url_helper
INFO - 2023-05-31 16:24:15 --> Helper loaded: file_helper
INFO - 2023-05-31 16:24:15 --> Helper loaded: html_helper
INFO - 2023-05-31 16:24:15 --> Helper loaded: text_helper
INFO - 2023-05-31 16:24:15 --> Helper loaded: form_helper
INFO - 2023-05-31 16:24:15 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:24:15 --> Helper loaded: security_helper
INFO - 2023-05-31 16:24:15 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:24:15 --> Database Driver Class Initialized
INFO - 2023-05-31 16:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:24:15 --> Parser Class Initialized
INFO - 2023-05-31 16:24:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:24:15 --> Pagination Class Initialized
INFO - 2023-05-31 16:24:15 --> Form Validation Class Initialized
INFO - 2023-05-31 16:24:15 --> Controller Class Initialized
DEBUG - 2023-05-31 16:24:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:24:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:24:15 --> Model Class Initialized
DEBUG - 2023-05-31 16:24:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:24:15 --> Model Class Initialized
INFO - 2023-05-31 16:24:15 --> Final output sent to browser
DEBUG - 2023-05-31 16:24:15 --> Total execution time: 0.0302
ERROR - 2023-05-31 16:24:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:24:19 --> Config Class Initialized
INFO - 2023-05-31 16:24:19 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:24:19 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:24:19 --> Utf8 Class Initialized
INFO - 2023-05-31 16:24:19 --> URI Class Initialized
INFO - 2023-05-31 16:24:19 --> Router Class Initialized
INFO - 2023-05-31 16:24:19 --> Output Class Initialized
INFO - 2023-05-31 16:24:19 --> Security Class Initialized
DEBUG - 2023-05-31 16:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:24:19 --> Input Class Initialized
INFO - 2023-05-31 16:24:19 --> Language Class Initialized
INFO - 2023-05-31 16:24:19 --> Loader Class Initialized
INFO - 2023-05-31 16:24:19 --> Helper loaded: url_helper
INFO - 2023-05-31 16:24:19 --> Helper loaded: file_helper
INFO - 2023-05-31 16:24:19 --> Helper loaded: html_helper
INFO - 2023-05-31 16:24:19 --> Helper loaded: text_helper
INFO - 2023-05-31 16:24:19 --> Helper loaded: form_helper
INFO - 2023-05-31 16:24:19 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:24:19 --> Helper loaded: security_helper
INFO - 2023-05-31 16:24:19 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:24:19 --> Database Driver Class Initialized
INFO - 2023-05-31 16:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:24:19 --> Parser Class Initialized
INFO - 2023-05-31 16:24:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:24:19 --> Pagination Class Initialized
INFO - 2023-05-31 16:24:19 --> Form Validation Class Initialized
INFO - 2023-05-31 16:24:19 --> Controller Class Initialized
DEBUG - 2023-05-31 16:24:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:24:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:24:19 --> Model Class Initialized
DEBUG - 2023-05-31 16:24:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:24:19 --> Model Class Initialized
INFO - 2023-05-31 16:24:19 --> Final output sent to browser
DEBUG - 2023-05-31 16:24:19 --> Total execution time: 0.0992
ERROR - 2023-05-31 16:24:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-31 16:24:27 --> Config Class Initialized
INFO - 2023-05-31 16:24:27 --> Hooks Class Initialized
DEBUG - 2023-05-31 16:24:27 --> UTF-8 Support Enabled
INFO - 2023-05-31 16:24:27 --> Utf8 Class Initialized
INFO - 2023-05-31 16:24:27 --> URI Class Initialized
DEBUG - 2023-05-31 16:24:27 --> No URI present. Default controller set.
INFO - 2023-05-31 16:24:27 --> Router Class Initialized
INFO - 2023-05-31 16:24:27 --> Output Class Initialized
INFO - 2023-05-31 16:24:27 --> Security Class Initialized
DEBUG - 2023-05-31 16:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 16:24:27 --> Input Class Initialized
INFO - 2023-05-31 16:24:27 --> Language Class Initialized
INFO - 2023-05-31 16:24:27 --> Loader Class Initialized
INFO - 2023-05-31 16:24:27 --> Helper loaded: url_helper
INFO - 2023-05-31 16:24:27 --> Helper loaded: file_helper
INFO - 2023-05-31 16:24:27 --> Helper loaded: html_helper
INFO - 2023-05-31 16:24:27 --> Helper loaded: text_helper
INFO - 2023-05-31 16:24:27 --> Helper loaded: form_helper
INFO - 2023-05-31 16:24:27 --> Helper loaded: lang_helper
INFO - 2023-05-31 16:24:27 --> Helper loaded: security_helper
INFO - 2023-05-31 16:24:27 --> Helper loaded: cookie_helper
INFO - 2023-05-31 16:24:27 --> Database Driver Class Initialized
INFO - 2023-05-31 16:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-31 16:24:27 --> Parser Class Initialized
INFO - 2023-05-31 16:24:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-31 16:24:27 --> Pagination Class Initialized
INFO - 2023-05-31 16:24:27 --> Form Validation Class Initialized
INFO - 2023-05-31 16:24:27 --> Controller Class Initialized
INFO - 2023-05-31 16:24:27 --> Model Class Initialized
DEBUG - 2023-05-31 16:24:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:24:27 --> Model Class Initialized
DEBUG - 2023-05-31 16:24:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:24:27 --> Model Class Initialized
INFO - 2023-05-31 16:24:27 --> Model Class Initialized
INFO - 2023-05-31 16:24:27 --> Model Class Initialized
INFO - 2023-05-31 16:24:27 --> Model Class Initialized
DEBUG - 2023-05-31 16:24:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-31 16:24:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:24:27 --> Model Class Initialized
INFO - 2023-05-31 16:24:27 --> Model Class Initialized
INFO - 2023-05-31 16:24:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-31 16:24:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-31 16:24:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-31 16:24:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-31 16:24:27 --> Model Class Initialized
INFO - 2023-05-31 16:24:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-31 16:24:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-31 16:24:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-31 16:24:27 --> Final output sent to browser
DEBUG - 2023-05-31 16:24:27 --> Total execution time: 0.1581
