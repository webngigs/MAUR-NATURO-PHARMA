<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-03-11 05:34:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:34:21 --> Config Class Initialized
INFO - 2024-03-11 05:34:21 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:34:21 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:34:21 --> Utf8 Class Initialized
INFO - 2024-03-11 05:34:21 --> URI Class Initialized
DEBUG - 2024-03-11 05:34:21 --> No URI present. Default controller set.
INFO - 2024-03-11 05:34:21 --> Router Class Initialized
INFO - 2024-03-11 05:34:21 --> Output Class Initialized
INFO - 2024-03-11 05:34:21 --> Security Class Initialized
DEBUG - 2024-03-11 05:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:34:21 --> Input Class Initialized
INFO - 2024-03-11 05:34:21 --> Language Class Initialized
INFO - 2024-03-11 05:34:21 --> Loader Class Initialized
INFO - 2024-03-11 05:34:21 --> Helper loaded: url_helper
INFO - 2024-03-11 05:34:21 --> Helper loaded: file_helper
INFO - 2024-03-11 05:34:21 --> Helper loaded: html_helper
INFO - 2024-03-11 05:34:21 --> Helper loaded: text_helper
INFO - 2024-03-11 05:34:21 --> Helper loaded: form_helper
INFO - 2024-03-11 05:34:21 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:34:21 --> Helper loaded: security_helper
INFO - 2024-03-11 05:34:21 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:34:21 --> Database Driver Class Initialized
INFO - 2024-03-11 05:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:34:21 --> Parser Class Initialized
INFO - 2024-03-11 05:34:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:34:21 --> Pagination Class Initialized
INFO - 2024-03-11 05:34:21 --> Form Validation Class Initialized
INFO - 2024-03-11 05:34:21 --> Controller Class Initialized
INFO - 2024-03-11 05:34:21 --> Model Class Initialized
DEBUG - 2024-03-11 05:34:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-11 05:34:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:34:22 --> Config Class Initialized
INFO - 2024-03-11 05:34:22 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:34:22 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:34:22 --> Utf8 Class Initialized
INFO - 2024-03-11 05:34:22 --> URI Class Initialized
INFO - 2024-03-11 05:34:22 --> Router Class Initialized
INFO - 2024-03-11 05:34:22 --> Output Class Initialized
INFO - 2024-03-11 05:34:22 --> Security Class Initialized
DEBUG - 2024-03-11 05:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:34:22 --> Input Class Initialized
INFO - 2024-03-11 05:34:22 --> Language Class Initialized
INFO - 2024-03-11 05:34:22 --> Loader Class Initialized
INFO - 2024-03-11 05:34:22 --> Helper loaded: url_helper
INFO - 2024-03-11 05:34:22 --> Helper loaded: file_helper
INFO - 2024-03-11 05:34:22 --> Helper loaded: html_helper
INFO - 2024-03-11 05:34:22 --> Helper loaded: text_helper
INFO - 2024-03-11 05:34:22 --> Helper loaded: form_helper
INFO - 2024-03-11 05:34:22 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:34:22 --> Helper loaded: security_helper
INFO - 2024-03-11 05:34:22 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:34:22 --> Database Driver Class Initialized
INFO - 2024-03-11 05:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:34:22 --> Parser Class Initialized
INFO - 2024-03-11 05:34:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:34:22 --> Pagination Class Initialized
INFO - 2024-03-11 05:34:22 --> Form Validation Class Initialized
INFO - 2024-03-11 05:34:22 --> Controller Class Initialized
INFO - 2024-03-11 05:34:22 --> Model Class Initialized
DEBUG - 2024-03-11 05:34:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:34:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-11 05:34:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:34:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 05:34:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 05:34:22 --> Model Class Initialized
INFO - 2024-03-11 05:34:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 05:34:22 --> Final output sent to browser
DEBUG - 2024-03-11 05:34:22 --> Total execution time: 0.0399
ERROR - 2024-03-11 05:34:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:34:33 --> Config Class Initialized
INFO - 2024-03-11 05:34:33 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:34:33 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:34:33 --> Utf8 Class Initialized
INFO - 2024-03-11 05:34:33 --> URI Class Initialized
INFO - 2024-03-11 05:34:33 --> Router Class Initialized
INFO - 2024-03-11 05:34:33 --> Output Class Initialized
INFO - 2024-03-11 05:34:33 --> Security Class Initialized
DEBUG - 2024-03-11 05:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:34:33 --> Input Class Initialized
INFO - 2024-03-11 05:34:33 --> Language Class Initialized
INFO - 2024-03-11 05:34:33 --> Loader Class Initialized
INFO - 2024-03-11 05:34:33 --> Helper loaded: url_helper
INFO - 2024-03-11 05:34:33 --> Helper loaded: file_helper
INFO - 2024-03-11 05:34:33 --> Helper loaded: html_helper
INFO - 2024-03-11 05:34:33 --> Helper loaded: text_helper
INFO - 2024-03-11 05:34:33 --> Helper loaded: form_helper
INFO - 2024-03-11 05:34:33 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:34:33 --> Helper loaded: security_helper
INFO - 2024-03-11 05:34:33 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:34:33 --> Database Driver Class Initialized
INFO - 2024-03-11 05:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:34:33 --> Parser Class Initialized
INFO - 2024-03-11 05:34:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:34:33 --> Pagination Class Initialized
INFO - 2024-03-11 05:34:33 --> Form Validation Class Initialized
INFO - 2024-03-11 05:34:33 --> Controller Class Initialized
INFO - 2024-03-11 05:34:33 --> Model Class Initialized
DEBUG - 2024-03-11 05:34:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:34:33 --> Model Class Initialized
INFO - 2024-03-11 05:34:33 --> Final output sent to browser
DEBUG - 2024-03-11 05:34:33 --> Total execution time: 0.0260
ERROR - 2024-03-11 05:34:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:34:33 --> Config Class Initialized
INFO - 2024-03-11 05:34:33 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:34:33 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:34:33 --> Utf8 Class Initialized
INFO - 2024-03-11 05:34:33 --> URI Class Initialized
DEBUG - 2024-03-11 05:34:33 --> No URI present. Default controller set.
INFO - 2024-03-11 05:34:33 --> Router Class Initialized
INFO - 2024-03-11 05:34:33 --> Output Class Initialized
INFO - 2024-03-11 05:34:33 --> Security Class Initialized
DEBUG - 2024-03-11 05:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:34:33 --> Input Class Initialized
INFO - 2024-03-11 05:34:33 --> Language Class Initialized
INFO - 2024-03-11 05:34:33 --> Loader Class Initialized
INFO - 2024-03-11 05:34:33 --> Helper loaded: url_helper
INFO - 2024-03-11 05:34:33 --> Helper loaded: file_helper
INFO - 2024-03-11 05:34:33 --> Helper loaded: html_helper
INFO - 2024-03-11 05:34:33 --> Helper loaded: text_helper
INFO - 2024-03-11 05:34:33 --> Helper loaded: form_helper
INFO - 2024-03-11 05:34:33 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:34:33 --> Helper loaded: security_helper
INFO - 2024-03-11 05:34:33 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:34:33 --> Database Driver Class Initialized
INFO - 2024-03-11 05:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:34:33 --> Parser Class Initialized
INFO - 2024-03-11 05:34:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:34:33 --> Pagination Class Initialized
INFO - 2024-03-11 05:34:33 --> Form Validation Class Initialized
INFO - 2024-03-11 05:34:33 --> Controller Class Initialized
INFO - 2024-03-11 05:34:33 --> Model Class Initialized
DEBUG - 2024-03-11 05:34:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:34:33 --> Model Class Initialized
DEBUG - 2024-03-11 05:34:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:34:33 --> Model Class Initialized
INFO - 2024-03-11 05:34:33 --> Model Class Initialized
INFO - 2024-03-11 05:34:33 --> Model Class Initialized
INFO - 2024-03-11 05:34:33 --> Model Class Initialized
DEBUG - 2024-03-11 05:34:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 05:34:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:34:33 --> Model Class Initialized
INFO - 2024-03-11 05:34:33 --> Model Class Initialized
INFO - 2024-03-11 05:34:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-11 05:34:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:34:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 05:34:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 05:34:33 --> Model Class Initialized
INFO - 2024-03-11 05:34:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 05:34:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 05:34:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 05:34:33 --> Final output sent to browser
DEBUG - 2024-03-11 05:34:33 --> Total execution time: 0.2556
ERROR - 2024-03-11 05:34:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:34:39 --> Config Class Initialized
INFO - 2024-03-11 05:34:39 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:34:39 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:34:39 --> Utf8 Class Initialized
INFO - 2024-03-11 05:34:39 --> URI Class Initialized
INFO - 2024-03-11 05:34:39 --> Router Class Initialized
INFO - 2024-03-11 05:34:39 --> Output Class Initialized
INFO - 2024-03-11 05:34:39 --> Security Class Initialized
DEBUG - 2024-03-11 05:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:34:39 --> Input Class Initialized
INFO - 2024-03-11 05:34:39 --> Language Class Initialized
INFO - 2024-03-11 05:34:39 --> Loader Class Initialized
INFO - 2024-03-11 05:34:39 --> Helper loaded: url_helper
INFO - 2024-03-11 05:34:39 --> Helper loaded: file_helper
INFO - 2024-03-11 05:34:39 --> Helper loaded: html_helper
INFO - 2024-03-11 05:34:39 --> Helper loaded: text_helper
INFO - 2024-03-11 05:34:39 --> Helper loaded: form_helper
INFO - 2024-03-11 05:34:39 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:34:39 --> Helper loaded: security_helper
INFO - 2024-03-11 05:34:39 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:34:39 --> Database Driver Class Initialized
INFO - 2024-03-11 05:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:34:39 --> Parser Class Initialized
INFO - 2024-03-11 05:34:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:34:39 --> Pagination Class Initialized
INFO - 2024-03-11 05:34:39 --> Form Validation Class Initialized
INFO - 2024-03-11 05:34:39 --> Controller Class Initialized
INFO - 2024-03-11 05:34:39 --> Model Class Initialized
DEBUG - 2024-03-11 05:34:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 05:34:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:34:39 --> Model Class Initialized
DEBUG - 2024-03-11 05:34:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:34:39 --> Model Class Initialized
INFO - 2024-03-11 05:34:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-03-11 05:34:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:34:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 05:34:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 05:34:39 --> Model Class Initialized
INFO - 2024-03-11 05:34:39 --> Model Class Initialized
INFO - 2024-03-11 05:34:39 --> Model Class Initialized
INFO - 2024-03-11 05:34:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 05:34:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 05:34:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 05:34:40 --> Final output sent to browser
DEBUG - 2024-03-11 05:34:40 --> Total execution time: 0.1966
ERROR - 2024-03-11 05:34:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:34:48 --> Config Class Initialized
INFO - 2024-03-11 05:34:48 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:34:48 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:34:48 --> Utf8 Class Initialized
INFO - 2024-03-11 05:34:48 --> URI Class Initialized
INFO - 2024-03-11 05:34:48 --> Router Class Initialized
INFO - 2024-03-11 05:34:48 --> Output Class Initialized
INFO - 2024-03-11 05:34:48 --> Security Class Initialized
DEBUG - 2024-03-11 05:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:34:48 --> Input Class Initialized
INFO - 2024-03-11 05:34:48 --> Language Class Initialized
INFO - 2024-03-11 05:34:48 --> Loader Class Initialized
INFO - 2024-03-11 05:34:48 --> Helper loaded: url_helper
INFO - 2024-03-11 05:34:48 --> Helper loaded: file_helper
INFO - 2024-03-11 05:34:48 --> Helper loaded: html_helper
INFO - 2024-03-11 05:34:48 --> Helper loaded: text_helper
INFO - 2024-03-11 05:34:48 --> Helper loaded: form_helper
INFO - 2024-03-11 05:34:48 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:34:48 --> Helper loaded: security_helper
INFO - 2024-03-11 05:34:48 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:34:48 --> Database Driver Class Initialized
INFO - 2024-03-11 05:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:34:48 --> Parser Class Initialized
INFO - 2024-03-11 05:34:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:34:48 --> Pagination Class Initialized
INFO - 2024-03-11 05:34:48 --> Form Validation Class Initialized
INFO - 2024-03-11 05:34:48 --> Controller Class Initialized
INFO - 2024-03-11 05:34:48 --> Model Class Initialized
DEBUG - 2024-03-11 05:34:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:34:48 --> Final output sent to browser
DEBUG - 2024-03-11 05:34:48 --> Total execution time: 0.0194
ERROR - 2024-03-11 05:35:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:35:06 --> Config Class Initialized
INFO - 2024-03-11 05:35:06 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:35:06 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:35:06 --> Utf8 Class Initialized
INFO - 2024-03-11 05:35:06 --> URI Class Initialized
INFO - 2024-03-11 05:35:06 --> Router Class Initialized
INFO - 2024-03-11 05:35:06 --> Output Class Initialized
INFO - 2024-03-11 05:35:06 --> Security Class Initialized
DEBUG - 2024-03-11 05:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:35:06 --> Input Class Initialized
INFO - 2024-03-11 05:35:06 --> Language Class Initialized
INFO - 2024-03-11 05:35:06 --> Loader Class Initialized
INFO - 2024-03-11 05:35:06 --> Helper loaded: url_helper
INFO - 2024-03-11 05:35:06 --> Helper loaded: file_helper
INFO - 2024-03-11 05:35:06 --> Helper loaded: html_helper
INFO - 2024-03-11 05:35:06 --> Helper loaded: text_helper
INFO - 2024-03-11 05:35:06 --> Helper loaded: form_helper
INFO - 2024-03-11 05:35:06 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:35:06 --> Helper loaded: security_helper
INFO - 2024-03-11 05:35:06 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:35:06 --> Database Driver Class Initialized
INFO - 2024-03-11 05:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:35:06 --> Parser Class Initialized
INFO - 2024-03-11 05:35:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:35:06 --> Pagination Class Initialized
INFO - 2024-03-11 05:35:06 --> Form Validation Class Initialized
INFO - 2024-03-11 05:35:06 --> Controller Class Initialized
INFO - 2024-03-11 05:35:06 --> Model Class Initialized
DEBUG - 2024-03-11 05:35:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:35:06 --> Final output sent to browser
DEBUG - 2024-03-11 05:35:06 --> Total execution time: 0.0188
ERROR - 2024-03-11 05:35:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:35:07 --> Config Class Initialized
INFO - 2024-03-11 05:35:07 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:35:07 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:35:07 --> Utf8 Class Initialized
INFO - 2024-03-11 05:35:07 --> URI Class Initialized
INFO - 2024-03-11 05:35:07 --> Router Class Initialized
INFO - 2024-03-11 05:35:07 --> Output Class Initialized
INFO - 2024-03-11 05:35:07 --> Security Class Initialized
DEBUG - 2024-03-11 05:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:35:07 --> Input Class Initialized
INFO - 2024-03-11 05:35:07 --> Language Class Initialized
INFO - 2024-03-11 05:35:07 --> Loader Class Initialized
INFO - 2024-03-11 05:35:07 --> Helper loaded: url_helper
INFO - 2024-03-11 05:35:07 --> Helper loaded: file_helper
INFO - 2024-03-11 05:35:07 --> Helper loaded: html_helper
INFO - 2024-03-11 05:35:07 --> Helper loaded: text_helper
INFO - 2024-03-11 05:35:07 --> Helper loaded: form_helper
INFO - 2024-03-11 05:35:07 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:35:07 --> Helper loaded: security_helper
INFO - 2024-03-11 05:35:07 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:35:07 --> Database Driver Class Initialized
INFO - 2024-03-11 05:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:35:07 --> Parser Class Initialized
INFO - 2024-03-11 05:35:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:35:07 --> Pagination Class Initialized
INFO - 2024-03-11 05:35:07 --> Form Validation Class Initialized
INFO - 2024-03-11 05:35:07 --> Controller Class Initialized
INFO - 2024-03-11 05:35:07 --> Model Class Initialized
DEBUG - 2024-03-11 05:35:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:35:07 --> Final output sent to browser
DEBUG - 2024-03-11 05:35:07 --> Total execution time: 0.0171
ERROR - 2024-03-11 05:35:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:35:14 --> Config Class Initialized
INFO - 2024-03-11 05:35:14 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:35:14 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:35:14 --> Utf8 Class Initialized
INFO - 2024-03-11 05:35:14 --> URI Class Initialized
INFO - 2024-03-11 05:35:14 --> Router Class Initialized
INFO - 2024-03-11 05:35:14 --> Output Class Initialized
INFO - 2024-03-11 05:35:14 --> Security Class Initialized
DEBUG - 2024-03-11 05:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:35:14 --> Input Class Initialized
INFO - 2024-03-11 05:35:14 --> Language Class Initialized
INFO - 2024-03-11 05:35:14 --> Loader Class Initialized
INFO - 2024-03-11 05:35:14 --> Helper loaded: url_helper
INFO - 2024-03-11 05:35:14 --> Helper loaded: file_helper
INFO - 2024-03-11 05:35:14 --> Helper loaded: html_helper
INFO - 2024-03-11 05:35:14 --> Helper loaded: text_helper
INFO - 2024-03-11 05:35:14 --> Helper loaded: form_helper
INFO - 2024-03-11 05:35:14 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:35:14 --> Helper loaded: security_helper
INFO - 2024-03-11 05:35:14 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:35:14 --> Database Driver Class Initialized
INFO - 2024-03-11 05:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:35:14 --> Parser Class Initialized
INFO - 2024-03-11 05:35:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:35:14 --> Pagination Class Initialized
INFO - 2024-03-11 05:35:14 --> Form Validation Class Initialized
INFO - 2024-03-11 05:35:14 --> Controller Class Initialized
INFO - 2024-03-11 05:35:14 --> Model Class Initialized
DEBUG - 2024-03-11 05:35:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-11 05:35:14 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-03-11 05:35:14 --> Final output sent to browser
DEBUG - 2024-03-11 05:35:14 --> Total execution time: 0.0180
ERROR - 2024-03-11 05:35:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:35:17 --> Config Class Initialized
INFO - 2024-03-11 05:35:17 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:35:17 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:35:17 --> Utf8 Class Initialized
INFO - 2024-03-11 05:35:17 --> URI Class Initialized
INFO - 2024-03-11 05:35:17 --> Router Class Initialized
INFO - 2024-03-11 05:35:17 --> Output Class Initialized
INFO - 2024-03-11 05:35:17 --> Security Class Initialized
DEBUG - 2024-03-11 05:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:35:17 --> Input Class Initialized
INFO - 2024-03-11 05:35:17 --> Language Class Initialized
INFO - 2024-03-11 05:35:17 --> Loader Class Initialized
INFO - 2024-03-11 05:35:17 --> Helper loaded: url_helper
INFO - 2024-03-11 05:35:17 --> Helper loaded: file_helper
INFO - 2024-03-11 05:35:17 --> Helper loaded: html_helper
INFO - 2024-03-11 05:35:17 --> Helper loaded: text_helper
INFO - 2024-03-11 05:35:17 --> Helper loaded: form_helper
INFO - 2024-03-11 05:35:17 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:35:17 --> Helper loaded: security_helper
INFO - 2024-03-11 05:35:17 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:35:17 --> Database Driver Class Initialized
INFO - 2024-03-11 05:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:35:17 --> Parser Class Initialized
INFO - 2024-03-11 05:35:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:35:17 --> Pagination Class Initialized
INFO - 2024-03-11 05:35:17 --> Form Validation Class Initialized
INFO - 2024-03-11 05:35:17 --> Controller Class Initialized
INFO - 2024-03-11 05:35:17 --> Model Class Initialized
DEBUG - 2024-03-11 05:35:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:35:17 --> Final output sent to browser
DEBUG - 2024-03-11 05:35:17 --> Total execution time: 0.0157
ERROR - 2024-03-11 05:35:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:35:28 --> Config Class Initialized
INFO - 2024-03-11 05:35:28 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:35:28 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:35:28 --> Utf8 Class Initialized
INFO - 2024-03-11 05:35:28 --> URI Class Initialized
INFO - 2024-03-11 05:35:28 --> Router Class Initialized
INFO - 2024-03-11 05:35:28 --> Output Class Initialized
INFO - 2024-03-11 05:35:28 --> Security Class Initialized
DEBUG - 2024-03-11 05:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:35:28 --> Input Class Initialized
INFO - 2024-03-11 05:35:28 --> Language Class Initialized
INFO - 2024-03-11 05:35:28 --> Loader Class Initialized
INFO - 2024-03-11 05:35:28 --> Helper loaded: url_helper
INFO - 2024-03-11 05:35:28 --> Helper loaded: file_helper
INFO - 2024-03-11 05:35:28 --> Helper loaded: html_helper
INFO - 2024-03-11 05:35:28 --> Helper loaded: text_helper
INFO - 2024-03-11 05:35:28 --> Helper loaded: form_helper
INFO - 2024-03-11 05:35:28 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:35:28 --> Helper loaded: security_helper
INFO - 2024-03-11 05:35:28 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:35:28 --> Database Driver Class Initialized
INFO - 2024-03-11 05:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:35:28 --> Parser Class Initialized
INFO - 2024-03-11 05:35:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:35:28 --> Pagination Class Initialized
INFO - 2024-03-11 05:35:28 --> Form Validation Class Initialized
INFO - 2024-03-11 05:35:28 --> Controller Class Initialized
INFO - 2024-03-11 05:35:28 --> Final output sent to browser
DEBUG - 2024-03-11 05:35:28 --> Total execution time: 0.0181
ERROR - 2024-03-11 05:35:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:35:35 --> Config Class Initialized
INFO - 2024-03-11 05:35:35 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:35:35 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:35:35 --> Utf8 Class Initialized
INFO - 2024-03-11 05:35:35 --> URI Class Initialized
INFO - 2024-03-11 05:35:35 --> Router Class Initialized
INFO - 2024-03-11 05:35:35 --> Output Class Initialized
INFO - 2024-03-11 05:35:35 --> Security Class Initialized
DEBUG - 2024-03-11 05:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:35:35 --> Input Class Initialized
INFO - 2024-03-11 05:35:35 --> Language Class Initialized
INFO - 2024-03-11 05:35:35 --> Loader Class Initialized
INFO - 2024-03-11 05:35:35 --> Helper loaded: url_helper
INFO - 2024-03-11 05:35:35 --> Helper loaded: file_helper
INFO - 2024-03-11 05:35:35 --> Helper loaded: html_helper
INFO - 2024-03-11 05:35:35 --> Helper loaded: text_helper
INFO - 2024-03-11 05:35:35 --> Helper loaded: form_helper
INFO - 2024-03-11 05:35:35 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:35:35 --> Helper loaded: security_helper
INFO - 2024-03-11 05:35:35 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:35:35 --> Database Driver Class Initialized
INFO - 2024-03-11 05:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:35:35 --> Parser Class Initialized
INFO - 2024-03-11 05:35:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:35:35 --> Pagination Class Initialized
INFO - 2024-03-11 05:35:35 --> Form Validation Class Initialized
INFO - 2024-03-11 05:35:35 --> Controller Class Initialized
INFO - 2024-03-11 05:35:35 --> Model Class Initialized
DEBUG - 2024-03-11 05:35:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:35:35 --> Final output sent to browser
DEBUG - 2024-03-11 05:35:35 --> Total execution time: 0.0147
ERROR - 2024-03-11 05:35:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:35:43 --> Config Class Initialized
INFO - 2024-03-11 05:35:43 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:35:43 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:35:43 --> Utf8 Class Initialized
INFO - 2024-03-11 05:35:43 --> URI Class Initialized
INFO - 2024-03-11 05:35:43 --> Router Class Initialized
INFO - 2024-03-11 05:35:43 --> Output Class Initialized
INFO - 2024-03-11 05:35:43 --> Security Class Initialized
DEBUG - 2024-03-11 05:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:35:43 --> Input Class Initialized
INFO - 2024-03-11 05:35:43 --> Language Class Initialized
INFO - 2024-03-11 05:35:43 --> Loader Class Initialized
INFO - 2024-03-11 05:35:43 --> Helper loaded: url_helper
INFO - 2024-03-11 05:35:43 --> Helper loaded: file_helper
INFO - 2024-03-11 05:35:43 --> Helper loaded: html_helper
INFO - 2024-03-11 05:35:43 --> Helper loaded: text_helper
INFO - 2024-03-11 05:35:43 --> Helper loaded: form_helper
INFO - 2024-03-11 05:35:43 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:35:43 --> Helper loaded: security_helper
INFO - 2024-03-11 05:35:43 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:35:43 --> Database Driver Class Initialized
INFO - 2024-03-11 05:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:35:43 --> Parser Class Initialized
INFO - 2024-03-11 05:35:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:35:43 --> Pagination Class Initialized
INFO - 2024-03-11 05:35:43 --> Form Validation Class Initialized
INFO - 2024-03-11 05:35:43 --> Controller Class Initialized
INFO - 2024-03-11 05:35:43 --> Final output sent to browser
DEBUG - 2024-03-11 05:35:43 --> Total execution time: 0.0139
ERROR - 2024-03-11 05:35:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:35:50 --> Config Class Initialized
INFO - 2024-03-11 05:35:50 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:35:50 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:35:50 --> Utf8 Class Initialized
INFO - 2024-03-11 05:35:50 --> URI Class Initialized
INFO - 2024-03-11 05:35:50 --> Router Class Initialized
INFO - 2024-03-11 05:35:50 --> Output Class Initialized
INFO - 2024-03-11 05:35:50 --> Security Class Initialized
DEBUG - 2024-03-11 05:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:35:50 --> Input Class Initialized
INFO - 2024-03-11 05:35:50 --> Language Class Initialized
INFO - 2024-03-11 05:35:50 --> Loader Class Initialized
INFO - 2024-03-11 05:35:50 --> Helper loaded: url_helper
INFO - 2024-03-11 05:35:50 --> Helper loaded: file_helper
INFO - 2024-03-11 05:35:50 --> Helper loaded: html_helper
INFO - 2024-03-11 05:35:50 --> Helper loaded: text_helper
INFO - 2024-03-11 05:35:50 --> Helper loaded: form_helper
INFO - 2024-03-11 05:35:50 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:35:50 --> Helper loaded: security_helper
INFO - 2024-03-11 05:35:50 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:35:50 --> Database Driver Class Initialized
INFO - 2024-03-11 05:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:35:50 --> Parser Class Initialized
INFO - 2024-03-11 05:35:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:35:50 --> Pagination Class Initialized
INFO - 2024-03-11 05:35:50 --> Form Validation Class Initialized
INFO - 2024-03-11 05:35:50 --> Controller Class Initialized
INFO - 2024-03-11 05:35:50 --> Model Class Initialized
DEBUG - 2024-03-11 05:35:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 05:35:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:35:50 --> Model Class Initialized
DEBUG - 2024-03-11 05:35:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:35:50 --> Model Class Initialized
INFO - 2024-03-11 05:35:51 --> Final output sent to browser
DEBUG - 2024-03-11 05:35:51 --> Total execution time: 0.1351
ERROR - 2024-03-11 05:35:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:35:52 --> Config Class Initialized
INFO - 2024-03-11 05:35:52 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:35:52 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:35:52 --> Utf8 Class Initialized
INFO - 2024-03-11 05:35:52 --> URI Class Initialized
INFO - 2024-03-11 05:35:52 --> Router Class Initialized
INFO - 2024-03-11 05:35:52 --> Output Class Initialized
INFO - 2024-03-11 05:35:52 --> Security Class Initialized
DEBUG - 2024-03-11 05:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:35:52 --> Input Class Initialized
INFO - 2024-03-11 05:35:52 --> Language Class Initialized
INFO - 2024-03-11 05:35:52 --> Loader Class Initialized
INFO - 2024-03-11 05:35:52 --> Helper loaded: url_helper
INFO - 2024-03-11 05:35:52 --> Helper loaded: file_helper
INFO - 2024-03-11 05:35:52 --> Helper loaded: html_helper
INFO - 2024-03-11 05:35:52 --> Helper loaded: text_helper
INFO - 2024-03-11 05:35:52 --> Helper loaded: form_helper
INFO - 2024-03-11 05:35:52 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:35:52 --> Helper loaded: security_helper
INFO - 2024-03-11 05:35:52 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:35:52 --> Database Driver Class Initialized
INFO - 2024-03-11 05:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:35:52 --> Parser Class Initialized
INFO - 2024-03-11 05:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:35:52 --> Pagination Class Initialized
INFO - 2024-03-11 05:35:52 --> Form Validation Class Initialized
INFO - 2024-03-11 05:35:52 --> Controller Class Initialized
INFO - 2024-03-11 05:35:52 --> Model Class Initialized
DEBUG - 2024-03-11 05:35:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 05:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:35:52 --> Model Class Initialized
DEBUG - 2024-03-11 05:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:35:52 --> Model Class Initialized
INFO - 2024-03-11 05:35:52 --> Final output sent to browser
DEBUG - 2024-03-11 05:35:52 --> Total execution time: 0.1363
ERROR - 2024-03-11 05:35:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:35:52 --> Config Class Initialized
INFO - 2024-03-11 05:35:52 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:35:52 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:35:52 --> Utf8 Class Initialized
INFO - 2024-03-11 05:35:52 --> URI Class Initialized
INFO - 2024-03-11 05:35:52 --> Router Class Initialized
INFO - 2024-03-11 05:35:52 --> Output Class Initialized
INFO - 2024-03-11 05:35:52 --> Security Class Initialized
DEBUG - 2024-03-11 05:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:35:52 --> Input Class Initialized
INFO - 2024-03-11 05:35:52 --> Language Class Initialized
INFO - 2024-03-11 05:35:52 --> Loader Class Initialized
INFO - 2024-03-11 05:35:52 --> Helper loaded: url_helper
INFO - 2024-03-11 05:35:52 --> Helper loaded: file_helper
INFO - 2024-03-11 05:35:52 --> Helper loaded: html_helper
INFO - 2024-03-11 05:35:52 --> Helper loaded: text_helper
INFO - 2024-03-11 05:35:52 --> Helper loaded: form_helper
INFO - 2024-03-11 05:35:52 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:35:52 --> Helper loaded: security_helper
INFO - 2024-03-11 05:35:52 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:35:52 --> Database Driver Class Initialized
INFO - 2024-03-11 05:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:35:52 --> Parser Class Initialized
INFO - 2024-03-11 05:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:35:52 --> Pagination Class Initialized
INFO - 2024-03-11 05:35:52 --> Form Validation Class Initialized
INFO - 2024-03-11 05:35:52 --> Controller Class Initialized
INFO - 2024-03-11 05:35:52 --> Model Class Initialized
DEBUG - 2024-03-11 05:35:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 05:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:35:52 --> Model Class Initialized
DEBUG - 2024-03-11 05:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:35:52 --> Model Class Initialized
INFO - 2024-03-11 05:35:52 --> Final output sent to browser
DEBUG - 2024-03-11 05:35:52 --> Total execution time: 0.1380
ERROR - 2024-03-11 05:35:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:35:57 --> Config Class Initialized
INFO - 2024-03-11 05:35:57 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:35:57 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:35:57 --> Utf8 Class Initialized
INFO - 2024-03-11 05:35:57 --> URI Class Initialized
INFO - 2024-03-11 05:35:57 --> Router Class Initialized
INFO - 2024-03-11 05:35:57 --> Output Class Initialized
INFO - 2024-03-11 05:35:57 --> Security Class Initialized
DEBUG - 2024-03-11 05:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:35:57 --> Input Class Initialized
INFO - 2024-03-11 05:35:57 --> Language Class Initialized
INFO - 2024-03-11 05:35:57 --> Loader Class Initialized
INFO - 2024-03-11 05:35:57 --> Helper loaded: url_helper
INFO - 2024-03-11 05:35:57 --> Helper loaded: file_helper
INFO - 2024-03-11 05:35:57 --> Helper loaded: html_helper
INFO - 2024-03-11 05:35:57 --> Helper loaded: text_helper
INFO - 2024-03-11 05:35:57 --> Helper loaded: form_helper
INFO - 2024-03-11 05:35:57 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:35:57 --> Helper loaded: security_helper
INFO - 2024-03-11 05:35:57 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:35:57 --> Database Driver Class Initialized
INFO - 2024-03-11 05:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:35:57 --> Parser Class Initialized
INFO - 2024-03-11 05:35:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:35:57 --> Pagination Class Initialized
INFO - 2024-03-11 05:35:57 --> Form Validation Class Initialized
INFO - 2024-03-11 05:35:57 --> Controller Class Initialized
INFO - 2024-03-11 05:35:57 --> Model Class Initialized
DEBUG - 2024-03-11 05:35:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 05:35:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:35:57 --> Model Class Initialized
INFO - 2024-03-11 05:35:57 --> Model Class Initialized
INFO - 2024-03-11 05:35:57 --> Final output sent to browser
DEBUG - 2024-03-11 05:35:57 --> Total execution time: 0.0203
ERROR - 2024-03-11 05:35:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:35:58 --> Config Class Initialized
INFO - 2024-03-11 05:35:58 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:35:58 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:35:58 --> Utf8 Class Initialized
INFO - 2024-03-11 05:35:58 --> URI Class Initialized
INFO - 2024-03-11 05:35:58 --> Router Class Initialized
INFO - 2024-03-11 05:35:58 --> Output Class Initialized
INFO - 2024-03-11 05:35:58 --> Security Class Initialized
DEBUG - 2024-03-11 05:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:35:58 --> Input Class Initialized
INFO - 2024-03-11 05:35:58 --> Language Class Initialized
INFO - 2024-03-11 05:35:58 --> Loader Class Initialized
INFO - 2024-03-11 05:35:58 --> Helper loaded: url_helper
INFO - 2024-03-11 05:35:58 --> Helper loaded: file_helper
INFO - 2024-03-11 05:35:58 --> Helper loaded: html_helper
INFO - 2024-03-11 05:35:58 --> Helper loaded: text_helper
INFO - 2024-03-11 05:35:58 --> Helper loaded: form_helper
INFO - 2024-03-11 05:35:58 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:35:58 --> Helper loaded: security_helper
INFO - 2024-03-11 05:35:58 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:35:58 --> Database Driver Class Initialized
INFO - 2024-03-11 05:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:35:58 --> Parser Class Initialized
INFO - 2024-03-11 05:35:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:35:58 --> Pagination Class Initialized
INFO - 2024-03-11 05:35:58 --> Form Validation Class Initialized
INFO - 2024-03-11 05:35:58 --> Controller Class Initialized
INFO - 2024-03-11 05:35:58 --> Model Class Initialized
DEBUG - 2024-03-11 05:35:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 05:35:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:35:58 --> Model Class Initialized
INFO - 2024-03-11 05:35:58 --> Final output sent to browser
DEBUG - 2024-03-11 05:35:58 --> Total execution time: 0.0160
ERROR - 2024-03-11 05:35:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:35:59 --> Config Class Initialized
INFO - 2024-03-11 05:35:59 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:35:59 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:35:59 --> Utf8 Class Initialized
INFO - 2024-03-11 05:35:59 --> URI Class Initialized
INFO - 2024-03-11 05:35:59 --> Router Class Initialized
INFO - 2024-03-11 05:35:59 --> Output Class Initialized
INFO - 2024-03-11 05:35:59 --> Security Class Initialized
DEBUG - 2024-03-11 05:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:35:59 --> Input Class Initialized
INFO - 2024-03-11 05:35:59 --> Language Class Initialized
INFO - 2024-03-11 05:35:59 --> Loader Class Initialized
INFO - 2024-03-11 05:35:59 --> Helper loaded: url_helper
INFO - 2024-03-11 05:35:59 --> Helper loaded: file_helper
INFO - 2024-03-11 05:35:59 --> Helper loaded: html_helper
INFO - 2024-03-11 05:35:59 --> Helper loaded: text_helper
INFO - 2024-03-11 05:35:59 --> Helper loaded: form_helper
INFO - 2024-03-11 05:35:59 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:35:59 --> Helper loaded: security_helper
INFO - 2024-03-11 05:35:59 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:35:59 --> Database Driver Class Initialized
INFO - 2024-03-11 05:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:35:59 --> Parser Class Initialized
INFO - 2024-03-11 05:35:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:35:59 --> Pagination Class Initialized
INFO - 2024-03-11 05:35:59 --> Form Validation Class Initialized
INFO - 2024-03-11 05:35:59 --> Controller Class Initialized
INFO - 2024-03-11 05:35:59 --> Model Class Initialized
DEBUG - 2024-03-11 05:35:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 05:35:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:35:59 --> Model Class Initialized
INFO - 2024-03-11 05:35:59 --> Final output sent to browser
DEBUG - 2024-03-11 05:35:59 --> Total execution time: 0.0168
ERROR - 2024-03-11 05:36:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:36:18 --> Config Class Initialized
INFO - 2024-03-11 05:36:18 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:36:18 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:36:18 --> Utf8 Class Initialized
INFO - 2024-03-11 05:36:18 --> URI Class Initialized
INFO - 2024-03-11 05:36:18 --> Router Class Initialized
INFO - 2024-03-11 05:36:18 --> Output Class Initialized
INFO - 2024-03-11 05:36:18 --> Security Class Initialized
DEBUG - 2024-03-11 05:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:36:18 --> Input Class Initialized
INFO - 2024-03-11 05:36:18 --> Language Class Initialized
INFO - 2024-03-11 05:36:18 --> Loader Class Initialized
INFO - 2024-03-11 05:36:18 --> Helper loaded: url_helper
INFO - 2024-03-11 05:36:18 --> Helper loaded: file_helper
INFO - 2024-03-11 05:36:18 --> Helper loaded: html_helper
INFO - 2024-03-11 05:36:18 --> Helper loaded: text_helper
INFO - 2024-03-11 05:36:18 --> Helper loaded: form_helper
INFO - 2024-03-11 05:36:18 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:36:18 --> Helper loaded: security_helper
INFO - 2024-03-11 05:36:18 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:36:18 --> Database Driver Class Initialized
INFO - 2024-03-11 05:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:36:18 --> Parser Class Initialized
INFO - 2024-03-11 05:36:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:36:18 --> Pagination Class Initialized
INFO - 2024-03-11 05:36:18 --> Form Validation Class Initialized
INFO - 2024-03-11 05:36:18 --> Controller Class Initialized
INFO - 2024-03-11 05:36:18 --> Model Class Initialized
DEBUG - 2024-03-11 05:36:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 05:36:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:36:18 --> Model Class Initialized
DEBUG - 2024-03-11 05:36:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:36:18 --> Model Class Initialized
INFO - 2024-03-11 05:36:18 --> Email Class Initialized
DEBUG - 2024-03-11 05:36:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:36:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-03-11 05:36:18 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-03-11 05:36:18 --> Language file loaded: language/english/email_lang.php
INFO - 2024-03-11 05:36:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-03-11 05:36:19 --> Final output sent to browser
DEBUG - 2024-03-11 05:36:19 --> Total execution time: 0.3803
ERROR - 2024-03-11 05:36:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:36:21 --> Config Class Initialized
INFO - 2024-03-11 05:36:21 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:36:21 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:36:21 --> Utf8 Class Initialized
INFO - 2024-03-11 05:36:21 --> URI Class Initialized
INFO - 2024-03-11 05:36:21 --> Router Class Initialized
INFO - 2024-03-11 05:36:21 --> Output Class Initialized
INFO - 2024-03-11 05:36:21 --> Security Class Initialized
DEBUG - 2024-03-11 05:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:36:21 --> Input Class Initialized
INFO - 2024-03-11 05:36:21 --> Language Class Initialized
INFO - 2024-03-11 05:36:21 --> Loader Class Initialized
INFO - 2024-03-11 05:36:21 --> Helper loaded: url_helper
INFO - 2024-03-11 05:36:21 --> Helper loaded: file_helper
INFO - 2024-03-11 05:36:21 --> Helper loaded: html_helper
INFO - 2024-03-11 05:36:21 --> Helper loaded: text_helper
INFO - 2024-03-11 05:36:21 --> Helper loaded: form_helper
INFO - 2024-03-11 05:36:21 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:36:21 --> Helper loaded: security_helper
INFO - 2024-03-11 05:36:21 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:36:21 --> Database Driver Class Initialized
INFO - 2024-03-11 05:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:36:21 --> Parser Class Initialized
INFO - 2024-03-11 05:36:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:36:21 --> Pagination Class Initialized
INFO - 2024-03-11 05:36:21 --> Form Validation Class Initialized
INFO - 2024-03-11 05:36:21 --> Controller Class Initialized
INFO - 2024-03-11 05:36:21 --> Model Class Initialized
DEBUG - 2024-03-11 05:36:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 05:36:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:36:21 --> Model Class Initialized
DEBUG - 2024-03-11 05:36:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:36:21 --> Model Class Initialized
INFO - 2024-03-11 05:36:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-03-11 05:36:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:36:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 05:36:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 05:36:21 --> Model Class Initialized
INFO - 2024-03-11 05:36:21 --> Model Class Initialized
INFO - 2024-03-11 05:36:21 --> Model Class Initialized
INFO - 2024-03-11 05:36:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 05:36:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 05:36:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 05:36:21 --> Final output sent to browser
DEBUG - 2024-03-11 05:36:21 --> Total execution time: 0.1874
ERROR - 2024-03-11 05:36:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:36:25 --> Config Class Initialized
INFO - 2024-03-11 05:36:25 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:36:25 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:36:25 --> Utf8 Class Initialized
INFO - 2024-03-11 05:36:25 --> URI Class Initialized
DEBUG - 2024-03-11 05:36:25 --> No URI present. Default controller set.
INFO - 2024-03-11 05:36:25 --> Router Class Initialized
INFO - 2024-03-11 05:36:25 --> Output Class Initialized
INFO - 2024-03-11 05:36:25 --> Security Class Initialized
DEBUG - 2024-03-11 05:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:36:25 --> Input Class Initialized
INFO - 2024-03-11 05:36:25 --> Language Class Initialized
INFO - 2024-03-11 05:36:25 --> Loader Class Initialized
INFO - 2024-03-11 05:36:25 --> Helper loaded: url_helper
INFO - 2024-03-11 05:36:25 --> Helper loaded: file_helper
INFO - 2024-03-11 05:36:25 --> Helper loaded: html_helper
INFO - 2024-03-11 05:36:25 --> Helper loaded: text_helper
INFO - 2024-03-11 05:36:25 --> Helper loaded: form_helper
INFO - 2024-03-11 05:36:25 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:36:25 --> Helper loaded: security_helper
INFO - 2024-03-11 05:36:25 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:36:25 --> Database Driver Class Initialized
INFO - 2024-03-11 05:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:36:25 --> Parser Class Initialized
INFO - 2024-03-11 05:36:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:36:25 --> Pagination Class Initialized
INFO - 2024-03-11 05:36:25 --> Form Validation Class Initialized
INFO - 2024-03-11 05:36:25 --> Controller Class Initialized
INFO - 2024-03-11 05:36:25 --> Model Class Initialized
DEBUG - 2024-03-11 05:36:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:36:25 --> Model Class Initialized
DEBUG - 2024-03-11 05:36:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:36:25 --> Model Class Initialized
INFO - 2024-03-11 05:36:25 --> Model Class Initialized
INFO - 2024-03-11 05:36:25 --> Model Class Initialized
INFO - 2024-03-11 05:36:25 --> Model Class Initialized
DEBUG - 2024-03-11 05:36:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 05:36:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:36:25 --> Model Class Initialized
INFO - 2024-03-11 05:36:25 --> Model Class Initialized
INFO - 2024-03-11 05:36:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-11 05:36:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:36:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 05:36:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 05:36:25 --> Model Class Initialized
INFO - 2024-03-11 05:36:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 05:36:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 05:36:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 05:36:25 --> Final output sent to browser
DEBUG - 2024-03-11 05:36:25 --> Total execution time: 0.2538
ERROR - 2024-03-11 05:36:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:36:38 --> Config Class Initialized
INFO - 2024-03-11 05:36:38 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:36:38 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:36:38 --> Utf8 Class Initialized
INFO - 2024-03-11 05:36:38 --> URI Class Initialized
INFO - 2024-03-11 05:36:38 --> Router Class Initialized
INFO - 2024-03-11 05:36:38 --> Output Class Initialized
INFO - 2024-03-11 05:36:38 --> Security Class Initialized
DEBUG - 2024-03-11 05:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:36:38 --> Input Class Initialized
INFO - 2024-03-11 05:36:38 --> Language Class Initialized
INFO - 2024-03-11 05:36:38 --> Loader Class Initialized
INFO - 2024-03-11 05:36:38 --> Helper loaded: url_helper
INFO - 2024-03-11 05:36:38 --> Helper loaded: file_helper
INFO - 2024-03-11 05:36:38 --> Helper loaded: html_helper
INFO - 2024-03-11 05:36:38 --> Helper loaded: text_helper
INFO - 2024-03-11 05:36:38 --> Helper loaded: form_helper
INFO - 2024-03-11 05:36:38 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:36:38 --> Helper loaded: security_helper
INFO - 2024-03-11 05:36:38 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:36:38 --> Database Driver Class Initialized
INFO - 2024-03-11 05:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:36:38 --> Parser Class Initialized
INFO - 2024-03-11 05:36:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:36:38 --> Pagination Class Initialized
INFO - 2024-03-11 05:36:38 --> Form Validation Class Initialized
INFO - 2024-03-11 05:36:38 --> Controller Class Initialized
INFO - 2024-03-11 05:36:38 --> Model Class Initialized
DEBUG - 2024-03-11 05:36:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 05:36:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:36:38 --> Model Class Initialized
DEBUG - 2024-03-11 05:36:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:36:38 --> Model Class Initialized
INFO - 2024-03-11 05:36:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-11 05:36:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:36:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 05:36:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 05:36:38 --> Model Class Initialized
INFO - 2024-03-11 05:36:38 --> Model Class Initialized
INFO - 2024-03-11 05:36:38 --> Model Class Initialized
INFO - 2024-03-11 05:36:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 05:36:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 05:36:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 05:36:38 --> Final output sent to browser
DEBUG - 2024-03-11 05:36:38 --> Total execution time: 0.1624
ERROR - 2024-03-11 05:36:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:36:39 --> Config Class Initialized
INFO - 2024-03-11 05:36:39 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:36:39 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:36:39 --> Utf8 Class Initialized
INFO - 2024-03-11 05:36:39 --> URI Class Initialized
INFO - 2024-03-11 05:36:39 --> Router Class Initialized
INFO - 2024-03-11 05:36:39 --> Output Class Initialized
INFO - 2024-03-11 05:36:39 --> Security Class Initialized
DEBUG - 2024-03-11 05:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:36:39 --> Input Class Initialized
INFO - 2024-03-11 05:36:39 --> Language Class Initialized
INFO - 2024-03-11 05:36:39 --> Loader Class Initialized
INFO - 2024-03-11 05:36:39 --> Helper loaded: url_helper
INFO - 2024-03-11 05:36:39 --> Helper loaded: file_helper
INFO - 2024-03-11 05:36:39 --> Helper loaded: html_helper
INFO - 2024-03-11 05:36:39 --> Helper loaded: text_helper
INFO - 2024-03-11 05:36:39 --> Helper loaded: form_helper
INFO - 2024-03-11 05:36:39 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:36:39 --> Helper loaded: security_helper
INFO - 2024-03-11 05:36:39 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:36:39 --> Database Driver Class Initialized
INFO - 2024-03-11 05:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:36:39 --> Parser Class Initialized
INFO - 2024-03-11 05:36:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:36:39 --> Pagination Class Initialized
INFO - 2024-03-11 05:36:39 --> Form Validation Class Initialized
INFO - 2024-03-11 05:36:39 --> Controller Class Initialized
INFO - 2024-03-11 05:36:39 --> Model Class Initialized
DEBUG - 2024-03-11 05:36:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 05:36:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:36:39 --> Model Class Initialized
DEBUG - 2024-03-11 05:36:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:36:39 --> Model Class Initialized
INFO - 2024-03-11 05:36:39 --> Final output sent to browser
DEBUG - 2024-03-11 05:36:39 --> Total execution time: 0.0425
ERROR - 2024-03-11 05:36:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:36:47 --> Config Class Initialized
INFO - 2024-03-11 05:36:47 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:36:47 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:36:47 --> Utf8 Class Initialized
INFO - 2024-03-11 05:36:47 --> URI Class Initialized
INFO - 2024-03-11 05:36:47 --> Router Class Initialized
INFO - 2024-03-11 05:36:47 --> Output Class Initialized
INFO - 2024-03-11 05:36:47 --> Security Class Initialized
DEBUG - 2024-03-11 05:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:36:47 --> Input Class Initialized
INFO - 2024-03-11 05:36:47 --> Language Class Initialized
INFO - 2024-03-11 05:36:47 --> Loader Class Initialized
INFO - 2024-03-11 05:36:47 --> Helper loaded: url_helper
INFO - 2024-03-11 05:36:47 --> Helper loaded: file_helper
INFO - 2024-03-11 05:36:47 --> Helper loaded: html_helper
INFO - 2024-03-11 05:36:47 --> Helper loaded: text_helper
INFO - 2024-03-11 05:36:47 --> Helper loaded: form_helper
INFO - 2024-03-11 05:36:47 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:36:47 --> Helper loaded: security_helper
INFO - 2024-03-11 05:36:47 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:36:47 --> Database Driver Class Initialized
INFO - 2024-03-11 05:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:36:47 --> Parser Class Initialized
INFO - 2024-03-11 05:36:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:36:47 --> Pagination Class Initialized
INFO - 2024-03-11 05:36:47 --> Form Validation Class Initialized
INFO - 2024-03-11 05:36:47 --> Controller Class Initialized
INFO - 2024-03-11 05:36:47 --> Model Class Initialized
DEBUG - 2024-03-11 05:36:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 05:36:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:36:47 --> Model Class Initialized
DEBUG - 2024-03-11 05:36:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:36:47 --> Model Class Initialized
DEBUG - 2024-03-11 05:36:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:36:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-03-11 05:36:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:36:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 05:36:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 05:36:47 --> Model Class Initialized
INFO - 2024-03-11 05:36:47 --> Model Class Initialized
INFO - 2024-03-11 05:36:47 --> Model Class Initialized
INFO - 2024-03-11 05:36:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 05:36:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 05:36:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 05:36:48 --> Final output sent to browser
DEBUG - 2024-03-11 05:36:48 --> Total execution time: 0.1711
ERROR - 2024-03-11 05:36:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:36:57 --> Config Class Initialized
INFO - 2024-03-11 05:36:57 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:36:57 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:36:57 --> Utf8 Class Initialized
INFO - 2024-03-11 05:36:57 --> URI Class Initialized
INFO - 2024-03-11 05:36:57 --> Router Class Initialized
INFO - 2024-03-11 05:36:57 --> Output Class Initialized
INFO - 2024-03-11 05:36:57 --> Security Class Initialized
DEBUG - 2024-03-11 05:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:36:57 --> Input Class Initialized
INFO - 2024-03-11 05:36:57 --> Language Class Initialized
INFO - 2024-03-11 05:36:57 --> Loader Class Initialized
INFO - 2024-03-11 05:36:57 --> Helper loaded: url_helper
INFO - 2024-03-11 05:36:57 --> Helper loaded: file_helper
INFO - 2024-03-11 05:36:57 --> Helper loaded: html_helper
INFO - 2024-03-11 05:36:57 --> Helper loaded: text_helper
INFO - 2024-03-11 05:36:57 --> Helper loaded: form_helper
INFO - 2024-03-11 05:36:57 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:36:57 --> Helper loaded: security_helper
INFO - 2024-03-11 05:36:57 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:36:57 --> Database Driver Class Initialized
INFO - 2024-03-11 05:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:36:57 --> Parser Class Initialized
INFO - 2024-03-11 05:36:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:36:57 --> Pagination Class Initialized
INFO - 2024-03-11 05:36:57 --> Form Validation Class Initialized
INFO - 2024-03-11 05:36:57 --> Controller Class Initialized
INFO - 2024-03-11 05:36:57 --> Model Class Initialized
DEBUG - 2024-03-11 05:36:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 05:36:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:36:57 --> Model Class Initialized
DEBUG - 2024-03-11 05:36:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:36:57 --> Model Class Initialized
INFO - 2024-03-11 05:36:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-11 05:36:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:36:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 05:36:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 05:36:57 --> Model Class Initialized
INFO - 2024-03-11 05:36:57 --> Model Class Initialized
INFO - 2024-03-11 05:36:57 --> Model Class Initialized
INFO - 2024-03-11 05:36:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 05:36:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 05:36:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 05:36:57 --> Final output sent to browser
DEBUG - 2024-03-11 05:36:57 --> Total execution time: 0.1571
ERROR - 2024-03-11 05:36:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:36:58 --> Config Class Initialized
INFO - 2024-03-11 05:36:58 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:36:58 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:36:58 --> Utf8 Class Initialized
INFO - 2024-03-11 05:36:58 --> URI Class Initialized
INFO - 2024-03-11 05:36:58 --> Router Class Initialized
INFO - 2024-03-11 05:36:58 --> Output Class Initialized
INFO - 2024-03-11 05:36:58 --> Security Class Initialized
DEBUG - 2024-03-11 05:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:36:58 --> Input Class Initialized
INFO - 2024-03-11 05:36:58 --> Language Class Initialized
INFO - 2024-03-11 05:36:58 --> Loader Class Initialized
INFO - 2024-03-11 05:36:58 --> Helper loaded: url_helper
INFO - 2024-03-11 05:36:58 --> Helper loaded: file_helper
INFO - 2024-03-11 05:36:58 --> Helper loaded: html_helper
INFO - 2024-03-11 05:36:58 --> Helper loaded: text_helper
INFO - 2024-03-11 05:36:58 --> Helper loaded: form_helper
INFO - 2024-03-11 05:36:58 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:36:58 --> Helper loaded: security_helper
INFO - 2024-03-11 05:36:58 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:36:58 --> Database Driver Class Initialized
INFO - 2024-03-11 05:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:36:58 --> Parser Class Initialized
INFO - 2024-03-11 05:36:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:36:58 --> Pagination Class Initialized
INFO - 2024-03-11 05:36:58 --> Form Validation Class Initialized
INFO - 2024-03-11 05:36:58 --> Controller Class Initialized
INFO - 2024-03-11 05:36:58 --> Model Class Initialized
DEBUG - 2024-03-11 05:36:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 05:36:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:36:58 --> Model Class Initialized
DEBUG - 2024-03-11 05:36:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:36:58 --> Model Class Initialized
INFO - 2024-03-11 05:36:58 --> Final output sent to browser
DEBUG - 2024-03-11 05:36:58 --> Total execution time: 0.0443
ERROR - 2024-03-11 05:36:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:36:59 --> Config Class Initialized
INFO - 2024-03-11 05:36:59 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:36:59 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:36:59 --> Utf8 Class Initialized
INFO - 2024-03-11 05:36:59 --> URI Class Initialized
DEBUG - 2024-03-11 05:36:59 --> No URI present. Default controller set.
INFO - 2024-03-11 05:36:59 --> Router Class Initialized
INFO - 2024-03-11 05:36:59 --> Output Class Initialized
INFO - 2024-03-11 05:36:59 --> Security Class Initialized
DEBUG - 2024-03-11 05:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:36:59 --> Input Class Initialized
INFO - 2024-03-11 05:36:59 --> Language Class Initialized
INFO - 2024-03-11 05:36:59 --> Loader Class Initialized
INFO - 2024-03-11 05:36:59 --> Helper loaded: url_helper
INFO - 2024-03-11 05:36:59 --> Helper loaded: file_helper
INFO - 2024-03-11 05:36:59 --> Helper loaded: html_helper
INFO - 2024-03-11 05:36:59 --> Helper loaded: text_helper
INFO - 2024-03-11 05:36:59 --> Helper loaded: form_helper
INFO - 2024-03-11 05:36:59 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:36:59 --> Helper loaded: security_helper
INFO - 2024-03-11 05:36:59 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:36:59 --> Database Driver Class Initialized
INFO - 2024-03-11 05:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:36:59 --> Parser Class Initialized
INFO - 2024-03-11 05:36:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:36:59 --> Pagination Class Initialized
INFO - 2024-03-11 05:36:59 --> Form Validation Class Initialized
INFO - 2024-03-11 05:36:59 --> Controller Class Initialized
INFO - 2024-03-11 05:36:59 --> Model Class Initialized
DEBUG - 2024-03-11 05:36:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:36:59 --> Model Class Initialized
DEBUG - 2024-03-11 05:36:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:36:59 --> Model Class Initialized
INFO - 2024-03-11 05:36:59 --> Model Class Initialized
INFO - 2024-03-11 05:36:59 --> Model Class Initialized
INFO - 2024-03-11 05:36:59 --> Model Class Initialized
DEBUG - 2024-03-11 05:36:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 05:36:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:36:59 --> Model Class Initialized
INFO - 2024-03-11 05:36:59 --> Model Class Initialized
INFO - 2024-03-11 05:37:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-11 05:37:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:37:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 05:37:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 05:37:00 --> Model Class Initialized
INFO - 2024-03-11 05:37:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 05:37:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 05:37:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 05:37:00 --> Final output sent to browser
DEBUG - 2024-03-11 05:37:00 --> Total execution time: 0.2493
ERROR - 2024-03-11 05:37:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:37:21 --> Config Class Initialized
INFO - 2024-03-11 05:37:21 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:37:21 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:37:21 --> Utf8 Class Initialized
INFO - 2024-03-11 05:37:21 --> URI Class Initialized
INFO - 2024-03-11 05:37:21 --> Router Class Initialized
INFO - 2024-03-11 05:37:21 --> Output Class Initialized
INFO - 2024-03-11 05:37:21 --> Security Class Initialized
DEBUG - 2024-03-11 05:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:37:21 --> Input Class Initialized
INFO - 2024-03-11 05:37:21 --> Language Class Initialized
INFO - 2024-03-11 05:37:21 --> Loader Class Initialized
INFO - 2024-03-11 05:37:21 --> Helper loaded: url_helper
INFO - 2024-03-11 05:37:21 --> Helper loaded: file_helper
INFO - 2024-03-11 05:37:21 --> Helper loaded: html_helper
INFO - 2024-03-11 05:37:21 --> Helper loaded: text_helper
INFO - 2024-03-11 05:37:21 --> Helper loaded: form_helper
INFO - 2024-03-11 05:37:21 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:37:21 --> Helper loaded: security_helper
INFO - 2024-03-11 05:37:21 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:37:21 --> Database Driver Class Initialized
INFO - 2024-03-11 05:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:37:21 --> Parser Class Initialized
INFO - 2024-03-11 05:37:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:37:21 --> Pagination Class Initialized
INFO - 2024-03-11 05:37:21 --> Form Validation Class Initialized
INFO - 2024-03-11 05:37:21 --> Controller Class Initialized
INFO - 2024-03-11 05:37:21 --> Model Class Initialized
DEBUG - 2024-03-11 05:37:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:37:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-11 05:37:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:37:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 05:37:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 05:37:21 --> Model Class Initialized
INFO - 2024-03-11 05:37:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 05:37:21 --> Final output sent to browser
DEBUG - 2024-03-11 05:37:21 --> Total execution time: 0.0353
ERROR - 2024-03-11 05:37:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 05:37:21 --> Config Class Initialized
INFO - 2024-03-11 05:37:21 --> Hooks Class Initialized
DEBUG - 2024-03-11 05:37:21 --> UTF-8 Support Enabled
INFO - 2024-03-11 05:37:21 --> Utf8 Class Initialized
INFO - 2024-03-11 05:37:21 --> URI Class Initialized
INFO - 2024-03-11 05:37:21 --> Router Class Initialized
INFO - 2024-03-11 05:37:21 --> Output Class Initialized
INFO - 2024-03-11 05:37:21 --> Security Class Initialized
DEBUG - 2024-03-11 05:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 05:37:21 --> Input Class Initialized
INFO - 2024-03-11 05:37:21 --> Language Class Initialized
INFO - 2024-03-11 05:37:21 --> Loader Class Initialized
INFO - 2024-03-11 05:37:21 --> Helper loaded: url_helper
INFO - 2024-03-11 05:37:21 --> Helper loaded: file_helper
INFO - 2024-03-11 05:37:21 --> Helper loaded: html_helper
INFO - 2024-03-11 05:37:21 --> Helper loaded: text_helper
INFO - 2024-03-11 05:37:21 --> Helper loaded: form_helper
INFO - 2024-03-11 05:37:21 --> Helper loaded: lang_helper
INFO - 2024-03-11 05:37:21 --> Helper loaded: security_helper
INFO - 2024-03-11 05:37:21 --> Helper loaded: cookie_helper
INFO - 2024-03-11 05:37:21 --> Database Driver Class Initialized
INFO - 2024-03-11 05:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 05:37:21 --> Parser Class Initialized
INFO - 2024-03-11 05:37:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 05:37:21 --> Pagination Class Initialized
INFO - 2024-03-11 05:37:21 --> Form Validation Class Initialized
INFO - 2024-03-11 05:37:21 --> Controller Class Initialized
INFO - 2024-03-11 05:37:21 --> Model Class Initialized
DEBUG - 2024-03-11 05:37:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:37:21 --> Model Class Initialized
DEBUG - 2024-03-11 05:37:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:37:21 --> Model Class Initialized
INFO - 2024-03-11 05:37:21 --> Model Class Initialized
INFO - 2024-03-11 05:37:21 --> Model Class Initialized
INFO - 2024-03-11 05:37:21 --> Model Class Initialized
DEBUG - 2024-03-11 05:37:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 05:37:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:37:21 --> Model Class Initialized
INFO - 2024-03-11 05:37:21 --> Model Class Initialized
INFO - 2024-03-11 05:37:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-11 05:37:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 05:37:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 05:37:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 05:37:21 --> Model Class Initialized
INFO - 2024-03-11 05:37:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 05:37:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 05:37:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 05:37:22 --> Final output sent to browser
DEBUG - 2024-03-11 05:37:22 --> Total execution time: 0.2480
ERROR - 2024-03-11 06:12:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:12:33 --> Config Class Initialized
INFO - 2024-03-11 06:12:33 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:12:33 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:12:33 --> Utf8 Class Initialized
INFO - 2024-03-11 06:12:33 --> URI Class Initialized
DEBUG - 2024-03-11 06:12:33 --> No URI present. Default controller set.
INFO - 2024-03-11 06:12:33 --> Router Class Initialized
INFO - 2024-03-11 06:12:33 --> Output Class Initialized
INFO - 2024-03-11 06:12:33 --> Security Class Initialized
DEBUG - 2024-03-11 06:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:12:33 --> Input Class Initialized
INFO - 2024-03-11 06:12:33 --> Language Class Initialized
INFO - 2024-03-11 06:12:33 --> Loader Class Initialized
INFO - 2024-03-11 06:12:33 --> Helper loaded: url_helper
INFO - 2024-03-11 06:12:33 --> Helper loaded: file_helper
INFO - 2024-03-11 06:12:33 --> Helper loaded: html_helper
INFO - 2024-03-11 06:12:33 --> Helper loaded: text_helper
INFO - 2024-03-11 06:12:33 --> Helper loaded: form_helper
INFO - 2024-03-11 06:12:33 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:12:33 --> Helper loaded: security_helper
INFO - 2024-03-11 06:12:33 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:12:33 --> Database Driver Class Initialized
INFO - 2024-03-11 06:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:12:33 --> Parser Class Initialized
INFO - 2024-03-11 06:12:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:12:33 --> Pagination Class Initialized
INFO - 2024-03-11 06:12:33 --> Form Validation Class Initialized
INFO - 2024-03-11 06:12:33 --> Controller Class Initialized
INFO - 2024-03-11 06:12:33 --> Model Class Initialized
DEBUG - 2024-03-11 06:12:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-11 06:12:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:12:34 --> Config Class Initialized
INFO - 2024-03-11 06:12:34 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:12:34 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:12:34 --> Utf8 Class Initialized
INFO - 2024-03-11 06:12:34 --> URI Class Initialized
INFO - 2024-03-11 06:12:34 --> Router Class Initialized
INFO - 2024-03-11 06:12:34 --> Output Class Initialized
INFO - 2024-03-11 06:12:34 --> Security Class Initialized
DEBUG - 2024-03-11 06:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:12:34 --> Input Class Initialized
INFO - 2024-03-11 06:12:34 --> Language Class Initialized
INFO - 2024-03-11 06:12:34 --> Loader Class Initialized
INFO - 2024-03-11 06:12:34 --> Helper loaded: url_helper
INFO - 2024-03-11 06:12:34 --> Helper loaded: file_helper
INFO - 2024-03-11 06:12:34 --> Helper loaded: html_helper
INFO - 2024-03-11 06:12:34 --> Helper loaded: text_helper
INFO - 2024-03-11 06:12:34 --> Helper loaded: form_helper
INFO - 2024-03-11 06:12:34 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:12:34 --> Helper loaded: security_helper
INFO - 2024-03-11 06:12:34 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:12:34 --> Database Driver Class Initialized
INFO - 2024-03-11 06:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:12:34 --> Parser Class Initialized
INFO - 2024-03-11 06:12:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:12:34 --> Pagination Class Initialized
INFO - 2024-03-11 06:12:34 --> Form Validation Class Initialized
INFO - 2024-03-11 06:12:34 --> Controller Class Initialized
INFO - 2024-03-11 06:12:34 --> Model Class Initialized
DEBUG - 2024-03-11 06:12:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:12:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-11 06:12:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:12:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 06:12:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 06:12:34 --> Model Class Initialized
INFO - 2024-03-11 06:12:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 06:12:34 --> Final output sent to browser
DEBUG - 2024-03-11 06:12:34 --> Total execution time: 0.0310
ERROR - 2024-03-11 06:12:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:12:43 --> Config Class Initialized
INFO - 2024-03-11 06:12:43 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:12:43 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:12:43 --> Utf8 Class Initialized
INFO - 2024-03-11 06:12:43 --> URI Class Initialized
INFO - 2024-03-11 06:12:43 --> Router Class Initialized
INFO - 2024-03-11 06:12:43 --> Output Class Initialized
INFO - 2024-03-11 06:12:43 --> Security Class Initialized
DEBUG - 2024-03-11 06:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:12:43 --> Input Class Initialized
INFO - 2024-03-11 06:12:43 --> Language Class Initialized
INFO - 2024-03-11 06:12:43 --> Loader Class Initialized
INFO - 2024-03-11 06:12:43 --> Helper loaded: url_helper
INFO - 2024-03-11 06:12:43 --> Helper loaded: file_helper
INFO - 2024-03-11 06:12:43 --> Helper loaded: html_helper
INFO - 2024-03-11 06:12:43 --> Helper loaded: text_helper
INFO - 2024-03-11 06:12:43 --> Helper loaded: form_helper
INFO - 2024-03-11 06:12:43 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:12:43 --> Helper loaded: security_helper
INFO - 2024-03-11 06:12:43 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:12:43 --> Database Driver Class Initialized
INFO - 2024-03-11 06:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:12:43 --> Parser Class Initialized
INFO - 2024-03-11 06:12:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:12:43 --> Pagination Class Initialized
INFO - 2024-03-11 06:12:43 --> Form Validation Class Initialized
INFO - 2024-03-11 06:12:43 --> Controller Class Initialized
INFO - 2024-03-11 06:12:43 --> Model Class Initialized
DEBUG - 2024-03-11 06:12:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:12:43 --> Model Class Initialized
INFO - 2024-03-11 06:12:43 --> Final output sent to browser
DEBUG - 2024-03-11 06:12:43 --> Total execution time: 0.0217
ERROR - 2024-03-11 06:12:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:12:44 --> Config Class Initialized
INFO - 2024-03-11 06:12:44 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:12:44 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:12:44 --> Utf8 Class Initialized
INFO - 2024-03-11 06:12:44 --> URI Class Initialized
DEBUG - 2024-03-11 06:12:44 --> No URI present. Default controller set.
INFO - 2024-03-11 06:12:44 --> Router Class Initialized
INFO - 2024-03-11 06:12:44 --> Output Class Initialized
INFO - 2024-03-11 06:12:44 --> Security Class Initialized
DEBUG - 2024-03-11 06:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:12:44 --> Input Class Initialized
INFO - 2024-03-11 06:12:44 --> Language Class Initialized
INFO - 2024-03-11 06:12:44 --> Loader Class Initialized
INFO - 2024-03-11 06:12:44 --> Helper loaded: url_helper
INFO - 2024-03-11 06:12:44 --> Helper loaded: file_helper
INFO - 2024-03-11 06:12:44 --> Helper loaded: html_helper
INFO - 2024-03-11 06:12:44 --> Helper loaded: text_helper
INFO - 2024-03-11 06:12:44 --> Helper loaded: form_helper
INFO - 2024-03-11 06:12:44 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:12:44 --> Helper loaded: security_helper
INFO - 2024-03-11 06:12:44 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:12:44 --> Database Driver Class Initialized
INFO - 2024-03-11 06:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:12:44 --> Parser Class Initialized
INFO - 2024-03-11 06:12:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:12:44 --> Pagination Class Initialized
INFO - 2024-03-11 06:12:44 --> Form Validation Class Initialized
INFO - 2024-03-11 06:12:44 --> Controller Class Initialized
INFO - 2024-03-11 06:12:44 --> Model Class Initialized
DEBUG - 2024-03-11 06:12:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:12:44 --> Model Class Initialized
DEBUG - 2024-03-11 06:12:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:12:44 --> Model Class Initialized
INFO - 2024-03-11 06:12:44 --> Model Class Initialized
INFO - 2024-03-11 06:12:44 --> Model Class Initialized
INFO - 2024-03-11 06:12:44 --> Model Class Initialized
DEBUG - 2024-03-11 06:12:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 06:12:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:12:44 --> Model Class Initialized
INFO - 2024-03-11 06:12:44 --> Model Class Initialized
INFO - 2024-03-11 06:12:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-11 06:12:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:12:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 06:12:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 06:12:44 --> Model Class Initialized
INFO - 2024-03-11 06:12:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 06:12:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 06:12:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 06:12:44 --> Final output sent to browser
DEBUG - 2024-03-11 06:12:44 --> Total execution time: 0.2497
ERROR - 2024-03-11 06:12:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:12:54 --> Config Class Initialized
INFO - 2024-03-11 06:12:54 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:12:54 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:12:54 --> Utf8 Class Initialized
INFO - 2024-03-11 06:12:54 --> URI Class Initialized
INFO - 2024-03-11 06:12:54 --> Router Class Initialized
INFO - 2024-03-11 06:12:54 --> Output Class Initialized
INFO - 2024-03-11 06:12:54 --> Security Class Initialized
DEBUG - 2024-03-11 06:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:12:54 --> Input Class Initialized
INFO - 2024-03-11 06:12:54 --> Language Class Initialized
INFO - 2024-03-11 06:12:54 --> Loader Class Initialized
INFO - 2024-03-11 06:12:54 --> Helper loaded: url_helper
INFO - 2024-03-11 06:12:54 --> Helper loaded: file_helper
INFO - 2024-03-11 06:12:54 --> Helper loaded: html_helper
INFO - 2024-03-11 06:12:54 --> Helper loaded: text_helper
INFO - 2024-03-11 06:12:54 --> Helper loaded: form_helper
INFO - 2024-03-11 06:12:54 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:12:54 --> Helper loaded: security_helper
INFO - 2024-03-11 06:12:54 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:12:54 --> Database Driver Class Initialized
INFO - 2024-03-11 06:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:12:54 --> Parser Class Initialized
INFO - 2024-03-11 06:12:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:12:54 --> Pagination Class Initialized
INFO - 2024-03-11 06:12:54 --> Form Validation Class Initialized
INFO - 2024-03-11 06:12:54 --> Controller Class Initialized
INFO - 2024-03-11 06:12:54 --> Model Class Initialized
DEBUG - 2024-03-11 06:12:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 06:12:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:12:54 --> Model Class Initialized
DEBUG - 2024-03-11 06:12:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:12:54 --> Model Class Initialized
INFO - 2024-03-11 06:12:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-11 06:12:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:12:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 06:12:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 06:12:54 --> Model Class Initialized
INFO - 2024-03-11 06:12:54 --> Model Class Initialized
INFO - 2024-03-11 06:12:54 --> Model Class Initialized
INFO - 2024-03-11 06:12:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 06:12:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 06:12:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 06:12:54 --> Final output sent to browser
DEBUG - 2024-03-11 06:12:54 --> Total execution time: 0.1613
ERROR - 2024-03-11 06:12:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:12:55 --> Config Class Initialized
INFO - 2024-03-11 06:12:55 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:12:55 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:12:55 --> Utf8 Class Initialized
INFO - 2024-03-11 06:12:55 --> URI Class Initialized
INFO - 2024-03-11 06:12:55 --> Router Class Initialized
INFO - 2024-03-11 06:12:55 --> Output Class Initialized
INFO - 2024-03-11 06:12:55 --> Security Class Initialized
DEBUG - 2024-03-11 06:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:12:55 --> Input Class Initialized
INFO - 2024-03-11 06:12:55 --> Language Class Initialized
INFO - 2024-03-11 06:12:55 --> Loader Class Initialized
INFO - 2024-03-11 06:12:55 --> Helper loaded: url_helper
INFO - 2024-03-11 06:12:55 --> Helper loaded: file_helper
INFO - 2024-03-11 06:12:55 --> Helper loaded: html_helper
INFO - 2024-03-11 06:12:55 --> Helper loaded: text_helper
INFO - 2024-03-11 06:12:55 --> Helper loaded: form_helper
INFO - 2024-03-11 06:12:55 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:12:55 --> Helper loaded: security_helper
INFO - 2024-03-11 06:12:55 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:12:55 --> Database Driver Class Initialized
INFO - 2024-03-11 06:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:12:55 --> Parser Class Initialized
INFO - 2024-03-11 06:12:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:12:55 --> Pagination Class Initialized
INFO - 2024-03-11 06:12:55 --> Form Validation Class Initialized
INFO - 2024-03-11 06:12:55 --> Controller Class Initialized
INFO - 2024-03-11 06:12:55 --> Model Class Initialized
DEBUG - 2024-03-11 06:12:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 06:12:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:12:55 --> Model Class Initialized
DEBUG - 2024-03-11 06:12:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:12:55 --> Model Class Initialized
INFO - 2024-03-11 06:12:55 --> Final output sent to browser
DEBUG - 2024-03-11 06:12:55 --> Total execution time: 0.0439
ERROR - 2024-03-11 06:12:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:12:58 --> Config Class Initialized
INFO - 2024-03-11 06:12:58 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:12:58 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:12:58 --> Utf8 Class Initialized
INFO - 2024-03-11 06:12:58 --> URI Class Initialized
INFO - 2024-03-11 06:12:58 --> Router Class Initialized
INFO - 2024-03-11 06:12:58 --> Output Class Initialized
INFO - 2024-03-11 06:12:58 --> Security Class Initialized
DEBUG - 2024-03-11 06:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:12:58 --> Input Class Initialized
INFO - 2024-03-11 06:12:58 --> Language Class Initialized
INFO - 2024-03-11 06:12:58 --> Loader Class Initialized
INFO - 2024-03-11 06:12:58 --> Helper loaded: url_helper
INFO - 2024-03-11 06:12:58 --> Helper loaded: file_helper
INFO - 2024-03-11 06:12:58 --> Helper loaded: html_helper
INFO - 2024-03-11 06:12:58 --> Helper loaded: text_helper
INFO - 2024-03-11 06:12:58 --> Helper loaded: form_helper
INFO - 2024-03-11 06:12:58 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:12:58 --> Helper loaded: security_helper
INFO - 2024-03-11 06:12:58 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:12:58 --> Database Driver Class Initialized
INFO - 2024-03-11 06:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:12:58 --> Parser Class Initialized
INFO - 2024-03-11 06:12:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:12:58 --> Pagination Class Initialized
INFO - 2024-03-11 06:12:58 --> Form Validation Class Initialized
INFO - 2024-03-11 06:12:58 --> Controller Class Initialized
INFO - 2024-03-11 06:12:58 --> Model Class Initialized
DEBUG - 2024-03-11 06:12:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 06:12:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:12:58 --> Model Class Initialized
DEBUG - 2024-03-11 06:12:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:12:58 --> Model Class Initialized
DEBUG - 2024-03-11 06:12:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:12:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-03-11 06:12:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:12:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 06:12:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 06:12:58 --> Model Class Initialized
INFO - 2024-03-11 06:12:58 --> Model Class Initialized
INFO - 2024-03-11 06:12:58 --> Model Class Initialized
INFO - 2024-03-11 06:12:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 06:12:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 06:12:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 06:12:58 --> Final output sent to browser
DEBUG - 2024-03-11 06:12:58 --> Total execution time: 0.1675
ERROR - 2024-03-11 06:13:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:13:22 --> Config Class Initialized
INFO - 2024-03-11 06:13:22 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:13:22 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:13:22 --> Utf8 Class Initialized
INFO - 2024-03-11 06:13:22 --> URI Class Initialized
DEBUG - 2024-03-11 06:13:22 --> No URI present. Default controller set.
INFO - 2024-03-11 06:13:22 --> Router Class Initialized
INFO - 2024-03-11 06:13:22 --> Output Class Initialized
INFO - 2024-03-11 06:13:22 --> Security Class Initialized
DEBUG - 2024-03-11 06:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:13:22 --> Input Class Initialized
INFO - 2024-03-11 06:13:22 --> Language Class Initialized
INFO - 2024-03-11 06:13:22 --> Loader Class Initialized
INFO - 2024-03-11 06:13:22 --> Helper loaded: url_helper
INFO - 2024-03-11 06:13:22 --> Helper loaded: file_helper
INFO - 2024-03-11 06:13:22 --> Helper loaded: html_helper
INFO - 2024-03-11 06:13:22 --> Helper loaded: text_helper
INFO - 2024-03-11 06:13:22 --> Helper loaded: form_helper
INFO - 2024-03-11 06:13:22 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:13:22 --> Helper loaded: security_helper
INFO - 2024-03-11 06:13:22 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:13:22 --> Database Driver Class Initialized
INFO - 2024-03-11 06:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:13:22 --> Parser Class Initialized
INFO - 2024-03-11 06:13:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:13:22 --> Pagination Class Initialized
INFO - 2024-03-11 06:13:22 --> Form Validation Class Initialized
INFO - 2024-03-11 06:13:22 --> Controller Class Initialized
INFO - 2024-03-11 06:13:22 --> Model Class Initialized
DEBUG - 2024-03-11 06:13:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:13:22 --> Model Class Initialized
DEBUG - 2024-03-11 06:13:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:13:22 --> Model Class Initialized
INFO - 2024-03-11 06:13:22 --> Model Class Initialized
INFO - 2024-03-11 06:13:22 --> Model Class Initialized
INFO - 2024-03-11 06:13:22 --> Model Class Initialized
DEBUG - 2024-03-11 06:13:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 06:13:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:13:22 --> Model Class Initialized
INFO - 2024-03-11 06:13:22 --> Model Class Initialized
INFO - 2024-03-11 06:13:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-11 06:13:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:13:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 06:13:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 06:13:22 --> Model Class Initialized
INFO - 2024-03-11 06:13:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 06:13:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 06:13:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 06:13:22 --> Final output sent to browser
DEBUG - 2024-03-11 06:13:22 --> Total execution time: 0.2523
ERROR - 2024-03-11 06:14:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:14:11 --> Config Class Initialized
INFO - 2024-03-11 06:14:11 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:14:11 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:14:11 --> Utf8 Class Initialized
INFO - 2024-03-11 06:14:11 --> URI Class Initialized
DEBUG - 2024-03-11 06:14:11 --> No URI present. Default controller set.
INFO - 2024-03-11 06:14:11 --> Router Class Initialized
INFO - 2024-03-11 06:14:11 --> Output Class Initialized
INFO - 2024-03-11 06:14:11 --> Security Class Initialized
DEBUG - 2024-03-11 06:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:14:11 --> Input Class Initialized
INFO - 2024-03-11 06:14:11 --> Language Class Initialized
INFO - 2024-03-11 06:14:11 --> Loader Class Initialized
INFO - 2024-03-11 06:14:11 --> Helper loaded: url_helper
INFO - 2024-03-11 06:14:11 --> Helper loaded: file_helper
INFO - 2024-03-11 06:14:11 --> Helper loaded: html_helper
INFO - 2024-03-11 06:14:11 --> Helper loaded: text_helper
INFO - 2024-03-11 06:14:11 --> Helper loaded: form_helper
INFO - 2024-03-11 06:14:11 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:14:11 --> Helper loaded: security_helper
INFO - 2024-03-11 06:14:11 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:14:11 --> Database Driver Class Initialized
INFO - 2024-03-11 06:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:14:11 --> Parser Class Initialized
INFO - 2024-03-11 06:14:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:14:11 --> Pagination Class Initialized
INFO - 2024-03-11 06:14:11 --> Form Validation Class Initialized
INFO - 2024-03-11 06:14:11 --> Controller Class Initialized
INFO - 2024-03-11 06:14:11 --> Model Class Initialized
DEBUG - 2024-03-11 06:14:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:14:11 --> Model Class Initialized
DEBUG - 2024-03-11 06:14:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:14:11 --> Model Class Initialized
INFO - 2024-03-11 06:14:11 --> Model Class Initialized
INFO - 2024-03-11 06:14:11 --> Model Class Initialized
INFO - 2024-03-11 06:14:11 --> Model Class Initialized
DEBUG - 2024-03-11 06:14:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 06:14:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:14:11 --> Model Class Initialized
INFO - 2024-03-11 06:14:11 --> Model Class Initialized
INFO - 2024-03-11 06:14:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-11 06:14:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:14:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 06:14:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 06:14:11 --> Model Class Initialized
INFO - 2024-03-11 06:14:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 06:14:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 06:14:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 06:14:11 --> Final output sent to browser
DEBUG - 2024-03-11 06:14:11 --> Total execution time: 0.2501
ERROR - 2024-03-11 06:14:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:14:31 --> Config Class Initialized
INFO - 2024-03-11 06:14:31 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:14:31 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:14:31 --> Utf8 Class Initialized
INFO - 2024-03-11 06:14:31 --> URI Class Initialized
INFO - 2024-03-11 06:14:31 --> Router Class Initialized
INFO - 2024-03-11 06:14:31 --> Output Class Initialized
INFO - 2024-03-11 06:14:31 --> Security Class Initialized
DEBUG - 2024-03-11 06:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:14:31 --> Input Class Initialized
INFO - 2024-03-11 06:14:31 --> Language Class Initialized
INFO - 2024-03-11 06:14:31 --> Loader Class Initialized
INFO - 2024-03-11 06:14:31 --> Helper loaded: url_helper
INFO - 2024-03-11 06:14:31 --> Helper loaded: file_helper
INFO - 2024-03-11 06:14:31 --> Helper loaded: html_helper
INFO - 2024-03-11 06:14:31 --> Helper loaded: text_helper
INFO - 2024-03-11 06:14:31 --> Helper loaded: form_helper
INFO - 2024-03-11 06:14:31 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:14:31 --> Helper loaded: security_helper
INFO - 2024-03-11 06:14:31 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:14:31 --> Database Driver Class Initialized
INFO - 2024-03-11 06:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:14:31 --> Parser Class Initialized
INFO - 2024-03-11 06:14:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:14:31 --> Pagination Class Initialized
INFO - 2024-03-11 06:14:31 --> Form Validation Class Initialized
INFO - 2024-03-11 06:14:31 --> Controller Class Initialized
INFO - 2024-03-11 06:14:31 --> Model Class Initialized
DEBUG - 2024-03-11 06:14:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 06:14:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:14:31 --> Model Class Initialized
DEBUG - 2024-03-11 06:14:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:14:31 --> Model Class Initialized
INFO - 2024-03-11 06:14:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-11 06:14:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:14:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 06:14:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 06:14:31 --> Model Class Initialized
INFO - 2024-03-11 06:14:31 --> Model Class Initialized
INFO - 2024-03-11 06:14:31 --> Model Class Initialized
INFO - 2024-03-11 06:14:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 06:14:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 06:14:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 06:14:31 --> Final output sent to browser
DEBUG - 2024-03-11 06:14:31 --> Total execution time: 0.1568
ERROR - 2024-03-11 06:14:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:14:31 --> Config Class Initialized
INFO - 2024-03-11 06:14:31 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:14:31 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:14:31 --> Utf8 Class Initialized
INFO - 2024-03-11 06:14:31 --> URI Class Initialized
INFO - 2024-03-11 06:14:31 --> Router Class Initialized
INFO - 2024-03-11 06:14:31 --> Output Class Initialized
INFO - 2024-03-11 06:14:31 --> Security Class Initialized
DEBUG - 2024-03-11 06:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:14:31 --> Input Class Initialized
INFO - 2024-03-11 06:14:31 --> Language Class Initialized
INFO - 2024-03-11 06:14:31 --> Loader Class Initialized
INFO - 2024-03-11 06:14:31 --> Helper loaded: url_helper
INFO - 2024-03-11 06:14:31 --> Helper loaded: file_helper
INFO - 2024-03-11 06:14:31 --> Helper loaded: html_helper
INFO - 2024-03-11 06:14:31 --> Helper loaded: text_helper
INFO - 2024-03-11 06:14:31 --> Helper loaded: form_helper
INFO - 2024-03-11 06:14:31 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:14:31 --> Helper loaded: security_helper
INFO - 2024-03-11 06:14:31 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:14:31 --> Database Driver Class Initialized
INFO - 2024-03-11 06:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:14:31 --> Parser Class Initialized
INFO - 2024-03-11 06:14:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:14:31 --> Pagination Class Initialized
INFO - 2024-03-11 06:14:31 --> Form Validation Class Initialized
INFO - 2024-03-11 06:14:31 --> Controller Class Initialized
INFO - 2024-03-11 06:14:31 --> Model Class Initialized
DEBUG - 2024-03-11 06:14:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 06:14:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:14:31 --> Model Class Initialized
DEBUG - 2024-03-11 06:14:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:14:31 --> Model Class Initialized
INFO - 2024-03-11 06:14:31 --> Final output sent to browser
DEBUG - 2024-03-11 06:14:31 --> Total execution time: 0.0367
ERROR - 2024-03-11 06:14:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:14:36 --> Config Class Initialized
INFO - 2024-03-11 06:14:36 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:14:36 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:14:36 --> Utf8 Class Initialized
INFO - 2024-03-11 06:14:36 --> URI Class Initialized
INFO - 2024-03-11 06:14:36 --> Router Class Initialized
INFO - 2024-03-11 06:14:36 --> Output Class Initialized
INFO - 2024-03-11 06:14:36 --> Security Class Initialized
DEBUG - 2024-03-11 06:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:14:36 --> Input Class Initialized
INFO - 2024-03-11 06:14:36 --> Language Class Initialized
INFO - 2024-03-11 06:14:36 --> Loader Class Initialized
INFO - 2024-03-11 06:14:36 --> Helper loaded: url_helper
INFO - 2024-03-11 06:14:36 --> Helper loaded: file_helper
INFO - 2024-03-11 06:14:36 --> Helper loaded: html_helper
INFO - 2024-03-11 06:14:36 --> Helper loaded: text_helper
INFO - 2024-03-11 06:14:36 --> Helper loaded: form_helper
INFO - 2024-03-11 06:14:36 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:14:36 --> Helper loaded: security_helper
INFO - 2024-03-11 06:14:36 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:14:36 --> Database Driver Class Initialized
INFO - 2024-03-11 06:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:14:36 --> Parser Class Initialized
INFO - 2024-03-11 06:14:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:14:36 --> Pagination Class Initialized
INFO - 2024-03-11 06:14:36 --> Form Validation Class Initialized
INFO - 2024-03-11 06:14:36 --> Controller Class Initialized
INFO - 2024-03-11 06:14:36 --> Model Class Initialized
DEBUG - 2024-03-11 06:14:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 06:14:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:14:36 --> Model Class Initialized
DEBUG - 2024-03-11 06:14:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:14:36 --> Model Class Initialized
INFO - 2024-03-11 06:14:36 --> Final output sent to browser
DEBUG - 2024-03-11 06:14:36 --> Total execution time: 0.2202
ERROR - 2024-03-11 06:15:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:15:05 --> Config Class Initialized
INFO - 2024-03-11 06:15:05 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:15:05 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:15:05 --> Utf8 Class Initialized
INFO - 2024-03-11 06:15:05 --> URI Class Initialized
INFO - 2024-03-11 06:15:05 --> Router Class Initialized
INFO - 2024-03-11 06:15:05 --> Output Class Initialized
INFO - 2024-03-11 06:15:05 --> Security Class Initialized
DEBUG - 2024-03-11 06:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:15:05 --> Input Class Initialized
INFO - 2024-03-11 06:15:05 --> Language Class Initialized
INFO - 2024-03-11 06:15:05 --> Loader Class Initialized
INFO - 2024-03-11 06:15:05 --> Helper loaded: url_helper
INFO - 2024-03-11 06:15:05 --> Helper loaded: file_helper
INFO - 2024-03-11 06:15:05 --> Helper loaded: html_helper
INFO - 2024-03-11 06:15:05 --> Helper loaded: text_helper
INFO - 2024-03-11 06:15:05 --> Helper loaded: form_helper
INFO - 2024-03-11 06:15:05 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:15:05 --> Helper loaded: security_helper
INFO - 2024-03-11 06:15:05 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:15:05 --> Database Driver Class Initialized
INFO - 2024-03-11 06:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:15:05 --> Parser Class Initialized
INFO - 2024-03-11 06:15:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:15:05 --> Pagination Class Initialized
INFO - 2024-03-11 06:15:05 --> Form Validation Class Initialized
INFO - 2024-03-11 06:15:05 --> Controller Class Initialized
INFO - 2024-03-11 06:15:05 --> Model Class Initialized
DEBUG - 2024-03-11 06:15:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 06:15:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:15:05 --> Model Class Initialized
DEBUG - 2024-03-11 06:15:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:15:05 --> Model Class Initialized
DEBUG - 2024-03-11 06:15:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:15:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-03-11 06:15:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:15:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 06:15:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 06:15:05 --> Model Class Initialized
INFO - 2024-03-11 06:15:05 --> Model Class Initialized
INFO - 2024-03-11 06:15:05 --> Model Class Initialized
INFO - 2024-03-11 06:15:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 06:15:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 06:15:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 06:15:05 --> Final output sent to browser
DEBUG - 2024-03-11 06:15:05 --> Total execution time: 0.1707
ERROR - 2024-03-11 06:15:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:15:11 --> Config Class Initialized
INFO - 2024-03-11 06:15:11 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:15:11 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:15:11 --> Utf8 Class Initialized
INFO - 2024-03-11 06:15:11 --> URI Class Initialized
DEBUG - 2024-03-11 06:15:11 --> No URI present. Default controller set.
INFO - 2024-03-11 06:15:11 --> Router Class Initialized
INFO - 2024-03-11 06:15:11 --> Output Class Initialized
INFO - 2024-03-11 06:15:11 --> Security Class Initialized
DEBUG - 2024-03-11 06:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:15:11 --> Input Class Initialized
INFO - 2024-03-11 06:15:11 --> Language Class Initialized
INFO - 2024-03-11 06:15:11 --> Loader Class Initialized
INFO - 2024-03-11 06:15:11 --> Helper loaded: url_helper
INFO - 2024-03-11 06:15:11 --> Helper loaded: file_helper
INFO - 2024-03-11 06:15:11 --> Helper loaded: html_helper
INFO - 2024-03-11 06:15:11 --> Helper loaded: text_helper
INFO - 2024-03-11 06:15:11 --> Helper loaded: form_helper
INFO - 2024-03-11 06:15:11 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:15:11 --> Helper loaded: security_helper
INFO - 2024-03-11 06:15:11 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:15:11 --> Database Driver Class Initialized
INFO - 2024-03-11 06:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:15:11 --> Parser Class Initialized
INFO - 2024-03-11 06:15:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:15:11 --> Pagination Class Initialized
INFO - 2024-03-11 06:15:11 --> Form Validation Class Initialized
INFO - 2024-03-11 06:15:11 --> Controller Class Initialized
INFO - 2024-03-11 06:15:11 --> Model Class Initialized
DEBUG - 2024-03-11 06:15:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:15:11 --> Model Class Initialized
DEBUG - 2024-03-11 06:15:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:15:11 --> Model Class Initialized
INFO - 2024-03-11 06:15:11 --> Model Class Initialized
INFO - 2024-03-11 06:15:11 --> Model Class Initialized
INFO - 2024-03-11 06:15:11 --> Model Class Initialized
DEBUG - 2024-03-11 06:15:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 06:15:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:15:11 --> Model Class Initialized
INFO - 2024-03-11 06:15:11 --> Model Class Initialized
INFO - 2024-03-11 06:15:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-11 06:15:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:15:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 06:15:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 06:15:11 --> Model Class Initialized
INFO - 2024-03-11 06:15:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 06:15:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 06:15:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 06:15:11 --> Final output sent to browser
DEBUG - 2024-03-11 06:15:11 --> Total execution time: 0.2466
ERROR - 2024-03-11 06:15:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:15:43 --> Config Class Initialized
INFO - 2024-03-11 06:15:43 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:15:43 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:15:43 --> Utf8 Class Initialized
INFO - 2024-03-11 06:15:43 --> URI Class Initialized
INFO - 2024-03-11 06:15:43 --> Router Class Initialized
INFO - 2024-03-11 06:15:43 --> Output Class Initialized
INFO - 2024-03-11 06:15:43 --> Security Class Initialized
DEBUG - 2024-03-11 06:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:15:43 --> Input Class Initialized
INFO - 2024-03-11 06:15:43 --> Language Class Initialized
INFO - 2024-03-11 06:15:43 --> Loader Class Initialized
INFO - 2024-03-11 06:15:43 --> Helper loaded: url_helper
INFO - 2024-03-11 06:15:43 --> Helper loaded: file_helper
INFO - 2024-03-11 06:15:43 --> Helper loaded: html_helper
INFO - 2024-03-11 06:15:43 --> Helper loaded: text_helper
INFO - 2024-03-11 06:15:43 --> Helper loaded: form_helper
INFO - 2024-03-11 06:15:43 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:15:43 --> Helper loaded: security_helper
INFO - 2024-03-11 06:15:43 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:15:43 --> Database Driver Class Initialized
INFO - 2024-03-11 06:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:15:43 --> Parser Class Initialized
INFO - 2024-03-11 06:15:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:15:43 --> Pagination Class Initialized
INFO - 2024-03-11 06:15:43 --> Form Validation Class Initialized
INFO - 2024-03-11 06:15:43 --> Controller Class Initialized
DEBUG - 2024-03-11 06:15:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 06:15:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:15:43 --> Model Class Initialized
DEBUG - 2024-03-11 06:15:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:15:43 --> Model Class Initialized
DEBUG - 2024-03-11 06:15:43 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:15:43 --> Model Class Initialized
INFO - 2024-03-11 06:15:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-03-11 06:15:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:15:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 06:15:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 06:15:43 --> Model Class Initialized
INFO - 2024-03-11 06:15:43 --> Model Class Initialized
INFO - 2024-03-11 06:15:43 --> Model Class Initialized
INFO - 2024-03-11 06:15:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 06:15:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 06:15:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 06:15:43 --> Final output sent to browser
DEBUG - 2024-03-11 06:15:43 --> Total execution time: 0.1547
ERROR - 2024-03-11 06:15:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:15:44 --> Config Class Initialized
INFO - 2024-03-11 06:15:44 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:15:44 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:15:44 --> Utf8 Class Initialized
INFO - 2024-03-11 06:15:44 --> URI Class Initialized
INFO - 2024-03-11 06:15:44 --> Router Class Initialized
INFO - 2024-03-11 06:15:44 --> Output Class Initialized
INFO - 2024-03-11 06:15:44 --> Security Class Initialized
DEBUG - 2024-03-11 06:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:15:44 --> Input Class Initialized
INFO - 2024-03-11 06:15:44 --> Language Class Initialized
INFO - 2024-03-11 06:15:44 --> Loader Class Initialized
INFO - 2024-03-11 06:15:44 --> Helper loaded: url_helper
INFO - 2024-03-11 06:15:44 --> Helper loaded: file_helper
INFO - 2024-03-11 06:15:44 --> Helper loaded: html_helper
INFO - 2024-03-11 06:15:44 --> Helper loaded: text_helper
INFO - 2024-03-11 06:15:44 --> Helper loaded: form_helper
INFO - 2024-03-11 06:15:44 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:15:44 --> Helper loaded: security_helper
INFO - 2024-03-11 06:15:44 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:15:44 --> Database Driver Class Initialized
INFO - 2024-03-11 06:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:15:44 --> Parser Class Initialized
INFO - 2024-03-11 06:15:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:15:44 --> Pagination Class Initialized
INFO - 2024-03-11 06:15:44 --> Form Validation Class Initialized
INFO - 2024-03-11 06:15:44 --> Controller Class Initialized
DEBUG - 2024-03-11 06:15:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 06:15:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:15:44 --> Model Class Initialized
DEBUG - 2024-03-11 06:15:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:15:44 --> Model Class Initialized
INFO - 2024-03-11 06:15:44 --> Final output sent to browser
DEBUG - 2024-03-11 06:15:44 --> Total execution time: 0.0267
ERROR - 2024-03-11 06:15:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:15:48 --> Config Class Initialized
INFO - 2024-03-11 06:15:48 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:15:48 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:15:48 --> Utf8 Class Initialized
INFO - 2024-03-11 06:15:48 --> URI Class Initialized
INFO - 2024-03-11 06:15:48 --> Router Class Initialized
INFO - 2024-03-11 06:15:48 --> Output Class Initialized
INFO - 2024-03-11 06:15:48 --> Security Class Initialized
DEBUG - 2024-03-11 06:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:15:48 --> Input Class Initialized
INFO - 2024-03-11 06:15:48 --> Language Class Initialized
INFO - 2024-03-11 06:15:48 --> Loader Class Initialized
INFO - 2024-03-11 06:15:48 --> Helper loaded: url_helper
INFO - 2024-03-11 06:15:48 --> Helper loaded: file_helper
INFO - 2024-03-11 06:15:48 --> Helper loaded: html_helper
INFO - 2024-03-11 06:15:48 --> Helper loaded: text_helper
INFO - 2024-03-11 06:15:48 --> Helper loaded: form_helper
INFO - 2024-03-11 06:15:48 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:15:48 --> Helper loaded: security_helper
INFO - 2024-03-11 06:15:48 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:15:48 --> Database Driver Class Initialized
INFO - 2024-03-11 06:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:15:48 --> Parser Class Initialized
INFO - 2024-03-11 06:15:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:15:48 --> Pagination Class Initialized
INFO - 2024-03-11 06:15:48 --> Form Validation Class Initialized
INFO - 2024-03-11 06:15:48 --> Controller Class Initialized
DEBUG - 2024-03-11 06:15:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 06:15:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:15:48 --> Model Class Initialized
DEBUG - 2024-03-11 06:15:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:15:48 --> Model Class Initialized
INFO - 2024-03-11 06:15:48 --> Final output sent to browser
DEBUG - 2024-03-11 06:15:48 --> Total execution time: 0.0365
ERROR - 2024-03-11 06:15:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:15:58 --> Config Class Initialized
INFO - 2024-03-11 06:15:58 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:15:58 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:15:58 --> Utf8 Class Initialized
INFO - 2024-03-11 06:15:58 --> URI Class Initialized
INFO - 2024-03-11 06:15:58 --> Router Class Initialized
INFO - 2024-03-11 06:15:58 --> Output Class Initialized
INFO - 2024-03-11 06:15:58 --> Security Class Initialized
DEBUG - 2024-03-11 06:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:15:58 --> Input Class Initialized
INFO - 2024-03-11 06:15:58 --> Language Class Initialized
INFO - 2024-03-11 06:15:58 --> Loader Class Initialized
INFO - 2024-03-11 06:15:58 --> Helper loaded: url_helper
INFO - 2024-03-11 06:15:58 --> Helper loaded: file_helper
INFO - 2024-03-11 06:15:58 --> Helper loaded: html_helper
INFO - 2024-03-11 06:15:58 --> Helper loaded: text_helper
INFO - 2024-03-11 06:15:58 --> Helper loaded: form_helper
INFO - 2024-03-11 06:15:58 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:15:58 --> Helper loaded: security_helper
INFO - 2024-03-11 06:15:58 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:15:58 --> Database Driver Class Initialized
INFO - 2024-03-11 06:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:15:58 --> Parser Class Initialized
INFO - 2024-03-11 06:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:15:58 --> Pagination Class Initialized
INFO - 2024-03-11 06:15:58 --> Form Validation Class Initialized
INFO - 2024-03-11 06:15:58 --> Controller Class Initialized
INFO - 2024-03-11 06:15:58 --> Model Class Initialized
DEBUG - 2024-03-11 06:15:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 06:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:15:58 --> Model Class Initialized
DEBUG - 2024-03-11 06:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:15:58 --> Model Class Initialized
INFO - 2024-03-11 06:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-11 06:15:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 06:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 06:15:58 --> Model Class Initialized
INFO - 2024-03-11 06:15:58 --> Model Class Initialized
INFO - 2024-03-11 06:15:58 --> Model Class Initialized
INFO - 2024-03-11 06:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 06:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 06:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 06:15:58 --> Final output sent to browser
DEBUG - 2024-03-11 06:15:58 --> Total execution time: 0.1610
ERROR - 2024-03-11 06:15:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:15:58 --> Config Class Initialized
INFO - 2024-03-11 06:15:58 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:15:58 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:15:58 --> Utf8 Class Initialized
INFO - 2024-03-11 06:15:58 --> URI Class Initialized
INFO - 2024-03-11 06:15:58 --> Router Class Initialized
INFO - 2024-03-11 06:15:58 --> Output Class Initialized
INFO - 2024-03-11 06:15:58 --> Security Class Initialized
DEBUG - 2024-03-11 06:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:15:58 --> Input Class Initialized
INFO - 2024-03-11 06:15:58 --> Language Class Initialized
INFO - 2024-03-11 06:15:58 --> Loader Class Initialized
INFO - 2024-03-11 06:15:58 --> Helper loaded: url_helper
INFO - 2024-03-11 06:15:58 --> Helper loaded: file_helper
INFO - 2024-03-11 06:15:58 --> Helper loaded: html_helper
INFO - 2024-03-11 06:15:58 --> Helper loaded: text_helper
INFO - 2024-03-11 06:15:58 --> Helper loaded: form_helper
INFO - 2024-03-11 06:15:58 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:15:58 --> Helper loaded: security_helper
INFO - 2024-03-11 06:15:58 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:15:58 --> Database Driver Class Initialized
INFO - 2024-03-11 06:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:15:58 --> Parser Class Initialized
INFO - 2024-03-11 06:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:15:58 --> Pagination Class Initialized
INFO - 2024-03-11 06:15:58 --> Form Validation Class Initialized
INFO - 2024-03-11 06:15:58 --> Controller Class Initialized
INFO - 2024-03-11 06:15:58 --> Model Class Initialized
DEBUG - 2024-03-11 06:15:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 06:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:15:58 --> Model Class Initialized
DEBUG - 2024-03-11 06:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:15:58 --> Model Class Initialized
INFO - 2024-03-11 06:15:58 --> Final output sent to browser
DEBUG - 2024-03-11 06:15:58 --> Total execution time: 0.0436
ERROR - 2024-03-11 06:16:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:16:53 --> Config Class Initialized
INFO - 2024-03-11 06:16:53 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:16:53 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:16:53 --> Utf8 Class Initialized
INFO - 2024-03-11 06:16:53 --> URI Class Initialized
INFO - 2024-03-11 06:16:53 --> Router Class Initialized
INFO - 2024-03-11 06:16:53 --> Output Class Initialized
INFO - 2024-03-11 06:16:53 --> Security Class Initialized
DEBUG - 2024-03-11 06:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:16:53 --> Input Class Initialized
INFO - 2024-03-11 06:16:53 --> Language Class Initialized
INFO - 2024-03-11 06:16:53 --> Loader Class Initialized
INFO - 2024-03-11 06:16:53 --> Helper loaded: url_helper
INFO - 2024-03-11 06:16:53 --> Helper loaded: file_helper
INFO - 2024-03-11 06:16:53 --> Helper loaded: html_helper
INFO - 2024-03-11 06:16:53 --> Helper loaded: text_helper
INFO - 2024-03-11 06:16:53 --> Helper loaded: form_helper
INFO - 2024-03-11 06:16:53 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:16:53 --> Helper loaded: security_helper
INFO - 2024-03-11 06:16:53 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:16:53 --> Database Driver Class Initialized
INFO - 2024-03-11 06:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:16:53 --> Parser Class Initialized
INFO - 2024-03-11 06:16:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:16:53 --> Pagination Class Initialized
INFO - 2024-03-11 06:16:53 --> Form Validation Class Initialized
INFO - 2024-03-11 06:16:53 --> Controller Class Initialized
INFO - 2024-03-11 06:16:53 --> Model Class Initialized
DEBUG - 2024-03-11 06:16:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 06:16:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:16:53 --> Model Class Initialized
DEBUG - 2024-03-11 06:16:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:16:53 --> Model Class Initialized
INFO - 2024-03-11 06:16:54 --> Final output sent to browser
DEBUG - 2024-03-11 06:16:54 --> Total execution time: 0.2555
ERROR - 2024-03-11 06:17:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:17:03 --> Config Class Initialized
INFO - 2024-03-11 06:17:03 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:17:03 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:17:03 --> Utf8 Class Initialized
INFO - 2024-03-11 06:17:03 --> URI Class Initialized
DEBUG - 2024-03-11 06:17:03 --> No URI present. Default controller set.
INFO - 2024-03-11 06:17:03 --> Router Class Initialized
INFO - 2024-03-11 06:17:03 --> Output Class Initialized
INFO - 2024-03-11 06:17:03 --> Security Class Initialized
DEBUG - 2024-03-11 06:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:17:03 --> Input Class Initialized
INFO - 2024-03-11 06:17:03 --> Language Class Initialized
INFO - 2024-03-11 06:17:03 --> Loader Class Initialized
INFO - 2024-03-11 06:17:03 --> Helper loaded: url_helper
INFO - 2024-03-11 06:17:03 --> Helper loaded: file_helper
INFO - 2024-03-11 06:17:03 --> Helper loaded: html_helper
INFO - 2024-03-11 06:17:03 --> Helper loaded: text_helper
INFO - 2024-03-11 06:17:03 --> Helper loaded: form_helper
INFO - 2024-03-11 06:17:03 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:17:03 --> Helper loaded: security_helper
INFO - 2024-03-11 06:17:03 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:17:03 --> Database Driver Class Initialized
INFO - 2024-03-11 06:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:17:03 --> Parser Class Initialized
INFO - 2024-03-11 06:17:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:17:03 --> Pagination Class Initialized
INFO - 2024-03-11 06:17:03 --> Form Validation Class Initialized
INFO - 2024-03-11 06:17:03 --> Controller Class Initialized
INFO - 2024-03-11 06:17:03 --> Model Class Initialized
DEBUG - 2024-03-11 06:17:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:17:03 --> Model Class Initialized
DEBUG - 2024-03-11 06:17:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:17:03 --> Model Class Initialized
INFO - 2024-03-11 06:17:03 --> Model Class Initialized
INFO - 2024-03-11 06:17:03 --> Model Class Initialized
INFO - 2024-03-11 06:17:03 --> Model Class Initialized
DEBUG - 2024-03-11 06:17:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 06:17:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:17:03 --> Model Class Initialized
INFO - 2024-03-11 06:17:03 --> Model Class Initialized
INFO - 2024-03-11 06:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-11 06:17:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 06:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 06:17:03 --> Model Class Initialized
INFO - 2024-03-11 06:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 06:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 06:17:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 06:17:03 --> Final output sent to browser
DEBUG - 2024-03-11 06:17:03 --> Total execution time: 0.2467
ERROR - 2024-03-11 06:22:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:22:13 --> Config Class Initialized
INFO - 2024-03-11 06:22:13 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:22:13 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:22:13 --> Utf8 Class Initialized
INFO - 2024-03-11 06:22:13 --> URI Class Initialized
INFO - 2024-03-11 06:22:13 --> Router Class Initialized
INFO - 2024-03-11 06:22:13 --> Output Class Initialized
INFO - 2024-03-11 06:22:13 --> Security Class Initialized
DEBUG - 2024-03-11 06:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:22:13 --> Input Class Initialized
INFO - 2024-03-11 06:22:13 --> Language Class Initialized
INFO - 2024-03-11 06:22:13 --> Loader Class Initialized
INFO - 2024-03-11 06:22:13 --> Helper loaded: url_helper
INFO - 2024-03-11 06:22:13 --> Helper loaded: file_helper
INFO - 2024-03-11 06:22:13 --> Helper loaded: html_helper
INFO - 2024-03-11 06:22:13 --> Helper loaded: text_helper
INFO - 2024-03-11 06:22:13 --> Helper loaded: form_helper
INFO - 2024-03-11 06:22:13 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:22:13 --> Helper loaded: security_helper
INFO - 2024-03-11 06:22:13 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:22:13 --> Database Driver Class Initialized
INFO - 2024-03-11 06:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:22:13 --> Parser Class Initialized
INFO - 2024-03-11 06:22:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:22:13 --> Pagination Class Initialized
INFO - 2024-03-11 06:22:13 --> Form Validation Class Initialized
INFO - 2024-03-11 06:22:13 --> Controller Class Initialized
INFO - 2024-03-11 06:22:13 --> Model Class Initialized
DEBUG - 2024-03-11 06:22:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:22:13 --> Final output sent to browser
DEBUG - 2024-03-11 06:22:13 --> Total execution time: 0.0170
ERROR - 2024-03-11 06:22:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:22:13 --> Config Class Initialized
INFO - 2024-03-11 06:22:13 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:22:13 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:22:13 --> Utf8 Class Initialized
INFO - 2024-03-11 06:22:13 --> URI Class Initialized
INFO - 2024-03-11 06:22:13 --> Router Class Initialized
INFO - 2024-03-11 06:22:13 --> Output Class Initialized
INFO - 2024-03-11 06:22:13 --> Security Class Initialized
DEBUG - 2024-03-11 06:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:22:13 --> Input Class Initialized
INFO - 2024-03-11 06:22:13 --> Language Class Initialized
INFO - 2024-03-11 06:22:13 --> Loader Class Initialized
INFO - 2024-03-11 06:22:13 --> Helper loaded: url_helper
INFO - 2024-03-11 06:22:13 --> Helper loaded: file_helper
INFO - 2024-03-11 06:22:13 --> Helper loaded: html_helper
INFO - 2024-03-11 06:22:13 --> Helper loaded: text_helper
INFO - 2024-03-11 06:22:13 --> Helper loaded: form_helper
INFO - 2024-03-11 06:22:13 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:22:13 --> Helper loaded: security_helper
INFO - 2024-03-11 06:22:13 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:22:13 --> Database Driver Class Initialized
INFO - 2024-03-11 06:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:22:13 --> Parser Class Initialized
INFO - 2024-03-11 06:22:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:22:13 --> Pagination Class Initialized
INFO - 2024-03-11 06:22:13 --> Form Validation Class Initialized
INFO - 2024-03-11 06:22:13 --> Controller Class Initialized
INFO - 2024-03-11 06:22:13 --> Model Class Initialized
DEBUG - 2024-03-11 06:22:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:22:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-11 06:22:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:22:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 06:22:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 06:22:13 --> Model Class Initialized
INFO - 2024-03-11 06:22:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 06:22:13 --> Final output sent to browser
DEBUG - 2024-03-11 06:22:13 --> Total execution time: 0.0285
ERROR - 2024-03-11 06:22:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:22:20 --> Config Class Initialized
INFO - 2024-03-11 06:22:20 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:22:20 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:22:20 --> Utf8 Class Initialized
INFO - 2024-03-11 06:22:20 --> URI Class Initialized
INFO - 2024-03-11 06:22:20 --> Router Class Initialized
INFO - 2024-03-11 06:22:20 --> Output Class Initialized
INFO - 2024-03-11 06:22:20 --> Security Class Initialized
DEBUG - 2024-03-11 06:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:22:20 --> Input Class Initialized
INFO - 2024-03-11 06:22:20 --> Language Class Initialized
INFO - 2024-03-11 06:22:20 --> Loader Class Initialized
INFO - 2024-03-11 06:22:20 --> Helper loaded: url_helper
INFO - 2024-03-11 06:22:20 --> Helper loaded: file_helper
INFO - 2024-03-11 06:22:20 --> Helper loaded: html_helper
INFO - 2024-03-11 06:22:20 --> Helper loaded: text_helper
INFO - 2024-03-11 06:22:20 --> Helper loaded: form_helper
INFO - 2024-03-11 06:22:20 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:22:20 --> Helper loaded: security_helper
INFO - 2024-03-11 06:22:20 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:22:20 --> Database Driver Class Initialized
INFO - 2024-03-11 06:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:22:20 --> Parser Class Initialized
INFO - 2024-03-11 06:22:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:22:20 --> Pagination Class Initialized
INFO - 2024-03-11 06:22:20 --> Form Validation Class Initialized
INFO - 2024-03-11 06:22:20 --> Controller Class Initialized
INFO - 2024-03-11 06:22:20 --> Model Class Initialized
DEBUG - 2024-03-11 06:22:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:22:20 --> Model Class Initialized
INFO - 2024-03-11 06:22:20 --> Final output sent to browser
DEBUG - 2024-03-11 06:22:20 --> Total execution time: 0.0985
ERROR - 2024-03-11 06:22:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:22:21 --> Config Class Initialized
INFO - 2024-03-11 06:22:21 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:22:21 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:22:21 --> Utf8 Class Initialized
INFO - 2024-03-11 06:22:21 --> URI Class Initialized
DEBUG - 2024-03-11 06:22:21 --> No URI present. Default controller set.
INFO - 2024-03-11 06:22:21 --> Router Class Initialized
INFO - 2024-03-11 06:22:21 --> Output Class Initialized
INFO - 2024-03-11 06:22:21 --> Security Class Initialized
DEBUG - 2024-03-11 06:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:22:21 --> Input Class Initialized
INFO - 2024-03-11 06:22:21 --> Language Class Initialized
INFO - 2024-03-11 06:22:21 --> Loader Class Initialized
INFO - 2024-03-11 06:22:21 --> Helper loaded: url_helper
INFO - 2024-03-11 06:22:21 --> Helper loaded: file_helper
INFO - 2024-03-11 06:22:21 --> Helper loaded: html_helper
INFO - 2024-03-11 06:22:21 --> Helper loaded: text_helper
INFO - 2024-03-11 06:22:21 --> Helper loaded: form_helper
INFO - 2024-03-11 06:22:21 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:22:21 --> Helper loaded: security_helper
INFO - 2024-03-11 06:22:21 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:22:21 --> Database Driver Class Initialized
INFO - 2024-03-11 06:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:22:21 --> Parser Class Initialized
INFO - 2024-03-11 06:22:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:22:21 --> Pagination Class Initialized
INFO - 2024-03-11 06:22:21 --> Form Validation Class Initialized
INFO - 2024-03-11 06:22:21 --> Controller Class Initialized
INFO - 2024-03-11 06:22:21 --> Model Class Initialized
DEBUG - 2024-03-11 06:22:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:22:21 --> Model Class Initialized
DEBUG - 2024-03-11 06:22:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:22:21 --> Model Class Initialized
INFO - 2024-03-11 06:22:21 --> Model Class Initialized
INFO - 2024-03-11 06:22:21 --> Model Class Initialized
INFO - 2024-03-11 06:22:21 --> Model Class Initialized
DEBUG - 2024-03-11 06:22:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 06:22:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:22:21 --> Model Class Initialized
INFO - 2024-03-11 06:22:21 --> Model Class Initialized
INFO - 2024-03-11 06:22:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-11 06:22:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:22:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 06:22:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 06:22:21 --> Model Class Initialized
INFO - 2024-03-11 06:22:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 06:22:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 06:22:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 06:22:21 --> Final output sent to browser
DEBUG - 2024-03-11 06:22:21 --> Total execution time: 0.2655
ERROR - 2024-03-11 06:22:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:22:55 --> Config Class Initialized
INFO - 2024-03-11 06:22:55 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:22:55 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:22:55 --> Utf8 Class Initialized
INFO - 2024-03-11 06:22:55 --> URI Class Initialized
INFO - 2024-03-11 06:22:55 --> Router Class Initialized
INFO - 2024-03-11 06:22:55 --> Output Class Initialized
INFO - 2024-03-11 06:22:55 --> Security Class Initialized
DEBUG - 2024-03-11 06:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:22:55 --> Input Class Initialized
INFO - 2024-03-11 06:22:55 --> Language Class Initialized
INFO - 2024-03-11 06:22:55 --> Loader Class Initialized
INFO - 2024-03-11 06:22:55 --> Helper loaded: url_helper
INFO - 2024-03-11 06:22:55 --> Helper loaded: file_helper
INFO - 2024-03-11 06:22:55 --> Helper loaded: html_helper
INFO - 2024-03-11 06:22:55 --> Helper loaded: text_helper
INFO - 2024-03-11 06:22:55 --> Helper loaded: form_helper
INFO - 2024-03-11 06:22:55 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:22:55 --> Helper loaded: security_helper
INFO - 2024-03-11 06:22:55 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:22:55 --> Database Driver Class Initialized
INFO - 2024-03-11 06:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:22:55 --> Parser Class Initialized
INFO - 2024-03-11 06:22:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:22:55 --> Pagination Class Initialized
INFO - 2024-03-11 06:22:55 --> Form Validation Class Initialized
INFO - 2024-03-11 06:22:55 --> Controller Class Initialized
INFO - 2024-03-11 06:22:55 --> Model Class Initialized
DEBUG - 2024-03-11 06:22:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 06:22:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:22:55 --> Model Class Initialized
DEBUG - 2024-03-11 06:22:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:22:55 --> Model Class Initialized
INFO - 2024-03-11 06:22:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-11 06:22:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:22:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 06:22:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 06:22:55 --> Model Class Initialized
INFO - 2024-03-11 06:22:55 --> Model Class Initialized
INFO - 2024-03-11 06:22:55 --> Model Class Initialized
INFO - 2024-03-11 06:22:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 06:22:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 06:22:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 06:22:55 --> Final output sent to browser
DEBUG - 2024-03-11 06:22:55 --> Total execution time: 0.1540
ERROR - 2024-03-11 06:22:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:22:55 --> Config Class Initialized
INFO - 2024-03-11 06:22:55 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:22:55 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:22:55 --> Utf8 Class Initialized
INFO - 2024-03-11 06:22:55 --> URI Class Initialized
INFO - 2024-03-11 06:22:55 --> Router Class Initialized
INFO - 2024-03-11 06:22:55 --> Output Class Initialized
INFO - 2024-03-11 06:22:55 --> Security Class Initialized
DEBUG - 2024-03-11 06:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:22:55 --> Input Class Initialized
INFO - 2024-03-11 06:22:55 --> Language Class Initialized
INFO - 2024-03-11 06:22:55 --> Loader Class Initialized
INFO - 2024-03-11 06:22:55 --> Helper loaded: url_helper
INFO - 2024-03-11 06:22:55 --> Helper loaded: file_helper
INFO - 2024-03-11 06:22:55 --> Helper loaded: html_helper
INFO - 2024-03-11 06:22:55 --> Helper loaded: text_helper
INFO - 2024-03-11 06:22:55 --> Helper loaded: form_helper
INFO - 2024-03-11 06:22:55 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:22:55 --> Helper loaded: security_helper
INFO - 2024-03-11 06:22:55 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:22:55 --> Database Driver Class Initialized
INFO - 2024-03-11 06:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:22:55 --> Parser Class Initialized
INFO - 2024-03-11 06:22:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:22:55 --> Pagination Class Initialized
INFO - 2024-03-11 06:22:55 --> Form Validation Class Initialized
INFO - 2024-03-11 06:22:55 --> Controller Class Initialized
INFO - 2024-03-11 06:22:55 --> Model Class Initialized
DEBUG - 2024-03-11 06:22:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 06:22:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:22:55 --> Model Class Initialized
DEBUG - 2024-03-11 06:22:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:22:55 --> Model Class Initialized
INFO - 2024-03-11 06:22:55 --> Final output sent to browser
DEBUG - 2024-03-11 06:22:55 --> Total execution time: 0.0432
ERROR - 2024-03-11 06:23:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:23:01 --> Config Class Initialized
INFO - 2024-03-11 06:23:01 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:23:01 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:23:01 --> Utf8 Class Initialized
INFO - 2024-03-11 06:23:01 --> URI Class Initialized
INFO - 2024-03-11 06:23:01 --> Router Class Initialized
INFO - 2024-03-11 06:23:01 --> Output Class Initialized
INFO - 2024-03-11 06:23:01 --> Security Class Initialized
DEBUG - 2024-03-11 06:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:23:01 --> Input Class Initialized
INFO - 2024-03-11 06:23:01 --> Language Class Initialized
INFO - 2024-03-11 06:23:01 --> Loader Class Initialized
INFO - 2024-03-11 06:23:01 --> Helper loaded: url_helper
INFO - 2024-03-11 06:23:01 --> Helper loaded: file_helper
INFO - 2024-03-11 06:23:01 --> Helper loaded: html_helper
INFO - 2024-03-11 06:23:01 --> Helper loaded: text_helper
INFO - 2024-03-11 06:23:01 --> Helper loaded: form_helper
INFO - 2024-03-11 06:23:01 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:23:01 --> Helper loaded: security_helper
INFO - 2024-03-11 06:23:01 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:23:01 --> Database Driver Class Initialized
INFO - 2024-03-11 06:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:23:01 --> Parser Class Initialized
INFO - 2024-03-11 06:23:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:23:01 --> Pagination Class Initialized
INFO - 2024-03-11 06:23:01 --> Form Validation Class Initialized
INFO - 2024-03-11 06:23:01 --> Controller Class Initialized
INFO - 2024-03-11 06:23:01 --> Model Class Initialized
DEBUG - 2024-03-11 06:23:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 06:23:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:23:01 --> Model Class Initialized
DEBUG - 2024-03-11 06:23:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:23:01 --> Model Class Initialized
INFO - 2024-03-11 06:23:01 --> Final output sent to browser
DEBUG - 2024-03-11 06:23:01 --> Total execution time: 0.4514
ERROR - 2024-03-11 06:23:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:23:16 --> Config Class Initialized
INFO - 2024-03-11 06:23:16 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:23:16 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:23:16 --> Utf8 Class Initialized
INFO - 2024-03-11 06:23:16 --> URI Class Initialized
DEBUG - 2024-03-11 06:23:16 --> No URI present. Default controller set.
INFO - 2024-03-11 06:23:16 --> Router Class Initialized
INFO - 2024-03-11 06:23:16 --> Output Class Initialized
INFO - 2024-03-11 06:23:16 --> Security Class Initialized
DEBUG - 2024-03-11 06:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:23:16 --> Input Class Initialized
INFO - 2024-03-11 06:23:16 --> Language Class Initialized
INFO - 2024-03-11 06:23:16 --> Loader Class Initialized
INFO - 2024-03-11 06:23:16 --> Helper loaded: url_helper
INFO - 2024-03-11 06:23:16 --> Helper loaded: file_helper
INFO - 2024-03-11 06:23:16 --> Helper loaded: html_helper
INFO - 2024-03-11 06:23:16 --> Helper loaded: text_helper
INFO - 2024-03-11 06:23:16 --> Helper loaded: form_helper
INFO - 2024-03-11 06:23:16 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:23:16 --> Helper loaded: security_helper
INFO - 2024-03-11 06:23:16 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:23:16 --> Database Driver Class Initialized
INFO - 2024-03-11 06:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:23:16 --> Parser Class Initialized
INFO - 2024-03-11 06:23:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:23:16 --> Pagination Class Initialized
INFO - 2024-03-11 06:23:16 --> Form Validation Class Initialized
INFO - 2024-03-11 06:23:16 --> Controller Class Initialized
INFO - 2024-03-11 06:23:16 --> Model Class Initialized
DEBUG - 2024-03-11 06:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:23:16 --> Model Class Initialized
DEBUG - 2024-03-11 06:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:23:16 --> Model Class Initialized
INFO - 2024-03-11 06:23:16 --> Model Class Initialized
INFO - 2024-03-11 06:23:16 --> Model Class Initialized
INFO - 2024-03-11 06:23:16 --> Model Class Initialized
DEBUG - 2024-03-11 06:23:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 06:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:23:16 --> Model Class Initialized
INFO - 2024-03-11 06:23:16 --> Model Class Initialized
INFO - 2024-03-11 06:23:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-11 06:23:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:23:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 06:23:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 06:23:16 --> Model Class Initialized
INFO - 2024-03-11 06:23:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 06:23:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 06:23:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 06:23:16 --> Final output sent to browser
DEBUG - 2024-03-11 06:23:16 --> Total execution time: 0.2430
ERROR - 2024-03-11 06:23:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:23:24 --> Config Class Initialized
INFO - 2024-03-11 06:23:24 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:23:24 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:23:24 --> Utf8 Class Initialized
INFO - 2024-03-11 06:23:24 --> URI Class Initialized
INFO - 2024-03-11 06:23:24 --> Router Class Initialized
INFO - 2024-03-11 06:23:24 --> Output Class Initialized
INFO - 2024-03-11 06:23:24 --> Security Class Initialized
DEBUG - 2024-03-11 06:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:23:24 --> Input Class Initialized
INFO - 2024-03-11 06:23:24 --> Language Class Initialized
INFO - 2024-03-11 06:23:24 --> Loader Class Initialized
INFO - 2024-03-11 06:23:24 --> Helper loaded: url_helper
INFO - 2024-03-11 06:23:24 --> Helper loaded: file_helper
INFO - 2024-03-11 06:23:24 --> Helper loaded: html_helper
INFO - 2024-03-11 06:23:24 --> Helper loaded: text_helper
INFO - 2024-03-11 06:23:24 --> Helper loaded: form_helper
INFO - 2024-03-11 06:23:24 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:23:24 --> Helper loaded: security_helper
INFO - 2024-03-11 06:23:24 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:23:24 --> Database Driver Class Initialized
INFO - 2024-03-11 06:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:23:24 --> Parser Class Initialized
INFO - 2024-03-11 06:23:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:23:24 --> Pagination Class Initialized
INFO - 2024-03-11 06:23:24 --> Form Validation Class Initialized
INFO - 2024-03-11 06:23:24 --> Controller Class Initialized
INFO - 2024-03-11 06:23:24 --> Model Class Initialized
DEBUG - 2024-03-11 06:23:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:23:24 --> Final output sent to browser
DEBUG - 2024-03-11 06:23:24 --> Total execution time: 0.0130
ERROR - 2024-03-11 06:23:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 06:23:24 --> Config Class Initialized
INFO - 2024-03-11 06:23:24 --> Hooks Class Initialized
DEBUG - 2024-03-11 06:23:24 --> UTF-8 Support Enabled
INFO - 2024-03-11 06:23:24 --> Utf8 Class Initialized
INFO - 2024-03-11 06:23:24 --> URI Class Initialized
INFO - 2024-03-11 06:23:24 --> Router Class Initialized
INFO - 2024-03-11 06:23:24 --> Output Class Initialized
INFO - 2024-03-11 06:23:24 --> Security Class Initialized
DEBUG - 2024-03-11 06:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 06:23:24 --> Input Class Initialized
INFO - 2024-03-11 06:23:24 --> Language Class Initialized
INFO - 2024-03-11 06:23:24 --> Loader Class Initialized
INFO - 2024-03-11 06:23:24 --> Helper loaded: url_helper
INFO - 2024-03-11 06:23:24 --> Helper loaded: file_helper
INFO - 2024-03-11 06:23:24 --> Helper loaded: html_helper
INFO - 2024-03-11 06:23:24 --> Helper loaded: text_helper
INFO - 2024-03-11 06:23:24 --> Helper loaded: form_helper
INFO - 2024-03-11 06:23:24 --> Helper loaded: lang_helper
INFO - 2024-03-11 06:23:24 --> Helper loaded: security_helper
INFO - 2024-03-11 06:23:24 --> Helper loaded: cookie_helper
INFO - 2024-03-11 06:23:24 --> Database Driver Class Initialized
INFO - 2024-03-11 06:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 06:23:24 --> Parser Class Initialized
INFO - 2024-03-11 06:23:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 06:23:24 --> Pagination Class Initialized
INFO - 2024-03-11 06:23:24 --> Form Validation Class Initialized
INFO - 2024-03-11 06:23:24 --> Controller Class Initialized
INFO - 2024-03-11 06:23:24 --> Model Class Initialized
DEBUG - 2024-03-11 06:23:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:23:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-11 06:23:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 06:23:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 06:23:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 06:23:24 --> Model Class Initialized
INFO - 2024-03-11 06:23:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 06:23:24 --> Final output sent to browser
DEBUG - 2024-03-11 06:23:24 --> Total execution time: 0.0263
ERROR - 2024-03-11 08:08:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 08:08:00 --> Config Class Initialized
INFO - 2024-03-11 08:08:00 --> Hooks Class Initialized
DEBUG - 2024-03-11 08:08:00 --> UTF-8 Support Enabled
INFO - 2024-03-11 08:08:00 --> Utf8 Class Initialized
INFO - 2024-03-11 08:08:00 --> URI Class Initialized
DEBUG - 2024-03-11 08:08:00 --> No URI present. Default controller set.
INFO - 2024-03-11 08:08:00 --> Router Class Initialized
INFO - 2024-03-11 08:08:00 --> Output Class Initialized
INFO - 2024-03-11 08:08:00 --> Security Class Initialized
DEBUG - 2024-03-11 08:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 08:08:00 --> Input Class Initialized
INFO - 2024-03-11 08:08:00 --> Language Class Initialized
INFO - 2024-03-11 08:08:00 --> Loader Class Initialized
INFO - 2024-03-11 08:08:00 --> Helper loaded: url_helper
INFO - 2024-03-11 08:08:00 --> Helper loaded: file_helper
INFO - 2024-03-11 08:08:00 --> Helper loaded: html_helper
INFO - 2024-03-11 08:08:00 --> Helper loaded: text_helper
INFO - 2024-03-11 08:08:00 --> Helper loaded: form_helper
INFO - 2024-03-11 08:08:00 --> Helper loaded: lang_helper
INFO - 2024-03-11 08:08:00 --> Helper loaded: security_helper
INFO - 2024-03-11 08:08:00 --> Helper loaded: cookie_helper
INFO - 2024-03-11 08:08:00 --> Database Driver Class Initialized
INFO - 2024-03-11 08:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 08:08:00 --> Parser Class Initialized
INFO - 2024-03-11 08:08:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 08:08:00 --> Pagination Class Initialized
INFO - 2024-03-11 08:08:00 --> Form Validation Class Initialized
INFO - 2024-03-11 08:08:00 --> Controller Class Initialized
INFO - 2024-03-11 08:08:00 --> Model Class Initialized
DEBUG - 2024-03-11 08:08:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-11 08:08:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 08:08:01 --> Config Class Initialized
INFO - 2024-03-11 08:08:01 --> Hooks Class Initialized
DEBUG - 2024-03-11 08:08:01 --> UTF-8 Support Enabled
INFO - 2024-03-11 08:08:01 --> Utf8 Class Initialized
INFO - 2024-03-11 08:08:01 --> URI Class Initialized
DEBUG - 2024-03-11 08:08:01 --> No URI present. Default controller set.
INFO - 2024-03-11 08:08:01 --> Router Class Initialized
INFO - 2024-03-11 08:08:01 --> Output Class Initialized
INFO - 2024-03-11 08:08:01 --> Security Class Initialized
DEBUG - 2024-03-11 08:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 08:08:01 --> Input Class Initialized
INFO - 2024-03-11 08:08:01 --> Language Class Initialized
INFO - 2024-03-11 08:08:01 --> Loader Class Initialized
INFO - 2024-03-11 08:08:01 --> Helper loaded: url_helper
INFO - 2024-03-11 08:08:01 --> Helper loaded: file_helper
INFO - 2024-03-11 08:08:01 --> Helper loaded: html_helper
INFO - 2024-03-11 08:08:01 --> Helper loaded: text_helper
INFO - 2024-03-11 08:08:01 --> Helper loaded: form_helper
INFO - 2024-03-11 08:08:01 --> Helper loaded: lang_helper
INFO - 2024-03-11 08:08:01 --> Helper loaded: security_helper
INFO - 2024-03-11 08:08:01 --> Helper loaded: cookie_helper
INFO - 2024-03-11 08:08:01 --> Database Driver Class Initialized
INFO - 2024-03-11 08:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 08:08:01 --> Parser Class Initialized
INFO - 2024-03-11 08:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 08:08:01 --> Pagination Class Initialized
INFO - 2024-03-11 08:08:01 --> Form Validation Class Initialized
INFO - 2024-03-11 08:08:01 --> Controller Class Initialized
INFO - 2024-03-11 08:08:01 --> Model Class Initialized
DEBUG - 2024-03-11 08:08:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-11 08:08:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 08:08:02 --> Config Class Initialized
INFO - 2024-03-11 08:08:02 --> Hooks Class Initialized
DEBUG - 2024-03-11 08:08:02 --> UTF-8 Support Enabled
INFO - 2024-03-11 08:08:02 --> Utf8 Class Initialized
INFO - 2024-03-11 08:08:02 --> URI Class Initialized
DEBUG - 2024-03-11 08:08:02 --> No URI present. Default controller set.
INFO - 2024-03-11 08:08:02 --> Router Class Initialized
INFO - 2024-03-11 08:08:02 --> Output Class Initialized
INFO - 2024-03-11 08:08:02 --> Security Class Initialized
DEBUG - 2024-03-11 08:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 08:08:02 --> Input Class Initialized
INFO - 2024-03-11 08:08:02 --> Language Class Initialized
INFO - 2024-03-11 08:08:02 --> Loader Class Initialized
INFO - 2024-03-11 08:08:02 --> Helper loaded: url_helper
INFO - 2024-03-11 08:08:02 --> Helper loaded: file_helper
INFO - 2024-03-11 08:08:02 --> Helper loaded: html_helper
INFO - 2024-03-11 08:08:02 --> Helper loaded: text_helper
INFO - 2024-03-11 08:08:02 --> Helper loaded: form_helper
INFO - 2024-03-11 08:08:02 --> Helper loaded: lang_helper
INFO - 2024-03-11 08:08:02 --> Helper loaded: security_helper
INFO - 2024-03-11 08:08:02 --> Helper loaded: cookie_helper
INFO - 2024-03-11 08:08:02 --> Database Driver Class Initialized
INFO - 2024-03-11 08:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 08:08:02 --> Parser Class Initialized
INFO - 2024-03-11 08:08:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 08:08:02 --> Pagination Class Initialized
INFO - 2024-03-11 08:08:02 --> Form Validation Class Initialized
INFO - 2024-03-11 08:08:02 --> Controller Class Initialized
INFO - 2024-03-11 08:08:02 --> Model Class Initialized
DEBUG - 2024-03-11 08:08:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-11 08:08:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 08:08:02 --> Config Class Initialized
INFO - 2024-03-11 08:08:02 --> Hooks Class Initialized
DEBUG - 2024-03-11 08:08:02 --> UTF-8 Support Enabled
INFO - 2024-03-11 08:08:02 --> Utf8 Class Initialized
INFO - 2024-03-11 08:08:02 --> URI Class Initialized
DEBUG - 2024-03-11 08:08:02 --> No URI present. Default controller set.
INFO - 2024-03-11 08:08:02 --> Router Class Initialized
INFO - 2024-03-11 08:08:02 --> Output Class Initialized
INFO - 2024-03-11 08:08:02 --> Security Class Initialized
DEBUG - 2024-03-11 08:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 08:08:02 --> Input Class Initialized
INFO - 2024-03-11 08:08:02 --> Language Class Initialized
INFO - 2024-03-11 08:08:02 --> Loader Class Initialized
INFO - 2024-03-11 08:08:02 --> Helper loaded: url_helper
INFO - 2024-03-11 08:08:02 --> Helper loaded: file_helper
INFO - 2024-03-11 08:08:02 --> Helper loaded: html_helper
INFO - 2024-03-11 08:08:02 --> Helper loaded: text_helper
INFO - 2024-03-11 08:08:02 --> Helper loaded: form_helper
INFO - 2024-03-11 08:08:02 --> Helper loaded: lang_helper
INFO - 2024-03-11 08:08:02 --> Helper loaded: security_helper
INFO - 2024-03-11 08:08:02 --> Helper loaded: cookie_helper
INFO - 2024-03-11 08:08:02 --> Database Driver Class Initialized
INFO - 2024-03-11 08:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 08:08:02 --> Parser Class Initialized
INFO - 2024-03-11 08:08:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 08:08:02 --> Pagination Class Initialized
INFO - 2024-03-11 08:08:02 --> Form Validation Class Initialized
INFO - 2024-03-11 08:08:02 --> Controller Class Initialized
INFO - 2024-03-11 08:08:02 --> Model Class Initialized
DEBUG - 2024-03-11 08:08:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-11 08:08:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 08:08:03 --> Config Class Initialized
INFO - 2024-03-11 08:08:03 --> Hooks Class Initialized
DEBUG - 2024-03-11 08:08:03 --> UTF-8 Support Enabled
INFO - 2024-03-11 08:08:03 --> Utf8 Class Initialized
INFO - 2024-03-11 08:08:03 --> URI Class Initialized
DEBUG - 2024-03-11 08:08:03 --> No URI present. Default controller set.
INFO - 2024-03-11 08:08:03 --> Router Class Initialized
INFO - 2024-03-11 08:08:03 --> Output Class Initialized
INFO - 2024-03-11 08:08:03 --> Security Class Initialized
DEBUG - 2024-03-11 08:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 08:08:03 --> Input Class Initialized
INFO - 2024-03-11 08:08:03 --> Language Class Initialized
INFO - 2024-03-11 08:08:03 --> Loader Class Initialized
INFO - 2024-03-11 08:08:03 --> Helper loaded: url_helper
INFO - 2024-03-11 08:08:03 --> Helper loaded: file_helper
INFO - 2024-03-11 08:08:03 --> Helper loaded: html_helper
INFO - 2024-03-11 08:08:03 --> Helper loaded: text_helper
INFO - 2024-03-11 08:08:03 --> Helper loaded: form_helper
INFO - 2024-03-11 08:08:03 --> Helper loaded: lang_helper
INFO - 2024-03-11 08:08:03 --> Helper loaded: security_helper
INFO - 2024-03-11 08:08:03 --> Helper loaded: cookie_helper
INFO - 2024-03-11 08:08:03 --> Database Driver Class Initialized
INFO - 2024-03-11 08:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 08:08:03 --> Parser Class Initialized
INFO - 2024-03-11 08:08:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 08:08:03 --> Pagination Class Initialized
INFO - 2024-03-11 08:08:03 --> Form Validation Class Initialized
INFO - 2024-03-11 08:08:03 --> Controller Class Initialized
INFO - 2024-03-11 08:08:03 --> Model Class Initialized
DEBUG - 2024-03-11 08:08:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-11 08:08:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 08:08:03 --> Config Class Initialized
INFO - 2024-03-11 08:08:03 --> Hooks Class Initialized
DEBUG - 2024-03-11 08:08:03 --> UTF-8 Support Enabled
INFO - 2024-03-11 08:08:03 --> Utf8 Class Initialized
INFO - 2024-03-11 08:08:03 --> URI Class Initialized
DEBUG - 2024-03-11 08:08:03 --> No URI present. Default controller set.
INFO - 2024-03-11 08:08:03 --> Router Class Initialized
INFO - 2024-03-11 08:08:03 --> Output Class Initialized
INFO - 2024-03-11 08:08:03 --> Security Class Initialized
DEBUG - 2024-03-11 08:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 08:08:03 --> Input Class Initialized
INFO - 2024-03-11 08:08:03 --> Language Class Initialized
INFO - 2024-03-11 08:08:03 --> Loader Class Initialized
INFO - 2024-03-11 08:08:03 --> Helper loaded: url_helper
INFO - 2024-03-11 08:08:03 --> Helper loaded: file_helper
INFO - 2024-03-11 08:08:03 --> Helper loaded: html_helper
INFO - 2024-03-11 08:08:03 --> Helper loaded: text_helper
INFO - 2024-03-11 08:08:03 --> Helper loaded: form_helper
INFO - 2024-03-11 08:08:03 --> Helper loaded: lang_helper
INFO - 2024-03-11 08:08:03 --> Helper loaded: security_helper
INFO - 2024-03-11 08:08:03 --> Helper loaded: cookie_helper
INFO - 2024-03-11 08:08:03 --> Database Driver Class Initialized
INFO - 2024-03-11 08:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 08:08:03 --> Parser Class Initialized
INFO - 2024-03-11 08:08:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 08:08:03 --> Pagination Class Initialized
INFO - 2024-03-11 08:08:03 --> Form Validation Class Initialized
INFO - 2024-03-11 08:08:03 --> Controller Class Initialized
INFO - 2024-03-11 08:08:03 --> Model Class Initialized
DEBUG - 2024-03-11 08:08:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-11 08:08:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 08:08:10 --> Config Class Initialized
INFO - 2024-03-11 08:08:10 --> Hooks Class Initialized
DEBUG - 2024-03-11 08:08:10 --> UTF-8 Support Enabled
INFO - 2024-03-11 08:08:10 --> Utf8 Class Initialized
INFO - 2024-03-11 08:08:10 --> URI Class Initialized
DEBUG - 2024-03-11 08:08:10 --> No URI present. Default controller set.
INFO - 2024-03-11 08:08:10 --> Router Class Initialized
INFO - 2024-03-11 08:08:10 --> Output Class Initialized
INFO - 2024-03-11 08:08:10 --> Security Class Initialized
DEBUG - 2024-03-11 08:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 08:08:10 --> Input Class Initialized
INFO - 2024-03-11 08:08:10 --> Language Class Initialized
INFO - 2024-03-11 08:08:10 --> Loader Class Initialized
INFO - 2024-03-11 08:08:10 --> Helper loaded: url_helper
INFO - 2024-03-11 08:08:10 --> Helper loaded: file_helper
INFO - 2024-03-11 08:08:10 --> Helper loaded: html_helper
INFO - 2024-03-11 08:08:10 --> Helper loaded: text_helper
INFO - 2024-03-11 08:08:10 --> Helper loaded: form_helper
INFO - 2024-03-11 08:08:10 --> Helper loaded: lang_helper
INFO - 2024-03-11 08:08:10 --> Helper loaded: security_helper
INFO - 2024-03-11 08:08:10 --> Helper loaded: cookie_helper
INFO - 2024-03-11 08:08:10 --> Database Driver Class Initialized
INFO - 2024-03-11 08:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 08:08:10 --> Parser Class Initialized
INFO - 2024-03-11 08:08:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 08:08:10 --> Pagination Class Initialized
INFO - 2024-03-11 08:08:10 --> Form Validation Class Initialized
INFO - 2024-03-11 08:08:10 --> Controller Class Initialized
INFO - 2024-03-11 08:08:10 --> Model Class Initialized
DEBUG - 2024-03-11 08:08:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-11 08:08:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 08:08:10 --> Config Class Initialized
INFO - 2024-03-11 08:08:10 --> Hooks Class Initialized
DEBUG - 2024-03-11 08:08:10 --> UTF-8 Support Enabled
INFO - 2024-03-11 08:08:10 --> Utf8 Class Initialized
INFO - 2024-03-11 08:08:10 --> URI Class Initialized
DEBUG - 2024-03-11 08:08:10 --> No URI present. Default controller set.
INFO - 2024-03-11 08:08:10 --> Router Class Initialized
INFO - 2024-03-11 08:08:10 --> Output Class Initialized
INFO - 2024-03-11 08:08:10 --> Security Class Initialized
DEBUG - 2024-03-11 08:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 08:08:10 --> Input Class Initialized
INFO - 2024-03-11 08:08:10 --> Language Class Initialized
INFO - 2024-03-11 08:08:10 --> Loader Class Initialized
INFO - 2024-03-11 08:08:10 --> Helper loaded: url_helper
INFO - 2024-03-11 08:08:10 --> Helper loaded: file_helper
INFO - 2024-03-11 08:08:10 --> Helper loaded: html_helper
INFO - 2024-03-11 08:08:10 --> Helper loaded: text_helper
INFO - 2024-03-11 08:08:10 --> Helper loaded: form_helper
INFO - 2024-03-11 08:08:10 --> Helper loaded: lang_helper
INFO - 2024-03-11 08:08:10 --> Helper loaded: security_helper
INFO - 2024-03-11 08:08:10 --> Helper loaded: cookie_helper
INFO - 2024-03-11 08:08:10 --> Database Driver Class Initialized
INFO - 2024-03-11 08:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 08:08:10 --> Parser Class Initialized
INFO - 2024-03-11 08:08:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 08:08:10 --> Pagination Class Initialized
INFO - 2024-03-11 08:08:10 --> Form Validation Class Initialized
INFO - 2024-03-11 08:08:10 --> Controller Class Initialized
INFO - 2024-03-11 08:08:10 --> Model Class Initialized
DEBUG - 2024-03-11 08:08:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-11 08:10:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 08:10:14 --> Config Class Initialized
INFO - 2024-03-11 08:10:14 --> Hooks Class Initialized
DEBUG - 2024-03-11 08:10:14 --> UTF-8 Support Enabled
INFO - 2024-03-11 08:10:14 --> Utf8 Class Initialized
INFO - 2024-03-11 08:10:14 --> URI Class Initialized
DEBUG - 2024-03-11 08:10:14 --> No URI present. Default controller set.
INFO - 2024-03-11 08:10:14 --> Router Class Initialized
INFO - 2024-03-11 08:10:14 --> Output Class Initialized
INFO - 2024-03-11 08:10:14 --> Security Class Initialized
DEBUG - 2024-03-11 08:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 08:10:14 --> Input Class Initialized
INFO - 2024-03-11 08:10:14 --> Language Class Initialized
INFO - 2024-03-11 08:10:14 --> Loader Class Initialized
INFO - 2024-03-11 08:10:14 --> Helper loaded: url_helper
INFO - 2024-03-11 08:10:14 --> Helper loaded: file_helper
INFO - 2024-03-11 08:10:14 --> Helper loaded: html_helper
INFO - 2024-03-11 08:10:14 --> Helper loaded: text_helper
INFO - 2024-03-11 08:10:14 --> Helper loaded: form_helper
INFO - 2024-03-11 08:10:14 --> Helper loaded: lang_helper
INFO - 2024-03-11 08:10:14 --> Helper loaded: security_helper
INFO - 2024-03-11 08:10:14 --> Helper loaded: cookie_helper
INFO - 2024-03-11 08:10:14 --> Database Driver Class Initialized
INFO - 2024-03-11 08:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 08:10:14 --> Parser Class Initialized
INFO - 2024-03-11 08:10:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 08:10:14 --> Pagination Class Initialized
INFO - 2024-03-11 08:10:14 --> Form Validation Class Initialized
INFO - 2024-03-11 08:10:14 --> Controller Class Initialized
INFO - 2024-03-11 08:10:14 --> Model Class Initialized
DEBUG - 2024-03-11 08:10:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-11 08:10:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 08:10:16 --> Config Class Initialized
INFO - 2024-03-11 08:10:16 --> Hooks Class Initialized
DEBUG - 2024-03-11 08:10:16 --> UTF-8 Support Enabled
INFO - 2024-03-11 08:10:16 --> Utf8 Class Initialized
INFO - 2024-03-11 08:10:16 --> URI Class Initialized
INFO - 2024-03-11 08:10:16 --> Router Class Initialized
INFO - 2024-03-11 08:10:16 --> Output Class Initialized
INFO - 2024-03-11 08:10:16 --> Security Class Initialized
DEBUG - 2024-03-11 08:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 08:10:16 --> Input Class Initialized
INFO - 2024-03-11 08:10:16 --> Language Class Initialized
INFO - 2024-03-11 08:10:16 --> Loader Class Initialized
INFO - 2024-03-11 08:10:16 --> Helper loaded: url_helper
INFO - 2024-03-11 08:10:16 --> Helper loaded: file_helper
INFO - 2024-03-11 08:10:16 --> Helper loaded: html_helper
INFO - 2024-03-11 08:10:16 --> Helper loaded: text_helper
INFO - 2024-03-11 08:10:16 --> Helper loaded: form_helper
INFO - 2024-03-11 08:10:16 --> Helper loaded: lang_helper
INFO - 2024-03-11 08:10:16 --> Helper loaded: security_helper
INFO - 2024-03-11 08:10:16 --> Helper loaded: cookie_helper
INFO - 2024-03-11 08:10:16 --> Database Driver Class Initialized
INFO - 2024-03-11 08:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 08:10:16 --> Parser Class Initialized
INFO - 2024-03-11 08:10:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 08:10:16 --> Pagination Class Initialized
INFO - 2024-03-11 08:10:16 --> Form Validation Class Initialized
INFO - 2024-03-11 08:10:16 --> Controller Class Initialized
INFO - 2024-03-11 08:10:16 --> Model Class Initialized
DEBUG - 2024-03-11 08:10:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 08:10:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-11 08:10:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 08:10:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 08:10:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 08:10:16 --> Model Class Initialized
INFO - 2024-03-11 08:10:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 08:10:16 --> Final output sent to browser
DEBUG - 2024-03-11 08:10:16 --> Total execution time: 0.0329
ERROR - 2024-03-11 08:10:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 08:10:37 --> Config Class Initialized
INFO - 2024-03-11 08:10:37 --> Hooks Class Initialized
DEBUG - 2024-03-11 08:10:37 --> UTF-8 Support Enabled
INFO - 2024-03-11 08:10:37 --> Utf8 Class Initialized
INFO - 2024-03-11 08:10:37 --> URI Class Initialized
INFO - 2024-03-11 08:10:37 --> Router Class Initialized
INFO - 2024-03-11 08:10:37 --> Output Class Initialized
INFO - 2024-03-11 08:10:37 --> Security Class Initialized
DEBUG - 2024-03-11 08:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 08:10:37 --> Input Class Initialized
INFO - 2024-03-11 08:10:37 --> Language Class Initialized
INFO - 2024-03-11 08:10:37 --> Loader Class Initialized
INFO - 2024-03-11 08:10:37 --> Helper loaded: url_helper
INFO - 2024-03-11 08:10:37 --> Helper loaded: file_helper
INFO - 2024-03-11 08:10:37 --> Helper loaded: html_helper
INFO - 2024-03-11 08:10:37 --> Helper loaded: text_helper
INFO - 2024-03-11 08:10:37 --> Helper loaded: form_helper
INFO - 2024-03-11 08:10:37 --> Helper loaded: lang_helper
INFO - 2024-03-11 08:10:37 --> Helper loaded: security_helper
INFO - 2024-03-11 08:10:37 --> Helper loaded: cookie_helper
INFO - 2024-03-11 08:10:37 --> Database Driver Class Initialized
INFO - 2024-03-11 08:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 08:10:37 --> Parser Class Initialized
INFO - 2024-03-11 08:10:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 08:10:37 --> Pagination Class Initialized
INFO - 2024-03-11 08:10:37 --> Form Validation Class Initialized
INFO - 2024-03-11 08:10:37 --> Controller Class Initialized
INFO - 2024-03-11 08:10:37 --> Model Class Initialized
DEBUG - 2024-03-11 08:10:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 08:10:37 --> Model Class Initialized
INFO - 2024-03-11 08:10:37 --> Final output sent to browser
DEBUG - 2024-03-11 08:10:37 --> Total execution time: 0.0218
ERROR - 2024-03-11 08:10:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 08:10:37 --> Config Class Initialized
INFO - 2024-03-11 08:10:37 --> Hooks Class Initialized
DEBUG - 2024-03-11 08:10:37 --> UTF-8 Support Enabled
INFO - 2024-03-11 08:10:37 --> Utf8 Class Initialized
INFO - 2024-03-11 08:10:37 --> URI Class Initialized
DEBUG - 2024-03-11 08:10:37 --> No URI present. Default controller set.
INFO - 2024-03-11 08:10:37 --> Router Class Initialized
INFO - 2024-03-11 08:10:37 --> Output Class Initialized
INFO - 2024-03-11 08:10:37 --> Security Class Initialized
DEBUG - 2024-03-11 08:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 08:10:37 --> Input Class Initialized
INFO - 2024-03-11 08:10:37 --> Language Class Initialized
INFO - 2024-03-11 08:10:37 --> Loader Class Initialized
INFO - 2024-03-11 08:10:37 --> Helper loaded: url_helper
INFO - 2024-03-11 08:10:37 --> Helper loaded: file_helper
INFO - 2024-03-11 08:10:37 --> Helper loaded: html_helper
INFO - 2024-03-11 08:10:37 --> Helper loaded: text_helper
INFO - 2024-03-11 08:10:37 --> Helper loaded: form_helper
INFO - 2024-03-11 08:10:37 --> Helper loaded: lang_helper
INFO - 2024-03-11 08:10:37 --> Helper loaded: security_helper
INFO - 2024-03-11 08:10:37 --> Helper loaded: cookie_helper
INFO - 2024-03-11 08:10:37 --> Database Driver Class Initialized
INFO - 2024-03-11 08:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 08:10:37 --> Parser Class Initialized
INFO - 2024-03-11 08:10:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 08:10:37 --> Pagination Class Initialized
INFO - 2024-03-11 08:10:37 --> Form Validation Class Initialized
INFO - 2024-03-11 08:10:37 --> Controller Class Initialized
INFO - 2024-03-11 08:10:37 --> Model Class Initialized
DEBUG - 2024-03-11 08:10:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 08:10:37 --> Model Class Initialized
DEBUG - 2024-03-11 08:10:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 08:10:37 --> Model Class Initialized
INFO - 2024-03-11 08:10:37 --> Model Class Initialized
INFO - 2024-03-11 08:10:37 --> Model Class Initialized
INFO - 2024-03-11 08:10:37 --> Model Class Initialized
DEBUG - 2024-03-11 08:10:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 08:10:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 08:10:37 --> Model Class Initialized
INFO - 2024-03-11 08:10:37 --> Model Class Initialized
INFO - 2024-03-11 08:10:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-11 08:10:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 08:10:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 08:10:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 08:10:37 --> Model Class Initialized
INFO - 2024-03-11 08:10:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 08:10:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 08:10:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 08:10:37 --> Final output sent to browser
DEBUG - 2024-03-11 08:10:37 --> Total execution time: 0.2774
ERROR - 2024-03-11 08:17:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 08:17:25 --> Config Class Initialized
INFO - 2024-03-11 08:17:25 --> Hooks Class Initialized
DEBUG - 2024-03-11 08:17:25 --> UTF-8 Support Enabled
INFO - 2024-03-11 08:17:25 --> Utf8 Class Initialized
INFO - 2024-03-11 08:17:25 --> URI Class Initialized
INFO - 2024-03-11 08:17:25 --> Router Class Initialized
INFO - 2024-03-11 08:17:25 --> Output Class Initialized
INFO - 2024-03-11 08:17:25 --> Security Class Initialized
DEBUG - 2024-03-11 08:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 08:17:25 --> Input Class Initialized
INFO - 2024-03-11 08:17:25 --> Language Class Initialized
INFO - 2024-03-11 08:17:25 --> Loader Class Initialized
INFO - 2024-03-11 08:17:25 --> Helper loaded: url_helper
INFO - 2024-03-11 08:17:25 --> Helper loaded: file_helper
INFO - 2024-03-11 08:17:25 --> Helper loaded: html_helper
INFO - 2024-03-11 08:17:25 --> Helper loaded: text_helper
INFO - 2024-03-11 08:17:25 --> Helper loaded: form_helper
INFO - 2024-03-11 08:17:25 --> Helper loaded: lang_helper
INFO - 2024-03-11 08:17:25 --> Helper loaded: security_helper
INFO - 2024-03-11 08:17:25 --> Helper loaded: cookie_helper
INFO - 2024-03-11 08:17:25 --> Database Driver Class Initialized
INFO - 2024-03-11 08:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 08:17:25 --> Parser Class Initialized
INFO - 2024-03-11 08:17:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 08:17:25 --> Pagination Class Initialized
INFO - 2024-03-11 08:17:25 --> Form Validation Class Initialized
INFO - 2024-03-11 08:17:25 --> Controller Class Initialized
INFO - 2024-03-11 08:17:25 --> Model Class Initialized
DEBUG - 2024-03-11 08:17:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 08:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 08:17:25 --> Model Class Initialized
DEBUG - 2024-03-11 08:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 08:17:25 --> Model Class Initialized
INFO - 2024-03-11 08:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-11 08:17:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 08:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 08:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 08:17:25 --> Model Class Initialized
INFO - 2024-03-11 08:17:25 --> Model Class Initialized
INFO - 2024-03-11 08:17:25 --> Model Class Initialized
INFO - 2024-03-11 08:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 08:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 08:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 08:17:25 --> Final output sent to browser
DEBUG - 2024-03-11 08:17:25 --> Total execution time: 0.1595
ERROR - 2024-03-11 08:17:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 08:17:26 --> Config Class Initialized
INFO - 2024-03-11 08:17:26 --> Hooks Class Initialized
DEBUG - 2024-03-11 08:17:26 --> UTF-8 Support Enabled
INFO - 2024-03-11 08:17:26 --> Utf8 Class Initialized
INFO - 2024-03-11 08:17:26 --> URI Class Initialized
INFO - 2024-03-11 08:17:26 --> Router Class Initialized
INFO - 2024-03-11 08:17:26 --> Output Class Initialized
INFO - 2024-03-11 08:17:26 --> Security Class Initialized
DEBUG - 2024-03-11 08:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 08:17:26 --> Input Class Initialized
INFO - 2024-03-11 08:17:26 --> Language Class Initialized
INFO - 2024-03-11 08:17:26 --> Loader Class Initialized
INFO - 2024-03-11 08:17:26 --> Helper loaded: url_helper
INFO - 2024-03-11 08:17:26 --> Helper loaded: file_helper
INFO - 2024-03-11 08:17:26 --> Helper loaded: html_helper
INFO - 2024-03-11 08:17:26 --> Helper loaded: text_helper
INFO - 2024-03-11 08:17:26 --> Helper loaded: form_helper
INFO - 2024-03-11 08:17:26 --> Helper loaded: lang_helper
INFO - 2024-03-11 08:17:26 --> Helper loaded: security_helper
INFO - 2024-03-11 08:17:26 --> Helper loaded: cookie_helper
INFO - 2024-03-11 08:17:26 --> Database Driver Class Initialized
INFO - 2024-03-11 08:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 08:17:26 --> Parser Class Initialized
INFO - 2024-03-11 08:17:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 08:17:26 --> Pagination Class Initialized
INFO - 2024-03-11 08:17:26 --> Form Validation Class Initialized
INFO - 2024-03-11 08:17:26 --> Controller Class Initialized
INFO - 2024-03-11 08:17:26 --> Model Class Initialized
DEBUG - 2024-03-11 08:17:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 08:17:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 08:17:26 --> Model Class Initialized
DEBUG - 2024-03-11 08:17:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 08:17:26 --> Model Class Initialized
INFO - 2024-03-11 08:17:26 --> Final output sent to browser
DEBUG - 2024-03-11 08:17:26 --> Total execution time: 0.0398
ERROR - 2024-03-11 12:22:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 12:22:22 --> Config Class Initialized
INFO - 2024-03-11 12:22:22 --> Hooks Class Initialized
DEBUG - 2024-03-11 12:22:22 --> UTF-8 Support Enabled
INFO - 2024-03-11 12:22:22 --> Utf8 Class Initialized
INFO - 2024-03-11 12:22:22 --> URI Class Initialized
DEBUG - 2024-03-11 12:22:22 --> No URI present. Default controller set.
INFO - 2024-03-11 12:22:22 --> Router Class Initialized
INFO - 2024-03-11 12:22:22 --> Output Class Initialized
INFO - 2024-03-11 12:22:22 --> Security Class Initialized
DEBUG - 2024-03-11 12:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 12:22:22 --> Input Class Initialized
INFO - 2024-03-11 12:22:22 --> Language Class Initialized
INFO - 2024-03-11 12:22:22 --> Loader Class Initialized
INFO - 2024-03-11 12:22:22 --> Helper loaded: url_helper
INFO - 2024-03-11 12:22:22 --> Helper loaded: file_helper
INFO - 2024-03-11 12:22:22 --> Helper loaded: html_helper
INFO - 2024-03-11 12:22:22 --> Helper loaded: text_helper
INFO - 2024-03-11 12:22:22 --> Helper loaded: form_helper
INFO - 2024-03-11 12:22:22 --> Helper loaded: lang_helper
INFO - 2024-03-11 12:22:22 --> Helper loaded: security_helper
INFO - 2024-03-11 12:22:22 --> Helper loaded: cookie_helper
INFO - 2024-03-11 12:22:22 --> Database Driver Class Initialized
INFO - 2024-03-11 12:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 12:22:22 --> Parser Class Initialized
INFO - 2024-03-11 12:22:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 12:22:22 --> Pagination Class Initialized
INFO - 2024-03-11 12:22:22 --> Form Validation Class Initialized
INFO - 2024-03-11 12:22:22 --> Controller Class Initialized
INFO - 2024-03-11 12:22:22 --> Model Class Initialized
DEBUG - 2024-03-11 12:22:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-11 15:23:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 15:23:23 --> Config Class Initialized
INFO - 2024-03-11 15:23:23 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:23:23 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:23:23 --> Utf8 Class Initialized
INFO - 2024-03-11 15:23:23 --> URI Class Initialized
DEBUG - 2024-03-11 15:23:23 --> No URI present. Default controller set.
INFO - 2024-03-11 15:23:23 --> Router Class Initialized
INFO - 2024-03-11 15:23:23 --> Output Class Initialized
INFO - 2024-03-11 15:23:23 --> Security Class Initialized
DEBUG - 2024-03-11 15:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:23:23 --> Input Class Initialized
INFO - 2024-03-11 15:23:23 --> Language Class Initialized
INFO - 2024-03-11 15:23:23 --> Loader Class Initialized
INFO - 2024-03-11 15:23:23 --> Helper loaded: url_helper
INFO - 2024-03-11 15:23:23 --> Helper loaded: file_helper
INFO - 2024-03-11 15:23:23 --> Helper loaded: html_helper
INFO - 2024-03-11 15:23:23 --> Helper loaded: text_helper
INFO - 2024-03-11 15:23:23 --> Helper loaded: form_helper
INFO - 2024-03-11 15:23:23 --> Helper loaded: lang_helper
INFO - 2024-03-11 15:23:23 --> Helper loaded: security_helper
INFO - 2024-03-11 15:23:23 --> Helper loaded: cookie_helper
INFO - 2024-03-11 15:23:23 --> Database Driver Class Initialized
INFO - 2024-03-11 15:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:23:23 --> Parser Class Initialized
INFO - 2024-03-11 15:23:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 15:23:23 --> Pagination Class Initialized
INFO - 2024-03-11 15:23:23 --> Form Validation Class Initialized
INFO - 2024-03-11 15:23:23 --> Controller Class Initialized
INFO - 2024-03-11 15:23:23 --> Model Class Initialized
DEBUG - 2024-03-11 15:23:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-11 15:23:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 15:23:23 --> Config Class Initialized
INFO - 2024-03-11 15:23:23 --> Hooks Class Initialized
DEBUG - 2024-03-11 15:23:23 --> UTF-8 Support Enabled
INFO - 2024-03-11 15:23:23 --> Utf8 Class Initialized
INFO - 2024-03-11 15:23:23 --> URI Class Initialized
INFO - 2024-03-11 15:23:23 --> Router Class Initialized
INFO - 2024-03-11 15:23:23 --> Output Class Initialized
INFO - 2024-03-11 15:23:23 --> Security Class Initialized
DEBUG - 2024-03-11 15:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 15:23:23 --> Input Class Initialized
INFO - 2024-03-11 15:23:23 --> Language Class Initialized
INFO - 2024-03-11 15:23:23 --> Loader Class Initialized
INFO - 2024-03-11 15:23:23 --> Helper loaded: url_helper
INFO - 2024-03-11 15:23:23 --> Helper loaded: file_helper
INFO - 2024-03-11 15:23:23 --> Helper loaded: html_helper
INFO - 2024-03-11 15:23:23 --> Helper loaded: text_helper
INFO - 2024-03-11 15:23:23 --> Helper loaded: form_helper
INFO - 2024-03-11 15:23:23 --> Helper loaded: lang_helper
INFO - 2024-03-11 15:23:23 --> Helper loaded: security_helper
INFO - 2024-03-11 15:23:23 --> Helper loaded: cookie_helper
INFO - 2024-03-11 15:23:23 --> Database Driver Class Initialized
INFO - 2024-03-11 15:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 15:23:23 --> Parser Class Initialized
INFO - 2024-03-11 15:23:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 15:23:23 --> Pagination Class Initialized
INFO - 2024-03-11 15:23:23 --> Form Validation Class Initialized
INFO - 2024-03-11 15:23:23 --> Controller Class Initialized
INFO - 2024-03-11 15:23:23 --> Model Class Initialized
DEBUG - 2024-03-11 15:23:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 15:23:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-11 15:23:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 15:23:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 15:23:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 15:23:23 --> Model Class Initialized
INFO - 2024-03-11 15:23:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 15:23:23 --> Final output sent to browser
DEBUG - 2024-03-11 15:23:23 --> Total execution time: 0.0361
ERROR - 2024-03-11 16:04:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 16:04:21 --> Config Class Initialized
INFO - 2024-03-11 16:04:21 --> Hooks Class Initialized
DEBUG - 2024-03-11 16:04:21 --> UTF-8 Support Enabled
INFO - 2024-03-11 16:04:21 --> Utf8 Class Initialized
INFO - 2024-03-11 16:04:21 --> URI Class Initialized
DEBUG - 2024-03-11 16:04:21 --> No URI present. Default controller set.
INFO - 2024-03-11 16:04:21 --> Router Class Initialized
INFO - 2024-03-11 16:04:21 --> Output Class Initialized
INFO - 2024-03-11 16:04:21 --> Security Class Initialized
DEBUG - 2024-03-11 16:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 16:04:21 --> Input Class Initialized
INFO - 2024-03-11 16:04:21 --> Language Class Initialized
INFO - 2024-03-11 16:04:21 --> Loader Class Initialized
INFO - 2024-03-11 16:04:21 --> Helper loaded: url_helper
INFO - 2024-03-11 16:04:21 --> Helper loaded: file_helper
INFO - 2024-03-11 16:04:21 --> Helper loaded: html_helper
INFO - 2024-03-11 16:04:21 --> Helper loaded: text_helper
INFO - 2024-03-11 16:04:21 --> Helper loaded: form_helper
INFO - 2024-03-11 16:04:21 --> Helper loaded: lang_helper
INFO - 2024-03-11 16:04:21 --> Helper loaded: security_helper
INFO - 2024-03-11 16:04:21 --> Helper loaded: cookie_helper
INFO - 2024-03-11 16:04:21 --> Database Driver Class Initialized
INFO - 2024-03-11 16:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 16:04:21 --> Parser Class Initialized
INFO - 2024-03-11 16:04:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 16:04:21 --> Pagination Class Initialized
INFO - 2024-03-11 16:04:21 --> Form Validation Class Initialized
INFO - 2024-03-11 16:04:21 --> Controller Class Initialized
INFO - 2024-03-11 16:04:21 --> Model Class Initialized
DEBUG - 2024-03-11 16:04:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-11 16:04:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 16:04:22 --> Config Class Initialized
INFO - 2024-03-11 16:04:22 --> Hooks Class Initialized
DEBUG - 2024-03-11 16:04:22 --> UTF-8 Support Enabled
INFO - 2024-03-11 16:04:22 --> Utf8 Class Initialized
INFO - 2024-03-11 16:04:22 --> URI Class Initialized
INFO - 2024-03-11 16:04:22 --> Router Class Initialized
INFO - 2024-03-11 16:04:22 --> Output Class Initialized
INFO - 2024-03-11 16:04:22 --> Security Class Initialized
DEBUG - 2024-03-11 16:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 16:04:22 --> Input Class Initialized
INFO - 2024-03-11 16:04:22 --> Language Class Initialized
INFO - 2024-03-11 16:04:22 --> Loader Class Initialized
INFO - 2024-03-11 16:04:22 --> Helper loaded: url_helper
INFO - 2024-03-11 16:04:22 --> Helper loaded: file_helper
INFO - 2024-03-11 16:04:22 --> Helper loaded: html_helper
INFO - 2024-03-11 16:04:22 --> Helper loaded: text_helper
INFO - 2024-03-11 16:04:22 --> Helper loaded: form_helper
INFO - 2024-03-11 16:04:22 --> Helper loaded: lang_helper
INFO - 2024-03-11 16:04:22 --> Helper loaded: security_helper
INFO - 2024-03-11 16:04:22 --> Helper loaded: cookie_helper
INFO - 2024-03-11 16:04:22 --> Database Driver Class Initialized
INFO - 2024-03-11 16:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 16:04:22 --> Parser Class Initialized
INFO - 2024-03-11 16:04:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 16:04:22 --> Pagination Class Initialized
INFO - 2024-03-11 16:04:22 --> Form Validation Class Initialized
INFO - 2024-03-11 16:04:22 --> Controller Class Initialized
INFO - 2024-03-11 16:04:22 --> Model Class Initialized
DEBUG - 2024-03-11 16:04:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:04:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-11 16:04:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:04:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 16:04:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 16:04:22 --> Model Class Initialized
INFO - 2024-03-11 16:04:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 16:04:22 --> Final output sent to browser
DEBUG - 2024-03-11 16:04:22 --> Total execution time: 0.0371
ERROR - 2024-03-11 16:04:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 16:04:32 --> Config Class Initialized
INFO - 2024-03-11 16:04:32 --> Hooks Class Initialized
DEBUG - 2024-03-11 16:04:32 --> UTF-8 Support Enabled
INFO - 2024-03-11 16:04:32 --> Utf8 Class Initialized
INFO - 2024-03-11 16:04:32 --> URI Class Initialized
INFO - 2024-03-11 16:04:32 --> Router Class Initialized
INFO - 2024-03-11 16:04:32 --> Output Class Initialized
INFO - 2024-03-11 16:04:32 --> Security Class Initialized
DEBUG - 2024-03-11 16:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 16:04:32 --> Input Class Initialized
INFO - 2024-03-11 16:04:32 --> Language Class Initialized
INFO - 2024-03-11 16:04:32 --> Loader Class Initialized
INFO - 2024-03-11 16:04:32 --> Helper loaded: url_helper
INFO - 2024-03-11 16:04:32 --> Helper loaded: file_helper
INFO - 2024-03-11 16:04:32 --> Helper loaded: html_helper
INFO - 2024-03-11 16:04:32 --> Helper loaded: text_helper
INFO - 2024-03-11 16:04:32 --> Helper loaded: form_helper
INFO - 2024-03-11 16:04:32 --> Helper loaded: lang_helper
INFO - 2024-03-11 16:04:32 --> Helper loaded: security_helper
INFO - 2024-03-11 16:04:32 --> Helper loaded: cookie_helper
INFO - 2024-03-11 16:04:32 --> Database Driver Class Initialized
INFO - 2024-03-11 16:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 16:04:32 --> Parser Class Initialized
INFO - 2024-03-11 16:04:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 16:04:33 --> Pagination Class Initialized
INFO - 2024-03-11 16:04:33 --> Form Validation Class Initialized
INFO - 2024-03-11 16:04:33 --> Controller Class Initialized
INFO - 2024-03-11 16:04:33 --> Model Class Initialized
DEBUG - 2024-03-11 16:04:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:04:33 --> Model Class Initialized
INFO - 2024-03-11 16:04:33 --> Final output sent to browser
DEBUG - 2024-03-11 16:04:33 --> Total execution time: 0.0190
ERROR - 2024-03-11 16:04:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 16:04:33 --> Config Class Initialized
INFO - 2024-03-11 16:04:33 --> Hooks Class Initialized
DEBUG - 2024-03-11 16:04:33 --> UTF-8 Support Enabled
INFO - 2024-03-11 16:04:33 --> Utf8 Class Initialized
INFO - 2024-03-11 16:04:33 --> URI Class Initialized
DEBUG - 2024-03-11 16:04:33 --> No URI present. Default controller set.
INFO - 2024-03-11 16:04:33 --> Router Class Initialized
INFO - 2024-03-11 16:04:33 --> Output Class Initialized
INFO - 2024-03-11 16:04:33 --> Security Class Initialized
DEBUG - 2024-03-11 16:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 16:04:33 --> Input Class Initialized
INFO - 2024-03-11 16:04:33 --> Language Class Initialized
INFO - 2024-03-11 16:04:33 --> Loader Class Initialized
INFO - 2024-03-11 16:04:33 --> Helper loaded: url_helper
INFO - 2024-03-11 16:04:33 --> Helper loaded: file_helper
INFO - 2024-03-11 16:04:33 --> Helper loaded: html_helper
INFO - 2024-03-11 16:04:33 --> Helper loaded: text_helper
INFO - 2024-03-11 16:04:33 --> Helper loaded: form_helper
INFO - 2024-03-11 16:04:33 --> Helper loaded: lang_helper
INFO - 2024-03-11 16:04:33 --> Helper loaded: security_helper
INFO - 2024-03-11 16:04:33 --> Helper loaded: cookie_helper
INFO - 2024-03-11 16:04:33 --> Database Driver Class Initialized
INFO - 2024-03-11 16:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 16:04:33 --> Parser Class Initialized
INFO - 2024-03-11 16:04:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 16:04:33 --> Pagination Class Initialized
INFO - 2024-03-11 16:04:33 --> Form Validation Class Initialized
INFO - 2024-03-11 16:04:33 --> Controller Class Initialized
INFO - 2024-03-11 16:04:33 --> Model Class Initialized
DEBUG - 2024-03-11 16:04:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:04:33 --> Model Class Initialized
DEBUG - 2024-03-11 16:04:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:04:33 --> Model Class Initialized
INFO - 2024-03-11 16:04:33 --> Model Class Initialized
INFO - 2024-03-11 16:04:33 --> Model Class Initialized
INFO - 2024-03-11 16:04:33 --> Model Class Initialized
DEBUG - 2024-03-11 16:04:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 16:04:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:04:33 --> Model Class Initialized
INFO - 2024-03-11 16:04:33 --> Model Class Initialized
INFO - 2024-03-11 16:04:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-11 16:04:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:04:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 16:04:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 16:04:33 --> Model Class Initialized
INFO - 2024-03-11 16:04:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 16:04:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 16:04:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 16:04:33 --> Final output sent to browser
DEBUG - 2024-03-11 16:04:33 --> Total execution time: 0.4314
ERROR - 2024-03-11 16:04:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 16:04:35 --> Config Class Initialized
INFO - 2024-03-11 16:04:35 --> Hooks Class Initialized
DEBUG - 2024-03-11 16:04:35 --> UTF-8 Support Enabled
INFO - 2024-03-11 16:04:35 --> Utf8 Class Initialized
INFO - 2024-03-11 16:04:35 --> URI Class Initialized
INFO - 2024-03-11 16:04:35 --> Router Class Initialized
INFO - 2024-03-11 16:04:35 --> Output Class Initialized
INFO - 2024-03-11 16:04:35 --> Security Class Initialized
DEBUG - 2024-03-11 16:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 16:04:35 --> Input Class Initialized
INFO - 2024-03-11 16:04:35 --> Language Class Initialized
INFO - 2024-03-11 16:04:35 --> Loader Class Initialized
INFO - 2024-03-11 16:04:35 --> Helper loaded: url_helper
INFO - 2024-03-11 16:04:35 --> Helper loaded: file_helper
INFO - 2024-03-11 16:04:35 --> Helper loaded: html_helper
INFO - 2024-03-11 16:04:35 --> Helper loaded: text_helper
INFO - 2024-03-11 16:04:35 --> Helper loaded: form_helper
INFO - 2024-03-11 16:04:35 --> Helper loaded: lang_helper
INFO - 2024-03-11 16:04:35 --> Helper loaded: security_helper
INFO - 2024-03-11 16:04:35 --> Helper loaded: cookie_helper
INFO - 2024-03-11 16:04:35 --> Database Driver Class Initialized
INFO - 2024-03-11 16:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 16:04:35 --> Parser Class Initialized
INFO - 2024-03-11 16:04:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 16:04:35 --> Pagination Class Initialized
INFO - 2024-03-11 16:04:35 --> Form Validation Class Initialized
INFO - 2024-03-11 16:04:35 --> Controller Class Initialized
DEBUG - 2024-03-11 16:04:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 16:04:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:04:35 --> Model Class Initialized
INFO - 2024-03-11 16:04:35 --> Final output sent to browser
DEBUG - 2024-03-11 16:04:35 --> Total execution time: 0.0134
ERROR - 2024-03-11 16:04:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 16:04:44 --> Config Class Initialized
INFO - 2024-03-11 16:04:44 --> Hooks Class Initialized
DEBUG - 2024-03-11 16:04:44 --> UTF-8 Support Enabled
INFO - 2024-03-11 16:04:44 --> Utf8 Class Initialized
INFO - 2024-03-11 16:04:44 --> URI Class Initialized
INFO - 2024-03-11 16:04:44 --> Router Class Initialized
INFO - 2024-03-11 16:04:44 --> Output Class Initialized
INFO - 2024-03-11 16:04:44 --> Security Class Initialized
DEBUG - 2024-03-11 16:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 16:04:44 --> Input Class Initialized
INFO - 2024-03-11 16:04:44 --> Language Class Initialized
INFO - 2024-03-11 16:04:44 --> Loader Class Initialized
INFO - 2024-03-11 16:04:44 --> Helper loaded: url_helper
INFO - 2024-03-11 16:04:44 --> Helper loaded: file_helper
INFO - 2024-03-11 16:04:44 --> Helper loaded: html_helper
INFO - 2024-03-11 16:04:44 --> Helper loaded: text_helper
INFO - 2024-03-11 16:04:44 --> Helper loaded: form_helper
INFO - 2024-03-11 16:04:44 --> Helper loaded: lang_helper
INFO - 2024-03-11 16:04:44 --> Helper loaded: security_helper
INFO - 2024-03-11 16:04:44 --> Helper loaded: cookie_helper
INFO - 2024-03-11 16:04:44 --> Database Driver Class Initialized
INFO - 2024-03-11 16:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 16:04:44 --> Parser Class Initialized
INFO - 2024-03-11 16:04:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 16:04:44 --> Pagination Class Initialized
INFO - 2024-03-11 16:04:44 --> Form Validation Class Initialized
INFO - 2024-03-11 16:04:44 --> Controller Class Initialized
DEBUG - 2024-03-11 16:04:44 --> Auth class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:04:44 --> Model Class Initialized
INFO - 2024-03-11 16:04:44 --> Model Class Initialized
INFO - 2024-03-11 16:04:44 --> Model Class Initialized
INFO - 2024-03-11 16:04:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product.php
DEBUG - 2024-03-11 16:04:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:04:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 16:04:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 16:04:44 --> Model Class Initialized
INFO - 2024-03-11 16:04:44 --> Model Class Initialized
INFO - 2024-03-11 16:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 16:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 16:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 16:04:45 --> Final output sent to browser
DEBUG - 2024-03-11 16:04:45 --> Total execution time: 0.2386
ERROR - 2024-03-11 16:04:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 16:04:46 --> Config Class Initialized
INFO - 2024-03-11 16:04:46 --> Hooks Class Initialized
DEBUG - 2024-03-11 16:04:46 --> UTF-8 Support Enabled
INFO - 2024-03-11 16:04:46 --> Utf8 Class Initialized
INFO - 2024-03-11 16:04:46 --> URI Class Initialized
INFO - 2024-03-11 16:04:46 --> Router Class Initialized
INFO - 2024-03-11 16:04:46 --> Output Class Initialized
INFO - 2024-03-11 16:04:46 --> Security Class Initialized
DEBUG - 2024-03-11 16:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 16:04:46 --> Input Class Initialized
INFO - 2024-03-11 16:04:46 --> Language Class Initialized
INFO - 2024-03-11 16:04:46 --> Loader Class Initialized
INFO - 2024-03-11 16:04:46 --> Helper loaded: url_helper
INFO - 2024-03-11 16:04:46 --> Helper loaded: file_helper
INFO - 2024-03-11 16:04:46 --> Helper loaded: html_helper
INFO - 2024-03-11 16:04:46 --> Helper loaded: text_helper
INFO - 2024-03-11 16:04:46 --> Helper loaded: form_helper
INFO - 2024-03-11 16:04:46 --> Helper loaded: lang_helper
INFO - 2024-03-11 16:04:46 --> Helper loaded: security_helper
INFO - 2024-03-11 16:04:46 --> Helper loaded: cookie_helper
INFO - 2024-03-11 16:04:46 --> Database Driver Class Initialized
INFO - 2024-03-11 16:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 16:04:46 --> Parser Class Initialized
INFO - 2024-03-11 16:04:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 16:04:46 --> Pagination Class Initialized
INFO - 2024-03-11 16:04:46 --> Form Validation Class Initialized
INFO - 2024-03-11 16:04:46 --> Controller Class Initialized
DEBUG - 2024-03-11 16:04:46 --> Auth class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:04:46 --> Model Class Initialized
INFO - 2024-03-11 16:04:46 --> Model Class Initialized
INFO - 2024-03-11 16:04:46 --> Final output sent to browser
DEBUG - 2024-03-11 16:04:46 --> Total execution time: 0.0487
ERROR - 2024-03-11 16:04:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 16:04:51 --> Config Class Initialized
INFO - 2024-03-11 16:04:51 --> Hooks Class Initialized
DEBUG - 2024-03-11 16:04:51 --> UTF-8 Support Enabled
INFO - 2024-03-11 16:04:51 --> Utf8 Class Initialized
INFO - 2024-03-11 16:04:51 --> URI Class Initialized
INFO - 2024-03-11 16:04:51 --> Router Class Initialized
INFO - 2024-03-11 16:04:51 --> Output Class Initialized
INFO - 2024-03-11 16:04:51 --> Security Class Initialized
DEBUG - 2024-03-11 16:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 16:04:51 --> Input Class Initialized
INFO - 2024-03-11 16:04:51 --> Language Class Initialized
INFO - 2024-03-11 16:04:51 --> Loader Class Initialized
INFO - 2024-03-11 16:04:51 --> Helper loaded: url_helper
INFO - 2024-03-11 16:04:51 --> Helper loaded: file_helper
INFO - 2024-03-11 16:04:51 --> Helper loaded: html_helper
INFO - 2024-03-11 16:04:51 --> Helper loaded: text_helper
INFO - 2024-03-11 16:04:51 --> Helper loaded: form_helper
INFO - 2024-03-11 16:04:51 --> Helper loaded: lang_helper
INFO - 2024-03-11 16:04:51 --> Helper loaded: security_helper
INFO - 2024-03-11 16:04:51 --> Helper loaded: cookie_helper
INFO - 2024-03-11 16:04:51 --> Database Driver Class Initialized
INFO - 2024-03-11 16:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 16:04:51 --> Parser Class Initialized
INFO - 2024-03-11 16:04:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 16:04:51 --> Pagination Class Initialized
INFO - 2024-03-11 16:04:51 --> Form Validation Class Initialized
INFO - 2024-03-11 16:04:51 --> Controller Class Initialized
DEBUG - 2024-03-11 16:04:51 --> Auth class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:04:51 --> Model Class Initialized
INFO - 2024-03-11 16:04:51 --> Model Class Initialized
INFO - 2024-03-11 16:04:51 --> Final output sent to browser
DEBUG - 2024-03-11 16:04:51 --> Total execution time: 0.1683
ERROR - 2024-03-11 16:04:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 16:04:56 --> Config Class Initialized
INFO - 2024-03-11 16:04:56 --> Hooks Class Initialized
DEBUG - 2024-03-11 16:04:56 --> UTF-8 Support Enabled
INFO - 2024-03-11 16:04:56 --> Utf8 Class Initialized
INFO - 2024-03-11 16:04:56 --> URI Class Initialized
DEBUG - 2024-03-11 16:04:56 --> No URI present. Default controller set.
INFO - 2024-03-11 16:04:56 --> Router Class Initialized
INFO - 2024-03-11 16:04:56 --> Output Class Initialized
INFO - 2024-03-11 16:04:56 --> Security Class Initialized
DEBUG - 2024-03-11 16:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 16:04:56 --> Input Class Initialized
INFO - 2024-03-11 16:04:56 --> Language Class Initialized
INFO - 2024-03-11 16:04:56 --> Loader Class Initialized
INFO - 2024-03-11 16:04:56 --> Helper loaded: url_helper
INFO - 2024-03-11 16:04:56 --> Helper loaded: file_helper
INFO - 2024-03-11 16:04:56 --> Helper loaded: html_helper
INFO - 2024-03-11 16:04:56 --> Helper loaded: text_helper
INFO - 2024-03-11 16:04:56 --> Helper loaded: form_helper
INFO - 2024-03-11 16:04:56 --> Helper loaded: lang_helper
INFO - 2024-03-11 16:04:56 --> Helper loaded: security_helper
INFO - 2024-03-11 16:04:56 --> Helper loaded: cookie_helper
INFO - 2024-03-11 16:04:56 --> Database Driver Class Initialized
INFO - 2024-03-11 16:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 16:04:56 --> Parser Class Initialized
INFO - 2024-03-11 16:04:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 16:04:56 --> Pagination Class Initialized
INFO - 2024-03-11 16:04:56 --> Form Validation Class Initialized
INFO - 2024-03-11 16:04:56 --> Controller Class Initialized
INFO - 2024-03-11 16:04:56 --> Model Class Initialized
DEBUG - 2024-03-11 16:04:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:04:56 --> Model Class Initialized
DEBUG - 2024-03-11 16:04:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:04:56 --> Model Class Initialized
INFO - 2024-03-11 16:04:56 --> Model Class Initialized
INFO - 2024-03-11 16:04:56 --> Model Class Initialized
INFO - 2024-03-11 16:04:56 --> Model Class Initialized
DEBUG - 2024-03-11 16:04:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 16:04:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:04:56 --> Model Class Initialized
INFO - 2024-03-11 16:04:56 --> Model Class Initialized
INFO - 2024-03-11 16:04:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-11 16:04:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:04:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 16:04:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 16:04:56 --> Model Class Initialized
INFO - 2024-03-11 16:04:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 16:04:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 16:04:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 16:04:56 --> Final output sent to browser
DEBUG - 2024-03-11 16:04:56 --> Total execution time: 0.4127
ERROR - 2024-03-11 16:05:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 16:05:06 --> Config Class Initialized
INFO - 2024-03-11 16:05:06 --> Hooks Class Initialized
DEBUG - 2024-03-11 16:05:06 --> UTF-8 Support Enabled
INFO - 2024-03-11 16:05:06 --> Utf8 Class Initialized
INFO - 2024-03-11 16:05:06 --> URI Class Initialized
INFO - 2024-03-11 16:05:06 --> Router Class Initialized
INFO - 2024-03-11 16:05:06 --> Output Class Initialized
INFO - 2024-03-11 16:05:06 --> Security Class Initialized
DEBUG - 2024-03-11 16:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 16:05:06 --> Input Class Initialized
INFO - 2024-03-11 16:05:06 --> Language Class Initialized
INFO - 2024-03-11 16:05:06 --> Loader Class Initialized
INFO - 2024-03-11 16:05:06 --> Helper loaded: url_helper
INFO - 2024-03-11 16:05:06 --> Helper loaded: file_helper
INFO - 2024-03-11 16:05:06 --> Helper loaded: html_helper
INFO - 2024-03-11 16:05:06 --> Helper loaded: text_helper
INFO - 2024-03-11 16:05:06 --> Helper loaded: form_helper
INFO - 2024-03-11 16:05:06 --> Helper loaded: lang_helper
INFO - 2024-03-11 16:05:06 --> Helper loaded: security_helper
INFO - 2024-03-11 16:05:06 --> Helper loaded: cookie_helper
INFO - 2024-03-11 16:05:06 --> Database Driver Class Initialized
INFO - 2024-03-11 16:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 16:05:06 --> Parser Class Initialized
INFO - 2024-03-11 16:05:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 16:05:06 --> Pagination Class Initialized
INFO - 2024-03-11 16:05:06 --> Form Validation Class Initialized
INFO - 2024-03-11 16:05:06 --> Controller Class Initialized
DEBUG - 2024-03-11 16:05:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 16:05:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:05:06 --> Model Class Initialized
DEBUG - 2024-03-11 16:05:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:05:06 --> Model Class Initialized
DEBUG - 2024-03-11 16:05:06 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:05:06 --> Model Class Initialized
INFO - 2024-03-11 16:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-03-11 16:05:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 16:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 16:05:06 --> Model Class Initialized
INFO - 2024-03-11 16:05:06 --> Model Class Initialized
INFO - 2024-03-11 16:05:06 --> Model Class Initialized
INFO - 2024-03-11 16:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 16:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 16:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 16:05:06 --> Final output sent to browser
DEBUG - 2024-03-11 16:05:06 --> Total execution time: 0.2454
ERROR - 2024-03-11 16:05:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 16:05:07 --> Config Class Initialized
INFO - 2024-03-11 16:05:07 --> Hooks Class Initialized
DEBUG - 2024-03-11 16:05:07 --> UTF-8 Support Enabled
INFO - 2024-03-11 16:05:07 --> Utf8 Class Initialized
INFO - 2024-03-11 16:05:07 --> URI Class Initialized
INFO - 2024-03-11 16:05:07 --> Router Class Initialized
INFO - 2024-03-11 16:05:07 --> Output Class Initialized
INFO - 2024-03-11 16:05:07 --> Security Class Initialized
DEBUG - 2024-03-11 16:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 16:05:07 --> Input Class Initialized
INFO - 2024-03-11 16:05:07 --> Language Class Initialized
INFO - 2024-03-11 16:05:07 --> Loader Class Initialized
INFO - 2024-03-11 16:05:07 --> Helper loaded: url_helper
INFO - 2024-03-11 16:05:07 --> Helper loaded: file_helper
INFO - 2024-03-11 16:05:07 --> Helper loaded: html_helper
INFO - 2024-03-11 16:05:07 --> Helper loaded: text_helper
INFO - 2024-03-11 16:05:07 --> Helper loaded: form_helper
INFO - 2024-03-11 16:05:07 --> Helper loaded: lang_helper
INFO - 2024-03-11 16:05:07 --> Helper loaded: security_helper
INFO - 2024-03-11 16:05:07 --> Helper loaded: cookie_helper
INFO - 2024-03-11 16:05:07 --> Database Driver Class Initialized
INFO - 2024-03-11 16:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 16:05:07 --> Parser Class Initialized
INFO - 2024-03-11 16:05:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 16:05:07 --> Pagination Class Initialized
INFO - 2024-03-11 16:05:07 --> Form Validation Class Initialized
INFO - 2024-03-11 16:05:07 --> Controller Class Initialized
DEBUG - 2024-03-11 16:05:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 16:05:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:05:07 --> Model Class Initialized
DEBUG - 2024-03-11 16:05:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:05:07 --> Model Class Initialized
INFO - 2024-03-11 16:05:07 --> Final output sent to browser
DEBUG - 2024-03-11 16:05:07 --> Total execution time: 0.0386
ERROR - 2024-03-11 16:05:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 16:05:09 --> Config Class Initialized
INFO - 2024-03-11 16:05:09 --> Hooks Class Initialized
DEBUG - 2024-03-11 16:05:09 --> UTF-8 Support Enabled
INFO - 2024-03-11 16:05:09 --> Utf8 Class Initialized
INFO - 2024-03-11 16:05:09 --> URI Class Initialized
INFO - 2024-03-11 16:05:09 --> Router Class Initialized
INFO - 2024-03-11 16:05:09 --> Output Class Initialized
INFO - 2024-03-11 16:05:09 --> Security Class Initialized
DEBUG - 2024-03-11 16:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 16:05:09 --> Input Class Initialized
INFO - 2024-03-11 16:05:09 --> Language Class Initialized
INFO - 2024-03-11 16:05:09 --> Loader Class Initialized
INFO - 2024-03-11 16:05:09 --> Helper loaded: url_helper
INFO - 2024-03-11 16:05:09 --> Helper loaded: file_helper
INFO - 2024-03-11 16:05:09 --> Helper loaded: html_helper
INFO - 2024-03-11 16:05:09 --> Helper loaded: text_helper
INFO - 2024-03-11 16:05:09 --> Helper loaded: form_helper
INFO - 2024-03-11 16:05:09 --> Helper loaded: lang_helper
INFO - 2024-03-11 16:05:09 --> Helper loaded: security_helper
INFO - 2024-03-11 16:05:09 --> Helper loaded: cookie_helper
INFO - 2024-03-11 16:05:09 --> Database Driver Class Initialized
INFO - 2024-03-11 16:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 16:05:09 --> Parser Class Initialized
INFO - 2024-03-11 16:05:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 16:05:09 --> Pagination Class Initialized
INFO - 2024-03-11 16:05:09 --> Form Validation Class Initialized
INFO - 2024-03-11 16:05:09 --> Controller Class Initialized
DEBUG - 2024-03-11 16:05:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 16:05:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:05:09 --> Model Class Initialized
DEBUG - 2024-03-11 16:05:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:05:09 --> Model Class Initialized
INFO - 2024-03-11 16:05:10 --> Final output sent to browser
DEBUG - 2024-03-11 16:05:10 --> Total execution time: 0.2766
ERROR - 2024-03-11 16:05:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 16:05:16 --> Config Class Initialized
INFO - 2024-03-11 16:05:16 --> Hooks Class Initialized
DEBUG - 2024-03-11 16:05:16 --> UTF-8 Support Enabled
INFO - 2024-03-11 16:05:16 --> Utf8 Class Initialized
INFO - 2024-03-11 16:05:16 --> URI Class Initialized
INFO - 2024-03-11 16:05:16 --> Router Class Initialized
INFO - 2024-03-11 16:05:16 --> Output Class Initialized
INFO - 2024-03-11 16:05:16 --> Security Class Initialized
DEBUG - 2024-03-11 16:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 16:05:16 --> Input Class Initialized
INFO - 2024-03-11 16:05:16 --> Language Class Initialized
INFO - 2024-03-11 16:05:16 --> Loader Class Initialized
INFO - 2024-03-11 16:05:16 --> Helper loaded: url_helper
INFO - 2024-03-11 16:05:16 --> Helper loaded: file_helper
INFO - 2024-03-11 16:05:16 --> Helper loaded: html_helper
INFO - 2024-03-11 16:05:16 --> Helper loaded: text_helper
INFO - 2024-03-11 16:05:16 --> Helper loaded: form_helper
INFO - 2024-03-11 16:05:16 --> Helper loaded: lang_helper
INFO - 2024-03-11 16:05:16 --> Helper loaded: security_helper
INFO - 2024-03-11 16:05:16 --> Helper loaded: cookie_helper
INFO - 2024-03-11 16:05:16 --> Database Driver Class Initialized
INFO - 2024-03-11 16:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 16:05:16 --> Parser Class Initialized
INFO - 2024-03-11 16:05:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 16:05:16 --> Pagination Class Initialized
INFO - 2024-03-11 16:05:16 --> Form Validation Class Initialized
INFO - 2024-03-11 16:05:16 --> Controller Class Initialized
INFO - 2024-03-11 16:05:16 --> Model Class Initialized
DEBUG - 2024-03-11 16:05:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 16:05:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:05:16 --> Model Class Initialized
DEBUG - 2024-03-11 16:05:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:05:16 --> Model Class Initialized
INFO - 2024-03-11 16:05:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-11 16:05:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:05:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 16:05:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 16:05:16 --> Model Class Initialized
INFO - 2024-03-11 16:05:16 --> Model Class Initialized
INFO - 2024-03-11 16:05:16 --> Model Class Initialized
INFO - 2024-03-11 16:05:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 16:05:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 16:05:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 16:05:16 --> Final output sent to browser
DEBUG - 2024-03-11 16:05:16 --> Total execution time: 0.2341
ERROR - 2024-03-11 16:05:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 16:05:17 --> Config Class Initialized
INFO - 2024-03-11 16:05:17 --> Hooks Class Initialized
DEBUG - 2024-03-11 16:05:17 --> UTF-8 Support Enabled
INFO - 2024-03-11 16:05:17 --> Utf8 Class Initialized
INFO - 2024-03-11 16:05:17 --> URI Class Initialized
INFO - 2024-03-11 16:05:17 --> Router Class Initialized
INFO - 2024-03-11 16:05:17 --> Output Class Initialized
INFO - 2024-03-11 16:05:17 --> Security Class Initialized
DEBUG - 2024-03-11 16:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 16:05:17 --> Input Class Initialized
INFO - 2024-03-11 16:05:17 --> Language Class Initialized
INFO - 2024-03-11 16:05:17 --> Loader Class Initialized
INFO - 2024-03-11 16:05:17 --> Helper loaded: url_helper
INFO - 2024-03-11 16:05:17 --> Helper loaded: file_helper
INFO - 2024-03-11 16:05:17 --> Helper loaded: html_helper
INFO - 2024-03-11 16:05:17 --> Helper loaded: text_helper
INFO - 2024-03-11 16:05:17 --> Helper loaded: form_helper
INFO - 2024-03-11 16:05:17 --> Helper loaded: lang_helper
INFO - 2024-03-11 16:05:17 --> Helper loaded: security_helper
INFO - 2024-03-11 16:05:17 --> Helper loaded: cookie_helper
INFO - 2024-03-11 16:05:17 --> Database Driver Class Initialized
INFO - 2024-03-11 16:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 16:05:17 --> Parser Class Initialized
INFO - 2024-03-11 16:05:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 16:05:17 --> Pagination Class Initialized
INFO - 2024-03-11 16:05:17 --> Form Validation Class Initialized
INFO - 2024-03-11 16:05:17 --> Controller Class Initialized
INFO - 2024-03-11 16:05:17 --> Model Class Initialized
DEBUG - 2024-03-11 16:05:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 16:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:05:17 --> Model Class Initialized
DEBUG - 2024-03-11 16:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:05:17 --> Model Class Initialized
INFO - 2024-03-11 16:05:17 --> Final output sent to browser
DEBUG - 2024-03-11 16:05:17 --> Total execution time: 0.0600
ERROR - 2024-03-11 16:05:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 16:05:20 --> Config Class Initialized
INFO - 2024-03-11 16:05:20 --> Hooks Class Initialized
DEBUG - 2024-03-11 16:05:20 --> UTF-8 Support Enabled
INFO - 2024-03-11 16:05:20 --> Utf8 Class Initialized
INFO - 2024-03-11 16:05:20 --> URI Class Initialized
INFO - 2024-03-11 16:05:20 --> Router Class Initialized
INFO - 2024-03-11 16:05:20 --> Output Class Initialized
INFO - 2024-03-11 16:05:20 --> Security Class Initialized
DEBUG - 2024-03-11 16:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 16:05:20 --> Input Class Initialized
INFO - 2024-03-11 16:05:20 --> Language Class Initialized
INFO - 2024-03-11 16:05:20 --> Loader Class Initialized
INFO - 2024-03-11 16:05:20 --> Helper loaded: url_helper
INFO - 2024-03-11 16:05:20 --> Helper loaded: file_helper
INFO - 2024-03-11 16:05:20 --> Helper loaded: html_helper
INFO - 2024-03-11 16:05:20 --> Helper loaded: text_helper
INFO - 2024-03-11 16:05:20 --> Helper loaded: form_helper
INFO - 2024-03-11 16:05:20 --> Helper loaded: lang_helper
INFO - 2024-03-11 16:05:20 --> Helper loaded: security_helper
INFO - 2024-03-11 16:05:20 --> Helper loaded: cookie_helper
INFO - 2024-03-11 16:05:20 --> Database Driver Class Initialized
INFO - 2024-03-11 16:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 16:05:20 --> Parser Class Initialized
INFO - 2024-03-11 16:05:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 16:05:20 --> Pagination Class Initialized
INFO - 2024-03-11 16:05:20 --> Form Validation Class Initialized
INFO - 2024-03-11 16:05:20 --> Controller Class Initialized
INFO - 2024-03-11 16:05:20 --> Model Class Initialized
DEBUG - 2024-03-11 16:05:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 16:05:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:05:20 --> Model Class Initialized
DEBUG - 2024-03-11 16:05:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:05:20 --> Model Class Initialized
INFO - 2024-03-11 16:05:21 --> Final output sent to browser
DEBUG - 2024-03-11 16:05:21 --> Total execution time: 1.5325
ERROR - 2024-03-11 16:05:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 16:05:37 --> Config Class Initialized
INFO - 2024-03-11 16:05:37 --> Hooks Class Initialized
DEBUG - 2024-03-11 16:05:37 --> UTF-8 Support Enabled
INFO - 2024-03-11 16:05:37 --> Utf8 Class Initialized
INFO - 2024-03-11 16:05:37 --> URI Class Initialized
INFO - 2024-03-11 16:05:37 --> Router Class Initialized
INFO - 2024-03-11 16:05:37 --> Output Class Initialized
INFO - 2024-03-11 16:05:37 --> Security Class Initialized
DEBUG - 2024-03-11 16:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 16:05:37 --> Input Class Initialized
INFO - 2024-03-11 16:05:37 --> Language Class Initialized
INFO - 2024-03-11 16:05:37 --> Loader Class Initialized
INFO - 2024-03-11 16:05:37 --> Helper loaded: url_helper
INFO - 2024-03-11 16:05:37 --> Helper loaded: file_helper
INFO - 2024-03-11 16:05:37 --> Helper loaded: html_helper
INFO - 2024-03-11 16:05:37 --> Helper loaded: text_helper
INFO - 2024-03-11 16:05:37 --> Helper loaded: form_helper
INFO - 2024-03-11 16:05:37 --> Helper loaded: lang_helper
INFO - 2024-03-11 16:05:37 --> Helper loaded: security_helper
INFO - 2024-03-11 16:05:37 --> Helper loaded: cookie_helper
INFO - 2024-03-11 16:05:37 --> Database Driver Class Initialized
INFO - 2024-03-11 16:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-11 16:05:37 --> Parser Class Initialized
INFO - 2024-03-11 16:05:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-11 16:05:37 --> Pagination Class Initialized
INFO - 2024-03-11 16:05:37 --> Form Validation Class Initialized
INFO - 2024-03-11 16:05:37 --> Controller Class Initialized
INFO - 2024-03-11 16:05:37 --> Model Class Initialized
DEBUG - 2024-03-11 16:05:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-11 16:05:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:05:37 --> Model Class Initialized
DEBUG - 2024-03-11 16:05:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:05:37 --> Model Class Initialized
DEBUG - 2024-03-11 16:05:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:05:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-03-11 16:05:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-11 16:05:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-11 16:05:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-11 16:05:37 --> Model Class Initialized
INFO - 2024-03-11 16:05:37 --> Model Class Initialized
INFO - 2024-03-11 16:05:37 --> Model Class Initialized
INFO - 2024-03-11 16:05:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-11 16:05:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-11 16:05:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-11 16:05:38 --> Final output sent to browser
DEBUG - 2024-03-11 16:05:38 --> Total execution time: 0.2546
ERROR - 2024-03-11 23:18:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 23:18:37 --> Config Class Initialized
INFO - 2024-03-11 23:18:37 --> Hooks Class Initialized
DEBUG - 2024-03-11 23:18:37 --> UTF-8 Support Enabled
INFO - 2024-03-11 23:18:37 --> Utf8 Class Initialized
INFO - 2024-03-11 23:18:37 --> URI Class Initialized
INFO - 2024-03-11 23:18:37 --> Router Class Initialized
INFO - 2024-03-11 23:18:37 --> Output Class Initialized
INFO - 2024-03-11 23:18:37 --> Security Class Initialized
DEBUG - 2024-03-11 23:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 23:18:37 --> Input Class Initialized
INFO - 2024-03-11 23:18:37 --> Language Class Initialized
ERROR - 2024-03-11 23:18:37 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-03-11 23:41:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-11 23:41:09 --> Config Class Initialized
INFO - 2024-03-11 23:41:09 --> Hooks Class Initialized
DEBUG - 2024-03-11 23:41:09 --> UTF-8 Support Enabled
INFO - 2024-03-11 23:41:09 --> Utf8 Class Initialized
INFO - 2024-03-11 23:41:09 --> URI Class Initialized
INFO - 2024-03-11 23:41:09 --> Router Class Initialized
INFO - 2024-03-11 23:41:09 --> Output Class Initialized
INFO - 2024-03-11 23:41:09 --> Security Class Initialized
DEBUG - 2024-03-11 23:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-11 23:41:09 --> Input Class Initialized
INFO - 2024-03-11 23:41:09 --> Language Class Initialized
ERROR - 2024-03-11 23:41:09 --> 404 Page Not Found: Well-known/assetlinks.json
