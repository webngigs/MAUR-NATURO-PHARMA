<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-22 06:59:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:05 --> Config Class Initialized
INFO - 2023-07-22 06:59:05 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:05 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:05 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:05 --> URI Class Initialized
DEBUG - 2023-07-22 06:59:05 --> No URI present. Default controller set.
INFO - 2023-07-22 06:59:05 --> Router Class Initialized
INFO - 2023-07-22 06:59:05 --> Output Class Initialized
INFO - 2023-07-22 06:59:05 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:05 --> Input Class Initialized
INFO - 2023-07-22 06:59:05 --> Language Class Initialized
INFO - 2023-07-22 06:59:05 --> Loader Class Initialized
INFO - 2023-07-22 06:59:05 --> Helper loaded: url_helper
INFO - 2023-07-22 06:59:05 --> Helper loaded: file_helper
INFO - 2023-07-22 06:59:05 --> Helper loaded: html_helper
INFO - 2023-07-22 06:59:05 --> Helper loaded: text_helper
INFO - 2023-07-22 06:59:05 --> Helper loaded: form_helper
INFO - 2023-07-22 06:59:05 --> Helper loaded: lang_helper
INFO - 2023-07-22 06:59:05 --> Helper loaded: security_helper
INFO - 2023-07-22 06:59:05 --> Helper loaded: cookie_helper
INFO - 2023-07-22 06:59:05 --> Database Driver Class Initialized
INFO - 2023-07-22 06:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 06:59:05 --> Parser Class Initialized
INFO - 2023-07-22 06:59:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 06:59:05 --> Pagination Class Initialized
INFO - 2023-07-22 06:59:05 --> Form Validation Class Initialized
INFO - 2023-07-22 06:59:05 --> Controller Class Initialized
INFO - 2023-07-22 06:59:05 --> Model Class Initialized
DEBUG - 2023-07-22 06:59:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 06:59:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:05 --> Config Class Initialized
INFO - 2023-07-22 06:59:05 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:05 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:05 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:05 --> URI Class Initialized
DEBUG - 2023-07-22 06:59:05 --> No URI present. Default controller set.
INFO - 2023-07-22 06:59:05 --> Router Class Initialized
INFO - 2023-07-22 06:59:05 --> Output Class Initialized
INFO - 2023-07-22 06:59:05 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:05 --> Input Class Initialized
INFO - 2023-07-22 06:59:05 --> Language Class Initialized
INFO - 2023-07-22 06:59:05 --> Loader Class Initialized
INFO - 2023-07-22 06:59:05 --> Helper loaded: url_helper
INFO - 2023-07-22 06:59:05 --> Helper loaded: file_helper
INFO - 2023-07-22 06:59:05 --> Helper loaded: html_helper
INFO - 2023-07-22 06:59:05 --> Helper loaded: text_helper
INFO - 2023-07-22 06:59:05 --> Helper loaded: form_helper
INFO - 2023-07-22 06:59:05 --> Helper loaded: lang_helper
INFO - 2023-07-22 06:59:05 --> Helper loaded: security_helper
INFO - 2023-07-22 06:59:05 --> Helper loaded: cookie_helper
INFO - 2023-07-22 06:59:05 --> Database Driver Class Initialized
INFO - 2023-07-22 06:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 06:59:05 --> Parser Class Initialized
INFO - 2023-07-22 06:59:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 06:59:05 --> Pagination Class Initialized
INFO - 2023-07-22 06:59:05 --> Form Validation Class Initialized
INFO - 2023-07-22 06:59:05 --> Controller Class Initialized
INFO - 2023-07-22 06:59:05 --> Model Class Initialized
DEBUG - 2023-07-22 06:59:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 06:59:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:09 --> Config Class Initialized
INFO - 2023-07-22 06:59:09 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:09 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:09 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:09 --> URI Class Initialized
DEBUG - 2023-07-22 06:59:09 --> No URI present. Default controller set.
INFO - 2023-07-22 06:59:09 --> Router Class Initialized
INFO - 2023-07-22 06:59:09 --> Output Class Initialized
INFO - 2023-07-22 06:59:09 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:09 --> Input Class Initialized
INFO - 2023-07-22 06:59:09 --> Language Class Initialized
INFO - 2023-07-22 06:59:09 --> Loader Class Initialized
INFO - 2023-07-22 06:59:09 --> Helper loaded: url_helper
INFO - 2023-07-22 06:59:09 --> Helper loaded: file_helper
INFO - 2023-07-22 06:59:09 --> Helper loaded: html_helper
INFO - 2023-07-22 06:59:09 --> Helper loaded: text_helper
INFO - 2023-07-22 06:59:09 --> Helper loaded: form_helper
INFO - 2023-07-22 06:59:09 --> Helper loaded: lang_helper
INFO - 2023-07-22 06:59:09 --> Helper loaded: security_helper
INFO - 2023-07-22 06:59:09 --> Helper loaded: cookie_helper
INFO - 2023-07-22 06:59:09 --> Database Driver Class Initialized
INFO - 2023-07-22 06:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 06:59:09 --> Parser Class Initialized
INFO - 2023-07-22 06:59:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 06:59:09 --> Pagination Class Initialized
INFO - 2023-07-22 06:59:09 --> Form Validation Class Initialized
INFO - 2023-07-22 06:59:09 --> Controller Class Initialized
INFO - 2023-07-22 06:59:09 --> Model Class Initialized
DEBUG - 2023-07-22 06:59:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 06:59:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:09 --> Config Class Initialized
INFO - 2023-07-22 06:59:09 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:09 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:09 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:09 --> URI Class Initialized
INFO - 2023-07-22 06:59:09 --> Router Class Initialized
INFO - 2023-07-22 06:59:09 --> Output Class Initialized
INFO - 2023-07-22 06:59:09 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:09 --> Input Class Initialized
INFO - 2023-07-22 06:59:09 --> Language Class Initialized
ERROR - 2023-07-22 06:59:09 --> 404 Page Not Found: Installerphp/index
ERROR - 2023-07-22 06:59:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:09 --> Config Class Initialized
INFO - 2023-07-22 06:59:09 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:09 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:09 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:09 --> URI Class Initialized
INFO - 2023-07-22 06:59:09 --> Router Class Initialized
INFO - 2023-07-22 06:59:09 --> Output Class Initialized
INFO - 2023-07-22 06:59:09 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:09 --> Input Class Initialized
INFO - 2023-07-22 06:59:09 --> Language Class Initialized
ERROR - 2023-07-22 06:59:09 --> 404 Page Not Found: Wp/index
ERROR - 2023-07-22 06:59:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:09 --> Config Class Initialized
INFO - 2023-07-22 06:59:09 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:09 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:09 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:09 --> URI Class Initialized
INFO - 2023-07-22 06:59:09 --> Router Class Initialized
INFO - 2023-07-22 06:59:09 --> Output Class Initialized
INFO - 2023-07-22 06:59:09 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:09 --> Input Class Initialized
INFO - 2023-07-22 06:59:09 --> Language Class Initialized
ERROR - 2023-07-22 06:59:09 --> 404 Page Not Found: Env/index
ERROR - 2023-07-22 06:59:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:09 --> Config Class Initialized
INFO - 2023-07-22 06:59:09 --> Hooks Class Initialized
ERROR - 2023-07-22 06:59:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
DEBUG - 2023-07-22 06:59:09 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:09 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:09 --> Config Class Initialized
INFO - 2023-07-22 06:59:09 --> Hooks Class Initialized
INFO - 2023-07-22 06:59:09 --> URI Class Initialized
INFO - 2023-07-22 06:59:09 --> Router Class Initialized
DEBUG - 2023-07-22 06:59:09 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:09 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:09 --> Output Class Initialized
INFO - 2023-07-22 06:59:09 --> URI Class Initialized
INFO - 2023-07-22 06:59:09 --> Router Class Initialized
INFO - 2023-07-22 06:59:09 --> Security Class Initialized
INFO - 2023-07-22 06:59:09 --> Output Class Initialized
DEBUG - 2023-07-22 06:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:09 --> Input Class Initialized
INFO - 2023-07-22 06:59:09 --> Language Class Initialized
ERROR - 2023-07-22 06:59:09 --> 404 Page Not Found: Envlocal/index
INFO - 2023-07-22 06:59:09 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:09 --> Input Class Initialized
INFO - 2023-07-22 06:59:09 --> Language Class Initialized
ERROR - 2023-07-22 06:59:09 --> 404 Page Not Found: Envproduction/index
ERROR - 2023-07-22 06:59:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:09 --> Config Class Initialized
INFO - 2023-07-22 06:59:09 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:09 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:09 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:09 --> URI Class Initialized
INFO - 2023-07-22 06:59:09 --> Router Class Initialized
INFO - 2023-07-22 06:59:09 --> Output Class Initialized
INFO - 2023-07-22 06:59:09 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:09 --> Input Class Initialized
INFO - 2023-07-22 06:59:09 --> Language Class Initialized
ERROR - 2023-07-22 06:59:09 --> 404 Page Not Found: Blog/index
ERROR - 2023-07-22 06:59:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:09 --> Config Class Initialized
INFO - 2023-07-22 06:59:09 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:09 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:09 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:09 --> URI Class Initialized
INFO - 2023-07-22 06:59:09 --> Router Class Initialized
INFO - 2023-07-22 06:59:09 --> Output Class Initialized
INFO - 2023-07-22 06:59:09 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:09 --> Input Class Initialized
INFO - 2023-07-22 06:59:09 --> Language Class Initialized
ERROR - 2023-07-22 06:59:09 --> 404 Page Not Found: Api/.env
ERROR - 2023-07-22 06:59:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:09 --> Config Class Initialized
INFO - 2023-07-22 06:59:09 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:09 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:09 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:09 --> URI Class Initialized
INFO - 2023-07-22 06:59:09 --> Router Class Initialized
INFO - 2023-07-22 06:59:09 --> Output Class Initialized
INFO - 2023-07-22 06:59:09 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:09 --> Input Class Initialized
INFO - 2023-07-22 06:59:09 --> Language Class Initialized
ERROR - 2023-07-22 06:59:09 --> 404 Page Not Found: Envdev/index
ERROR - 2023-07-22 06:59:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
ERROR - 2023-07-22 06:59:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:09 --> Config Class Initialized
INFO - 2023-07-22 06:59:09 --> Hooks Class Initialized
INFO - 2023-07-22 06:59:09 --> Config Class Initialized
INFO - 2023-07-22 06:59:09 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:09 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:09 --> Utf8 Class Initialized
DEBUG - 2023-07-22 06:59:09 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:09 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:09 --> URI Class Initialized
INFO - 2023-07-22 06:59:09 --> URI Class Initialized
INFO - 2023-07-22 06:59:09 --> Router Class Initialized
INFO - 2023-07-22 06:59:09 --> Router Class Initialized
INFO - 2023-07-22 06:59:09 --> Output Class Initialized
INFO - 2023-07-22 06:59:09 --> Output Class Initialized
INFO - 2023-07-22 06:59:09 --> Security Class Initialized
INFO - 2023-07-22 06:59:09 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:09 --> Input Class Initialized
DEBUG - 2023-07-22 06:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:09 --> Input Class Initialized
INFO - 2023-07-22 06:59:09 --> Language Class Initialized
INFO - 2023-07-22 06:59:09 --> Language Class Initialized
ERROR - 2023-07-22 06:59:09 --> 404 Page Not Found: Envtest/index
ERROR - 2023-07-22 06:59:09 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Envstaging/index
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Envbak/index
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Vscode/sftp.json
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Envbackup/index
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Aws/credentials
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Envphp/index
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Vscode/ftp-sync.json
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Infophp/index
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Testphp/index
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Envprod/index
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Vscode/.env
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Telescope/requests
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Api/info.php
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Phpphp/index
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Api/phpinfo.php
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Phpinfophp/index
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Wp-infophp/index
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Api/php.php
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Api/wp-info.php
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Swagger-uihtml/index
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Swagger/static
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Swagger/ui
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Recentserversxml/index
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Filezillaxml/index
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: PMA/index
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Swagger/index.html
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Sitemanagerxml/index
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Sftp-configjson/index
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Awsjson/index
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Config/aws.json
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Awsyml/index
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Config/aws.yml
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Config/prod.json
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Config/default.json
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Prodjson/index
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Productionjson/index
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Configini/index
ERROR - 2023-07-22 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:10 --> Config Class Initialized
INFO - 2023-07-22 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:10 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:10 --> URI Class Initialized
INFO - 2023-07-22 06:59:10 --> Router Class Initialized
INFO - 2023-07-22 06:59:10 --> Output Class Initialized
INFO - 2023-07-22 06:59:10 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:10 --> Input Class Initialized
INFO - 2023-07-22 06:59:10 --> Language Class Initialized
ERROR - 2023-07-22 06:59:10 --> 404 Page Not Found: Stagingjson/index
ERROR - 2023-07-22 06:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:11 --> Config Class Initialized
INFO - 2023-07-22 06:59:11 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:11 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:11 --> URI Class Initialized
INFO - 2023-07-22 06:59:11 --> Router Class Initialized
INFO - 2023-07-22 06:59:11 --> Output Class Initialized
INFO - 2023-07-22 06:59:11 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:11 --> Input Class Initialized
INFO - 2023-07-22 06:59:11 --> Language Class Initialized
ERROR - 2023-07-22 06:59:11 --> 404 Page Not Found: Appini/index
ERROR - 2023-07-22 06:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:11 --> Config Class Initialized
INFO - 2023-07-22 06:59:11 --> Hooks Class Initialized
ERROR - 2023-07-22 06:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:11 --> Config Class Initialized
INFO - 2023-07-22 06:59:11 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:11 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:11 --> URI Class Initialized
DEBUG - 2023-07-22 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:11 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:11 --> Router Class Initialized
INFO - 2023-07-22 06:59:11 --> URI Class Initialized
INFO - 2023-07-22 06:59:11 --> Output Class Initialized
INFO - 2023-07-22 06:59:11 --> Router Class Initialized
INFO - 2023-07-22 06:59:11 --> Security Class Initialized
INFO - 2023-07-22 06:59:11 --> Output Class Initialized
DEBUG - 2023-07-22 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:11 --> Input Class Initialized
INFO - 2023-07-22 06:59:11 --> Language Class Initialized
INFO - 2023-07-22 06:59:11 --> Security Class Initialized
ERROR - 2023-07-22 06:59:11 --> 404 Page Not Found: Defaultini/index
DEBUG - 2023-07-22 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:11 --> Input Class Initialized
INFO - 2023-07-22 06:59:11 --> Language Class Initialized
ERROR - 2023-07-22 06:59:11 --> 404 Page Not Found: Productionini/index
ERROR - 2023-07-22 06:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:11 --> Config Class Initialized
INFO - 2023-07-22 06:59:11 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:11 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:11 --> URI Class Initialized
INFO - 2023-07-22 06:59:11 --> Router Class Initialized
INFO - 2023-07-22 06:59:11 --> Output Class Initialized
INFO - 2023-07-22 06:59:11 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:11 --> Input Class Initialized
INFO - 2023-07-22 06:59:11 --> Language Class Initialized
ERROR - 2023-07-22 06:59:11 --> 404 Page Not Found: Databasezip/index
ERROR - 2023-07-22 06:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:11 --> Config Class Initialized
INFO - 2023-07-22 06:59:11 --> Hooks Class Initialized
ERROR - 2023-07-22 06:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
DEBUG - 2023-07-22 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:11 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:11 --> Config Class Initialized
INFO - 2023-07-22 06:59:11 --> Hooks Class Initialized
INFO - 2023-07-22 06:59:11 --> URI Class Initialized
INFO - 2023-07-22 06:59:11 --> Router Class Initialized
DEBUG - 2023-07-22 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:11 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:11 --> Output Class Initialized
INFO - 2023-07-22 06:59:11 --> URI Class Initialized
INFO - 2023-07-22 06:59:11 --> Security Class Initialized
INFO - 2023-07-22 06:59:11 --> Router Class Initialized
DEBUG - 2023-07-22 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:11 --> Input Class Initialized
INFO - 2023-07-22 06:59:11 --> Language Class Initialized
INFO - 2023-07-22 06:59:11 --> Output Class Initialized
ERROR - 2023-07-22 06:59:11 --> 404 Page Not Found: Databasesql/index
INFO - 2023-07-22 06:59:11 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:11 --> Input Class Initialized
INFO - 2023-07-22 06:59:11 --> Language Class Initialized
ERROR - 2023-07-22 06:59:11 --> 404 Page Not Found: Dbzip/index
ERROR - 2023-07-22 06:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:11 --> Config Class Initialized
INFO - 2023-07-22 06:59:11 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:11 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:11 --> URI Class Initialized
INFO - 2023-07-22 06:59:11 --> Router Class Initialized
INFO - 2023-07-22 06:59:11 --> Output Class Initialized
INFO - 2023-07-22 06:59:11 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:11 --> Input Class Initialized
INFO - 2023-07-22 06:59:11 --> Language Class Initialized
ERROR - 2023-07-22 06:59:11 --> 404 Page Not Found: Dbsql/index
ERROR - 2023-07-22 06:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:11 --> Config Class Initialized
INFO - 2023-07-22 06:59:11 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:11 --> Utf8 Class Initialized
ERROR - 2023-07-22 06:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:11 --> URI Class Initialized
INFO - 2023-07-22 06:59:11 --> Config Class Initialized
INFO - 2023-07-22 06:59:11 --> Hooks Class Initialized
INFO - 2023-07-22 06:59:11 --> Router Class Initialized
INFO - 2023-07-22 06:59:11 --> Output Class Initialized
DEBUG - 2023-07-22 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:11 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:11 --> URI Class Initialized
INFO - 2023-07-22 06:59:11 --> Security Class Initialized
INFO - 2023-07-22 06:59:11 --> Router Class Initialized
DEBUG - 2023-07-22 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:11 --> Input Class Initialized
INFO - 2023-07-22 06:59:11 --> Language Class Initialized
INFO - 2023-07-22 06:59:11 --> Output Class Initialized
ERROR - 2023-07-22 06:59:11 --> 404 Page Not Found: Backupsql/index
INFO - 2023-07-22 06:59:11 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:11 --> Input Class Initialized
INFO - 2023-07-22 06:59:11 --> Language Class Initialized
ERROR - 2023-07-22 06:59:11 --> 404 Page Not Found: Exportsql/index
ERROR - 2023-07-22 06:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:11 --> Config Class Initialized
INFO - 2023-07-22 06:59:11 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:11 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:11 --> URI Class Initialized
INFO - 2023-07-22 06:59:11 --> Router Class Initialized
INFO - 2023-07-22 06:59:11 --> Output Class Initialized
INFO - 2023-07-22 06:59:11 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:11 --> Input Class Initialized
INFO - 2023-07-22 06:59:11 --> Language Class Initialized
ERROR - 2023-07-22 06:59:11 --> 404 Page Not Found: Dumpsql/index
ERROR - 2023-07-22 06:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:11 --> Config Class Initialized
INFO - 2023-07-22 06:59:11 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:11 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:11 --> URI Class Initialized
ERROR - 2023-07-22 06:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:11 --> Router Class Initialized
INFO - 2023-07-22 06:59:11 --> Config Class Initialized
INFO - 2023-07-22 06:59:11 --> Hooks Class Initialized
INFO - 2023-07-22 06:59:11 --> Output Class Initialized
INFO - 2023-07-22 06:59:11 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:11 --> Utf8 Class Initialized
DEBUG - 2023-07-22 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:11 --> Input Class Initialized
INFO - 2023-07-22 06:59:11 --> URI Class Initialized
INFO - 2023-07-22 06:59:11 --> Language Class Initialized
ERROR - 2023-07-22 06:59:11 --> 404 Page Not Found: Databasetargz/index
INFO - 2023-07-22 06:59:11 --> Router Class Initialized
INFO - 2023-07-22 06:59:11 --> Output Class Initialized
INFO - 2023-07-22 06:59:11 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:11 --> Input Class Initialized
INFO - 2023-07-22 06:59:11 --> Language Class Initialized
ERROR - 2023-07-22 06:59:11 --> 404 Page Not Found: Db_backupsql/index
ERROR - 2023-07-22 06:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:11 --> Config Class Initialized
INFO - 2023-07-22 06:59:11 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:11 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:11 --> URI Class Initialized
INFO - 2023-07-22 06:59:11 --> Router Class Initialized
INFO - 2023-07-22 06:59:11 --> Output Class Initialized
INFO - 2023-07-22 06:59:11 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:11 --> Input Class Initialized
INFO - 2023-07-22 06:59:11 --> Language Class Initialized
ERROR - 2023-07-22 06:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
ERROR - 2023-07-22 06:59:11 --> 404 Page Not Found: Databasesqlgz/index
INFO - 2023-07-22 06:59:11 --> Config Class Initialized
INFO - 2023-07-22 06:59:11 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:11 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:11 --> URI Class Initialized
INFO - 2023-07-22 06:59:11 --> Router Class Initialized
INFO - 2023-07-22 06:59:11 --> Output Class Initialized
INFO - 2023-07-22 06:59:11 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:11 --> Input Class Initialized
ERROR - 2023-07-22 06:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:11 --> Language Class Initialized
ERROR - 2023-07-22 06:59:11 --> 404 Page Not Found: Dumpsqlgz/index
INFO - 2023-07-22 06:59:11 --> Config Class Initialized
INFO - 2023-07-22 06:59:11 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:11 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:11 --> URI Class Initialized
INFO - 2023-07-22 06:59:11 --> Router Class Initialized
ERROR - 2023-07-22 06:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:11 --> Output Class Initialized
INFO - 2023-07-22 06:59:11 --> Config Class Initialized
INFO - 2023-07-22 06:59:11 --> Hooks Class Initialized
INFO - 2023-07-22 06:59:11 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:11 --> Input Class Initialized
DEBUG - 2023-07-22 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:11 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:11 --> Language Class Initialized
ERROR - 2023-07-22 06:59:11 --> 404 Page Not Found: Dbtargz/index
INFO - 2023-07-22 06:59:11 --> URI Class Initialized
INFO - 2023-07-22 06:59:11 --> Router Class Initialized
INFO - 2023-07-22 06:59:11 --> Output Class Initialized
ERROR - 2023-07-22 06:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:11 --> Security Class Initialized
INFO - 2023-07-22 06:59:11 --> Config Class Initialized
INFO - 2023-07-22 06:59:11 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:11 --> Input Class Initialized
INFO - 2023-07-22 06:59:11 --> Language Class Initialized
ERROR - 2023-07-22 06:59:11 --> 404 Page Not Found: Docker/Dockerfile
DEBUG - 2023-07-22 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:11 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:11 --> URI Class Initialized
INFO - 2023-07-22 06:59:11 --> Router Class Initialized
INFO - 2023-07-22 06:59:11 --> Output Class Initialized
INFO - 2023-07-22 06:59:11 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:11 --> Input Class Initialized
INFO - 2023-07-22 06:59:11 --> Language Class Initialized
ERROR - 2023-07-22 06:59:11 --> 404 Page Not Found: Dbsqlgz/index
ERROR - 2023-07-22 06:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:11 --> Config Class Initialized
INFO - 2023-07-22 06:59:11 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:11 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:11 --> URI Class Initialized
INFO - 2023-07-22 06:59:11 --> Router Class Initialized
INFO - 2023-07-22 06:59:11 --> Output Class Initialized
INFO - 2023-07-22 06:59:11 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:11 --> Input Class Initialized
INFO - 2023-07-22 06:59:11 --> Language Class Initialized
ERROR - 2023-07-22 06:59:11 --> 404 Page Not Found: Dockerfile/index
ERROR - 2023-07-22 06:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:11 --> Config Class Initialized
INFO - 2023-07-22 06:59:11 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:11 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:11 --> URI Class Initialized
INFO - 2023-07-22 06:59:11 --> Router Class Initialized
INFO - 2023-07-22 06:59:11 --> Output Class Initialized
INFO - 2023-07-22 06:59:11 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:11 --> Input Class Initialized
INFO - 2023-07-22 06:59:11 --> Language Class Initialized
ERROR - 2023-07-22 06:59:11 --> 404 Page Not Found: Config/config.ini
ERROR - 2023-07-22 06:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:11 --> Config Class Initialized
INFO - 2023-07-22 06:59:11 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:11 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:11 --> URI Class Initialized
INFO - 2023-07-22 06:59:11 --> Router Class Initialized
INFO - 2023-07-22 06:59:11 --> Output Class Initialized
INFO - 2023-07-22 06:59:11 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:11 --> Input Class Initialized
INFO - 2023-07-22 06:59:11 --> Language Class Initialized
ERROR - 2023-07-22 06:59:11 --> 404 Page Not Found: Adminerphp/index
ERROR - 2023-07-22 06:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:11 --> Config Class Initialized
INFO - 2023-07-22 06:59:11 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:11 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:11 --> URI Class Initialized
INFO - 2023-07-22 06:59:11 --> Router Class Initialized
INFO - 2023-07-22 06:59:11 --> Output Class Initialized
INFO - 2023-07-22 06:59:11 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:11 --> Input Class Initialized
INFO - 2023-07-22 06:59:11 --> Language Class Initialized
ERROR - 2023-07-22 06:59:11 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2023-07-22 06:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:11 --> Config Class Initialized
INFO - 2023-07-22 06:59:11 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:11 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:11 --> URI Class Initialized
INFO - 2023-07-22 06:59:11 --> Router Class Initialized
INFO - 2023-07-22 06:59:11 --> Output Class Initialized
INFO - 2023-07-22 06:59:11 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:11 --> Input Class Initialized
INFO - 2023-07-22 06:59:11 --> Language Class Initialized
ERROR - 2023-07-22 06:59:11 --> 404 Page Not Found: Defaultjson/index
ERROR - 2023-07-22 06:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:11 --> Config Class Initialized
INFO - 2023-07-22 06:59:11 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:11 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:11 --> URI Class Initialized
INFO - 2023-07-22 06:59:11 --> Router Class Initialized
INFO - 2023-07-22 06:59:11 --> Output Class Initialized
INFO - 2023-07-22 06:59:11 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:11 --> Input Class Initialized
INFO - 2023-07-22 06:59:11 --> Language Class Initialized
ERROR - 2023-07-22 06:59:11 --> 404 Page Not Found: Dockerfiledev/index
ERROR - 2023-07-22 06:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:11 --> Config Class Initialized
INFO - 2023-07-22 06:59:11 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:11 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:11 --> URI Class Initialized
INFO - 2023-07-22 06:59:11 --> Router Class Initialized
INFO - 2023-07-22 06:59:11 --> Output Class Initialized
INFO - 2023-07-22 06:59:11 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:11 --> Input Class Initialized
INFO - 2023-07-22 06:59:11 --> Language Class Initialized
ERROR - 2023-07-22 06:59:11 --> 404 Page Not Found: DevDockerfile/index
ERROR - 2023-07-22 06:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:11 --> Config Class Initialized
INFO - 2023-07-22 06:59:11 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:11 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:11 --> URI Class Initialized
INFO - 2023-07-22 06:59:11 --> Router Class Initialized
INFO - 2023-07-22 06:59:11 --> Output Class Initialized
INFO - 2023-07-22 06:59:11 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:11 --> Input Class Initialized
INFO - 2023-07-22 06:59:11 --> Language Class Initialized
ERROR - 2023-07-22 06:59:11 --> 404 Page Not Found: ProductionDockerfile/index
ERROR - 2023-07-22 06:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:11 --> Config Class Initialized
INFO - 2023-07-22 06:59:11 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:11 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:11 --> URI Class Initialized
INFO - 2023-07-22 06:59:11 --> Router Class Initialized
INFO - 2023-07-22 06:59:11 --> Output Class Initialized
INFO - 2023-07-22 06:59:11 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:11 --> Input Class Initialized
INFO - 2023-07-22 06:59:11 --> Language Class Initialized
ERROR - 2023-07-22 06:59:11 --> 404 Page Not Found: Docker-composeyaml/index
ERROR - 2023-07-22 06:59:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:11 --> Config Class Initialized
INFO - 2023-07-22 06:59:11 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:11 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:11 --> URI Class Initialized
INFO - 2023-07-22 06:59:11 --> Router Class Initialized
INFO - 2023-07-22 06:59:11 --> Output Class Initialized
INFO - 2023-07-22 06:59:11 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:11 --> Input Class Initialized
INFO - 2023-07-22 06:59:11 --> Language Class Initialized
ERROR - 2023-07-22 06:59:11 --> 404 Page Not Found: Docker-composeyml/index
ERROR - 2023-07-22 06:59:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:14 --> Config Class Initialized
INFO - 2023-07-22 06:59:14 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:14 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:14 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:14 --> URI Class Initialized
INFO - 2023-07-22 06:59:14 --> Router Class Initialized
INFO - 2023-07-22 06:59:14 --> Output Class Initialized
INFO - 2023-07-22 06:59:14 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:14 --> Input Class Initialized
INFO - 2023-07-22 06:59:14 --> Language Class Initialized
ERROR - 2023-07-22 06:59:14 --> 404 Page Not Found: Github/index
ERROR - 2023-07-22 06:59:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:17 --> Config Class Initialized
INFO - 2023-07-22 06:59:17 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:17 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:17 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:17 --> URI Class Initialized
INFO - 2023-07-22 06:59:17 --> Router Class Initialized
INFO - 2023-07-22 06:59:17 --> Output Class Initialized
INFO - 2023-07-22 06:59:17 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:17 --> Input Class Initialized
INFO - 2023-07-22 06:59:17 --> Language Class Initialized
ERROR - 2023-07-22 06:59:17 --> 404 Page Not Found: Config/production.json
ERROR - 2023-07-22 06:59:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 06:59:17 --> Config Class Initialized
INFO - 2023-07-22 06:59:17 --> Hooks Class Initialized
DEBUG - 2023-07-22 06:59:17 --> UTF-8 Support Enabled
INFO - 2023-07-22 06:59:17 --> Utf8 Class Initialized
INFO - 2023-07-22 06:59:17 --> URI Class Initialized
INFO - 2023-07-22 06:59:17 --> Router Class Initialized
INFO - 2023-07-22 06:59:17 --> Output Class Initialized
INFO - 2023-07-22 06:59:17 --> Security Class Initialized
DEBUG - 2023-07-22 06:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 06:59:17 --> Input Class Initialized
INFO - 2023-07-22 06:59:17 --> Language Class Initialized
ERROR - 2023-07-22 06:59:17 --> 404 Page Not Found: Config/staging.json
ERROR - 2023-07-22 07:19:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 07:19:49 --> Config Class Initialized
INFO - 2023-07-22 07:19:49 --> Hooks Class Initialized
DEBUG - 2023-07-22 07:19:49 --> UTF-8 Support Enabled
INFO - 2023-07-22 07:19:49 --> Utf8 Class Initialized
INFO - 2023-07-22 07:19:49 --> URI Class Initialized
DEBUG - 2023-07-22 07:19:49 --> No URI present. Default controller set.
INFO - 2023-07-22 07:19:49 --> Router Class Initialized
INFO - 2023-07-22 07:19:49 --> Output Class Initialized
INFO - 2023-07-22 07:19:49 --> Security Class Initialized
DEBUG - 2023-07-22 07:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 07:19:49 --> Input Class Initialized
INFO - 2023-07-22 07:19:49 --> Language Class Initialized
INFO - 2023-07-22 07:19:49 --> Loader Class Initialized
INFO - 2023-07-22 07:19:49 --> Helper loaded: url_helper
INFO - 2023-07-22 07:19:49 --> Helper loaded: file_helper
INFO - 2023-07-22 07:19:49 --> Helper loaded: html_helper
INFO - 2023-07-22 07:19:49 --> Helper loaded: text_helper
INFO - 2023-07-22 07:19:49 --> Helper loaded: form_helper
INFO - 2023-07-22 07:19:49 --> Helper loaded: lang_helper
INFO - 2023-07-22 07:19:49 --> Helper loaded: security_helper
INFO - 2023-07-22 07:19:49 --> Helper loaded: cookie_helper
INFO - 2023-07-22 07:19:49 --> Database Driver Class Initialized
INFO - 2023-07-22 07:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 07:19:49 --> Parser Class Initialized
INFO - 2023-07-22 07:19:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 07:19:49 --> Pagination Class Initialized
INFO - 2023-07-22 07:19:49 --> Form Validation Class Initialized
INFO - 2023-07-22 07:19:49 --> Controller Class Initialized
INFO - 2023-07-22 07:19:49 --> Model Class Initialized
DEBUG - 2023-07-22 07:19:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 07:19:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 07:19:50 --> Config Class Initialized
INFO - 2023-07-22 07:19:50 --> Hooks Class Initialized
DEBUG - 2023-07-22 07:19:50 --> UTF-8 Support Enabled
INFO - 2023-07-22 07:19:50 --> Utf8 Class Initialized
INFO - 2023-07-22 07:19:50 --> URI Class Initialized
INFO - 2023-07-22 07:19:50 --> Router Class Initialized
INFO - 2023-07-22 07:19:50 --> Output Class Initialized
INFO - 2023-07-22 07:19:50 --> Security Class Initialized
DEBUG - 2023-07-22 07:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 07:19:50 --> Input Class Initialized
INFO - 2023-07-22 07:19:50 --> Language Class Initialized
INFO - 2023-07-22 07:19:50 --> Loader Class Initialized
INFO - 2023-07-22 07:19:50 --> Helper loaded: url_helper
INFO - 2023-07-22 07:19:50 --> Helper loaded: file_helper
INFO - 2023-07-22 07:19:50 --> Helper loaded: html_helper
INFO - 2023-07-22 07:19:50 --> Helper loaded: text_helper
INFO - 2023-07-22 07:19:50 --> Helper loaded: form_helper
INFO - 2023-07-22 07:19:50 --> Helper loaded: lang_helper
INFO - 2023-07-22 07:19:50 --> Helper loaded: security_helper
INFO - 2023-07-22 07:19:50 --> Helper loaded: cookie_helper
INFO - 2023-07-22 07:19:50 --> Database Driver Class Initialized
INFO - 2023-07-22 07:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 07:19:50 --> Parser Class Initialized
INFO - 2023-07-22 07:19:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 07:19:50 --> Pagination Class Initialized
INFO - 2023-07-22 07:19:50 --> Form Validation Class Initialized
INFO - 2023-07-22 07:19:50 --> Controller Class Initialized
INFO - 2023-07-22 07:19:50 --> Model Class Initialized
DEBUG - 2023-07-22 07:19:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-22 07:19:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-22 07:19:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-22 07:19:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-22 07:19:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-22 07:19:50 --> Model Class Initialized
INFO - 2023-07-22 07:19:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-22 07:19:50 --> Final output sent to browser
DEBUG - 2023-07-22 07:19:50 --> Total execution time: 0.0311
ERROR - 2023-07-22 07:19:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 07:19:59 --> Config Class Initialized
INFO - 2023-07-22 07:19:59 --> Hooks Class Initialized
DEBUG - 2023-07-22 07:19:59 --> UTF-8 Support Enabled
INFO - 2023-07-22 07:19:59 --> Utf8 Class Initialized
INFO - 2023-07-22 07:19:59 --> URI Class Initialized
DEBUG - 2023-07-22 07:19:59 --> No URI present. Default controller set.
INFO - 2023-07-22 07:19:59 --> Router Class Initialized
INFO - 2023-07-22 07:19:59 --> Output Class Initialized
INFO - 2023-07-22 07:19:59 --> Security Class Initialized
DEBUG - 2023-07-22 07:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 07:19:59 --> Input Class Initialized
INFO - 2023-07-22 07:19:59 --> Language Class Initialized
INFO - 2023-07-22 07:19:59 --> Loader Class Initialized
INFO - 2023-07-22 07:19:59 --> Helper loaded: url_helper
INFO - 2023-07-22 07:19:59 --> Helper loaded: file_helper
INFO - 2023-07-22 07:19:59 --> Helper loaded: html_helper
INFO - 2023-07-22 07:19:59 --> Helper loaded: text_helper
INFO - 2023-07-22 07:19:59 --> Helper loaded: form_helper
INFO - 2023-07-22 07:19:59 --> Helper loaded: lang_helper
INFO - 2023-07-22 07:19:59 --> Helper loaded: security_helper
INFO - 2023-07-22 07:19:59 --> Helper loaded: cookie_helper
INFO - 2023-07-22 07:19:59 --> Database Driver Class Initialized
INFO - 2023-07-22 07:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 07:19:59 --> Parser Class Initialized
INFO - 2023-07-22 07:19:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 07:19:59 --> Pagination Class Initialized
INFO - 2023-07-22 07:19:59 --> Form Validation Class Initialized
INFO - 2023-07-22 07:19:59 --> Controller Class Initialized
INFO - 2023-07-22 07:19:59 --> Model Class Initialized
DEBUG - 2023-07-22 07:19:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 07:19:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 07:19:59 --> Config Class Initialized
INFO - 2023-07-22 07:19:59 --> Hooks Class Initialized
DEBUG - 2023-07-22 07:19:59 --> UTF-8 Support Enabled
INFO - 2023-07-22 07:19:59 --> Utf8 Class Initialized
INFO - 2023-07-22 07:19:59 --> URI Class Initialized
INFO - 2023-07-22 07:19:59 --> Router Class Initialized
INFO - 2023-07-22 07:19:59 --> Output Class Initialized
INFO - 2023-07-22 07:19:59 --> Security Class Initialized
DEBUG - 2023-07-22 07:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 07:19:59 --> Input Class Initialized
INFO - 2023-07-22 07:19:59 --> Language Class Initialized
INFO - 2023-07-22 07:19:59 --> Loader Class Initialized
INFO - 2023-07-22 07:19:59 --> Helper loaded: url_helper
INFO - 2023-07-22 07:19:59 --> Helper loaded: file_helper
INFO - 2023-07-22 07:19:59 --> Helper loaded: html_helper
INFO - 2023-07-22 07:19:59 --> Helper loaded: text_helper
INFO - 2023-07-22 07:19:59 --> Helper loaded: form_helper
INFO - 2023-07-22 07:19:59 --> Helper loaded: lang_helper
INFO - 2023-07-22 07:19:59 --> Helper loaded: security_helper
INFO - 2023-07-22 07:19:59 --> Helper loaded: cookie_helper
INFO - 2023-07-22 07:19:59 --> Database Driver Class Initialized
INFO - 2023-07-22 07:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 07:19:59 --> Parser Class Initialized
INFO - 2023-07-22 07:19:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 07:19:59 --> Pagination Class Initialized
INFO - 2023-07-22 07:19:59 --> Form Validation Class Initialized
INFO - 2023-07-22 07:19:59 --> Controller Class Initialized
INFO - 2023-07-22 07:19:59 --> Model Class Initialized
DEBUG - 2023-07-22 07:19:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-22 07:19:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-22 07:19:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-22 07:19:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-22 07:19:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-22 07:19:59 --> Model Class Initialized
INFO - 2023-07-22 07:19:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-22 07:19:59 --> Final output sent to browser
DEBUG - 2023-07-22 07:19:59 --> Total execution time: 0.0345
ERROR - 2023-07-22 08:49:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 08:49:05 --> Config Class Initialized
INFO - 2023-07-22 08:49:05 --> Hooks Class Initialized
DEBUG - 2023-07-22 08:49:05 --> UTF-8 Support Enabled
INFO - 2023-07-22 08:49:05 --> Utf8 Class Initialized
INFO - 2023-07-22 08:49:05 --> URI Class Initialized
DEBUG - 2023-07-22 08:49:05 --> No URI present. Default controller set.
INFO - 2023-07-22 08:49:05 --> Router Class Initialized
INFO - 2023-07-22 08:49:05 --> Output Class Initialized
INFO - 2023-07-22 08:49:05 --> Security Class Initialized
DEBUG - 2023-07-22 08:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 08:49:05 --> Input Class Initialized
INFO - 2023-07-22 08:49:05 --> Language Class Initialized
INFO - 2023-07-22 08:49:05 --> Loader Class Initialized
INFO - 2023-07-22 08:49:05 --> Helper loaded: url_helper
INFO - 2023-07-22 08:49:05 --> Helper loaded: file_helper
INFO - 2023-07-22 08:49:05 --> Helper loaded: html_helper
INFO - 2023-07-22 08:49:05 --> Helper loaded: text_helper
INFO - 2023-07-22 08:49:05 --> Helper loaded: form_helper
INFO - 2023-07-22 08:49:05 --> Helper loaded: lang_helper
INFO - 2023-07-22 08:49:05 --> Helper loaded: security_helper
INFO - 2023-07-22 08:49:05 --> Helper loaded: cookie_helper
INFO - 2023-07-22 08:49:05 --> Database Driver Class Initialized
INFO - 2023-07-22 08:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 08:49:05 --> Parser Class Initialized
INFO - 2023-07-22 08:49:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 08:49:05 --> Pagination Class Initialized
INFO - 2023-07-22 08:49:05 --> Form Validation Class Initialized
INFO - 2023-07-22 08:49:05 --> Controller Class Initialized
INFO - 2023-07-22 08:49:05 --> Model Class Initialized
DEBUG - 2023-07-22 08:49:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 08:49:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 08:49:05 --> Config Class Initialized
INFO - 2023-07-22 08:49:05 --> Hooks Class Initialized
DEBUG - 2023-07-22 08:49:05 --> UTF-8 Support Enabled
INFO - 2023-07-22 08:49:05 --> Utf8 Class Initialized
INFO - 2023-07-22 08:49:05 --> URI Class Initialized
INFO - 2023-07-22 08:49:05 --> Router Class Initialized
INFO - 2023-07-22 08:49:05 --> Output Class Initialized
INFO - 2023-07-22 08:49:05 --> Security Class Initialized
DEBUG - 2023-07-22 08:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 08:49:05 --> Input Class Initialized
INFO - 2023-07-22 08:49:05 --> Language Class Initialized
INFO - 2023-07-22 08:49:05 --> Loader Class Initialized
INFO - 2023-07-22 08:49:05 --> Helper loaded: url_helper
INFO - 2023-07-22 08:49:05 --> Helper loaded: file_helper
INFO - 2023-07-22 08:49:05 --> Helper loaded: html_helper
INFO - 2023-07-22 08:49:05 --> Helper loaded: text_helper
INFO - 2023-07-22 08:49:05 --> Helper loaded: form_helper
INFO - 2023-07-22 08:49:05 --> Helper loaded: lang_helper
INFO - 2023-07-22 08:49:05 --> Helper loaded: security_helper
INFO - 2023-07-22 08:49:05 --> Helper loaded: cookie_helper
INFO - 2023-07-22 08:49:05 --> Database Driver Class Initialized
INFO - 2023-07-22 08:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 08:49:05 --> Parser Class Initialized
INFO - 2023-07-22 08:49:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 08:49:05 --> Pagination Class Initialized
INFO - 2023-07-22 08:49:05 --> Form Validation Class Initialized
INFO - 2023-07-22 08:49:05 --> Controller Class Initialized
INFO - 2023-07-22 08:49:05 --> Model Class Initialized
DEBUG - 2023-07-22 08:49:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-07-22 08:49:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-07-22 08:49:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-07-22 08:49:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-07-22 08:49:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-07-22 08:49:05 --> Model Class Initialized
INFO - 2023-07-22 08:49:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-07-22 08:49:05 --> Final output sent to browser
DEBUG - 2023-07-22 08:49:05 --> Total execution time: 0.0385
ERROR - 2023-07-22 13:20:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 13:20:54 --> Config Class Initialized
INFO - 2023-07-22 13:20:54 --> Hooks Class Initialized
DEBUG - 2023-07-22 13:20:54 --> UTF-8 Support Enabled
INFO - 2023-07-22 13:20:54 --> Utf8 Class Initialized
INFO - 2023-07-22 13:20:54 --> URI Class Initialized
DEBUG - 2023-07-22 13:20:54 --> No URI present. Default controller set.
INFO - 2023-07-22 13:20:54 --> Router Class Initialized
INFO - 2023-07-22 13:20:54 --> Output Class Initialized
INFO - 2023-07-22 13:20:54 --> Security Class Initialized
DEBUG - 2023-07-22 13:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 13:20:54 --> Input Class Initialized
INFO - 2023-07-22 13:20:54 --> Language Class Initialized
INFO - 2023-07-22 13:20:54 --> Loader Class Initialized
INFO - 2023-07-22 13:20:54 --> Helper loaded: url_helper
INFO - 2023-07-22 13:20:54 --> Helper loaded: file_helper
INFO - 2023-07-22 13:20:54 --> Helper loaded: html_helper
INFO - 2023-07-22 13:20:54 --> Helper loaded: text_helper
INFO - 2023-07-22 13:20:54 --> Helper loaded: form_helper
INFO - 2023-07-22 13:20:54 --> Helper loaded: lang_helper
INFO - 2023-07-22 13:20:54 --> Helper loaded: security_helper
INFO - 2023-07-22 13:20:54 --> Helper loaded: cookie_helper
INFO - 2023-07-22 13:20:54 --> Database Driver Class Initialized
INFO - 2023-07-22 13:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 13:20:54 --> Parser Class Initialized
INFO - 2023-07-22 13:20:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 13:20:54 --> Pagination Class Initialized
INFO - 2023-07-22 13:20:54 --> Form Validation Class Initialized
INFO - 2023-07-22 13:20:54 --> Controller Class Initialized
INFO - 2023-07-22 13:20:54 --> Model Class Initialized
DEBUG - 2023-07-22 13:20:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 16:13:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 16:13:06 --> Config Class Initialized
INFO - 2023-07-22 16:13:06 --> Hooks Class Initialized
DEBUG - 2023-07-22 16:13:06 --> UTF-8 Support Enabled
INFO - 2023-07-22 16:13:06 --> Utf8 Class Initialized
INFO - 2023-07-22 16:13:06 --> URI Class Initialized
DEBUG - 2023-07-22 16:13:06 --> No URI present. Default controller set.
INFO - 2023-07-22 16:13:06 --> Router Class Initialized
INFO - 2023-07-22 16:13:06 --> Output Class Initialized
INFO - 2023-07-22 16:13:06 --> Security Class Initialized
DEBUG - 2023-07-22 16:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 16:13:06 --> Input Class Initialized
INFO - 2023-07-22 16:13:06 --> Language Class Initialized
INFO - 2023-07-22 16:13:06 --> Loader Class Initialized
INFO - 2023-07-22 16:13:06 --> Helper loaded: url_helper
INFO - 2023-07-22 16:13:06 --> Helper loaded: file_helper
INFO - 2023-07-22 16:13:06 --> Helper loaded: html_helper
INFO - 2023-07-22 16:13:06 --> Helper loaded: text_helper
INFO - 2023-07-22 16:13:06 --> Helper loaded: form_helper
INFO - 2023-07-22 16:13:06 --> Helper loaded: lang_helper
INFO - 2023-07-22 16:13:06 --> Helper loaded: security_helper
INFO - 2023-07-22 16:13:06 --> Helper loaded: cookie_helper
INFO - 2023-07-22 16:13:06 --> Database Driver Class Initialized
INFO - 2023-07-22 16:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 16:13:06 --> Parser Class Initialized
INFO - 2023-07-22 16:13:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 16:13:06 --> Pagination Class Initialized
INFO - 2023-07-22 16:13:06 --> Form Validation Class Initialized
INFO - 2023-07-22 16:13:06 --> Controller Class Initialized
INFO - 2023-07-22 16:13:06 --> Model Class Initialized
DEBUG - 2023-07-22 16:13:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 16:13:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 16:13:41 --> Config Class Initialized
INFO - 2023-07-22 16:13:41 --> Hooks Class Initialized
DEBUG - 2023-07-22 16:13:41 --> UTF-8 Support Enabled
INFO - 2023-07-22 16:13:41 --> Utf8 Class Initialized
INFO - 2023-07-22 16:13:41 --> URI Class Initialized
DEBUG - 2023-07-22 16:13:41 --> No URI present. Default controller set.
INFO - 2023-07-22 16:13:41 --> Router Class Initialized
INFO - 2023-07-22 16:13:41 --> Output Class Initialized
INFO - 2023-07-22 16:13:41 --> Security Class Initialized
DEBUG - 2023-07-22 16:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 16:13:41 --> Input Class Initialized
INFO - 2023-07-22 16:13:41 --> Language Class Initialized
INFO - 2023-07-22 16:13:41 --> Loader Class Initialized
INFO - 2023-07-22 16:13:41 --> Helper loaded: url_helper
INFO - 2023-07-22 16:13:41 --> Helper loaded: file_helper
INFO - 2023-07-22 16:13:41 --> Helper loaded: html_helper
INFO - 2023-07-22 16:13:41 --> Helper loaded: text_helper
INFO - 2023-07-22 16:13:41 --> Helper loaded: form_helper
INFO - 2023-07-22 16:13:41 --> Helper loaded: lang_helper
INFO - 2023-07-22 16:13:41 --> Helper loaded: security_helper
INFO - 2023-07-22 16:13:41 --> Helper loaded: cookie_helper
INFO - 2023-07-22 16:13:41 --> Database Driver Class Initialized
INFO - 2023-07-22 16:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 16:13:41 --> Parser Class Initialized
INFO - 2023-07-22 16:13:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 16:13:41 --> Pagination Class Initialized
INFO - 2023-07-22 16:13:41 --> Form Validation Class Initialized
INFO - 2023-07-22 16:13:41 --> Controller Class Initialized
INFO - 2023-07-22 16:13:41 --> Model Class Initialized
DEBUG - 2023-07-22 16:13:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 16:15:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 16:15:18 --> Config Class Initialized
INFO - 2023-07-22 16:15:18 --> Hooks Class Initialized
DEBUG - 2023-07-22 16:15:18 --> UTF-8 Support Enabled
INFO - 2023-07-22 16:15:18 --> Utf8 Class Initialized
INFO - 2023-07-22 16:15:18 --> URI Class Initialized
DEBUG - 2023-07-22 16:15:18 --> No URI present. Default controller set.
INFO - 2023-07-22 16:15:18 --> Router Class Initialized
INFO - 2023-07-22 16:15:18 --> Output Class Initialized
INFO - 2023-07-22 16:15:18 --> Security Class Initialized
DEBUG - 2023-07-22 16:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 16:15:18 --> Input Class Initialized
INFO - 2023-07-22 16:15:18 --> Language Class Initialized
INFO - 2023-07-22 16:15:18 --> Loader Class Initialized
INFO - 2023-07-22 16:15:18 --> Helper loaded: url_helper
INFO - 2023-07-22 16:15:18 --> Helper loaded: file_helper
INFO - 2023-07-22 16:15:18 --> Helper loaded: html_helper
INFO - 2023-07-22 16:15:18 --> Helper loaded: text_helper
INFO - 2023-07-22 16:15:18 --> Helper loaded: form_helper
INFO - 2023-07-22 16:15:18 --> Helper loaded: lang_helper
INFO - 2023-07-22 16:15:18 --> Helper loaded: security_helper
INFO - 2023-07-22 16:15:18 --> Helper loaded: cookie_helper
INFO - 2023-07-22 16:15:18 --> Database Driver Class Initialized
INFO - 2023-07-22 16:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 16:15:18 --> Parser Class Initialized
INFO - 2023-07-22 16:15:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 16:15:18 --> Pagination Class Initialized
INFO - 2023-07-22 16:15:18 --> Form Validation Class Initialized
INFO - 2023-07-22 16:15:18 --> Controller Class Initialized
INFO - 2023-07-22 16:15:18 --> Model Class Initialized
DEBUG - 2023-07-22 16:15:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 16:15:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 16:15:18 --> Config Class Initialized
INFO - 2023-07-22 16:15:18 --> Hooks Class Initialized
DEBUG - 2023-07-22 16:15:18 --> UTF-8 Support Enabled
INFO - 2023-07-22 16:15:18 --> Utf8 Class Initialized
INFO - 2023-07-22 16:15:18 --> URI Class Initialized
DEBUG - 2023-07-22 16:15:18 --> No URI present. Default controller set.
INFO - 2023-07-22 16:15:18 --> Router Class Initialized
INFO - 2023-07-22 16:15:18 --> Output Class Initialized
INFO - 2023-07-22 16:15:18 --> Security Class Initialized
DEBUG - 2023-07-22 16:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 16:15:18 --> Input Class Initialized
INFO - 2023-07-22 16:15:18 --> Language Class Initialized
INFO - 2023-07-22 16:15:18 --> Loader Class Initialized
INFO - 2023-07-22 16:15:18 --> Helper loaded: url_helper
INFO - 2023-07-22 16:15:18 --> Helper loaded: file_helper
INFO - 2023-07-22 16:15:18 --> Helper loaded: html_helper
INFO - 2023-07-22 16:15:18 --> Helper loaded: text_helper
INFO - 2023-07-22 16:15:18 --> Helper loaded: form_helper
INFO - 2023-07-22 16:15:18 --> Helper loaded: lang_helper
INFO - 2023-07-22 16:15:18 --> Helper loaded: security_helper
INFO - 2023-07-22 16:15:18 --> Helper loaded: cookie_helper
INFO - 2023-07-22 16:15:18 --> Database Driver Class Initialized
INFO - 2023-07-22 16:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 16:15:18 --> Parser Class Initialized
INFO - 2023-07-22 16:15:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 16:15:18 --> Pagination Class Initialized
INFO - 2023-07-22 16:15:18 --> Form Validation Class Initialized
INFO - 2023-07-22 16:15:18 --> Controller Class Initialized
INFO - 2023-07-22 16:15:18 --> Model Class Initialized
DEBUG - 2023-07-22 16:15:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 16:27:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 16:27:49 --> Config Class Initialized
INFO - 2023-07-22 16:27:49 --> Hooks Class Initialized
DEBUG - 2023-07-22 16:27:49 --> UTF-8 Support Enabled
INFO - 2023-07-22 16:27:49 --> Utf8 Class Initialized
INFO - 2023-07-22 16:27:49 --> URI Class Initialized
DEBUG - 2023-07-22 16:27:49 --> No URI present. Default controller set.
INFO - 2023-07-22 16:27:49 --> Router Class Initialized
INFO - 2023-07-22 16:27:49 --> Output Class Initialized
INFO - 2023-07-22 16:27:49 --> Security Class Initialized
DEBUG - 2023-07-22 16:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 16:27:49 --> Input Class Initialized
INFO - 2023-07-22 16:27:49 --> Language Class Initialized
INFO - 2023-07-22 16:27:49 --> Loader Class Initialized
INFO - 2023-07-22 16:27:49 --> Helper loaded: url_helper
INFO - 2023-07-22 16:27:49 --> Helper loaded: file_helper
INFO - 2023-07-22 16:27:49 --> Helper loaded: html_helper
INFO - 2023-07-22 16:27:49 --> Helper loaded: text_helper
INFO - 2023-07-22 16:27:49 --> Helper loaded: form_helper
INFO - 2023-07-22 16:27:49 --> Helper loaded: lang_helper
INFO - 2023-07-22 16:27:49 --> Helper loaded: security_helper
INFO - 2023-07-22 16:27:49 --> Helper loaded: cookie_helper
INFO - 2023-07-22 16:27:49 --> Database Driver Class Initialized
INFO - 2023-07-22 16:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 16:27:49 --> Parser Class Initialized
INFO - 2023-07-22 16:27:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 16:27:49 --> Pagination Class Initialized
INFO - 2023-07-22 16:27:49 --> Form Validation Class Initialized
INFO - 2023-07-22 16:27:49 --> Controller Class Initialized
INFO - 2023-07-22 16:27:49 --> Model Class Initialized
DEBUG - 2023-07-22 16:27:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 16:28:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 16:28:10 --> Config Class Initialized
INFO - 2023-07-22 16:28:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 16:28:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 16:28:10 --> Utf8 Class Initialized
INFO - 2023-07-22 16:28:10 --> URI Class Initialized
DEBUG - 2023-07-22 16:28:10 --> No URI present. Default controller set.
INFO - 2023-07-22 16:28:10 --> Router Class Initialized
INFO - 2023-07-22 16:28:10 --> Output Class Initialized
INFO - 2023-07-22 16:28:10 --> Security Class Initialized
DEBUG - 2023-07-22 16:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 16:28:10 --> Input Class Initialized
INFO - 2023-07-22 16:28:10 --> Language Class Initialized
INFO - 2023-07-22 16:28:10 --> Loader Class Initialized
INFO - 2023-07-22 16:28:10 --> Helper loaded: url_helper
INFO - 2023-07-22 16:28:10 --> Helper loaded: file_helper
INFO - 2023-07-22 16:28:10 --> Helper loaded: html_helper
INFO - 2023-07-22 16:28:10 --> Helper loaded: text_helper
INFO - 2023-07-22 16:28:10 --> Helper loaded: form_helper
INFO - 2023-07-22 16:28:10 --> Helper loaded: lang_helper
INFO - 2023-07-22 16:28:10 --> Helper loaded: security_helper
INFO - 2023-07-22 16:28:10 --> Helper loaded: cookie_helper
INFO - 2023-07-22 16:28:10 --> Database Driver Class Initialized
INFO - 2023-07-22 16:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 16:28:10 --> Parser Class Initialized
INFO - 2023-07-22 16:28:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 16:28:10 --> Pagination Class Initialized
INFO - 2023-07-22 16:28:10 --> Form Validation Class Initialized
INFO - 2023-07-22 16:28:10 --> Controller Class Initialized
INFO - 2023-07-22 16:28:10 --> Model Class Initialized
DEBUG - 2023-07-22 16:28:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 16:30:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 16:30:49 --> Config Class Initialized
INFO - 2023-07-22 16:30:49 --> Hooks Class Initialized
DEBUG - 2023-07-22 16:30:49 --> UTF-8 Support Enabled
INFO - 2023-07-22 16:30:49 --> Utf8 Class Initialized
INFO - 2023-07-22 16:30:49 --> URI Class Initialized
DEBUG - 2023-07-22 16:30:49 --> No URI present. Default controller set.
INFO - 2023-07-22 16:30:49 --> Router Class Initialized
INFO - 2023-07-22 16:30:49 --> Output Class Initialized
INFO - 2023-07-22 16:30:49 --> Security Class Initialized
DEBUG - 2023-07-22 16:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 16:30:49 --> Input Class Initialized
INFO - 2023-07-22 16:30:49 --> Language Class Initialized
INFO - 2023-07-22 16:30:49 --> Loader Class Initialized
INFO - 2023-07-22 16:30:49 --> Helper loaded: url_helper
INFO - 2023-07-22 16:30:49 --> Helper loaded: file_helper
INFO - 2023-07-22 16:30:49 --> Helper loaded: html_helper
INFO - 2023-07-22 16:30:49 --> Helper loaded: text_helper
INFO - 2023-07-22 16:30:49 --> Helper loaded: form_helper
INFO - 2023-07-22 16:30:49 --> Helper loaded: lang_helper
INFO - 2023-07-22 16:30:49 --> Helper loaded: security_helper
INFO - 2023-07-22 16:30:49 --> Helper loaded: cookie_helper
INFO - 2023-07-22 16:30:49 --> Database Driver Class Initialized
INFO - 2023-07-22 16:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 16:30:49 --> Parser Class Initialized
INFO - 2023-07-22 16:30:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 16:30:49 --> Pagination Class Initialized
INFO - 2023-07-22 16:30:49 --> Form Validation Class Initialized
INFO - 2023-07-22 16:30:49 --> Controller Class Initialized
INFO - 2023-07-22 16:30:49 --> Model Class Initialized
DEBUG - 2023-07-22 16:30:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 16:30:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 16:30:56 --> Config Class Initialized
INFO - 2023-07-22 16:30:56 --> Hooks Class Initialized
DEBUG - 2023-07-22 16:30:56 --> UTF-8 Support Enabled
INFO - 2023-07-22 16:30:56 --> Utf8 Class Initialized
INFO - 2023-07-22 16:30:56 --> URI Class Initialized
DEBUG - 2023-07-22 16:30:56 --> No URI present. Default controller set.
INFO - 2023-07-22 16:30:56 --> Router Class Initialized
INFO - 2023-07-22 16:30:56 --> Output Class Initialized
INFO - 2023-07-22 16:30:56 --> Security Class Initialized
DEBUG - 2023-07-22 16:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 16:30:56 --> Input Class Initialized
INFO - 2023-07-22 16:30:56 --> Language Class Initialized
INFO - 2023-07-22 16:30:56 --> Loader Class Initialized
INFO - 2023-07-22 16:30:56 --> Helper loaded: url_helper
INFO - 2023-07-22 16:30:56 --> Helper loaded: file_helper
INFO - 2023-07-22 16:30:56 --> Helper loaded: html_helper
INFO - 2023-07-22 16:30:56 --> Helper loaded: text_helper
INFO - 2023-07-22 16:30:56 --> Helper loaded: form_helper
INFO - 2023-07-22 16:30:56 --> Helper loaded: lang_helper
INFO - 2023-07-22 16:30:56 --> Helper loaded: security_helper
INFO - 2023-07-22 16:30:56 --> Helper loaded: cookie_helper
INFO - 2023-07-22 16:30:56 --> Database Driver Class Initialized
INFO - 2023-07-22 16:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 16:30:56 --> Parser Class Initialized
INFO - 2023-07-22 16:30:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 16:30:56 --> Pagination Class Initialized
INFO - 2023-07-22 16:30:56 --> Form Validation Class Initialized
INFO - 2023-07-22 16:30:56 --> Controller Class Initialized
INFO - 2023-07-22 16:30:56 --> Model Class Initialized
DEBUG - 2023-07-22 16:30:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 16:44:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 16:44:14 --> Config Class Initialized
INFO - 2023-07-22 16:44:14 --> Hooks Class Initialized
DEBUG - 2023-07-22 16:44:14 --> UTF-8 Support Enabled
INFO - 2023-07-22 16:44:14 --> Utf8 Class Initialized
INFO - 2023-07-22 16:44:14 --> URI Class Initialized
DEBUG - 2023-07-22 16:44:14 --> No URI present. Default controller set.
INFO - 2023-07-22 16:44:14 --> Router Class Initialized
INFO - 2023-07-22 16:44:14 --> Output Class Initialized
INFO - 2023-07-22 16:44:14 --> Security Class Initialized
DEBUG - 2023-07-22 16:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 16:44:14 --> Input Class Initialized
INFO - 2023-07-22 16:44:14 --> Language Class Initialized
INFO - 2023-07-22 16:44:14 --> Loader Class Initialized
INFO - 2023-07-22 16:44:14 --> Helper loaded: url_helper
INFO - 2023-07-22 16:44:14 --> Helper loaded: file_helper
INFO - 2023-07-22 16:44:14 --> Helper loaded: html_helper
INFO - 2023-07-22 16:44:14 --> Helper loaded: text_helper
INFO - 2023-07-22 16:44:14 --> Helper loaded: form_helper
INFO - 2023-07-22 16:44:14 --> Helper loaded: lang_helper
INFO - 2023-07-22 16:44:14 --> Helper loaded: security_helper
INFO - 2023-07-22 16:44:14 --> Helper loaded: cookie_helper
INFO - 2023-07-22 16:44:14 --> Database Driver Class Initialized
INFO - 2023-07-22 16:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 16:44:14 --> Parser Class Initialized
INFO - 2023-07-22 16:44:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 16:44:14 --> Pagination Class Initialized
INFO - 2023-07-22 16:44:14 --> Form Validation Class Initialized
INFO - 2023-07-22 16:44:14 --> Controller Class Initialized
INFO - 2023-07-22 16:44:14 --> Model Class Initialized
DEBUG - 2023-07-22 16:44:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 16:44:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 16:44:51 --> Config Class Initialized
INFO - 2023-07-22 16:44:51 --> Hooks Class Initialized
DEBUG - 2023-07-22 16:44:51 --> UTF-8 Support Enabled
INFO - 2023-07-22 16:44:51 --> Utf8 Class Initialized
INFO - 2023-07-22 16:44:51 --> URI Class Initialized
DEBUG - 2023-07-22 16:44:51 --> No URI present. Default controller set.
INFO - 2023-07-22 16:44:51 --> Router Class Initialized
INFO - 2023-07-22 16:44:51 --> Output Class Initialized
INFO - 2023-07-22 16:44:51 --> Security Class Initialized
DEBUG - 2023-07-22 16:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 16:44:51 --> Input Class Initialized
INFO - 2023-07-22 16:44:51 --> Language Class Initialized
INFO - 2023-07-22 16:44:51 --> Loader Class Initialized
INFO - 2023-07-22 16:44:51 --> Helper loaded: url_helper
INFO - 2023-07-22 16:44:51 --> Helper loaded: file_helper
INFO - 2023-07-22 16:44:51 --> Helper loaded: html_helper
INFO - 2023-07-22 16:44:51 --> Helper loaded: text_helper
INFO - 2023-07-22 16:44:51 --> Helper loaded: form_helper
INFO - 2023-07-22 16:44:51 --> Helper loaded: lang_helper
INFO - 2023-07-22 16:44:51 --> Helper loaded: security_helper
INFO - 2023-07-22 16:44:51 --> Helper loaded: cookie_helper
INFO - 2023-07-22 16:44:51 --> Database Driver Class Initialized
INFO - 2023-07-22 16:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 16:44:51 --> Parser Class Initialized
INFO - 2023-07-22 16:44:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 16:44:51 --> Pagination Class Initialized
INFO - 2023-07-22 16:44:51 --> Form Validation Class Initialized
INFO - 2023-07-22 16:44:51 --> Controller Class Initialized
INFO - 2023-07-22 16:44:51 --> Model Class Initialized
DEBUG - 2023-07-22 16:44:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 16:45:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 16:45:41 --> Config Class Initialized
INFO - 2023-07-22 16:45:41 --> Hooks Class Initialized
DEBUG - 2023-07-22 16:45:41 --> UTF-8 Support Enabled
INFO - 2023-07-22 16:45:41 --> Utf8 Class Initialized
INFO - 2023-07-22 16:45:41 --> URI Class Initialized
DEBUG - 2023-07-22 16:45:41 --> No URI present. Default controller set.
INFO - 2023-07-22 16:45:41 --> Router Class Initialized
INFO - 2023-07-22 16:45:41 --> Output Class Initialized
INFO - 2023-07-22 16:45:41 --> Security Class Initialized
DEBUG - 2023-07-22 16:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 16:45:41 --> Input Class Initialized
INFO - 2023-07-22 16:45:41 --> Language Class Initialized
INFO - 2023-07-22 16:45:41 --> Loader Class Initialized
INFO - 2023-07-22 16:45:41 --> Helper loaded: url_helper
INFO - 2023-07-22 16:45:41 --> Helper loaded: file_helper
INFO - 2023-07-22 16:45:41 --> Helper loaded: html_helper
INFO - 2023-07-22 16:45:41 --> Helper loaded: text_helper
INFO - 2023-07-22 16:45:41 --> Helper loaded: form_helper
INFO - 2023-07-22 16:45:41 --> Helper loaded: lang_helper
INFO - 2023-07-22 16:45:41 --> Helper loaded: security_helper
INFO - 2023-07-22 16:45:41 --> Helper loaded: cookie_helper
INFO - 2023-07-22 16:45:41 --> Database Driver Class Initialized
INFO - 2023-07-22 16:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 16:45:41 --> Parser Class Initialized
INFO - 2023-07-22 16:45:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 16:45:41 --> Pagination Class Initialized
INFO - 2023-07-22 16:45:41 --> Form Validation Class Initialized
INFO - 2023-07-22 16:45:41 --> Controller Class Initialized
INFO - 2023-07-22 16:45:41 --> Model Class Initialized
DEBUG - 2023-07-22 16:45:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 16:47:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 16:47:34 --> Config Class Initialized
INFO - 2023-07-22 16:47:34 --> Hooks Class Initialized
DEBUG - 2023-07-22 16:47:34 --> UTF-8 Support Enabled
INFO - 2023-07-22 16:47:34 --> Utf8 Class Initialized
INFO - 2023-07-22 16:47:34 --> URI Class Initialized
DEBUG - 2023-07-22 16:47:34 --> No URI present. Default controller set.
INFO - 2023-07-22 16:47:34 --> Router Class Initialized
INFO - 2023-07-22 16:47:34 --> Output Class Initialized
INFO - 2023-07-22 16:47:34 --> Security Class Initialized
DEBUG - 2023-07-22 16:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 16:47:34 --> Input Class Initialized
INFO - 2023-07-22 16:47:34 --> Language Class Initialized
INFO - 2023-07-22 16:47:34 --> Loader Class Initialized
INFO - 2023-07-22 16:47:34 --> Helper loaded: url_helper
INFO - 2023-07-22 16:47:34 --> Helper loaded: file_helper
INFO - 2023-07-22 16:47:34 --> Helper loaded: html_helper
INFO - 2023-07-22 16:47:34 --> Helper loaded: text_helper
INFO - 2023-07-22 16:47:34 --> Helper loaded: form_helper
INFO - 2023-07-22 16:47:34 --> Helper loaded: lang_helper
INFO - 2023-07-22 16:47:34 --> Helper loaded: security_helper
INFO - 2023-07-22 16:47:34 --> Helper loaded: cookie_helper
INFO - 2023-07-22 16:47:34 --> Database Driver Class Initialized
INFO - 2023-07-22 16:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 16:47:34 --> Parser Class Initialized
INFO - 2023-07-22 16:47:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 16:47:34 --> Pagination Class Initialized
INFO - 2023-07-22 16:47:34 --> Form Validation Class Initialized
INFO - 2023-07-22 16:47:34 --> Controller Class Initialized
INFO - 2023-07-22 16:47:34 --> Model Class Initialized
DEBUG - 2023-07-22 16:47:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 16:54:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 16:54:41 --> Config Class Initialized
INFO - 2023-07-22 16:54:41 --> Hooks Class Initialized
DEBUG - 2023-07-22 16:54:41 --> UTF-8 Support Enabled
INFO - 2023-07-22 16:54:41 --> Utf8 Class Initialized
INFO - 2023-07-22 16:54:41 --> URI Class Initialized
DEBUG - 2023-07-22 16:54:41 --> No URI present. Default controller set.
INFO - 2023-07-22 16:54:41 --> Router Class Initialized
INFO - 2023-07-22 16:54:41 --> Output Class Initialized
INFO - 2023-07-22 16:54:41 --> Security Class Initialized
DEBUG - 2023-07-22 16:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 16:54:41 --> Input Class Initialized
INFO - 2023-07-22 16:54:41 --> Language Class Initialized
INFO - 2023-07-22 16:54:41 --> Loader Class Initialized
INFO - 2023-07-22 16:54:41 --> Helper loaded: url_helper
INFO - 2023-07-22 16:54:41 --> Helper loaded: file_helper
INFO - 2023-07-22 16:54:41 --> Helper loaded: html_helper
INFO - 2023-07-22 16:54:41 --> Helper loaded: text_helper
INFO - 2023-07-22 16:54:41 --> Helper loaded: form_helper
INFO - 2023-07-22 16:54:41 --> Helper loaded: lang_helper
INFO - 2023-07-22 16:54:41 --> Helper loaded: security_helper
INFO - 2023-07-22 16:54:41 --> Helper loaded: cookie_helper
INFO - 2023-07-22 16:54:41 --> Database Driver Class Initialized
INFO - 2023-07-22 16:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 16:54:41 --> Parser Class Initialized
INFO - 2023-07-22 16:54:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 16:54:41 --> Pagination Class Initialized
INFO - 2023-07-22 16:54:41 --> Form Validation Class Initialized
INFO - 2023-07-22 16:54:41 --> Controller Class Initialized
INFO - 2023-07-22 16:54:41 --> Model Class Initialized
DEBUG - 2023-07-22 16:54:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 16:56:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 16:56:35 --> Config Class Initialized
INFO - 2023-07-22 16:56:35 --> Hooks Class Initialized
DEBUG - 2023-07-22 16:56:35 --> UTF-8 Support Enabled
INFO - 2023-07-22 16:56:35 --> Utf8 Class Initialized
INFO - 2023-07-22 16:56:35 --> URI Class Initialized
DEBUG - 2023-07-22 16:56:35 --> No URI present. Default controller set.
INFO - 2023-07-22 16:56:35 --> Router Class Initialized
INFO - 2023-07-22 16:56:35 --> Output Class Initialized
INFO - 2023-07-22 16:56:35 --> Security Class Initialized
DEBUG - 2023-07-22 16:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 16:56:35 --> Input Class Initialized
INFO - 2023-07-22 16:56:35 --> Language Class Initialized
INFO - 2023-07-22 16:56:35 --> Loader Class Initialized
INFO - 2023-07-22 16:56:35 --> Helper loaded: url_helper
INFO - 2023-07-22 16:56:35 --> Helper loaded: file_helper
INFO - 2023-07-22 16:56:35 --> Helper loaded: html_helper
INFO - 2023-07-22 16:56:35 --> Helper loaded: text_helper
INFO - 2023-07-22 16:56:35 --> Helper loaded: form_helper
INFO - 2023-07-22 16:56:35 --> Helper loaded: lang_helper
INFO - 2023-07-22 16:56:35 --> Helper loaded: security_helper
INFO - 2023-07-22 16:56:35 --> Helper loaded: cookie_helper
INFO - 2023-07-22 16:56:35 --> Database Driver Class Initialized
INFO - 2023-07-22 16:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 16:56:35 --> Parser Class Initialized
INFO - 2023-07-22 16:56:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 16:56:35 --> Pagination Class Initialized
INFO - 2023-07-22 16:56:35 --> Form Validation Class Initialized
INFO - 2023-07-22 16:56:35 --> Controller Class Initialized
INFO - 2023-07-22 16:56:35 --> Model Class Initialized
DEBUG - 2023-07-22 16:56:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 16:56:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 16:56:44 --> Config Class Initialized
INFO - 2023-07-22 16:56:44 --> Hooks Class Initialized
DEBUG - 2023-07-22 16:56:44 --> UTF-8 Support Enabled
INFO - 2023-07-22 16:56:44 --> Utf8 Class Initialized
INFO - 2023-07-22 16:56:44 --> URI Class Initialized
DEBUG - 2023-07-22 16:56:44 --> No URI present. Default controller set.
INFO - 2023-07-22 16:56:44 --> Router Class Initialized
INFO - 2023-07-22 16:56:44 --> Output Class Initialized
INFO - 2023-07-22 16:56:44 --> Security Class Initialized
DEBUG - 2023-07-22 16:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 16:56:44 --> Input Class Initialized
INFO - 2023-07-22 16:56:44 --> Language Class Initialized
INFO - 2023-07-22 16:56:44 --> Loader Class Initialized
INFO - 2023-07-22 16:56:44 --> Helper loaded: url_helper
INFO - 2023-07-22 16:56:44 --> Helper loaded: file_helper
INFO - 2023-07-22 16:56:44 --> Helper loaded: html_helper
INFO - 2023-07-22 16:56:44 --> Helper loaded: text_helper
INFO - 2023-07-22 16:56:44 --> Helper loaded: form_helper
INFO - 2023-07-22 16:56:44 --> Helper loaded: lang_helper
INFO - 2023-07-22 16:56:44 --> Helper loaded: security_helper
INFO - 2023-07-22 16:56:44 --> Helper loaded: cookie_helper
INFO - 2023-07-22 16:56:44 --> Database Driver Class Initialized
INFO - 2023-07-22 16:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 16:56:44 --> Parser Class Initialized
INFO - 2023-07-22 16:56:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 16:56:44 --> Pagination Class Initialized
INFO - 2023-07-22 16:56:44 --> Form Validation Class Initialized
INFO - 2023-07-22 16:56:44 --> Controller Class Initialized
INFO - 2023-07-22 16:56:44 --> Model Class Initialized
DEBUG - 2023-07-22 16:56:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 17:13:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 17:13:48 --> Config Class Initialized
INFO - 2023-07-22 17:13:48 --> Hooks Class Initialized
DEBUG - 2023-07-22 17:13:48 --> UTF-8 Support Enabled
INFO - 2023-07-22 17:13:48 --> Utf8 Class Initialized
INFO - 2023-07-22 17:13:48 --> URI Class Initialized
DEBUG - 2023-07-22 17:13:48 --> No URI present. Default controller set.
INFO - 2023-07-22 17:13:48 --> Router Class Initialized
INFO - 2023-07-22 17:13:48 --> Output Class Initialized
INFO - 2023-07-22 17:13:48 --> Security Class Initialized
DEBUG - 2023-07-22 17:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 17:13:48 --> Input Class Initialized
INFO - 2023-07-22 17:13:48 --> Language Class Initialized
INFO - 2023-07-22 17:13:48 --> Loader Class Initialized
INFO - 2023-07-22 17:13:48 --> Helper loaded: url_helper
INFO - 2023-07-22 17:13:48 --> Helper loaded: file_helper
INFO - 2023-07-22 17:13:48 --> Helper loaded: html_helper
INFO - 2023-07-22 17:13:48 --> Helper loaded: text_helper
INFO - 2023-07-22 17:13:48 --> Helper loaded: form_helper
INFO - 2023-07-22 17:13:48 --> Helper loaded: lang_helper
INFO - 2023-07-22 17:13:48 --> Helper loaded: security_helper
INFO - 2023-07-22 17:13:48 --> Helper loaded: cookie_helper
INFO - 2023-07-22 17:13:48 --> Database Driver Class Initialized
INFO - 2023-07-22 17:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 17:13:48 --> Parser Class Initialized
INFO - 2023-07-22 17:13:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 17:13:48 --> Pagination Class Initialized
INFO - 2023-07-22 17:13:48 --> Form Validation Class Initialized
INFO - 2023-07-22 17:13:48 --> Controller Class Initialized
INFO - 2023-07-22 17:13:48 --> Model Class Initialized
DEBUG - 2023-07-22 17:13:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 19:14:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 19:14:12 --> Config Class Initialized
INFO - 2023-07-22 19:14:12 --> Hooks Class Initialized
DEBUG - 2023-07-22 19:14:12 --> UTF-8 Support Enabled
INFO - 2023-07-22 19:14:12 --> Utf8 Class Initialized
INFO - 2023-07-22 19:14:12 --> URI Class Initialized
DEBUG - 2023-07-22 19:14:12 --> No URI present. Default controller set.
INFO - 2023-07-22 19:14:12 --> Router Class Initialized
INFO - 2023-07-22 19:14:12 --> Output Class Initialized
INFO - 2023-07-22 19:14:12 --> Security Class Initialized
DEBUG - 2023-07-22 19:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 19:14:12 --> Input Class Initialized
INFO - 2023-07-22 19:14:12 --> Language Class Initialized
INFO - 2023-07-22 19:14:12 --> Loader Class Initialized
INFO - 2023-07-22 19:14:12 --> Helper loaded: url_helper
INFO - 2023-07-22 19:14:12 --> Helper loaded: file_helper
INFO - 2023-07-22 19:14:12 --> Helper loaded: html_helper
INFO - 2023-07-22 19:14:12 --> Helper loaded: text_helper
INFO - 2023-07-22 19:14:12 --> Helper loaded: form_helper
INFO - 2023-07-22 19:14:12 --> Helper loaded: lang_helper
INFO - 2023-07-22 19:14:12 --> Helper loaded: security_helper
INFO - 2023-07-22 19:14:12 --> Helper loaded: cookie_helper
INFO - 2023-07-22 19:14:12 --> Database Driver Class Initialized
INFO - 2023-07-22 19:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 19:14:12 --> Parser Class Initialized
INFO - 2023-07-22 19:14:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 19:14:12 --> Pagination Class Initialized
INFO - 2023-07-22 19:14:12 --> Form Validation Class Initialized
INFO - 2023-07-22 19:14:12 --> Controller Class Initialized
INFO - 2023-07-22 19:14:12 --> Model Class Initialized
DEBUG - 2023-07-22 19:14:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 19:43:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 19:43:41 --> Config Class Initialized
INFO - 2023-07-22 19:43:41 --> Hooks Class Initialized
DEBUG - 2023-07-22 19:43:41 --> UTF-8 Support Enabled
INFO - 2023-07-22 19:43:41 --> Utf8 Class Initialized
INFO - 2023-07-22 19:43:41 --> URI Class Initialized
DEBUG - 2023-07-22 19:43:41 --> No URI present. Default controller set.
INFO - 2023-07-22 19:43:41 --> Router Class Initialized
INFO - 2023-07-22 19:43:41 --> Output Class Initialized
INFO - 2023-07-22 19:43:41 --> Security Class Initialized
DEBUG - 2023-07-22 19:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 19:43:41 --> Input Class Initialized
INFO - 2023-07-22 19:43:41 --> Language Class Initialized
INFO - 2023-07-22 19:43:41 --> Loader Class Initialized
INFO - 2023-07-22 19:43:41 --> Helper loaded: url_helper
INFO - 2023-07-22 19:43:41 --> Helper loaded: file_helper
INFO - 2023-07-22 19:43:41 --> Helper loaded: html_helper
INFO - 2023-07-22 19:43:41 --> Helper loaded: text_helper
INFO - 2023-07-22 19:43:41 --> Helper loaded: form_helper
INFO - 2023-07-22 19:43:41 --> Helper loaded: lang_helper
INFO - 2023-07-22 19:43:41 --> Helper loaded: security_helper
INFO - 2023-07-22 19:43:41 --> Helper loaded: cookie_helper
INFO - 2023-07-22 19:43:41 --> Database Driver Class Initialized
INFO - 2023-07-22 19:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 19:43:41 --> Parser Class Initialized
INFO - 2023-07-22 19:43:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 19:43:41 --> Pagination Class Initialized
INFO - 2023-07-22 19:43:41 --> Form Validation Class Initialized
INFO - 2023-07-22 19:43:41 --> Controller Class Initialized
INFO - 2023-07-22 19:43:41 --> Model Class Initialized
DEBUG - 2023-07-22 19:43:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 20:08:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 20:08:53 --> Config Class Initialized
INFO - 2023-07-22 20:08:53 --> Hooks Class Initialized
DEBUG - 2023-07-22 20:08:53 --> UTF-8 Support Enabled
INFO - 2023-07-22 20:08:53 --> Utf8 Class Initialized
INFO - 2023-07-22 20:08:53 --> URI Class Initialized
DEBUG - 2023-07-22 20:08:53 --> No URI present. Default controller set.
INFO - 2023-07-22 20:08:53 --> Router Class Initialized
INFO - 2023-07-22 20:08:53 --> Output Class Initialized
INFO - 2023-07-22 20:08:53 --> Security Class Initialized
DEBUG - 2023-07-22 20:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 20:08:53 --> Input Class Initialized
INFO - 2023-07-22 20:08:53 --> Language Class Initialized
INFO - 2023-07-22 20:08:53 --> Loader Class Initialized
INFO - 2023-07-22 20:08:53 --> Helper loaded: url_helper
INFO - 2023-07-22 20:08:53 --> Helper loaded: file_helper
INFO - 2023-07-22 20:08:53 --> Helper loaded: html_helper
INFO - 2023-07-22 20:08:53 --> Helper loaded: text_helper
INFO - 2023-07-22 20:08:53 --> Helper loaded: form_helper
INFO - 2023-07-22 20:08:53 --> Helper loaded: lang_helper
INFO - 2023-07-22 20:08:53 --> Helper loaded: security_helper
INFO - 2023-07-22 20:08:53 --> Helper loaded: cookie_helper
INFO - 2023-07-22 20:08:53 --> Database Driver Class Initialized
INFO - 2023-07-22 20:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 20:08:53 --> Parser Class Initialized
INFO - 2023-07-22 20:08:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 20:08:53 --> Pagination Class Initialized
INFO - 2023-07-22 20:08:53 --> Form Validation Class Initialized
INFO - 2023-07-22 20:08:53 --> Controller Class Initialized
INFO - 2023-07-22 20:08:53 --> Model Class Initialized
DEBUG - 2023-07-22 20:08:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 20:09:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 20:09:10 --> Config Class Initialized
INFO - 2023-07-22 20:09:10 --> Hooks Class Initialized
DEBUG - 2023-07-22 20:09:10 --> UTF-8 Support Enabled
INFO - 2023-07-22 20:09:10 --> Utf8 Class Initialized
INFO - 2023-07-22 20:09:10 --> URI Class Initialized
DEBUG - 2023-07-22 20:09:10 --> No URI present. Default controller set.
INFO - 2023-07-22 20:09:10 --> Router Class Initialized
INFO - 2023-07-22 20:09:10 --> Output Class Initialized
INFO - 2023-07-22 20:09:10 --> Security Class Initialized
DEBUG - 2023-07-22 20:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 20:09:10 --> Input Class Initialized
INFO - 2023-07-22 20:09:10 --> Language Class Initialized
INFO - 2023-07-22 20:09:10 --> Loader Class Initialized
INFO - 2023-07-22 20:09:10 --> Helper loaded: url_helper
INFO - 2023-07-22 20:09:10 --> Helper loaded: file_helper
INFO - 2023-07-22 20:09:10 --> Helper loaded: html_helper
INFO - 2023-07-22 20:09:10 --> Helper loaded: text_helper
INFO - 2023-07-22 20:09:10 --> Helper loaded: form_helper
INFO - 2023-07-22 20:09:10 --> Helper loaded: lang_helper
INFO - 2023-07-22 20:09:10 --> Helper loaded: security_helper
INFO - 2023-07-22 20:09:10 --> Helper loaded: cookie_helper
INFO - 2023-07-22 20:09:10 --> Database Driver Class Initialized
INFO - 2023-07-22 20:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 20:09:10 --> Parser Class Initialized
INFO - 2023-07-22 20:09:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 20:09:10 --> Pagination Class Initialized
INFO - 2023-07-22 20:09:10 --> Form Validation Class Initialized
INFO - 2023-07-22 20:09:10 --> Controller Class Initialized
INFO - 2023-07-22 20:09:10 --> Model Class Initialized
DEBUG - 2023-07-22 20:09:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 20:11:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 20:11:26 --> Config Class Initialized
INFO - 2023-07-22 20:11:26 --> Hooks Class Initialized
DEBUG - 2023-07-22 20:11:26 --> UTF-8 Support Enabled
INFO - 2023-07-22 20:11:26 --> Utf8 Class Initialized
INFO - 2023-07-22 20:11:26 --> URI Class Initialized
DEBUG - 2023-07-22 20:11:26 --> No URI present. Default controller set.
INFO - 2023-07-22 20:11:26 --> Router Class Initialized
INFO - 2023-07-22 20:11:26 --> Output Class Initialized
INFO - 2023-07-22 20:11:26 --> Security Class Initialized
DEBUG - 2023-07-22 20:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 20:11:26 --> Input Class Initialized
INFO - 2023-07-22 20:11:26 --> Language Class Initialized
INFO - 2023-07-22 20:11:26 --> Loader Class Initialized
INFO - 2023-07-22 20:11:26 --> Helper loaded: url_helper
INFO - 2023-07-22 20:11:26 --> Helper loaded: file_helper
INFO - 2023-07-22 20:11:26 --> Helper loaded: html_helper
INFO - 2023-07-22 20:11:26 --> Helper loaded: text_helper
INFO - 2023-07-22 20:11:26 --> Helper loaded: form_helper
INFO - 2023-07-22 20:11:26 --> Helper loaded: lang_helper
INFO - 2023-07-22 20:11:26 --> Helper loaded: security_helper
INFO - 2023-07-22 20:11:26 --> Helper loaded: cookie_helper
INFO - 2023-07-22 20:11:26 --> Database Driver Class Initialized
INFO - 2023-07-22 20:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 20:11:26 --> Parser Class Initialized
INFO - 2023-07-22 20:11:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 20:11:26 --> Pagination Class Initialized
INFO - 2023-07-22 20:11:26 --> Form Validation Class Initialized
INFO - 2023-07-22 20:11:26 --> Controller Class Initialized
INFO - 2023-07-22 20:11:26 --> Model Class Initialized
DEBUG - 2023-07-22 20:11:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 20:11:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 20:11:40 --> Config Class Initialized
INFO - 2023-07-22 20:11:40 --> Hooks Class Initialized
DEBUG - 2023-07-22 20:11:40 --> UTF-8 Support Enabled
INFO - 2023-07-22 20:11:40 --> Utf8 Class Initialized
INFO - 2023-07-22 20:11:40 --> URI Class Initialized
DEBUG - 2023-07-22 20:11:40 --> No URI present. Default controller set.
INFO - 2023-07-22 20:11:40 --> Router Class Initialized
INFO - 2023-07-22 20:11:40 --> Output Class Initialized
INFO - 2023-07-22 20:11:40 --> Security Class Initialized
DEBUG - 2023-07-22 20:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 20:11:40 --> Input Class Initialized
INFO - 2023-07-22 20:11:40 --> Language Class Initialized
INFO - 2023-07-22 20:11:40 --> Loader Class Initialized
INFO - 2023-07-22 20:11:40 --> Helper loaded: url_helper
INFO - 2023-07-22 20:11:40 --> Helper loaded: file_helper
INFO - 2023-07-22 20:11:40 --> Helper loaded: html_helper
INFO - 2023-07-22 20:11:40 --> Helper loaded: text_helper
INFO - 2023-07-22 20:11:40 --> Helper loaded: form_helper
INFO - 2023-07-22 20:11:40 --> Helper loaded: lang_helper
INFO - 2023-07-22 20:11:40 --> Helper loaded: security_helper
INFO - 2023-07-22 20:11:40 --> Helper loaded: cookie_helper
INFO - 2023-07-22 20:11:40 --> Database Driver Class Initialized
INFO - 2023-07-22 20:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 20:11:40 --> Parser Class Initialized
INFO - 2023-07-22 20:11:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 20:11:40 --> Pagination Class Initialized
INFO - 2023-07-22 20:11:40 --> Form Validation Class Initialized
INFO - 2023-07-22 20:11:40 --> Controller Class Initialized
INFO - 2023-07-22 20:11:40 --> Model Class Initialized
DEBUG - 2023-07-22 20:11:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-07-22 20:42:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-07-22 20:42:13 --> Config Class Initialized
INFO - 2023-07-22 20:42:13 --> Hooks Class Initialized
DEBUG - 2023-07-22 20:42:13 --> UTF-8 Support Enabled
INFO - 2023-07-22 20:42:13 --> Utf8 Class Initialized
INFO - 2023-07-22 20:42:13 --> URI Class Initialized
DEBUG - 2023-07-22 20:42:13 --> No URI present. Default controller set.
INFO - 2023-07-22 20:42:13 --> Router Class Initialized
INFO - 2023-07-22 20:42:13 --> Output Class Initialized
INFO - 2023-07-22 20:42:13 --> Security Class Initialized
DEBUG - 2023-07-22 20:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-22 20:42:13 --> Input Class Initialized
INFO - 2023-07-22 20:42:13 --> Language Class Initialized
INFO - 2023-07-22 20:42:13 --> Loader Class Initialized
INFO - 2023-07-22 20:42:13 --> Helper loaded: url_helper
INFO - 2023-07-22 20:42:13 --> Helper loaded: file_helper
INFO - 2023-07-22 20:42:13 --> Helper loaded: html_helper
INFO - 2023-07-22 20:42:13 --> Helper loaded: text_helper
INFO - 2023-07-22 20:42:13 --> Helper loaded: form_helper
INFO - 2023-07-22 20:42:13 --> Helper loaded: lang_helper
INFO - 2023-07-22 20:42:13 --> Helper loaded: security_helper
INFO - 2023-07-22 20:42:13 --> Helper loaded: cookie_helper
INFO - 2023-07-22 20:42:13 --> Database Driver Class Initialized
INFO - 2023-07-22 20:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-22 20:42:13 --> Parser Class Initialized
INFO - 2023-07-22 20:42:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-07-22 20:42:13 --> Pagination Class Initialized
INFO - 2023-07-22 20:42:13 --> Form Validation Class Initialized
INFO - 2023-07-22 20:42:13 --> Controller Class Initialized
INFO - 2023-07-22 20:42:13 --> Model Class Initialized
DEBUG - 2023-07-22 20:42:13 --> Session class already loaded. Second attempt ignored.
