<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-16 02:30:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-16 02:30:18 --> Config Class Initialized
INFO - 2023-06-16 02:30:18 --> Hooks Class Initialized
DEBUG - 2023-06-16 02:30:18 --> UTF-8 Support Enabled
INFO - 2023-06-16 02:30:18 --> Utf8 Class Initialized
INFO - 2023-06-16 02:30:18 --> URI Class Initialized
DEBUG - 2023-06-16 02:30:18 --> No URI present. Default controller set.
INFO - 2023-06-16 02:30:18 --> Router Class Initialized
INFO - 2023-06-16 02:30:18 --> Output Class Initialized
INFO - 2023-06-16 02:30:18 --> Security Class Initialized
DEBUG - 2023-06-16 02:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-16 02:30:18 --> Input Class Initialized
INFO - 2023-06-16 02:30:18 --> Language Class Initialized
INFO - 2023-06-16 02:30:18 --> Loader Class Initialized
INFO - 2023-06-16 02:30:18 --> Helper loaded: url_helper
INFO - 2023-06-16 02:30:18 --> Helper loaded: file_helper
INFO - 2023-06-16 02:30:18 --> Helper loaded: html_helper
INFO - 2023-06-16 02:30:18 --> Helper loaded: text_helper
INFO - 2023-06-16 02:30:18 --> Helper loaded: form_helper
INFO - 2023-06-16 02:30:18 --> Helper loaded: lang_helper
INFO - 2023-06-16 02:30:18 --> Helper loaded: security_helper
INFO - 2023-06-16 02:30:18 --> Helper loaded: cookie_helper
INFO - 2023-06-16 02:30:18 --> Database Driver Class Initialized
INFO - 2023-06-16 02:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-16 02:30:18 --> Parser Class Initialized
INFO - 2023-06-16 02:30:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-16 02:30:18 --> Pagination Class Initialized
INFO - 2023-06-16 02:30:18 --> Form Validation Class Initialized
INFO - 2023-06-16 02:30:18 --> Controller Class Initialized
INFO - 2023-06-16 02:30:18 --> Model Class Initialized
DEBUG - 2023-06-16 02:30:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-16 02:30:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-16 02:30:19 --> Config Class Initialized
INFO - 2023-06-16 02:30:19 --> Hooks Class Initialized
DEBUG - 2023-06-16 02:30:19 --> UTF-8 Support Enabled
INFO - 2023-06-16 02:30:19 --> Utf8 Class Initialized
INFO - 2023-06-16 02:30:19 --> URI Class Initialized
INFO - 2023-06-16 02:30:19 --> Router Class Initialized
INFO - 2023-06-16 02:30:19 --> Output Class Initialized
INFO - 2023-06-16 02:30:19 --> Security Class Initialized
DEBUG - 2023-06-16 02:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-16 02:30:19 --> Input Class Initialized
INFO - 2023-06-16 02:30:19 --> Language Class Initialized
INFO - 2023-06-16 02:30:19 --> Loader Class Initialized
INFO - 2023-06-16 02:30:19 --> Helper loaded: url_helper
INFO - 2023-06-16 02:30:19 --> Helper loaded: file_helper
INFO - 2023-06-16 02:30:19 --> Helper loaded: html_helper
INFO - 2023-06-16 02:30:19 --> Helper loaded: text_helper
INFO - 2023-06-16 02:30:19 --> Helper loaded: form_helper
INFO - 2023-06-16 02:30:19 --> Helper loaded: lang_helper
INFO - 2023-06-16 02:30:19 --> Helper loaded: security_helper
INFO - 2023-06-16 02:30:19 --> Helper loaded: cookie_helper
INFO - 2023-06-16 02:30:20 --> Database Driver Class Initialized
INFO - 2023-06-16 02:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-16 02:30:20 --> Parser Class Initialized
INFO - 2023-06-16 02:30:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-16 02:30:20 --> Pagination Class Initialized
INFO - 2023-06-16 02:30:20 --> Form Validation Class Initialized
INFO - 2023-06-16 02:30:20 --> Controller Class Initialized
INFO - 2023-06-16 02:30:20 --> Model Class Initialized
DEBUG - 2023-06-16 02:30:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-16 02:30:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-16 02:30:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-16 02:30:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-16 02:30:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-16 02:30:20 --> Model Class Initialized
INFO - 2023-06-16 02:30:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-16 02:30:20 --> Final output sent to browser
DEBUG - 2023-06-16 02:30:20 --> Total execution time: 0.0324
ERROR - 2023-06-16 05:20:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-16 05:20:07 --> Config Class Initialized
INFO - 2023-06-16 05:20:07 --> Hooks Class Initialized
DEBUG - 2023-06-16 05:20:07 --> UTF-8 Support Enabled
INFO - 2023-06-16 05:20:07 --> Utf8 Class Initialized
INFO - 2023-06-16 05:20:07 --> URI Class Initialized
DEBUG - 2023-06-16 05:20:07 --> No URI present. Default controller set.
INFO - 2023-06-16 05:20:07 --> Router Class Initialized
INFO - 2023-06-16 05:20:07 --> Output Class Initialized
INFO - 2023-06-16 05:20:07 --> Security Class Initialized
DEBUG - 2023-06-16 05:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-16 05:20:07 --> Input Class Initialized
INFO - 2023-06-16 05:20:07 --> Language Class Initialized
INFO - 2023-06-16 05:20:07 --> Loader Class Initialized
INFO - 2023-06-16 05:20:07 --> Helper loaded: url_helper
INFO - 2023-06-16 05:20:07 --> Helper loaded: file_helper
INFO - 2023-06-16 05:20:07 --> Helper loaded: html_helper
INFO - 2023-06-16 05:20:07 --> Helper loaded: text_helper
INFO - 2023-06-16 05:20:07 --> Helper loaded: form_helper
INFO - 2023-06-16 05:20:07 --> Helper loaded: lang_helper
INFO - 2023-06-16 05:20:07 --> Helper loaded: security_helper
INFO - 2023-06-16 05:20:07 --> Helper loaded: cookie_helper
INFO - 2023-06-16 05:20:07 --> Database Driver Class Initialized
INFO - 2023-06-16 05:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-16 05:20:07 --> Parser Class Initialized
INFO - 2023-06-16 05:20:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-16 05:20:07 --> Pagination Class Initialized
INFO - 2023-06-16 05:20:07 --> Form Validation Class Initialized
INFO - 2023-06-16 05:20:07 --> Controller Class Initialized
INFO - 2023-06-16 05:20:07 --> Model Class Initialized
DEBUG - 2023-06-16 05:20:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-16 05:20:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-16 05:20:07 --> Config Class Initialized
INFO - 2023-06-16 05:20:07 --> Hooks Class Initialized
DEBUG - 2023-06-16 05:20:07 --> UTF-8 Support Enabled
INFO - 2023-06-16 05:20:07 --> Utf8 Class Initialized
INFO - 2023-06-16 05:20:07 --> URI Class Initialized
INFO - 2023-06-16 05:20:07 --> Router Class Initialized
INFO - 2023-06-16 05:20:07 --> Output Class Initialized
INFO - 2023-06-16 05:20:07 --> Security Class Initialized
DEBUG - 2023-06-16 05:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-16 05:20:07 --> Input Class Initialized
INFO - 2023-06-16 05:20:07 --> Language Class Initialized
INFO - 2023-06-16 05:20:07 --> Loader Class Initialized
INFO - 2023-06-16 05:20:07 --> Helper loaded: url_helper
INFO - 2023-06-16 05:20:07 --> Helper loaded: file_helper
INFO - 2023-06-16 05:20:07 --> Helper loaded: html_helper
INFO - 2023-06-16 05:20:07 --> Helper loaded: text_helper
INFO - 2023-06-16 05:20:07 --> Helper loaded: form_helper
INFO - 2023-06-16 05:20:07 --> Helper loaded: lang_helper
INFO - 2023-06-16 05:20:07 --> Helper loaded: security_helper
INFO - 2023-06-16 05:20:07 --> Helper loaded: cookie_helper
INFO - 2023-06-16 05:20:07 --> Database Driver Class Initialized
INFO - 2023-06-16 05:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-16 05:20:07 --> Parser Class Initialized
INFO - 2023-06-16 05:20:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-16 05:20:07 --> Pagination Class Initialized
INFO - 2023-06-16 05:20:07 --> Form Validation Class Initialized
INFO - 2023-06-16 05:20:07 --> Controller Class Initialized
INFO - 2023-06-16 05:20:07 --> Model Class Initialized
DEBUG - 2023-06-16 05:20:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-16 05:20:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-16 05:20:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-16 05:20:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-16 05:20:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-16 05:20:07 --> Model Class Initialized
INFO - 2023-06-16 05:20:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-16 05:20:07 --> Final output sent to browser
DEBUG - 2023-06-16 05:20:07 --> Total execution time: 0.0386
ERROR - 2023-06-16 05:20:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-16 05:20:17 --> Config Class Initialized
INFO - 2023-06-16 05:20:17 --> Hooks Class Initialized
DEBUG - 2023-06-16 05:20:17 --> UTF-8 Support Enabled
INFO - 2023-06-16 05:20:17 --> Utf8 Class Initialized
INFO - 2023-06-16 05:20:17 --> URI Class Initialized
DEBUG - 2023-06-16 05:20:17 --> No URI present. Default controller set.
INFO - 2023-06-16 05:20:17 --> Router Class Initialized
INFO - 2023-06-16 05:20:17 --> Output Class Initialized
INFO - 2023-06-16 05:20:17 --> Security Class Initialized
DEBUG - 2023-06-16 05:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-16 05:20:17 --> Input Class Initialized
INFO - 2023-06-16 05:20:17 --> Language Class Initialized
INFO - 2023-06-16 05:20:17 --> Loader Class Initialized
INFO - 2023-06-16 05:20:17 --> Helper loaded: url_helper
INFO - 2023-06-16 05:20:17 --> Helper loaded: file_helper
INFO - 2023-06-16 05:20:17 --> Helper loaded: html_helper
INFO - 2023-06-16 05:20:17 --> Helper loaded: text_helper
INFO - 2023-06-16 05:20:17 --> Helper loaded: form_helper
INFO - 2023-06-16 05:20:17 --> Helper loaded: lang_helper
INFO - 2023-06-16 05:20:17 --> Helper loaded: security_helper
INFO - 2023-06-16 05:20:17 --> Helper loaded: cookie_helper
INFO - 2023-06-16 05:20:17 --> Database Driver Class Initialized
INFO - 2023-06-16 05:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-16 05:20:17 --> Parser Class Initialized
INFO - 2023-06-16 05:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-16 05:20:17 --> Pagination Class Initialized
INFO - 2023-06-16 05:20:17 --> Form Validation Class Initialized
INFO - 2023-06-16 05:20:17 --> Controller Class Initialized
INFO - 2023-06-16 05:20:17 --> Model Class Initialized
DEBUG - 2023-06-16 05:20:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-16 05:20:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-16 05:20:17 --> Config Class Initialized
INFO - 2023-06-16 05:20:17 --> Hooks Class Initialized
DEBUG - 2023-06-16 05:20:17 --> UTF-8 Support Enabled
INFO - 2023-06-16 05:20:17 --> Utf8 Class Initialized
INFO - 2023-06-16 05:20:17 --> URI Class Initialized
INFO - 2023-06-16 05:20:17 --> Router Class Initialized
INFO - 2023-06-16 05:20:17 --> Output Class Initialized
INFO - 2023-06-16 05:20:17 --> Security Class Initialized
DEBUG - 2023-06-16 05:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-16 05:20:17 --> Input Class Initialized
INFO - 2023-06-16 05:20:17 --> Language Class Initialized
INFO - 2023-06-16 05:20:17 --> Loader Class Initialized
INFO - 2023-06-16 05:20:17 --> Helper loaded: url_helper
INFO - 2023-06-16 05:20:17 --> Helper loaded: file_helper
INFO - 2023-06-16 05:20:17 --> Helper loaded: html_helper
INFO - 2023-06-16 05:20:17 --> Helper loaded: text_helper
INFO - 2023-06-16 05:20:17 --> Helper loaded: form_helper
INFO - 2023-06-16 05:20:17 --> Helper loaded: lang_helper
INFO - 2023-06-16 05:20:17 --> Helper loaded: security_helper
INFO - 2023-06-16 05:20:17 --> Helper loaded: cookie_helper
INFO - 2023-06-16 05:20:17 --> Database Driver Class Initialized
INFO - 2023-06-16 05:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-16 05:20:17 --> Parser Class Initialized
INFO - 2023-06-16 05:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-16 05:20:17 --> Pagination Class Initialized
INFO - 2023-06-16 05:20:17 --> Form Validation Class Initialized
INFO - 2023-06-16 05:20:17 --> Controller Class Initialized
INFO - 2023-06-16 05:20:17 --> Model Class Initialized
DEBUG - 2023-06-16 05:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-16 05:20:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-16 05:20:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-16 05:20:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-16 05:20:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-16 05:20:17 --> Model Class Initialized
INFO - 2023-06-16 05:20:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-16 05:20:17 --> Final output sent to browser
DEBUG - 2023-06-16 05:20:17 --> Total execution time: 0.0284
ERROR - 2023-06-16 06:05:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-16 06:05:36 --> Config Class Initialized
INFO - 2023-06-16 06:05:36 --> Hooks Class Initialized
DEBUG - 2023-06-16 06:05:36 --> UTF-8 Support Enabled
INFO - 2023-06-16 06:05:36 --> Utf8 Class Initialized
INFO - 2023-06-16 06:05:36 --> URI Class Initialized
DEBUG - 2023-06-16 06:05:36 --> No URI present. Default controller set.
INFO - 2023-06-16 06:05:36 --> Router Class Initialized
INFO - 2023-06-16 06:05:36 --> Output Class Initialized
INFO - 2023-06-16 06:05:36 --> Security Class Initialized
DEBUG - 2023-06-16 06:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-16 06:05:36 --> Input Class Initialized
INFO - 2023-06-16 06:05:36 --> Language Class Initialized
INFO - 2023-06-16 06:05:36 --> Loader Class Initialized
INFO - 2023-06-16 06:05:36 --> Helper loaded: url_helper
INFO - 2023-06-16 06:05:36 --> Helper loaded: file_helper
INFO - 2023-06-16 06:05:36 --> Helper loaded: html_helper
INFO - 2023-06-16 06:05:36 --> Helper loaded: text_helper
INFO - 2023-06-16 06:05:36 --> Helper loaded: form_helper
INFO - 2023-06-16 06:05:36 --> Helper loaded: lang_helper
INFO - 2023-06-16 06:05:36 --> Helper loaded: security_helper
INFO - 2023-06-16 06:05:36 --> Helper loaded: cookie_helper
INFO - 2023-06-16 06:05:36 --> Database Driver Class Initialized
INFO - 2023-06-16 06:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-16 06:05:36 --> Parser Class Initialized
INFO - 2023-06-16 06:05:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-16 06:05:36 --> Pagination Class Initialized
INFO - 2023-06-16 06:05:36 --> Form Validation Class Initialized
INFO - 2023-06-16 06:05:36 --> Controller Class Initialized
INFO - 2023-06-16 06:05:36 --> Model Class Initialized
DEBUG - 2023-06-16 06:05:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-16 06:05:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-16 06:05:38 --> Config Class Initialized
INFO - 2023-06-16 06:05:38 --> Hooks Class Initialized
DEBUG - 2023-06-16 06:05:38 --> UTF-8 Support Enabled
INFO - 2023-06-16 06:05:38 --> Utf8 Class Initialized
INFO - 2023-06-16 06:05:38 --> URI Class Initialized
INFO - 2023-06-16 06:05:38 --> Router Class Initialized
INFO - 2023-06-16 06:05:38 --> Output Class Initialized
INFO - 2023-06-16 06:05:38 --> Security Class Initialized
DEBUG - 2023-06-16 06:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-16 06:05:38 --> Input Class Initialized
INFO - 2023-06-16 06:05:38 --> Language Class Initialized
INFO - 2023-06-16 06:05:38 --> Loader Class Initialized
INFO - 2023-06-16 06:05:38 --> Helper loaded: url_helper
INFO - 2023-06-16 06:05:38 --> Helper loaded: file_helper
INFO - 2023-06-16 06:05:38 --> Helper loaded: html_helper
INFO - 2023-06-16 06:05:38 --> Helper loaded: text_helper
INFO - 2023-06-16 06:05:38 --> Helper loaded: form_helper
INFO - 2023-06-16 06:05:38 --> Helper loaded: lang_helper
INFO - 2023-06-16 06:05:38 --> Helper loaded: security_helper
INFO - 2023-06-16 06:05:38 --> Helper loaded: cookie_helper
INFO - 2023-06-16 06:05:38 --> Database Driver Class Initialized
INFO - 2023-06-16 06:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-16 06:05:38 --> Parser Class Initialized
INFO - 2023-06-16 06:05:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-16 06:05:38 --> Pagination Class Initialized
INFO - 2023-06-16 06:05:38 --> Form Validation Class Initialized
INFO - 2023-06-16 06:05:38 --> Controller Class Initialized
INFO - 2023-06-16 06:05:38 --> Model Class Initialized
DEBUG - 2023-06-16 06:05:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-16 06:05:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-16 06:05:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-16 06:05:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-16 06:05:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-16 06:05:38 --> Model Class Initialized
INFO - 2023-06-16 06:05:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-16 06:05:38 --> Final output sent to browser
DEBUG - 2023-06-16 06:05:38 --> Total execution time: 0.0309
ERROR - 2023-06-16 13:37:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-16 13:37:53 --> Config Class Initialized
INFO - 2023-06-16 13:37:53 --> Hooks Class Initialized
DEBUG - 2023-06-16 13:37:53 --> UTF-8 Support Enabled
INFO - 2023-06-16 13:37:53 --> Utf8 Class Initialized
INFO - 2023-06-16 13:37:53 --> URI Class Initialized
DEBUG - 2023-06-16 13:37:53 --> No URI present. Default controller set.
INFO - 2023-06-16 13:37:53 --> Router Class Initialized
INFO - 2023-06-16 13:37:53 --> Output Class Initialized
INFO - 2023-06-16 13:37:53 --> Security Class Initialized
DEBUG - 2023-06-16 13:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-16 13:37:53 --> Input Class Initialized
INFO - 2023-06-16 13:37:53 --> Language Class Initialized
INFO - 2023-06-16 13:37:53 --> Loader Class Initialized
INFO - 2023-06-16 13:37:53 --> Helper loaded: url_helper
INFO - 2023-06-16 13:37:53 --> Helper loaded: file_helper
INFO - 2023-06-16 13:37:53 --> Helper loaded: html_helper
INFO - 2023-06-16 13:37:53 --> Helper loaded: text_helper
INFO - 2023-06-16 13:37:53 --> Helper loaded: form_helper
INFO - 2023-06-16 13:37:53 --> Helper loaded: lang_helper
INFO - 2023-06-16 13:37:53 --> Helper loaded: security_helper
INFO - 2023-06-16 13:37:53 --> Helper loaded: cookie_helper
INFO - 2023-06-16 13:37:53 --> Database Driver Class Initialized
INFO - 2023-06-16 13:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-16 13:37:53 --> Parser Class Initialized
INFO - 2023-06-16 13:37:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-16 13:37:53 --> Pagination Class Initialized
INFO - 2023-06-16 13:37:53 --> Form Validation Class Initialized
INFO - 2023-06-16 13:37:53 --> Controller Class Initialized
INFO - 2023-06-16 13:37:53 --> Model Class Initialized
DEBUG - 2023-06-16 13:37:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-16 13:37:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-16 13:37:53 --> Config Class Initialized
INFO - 2023-06-16 13:37:53 --> Hooks Class Initialized
DEBUG - 2023-06-16 13:37:53 --> UTF-8 Support Enabled
INFO - 2023-06-16 13:37:53 --> Utf8 Class Initialized
INFO - 2023-06-16 13:37:53 --> URI Class Initialized
INFO - 2023-06-16 13:37:53 --> Router Class Initialized
INFO - 2023-06-16 13:37:53 --> Output Class Initialized
INFO - 2023-06-16 13:37:53 --> Security Class Initialized
DEBUG - 2023-06-16 13:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-16 13:37:53 --> Input Class Initialized
INFO - 2023-06-16 13:37:53 --> Language Class Initialized
INFO - 2023-06-16 13:37:53 --> Loader Class Initialized
INFO - 2023-06-16 13:37:53 --> Helper loaded: url_helper
INFO - 2023-06-16 13:37:53 --> Helper loaded: file_helper
INFO - 2023-06-16 13:37:53 --> Helper loaded: html_helper
INFO - 2023-06-16 13:37:53 --> Helper loaded: text_helper
INFO - 2023-06-16 13:37:53 --> Helper loaded: form_helper
INFO - 2023-06-16 13:37:53 --> Helper loaded: lang_helper
INFO - 2023-06-16 13:37:53 --> Helper loaded: security_helper
INFO - 2023-06-16 13:37:53 --> Helper loaded: cookie_helper
INFO - 2023-06-16 13:37:53 --> Database Driver Class Initialized
INFO - 2023-06-16 13:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-16 13:37:53 --> Parser Class Initialized
INFO - 2023-06-16 13:37:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-16 13:37:53 --> Pagination Class Initialized
INFO - 2023-06-16 13:37:53 --> Form Validation Class Initialized
INFO - 2023-06-16 13:37:53 --> Controller Class Initialized
INFO - 2023-06-16 13:37:53 --> Model Class Initialized
DEBUG - 2023-06-16 13:37:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-16 13:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-16 13:37:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-16 13:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-16 13:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-16 13:37:53 --> Model Class Initialized
INFO - 2023-06-16 13:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-16 13:37:53 --> Final output sent to browser
DEBUG - 2023-06-16 13:37:53 --> Total execution time: 0.0348
ERROR - 2023-06-16 16:24:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-16 16:24:53 --> Config Class Initialized
INFO - 2023-06-16 16:24:53 --> Hooks Class Initialized
DEBUG - 2023-06-16 16:24:53 --> UTF-8 Support Enabled
INFO - 2023-06-16 16:24:53 --> Utf8 Class Initialized
INFO - 2023-06-16 16:24:53 --> URI Class Initialized
DEBUG - 2023-06-16 16:24:53 --> No URI present. Default controller set.
INFO - 2023-06-16 16:24:53 --> Router Class Initialized
INFO - 2023-06-16 16:24:53 --> Output Class Initialized
INFO - 2023-06-16 16:24:53 --> Security Class Initialized
DEBUG - 2023-06-16 16:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-16 16:24:53 --> Input Class Initialized
INFO - 2023-06-16 16:24:53 --> Language Class Initialized
INFO - 2023-06-16 16:24:53 --> Loader Class Initialized
INFO - 2023-06-16 16:24:53 --> Helper loaded: url_helper
INFO - 2023-06-16 16:24:53 --> Helper loaded: file_helper
INFO - 2023-06-16 16:24:53 --> Helper loaded: html_helper
INFO - 2023-06-16 16:24:53 --> Helper loaded: text_helper
INFO - 2023-06-16 16:24:53 --> Helper loaded: form_helper
INFO - 2023-06-16 16:24:53 --> Helper loaded: lang_helper
INFO - 2023-06-16 16:24:53 --> Helper loaded: security_helper
INFO - 2023-06-16 16:24:53 --> Helper loaded: cookie_helper
INFO - 2023-06-16 16:24:53 --> Database Driver Class Initialized
INFO - 2023-06-16 16:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-16 16:24:53 --> Parser Class Initialized
INFO - 2023-06-16 16:24:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-16 16:24:53 --> Pagination Class Initialized
INFO - 2023-06-16 16:24:53 --> Form Validation Class Initialized
INFO - 2023-06-16 16:24:53 --> Controller Class Initialized
INFO - 2023-06-16 16:24:53 --> Model Class Initialized
DEBUG - 2023-06-16 16:24:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-16 16:24:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-16 16:24:55 --> Config Class Initialized
INFO - 2023-06-16 16:24:55 --> Hooks Class Initialized
DEBUG - 2023-06-16 16:24:55 --> UTF-8 Support Enabled
INFO - 2023-06-16 16:24:55 --> Utf8 Class Initialized
INFO - 2023-06-16 16:24:55 --> URI Class Initialized
INFO - 2023-06-16 16:24:55 --> Router Class Initialized
INFO - 2023-06-16 16:24:55 --> Output Class Initialized
INFO - 2023-06-16 16:24:55 --> Security Class Initialized
DEBUG - 2023-06-16 16:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-16 16:24:55 --> Input Class Initialized
INFO - 2023-06-16 16:24:55 --> Language Class Initialized
INFO - 2023-06-16 16:24:55 --> Loader Class Initialized
INFO - 2023-06-16 16:24:55 --> Helper loaded: url_helper
INFO - 2023-06-16 16:24:55 --> Helper loaded: file_helper
INFO - 2023-06-16 16:24:55 --> Helper loaded: html_helper
INFO - 2023-06-16 16:24:55 --> Helper loaded: text_helper
INFO - 2023-06-16 16:24:55 --> Helper loaded: form_helper
INFO - 2023-06-16 16:24:55 --> Helper loaded: lang_helper
INFO - 2023-06-16 16:24:55 --> Helper loaded: security_helper
INFO - 2023-06-16 16:24:55 --> Helper loaded: cookie_helper
INFO - 2023-06-16 16:24:55 --> Database Driver Class Initialized
INFO - 2023-06-16 16:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-16 16:24:55 --> Parser Class Initialized
INFO - 2023-06-16 16:24:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-16 16:24:55 --> Pagination Class Initialized
INFO - 2023-06-16 16:24:55 --> Form Validation Class Initialized
INFO - 2023-06-16 16:24:55 --> Controller Class Initialized
INFO - 2023-06-16 16:24:55 --> Model Class Initialized
DEBUG - 2023-06-16 16:24:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-16 16:24:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-16 16:24:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-16 16:24:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-16 16:24:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-16 16:24:55 --> Model Class Initialized
INFO - 2023-06-16 16:24:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-16 16:24:55 --> Final output sent to browser
DEBUG - 2023-06-16 16:24:55 --> Total execution time: 0.0371
