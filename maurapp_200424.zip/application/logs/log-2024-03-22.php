<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-03-22 02:11:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 02:11:28 --> Config Class Initialized
INFO - 2024-03-22 02:11:28 --> Hooks Class Initialized
DEBUG - 2024-03-22 02:11:28 --> UTF-8 Support Enabled
INFO - 2024-03-22 02:11:28 --> Utf8 Class Initialized
INFO - 2024-03-22 02:11:28 --> URI Class Initialized
DEBUG - 2024-03-22 02:11:28 --> No URI present. Default controller set.
INFO - 2024-03-22 02:11:28 --> Router Class Initialized
INFO - 2024-03-22 02:11:28 --> Output Class Initialized
INFO - 2024-03-22 02:11:28 --> Security Class Initialized
DEBUG - 2024-03-22 02:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 02:11:28 --> Input Class Initialized
INFO - 2024-03-22 02:11:28 --> Language Class Initialized
INFO - 2024-03-22 02:11:28 --> Loader Class Initialized
INFO - 2024-03-22 02:11:28 --> Helper loaded: url_helper
INFO - 2024-03-22 02:11:28 --> Helper loaded: file_helper
INFO - 2024-03-22 02:11:28 --> Helper loaded: html_helper
INFO - 2024-03-22 02:11:28 --> Helper loaded: text_helper
INFO - 2024-03-22 02:11:28 --> Helper loaded: form_helper
INFO - 2024-03-22 02:11:28 --> Helper loaded: lang_helper
INFO - 2024-03-22 02:11:28 --> Helper loaded: security_helper
INFO - 2024-03-22 02:11:28 --> Helper loaded: cookie_helper
INFO - 2024-03-22 02:11:28 --> Database Driver Class Initialized
INFO - 2024-03-22 02:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 02:11:28 --> Parser Class Initialized
INFO - 2024-03-22 02:11:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 02:11:28 --> Pagination Class Initialized
INFO - 2024-03-22 02:11:28 --> Form Validation Class Initialized
INFO - 2024-03-22 02:11:28 --> Controller Class Initialized
INFO - 2024-03-22 02:11:28 --> Model Class Initialized
DEBUG - 2024-03-22 02:11:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 02:11:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 02:11:37 --> Config Class Initialized
INFO - 2024-03-22 02:11:37 --> Hooks Class Initialized
DEBUG - 2024-03-22 02:11:37 --> UTF-8 Support Enabled
INFO - 2024-03-22 02:11:37 --> Utf8 Class Initialized
INFO - 2024-03-22 02:11:37 --> URI Class Initialized
INFO - 2024-03-22 02:11:37 --> Router Class Initialized
INFO - 2024-03-22 02:11:37 --> Output Class Initialized
INFO - 2024-03-22 02:11:37 --> Security Class Initialized
DEBUG - 2024-03-22 02:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 02:11:37 --> Input Class Initialized
INFO - 2024-03-22 02:11:37 --> Language Class Initialized
ERROR - 2024-03-22 02:11:37 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2024-03-22 04:19:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 04:19:35 --> Config Class Initialized
INFO - 2024-03-22 04:19:35 --> Hooks Class Initialized
DEBUG - 2024-03-22 04:19:35 --> UTF-8 Support Enabled
INFO - 2024-03-22 04:19:35 --> Utf8 Class Initialized
INFO - 2024-03-22 04:19:35 --> URI Class Initialized
DEBUG - 2024-03-22 04:19:35 --> No URI present. Default controller set.
INFO - 2024-03-22 04:19:35 --> Router Class Initialized
INFO - 2024-03-22 04:19:35 --> Output Class Initialized
INFO - 2024-03-22 04:19:35 --> Security Class Initialized
DEBUG - 2024-03-22 04:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 04:19:35 --> Input Class Initialized
INFO - 2024-03-22 04:19:35 --> Language Class Initialized
INFO - 2024-03-22 04:19:35 --> Loader Class Initialized
INFO - 2024-03-22 04:19:35 --> Helper loaded: url_helper
INFO - 2024-03-22 04:19:35 --> Helper loaded: file_helper
INFO - 2024-03-22 04:19:35 --> Helper loaded: html_helper
INFO - 2024-03-22 04:19:35 --> Helper loaded: text_helper
INFO - 2024-03-22 04:19:35 --> Helper loaded: form_helper
INFO - 2024-03-22 04:19:35 --> Helper loaded: lang_helper
INFO - 2024-03-22 04:19:35 --> Helper loaded: security_helper
INFO - 2024-03-22 04:19:35 --> Helper loaded: cookie_helper
INFO - 2024-03-22 04:19:35 --> Database Driver Class Initialized
INFO - 2024-03-22 04:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 04:19:35 --> Parser Class Initialized
INFO - 2024-03-22 04:19:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 04:19:35 --> Pagination Class Initialized
INFO - 2024-03-22 04:19:35 --> Form Validation Class Initialized
INFO - 2024-03-22 04:19:35 --> Controller Class Initialized
INFO - 2024-03-22 04:19:35 --> Model Class Initialized
DEBUG - 2024-03-22 04:19:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 04:19:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 04:19:36 --> Config Class Initialized
INFO - 2024-03-22 04:19:36 --> Hooks Class Initialized
DEBUG - 2024-03-22 04:19:36 --> UTF-8 Support Enabled
INFO - 2024-03-22 04:19:36 --> Utf8 Class Initialized
INFO - 2024-03-22 04:19:36 --> URI Class Initialized
INFO - 2024-03-22 04:19:36 --> Router Class Initialized
INFO - 2024-03-22 04:19:36 --> Output Class Initialized
INFO - 2024-03-22 04:19:36 --> Security Class Initialized
DEBUG - 2024-03-22 04:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 04:19:36 --> Input Class Initialized
INFO - 2024-03-22 04:19:36 --> Language Class Initialized
INFO - 2024-03-22 04:19:36 --> Loader Class Initialized
INFO - 2024-03-22 04:19:36 --> Helper loaded: url_helper
INFO - 2024-03-22 04:19:36 --> Helper loaded: file_helper
INFO - 2024-03-22 04:19:36 --> Helper loaded: html_helper
INFO - 2024-03-22 04:19:36 --> Helper loaded: text_helper
INFO - 2024-03-22 04:19:36 --> Helper loaded: form_helper
INFO - 2024-03-22 04:19:36 --> Helper loaded: lang_helper
INFO - 2024-03-22 04:19:36 --> Helper loaded: security_helper
INFO - 2024-03-22 04:19:36 --> Helper loaded: cookie_helper
INFO - 2024-03-22 04:19:36 --> Database Driver Class Initialized
INFO - 2024-03-22 04:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 04:19:36 --> Parser Class Initialized
INFO - 2024-03-22 04:19:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 04:19:36 --> Pagination Class Initialized
INFO - 2024-03-22 04:19:36 --> Form Validation Class Initialized
INFO - 2024-03-22 04:19:36 --> Controller Class Initialized
INFO - 2024-03-22 04:19:36 --> Model Class Initialized
DEBUG - 2024-03-22 04:19:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:19:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-22 04:19:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:19:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 04:19:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 04:19:36 --> Model Class Initialized
INFO - 2024-03-22 04:19:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 04:19:36 --> Final output sent to browser
DEBUG - 2024-03-22 04:19:36 --> Total execution time: 0.0367
ERROR - 2024-03-22 04:19:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 04:19:47 --> Config Class Initialized
INFO - 2024-03-22 04:19:47 --> Hooks Class Initialized
DEBUG - 2024-03-22 04:19:47 --> UTF-8 Support Enabled
INFO - 2024-03-22 04:19:47 --> Utf8 Class Initialized
INFO - 2024-03-22 04:19:47 --> URI Class Initialized
INFO - 2024-03-22 04:19:47 --> Router Class Initialized
INFO - 2024-03-22 04:19:47 --> Output Class Initialized
INFO - 2024-03-22 04:19:47 --> Security Class Initialized
DEBUG - 2024-03-22 04:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 04:19:47 --> Input Class Initialized
INFO - 2024-03-22 04:19:47 --> Language Class Initialized
INFO - 2024-03-22 04:19:47 --> Loader Class Initialized
INFO - 2024-03-22 04:19:47 --> Helper loaded: url_helper
INFO - 2024-03-22 04:19:47 --> Helper loaded: file_helper
INFO - 2024-03-22 04:19:47 --> Helper loaded: html_helper
INFO - 2024-03-22 04:19:47 --> Helper loaded: text_helper
INFO - 2024-03-22 04:19:47 --> Helper loaded: form_helper
INFO - 2024-03-22 04:19:47 --> Helper loaded: lang_helper
INFO - 2024-03-22 04:19:47 --> Helper loaded: security_helper
INFO - 2024-03-22 04:19:47 --> Helper loaded: cookie_helper
INFO - 2024-03-22 04:19:47 --> Database Driver Class Initialized
INFO - 2024-03-22 04:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 04:19:47 --> Parser Class Initialized
INFO - 2024-03-22 04:19:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 04:19:47 --> Pagination Class Initialized
INFO - 2024-03-22 04:19:47 --> Form Validation Class Initialized
INFO - 2024-03-22 04:19:47 --> Controller Class Initialized
INFO - 2024-03-22 04:19:47 --> Model Class Initialized
DEBUG - 2024-03-22 04:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:19:47 --> Model Class Initialized
INFO - 2024-03-22 04:19:47 --> Final output sent to browser
DEBUG - 2024-03-22 04:19:47 --> Total execution time: 0.0192
ERROR - 2024-03-22 04:19:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 04:19:47 --> Config Class Initialized
INFO - 2024-03-22 04:19:47 --> Hooks Class Initialized
DEBUG - 2024-03-22 04:19:47 --> UTF-8 Support Enabled
INFO - 2024-03-22 04:19:47 --> Utf8 Class Initialized
INFO - 2024-03-22 04:19:47 --> URI Class Initialized
DEBUG - 2024-03-22 04:19:47 --> No URI present. Default controller set.
INFO - 2024-03-22 04:19:47 --> Router Class Initialized
INFO - 2024-03-22 04:19:47 --> Output Class Initialized
INFO - 2024-03-22 04:19:47 --> Security Class Initialized
DEBUG - 2024-03-22 04:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 04:19:47 --> Input Class Initialized
INFO - 2024-03-22 04:19:47 --> Language Class Initialized
INFO - 2024-03-22 04:19:47 --> Loader Class Initialized
INFO - 2024-03-22 04:19:47 --> Helper loaded: url_helper
INFO - 2024-03-22 04:19:47 --> Helper loaded: file_helper
INFO - 2024-03-22 04:19:47 --> Helper loaded: html_helper
INFO - 2024-03-22 04:19:47 --> Helper loaded: text_helper
INFO - 2024-03-22 04:19:47 --> Helper loaded: form_helper
INFO - 2024-03-22 04:19:47 --> Helper loaded: lang_helper
INFO - 2024-03-22 04:19:47 --> Helper loaded: security_helper
INFO - 2024-03-22 04:19:47 --> Helper loaded: cookie_helper
INFO - 2024-03-22 04:19:47 --> Database Driver Class Initialized
INFO - 2024-03-22 04:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 04:19:47 --> Parser Class Initialized
INFO - 2024-03-22 04:19:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 04:19:47 --> Pagination Class Initialized
INFO - 2024-03-22 04:19:47 --> Form Validation Class Initialized
INFO - 2024-03-22 04:19:47 --> Controller Class Initialized
INFO - 2024-03-22 04:19:47 --> Model Class Initialized
DEBUG - 2024-03-22 04:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:19:47 --> Model Class Initialized
DEBUG - 2024-03-22 04:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:19:47 --> Model Class Initialized
INFO - 2024-03-22 04:19:47 --> Model Class Initialized
INFO - 2024-03-22 04:19:47 --> Model Class Initialized
INFO - 2024-03-22 04:19:47 --> Model Class Initialized
DEBUG - 2024-03-22 04:19:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 04:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:19:47 --> Model Class Initialized
INFO - 2024-03-22 04:19:47 --> Model Class Initialized
INFO - 2024-03-22 04:19:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 04:19:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:19:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 04:19:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 04:19:48 --> Model Class Initialized
INFO - 2024-03-22 04:19:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 04:19:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 04:19:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 04:19:48 --> Final output sent to browser
DEBUG - 2024-03-22 04:19:48 --> Total execution time: 0.2744
ERROR - 2024-03-22 04:19:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 04:19:59 --> Config Class Initialized
INFO - 2024-03-22 04:19:59 --> Hooks Class Initialized
DEBUG - 2024-03-22 04:19:59 --> UTF-8 Support Enabled
INFO - 2024-03-22 04:19:59 --> Utf8 Class Initialized
INFO - 2024-03-22 04:19:59 --> URI Class Initialized
INFO - 2024-03-22 04:19:59 --> Router Class Initialized
INFO - 2024-03-22 04:19:59 --> Output Class Initialized
INFO - 2024-03-22 04:19:59 --> Security Class Initialized
DEBUG - 2024-03-22 04:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 04:19:59 --> Input Class Initialized
INFO - 2024-03-22 04:19:59 --> Language Class Initialized
INFO - 2024-03-22 04:19:59 --> Loader Class Initialized
INFO - 2024-03-22 04:19:59 --> Helper loaded: url_helper
INFO - 2024-03-22 04:19:59 --> Helper loaded: file_helper
INFO - 2024-03-22 04:19:59 --> Helper loaded: html_helper
INFO - 2024-03-22 04:19:59 --> Helper loaded: text_helper
INFO - 2024-03-22 04:19:59 --> Helper loaded: form_helper
INFO - 2024-03-22 04:19:59 --> Helper loaded: lang_helper
INFO - 2024-03-22 04:19:59 --> Helper loaded: security_helper
INFO - 2024-03-22 04:19:59 --> Helper loaded: cookie_helper
INFO - 2024-03-22 04:19:59 --> Database Driver Class Initialized
INFO - 2024-03-22 04:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 04:19:59 --> Parser Class Initialized
INFO - 2024-03-22 04:19:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 04:19:59 --> Pagination Class Initialized
INFO - 2024-03-22 04:19:59 --> Form Validation Class Initialized
INFO - 2024-03-22 04:19:59 --> Controller Class Initialized
INFO - 2024-03-22 04:19:59 --> Model Class Initialized
DEBUG - 2024-03-22 04:19:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 04:19:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:19:59 --> Model Class Initialized
DEBUG - 2024-03-22 04:19:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:19:59 --> Model Class Initialized
INFO - 2024-03-22 04:19:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-03-22 04:19:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:19:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 04:19:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 04:19:59 --> Model Class Initialized
INFO - 2024-03-22 04:19:59 --> Model Class Initialized
INFO - 2024-03-22 04:19:59 --> Model Class Initialized
INFO - 2024-03-22 04:19:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 04:19:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 04:19:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 04:19:59 --> Final output sent to browser
DEBUG - 2024-03-22 04:19:59 --> Total execution time: 0.2005
ERROR - 2024-03-22 04:20:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 04:20:06 --> Config Class Initialized
INFO - 2024-03-22 04:20:06 --> Hooks Class Initialized
DEBUG - 2024-03-22 04:20:06 --> UTF-8 Support Enabled
INFO - 2024-03-22 04:20:06 --> Utf8 Class Initialized
INFO - 2024-03-22 04:20:06 --> URI Class Initialized
INFO - 2024-03-22 04:20:06 --> Router Class Initialized
INFO - 2024-03-22 04:20:06 --> Output Class Initialized
INFO - 2024-03-22 04:20:06 --> Security Class Initialized
DEBUG - 2024-03-22 04:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 04:20:06 --> Input Class Initialized
INFO - 2024-03-22 04:20:06 --> Language Class Initialized
INFO - 2024-03-22 04:20:06 --> Loader Class Initialized
INFO - 2024-03-22 04:20:06 --> Helper loaded: url_helper
INFO - 2024-03-22 04:20:06 --> Helper loaded: file_helper
INFO - 2024-03-22 04:20:06 --> Helper loaded: html_helper
INFO - 2024-03-22 04:20:06 --> Helper loaded: text_helper
INFO - 2024-03-22 04:20:06 --> Helper loaded: form_helper
INFO - 2024-03-22 04:20:06 --> Helper loaded: lang_helper
INFO - 2024-03-22 04:20:06 --> Helper loaded: security_helper
INFO - 2024-03-22 04:20:06 --> Helper loaded: cookie_helper
INFO - 2024-03-22 04:20:06 --> Database Driver Class Initialized
INFO - 2024-03-22 04:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 04:20:06 --> Parser Class Initialized
INFO - 2024-03-22 04:20:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 04:20:06 --> Pagination Class Initialized
INFO - 2024-03-22 04:20:06 --> Form Validation Class Initialized
INFO - 2024-03-22 04:20:06 --> Controller Class Initialized
INFO - 2024-03-22 04:20:06 --> Model Class Initialized
DEBUG - 2024-03-22 04:20:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:20:06 --> Final output sent to browser
DEBUG - 2024-03-22 04:20:06 --> Total execution time: 0.0168
ERROR - 2024-03-22 04:20:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 04:20:07 --> Config Class Initialized
INFO - 2024-03-22 04:20:07 --> Hooks Class Initialized
DEBUG - 2024-03-22 04:20:07 --> UTF-8 Support Enabled
INFO - 2024-03-22 04:20:07 --> Utf8 Class Initialized
INFO - 2024-03-22 04:20:07 --> URI Class Initialized
INFO - 2024-03-22 04:20:07 --> Router Class Initialized
INFO - 2024-03-22 04:20:07 --> Output Class Initialized
INFO - 2024-03-22 04:20:07 --> Security Class Initialized
DEBUG - 2024-03-22 04:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 04:20:07 --> Input Class Initialized
INFO - 2024-03-22 04:20:07 --> Language Class Initialized
INFO - 2024-03-22 04:20:07 --> Loader Class Initialized
INFO - 2024-03-22 04:20:07 --> Helper loaded: url_helper
INFO - 2024-03-22 04:20:07 --> Helper loaded: file_helper
INFO - 2024-03-22 04:20:07 --> Helper loaded: html_helper
INFO - 2024-03-22 04:20:07 --> Helper loaded: text_helper
INFO - 2024-03-22 04:20:07 --> Helper loaded: form_helper
INFO - 2024-03-22 04:20:07 --> Helper loaded: lang_helper
INFO - 2024-03-22 04:20:07 --> Helper loaded: security_helper
INFO - 2024-03-22 04:20:07 --> Helper loaded: cookie_helper
INFO - 2024-03-22 04:20:07 --> Database Driver Class Initialized
INFO - 2024-03-22 04:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 04:20:07 --> Parser Class Initialized
INFO - 2024-03-22 04:20:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 04:20:07 --> Pagination Class Initialized
INFO - 2024-03-22 04:20:07 --> Form Validation Class Initialized
INFO - 2024-03-22 04:20:07 --> Controller Class Initialized
INFO - 2024-03-22 04:20:07 --> Model Class Initialized
DEBUG - 2024-03-22 04:20:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:20:07 --> Final output sent to browser
DEBUG - 2024-03-22 04:20:07 --> Total execution time: 0.0189
ERROR - 2024-03-22 04:20:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 04:20:09 --> Config Class Initialized
INFO - 2024-03-22 04:20:09 --> Hooks Class Initialized
DEBUG - 2024-03-22 04:20:09 --> UTF-8 Support Enabled
INFO - 2024-03-22 04:20:09 --> Utf8 Class Initialized
INFO - 2024-03-22 04:20:09 --> URI Class Initialized
INFO - 2024-03-22 04:20:09 --> Router Class Initialized
INFO - 2024-03-22 04:20:09 --> Output Class Initialized
INFO - 2024-03-22 04:20:09 --> Security Class Initialized
DEBUG - 2024-03-22 04:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 04:20:09 --> Input Class Initialized
INFO - 2024-03-22 04:20:09 --> Language Class Initialized
INFO - 2024-03-22 04:20:09 --> Loader Class Initialized
INFO - 2024-03-22 04:20:09 --> Helper loaded: url_helper
INFO - 2024-03-22 04:20:09 --> Helper loaded: file_helper
INFO - 2024-03-22 04:20:09 --> Helper loaded: html_helper
INFO - 2024-03-22 04:20:09 --> Helper loaded: text_helper
INFO - 2024-03-22 04:20:09 --> Helper loaded: form_helper
INFO - 2024-03-22 04:20:09 --> Helper loaded: lang_helper
INFO - 2024-03-22 04:20:09 --> Helper loaded: security_helper
INFO - 2024-03-22 04:20:09 --> Helper loaded: cookie_helper
INFO - 2024-03-22 04:20:09 --> Database Driver Class Initialized
INFO - 2024-03-22 04:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 04:20:09 --> Parser Class Initialized
INFO - 2024-03-22 04:20:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 04:20:09 --> Pagination Class Initialized
INFO - 2024-03-22 04:20:09 --> Form Validation Class Initialized
INFO - 2024-03-22 04:20:09 --> Controller Class Initialized
INFO - 2024-03-22 04:20:09 --> Final output sent to browser
DEBUG - 2024-03-22 04:20:09 --> Total execution time: 0.0157
ERROR - 2024-03-22 04:20:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 04:20:15 --> Config Class Initialized
INFO - 2024-03-22 04:20:15 --> Hooks Class Initialized
DEBUG - 2024-03-22 04:20:15 --> UTF-8 Support Enabled
INFO - 2024-03-22 04:20:15 --> Utf8 Class Initialized
INFO - 2024-03-22 04:20:15 --> URI Class Initialized
INFO - 2024-03-22 04:20:15 --> Router Class Initialized
INFO - 2024-03-22 04:20:15 --> Output Class Initialized
INFO - 2024-03-22 04:20:15 --> Security Class Initialized
DEBUG - 2024-03-22 04:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 04:20:15 --> Input Class Initialized
INFO - 2024-03-22 04:20:15 --> Language Class Initialized
INFO - 2024-03-22 04:20:15 --> Loader Class Initialized
INFO - 2024-03-22 04:20:15 --> Helper loaded: url_helper
INFO - 2024-03-22 04:20:15 --> Helper loaded: file_helper
INFO - 2024-03-22 04:20:15 --> Helper loaded: html_helper
INFO - 2024-03-22 04:20:15 --> Helper loaded: text_helper
INFO - 2024-03-22 04:20:15 --> Helper loaded: form_helper
INFO - 2024-03-22 04:20:15 --> Helper loaded: lang_helper
INFO - 2024-03-22 04:20:15 --> Helper loaded: security_helper
INFO - 2024-03-22 04:20:15 --> Helper loaded: cookie_helper
INFO - 2024-03-22 04:20:15 --> Database Driver Class Initialized
INFO - 2024-03-22 04:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 04:20:15 --> Parser Class Initialized
INFO - 2024-03-22 04:20:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 04:20:15 --> Pagination Class Initialized
INFO - 2024-03-22 04:20:15 --> Form Validation Class Initialized
INFO - 2024-03-22 04:20:15 --> Controller Class Initialized
INFO - 2024-03-22 04:20:15 --> Model Class Initialized
DEBUG - 2024-03-22 04:20:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 04:20:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:20:15 --> Model Class Initialized
DEBUG - 2024-03-22 04:20:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:20:15 --> Model Class Initialized
INFO - 2024-03-22 04:20:15 --> Final output sent to browser
DEBUG - 2024-03-22 04:20:15 --> Total execution time: 0.1519
ERROR - 2024-03-22 04:20:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 04:20:16 --> Config Class Initialized
INFO - 2024-03-22 04:20:16 --> Hooks Class Initialized
DEBUG - 2024-03-22 04:20:16 --> UTF-8 Support Enabled
INFO - 2024-03-22 04:20:16 --> Utf8 Class Initialized
INFO - 2024-03-22 04:20:16 --> URI Class Initialized
INFO - 2024-03-22 04:20:16 --> Router Class Initialized
INFO - 2024-03-22 04:20:16 --> Output Class Initialized
INFO - 2024-03-22 04:20:16 --> Security Class Initialized
DEBUG - 2024-03-22 04:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 04:20:16 --> Input Class Initialized
INFO - 2024-03-22 04:20:16 --> Language Class Initialized
INFO - 2024-03-22 04:20:16 --> Loader Class Initialized
INFO - 2024-03-22 04:20:16 --> Helper loaded: url_helper
INFO - 2024-03-22 04:20:16 --> Helper loaded: file_helper
INFO - 2024-03-22 04:20:16 --> Helper loaded: html_helper
INFO - 2024-03-22 04:20:16 --> Helper loaded: text_helper
INFO - 2024-03-22 04:20:16 --> Helper loaded: form_helper
INFO - 2024-03-22 04:20:16 --> Helper loaded: lang_helper
INFO - 2024-03-22 04:20:16 --> Helper loaded: security_helper
INFO - 2024-03-22 04:20:16 --> Helper loaded: cookie_helper
INFO - 2024-03-22 04:20:16 --> Database Driver Class Initialized
INFO - 2024-03-22 04:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 04:20:16 --> Parser Class Initialized
INFO - 2024-03-22 04:20:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 04:20:16 --> Pagination Class Initialized
INFO - 2024-03-22 04:20:16 --> Form Validation Class Initialized
INFO - 2024-03-22 04:20:16 --> Controller Class Initialized
INFO - 2024-03-22 04:20:16 --> Model Class Initialized
DEBUG - 2024-03-22 04:20:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 04:20:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:20:16 --> Model Class Initialized
DEBUG - 2024-03-22 04:20:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:20:16 --> Model Class Initialized
INFO - 2024-03-22 04:20:16 --> Final output sent to browser
DEBUG - 2024-03-22 04:20:16 --> Total execution time: 0.1463
ERROR - 2024-03-22 04:20:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 04:20:16 --> Config Class Initialized
INFO - 2024-03-22 04:20:16 --> Hooks Class Initialized
DEBUG - 2024-03-22 04:20:16 --> UTF-8 Support Enabled
INFO - 2024-03-22 04:20:16 --> Utf8 Class Initialized
INFO - 2024-03-22 04:20:16 --> URI Class Initialized
INFO - 2024-03-22 04:20:16 --> Router Class Initialized
INFO - 2024-03-22 04:20:16 --> Output Class Initialized
INFO - 2024-03-22 04:20:16 --> Security Class Initialized
DEBUG - 2024-03-22 04:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 04:20:16 --> Input Class Initialized
INFO - 2024-03-22 04:20:16 --> Language Class Initialized
INFO - 2024-03-22 04:20:16 --> Loader Class Initialized
INFO - 2024-03-22 04:20:16 --> Helper loaded: url_helper
INFO - 2024-03-22 04:20:16 --> Helper loaded: file_helper
INFO - 2024-03-22 04:20:16 --> Helper loaded: html_helper
INFO - 2024-03-22 04:20:16 --> Helper loaded: text_helper
INFO - 2024-03-22 04:20:16 --> Helper loaded: form_helper
INFO - 2024-03-22 04:20:16 --> Helper loaded: lang_helper
INFO - 2024-03-22 04:20:16 --> Helper loaded: security_helper
INFO - 2024-03-22 04:20:16 --> Helper loaded: cookie_helper
INFO - 2024-03-22 04:20:16 --> Database Driver Class Initialized
INFO - 2024-03-22 04:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 04:20:16 --> Parser Class Initialized
INFO - 2024-03-22 04:20:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 04:20:16 --> Pagination Class Initialized
INFO - 2024-03-22 04:20:16 --> Form Validation Class Initialized
INFO - 2024-03-22 04:20:16 --> Controller Class Initialized
INFO - 2024-03-22 04:20:17 --> Model Class Initialized
DEBUG - 2024-03-22 04:20:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 04:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:20:17 --> Model Class Initialized
DEBUG - 2024-03-22 04:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:20:17 --> Model Class Initialized
INFO - 2024-03-22 04:20:17 --> Final output sent to browser
DEBUG - 2024-03-22 04:20:17 --> Total execution time: 0.1413
ERROR - 2024-03-22 04:20:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 04:20:21 --> Config Class Initialized
INFO - 2024-03-22 04:20:21 --> Hooks Class Initialized
DEBUG - 2024-03-22 04:20:21 --> UTF-8 Support Enabled
INFO - 2024-03-22 04:20:21 --> Utf8 Class Initialized
INFO - 2024-03-22 04:20:21 --> URI Class Initialized
INFO - 2024-03-22 04:20:21 --> Router Class Initialized
INFO - 2024-03-22 04:20:21 --> Output Class Initialized
INFO - 2024-03-22 04:20:21 --> Security Class Initialized
DEBUG - 2024-03-22 04:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 04:20:21 --> Input Class Initialized
INFO - 2024-03-22 04:20:21 --> Language Class Initialized
INFO - 2024-03-22 04:20:21 --> Loader Class Initialized
INFO - 2024-03-22 04:20:21 --> Helper loaded: url_helper
INFO - 2024-03-22 04:20:21 --> Helper loaded: file_helper
INFO - 2024-03-22 04:20:21 --> Helper loaded: html_helper
INFO - 2024-03-22 04:20:21 --> Helper loaded: text_helper
INFO - 2024-03-22 04:20:21 --> Helper loaded: form_helper
INFO - 2024-03-22 04:20:21 --> Helper loaded: lang_helper
INFO - 2024-03-22 04:20:21 --> Helper loaded: security_helper
INFO - 2024-03-22 04:20:21 --> Helper loaded: cookie_helper
INFO - 2024-03-22 04:20:21 --> Database Driver Class Initialized
INFO - 2024-03-22 04:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 04:20:21 --> Parser Class Initialized
INFO - 2024-03-22 04:20:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 04:20:21 --> Pagination Class Initialized
INFO - 2024-03-22 04:20:21 --> Form Validation Class Initialized
INFO - 2024-03-22 04:20:21 --> Controller Class Initialized
INFO - 2024-03-22 04:20:21 --> Model Class Initialized
DEBUG - 2024-03-22 04:20:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 04:20:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:20:21 --> Model Class Initialized
INFO - 2024-03-22 04:20:21 --> Model Class Initialized
INFO - 2024-03-22 04:20:21 --> Final output sent to browser
DEBUG - 2024-03-22 04:20:21 --> Total execution time: 0.0210
ERROR - 2024-03-22 04:20:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 04:20:25 --> Config Class Initialized
INFO - 2024-03-22 04:20:25 --> Hooks Class Initialized
DEBUG - 2024-03-22 04:20:25 --> UTF-8 Support Enabled
INFO - 2024-03-22 04:20:25 --> Utf8 Class Initialized
INFO - 2024-03-22 04:20:25 --> URI Class Initialized
INFO - 2024-03-22 04:20:25 --> Router Class Initialized
INFO - 2024-03-22 04:20:25 --> Output Class Initialized
INFO - 2024-03-22 04:20:25 --> Security Class Initialized
DEBUG - 2024-03-22 04:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 04:20:25 --> Input Class Initialized
INFO - 2024-03-22 04:20:25 --> Language Class Initialized
INFO - 2024-03-22 04:20:25 --> Loader Class Initialized
INFO - 2024-03-22 04:20:25 --> Helper loaded: url_helper
INFO - 2024-03-22 04:20:25 --> Helper loaded: file_helper
INFO - 2024-03-22 04:20:25 --> Helper loaded: html_helper
INFO - 2024-03-22 04:20:25 --> Helper loaded: text_helper
INFO - 2024-03-22 04:20:25 --> Helper loaded: form_helper
INFO - 2024-03-22 04:20:25 --> Helper loaded: lang_helper
INFO - 2024-03-22 04:20:25 --> Helper loaded: security_helper
INFO - 2024-03-22 04:20:25 --> Helper loaded: cookie_helper
INFO - 2024-03-22 04:20:25 --> Database Driver Class Initialized
INFO - 2024-03-22 04:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 04:20:25 --> Parser Class Initialized
INFO - 2024-03-22 04:20:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 04:20:25 --> Pagination Class Initialized
INFO - 2024-03-22 04:20:25 --> Form Validation Class Initialized
INFO - 2024-03-22 04:20:25 --> Controller Class Initialized
INFO - 2024-03-22 04:20:25 --> Model Class Initialized
DEBUG - 2024-03-22 04:20:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 04:20:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:20:25 --> Model Class Initialized
INFO - 2024-03-22 04:20:25 --> Final output sent to browser
DEBUG - 2024-03-22 04:20:25 --> Total execution time: 0.0181
ERROR - 2024-03-22 04:20:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 04:20:27 --> Config Class Initialized
INFO - 2024-03-22 04:20:27 --> Hooks Class Initialized
DEBUG - 2024-03-22 04:20:27 --> UTF-8 Support Enabled
INFO - 2024-03-22 04:20:27 --> Utf8 Class Initialized
INFO - 2024-03-22 04:20:27 --> URI Class Initialized
INFO - 2024-03-22 04:20:27 --> Router Class Initialized
INFO - 2024-03-22 04:20:27 --> Output Class Initialized
INFO - 2024-03-22 04:20:27 --> Security Class Initialized
DEBUG - 2024-03-22 04:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 04:20:27 --> Input Class Initialized
INFO - 2024-03-22 04:20:27 --> Language Class Initialized
INFO - 2024-03-22 04:20:27 --> Loader Class Initialized
INFO - 2024-03-22 04:20:27 --> Helper loaded: url_helper
INFO - 2024-03-22 04:20:27 --> Helper loaded: file_helper
INFO - 2024-03-22 04:20:27 --> Helper loaded: html_helper
INFO - 2024-03-22 04:20:27 --> Helper loaded: text_helper
INFO - 2024-03-22 04:20:27 --> Helper loaded: form_helper
INFO - 2024-03-22 04:20:27 --> Helper loaded: lang_helper
INFO - 2024-03-22 04:20:27 --> Helper loaded: security_helper
INFO - 2024-03-22 04:20:27 --> Helper loaded: cookie_helper
INFO - 2024-03-22 04:20:27 --> Database Driver Class Initialized
INFO - 2024-03-22 04:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 04:20:27 --> Parser Class Initialized
INFO - 2024-03-22 04:20:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 04:20:27 --> Pagination Class Initialized
INFO - 2024-03-22 04:20:27 --> Form Validation Class Initialized
INFO - 2024-03-22 04:20:27 --> Controller Class Initialized
INFO - 2024-03-22 04:20:27 --> Model Class Initialized
DEBUG - 2024-03-22 04:20:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 04:20:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:20:27 --> Model Class Initialized
INFO - 2024-03-22 04:20:27 --> Final output sent to browser
DEBUG - 2024-03-22 04:20:27 --> Total execution time: 0.0175
ERROR - 2024-03-22 04:20:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 04:20:35 --> Config Class Initialized
INFO - 2024-03-22 04:20:35 --> Hooks Class Initialized
DEBUG - 2024-03-22 04:20:35 --> UTF-8 Support Enabled
INFO - 2024-03-22 04:20:35 --> Utf8 Class Initialized
INFO - 2024-03-22 04:20:35 --> URI Class Initialized
DEBUG - 2024-03-22 04:20:35 --> No URI present. Default controller set.
INFO - 2024-03-22 04:20:35 --> Router Class Initialized
INFO - 2024-03-22 04:20:35 --> Output Class Initialized
INFO - 2024-03-22 04:20:35 --> Security Class Initialized
DEBUG - 2024-03-22 04:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 04:20:35 --> Input Class Initialized
INFO - 2024-03-22 04:20:35 --> Language Class Initialized
INFO - 2024-03-22 04:20:35 --> Loader Class Initialized
INFO - 2024-03-22 04:20:35 --> Helper loaded: url_helper
INFO - 2024-03-22 04:20:35 --> Helper loaded: file_helper
INFO - 2024-03-22 04:20:35 --> Helper loaded: html_helper
INFO - 2024-03-22 04:20:35 --> Helper loaded: text_helper
INFO - 2024-03-22 04:20:35 --> Helper loaded: form_helper
INFO - 2024-03-22 04:20:35 --> Helper loaded: lang_helper
INFO - 2024-03-22 04:20:35 --> Helper loaded: security_helper
INFO - 2024-03-22 04:20:35 --> Helper loaded: cookie_helper
INFO - 2024-03-22 04:20:35 --> Database Driver Class Initialized
INFO - 2024-03-22 04:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 04:20:35 --> Parser Class Initialized
INFO - 2024-03-22 04:20:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 04:20:35 --> Pagination Class Initialized
INFO - 2024-03-22 04:20:35 --> Form Validation Class Initialized
INFO - 2024-03-22 04:20:35 --> Controller Class Initialized
INFO - 2024-03-22 04:20:35 --> Model Class Initialized
DEBUG - 2024-03-22 04:20:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:20:35 --> Model Class Initialized
DEBUG - 2024-03-22 04:20:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:20:35 --> Model Class Initialized
INFO - 2024-03-22 04:20:35 --> Model Class Initialized
INFO - 2024-03-22 04:20:35 --> Model Class Initialized
INFO - 2024-03-22 04:20:35 --> Model Class Initialized
DEBUG - 2024-03-22 04:20:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 04:20:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:20:35 --> Model Class Initialized
INFO - 2024-03-22 04:20:35 --> Model Class Initialized
ERROR - 2024-03-22 04:20:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 04:20:35 --> Config Class Initialized
INFO - 2024-03-22 04:20:35 --> Hooks Class Initialized
DEBUG - 2024-03-22 04:20:35 --> UTF-8 Support Enabled
INFO - 2024-03-22 04:20:35 --> Utf8 Class Initialized
INFO - 2024-03-22 04:20:35 --> URI Class Initialized
INFO - 2024-03-22 04:20:35 --> Router Class Initialized
INFO - 2024-03-22 04:20:35 --> Output Class Initialized
INFO - 2024-03-22 04:20:35 --> Security Class Initialized
DEBUG - 2024-03-22 04:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 04:20:35 --> Input Class Initialized
INFO - 2024-03-22 04:20:35 --> Language Class Initialized
INFO - 2024-03-22 04:20:35 --> Loader Class Initialized
INFO - 2024-03-22 04:20:35 --> Helper loaded: url_helper
INFO - 2024-03-22 04:20:35 --> Helper loaded: file_helper
INFO - 2024-03-22 04:20:35 --> Helper loaded: html_helper
INFO - 2024-03-22 04:20:35 --> Helper loaded: text_helper
INFO - 2024-03-22 04:20:35 --> Helper loaded: form_helper
INFO - 2024-03-22 04:20:35 --> Helper loaded: lang_helper
INFO - 2024-03-22 04:20:35 --> Helper loaded: security_helper
INFO - 2024-03-22 04:20:35 --> Helper loaded: cookie_helper
INFO - 2024-03-22 04:20:35 --> Database Driver Class Initialized
INFO - 2024-03-22 04:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 04:20:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 04:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 04:20:35 --> Model Class Initialized
INFO - 2024-03-22 04:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 04:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 04:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 04:20:35 --> Final output sent to browser
DEBUG - 2024-03-22 04:20:35 --> Total execution time: 0.2544
INFO - 2024-03-22 04:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 04:20:35 --> Parser Class Initialized
INFO - 2024-03-22 04:20:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 04:20:35 --> Pagination Class Initialized
INFO - 2024-03-22 04:20:35 --> Form Validation Class Initialized
INFO - 2024-03-22 04:20:35 --> Controller Class Initialized
INFO - 2024-03-22 04:20:35 --> Model Class Initialized
DEBUG - 2024-03-22 04:20:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-22 04:20:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 04:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 04:20:35 --> Model Class Initialized
INFO - 2024-03-22 04:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 04:20:35 --> Final output sent to browser
DEBUG - 2024-03-22 04:20:35 --> Total execution time: 0.2197
ERROR - 2024-03-22 04:20:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 04:20:35 --> Config Class Initialized
INFO - 2024-03-22 04:20:35 --> Hooks Class Initialized
DEBUG - 2024-03-22 04:20:35 --> UTF-8 Support Enabled
INFO - 2024-03-22 04:20:35 --> Utf8 Class Initialized
INFO - 2024-03-22 04:20:35 --> URI Class Initialized
INFO - 2024-03-22 04:20:35 --> Router Class Initialized
INFO - 2024-03-22 04:20:35 --> Output Class Initialized
INFO - 2024-03-22 04:20:35 --> Security Class Initialized
DEBUG - 2024-03-22 04:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 04:20:35 --> Input Class Initialized
INFO - 2024-03-22 04:20:35 --> Language Class Initialized
INFO - 2024-03-22 04:20:35 --> Loader Class Initialized
INFO - 2024-03-22 04:20:35 --> Helper loaded: url_helper
INFO - 2024-03-22 04:20:35 --> Helper loaded: file_helper
INFO - 2024-03-22 04:20:35 --> Helper loaded: html_helper
INFO - 2024-03-22 04:20:35 --> Helper loaded: text_helper
INFO - 2024-03-22 04:20:35 --> Helper loaded: form_helper
INFO - 2024-03-22 04:20:35 --> Helper loaded: lang_helper
INFO - 2024-03-22 04:20:35 --> Helper loaded: security_helper
INFO - 2024-03-22 04:20:35 --> Helper loaded: cookie_helper
INFO - 2024-03-22 04:20:35 --> Database Driver Class Initialized
INFO - 2024-03-22 04:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 04:20:35 --> Parser Class Initialized
INFO - 2024-03-22 04:20:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 04:20:35 --> Pagination Class Initialized
INFO - 2024-03-22 04:20:35 --> Form Validation Class Initialized
INFO - 2024-03-22 04:20:35 --> Controller Class Initialized
INFO - 2024-03-22 04:20:35 --> Model Class Initialized
DEBUG - 2024-03-22 04:20:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:20:35 --> Model Class Initialized
DEBUG - 2024-03-22 04:20:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:20:35 --> Model Class Initialized
INFO - 2024-03-22 04:20:35 --> Model Class Initialized
INFO - 2024-03-22 04:20:35 --> Model Class Initialized
INFO - 2024-03-22 04:20:35 --> Model Class Initialized
DEBUG - 2024-03-22 04:20:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 04:20:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:20:35 --> Model Class Initialized
INFO - 2024-03-22 04:20:35 --> Model Class Initialized
INFO - 2024-03-22 04:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 04:20:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 04:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 04:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 04:20:35 --> Model Class Initialized
INFO - 2024-03-22 04:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 04:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 04:20:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 04:20:35 --> Final output sent to browser
DEBUG - 2024-03-22 04:20:35 --> Total execution time: 0.2524
ERROR - 2024-03-22 05:16:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:16:17 --> Config Class Initialized
INFO - 2024-03-22 05:16:17 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:16:17 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:16:17 --> Utf8 Class Initialized
INFO - 2024-03-22 05:16:17 --> URI Class Initialized
DEBUG - 2024-03-22 05:16:17 --> No URI present. Default controller set.
INFO - 2024-03-22 05:16:17 --> Router Class Initialized
INFO - 2024-03-22 05:16:17 --> Output Class Initialized
INFO - 2024-03-22 05:16:17 --> Security Class Initialized
DEBUG - 2024-03-22 05:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:16:17 --> Input Class Initialized
INFO - 2024-03-22 05:16:17 --> Language Class Initialized
INFO - 2024-03-22 05:16:18 --> Loader Class Initialized
INFO - 2024-03-22 05:16:18 --> Helper loaded: url_helper
INFO - 2024-03-22 05:16:18 --> Helper loaded: file_helper
INFO - 2024-03-22 05:16:18 --> Helper loaded: html_helper
INFO - 2024-03-22 05:16:18 --> Helper loaded: text_helper
INFO - 2024-03-22 05:16:18 --> Helper loaded: form_helper
INFO - 2024-03-22 05:16:18 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:16:18 --> Helper loaded: security_helper
INFO - 2024-03-22 05:16:18 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:16:18 --> Database Driver Class Initialized
INFO - 2024-03-22 05:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:16:18 --> Parser Class Initialized
INFO - 2024-03-22 05:16:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:16:18 --> Pagination Class Initialized
INFO - 2024-03-22 05:16:18 --> Form Validation Class Initialized
INFO - 2024-03-22 05:16:18 --> Controller Class Initialized
INFO - 2024-03-22 05:16:18 --> Model Class Initialized
DEBUG - 2024-03-22 05:16:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 05:16:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:16:18 --> Config Class Initialized
INFO - 2024-03-22 05:16:18 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:16:18 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:16:18 --> Utf8 Class Initialized
INFO - 2024-03-22 05:16:18 --> URI Class Initialized
INFO - 2024-03-22 05:16:18 --> Router Class Initialized
INFO - 2024-03-22 05:16:18 --> Output Class Initialized
INFO - 2024-03-22 05:16:18 --> Security Class Initialized
DEBUG - 2024-03-22 05:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:16:18 --> Input Class Initialized
INFO - 2024-03-22 05:16:18 --> Language Class Initialized
INFO - 2024-03-22 05:16:18 --> Loader Class Initialized
INFO - 2024-03-22 05:16:18 --> Helper loaded: url_helper
INFO - 2024-03-22 05:16:18 --> Helper loaded: file_helper
INFO - 2024-03-22 05:16:18 --> Helper loaded: html_helper
INFO - 2024-03-22 05:16:18 --> Helper loaded: text_helper
INFO - 2024-03-22 05:16:18 --> Helper loaded: form_helper
INFO - 2024-03-22 05:16:18 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:16:18 --> Helper loaded: security_helper
INFO - 2024-03-22 05:16:18 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:16:18 --> Database Driver Class Initialized
INFO - 2024-03-22 05:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:16:18 --> Parser Class Initialized
INFO - 2024-03-22 05:16:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:16:18 --> Pagination Class Initialized
INFO - 2024-03-22 05:16:18 --> Form Validation Class Initialized
INFO - 2024-03-22 05:16:18 --> Controller Class Initialized
INFO - 2024-03-22 05:16:18 --> Model Class Initialized
DEBUG - 2024-03-22 05:16:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:16:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-22 05:16:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:16:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 05:16:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 05:16:18 --> Model Class Initialized
INFO - 2024-03-22 05:16:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 05:16:18 --> Final output sent to browser
DEBUG - 2024-03-22 05:16:18 --> Total execution time: 0.0334
ERROR - 2024-03-22 05:16:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:16:22 --> Config Class Initialized
INFO - 2024-03-22 05:16:22 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:16:22 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:16:22 --> Utf8 Class Initialized
INFO - 2024-03-22 05:16:22 --> URI Class Initialized
INFO - 2024-03-22 05:16:22 --> Router Class Initialized
INFO - 2024-03-22 05:16:22 --> Output Class Initialized
INFO - 2024-03-22 05:16:22 --> Security Class Initialized
DEBUG - 2024-03-22 05:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:16:22 --> Input Class Initialized
INFO - 2024-03-22 05:16:22 --> Language Class Initialized
INFO - 2024-03-22 05:16:22 --> Loader Class Initialized
INFO - 2024-03-22 05:16:22 --> Helper loaded: url_helper
INFO - 2024-03-22 05:16:22 --> Helper loaded: file_helper
INFO - 2024-03-22 05:16:22 --> Helper loaded: html_helper
INFO - 2024-03-22 05:16:22 --> Helper loaded: text_helper
INFO - 2024-03-22 05:16:22 --> Helper loaded: form_helper
INFO - 2024-03-22 05:16:22 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:16:22 --> Helper loaded: security_helper
INFO - 2024-03-22 05:16:22 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:16:22 --> Database Driver Class Initialized
INFO - 2024-03-22 05:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:16:22 --> Parser Class Initialized
INFO - 2024-03-22 05:16:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:16:22 --> Pagination Class Initialized
INFO - 2024-03-22 05:16:22 --> Form Validation Class Initialized
INFO - 2024-03-22 05:16:22 --> Controller Class Initialized
INFO - 2024-03-22 05:16:22 --> Model Class Initialized
DEBUG - 2024-03-22 05:16:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:16:22 --> Model Class Initialized
INFO - 2024-03-22 05:16:22 --> Final output sent to browser
DEBUG - 2024-03-22 05:16:22 --> Total execution time: 0.0195
ERROR - 2024-03-22 05:16:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:16:22 --> Config Class Initialized
INFO - 2024-03-22 05:16:22 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:16:22 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:16:22 --> Utf8 Class Initialized
INFO - 2024-03-22 05:16:22 --> URI Class Initialized
DEBUG - 2024-03-22 05:16:22 --> No URI present. Default controller set.
INFO - 2024-03-22 05:16:22 --> Router Class Initialized
INFO - 2024-03-22 05:16:22 --> Output Class Initialized
INFO - 2024-03-22 05:16:22 --> Security Class Initialized
DEBUG - 2024-03-22 05:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:16:22 --> Input Class Initialized
INFO - 2024-03-22 05:16:22 --> Language Class Initialized
INFO - 2024-03-22 05:16:22 --> Loader Class Initialized
INFO - 2024-03-22 05:16:22 --> Helper loaded: url_helper
INFO - 2024-03-22 05:16:22 --> Helper loaded: file_helper
INFO - 2024-03-22 05:16:22 --> Helper loaded: html_helper
INFO - 2024-03-22 05:16:22 --> Helper loaded: text_helper
INFO - 2024-03-22 05:16:22 --> Helper loaded: form_helper
INFO - 2024-03-22 05:16:22 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:16:22 --> Helper loaded: security_helper
INFO - 2024-03-22 05:16:22 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:16:22 --> Database Driver Class Initialized
INFO - 2024-03-22 05:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:16:22 --> Parser Class Initialized
INFO - 2024-03-22 05:16:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:16:22 --> Pagination Class Initialized
INFO - 2024-03-22 05:16:22 --> Form Validation Class Initialized
INFO - 2024-03-22 05:16:22 --> Controller Class Initialized
INFO - 2024-03-22 05:16:22 --> Model Class Initialized
DEBUG - 2024-03-22 05:16:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:16:22 --> Model Class Initialized
DEBUG - 2024-03-22 05:16:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:16:22 --> Model Class Initialized
INFO - 2024-03-22 05:16:22 --> Model Class Initialized
INFO - 2024-03-22 05:16:22 --> Model Class Initialized
INFO - 2024-03-22 05:16:22 --> Model Class Initialized
DEBUG - 2024-03-22 05:16:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:16:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:16:22 --> Model Class Initialized
INFO - 2024-03-22 05:16:22 --> Model Class Initialized
INFO - 2024-03-22 05:16:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 05:16:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:16:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 05:16:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 05:16:23 --> Model Class Initialized
INFO - 2024-03-22 05:16:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 05:16:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 05:16:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 05:16:23 --> Final output sent to browser
DEBUG - 2024-03-22 05:16:23 --> Total execution time: 0.4387
ERROR - 2024-03-22 05:16:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:16:24 --> Config Class Initialized
INFO - 2024-03-22 05:16:24 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:16:24 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:16:24 --> Utf8 Class Initialized
INFO - 2024-03-22 05:16:24 --> URI Class Initialized
INFO - 2024-03-22 05:16:24 --> Router Class Initialized
INFO - 2024-03-22 05:16:24 --> Output Class Initialized
INFO - 2024-03-22 05:16:24 --> Security Class Initialized
DEBUG - 2024-03-22 05:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:16:24 --> Input Class Initialized
INFO - 2024-03-22 05:16:24 --> Language Class Initialized
INFO - 2024-03-22 05:16:24 --> Loader Class Initialized
INFO - 2024-03-22 05:16:24 --> Helper loaded: url_helper
INFO - 2024-03-22 05:16:24 --> Helper loaded: file_helper
INFO - 2024-03-22 05:16:24 --> Helper loaded: html_helper
INFO - 2024-03-22 05:16:24 --> Helper loaded: text_helper
INFO - 2024-03-22 05:16:24 --> Helper loaded: form_helper
INFO - 2024-03-22 05:16:24 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:16:24 --> Helper loaded: security_helper
INFO - 2024-03-22 05:16:24 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:16:24 --> Database Driver Class Initialized
INFO - 2024-03-22 05:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:16:24 --> Parser Class Initialized
INFO - 2024-03-22 05:16:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:16:24 --> Pagination Class Initialized
INFO - 2024-03-22 05:16:24 --> Form Validation Class Initialized
INFO - 2024-03-22 05:16:24 --> Controller Class Initialized
DEBUG - 2024-03-22 05:16:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:16:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:16:24 --> Model Class Initialized
INFO - 2024-03-22 05:16:24 --> Final output sent to browser
DEBUG - 2024-03-22 05:16:24 --> Total execution time: 0.0154
ERROR - 2024-03-22 05:16:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:16:30 --> Config Class Initialized
INFO - 2024-03-22 05:16:30 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:16:30 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:16:30 --> Utf8 Class Initialized
INFO - 2024-03-22 05:16:30 --> URI Class Initialized
INFO - 2024-03-22 05:16:30 --> Router Class Initialized
INFO - 2024-03-22 05:16:30 --> Output Class Initialized
INFO - 2024-03-22 05:16:30 --> Security Class Initialized
DEBUG - 2024-03-22 05:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:16:30 --> Input Class Initialized
INFO - 2024-03-22 05:16:30 --> Language Class Initialized
INFO - 2024-03-22 05:16:30 --> Loader Class Initialized
INFO - 2024-03-22 05:16:30 --> Helper loaded: url_helper
INFO - 2024-03-22 05:16:30 --> Helper loaded: file_helper
INFO - 2024-03-22 05:16:30 --> Helper loaded: html_helper
INFO - 2024-03-22 05:16:30 --> Helper loaded: text_helper
INFO - 2024-03-22 05:16:30 --> Helper loaded: form_helper
INFO - 2024-03-22 05:16:30 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:16:30 --> Helper loaded: security_helper
INFO - 2024-03-22 05:16:30 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:16:30 --> Database Driver Class Initialized
INFO - 2024-03-22 05:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:16:30 --> Parser Class Initialized
INFO - 2024-03-22 05:16:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:16:30 --> Pagination Class Initialized
INFO - 2024-03-22 05:16:30 --> Form Validation Class Initialized
INFO - 2024-03-22 05:16:30 --> Controller Class Initialized
INFO - 2024-03-22 05:16:30 --> Model Class Initialized
DEBUG - 2024-03-22 05:16:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:16:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:16:30 --> Model Class Initialized
DEBUG - 2024-03-22 05:16:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:16:30 --> Model Class Initialized
INFO - 2024-03-22 05:16:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-22 05:16:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:16:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 05:16:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 05:16:30 --> Model Class Initialized
INFO - 2024-03-22 05:16:30 --> Model Class Initialized
INFO - 2024-03-22 05:16:30 --> Model Class Initialized
INFO - 2024-03-22 05:16:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 05:16:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 05:16:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 05:16:31 --> Final output sent to browser
DEBUG - 2024-03-22 05:16:31 --> Total execution time: 0.2523
ERROR - 2024-03-22 05:16:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:16:31 --> Config Class Initialized
INFO - 2024-03-22 05:16:31 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:16:31 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:16:31 --> Utf8 Class Initialized
INFO - 2024-03-22 05:16:31 --> URI Class Initialized
INFO - 2024-03-22 05:16:31 --> Router Class Initialized
INFO - 2024-03-22 05:16:31 --> Output Class Initialized
INFO - 2024-03-22 05:16:31 --> Security Class Initialized
DEBUG - 2024-03-22 05:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:16:31 --> Input Class Initialized
INFO - 2024-03-22 05:16:31 --> Language Class Initialized
INFO - 2024-03-22 05:16:31 --> Loader Class Initialized
INFO - 2024-03-22 05:16:31 --> Helper loaded: url_helper
INFO - 2024-03-22 05:16:31 --> Helper loaded: file_helper
INFO - 2024-03-22 05:16:31 --> Helper loaded: html_helper
INFO - 2024-03-22 05:16:31 --> Helper loaded: text_helper
INFO - 2024-03-22 05:16:31 --> Helper loaded: form_helper
INFO - 2024-03-22 05:16:31 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:16:31 --> Helper loaded: security_helper
INFO - 2024-03-22 05:16:31 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:16:31 --> Database Driver Class Initialized
INFO - 2024-03-22 05:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:16:31 --> Parser Class Initialized
INFO - 2024-03-22 05:16:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:16:31 --> Pagination Class Initialized
INFO - 2024-03-22 05:16:31 --> Form Validation Class Initialized
INFO - 2024-03-22 05:16:31 --> Controller Class Initialized
INFO - 2024-03-22 05:16:31 --> Model Class Initialized
DEBUG - 2024-03-22 05:16:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:16:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:16:31 --> Model Class Initialized
DEBUG - 2024-03-22 05:16:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:16:31 --> Model Class Initialized
INFO - 2024-03-22 05:16:31 --> Final output sent to browser
DEBUG - 2024-03-22 05:16:31 --> Total execution time: 0.0598
ERROR - 2024-03-22 05:16:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:16:34 --> Config Class Initialized
INFO - 2024-03-22 05:16:34 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:16:34 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:16:34 --> Utf8 Class Initialized
INFO - 2024-03-22 05:16:34 --> URI Class Initialized
INFO - 2024-03-22 05:16:34 --> Router Class Initialized
INFO - 2024-03-22 05:16:34 --> Output Class Initialized
INFO - 2024-03-22 05:16:34 --> Security Class Initialized
DEBUG - 2024-03-22 05:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:16:34 --> Input Class Initialized
INFO - 2024-03-22 05:16:34 --> Language Class Initialized
INFO - 2024-03-22 05:16:34 --> Loader Class Initialized
INFO - 2024-03-22 05:16:34 --> Helper loaded: url_helper
INFO - 2024-03-22 05:16:34 --> Helper loaded: file_helper
INFO - 2024-03-22 05:16:34 --> Helper loaded: html_helper
INFO - 2024-03-22 05:16:34 --> Helper loaded: text_helper
INFO - 2024-03-22 05:16:34 --> Helper loaded: form_helper
INFO - 2024-03-22 05:16:34 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:16:34 --> Helper loaded: security_helper
INFO - 2024-03-22 05:16:34 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:16:34 --> Database Driver Class Initialized
INFO - 2024-03-22 05:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:16:34 --> Parser Class Initialized
INFO - 2024-03-22 05:16:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:16:34 --> Pagination Class Initialized
INFO - 2024-03-22 05:16:34 --> Form Validation Class Initialized
INFO - 2024-03-22 05:16:34 --> Controller Class Initialized
INFO - 2024-03-22 05:16:34 --> Model Class Initialized
DEBUG - 2024-03-22 05:16:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:16:34 --> Model Class Initialized
DEBUG - 2024-03-22 05:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:16:34 --> Model Class Initialized
INFO - 2024-03-22 05:16:35 --> Final output sent to browser
DEBUG - 2024-03-22 05:16:35 --> Total execution time: 1.5435
ERROR - 2024-03-22 05:16:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:16:49 --> Config Class Initialized
INFO - 2024-03-22 05:16:49 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:16:49 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:16:49 --> Utf8 Class Initialized
INFO - 2024-03-22 05:16:49 --> URI Class Initialized
INFO - 2024-03-22 05:16:49 --> Router Class Initialized
INFO - 2024-03-22 05:16:49 --> Output Class Initialized
INFO - 2024-03-22 05:16:49 --> Security Class Initialized
DEBUG - 2024-03-22 05:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:16:49 --> Input Class Initialized
INFO - 2024-03-22 05:16:49 --> Language Class Initialized
INFO - 2024-03-22 05:16:49 --> Loader Class Initialized
INFO - 2024-03-22 05:16:49 --> Helper loaded: url_helper
INFO - 2024-03-22 05:16:49 --> Helper loaded: file_helper
INFO - 2024-03-22 05:16:49 --> Helper loaded: html_helper
INFO - 2024-03-22 05:16:49 --> Helper loaded: text_helper
INFO - 2024-03-22 05:16:49 --> Helper loaded: form_helper
INFO - 2024-03-22 05:16:49 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:16:49 --> Helper loaded: security_helper
INFO - 2024-03-22 05:16:49 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:16:49 --> Database Driver Class Initialized
INFO - 2024-03-22 05:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:16:49 --> Parser Class Initialized
INFO - 2024-03-22 05:16:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:16:49 --> Pagination Class Initialized
INFO - 2024-03-22 05:16:49 --> Form Validation Class Initialized
INFO - 2024-03-22 05:16:49 --> Controller Class Initialized
INFO - 2024-03-22 05:16:49 --> Model Class Initialized
DEBUG - 2024-03-22 05:16:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:16:49 --> Final output sent to browser
DEBUG - 2024-03-22 05:16:49 --> Total execution time: 0.0147
ERROR - 2024-03-22 05:16:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:16:49 --> Config Class Initialized
INFO - 2024-03-22 05:16:49 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:16:49 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:16:49 --> Utf8 Class Initialized
INFO - 2024-03-22 05:16:49 --> URI Class Initialized
INFO - 2024-03-22 05:16:49 --> Router Class Initialized
INFO - 2024-03-22 05:16:49 --> Output Class Initialized
INFO - 2024-03-22 05:16:49 --> Security Class Initialized
DEBUG - 2024-03-22 05:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:16:49 --> Input Class Initialized
INFO - 2024-03-22 05:16:49 --> Language Class Initialized
INFO - 2024-03-22 05:16:49 --> Loader Class Initialized
INFO - 2024-03-22 05:16:49 --> Helper loaded: url_helper
INFO - 2024-03-22 05:16:49 --> Helper loaded: file_helper
INFO - 2024-03-22 05:16:49 --> Helper loaded: html_helper
INFO - 2024-03-22 05:16:49 --> Helper loaded: text_helper
INFO - 2024-03-22 05:16:49 --> Helper loaded: form_helper
INFO - 2024-03-22 05:16:49 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:16:49 --> Helper loaded: security_helper
INFO - 2024-03-22 05:16:49 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:16:49 --> Database Driver Class Initialized
INFO - 2024-03-22 05:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:16:49 --> Parser Class Initialized
INFO - 2024-03-22 05:16:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:16:49 --> Pagination Class Initialized
INFO - 2024-03-22 05:16:49 --> Form Validation Class Initialized
INFO - 2024-03-22 05:16:49 --> Controller Class Initialized
INFO - 2024-03-22 05:16:49 --> Model Class Initialized
DEBUG - 2024-03-22 05:16:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:16:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-22 05:16:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:16:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 05:16:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 05:16:49 --> Model Class Initialized
INFO - 2024-03-22 05:16:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 05:16:49 --> Final output sent to browser
DEBUG - 2024-03-22 05:16:49 --> Total execution time: 0.0343
ERROR - 2024-03-22 05:17:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:17:01 --> Config Class Initialized
INFO - 2024-03-22 05:17:01 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:17:01 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:17:01 --> Utf8 Class Initialized
INFO - 2024-03-22 05:17:01 --> URI Class Initialized
INFO - 2024-03-22 05:17:01 --> Router Class Initialized
INFO - 2024-03-22 05:17:01 --> Output Class Initialized
INFO - 2024-03-22 05:17:01 --> Security Class Initialized
DEBUG - 2024-03-22 05:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:17:01 --> Input Class Initialized
INFO - 2024-03-22 05:17:01 --> Language Class Initialized
INFO - 2024-03-22 05:17:01 --> Loader Class Initialized
INFO - 2024-03-22 05:17:01 --> Helper loaded: url_helper
INFO - 2024-03-22 05:17:01 --> Helper loaded: file_helper
INFO - 2024-03-22 05:17:01 --> Helper loaded: html_helper
INFO - 2024-03-22 05:17:01 --> Helper loaded: text_helper
INFO - 2024-03-22 05:17:01 --> Helper loaded: form_helper
INFO - 2024-03-22 05:17:01 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:17:01 --> Helper loaded: security_helper
INFO - 2024-03-22 05:17:01 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:17:01 --> Database Driver Class Initialized
INFO - 2024-03-22 05:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:17:01 --> Parser Class Initialized
INFO - 2024-03-22 05:17:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:17:01 --> Pagination Class Initialized
INFO - 2024-03-22 05:17:01 --> Form Validation Class Initialized
INFO - 2024-03-22 05:17:01 --> Controller Class Initialized
INFO - 2024-03-22 05:17:01 --> Model Class Initialized
DEBUG - 2024-03-22 05:17:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:17:01 --> Model Class Initialized
INFO - 2024-03-22 05:17:01 --> Final output sent to browser
DEBUG - 2024-03-22 05:17:01 --> Total execution time: 0.0200
ERROR - 2024-03-22 05:17:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:17:02 --> Config Class Initialized
INFO - 2024-03-22 05:17:02 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:17:02 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:17:02 --> Utf8 Class Initialized
INFO - 2024-03-22 05:17:02 --> URI Class Initialized
DEBUG - 2024-03-22 05:17:02 --> No URI present. Default controller set.
INFO - 2024-03-22 05:17:02 --> Router Class Initialized
INFO - 2024-03-22 05:17:02 --> Output Class Initialized
INFO - 2024-03-22 05:17:02 --> Security Class Initialized
DEBUG - 2024-03-22 05:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:17:02 --> Input Class Initialized
INFO - 2024-03-22 05:17:02 --> Language Class Initialized
INFO - 2024-03-22 05:17:02 --> Loader Class Initialized
INFO - 2024-03-22 05:17:02 --> Helper loaded: url_helper
INFO - 2024-03-22 05:17:02 --> Helper loaded: file_helper
INFO - 2024-03-22 05:17:02 --> Helper loaded: html_helper
INFO - 2024-03-22 05:17:02 --> Helper loaded: text_helper
INFO - 2024-03-22 05:17:02 --> Helper loaded: form_helper
INFO - 2024-03-22 05:17:02 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:17:02 --> Helper loaded: security_helper
INFO - 2024-03-22 05:17:02 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:17:02 --> Database Driver Class Initialized
INFO - 2024-03-22 05:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:17:02 --> Parser Class Initialized
INFO - 2024-03-22 05:17:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:17:02 --> Pagination Class Initialized
INFO - 2024-03-22 05:17:02 --> Form Validation Class Initialized
INFO - 2024-03-22 05:17:02 --> Controller Class Initialized
INFO - 2024-03-22 05:17:02 --> Model Class Initialized
DEBUG - 2024-03-22 05:17:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:17:02 --> Model Class Initialized
DEBUG - 2024-03-22 05:17:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:17:02 --> Model Class Initialized
INFO - 2024-03-22 05:17:02 --> Model Class Initialized
INFO - 2024-03-22 05:17:02 --> Model Class Initialized
INFO - 2024-03-22 05:17:02 --> Model Class Initialized
DEBUG - 2024-03-22 05:17:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:17:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:17:02 --> Model Class Initialized
INFO - 2024-03-22 05:17:02 --> Model Class Initialized
INFO - 2024-03-22 05:17:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 05:17:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:17:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 05:17:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 05:17:02 --> Model Class Initialized
INFO - 2024-03-22 05:17:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 05:17:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 05:17:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 05:17:02 --> Final output sent to browser
DEBUG - 2024-03-22 05:17:02 --> Total execution time: 0.2649
ERROR - 2024-03-22 05:17:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:17:06 --> Config Class Initialized
INFO - 2024-03-22 05:17:06 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:17:06 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:17:06 --> Utf8 Class Initialized
INFO - 2024-03-22 05:17:06 --> URI Class Initialized
INFO - 2024-03-22 05:17:06 --> Router Class Initialized
INFO - 2024-03-22 05:17:06 --> Output Class Initialized
INFO - 2024-03-22 05:17:06 --> Security Class Initialized
DEBUG - 2024-03-22 05:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:17:06 --> Input Class Initialized
INFO - 2024-03-22 05:17:06 --> Language Class Initialized
INFO - 2024-03-22 05:17:06 --> Loader Class Initialized
INFO - 2024-03-22 05:17:06 --> Helper loaded: url_helper
INFO - 2024-03-22 05:17:06 --> Helper loaded: file_helper
INFO - 2024-03-22 05:17:06 --> Helper loaded: html_helper
INFO - 2024-03-22 05:17:06 --> Helper loaded: text_helper
INFO - 2024-03-22 05:17:06 --> Helper loaded: form_helper
INFO - 2024-03-22 05:17:06 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:17:06 --> Helper loaded: security_helper
INFO - 2024-03-22 05:17:06 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:17:06 --> Database Driver Class Initialized
INFO - 2024-03-22 05:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:17:06 --> Parser Class Initialized
INFO - 2024-03-22 05:17:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:17:06 --> Pagination Class Initialized
INFO - 2024-03-22 05:17:06 --> Form Validation Class Initialized
INFO - 2024-03-22 05:17:06 --> Controller Class Initialized
INFO - 2024-03-22 05:17:06 --> Model Class Initialized
DEBUG - 2024-03-22 05:17:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:17:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:17:06 --> Model Class Initialized
DEBUG - 2024-03-22 05:17:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:17:06 --> Model Class Initialized
INFO - 2024-03-22 05:17:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-22 05:17:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:17:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 05:17:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 05:17:06 --> Model Class Initialized
INFO - 2024-03-22 05:17:06 --> Model Class Initialized
INFO - 2024-03-22 05:17:06 --> Model Class Initialized
INFO - 2024-03-22 05:17:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 05:17:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 05:17:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 05:17:06 --> Final output sent to browser
DEBUG - 2024-03-22 05:17:06 --> Total execution time: 0.1610
ERROR - 2024-03-22 05:17:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:17:06 --> Config Class Initialized
INFO - 2024-03-22 05:17:06 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:17:06 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:17:06 --> Utf8 Class Initialized
INFO - 2024-03-22 05:17:06 --> URI Class Initialized
INFO - 2024-03-22 05:17:06 --> Router Class Initialized
INFO - 2024-03-22 05:17:06 --> Output Class Initialized
INFO - 2024-03-22 05:17:06 --> Security Class Initialized
DEBUG - 2024-03-22 05:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:17:06 --> Input Class Initialized
INFO - 2024-03-22 05:17:06 --> Language Class Initialized
INFO - 2024-03-22 05:17:06 --> Loader Class Initialized
INFO - 2024-03-22 05:17:06 --> Helper loaded: url_helper
INFO - 2024-03-22 05:17:06 --> Helper loaded: file_helper
INFO - 2024-03-22 05:17:06 --> Helper loaded: html_helper
INFO - 2024-03-22 05:17:06 --> Helper loaded: text_helper
INFO - 2024-03-22 05:17:06 --> Helper loaded: form_helper
INFO - 2024-03-22 05:17:06 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:17:06 --> Helper loaded: security_helper
INFO - 2024-03-22 05:17:06 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:17:06 --> Database Driver Class Initialized
INFO - 2024-03-22 05:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:17:06 --> Parser Class Initialized
INFO - 2024-03-22 05:17:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:17:06 --> Pagination Class Initialized
INFO - 2024-03-22 05:17:06 --> Form Validation Class Initialized
INFO - 2024-03-22 05:17:06 --> Controller Class Initialized
INFO - 2024-03-22 05:17:06 --> Model Class Initialized
DEBUG - 2024-03-22 05:17:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:17:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:17:06 --> Model Class Initialized
DEBUG - 2024-03-22 05:17:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:17:06 --> Model Class Initialized
INFO - 2024-03-22 05:17:06 --> Final output sent to browser
DEBUG - 2024-03-22 05:17:06 --> Total execution time: 0.0465
ERROR - 2024-03-22 05:17:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:17:13 --> Config Class Initialized
INFO - 2024-03-22 05:17:13 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:17:13 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:17:13 --> Utf8 Class Initialized
INFO - 2024-03-22 05:17:13 --> URI Class Initialized
INFO - 2024-03-22 05:17:13 --> Router Class Initialized
INFO - 2024-03-22 05:17:13 --> Output Class Initialized
INFO - 2024-03-22 05:17:13 --> Security Class Initialized
DEBUG - 2024-03-22 05:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:17:13 --> Input Class Initialized
INFO - 2024-03-22 05:17:13 --> Language Class Initialized
INFO - 2024-03-22 05:17:13 --> Loader Class Initialized
INFO - 2024-03-22 05:17:13 --> Helper loaded: url_helper
INFO - 2024-03-22 05:17:13 --> Helper loaded: file_helper
INFO - 2024-03-22 05:17:13 --> Helper loaded: html_helper
INFO - 2024-03-22 05:17:13 --> Helper loaded: text_helper
INFO - 2024-03-22 05:17:13 --> Helper loaded: form_helper
INFO - 2024-03-22 05:17:13 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:17:13 --> Helper loaded: security_helper
INFO - 2024-03-22 05:17:13 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:17:13 --> Database Driver Class Initialized
INFO - 2024-03-22 05:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:17:13 --> Parser Class Initialized
INFO - 2024-03-22 05:17:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:17:13 --> Pagination Class Initialized
INFO - 2024-03-22 05:17:13 --> Form Validation Class Initialized
INFO - 2024-03-22 05:17:13 --> Controller Class Initialized
INFO - 2024-03-22 05:17:13 --> Model Class Initialized
DEBUG - 2024-03-22 05:17:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:17:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:17:13 --> Model Class Initialized
DEBUG - 2024-03-22 05:17:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:17:13 --> Model Class Initialized
INFO - 2024-03-22 05:17:13 --> Final output sent to browser
DEBUG - 2024-03-22 05:17:13 --> Total execution time: 0.0415
ERROR - 2024-03-22 05:17:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:17:16 --> Config Class Initialized
INFO - 2024-03-22 05:17:16 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:17:16 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:17:16 --> Utf8 Class Initialized
INFO - 2024-03-22 05:17:16 --> URI Class Initialized
INFO - 2024-03-22 05:17:16 --> Router Class Initialized
INFO - 2024-03-22 05:17:16 --> Output Class Initialized
INFO - 2024-03-22 05:17:16 --> Security Class Initialized
DEBUG - 2024-03-22 05:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:17:16 --> Input Class Initialized
INFO - 2024-03-22 05:17:16 --> Language Class Initialized
INFO - 2024-03-22 05:17:16 --> Loader Class Initialized
INFO - 2024-03-22 05:17:16 --> Helper loaded: url_helper
INFO - 2024-03-22 05:17:16 --> Helper loaded: file_helper
INFO - 2024-03-22 05:17:16 --> Helper loaded: html_helper
INFO - 2024-03-22 05:17:16 --> Helper loaded: text_helper
INFO - 2024-03-22 05:17:16 --> Helper loaded: form_helper
INFO - 2024-03-22 05:17:16 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:17:16 --> Helper loaded: security_helper
INFO - 2024-03-22 05:17:16 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:17:16 --> Database Driver Class Initialized
INFO - 2024-03-22 05:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:17:16 --> Parser Class Initialized
INFO - 2024-03-22 05:17:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:17:16 --> Pagination Class Initialized
INFO - 2024-03-22 05:17:16 --> Form Validation Class Initialized
INFO - 2024-03-22 05:17:16 --> Controller Class Initialized
INFO - 2024-03-22 05:17:16 --> Model Class Initialized
DEBUG - 2024-03-22 05:17:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:17:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:17:16 --> Model Class Initialized
DEBUG - 2024-03-22 05:17:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:17:16 --> Model Class Initialized
INFO - 2024-03-22 05:17:16 --> Final output sent to browser
DEBUG - 2024-03-22 05:17:16 --> Total execution time: 0.0630
ERROR - 2024-03-22 05:50:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:50:54 --> Config Class Initialized
INFO - 2024-03-22 05:50:54 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:50:54 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:50:54 --> Utf8 Class Initialized
INFO - 2024-03-22 05:50:54 --> URI Class Initialized
DEBUG - 2024-03-22 05:50:54 --> No URI present. Default controller set.
INFO - 2024-03-22 05:50:54 --> Router Class Initialized
INFO - 2024-03-22 05:50:54 --> Output Class Initialized
INFO - 2024-03-22 05:50:54 --> Security Class Initialized
DEBUG - 2024-03-22 05:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:50:54 --> Input Class Initialized
INFO - 2024-03-22 05:50:54 --> Language Class Initialized
INFO - 2024-03-22 05:50:54 --> Loader Class Initialized
INFO - 2024-03-22 05:50:54 --> Helper loaded: url_helper
INFO - 2024-03-22 05:50:54 --> Helper loaded: file_helper
INFO - 2024-03-22 05:50:54 --> Helper loaded: html_helper
INFO - 2024-03-22 05:50:54 --> Helper loaded: text_helper
INFO - 2024-03-22 05:50:54 --> Helper loaded: form_helper
INFO - 2024-03-22 05:50:54 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:50:54 --> Helper loaded: security_helper
INFO - 2024-03-22 05:50:54 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:50:54 --> Database Driver Class Initialized
INFO - 2024-03-22 05:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:50:54 --> Parser Class Initialized
INFO - 2024-03-22 05:50:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:50:54 --> Pagination Class Initialized
INFO - 2024-03-22 05:50:54 --> Form Validation Class Initialized
INFO - 2024-03-22 05:50:54 --> Controller Class Initialized
INFO - 2024-03-22 05:50:54 --> Model Class Initialized
DEBUG - 2024-03-22 05:50:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:50:54 --> Model Class Initialized
DEBUG - 2024-03-22 05:50:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:50:54 --> Model Class Initialized
INFO - 2024-03-22 05:50:54 --> Model Class Initialized
INFO - 2024-03-22 05:50:54 --> Model Class Initialized
INFO - 2024-03-22 05:50:54 --> Model Class Initialized
DEBUG - 2024-03-22 05:50:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:50:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:50:54 --> Model Class Initialized
INFO - 2024-03-22 05:50:54 --> Model Class Initialized
INFO - 2024-03-22 05:50:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 05:50:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:50:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 05:50:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 05:50:54 --> Model Class Initialized
INFO - 2024-03-22 05:50:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 05:50:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 05:50:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 05:50:54 --> Final output sent to browser
DEBUG - 2024-03-22 05:50:54 --> Total execution time: 0.2864
ERROR - 2024-03-22 05:51:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:51:04 --> Config Class Initialized
INFO - 2024-03-22 05:51:04 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:51:04 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:51:04 --> Utf8 Class Initialized
INFO - 2024-03-22 05:51:04 --> URI Class Initialized
INFO - 2024-03-22 05:51:04 --> Router Class Initialized
INFO - 2024-03-22 05:51:04 --> Output Class Initialized
INFO - 2024-03-22 05:51:04 --> Security Class Initialized
DEBUG - 2024-03-22 05:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:51:04 --> Input Class Initialized
INFO - 2024-03-22 05:51:04 --> Language Class Initialized
INFO - 2024-03-22 05:51:04 --> Loader Class Initialized
INFO - 2024-03-22 05:51:04 --> Helper loaded: url_helper
INFO - 2024-03-22 05:51:04 --> Helper loaded: file_helper
INFO - 2024-03-22 05:51:04 --> Helper loaded: html_helper
INFO - 2024-03-22 05:51:04 --> Helper loaded: text_helper
INFO - 2024-03-22 05:51:04 --> Helper loaded: form_helper
INFO - 2024-03-22 05:51:04 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:51:04 --> Helper loaded: security_helper
INFO - 2024-03-22 05:51:04 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:51:04 --> Database Driver Class Initialized
INFO - 2024-03-22 05:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:51:04 --> Parser Class Initialized
INFO - 2024-03-22 05:51:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:51:04 --> Pagination Class Initialized
INFO - 2024-03-22 05:51:04 --> Form Validation Class Initialized
INFO - 2024-03-22 05:51:04 --> Controller Class Initialized
INFO - 2024-03-22 05:51:04 --> Model Class Initialized
DEBUG - 2024-03-22 05:51:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:51:04 --> Final output sent to browser
DEBUG - 2024-03-22 05:51:04 --> Total execution time: 0.0132
ERROR - 2024-03-22 05:51:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:51:05 --> Config Class Initialized
INFO - 2024-03-22 05:51:05 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:51:05 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:51:05 --> Utf8 Class Initialized
INFO - 2024-03-22 05:51:05 --> URI Class Initialized
INFO - 2024-03-22 05:51:05 --> Router Class Initialized
INFO - 2024-03-22 05:51:05 --> Output Class Initialized
INFO - 2024-03-22 05:51:05 --> Security Class Initialized
DEBUG - 2024-03-22 05:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:51:05 --> Input Class Initialized
INFO - 2024-03-22 05:51:05 --> Language Class Initialized
INFO - 2024-03-22 05:51:05 --> Loader Class Initialized
INFO - 2024-03-22 05:51:05 --> Helper loaded: url_helper
INFO - 2024-03-22 05:51:05 --> Helper loaded: file_helper
INFO - 2024-03-22 05:51:05 --> Helper loaded: html_helper
INFO - 2024-03-22 05:51:05 --> Helper loaded: text_helper
INFO - 2024-03-22 05:51:05 --> Helper loaded: form_helper
INFO - 2024-03-22 05:51:05 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:51:05 --> Helper loaded: security_helper
INFO - 2024-03-22 05:51:05 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:51:05 --> Database Driver Class Initialized
INFO - 2024-03-22 05:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:51:05 --> Parser Class Initialized
INFO - 2024-03-22 05:51:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:51:05 --> Pagination Class Initialized
INFO - 2024-03-22 05:51:05 --> Form Validation Class Initialized
INFO - 2024-03-22 05:51:05 --> Controller Class Initialized
INFO - 2024-03-22 05:51:05 --> Model Class Initialized
DEBUG - 2024-03-22 05:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-22 05:51:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 05:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 05:51:05 --> Model Class Initialized
INFO - 2024-03-22 05:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 05:51:05 --> Final output sent to browser
DEBUG - 2024-03-22 05:51:05 --> Total execution time: 0.0396
ERROR - 2024-03-22 05:51:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:51:15 --> Config Class Initialized
INFO - 2024-03-22 05:51:15 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:51:15 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:51:15 --> Utf8 Class Initialized
INFO - 2024-03-22 05:51:15 --> URI Class Initialized
INFO - 2024-03-22 05:51:15 --> Router Class Initialized
INFO - 2024-03-22 05:51:15 --> Output Class Initialized
INFO - 2024-03-22 05:51:15 --> Security Class Initialized
DEBUG - 2024-03-22 05:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:51:15 --> Input Class Initialized
INFO - 2024-03-22 05:51:15 --> Language Class Initialized
INFO - 2024-03-22 05:51:15 --> Loader Class Initialized
INFO - 2024-03-22 05:51:15 --> Helper loaded: url_helper
INFO - 2024-03-22 05:51:15 --> Helper loaded: file_helper
INFO - 2024-03-22 05:51:15 --> Helper loaded: html_helper
INFO - 2024-03-22 05:51:15 --> Helper loaded: text_helper
INFO - 2024-03-22 05:51:15 --> Helper loaded: form_helper
INFO - 2024-03-22 05:51:15 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:51:15 --> Helper loaded: security_helper
INFO - 2024-03-22 05:51:15 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:51:15 --> Database Driver Class Initialized
INFO - 2024-03-22 05:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:51:15 --> Parser Class Initialized
INFO - 2024-03-22 05:51:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:51:15 --> Pagination Class Initialized
INFO - 2024-03-22 05:51:15 --> Form Validation Class Initialized
INFO - 2024-03-22 05:51:15 --> Controller Class Initialized
INFO - 2024-03-22 05:51:15 --> Model Class Initialized
DEBUG - 2024-03-22 05:51:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:51:15 --> Model Class Initialized
INFO - 2024-03-22 05:51:15 --> Final output sent to browser
DEBUG - 2024-03-22 05:51:15 --> Total execution time: 0.0193
ERROR - 2024-03-22 05:51:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:51:15 --> Config Class Initialized
INFO - 2024-03-22 05:51:15 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:51:15 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:51:15 --> Utf8 Class Initialized
INFO - 2024-03-22 05:51:15 --> URI Class Initialized
DEBUG - 2024-03-22 05:51:15 --> No URI present. Default controller set.
INFO - 2024-03-22 05:51:15 --> Router Class Initialized
INFO - 2024-03-22 05:51:15 --> Output Class Initialized
INFO - 2024-03-22 05:51:15 --> Security Class Initialized
DEBUG - 2024-03-22 05:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:51:15 --> Input Class Initialized
INFO - 2024-03-22 05:51:15 --> Language Class Initialized
INFO - 2024-03-22 05:51:15 --> Loader Class Initialized
INFO - 2024-03-22 05:51:15 --> Helper loaded: url_helper
INFO - 2024-03-22 05:51:15 --> Helper loaded: file_helper
INFO - 2024-03-22 05:51:15 --> Helper loaded: html_helper
INFO - 2024-03-22 05:51:15 --> Helper loaded: text_helper
INFO - 2024-03-22 05:51:15 --> Helper loaded: form_helper
INFO - 2024-03-22 05:51:15 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:51:15 --> Helper loaded: security_helper
INFO - 2024-03-22 05:51:15 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:51:15 --> Database Driver Class Initialized
INFO - 2024-03-22 05:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:51:15 --> Parser Class Initialized
INFO - 2024-03-22 05:51:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:51:15 --> Pagination Class Initialized
INFO - 2024-03-22 05:51:15 --> Form Validation Class Initialized
INFO - 2024-03-22 05:51:15 --> Controller Class Initialized
INFO - 2024-03-22 05:51:15 --> Model Class Initialized
DEBUG - 2024-03-22 05:51:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:51:15 --> Model Class Initialized
DEBUG - 2024-03-22 05:51:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:51:15 --> Model Class Initialized
INFO - 2024-03-22 05:51:15 --> Model Class Initialized
INFO - 2024-03-22 05:51:15 --> Model Class Initialized
INFO - 2024-03-22 05:51:15 --> Model Class Initialized
DEBUG - 2024-03-22 05:51:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:51:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:51:15 --> Model Class Initialized
INFO - 2024-03-22 05:51:15 --> Model Class Initialized
INFO - 2024-03-22 05:51:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 05:51:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:51:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 05:51:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 05:51:15 --> Model Class Initialized
INFO - 2024-03-22 05:51:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 05:51:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 05:51:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 05:51:15 --> Final output sent to browser
DEBUG - 2024-03-22 05:51:15 --> Total execution time: 0.2487
ERROR - 2024-03-22 05:51:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:51:20 --> Config Class Initialized
INFO - 2024-03-22 05:51:20 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:51:20 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:51:20 --> Utf8 Class Initialized
INFO - 2024-03-22 05:51:20 --> URI Class Initialized
INFO - 2024-03-22 05:51:20 --> Router Class Initialized
INFO - 2024-03-22 05:51:20 --> Output Class Initialized
INFO - 2024-03-22 05:51:20 --> Security Class Initialized
DEBUG - 2024-03-22 05:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:51:20 --> Input Class Initialized
INFO - 2024-03-22 05:51:20 --> Language Class Initialized
INFO - 2024-03-22 05:51:20 --> Loader Class Initialized
INFO - 2024-03-22 05:51:20 --> Helper loaded: url_helper
INFO - 2024-03-22 05:51:20 --> Helper loaded: file_helper
INFO - 2024-03-22 05:51:20 --> Helper loaded: html_helper
INFO - 2024-03-22 05:51:20 --> Helper loaded: text_helper
INFO - 2024-03-22 05:51:20 --> Helper loaded: form_helper
INFO - 2024-03-22 05:51:20 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:51:20 --> Helper loaded: security_helper
INFO - 2024-03-22 05:51:20 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:51:20 --> Database Driver Class Initialized
INFO - 2024-03-22 05:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:51:20 --> Parser Class Initialized
INFO - 2024-03-22 05:51:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:51:20 --> Pagination Class Initialized
INFO - 2024-03-22 05:51:20 --> Form Validation Class Initialized
INFO - 2024-03-22 05:51:20 --> Controller Class Initialized
INFO - 2024-03-22 05:51:21 --> Model Class Initialized
DEBUG - 2024-03-22 05:51:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:51:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:51:21 --> Model Class Initialized
DEBUG - 2024-03-22 05:51:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:51:21 --> Model Class Initialized
INFO - 2024-03-22 05:51:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-22 05:51:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:51:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 05:51:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 05:51:21 --> Model Class Initialized
INFO - 2024-03-22 05:51:21 --> Model Class Initialized
INFO - 2024-03-22 05:51:21 --> Model Class Initialized
INFO - 2024-03-22 05:51:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 05:51:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 05:51:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 05:51:21 --> Final output sent to browser
DEBUG - 2024-03-22 05:51:21 --> Total execution time: 0.2035
ERROR - 2024-03-22 05:51:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:51:22 --> Config Class Initialized
INFO - 2024-03-22 05:51:22 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:51:22 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:51:22 --> Utf8 Class Initialized
INFO - 2024-03-22 05:51:22 --> URI Class Initialized
INFO - 2024-03-22 05:51:22 --> Router Class Initialized
INFO - 2024-03-22 05:51:22 --> Output Class Initialized
INFO - 2024-03-22 05:51:22 --> Security Class Initialized
DEBUG - 2024-03-22 05:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:51:22 --> Input Class Initialized
INFO - 2024-03-22 05:51:22 --> Language Class Initialized
INFO - 2024-03-22 05:51:22 --> Loader Class Initialized
INFO - 2024-03-22 05:51:22 --> Helper loaded: url_helper
INFO - 2024-03-22 05:51:22 --> Helper loaded: file_helper
INFO - 2024-03-22 05:51:22 --> Helper loaded: html_helper
INFO - 2024-03-22 05:51:22 --> Helper loaded: text_helper
INFO - 2024-03-22 05:51:22 --> Helper loaded: form_helper
INFO - 2024-03-22 05:51:22 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:51:22 --> Helper loaded: security_helper
INFO - 2024-03-22 05:51:22 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:51:22 --> Database Driver Class Initialized
INFO - 2024-03-22 05:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:51:22 --> Parser Class Initialized
INFO - 2024-03-22 05:51:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:51:22 --> Pagination Class Initialized
INFO - 2024-03-22 05:51:22 --> Form Validation Class Initialized
INFO - 2024-03-22 05:51:22 --> Controller Class Initialized
INFO - 2024-03-22 05:51:22 --> Model Class Initialized
DEBUG - 2024-03-22 05:51:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:51:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:51:22 --> Model Class Initialized
DEBUG - 2024-03-22 05:51:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:51:22 --> Model Class Initialized
INFO - 2024-03-22 05:51:22 --> Final output sent to browser
DEBUG - 2024-03-22 05:51:22 --> Total execution time: 0.0485
ERROR - 2024-03-22 05:51:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:51:27 --> Config Class Initialized
INFO - 2024-03-22 05:51:27 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:51:27 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:51:27 --> Utf8 Class Initialized
INFO - 2024-03-22 05:51:27 --> URI Class Initialized
INFO - 2024-03-22 05:51:27 --> Router Class Initialized
INFO - 2024-03-22 05:51:27 --> Output Class Initialized
INFO - 2024-03-22 05:51:27 --> Security Class Initialized
DEBUG - 2024-03-22 05:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:51:27 --> Input Class Initialized
INFO - 2024-03-22 05:51:27 --> Language Class Initialized
INFO - 2024-03-22 05:51:27 --> Loader Class Initialized
INFO - 2024-03-22 05:51:27 --> Helper loaded: url_helper
INFO - 2024-03-22 05:51:27 --> Helper loaded: file_helper
INFO - 2024-03-22 05:51:27 --> Helper loaded: html_helper
INFO - 2024-03-22 05:51:27 --> Helper loaded: text_helper
INFO - 2024-03-22 05:51:27 --> Helper loaded: form_helper
INFO - 2024-03-22 05:51:27 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:51:27 --> Helper loaded: security_helper
INFO - 2024-03-22 05:51:27 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:51:27 --> Database Driver Class Initialized
INFO - 2024-03-22 05:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:51:27 --> Parser Class Initialized
INFO - 2024-03-22 05:51:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:51:27 --> Pagination Class Initialized
INFO - 2024-03-22 05:51:27 --> Form Validation Class Initialized
INFO - 2024-03-22 05:51:27 --> Controller Class Initialized
INFO - 2024-03-22 05:51:27 --> Model Class Initialized
DEBUG - 2024-03-22 05:51:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:51:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:51:27 --> Model Class Initialized
DEBUG - 2024-03-22 05:51:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:51:27 --> Model Class Initialized
INFO - 2024-03-22 05:51:27 --> Final output sent to browser
DEBUG - 2024-03-22 05:51:27 --> Total execution time: 0.2874
ERROR - 2024-03-22 05:52:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:52:11 --> Config Class Initialized
INFO - 2024-03-22 05:52:11 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:52:11 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:52:11 --> Utf8 Class Initialized
INFO - 2024-03-22 05:52:11 --> URI Class Initialized
DEBUG - 2024-03-22 05:52:11 --> No URI present. Default controller set.
INFO - 2024-03-22 05:52:11 --> Router Class Initialized
INFO - 2024-03-22 05:52:11 --> Output Class Initialized
INFO - 2024-03-22 05:52:11 --> Security Class Initialized
DEBUG - 2024-03-22 05:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:52:11 --> Input Class Initialized
INFO - 2024-03-22 05:52:11 --> Language Class Initialized
INFO - 2024-03-22 05:52:11 --> Loader Class Initialized
INFO - 2024-03-22 05:52:11 --> Helper loaded: url_helper
INFO - 2024-03-22 05:52:11 --> Helper loaded: file_helper
INFO - 2024-03-22 05:52:11 --> Helper loaded: html_helper
INFO - 2024-03-22 05:52:11 --> Helper loaded: text_helper
INFO - 2024-03-22 05:52:11 --> Helper loaded: form_helper
INFO - 2024-03-22 05:52:11 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:52:11 --> Helper loaded: security_helper
INFO - 2024-03-22 05:52:11 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:52:11 --> Database Driver Class Initialized
INFO - 2024-03-22 05:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:52:11 --> Parser Class Initialized
INFO - 2024-03-22 05:52:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:52:11 --> Pagination Class Initialized
INFO - 2024-03-22 05:52:11 --> Form Validation Class Initialized
INFO - 2024-03-22 05:52:11 --> Controller Class Initialized
INFO - 2024-03-22 05:52:11 --> Model Class Initialized
DEBUG - 2024-03-22 05:52:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:52:11 --> Model Class Initialized
DEBUG - 2024-03-22 05:52:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:52:11 --> Model Class Initialized
INFO - 2024-03-22 05:52:11 --> Model Class Initialized
INFO - 2024-03-22 05:52:11 --> Model Class Initialized
INFO - 2024-03-22 05:52:11 --> Model Class Initialized
DEBUG - 2024-03-22 05:52:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:52:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:52:11 --> Model Class Initialized
INFO - 2024-03-22 05:52:11 --> Model Class Initialized
INFO - 2024-03-22 05:52:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 05:52:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:52:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 05:52:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 05:52:11 --> Model Class Initialized
INFO - 2024-03-22 05:52:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 05:52:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 05:52:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 05:52:11 --> Final output sent to browser
DEBUG - 2024-03-22 05:52:11 --> Total execution time: 0.2511
ERROR - 2024-03-22 05:52:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:52:24 --> Config Class Initialized
INFO - 2024-03-22 05:52:24 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:52:24 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:52:24 --> Utf8 Class Initialized
INFO - 2024-03-22 05:52:24 --> URI Class Initialized
INFO - 2024-03-22 05:52:24 --> Router Class Initialized
INFO - 2024-03-22 05:52:24 --> Output Class Initialized
INFO - 2024-03-22 05:52:24 --> Security Class Initialized
DEBUG - 2024-03-22 05:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:52:24 --> Input Class Initialized
INFO - 2024-03-22 05:52:24 --> Language Class Initialized
INFO - 2024-03-22 05:52:24 --> Loader Class Initialized
INFO - 2024-03-22 05:52:24 --> Helper loaded: url_helper
INFO - 2024-03-22 05:52:24 --> Helper loaded: file_helper
INFO - 2024-03-22 05:52:24 --> Helper loaded: html_helper
INFO - 2024-03-22 05:52:24 --> Helper loaded: text_helper
INFO - 2024-03-22 05:52:24 --> Helper loaded: form_helper
INFO - 2024-03-22 05:52:24 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:52:24 --> Helper loaded: security_helper
INFO - 2024-03-22 05:52:24 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:52:24 --> Database Driver Class Initialized
INFO - 2024-03-22 05:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:52:24 --> Parser Class Initialized
INFO - 2024-03-22 05:52:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:52:24 --> Pagination Class Initialized
INFO - 2024-03-22 05:52:24 --> Form Validation Class Initialized
INFO - 2024-03-22 05:52:24 --> Controller Class Initialized
DEBUG - 2024-03-22 05:52:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:52:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:52:24 --> Model Class Initialized
DEBUG - 2024-03-22 05:52:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:52:24 --> Model Class Initialized
DEBUG - 2024-03-22 05:52:24 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:52:24 --> Model Class Initialized
INFO - 2024-03-22 05:52:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-03-22 05:52:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:52:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 05:52:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 05:52:24 --> Model Class Initialized
INFO - 2024-03-22 05:52:24 --> Model Class Initialized
INFO - 2024-03-22 05:52:24 --> Model Class Initialized
INFO - 2024-03-22 05:52:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 05:52:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 05:52:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 05:52:24 --> Final output sent to browser
DEBUG - 2024-03-22 05:52:24 --> Total execution time: 0.1728
ERROR - 2024-03-22 05:52:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:52:25 --> Config Class Initialized
INFO - 2024-03-22 05:52:25 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:52:25 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:52:25 --> Utf8 Class Initialized
INFO - 2024-03-22 05:52:25 --> URI Class Initialized
INFO - 2024-03-22 05:52:25 --> Router Class Initialized
INFO - 2024-03-22 05:52:25 --> Output Class Initialized
INFO - 2024-03-22 05:52:25 --> Security Class Initialized
DEBUG - 2024-03-22 05:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:52:25 --> Input Class Initialized
INFO - 2024-03-22 05:52:25 --> Language Class Initialized
INFO - 2024-03-22 05:52:25 --> Loader Class Initialized
INFO - 2024-03-22 05:52:25 --> Helper loaded: url_helper
INFO - 2024-03-22 05:52:25 --> Helper loaded: file_helper
INFO - 2024-03-22 05:52:25 --> Helper loaded: html_helper
INFO - 2024-03-22 05:52:25 --> Helper loaded: text_helper
INFO - 2024-03-22 05:52:25 --> Helper loaded: form_helper
INFO - 2024-03-22 05:52:25 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:52:25 --> Helper loaded: security_helper
INFO - 2024-03-22 05:52:25 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:52:25 --> Database Driver Class Initialized
INFO - 2024-03-22 05:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:52:25 --> Parser Class Initialized
INFO - 2024-03-22 05:52:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:52:25 --> Pagination Class Initialized
INFO - 2024-03-22 05:52:25 --> Form Validation Class Initialized
INFO - 2024-03-22 05:52:25 --> Controller Class Initialized
DEBUG - 2024-03-22 05:52:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:52:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:52:25 --> Model Class Initialized
DEBUG - 2024-03-22 05:52:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:52:25 --> Model Class Initialized
INFO - 2024-03-22 05:52:25 --> Final output sent to browser
DEBUG - 2024-03-22 05:52:25 --> Total execution time: 0.0236
ERROR - 2024-03-22 05:52:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:52:28 --> Config Class Initialized
INFO - 2024-03-22 05:52:28 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:52:28 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:52:28 --> Utf8 Class Initialized
INFO - 2024-03-22 05:52:28 --> URI Class Initialized
INFO - 2024-03-22 05:52:28 --> Router Class Initialized
INFO - 2024-03-22 05:52:28 --> Output Class Initialized
INFO - 2024-03-22 05:52:28 --> Security Class Initialized
DEBUG - 2024-03-22 05:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:52:28 --> Input Class Initialized
INFO - 2024-03-22 05:52:28 --> Language Class Initialized
INFO - 2024-03-22 05:52:28 --> Loader Class Initialized
INFO - 2024-03-22 05:52:28 --> Helper loaded: url_helper
INFO - 2024-03-22 05:52:28 --> Helper loaded: file_helper
INFO - 2024-03-22 05:52:28 --> Helper loaded: html_helper
INFO - 2024-03-22 05:52:28 --> Helper loaded: text_helper
INFO - 2024-03-22 05:52:28 --> Helper loaded: form_helper
INFO - 2024-03-22 05:52:28 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:52:28 --> Helper loaded: security_helper
INFO - 2024-03-22 05:52:28 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:52:28 --> Database Driver Class Initialized
INFO - 2024-03-22 05:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:52:28 --> Parser Class Initialized
INFO - 2024-03-22 05:52:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:52:28 --> Pagination Class Initialized
INFO - 2024-03-22 05:52:28 --> Form Validation Class Initialized
INFO - 2024-03-22 05:52:28 --> Controller Class Initialized
DEBUG - 2024-03-22 05:52:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:52:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:52:28 --> Model Class Initialized
DEBUG - 2024-03-22 05:52:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:52:28 --> Model Class Initialized
INFO - 2024-03-22 05:52:28 --> Final output sent to browser
DEBUG - 2024-03-22 05:52:28 --> Total execution time: 0.0459
ERROR - 2024-03-22 05:53:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:53:28 --> Config Class Initialized
INFO - 2024-03-22 05:53:28 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:53:28 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:53:28 --> Utf8 Class Initialized
INFO - 2024-03-22 05:53:28 --> URI Class Initialized
INFO - 2024-03-22 05:53:28 --> Router Class Initialized
INFO - 2024-03-22 05:53:28 --> Output Class Initialized
INFO - 2024-03-22 05:53:28 --> Security Class Initialized
DEBUG - 2024-03-22 05:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:53:28 --> Input Class Initialized
INFO - 2024-03-22 05:53:28 --> Language Class Initialized
INFO - 2024-03-22 05:53:28 --> Loader Class Initialized
INFO - 2024-03-22 05:53:28 --> Helper loaded: url_helper
INFO - 2024-03-22 05:53:28 --> Helper loaded: file_helper
INFO - 2024-03-22 05:53:28 --> Helper loaded: html_helper
INFO - 2024-03-22 05:53:28 --> Helper loaded: text_helper
INFO - 2024-03-22 05:53:28 --> Helper loaded: form_helper
INFO - 2024-03-22 05:53:28 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:53:28 --> Helper loaded: security_helper
INFO - 2024-03-22 05:53:28 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:53:28 --> Database Driver Class Initialized
INFO - 2024-03-22 05:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:53:28 --> Parser Class Initialized
INFO - 2024-03-22 05:53:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:53:28 --> Pagination Class Initialized
INFO - 2024-03-22 05:53:28 --> Form Validation Class Initialized
INFO - 2024-03-22 05:53:28 --> Controller Class Initialized
DEBUG - 2024-03-22 05:53:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:53:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:53:28 --> Model Class Initialized
DEBUG - 2024-03-22 05:53:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:53:28 --> Model Class Initialized
INFO - 2024-03-22 05:53:28 --> Final output sent to browser
DEBUG - 2024-03-22 05:53:28 --> Total execution time: 0.0211
ERROR - 2024-03-22 05:53:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:53:30 --> Config Class Initialized
INFO - 2024-03-22 05:53:30 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:53:30 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:53:30 --> Utf8 Class Initialized
INFO - 2024-03-22 05:53:30 --> URI Class Initialized
DEBUG - 2024-03-22 05:53:30 --> No URI present. Default controller set.
INFO - 2024-03-22 05:53:30 --> Router Class Initialized
INFO - 2024-03-22 05:53:30 --> Output Class Initialized
INFO - 2024-03-22 05:53:30 --> Security Class Initialized
DEBUG - 2024-03-22 05:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:53:30 --> Input Class Initialized
INFO - 2024-03-22 05:53:30 --> Language Class Initialized
INFO - 2024-03-22 05:53:30 --> Loader Class Initialized
INFO - 2024-03-22 05:53:30 --> Helper loaded: url_helper
INFO - 2024-03-22 05:53:30 --> Helper loaded: file_helper
INFO - 2024-03-22 05:53:30 --> Helper loaded: html_helper
INFO - 2024-03-22 05:53:30 --> Helper loaded: text_helper
INFO - 2024-03-22 05:53:30 --> Helper loaded: form_helper
INFO - 2024-03-22 05:53:30 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:53:30 --> Helper loaded: security_helper
INFO - 2024-03-22 05:53:30 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:53:30 --> Database Driver Class Initialized
INFO - 2024-03-22 05:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:53:30 --> Parser Class Initialized
INFO - 2024-03-22 05:53:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:53:30 --> Pagination Class Initialized
INFO - 2024-03-22 05:53:30 --> Form Validation Class Initialized
INFO - 2024-03-22 05:53:30 --> Controller Class Initialized
INFO - 2024-03-22 05:53:30 --> Model Class Initialized
DEBUG - 2024-03-22 05:53:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:53:30 --> Model Class Initialized
DEBUG - 2024-03-22 05:53:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:53:30 --> Model Class Initialized
INFO - 2024-03-22 05:53:30 --> Model Class Initialized
INFO - 2024-03-22 05:53:30 --> Model Class Initialized
INFO - 2024-03-22 05:53:30 --> Model Class Initialized
DEBUG - 2024-03-22 05:53:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:53:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:53:30 --> Model Class Initialized
INFO - 2024-03-22 05:53:30 --> Model Class Initialized
INFO - 2024-03-22 05:53:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 05:53:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:53:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 05:53:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 05:53:30 --> Model Class Initialized
INFO - 2024-03-22 05:53:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 05:53:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 05:53:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 05:53:30 --> Final output sent to browser
DEBUG - 2024-03-22 05:53:30 --> Total execution time: 0.2529
ERROR - 2024-03-22 05:53:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:53:38 --> Config Class Initialized
INFO - 2024-03-22 05:53:38 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:53:38 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:53:38 --> Utf8 Class Initialized
INFO - 2024-03-22 05:53:38 --> URI Class Initialized
INFO - 2024-03-22 05:53:38 --> Router Class Initialized
INFO - 2024-03-22 05:53:38 --> Output Class Initialized
INFO - 2024-03-22 05:53:38 --> Security Class Initialized
DEBUG - 2024-03-22 05:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:53:38 --> Input Class Initialized
INFO - 2024-03-22 05:53:38 --> Language Class Initialized
INFO - 2024-03-22 05:53:38 --> Loader Class Initialized
INFO - 2024-03-22 05:53:38 --> Helper loaded: url_helper
INFO - 2024-03-22 05:53:38 --> Helper loaded: file_helper
INFO - 2024-03-22 05:53:38 --> Helper loaded: html_helper
INFO - 2024-03-22 05:53:38 --> Helper loaded: text_helper
INFO - 2024-03-22 05:53:38 --> Helper loaded: form_helper
INFO - 2024-03-22 05:53:38 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:53:38 --> Helper loaded: security_helper
INFO - 2024-03-22 05:53:38 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:53:38 --> Database Driver Class Initialized
INFO - 2024-03-22 05:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:53:38 --> Parser Class Initialized
INFO - 2024-03-22 05:53:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:53:38 --> Pagination Class Initialized
INFO - 2024-03-22 05:53:38 --> Form Validation Class Initialized
INFO - 2024-03-22 05:53:38 --> Controller Class Initialized
INFO - 2024-03-22 05:53:38 --> Model Class Initialized
DEBUG - 2024-03-22 05:53:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:53:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:53:38 --> Model Class Initialized
DEBUG - 2024-03-22 05:53:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:53:38 --> Model Class Initialized
INFO - 2024-03-22 05:53:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-22 05:53:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:53:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 05:53:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 05:53:38 --> Model Class Initialized
INFO - 2024-03-22 05:53:38 --> Model Class Initialized
INFO - 2024-03-22 05:53:38 --> Model Class Initialized
INFO - 2024-03-22 05:53:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 05:53:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 05:53:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 05:53:38 --> Final output sent to browser
DEBUG - 2024-03-22 05:53:38 --> Total execution time: 0.1634
ERROR - 2024-03-22 05:53:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:53:39 --> Config Class Initialized
INFO - 2024-03-22 05:53:39 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:53:39 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:53:39 --> Utf8 Class Initialized
INFO - 2024-03-22 05:53:39 --> URI Class Initialized
INFO - 2024-03-22 05:53:39 --> Router Class Initialized
INFO - 2024-03-22 05:53:39 --> Output Class Initialized
INFO - 2024-03-22 05:53:39 --> Security Class Initialized
DEBUG - 2024-03-22 05:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:53:39 --> Input Class Initialized
INFO - 2024-03-22 05:53:39 --> Language Class Initialized
INFO - 2024-03-22 05:53:39 --> Loader Class Initialized
INFO - 2024-03-22 05:53:39 --> Helper loaded: url_helper
INFO - 2024-03-22 05:53:39 --> Helper loaded: file_helper
INFO - 2024-03-22 05:53:39 --> Helper loaded: html_helper
INFO - 2024-03-22 05:53:39 --> Helper loaded: text_helper
INFO - 2024-03-22 05:53:39 --> Helper loaded: form_helper
INFO - 2024-03-22 05:53:39 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:53:39 --> Helper loaded: security_helper
INFO - 2024-03-22 05:53:39 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:53:39 --> Database Driver Class Initialized
INFO - 2024-03-22 05:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:53:39 --> Parser Class Initialized
INFO - 2024-03-22 05:53:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:53:39 --> Pagination Class Initialized
INFO - 2024-03-22 05:53:39 --> Form Validation Class Initialized
INFO - 2024-03-22 05:53:39 --> Controller Class Initialized
INFO - 2024-03-22 05:53:39 --> Model Class Initialized
DEBUG - 2024-03-22 05:53:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:53:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:53:39 --> Model Class Initialized
DEBUG - 2024-03-22 05:53:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:53:39 --> Model Class Initialized
INFO - 2024-03-22 05:53:39 --> Final output sent to browser
DEBUG - 2024-03-22 05:53:39 --> Total execution time: 0.0440
ERROR - 2024-03-22 05:53:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:53:50 --> Config Class Initialized
INFO - 2024-03-22 05:53:50 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:53:50 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:53:50 --> Utf8 Class Initialized
INFO - 2024-03-22 05:53:50 --> URI Class Initialized
INFO - 2024-03-22 05:53:50 --> Router Class Initialized
INFO - 2024-03-22 05:53:50 --> Output Class Initialized
INFO - 2024-03-22 05:53:50 --> Security Class Initialized
DEBUG - 2024-03-22 05:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:53:50 --> Input Class Initialized
INFO - 2024-03-22 05:53:50 --> Language Class Initialized
INFO - 2024-03-22 05:53:50 --> Loader Class Initialized
INFO - 2024-03-22 05:53:50 --> Helper loaded: url_helper
INFO - 2024-03-22 05:53:50 --> Helper loaded: file_helper
INFO - 2024-03-22 05:53:50 --> Helper loaded: html_helper
INFO - 2024-03-22 05:53:50 --> Helper loaded: text_helper
INFO - 2024-03-22 05:53:50 --> Helper loaded: form_helper
INFO - 2024-03-22 05:53:50 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:53:50 --> Helper loaded: security_helper
INFO - 2024-03-22 05:53:50 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:53:50 --> Database Driver Class Initialized
INFO - 2024-03-22 05:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:53:50 --> Parser Class Initialized
INFO - 2024-03-22 05:53:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:53:50 --> Pagination Class Initialized
INFO - 2024-03-22 05:53:50 --> Form Validation Class Initialized
INFO - 2024-03-22 05:53:50 --> Controller Class Initialized
DEBUG - 2024-03-22 05:53:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:53:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:53:50 --> Model Class Initialized
DEBUG - 2024-03-22 05:53:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:53:50 --> Model Class Initialized
DEBUG - 2024-03-22 05:53:50 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:53:50 --> Model Class Initialized
INFO - 2024-03-22 05:53:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-03-22 05:53:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:53:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 05:53:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 05:53:50 --> Model Class Initialized
INFO - 2024-03-22 05:53:50 --> Model Class Initialized
INFO - 2024-03-22 05:53:50 --> Model Class Initialized
INFO - 2024-03-22 05:53:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 05:53:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 05:53:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 05:53:50 --> Final output sent to browser
DEBUG - 2024-03-22 05:53:50 --> Total execution time: 0.1726
ERROR - 2024-03-22 05:53:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:53:51 --> Config Class Initialized
INFO - 2024-03-22 05:53:51 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:53:51 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:53:51 --> Utf8 Class Initialized
INFO - 2024-03-22 05:53:51 --> URI Class Initialized
INFO - 2024-03-22 05:53:51 --> Router Class Initialized
INFO - 2024-03-22 05:53:51 --> Output Class Initialized
INFO - 2024-03-22 05:53:51 --> Security Class Initialized
DEBUG - 2024-03-22 05:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:53:51 --> Input Class Initialized
INFO - 2024-03-22 05:53:51 --> Language Class Initialized
INFO - 2024-03-22 05:53:51 --> Loader Class Initialized
INFO - 2024-03-22 05:53:51 --> Helper loaded: url_helper
INFO - 2024-03-22 05:53:51 --> Helper loaded: file_helper
INFO - 2024-03-22 05:53:51 --> Helper loaded: html_helper
INFO - 2024-03-22 05:53:51 --> Helper loaded: text_helper
INFO - 2024-03-22 05:53:51 --> Helper loaded: form_helper
INFO - 2024-03-22 05:53:51 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:53:51 --> Helper loaded: security_helper
INFO - 2024-03-22 05:53:51 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:53:51 --> Database Driver Class Initialized
INFO - 2024-03-22 05:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:53:51 --> Parser Class Initialized
INFO - 2024-03-22 05:53:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:53:51 --> Pagination Class Initialized
INFO - 2024-03-22 05:53:51 --> Form Validation Class Initialized
INFO - 2024-03-22 05:53:51 --> Controller Class Initialized
DEBUG - 2024-03-22 05:53:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:53:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:53:51 --> Model Class Initialized
DEBUG - 2024-03-22 05:53:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:53:51 --> Model Class Initialized
INFO - 2024-03-22 05:53:51 --> Final output sent to browser
DEBUG - 2024-03-22 05:53:51 --> Total execution time: 0.0227
ERROR - 2024-03-22 05:53:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:53:55 --> Config Class Initialized
INFO - 2024-03-22 05:53:55 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:53:55 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:53:55 --> Utf8 Class Initialized
INFO - 2024-03-22 05:53:55 --> URI Class Initialized
INFO - 2024-03-22 05:53:55 --> Router Class Initialized
INFO - 2024-03-22 05:53:55 --> Output Class Initialized
INFO - 2024-03-22 05:53:55 --> Security Class Initialized
DEBUG - 2024-03-22 05:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:53:55 --> Input Class Initialized
INFO - 2024-03-22 05:53:55 --> Language Class Initialized
INFO - 2024-03-22 05:53:55 --> Loader Class Initialized
INFO - 2024-03-22 05:53:55 --> Helper loaded: url_helper
INFO - 2024-03-22 05:53:55 --> Helper loaded: file_helper
INFO - 2024-03-22 05:53:55 --> Helper loaded: html_helper
INFO - 2024-03-22 05:53:55 --> Helper loaded: text_helper
INFO - 2024-03-22 05:53:55 --> Helper loaded: form_helper
INFO - 2024-03-22 05:53:55 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:53:55 --> Helper loaded: security_helper
INFO - 2024-03-22 05:53:55 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:53:55 --> Database Driver Class Initialized
INFO - 2024-03-22 05:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:53:55 --> Parser Class Initialized
INFO - 2024-03-22 05:53:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:53:55 --> Pagination Class Initialized
INFO - 2024-03-22 05:53:55 --> Form Validation Class Initialized
INFO - 2024-03-22 05:53:55 --> Controller Class Initialized
DEBUG - 2024-03-22 05:53:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:53:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:53:55 --> Model Class Initialized
DEBUG - 2024-03-22 05:53:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:53:55 --> Model Class Initialized
INFO - 2024-03-22 05:53:55 --> Final output sent to browser
DEBUG - 2024-03-22 05:53:55 --> Total execution time: 0.0249
ERROR - 2024-03-22 05:53:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:53:55 --> Config Class Initialized
INFO - 2024-03-22 05:53:55 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:53:55 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:53:55 --> Utf8 Class Initialized
INFO - 2024-03-22 05:53:55 --> URI Class Initialized
INFO - 2024-03-22 05:53:55 --> Router Class Initialized
INFO - 2024-03-22 05:53:55 --> Output Class Initialized
INFO - 2024-03-22 05:53:55 --> Security Class Initialized
DEBUG - 2024-03-22 05:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:53:55 --> Input Class Initialized
INFO - 2024-03-22 05:53:55 --> Language Class Initialized
INFO - 2024-03-22 05:53:55 --> Loader Class Initialized
INFO - 2024-03-22 05:53:55 --> Helper loaded: url_helper
INFO - 2024-03-22 05:53:55 --> Helper loaded: file_helper
INFO - 2024-03-22 05:53:55 --> Helper loaded: html_helper
INFO - 2024-03-22 05:53:55 --> Helper loaded: text_helper
INFO - 2024-03-22 05:53:55 --> Helper loaded: form_helper
INFO - 2024-03-22 05:53:55 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:53:55 --> Helper loaded: security_helper
INFO - 2024-03-22 05:53:55 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:53:55 --> Database Driver Class Initialized
INFO - 2024-03-22 05:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:53:55 --> Parser Class Initialized
INFO - 2024-03-22 05:53:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:53:55 --> Pagination Class Initialized
INFO - 2024-03-22 05:53:55 --> Form Validation Class Initialized
INFO - 2024-03-22 05:53:55 --> Controller Class Initialized
DEBUG - 2024-03-22 05:53:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:53:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:53:55 --> Model Class Initialized
DEBUG - 2024-03-22 05:53:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:53:55 --> Model Class Initialized
INFO - 2024-03-22 05:53:55 --> Final output sent to browser
DEBUG - 2024-03-22 05:53:55 --> Total execution time: 0.0213
ERROR - 2024-03-22 05:53:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:53:56 --> Config Class Initialized
INFO - 2024-03-22 05:53:56 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:53:56 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:53:56 --> Utf8 Class Initialized
INFO - 2024-03-22 05:53:56 --> URI Class Initialized
INFO - 2024-03-22 05:53:56 --> Router Class Initialized
INFO - 2024-03-22 05:53:56 --> Output Class Initialized
INFO - 2024-03-22 05:53:56 --> Security Class Initialized
DEBUG - 2024-03-22 05:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:53:56 --> Input Class Initialized
INFO - 2024-03-22 05:53:56 --> Language Class Initialized
INFO - 2024-03-22 05:53:56 --> Loader Class Initialized
INFO - 2024-03-22 05:53:56 --> Helper loaded: url_helper
INFO - 2024-03-22 05:53:56 --> Helper loaded: file_helper
INFO - 2024-03-22 05:53:56 --> Helper loaded: html_helper
INFO - 2024-03-22 05:53:56 --> Helper loaded: text_helper
INFO - 2024-03-22 05:53:56 --> Helper loaded: form_helper
INFO - 2024-03-22 05:53:56 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:53:56 --> Helper loaded: security_helper
INFO - 2024-03-22 05:53:56 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:53:56 --> Database Driver Class Initialized
INFO - 2024-03-22 05:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:53:56 --> Parser Class Initialized
INFO - 2024-03-22 05:53:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:53:56 --> Pagination Class Initialized
INFO - 2024-03-22 05:53:56 --> Form Validation Class Initialized
INFO - 2024-03-22 05:53:56 --> Controller Class Initialized
DEBUG - 2024-03-22 05:53:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:53:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:53:56 --> Model Class Initialized
DEBUG - 2024-03-22 05:53:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:53:56 --> Model Class Initialized
INFO - 2024-03-22 05:53:56 --> Final output sent to browser
DEBUG - 2024-03-22 05:53:56 --> Total execution time: 0.0187
ERROR - 2024-03-22 05:53:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:53:56 --> Config Class Initialized
INFO - 2024-03-22 05:53:56 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:53:56 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:53:56 --> Utf8 Class Initialized
INFO - 2024-03-22 05:53:56 --> URI Class Initialized
INFO - 2024-03-22 05:53:56 --> Router Class Initialized
INFO - 2024-03-22 05:53:56 --> Output Class Initialized
INFO - 2024-03-22 05:53:56 --> Security Class Initialized
DEBUG - 2024-03-22 05:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:53:56 --> Input Class Initialized
INFO - 2024-03-22 05:53:56 --> Language Class Initialized
INFO - 2024-03-22 05:53:56 --> Loader Class Initialized
INFO - 2024-03-22 05:53:56 --> Helper loaded: url_helper
INFO - 2024-03-22 05:53:56 --> Helper loaded: file_helper
INFO - 2024-03-22 05:53:56 --> Helper loaded: html_helper
INFO - 2024-03-22 05:53:56 --> Helper loaded: text_helper
INFO - 2024-03-22 05:53:56 --> Helper loaded: form_helper
INFO - 2024-03-22 05:53:56 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:53:56 --> Helper loaded: security_helper
INFO - 2024-03-22 05:53:56 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:53:56 --> Database Driver Class Initialized
INFO - 2024-03-22 05:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:53:56 --> Parser Class Initialized
INFO - 2024-03-22 05:53:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:53:56 --> Pagination Class Initialized
INFO - 2024-03-22 05:53:56 --> Form Validation Class Initialized
INFO - 2024-03-22 05:53:56 --> Controller Class Initialized
DEBUG - 2024-03-22 05:53:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:53:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:53:56 --> Model Class Initialized
DEBUG - 2024-03-22 05:53:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:53:56 --> Model Class Initialized
INFO - 2024-03-22 05:53:56 --> Final output sent to browser
DEBUG - 2024-03-22 05:53:56 --> Total execution time: 0.0189
ERROR - 2024-03-22 05:53:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:53:57 --> Config Class Initialized
INFO - 2024-03-22 05:53:57 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:53:57 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:53:57 --> Utf8 Class Initialized
INFO - 2024-03-22 05:53:57 --> URI Class Initialized
INFO - 2024-03-22 05:53:57 --> Router Class Initialized
INFO - 2024-03-22 05:53:57 --> Output Class Initialized
INFO - 2024-03-22 05:53:57 --> Security Class Initialized
DEBUG - 2024-03-22 05:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:53:57 --> Input Class Initialized
INFO - 2024-03-22 05:53:57 --> Language Class Initialized
INFO - 2024-03-22 05:53:57 --> Loader Class Initialized
INFO - 2024-03-22 05:53:57 --> Helper loaded: url_helper
INFO - 2024-03-22 05:53:57 --> Helper loaded: file_helper
INFO - 2024-03-22 05:53:57 --> Helper loaded: html_helper
INFO - 2024-03-22 05:53:57 --> Helper loaded: text_helper
INFO - 2024-03-22 05:53:57 --> Helper loaded: form_helper
INFO - 2024-03-22 05:53:57 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:53:57 --> Helper loaded: security_helper
INFO - 2024-03-22 05:53:57 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:53:57 --> Database Driver Class Initialized
INFO - 2024-03-22 05:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:53:57 --> Parser Class Initialized
INFO - 2024-03-22 05:53:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:53:57 --> Pagination Class Initialized
INFO - 2024-03-22 05:53:57 --> Form Validation Class Initialized
INFO - 2024-03-22 05:53:57 --> Controller Class Initialized
DEBUG - 2024-03-22 05:53:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:53:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:53:57 --> Model Class Initialized
DEBUG - 2024-03-22 05:53:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:53:57 --> Model Class Initialized
INFO - 2024-03-22 05:53:57 --> Final output sent to browser
DEBUG - 2024-03-22 05:53:57 --> Total execution time: 0.0210
ERROR - 2024-03-22 05:54:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:54:03 --> Config Class Initialized
INFO - 2024-03-22 05:54:03 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:54:03 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:54:03 --> Utf8 Class Initialized
INFO - 2024-03-22 05:54:03 --> URI Class Initialized
INFO - 2024-03-22 05:54:03 --> Router Class Initialized
INFO - 2024-03-22 05:54:03 --> Output Class Initialized
INFO - 2024-03-22 05:54:03 --> Security Class Initialized
DEBUG - 2024-03-22 05:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:54:03 --> Input Class Initialized
INFO - 2024-03-22 05:54:03 --> Language Class Initialized
INFO - 2024-03-22 05:54:03 --> Loader Class Initialized
INFO - 2024-03-22 05:54:03 --> Helper loaded: url_helper
INFO - 2024-03-22 05:54:03 --> Helper loaded: file_helper
INFO - 2024-03-22 05:54:03 --> Helper loaded: html_helper
INFO - 2024-03-22 05:54:03 --> Helper loaded: text_helper
INFO - 2024-03-22 05:54:03 --> Helper loaded: form_helper
INFO - 2024-03-22 05:54:03 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:54:03 --> Helper loaded: security_helper
INFO - 2024-03-22 05:54:03 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:54:03 --> Database Driver Class Initialized
INFO - 2024-03-22 05:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:54:03 --> Parser Class Initialized
INFO - 2024-03-22 05:54:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:54:03 --> Pagination Class Initialized
INFO - 2024-03-22 05:54:03 --> Form Validation Class Initialized
INFO - 2024-03-22 05:54:03 --> Controller Class Initialized
DEBUG - 2024-03-22 05:54:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:54:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:54:03 --> Model Class Initialized
DEBUG - 2024-03-22 05:54:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:54:03 --> Model Class Initialized
INFO - 2024-03-22 05:54:03 --> Final output sent to browser
DEBUG - 2024-03-22 05:54:03 --> Total execution time: 0.0180
ERROR - 2024-03-22 05:54:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:54:35 --> Config Class Initialized
INFO - 2024-03-22 05:54:35 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:54:35 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:54:35 --> Utf8 Class Initialized
INFO - 2024-03-22 05:54:35 --> URI Class Initialized
DEBUG - 2024-03-22 05:54:35 --> No URI present. Default controller set.
INFO - 2024-03-22 05:54:35 --> Router Class Initialized
INFO - 2024-03-22 05:54:35 --> Output Class Initialized
INFO - 2024-03-22 05:54:35 --> Security Class Initialized
DEBUG - 2024-03-22 05:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:54:35 --> Input Class Initialized
INFO - 2024-03-22 05:54:35 --> Language Class Initialized
INFO - 2024-03-22 05:54:35 --> Loader Class Initialized
INFO - 2024-03-22 05:54:35 --> Helper loaded: url_helper
INFO - 2024-03-22 05:54:35 --> Helper loaded: file_helper
INFO - 2024-03-22 05:54:35 --> Helper loaded: html_helper
INFO - 2024-03-22 05:54:35 --> Helper loaded: text_helper
INFO - 2024-03-22 05:54:35 --> Helper loaded: form_helper
INFO - 2024-03-22 05:54:35 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:54:35 --> Helper loaded: security_helper
INFO - 2024-03-22 05:54:35 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:54:35 --> Database Driver Class Initialized
INFO - 2024-03-22 05:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:54:35 --> Parser Class Initialized
INFO - 2024-03-22 05:54:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:54:35 --> Pagination Class Initialized
INFO - 2024-03-22 05:54:35 --> Form Validation Class Initialized
INFO - 2024-03-22 05:54:35 --> Controller Class Initialized
INFO - 2024-03-22 05:54:35 --> Model Class Initialized
DEBUG - 2024-03-22 05:54:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:54:35 --> Model Class Initialized
DEBUG - 2024-03-22 05:54:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:54:35 --> Model Class Initialized
INFO - 2024-03-22 05:54:35 --> Model Class Initialized
INFO - 2024-03-22 05:54:35 --> Model Class Initialized
INFO - 2024-03-22 05:54:35 --> Model Class Initialized
DEBUG - 2024-03-22 05:54:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:54:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:54:35 --> Model Class Initialized
INFO - 2024-03-22 05:54:35 --> Model Class Initialized
INFO - 2024-03-22 05:54:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 05:54:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:54:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 05:54:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 05:54:35 --> Model Class Initialized
INFO - 2024-03-22 05:54:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 05:54:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 05:54:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 05:54:35 --> Final output sent to browser
DEBUG - 2024-03-22 05:54:35 --> Total execution time: 0.2587
ERROR - 2024-03-22 05:54:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:54:49 --> Config Class Initialized
INFO - 2024-03-22 05:54:49 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:54:49 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:54:49 --> Utf8 Class Initialized
INFO - 2024-03-22 05:54:49 --> URI Class Initialized
INFO - 2024-03-22 05:54:49 --> Router Class Initialized
INFO - 2024-03-22 05:54:49 --> Output Class Initialized
INFO - 2024-03-22 05:54:49 --> Security Class Initialized
DEBUG - 2024-03-22 05:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:54:49 --> Input Class Initialized
INFO - 2024-03-22 05:54:49 --> Language Class Initialized
INFO - 2024-03-22 05:54:49 --> Loader Class Initialized
INFO - 2024-03-22 05:54:49 --> Helper loaded: url_helper
INFO - 2024-03-22 05:54:49 --> Helper loaded: file_helper
INFO - 2024-03-22 05:54:49 --> Helper loaded: html_helper
INFO - 2024-03-22 05:54:49 --> Helper loaded: text_helper
INFO - 2024-03-22 05:54:49 --> Helper loaded: form_helper
INFO - 2024-03-22 05:54:49 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:54:49 --> Helper loaded: security_helper
INFO - 2024-03-22 05:54:49 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:54:49 --> Database Driver Class Initialized
INFO - 2024-03-22 05:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:54:49 --> Parser Class Initialized
INFO - 2024-03-22 05:54:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:54:49 --> Pagination Class Initialized
INFO - 2024-03-22 05:54:49 --> Form Validation Class Initialized
INFO - 2024-03-22 05:54:49 --> Controller Class Initialized
INFO - 2024-03-22 05:54:49 --> Model Class Initialized
DEBUG - 2024-03-22 05:54:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:54:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:54:49 --> Model Class Initialized
DEBUG - 2024-03-22 05:54:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:54:49 --> Model Class Initialized
INFO - 2024-03-22 05:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-22 05:54:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 05:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 05:54:49 --> Model Class Initialized
INFO - 2024-03-22 05:54:49 --> Model Class Initialized
INFO - 2024-03-22 05:54:49 --> Model Class Initialized
INFO - 2024-03-22 05:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 05:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 05:54:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 05:54:49 --> Final output sent to browser
DEBUG - 2024-03-22 05:54:49 --> Total execution time: 0.1712
ERROR - 2024-03-22 05:54:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:54:49 --> Config Class Initialized
INFO - 2024-03-22 05:54:49 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:54:49 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:54:49 --> Utf8 Class Initialized
INFO - 2024-03-22 05:54:49 --> URI Class Initialized
INFO - 2024-03-22 05:54:49 --> Router Class Initialized
INFO - 2024-03-22 05:54:49 --> Output Class Initialized
INFO - 2024-03-22 05:54:49 --> Security Class Initialized
DEBUG - 2024-03-22 05:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:54:49 --> Input Class Initialized
INFO - 2024-03-22 05:54:49 --> Language Class Initialized
INFO - 2024-03-22 05:54:49 --> Loader Class Initialized
INFO - 2024-03-22 05:54:49 --> Helper loaded: url_helper
INFO - 2024-03-22 05:54:49 --> Helper loaded: file_helper
INFO - 2024-03-22 05:54:49 --> Helper loaded: html_helper
INFO - 2024-03-22 05:54:49 --> Helper loaded: text_helper
INFO - 2024-03-22 05:54:49 --> Helper loaded: form_helper
INFO - 2024-03-22 05:54:49 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:54:49 --> Helper loaded: security_helper
INFO - 2024-03-22 05:54:49 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:54:49 --> Database Driver Class Initialized
INFO - 2024-03-22 05:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:54:49 --> Parser Class Initialized
INFO - 2024-03-22 05:54:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:54:49 --> Pagination Class Initialized
INFO - 2024-03-22 05:54:49 --> Form Validation Class Initialized
INFO - 2024-03-22 05:54:49 --> Controller Class Initialized
INFO - 2024-03-22 05:54:49 --> Model Class Initialized
DEBUG - 2024-03-22 05:54:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:54:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:54:49 --> Model Class Initialized
DEBUG - 2024-03-22 05:54:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:54:49 --> Model Class Initialized
INFO - 2024-03-22 05:54:49 --> Final output sent to browser
DEBUG - 2024-03-22 05:54:49 --> Total execution time: 0.0453
ERROR - 2024-03-22 05:54:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:54:52 --> Config Class Initialized
INFO - 2024-03-22 05:54:52 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:54:52 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:54:52 --> Utf8 Class Initialized
INFO - 2024-03-22 05:54:52 --> URI Class Initialized
INFO - 2024-03-22 05:54:52 --> Router Class Initialized
INFO - 2024-03-22 05:54:52 --> Output Class Initialized
INFO - 2024-03-22 05:54:52 --> Security Class Initialized
DEBUG - 2024-03-22 05:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:54:52 --> Input Class Initialized
INFO - 2024-03-22 05:54:52 --> Language Class Initialized
INFO - 2024-03-22 05:54:52 --> Loader Class Initialized
INFO - 2024-03-22 05:54:52 --> Helper loaded: url_helper
INFO - 2024-03-22 05:54:52 --> Helper loaded: file_helper
INFO - 2024-03-22 05:54:52 --> Helper loaded: html_helper
INFO - 2024-03-22 05:54:52 --> Helper loaded: text_helper
INFO - 2024-03-22 05:54:52 --> Helper loaded: form_helper
INFO - 2024-03-22 05:54:52 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:54:52 --> Helper loaded: security_helper
INFO - 2024-03-22 05:54:52 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:54:52 --> Database Driver Class Initialized
INFO - 2024-03-22 05:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:54:52 --> Parser Class Initialized
INFO - 2024-03-22 05:54:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:54:52 --> Pagination Class Initialized
INFO - 2024-03-22 05:54:52 --> Form Validation Class Initialized
INFO - 2024-03-22 05:54:52 --> Controller Class Initialized
INFO - 2024-03-22 05:54:52 --> Model Class Initialized
DEBUG - 2024-03-22 05:54:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:54:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:54:52 --> Model Class Initialized
DEBUG - 2024-03-22 05:54:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:54:52 --> Model Class Initialized
INFO - 2024-03-22 05:54:53 --> Final output sent to browser
DEBUG - 2024-03-22 05:54:53 --> Total execution time: 0.2709
ERROR - 2024-03-22 05:55:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:55:01 --> Config Class Initialized
INFO - 2024-03-22 05:55:01 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:55:01 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:55:01 --> Utf8 Class Initialized
INFO - 2024-03-22 05:55:01 --> URI Class Initialized
DEBUG - 2024-03-22 05:55:01 --> No URI present. Default controller set.
INFO - 2024-03-22 05:55:01 --> Router Class Initialized
INFO - 2024-03-22 05:55:01 --> Output Class Initialized
INFO - 2024-03-22 05:55:01 --> Security Class Initialized
DEBUG - 2024-03-22 05:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:55:01 --> Input Class Initialized
INFO - 2024-03-22 05:55:01 --> Language Class Initialized
INFO - 2024-03-22 05:55:01 --> Loader Class Initialized
INFO - 2024-03-22 05:55:01 --> Helper loaded: url_helper
INFO - 2024-03-22 05:55:01 --> Helper loaded: file_helper
INFO - 2024-03-22 05:55:01 --> Helper loaded: html_helper
INFO - 2024-03-22 05:55:01 --> Helper loaded: text_helper
INFO - 2024-03-22 05:55:01 --> Helper loaded: form_helper
INFO - 2024-03-22 05:55:01 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:55:01 --> Helper loaded: security_helper
INFO - 2024-03-22 05:55:01 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:55:01 --> Database Driver Class Initialized
INFO - 2024-03-22 05:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:55:01 --> Parser Class Initialized
INFO - 2024-03-22 05:55:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:55:01 --> Pagination Class Initialized
INFO - 2024-03-22 05:55:01 --> Form Validation Class Initialized
INFO - 2024-03-22 05:55:01 --> Controller Class Initialized
INFO - 2024-03-22 05:55:01 --> Model Class Initialized
DEBUG - 2024-03-22 05:55:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:55:01 --> Model Class Initialized
DEBUG - 2024-03-22 05:55:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:55:01 --> Model Class Initialized
INFO - 2024-03-22 05:55:01 --> Model Class Initialized
INFO - 2024-03-22 05:55:01 --> Model Class Initialized
INFO - 2024-03-22 05:55:01 --> Model Class Initialized
DEBUG - 2024-03-22 05:55:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:55:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:55:01 --> Model Class Initialized
INFO - 2024-03-22 05:55:01 --> Model Class Initialized
INFO - 2024-03-22 05:55:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 05:55:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:55:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 05:55:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 05:55:02 --> Model Class Initialized
INFO - 2024-03-22 05:55:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 05:55:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 05:55:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 05:55:02 --> Final output sent to browser
DEBUG - 2024-03-22 05:55:02 --> Total execution time: 0.4046
ERROR - 2024-03-22 05:55:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:55:43 --> Config Class Initialized
INFO - 2024-03-22 05:55:43 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:55:43 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:55:43 --> Utf8 Class Initialized
INFO - 2024-03-22 05:55:43 --> URI Class Initialized
INFO - 2024-03-22 05:55:43 --> Router Class Initialized
INFO - 2024-03-22 05:55:43 --> Output Class Initialized
INFO - 2024-03-22 05:55:43 --> Security Class Initialized
DEBUG - 2024-03-22 05:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:55:43 --> Input Class Initialized
INFO - 2024-03-22 05:55:43 --> Language Class Initialized
INFO - 2024-03-22 05:55:43 --> Loader Class Initialized
INFO - 2024-03-22 05:55:43 --> Helper loaded: url_helper
INFO - 2024-03-22 05:55:43 --> Helper loaded: file_helper
INFO - 2024-03-22 05:55:43 --> Helper loaded: html_helper
INFO - 2024-03-22 05:55:43 --> Helper loaded: text_helper
INFO - 2024-03-22 05:55:43 --> Helper loaded: form_helper
INFO - 2024-03-22 05:55:43 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:55:43 --> Helper loaded: security_helper
INFO - 2024-03-22 05:55:43 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:55:43 --> Database Driver Class Initialized
INFO - 2024-03-22 05:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:55:43 --> Parser Class Initialized
INFO - 2024-03-22 05:55:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:55:43 --> Pagination Class Initialized
INFO - 2024-03-22 05:55:43 --> Form Validation Class Initialized
INFO - 2024-03-22 05:55:43 --> Controller Class Initialized
DEBUG - 2024-03-22 05:55:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:55:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:55:43 --> Model Class Initialized
DEBUG - 2024-03-22 05:55:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:55:43 --> Model Class Initialized
DEBUG - 2024-03-22 05:55:43 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:55:43 --> Model Class Initialized
INFO - 2024-03-22 05:55:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-03-22 05:55:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:55:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 05:55:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 05:55:43 --> Model Class Initialized
INFO - 2024-03-22 05:55:43 --> Model Class Initialized
INFO - 2024-03-22 05:55:43 --> Model Class Initialized
INFO - 2024-03-22 05:55:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 05:55:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 05:55:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 05:55:43 --> Final output sent to browser
DEBUG - 2024-03-22 05:55:43 --> Total execution time: 0.1733
ERROR - 2024-03-22 05:55:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:55:44 --> Config Class Initialized
INFO - 2024-03-22 05:55:44 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:55:44 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:55:44 --> Utf8 Class Initialized
INFO - 2024-03-22 05:55:44 --> URI Class Initialized
INFO - 2024-03-22 05:55:44 --> Router Class Initialized
INFO - 2024-03-22 05:55:44 --> Output Class Initialized
INFO - 2024-03-22 05:55:44 --> Security Class Initialized
DEBUG - 2024-03-22 05:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:55:44 --> Input Class Initialized
INFO - 2024-03-22 05:55:44 --> Language Class Initialized
INFO - 2024-03-22 05:55:44 --> Loader Class Initialized
INFO - 2024-03-22 05:55:44 --> Helper loaded: url_helper
INFO - 2024-03-22 05:55:44 --> Helper loaded: file_helper
INFO - 2024-03-22 05:55:44 --> Helper loaded: html_helper
INFO - 2024-03-22 05:55:44 --> Helper loaded: text_helper
INFO - 2024-03-22 05:55:44 --> Helper loaded: form_helper
INFO - 2024-03-22 05:55:44 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:55:44 --> Helper loaded: security_helper
INFO - 2024-03-22 05:55:44 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:55:44 --> Database Driver Class Initialized
INFO - 2024-03-22 05:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:55:44 --> Parser Class Initialized
INFO - 2024-03-22 05:55:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:55:44 --> Pagination Class Initialized
INFO - 2024-03-22 05:55:44 --> Form Validation Class Initialized
INFO - 2024-03-22 05:55:44 --> Controller Class Initialized
DEBUG - 2024-03-22 05:55:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:55:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:55:44 --> Model Class Initialized
DEBUG - 2024-03-22 05:55:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:55:44 --> Model Class Initialized
INFO - 2024-03-22 05:55:44 --> Final output sent to browser
DEBUG - 2024-03-22 05:55:44 --> Total execution time: 0.0205
ERROR - 2024-03-22 05:55:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 05:55:47 --> Config Class Initialized
INFO - 2024-03-22 05:55:47 --> Hooks Class Initialized
DEBUG - 2024-03-22 05:55:47 --> UTF-8 Support Enabled
INFO - 2024-03-22 05:55:47 --> Utf8 Class Initialized
INFO - 2024-03-22 05:55:47 --> URI Class Initialized
INFO - 2024-03-22 05:55:47 --> Router Class Initialized
INFO - 2024-03-22 05:55:47 --> Output Class Initialized
INFO - 2024-03-22 05:55:47 --> Security Class Initialized
DEBUG - 2024-03-22 05:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 05:55:47 --> Input Class Initialized
INFO - 2024-03-22 05:55:47 --> Language Class Initialized
INFO - 2024-03-22 05:55:47 --> Loader Class Initialized
INFO - 2024-03-22 05:55:47 --> Helper loaded: url_helper
INFO - 2024-03-22 05:55:47 --> Helper loaded: file_helper
INFO - 2024-03-22 05:55:47 --> Helper loaded: html_helper
INFO - 2024-03-22 05:55:47 --> Helper loaded: text_helper
INFO - 2024-03-22 05:55:47 --> Helper loaded: form_helper
INFO - 2024-03-22 05:55:47 --> Helper loaded: lang_helper
INFO - 2024-03-22 05:55:47 --> Helper loaded: security_helper
INFO - 2024-03-22 05:55:47 --> Helper loaded: cookie_helper
INFO - 2024-03-22 05:55:47 --> Database Driver Class Initialized
INFO - 2024-03-22 05:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 05:55:47 --> Parser Class Initialized
INFO - 2024-03-22 05:55:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 05:55:47 --> Pagination Class Initialized
INFO - 2024-03-22 05:55:47 --> Form Validation Class Initialized
INFO - 2024-03-22 05:55:47 --> Controller Class Initialized
DEBUG - 2024-03-22 05:55:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 05:55:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:55:47 --> Model Class Initialized
DEBUG - 2024-03-22 05:55:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 05:55:47 --> Model Class Initialized
INFO - 2024-03-22 05:55:47 --> Final output sent to browser
DEBUG - 2024-03-22 05:55:47 --> Total execution time: 0.0436
ERROR - 2024-03-22 06:48:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 06:48:44 --> Config Class Initialized
INFO - 2024-03-22 06:48:44 --> Hooks Class Initialized
DEBUG - 2024-03-22 06:48:44 --> UTF-8 Support Enabled
INFO - 2024-03-22 06:48:44 --> Utf8 Class Initialized
INFO - 2024-03-22 06:48:44 --> URI Class Initialized
DEBUG - 2024-03-22 06:48:44 --> No URI present. Default controller set.
INFO - 2024-03-22 06:48:44 --> Router Class Initialized
INFO - 2024-03-22 06:48:44 --> Output Class Initialized
INFO - 2024-03-22 06:48:44 --> Security Class Initialized
DEBUG - 2024-03-22 06:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 06:48:44 --> Input Class Initialized
INFO - 2024-03-22 06:48:44 --> Language Class Initialized
INFO - 2024-03-22 06:48:44 --> Loader Class Initialized
INFO - 2024-03-22 06:48:44 --> Helper loaded: url_helper
INFO - 2024-03-22 06:48:44 --> Helper loaded: file_helper
INFO - 2024-03-22 06:48:44 --> Helper loaded: html_helper
INFO - 2024-03-22 06:48:44 --> Helper loaded: text_helper
INFO - 2024-03-22 06:48:44 --> Helper loaded: form_helper
INFO - 2024-03-22 06:48:44 --> Helper loaded: lang_helper
INFO - 2024-03-22 06:48:44 --> Helper loaded: security_helper
INFO - 2024-03-22 06:48:44 --> Helper loaded: cookie_helper
INFO - 2024-03-22 06:48:44 --> Database Driver Class Initialized
INFO - 2024-03-22 06:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 06:48:44 --> Parser Class Initialized
INFO - 2024-03-22 06:48:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 06:48:44 --> Pagination Class Initialized
INFO - 2024-03-22 06:48:44 --> Form Validation Class Initialized
INFO - 2024-03-22 06:48:44 --> Controller Class Initialized
INFO - 2024-03-22 06:48:44 --> Model Class Initialized
DEBUG - 2024-03-22 06:48:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 06:48:44 --> Model Class Initialized
DEBUG - 2024-03-22 06:48:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 06:48:44 --> Model Class Initialized
INFO - 2024-03-22 06:48:44 --> Model Class Initialized
INFO - 2024-03-22 06:48:44 --> Model Class Initialized
INFO - 2024-03-22 06:48:44 --> Model Class Initialized
DEBUG - 2024-03-22 06:48:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 06:48:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 06:48:44 --> Model Class Initialized
INFO - 2024-03-22 06:48:44 --> Model Class Initialized
INFO - 2024-03-22 06:48:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 06:48:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 06:48:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 06:48:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 06:48:45 --> Model Class Initialized
INFO - 2024-03-22 06:48:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 06:48:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 06:48:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 06:48:45 --> Final output sent to browser
DEBUG - 2024-03-22 06:48:45 --> Total execution time: 0.2537
ERROR - 2024-03-22 06:48:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 06:48:52 --> Config Class Initialized
INFO - 2024-03-22 06:48:52 --> Hooks Class Initialized
DEBUG - 2024-03-22 06:48:52 --> UTF-8 Support Enabled
INFO - 2024-03-22 06:48:52 --> Utf8 Class Initialized
INFO - 2024-03-22 06:48:52 --> URI Class Initialized
INFO - 2024-03-22 06:48:52 --> Router Class Initialized
INFO - 2024-03-22 06:48:52 --> Output Class Initialized
INFO - 2024-03-22 06:48:52 --> Security Class Initialized
DEBUG - 2024-03-22 06:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 06:48:52 --> Input Class Initialized
INFO - 2024-03-22 06:48:52 --> Language Class Initialized
INFO - 2024-03-22 06:48:52 --> Loader Class Initialized
INFO - 2024-03-22 06:48:52 --> Helper loaded: url_helper
INFO - 2024-03-22 06:48:52 --> Helper loaded: file_helper
INFO - 2024-03-22 06:48:52 --> Helper loaded: html_helper
INFO - 2024-03-22 06:48:52 --> Helper loaded: text_helper
INFO - 2024-03-22 06:48:52 --> Helper loaded: form_helper
INFO - 2024-03-22 06:48:52 --> Helper loaded: lang_helper
INFO - 2024-03-22 06:48:52 --> Helper loaded: security_helper
INFO - 2024-03-22 06:48:52 --> Helper loaded: cookie_helper
INFO - 2024-03-22 06:48:52 --> Database Driver Class Initialized
INFO - 2024-03-22 06:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 06:48:52 --> Parser Class Initialized
INFO - 2024-03-22 06:48:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 06:48:52 --> Pagination Class Initialized
INFO - 2024-03-22 06:48:52 --> Form Validation Class Initialized
INFO - 2024-03-22 06:48:52 --> Controller Class Initialized
INFO - 2024-03-22 06:48:52 --> Model Class Initialized
DEBUG - 2024-03-22 06:48:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 06:48:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 06:48:52 --> Model Class Initialized
DEBUG - 2024-03-22 06:48:52 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 06:48:52 --> Model Class Initialized
INFO - 2024-03-22 06:48:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-22 06:48:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 06:48:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 06:48:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 06:48:52 --> Model Class Initialized
INFO - 2024-03-22 06:48:52 --> Model Class Initialized
INFO - 2024-03-22 06:48:52 --> Model Class Initialized
INFO - 2024-03-22 06:48:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 06:48:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 06:48:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 06:48:52 --> Final output sent to browser
DEBUG - 2024-03-22 06:48:52 --> Total execution time: 0.1684
ERROR - 2024-03-22 06:48:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 06:48:53 --> Config Class Initialized
INFO - 2024-03-22 06:48:53 --> Hooks Class Initialized
DEBUG - 2024-03-22 06:48:53 --> UTF-8 Support Enabled
INFO - 2024-03-22 06:48:53 --> Utf8 Class Initialized
INFO - 2024-03-22 06:48:53 --> URI Class Initialized
INFO - 2024-03-22 06:48:53 --> Router Class Initialized
INFO - 2024-03-22 06:48:53 --> Output Class Initialized
INFO - 2024-03-22 06:48:53 --> Security Class Initialized
DEBUG - 2024-03-22 06:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 06:48:53 --> Input Class Initialized
INFO - 2024-03-22 06:48:53 --> Language Class Initialized
INFO - 2024-03-22 06:48:53 --> Loader Class Initialized
INFO - 2024-03-22 06:48:53 --> Helper loaded: url_helper
INFO - 2024-03-22 06:48:53 --> Helper loaded: file_helper
INFO - 2024-03-22 06:48:53 --> Helper loaded: html_helper
INFO - 2024-03-22 06:48:53 --> Helper loaded: text_helper
INFO - 2024-03-22 06:48:53 --> Helper loaded: form_helper
INFO - 2024-03-22 06:48:53 --> Helper loaded: lang_helper
INFO - 2024-03-22 06:48:53 --> Helper loaded: security_helper
INFO - 2024-03-22 06:48:53 --> Helper loaded: cookie_helper
INFO - 2024-03-22 06:48:53 --> Database Driver Class Initialized
INFO - 2024-03-22 06:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 06:48:53 --> Parser Class Initialized
INFO - 2024-03-22 06:48:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 06:48:53 --> Pagination Class Initialized
INFO - 2024-03-22 06:48:53 --> Form Validation Class Initialized
INFO - 2024-03-22 06:48:53 --> Controller Class Initialized
INFO - 2024-03-22 06:48:53 --> Model Class Initialized
DEBUG - 2024-03-22 06:48:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 06:48:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 06:48:53 --> Model Class Initialized
DEBUG - 2024-03-22 06:48:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 06:48:53 --> Model Class Initialized
INFO - 2024-03-22 06:48:53 --> Final output sent to browser
DEBUG - 2024-03-22 06:48:53 --> Total execution time: 0.0423
ERROR - 2024-03-22 06:52:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 06:52:29 --> Config Class Initialized
INFO - 2024-03-22 06:52:29 --> Hooks Class Initialized
DEBUG - 2024-03-22 06:52:29 --> UTF-8 Support Enabled
INFO - 2024-03-22 06:52:29 --> Utf8 Class Initialized
INFO - 2024-03-22 06:52:29 --> URI Class Initialized
DEBUG - 2024-03-22 06:52:29 --> No URI present. Default controller set.
INFO - 2024-03-22 06:52:29 --> Router Class Initialized
INFO - 2024-03-22 06:52:29 --> Output Class Initialized
INFO - 2024-03-22 06:52:29 --> Security Class Initialized
DEBUG - 2024-03-22 06:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 06:52:29 --> Input Class Initialized
INFO - 2024-03-22 06:52:29 --> Language Class Initialized
INFO - 2024-03-22 06:52:29 --> Loader Class Initialized
INFO - 2024-03-22 06:52:29 --> Helper loaded: url_helper
INFO - 2024-03-22 06:52:29 --> Helper loaded: file_helper
INFO - 2024-03-22 06:52:29 --> Helper loaded: html_helper
INFO - 2024-03-22 06:52:29 --> Helper loaded: text_helper
INFO - 2024-03-22 06:52:29 --> Helper loaded: form_helper
INFO - 2024-03-22 06:52:29 --> Helper loaded: lang_helper
INFO - 2024-03-22 06:52:29 --> Helper loaded: security_helper
INFO - 2024-03-22 06:52:29 --> Helper loaded: cookie_helper
INFO - 2024-03-22 06:52:29 --> Database Driver Class Initialized
INFO - 2024-03-22 06:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 06:52:29 --> Parser Class Initialized
INFO - 2024-03-22 06:52:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 06:52:29 --> Pagination Class Initialized
INFO - 2024-03-22 06:52:29 --> Form Validation Class Initialized
INFO - 2024-03-22 06:52:29 --> Controller Class Initialized
INFO - 2024-03-22 06:52:29 --> Model Class Initialized
DEBUG - 2024-03-22 06:52:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 06:52:29 --> Model Class Initialized
DEBUG - 2024-03-22 06:52:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 06:52:29 --> Model Class Initialized
INFO - 2024-03-22 06:52:29 --> Model Class Initialized
INFO - 2024-03-22 06:52:29 --> Model Class Initialized
INFO - 2024-03-22 06:52:29 --> Model Class Initialized
DEBUG - 2024-03-22 06:52:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 06:52:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 06:52:29 --> Model Class Initialized
INFO - 2024-03-22 06:52:29 --> Model Class Initialized
INFO - 2024-03-22 06:52:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 06:52:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 06:52:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 06:52:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 06:52:29 --> Model Class Initialized
INFO - 2024-03-22 06:52:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 06:52:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 06:52:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 06:52:29 --> Final output sent to browser
DEBUG - 2024-03-22 06:52:29 --> Total execution time: 0.2685
ERROR - 2024-03-22 06:52:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 06:52:34 --> Config Class Initialized
INFO - 2024-03-22 06:52:34 --> Hooks Class Initialized
DEBUG - 2024-03-22 06:52:34 --> UTF-8 Support Enabled
INFO - 2024-03-22 06:52:34 --> Utf8 Class Initialized
INFO - 2024-03-22 06:52:34 --> URI Class Initialized
INFO - 2024-03-22 06:52:34 --> Router Class Initialized
INFO - 2024-03-22 06:52:34 --> Output Class Initialized
INFO - 2024-03-22 06:52:34 --> Security Class Initialized
DEBUG - 2024-03-22 06:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 06:52:34 --> Input Class Initialized
INFO - 2024-03-22 06:52:34 --> Language Class Initialized
INFO - 2024-03-22 06:52:34 --> Loader Class Initialized
INFO - 2024-03-22 06:52:34 --> Helper loaded: url_helper
INFO - 2024-03-22 06:52:34 --> Helper loaded: file_helper
INFO - 2024-03-22 06:52:34 --> Helper loaded: html_helper
INFO - 2024-03-22 06:52:34 --> Helper loaded: text_helper
INFO - 2024-03-22 06:52:34 --> Helper loaded: form_helper
INFO - 2024-03-22 06:52:34 --> Helper loaded: lang_helper
INFO - 2024-03-22 06:52:34 --> Helper loaded: security_helper
INFO - 2024-03-22 06:52:34 --> Helper loaded: cookie_helper
INFO - 2024-03-22 06:52:34 --> Database Driver Class Initialized
INFO - 2024-03-22 06:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 06:52:34 --> Parser Class Initialized
INFO - 2024-03-22 06:52:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 06:52:34 --> Pagination Class Initialized
INFO - 2024-03-22 06:52:34 --> Form Validation Class Initialized
INFO - 2024-03-22 06:52:34 --> Controller Class Initialized
INFO - 2024-03-22 06:52:34 --> Model Class Initialized
DEBUG - 2024-03-22 06:52:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 06:52:34 --> Final output sent to browser
DEBUG - 2024-03-22 06:52:34 --> Total execution time: 0.0128
ERROR - 2024-03-22 06:52:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 06:52:34 --> Config Class Initialized
INFO - 2024-03-22 06:52:34 --> Hooks Class Initialized
DEBUG - 2024-03-22 06:52:34 --> UTF-8 Support Enabled
INFO - 2024-03-22 06:52:34 --> Utf8 Class Initialized
INFO - 2024-03-22 06:52:34 --> URI Class Initialized
INFO - 2024-03-22 06:52:34 --> Router Class Initialized
INFO - 2024-03-22 06:52:34 --> Output Class Initialized
INFO - 2024-03-22 06:52:34 --> Security Class Initialized
DEBUG - 2024-03-22 06:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 06:52:34 --> Input Class Initialized
INFO - 2024-03-22 06:52:34 --> Language Class Initialized
INFO - 2024-03-22 06:52:34 --> Loader Class Initialized
INFO - 2024-03-22 06:52:34 --> Helper loaded: url_helper
INFO - 2024-03-22 06:52:34 --> Helper loaded: file_helper
INFO - 2024-03-22 06:52:34 --> Helper loaded: html_helper
INFO - 2024-03-22 06:52:34 --> Helper loaded: text_helper
INFO - 2024-03-22 06:52:34 --> Helper loaded: form_helper
INFO - 2024-03-22 06:52:34 --> Helper loaded: lang_helper
INFO - 2024-03-22 06:52:34 --> Helper loaded: security_helper
INFO - 2024-03-22 06:52:34 --> Helper loaded: cookie_helper
INFO - 2024-03-22 06:52:34 --> Database Driver Class Initialized
INFO - 2024-03-22 06:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 06:52:34 --> Parser Class Initialized
INFO - 2024-03-22 06:52:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 06:52:34 --> Pagination Class Initialized
INFO - 2024-03-22 06:52:34 --> Form Validation Class Initialized
INFO - 2024-03-22 06:52:34 --> Controller Class Initialized
INFO - 2024-03-22 06:52:34 --> Model Class Initialized
DEBUG - 2024-03-22 06:52:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 06:52:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-22 06:52:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 06:52:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 06:52:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 06:52:34 --> Model Class Initialized
INFO - 2024-03-22 06:52:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 06:52:34 --> Final output sent to browser
DEBUG - 2024-03-22 06:52:34 --> Total execution time: 0.0384
ERROR - 2024-03-22 06:52:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 06:52:41 --> Config Class Initialized
INFO - 2024-03-22 06:52:41 --> Hooks Class Initialized
DEBUG - 2024-03-22 06:52:41 --> UTF-8 Support Enabled
INFO - 2024-03-22 06:52:41 --> Utf8 Class Initialized
INFO - 2024-03-22 06:52:41 --> URI Class Initialized
INFO - 2024-03-22 06:52:41 --> Router Class Initialized
INFO - 2024-03-22 06:52:41 --> Output Class Initialized
INFO - 2024-03-22 06:52:41 --> Security Class Initialized
DEBUG - 2024-03-22 06:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 06:52:41 --> Input Class Initialized
INFO - 2024-03-22 06:52:41 --> Language Class Initialized
INFO - 2024-03-22 06:52:41 --> Loader Class Initialized
INFO - 2024-03-22 06:52:41 --> Helper loaded: url_helper
INFO - 2024-03-22 06:52:41 --> Helper loaded: file_helper
INFO - 2024-03-22 06:52:41 --> Helper loaded: html_helper
INFO - 2024-03-22 06:52:41 --> Helper loaded: text_helper
INFO - 2024-03-22 06:52:41 --> Helper loaded: form_helper
INFO - 2024-03-22 06:52:41 --> Helper loaded: lang_helper
INFO - 2024-03-22 06:52:41 --> Helper loaded: security_helper
INFO - 2024-03-22 06:52:41 --> Helper loaded: cookie_helper
INFO - 2024-03-22 06:52:41 --> Database Driver Class Initialized
INFO - 2024-03-22 06:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 06:52:41 --> Parser Class Initialized
INFO - 2024-03-22 06:52:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 06:52:41 --> Pagination Class Initialized
INFO - 2024-03-22 06:52:41 --> Form Validation Class Initialized
INFO - 2024-03-22 06:52:41 --> Controller Class Initialized
INFO - 2024-03-22 06:52:41 --> Model Class Initialized
DEBUG - 2024-03-22 06:52:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 06:52:41 --> Model Class Initialized
INFO - 2024-03-22 06:52:41 --> Final output sent to browser
DEBUG - 2024-03-22 06:52:41 --> Total execution time: 0.0215
ERROR - 2024-03-22 06:52:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 06:52:42 --> Config Class Initialized
INFO - 2024-03-22 06:52:42 --> Hooks Class Initialized
DEBUG - 2024-03-22 06:52:42 --> UTF-8 Support Enabled
INFO - 2024-03-22 06:52:42 --> Utf8 Class Initialized
INFO - 2024-03-22 06:52:42 --> URI Class Initialized
DEBUG - 2024-03-22 06:52:42 --> No URI present. Default controller set.
INFO - 2024-03-22 06:52:42 --> Router Class Initialized
INFO - 2024-03-22 06:52:42 --> Output Class Initialized
INFO - 2024-03-22 06:52:42 --> Security Class Initialized
DEBUG - 2024-03-22 06:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 06:52:42 --> Input Class Initialized
INFO - 2024-03-22 06:52:42 --> Language Class Initialized
INFO - 2024-03-22 06:52:42 --> Loader Class Initialized
INFO - 2024-03-22 06:52:42 --> Helper loaded: url_helper
INFO - 2024-03-22 06:52:42 --> Helper loaded: file_helper
INFO - 2024-03-22 06:52:42 --> Helper loaded: html_helper
INFO - 2024-03-22 06:52:42 --> Helper loaded: text_helper
INFO - 2024-03-22 06:52:42 --> Helper loaded: form_helper
INFO - 2024-03-22 06:52:42 --> Helper loaded: lang_helper
INFO - 2024-03-22 06:52:42 --> Helper loaded: security_helper
INFO - 2024-03-22 06:52:42 --> Helper loaded: cookie_helper
INFO - 2024-03-22 06:52:42 --> Database Driver Class Initialized
INFO - 2024-03-22 06:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 06:52:42 --> Parser Class Initialized
INFO - 2024-03-22 06:52:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 06:52:42 --> Pagination Class Initialized
INFO - 2024-03-22 06:52:42 --> Form Validation Class Initialized
INFO - 2024-03-22 06:52:42 --> Controller Class Initialized
INFO - 2024-03-22 06:52:42 --> Model Class Initialized
DEBUG - 2024-03-22 06:52:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 06:52:42 --> Model Class Initialized
DEBUG - 2024-03-22 06:52:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 06:52:42 --> Model Class Initialized
INFO - 2024-03-22 06:52:42 --> Model Class Initialized
INFO - 2024-03-22 06:52:42 --> Model Class Initialized
INFO - 2024-03-22 06:52:42 --> Model Class Initialized
DEBUG - 2024-03-22 06:52:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 06:52:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 06:52:42 --> Model Class Initialized
INFO - 2024-03-22 06:52:42 --> Model Class Initialized
INFO - 2024-03-22 06:52:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 06:52:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 06:52:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 06:52:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 06:52:42 --> Model Class Initialized
INFO - 2024-03-22 06:52:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 06:52:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 06:52:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 06:52:42 --> Final output sent to browser
DEBUG - 2024-03-22 06:52:42 --> Total execution time: 0.4486
ERROR - 2024-03-22 06:52:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 06:52:43 --> Config Class Initialized
INFO - 2024-03-22 06:52:43 --> Hooks Class Initialized
DEBUG - 2024-03-22 06:52:43 --> UTF-8 Support Enabled
INFO - 2024-03-22 06:52:43 --> Utf8 Class Initialized
INFO - 2024-03-22 06:52:43 --> URI Class Initialized
INFO - 2024-03-22 06:52:43 --> Router Class Initialized
INFO - 2024-03-22 06:52:43 --> Output Class Initialized
INFO - 2024-03-22 06:52:43 --> Security Class Initialized
DEBUG - 2024-03-22 06:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 06:52:43 --> Input Class Initialized
INFO - 2024-03-22 06:52:43 --> Language Class Initialized
INFO - 2024-03-22 06:52:43 --> Loader Class Initialized
INFO - 2024-03-22 06:52:43 --> Helper loaded: url_helper
INFO - 2024-03-22 06:52:43 --> Helper loaded: file_helper
INFO - 2024-03-22 06:52:43 --> Helper loaded: html_helper
INFO - 2024-03-22 06:52:43 --> Helper loaded: text_helper
INFO - 2024-03-22 06:52:43 --> Helper loaded: form_helper
INFO - 2024-03-22 06:52:43 --> Helper loaded: lang_helper
INFO - 2024-03-22 06:52:43 --> Helper loaded: security_helper
INFO - 2024-03-22 06:52:43 --> Helper loaded: cookie_helper
INFO - 2024-03-22 06:52:43 --> Database Driver Class Initialized
INFO - 2024-03-22 06:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 06:52:43 --> Parser Class Initialized
INFO - 2024-03-22 06:52:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 06:52:43 --> Pagination Class Initialized
INFO - 2024-03-22 06:52:43 --> Form Validation Class Initialized
INFO - 2024-03-22 06:52:43 --> Controller Class Initialized
DEBUG - 2024-03-22 06:52:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 06:52:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 06:52:43 --> Model Class Initialized
INFO - 2024-03-22 06:52:43 --> Final output sent to browser
DEBUG - 2024-03-22 06:52:43 --> Total execution time: 0.0143
ERROR - 2024-03-22 06:52:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 06:52:54 --> Config Class Initialized
INFO - 2024-03-22 06:52:54 --> Hooks Class Initialized
DEBUG - 2024-03-22 06:52:54 --> UTF-8 Support Enabled
INFO - 2024-03-22 06:52:54 --> Utf8 Class Initialized
INFO - 2024-03-22 06:52:54 --> URI Class Initialized
INFO - 2024-03-22 06:52:54 --> Router Class Initialized
INFO - 2024-03-22 06:52:54 --> Output Class Initialized
INFO - 2024-03-22 06:52:54 --> Security Class Initialized
DEBUG - 2024-03-22 06:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 06:52:54 --> Input Class Initialized
INFO - 2024-03-22 06:52:54 --> Language Class Initialized
INFO - 2024-03-22 06:52:54 --> Loader Class Initialized
INFO - 2024-03-22 06:52:54 --> Helper loaded: url_helper
INFO - 2024-03-22 06:52:54 --> Helper loaded: file_helper
INFO - 2024-03-22 06:52:54 --> Helper loaded: html_helper
INFO - 2024-03-22 06:52:54 --> Helper loaded: text_helper
INFO - 2024-03-22 06:52:54 --> Helper loaded: form_helper
INFO - 2024-03-22 06:52:54 --> Helper loaded: lang_helper
INFO - 2024-03-22 06:52:54 --> Helper loaded: security_helper
INFO - 2024-03-22 06:52:54 --> Helper loaded: cookie_helper
INFO - 2024-03-22 06:52:54 --> Database Driver Class Initialized
INFO - 2024-03-22 06:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 06:52:54 --> Parser Class Initialized
INFO - 2024-03-22 06:52:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 06:52:54 --> Pagination Class Initialized
INFO - 2024-03-22 06:52:54 --> Form Validation Class Initialized
INFO - 2024-03-22 06:52:54 --> Controller Class Initialized
INFO - 2024-03-22 06:52:54 --> Model Class Initialized
DEBUG - 2024-03-22 06:52:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 06:52:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 06:52:54 --> Model Class Initialized
DEBUG - 2024-03-22 06:52:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 06:52:54 --> Model Class Initialized
INFO - 2024-03-22 06:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-22 06:52:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 06:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 06:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 06:52:54 --> Model Class Initialized
INFO - 2024-03-22 06:52:54 --> Model Class Initialized
INFO - 2024-03-22 06:52:54 --> Model Class Initialized
INFO - 2024-03-22 06:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 06:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 06:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 06:52:54 --> Final output sent to browser
DEBUG - 2024-03-22 06:52:54 --> Total execution time: 0.2407
ERROR - 2024-03-22 06:52:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 06:52:54 --> Config Class Initialized
INFO - 2024-03-22 06:52:54 --> Hooks Class Initialized
DEBUG - 2024-03-22 06:52:54 --> UTF-8 Support Enabled
INFO - 2024-03-22 06:52:54 --> Utf8 Class Initialized
INFO - 2024-03-22 06:52:54 --> URI Class Initialized
INFO - 2024-03-22 06:52:54 --> Router Class Initialized
INFO - 2024-03-22 06:52:54 --> Output Class Initialized
INFO - 2024-03-22 06:52:54 --> Security Class Initialized
DEBUG - 2024-03-22 06:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 06:52:54 --> Input Class Initialized
INFO - 2024-03-22 06:52:54 --> Language Class Initialized
INFO - 2024-03-22 06:52:54 --> Loader Class Initialized
INFO - 2024-03-22 06:52:54 --> Helper loaded: url_helper
INFO - 2024-03-22 06:52:54 --> Helper loaded: file_helper
INFO - 2024-03-22 06:52:54 --> Helper loaded: html_helper
INFO - 2024-03-22 06:52:54 --> Helper loaded: text_helper
INFO - 2024-03-22 06:52:54 --> Helper loaded: form_helper
INFO - 2024-03-22 06:52:54 --> Helper loaded: lang_helper
INFO - 2024-03-22 06:52:54 --> Helper loaded: security_helper
INFO - 2024-03-22 06:52:54 --> Helper loaded: cookie_helper
INFO - 2024-03-22 06:52:54 --> Database Driver Class Initialized
INFO - 2024-03-22 06:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 06:52:54 --> Parser Class Initialized
INFO - 2024-03-22 06:52:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 06:52:54 --> Pagination Class Initialized
INFO - 2024-03-22 06:52:54 --> Form Validation Class Initialized
INFO - 2024-03-22 06:52:54 --> Controller Class Initialized
INFO - 2024-03-22 06:52:54 --> Model Class Initialized
DEBUG - 2024-03-22 06:52:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 06:52:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 06:52:54 --> Model Class Initialized
DEBUG - 2024-03-22 06:52:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 06:52:54 --> Model Class Initialized
INFO - 2024-03-22 06:52:55 --> Final output sent to browser
DEBUG - 2024-03-22 06:52:55 --> Total execution time: 0.0556
ERROR - 2024-03-22 07:04:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:13 --> Config Class Initialized
INFO - 2024-03-22 07:04:13 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:13 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:13 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:13 --> URI Class Initialized
DEBUG - 2024-03-22 07:04:13 --> No URI present. Default controller set.
INFO - 2024-03-22 07:04:13 --> Router Class Initialized
INFO - 2024-03-22 07:04:13 --> Output Class Initialized
INFO - 2024-03-22 07:04:13 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:13 --> Input Class Initialized
INFO - 2024-03-22 07:04:13 --> Language Class Initialized
INFO - 2024-03-22 07:04:13 --> Loader Class Initialized
INFO - 2024-03-22 07:04:13 --> Helper loaded: url_helper
INFO - 2024-03-22 07:04:13 --> Helper loaded: file_helper
INFO - 2024-03-22 07:04:13 --> Helper loaded: html_helper
INFO - 2024-03-22 07:04:13 --> Helper loaded: text_helper
INFO - 2024-03-22 07:04:13 --> Helper loaded: form_helper
INFO - 2024-03-22 07:04:13 --> Helper loaded: lang_helper
INFO - 2024-03-22 07:04:13 --> Helper loaded: security_helper
INFO - 2024-03-22 07:04:13 --> Helper loaded: cookie_helper
INFO - 2024-03-22 07:04:13 --> Database Driver Class Initialized
INFO - 2024-03-22 07:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 07:04:13 --> Parser Class Initialized
INFO - 2024-03-22 07:04:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 07:04:13 --> Pagination Class Initialized
INFO - 2024-03-22 07:04:13 --> Form Validation Class Initialized
INFO - 2024-03-22 07:04:13 --> Controller Class Initialized
INFO - 2024-03-22 07:04:13 --> Model Class Initialized
DEBUG - 2024-03-22 07:04:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 07:04:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:15 --> Config Class Initialized
INFO - 2024-03-22 07:04:15 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:15 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:15 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:15 --> URI Class Initialized
DEBUG - 2024-03-22 07:04:15 --> No URI present. Default controller set.
INFO - 2024-03-22 07:04:15 --> Router Class Initialized
INFO - 2024-03-22 07:04:15 --> Output Class Initialized
INFO - 2024-03-22 07:04:15 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:15 --> Input Class Initialized
INFO - 2024-03-22 07:04:15 --> Language Class Initialized
INFO - 2024-03-22 07:04:15 --> Loader Class Initialized
INFO - 2024-03-22 07:04:15 --> Helper loaded: url_helper
INFO - 2024-03-22 07:04:15 --> Helper loaded: file_helper
INFO - 2024-03-22 07:04:15 --> Helper loaded: html_helper
INFO - 2024-03-22 07:04:15 --> Helper loaded: text_helper
INFO - 2024-03-22 07:04:15 --> Helper loaded: form_helper
INFO - 2024-03-22 07:04:15 --> Helper loaded: lang_helper
INFO - 2024-03-22 07:04:15 --> Helper loaded: security_helper
INFO - 2024-03-22 07:04:15 --> Helper loaded: cookie_helper
INFO - 2024-03-22 07:04:15 --> Database Driver Class Initialized
INFO - 2024-03-22 07:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 07:04:15 --> Parser Class Initialized
INFO - 2024-03-22 07:04:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 07:04:15 --> Pagination Class Initialized
INFO - 2024-03-22 07:04:15 --> Form Validation Class Initialized
INFO - 2024-03-22 07:04:15 --> Controller Class Initialized
INFO - 2024-03-22 07:04:15 --> Model Class Initialized
DEBUG - 2024-03-22 07:04:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 07:04:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:16 --> Config Class Initialized
INFO - 2024-03-22 07:04:16 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:16 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:16 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:16 --> URI Class Initialized
DEBUG - 2024-03-22 07:04:16 --> No URI present. Default controller set.
INFO - 2024-03-22 07:04:16 --> Router Class Initialized
INFO - 2024-03-22 07:04:16 --> Output Class Initialized
INFO - 2024-03-22 07:04:16 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:16 --> Input Class Initialized
INFO - 2024-03-22 07:04:16 --> Language Class Initialized
INFO - 2024-03-22 07:04:16 --> Loader Class Initialized
INFO - 2024-03-22 07:04:16 --> Helper loaded: url_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: file_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: html_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: text_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: form_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: lang_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: security_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: cookie_helper
INFO - 2024-03-22 07:04:16 --> Database Driver Class Initialized
INFO - 2024-03-22 07:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 07:04:16 --> Parser Class Initialized
INFO - 2024-03-22 07:04:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 07:04:16 --> Pagination Class Initialized
INFO - 2024-03-22 07:04:16 --> Form Validation Class Initialized
INFO - 2024-03-22 07:04:16 --> Controller Class Initialized
INFO - 2024-03-22 07:04:16 --> Model Class Initialized
DEBUG - 2024-03-22 07:04:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 07:04:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:16 --> Config Class Initialized
INFO - 2024-03-22 07:04:16 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:16 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:16 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:16 --> URI Class Initialized
DEBUG - 2024-03-22 07:04:16 --> No URI present. Default controller set.
INFO - 2024-03-22 07:04:16 --> Router Class Initialized
INFO - 2024-03-22 07:04:16 --> Output Class Initialized
INFO - 2024-03-22 07:04:16 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:16 --> Input Class Initialized
INFO - 2024-03-22 07:04:16 --> Language Class Initialized
INFO - 2024-03-22 07:04:16 --> Loader Class Initialized
INFO - 2024-03-22 07:04:16 --> Helper loaded: url_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: file_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: html_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: text_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: form_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: lang_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: security_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: cookie_helper
INFO - 2024-03-22 07:04:16 --> Database Driver Class Initialized
INFO - 2024-03-22 07:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 07:04:16 --> Parser Class Initialized
INFO - 2024-03-22 07:04:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 07:04:16 --> Pagination Class Initialized
INFO - 2024-03-22 07:04:16 --> Form Validation Class Initialized
INFO - 2024-03-22 07:04:16 --> Controller Class Initialized
INFO - 2024-03-22 07:04:16 --> Model Class Initialized
DEBUG - 2024-03-22 07:04:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 07:04:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:16 --> Config Class Initialized
INFO - 2024-03-22 07:04:16 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:16 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:16 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:16 --> URI Class Initialized
DEBUG - 2024-03-22 07:04:16 --> No URI present. Default controller set.
INFO - 2024-03-22 07:04:16 --> Router Class Initialized
INFO - 2024-03-22 07:04:16 --> Output Class Initialized
INFO - 2024-03-22 07:04:16 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:16 --> Input Class Initialized
INFO - 2024-03-22 07:04:16 --> Language Class Initialized
INFO - 2024-03-22 07:04:16 --> Loader Class Initialized
INFO - 2024-03-22 07:04:16 --> Helper loaded: url_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: file_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: html_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: text_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: form_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: lang_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: security_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: cookie_helper
INFO - 2024-03-22 07:04:16 --> Database Driver Class Initialized
INFO - 2024-03-22 07:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 07:04:16 --> Parser Class Initialized
INFO - 2024-03-22 07:04:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 07:04:16 --> Pagination Class Initialized
INFO - 2024-03-22 07:04:16 --> Form Validation Class Initialized
INFO - 2024-03-22 07:04:16 --> Controller Class Initialized
INFO - 2024-03-22 07:04:16 --> Model Class Initialized
DEBUG - 2024-03-22 07:04:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 07:04:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:16 --> Config Class Initialized
INFO - 2024-03-22 07:04:16 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:16 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:16 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:16 --> URI Class Initialized
INFO - 2024-03-22 07:04:16 --> Router Class Initialized
INFO - 2024-03-22 07:04:16 --> Output Class Initialized
INFO - 2024-03-22 07:04:16 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:16 --> Input Class Initialized
INFO - 2024-03-22 07:04:16 --> Language Class Initialized
ERROR - 2024-03-22 07:04:16 --> 404 Page Not Found: Server/index
ERROR - 2024-03-22 07:04:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:16 --> Config Class Initialized
INFO - 2024-03-22 07:04:16 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:16 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:16 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:16 --> URI Class Initialized
DEBUG - 2024-03-22 07:04:16 --> No URI present. Default controller set.
INFO - 2024-03-22 07:04:16 --> Router Class Initialized
INFO - 2024-03-22 07:04:16 --> Output Class Initialized
INFO - 2024-03-22 07:04:16 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:16 --> Input Class Initialized
INFO - 2024-03-22 07:04:16 --> Language Class Initialized
INFO - 2024-03-22 07:04:16 --> Loader Class Initialized
INFO - 2024-03-22 07:04:16 --> Helper loaded: url_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: file_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: html_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: text_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: form_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: lang_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: security_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: cookie_helper
INFO - 2024-03-22 07:04:16 --> Database Driver Class Initialized
INFO - 2024-03-22 07:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 07:04:16 --> Parser Class Initialized
INFO - 2024-03-22 07:04:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 07:04:16 --> Pagination Class Initialized
INFO - 2024-03-22 07:04:16 --> Form Validation Class Initialized
INFO - 2024-03-22 07:04:16 --> Controller Class Initialized
INFO - 2024-03-22 07:04:16 --> Model Class Initialized
DEBUG - 2024-03-22 07:04:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 07:04:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:16 --> Config Class Initialized
INFO - 2024-03-22 07:04:16 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:16 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:16 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:16 --> URI Class Initialized
DEBUG - 2024-03-22 07:04:16 --> No URI present. Default controller set.
INFO - 2024-03-22 07:04:16 --> Router Class Initialized
INFO - 2024-03-22 07:04:16 --> Output Class Initialized
INFO - 2024-03-22 07:04:16 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:16 --> Input Class Initialized
INFO - 2024-03-22 07:04:16 --> Language Class Initialized
INFO - 2024-03-22 07:04:16 --> Loader Class Initialized
INFO - 2024-03-22 07:04:16 --> Helper loaded: url_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: file_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: html_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: text_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: form_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: lang_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: security_helper
INFO - 2024-03-22 07:04:16 --> Helper loaded: cookie_helper
INFO - 2024-03-22 07:04:16 --> Database Driver Class Initialized
INFO - 2024-03-22 07:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 07:04:16 --> Parser Class Initialized
INFO - 2024-03-22 07:04:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 07:04:16 --> Pagination Class Initialized
INFO - 2024-03-22 07:04:16 --> Form Validation Class Initialized
INFO - 2024-03-22 07:04:16 --> Controller Class Initialized
INFO - 2024-03-22 07:04:16 --> Model Class Initialized
DEBUG - 2024-03-22 07:04:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 07:04:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:17 --> Config Class Initialized
INFO - 2024-03-22 07:04:17 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:17 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:17 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:17 --> URI Class Initialized
INFO - 2024-03-22 07:04:17 --> Router Class Initialized
INFO - 2024-03-22 07:04:17 --> Output Class Initialized
INFO - 2024-03-22 07:04:17 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:17 --> Input Class Initialized
INFO - 2024-03-22 07:04:17 --> Language Class Initialized
ERROR - 2024-03-22 07:04:17 --> 404 Page Not Found: Vscode/sftp.json
ERROR - 2024-03-22 07:04:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:17 --> Config Class Initialized
INFO - 2024-03-22 07:04:17 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:17 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:17 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:17 --> URI Class Initialized
INFO - 2024-03-22 07:04:17 --> Router Class Initialized
INFO - 2024-03-22 07:04:17 --> Output Class Initialized
INFO - 2024-03-22 07:04:17 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:17 --> Input Class Initialized
INFO - 2024-03-22 07:04:17 --> Language Class Initialized
ERROR - 2024-03-22 07:04:17 --> 404 Page Not Found: Server/index
ERROR - 2024-03-22 07:04:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:17 --> Config Class Initialized
INFO - 2024-03-22 07:04:17 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:17 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:17 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:17 --> URI Class Initialized
INFO - 2024-03-22 07:04:17 --> Router Class Initialized
INFO - 2024-03-22 07:04:17 --> Output Class Initialized
INFO - 2024-03-22 07:04:17 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:17 --> Input Class Initialized
INFO - 2024-03-22 07:04:17 --> Language Class Initialized
ERROR - 2024-03-22 07:04:17 --> 404 Page Not Found: About/index
ERROR - 2024-03-22 07:04:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:17 --> Config Class Initialized
INFO - 2024-03-22 07:04:17 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:17 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:17 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:17 --> URI Class Initialized
INFO - 2024-03-22 07:04:17 --> Router Class Initialized
INFO - 2024-03-22 07:04:17 --> Output Class Initialized
INFO - 2024-03-22 07:04:17 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:17 --> Input Class Initialized
INFO - 2024-03-22 07:04:17 --> Language Class Initialized
ERROR - 2024-03-22 07:04:17 --> 404 Page Not Found: Vscode/sftp.json
ERROR - 2024-03-22 07:04:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:18 --> Config Class Initialized
INFO - 2024-03-22 07:04:18 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:18 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:18 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:18 --> URI Class Initialized
INFO - 2024-03-22 07:04:18 --> Router Class Initialized
INFO - 2024-03-22 07:04:18 --> Output Class Initialized
INFO - 2024-03-22 07:04:18 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:18 --> Input Class Initialized
INFO - 2024-03-22 07:04:18 --> Language Class Initialized
ERROR - 2024-03-22 07:04:18 --> 404 Page Not Found: Debug/default
ERROR - 2024-03-22 07:04:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:18 --> Config Class Initialized
INFO - 2024-03-22 07:04:18 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:18 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:18 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:18 --> URI Class Initialized
INFO - 2024-03-22 07:04:18 --> Router Class Initialized
INFO - 2024-03-22 07:04:18 --> Output Class Initialized
INFO - 2024-03-22 07:04:18 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:18 --> Input Class Initialized
INFO - 2024-03-22 07:04:18 --> Language Class Initialized
ERROR - 2024-03-22 07:04:18 --> 404 Page Not Found: About/index
ERROR - 2024-03-22 07:04:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:18 --> Config Class Initialized
INFO - 2024-03-22 07:04:18 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:18 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:18 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:18 --> URI Class Initialized
INFO - 2024-03-22 07:04:18 --> Router Class Initialized
INFO - 2024-03-22 07:04:18 --> Output Class Initialized
INFO - 2024-03-22 07:04:18 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:18 --> Input Class Initialized
INFO - 2024-03-22 07:04:18 --> Language Class Initialized
ERROR - 2024-03-22 07:04:18 --> 404 Page Not Found: V2/_catalog
ERROR - 2024-03-22 07:04:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:18 --> Config Class Initialized
INFO - 2024-03-22 07:04:18 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:18 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:18 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:18 --> URI Class Initialized
INFO - 2024-03-22 07:04:18 --> Router Class Initialized
INFO - 2024-03-22 07:04:18 --> Output Class Initialized
INFO - 2024-03-22 07:04:18 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:18 --> Input Class Initialized
INFO - 2024-03-22 07:04:18 --> Language Class Initialized
ERROR - 2024-03-22 07:04:18 --> 404 Page Not Found: Debug/default
ERROR - 2024-03-22 07:04:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:18 --> Config Class Initialized
INFO - 2024-03-22 07:04:18 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:18 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:18 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:18 --> URI Class Initialized
DEBUG - 2024-03-22 07:04:18 --> No URI present. Default controller set.
INFO - 2024-03-22 07:04:18 --> Router Class Initialized
INFO - 2024-03-22 07:04:18 --> Output Class Initialized
INFO - 2024-03-22 07:04:18 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:18 --> Input Class Initialized
INFO - 2024-03-22 07:04:18 --> Language Class Initialized
INFO - 2024-03-22 07:04:18 --> Loader Class Initialized
INFO - 2024-03-22 07:04:18 --> Helper loaded: url_helper
INFO - 2024-03-22 07:04:18 --> Helper loaded: file_helper
INFO - 2024-03-22 07:04:18 --> Helper loaded: html_helper
INFO - 2024-03-22 07:04:18 --> Helper loaded: text_helper
INFO - 2024-03-22 07:04:18 --> Helper loaded: form_helper
INFO - 2024-03-22 07:04:18 --> Helper loaded: lang_helper
INFO - 2024-03-22 07:04:18 --> Helper loaded: security_helper
INFO - 2024-03-22 07:04:18 --> Helper loaded: cookie_helper
INFO - 2024-03-22 07:04:18 --> Database Driver Class Initialized
INFO - 2024-03-22 07:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 07:04:18 --> Parser Class Initialized
INFO - 2024-03-22 07:04:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 07:04:18 --> Pagination Class Initialized
INFO - 2024-03-22 07:04:18 --> Form Validation Class Initialized
INFO - 2024-03-22 07:04:18 --> Controller Class Initialized
INFO - 2024-03-22 07:04:18 --> Model Class Initialized
DEBUG - 2024-03-22 07:04:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 07:04:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:19 --> Config Class Initialized
INFO - 2024-03-22 07:04:19 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:19 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:19 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:19 --> URI Class Initialized
INFO - 2024-03-22 07:04:19 --> Router Class Initialized
INFO - 2024-03-22 07:04:19 --> Output Class Initialized
INFO - 2024-03-22 07:04:19 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:19 --> Input Class Initialized
INFO - 2024-03-22 07:04:19 --> Language Class Initialized
ERROR - 2024-03-22 07:04:19 --> 404 Page Not Found: Ecp/Current
ERROR - 2024-03-22 07:04:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:19 --> Config Class Initialized
INFO - 2024-03-22 07:04:19 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:19 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:19 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:19 --> URI Class Initialized
INFO - 2024-03-22 07:04:19 --> Router Class Initialized
INFO - 2024-03-22 07:04:19 --> Output Class Initialized
INFO - 2024-03-22 07:04:19 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:19 --> Input Class Initialized
INFO - 2024-03-22 07:04:19 --> Language Class Initialized
ERROR - 2024-03-22 07:04:19 --> 404 Page Not Found: V2/_catalog
ERROR - 2024-03-22 07:04:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:19 --> Config Class Initialized
INFO - 2024-03-22 07:04:19 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:19 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:19 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:19 --> URI Class Initialized
INFO - 2024-03-22 07:04:19 --> Router Class Initialized
INFO - 2024-03-22 07:04:19 --> Output Class Initialized
INFO - 2024-03-22 07:04:19 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:19 --> Input Class Initialized
INFO - 2024-03-22 07:04:19 --> Language Class Initialized
ERROR - 2024-03-22 07:04:19 --> 404 Page Not Found: Server-status/index
ERROR - 2024-03-22 07:04:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:19 --> Config Class Initialized
INFO - 2024-03-22 07:04:19 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:19 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:19 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:19 --> URI Class Initialized
INFO - 2024-03-22 07:04:19 --> Router Class Initialized
INFO - 2024-03-22 07:04:19 --> Output Class Initialized
INFO - 2024-03-22 07:04:19 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:19 --> Input Class Initialized
INFO - 2024-03-22 07:04:19 --> Language Class Initialized
ERROR - 2024-03-22 07:04:19 --> 404 Page Not Found: Ecp/Current
ERROR - 2024-03-22 07:04:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:19 --> Config Class Initialized
INFO - 2024-03-22 07:04:19 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:19 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:19 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:19 --> URI Class Initialized
INFO - 2024-03-22 07:04:19 --> Router Class Initialized
INFO - 2024-03-22 07:04:19 --> Output Class Initialized
INFO - 2024-03-22 07:04:19 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:19 --> Input Class Initialized
INFO - 2024-03-22 07:04:19 --> Language Class Initialized
ERROR - 2024-03-22 07:04:19 --> 404 Page Not Found: Loginaction/index
ERROR - 2024-03-22 07:04:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:20 --> Config Class Initialized
INFO - 2024-03-22 07:04:20 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:20 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:20 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:20 --> URI Class Initialized
INFO - 2024-03-22 07:04:20 --> Router Class Initialized
ERROR - 2024-03-22 07:04:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:20 --> Output Class Initialized
INFO - 2024-03-22 07:04:20 --> Config Class Initialized
INFO - 2024-03-22 07:04:20 --> Hooks Class Initialized
INFO - 2024-03-22 07:04:20 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:20 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:20 --> Utf8 Class Initialized
DEBUG - 2024-03-22 07:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:20 --> Input Class Initialized
INFO - 2024-03-22 07:04:20 --> Language Class Initialized
INFO - 2024-03-22 07:04:20 --> URI Class Initialized
ERROR - 2024-03-22 07:04:20 --> 404 Page Not Found: Server-status/index
INFO - 2024-03-22 07:04:20 --> Router Class Initialized
INFO - 2024-03-22 07:04:20 --> Output Class Initialized
INFO - 2024-03-22 07:04:20 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:20 --> Input Class Initialized
INFO - 2024-03-22 07:04:20 --> Language Class Initialized
ERROR - 2024-03-22 07:04:20 --> 404 Page Not Found: _all_dbs/index
ERROR - 2024-03-22 07:04:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:20 --> Config Class Initialized
INFO - 2024-03-22 07:04:20 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:20 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:20 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:20 --> URI Class Initialized
INFO - 2024-03-22 07:04:20 --> Router Class Initialized
INFO - 2024-03-22 07:04:20 --> Output Class Initialized
INFO - 2024-03-22 07:04:20 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:20 --> Input Class Initialized
INFO - 2024-03-22 07:04:20 --> Language Class Initialized
ERROR - 2024-03-22 07:04:20 --> 404 Page Not Found: DS_Store/index
ERROR - 2024-03-22 07:04:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:20 --> Config Class Initialized
INFO - 2024-03-22 07:04:20 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:20 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:20 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:20 --> URI Class Initialized
INFO - 2024-03-22 07:04:20 --> Router Class Initialized
INFO - 2024-03-22 07:04:20 --> Output Class Initialized
INFO - 2024-03-22 07:04:20 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:20 --> Input Class Initialized
INFO - 2024-03-22 07:04:20 --> Language Class Initialized
ERROR - 2024-03-22 07:04:20 --> 404 Page Not Found: Loginaction/index
ERROR - 2024-03-22 07:04:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:21 --> Config Class Initialized
INFO - 2024-03-22 07:04:21 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:21 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:21 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:21 --> URI Class Initialized
INFO - 2024-03-22 07:04:21 --> Router Class Initialized
INFO - 2024-03-22 07:04:21 --> Output Class Initialized
INFO - 2024-03-22 07:04:21 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:21 --> Input Class Initialized
INFO - 2024-03-22 07:04:21 --> Language Class Initialized
ERROR - 2024-03-22 07:04:21 --> 404 Page Not Found: _all_dbs/index
ERROR - 2024-03-22 07:04:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:21 --> Config Class Initialized
INFO - 2024-03-22 07:04:21 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:21 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:21 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:21 --> URI Class Initialized
INFO - 2024-03-22 07:04:21 --> Router Class Initialized
INFO - 2024-03-22 07:04:21 --> Output Class Initialized
INFO - 2024-03-22 07:04:21 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:21 --> Input Class Initialized
INFO - 2024-03-22 07:04:21 --> Language Class Initialized
ERROR - 2024-03-22 07:04:21 --> 404 Page Not Found: DS_Store/index
ERROR - 2024-03-22 07:04:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:21 --> Config Class Initialized
INFO - 2024-03-22 07:04:21 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:21 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:21 --> Utf8 Class Initialized
ERROR - 2024-03-22 07:04:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:22 --> Config Class Initialized
INFO - 2024-03-22 07:04:22 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:22 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:22 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:22 --> URI Class Initialized
INFO - 2024-03-22 07:04:22 --> Router Class Initialized
INFO - 2024-03-22 07:04:22 --> Output Class Initialized
INFO - 2024-03-22 07:04:22 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:22 --> Input Class Initialized
INFO - 2024-03-22 07:04:22 --> Language Class Initialized
ERROR - 2024-03-22 07:04:22 --> 404 Page Not Found: Configjson/index
ERROR - 2024-03-22 07:04:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:22 --> Config Class Initialized
INFO - 2024-03-22 07:04:22 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:22 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:22 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:22 --> URI Class Initialized
INFO - 2024-03-22 07:04:22 --> Router Class Initialized
INFO - 2024-03-22 07:04:22 --> Output Class Initialized
INFO - 2024-03-22 07:04:22 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:22 --> Input Class Initialized
INFO - 2024-03-22 07:04:22 --> Language Class Initialized
ERROR - 2024-03-22 07:04:22 --> 404 Page Not Found: Telescope/requests
ERROR - 2024-03-22 07:04:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:23 --> Config Class Initialized
INFO - 2024-03-22 07:04:23 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:23 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:23 --> Utf8 Class Initialized
ERROR - 2024-03-22 07:04:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:23 --> Config Class Initialized
INFO - 2024-03-22 07:04:23 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:23 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:23 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:23 --> URI Class Initialized
DEBUG - 2024-03-22 07:04:23 --> No URI present. Default controller set.
INFO - 2024-03-22 07:04:23 --> Router Class Initialized
INFO - 2024-03-22 07:04:23 --> Output Class Initialized
INFO - 2024-03-22 07:04:23 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:23 --> Input Class Initialized
INFO - 2024-03-22 07:04:23 --> Language Class Initialized
INFO - 2024-03-22 07:04:23 --> Loader Class Initialized
INFO - 2024-03-22 07:04:23 --> Helper loaded: url_helper
INFO - 2024-03-22 07:04:23 --> Helper loaded: file_helper
INFO - 2024-03-22 07:04:23 --> Helper loaded: html_helper
INFO - 2024-03-22 07:04:23 --> Helper loaded: text_helper
INFO - 2024-03-22 07:04:23 --> Helper loaded: form_helper
INFO - 2024-03-22 07:04:23 --> Helper loaded: lang_helper
INFO - 2024-03-22 07:04:23 --> Helper loaded: security_helper
INFO - 2024-03-22 07:04:23 --> Helper loaded: cookie_helper
INFO - 2024-03-22 07:04:23 --> Database Driver Class Initialized
INFO - 2024-03-22 07:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 07:04:23 --> Parser Class Initialized
INFO - 2024-03-22 07:04:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 07:04:23 --> Pagination Class Initialized
INFO - 2024-03-22 07:04:23 --> Form Validation Class Initialized
INFO - 2024-03-22 07:04:23 --> Controller Class Initialized
INFO - 2024-03-22 07:04:23 --> Model Class Initialized
DEBUG - 2024-03-22 07:04:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 07:04:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:23 --> Config Class Initialized
INFO - 2024-03-22 07:04:23 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:23 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:23 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:23 --> URI Class Initialized
INFO - 2024-03-22 07:04:23 --> Router Class Initialized
INFO - 2024-03-22 07:04:23 --> Output Class Initialized
INFO - 2024-03-22 07:04:23 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:23 --> Input Class Initialized
INFO - 2024-03-22 07:04:23 --> Language Class Initialized
ERROR - 2024-03-22 07:04:23 --> 404 Page Not Found: Configjson/index
ERROR - 2024-03-22 07:04:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:23 --> Config Class Initialized
INFO - 2024-03-22 07:04:23 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:23 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:23 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:23 --> URI Class Initialized
INFO - 2024-03-22 07:04:23 --> Router Class Initialized
INFO - 2024-03-22 07:04:23 --> Output Class Initialized
INFO - 2024-03-22 07:04:23 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:23 --> Input Class Initialized
INFO - 2024-03-22 07:04:23 --> Language Class Initialized
ERROR - 2024-03-22 07:04:23 --> 404 Page Not Found: Telescope/requests
ERROR - 2024-03-22 07:04:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:24 --> Config Class Initialized
INFO - 2024-03-22 07:04:24 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:24 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:24 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:24 --> URI Class Initialized
DEBUG - 2024-03-22 07:04:24 --> No URI present. Default controller set.
INFO - 2024-03-22 07:04:24 --> Router Class Initialized
INFO - 2024-03-22 07:04:24 --> Output Class Initialized
INFO - 2024-03-22 07:04:24 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:24 --> Input Class Initialized
INFO - 2024-03-22 07:04:24 --> Language Class Initialized
INFO - 2024-03-22 07:04:24 --> Loader Class Initialized
INFO - 2024-03-22 07:04:24 --> Helper loaded: url_helper
INFO - 2024-03-22 07:04:24 --> Helper loaded: file_helper
INFO - 2024-03-22 07:04:24 --> Helper loaded: html_helper
INFO - 2024-03-22 07:04:24 --> Helper loaded: text_helper
INFO - 2024-03-22 07:04:24 --> Helper loaded: form_helper
INFO - 2024-03-22 07:04:24 --> Helper loaded: lang_helper
INFO - 2024-03-22 07:04:24 --> Helper loaded: security_helper
INFO - 2024-03-22 07:04:24 --> Helper loaded: cookie_helper
INFO - 2024-03-22 07:04:24 --> Database Driver Class Initialized
INFO - 2024-03-22 07:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 07:04:24 --> Parser Class Initialized
INFO - 2024-03-22 07:04:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 07:04:24 --> Pagination Class Initialized
INFO - 2024-03-22 07:04:24 --> Form Validation Class Initialized
INFO - 2024-03-22 07:04:24 --> Controller Class Initialized
INFO - 2024-03-22 07:04:24 --> Model Class Initialized
DEBUG - 2024-03-22 07:04:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 07:04:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:40 --> Config Class Initialized
INFO - 2024-03-22 07:04:40 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:40 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:40 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:40 --> URI Class Initialized
DEBUG - 2024-03-22 07:04:40 --> No URI present. Default controller set.
INFO - 2024-03-22 07:04:40 --> Router Class Initialized
INFO - 2024-03-22 07:04:40 --> Output Class Initialized
INFO - 2024-03-22 07:04:40 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:40 --> Input Class Initialized
INFO - 2024-03-22 07:04:40 --> Language Class Initialized
INFO - 2024-03-22 07:04:40 --> Loader Class Initialized
INFO - 2024-03-22 07:04:40 --> Helper loaded: url_helper
INFO - 2024-03-22 07:04:40 --> Helper loaded: file_helper
INFO - 2024-03-22 07:04:40 --> Helper loaded: html_helper
INFO - 2024-03-22 07:04:40 --> Helper loaded: text_helper
INFO - 2024-03-22 07:04:40 --> Helper loaded: form_helper
INFO - 2024-03-22 07:04:40 --> Helper loaded: lang_helper
INFO - 2024-03-22 07:04:40 --> Helper loaded: security_helper
INFO - 2024-03-22 07:04:40 --> Helper loaded: cookie_helper
INFO - 2024-03-22 07:04:40 --> Database Driver Class Initialized
INFO - 2024-03-22 07:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 07:04:40 --> Parser Class Initialized
INFO - 2024-03-22 07:04:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 07:04:40 --> Pagination Class Initialized
INFO - 2024-03-22 07:04:40 --> Form Validation Class Initialized
INFO - 2024-03-22 07:04:40 --> Controller Class Initialized
INFO - 2024-03-22 07:04:40 --> Model Class Initialized
DEBUG - 2024-03-22 07:04:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 07:04:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:40 --> Config Class Initialized
INFO - 2024-03-22 07:04:40 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:40 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:40 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:40 --> URI Class Initialized
INFO - 2024-03-22 07:04:40 --> Router Class Initialized
INFO - 2024-03-22 07:04:40 --> Output Class Initialized
INFO - 2024-03-22 07:04:40 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:40 --> Input Class Initialized
INFO - 2024-03-22 07:04:40 --> Language Class Initialized
INFO - 2024-03-22 07:04:40 --> Loader Class Initialized
INFO - 2024-03-22 07:04:40 --> Helper loaded: url_helper
INFO - 2024-03-22 07:04:40 --> Helper loaded: file_helper
INFO - 2024-03-22 07:04:40 --> Helper loaded: html_helper
INFO - 2024-03-22 07:04:40 --> Helper loaded: text_helper
INFO - 2024-03-22 07:04:40 --> Helper loaded: form_helper
INFO - 2024-03-22 07:04:40 --> Helper loaded: lang_helper
INFO - 2024-03-22 07:04:40 --> Helper loaded: security_helper
INFO - 2024-03-22 07:04:40 --> Helper loaded: cookie_helper
INFO - 2024-03-22 07:04:40 --> Database Driver Class Initialized
INFO - 2024-03-22 07:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 07:04:40 --> Parser Class Initialized
INFO - 2024-03-22 07:04:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 07:04:40 --> Pagination Class Initialized
INFO - 2024-03-22 07:04:40 --> Form Validation Class Initialized
INFO - 2024-03-22 07:04:40 --> Controller Class Initialized
INFO - 2024-03-22 07:04:40 --> Model Class Initialized
DEBUG - 2024-03-22 07:04:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 07:04:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-22 07:04:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 07:04:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 07:04:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 07:04:40 --> Model Class Initialized
INFO - 2024-03-22 07:04:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 07:04:40 --> Final output sent to browser
DEBUG - 2024-03-22 07:04:40 --> Total execution time: 0.0332
ERROR - 2024-03-22 07:04:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:44 --> Config Class Initialized
INFO - 2024-03-22 07:04:44 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:44 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:44 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:44 --> URI Class Initialized
DEBUG - 2024-03-22 07:04:44 --> No URI present. Default controller set.
INFO - 2024-03-22 07:04:44 --> Router Class Initialized
INFO - 2024-03-22 07:04:44 --> Output Class Initialized
INFO - 2024-03-22 07:04:44 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:44 --> Input Class Initialized
INFO - 2024-03-22 07:04:44 --> Language Class Initialized
INFO - 2024-03-22 07:04:44 --> Loader Class Initialized
INFO - 2024-03-22 07:04:44 --> Helper loaded: url_helper
INFO - 2024-03-22 07:04:44 --> Helper loaded: file_helper
INFO - 2024-03-22 07:04:44 --> Helper loaded: html_helper
INFO - 2024-03-22 07:04:44 --> Helper loaded: text_helper
INFO - 2024-03-22 07:04:44 --> Helper loaded: form_helper
INFO - 2024-03-22 07:04:44 --> Helper loaded: lang_helper
INFO - 2024-03-22 07:04:44 --> Helper loaded: security_helper
INFO - 2024-03-22 07:04:44 --> Helper loaded: cookie_helper
INFO - 2024-03-22 07:04:44 --> Database Driver Class Initialized
INFO - 2024-03-22 07:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 07:04:44 --> Parser Class Initialized
INFO - 2024-03-22 07:04:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 07:04:44 --> Pagination Class Initialized
INFO - 2024-03-22 07:04:44 --> Form Validation Class Initialized
INFO - 2024-03-22 07:04:44 --> Controller Class Initialized
INFO - 2024-03-22 07:04:44 --> Model Class Initialized
DEBUG - 2024-03-22 07:04:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 07:04:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:44 --> Config Class Initialized
INFO - 2024-03-22 07:04:44 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:44 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:44 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:44 --> URI Class Initialized
INFO - 2024-03-22 07:04:44 --> Router Class Initialized
INFO - 2024-03-22 07:04:44 --> Output Class Initialized
INFO - 2024-03-22 07:04:44 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:44 --> Input Class Initialized
INFO - 2024-03-22 07:04:44 --> Language Class Initialized
INFO - 2024-03-22 07:04:44 --> Loader Class Initialized
INFO - 2024-03-22 07:04:44 --> Helper loaded: url_helper
INFO - 2024-03-22 07:04:44 --> Helper loaded: file_helper
INFO - 2024-03-22 07:04:44 --> Helper loaded: html_helper
INFO - 2024-03-22 07:04:44 --> Helper loaded: text_helper
INFO - 2024-03-22 07:04:44 --> Helper loaded: form_helper
INFO - 2024-03-22 07:04:44 --> Helper loaded: lang_helper
INFO - 2024-03-22 07:04:44 --> Helper loaded: security_helper
INFO - 2024-03-22 07:04:44 --> Helper loaded: cookie_helper
INFO - 2024-03-22 07:04:44 --> Database Driver Class Initialized
INFO - 2024-03-22 07:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 07:04:44 --> Parser Class Initialized
INFO - 2024-03-22 07:04:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 07:04:44 --> Pagination Class Initialized
INFO - 2024-03-22 07:04:44 --> Form Validation Class Initialized
INFO - 2024-03-22 07:04:44 --> Controller Class Initialized
INFO - 2024-03-22 07:04:44 --> Model Class Initialized
DEBUG - 2024-03-22 07:04:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 07:04:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-22 07:04:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 07:04:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 07:04:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 07:04:44 --> Model Class Initialized
INFO - 2024-03-22 07:04:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 07:04:44 --> Final output sent to browser
DEBUG - 2024-03-22 07:04:44 --> Total execution time: 0.0292
ERROR - 2024-03-22 07:04:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:04:56 --> Config Class Initialized
INFO - 2024-03-22 07:04:56 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:04:56 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:04:56 --> Utf8 Class Initialized
INFO - 2024-03-22 07:04:56 --> URI Class Initialized
DEBUG - 2024-03-22 07:04:56 --> No URI present. Default controller set.
INFO - 2024-03-22 07:04:56 --> Router Class Initialized
INFO - 2024-03-22 07:04:56 --> Output Class Initialized
INFO - 2024-03-22 07:04:56 --> Security Class Initialized
DEBUG - 2024-03-22 07:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:04:56 --> Input Class Initialized
INFO - 2024-03-22 07:04:56 --> Language Class Initialized
INFO - 2024-03-22 07:04:56 --> Loader Class Initialized
INFO - 2024-03-22 07:04:56 --> Helper loaded: url_helper
INFO - 2024-03-22 07:04:56 --> Helper loaded: file_helper
INFO - 2024-03-22 07:04:56 --> Helper loaded: html_helper
INFO - 2024-03-22 07:04:56 --> Helper loaded: text_helper
INFO - 2024-03-22 07:04:56 --> Helper loaded: form_helper
INFO - 2024-03-22 07:04:56 --> Helper loaded: lang_helper
INFO - 2024-03-22 07:04:56 --> Helper loaded: security_helper
INFO - 2024-03-22 07:04:56 --> Helper loaded: cookie_helper
INFO - 2024-03-22 07:04:56 --> Database Driver Class Initialized
INFO - 2024-03-22 07:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 07:04:56 --> Parser Class Initialized
INFO - 2024-03-22 07:04:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 07:04:56 --> Pagination Class Initialized
INFO - 2024-03-22 07:04:56 --> Form Validation Class Initialized
INFO - 2024-03-22 07:04:56 --> Controller Class Initialized
INFO - 2024-03-22 07:04:56 --> Model Class Initialized
DEBUG - 2024-03-22 07:04:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 07:05:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:05:14 --> Config Class Initialized
INFO - 2024-03-22 07:05:14 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:05:14 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:05:14 --> Utf8 Class Initialized
INFO - 2024-03-22 07:05:14 --> URI Class Initialized
DEBUG - 2024-03-22 07:05:14 --> No URI present. Default controller set.
INFO - 2024-03-22 07:05:14 --> Router Class Initialized
INFO - 2024-03-22 07:05:14 --> Output Class Initialized
INFO - 2024-03-22 07:05:14 --> Security Class Initialized
DEBUG - 2024-03-22 07:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:05:14 --> Input Class Initialized
INFO - 2024-03-22 07:05:14 --> Language Class Initialized
INFO - 2024-03-22 07:05:14 --> Loader Class Initialized
INFO - 2024-03-22 07:05:14 --> Helper loaded: url_helper
INFO - 2024-03-22 07:05:14 --> Helper loaded: file_helper
INFO - 2024-03-22 07:05:14 --> Helper loaded: html_helper
INFO - 2024-03-22 07:05:14 --> Helper loaded: text_helper
INFO - 2024-03-22 07:05:14 --> Helper loaded: form_helper
INFO - 2024-03-22 07:05:14 --> Helper loaded: lang_helper
INFO - 2024-03-22 07:05:14 --> Helper loaded: security_helper
INFO - 2024-03-22 07:05:14 --> Helper loaded: cookie_helper
INFO - 2024-03-22 07:05:14 --> Database Driver Class Initialized
INFO - 2024-03-22 07:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 07:05:14 --> Parser Class Initialized
INFO - 2024-03-22 07:05:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 07:05:14 --> Pagination Class Initialized
INFO - 2024-03-22 07:05:14 --> Form Validation Class Initialized
INFO - 2024-03-22 07:05:14 --> Controller Class Initialized
INFO - 2024-03-22 07:05:14 --> Model Class Initialized
DEBUG - 2024-03-22 07:05:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 07:05:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:05:16 --> Config Class Initialized
INFO - 2024-03-22 07:05:16 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:05:16 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:05:16 --> Utf8 Class Initialized
INFO - 2024-03-22 07:05:16 --> URI Class Initialized
DEBUG - 2024-03-22 07:05:16 --> No URI present. Default controller set.
INFO - 2024-03-22 07:05:16 --> Router Class Initialized
INFO - 2024-03-22 07:05:16 --> Output Class Initialized
INFO - 2024-03-22 07:05:16 --> Security Class Initialized
DEBUG - 2024-03-22 07:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:05:16 --> Input Class Initialized
INFO - 2024-03-22 07:05:16 --> Language Class Initialized
INFO - 2024-03-22 07:05:16 --> Loader Class Initialized
INFO - 2024-03-22 07:05:16 --> Helper loaded: url_helper
INFO - 2024-03-22 07:05:16 --> Helper loaded: file_helper
INFO - 2024-03-22 07:05:16 --> Helper loaded: html_helper
INFO - 2024-03-22 07:05:16 --> Helper loaded: text_helper
INFO - 2024-03-22 07:05:16 --> Helper loaded: form_helper
INFO - 2024-03-22 07:05:16 --> Helper loaded: lang_helper
INFO - 2024-03-22 07:05:16 --> Helper loaded: security_helper
INFO - 2024-03-22 07:05:16 --> Helper loaded: cookie_helper
INFO - 2024-03-22 07:05:16 --> Database Driver Class Initialized
INFO - 2024-03-22 07:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 07:05:16 --> Parser Class Initialized
INFO - 2024-03-22 07:05:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 07:05:16 --> Pagination Class Initialized
INFO - 2024-03-22 07:05:16 --> Form Validation Class Initialized
INFO - 2024-03-22 07:05:16 --> Controller Class Initialized
INFO - 2024-03-22 07:05:16 --> Model Class Initialized
DEBUG - 2024-03-22 07:05:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 07:05:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:05:17 --> Config Class Initialized
INFO - 2024-03-22 07:05:17 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:05:17 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:05:17 --> Utf8 Class Initialized
INFO - 2024-03-22 07:05:17 --> URI Class Initialized
DEBUG - 2024-03-22 07:05:17 --> No URI present. Default controller set.
INFO - 2024-03-22 07:05:17 --> Router Class Initialized
INFO - 2024-03-22 07:05:17 --> Output Class Initialized
INFO - 2024-03-22 07:05:17 --> Security Class Initialized
DEBUG - 2024-03-22 07:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:05:17 --> Input Class Initialized
INFO - 2024-03-22 07:05:17 --> Language Class Initialized
INFO - 2024-03-22 07:05:17 --> Loader Class Initialized
INFO - 2024-03-22 07:05:17 --> Helper loaded: url_helper
INFO - 2024-03-22 07:05:17 --> Helper loaded: file_helper
INFO - 2024-03-22 07:05:17 --> Helper loaded: html_helper
INFO - 2024-03-22 07:05:17 --> Helper loaded: text_helper
INFO - 2024-03-22 07:05:17 --> Helper loaded: form_helper
INFO - 2024-03-22 07:05:17 --> Helper loaded: lang_helper
INFO - 2024-03-22 07:05:17 --> Helper loaded: security_helper
INFO - 2024-03-22 07:05:17 --> Helper loaded: cookie_helper
INFO - 2024-03-22 07:05:17 --> Database Driver Class Initialized
INFO - 2024-03-22 07:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 07:05:17 --> Parser Class Initialized
INFO - 2024-03-22 07:05:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 07:05:17 --> Pagination Class Initialized
INFO - 2024-03-22 07:05:17 --> Form Validation Class Initialized
INFO - 2024-03-22 07:05:17 --> Controller Class Initialized
INFO - 2024-03-22 07:05:17 --> Model Class Initialized
DEBUG - 2024-03-22 07:05:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 07:05:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:05:20 --> Config Class Initialized
INFO - 2024-03-22 07:05:20 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:05:20 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:05:20 --> Utf8 Class Initialized
INFO - 2024-03-22 07:05:20 --> URI Class Initialized
DEBUG - 2024-03-22 07:05:20 --> No URI present. Default controller set.
INFO - 2024-03-22 07:05:20 --> Router Class Initialized
INFO - 2024-03-22 07:05:20 --> Output Class Initialized
INFO - 2024-03-22 07:05:20 --> Security Class Initialized
DEBUG - 2024-03-22 07:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:05:20 --> Input Class Initialized
INFO - 2024-03-22 07:05:20 --> Language Class Initialized
INFO - 2024-03-22 07:05:20 --> Loader Class Initialized
INFO - 2024-03-22 07:05:20 --> Helper loaded: url_helper
INFO - 2024-03-22 07:05:20 --> Helper loaded: file_helper
INFO - 2024-03-22 07:05:20 --> Helper loaded: html_helper
INFO - 2024-03-22 07:05:20 --> Helper loaded: text_helper
INFO - 2024-03-22 07:05:20 --> Helper loaded: form_helper
INFO - 2024-03-22 07:05:20 --> Helper loaded: lang_helper
INFO - 2024-03-22 07:05:20 --> Helper loaded: security_helper
INFO - 2024-03-22 07:05:20 --> Helper loaded: cookie_helper
INFO - 2024-03-22 07:05:20 --> Database Driver Class Initialized
INFO - 2024-03-22 07:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 07:05:20 --> Parser Class Initialized
INFO - 2024-03-22 07:05:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 07:05:20 --> Pagination Class Initialized
INFO - 2024-03-22 07:05:20 --> Form Validation Class Initialized
INFO - 2024-03-22 07:05:20 --> Controller Class Initialized
INFO - 2024-03-22 07:05:20 --> Model Class Initialized
DEBUG - 2024-03-22 07:05:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 07:05:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:05:32 --> Config Class Initialized
INFO - 2024-03-22 07:05:32 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:05:32 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:05:32 --> Utf8 Class Initialized
INFO - 2024-03-22 07:05:32 --> URI Class Initialized
DEBUG - 2024-03-22 07:05:32 --> No URI present. Default controller set.
INFO - 2024-03-22 07:05:32 --> Router Class Initialized
INFO - 2024-03-22 07:05:32 --> Output Class Initialized
INFO - 2024-03-22 07:05:32 --> Security Class Initialized
DEBUG - 2024-03-22 07:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:05:32 --> Input Class Initialized
INFO - 2024-03-22 07:05:32 --> Language Class Initialized
INFO - 2024-03-22 07:05:32 --> Loader Class Initialized
INFO - 2024-03-22 07:05:32 --> Helper loaded: url_helper
INFO - 2024-03-22 07:05:32 --> Helper loaded: file_helper
INFO - 2024-03-22 07:05:32 --> Helper loaded: html_helper
INFO - 2024-03-22 07:05:32 --> Helper loaded: text_helper
INFO - 2024-03-22 07:05:32 --> Helper loaded: form_helper
INFO - 2024-03-22 07:05:32 --> Helper loaded: lang_helper
INFO - 2024-03-22 07:05:32 --> Helper loaded: security_helper
INFO - 2024-03-22 07:05:32 --> Helper loaded: cookie_helper
INFO - 2024-03-22 07:05:32 --> Database Driver Class Initialized
INFO - 2024-03-22 07:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 07:05:32 --> Parser Class Initialized
INFO - 2024-03-22 07:05:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 07:05:32 --> Pagination Class Initialized
INFO - 2024-03-22 07:05:32 --> Form Validation Class Initialized
INFO - 2024-03-22 07:05:32 --> Controller Class Initialized
INFO - 2024-03-22 07:05:32 --> Model Class Initialized
DEBUG - 2024-03-22 07:05:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 07:57:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:57:31 --> Config Class Initialized
INFO - 2024-03-22 07:57:31 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:57:31 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:57:31 --> Utf8 Class Initialized
INFO - 2024-03-22 07:57:31 --> URI Class Initialized
DEBUG - 2024-03-22 07:57:31 --> No URI present. Default controller set.
INFO - 2024-03-22 07:57:31 --> Router Class Initialized
INFO - 2024-03-22 07:57:31 --> Output Class Initialized
INFO - 2024-03-22 07:57:31 --> Security Class Initialized
DEBUG - 2024-03-22 07:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:57:31 --> Input Class Initialized
INFO - 2024-03-22 07:57:31 --> Language Class Initialized
INFO - 2024-03-22 07:57:31 --> Loader Class Initialized
INFO - 2024-03-22 07:57:31 --> Helper loaded: url_helper
INFO - 2024-03-22 07:57:31 --> Helper loaded: file_helper
INFO - 2024-03-22 07:57:31 --> Helper loaded: html_helper
INFO - 2024-03-22 07:57:31 --> Helper loaded: text_helper
INFO - 2024-03-22 07:57:31 --> Helper loaded: form_helper
INFO - 2024-03-22 07:57:31 --> Helper loaded: lang_helper
INFO - 2024-03-22 07:57:31 --> Helper loaded: security_helper
INFO - 2024-03-22 07:57:31 --> Helper loaded: cookie_helper
INFO - 2024-03-22 07:57:31 --> Database Driver Class Initialized
INFO - 2024-03-22 07:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 07:57:31 --> Parser Class Initialized
INFO - 2024-03-22 07:57:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 07:57:31 --> Pagination Class Initialized
INFO - 2024-03-22 07:57:31 --> Form Validation Class Initialized
INFO - 2024-03-22 07:57:31 --> Controller Class Initialized
INFO - 2024-03-22 07:57:31 --> Model Class Initialized
DEBUG - 2024-03-22 07:57:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 07:57:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 07:57:31 --> Config Class Initialized
INFO - 2024-03-22 07:57:31 --> Hooks Class Initialized
DEBUG - 2024-03-22 07:57:31 --> UTF-8 Support Enabled
INFO - 2024-03-22 07:57:31 --> Utf8 Class Initialized
INFO - 2024-03-22 07:57:31 --> URI Class Initialized
INFO - 2024-03-22 07:57:31 --> Router Class Initialized
INFO - 2024-03-22 07:57:31 --> Output Class Initialized
INFO - 2024-03-22 07:57:31 --> Security Class Initialized
DEBUG - 2024-03-22 07:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 07:57:31 --> Input Class Initialized
INFO - 2024-03-22 07:57:31 --> Language Class Initialized
INFO - 2024-03-22 07:57:31 --> Loader Class Initialized
INFO - 2024-03-22 07:57:31 --> Helper loaded: url_helper
INFO - 2024-03-22 07:57:31 --> Helper loaded: file_helper
INFO - 2024-03-22 07:57:31 --> Helper loaded: html_helper
INFO - 2024-03-22 07:57:31 --> Helper loaded: text_helper
INFO - 2024-03-22 07:57:31 --> Helper loaded: form_helper
INFO - 2024-03-22 07:57:31 --> Helper loaded: lang_helper
INFO - 2024-03-22 07:57:31 --> Helper loaded: security_helper
INFO - 2024-03-22 07:57:31 --> Helper loaded: cookie_helper
INFO - 2024-03-22 07:57:31 --> Database Driver Class Initialized
INFO - 2024-03-22 07:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 07:57:31 --> Parser Class Initialized
INFO - 2024-03-22 07:57:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 07:57:31 --> Pagination Class Initialized
INFO - 2024-03-22 07:57:31 --> Form Validation Class Initialized
INFO - 2024-03-22 07:57:31 --> Controller Class Initialized
INFO - 2024-03-22 07:57:31 --> Model Class Initialized
DEBUG - 2024-03-22 07:57:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 07:57:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-22 07:57:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 07:57:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 07:57:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 07:57:31 --> Model Class Initialized
INFO - 2024-03-22 07:57:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 07:57:31 --> Final output sent to browser
DEBUG - 2024-03-22 07:57:31 --> Total execution time: 0.0327
ERROR - 2024-03-22 09:32:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 09:32:39 --> Config Class Initialized
INFO - 2024-03-22 09:32:39 --> Hooks Class Initialized
DEBUG - 2024-03-22 09:32:39 --> UTF-8 Support Enabled
INFO - 2024-03-22 09:32:39 --> Utf8 Class Initialized
INFO - 2024-03-22 09:32:39 --> URI Class Initialized
INFO - 2024-03-22 09:32:39 --> Router Class Initialized
INFO - 2024-03-22 09:32:39 --> Output Class Initialized
INFO - 2024-03-22 09:32:39 --> Security Class Initialized
DEBUG - 2024-03-22 09:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 09:32:39 --> Input Class Initialized
INFO - 2024-03-22 09:32:39 --> Language Class Initialized
ERROR - 2024-03-22 09:32:39 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2024-03-22 10:07:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 10:07:17 --> Config Class Initialized
INFO - 2024-03-22 10:07:17 --> Hooks Class Initialized
DEBUG - 2024-03-22 10:07:17 --> UTF-8 Support Enabled
INFO - 2024-03-22 10:07:17 --> Utf8 Class Initialized
INFO - 2024-03-22 10:07:17 --> URI Class Initialized
DEBUG - 2024-03-22 10:07:17 --> No URI present. Default controller set.
INFO - 2024-03-22 10:07:17 --> Router Class Initialized
INFO - 2024-03-22 10:07:17 --> Output Class Initialized
INFO - 2024-03-22 10:07:17 --> Security Class Initialized
DEBUG - 2024-03-22 10:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 10:07:17 --> Input Class Initialized
INFO - 2024-03-22 10:07:17 --> Language Class Initialized
INFO - 2024-03-22 10:07:17 --> Loader Class Initialized
INFO - 2024-03-22 10:07:17 --> Helper loaded: url_helper
INFO - 2024-03-22 10:07:17 --> Helper loaded: file_helper
INFO - 2024-03-22 10:07:17 --> Helper loaded: html_helper
INFO - 2024-03-22 10:07:17 --> Helper loaded: text_helper
INFO - 2024-03-22 10:07:17 --> Helper loaded: form_helper
INFO - 2024-03-22 10:07:17 --> Helper loaded: lang_helper
INFO - 2024-03-22 10:07:17 --> Helper loaded: security_helper
INFO - 2024-03-22 10:07:17 --> Helper loaded: cookie_helper
INFO - 2024-03-22 10:07:17 --> Database Driver Class Initialized
INFO - 2024-03-22 10:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 10:07:17 --> Parser Class Initialized
INFO - 2024-03-22 10:07:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 10:07:17 --> Pagination Class Initialized
INFO - 2024-03-22 10:07:17 --> Form Validation Class Initialized
INFO - 2024-03-22 10:07:17 --> Controller Class Initialized
INFO - 2024-03-22 10:07:17 --> Model Class Initialized
DEBUG - 2024-03-22 10:07:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 11:05:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 11:05:15 --> Config Class Initialized
INFO - 2024-03-22 11:05:15 --> Hooks Class Initialized
DEBUG - 2024-03-22 11:05:15 --> UTF-8 Support Enabled
INFO - 2024-03-22 11:05:15 --> Utf8 Class Initialized
INFO - 2024-03-22 11:05:15 --> URI Class Initialized
DEBUG - 2024-03-22 11:05:15 --> No URI present. Default controller set.
INFO - 2024-03-22 11:05:15 --> Router Class Initialized
INFO - 2024-03-22 11:05:15 --> Output Class Initialized
INFO - 2024-03-22 11:05:15 --> Security Class Initialized
DEBUG - 2024-03-22 11:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 11:05:15 --> Input Class Initialized
INFO - 2024-03-22 11:05:15 --> Language Class Initialized
INFO - 2024-03-22 11:05:15 --> Loader Class Initialized
INFO - 2024-03-22 11:05:15 --> Helper loaded: url_helper
INFO - 2024-03-22 11:05:15 --> Helper loaded: file_helper
INFO - 2024-03-22 11:05:15 --> Helper loaded: html_helper
INFO - 2024-03-22 11:05:15 --> Helper loaded: text_helper
INFO - 2024-03-22 11:05:15 --> Helper loaded: form_helper
INFO - 2024-03-22 11:05:15 --> Helper loaded: lang_helper
INFO - 2024-03-22 11:05:15 --> Helper loaded: security_helper
INFO - 2024-03-22 11:05:15 --> Helper loaded: cookie_helper
INFO - 2024-03-22 11:05:15 --> Database Driver Class Initialized
INFO - 2024-03-22 11:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 11:05:15 --> Parser Class Initialized
INFO - 2024-03-22 11:05:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 11:05:15 --> Pagination Class Initialized
INFO - 2024-03-22 11:05:15 --> Form Validation Class Initialized
INFO - 2024-03-22 11:05:15 --> Controller Class Initialized
INFO - 2024-03-22 11:05:15 --> Model Class Initialized
DEBUG - 2024-03-22 11:05:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 11:05:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 11:05:15 --> Config Class Initialized
INFO - 2024-03-22 11:05:15 --> Hooks Class Initialized
DEBUG - 2024-03-22 11:05:15 --> UTF-8 Support Enabled
INFO - 2024-03-22 11:05:15 --> Utf8 Class Initialized
INFO - 2024-03-22 11:05:15 --> URI Class Initialized
INFO - 2024-03-22 11:05:15 --> Router Class Initialized
INFO - 2024-03-22 11:05:15 --> Output Class Initialized
INFO - 2024-03-22 11:05:15 --> Security Class Initialized
DEBUG - 2024-03-22 11:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 11:05:15 --> Input Class Initialized
INFO - 2024-03-22 11:05:15 --> Language Class Initialized
INFO - 2024-03-22 11:05:15 --> Loader Class Initialized
INFO - 2024-03-22 11:05:15 --> Helper loaded: url_helper
INFO - 2024-03-22 11:05:15 --> Helper loaded: file_helper
INFO - 2024-03-22 11:05:15 --> Helper loaded: html_helper
INFO - 2024-03-22 11:05:15 --> Helper loaded: text_helper
INFO - 2024-03-22 11:05:15 --> Helper loaded: form_helper
INFO - 2024-03-22 11:05:15 --> Helper loaded: lang_helper
INFO - 2024-03-22 11:05:15 --> Helper loaded: security_helper
INFO - 2024-03-22 11:05:15 --> Helper loaded: cookie_helper
INFO - 2024-03-22 11:05:15 --> Database Driver Class Initialized
INFO - 2024-03-22 11:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 11:05:15 --> Parser Class Initialized
INFO - 2024-03-22 11:05:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 11:05:15 --> Pagination Class Initialized
INFO - 2024-03-22 11:05:15 --> Form Validation Class Initialized
INFO - 2024-03-22 11:05:15 --> Controller Class Initialized
INFO - 2024-03-22 11:05:15 --> Model Class Initialized
DEBUG - 2024-03-22 11:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 11:05:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-22 11:05:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 11:05:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 11:05:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 11:05:15 --> Model Class Initialized
INFO - 2024-03-22 11:05:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 11:05:15 --> Final output sent to browser
DEBUG - 2024-03-22 11:05:15 --> Total execution time: 0.0319
ERROR - 2024-03-22 11:05:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 11:05:29 --> Config Class Initialized
INFO - 2024-03-22 11:05:29 --> Hooks Class Initialized
DEBUG - 2024-03-22 11:05:29 --> UTF-8 Support Enabled
INFO - 2024-03-22 11:05:29 --> Utf8 Class Initialized
INFO - 2024-03-22 11:05:29 --> URI Class Initialized
INFO - 2024-03-22 11:05:29 --> Router Class Initialized
INFO - 2024-03-22 11:05:29 --> Output Class Initialized
INFO - 2024-03-22 11:05:29 --> Security Class Initialized
DEBUG - 2024-03-22 11:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 11:05:29 --> Input Class Initialized
INFO - 2024-03-22 11:05:29 --> Language Class Initialized
INFO - 2024-03-22 11:05:29 --> Loader Class Initialized
INFO - 2024-03-22 11:05:29 --> Helper loaded: url_helper
INFO - 2024-03-22 11:05:29 --> Helper loaded: file_helper
INFO - 2024-03-22 11:05:29 --> Helper loaded: html_helper
INFO - 2024-03-22 11:05:29 --> Helper loaded: text_helper
INFO - 2024-03-22 11:05:29 --> Helper loaded: form_helper
INFO - 2024-03-22 11:05:29 --> Helper loaded: lang_helper
INFO - 2024-03-22 11:05:29 --> Helper loaded: security_helper
INFO - 2024-03-22 11:05:29 --> Helper loaded: cookie_helper
INFO - 2024-03-22 11:05:29 --> Database Driver Class Initialized
INFO - 2024-03-22 11:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 11:05:29 --> Parser Class Initialized
INFO - 2024-03-22 11:05:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 11:05:29 --> Pagination Class Initialized
INFO - 2024-03-22 11:05:29 --> Form Validation Class Initialized
INFO - 2024-03-22 11:05:29 --> Controller Class Initialized
INFO - 2024-03-22 11:05:29 --> Model Class Initialized
DEBUG - 2024-03-22 11:05:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 11:05:29 --> Model Class Initialized
INFO - 2024-03-22 11:05:29 --> Final output sent to browser
DEBUG - 2024-03-22 11:05:29 --> Total execution time: 0.0194
ERROR - 2024-03-22 11:05:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 11:05:29 --> Config Class Initialized
INFO - 2024-03-22 11:05:29 --> Hooks Class Initialized
DEBUG - 2024-03-22 11:05:29 --> UTF-8 Support Enabled
INFO - 2024-03-22 11:05:29 --> Utf8 Class Initialized
INFO - 2024-03-22 11:05:29 --> URI Class Initialized
DEBUG - 2024-03-22 11:05:29 --> No URI present. Default controller set.
INFO - 2024-03-22 11:05:29 --> Router Class Initialized
INFO - 2024-03-22 11:05:29 --> Output Class Initialized
INFO - 2024-03-22 11:05:29 --> Security Class Initialized
DEBUG - 2024-03-22 11:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 11:05:29 --> Input Class Initialized
INFO - 2024-03-22 11:05:29 --> Language Class Initialized
INFO - 2024-03-22 11:05:29 --> Loader Class Initialized
INFO - 2024-03-22 11:05:29 --> Helper loaded: url_helper
INFO - 2024-03-22 11:05:29 --> Helper loaded: file_helper
INFO - 2024-03-22 11:05:29 --> Helper loaded: html_helper
INFO - 2024-03-22 11:05:29 --> Helper loaded: text_helper
INFO - 2024-03-22 11:05:29 --> Helper loaded: form_helper
INFO - 2024-03-22 11:05:29 --> Helper loaded: lang_helper
INFO - 2024-03-22 11:05:29 --> Helper loaded: security_helper
INFO - 2024-03-22 11:05:29 --> Helper loaded: cookie_helper
INFO - 2024-03-22 11:05:29 --> Database Driver Class Initialized
INFO - 2024-03-22 11:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 11:05:29 --> Parser Class Initialized
INFO - 2024-03-22 11:05:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 11:05:29 --> Pagination Class Initialized
INFO - 2024-03-22 11:05:29 --> Form Validation Class Initialized
INFO - 2024-03-22 11:05:29 --> Controller Class Initialized
INFO - 2024-03-22 11:05:29 --> Model Class Initialized
DEBUG - 2024-03-22 11:05:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 11:05:29 --> Model Class Initialized
DEBUG - 2024-03-22 11:05:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 11:05:29 --> Model Class Initialized
INFO - 2024-03-22 11:05:29 --> Model Class Initialized
INFO - 2024-03-22 11:05:29 --> Model Class Initialized
INFO - 2024-03-22 11:05:29 --> Model Class Initialized
DEBUG - 2024-03-22 11:05:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 11:05:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 11:05:29 --> Model Class Initialized
INFO - 2024-03-22 11:05:29 --> Model Class Initialized
INFO - 2024-03-22 11:05:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 11:05:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 11:05:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 11:05:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 11:05:29 --> Model Class Initialized
INFO - 2024-03-22 11:05:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 11:05:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 11:05:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 11:05:29 --> Final output sent to browser
DEBUG - 2024-03-22 11:05:29 --> Total execution time: 0.4362
ERROR - 2024-03-22 11:05:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 11:05:30 --> Config Class Initialized
INFO - 2024-03-22 11:05:30 --> Hooks Class Initialized
DEBUG - 2024-03-22 11:05:30 --> UTF-8 Support Enabled
INFO - 2024-03-22 11:05:30 --> Utf8 Class Initialized
INFO - 2024-03-22 11:05:30 --> URI Class Initialized
INFO - 2024-03-22 11:05:30 --> Router Class Initialized
INFO - 2024-03-22 11:05:30 --> Output Class Initialized
INFO - 2024-03-22 11:05:30 --> Security Class Initialized
DEBUG - 2024-03-22 11:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 11:05:30 --> Input Class Initialized
INFO - 2024-03-22 11:05:30 --> Language Class Initialized
INFO - 2024-03-22 11:05:30 --> Loader Class Initialized
INFO - 2024-03-22 11:05:30 --> Helper loaded: url_helper
INFO - 2024-03-22 11:05:30 --> Helper loaded: file_helper
INFO - 2024-03-22 11:05:30 --> Helper loaded: html_helper
INFO - 2024-03-22 11:05:30 --> Helper loaded: text_helper
INFO - 2024-03-22 11:05:30 --> Helper loaded: form_helper
INFO - 2024-03-22 11:05:30 --> Helper loaded: lang_helper
INFO - 2024-03-22 11:05:30 --> Helper loaded: security_helper
INFO - 2024-03-22 11:05:30 --> Helper loaded: cookie_helper
INFO - 2024-03-22 11:05:30 --> Database Driver Class Initialized
INFO - 2024-03-22 11:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 11:05:30 --> Parser Class Initialized
INFO - 2024-03-22 11:05:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 11:05:30 --> Pagination Class Initialized
INFO - 2024-03-22 11:05:30 --> Form Validation Class Initialized
INFO - 2024-03-22 11:05:30 --> Controller Class Initialized
DEBUG - 2024-03-22 11:05:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 11:05:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 11:05:30 --> Model Class Initialized
INFO - 2024-03-22 11:05:30 --> Final output sent to browser
DEBUG - 2024-03-22 11:05:30 --> Total execution time: 0.0119
ERROR - 2024-03-22 11:05:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 11:05:46 --> Config Class Initialized
INFO - 2024-03-22 11:05:46 --> Hooks Class Initialized
DEBUG - 2024-03-22 11:05:46 --> UTF-8 Support Enabled
INFO - 2024-03-22 11:05:46 --> Utf8 Class Initialized
INFO - 2024-03-22 11:05:46 --> URI Class Initialized
INFO - 2024-03-22 11:05:46 --> Router Class Initialized
INFO - 2024-03-22 11:05:46 --> Output Class Initialized
INFO - 2024-03-22 11:05:46 --> Security Class Initialized
DEBUG - 2024-03-22 11:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 11:05:46 --> Input Class Initialized
INFO - 2024-03-22 11:05:46 --> Language Class Initialized
INFO - 2024-03-22 11:05:46 --> Loader Class Initialized
INFO - 2024-03-22 11:05:46 --> Helper loaded: url_helper
INFO - 2024-03-22 11:05:46 --> Helper loaded: file_helper
INFO - 2024-03-22 11:05:46 --> Helper loaded: html_helper
INFO - 2024-03-22 11:05:46 --> Helper loaded: text_helper
INFO - 2024-03-22 11:05:46 --> Helper loaded: form_helper
INFO - 2024-03-22 11:05:46 --> Helper loaded: lang_helper
INFO - 2024-03-22 11:05:46 --> Helper loaded: security_helper
INFO - 2024-03-22 11:05:46 --> Helper loaded: cookie_helper
INFO - 2024-03-22 11:05:46 --> Database Driver Class Initialized
INFO - 2024-03-22 11:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 11:05:46 --> Parser Class Initialized
INFO - 2024-03-22 11:05:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 11:05:46 --> Pagination Class Initialized
INFO - 2024-03-22 11:05:46 --> Form Validation Class Initialized
INFO - 2024-03-22 11:05:46 --> Controller Class Initialized
INFO - 2024-03-22 11:05:46 --> Model Class Initialized
DEBUG - 2024-03-22 11:05:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 11:05:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 11:05:46 --> Model Class Initialized
DEBUG - 2024-03-22 11:05:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 11:05:46 --> Model Class Initialized
INFO - 2024-03-22 11:05:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-22 11:05:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 11:05:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 11:05:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 11:05:46 --> Model Class Initialized
INFO - 2024-03-22 11:05:46 --> Model Class Initialized
INFO - 2024-03-22 11:05:46 --> Model Class Initialized
INFO - 2024-03-22 11:05:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 11:05:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 11:05:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 11:05:47 --> Final output sent to browser
DEBUG - 2024-03-22 11:05:47 --> Total execution time: 0.2456
ERROR - 2024-03-22 11:05:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 11:05:48 --> Config Class Initialized
INFO - 2024-03-22 11:05:48 --> Hooks Class Initialized
DEBUG - 2024-03-22 11:05:48 --> UTF-8 Support Enabled
INFO - 2024-03-22 11:05:48 --> Utf8 Class Initialized
INFO - 2024-03-22 11:05:48 --> URI Class Initialized
INFO - 2024-03-22 11:05:48 --> Router Class Initialized
INFO - 2024-03-22 11:05:48 --> Output Class Initialized
INFO - 2024-03-22 11:05:48 --> Security Class Initialized
DEBUG - 2024-03-22 11:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 11:05:48 --> Input Class Initialized
INFO - 2024-03-22 11:05:48 --> Language Class Initialized
INFO - 2024-03-22 11:05:48 --> Loader Class Initialized
INFO - 2024-03-22 11:05:48 --> Helper loaded: url_helper
INFO - 2024-03-22 11:05:48 --> Helper loaded: file_helper
INFO - 2024-03-22 11:05:48 --> Helper loaded: html_helper
INFO - 2024-03-22 11:05:48 --> Helper loaded: text_helper
INFO - 2024-03-22 11:05:48 --> Helper loaded: form_helper
INFO - 2024-03-22 11:05:48 --> Helper loaded: lang_helper
INFO - 2024-03-22 11:05:48 --> Helper loaded: security_helper
INFO - 2024-03-22 11:05:48 --> Helper loaded: cookie_helper
INFO - 2024-03-22 11:05:48 --> Database Driver Class Initialized
INFO - 2024-03-22 11:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 11:05:48 --> Parser Class Initialized
INFO - 2024-03-22 11:05:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 11:05:48 --> Pagination Class Initialized
INFO - 2024-03-22 11:05:48 --> Form Validation Class Initialized
INFO - 2024-03-22 11:05:48 --> Controller Class Initialized
INFO - 2024-03-22 11:05:48 --> Model Class Initialized
DEBUG - 2024-03-22 11:05:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 11:05:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 11:05:48 --> Model Class Initialized
DEBUG - 2024-03-22 11:05:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 11:05:48 --> Model Class Initialized
INFO - 2024-03-22 11:05:48 --> Final output sent to browser
DEBUG - 2024-03-22 11:05:48 --> Total execution time: 0.0667
ERROR - 2024-03-22 11:48:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 11:48:20 --> Config Class Initialized
INFO - 2024-03-22 11:48:20 --> Hooks Class Initialized
DEBUG - 2024-03-22 11:48:20 --> UTF-8 Support Enabled
INFO - 2024-03-22 11:48:20 --> Utf8 Class Initialized
INFO - 2024-03-22 11:48:20 --> URI Class Initialized
DEBUG - 2024-03-22 11:48:20 --> No URI present. Default controller set.
INFO - 2024-03-22 11:48:20 --> Router Class Initialized
INFO - 2024-03-22 11:48:20 --> Output Class Initialized
INFO - 2024-03-22 11:48:20 --> Security Class Initialized
DEBUG - 2024-03-22 11:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 11:48:20 --> Input Class Initialized
INFO - 2024-03-22 11:48:20 --> Language Class Initialized
INFO - 2024-03-22 11:48:20 --> Loader Class Initialized
INFO - 2024-03-22 11:48:20 --> Helper loaded: url_helper
INFO - 2024-03-22 11:48:20 --> Helper loaded: file_helper
INFO - 2024-03-22 11:48:20 --> Helper loaded: html_helper
INFO - 2024-03-22 11:48:20 --> Helper loaded: text_helper
INFO - 2024-03-22 11:48:20 --> Helper loaded: form_helper
INFO - 2024-03-22 11:48:20 --> Helper loaded: lang_helper
INFO - 2024-03-22 11:48:20 --> Helper loaded: security_helper
INFO - 2024-03-22 11:48:20 --> Helper loaded: cookie_helper
INFO - 2024-03-22 11:48:20 --> Database Driver Class Initialized
INFO - 2024-03-22 11:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 11:48:20 --> Parser Class Initialized
INFO - 2024-03-22 11:48:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 11:48:20 --> Pagination Class Initialized
INFO - 2024-03-22 11:48:20 --> Form Validation Class Initialized
INFO - 2024-03-22 11:48:20 --> Controller Class Initialized
INFO - 2024-03-22 11:48:20 --> Model Class Initialized
DEBUG - 2024-03-22 11:48:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 11:48:20 --> Model Class Initialized
DEBUG - 2024-03-22 11:48:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 11:48:20 --> Model Class Initialized
INFO - 2024-03-22 11:48:20 --> Model Class Initialized
INFO - 2024-03-22 11:48:20 --> Model Class Initialized
INFO - 2024-03-22 11:48:20 --> Model Class Initialized
DEBUG - 2024-03-22 11:48:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 11:48:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 11:48:20 --> Model Class Initialized
INFO - 2024-03-22 11:48:20 --> Model Class Initialized
INFO - 2024-03-22 11:48:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 11:48:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 11:48:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 11:48:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 11:48:20 --> Model Class Initialized
INFO - 2024-03-22 11:48:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 11:48:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 11:48:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 11:48:20 --> Final output sent to browser
DEBUG - 2024-03-22 11:48:20 --> Total execution time: 0.4524
ERROR - 2024-03-22 13:10:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 13:10:54 --> Config Class Initialized
INFO - 2024-03-22 13:10:54 --> Hooks Class Initialized
DEBUG - 2024-03-22 13:10:54 --> UTF-8 Support Enabled
INFO - 2024-03-22 13:10:54 --> Utf8 Class Initialized
INFO - 2024-03-22 13:10:54 --> URI Class Initialized
INFO - 2024-03-22 13:10:54 --> Router Class Initialized
INFO - 2024-03-22 13:10:54 --> Output Class Initialized
INFO - 2024-03-22 13:10:54 --> Security Class Initialized
DEBUG - 2024-03-22 13:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 13:10:54 --> Input Class Initialized
INFO - 2024-03-22 13:10:54 --> Language Class Initialized
ERROR - 2024-03-22 13:10:54 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2024-03-22 13:21:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 13:21:55 --> Config Class Initialized
INFO - 2024-03-22 13:21:55 --> Hooks Class Initialized
DEBUG - 2024-03-22 13:21:55 --> UTF-8 Support Enabled
INFO - 2024-03-22 13:21:55 --> Utf8 Class Initialized
INFO - 2024-03-22 13:21:55 --> URI Class Initialized
DEBUG - 2024-03-22 13:21:55 --> No URI present. Default controller set.
INFO - 2024-03-22 13:21:55 --> Router Class Initialized
INFO - 2024-03-22 13:21:55 --> Output Class Initialized
INFO - 2024-03-22 13:21:55 --> Security Class Initialized
DEBUG - 2024-03-22 13:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 13:21:55 --> Input Class Initialized
INFO - 2024-03-22 13:21:55 --> Language Class Initialized
INFO - 2024-03-22 13:21:55 --> Loader Class Initialized
INFO - 2024-03-22 13:21:55 --> Helper loaded: url_helper
INFO - 2024-03-22 13:21:55 --> Helper loaded: file_helper
INFO - 2024-03-22 13:21:55 --> Helper loaded: html_helper
INFO - 2024-03-22 13:21:55 --> Helper loaded: text_helper
INFO - 2024-03-22 13:21:55 --> Helper loaded: form_helper
INFO - 2024-03-22 13:21:55 --> Helper loaded: lang_helper
INFO - 2024-03-22 13:21:55 --> Helper loaded: security_helper
INFO - 2024-03-22 13:21:55 --> Helper loaded: cookie_helper
INFO - 2024-03-22 13:21:55 --> Database Driver Class Initialized
INFO - 2024-03-22 13:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 13:21:55 --> Parser Class Initialized
INFO - 2024-03-22 13:21:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 13:21:55 --> Pagination Class Initialized
INFO - 2024-03-22 13:21:55 --> Form Validation Class Initialized
INFO - 2024-03-22 13:21:55 --> Controller Class Initialized
INFO - 2024-03-22 13:21:55 --> Model Class Initialized
DEBUG - 2024-03-22 13:21:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 14:17:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 14:17:04 --> Config Class Initialized
INFO - 2024-03-22 14:17:04 --> Hooks Class Initialized
DEBUG - 2024-03-22 14:17:04 --> UTF-8 Support Enabled
INFO - 2024-03-22 14:17:04 --> Utf8 Class Initialized
INFO - 2024-03-22 14:17:04 --> URI Class Initialized
INFO - 2024-03-22 14:17:04 --> Router Class Initialized
INFO - 2024-03-22 14:17:04 --> Output Class Initialized
INFO - 2024-03-22 14:17:04 --> Security Class Initialized
DEBUG - 2024-03-22 14:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 14:17:04 --> Input Class Initialized
INFO - 2024-03-22 14:17:04 --> Language Class Initialized
ERROR - 2024-03-22 14:17:04 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2024-03-22 14:44:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 14:44:56 --> Config Class Initialized
INFO - 2024-03-22 14:44:56 --> Hooks Class Initialized
DEBUG - 2024-03-22 14:44:56 --> UTF-8 Support Enabled
INFO - 2024-03-22 14:44:56 --> Utf8 Class Initialized
INFO - 2024-03-22 14:44:56 --> URI Class Initialized
INFO - 2024-03-22 14:44:56 --> Router Class Initialized
INFO - 2024-03-22 14:44:56 --> Output Class Initialized
INFO - 2024-03-22 14:44:56 --> Security Class Initialized
DEBUG - 2024-03-22 14:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 14:44:56 --> Input Class Initialized
INFO - 2024-03-22 14:44:56 --> Language Class Initialized
ERROR - 2024-03-22 14:44:56 --> 404 Page Not Found: Wp-admin/setup-config.php
ERROR - 2024-03-22 14:44:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 14:44:56 --> Config Class Initialized
INFO - 2024-03-22 14:44:56 --> Hooks Class Initialized
DEBUG - 2024-03-22 14:44:56 --> UTF-8 Support Enabled
INFO - 2024-03-22 14:44:56 --> Utf8 Class Initialized
INFO - 2024-03-22 14:44:56 --> URI Class Initialized
INFO - 2024-03-22 14:44:56 --> Router Class Initialized
INFO - 2024-03-22 14:44:56 --> Output Class Initialized
INFO - 2024-03-22 14:44:56 --> Security Class Initialized
DEBUG - 2024-03-22 14:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 14:44:56 --> Input Class Initialized
INFO - 2024-03-22 14:44:56 --> Language Class Initialized
ERROR - 2024-03-22 14:44:56 --> 404 Page Not Found: Wordpress/wp-admin
ERROR - 2024-03-22 14:44:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 14:44:57 --> Config Class Initialized
INFO - 2024-03-22 14:44:57 --> Hooks Class Initialized
DEBUG - 2024-03-22 14:44:57 --> UTF-8 Support Enabled
INFO - 2024-03-22 14:44:57 --> Utf8 Class Initialized
INFO - 2024-03-22 14:44:57 --> URI Class Initialized
INFO - 2024-03-22 14:44:57 --> Router Class Initialized
INFO - 2024-03-22 14:44:57 --> Output Class Initialized
INFO - 2024-03-22 14:44:57 --> Security Class Initialized
DEBUG - 2024-03-22 14:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 14:44:57 --> Input Class Initialized
INFO - 2024-03-22 14:44:57 --> Language Class Initialized
ERROR - 2024-03-22 14:44:57 --> 404 Page Not Found: Old/wp-admin
ERROR - 2024-03-22 14:58:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 14:58:35 --> Config Class Initialized
INFO - 2024-03-22 14:58:35 --> Hooks Class Initialized
DEBUG - 2024-03-22 14:58:35 --> UTF-8 Support Enabled
INFO - 2024-03-22 14:58:35 --> Utf8 Class Initialized
INFO - 2024-03-22 14:58:35 --> URI Class Initialized
DEBUG - 2024-03-22 14:58:35 --> No URI present. Default controller set.
INFO - 2024-03-22 14:58:35 --> Router Class Initialized
INFO - 2024-03-22 14:58:35 --> Output Class Initialized
INFO - 2024-03-22 14:58:35 --> Security Class Initialized
DEBUG - 2024-03-22 14:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 14:58:35 --> Input Class Initialized
INFO - 2024-03-22 14:58:35 --> Language Class Initialized
INFO - 2024-03-22 14:58:35 --> Loader Class Initialized
INFO - 2024-03-22 14:58:35 --> Helper loaded: url_helper
INFO - 2024-03-22 14:58:35 --> Helper loaded: file_helper
INFO - 2024-03-22 14:58:35 --> Helper loaded: html_helper
INFO - 2024-03-22 14:58:35 --> Helper loaded: text_helper
INFO - 2024-03-22 14:58:35 --> Helper loaded: form_helper
INFO - 2024-03-22 14:58:35 --> Helper loaded: lang_helper
INFO - 2024-03-22 14:58:35 --> Helper loaded: security_helper
INFO - 2024-03-22 14:58:35 --> Helper loaded: cookie_helper
INFO - 2024-03-22 14:58:35 --> Database Driver Class Initialized
INFO - 2024-03-22 14:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 14:58:35 --> Parser Class Initialized
INFO - 2024-03-22 14:58:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 14:58:35 --> Pagination Class Initialized
INFO - 2024-03-22 14:58:35 --> Form Validation Class Initialized
INFO - 2024-03-22 14:58:35 --> Controller Class Initialized
INFO - 2024-03-22 14:58:35 --> Model Class Initialized
DEBUG - 2024-03-22 14:58:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 15:04:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:04:31 --> Config Class Initialized
INFO - 2024-03-22 15:04:31 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:04:31 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:04:31 --> Utf8 Class Initialized
INFO - 2024-03-22 15:04:31 --> URI Class Initialized
DEBUG - 2024-03-22 15:04:31 --> No URI present. Default controller set.
INFO - 2024-03-22 15:04:31 --> Router Class Initialized
INFO - 2024-03-22 15:04:31 --> Output Class Initialized
INFO - 2024-03-22 15:04:31 --> Security Class Initialized
DEBUG - 2024-03-22 15:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:04:31 --> Input Class Initialized
INFO - 2024-03-22 15:04:31 --> Language Class Initialized
INFO - 2024-03-22 15:04:31 --> Loader Class Initialized
INFO - 2024-03-22 15:04:31 --> Helper loaded: url_helper
INFO - 2024-03-22 15:04:31 --> Helper loaded: file_helper
INFO - 2024-03-22 15:04:31 --> Helper loaded: html_helper
INFO - 2024-03-22 15:04:31 --> Helper loaded: text_helper
INFO - 2024-03-22 15:04:31 --> Helper loaded: form_helper
INFO - 2024-03-22 15:04:31 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:04:31 --> Helper loaded: security_helper
INFO - 2024-03-22 15:04:31 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:04:31 --> Database Driver Class Initialized
INFO - 2024-03-22 15:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:04:31 --> Parser Class Initialized
INFO - 2024-03-22 15:04:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:04:31 --> Pagination Class Initialized
INFO - 2024-03-22 15:04:31 --> Form Validation Class Initialized
INFO - 2024-03-22 15:04:31 --> Controller Class Initialized
INFO - 2024-03-22 15:04:31 --> Model Class Initialized
DEBUG - 2024-03-22 15:04:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 15:15:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:15:09 --> Config Class Initialized
INFO - 2024-03-22 15:15:09 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:15:09 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:15:09 --> Utf8 Class Initialized
INFO - 2024-03-22 15:15:09 --> URI Class Initialized
INFO - 2024-03-22 15:15:09 --> Router Class Initialized
INFO - 2024-03-22 15:15:09 --> Output Class Initialized
INFO - 2024-03-22 15:15:09 --> Security Class Initialized
DEBUG - 2024-03-22 15:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:15:09 --> Input Class Initialized
INFO - 2024-03-22 15:15:09 --> Language Class Initialized
INFO - 2024-03-22 15:15:09 --> Loader Class Initialized
INFO - 2024-03-22 15:15:09 --> Helper loaded: url_helper
INFO - 2024-03-22 15:15:09 --> Helper loaded: file_helper
INFO - 2024-03-22 15:15:09 --> Helper loaded: html_helper
INFO - 2024-03-22 15:15:09 --> Helper loaded: text_helper
INFO - 2024-03-22 15:15:09 --> Helper loaded: form_helper
INFO - 2024-03-22 15:15:09 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:15:09 --> Helper loaded: security_helper
INFO - 2024-03-22 15:15:09 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:15:09 --> Database Driver Class Initialized
INFO - 2024-03-22 15:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:15:09 --> Parser Class Initialized
INFO - 2024-03-22 15:15:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:15:09 --> Pagination Class Initialized
INFO - 2024-03-22 15:15:09 --> Form Validation Class Initialized
INFO - 2024-03-22 15:15:09 --> Controller Class Initialized
ERROR - 2024-03-22 15:15:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:15:09 --> Config Class Initialized
INFO - 2024-03-22 15:15:09 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:15:09 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:15:09 --> Utf8 Class Initialized
INFO - 2024-03-22 15:15:09 --> URI Class Initialized
INFO - 2024-03-22 15:15:09 --> Router Class Initialized
INFO - 2024-03-22 15:15:09 --> Output Class Initialized
INFO - 2024-03-22 15:15:09 --> Security Class Initialized
DEBUG - 2024-03-22 15:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:15:09 --> Input Class Initialized
INFO - 2024-03-22 15:15:09 --> Language Class Initialized
INFO - 2024-03-22 15:15:09 --> Loader Class Initialized
INFO - 2024-03-22 15:15:09 --> Helper loaded: url_helper
INFO - 2024-03-22 15:15:09 --> Helper loaded: file_helper
INFO - 2024-03-22 15:15:09 --> Helper loaded: html_helper
INFO - 2024-03-22 15:15:09 --> Helper loaded: text_helper
INFO - 2024-03-22 15:15:09 --> Helper loaded: form_helper
INFO - 2024-03-22 15:15:09 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:15:09 --> Helper loaded: security_helper
INFO - 2024-03-22 15:15:09 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:15:09 --> Database Driver Class Initialized
INFO - 2024-03-22 15:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:15:09 --> Parser Class Initialized
INFO - 2024-03-22 15:15:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:15:09 --> Pagination Class Initialized
INFO - 2024-03-22 15:15:09 --> Form Validation Class Initialized
INFO - 2024-03-22 15:15:09 --> Controller Class Initialized
INFO - 2024-03-22 15:15:09 --> Model Class Initialized
DEBUG - 2024-03-22 15:15:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:15:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-22 15:15:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:15:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:15:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:15:09 --> Model Class Initialized
INFO - 2024-03-22 15:15:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:15:09 --> Final output sent to browser
DEBUG - 2024-03-22 15:15:09 --> Total execution time: 0.0343
ERROR - 2024-03-22 15:15:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:15:13 --> Config Class Initialized
INFO - 2024-03-22 15:15:13 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:15:13 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:15:13 --> Utf8 Class Initialized
INFO - 2024-03-22 15:15:13 --> URI Class Initialized
INFO - 2024-03-22 15:15:13 --> Router Class Initialized
INFO - 2024-03-22 15:15:13 --> Output Class Initialized
INFO - 2024-03-22 15:15:13 --> Security Class Initialized
DEBUG - 2024-03-22 15:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:15:13 --> Input Class Initialized
INFO - 2024-03-22 15:15:13 --> Language Class Initialized
INFO - 2024-03-22 15:15:13 --> Loader Class Initialized
INFO - 2024-03-22 15:15:13 --> Helper loaded: url_helper
INFO - 2024-03-22 15:15:13 --> Helper loaded: file_helper
INFO - 2024-03-22 15:15:13 --> Helper loaded: html_helper
INFO - 2024-03-22 15:15:13 --> Helper loaded: text_helper
INFO - 2024-03-22 15:15:13 --> Helper loaded: form_helper
INFO - 2024-03-22 15:15:13 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:15:13 --> Helper loaded: security_helper
INFO - 2024-03-22 15:15:13 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:15:13 --> Database Driver Class Initialized
INFO - 2024-03-22 15:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:15:13 --> Parser Class Initialized
INFO - 2024-03-22 15:15:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:15:13 --> Pagination Class Initialized
INFO - 2024-03-22 15:15:13 --> Form Validation Class Initialized
INFO - 2024-03-22 15:15:13 --> Controller Class Initialized
INFO - 2024-03-22 15:15:13 --> Model Class Initialized
DEBUG - 2024-03-22 15:15:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:15:13 --> Model Class Initialized
INFO - 2024-03-22 15:15:13 --> Final output sent to browser
DEBUG - 2024-03-22 15:15:13 --> Total execution time: 0.0189
ERROR - 2024-03-22 15:15:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:15:14 --> Config Class Initialized
INFO - 2024-03-22 15:15:14 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:15:14 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:15:14 --> Utf8 Class Initialized
INFO - 2024-03-22 15:15:14 --> URI Class Initialized
DEBUG - 2024-03-22 15:15:14 --> No URI present. Default controller set.
INFO - 2024-03-22 15:15:14 --> Router Class Initialized
INFO - 2024-03-22 15:15:14 --> Output Class Initialized
INFO - 2024-03-22 15:15:14 --> Security Class Initialized
DEBUG - 2024-03-22 15:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:15:14 --> Input Class Initialized
INFO - 2024-03-22 15:15:14 --> Language Class Initialized
INFO - 2024-03-22 15:15:14 --> Loader Class Initialized
INFO - 2024-03-22 15:15:14 --> Helper loaded: url_helper
INFO - 2024-03-22 15:15:14 --> Helper loaded: file_helper
INFO - 2024-03-22 15:15:14 --> Helper loaded: html_helper
INFO - 2024-03-22 15:15:14 --> Helper loaded: text_helper
INFO - 2024-03-22 15:15:14 --> Helper loaded: form_helper
INFO - 2024-03-22 15:15:14 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:15:14 --> Helper loaded: security_helper
INFO - 2024-03-22 15:15:14 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:15:14 --> Database Driver Class Initialized
INFO - 2024-03-22 15:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:15:14 --> Parser Class Initialized
INFO - 2024-03-22 15:15:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:15:14 --> Pagination Class Initialized
INFO - 2024-03-22 15:15:14 --> Form Validation Class Initialized
INFO - 2024-03-22 15:15:14 --> Controller Class Initialized
INFO - 2024-03-22 15:15:14 --> Model Class Initialized
DEBUG - 2024-03-22 15:15:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:15:14 --> Model Class Initialized
DEBUG - 2024-03-22 15:15:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:15:14 --> Model Class Initialized
INFO - 2024-03-22 15:15:14 --> Model Class Initialized
INFO - 2024-03-22 15:15:14 --> Model Class Initialized
INFO - 2024-03-22 15:15:14 --> Model Class Initialized
DEBUG - 2024-03-22 15:15:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:15:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:15:14 --> Model Class Initialized
INFO - 2024-03-22 15:15:14 --> Model Class Initialized
INFO - 2024-03-22 15:15:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 15:15:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:15:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:15:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:15:14 --> Model Class Initialized
INFO - 2024-03-22 15:15:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 15:15:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 15:15:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:15:14 --> Final output sent to browser
DEBUG - 2024-03-22 15:15:14 --> Total execution time: 0.4424
ERROR - 2024-03-22 15:15:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:15:15 --> Config Class Initialized
INFO - 2024-03-22 15:15:15 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:15:15 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:15:15 --> Utf8 Class Initialized
INFO - 2024-03-22 15:15:15 --> URI Class Initialized
INFO - 2024-03-22 15:15:15 --> Router Class Initialized
INFO - 2024-03-22 15:15:15 --> Output Class Initialized
INFO - 2024-03-22 15:15:15 --> Security Class Initialized
DEBUG - 2024-03-22 15:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:15:15 --> Input Class Initialized
INFO - 2024-03-22 15:15:15 --> Language Class Initialized
INFO - 2024-03-22 15:15:15 --> Loader Class Initialized
INFO - 2024-03-22 15:15:15 --> Helper loaded: url_helper
INFO - 2024-03-22 15:15:15 --> Helper loaded: file_helper
INFO - 2024-03-22 15:15:15 --> Helper loaded: html_helper
INFO - 2024-03-22 15:15:15 --> Helper loaded: text_helper
INFO - 2024-03-22 15:15:15 --> Helper loaded: form_helper
INFO - 2024-03-22 15:15:15 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:15:15 --> Helper loaded: security_helper
INFO - 2024-03-22 15:15:15 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:15:15 --> Database Driver Class Initialized
INFO - 2024-03-22 15:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:15:15 --> Parser Class Initialized
INFO - 2024-03-22 15:15:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:15:15 --> Pagination Class Initialized
INFO - 2024-03-22 15:15:15 --> Form Validation Class Initialized
INFO - 2024-03-22 15:15:15 --> Controller Class Initialized
DEBUG - 2024-03-22 15:15:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:15:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:15:15 --> Model Class Initialized
INFO - 2024-03-22 15:15:15 --> Final output sent to browser
DEBUG - 2024-03-22 15:15:15 --> Total execution time: 0.0149
ERROR - 2024-03-22 15:15:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:15:27 --> Config Class Initialized
INFO - 2024-03-22 15:15:27 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:15:27 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:15:27 --> Utf8 Class Initialized
INFO - 2024-03-22 15:15:27 --> URI Class Initialized
INFO - 2024-03-22 15:15:27 --> Router Class Initialized
INFO - 2024-03-22 15:15:27 --> Output Class Initialized
INFO - 2024-03-22 15:15:27 --> Security Class Initialized
DEBUG - 2024-03-22 15:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:15:27 --> Input Class Initialized
INFO - 2024-03-22 15:15:27 --> Language Class Initialized
INFO - 2024-03-22 15:15:27 --> Loader Class Initialized
INFO - 2024-03-22 15:15:27 --> Helper loaded: url_helper
INFO - 2024-03-22 15:15:27 --> Helper loaded: file_helper
INFO - 2024-03-22 15:15:27 --> Helper loaded: html_helper
INFO - 2024-03-22 15:15:27 --> Helper loaded: text_helper
INFO - 2024-03-22 15:15:27 --> Helper loaded: form_helper
INFO - 2024-03-22 15:15:27 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:15:27 --> Helper loaded: security_helper
INFO - 2024-03-22 15:15:27 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:15:27 --> Database Driver Class Initialized
INFO - 2024-03-22 15:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:15:27 --> Parser Class Initialized
INFO - 2024-03-22 15:15:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:15:27 --> Pagination Class Initialized
INFO - 2024-03-22 15:15:27 --> Form Validation Class Initialized
INFO - 2024-03-22 15:15:27 --> Controller Class Initialized
INFO - 2024-03-22 15:15:27 --> Model Class Initialized
DEBUG - 2024-03-22 15:15:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:15:27 --> Final output sent to browser
DEBUG - 2024-03-22 15:15:27 --> Total execution time: 0.0154
ERROR - 2024-03-22 15:15:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:15:28 --> Config Class Initialized
INFO - 2024-03-22 15:15:28 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:15:28 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:15:28 --> Utf8 Class Initialized
INFO - 2024-03-22 15:15:28 --> URI Class Initialized
INFO - 2024-03-22 15:15:28 --> Router Class Initialized
INFO - 2024-03-22 15:15:28 --> Output Class Initialized
INFO - 2024-03-22 15:15:28 --> Security Class Initialized
DEBUG - 2024-03-22 15:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:15:28 --> Input Class Initialized
INFO - 2024-03-22 15:15:28 --> Language Class Initialized
INFO - 2024-03-22 15:15:28 --> Loader Class Initialized
INFO - 2024-03-22 15:15:28 --> Helper loaded: url_helper
INFO - 2024-03-22 15:15:28 --> Helper loaded: file_helper
INFO - 2024-03-22 15:15:28 --> Helper loaded: html_helper
INFO - 2024-03-22 15:15:28 --> Helper loaded: text_helper
INFO - 2024-03-22 15:15:28 --> Helper loaded: form_helper
INFO - 2024-03-22 15:15:28 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:15:28 --> Helper loaded: security_helper
INFO - 2024-03-22 15:15:28 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:15:28 --> Database Driver Class Initialized
INFO - 2024-03-22 15:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:15:28 --> Parser Class Initialized
INFO - 2024-03-22 15:15:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:15:28 --> Pagination Class Initialized
INFO - 2024-03-22 15:15:28 --> Form Validation Class Initialized
INFO - 2024-03-22 15:15:28 --> Controller Class Initialized
INFO - 2024-03-22 15:15:28 --> Model Class Initialized
DEBUG - 2024-03-22 15:15:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:15:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-22 15:15:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:15:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:15:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:15:28 --> Model Class Initialized
INFO - 2024-03-22 15:15:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:15:28 --> Final output sent to browser
DEBUG - 2024-03-22 15:15:28 --> Total execution time: 0.0304
ERROR - 2024-03-22 15:15:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:15:39 --> Config Class Initialized
INFO - 2024-03-22 15:15:39 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:15:39 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:15:39 --> Utf8 Class Initialized
INFO - 2024-03-22 15:15:39 --> URI Class Initialized
INFO - 2024-03-22 15:15:39 --> Router Class Initialized
INFO - 2024-03-22 15:15:39 --> Output Class Initialized
INFO - 2024-03-22 15:15:39 --> Security Class Initialized
DEBUG - 2024-03-22 15:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:15:39 --> Input Class Initialized
INFO - 2024-03-22 15:15:39 --> Language Class Initialized
INFO - 2024-03-22 15:15:39 --> Loader Class Initialized
INFO - 2024-03-22 15:15:39 --> Helper loaded: url_helper
INFO - 2024-03-22 15:15:39 --> Helper loaded: file_helper
INFO - 2024-03-22 15:15:39 --> Helper loaded: html_helper
INFO - 2024-03-22 15:15:39 --> Helper loaded: text_helper
INFO - 2024-03-22 15:15:39 --> Helper loaded: form_helper
INFO - 2024-03-22 15:15:39 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:15:39 --> Helper loaded: security_helper
INFO - 2024-03-22 15:15:39 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:15:39 --> Database Driver Class Initialized
INFO - 2024-03-22 15:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:15:39 --> Parser Class Initialized
INFO - 2024-03-22 15:15:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:15:39 --> Pagination Class Initialized
INFO - 2024-03-22 15:15:39 --> Form Validation Class Initialized
INFO - 2024-03-22 15:15:39 --> Controller Class Initialized
INFO - 2024-03-22 15:15:39 --> Model Class Initialized
DEBUG - 2024-03-22 15:15:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:15:39 --> Model Class Initialized
INFO - 2024-03-22 15:15:39 --> Final output sent to browser
DEBUG - 2024-03-22 15:15:39 --> Total execution time: 0.0170
ERROR - 2024-03-22 15:15:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:15:40 --> Config Class Initialized
INFO - 2024-03-22 15:15:40 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:15:40 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:15:40 --> Utf8 Class Initialized
INFO - 2024-03-22 15:15:40 --> URI Class Initialized
DEBUG - 2024-03-22 15:15:40 --> No URI present. Default controller set.
INFO - 2024-03-22 15:15:40 --> Router Class Initialized
INFO - 2024-03-22 15:15:40 --> Output Class Initialized
INFO - 2024-03-22 15:15:40 --> Security Class Initialized
DEBUG - 2024-03-22 15:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:15:40 --> Input Class Initialized
INFO - 2024-03-22 15:15:40 --> Language Class Initialized
INFO - 2024-03-22 15:15:40 --> Loader Class Initialized
INFO - 2024-03-22 15:15:40 --> Helper loaded: url_helper
INFO - 2024-03-22 15:15:40 --> Helper loaded: file_helper
INFO - 2024-03-22 15:15:40 --> Helper loaded: html_helper
INFO - 2024-03-22 15:15:40 --> Helper loaded: text_helper
INFO - 2024-03-22 15:15:40 --> Helper loaded: form_helper
INFO - 2024-03-22 15:15:40 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:15:40 --> Helper loaded: security_helper
INFO - 2024-03-22 15:15:40 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:15:40 --> Database Driver Class Initialized
INFO - 2024-03-22 15:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:15:40 --> Parser Class Initialized
INFO - 2024-03-22 15:15:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:15:40 --> Pagination Class Initialized
INFO - 2024-03-22 15:15:40 --> Form Validation Class Initialized
INFO - 2024-03-22 15:15:40 --> Controller Class Initialized
INFO - 2024-03-22 15:15:40 --> Model Class Initialized
DEBUG - 2024-03-22 15:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:15:40 --> Model Class Initialized
DEBUG - 2024-03-22 15:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:15:40 --> Model Class Initialized
INFO - 2024-03-22 15:15:40 --> Model Class Initialized
INFO - 2024-03-22 15:15:40 --> Model Class Initialized
INFO - 2024-03-22 15:15:40 --> Model Class Initialized
DEBUG - 2024-03-22 15:15:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:15:40 --> Model Class Initialized
INFO - 2024-03-22 15:15:40 --> Model Class Initialized
INFO - 2024-03-22 15:15:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 15:15:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:15:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:15:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:15:40 --> Model Class Initialized
INFO - 2024-03-22 15:15:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 15:15:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 15:15:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:15:40 --> Final output sent to browser
DEBUG - 2024-03-22 15:15:40 --> Total execution time: 0.2506
ERROR - 2024-03-22 15:15:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:15:43 --> Config Class Initialized
INFO - 2024-03-22 15:15:43 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:15:43 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:15:43 --> Utf8 Class Initialized
INFO - 2024-03-22 15:15:43 --> URI Class Initialized
INFO - 2024-03-22 15:15:43 --> Router Class Initialized
INFO - 2024-03-22 15:15:43 --> Output Class Initialized
INFO - 2024-03-22 15:15:43 --> Security Class Initialized
DEBUG - 2024-03-22 15:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:15:43 --> Input Class Initialized
INFO - 2024-03-22 15:15:43 --> Language Class Initialized
INFO - 2024-03-22 15:15:43 --> Loader Class Initialized
INFO - 2024-03-22 15:15:43 --> Helper loaded: url_helper
INFO - 2024-03-22 15:15:43 --> Helper loaded: file_helper
INFO - 2024-03-22 15:15:43 --> Helper loaded: html_helper
INFO - 2024-03-22 15:15:43 --> Helper loaded: text_helper
INFO - 2024-03-22 15:15:43 --> Helper loaded: form_helper
INFO - 2024-03-22 15:15:43 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:15:43 --> Helper loaded: security_helper
INFO - 2024-03-22 15:15:43 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:15:43 --> Database Driver Class Initialized
INFO - 2024-03-22 15:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:15:43 --> Parser Class Initialized
INFO - 2024-03-22 15:15:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:15:43 --> Pagination Class Initialized
INFO - 2024-03-22 15:15:43 --> Form Validation Class Initialized
INFO - 2024-03-22 15:15:43 --> Controller Class Initialized
DEBUG - 2024-03-22 15:15:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:15:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:15:43 --> Model Class Initialized
DEBUG - 2024-03-22 15:15:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:15:43 --> Model Class Initialized
INFO - 2024-03-22 15:15:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-03-22 15:15:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:15:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:15:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:15:43 --> Model Class Initialized
INFO - 2024-03-22 15:15:43 --> Model Class Initialized
INFO - 2024-03-22 15:15:43 --> Model Class Initialized
INFO - 2024-03-22 15:15:43 --> Model Class Initialized
INFO - 2024-03-22 15:15:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 15:15:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 15:15:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:15:44 --> Final output sent to browser
DEBUG - 2024-03-22 15:15:44 --> Total execution time: 0.2436
ERROR - 2024-03-22 15:15:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:15:47 --> Config Class Initialized
INFO - 2024-03-22 15:15:47 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:15:47 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:15:47 --> Utf8 Class Initialized
INFO - 2024-03-22 15:15:47 --> URI Class Initialized
DEBUG - 2024-03-22 15:15:47 --> No URI present. Default controller set.
INFO - 2024-03-22 15:15:47 --> Router Class Initialized
INFO - 2024-03-22 15:15:47 --> Output Class Initialized
INFO - 2024-03-22 15:15:47 --> Security Class Initialized
DEBUG - 2024-03-22 15:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:15:47 --> Input Class Initialized
INFO - 2024-03-22 15:15:47 --> Language Class Initialized
INFO - 2024-03-22 15:15:47 --> Loader Class Initialized
INFO - 2024-03-22 15:15:47 --> Helper loaded: url_helper
INFO - 2024-03-22 15:15:47 --> Helper loaded: file_helper
INFO - 2024-03-22 15:15:47 --> Helper loaded: html_helper
INFO - 2024-03-22 15:15:47 --> Helper loaded: text_helper
INFO - 2024-03-22 15:15:47 --> Helper loaded: form_helper
INFO - 2024-03-22 15:15:47 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:15:47 --> Helper loaded: security_helper
INFO - 2024-03-22 15:15:47 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:15:47 --> Database Driver Class Initialized
INFO - 2024-03-22 15:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:15:47 --> Parser Class Initialized
INFO - 2024-03-22 15:15:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:15:47 --> Pagination Class Initialized
INFO - 2024-03-22 15:15:47 --> Form Validation Class Initialized
INFO - 2024-03-22 15:15:47 --> Controller Class Initialized
INFO - 2024-03-22 15:15:47 --> Model Class Initialized
DEBUG - 2024-03-22 15:15:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:15:47 --> Model Class Initialized
DEBUG - 2024-03-22 15:15:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:15:47 --> Model Class Initialized
INFO - 2024-03-22 15:15:47 --> Model Class Initialized
INFO - 2024-03-22 15:15:47 --> Model Class Initialized
INFO - 2024-03-22 15:15:47 --> Model Class Initialized
DEBUG - 2024-03-22 15:15:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:15:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:15:47 --> Model Class Initialized
INFO - 2024-03-22 15:15:47 --> Model Class Initialized
INFO - 2024-03-22 15:15:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 15:15:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:15:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:15:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:15:47 --> Model Class Initialized
INFO - 2024-03-22 15:15:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 15:15:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 15:15:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:15:47 --> Final output sent to browser
DEBUG - 2024-03-22 15:15:47 --> Total execution time: 0.2487
ERROR - 2024-03-22 15:15:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:15:58 --> Config Class Initialized
INFO - 2024-03-22 15:15:58 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:15:58 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:15:58 --> Utf8 Class Initialized
INFO - 2024-03-22 15:15:58 --> URI Class Initialized
INFO - 2024-03-22 15:15:58 --> Router Class Initialized
INFO - 2024-03-22 15:15:58 --> Output Class Initialized
INFO - 2024-03-22 15:15:58 --> Security Class Initialized
DEBUG - 2024-03-22 15:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:15:58 --> Input Class Initialized
INFO - 2024-03-22 15:15:58 --> Language Class Initialized
INFO - 2024-03-22 15:15:58 --> Loader Class Initialized
INFO - 2024-03-22 15:15:58 --> Helper loaded: url_helper
INFO - 2024-03-22 15:15:58 --> Helper loaded: file_helper
INFO - 2024-03-22 15:15:58 --> Helper loaded: html_helper
INFO - 2024-03-22 15:15:58 --> Helper loaded: text_helper
INFO - 2024-03-22 15:15:58 --> Helper loaded: form_helper
INFO - 2024-03-22 15:15:58 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:15:58 --> Helper loaded: security_helper
INFO - 2024-03-22 15:15:58 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:15:58 --> Database Driver Class Initialized
INFO - 2024-03-22 15:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:15:58 --> Parser Class Initialized
INFO - 2024-03-22 15:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:15:58 --> Pagination Class Initialized
INFO - 2024-03-22 15:15:58 --> Form Validation Class Initialized
INFO - 2024-03-22 15:15:58 --> Controller Class Initialized
DEBUG - 2024-03-22 15:15:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:15:58 --> Model Class Initialized
DEBUG - 2024-03-22 15:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:15:58 --> Model Class Initialized
INFO - 2024-03-22 15:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-03-22 15:15:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:15:58 --> Model Class Initialized
INFO - 2024-03-22 15:15:58 --> Model Class Initialized
INFO - 2024-03-22 15:15:58 --> Model Class Initialized
INFO - 2024-03-22 15:15:58 --> Model Class Initialized
INFO - 2024-03-22 15:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 15:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 15:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:15:58 --> Final output sent to browser
DEBUG - 2024-03-22 15:15:58 --> Total execution time: 0.1939
ERROR - 2024-03-22 15:21:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:21:15 --> Config Class Initialized
INFO - 2024-03-22 15:21:15 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:21:15 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:21:15 --> Utf8 Class Initialized
INFO - 2024-03-22 15:21:15 --> URI Class Initialized
INFO - 2024-03-22 15:21:15 --> Router Class Initialized
INFO - 2024-03-22 15:21:15 --> Output Class Initialized
INFO - 2024-03-22 15:21:15 --> Security Class Initialized
DEBUG - 2024-03-22 15:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:21:15 --> Input Class Initialized
INFO - 2024-03-22 15:21:15 --> Language Class Initialized
INFO - 2024-03-22 15:21:15 --> Loader Class Initialized
INFO - 2024-03-22 15:21:15 --> Helper loaded: url_helper
INFO - 2024-03-22 15:21:15 --> Helper loaded: file_helper
INFO - 2024-03-22 15:21:15 --> Helper loaded: html_helper
INFO - 2024-03-22 15:21:15 --> Helper loaded: text_helper
INFO - 2024-03-22 15:21:15 --> Helper loaded: form_helper
INFO - 2024-03-22 15:21:15 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:21:15 --> Helper loaded: security_helper
INFO - 2024-03-22 15:21:15 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:21:15 --> Database Driver Class Initialized
INFO - 2024-03-22 15:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:21:15 --> Parser Class Initialized
INFO - 2024-03-22 15:21:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:21:15 --> Pagination Class Initialized
INFO - 2024-03-22 15:21:15 --> Form Validation Class Initialized
INFO - 2024-03-22 15:21:15 --> Controller Class Initialized
DEBUG - 2024-03-22 15:21:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:21:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:21:15 --> Model Class Initialized
DEBUG - 2024-03-22 15:21:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:21:15 --> Model Class Initialized
DEBUG - 2024-03-22 15:21:15 --> Auth class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:21:15 --> Final output sent to browser
DEBUG - 2024-03-22 15:21:15 --> Total execution time: 0.0269
ERROR - 2024-03-22 15:21:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:21:26 --> Config Class Initialized
INFO - 2024-03-22 15:21:26 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:21:26 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:21:26 --> Utf8 Class Initialized
INFO - 2024-03-22 15:21:26 --> URI Class Initialized
INFO - 2024-03-22 15:21:26 --> Router Class Initialized
INFO - 2024-03-22 15:21:26 --> Output Class Initialized
INFO - 2024-03-22 15:21:26 --> Security Class Initialized
DEBUG - 2024-03-22 15:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:21:26 --> Input Class Initialized
INFO - 2024-03-22 15:21:26 --> Language Class Initialized
INFO - 2024-03-22 15:21:26 --> Loader Class Initialized
INFO - 2024-03-22 15:21:26 --> Helper loaded: url_helper
INFO - 2024-03-22 15:21:26 --> Helper loaded: file_helper
INFO - 2024-03-22 15:21:26 --> Helper loaded: html_helper
INFO - 2024-03-22 15:21:26 --> Helper loaded: text_helper
INFO - 2024-03-22 15:21:26 --> Helper loaded: form_helper
INFO - 2024-03-22 15:21:26 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:21:26 --> Helper loaded: security_helper
INFO - 2024-03-22 15:21:26 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:21:26 --> Database Driver Class Initialized
INFO - 2024-03-22 15:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:21:26 --> Parser Class Initialized
INFO - 2024-03-22 15:21:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:21:26 --> Pagination Class Initialized
INFO - 2024-03-22 15:21:26 --> Form Validation Class Initialized
INFO - 2024-03-22 15:21:26 --> Controller Class Initialized
DEBUG - 2024-03-22 15:21:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:21:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:21:26 --> Model Class Initialized
DEBUG - 2024-03-22 15:21:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:21:26 --> Model Class Initialized
DEBUG - 2024-03-22 15:21:26 --> Auth class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:21:26 --> Final output sent to browser
DEBUG - 2024-03-22 15:21:26 --> Total execution time: 0.0194
ERROR - 2024-03-22 15:21:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:21:31 --> Config Class Initialized
INFO - 2024-03-22 15:21:31 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:21:31 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:21:31 --> Utf8 Class Initialized
INFO - 2024-03-22 15:21:31 --> URI Class Initialized
DEBUG - 2024-03-22 15:21:31 --> No URI present. Default controller set.
INFO - 2024-03-22 15:21:31 --> Router Class Initialized
INFO - 2024-03-22 15:21:31 --> Output Class Initialized
INFO - 2024-03-22 15:21:31 --> Security Class Initialized
DEBUG - 2024-03-22 15:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:21:31 --> Input Class Initialized
INFO - 2024-03-22 15:21:31 --> Language Class Initialized
INFO - 2024-03-22 15:21:31 --> Loader Class Initialized
INFO - 2024-03-22 15:21:31 --> Helper loaded: url_helper
INFO - 2024-03-22 15:21:31 --> Helper loaded: file_helper
INFO - 2024-03-22 15:21:31 --> Helper loaded: html_helper
INFO - 2024-03-22 15:21:31 --> Helper loaded: text_helper
INFO - 2024-03-22 15:21:31 --> Helper loaded: form_helper
INFO - 2024-03-22 15:21:31 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:21:31 --> Helper loaded: security_helper
INFO - 2024-03-22 15:21:31 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:21:31 --> Database Driver Class Initialized
INFO - 2024-03-22 15:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:21:31 --> Parser Class Initialized
INFO - 2024-03-22 15:21:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:21:31 --> Pagination Class Initialized
INFO - 2024-03-22 15:21:31 --> Form Validation Class Initialized
INFO - 2024-03-22 15:21:31 --> Controller Class Initialized
INFO - 2024-03-22 15:21:31 --> Model Class Initialized
DEBUG - 2024-03-22 15:21:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:21:31 --> Model Class Initialized
DEBUG - 2024-03-22 15:21:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:21:31 --> Model Class Initialized
INFO - 2024-03-22 15:21:31 --> Model Class Initialized
INFO - 2024-03-22 15:21:31 --> Model Class Initialized
INFO - 2024-03-22 15:21:31 --> Model Class Initialized
DEBUG - 2024-03-22 15:21:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:21:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:21:31 --> Model Class Initialized
INFO - 2024-03-22 15:21:31 --> Model Class Initialized
INFO - 2024-03-22 15:21:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 15:21:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:21:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:21:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:21:31 --> Model Class Initialized
INFO - 2024-03-22 15:21:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 15:21:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 15:21:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:21:31 --> Final output sent to browser
DEBUG - 2024-03-22 15:21:31 --> Total execution time: 0.2562
ERROR - 2024-03-22 15:21:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:21:45 --> Config Class Initialized
INFO - 2024-03-22 15:21:45 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:21:45 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:21:45 --> Utf8 Class Initialized
INFO - 2024-03-22 15:21:45 --> URI Class Initialized
INFO - 2024-03-22 15:21:45 --> Router Class Initialized
INFO - 2024-03-22 15:21:45 --> Output Class Initialized
INFO - 2024-03-22 15:21:45 --> Security Class Initialized
DEBUG - 2024-03-22 15:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:21:45 --> Input Class Initialized
INFO - 2024-03-22 15:21:45 --> Language Class Initialized
INFO - 2024-03-22 15:21:45 --> Loader Class Initialized
INFO - 2024-03-22 15:21:45 --> Helper loaded: url_helper
INFO - 2024-03-22 15:21:45 --> Helper loaded: file_helper
INFO - 2024-03-22 15:21:45 --> Helper loaded: html_helper
INFO - 2024-03-22 15:21:45 --> Helper loaded: text_helper
INFO - 2024-03-22 15:21:45 --> Helper loaded: form_helper
INFO - 2024-03-22 15:21:45 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:21:45 --> Helper loaded: security_helper
INFO - 2024-03-22 15:21:45 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:21:45 --> Database Driver Class Initialized
INFO - 2024-03-22 15:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:21:45 --> Parser Class Initialized
INFO - 2024-03-22 15:21:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:21:45 --> Pagination Class Initialized
INFO - 2024-03-22 15:21:45 --> Form Validation Class Initialized
INFO - 2024-03-22 15:21:45 --> Controller Class Initialized
INFO - 2024-03-22 15:21:45 --> Model Class Initialized
DEBUG - 2024-03-22 15:21:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:21:45 --> Final output sent to browser
DEBUG - 2024-03-22 15:21:45 --> Total execution time: 0.0165
ERROR - 2024-03-22 15:21:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:21:46 --> Config Class Initialized
INFO - 2024-03-22 15:21:46 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:21:46 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:21:46 --> Utf8 Class Initialized
INFO - 2024-03-22 15:21:46 --> URI Class Initialized
INFO - 2024-03-22 15:21:46 --> Router Class Initialized
INFO - 2024-03-22 15:21:46 --> Output Class Initialized
INFO - 2024-03-22 15:21:46 --> Security Class Initialized
DEBUG - 2024-03-22 15:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:21:46 --> Input Class Initialized
INFO - 2024-03-22 15:21:46 --> Language Class Initialized
INFO - 2024-03-22 15:21:46 --> Loader Class Initialized
INFO - 2024-03-22 15:21:46 --> Helper loaded: url_helper
INFO - 2024-03-22 15:21:46 --> Helper loaded: file_helper
INFO - 2024-03-22 15:21:46 --> Helper loaded: html_helper
INFO - 2024-03-22 15:21:46 --> Helper loaded: text_helper
INFO - 2024-03-22 15:21:46 --> Helper loaded: form_helper
INFO - 2024-03-22 15:21:46 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:21:46 --> Helper loaded: security_helper
INFO - 2024-03-22 15:21:46 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:21:46 --> Database Driver Class Initialized
INFO - 2024-03-22 15:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:21:46 --> Parser Class Initialized
INFO - 2024-03-22 15:21:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:21:46 --> Pagination Class Initialized
INFO - 2024-03-22 15:21:46 --> Form Validation Class Initialized
INFO - 2024-03-22 15:21:46 --> Controller Class Initialized
INFO - 2024-03-22 15:21:46 --> Model Class Initialized
DEBUG - 2024-03-22 15:21:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:21:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-22 15:21:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:21:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:21:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:21:46 --> Model Class Initialized
INFO - 2024-03-22 15:21:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:21:46 --> Final output sent to browser
DEBUG - 2024-03-22 15:21:46 --> Total execution time: 0.0394
ERROR - 2024-03-22 15:21:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:21:53 --> Config Class Initialized
INFO - 2024-03-22 15:21:53 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:21:53 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:21:53 --> Utf8 Class Initialized
INFO - 2024-03-22 15:21:53 --> URI Class Initialized
INFO - 2024-03-22 15:21:53 --> Router Class Initialized
INFO - 2024-03-22 15:21:53 --> Output Class Initialized
INFO - 2024-03-22 15:21:53 --> Security Class Initialized
DEBUG - 2024-03-22 15:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:21:53 --> Input Class Initialized
INFO - 2024-03-22 15:21:53 --> Language Class Initialized
INFO - 2024-03-22 15:21:53 --> Loader Class Initialized
INFO - 2024-03-22 15:21:53 --> Helper loaded: url_helper
INFO - 2024-03-22 15:21:53 --> Helper loaded: file_helper
INFO - 2024-03-22 15:21:53 --> Helper loaded: html_helper
INFO - 2024-03-22 15:21:53 --> Helper loaded: text_helper
INFO - 2024-03-22 15:21:53 --> Helper loaded: form_helper
INFO - 2024-03-22 15:21:53 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:21:53 --> Helper loaded: security_helper
INFO - 2024-03-22 15:21:53 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:21:53 --> Database Driver Class Initialized
INFO - 2024-03-22 15:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:21:53 --> Parser Class Initialized
INFO - 2024-03-22 15:21:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:21:53 --> Pagination Class Initialized
INFO - 2024-03-22 15:21:53 --> Form Validation Class Initialized
INFO - 2024-03-22 15:21:53 --> Controller Class Initialized
INFO - 2024-03-22 15:21:53 --> Model Class Initialized
DEBUG - 2024-03-22 15:21:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:21:53 --> Model Class Initialized
INFO - 2024-03-22 15:21:53 --> Final output sent to browser
DEBUG - 2024-03-22 15:21:53 --> Total execution time: 0.0162
ERROR - 2024-03-22 15:21:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:21:53 --> Config Class Initialized
INFO - 2024-03-22 15:21:53 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:21:53 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:21:53 --> Utf8 Class Initialized
INFO - 2024-03-22 15:21:53 --> URI Class Initialized
DEBUG - 2024-03-22 15:21:53 --> No URI present. Default controller set.
INFO - 2024-03-22 15:21:53 --> Router Class Initialized
INFO - 2024-03-22 15:21:53 --> Output Class Initialized
INFO - 2024-03-22 15:21:53 --> Security Class Initialized
DEBUG - 2024-03-22 15:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:21:53 --> Input Class Initialized
INFO - 2024-03-22 15:21:53 --> Language Class Initialized
INFO - 2024-03-22 15:21:53 --> Loader Class Initialized
INFO - 2024-03-22 15:21:53 --> Helper loaded: url_helper
INFO - 2024-03-22 15:21:53 --> Helper loaded: file_helper
INFO - 2024-03-22 15:21:53 --> Helper loaded: html_helper
INFO - 2024-03-22 15:21:53 --> Helper loaded: text_helper
INFO - 2024-03-22 15:21:53 --> Helper loaded: form_helper
INFO - 2024-03-22 15:21:53 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:21:53 --> Helper loaded: security_helper
INFO - 2024-03-22 15:21:53 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:21:53 --> Database Driver Class Initialized
INFO - 2024-03-22 15:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:21:53 --> Parser Class Initialized
INFO - 2024-03-22 15:21:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:21:53 --> Pagination Class Initialized
INFO - 2024-03-22 15:21:53 --> Form Validation Class Initialized
INFO - 2024-03-22 15:21:53 --> Controller Class Initialized
INFO - 2024-03-22 15:21:53 --> Model Class Initialized
DEBUG - 2024-03-22 15:21:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:21:53 --> Model Class Initialized
DEBUG - 2024-03-22 15:21:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:21:53 --> Model Class Initialized
INFO - 2024-03-22 15:21:53 --> Model Class Initialized
INFO - 2024-03-22 15:21:53 --> Model Class Initialized
INFO - 2024-03-22 15:21:53 --> Model Class Initialized
DEBUG - 2024-03-22 15:21:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:21:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:21:53 --> Model Class Initialized
INFO - 2024-03-22 15:21:53 --> Model Class Initialized
INFO - 2024-03-22 15:21:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 15:21:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:21:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:21:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:21:54 --> Model Class Initialized
INFO - 2024-03-22 15:21:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 15:21:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 15:21:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:21:54 --> Final output sent to browser
DEBUG - 2024-03-22 15:21:54 --> Total execution time: 0.4677
ERROR - 2024-03-22 15:21:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:21:54 --> Config Class Initialized
INFO - 2024-03-22 15:21:54 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:21:54 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:21:54 --> Utf8 Class Initialized
INFO - 2024-03-22 15:21:54 --> URI Class Initialized
INFO - 2024-03-22 15:21:54 --> Router Class Initialized
INFO - 2024-03-22 15:21:54 --> Output Class Initialized
INFO - 2024-03-22 15:21:54 --> Security Class Initialized
DEBUG - 2024-03-22 15:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:21:54 --> Input Class Initialized
INFO - 2024-03-22 15:21:54 --> Language Class Initialized
INFO - 2024-03-22 15:21:54 --> Loader Class Initialized
INFO - 2024-03-22 15:21:54 --> Helper loaded: url_helper
INFO - 2024-03-22 15:21:54 --> Helper loaded: file_helper
INFO - 2024-03-22 15:21:54 --> Helper loaded: html_helper
INFO - 2024-03-22 15:21:54 --> Helper loaded: text_helper
INFO - 2024-03-22 15:21:54 --> Helper loaded: form_helper
INFO - 2024-03-22 15:21:54 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:21:54 --> Helper loaded: security_helper
INFO - 2024-03-22 15:21:54 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:21:54 --> Database Driver Class Initialized
INFO - 2024-03-22 15:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:21:54 --> Parser Class Initialized
INFO - 2024-03-22 15:21:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:21:54 --> Pagination Class Initialized
INFO - 2024-03-22 15:21:54 --> Form Validation Class Initialized
INFO - 2024-03-22 15:21:54 --> Controller Class Initialized
DEBUG - 2024-03-22 15:21:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:21:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:21:54 --> Model Class Initialized
INFO - 2024-03-22 15:21:54 --> Final output sent to browser
DEBUG - 2024-03-22 15:21:54 --> Total execution time: 0.0135
ERROR - 2024-03-22 15:22:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:22:02 --> Config Class Initialized
INFO - 2024-03-22 15:22:02 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:22:02 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:22:02 --> Utf8 Class Initialized
INFO - 2024-03-22 15:22:02 --> URI Class Initialized
INFO - 2024-03-22 15:22:02 --> Router Class Initialized
INFO - 2024-03-22 15:22:02 --> Output Class Initialized
INFO - 2024-03-22 15:22:02 --> Security Class Initialized
DEBUG - 2024-03-22 15:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:22:02 --> Input Class Initialized
INFO - 2024-03-22 15:22:02 --> Language Class Initialized
INFO - 2024-03-22 15:22:02 --> Loader Class Initialized
INFO - 2024-03-22 15:22:02 --> Helper loaded: url_helper
INFO - 2024-03-22 15:22:02 --> Helper loaded: file_helper
INFO - 2024-03-22 15:22:02 --> Helper loaded: html_helper
INFO - 2024-03-22 15:22:02 --> Helper loaded: text_helper
INFO - 2024-03-22 15:22:02 --> Helper loaded: form_helper
INFO - 2024-03-22 15:22:02 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:22:02 --> Helper loaded: security_helper
INFO - 2024-03-22 15:22:02 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:22:02 --> Database Driver Class Initialized
INFO - 2024-03-22 15:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:22:02 --> Parser Class Initialized
INFO - 2024-03-22 15:22:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:22:02 --> Pagination Class Initialized
INFO - 2024-03-22 15:22:02 --> Form Validation Class Initialized
INFO - 2024-03-22 15:22:02 --> Controller Class Initialized
DEBUG - 2024-03-22 15:22:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:22:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:02 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:02 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:02 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:02 --> Model Class Initialized
INFO - 2024-03-22 15:22:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-03-22 15:22:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:22:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:22:03 --> Model Class Initialized
INFO - 2024-03-22 15:22:03 --> Model Class Initialized
INFO - 2024-03-22 15:22:03 --> Model Class Initialized
INFO - 2024-03-22 15:22:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 15:22:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 15:22:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:22:03 --> Final output sent to browser
DEBUG - 2024-03-22 15:22:03 --> Total execution time: 0.2420
ERROR - 2024-03-22 15:22:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:22:03 --> Config Class Initialized
INFO - 2024-03-22 15:22:03 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:22:03 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:22:03 --> Utf8 Class Initialized
INFO - 2024-03-22 15:22:03 --> URI Class Initialized
INFO - 2024-03-22 15:22:03 --> Router Class Initialized
INFO - 2024-03-22 15:22:03 --> Output Class Initialized
INFO - 2024-03-22 15:22:03 --> Security Class Initialized
DEBUG - 2024-03-22 15:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:22:03 --> Input Class Initialized
INFO - 2024-03-22 15:22:03 --> Language Class Initialized
INFO - 2024-03-22 15:22:03 --> Loader Class Initialized
INFO - 2024-03-22 15:22:03 --> Helper loaded: url_helper
INFO - 2024-03-22 15:22:03 --> Helper loaded: file_helper
INFO - 2024-03-22 15:22:03 --> Helper loaded: html_helper
INFO - 2024-03-22 15:22:03 --> Helper loaded: text_helper
INFO - 2024-03-22 15:22:03 --> Helper loaded: form_helper
INFO - 2024-03-22 15:22:03 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:22:03 --> Helper loaded: security_helper
INFO - 2024-03-22 15:22:03 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:22:03 --> Database Driver Class Initialized
INFO - 2024-03-22 15:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:22:03 --> Parser Class Initialized
INFO - 2024-03-22 15:22:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:22:03 --> Pagination Class Initialized
INFO - 2024-03-22 15:22:03 --> Form Validation Class Initialized
INFO - 2024-03-22 15:22:03 --> Controller Class Initialized
DEBUG - 2024-03-22 15:22:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:22:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:03 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:03 --> Model Class Initialized
INFO - 2024-03-22 15:22:03 --> Final output sent to browser
DEBUG - 2024-03-22 15:22:03 --> Total execution time: 0.0327
ERROR - 2024-03-22 15:22:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:22:08 --> Config Class Initialized
INFO - 2024-03-22 15:22:08 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:22:08 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:22:08 --> Utf8 Class Initialized
INFO - 2024-03-22 15:22:08 --> URI Class Initialized
INFO - 2024-03-22 15:22:08 --> Router Class Initialized
INFO - 2024-03-22 15:22:08 --> Output Class Initialized
INFO - 2024-03-22 15:22:08 --> Security Class Initialized
DEBUG - 2024-03-22 15:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:22:08 --> Input Class Initialized
INFO - 2024-03-22 15:22:08 --> Language Class Initialized
INFO - 2024-03-22 15:22:08 --> Loader Class Initialized
INFO - 2024-03-22 15:22:08 --> Helper loaded: url_helper
INFO - 2024-03-22 15:22:08 --> Helper loaded: file_helper
INFO - 2024-03-22 15:22:08 --> Helper loaded: html_helper
INFO - 2024-03-22 15:22:08 --> Helper loaded: text_helper
INFO - 2024-03-22 15:22:08 --> Helper loaded: form_helper
INFO - 2024-03-22 15:22:08 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:22:08 --> Helper loaded: security_helper
INFO - 2024-03-22 15:22:08 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:22:08 --> Database Driver Class Initialized
INFO - 2024-03-22 15:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:22:08 --> Parser Class Initialized
INFO - 2024-03-22 15:22:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:22:08 --> Pagination Class Initialized
INFO - 2024-03-22 15:22:08 --> Form Validation Class Initialized
INFO - 2024-03-22 15:22:08 --> Controller Class Initialized
DEBUG - 2024-03-22 15:22:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:22:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:08 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:08 --> Model Class Initialized
INFO - 2024-03-22 15:22:08 --> Final output sent to browser
DEBUG - 2024-03-22 15:22:08 --> Total execution time: 0.0382
ERROR - 2024-03-22 15:22:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:22:08 --> Config Class Initialized
INFO - 2024-03-22 15:22:08 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:22:08 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:22:08 --> Utf8 Class Initialized
INFO - 2024-03-22 15:22:08 --> URI Class Initialized
INFO - 2024-03-22 15:22:08 --> Router Class Initialized
INFO - 2024-03-22 15:22:08 --> Output Class Initialized
INFO - 2024-03-22 15:22:08 --> Security Class Initialized
DEBUG - 2024-03-22 15:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:22:08 --> Input Class Initialized
INFO - 2024-03-22 15:22:08 --> Language Class Initialized
INFO - 2024-03-22 15:22:08 --> Loader Class Initialized
INFO - 2024-03-22 15:22:08 --> Helper loaded: url_helper
INFO - 2024-03-22 15:22:08 --> Helper loaded: file_helper
INFO - 2024-03-22 15:22:08 --> Helper loaded: html_helper
INFO - 2024-03-22 15:22:08 --> Helper loaded: text_helper
INFO - 2024-03-22 15:22:08 --> Helper loaded: form_helper
INFO - 2024-03-22 15:22:08 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:22:08 --> Helper loaded: security_helper
INFO - 2024-03-22 15:22:08 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:22:08 --> Database Driver Class Initialized
INFO - 2024-03-22 15:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:22:08 --> Parser Class Initialized
INFO - 2024-03-22 15:22:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:22:08 --> Pagination Class Initialized
INFO - 2024-03-22 15:22:08 --> Form Validation Class Initialized
INFO - 2024-03-22 15:22:08 --> Controller Class Initialized
DEBUG - 2024-03-22 15:22:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:22:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:08 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:08 --> Model Class Initialized
INFO - 2024-03-22 15:22:08 --> Final output sent to browser
DEBUG - 2024-03-22 15:22:08 --> Total execution time: 0.0337
ERROR - 2024-03-22 15:22:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:22:09 --> Config Class Initialized
INFO - 2024-03-22 15:22:09 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:22:09 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:22:09 --> Utf8 Class Initialized
INFO - 2024-03-22 15:22:09 --> URI Class Initialized
INFO - 2024-03-22 15:22:09 --> Router Class Initialized
INFO - 2024-03-22 15:22:09 --> Output Class Initialized
INFO - 2024-03-22 15:22:09 --> Security Class Initialized
DEBUG - 2024-03-22 15:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:22:09 --> Input Class Initialized
INFO - 2024-03-22 15:22:09 --> Language Class Initialized
INFO - 2024-03-22 15:22:09 --> Loader Class Initialized
INFO - 2024-03-22 15:22:09 --> Helper loaded: url_helper
INFO - 2024-03-22 15:22:09 --> Helper loaded: file_helper
INFO - 2024-03-22 15:22:09 --> Helper loaded: html_helper
INFO - 2024-03-22 15:22:09 --> Helper loaded: text_helper
INFO - 2024-03-22 15:22:09 --> Helper loaded: form_helper
INFO - 2024-03-22 15:22:09 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:22:09 --> Helper loaded: security_helper
INFO - 2024-03-22 15:22:09 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:22:09 --> Database Driver Class Initialized
INFO - 2024-03-22 15:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:22:09 --> Parser Class Initialized
INFO - 2024-03-22 15:22:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:22:09 --> Pagination Class Initialized
INFO - 2024-03-22 15:22:09 --> Form Validation Class Initialized
INFO - 2024-03-22 15:22:09 --> Controller Class Initialized
DEBUG - 2024-03-22 15:22:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:22:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:09 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:09 --> Model Class Initialized
INFO - 2024-03-22 15:22:09 --> Final output sent to browser
DEBUG - 2024-03-22 15:22:09 --> Total execution time: 0.0330
ERROR - 2024-03-22 15:22:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:22:09 --> Config Class Initialized
INFO - 2024-03-22 15:22:09 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:22:09 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:22:09 --> Utf8 Class Initialized
INFO - 2024-03-22 15:22:09 --> URI Class Initialized
INFO - 2024-03-22 15:22:09 --> Router Class Initialized
INFO - 2024-03-22 15:22:09 --> Output Class Initialized
INFO - 2024-03-22 15:22:09 --> Security Class Initialized
DEBUG - 2024-03-22 15:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:22:09 --> Input Class Initialized
INFO - 2024-03-22 15:22:09 --> Language Class Initialized
INFO - 2024-03-22 15:22:09 --> Loader Class Initialized
INFO - 2024-03-22 15:22:09 --> Helper loaded: url_helper
INFO - 2024-03-22 15:22:09 --> Helper loaded: file_helper
INFO - 2024-03-22 15:22:09 --> Helper loaded: html_helper
INFO - 2024-03-22 15:22:09 --> Helper loaded: text_helper
INFO - 2024-03-22 15:22:09 --> Helper loaded: form_helper
INFO - 2024-03-22 15:22:09 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:22:09 --> Helper loaded: security_helper
INFO - 2024-03-22 15:22:09 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:22:09 --> Database Driver Class Initialized
INFO - 2024-03-22 15:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:22:09 --> Parser Class Initialized
INFO - 2024-03-22 15:22:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:22:09 --> Pagination Class Initialized
INFO - 2024-03-22 15:22:09 --> Form Validation Class Initialized
INFO - 2024-03-22 15:22:09 --> Controller Class Initialized
DEBUG - 2024-03-22 15:22:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:22:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:09 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:09 --> Model Class Initialized
INFO - 2024-03-22 15:22:09 --> Final output sent to browser
DEBUG - 2024-03-22 15:22:09 --> Total execution time: 0.0176
ERROR - 2024-03-22 15:22:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:22:10 --> Config Class Initialized
INFO - 2024-03-22 15:22:10 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:22:10 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:22:10 --> Utf8 Class Initialized
INFO - 2024-03-22 15:22:10 --> URI Class Initialized
INFO - 2024-03-22 15:22:10 --> Router Class Initialized
INFO - 2024-03-22 15:22:10 --> Output Class Initialized
INFO - 2024-03-22 15:22:10 --> Security Class Initialized
DEBUG - 2024-03-22 15:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:22:10 --> Input Class Initialized
INFO - 2024-03-22 15:22:10 --> Language Class Initialized
INFO - 2024-03-22 15:22:10 --> Loader Class Initialized
INFO - 2024-03-22 15:22:10 --> Helper loaded: url_helper
INFO - 2024-03-22 15:22:10 --> Helper loaded: file_helper
INFO - 2024-03-22 15:22:10 --> Helper loaded: html_helper
INFO - 2024-03-22 15:22:10 --> Helper loaded: text_helper
INFO - 2024-03-22 15:22:10 --> Helper loaded: form_helper
INFO - 2024-03-22 15:22:10 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:22:10 --> Helper loaded: security_helper
INFO - 2024-03-22 15:22:10 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:22:10 --> Database Driver Class Initialized
INFO - 2024-03-22 15:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:22:10 --> Parser Class Initialized
INFO - 2024-03-22 15:22:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:22:10 --> Pagination Class Initialized
INFO - 2024-03-22 15:22:10 --> Form Validation Class Initialized
INFO - 2024-03-22 15:22:10 --> Controller Class Initialized
DEBUG - 2024-03-22 15:22:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:22:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:10 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:10 --> Model Class Initialized
INFO - 2024-03-22 15:22:10 --> Final output sent to browser
DEBUG - 2024-03-22 15:22:10 --> Total execution time: 0.0235
ERROR - 2024-03-22 15:22:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:22:10 --> Config Class Initialized
INFO - 2024-03-22 15:22:10 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:22:10 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:22:10 --> Utf8 Class Initialized
INFO - 2024-03-22 15:22:10 --> URI Class Initialized
INFO - 2024-03-22 15:22:10 --> Router Class Initialized
INFO - 2024-03-22 15:22:10 --> Output Class Initialized
INFO - 2024-03-22 15:22:10 --> Security Class Initialized
DEBUG - 2024-03-22 15:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:22:10 --> Input Class Initialized
INFO - 2024-03-22 15:22:10 --> Language Class Initialized
INFO - 2024-03-22 15:22:10 --> Loader Class Initialized
INFO - 2024-03-22 15:22:10 --> Helper loaded: url_helper
INFO - 2024-03-22 15:22:10 --> Helper loaded: file_helper
INFO - 2024-03-22 15:22:10 --> Helper loaded: html_helper
INFO - 2024-03-22 15:22:10 --> Helper loaded: text_helper
INFO - 2024-03-22 15:22:10 --> Helper loaded: form_helper
INFO - 2024-03-22 15:22:10 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:22:10 --> Helper loaded: security_helper
INFO - 2024-03-22 15:22:10 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:22:10 --> Database Driver Class Initialized
INFO - 2024-03-22 15:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:22:10 --> Parser Class Initialized
INFO - 2024-03-22 15:22:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:22:10 --> Pagination Class Initialized
INFO - 2024-03-22 15:22:10 --> Form Validation Class Initialized
INFO - 2024-03-22 15:22:10 --> Controller Class Initialized
DEBUG - 2024-03-22 15:22:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:22:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:10 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:10 --> Model Class Initialized
INFO - 2024-03-22 15:22:10 --> Final output sent to browser
DEBUG - 2024-03-22 15:22:10 --> Total execution time: 0.0212
ERROR - 2024-03-22 15:22:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:22:11 --> Config Class Initialized
INFO - 2024-03-22 15:22:11 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:22:11 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:22:11 --> Utf8 Class Initialized
INFO - 2024-03-22 15:22:11 --> URI Class Initialized
INFO - 2024-03-22 15:22:11 --> Router Class Initialized
INFO - 2024-03-22 15:22:11 --> Output Class Initialized
INFO - 2024-03-22 15:22:11 --> Security Class Initialized
DEBUG - 2024-03-22 15:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:22:11 --> Input Class Initialized
INFO - 2024-03-22 15:22:11 --> Language Class Initialized
INFO - 2024-03-22 15:22:11 --> Loader Class Initialized
INFO - 2024-03-22 15:22:11 --> Helper loaded: url_helper
INFO - 2024-03-22 15:22:11 --> Helper loaded: file_helper
INFO - 2024-03-22 15:22:11 --> Helper loaded: html_helper
INFO - 2024-03-22 15:22:11 --> Helper loaded: text_helper
INFO - 2024-03-22 15:22:11 --> Helper loaded: form_helper
INFO - 2024-03-22 15:22:11 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:22:11 --> Helper loaded: security_helper
INFO - 2024-03-22 15:22:11 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:22:11 --> Database Driver Class Initialized
INFO - 2024-03-22 15:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:22:11 --> Parser Class Initialized
INFO - 2024-03-22 15:22:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:22:11 --> Pagination Class Initialized
INFO - 2024-03-22 15:22:11 --> Form Validation Class Initialized
INFO - 2024-03-22 15:22:11 --> Controller Class Initialized
DEBUG - 2024-03-22 15:22:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:22:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:11 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:11 --> Model Class Initialized
INFO - 2024-03-22 15:22:11 --> Final output sent to browser
DEBUG - 2024-03-22 15:22:11 --> Total execution time: 0.0321
ERROR - 2024-03-22 15:22:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:22:13 --> Config Class Initialized
INFO - 2024-03-22 15:22:13 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:22:13 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:22:13 --> Utf8 Class Initialized
INFO - 2024-03-22 15:22:13 --> URI Class Initialized
INFO - 2024-03-22 15:22:13 --> Router Class Initialized
INFO - 2024-03-22 15:22:13 --> Output Class Initialized
INFO - 2024-03-22 15:22:13 --> Security Class Initialized
DEBUG - 2024-03-22 15:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:22:13 --> Input Class Initialized
INFO - 2024-03-22 15:22:13 --> Language Class Initialized
INFO - 2024-03-22 15:22:13 --> Loader Class Initialized
INFO - 2024-03-22 15:22:13 --> Helper loaded: url_helper
INFO - 2024-03-22 15:22:13 --> Helper loaded: file_helper
INFO - 2024-03-22 15:22:13 --> Helper loaded: html_helper
INFO - 2024-03-22 15:22:13 --> Helper loaded: text_helper
INFO - 2024-03-22 15:22:13 --> Helper loaded: form_helper
INFO - 2024-03-22 15:22:13 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:22:13 --> Helper loaded: security_helper
INFO - 2024-03-22 15:22:13 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:22:13 --> Database Driver Class Initialized
INFO - 2024-03-22 15:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:22:13 --> Parser Class Initialized
INFO - 2024-03-22 15:22:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:22:13 --> Pagination Class Initialized
INFO - 2024-03-22 15:22:13 --> Form Validation Class Initialized
INFO - 2024-03-22 15:22:13 --> Controller Class Initialized
DEBUG - 2024-03-22 15:22:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:22:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:13 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:13 --> Model Class Initialized
INFO - 2024-03-22 15:22:13 --> Final output sent to browser
DEBUG - 2024-03-22 15:22:13 --> Total execution time: 0.0342
ERROR - 2024-03-22 15:22:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:22:14 --> Config Class Initialized
INFO - 2024-03-22 15:22:14 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:22:14 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:22:14 --> Utf8 Class Initialized
INFO - 2024-03-22 15:22:14 --> URI Class Initialized
INFO - 2024-03-22 15:22:14 --> Router Class Initialized
INFO - 2024-03-22 15:22:14 --> Output Class Initialized
INFO - 2024-03-22 15:22:14 --> Security Class Initialized
DEBUG - 2024-03-22 15:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:22:14 --> Input Class Initialized
INFO - 2024-03-22 15:22:14 --> Language Class Initialized
INFO - 2024-03-22 15:22:14 --> Loader Class Initialized
INFO - 2024-03-22 15:22:14 --> Helper loaded: url_helper
INFO - 2024-03-22 15:22:14 --> Helper loaded: file_helper
INFO - 2024-03-22 15:22:14 --> Helper loaded: html_helper
INFO - 2024-03-22 15:22:14 --> Helper loaded: text_helper
INFO - 2024-03-22 15:22:14 --> Helper loaded: form_helper
INFO - 2024-03-22 15:22:14 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:22:14 --> Helper loaded: security_helper
INFO - 2024-03-22 15:22:14 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:22:14 --> Database Driver Class Initialized
INFO - 2024-03-22 15:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:22:14 --> Parser Class Initialized
INFO - 2024-03-22 15:22:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:22:14 --> Pagination Class Initialized
INFO - 2024-03-22 15:22:14 --> Form Validation Class Initialized
INFO - 2024-03-22 15:22:14 --> Controller Class Initialized
DEBUG - 2024-03-22 15:22:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:22:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:14 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:14 --> Model Class Initialized
INFO - 2024-03-22 15:22:14 --> Final output sent to browser
DEBUG - 2024-03-22 15:22:14 --> Total execution time: 0.0436
ERROR - 2024-03-22 15:22:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:22:15 --> Config Class Initialized
INFO - 2024-03-22 15:22:15 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:22:15 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:22:15 --> Utf8 Class Initialized
INFO - 2024-03-22 15:22:15 --> URI Class Initialized
INFO - 2024-03-22 15:22:15 --> Router Class Initialized
INFO - 2024-03-22 15:22:15 --> Output Class Initialized
INFO - 2024-03-22 15:22:15 --> Security Class Initialized
DEBUG - 2024-03-22 15:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:22:15 --> Input Class Initialized
INFO - 2024-03-22 15:22:15 --> Language Class Initialized
INFO - 2024-03-22 15:22:15 --> Loader Class Initialized
INFO - 2024-03-22 15:22:15 --> Helper loaded: url_helper
INFO - 2024-03-22 15:22:15 --> Helper loaded: file_helper
INFO - 2024-03-22 15:22:15 --> Helper loaded: html_helper
INFO - 2024-03-22 15:22:15 --> Helper loaded: text_helper
INFO - 2024-03-22 15:22:15 --> Helper loaded: form_helper
INFO - 2024-03-22 15:22:15 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:22:15 --> Helper loaded: security_helper
INFO - 2024-03-22 15:22:15 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:22:15 --> Database Driver Class Initialized
INFO - 2024-03-22 15:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:22:15 --> Parser Class Initialized
INFO - 2024-03-22 15:22:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:22:15 --> Pagination Class Initialized
INFO - 2024-03-22 15:22:15 --> Form Validation Class Initialized
INFO - 2024-03-22 15:22:15 --> Controller Class Initialized
DEBUG - 2024-03-22 15:22:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:22:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:15 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:15 --> Model Class Initialized
INFO - 2024-03-22 15:22:15 --> Final output sent to browser
DEBUG - 2024-03-22 15:22:15 --> Total execution time: 0.0204
ERROR - 2024-03-22 15:22:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:22:29 --> Config Class Initialized
INFO - 2024-03-22 15:22:29 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:22:29 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:22:29 --> Utf8 Class Initialized
INFO - 2024-03-22 15:22:29 --> URI Class Initialized
INFO - 2024-03-22 15:22:29 --> Router Class Initialized
INFO - 2024-03-22 15:22:29 --> Output Class Initialized
INFO - 2024-03-22 15:22:29 --> Security Class Initialized
DEBUG - 2024-03-22 15:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:22:29 --> Input Class Initialized
INFO - 2024-03-22 15:22:29 --> Language Class Initialized
INFO - 2024-03-22 15:22:29 --> Loader Class Initialized
INFO - 2024-03-22 15:22:29 --> Helper loaded: url_helper
INFO - 2024-03-22 15:22:29 --> Helper loaded: file_helper
INFO - 2024-03-22 15:22:29 --> Helper loaded: html_helper
INFO - 2024-03-22 15:22:29 --> Helper loaded: text_helper
INFO - 2024-03-22 15:22:29 --> Helper loaded: form_helper
INFO - 2024-03-22 15:22:29 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:22:29 --> Helper loaded: security_helper
INFO - 2024-03-22 15:22:29 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:22:29 --> Database Driver Class Initialized
INFO - 2024-03-22 15:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:22:29 --> Parser Class Initialized
INFO - 2024-03-22 15:22:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:22:29 --> Pagination Class Initialized
INFO - 2024-03-22 15:22:29 --> Form Validation Class Initialized
INFO - 2024-03-22 15:22:29 --> Controller Class Initialized
DEBUG - 2024-03-22 15:22:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:22:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:29 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:29 --> Model Class Initialized
ERROR - 2024-03-22 15:22:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:22:30 --> Config Class Initialized
INFO - 2024-03-22 15:22:30 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:22:30 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:22:30 --> Utf8 Class Initialized
INFO - 2024-03-22 15:22:30 --> URI Class Initialized
INFO - 2024-03-22 15:22:30 --> Router Class Initialized
INFO - 2024-03-22 15:22:30 --> Output Class Initialized
INFO - 2024-03-22 15:22:30 --> Security Class Initialized
DEBUG - 2024-03-22 15:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:22:30 --> Input Class Initialized
INFO - 2024-03-22 15:22:30 --> Language Class Initialized
INFO - 2024-03-22 15:22:30 --> Loader Class Initialized
INFO - 2024-03-22 15:22:30 --> Helper loaded: url_helper
INFO - 2024-03-22 15:22:30 --> Helper loaded: file_helper
INFO - 2024-03-22 15:22:30 --> Helper loaded: html_helper
INFO - 2024-03-22 15:22:30 --> Helper loaded: text_helper
INFO - 2024-03-22 15:22:30 --> Helper loaded: form_helper
INFO - 2024-03-22 15:22:30 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:22:30 --> Helper loaded: security_helper
INFO - 2024-03-22 15:22:30 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:22:30 --> Database Driver Class Initialized
INFO - 2024-03-22 15:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:22:30 --> Parser Class Initialized
INFO - 2024-03-22 15:22:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:22:30 --> Pagination Class Initialized
INFO - 2024-03-22 15:22:30 --> Form Validation Class Initialized
INFO - 2024-03-22 15:22:30 --> Controller Class Initialized
DEBUG - 2024-03-22 15:22:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:22:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:30 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:30 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:30 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:30 --> Model Class Initialized
INFO - 2024-03-22 15:22:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-03-22 15:22:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:22:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:22:30 --> Model Class Initialized
INFO - 2024-03-22 15:22:30 --> Model Class Initialized
INFO - 2024-03-22 15:22:30 --> Model Class Initialized
INFO - 2024-03-22 15:22:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 15:22:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 15:22:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:22:30 --> Final output sent to browser
DEBUG - 2024-03-22 15:22:30 --> Total execution time: 0.2685
ERROR - 2024-03-22 15:22:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:22:30 --> Config Class Initialized
INFO - 2024-03-22 15:22:30 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:22:30 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:22:30 --> Utf8 Class Initialized
INFO - 2024-03-22 15:22:30 --> URI Class Initialized
INFO - 2024-03-22 15:22:30 --> Router Class Initialized
INFO - 2024-03-22 15:22:30 --> Output Class Initialized
INFO - 2024-03-22 15:22:30 --> Security Class Initialized
DEBUG - 2024-03-22 15:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:22:30 --> Input Class Initialized
INFO - 2024-03-22 15:22:30 --> Language Class Initialized
INFO - 2024-03-22 15:22:30 --> Loader Class Initialized
INFO - 2024-03-22 15:22:30 --> Helper loaded: url_helper
INFO - 2024-03-22 15:22:30 --> Helper loaded: file_helper
INFO - 2024-03-22 15:22:30 --> Helper loaded: html_helper
INFO - 2024-03-22 15:22:30 --> Helper loaded: text_helper
INFO - 2024-03-22 15:22:30 --> Helper loaded: form_helper
INFO - 2024-03-22 15:22:30 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:22:30 --> Helper loaded: security_helper
INFO - 2024-03-22 15:22:30 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:22:30 --> Database Driver Class Initialized
INFO - 2024-03-22 15:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:22:30 --> Parser Class Initialized
INFO - 2024-03-22 15:22:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:22:30 --> Pagination Class Initialized
INFO - 2024-03-22 15:22:30 --> Form Validation Class Initialized
INFO - 2024-03-22 15:22:30 --> Controller Class Initialized
DEBUG - 2024-03-22 15:22:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:22:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:30 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:30 --> Model Class Initialized
INFO - 2024-03-22 15:22:30 --> Final output sent to browser
DEBUG - 2024-03-22 15:22:30 --> Total execution time: 0.0320
ERROR - 2024-03-22 15:22:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:22:34 --> Config Class Initialized
INFO - 2024-03-22 15:22:34 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:22:34 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:22:34 --> Utf8 Class Initialized
INFO - 2024-03-22 15:22:34 --> URI Class Initialized
INFO - 2024-03-22 15:22:34 --> Router Class Initialized
INFO - 2024-03-22 15:22:34 --> Output Class Initialized
INFO - 2024-03-22 15:22:34 --> Security Class Initialized
DEBUG - 2024-03-22 15:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:22:34 --> Input Class Initialized
INFO - 2024-03-22 15:22:34 --> Language Class Initialized
INFO - 2024-03-22 15:22:34 --> Loader Class Initialized
INFO - 2024-03-22 15:22:34 --> Helper loaded: url_helper
INFO - 2024-03-22 15:22:34 --> Helper loaded: file_helper
INFO - 2024-03-22 15:22:34 --> Helper loaded: html_helper
INFO - 2024-03-22 15:22:34 --> Helper loaded: text_helper
INFO - 2024-03-22 15:22:34 --> Helper loaded: form_helper
INFO - 2024-03-22 15:22:34 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:22:34 --> Helper loaded: security_helper
INFO - 2024-03-22 15:22:34 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:22:34 --> Database Driver Class Initialized
INFO - 2024-03-22 15:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:22:34 --> Parser Class Initialized
INFO - 2024-03-22 15:22:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:22:34 --> Pagination Class Initialized
INFO - 2024-03-22 15:22:34 --> Form Validation Class Initialized
INFO - 2024-03-22 15:22:34 --> Controller Class Initialized
DEBUG - 2024-03-22 15:22:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:34 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:34 --> Model Class Initialized
INFO - 2024-03-22 15:22:34 --> Final output sent to browser
DEBUG - 2024-03-22 15:22:34 --> Total execution time: 0.0314
ERROR - 2024-03-22 15:22:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:22:34 --> Config Class Initialized
INFO - 2024-03-22 15:22:34 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:22:34 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:22:34 --> Utf8 Class Initialized
INFO - 2024-03-22 15:22:34 --> URI Class Initialized
INFO - 2024-03-22 15:22:34 --> Router Class Initialized
INFO - 2024-03-22 15:22:34 --> Output Class Initialized
INFO - 2024-03-22 15:22:34 --> Security Class Initialized
DEBUG - 2024-03-22 15:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:22:34 --> Input Class Initialized
INFO - 2024-03-22 15:22:34 --> Language Class Initialized
INFO - 2024-03-22 15:22:34 --> Loader Class Initialized
INFO - 2024-03-22 15:22:34 --> Helper loaded: url_helper
INFO - 2024-03-22 15:22:34 --> Helper loaded: file_helper
INFO - 2024-03-22 15:22:34 --> Helper loaded: html_helper
INFO - 2024-03-22 15:22:34 --> Helper loaded: text_helper
INFO - 2024-03-22 15:22:34 --> Helper loaded: form_helper
INFO - 2024-03-22 15:22:34 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:22:34 --> Helper loaded: security_helper
INFO - 2024-03-22 15:22:34 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:22:34 --> Database Driver Class Initialized
INFO - 2024-03-22 15:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:22:34 --> Parser Class Initialized
INFO - 2024-03-22 15:22:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:22:34 --> Pagination Class Initialized
INFO - 2024-03-22 15:22:34 --> Form Validation Class Initialized
INFO - 2024-03-22 15:22:34 --> Controller Class Initialized
DEBUG - 2024-03-22 15:22:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:34 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:34 --> Model Class Initialized
INFO - 2024-03-22 15:22:34 --> Final output sent to browser
DEBUG - 2024-03-22 15:22:34 --> Total execution time: 0.0324
ERROR - 2024-03-22 15:22:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:22:35 --> Config Class Initialized
INFO - 2024-03-22 15:22:35 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:22:35 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:22:35 --> Utf8 Class Initialized
INFO - 2024-03-22 15:22:35 --> URI Class Initialized
INFO - 2024-03-22 15:22:35 --> Router Class Initialized
INFO - 2024-03-22 15:22:35 --> Output Class Initialized
INFO - 2024-03-22 15:22:35 --> Security Class Initialized
DEBUG - 2024-03-22 15:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:22:35 --> Input Class Initialized
INFO - 2024-03-22 15:22:35 --> Language Class Initialized
INFO - 2024-03-22 15:22:35 --> Loader Class Initialized
INFO - 2024-03-22 15:22:35 --> Helper loaded: url_helper
INFO - 2024-03-22 15:22:35 --> Helper loaded: file_helper
INFO - 2024-03-22 15:22:35 --> Helper loaded: html_helper
INFO - 2024-03-22 15:22:35 --> Helper loaded: text_helper
INFO - 2024-03-22 15:22:35 --> Helper loaded: form_helper
INFO - 2024-03-22 15:22:35 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:22:35 --> Helper loaded: security_helper
INFO - 2024-03-22 15:22:35 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:22:35 --> Database Driver Class Initialized
INFO - 2024-03-22 15:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:22:35 --> Parser Class Initialized
INFO - 2024-03-22 15:22:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:22:35 --> Pagination Class Initialized
INFO - 2024-03-22 15:22:35 --> Form Validation Class Initialized
INFO - 2024-03-22 15:22:35 --> Controller Class Initialized
DEBUG - 2024-03-22 15:22:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:22:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:35 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:35 --> Model Class Initialized
INFO - 2024-03-22 15:22:35 --> Final output sent to browser
DEBUG - 2024-03-22 15:22:35 --> Total execution time: 0.0327
ERROR - 2024-03-22 15:22:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:22:35 --> Config Class Initialized
INFO - 2024-03-22 15:22:35 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:22:35 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:22:35 --> Utf8 Class Initialized
INFO - 2024-03-22 15:22:35 --> URI Class Initialized
INFO - 2024-03-22 15:22:35 --> Router Class Initialized
INFO - 2024-03-22 15:22:35 --> Output Class Initialized
INFO - 2024-03-22 15:22:35 --> Security Class Initialized
DEBUG - 2024-03-22 15:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:22:35 --> Input Class Initialized
INFO - 2024-03-22 15:22:35 --> Language Class Initialized
INFO - 2024-03-22 15:22:35 --> Loader Class Initialized
INFO - 2024-03-22 15:22:35 --> Helper loaded: url_helper
INFO - 2024-03-22 15:22:35 --> Helper loaded: file_helper
INFO - 2024-03-22 15:22:35 --> Helper loaded: html_helper
INFO - 2024-03-22 15:22:35 --> Helper loaded: text_helper
INFO - 2024-03-22 15:22:35 --> Helper loaded: form_helper
INFO - 2024-03-22 15:22:35 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:22:35 --> Helper loaded: security_helper
INFO - 2024-03-22 15:22:35 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:22:35 --> Database Driver Class Initialized
INFO - 2024-03-22 15:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:22:35 --> Parser Class Initialized
INFO - 2024-03-22 15:22:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:22:35 --> Pagination Class Initialized
INFO - 2024-03-22 15:22:35 --> Form Validation Class Initialized
INFO - 2024-03-22 15:22:35 --> Controller Class Initialized
DEBUG - 2024-03-22 15:22:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:22:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:35 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:35 --> Model Class Initialized
INFO - 2024-03-22 15:22:35 --> Final output sent to browser
DEBUG - 2024-03-22 15:22:35 --> Total execution time: 0.0319
ERROR - 2024-03-22 15:22:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:22:36 --> Config Class Initialized
INFO - 2024-03-22 15:22:36 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:22:36 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:22:36 --> Utf8 Class Initialized
INFO - 2024-03-22 15:22:36 --> URI Class Initialized
INFO - 2024-03-22 15:22:36 --> Router Class Initialized
INFO - 2024-03-22 15:22:36 --> Output Class Initialized
INFO - 2024-03-22 15:22:36 --> Security Class Initialized
DEBUG - 2024-03-22 15:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:22:36 --> Input Class Initialized
INFO - 2024-03-22 15:22:36 --> Language Class Initialized
INFO - 2024-03-22 15:22:36 --> Loader Class Initialized
INFO - 2024-03-22 15:22:36 --> Helper loaded: url_helper
INFO - 2024-03-22 15:22:36 --> Helper loaded: file_helper
INFO - 2024-03-22 15:22:36 --> Helper loaded: html_helper
INFO - 2024-03-22 15:22:36 --> Helper loaded: text_helper
INFO - 2024-03-22 15:22:36 --> Helper loaded: form_helper
INFO - 2024-03-22 15:22:36 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:22:36 --> Helper loaded: security_helper
INFO - 2024-03-22 15:22:36 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:22:36 --> Database Driver Class Initialized
INFO - 2024-03-22 15:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:22:36 --> Parser Class Initialized
INFO - 2024-03-22 15:22:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:22:36 --> Pagination Class Initialized
INFO - 2024-03-22 15:22:36 --> Form Validation Class Initialized
INFO - 2024-03-22 15:22:36 --> Controller Class Initialized
DEBUG - 2024-03-22 15:22:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:36 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:36 --> Model Class Initialized
INFO - 2024-03-22 15:22:36 --> Final output sent to browser
DEBUG - 2024-03-22 15:22:36 --> Total execution time: 0.0210
ERROR - 2024-03-22 15:22:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:22:39 --> Config Class Initialized
INFO - 2024-03-22 15:22:39 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:22:39 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:22:39 --> Utf8 Class Initialized
INFO - 2024-03-22 15:22:39 --> URI Class Initialized
INFO - 2024-03-22 15:22:39 --> Router Class Initialized
INFO - 2024-03-22 15:22:39 --> Output Class Initialized
INFO - 2024-03-22 15:22:39 --> Security Class Initialized
DEBUG - 2024-03-22 15:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:22:39 --> Input Class Initialized
INFO - 2024-03-22 15:22:39 --> Language Class Initialized
INFO - 2024-03-22 15:22:39 --> Loader Class Initialized
INFO - 2024-03-22 15:22:39 --> Helper loaded: url_helper
INFO - 2024-03-22 15:22:39 --> Helper loaded: file_helper
INFO - 2024-03-22 15:22:39 --> Helper loaded: html_helper
INFO - 2024-03-22 15:22:39 --> Helper loaded: text_helper
INFO - 2024-03-22 15:22:39 --> Helper loaded: form_helper
INFO - 2024-03-22 15:22:39 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:22:39 --> Helper loaded: security_helper
INFO - 2024-03-22 15:22:39 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:22:39 --> Database Driver Class Initialized
INFO - 2024-03-22 15:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:22:39 --> Parser Class Initialized
INFO - 2024-03-22 15:22:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:22:39 --> Pagination Class Initialized
INFO - 2024-03-22 15:22:39 --> Form Validation Class Initialized
INFO - 2024-03-22 15:22:39 --> Controller Class Initialized
DEBUG - 2024-03-22 15:22:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:22:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:39 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:39 --> Model Class Initialized
INFO - 2024-03-22 15:22:39 --> Final output sent to browser
DEBUG - 2024-03-22 15:22:39 --> Total execution time: 0.0154
ERROR - 2024-03-22 15:22:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:22:43 --> Config Class Initialized
INFO - 2024-03-22 15:22:43 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:22:43 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:22:43 --> Utf8 Class Initialized
INFO - 2024-03-22 15:22:43 --> URI Class Initialized
INFO - 2024-03-22 15:22:43 --> Router Class Initialized
INFO - 2024-03-22 15:22:43 --> Output Class Initialized
INFO - 2024-03-22 15:22:43 --> Security Class Initialized
DEBUG - 2024-03-22 15:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:22:43 --> Input Class Initialized
INFO - 2024-03-22 15:22:43 --> Language Class Initialized
INFO - 2024-03-22 15:22:43 --> Loader Class Initialized
INFO - 2024-03-22 15:22:43 --> Helper loaded: url_helper
INFO - 2024-03-22 15:22:43 --> Helper loaded: file_helper
INFO - 2024-03-22 15:22:43 --> Helper loaded: html_helper
INFO - 2024-03-22 15:22:43 --> Helper loaded: text_helper
INFO - 2024-03-22 15:22:43 --> Helper loaded: form_helper
INFO - 2024-03-22 15:22:43 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:22:43 --> Helper loaded: security_helper
INFO - 2024-03-22 15:22:43 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:22:43 --> Database Driver Class Initialized
INFO - 2024-03-22 15:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:22:43 --> Parser Class Initialized
INFO - 2024-03-22 15:22:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:22:43 --> Pagination Class Initialized
INFO - 2024-03-22 15:22:43 --> Form Validation Class Initialized
INFO - 2024-03-22 15:22:43 --> Controller Class Initialized
DEBUG - 2024-03-22 15:22:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:22:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:43 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:43 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:43 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:43 --> Model Class Initialized
INFO - 2024-03-22 15:22:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-03-22 15:22:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:22:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:22:43 --> Model Class Initialized
INFO - 2024-03-22 15:22:43 --> Model Class Initialized
INFO - 2024-03-22 15:22:43 --> Model Class Initialized
INFO - 2024-03-22 15:22:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 15:22:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 15:22:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:22:43 --> Final output sent to browser
DEBUG - 2024-03-22 15:22:43 --> Total execution time: 0.2436
ERROR - 2024-03-22 15:22:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:22:43 --> Config Class Initialized
INFO - 2024-03-22 15:22:43 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:22:43 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:22:43 --> Utf8 Class Initialized
INFO - 2024-03-22 15:22:43 --> URI Class Initialized
INFO - 2024-03-22 15:22:43 --> Router Class Initialized
INFO - 2024-03-22 15:22:43 --> Output Class Initialized
INFO - 2024-03-22 15:22:43 --> Security Class Initialized
DEBUG - 2024-03-22 15:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:22:43 --> Input Class Initialized
INFO - 2024-03-22 15:22:43 --> Language Class Initialized
INFO - 2024-03-22 15:22:43 --> Loader Class Initialized
INFO - 2024-03-22 15:22:43 --> Helper loaded: url_helper
INFO - 2024-03-22 15:22:43 --> Helper loaded: file_helper
INFO - 2024-03-22 15:22:43 --> Helper loaded: html_helper
INFO - 2024-03-22 15:22:43 --> Helper loaded: text_helper
INFO - 2024-03-22 15:22:43 --> Helper loaded: form_helper
INFO - 2024-03-22 15:22:43 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:22:43 --> Helper loaded: security_helper
INFO - 2024-03-22 15:22:43 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:22:43 --> Database Driver Class Initialized
INFO - 2024-03-22 15:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:22:43 --> Parser Class Initialized
INFO - 2024-03-22 15:22:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:22:43 --> Pagination Class Initialized
INFO - 2024-03-22 15:22:43 --> Form Validation Class Initialized
INFO - 2024-03-22 15:22:43 --> Controller Class Initialized
DEBUG - 2024-03-22 15:22:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:22:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:43 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:43 --> Model Class Initialized
INFO - 2024-03-22 15:22:43 --> Final output sent to browser
DEBUG - 2024-03-22 15:22:43 --> Total execution time: 0.0320
ERROR - 2024-03-22 15:22:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:22:46 --> Config Class Initialized
INFO - 2024-03-22 15:22:46 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:22:46 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:22:46 --> Utf8 Class Initialized
INFO - 2024-03-22 15:22:46 --> URI Class Initialized
DEBUG - 2024-03-22 15:22:46 --> No URI present. Default controller set.
INFO - 2024-03-22 15:22:46 --> Router Class Initialized
INFO - 2024-03-22 15:22:46 --> Output Class Initialized
INFO - 2024-03-22 15:22:46 --> Security Class Initialized
DEBUG - 2024-03-22 15:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:22:46 --> Input Class Initialized
INFO - 2024-03-22 15:22:46 --> Language Class Initialized
INFO - 2024-03-22 15:22:46 --> Loader Class Initialized
INFO - 2024-03-22 15:22:46 --> Helper loaded: url_helper
INFO - 2024-03-22 15:22:46 --> Helper loaded: file_helper
INFO - 2024-03-22 15:22:46 --> Helper loaded: html_helper
INFO - 2024-03-22 15:22:46 --> Helper loaded: text_helper
INFO - 2024-03-22 15:22:46 --> Helper loaded: form_helper
INFO - 2024-03-22 15:22:46 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:22:46 --> Helper loaded: security_helper
INFO - 2024-03-22 15:22:46 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:22:46 --> Database Driver Class Initialized
INFO - 2024-03-22 15:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:22:46 --> Parser Class Initialized
INFO - 2024-03-22 15:22:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:22:46 --> Pagination Class Initialized
INFO - 2024-03-22 15:22:46 --> Form Validation Class Initialized
INFO - 2024-03-22 15:22:46 --> Controller Class Initialized
INFO - 2024-03-22 15:22:46 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:46 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:46 --> Model Class Initialized
INFO - 2024-03-22 15:22:46 --> Model Class Initialized
INFO - 2024-03-22 15:22:46 --> Model Class Initialized
INFO - 2024-03-22 15:22:46 --> Model Class Initialized
DEBUG - 2024-03-22 15:22:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:22:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:46 --> Model Class Initialized
INFO - 2024-03-22 15:22:46 --> Model Class Initialized
INFO - 2024-03-22 15:22:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 15:22:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:22:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:22:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:22:46 --> Model Class Initialized
INFO - 2024-03-22 15:22:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 15:22:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 15:22:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:22:46 --> Final output sent to browser
DEBUG - 2024-03-22 15:22:46 --> Total execution time: 0.5303
ERROR - 2024-03-22 15:23:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:23:11 --> Config Class Initialized
INFO - 2024-03-22 15:23:11 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:23:11 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:23:11 --> Utf8 Class Initialized
INFO - 2024-03-22 15:23:11 --> URI Class Initialized
INFO - 2024-03-22 15:23:11 --> Router Class Initialized
INFO - 2024-03-22 15:23:11 --> Output Class Initialized
INFO - 2024-03-22 15:23:11 --> Security Class Initialized
DEBUG - 2024-03-22 15:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:23:11 --> Input Class Initialized
INFO - 2024-03-22 15:23:11 --> Language Class Initialized
INFO - 2024-03-22 15:23:11 --> Loader Class Initialized
INFO - 2024-03-22 15:23:11 --> Helper loaded: url_helper
INFO - 2024-03-22 15:23:11 --> Helper loaded: file_helper
INFO - 2024-03-22 15:23:11 --> Helper loaded: html_helper
INFO - 2024-03-22 15:23:11 --> Helper loaded: text_helper
INFO - 2024-03-22 15:23:11 --> Helper loaded: form_helper
INFO - 2024-03-22 15:23:11 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:23:11 --> Helper loaded: security_helper
INFO - 2024-03-22 15:23:11 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:23:11 --> Database Driver Class Initialized
INFO - 2024-03-22 15:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:23:11 --> Parser Class Initialized
INFO - 2024-03-22 15:23:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:23:11 --> Pagination Class Initialized
INFO - 2024-03-22 15:23:11 --> Form Validation Class Initialized
INFO - 2024-03-22 15:23:11 --> Controller Class Initialized
INFO - 2024-03-22 15:23:11 --> Model Class Initialized
DEBUG - 2024-03-22 15:23:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:23:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:23:11 --> Model Class Initialized
DEBUG - 2024-03-22 15:23:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:23:11 --> Model Class Initialized
INFO - 2024-03-22 15:23:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-22 15:23:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:23:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:23:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:23:11 --> Model Class Initialized
INFO - 2024-03-22 15:23:11 --> Model Class Initialized
INFO - 2024-03-22 15:23:11 --> Model Class Initialized
INFO - 2024-03-22 15:23:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 15:23:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 15:23:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:23:11 --> Final output sent to browser
DEBUG - 2024-03-22 15:23:11 --> Total execution time: 0.2567
ERROR - 2024-03-22 15:23:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:23:12 --> Config Class Initialized
INFO - 2024-03-22 15:23:12 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:23:12 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:23:12 --> Utf8 Class Initialized
INFO - 2024-03-22 15:23:12 --> URI Class Initialized
INFO - 2024-03-22 15:23:12 --> Router Class Initialized
INFO - 2024-03-22 15:23:12 --> Output Class Initialized
INFO - 2024-03-22 15:23:12 --> Security Class Initialized
DEBUG - 2024-03-22 15:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:23:12 --> Input Class Initialized
INFO - 2024-03-22 15:23:12 --> Language Class Initialized
INFO - 2024-03-22 15:23:12 --> Loader Class Initialized
INFO - 2024-03-22 15:23:12 --> Helper loaded: url_helper
INFO - 2024-03-22 15:23:12 --> Helper loaded: file_helper
INFO - 2024-03-22 15:23:12 --> Helper loaded: html_helper
INFO - 2024-03-22 15:23:12 --> Helper loaded: text_helper
INFO - 2024-03-22 15:23:12 --> Helper loaded: form_helper
INFO - 2024-03-22 15:23:12 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:23:12 --> Helper loaded: security_helper
INFO - 2024-03-22 15:23:12 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:23:12 --> Database Driver Class Initialized
INFO - 2024-03-22 15:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:23:12 --> Parser Class Initialized
INFO - 2024-03-22 15:23:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:23:12 --> Pagination Class Initialized
INFO - 2024-03-22 15:23:12 --> Form Validation Class Initialized
INFO - 2024-03-22 15:23:12 --> Controller Class Initialized
INFO - 2024-03-22 15:23:12 --> Model Class Initialized
DEBUG - 2024-03-22 15:23:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:23:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:23:12 --> Model Class Initialized
DEBUG - 2024-03-22 15:23:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:23:12 --> Model Class Initialized
INFO - 2024-03-22 15:23:12 --> Final output sent to browser
DEBUG - 2024-03-22 15:23:12 --> Total execution time: 0.0679
ERROR - 2024-03-22 15:23:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:23:15 --> Config Class Initialized
INFO - 2024-03-22 15:23:15 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:23:15 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:23:15 --> Utf8 Class Initialized
INFO - 2024-03-22 15:23:15 --> URI Class Initialized
INFO - 2024-03-22 15:23:15 --> Router Class Initialized
INFO - 2024-03-22 15:23:15 --> Output Class Initialized
INFO - 2024-03-22 15:23:15 --> Security Class Initialized
DEBUG - 2024-03-22 15:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:23:15 --> Input Class Initialized
INFO - 2024-03-22 15:23:15 --> Language Class Initialized
INFO - 2024-03-22 15:23:15 --> Loader Class Initialized
INFO - 2024-03-22 15:23:15 --> Helper loaded: url_helper
INFO - 2024-03-22 15:23:15 --> Helper loaded: file_helper
INFO - 2024-03-22 15:23:15 --> Helper loaded: html_helper
INFO - 2024-03-22 15:23:15 --> Helper loaded: text_helper
INFO - 2024-03-22 15:23:15 --> Helper loaded: form_helper
INFO - 2024-03-22 15:23:15 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:23:15 --> Helper loaded: security_helper
INFO - 2024-03-22 15:23:15 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:23:15 --> Database Driver Class Initialized
INFO - 2024-03-22 15:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:23:15 --> Parser Class Initialized
INFO - 2024-03-22 15:23:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:23:15 --> Pagination Class Initialized
INFO - 2024-03-22 15:23:15 --> Form Validation Class Initialized
INFO - 2024-03-22 15:23:15 --> Controller Class Initialized
INFO - 2024-03-22 15:23:15 --> Model Class Initialized
DEBUG - 2024-03-22 15:23:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:23:15 --> Model Class Initialized
DEBUG - 2024-03-22 15:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:23:15 --> Model Class Initialized
INFO - 2024-03-22 15:23:16 --> Final output sent to browser
DEBUG - 2024-03-22 15:23:16 --> Total execution time: 1.6834
ERROR - 2024-03-22 15:23:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:23:20 --> Config Class Initialized
INFO - 2024-03-22 15:23:20 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:23:20 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:23:20 --> Utf8 Class Initialized
INFO - 2024-03-22 15:23:20 --> URI Class Initialized
DEBUG - 2024-03-22 15:23:20 --> No URI present. Default controller set.
INFO - 2024-03-22 15:23:20 --> Router Class Initialized
INFO - 2024-03-22 15:23:20 --> Output Class Initialized
INFO - 2024-03-22 15:23:20 --> Security Class Initialized
DEBUG - 2024-03-22 15:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:23:20 --> Input Class Initialized
INFO - 2024-03-22 15:23:20 --> Language Class Initialized
INFO - 2024-03-22 15:23:20 --> Loader Class Initialized
INFO - 2024-03-22 15:23:20 --> Helper loaded: url_helper
INFO - 2024-03-22 15:23:20 --> Helper loaded: file_helper
INFO - 2024-03-22 15:23:20 --> Helper loaded: html_helper
INFO - 2024-03-22 15:23:20 --> Helper loaded: text_helper
INFO - 2024-03-22 15:23:20 --> Helper loaded: form_helper
INFO - 2024-03-22 15:23:20 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:23:20 --> Helper loaded: security_helper
INFO - 2024-03-22 15:23:20 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:23:20 --> Database Driver Class Initialized
INFO - 2024-03-22 15:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:23:20 --> Parser Class Initialized
INFO - 2024-03-22 15:23:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:23:20 --> Pagination Class Initialized
INFO - 2024-03-22 15:23:20 --> Form Validation Class Initialized
INFO - 2024-03-22 15:23:20 --> Controller Class Initialized
INFO - 2024-03-22 15:23:20 --> Model Class Initialized
DEBUG - 2024-03-22 15:23:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:23:20 --> Model Class Initialized
DEBUG - 2024-03-22 15:23:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:23:20 --> Model Class Initialized
INFO - 2024-03-22 15:23:20 --> Model Class Initialized
INFO - 2024-03-22 15:23:20 --> Model Class Initialized
INFO - 2024-03-22 15:23:20 --> Model Class Initialized
DEBUG - 2024-03-22 15:23:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:23:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:23:20 --> Model Class Initialized
INFO - 2024-03-22 15:23:20 --> Model Class Initialized
INFO - 2024-03-22 15:23:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 15:23:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:23:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:23:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:23:21 --> Model Class Initialized
INFO - 2024-03-22 15:23:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 15:23:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 15:23:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:23:21 --> Final output sent to browser
DEBUG - 2024-03-22 15:23:21 --> Total execution time: 0.4649
ERROR - 2024-03-22 15:23:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:23:38 --> Config Class Initialized
INFO - 2024-03-22 15:23:38 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:23:38 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:23:38 --> Utf8 Class Initialized
INFO - 2024-03-22 15:23:38 --> URI Class Initialized
INFO - 2024-03-22 15:23:38 --> Router Class Initialized
INFO - 2024-03-22 15:23:38 --> Output Class Initialized
INFO - 2024-03-22 15:23:38 --> Security Class Initialized
DEBUG - 2024-03-22 15:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:23:38 --> Input Class Initialized
INFO - 2024-03-22 15:23:38 --> Language Class Initialized
INFO - 2024-03-22 15:23:38 --> Loader Class Initialized
INFO - 2024-03-22 15:23:38 --> Helper loaded: url_helper
INFO - 2024-03-22 15:23:38 --> Helper loaded: file_helper
INFO - 2024-03-22 15:23:38 --> Helper loaded: html_helper
INFO - 2024-03-22 15:23:38 --> Helper loaded: text_helper
INFO - 2024-03-22 15:23:38 --> Helper loaded: form_helper
INFO - 2024-03-22 15:23:38 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:23:38 --> Helper loaded: security_helper
INFO - 2024-03-22 15:23:38 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:23:38 --> Database Driver Class Initialized
INFO - 2024-03-22 15:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:23:38 --> Parser Class Initialized
INFO - 2024-03-22 15:23:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:23:38 --> Pagination Class Initialized
INFO - 2024-03-22 15:23:38 --> Form Validation Class Initialized
INFO - 2024-03-22 15:23:38 --> Controller Class Initialized
DEBUG - 2024-03-22 15:23:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:23:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:23:38 --> Model Class Initialized
DEBUG - 2024-03-22 15:23:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:23:38 --> Model Class Initialized
DEBUG - 2024-03-22 15:23:38 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:23:38 --> Model Class Initialized
INFO - 2024-03-22 15:23:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-03-22 15:23:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:23:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:23:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:23:38 --> Model Class Initialized
INFO - 2024-03-22 15:23:38 --> Model Class Initialized
INFO - 2024-03-22 15:23:38 --> Model Class Initialized
INFO - 2024-03-22 15:23:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 15:23:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 15:23:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:23:38 --> Final output sent to browser
DEBUG - 2024-03-22 15:23:38 --> Total execution time: 0.2457
ERROR - 2024-03-22 15:23:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:23:39 --> Config Class Initialized
INFO - 2024-03-22 15:23:39 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:23:39 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:23:39 --> Utf8 Class Initialized
INFO - 2024-03-22 15:23:39 --> URI Class Initialized
INFO - 2024-03-22 15:23:39 --> Router Class Initialized
INFO - 2024-03-22 15:23:39 --> Output Class Initialized
INFO - 2024-03-22 15:23:39 --> Security Class Initialized
DEBUG - 2024-03-22 15:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:23:39 --> Input Class Initialized
INFO - 2024-03-22 15:23:39 --> Language Class Initialized
INFO - 2024-03-22 15:23:39 --> Loader Class Initialized
INFO - 2024-03-22 15:23:39 --> Helper loaded: url_helper
INFO - 2024-03-22 15:23:39 --> Helper loaded: file_helper
INFO - 2024-03-22 15:23:39 --> Helper loaded: html_helper
INFO - 2024-03-22 15:23:39 --> Helper loaded: text_helper
INFO - 2024-03-22 15:23:39 --> Helper loaded: form_helper
INFO - 2024-03-22 15:23:39 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:23:39 --> Helper loaded: security_helper
INFO - 2024-03-22 15:23:39 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:23:39 --> Database Driver Class Initialized
INFO - 2024-03-22 15:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:23:39 --> Parser Class Initialized
INFO - 2024-03-22 15:23:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:23:39 --> Pagination Class Initialized
INFO - 2024-03-22 15:23:39 --> Form Validation Class Initialized
INFO - 2024-03-22 15:23:39 --> Controller Class Initialized
DEBUG - 2024-03-22 15:23:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:23:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:23:39 --> Model Class Initialized
DEBUG - 2024-03-22 15:23:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:23:39 --> Model Class Initialized
INFO - 2024-03-22 15:23:39 --> Final output sent to browser
DEBUG - 2024-03-22 15:23:39 --> Total execution time: 0.0321
ERROR - 2024-03-22 15:23:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:23:42 --> Config Class Initialized
INFO - 2024-03-22 15:23:42 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:23:42 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:23:42 --> Utf8 Class Initialized
INFO - 2024-03-22 15:23:42 --> URI Class Initialized
INFO - 2024-03-22 15:23:42 --> Router Class Initialized
INFO - 2024-03-22 15:23:42 --> Output Class Initialized
INFO - 2024-03-22 15:23:42 --> Security Class Initialized
DEBUG - 2024-03-22 15:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:23:42 --> Input Class Initialized
INFO - 2024-03-22 15:23:42 --> Language Class Initialized
INFO - 2024-03-22 15:23:42 --> Loader Class Initialized
INFO - 2024-03-22 15:23:42 --> Helper loaded: url_helper
INFO - 2024-03-22 15:23:42 --> Helper loaded: file_helper
INFO - 2024-03-22 15:23:42 --> Helper loaded: html_helper
INFO - 2024-03-22 15:23:42 --> Helper loaded: text_helper
INFO - 2024-03-22 15:23:42 --> Helper loaded: form_helper
INFO - 2024-03-22 15:23:42 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:23:42 --> Helper loaded: security_helper
INFO - 2024-03-22 15:23:42 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:23:42 --> Database Driver Class Initialized
INFO - 2024-03-22 15:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:23:42 --> Parser Class Initialized
INFO - 2024-03-22 15:23:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:23:42 --> Pagination Class Initialized
INFO - 2024-03-22 15:23:42 --> Form Validation Class Initialized
INFO - 2024-03-22 15:23:42 --> Controller Class Initialized
DEBUG - 2024-03-22 15:23:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:23:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:23:42 --> Model Class Initialized
DEBUG - 2024-03-22 15:23:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:23:42 --> Model Class Initialized
INFO - 2024-03-22 15:23:42 --> Final output sent to browser
DEBUG - 2024-03-22 15:23:42 --> Total execution time: 0.3245
ERROR - 2024-03-22 15:23:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:23:48 --> Config Class Initialized
INFO - 2024-03-22 15:23:48 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:23:48 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:23:48 --> Utf8 Class Initialized
INFO - 2024-03-22 15:23:48 --> URI Class Initialized
DEBUG - 2024-03-22 15:23:48 --> No URI present. Default controller set.
INFO - 2024-03-22 15:23:48 --> Router Class Initialized
INFO - 2024-03-22 15:23:48 --> Output Class Initialized
INFO - 2024-03-22 15:23:48 --> Security Class Initialized
DEBUG - 2024-03-22 15:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:23:48 --> Input Class Initialized
INFO - 2024-03-22 15:23:48 --> Language Class Initialized
INFO - 2024-03-22 15:23:48 --> Loader Class Initialized
INFO - 2024-03-22 15:23:48 --> Helper loaded: url_helper
INFO - 2024-03-22 15:23:48 --> Helper loaded: file_helper
INFO - 2024-03-22 15:23:48 --> Helper loaded: html_helper
INFO - 2024-03-22 15:23:48 --> Helper loaded: text_helper
INFO - 2024-03-22 15:23:48 --> Helper loaded: form_helper
INFO - 2024-03-22 15:23:48 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:23:48 --> Helper loaded: security_helper
INFO - 2024-03-22 15:23:48 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:23:48 --> Database Driver Class Initialized
INFO - 2024-03-22 15:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:23:48 --> Parser Class Initialized
INFO - 2024-03-22 15:23:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:23:48 --> Pagination Class Initialized
INFO - 2024-03-22 15:23:48 --> Form Validation Class Initialized
INFO - 2024-03-22 15:23:48 --> Controller Class Initialized
INFO - 2024-03-22 15:23:48 --> Model Class Initialized
DEBUG - 2024-03-22 15:23:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:23:48 --> Model Class Initialized
DEBUG - 2024-03-22 15:23:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:23:48 --> Model Class Initialized
INFO - 2024-03-22 15:23:48 --> Model Class Initialized
INFO - 2024-03-22 15:23:48 --> Model Class Initialized
INFO - 2024-03-22 15:23:48 --> Model Class Initialized
DEBUG - 2024-03-22 15:23:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:23:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:23:48 --> Model Class Initialized
INFO - 2024-03-22 15:23:48 --> Model Class Initialized
INFO - 2024-03-22 15:23:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 15:23:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:23:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:23:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:23:49 --> Model Class Initialized
INFO - 2024-03-22 15:23:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 15:23:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 15:23:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:23:49 --> Final output sent to browser
DEBUG - 2024-03-22 15:23:49 --> Total execution time: 0.4798
ERROR - 2024-03-22 15:24:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:24:16 --> Config Class Initialized
INFO - 2024-03-22 15:24:16 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:24:16 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:24:16 --> Utf8 Class Initialized
INFO - 2024-03-22 15:24:16 --> URI Class Initialized
INFO - 2024-03-22 15:24:16 --> Router Class Initialized
INFO - 2024-03-22 15:24:16 --> Output Class Initialized
INFO - 2024-03-22 15:24:16 --> Security Class Initialized
DEBUG - 2024-03-22 15:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:24:16 --> Input Class Initialized
INFO - 2024-03-22 15:24:16 --> Language Class Initialized
INFO - 2024-03-22 15:24:16 --> Loader Class Initialized
INFO - 2024-03-22 15:24:16 --> Helper loaded: url_helper
INFO - 2024-03-22 15:24:16 --> Helper loaded: file_helper
INFO - 2024-03-22 15:24:16 --> Helper loaded: html_helper
INFO - 2024-03-22 15:24:16 --> Helper loaded: text_helper
INFO - 2024-03-22 15:24:16 --> Helper loaded: form_helper
INFO - 2024-03-22 15:24:16 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:24:16 --> Helper loaded: security_helper
INFO - 2024-03-22 15:24:16 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:24:16 --> Database Driver Class Initialized
INFO - 2024-03-22 15:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:24:16 --> Parser Class Initialized
INFO - 2024-03-22 15:24:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:24:16 --> Pagination Class Initialized
INFO - 2024-03-22 15:24:16 --> Form Validation Class Initialized
INFO - 2024-03-22 15:24:16 --> Controller Class Initialized
INFO - 2024-03-22 15:24:16 --> Model Class Initialized
DEBUG - 2024-03-22 15:24:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:24:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:24:16 --> Model Class Initialized
DEBUG - 2024-03-22 15:24:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:24:16 --> Model Class Initialized
INFO - 2024-03-22 15:24:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-22 15:24:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:24:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:24:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:24:16 --> Model Class Initialized
INFO - 2024-03-22 15:24:16 --> Model Class Initialized
INFO - 2024-03-22 15:24:16 --> Model Class Initialized
INFO - 2024-03-22 15:24:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 15:24:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 15:24:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:24:16 --> Final output sent to browser
DEBUG - 2024-03-22 15:24:16 --> Total execution time: 0.2653
ERROR - 2024-03-22 15:24:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:24:16 --> Config Class Initialized
INFO - 2024-03-22 15:24:16 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:24:16 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:24:16 --> Utf8 Class Initialized
INFO - 2024-03-22 15:24:16 --> URI Class Initialized
INFO - 2024-03-22 15:24:16 --> Router Class Initialized
INFO - 2024-03-22 15:24:16 --> Output Class Initialized
INFO - 2024-03-22 15:24:16 --> Security Class Initialized
DEBUG - 2024-03-22 15:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:24:16 --> Input Class Initialized
INFO - 2024-03-22 15:24:16 --> Language Class Initialized
INFO - 2024-03-22 15:24:16 --> Loader Class Initialized
INFO - 2024-03-22 15:24:16 --> Helper loaded: url_helper
INFO - 2024-03-22 15:24:16 --> Helper loaded: file_helper
INFO - 2024-03-22 15:24:16 --> Helper loaded: html_helper
INFO - 2024-03-22 15:24:16 --> Helper loaded: text_helper
INFO - 2024-03-22 15:24:16 --> Helper loaded: form_helper
INFO - 2024-03-22 15:24:16 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:24:16 --> Helper loaded: security_helper
INFO - 2024-03-22 15:24:16 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:24:16 --> Database Driver Class Initialized
INFO - 2024-03-22 15:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:24:16 --> Parser Class Initialized
INFO - 2024-03-22 15:24:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:24:16 --> Pagination Class Initialized
INFO - 2024-03-22 15:24:16 --> Form Validation Class Initialized
INFO - 2024-03-22 15:24:16 --> Controller Class Initialized
INFO - 2024-03-22 15:24:16 --> Model Class Initialized
DEBUG - 2024-03-22 15:24:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:24:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:24:16 --> Model Class Initialized
DEBUG - 2024-03-22 15:24:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:24:16 --> Model Class Initialized
INFO - 2024-03-22 15:24:16 --> Final output sent to browser
DEBUG - 2024-03-22 15:24:16 --> Total execution time: 0.0737
ERROR - 2024-03-22 15:24:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:24:19 --> Config Class Initialized
INFO - 2024-03-22 15:24:19 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:24:19 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:24:19 --> Utf8 Class Initialized
INFO - 2024-03-22 15:24:19 --> URI Class Initialized
INFO - 2024-03-22 15:24:19 --> Router Class Initialized
INFO - 2024-03-22 15:24:19 --> Output Class Initialized
INFO - 2024-03-22 15:24:19 --> Security Class Initialized
DEBUG - 2024-03-22 15:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:24:19 --> Input Class Initialized
INFO - 2024-03-22 15:24:19 --> Language Class Initialized
INFO - 2024-03-22 15:24:19 --> Loader Class Initialized
INFO - 2024-03-22 15:24:19 --> Helper loaded: url_helper
INFO - 2024-03-22 15:24:19 --> Helper loaded: file_helper
INFO - 2024-03-22 15:24:19 --> Helper loaded: html_helper
INFO - 2024-03-22 15:24:19 --> Helper loaded: text_helper
INFO - 2024-03-22 15:24:19 --> Helper loaded: form_helper
INFO - 2024-03-22 15:24:19 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:24:19 --> Helper loaded: security_helper
INFO - 2024-03-22 15:24:19 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:24:19 --> Database Driver Class Initialized
INFO - 2024-03-22 15:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:24:19 --> Parser Class Initialized
INFO - 2024-03-22 15:24:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:24:19 --> Pagination Class Initialized
INFO - 2024-03-22 15:24:19 --> Form Validation Class Initialized
INFO - 2024-03-22 15:24:19 --> Controller Class Initialized
INFO - 2024-03-22 15:24:19 --> Model Class Initialized
DEBUG - 2024-03-22 15:24:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:24:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:24:19 --> Model Class Initialized
DEBUG - 2024-03-22 15:24:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:24:19 --> Model Class Initialized
INFO - 2024-03-22 15:24:21 --> Final output sent to browser
DEBUG - 2024-03-22 15:24:21 --> Total execution time: 1.6766
ERROR - 2024-03-22 15:24:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:24:25 --> Config Class Initialized
INFO - 2024-03-22 15:24:25 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:24:25 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:24:25 --> Utf8 Class Initialized
INFO - 2024-03-22 15:24:25 --> URI Class Initialized
DEBUG - 2024-03-22 15:24:25 --> No URI present. Default controller set.
INFO - 2024-03-22 15:24:25 --> Router Class Initialized
INFO - 2024-03-22 15:24:25 --> Output Class Initialized
INFO - 2024-03-22 15:24:25 --> Security Class Initialized
DEBUG - 2024-03-22 15:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:24:25 --> Input Class Initialized
INFO - 2024-03-22 15:24:25 --> Language Class Initialized
INFO - 2024-03-22 15:24:25 --> Loader Class Initialized
INFO - 2024-03-22 15:24:25 --> Helper loaded: url_helper
INFO - 2024-03-22 15:24:25 --> Helper loaded: file_helper
INFO - 2024-03-22 15:24:25 --> Helper loaded: html_helper
INFO - 2024-03-22 15:24:25 --> Helper loaded: text_helper
INFO - 2024-03-22 15:24:25 --> Helper loaded: form_helper
INFO - 2024-03-22 15:24:25 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:24:25 --> Helper loaded: security_helper
INFO - 2024-03-22 15:24:25 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:24:25 --> Database Driver Class Initialized
INFO - 2024-03-22 15:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:24:25 --> Parser Class Initialized
INFO - 2024-03-22 15:24:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:24:25 --> Pagination Class Initialized
INFO - 2024-03-22 15:24:25 --> Form Validation Class Initialized
INFO - 2024-03-22 15:24:25 --> Controller Class Initialized
INFO - 2024-03-22 15:24:25 --> Model Class Initialized
DEBUG - 2024-03-22 15:24:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:24:25 --> Model Class Initialized
DEBUG - 2024-03-22 15:24:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:24:25 --> Model Class Initialized
INFO - 2024-03-22 15:24:25 --> Model Class Initialized
INFO - 2024-03-22 15:24:25 --> Model Class Initialized
INFO - 2024-03-22 15:24:25 --> Model Class Initialized
DEBUG - 2024-03-22 15:24:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:24:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:24:25 --> Model Class Initialized
INFO - 2024-03-22 15:24:25 --> Model Class Initialized
INFO - 2024-03-22 15:24:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 15:24:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:24:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:24:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:24:25 --> Model Class Initialized
INFO - 2024-03-22 15:24:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 15:24:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 15:24:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:24:25 --> Final output sent to browser
DEBUG - 2024-03-22 15:24:25 --> Total execution time: 0.4515
ERROR - 2024-03-22 15:24:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:24:37 --> Config Class Initialized
INFO - 2024-03-22 15:24:37 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:24:37 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:24:37 --> Utf8 Class Initialized
INFO - 2024-03-22 15:24:37 --> URI Class Initialized
INFO - 2024-03-22 15:24:37 --> Router Class Initialized
INFO - 2024-03-22 15:24:37 --> Output Class Initialized
INFO - 2024-03-22 15:24:37 --> Security Class Initialized
DEBUG - 2024-03-22 15:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:24:37 --> Input Class Initialized
INFO - 2024-03-22 15:24:37 --> Language Class Initialized
INFO - 2024-03-22 15:24:37 --> Loader Class Initialized
INFO - 2024-03-22 15:24:37 --> Helper loaded: url_helper
INFO - 2024-03-22 15:24:37 --> Helper loaded: file_helper
INFO - 2024-03-22 15:24:37 --> Helper loaded: html_helper
INFO - 2024-03-22 15:24:37 --> Helper loaded: text_helper
INFO - 2024-03-22 15:24:37 --> Helper loaded: form_helper
INFO - 2024-03-22 15:24:37 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:24:37 --> Helper loaded: security_helper
INFO - 2024-03-22 15:24:37 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:24:37 --> Database Driver Class Initialized
INFO - 2024-03-22 15:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:24:37 --> Parser Class Initialized
INFO - 2024-03-22 15:24:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:24:37 --> Pagination Class Initialized
INFO - 2024-03-22 15:24:37 --> Form Validation Class Initialized
INFO - 2024-03-22 15:24:37 --> Controller Class Initialized
INFO - 2024-03-22 15:24:37 --> Model Class Initialized
DEBUG - 2024-03-22 15:24:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:24:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:24:37 --> Model Class Initialized
DEBUG - 2024-03-22 15:24:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:24:37 --> Model Class Initialized
INFO - 2024-03-22 15:24:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-22 15:24:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:24:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:24:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:24:37 --> Model Class Initialized
INFO - 2024-03-22 15:24:37 --> Model Class Initialized
INFO - 2024-03-22 15:24:37 --> Model Class Initialized
INFO - 2024-03-22 15:24:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 15:24:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 15:24:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:24:37 --> Final output sent to browser
DEBUG - 2024-03-22 15:24:37 --> Total execution time: 0.2425
ERROR - 2024-03-22 15:24:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:24:37 --> Config Class Initialized
INFO - 2024-03-22 15:24:37 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:24:37 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:24:37 --> Utf8 Class Initialized
INFO - 2024-03-22 15:24:37 --> URI Class Initialized
INFO - 2024-03-22 15:24:37 --> Router Class Initialized
INFO - 2024-03-22 15:24:37 --> Output Class Initialized
INFO - 2024-03-22 15:24:37 --> Security Class Initialized
DEBUG - 2024-03-22 15:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:24:37 --> Input Class Initialized
INFO - 2024-03-22 15:24:37 --> Language Class Initialized
INFO - 2024-03-22 15:24:37 --> Loader Class Initialized
INFO - 2024-03-22 15:24:37 --> Helper loaded: url_helper
INFO - 2024-03-22 15:24:37 --> Helper loaded: file_helper
INFO - 2024-03-22 15:24:37 --> Helper loaded: html_helper
INFO - 2024-03-22 15:24:37 --> Helper loaded: text_helper
INFO - 2024-03-22 15:24:37 --> Helper loaded: form_helper
INFO - 2024-03-22 15:24:37 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:24:37 --> Helper loaded: security_helper
INFO - 2024-03-22 15:24:37 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:24:37 --> Database Driver Class Initialized
INFO - 2024-03-22 15:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:24:37 --> Parser Class Initialized
INFO - 2024-03-22 15:24:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:24:37 --> Pagination Class Initialized
INFO - 2024-03-22 15:24:37 --> Form Validation Class Initialized
INFO - 2024-03-22 15:24:37 --> Controller Class Initialized
INFO - 2024-03-22 15:24:37 --> Model Class Initialized
DEBUG - 2024-03-22 15:24:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:24:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:24:37 --> Model Class Initialized
DEBUG - 2024-03-22 15:24:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:24:37 --> Model Class Initialized
INFO - 2024-03-22 15:24:37 --> Final output sent to browser
DEBUG - 2024-03-22 15:24:37 --> Total execution time: 0.0811
ERROR - 2024-03-22 15:24:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:24:40 --> Config Class Initialized
INFO - 2024-03-22 15:24:40 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:24:40 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:24:40 --> Utf8 Class Initialized
INFO - 2024-03-22 15:24:40 --> URI Class Initialized
INFO - 2024-03-22 15:24:40 --> Router Class Initialized
INFO - 2024-03-22 15:24:40 --> Output Class Initialized
INFO - 2024-03-22 15:24:40 --> Security Class Initialized
DEBUG - 2024-03-22 15:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:24:40 --> Input Class Initialized
INFO - 2024-03-22 15:24:40 --> Language Class Initialized
INFO - 2024-03-22 15:24:40 --> Loader Class Initialized
INFO - 2024-03-22 15:24:40 --> Helper loaded: url_helper
INFO - 2024-03-22 15:24:40 --> Helper loaded: file_helper
INFO - 2024-03-22 15:24:40 --> Helper loaded: html_helper
INFO - 2024-03-22 15:24:40 --> Helper loaded: text_helper
INFO - 2024-03-22 15:24:40 --> Helper loaded: form_helper
INFO - 2024-03-22 15:24:40 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:24:40 --> Helper loaded: security_helper
INFO - 2024-03-22 15:24:40 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:24:40 --> Database Driver Class Initialized
INFO - 2024-03-22 15:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:24:40 --> Parser Class Initialized
INFO - 2024-03-22 15:24:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:24:40 --> Pagination Class Initialized
INFO - 2024-03-22 15:24:40 --> Form Validation Class Initialized
INFO - 2024-03-22 15:24:40 --> Controller Class Initialized
INFO - 2024-03-22 15:24:40 --> Model Class Initialized
DEBUG - 2024-03-22 15:24:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:24:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:24:40 --> Model Class Initialized
DEBUG - 2024-03-22 15:24:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:24:40 --> Model Class Initialized
INFO - 2024-03-22 15:24:42 --> Final output sent to browser
DEBUG - 2024-03-22 15:24:42 --> Total execution time: 1.6215
ERROR - 2024-03-22 15:24:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:24:55 --> Config Class Initialized
INFO - 2024-03-22 15:24:55 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:24:55 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:24:55 --> Utf8 Class Initialized
INFO - 2024-03-22 15:24:55 --> URI Class Initialized
INFO - 2024-03-22 15:24:55 --> Router Class Initialized
INFO - 2024-03-22 15:24:55 --> Output Class Initialized
INFO - 2024-03-22 15:24:55 --> Security Class Initialized
DEBUG - 2024-03-22 15:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:24:55 --> Input Class Initialized
INFO - 2024-03-22 15:24:55 --> Language Class Initialized
INFO - 2024-03-22 15:24:55 --> Loader Class Initialized
INFO - 2024-03-22 15:24:55 --> Helper loaded: url_helper
INFO - 2024-03-22 15:24:55 --> Helper loaded: file_helper
INFO - 2024-03-22 15:24:55 --> Helper loaded: html_helper
INFO - 2024-03-22 15:24:55 --> Helper loaded: text_helper
INFO - 2024-03-22 15:24:55 --> Helper loaded: form_helper
INFO - 2024-03-22 15:24:55 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:24:55 --> Helper loaded: security_helper
INFO - 2024-03-22 15:24:55 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:24:55 --> Database Driver Class Initialized
INFO - 2024-03-22 15:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:24:55 --> Parser Class Initialized
INFO - 2024-03-22 15:24:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:24:55 --> Pagination Class Initialized
INFO - 2024-03-22 15:24:55 --> Form Validation Class Initialized
INFO - 2024-03-22 15:24:55 --> Controller Class Initialized
INFO - 2024-03-22 15:24:55 --> Model Class Initialized
DEBUG - 2024-03-22 15:24:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:24:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:24:55 --> Model Class Initialized
DEBUG - 2024-03-22 15:24:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:24:55 --> Model Class Initialized
DEBUG - 2024-03-22 15:24:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:24:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-03-22 15:24:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:24:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:24:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:24:55 --> Model Class Initialized
INFO - 2024-03-22 15:24:55 --> Model Class Initialized
INFO - 2024-03-22 15:24:55 --> Model Class Initialized
INFO - 2024-03-22 15:24:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 15:24:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 15:24:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:24:55 --> Final output sent to browser
DEBUG - 2024-03-22 15:24:55 --> Total execution time: 0.2590
ERROR - 2024-03-22 15:25:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:25:02 --> Config Class Initialized
INFO - 2024-03-22 15:25:02 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:25:02 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:25:02 --> Utf8 Class Initialized
INFO - 2024-03-22 15:25:02 --> URI Class Initialized
DEBUG - 2024-03-22 15:25:02 --> No URI present. Default controller set.
INFO - 2024-03-22 15:25:02 --> Router Class Initialized
INFO - 2024-03-22 15:25:02 --> Output Class Initialized
INFO - 2024-03-22 15:25:02 --> Security Class Initialized
DEBUG - 2024-03-22 15:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:25:02 --> Input Class Initialized
INFO - 2024-03-22 15:25:02 --> Language Class Initialized
INFO - 2024-03-22 15:25:02 --> Loader Class Initialized
INFO - 2024-03-22 15:25:02 --> Helper loaded: url_helper
INFO - 2024-03-22 15:25:02 --> Helper loaded: file_helper
INFO - 2024-03-22 15:25:02 --> Helper loaded: html_helper
INFO - 2024-03-22 15:25:02 --> Helper loaded: text_helper
INFO - 2024-03-22 15:25:02 --> Helper loaded: form_helper
INFO - 2024-03-22 15:25:02 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:25:02 --> Helper loaded: security_helper
INFO - 2024-03-22 15:25:02 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:25:02 --> Database Driver Class Initialized
INFO - 2024-03-22 15:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:25:02 --> Parser Class Initialized
INFO - 2024-03-22 15:25:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:25:02 --> Pagination Class Initialized
INFO - 2024-03-22 15:25:02 --> Form Validation Class Initialized
INFO - 2024-03-22 15:25:02 --> Controller Class Initialized
INFO - 2024-03-22 15:25:02 --> Model Class Initialized
DEBUG - 2024-03-22 15:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:25:02 --> Model Class Initialized
DEBUG - 2024-03-22 15:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:25:02 --> Model Class Initialized
INFO - 2024-03-22 15:25:02 --> Model Class Initialized
INFO - 2024-03-22 15:25:02 --> Model Class Initialized
INFO - 2024-03-22 15:25:02 --> Model Class Initialized
DEBUG - 2024-03-22 15:25:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:25:02 --> Model Class Initialized
INFO - 2024-03-22 15:25:02 --> Model Class Initialized
INFO - 2024-03-22 15:25:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 15:25:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:25:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:25:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:25:02 --> Model Class Initialized
INFO - 2024-03-22 15:25:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 15:25:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 15:25:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:25:03 --> Final output sent to browser
DEBUG - 2024-03-22 15:25:03 --> Total execution time: 0.5682
ERROR - 2024-03-22 15:25:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:25:15 --> Config Class Initialized
INFO - 2024-03-22 15:25:15 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:25:15 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:25:15 --> Utf8 Class Initialized
INFO - 2024-03-22 15:25:15 --> URI Class Initialized
INFO - 2024-03-22 15:25:15 --> Router Class Initialized
INFO - 2024-03-22 15:25:15 --> Output Class Initialized
INFO - 2024-03-22 15:25:15 --> Security Class Initialized
DEBUG - 2024-03-22 15:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:25:15 --> Input Class Initialized
INFO - 2024-03-22 15:25:15 --> Language Class Initialized
INFO - 2024-03-22 15:25:15 --> Loader Class Initialized
INFO - 2024-03-22 15:25:15 --> Helper loaded: url_helper
INFO - 2024-03-22 15:25:15 --> Helper loaded: file_helper
INFO - 2024-03-22 15:25:15 --> Helper loaded: html_helper
INFO - 2024-03-22 15:25:15 --> Helper loaded: text_helper
INFO - 2024-03-22 15:25:15 --> Helper loaded: form_helper
INFO - 2024-03-22 15:25:15 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:25:15 --> Helper loaded: security_helper
INFO - 2024-03-22 15:25:15 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:25:15 --> Database Driver Class Initialized
INFO - 2024-03-22 15:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:25:15 --> Parser Class Initialized
INFO - 2024-03-22 15:25:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:25:15 --> Pagination Class Initialized
INFO - 2024-03-22 15:25:15 --> Form Validation Class Initialized
INFO - 2024-03-22 15:25:15 --> Controller Class Initialized
INFO - 2024-03-22 15:25:15 --> Model Class Initialized
DEBUG - 2024-03-22 15:25:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:25:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:25:15 --> Model Class Initialized
DEBUG - 2024-03-22 15:25:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:25:15 --> Model Class Initialized
INFO - 2024-03-22 15:25:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-22 15:25:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:25:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:25:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:25:15 --> Model Class Initialized
INFO - 2024-03-22 15:25:15 --> Model Class Initialized
INFO - 2024-03-22 15:25:15 --> Model Class Initialized
INFO - 2024-03-22 15:25:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 15:25:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 15:25:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:25:15 --> Final output sent to browser
DEBUG - 2024-03-22 15:25:15 --> Total execution time: 0.2463
ERROR - 2024-03-22 15:25:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:25:16 --> Config Class Initialized
INFO - 2024-03-22 15:25:16 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:25:16 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:25:16 --> Utf8 Class Initialized
INFO - 2024-03-22 15:25:16 --> URI Class Initialized
INFO - 2024-03-22 15:25:16 --> Router Class Initialized
INFO - 2024-03-22 15:25:16 --> Output Class Initialized
INFO - 2024-03-22 15:25:16 --> Security Class Initialized
DEBUG - 2024-03-22 15:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:25:16 --> Input Class Initialized
INFO - 2024-03-22 15:25:16 --> Language Class Initialized
INFO - 2024-03-22 15:25:16 --> Loader Class Initialized
INFO - 2024-03-22 15:25:16 --> Helper loaded: url_helper
INFO - 2024-03-22 15:25:16 --> Helper loaded: file_helper
INFO - 2024-03-22 15:25:16 --> Helper loaded: html_helper
INFO - 2024-03-22 15:25:16 --> Helper loaded: text_helper
INFO - 2024-03-22 15:25:16 --> Helper loaded: form_helper
INFO - 2024-03-22 15:25:16 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:25:16 --> Helper loaded: security_helper
INFO - 2024-03-22 15:25:16 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:25:16 --> Database Driver Class Initialized
INFO - 2024-03-22 15:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:25:16 --> Parser Class Initialized
INFO - 2024-03-22 15:25:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:25:16 --> Pagination Class Initialized
INFO - 2024-03-22 15:25:16 --> Form Validation Class Initialized
INFO - 2024-03-22 15:25:16 --> Controller Class Initialized
INFO - 2024-03-22 15:25:16 --> Model Class Initialized
DEBUG - 2024-03-22 15:25:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:25:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:25:16 --> Model Class Initialized
DEBUG - 2024-03-22 15:25:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:25:16 --> Model Class Initialized
INFO - 2024-03-22 15:25:16 --> Final output sent to browser
DEBUG - 2024-03-22 15:25:16 --> Total execution time: 0.0727
ERROR - 2024-03-22 15:25:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:25:19 --> Config Class Initialized
INFO - 2024-03-22 15:25:19 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:25:19 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:25:19 --> Utf8 Class Initialized
INFO - 2024-03-22 15:25:19 --> URI Class Initialized
INFO - 2024-03-22 15:25:19 --> Router Class Initialized
INFO - 2024-03-22 15:25:19 --> Output Class Initialized
INFO - 2024-03-22 15:25:19 --> Security Class Initialized
DEBUG - 2024-03-22 15:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:25:19 --> Input Class Initialized
INFO - 2024-03-22 15:25:19 --> Language Class Initialized
INFO - 2024-03-22 15:25:19 --> Loader Class Initialized
INFO - 2024-03-22 15:25:19 --> Helper loaded: url_helper
INFO - 2024-03-22 15:25:19 --> Helper loaded: file_helper
INFO - 2024-03-22 15:25:19 --> Helper loaded: html_helper
INFO - 2024-03-22 15:25:19 --> Helper loaded: text_helper
INFO - 2024-03-22 15:25:19 --> Helper loaded: form_helper
INFO - 2024-03-22 15:25:19 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:25:19 --> Helper loaded: security_helper
INFO - 2024-03-22 15:25:19 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:25:19 --> Database Driver Class Initialized
INFO - 2024-03-22 15:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:25:19 --> Parser Class Initialized
INFO - 2024-03-22 15:25:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:25:19 --> Pagination Class Initialized
INFO - 2024-03-22 15:25:19 --> Form Validation Class Initialized
INFO - 2024-03-22 15:25:19 --> Controller Class Initialized
INFO - 2024-03-22 15:25:19 --> Model Class Initialized
DEBUG - 2024-03-22 15:25:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:25:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:25:19 --> Model Class Initialized
DEBUG - 2024-03-22 15:25:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:25:19 --> Model Class Initialized
INFO - 2024-03-22 15:25:20 --> Final output sent to browser
DEBUG - 2024-03-22 15:25:20 --> Total execution time: 1.6370
ERROR - 2024-03-22 15:25:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:25:26 --> Config Class Initialized
INFO - 2024-03-22 15:25:26 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:25:26 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:25:26 --> Utf8 Class Initialized
INFO - 2024-03-22 15:25:26 --> URI Class Initialized
DEBUG - 2024-03-22 15:25:26 --> No URI present. Default controller set.
INFO - 2024-03-22 15:25:26 --> Router Class Initialized
INFO - 2024-03-22 15:25:26 --> Output Class Initialized
INFO - 2024-03-22 15:25:26 --> Security Class Initialized
DEBUG - 2024-03-22 15:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:25:26 --> Input Class Initialized
INFO - 2024-03-22 15:25:26 --> Language Class Initialized
INFO - 2024-03-22 15:25:26 --> Loader Class Initialized
INFO - 2024-03-22 15:25:26 --> Helper loaded: url_helper
INFO - 2024-03-22 15:25:26 --> Helper loaded: file_helper
INFO - 2024-03-22 15:25:26 --> Helper loaded: html_helper
INFO - 2024-03-22 15:25:26 --> Helper loaded: text_helper
INFO - 2024-03-22 15:25:26 --> Helper loaded: form_helper
INFO - 2024-03-22 15:25:26 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:25:26 --> Helper loaded: security_helper
INFO - 2024-03-22 15:25:26 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:25:26 --> Database Driver Class Initialized
INFO - 2024-03-22 15:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:25:26 --> Parser Class Initialized
INFO - 2024-03-22 15:25:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:25:26 --> Pagination Class Initialized
INFO - 2024-03-22 15:25:26 --> Form Validation Class Initialized
INFO - 2024-03-22 15:25:26 --> Controller Class Initialized
INFO - 2024-03-22 15:25:26 --> Model Class Initialized
DEBUG - 2024-03-22 15:25:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:25:26 --> Model Class Initialized
DEBUG - 2024-03-22 15:25:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:25:26 --> Model Class Initialized
INFO - 2024-03-22 15:25:26 --> Model Class Initialized
INFO - 2024-03-22 15:25:26 --> Model Class Initialized
INFO - 2024-03-22 15:25:26 --> Model Class Initialized
DEBUG - 2024-03-22 15:25:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:25:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:25:26 --> Model Class Initialized
INFO - 2024-03-22 15:25:26 --> Model Class Initialized
INFO - 2024-03-22 15:25:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 15:25:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:25:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:25:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:25:26 --> Model Class Initialized
INFO - 2024-03-22 15:25:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 15:25:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 15:25:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:25:26 --> Final output sent to browser
DEBUG - 2024-03-22 15:25:26 --> Total execution time: 0.4615
ERROR - 2024-03-22 15:28:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:28:03 --> Config Class Initialized
INFO - 2024-03-22 15:28:03 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:28:03 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:28:03 --> Utf8 Class Initialized
INFO - 2024-03-22 15:28:03 --> URI Class Initialized
DEBUG - 2024-03-22 15:28:03 --> No URI present. Default controller set.
INFO - 2024-03-22 15:28:03 --> Router Class Initialized
INFO - 2024-03-22 15:28:03 --> Output Class Initialized
INFO - 2024-03-22 15:28:03 --> Security Class Initialized
DEBUG - 2024-03-22 15:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:28:03 --> Input Class Initialized
INFO - 2024-03-22 15:28:03 --> Language Class Initialized
INFO - 2024-03-22 15:28:03 --> Loader Class Initialized
INFO - 2024-03-22 15:28:03 --> Helper loaded: url_helper
INFO - 2024-03-22 15:28:03 --> Helper loaded: file_helper
INFO - 2024-03-22 15:28:03 --> Helper loaded: html_helper
INFO - 2024-03-22 15:28:03 --> Helper loaded: text_helper
INFO - 2024-03-22 15:28:03 --> Helper loaded: form_helper
INFO - 2024-03-22 15:28:03 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:28:03 --> Helper loaded: security_helper
INFO - 2024-03-22 15:28:03 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:28:03 --> Database Driver Class Initialized
INFO - 2024-03-22 15:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:28:03 --> Parser Class Initialized
INFO - 2024-03-22 15:28:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:28:03 --> Pagination Class Initialized
INFO - 2024-03-22 15:28:03 --> Form Validation Class Initialized
INFO - 2024-03-22 15:28:03 --> Controller Class Initialized
INFO - 2024-03-22 15:28:03 --> Model Class Initialized
DEBUG - 2024-03-22 15:28:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:28:03 --> Model Class Initialized
DEBUG - 2024-03-22 15:28:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:28:03 --> Model Class Initialized
INFO - 2024-03-22 15:28:03 --> Model Class Initialized
INFO - 2024-03-22 15:28:03 --> Model Class Initialized
INFO - 2024-03-22 15:28:03 --> Model Class Initialized
DEBUG - 2024-03-22 15:28:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:28:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:28:03 --> Model Class Initialized
INFO - 2024-03-22 15:28:03 --> Model Class Initialized
INFO - 2024-03-22 15:28:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 15:28:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:28:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:28:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:28:04 --> Model Class Initialized
INFO - 2024-03-22 15:28:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 15:28:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 15:28:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:28:04 --> Final output sent to browser
DEBUG - 2024-03-22 15:28:04 --> Total execution time: 0.4738
ERROR - 2024-03-22 15:28:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:28:10 --> Config Class Initialized
INFO - 2024-03-22 15:28:10 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:28:10 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:28:10 --> Utf8 Class Initialized
INFO - 2024-03-22 15:28:10 --> URI Class Initialized
INFO - 2024-03-22 15:28:10 --> Router Class Initialized
INFO - 2024-03-22 15:28:10 --> Output Class Initialized
INFO - 2024-03-22 15:28:10 --> Security Class Initialized
DEBUG - 2024-03-22 15:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:28:10 --> Input Class Initialized
INFO - 2024-03-22 15:28:10 --> Language Class Initialized
INFO - 2024-03-22 15:28:10 --> Loader Class Initialized
INFO - 2024-03-22 15:28:10 --> Helper loaded: url_helper
INFO - 2024-03-22 15:28:10 --> Helper loaded: file_helper
INFO - 2024-03-22 15:28:10 --> Helper loaded: html_helper
INFO - 2024-03-22 15:28:10 --> Helper loaded: text_helper
INFO - 2024-03-22 15:28:10 --> Helper loaded: form_helper
INFO - 2024-03-22 15:28:10 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:28:10 --> Helper loaded: security_helper
INFO - 2024-03-22 15:28:10 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:28:10 --> Database Driver Class Initialized
INFO - 2024-03-22 15:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:28:10 --> Parser Class Initialized
INFO - 2024-03-22 15:28:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:28:10 --> Pagination Class Initialized
INFO - 2024-03-22 15:28:10 --> Form Validation Class Initialized
INFO - 2024-03-22 15:28:10 --> Controller Class Initialized
INFO - 2024-03-22 15:28:10 --> Model Class Initialized
DEBUG - 2024-03-22 15:28:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:28:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:28:10 --> Model Class Initialized
DEBUG - 2024-03-22 15:28:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:28:10 --> Model Class Initialized
INFO - 2024-03-22 15:28:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-22 15:28:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:28:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:28:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:28:10 --> Model Class Initialized
INFO - 2024-03-22 15:28:10 --> Model Class Initialized
INFO - 2024-03-22 15:28:10 --> Model Class Initialized
INFO - 2024-03-22 15:28:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 15:28:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 15:28:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:28:10 --> Final output sent to browser
DEBUG - 2024-03-22 15:28:10 --> Total execution time: 0.2654
ERROR - 2024-03-22 15:28:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:28:10 --> Config Class Initialized
INFO - 2024-03-22 15:28:10 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:28:10 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:28:10 --> Utf8 Class Initialized
INFO - 2024-03-22 15:28:10 --> URI Class Initialized
INFO - 2024-03-22 15:28:10 --> Router Class Initialized
INFO - 2024-03-22 15:28:10 --> Output Class Initialized
INFO - 2024-03-22 15:28:10 --> Security Class Initialized
DEBUG - 2024-03-22 15:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:28:10 --> Input Class Initialized
INFO - 2024-03-22 15:28:10 --> Language Class Initialized
INFO - 2024-03-22 15:28:10 --> Loader Class Initialized
INFO - 2024-03-22 15:28:10 --> Helper loaded: url_helper
INFO - 2024-03-22 15:28:10 --> Helper loaded: file_helper
INFO - 2024-03-22 15:28:10 --> Helper loaded: html_helper
INFO - 2024-03-22 15:28:10 --> Helper loaded: text_helper
INFO - 2024-03-22 15:28:10 --> Helper loaded: form_helper
INFO - 2024-03-22 15:28:10 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:28:10 --> Helper loaded: security_helper
INFO - 2024-03-22 15:28:10 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:28:10 --> Database Driver Class Initialized
INFO - 2024-03-22 15:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:28:10 --> Parser Class Initialized
INFO - 2024-03-22 15:28:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:28:10 --> Pagination Class Initialized
INFO - 2024-03-22 15:28:10 --> Form Validation Class Initialized
INFO - 2024-03-22 15:28:10 --> Controller Class Initialized
INFO - 2024-03-22 15:28:10 --> Model Class Initialized
DEBUG - 2024-03-22 15:28:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:28:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:28:10 --> Model Class Initialized
DEBUG - 2024-03-22 15:28:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:28:10 --> Model Class Initialized
INFO - 2024-03-22 15:28:10 --> Final output sent to browser
DEBUG - 2024-03-22 15:28:10 --> Total execution time: 0.0710
ERROR - 2024-03-22 15:28:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:28:14 --> Config Class Initialized
INFO - 2024-03-22 15:28:14 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:28:14 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:28:14 --> Utf8 Class Initialized
INFO - 2024-03-22 15:28:14 --> URI Class Initialized
INFO - 2024-03-22 15:28:14 --> Router Class Initialized
INFO - 2024-03-22 15:28:14 --> Output Class Initialized
INFO - 2024-03-22 15:28:14 --> Security Class Initialized
DEBUG - 2024-03-22 15:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:28:14 --> Input Class Initialized
INFO - 2024-03-22 15:28:14 --> Language Class Initialized
INFO - 2024-03-22 15:28:14 --> Loader Class Initialized
INFO - 2024-03-22 15:28:14 --> Helper loaded: url_helper
INFO - 2024-03-22 15:28:14 --> Helper loaded: file_helper
INFO - 2024-03-22 15:28:14 --> Helper loaded: html_helper
INFO - 2024-03-22 15:28:14 --> Helper loaded: text_helper
INFO - 2024-03-22 15:28:14 --> Helper loaded: form_helper
INFO - 2024-03-22 15:28:14 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:28:14 --> Helper loaded: security_helper
INFO - 2024-03-22 15:28:14 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:28:14 --> Database Driver Class Initialized
INFO - 2024-03-22 15:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:28:14 --> Parser Class Initialized
INFO - 2024-03-22 15:28:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:28:14 --> Pagination Class Initialized
INFO - 2024-03-22 15:28:14 --> Form Validation Class Initialized
INFO - 2024-03-22 15:28:14 --> Controller Class Initialized
INFO - 2024-03-22 15:28:14 --> Model Class Initialized
DEBUG - 2024-03-22 15:28:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:28:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:28:14 --> Model Class Initialized
DEBUG - 2024-03-22 15:28:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:28:14 --> Model Class Initialized
INFO - 2024-03-22 15:28:15 --> Final output sent to browser
DEBUG - 2024-03-22 15:28:15 --> Total execution time: 1.6039
ERROR - 2024-03-22 15:28:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:28:37 --> Config Class Initialized
INFO - 2024-03-22 15:28:37 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:28:37 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:28:37 --> Utf8 Class Initialized
INFO - 2024-03-22 15:28:37 --> URI Class Initialized
INFO - 2024-03-22 15:28:37 --> Router Class Initialized
INFO - 2024-03-22 15:28:37 --> Output Class Initialized
INFO - 2024-03-22 15:28:37 --> Security Class Initialized
DEBUG - 2024-03-22 15:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:28:37 --> Input Class Initialized
INFO - 2024-03-22 15:28:37 --> Language Class Initialized
INFO - 2024-03-22 15:28:37 --> Loader Class Initialized
INFO - 2024-03-22 15:28:37 --> Helper loaded: url_helper
INFO - 2024-03-22 15:28:37 --> Helper loaded: file_helper
INFO - 2024-03-22 15:28:37 --> Helper loaded: html_helper
INFO - 2024-03-22 15:28:37 --> Helper loaded: text_helper
INFO - 2024-03-22 15:28:37 --> Helper loaded: form_helper
INFO - 2024-03-22 15:28:37 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:28:37 --> Helper loaded: security_helper
INFO - 2024-03-22 15:28:37 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:28:37 --> Database Driver Class Initialized
INFO - 2024-03-22 15:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:28:37 --> Parser Class Initialized
INFO - 2024-03-22 15:28:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:28:37 --> Pagination Class Initialized
INFO - 2024-03-22 15:28:37 --> Form Validation Class Initialized
INFO - 2024-03-22 15:28:37 --> Controller Class Initialized
INFO - 2024-03-22 15:28:37 --> Model Class Initialized
DEBUG - 2024-03-22 15:28:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:28:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:28:37 --> Model Class Initialized
DEBUG - 2024-03-22 15:28:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:28:37 --> Model Class Initialized
INFO - 2024-03-22 15:28:37 --> Final output sent to browser
DEBUG - 2024-03-22 15:28:37 --> Total execution time: 0.1925
ERROR - 2024-03-22 15:29:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:29:34 --> Config Class Initialized
INFO - 2024-03-22 15:29:34 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:29:34 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:29:34 --> Utf8 Class Initialized
INFO - 2024-03-22 15:29:34 --> URI Class Initialized
INFO - 2024-03-22 15:29:34 --> Router Class Initialized
INFO - 2024-03-22 15:29:34 --> Output Class Initialized
INFO - 2024-03-22 15:29:34 --> Security Class Initialized
DEBUG - 2024-03-22 15:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:29:34 --> Input Class Initialized
INFO - 2024-03-22 15:29:34 --> Language Class Initialized
INFO - 2024-03-22 15:29:34 --> Loader Class Initialized
INFO - 2024-03-22 15:29:34 --> Helper loaded: url_helper
INFO - 2024-03-22 15:29:34 --> Helper loaded: file_helper
INFO - 2024-03-22 15:29:34 --> Helper loaded: html_helper
INFO - 2024-03-22 15:29:34 --> Helper loaded: text_helper
INFO - 2024-03-22 15:29:34 --> Helper loaded: form_helper
INFO - 2024-03-22 15:29:34 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:29:34 --> Helper loaded: security_helper
INFO - 2024-03-22 15:29:34 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:29:34 --> Database Driver Class Initialized
INFO - 2024-03-22 15:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:29:34 --> Parser Class Initialized
INFO - 2024-03-22 15:29:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:29:34 --> Pagination Class Initialized
INFO - 2024-03-22 15:29:34 --> Form Validation Class Initialized
INFO - 2024-03-22 15:29:34 --> Controller Class Initialized
INFO - 2024-03-22 15:29:34 --> Model Class Initialized
DEBUG - 2024-03-22 15:29:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:29:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:29:34 --> Model Class Initialized
DEBUG - 2024-03-22 15:29:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:29:34 --> Model Class Initialized
INFO - 2024-03-22 15:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-22 15:29:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 15:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 15:29:34 --> Model Class Initialized
INFO - 2024-03-22 15:29:34 --> Model Class Initialized
INFO - 2024-03-22 15:29:34 --> Model Class Initialized
INFO - 2024-03-22 15:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 15:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 15:29:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 15:29:34 --> Final output sent to browser
DEBUG - 2024-03-22 15:29:34 --> Total execution time: 0.2418
ERROR - 2024-03-22 15:29:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:29:34 --> Config Class Initialized
INFO - 2024-03-22 15:29:34 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:29:34 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:29:34 --> Utf8 Class Initialized
INFO - 2024-03-22 15:29:34 --> URI Class Initialized
INFO - 2024-03-22 15:29:34 --> Router Class Initialized
INFO - 2024-03-22 15:29:34 --> Output Class Initialized
INFO - 2024-03-22 15:29:34 --> Security Class Initialized
DEBUG - 2024-03-22 15:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:29:34 --> Input Class Initialized
INFO - 2024-03-22 15:29:34 --> Language Class Initialized
INFO - 2024-03-22 15:29:34 --> Loader Class Initialized
INFO - 2024-03-22 15:29:34 --> Helper loaded: url_helper
INFO - 2024-03-22 15:29:34 --> Helper loaded: file_helper
INFO - 2024-03-22 15:29:34 --> Helper loaded: html_helper
INFO - 2024-03-22 15:29:34 --> Helper loaded: text_helper
INFO - 2024-03-22 15:29:34 --> Helper loaded: form_helper
INFO - 2024-03-22 15:29:34 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:29:34 --> Helper loaded: security_helper
INFO - 2024-03-22 15:29:34 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:29:34 --> Database Driver Class Initialized
INFO - 2024-03-22 15:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:29:34 --> Parser Class Initialized
INFO - 2024-03-22 15:29:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:29:34 --> Pagination Class Initialized
INFO - 2024-03-22 15:29:34 --> Form Validation Class Initialized
INFO - 2024-03-22 15:29:34 --> Controller Class Initialized
INFO - 2024-03-22 15:29:34 --> Model Class Initialized
DEBUG - 2024-03-22 15:29:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:29:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:29:34 --> Model Class Initialized
DEBUG - 2024-03-22 15:29:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:29:34 --> Model Class Initialized
INFO - 2024-03-22 15:29:34 --> Final output sent to browser
DEBUG - 2024-03-22 15:29:34 --> Total execution time: 0.0620
ERROR - 2024-03-22 15:29:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:29:48 --> Config Class Initialized
INFO - 2024-03-22 15:29:48 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:29:48 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:29:48 --> Utf8 Class Initialized
INFO - 2024-03-22 15:29:48 --> URI Class Initialized
INFO - 2024-03-22 15:29:48 --> Router Class Initialized
INFO - 2024-03-22 15:29:48 --> Output Class Initialized
INFO - 2024-03-22 15:29:48 --> Security Class Initialized
DEBUG - 2024-03-22 15:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:29:48 --> Input Class Initialized
INFO - 2024-03-22 15:29:48 --> Language Class Initialized
INFO - 2024-03-22 15:29:48 --> Loader Class Initialized
INFO - 2024-03-22 15:29:48 --> Helper loaded: url_helper
INFO - 2024-03-22 15:29:48 --> Helper loaded: file_helper
INFO - 2024-03-22 15:29:48 --> Helper loaded: html_helper
INFO - 2024-03-22 15:29:48 --> Helper loaded: text_helper
INFO - 2024-03-22 15:29:48 --> Helper loaded: form_helper
INFO - 2024-03-22 15:29:48 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:29:48 --> Helper loaded: security_helper
INFO - 2024-03-22 15:29:48 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:29:48 --> Database Driver Class Initialized
INFO - 2024-03-22 15:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:29:48 --> Parser Class Initialized
INFO - 2024-03-22 15:29:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:29:48 --> Pagination Class Initialized
INFO - 2024-03-22 15:29:48 --> Form Validation Class Initialized
INFO - 2024-03-22 15:29:48 --> Controller Class Initialized
INFO - 2024-03-22 15:29:48 --> Model Class Initialized
DEBUG - 2024-03-22 15:29:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 15:29:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:29:48 --> Model Class Initialized
DEBUG - 2024-03-22 15:29:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 15:29:48 --> Model Class Initialized
INFO - 2024-03-22 15:29:50 --> Final output sent to browser
DEBUG - 2024-03-22 15:29:50 --> Total execution time: 1.7492
ERROR - 2024-03-22 15:47:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 15:47:32 --> Config Class Initialized
INFO - 2024-03-22 15:47:32 --> Hooks Class Initialized
DEBUG - 2024-03-22 15:47:32 --> UTF-8 Support Enabled
INFO - 2024-03-22 15:47:32 --> Utf8 Class Initialized
INFO - 2024-03-22 15:47:32 --> URI Class Initialized
DEBUG - 2024-03-22 15:47:32 --> No URI present. Default controller set.
INFO - 2024-03-22 15:47:32 --> Router Class Initialized
INFO - 2024-03-22 15:47:32 --> Output Class Initialized
INFO - 2024-03-22 15:47:32 --> Security Class Initialized
DEBUG - 2024-03-22 15:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 15:47:32 --> Input Class Initialized
INFO - 2024-03-22 15:47:32 --> Language Class Initialized
INFO - 2024-03-22 15:47:32 --> Loader Class Initialized
INFO - 2024-03-22 15:47:32 --> Helper loaded: url_helper
INFO - 2024-03-22 15:47:32 --> Helper loaded: file_helper
INFO - 2024-03-22 15:47:32 --> Helper loaded: html_helper
INFO - 2024-03-22 15:47:32 --> Helper loaded: text_helper
INFO - 2024-03-22 15:47:32 --> Helper loaded: form_helper
INFO - 2024-03-22 15:47:32 --> Helper loaded: lang_helper
INFO - 2024-03-22 15:47:32 --> Helper loaded: security_helper
INFO - 2024-03-22 15:47:32 --> Helper loaded: cookie_helper
INFO - 2024-03-22 15:47:32 --> Database Driver Class Initialized
INFO - 2024-03-22 15:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 15:47:32 --> Parser Class Initialized
INFO - 2024-03-22 15:47:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 15:47:32 --> Pagination Class Initialized
INFO - 2024-03-22 15:47:32 --> Form Validation Class Initialized
INFO - 2024-03-22 15:47:32 --> Controller Class Initialized
INFO - 2024-03-22 15:47:32 --> Model Class Initialized
DEBUG - 2024-03-22 15:47:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-03-22 16:38:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 16:38:32 --> Config Class Initialized
INFO - 2024-03-22 16:38:32 --> Hooks Class Initialized
DEBUG - 2024-03-22 16:38:32 --> UTF-8 Support Enabled
INFO - 2024-03-22 16:38:32 --> Utf8 Class Initialized
INFO - 2024-03-22 16:38:32 --> URI Class Initialized
INFO - 2024-03-22 16:38:32 --> Router Class Initialized
INFO - 2024-03-22 16:38:32 --> Output Class Initialized
INFO - 2024-03-22 16:38:32 --> Security Class Initialized
DEBUG - 2024-03-22 16:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 16:38:32 --> Input Class Initialized
INFO - 2024-03-22 16:38:32 --> Language Class Initialized
INFO - 2024-03-22 16:38:32 --> Loader Class Initialized
INFO - 2024-03-22 16:38:32 --> Helper loaded: url_helper
INFO - 2024-03-22 16:38:32 --> Helper loaded: file_helper
INFO - 2024-03-22 16:38:32 --> Helper loaded: html_helper
INFO - 2024-03-22 16:38:32 --> Helper loaded: text_helper
INFO - 2024-03-22 16:38:32 --> Helper loaded: form_helper
INFO - 2024-03-22 16:38:32 --> Helper loaded: lang_helper
INFO - 2024-03-22 16:38:32 --> Helper loaded: security_helper
INFO - 2024-03-22 16:38:32 --> Helper loaded: cookie_helper
INFO - 2024-03-22 16:38:32 --> Database Driver Class Initialized
INFO - 2024-03-22 16:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 16:38:32 --> Parser Class Initialized
INFO - 2024-03-22 16:38:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 16:38:32 --> Pagination Class Initialized
INFO - 2024-03-22 16:38:32 --> Form Validation Class Initialized
INFO - 2024-03-22 16:38:32 --> Controller Class Initialized
DEBUG - 2024-03-22 16:38:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 16:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:38:32 --> Model Class Initialized
DEBUG - 2024-03-22 16:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:38:32 --> Model Class Initialized
ERROR - 2024-03-22 16:38:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 16:38:33 --> Config Class Initialized
INFO - 2024-03-22 16:38:33 --> Hooks Class Initialized
DEBUG - 2024-03-22 16:38:33 --> UTF-8 Support Enabled
INFO - 2024-03-22 16:38:33 --> Utf8 Class Initialized
INFO - 2024-03-22 16:38:33 --> URI Class Initialized
INFO - 2024-03-22 16:38:33 --> Router Class Initialized
INFO - 2024-03-22 16:38:33 --> Output Class Initialized
INFO - 2024-03-22 16:38:33 --> Security Class Initialized
DEBUG - 2024-03-22 16:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 16:38:33 --> Input Class Initialized
INFO - 2024-03-22 16:38:33 --> Language Class Initialized
INFO - 2024-03-22 16:38:33 --> Loader Class Initialized
INFO - 2024-03-22 16:38:33 --> Helper loaded: url_helper
INFO - 2024-03-22 16:38:33 --> Helper loaded: file_helper
INFO - 2024-03-22 16:38:33 --> Helper loaded: html_helper
INFO - 2024-03-22 16:38:33 --> Helper loaded: text_helper
INFO - 2024-03-22 16:38:33 --> Helper loaded: form_helper
INFO - 2024-03-22 16:38:33 --> Helper loaded: lang_helper
INFO - 2024-03-22 16:38:33 --> Helper loaded: security_helper
INFO - 2024-03-22 16:38:33 --> Helper loaded: cookie_helper
INFO - 2024-03-22 16:38:33 --> Database Driver Class Initialized
INFO - 2024-03-22 16:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 16:38:33 --> Parser Class Initialized
INFO - 2024-03-22 16:38:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 16:38:33 --> Pagination Class Initialized
INFO - 2024-03-22 16:38:33 --> Form Validation Class Initialized
INFO - 2024-03-22 16:38:33 --> Controller Class Initialized
INFO - 2024-03-22 16:38:33 --> Model Class Initialized
DEBUG - 2024-03-22 16:38:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:38:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-03-22 16:38:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:38:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 16:38:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 16:38:33 --> Model Class Initialized
INFO - 2024-03-22 16:38:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 16:38:33 --> Final output sent to browser
DEBUG - 2024-03-22 16:38:33 --> Total execution time: 0.0378
ERROR - 2024-03-22 16:38:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 16:38:45 --> Config Class Initialized
INFO - 2024-03-22 16:38:45 --> Hooks Class Initialized
DEBUG - 2024-03-22 16:38:45 --> UTF-8 Support Enabled
INFO - 2024-03-22 16:38:45 --> Utf8 Class Initialized
INFO - 2024-03-22 16:38:45 --> URI Class Initialized
INFO - 2024-03-22 16:38:45 --> Router Class Initialized
INFO - 2024-03-22 16:38:45 --> Output Class Initialized
INFO - 2024-03-22 16:38:45 --> Security Class Initialized
DEBUG - 2024-03-22 16:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 16:38:45 --> Input Class Initialized
INFO - 2024-03-22 16:38:45 --> Language Class Initialized
INFO - 2024-03-22 16:38:45 --> Loader Class Initialized
INFO - 2024-03-22 16:38:45 --> Helper loaded: url_helper
INFO - 2024-03-22 16:38:45 --> Helper loaded: file_helper
INFO - 2024-03-22 16:38:45 --> Helper loaded: html_helper
INFO - 2024-03-22 16:38:45 --> Helper loaded: text_helper
INFO - 2024-03-22 16:38:45 --> Helper loaded: form_helper
INFO - 2024-03-22 16:38:45 --> Helper loaded: lang_helper
INFO - 2024-03-22 16:38:45 --> Helper loaded: security_helper
INFO - 2024-03-22 16:38:45 --> Helper loaded: cookie_helper
INFO - 2024-03-22 16:38:45 --> Database Driver Class Initialized
INFO - 2024-03-22 16:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 16:38:45 --> Parser Class Initialized
INFO - 2024-03-22 16:38:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 16:38:45 --> Pagination Class Initialized
INFO - 2024-03-22 16:38:45 --> Form Validation Class Initialized
INFO - 2024-03-22 16:38:45 --> Controller Class Initialized
INFO - 2024-03-22 16:38:45 --> Model Class Initialized
DEBUG - 2024-03-22 16:38:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:38:45 --> Model Class Initialized
INFO - 2024-03-22 16:38:45 --> Final output sent to browser
DEBUG - 2024-03-22 16:38:45 --> Total execution time: 0.0206
ERROR - 2024-03-22 16:38:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 16:38:45 --> Config Class Initialized
INFO - 2024-03-22 16:38:45 --> Hooks Class Initialized
DEBUG - 2024-03-22 16:38:45 --> UTF-8 Support Enabled
INFO - 2024-03-22 16:38:45 --> Utf8 Class Initialized
INFO - 2024-03-22 16:38:45 --> URI Class Initialized
DEBUG - 2024-03-22 16:38:45 --> No URI present. Default controller set.
INFO - 2024-03-22 16:38:45 --> Router Class Initialized
INFO - 2024-03-22 16:38:45 --> Output Class Initialized
INFO - 2024-03-22 16:38:45 --> Security Class Initialized
DEBUG - 2024-03-22 16:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 16:38:45 --> Input Class Initialized
INFO - 2024-03-22 16:38:45 --> Language Class Initialized
INFO - 2024-03-22 16:38:45 --> Loader Class Initialized
INFO - 2024-03-22 16:38:45 --> Helper loaded: url_helper
INFO - 2024-03-22 16:38:45 --> Helper loaded: file_helper
INFO - 2024-03-22 16:38:45 --> Helper loaded: html_helper
INFO - 2024-03-22 16:38:45 --> Helper loaded: text_helper
INFO - 2024-03-22 16:38:45 --> Helper loaded: form_helper
INFO - 2024-03-22 16:38:45 --> Helper loaded: lang_helper
INFO - 2024-03-22 16:38:45 --> Helper loaded: security_helper
INFO - 2024-03-22 16:38:45 --> Helper loaded: cookie_helper
INFO - 2024-03-22 16:38:45 --> Database Driver Class Initialized
INFO - 2024-03-22 16:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 16:38:45 --> Parser Class Initialized
INFO - 2024-03-22 16:38:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 16:38:45 --> Pagination Class Initialized
INFO - 2024-03-22 16:38:45 --> Form Validation Class Initialized
INFO - 2024-03-22 16:38:45 --> Controller Class Initialized
INFO - 2024-03-22 16:38:45 --> Model Class Initialized
DEBUG - 2024-03-22 16:38:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:38:45 --> Model Class Initialized
DEBUG - 2024-03-22 16:38:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:38:45 --> Model Class Initialized
INFO - 2024-03-22 16:38:45 --> Model Class Initialized
INFO - 2024-03-22 16:38:45 --> Model Class Initialized
INFO - 2024-03-22 16:38:45 --> Model Class Initialized
DEBUG - 2024-03-22 16:38:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 16:38:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:38:45 --> Model Class Initialized
INFO - 2024-03-22 16:38:45 --> Model Class Initialized
INFO - 2024-03-22 16:38:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 16:38:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:38:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 16:38:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 16:38:45 --> Model Class Initialized
INFO - 2024-03-22 16:38:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 16:38:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 16:38:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 16:38:46 --> Final output sent to browser
DEBUG - 2024-03-22 16:38:46 --> Total execution time: 0.4437
ERROR - 2024-03-22 16:38:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 16:38:46 --> Config Class Initialized
INFO - 2024-03-22 16:38:46 --> Hooks Class Initialized
DEBUG - 2024-03-22 16:38:46 --> UTF-8 Support Enabled
INFO - 2024-03-22 16:38:46 --> Utf8 Class Initialized
INFO - 2024-03-22 16:38:46 --> URI Class Initialized
INFO - 2024-03-22 16:38:46 --> Router Class Initialized
INFO - 2024-03-22 16:38:46 --> Output Class Initialized
INFO - 2024-03-22 16:38:46 --> Security Class Initialized
DEBUG - 2024-03-22 16:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 16:38:46 --> Input Class Initialized
INFO - 2024-03-22 16:38:46 --> Language Class Initialized
INFO - 2024-03-22 16:38:46 --> Loader Class Initialized
INFO - 2024-03-22 16:38:46 --> Helper loaded: url_helper
INFO - 2024-03-22 16:38:46 --> Helper loaded: file_helper
INFO - 2024-03-22 16:38:46 --> Helper loaded: html_helper
INFO - 2024-03-22 16:38:46 --> Helper loaded: text_helper
INFO - 2024-03-22 16:38:46 --> Helper loaded: form_helper
INFO - 2024-03-22 16:38:46 --> Helper loaded: lang_helper
INFO - 2024-03-22 16:38:46 --> Helper loaded: security_helper
INFO - 2024-03-22 16:38:46 --> Helper loaded: cookie_helper
INFO - 2024-03-22 16:38:46 --> Database Driver Class Initialized
INFO - 2024-03-22 16:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 16:38:46 --> Parser Class Initialized
INFO - 2024-03-22 16:38:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 16:38:46 --> Pagination Class Initialized
INFO - 2024-03-22 16:38:46 --> Form Validation Class Initialized
INFO - 2024-03-22 16:38:46 --> Controller Class Initialized
DEBUG - 2024-03-22 16:38:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 16:38:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:38:46 --> Model Class Initialized
INFO - 2024-03-22 16:38:46 --> Final output sent to browser
DEBUG - 2024-03-22 16:38:46 --> Total execution time: 0.0133
ERROR - 2024-03-22 16:39:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 16:39:04 --> Config Class Initialized
INFO - 2024-03-22 16:39:04 --> Hooks Class Initialized
DEBUG - 2024-03-22 16:39:04 --> UTF-8 Support Enabled
INFO - 2024-03-22 16:39:04 --> Utf8 Class Initialized
INFO - 2024-03-22 16:39:04 --> URI Class Initialized
INFO - 2024-03-22 16:39:04 --> Router Class Initialized
INFO - 2024-03-22 16:39:04 --> Output Class Initialized
INFO - 2024-03-22 16:39:04 --> Security Class Initialized
DEBUG - 2024-03-22 16:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 16:39:04 --> Input Class Initialized
INFO - 2024-03-22 16:39:04 --> Language Class Initialized
INFO - 2024-03-22 16:39:04 --> Loader Class Initialized
INFO - 2024-03-22 16:39:04 --> Helper loaded: url_helper
INFO - 2024-03-22 16:39:04 --> Helper loaded: file_helper
INFO - 2024-03-22 16:39:04 --> Helper loaded: html_helper
INFO - 2024-03-22 16:39:04 --> Helper loaded: text_helper
INFO - 2024-03-22 16:39:04 --> Helper loaded: form_helper
INFO - 2024-03-22 16:39:04 --> Helper loaded: lang_helper
INFO - 2024-03-22 16:39:04 --> Helper loaded: security_helper
INFO - 2024-03-22 16:39:04 --> Helper loaded: cookie_helper
INFO - 2024-03-22 16:39:04 --> Database Driver Class Initialized
INFO - 2024-03-22 16:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 16:39:04 --> Parser Class Initialized
INFO - 2024-03-22 16:39:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 16:39:04 --> Pagination Class Initialized
INFO - 2024-03-22 16:39:04 --> Form Validation Class Initialized
INFO - 2024-03-22 16:39:04 --> Controller Class Initialized
INFO - 2024-03-22 16:39:04 --> Model Class Initialized
DEBUG - 2024-03-22 16:39:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 16:39:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:39:04 --> Model Class Initialized
DEBUG - 2024-03-22 16:39:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:39:04 --> Model Class Initialized
INFO - 2024-03-22 16:39:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-22 16:39:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:39:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 16:39:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 16:39:05 --> Model Class Initialized
INFO - 2024-03-22 16:39:05 --> Model Class Initialized
INFO - 2024-03-22 16:39:05 --> Model Class Initialized
INFO - 2024-03-22 16:39:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 16:39:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 16:39:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 16:39:05 --> Final output sent to browser
DEBUG - 2024-03-22 16:39:05 --> Total execution time: 0.2396
ERROR - 2024-03-22 16:39:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 16:39:06 --> Config Class Initialized
INFO - 2024-03-22 16:39:06 --> Hooks Class Initialized
DEBUG - 2024-03-22 16:39:06 --> UTF-8 Support Enabled
INFO - 2024-03-22 16:39:06 --> Utf8 Class Initialized
INFO - 2024-03-22 16:39:06 --> URI Class Initialized
INFO - 2024-03-22 16:39:06 --> Router Class Initialized
INFO - 2024-03-22 16:39:06 --> Output Class Initialized
INFO - 2024-03-22 16:39:06 --> Security Class Initialized
DEBUG - 2024-03-22 16:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 16:39:06 --> Input Class Initialized
INFO - 2024-03-22 16:39:06 --> Language Class Initialized
INFO - 2024-03-22 16:39:06 --> Loader Class Initialized
INFO - 2024-03-22 16:39:06 --> Helper loaded: url_helper
INFO - 2024-03-22 16:39:06 --> Helper loaded: file_helper
INFO - 2024-03-22 16:39:06 --> Helper loaded: html_helper
INFO - 2024-03-22 16:39:06 --> Helper loaded: text_helper
INFO - 2024-03-22 16:39:06 --> Helper loaded: form_helper
INFO - 2024-03-22 16:39:06 --> Helper loaded: lang_helper
INFO - 2024-03-22 16:39:06 --> Helper loaded: security_helper
INFO - 2024-03-22 16:39:06 --> Helper loaded: cookie_helper
INFO - 2024-03-22 16:39:06 --> Database Driver Class Initialized
INFO - 2024-03-22 16:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 16:39:06 --> Parser Class Initialized
INFO - 2024-03-22 16:39:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 16:39:06 --> Pagination Class Initialized
INFO - 2024-03-22 16:39:06 --> Form Validation Class Initialized
INFO - 2024-03-22 16:39:06 --> Controller Class Initialized
INFO - 2024-03-22 16:39:06 --> Model Class Initialized
DEBUG - 2024-03-22 16:39:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 16:39:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:39:06 --> Model Class Initialized
DEBUG - 2024-03-22 16:39:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:39:06 --> Model Class Initialized
INFO - 2024-03-22 16:39:06 --> Final output sent to browser
DEBUG - 2024-03-22 16:39:06 --> Total execution time: 0.0614
ERROR - 2024-03-22 16:39:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 16:39:14 --> Config Class Initialized
INFO - 2024-03-22 16:39:14 --> Hooks Class Initialized
DEBUG - 2024-03-22 16:39:14 --> UTF-8 Support Enabled
INFO - 2024-03-22 16:39:14 --> Utf8 Class Initialized
INFO - 2024-03-22 16:39:14 --> URI Class Initialized
INFO - 2024-03-22 16:39:14 --> Router Class Initialized
INFO - 2024-03-22 16:39:14 --> Output Class Initialized
INFO - 2024-03-22 16:39:14 --> Security Class Initialized
DEBUG - 2024-03-22 16:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 16:39:14 --> Input Class Initialized
INFO - 2024-03-22 16:39:14 --> Language Class Initialized
INFO - 2024-03-22 16:39:14 --> Loader Class Initialized
INFO - 2024-03-22 16:39:14 --> Helper loaded: url_helper
INFO - 2024-03-22 16:39:14 --> Helper loaded: file_helper
INFO - 2024-03-22 16:39:14 --> Helper loaded: html_helper
INFO - 2024-03-22 16:39:14 --> Helper loaded: text_helper
INFO - 2024-03-22 16:39:14 --> Helper loaded: form_helper
INFO - 2024-03-22 16:39:14 --> Helper loaded: lang_helper
INFO - 2024-03-22 16:39:14 --> Helper loaded: security_helper
INFO - 2024-03-22 16:39:14 --> Helper loaded: cookie_helper
INFO - 2024-03-22 16:39:14 --> Database Driver Class Initialized
INFO - 2024-03-22 16:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 16:39:14 --> Parser Class Initialized
INFO - 2024-03-22 16:39:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 16:39:14 --> Pagination Class Initialized
INFO - 2024-03-22 16:39:14 --> Form Validation Class Initialized
INFO - 2024-03-22 16:39:14 --> Controller Class Initialized
INFO - 2024-03-22 16:39:14 --> Model Class Initialized
INFO - 2024-03-22 16:39:14 --> Model Class Initialized
INFO - 2024-03-22 16:39:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2024-03-22 16:39:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:39:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 16:39:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 16:39:14 --> Model Class Initialized
INFO - 2024-03-22 16:39:14 --> Model Class Initialized
INFO - 2024-03-22 16:39:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 16:39:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 16:39:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 16:39:14 --> Final output sent to browser
DEBUG - 2024-03-22 16:39:14 --> Total execution time: 0.2826
ERROR - 2024-03-22 16:39:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 16:39:15 --> Config Class Initialized
INFO - 2024-03-22 16:39:15 --> Hooks Class Initialized
DEBUG - 2024-03-22 16:39:15 --> UTF-8 Support Enabled
INFO - 2024-03-22 16:39:15 --> Utf8 Class Initialized
INFO - 2024-03-22 16:39:15 --> URI Class Initialized
INFO - 2024-03-22 16:39:15 --> Router Class Initialized
INFO - 2024-03-22 16:39:15 --> Output Class Initialized
INFO - 2024-03-22 16:39:15 --> Security Class Initialized
DEBUG - 2024-03-22 16:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 16:39:15 --> Input Class Initialized
INFO - 2024-03-22 16:39:15 --> Language Class Initialized
INFO - 2024-03-22 16:39:15 --> Loader Class Initialized
INFO - 2024-03-22 16:39:15 --> Helper loaded: url_helper
INFO - 2024-03-22 16:39:15 --> Helper loaded: file_helper
INFO - 2024-03-22 16:39:15 --> Helper loaded: html_helper
INFO - 2024-03-22 16:39:15 --> Helper loaded: text_helper
INFO - 2024-03-22 16:39:15 --> Helper loaded: form_helper
INFO - 2024-03-22 16:39:15 --> Helper loaded: lang_helper
INFO - 2024-03-22 16:39:15 --> Helper loaded: security_helper
INFO - 2024-03-22 16:39:15 --> Helper loaded: cookie_helper
INFO - 2024-03-22 16:39:15 --> Database Driver Class Initialized
INFO - 2024-03-22 16:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 16:39:15 --> Parser Class Initialized
INFO - 2024-03-22 16:39:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 16:39:15 --> Pagination Class Initialized
INFO - 2024-03-22 16:39:15 --> Form Validation Class Initialized
INFO - 2024-03-22 16:39:15 --> Controller Class Initialized
INFO - 2024-03-22 16:39:15 --> Model Class Initialized
INFO - 2024-03-22 16:39:15 --> Model Class Initialized
INFO - 2024-03-22 16:39:15 --> Final output sent to browser
DEBUG - 2024-03-22 16:39:15 --> Total execution time: 0.2108
ERROR - 2024-03-22 16:39:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 16:39:21 --> Config Class Initialized
INFO - 2024-03-22 16:39:21 --> Hooks Class Initialized
DEBUG - 2024-03-22 16:39:21 --> UTF-8 Support Enabled
INFO - 2024-03-22 16:39:21 --> Utf8 Class Initialized
INFO - 2024-03-22 16:39:21 --> URI Class Initialized
INFO - 2024-03-22 16:39:21 --> Router Class Initialized
INFO - 2024-03-22 16:39:21 --> Output Class Initialized
INFO - 2024-03-22 16:39:21 --> Security Class Initialized
DEBUG - 2024-03-22 16:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 16:39:21 --> Input Class Initialized
INFO - 2024-03-22 16:39:21 --> Language Class Initialized
INFO - 2024-03-22 16:39:21 --> Loader Class Initialized
INFO - 2024-03-22 16:39:21 --> Helper loaded: url_helper
INFO - 2024-03-22 16:39:21 --> Helper loaded: file_helper
INFO - 2024-03-22 16:39:21 --> Helper loaded: html_helper
INFO - 2024-03-22 16:39:21 --> Helper loaded: text_helper
INFO - 2024-03-22 16:39:21 --> Helper loaded: form_helper
INFO - 2024-03-22 16:39:21 --> Helper loaded: lang_helper
INFO - 2024-03-22 16:39:21 --> Helper loaded: security_helper
INFO - 2024-03-22 16:39:21 --> Helper loaded: cookie_helper
INFO - 2024-03-22 16:39:21 --> Database Driver Class Initialized
INFO - 2024-03-22 16:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 16:39:21 --> Parser Class Initialized
INFO - 2024-03-22 16:39:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 16:39:21 --> Pagination Class Initialized
INFO - 2024-03-22 16:39:21 --> Form Validation Class Initialized
INFO - 2024-03-22 16:39:21 --> Controller Class Initialized
INFO - 2024-03-22 16:39:21 --> Model Class Initialized
DEBUG - 2024-03-22 16:39:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 16:39:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:39:21 --> Model Class Initialized
DEBUG - 2024-03-22 16:39:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:39:21 --> Model Class Initialized
INFO - 2024-03-22 16:39:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-03-22 16:39:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:39:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 16:39:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 16:39:21 --> Model Class Initialized
INFO - 2024-03-22 16:39:21 --> Model Class Initialized
INFO - 2024-03-22 16:39:21 --> Model Class Initialized
INFO - 2024-03-22 16:39:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 16:39:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 16:39:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 16:39:21 --> Final output sent to browser
DEBUG - 2024-03-22 16:39:21 --> Total execution time: 0.2416
ERROR - 2024-03-22 16:39:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 16:39:22 --> Config Class Initialized
INFO - 2024-03-22 16:39:22 --> Hooks Class Initialized
DEBUG - 2024-03-22 16:39:22 --> UTF-8 Support Enabled
INFO - 2024-03-22 16:39:22 --> Utf8 Class Initialized
INFO - 2024-03-22 16:39:22 --> URI Class Initialized
INFO - 2024-03-22 16:39:22 --> Router Class Initialized
INFO - 2024-03-22 16:39:22 --> Output Class Initialized
INFO - 2024-03-22 16:39:22 --> Security Class Initialized
DEBUG - 2024-03-22 16:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 16:39:22 --> Input Class Initialized
INFO - 2024-03-22 16:39:22 --> Language Class Initialized
INFO - 2024-03-22 16:39:22 --> Loader Class Initialized
INFO - 2024-03-22 16:39:22 --> Helper loaded: url_helper
INFO - 2024-03-22 16:39:22 --> Helper loaded: file_helper
INFO - 2024-03-22 16:39:22 --> Helper loaded: html_helper
INFO - 2024-03-22 16:39:22 --> Helper loaded: text_helper
INFO - 2024-03-22 16:39:22 --> Helper loaded: form_helper
INFO - 2024-03-22 16:39:22 --> Helper loaded: lang_helper
INFO - 2024-03-22 16:39:22 --> Helper loaded: security_helper
INFO - 2024-03-22 16:39:22 --> Helper loaded: cookie_helper
INFO - 2024-03-22 16:39:22 --> Database Driver Class Initialized
INFO - 2024-03-22 16:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 16:39:22 --> Parser Class Initialized
INFO - 2024-03-22 16:39:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 16:39:22 --> Pagination Class Initialized
INFO - 2024-03-22 16:39:22 --> Form Validation Class Initialized
INFO - 2024-03-22 16:39:22 --> Controller Class Initialized
INFO - 2024-03-22 16:39:22 --> Model Class Initialized
DEBUG - 2024-03-22 16:39:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 16:39:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:39:22 --> Model Class Initialized
DEBUG - 2024-03-22 16:39:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:39:22 --> Model Class Initialized
INFO - 2024-03-22 16:39:22 --> Final output sent to browser
DEBUG - 2024-03-22 16:39:22 --> Total execution time: 0.0620
ERROR - 2024-03-22 16:39:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 16:39:24 --> Config Class Initialized
INFO - 2024-03-22 16:39:24 --> Hooks Class Initialized
DEBUG - 2024-03-22 16:39:24 --> UTF-8 Support Enabled
INFO - 2024-03-22 16:39:24 --> Utf8 Class Initialized
INFO - 2024-03-22 16:39:24 --> URI Class Initialized
DEBUG - 2024-03-22 16:39:24 --> No URI present. Default controller set.
INFO - 2024-03-22 16:39:24 --> Router Class Initialized
INFO - 2024-03-22 16:39:24 --> Output Class Initialized
INFO - 2024-03-22 16:39:24 --> Security Class Initialized
DEBUG - 2024-03-22 16:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 16:39:24 --> Input Class Initialized
INFO - 2024-03-22 16:39:24 --> Language Class Initialized
INFO - 2024-03-22 16:39:24 --> Loader Class Initialized
INFO - 2024-03-22 16:39:24 --> Helper loaded: url_helper
INFO - 2024-03-22 16:39:24 --> Helper loaded: file_helper
INFO - 2024-03-22 16:39:24 --> Helper loaded: html_helper
INFO - 2024-03-22 16:39:24 --> Helper loaded: text_helper
INFO - 2024-03-22 16:39:24 --> Helper loaded: form_helper
INFO - 2024-03-22 16:39:24 --> Helper loaded: lang_helper
INFO - 2024-03-22 16:39:24 --> Helper loaded: security_helper
INFO - 2024-03-22 16:39:24 --> Helper loaded: cookie_helper
INFO - 2024-03-22 16:39:24 --> Database Driver Class Initialized
INFO - 2024-03-22 16:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 16:39:24 --> Parser Class Initialized
INFO - 2024-03-22 16:39:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 16:39:24 --> Pagination Class Initialized
INFO - 2024-03-22 16:39:24 --> Form Validation Class Initialized
INFO - 2024-03-22 16:39:24 --> Controller Class Initialized
INFO - 2024-03-22 16:39:24 --> Model Class Initialized
DEBUG - 2024-03-22 16:39:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:39:24 --> Model Class Initialized
DEBUG - 2024-03-22 16:39:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:39:24 --> Model Class Initialized
INFO - 2024-03-22 16:39:24 --> Model Class Initialized
INFO - 2024-03-22 16:39:24 --> Model Class Initialized
INFO - 2024-03-22 16:39:24 --> Model Class Initialized
DEBUG - 2024-03-22 16:39:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 16:39:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:39:24 --> Model Class Initialized
INFO - 2024-03-22 16:39:24 --> Model Class Initialized
INFO - 2024-03-22 16:39:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 16:39:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:39:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 16:39:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 16:39:24 --> Model Class Initialized
INFO - 2024-03-22 16:39:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 16:39:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 16:39:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 16:39:25 --> Final output sent to browser
DEBUG - 2024-03-22 16:39:25 --> Total execution time: 0.4517
ERROR - 2024-03-22 16:40:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 16:40:51 --> Config Class Initialized
INFO - 2024-03-22 16:40:51 --> Hooks Class Initialized
DEBUG - 2024-03-22 16:40:51 --> UTF-8 Support Enabled
INFO - 2024-03-22 16:40:51 --> Utf8 Class Initialized
INFO - 2024-03-22 16:40:51 --> URI Class Initialized
DEBUG - 2024-03-22 16:40:51 --> No URI present. Default controller set.
INFO - 2024-03-22 16:40:51 --> Router Class Initialized
INFO - 2024-03-22 16:40:51 --> Output Class Initialized
INFO - 2024-03-22 16:40:51 --> Security Class Initialized
DEBUG - 2024-03-22 16:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 16:40:51 --> Input Class Initialized
INFO - 2024-03-22 16:40:51 --> Language Class Initialized
INFO - 2024-03-22 16:40:51 --> Loader Class Initialized
INFO - 2024-03-22 16:40:51 --> Helper loaded: url_helper
INFO - 2024-03-22 16:40:51 --> Helper loaded: file_helper
INFO - 2024-03-22 16:40:51 --> Helper loaded: html_helper
INFO - 2024-03-22 16:40:51 --> Helper loaded: text_helper
INFO - 2024-03-22 16:40:51 --> Helper loaded: form_helper
INFO - 2024-03-22 16:40:51 --> Helper loaded: lang_helper
INFO - 2024-03-22 16:40:51 --> Helper loaded: security_helper
INFO - 2024-03-22 16:40:51 --> Helper loaded: cookie_helper
INFO - 2024-03-22 16:40:51 --> Database Driver Class Initialized
INFO - 2024-03-22 16:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-22 16:40:51 --> Parser Class Initialized
INFO - 2024-03-22 16:40:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-03-22 16:40:51 --> Pagination Class Initialized
INFO - 2024-03-22 16:40:51 --> Form Validation Class Initialized
INFO - 2024-03-22 16:40:51 --> Controller Class Initialized
INFO - 2024-03-22 16:40:51 --> Model Class Initialized
DEBUG - 2024-03-22 16:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:40:51 --> Model Class Initialized
DEBUG - 2024-03-22 16:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:40:51 --> Model Class Initialized
INFO - 2024-03-22 16:40:51 --> Model Class Initialized
INFO - 2024-03-22 16:40:51 --> Model Class Initialized
INFO - 2024-03-22 16:40:51 --> Model Class Initialized
DEBUG - 2024-03-22 16:40:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-03-22 16:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:40:51 --> Model Class Initialized
INFO - 2024-03-22 16:40:51 --> Model Class Initialized
INFO - 2024-03-22 16:40:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-03-22 16:40:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-03-22 16:40:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-03-22 16:40:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-03-22 16:40:51 --> Model Class Initialized
INFO - 2024-03-22 16:40:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-03-22 16:40:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-03-22 16:40:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-03-22 16:40:51 --> Final output sent to browser
DEBUG - 2024-03-22 16:40:51 --> Total execution time: 0.4334
ERROR - 2024-03-22 17:08:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 17:08:53 --> Config Class Initialized
INFO - 2024-03-22 17:08:53 --> Hooks Class Initialized
DEBUG - 2024-03-22 17:08:53 --> UTF-8 Support Enabled
INFO - 2024-03-22 17:08:53 --> Utf8 Class Initialized
INFO - 2024-03-22 17:08:53 --> URI Class Initialized
INFO - 2024-03-22 17:08:53 --> Router Class Initialized
INFO - 2024-03-22 17:08:53 --> Output Class Initialized
INFO - 2024-03-22 17:08:53 --> Security Class Initialized
DEBUG - 2024-03-22 17:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 17:08:53 --> Input Class Initialized
INFO - 2024-03-22 17:08:53 --> Language Class Initialized
ERROR - 2024-03-22 17:08:53 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2024-03-22 18:24:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 18:24:31 --> Config Class Initialized
INFO - 2024-03-22 18:24:31 --> Hooks Class Initialized
DEBUG - 2024-03-22 18:24:31 --> UTF-8 Support Enabled
INFO - 2024-03-22 18:24:31 --> Utf8 Class Initialized
INFO - 2024-03-22 18:24:31 --> URI Class Initialized
INFO - 2024-03-22 18:24:31 --> Router Class Initialized
INFO - 2024-03-22 18:24:31 --> Output Class Initialized
INFO - 2024-03-22 18:24:31 --> Security Class Initialized
DEBUG - 2024-03-22 18:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 18:24:31 --> Input Class Initialized
INFO - 2024-03-22 18:24:31 --> Language Class Initialized
ERROR - 2024-03-22 18:24:31 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-03-22 23:24:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-03-22 23:24:32 --> Config Class Initialized
INFO - 2024-03-22 23:24:32 --> Hooks Class Initialized
DEBUG - 2024-03-22 23:24:32 --> UTF-8 Support Enabled
INFO - 2024-03-22 23:24:32 --> Utf8 Class Initialized
INFO - 2024-03-22 23:24:32 --> URI Class Initialized
INFO - 2024-03-22 23:24:32 --> Router Class Initialized
INFO - 2024-03-22 23:24:32 --> Output Class Initialized
INFO - 2024-03-22 23:24:32 --> Security Class Initialized
DEBUG - 2024-03-22 23:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-22 23:24:32 --> Input Class Initialized
INFO - 2024-03-22 23:24:32 --> Language Class Initialized
ERROR - 2024-03-22 23:24:32 --> 404 Page Not Found: Well-known/assetlinks.json
