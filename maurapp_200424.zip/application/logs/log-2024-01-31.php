<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-31 02:25:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-31 02:25:38 --> Config Class Initialized
INFO - 2024-01-31 02:25:38 --> Hooks Class Initialized
DEBUG - 2024-01-31 02:25:38 --> UTF-8 Support Enabled
INFO - 2024-01-31 02:25:38 --> Utf8 Class Initialized
INFO - 2024-01-31 02:25:38 --> URI Class Initialized
INFO - 2024-01-31 02:25:38 --> Router Class Initialized
INFO - 2024-01-31 02:25:38 --> Output Class Initialized
INFO - 2024-01-31 02:25:38 --> Security Class Initialized
DEBUG - 2024-01-31 02:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-31 02:25:38 --> Input Class Initialized
INFO - 2024-01-31 02:25:38 --> Language Class Initialized
ERROR - 2024-01-31 02:25:38 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-01-31 05:33:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-31 05:33:14 --> Config Class Initialized
INFO - 2024-01-31 05:33:14 --> Hooks Class Initialized
DEBUG - 2024-01-31 05:33:14 --> UTF-8 Support Enabled
INFO - 2024-01-31 05:33:14 --> Utf8 Class Initialized
INFO - 2024-01-31 05:33:14 --> URI Class Initialized
DEBUG - 2024-01-31 05:33:14 --> No URI present. Default controller set.
INFO - 2024-01-31 05:33:14 --> Router Class Initialized
INFO - 2024-01-31 05:33:14 --> Output Class Initialized
INFO - 2024-01-31 05:33:14 --> Security Class Initialized
DEBUG - 2024-01-31 05:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-31 05:33:14 --> Input Class Initialized
INFO - 2024-01-31 05:33:14 --> Language Class Initialized
INFO - 2024-01-31 05:33:14 --> Loader Class Initialized
INFO - 2024-01-31 05:33:14 --> Helper loaded: url_helper
INFO - 2024-01-31 05:33:14 --> Helper loaded: file_helper
INFO - 2024-01-31 05:33:14 --> Helper loaded: html_helper
INFO - 2024-01-31 05:33:14 --> Helper loaded: text_helper
INFO - 2024-01-31 05:33:14 --> Helper loaded: form_helper
INFO - 2024-01-31 05:33:14 --> Helper loaded: lang_helper
INFO - 2024-01-31 05:33:14 --> Helper loaded: security_helper
INFO - 2024-01-31 05:33:14 --> Helper loaded: cookie_helper
INFO - 2024-01-31 05:33:14 --> Database Driver Class Initialized
INFO - 2024-01-31 05:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-31 05:33:14 --> Parser Class Initialized
INFO - 2024-01-31 05:33:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-31 05:33:14 --> Pagination Class Initialized
INFO - 2024-01-31 05:33:14 --> Form Validation Class Initialized
INFO - 2024-01-31 05:33:14 --> Controller Class Initialized
INFO - 2024-01-31 05:33:14 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-31 05:33:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-31 05:33:15 --> Config Class Initialized
INFO - 2024-01-31 05:33:15 --> Hooks Class Initialized
DEBUG - 2024-01-31 05:33:15 --> UTF-8 Support Enabled
INFO - 2024-01-31 05:33:15 --> Utf8 Class Initialized
INFO - 2024-01-31 05:33:15 --> URI Class Initialized
INFO - 2024-01-31 05:33:15 --> Router Class Initialized
INFO - 2024-01-31 05:33:15 --> Output Class Initialized
INFO - 2024-01-31 05:33:15 --> Security Class Initialized
DEBUG - 2024-01-31 05:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-31 05:33:15 --> Input Class Initialized
INFO - 2024-01-31 05:33:15 --> Language Class Initialized
INFO - 2024-01-31 05:33:15 --> Loader Class Initialized
INFO - 2024-01-31 05:33:15 --> Helper loaded: url_helper
INFO - 2024-01-31 05:33:15 --> Helper loaded: file_helper
INFO - 2024-01-31 05:33:15 --> Helper loaded: html_helper
INFO - 2024-01-31 05:33:15 --> Helper loaded: text_helper
INFO - 2024-01-31 05:33:15 --> Helper loaded: form_helper
INFO - 2024-01-31 05:33:15 --> Helper loaded: lang_helper
INFO - 2024-01-31 05:33:15 --> Helper loaded: security_helper
INFO - 2024-01-31 05:33:15 --> Helper loaded: cookie_helper
INFO - 2024-01-31 05:33:15 --> Database Driver Class Initialized
INFO - 2024-01-31 05:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-31 05:33:15 --> Parser Class Initialized
INFO - 2024-01-31 05:33:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-31 05:33:15 --> Pagination Class Initialized
INFO - 2024-01-31 05:33:15 --> Form Validation Class Initialized
INFO - 2024-01-31 05:33:15 --> Controller Class Initialized
INFO - 2024-01-31 05:33:15 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-31 05:33:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-31 05:33:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-31 05:33:15 --> Model Class Initialized
INFO - 2024-01-31 05:33:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-31 05:33:15 --> Final output sent to browser
DEBUG - 2024-01-31 05:33:15 --> Total execution time: 0.0422
ERROR - 2024-01-31 05:33:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-31 05:33:30 --> Config Class Initialized
INFO - 2024-01-31 05:33:30 --> Hooks Class Initialized
DEBUG - 2024-01-31 05:33:30 --> UTF-8 Support Enabled
INFO - 2024-01-31 05:33:30 --> Utf8 Class Initialized
INFO - 2024-01-31 05:33:30 --> URI Class Initialized
INFO - 2024-01-31 05:33:30 --> Router Class Initialized
INFO - 2024-01-31 05:33:30 --> Output Class Initialized
INFO - 2024-01-31 05:33:30 --> Security Class Initialized
DEBUG - 2024-01-31 05:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-31 05:33:30 --> Input Class Initialized
INFO - 2024-01-31 05:33:30 --> Language Class Initialized
INFO - 2024-01-31 05:33:30 --> Loader Class Initialized
INFO - 2024-01-31 05:33:30 --> Helper loaded: url_helper
INFO - 2024-01-31 05:33:30 --> Helper loaded: file_helper
INFO - 2024-01-31 05:33:30 --> Helper loaded: html_helper
INFO - 2024-01-31 05:33:30 --> Helper loaded: text_helper
INFO - 2024-01-31 05:33:30 --> Helper loaded: form_helper
INFO - 2024-01-31 05:33:30 --> Helper loaded: lang_helper
INFO - 2024-01-31 05:33:30 --> Helper loaded: security_helper
INFO - 2024-01-31 05:33:30 --> Helper loaded: cookie_helper
INFO - 2024-01-31 05:33:30 --> Database Driver Class Initialized
INFO - 2024-01-31 05:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-31 05:33:30 --> Parser Class Initialized
INFO - 2024-01-31 05:33:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-31 05:33:30 --> Pagination Class Initialized
INFO - 2024-01-31 05:33:30 --> Form Validation Class Initialized
INFO - 2024-01-31 05:33:30 --> Controller Class Initialized
INFO - 2024-01-31 05:33:30 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:30 --> Model Class Initialized
INFO - 2024-01-31 05:33:30 --> Final output sent to browser
DEBUG - 2024-01-31 05:33:30 --> Total execution time: 0.0280
ERROR - 2024-01-31 05:33:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-31 05:33:30 --> Config Class Initialized
INFO - 2024-01-31 05:33:30 --> Hooks Class Initialized
DEBUG - 2024-01-31 05:33:30 --> UTF-8 Support Enabled
INFO - 2024-01-31 05:33:30 --> Utf8 Class Initialized
INFO - 2024-01-31 05:33:30 --> URI Class Initialized
DEBUG - 2024-01-31 05:33:30 --> No URI present. Default controller set.
INFO - 2024-01-31 05:33:30 --> Router Class Initialized
INFO - 2024-01-31 05:33:30 --> Output Class Initialized
INFO - 2024-01-31 05:33:30 --> Security Class Initialized
DEBUG - 2024-01-31 05:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-31 05:33:30 --> Input Class Initialized
INFO - 2024-01-31 05:33:30 --> Language Class Initialized
INFO - 2024-01-31 05:33:30 --> Loader Class Initialized
INFO - 2024-01-31 05:33:30 --> Helper loaded: url_helper
INFO - 2024-01-31 05:33:30 --> Helper loaded: file_helper
INFO - 2024-01-31 05:33:30 --> Helper loaded: html_helper
INFO - 2024-01-31 05:33:30 --> Helper loaded: text_helper
INFO - 2024-01-31 05:33:30 --> Helper loaded: form_helper
INFO - 2024-01-31 05:33:30 --> Helper loaded: lang_helper
INFO - 2024-01-31 05:33:30 --> Helper loaded: security_helper
INFO - 2024-01-31 05:33:30 --> Helper loaded: cookie_helper
INFO - 2024-01-31 05:33:31 --> Database Driver Class Initialized
INFO - 2024-01-31 05:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-31 05:33:31 --> Parser Class Initialized
INFO - 2024-01-31 05:33:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-31 05:33:31 --> Pagination Class Initialized
INFO - 2024-01-31 05:33:31 --> Form Validation Class Initialized
INFO - 2024-01-31 05:33:31 --> Controller Class Initialized
INFO - 2024-01-31 05:33:31 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:31 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:31 --> Model Class Initialized
INFO - 2024-01-31 05:33:31 --> Model Class Initialized
INFO - 2024-01-31 05:33:31 --> Model Class Initialized
INFO - 2024-01-31 05:33:31 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-31 05:33:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:31 --> Model Class Initialized
INFO - 2024-01-31 05:33:31 --> Model Class Initialized
INFO - 2024-01-31 05:33:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-01-31 05:33:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-31 05:33:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-31 05:33:31 --> Model Class Initialized
INFO - 2024-01-31 05:33:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-31 05:33:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-31 05:33:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-31 05:33:31 --> Final output sent to browser
DEBUG - 2024-01-31 05:33:31 --> Total execution time: 0.2521
ERROR - 2024-01-31 05:33:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-31 05:33:36 --> Config Class Initialized
INFO - 2024-01-31 05:33:36 --> Hooks Class Initialized
DEBUG - 2024-01-31 05:33:36 --> UTF-8 Support Enabled
INFO - 2024-01-31 05:33:36 --> Utf8 Class Initialized
INFO - 2024-01-31 05:33:36 --> URI Class Initialized
INFO - 2024-01-31 05:33:36 --> Router Class Initialized
INFO - 2024-01-31 05:33:36 --> Output Class Initialized
INFO - 2024-01-31 05:33:36 --> Security Class Initialized
DEBUG - 2024-01-31 05:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-31 05:33:36 --> Input Class Initialized
INFO - 2024-01-31 05:33:36 --> Language Class Initialized
INFO - 2024-01-31 05:33:36 --> Loader Class Initialized
INFO - 2024-01-31 05:33:36 --> Helper loaded: url_helper
INFO - 2024-01-31 05:33:36 --> Helper loaded: file_helper
INFO - 2024-01-31 05:33:36 --> Helper loaded: html_helper
INFO - 2024-01-31 05:33:36 --> Helper loaded: text_helper
INFO - 2024-01-31 05:33:36 --> Helper loaded: form_helper
INFO - 2024-01-31 05:33:36 --> Helper loaded: lang_helper
INFO - 2024-01-31 05:33:36 --> Helper loaded: security_helper
INFO - 2024-01-31 05:33:36 --> Helper loaded: cookie_helper
INFO - 2024-01-31 05:33:36 --> Database Driver Class Initialized
INFO - 2024-01-31 05:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-31 05:33:36 --> Parser Class Initialized
INFO - 2024-01-31 05:33:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-31 05:33:36 --> Pagination Class Initialized
INFO - 2024-01-31 05:33:36 --> Form Validation Class Initialized
INFO - 2024-01-31 05:33:36 --> Controller Class Initialized
INFO - 2024-01-31 05:33:36 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-31 05:33:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:36 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:36 --> Model Class Initialized
INFO - 2024-01-31 05:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-31 05:33:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-31 05:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-31 05:33:36 --> Model Class Initialized
INFO - 2024-01-31 05:33:36 --> Model Class Initialized
INFO - 2024-01-31 05:33:36 --> Model Class Initialized
INFO - 2024-01-31 05:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-31 05:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-31 05:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-31 05:33:36 --> Final output sent to browser
DEBUG - 2024-01-31 05:33:36 --> Total execution time: 0.1640
ERROR - 2024-01-31 05:33:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-31 05:33:36 --> Config Class Initialized
INFO - 2024-01-31 05:33:36 --> Hooks Class Initialized
DEBUG - 2024-01-31 05:33:36 --> UTF-8 Support Enabled
INFO - 2024-01-31 05:33:36 --> Utf8 Class Initialized
INFO - 2024-01-31 05:33:36 --> URI Class Initialized
INFO - 2024-01-31 05:33:36 --> Router Class Initialized
INFO - 2024-01-31 05:33:36 --> Output Class Initialized
INFO - 2024-01-31 05:33:36 --> Security Class Initialized
DEBUG - 2024-01-31 05:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-31 05:33:36 --> Input Class Initialized
INFO - 2024-01-31 05:33:36 --> Language Class Initialized
INFO - 2024-01-31 05:33:36 --> Loader Class Initialized
INFO - 2024-01-31 05:33:36 --> Helper loaded: url_helper
INFO - 2024-01-31 05:33:36 --> Helper loaded: file_helper
INFO - 2024-01-31 05:33:36 --> Helper loaded: html_helper
INFO - 2024-01-31 05:33:36 --> Helper loaded: text_helper
INFO - 2024-01-31 05:33:36 --> Helper loaded: form_helper
INFO - 2024-01-31 05:33:36 --> Helper loaded: lang_helper
INFO - 2024-01-31 05:33:36 --> Helper loaded: security_helper
INFO - 2024-01-31 05:33:36 --> Helper loaded: cookie_helper
INFO - 2024-01-31 05:33:36 --> Database Driver Class Initialized
INFO - 2024-01-31 05:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-31 05:33:36 --> Parser Class Initialized
INFO - 2024-01-31 05:33:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-31 05:33:36 --> Pagination Class Initialized
INFO - 2024-01-31 05:33:36 --> Form Validation Class Initialized
INFO - 2024-01-31 05:33:36 --> Controller Class Initialized
INFO - 2024-01-31 05:33:36 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-31 05:33:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:36 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:36 --> Model Class Initialized
INFO - 2024-01-31 05:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-01-31 05:33:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-31 05:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-31 05:33:36 --> Model Class Initialized
INFO - 2024-01-31 05:33:36 --> Model Class Initialized
INFO - 2024-01-31 05:33:36 --> Model Class Initialized
INFO - 2024-01-31 05:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-31 05:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-31 05:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-31 05:33:36 --> Final output sent to browser
DEBUG - 2024-01-31 05:33:36 --> Total execution time: 0.1645
ERROR - 2024-01-31 05:33:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-31 05:33:38 --> Config Class Initialized
INFO - 2024-01-31 05:33:38 --> Hooks Class Initialized
DEBUG - 2024-01-31 05:33:38 --> UTF-8 Support Enabled
INFO - 2024-01-31 05:33:38 --> Utf8 Class Initialized
INFO - 2024-01-31 05:33:38 --> URI Class Initialized
INFO - 2024-01-31 05:33:38 --> Router Class Initialized
INFO - 2024-01-31 05:33:38 --> Output Class Initialized
INFO - 2024-01-31 05:33:38 --> Security Class Initialized
DEBUG - 2024-01-31 05:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-31 05:33:38 --> Input Class Initialized
INFO - 2024-01-31 05:33:38 --> Language Class Initialized
INFO - 2024-01-31 05:33:38 --> Loader Class Initialized
INFO - 2024-01-31 05:33:38 --> Helper loaded: url_helper
INFO - 2024-01-31 05:33:38 --> Helper loaded: file_helper
INFO - 2024-01-31 05:33:38 --> Helper loaded: html_helper
INFO - 2024-01-31 05:33:38 --> Helper loaded: text_helper
INFO - 2024-01-31 05:33:38 --> Helper loaded: form_helper
INFO - 2024-01-31 05:33:38 --> Helper loaded: lang_helper
INFO - 2024-01-31 05:33:38 --> Helper loaded: security_helper
INFO - 2024-01-31 05:33:38 --> Helper loaded: cookie_helper
INFO - 2024-01-31 05:33:38 --> Database Driver Class Initialized
INFO - 2024-01-31 05:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-31 05:33:38 --> Parser Class Initialized
INFO - 2024-01-31 05:33:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-31 05:33:38 --> Pagination Class Initialized
INFO - 2024-01-31 05:33:38 --> Form Validation Class Initialized
INFO - 2024-01-31 05:33:38 --> Controller Class Initialized
INFO - 2024-01-31 05:33:38 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-31 05:33:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:38 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:38 --> Model Class Initialized
INFO - 2024-01-31 05:33:38 --> Final output sent to browser
DEBUG - 2024-01-31 05:33:38 --> Total execution time: 0.0479
ERROR - 2024-01-31 05:33:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-31 05:33:40 --> Config Class Initialized
INFO - 2024-01-31 05:33:40 --> Hooks Class Initialized
DEBUG - 2024-01-31 05:33:40 --> UTF-8 Support Enabled
INFO - 2024-01-31 05:33:40 --> Utf8 Class Initialized
INFO - 2024-01-31 05:33:40 --> URI Class Initialized
INFO - 2024-01-31 05:33:40 --> Router Class Initialized
INFO - 2024-01-31 05:33:40 --> Output Class Initialized
INFO - 2024-01-31 05:33:40 --> Security Class Initialized
DEBUG - 2024-01-31 05:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-31 05:33:40 --> Input Class Initialized
INFO - 2024-01-31 05:33:40 --> Language Class Initialized
INFO - 2024-01-31 05:33:40 --> Loader Class Initialized
INFO - 2024-01-31 05:33:40 --> Helper loaded: url_helper
INFO - 2024-01-31 05:33:40 --> Helper loaded: file_helper
INFO - 2024-01-31 05:33:40 --> Helper loaded: html_helper
INFO - 2024-01-31 05:33:40 --> Helper loaded: text_helper
INFO - 2024-01-31 05:33:40 --> Helper loaded: form_helper
INFO - 2024-01-31 05:33:40 --> Helper loaded: lang_helper
INFO - 2024-01-31 05:33:40 --> Helper loaded: security_helper
INFO - 2024-01-31 05:33:40 --> Helper loaded: cookie_helper
INFO - 2024-01-31 05:33:40 --> Database Driver Class Initialized
INFO - 2024-01-31 05:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-31 05:33:40 --> Parser Class Initialized
INFO - 2024-01-31 05:33:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-31 05:33:40 --> Pagination Class Initialized
INFO - 2024-01-31 05:33:40 --> Form Validation Class Initialized
INFO - 2024-01-31 05:33:40 --> Controller Class Initialized
INFO - 2024-01-31 05:33:40 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-31 05:33:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:40 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:40 --> Model Class Initialized
INFO - 2024-01-31 05:33:40 --> Final output sent to browser
DEBUG - 2024-01-31 05:33:40 --> Total execution time: 0.0469
ERROR - 2024-01-31 05:33:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-31 05:33:41 --> Config Class Initialized
INFO - 2024-01-31 05:33:41 --> Hooks Class Initialized
DEBUG - 2024-01-31 05:33:41 --> UTF-8 Support Enabled
INFO - 2024-01-31 05:33:41 --> Utf8 Class Initialized
INFO - 2024-01-31 05:33:41 --> URI Class Initialized
INFO - 2024-01-31 05:33:41 --> Router Class Initialized
INFO - 2024-01-31 05:33:41 --> Output Class Initialized
INFO - 2024-01-31 05:33:41 --> Security Class Initialized
DEBUG - 2024-01-31 05:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-31 05:33:41 --> Input Class Initialized
INFO - 2024-01-31 05:33:41 --> Language Class Initialized
INFO - 2024-01-31 05:33:41 --> Loader Class Initialized
INFO - 2024-01-31 05:33:41 --> Helper loaded: url_helper
INFO - 2024-01-31 05:33:41 --> Helper loaded: file_helper
INFO - 2024-01-31 05:33:41 --> Helper loaded: html_helper
INFO - 2024-01-31 05:33:41 --> Helper loaded: text_helper
INFO - 2024-01-31 05:33:41 --> Helper loaded: form_helper
INFO - 2024-01-31 05:33:41 --> Helper loaded: lang_helper
INFO - 2024-01-31 05:33:41 --> Helper loaded: security_helper
INFO - 2024-01-31 05:33:41 --> Helper loaded: cookie_helper
INFO - 2024-01-31 05:33:41 --> Database Driver Class Initialized
INFO - 2024-01-31 05:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-31 05:33:41 --> Parser Class Initialized
INFO - 2024-01-31 05:33:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-31 05:33:41 --> Pagination Class Initialized
INFO - 2024-01-31 05:33:41 --> Form Validation Class Initialized
INFO - 2024-01-31 05:33:41 --> Controller Class Initialized
INFO - 2024-01-31 05:33:41 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-31 05:33:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:41 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:41 --> Model Class Initialized
INFO - 2024-01-31 05:33:41 --> Final output sent to browser
DEBUG - 2024-01-31 05:33:41 --> Total execution time: 0.0437
ERROR - 2024-01-31 05:33:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-31 05:33:42 --> Config Class Initialized
INFO - 2024-01-31 05:33:42 --> Hooks Class Initialized
DEBUG - 2024-01-31 05:33:42 --> UTF-8 Support Enabled
INFO - 2024-01-31 05:33:42 --> Utf8 Class Initialized
INFO - 2024-01-31 05:33:42 --> URI Class Initialized
INFO - 2024-01-31 05:33:42 --> Router Class Initialized
INFO - 2024-01-31 05:33:42 --> Output Class Initialized
INFO - 2024-01-31 05:33:42 --> Security Class Initialized
DEBUG - 2024-01-31 05:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-31 05:33:42 --> Input Class Initialized
INFO - 2024-01-31 05:33:42 --> Language Class Initialized
INFO - 2024-01-31 05:33:42 --> Loader Class Initialized
INFO - 2024-01-31 05:33:42 --> Helper loaded: url_helper
INFO - 2024-01-31 05:33:42 --> Helper loaded: file_helper
INFO - 2024-01-31 05:33:42 --> Helper loaded: html_helper
INFO - 2024-01-31 05:33:42 --> Helper loaded: text_helper
INFO - 2024-01-31 05:33:42 --> Helper loaded: form_helper
INFO - 2024-01-31 05:33:42 --> Helper loaded: lang_helper
INFO - 2024-01-31 05:33:42 --> Helper loaded: security_helper
INFO - 2024-01-31 05:33:42 --> Helper loaded: cookie_helper
INFO - 2024-01-31 05:33:42 --> Database Driver Class Initialized
INFO - 2024-01-31 05:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-31 05:33:42 --> Parser Class Initialized
INFO - 2024-01-31 05:33:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-31 05:33:42 --> Pagination Class Initialized
INFO - 2024-01-31 05:33:42 --> Form Validation Class Initialized
INFO - 2024-01-31 05:33:42 --> Controller Class Initialized
INFO - 2024-01-31 05:33:42 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-31 05:33:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:42 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:42 --> Model Class Initialized
INFO - 2024-01-31 05:33:42 --> Final output sent to browser
DEBUG - 2024-01-31 05:33:42 --> Total execution time: 0.0275
ERROR - 2024-01-31 05:33:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-31 05:33:43 --> Config Class Initialized
INFO - 2024-01-31 05:33:43 --> Hooks Class Initialized
DEBUG - 2024-01-31 05:33:43 --> UTF-8 Support Enabled
INFO - 2024-01-31 05:33:43 --> Utf8 Class Initialized
INFO - 2024-01-31 05:33:43 --> URI Class Initialized
INFO - 2024-01-31 05:33:43 --> Router Class Initialized
INFO - 2024-01-31 05:33:43 --> Output Class Initialized
INFO - 2024-01-31 05:33:43 --> Security Class Initialized
DEBUG - 2024-01-31 05:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-31 05:33:43 --> Input Class Initialized
INFO - 2024-01-31 05:33:43 --> Language Class Initialized
INFO - 2024-01-31 05:33:43 --> Loader Class Initialized
INFO - 2024-01-31 05:33:43 --> Helper loaded: url_helper
INFO - 2024-01-31 05:33:43 --> Helper loaded: file_helper
INFO - 2024-01-31 05:33:43 --> Helper loaded: html_helper
INFO - 2024-01-31 05:33:43 --> Helper loaded: text_helper
INFO - 2024-01-31 05:33:43 --> Helper loaded: form_helper
INFO - 2024-01-31 05:33:43 --> Helper loaded: lang_helper
INFO - 2024-01-31 05:33:43 --> Helper loaded: security_helper
INFO - 2024-01-31 05:33:43 --> Helper loaded: cookie_helper
INFO - 2024-01-31 05:33:43 --> Database Driver Class Initialized
INFO - 2024-01-31 05:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-31 05:33:43 --> Parser Class Initialized
INFO - 2024-01-31 05:33:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-31 05:33:43 --> Pagination Class Initialized
INFO - 2024-01-31 05:33:43 --> Form Validation Class Initialized
INFO - 2024-01-31 05:33:43 --> Controller Class Initialized
INFO - 2024-01-31 05:33:43 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-31 05:33:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:43 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:43 --> Model Class Initialized
INFO - 2024-01-31 05:33:43 --> Final output sent to browser
DEBUG - 2024-01-31 05:33:43 --> Total execution time: 0.0295
ERROR - 2024-01-31 05:33:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-31 05:33:44 --> Config Class Initialized
INFO - 2024-01-31 05:33:44 --> Hooks Class Initialized
DEBUG - 2024-01-31 05:33:44 --> UTF-8 Support Enabled
INFO - 2024-01-31 05:33:44 --> Utf8 Class Initialized
INFO - 2024-01-31 05:33:44 --> URI Class Initialized
INFO - 2024-01-31 05:33:44 --> Router Class Initialized
INFO - 2024-01-31 05:33:44 --> Output Class Initialized
INFO - 2024-01-31 05:33:44 --> Security Class Initialized
DEBUG - 2024-01-31 05:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-31 05:33:44 --> Input Class Initialized
INFO - 2024-01-31 05:33:44 --> Language Class Initialized
INFO - 2024-01-31 05:33:44 --> Loader Class Initialized
INFO - 2024-01-31 05:33:44 --> Helper loaded: url_helper
INFO - 2024-01-31 05:33:44 --> Helper loaded: file_helper
INFO - 2024-01-31 05:33:44 --> Helper loaded: html_helper
INFO - 2024-01-31 05:33:44 --> Helper loaded: text_helper
INFO - 2024-01-31 05:33:44 --> Helper loaded: form_helper
INFO - 2024-01-31 05:33:44 --> Helper loaded: lang_helper
INFO - 2024-01-31 05:33:44 --> Helper loaded: security_helper
INFO - 2024-01-31 05:33:44 --> Helper loaded: cookie_helper
INFO - 2024-01-31 05:33:44 --> Database Driver Class Initialized
INFO - 2024-01-31 05:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-31 05:33:44 --> Parser Class Initialized
INFO - 2024-01-31 05:33:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-31 05:33:44 --> Pagination Class Initialized
INFO - 2024-01-31 05:33:44 --> Form Validation Class Initialized
INFO - 2024-01-31 05:33:44 --> Controller Class Initialized
INFO - 2024-01-31 05:33:44 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-31 05:33:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:44 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:44 --> Model Class Initialized
INFO - 2024-01-31 05:33:44 --> Final output sent to browser
DEBUG - 2024-01-31 05:33:44 --> Total execution time: 0.0260
ERROR - 2024-01-31 05:33:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-31 05:33:44 --> Config Class Initialized
INFO - 2024-01-31 05:33:44 --> Hooks Class Initialized
DEBUG - 2024-01-31 05:33:44 --> UTF-8 Support Enabled
INFO - 2024-01-31 05:33:44 --> Utf8 Class Initialized
INFO - 2024-01-31 05:33:44 --> URI Class Initialized
INFO - 2024-01-31 05:33:44 --> Router Class Initialized
INFO - 2024-01-31 05:33:44 --> Output Class Initialized
INFO - 2024-01-31 05:33:44 --> Security Class Initialized
DEBUG - 2024-01-31 05:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-31 05:33:44 --> Input Class Initialized
INFO - 2024-01-31 05:33:44 --> Language Class Initialized
INFO - 2024-01-31 05:33:44 --> Loader Class Initialized
INFO - 2024-01-31 05:33:44 --> Helper loaded: url_helper
INFO - 2024-01-31 05:33:44 --> Helper loaded: file_helper
INFO - 2024-01-31 05:33:44 --> Helper loaded: html_helper
INFO - 2024-01-31 05:33:44 --> Helper loaded: text_helper
INFO - 2024-01-31 05:33:44 --> Helper loaded: form_helper
INFO - 2024-01-31 05:33:44 --> Helper loaded: lang_helper
INFO - 2024-01-31 05:33:44 --> Helper loaded: security_helper
INFO - 2024-01-31 05:33:44 --> Helper loaded: cookie_helper
INFO - 2024-01-31 05:33:44 --> Database Driver Class Initialized
INFO - 2024-01-31 05:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-31 05:33:44 --> Parser Class Initialized
INFO - 2024-01-31 05:33:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-31 05:33:44 --> Pagination Class Initialized
INFO - 2024-01-31 05:33:44 --> Form Validation Class Initialized
INFO - 2024-01-31 05:33:44 --> Controller Class Initialized
INFO - 2024-01-31 05:33:44 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-31 05:33:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:44 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:44 --> Model Class Initialized
INFO - 2024-01-31 05:33:44 --> Final output sent to browser
DEBUG - 2024-01-31 05:33:44 --> Total execution time: 0.0310
ERROR - 2024-01-31 05:33:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-31 05:33:47 --> Config Class Initialized
INFO - 2024-01-31 05:33:47 --> Hooks Class Initialized
DEBUG - 2024-01-31 05:33:47 --> UTF-8 Support Enabled
INFO - 2024-01-31 05:33:47 --> Utf8 Class Initialized
INFO - 2024-01-31 05:33:47 --> URI Class Initialized
INFO - 2024-01-31 05:33:47 --> Router Class Initialized
INFO - 2024-01-31 05:33:47 --> Output Class Initialized
INFO - 2024-01-31 05:33:47 --> Security Class Initialized
DEBUG - 2024-01-31 05:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-31 05:33:47 --> Input Class Initialized
INFO - 2024-01-31 05:33:47 --> Language Class Initialized
INFO - 2024-01-31 05:33:47 --> Loader Class Initialized
INFO - 2024-01-31 05:33:47 --> Helper loaded: url_helper
INFO - 2024-01-31 05:33:47 --> Helper loaded: file_helper
INFO - 2024-01-31 05:33:47 --> Helper loaded: html_helper
INFO - 2024-01-31 05:33:47 --> Helper loaded: text_helper
INFO - 2024-01-31 05:33:47 --> Helper loaded: form_helper
INFO - 2024-01-31 05:33:47 --> Helper loaded: lang_helper
INFO - 2024-01-31 05:33:47 --> Helper loaded: security_helper
INFO - 2024-01-31 05:33:47 --> Helper loaded: cookie_helper
INFO - 2024-01-31 05:33:47 --> Database Driver Class Initialized
INFO - 2024-01-31 05:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-31 05:33:47 --> Parser Class Initialized
INFO - 2024-01-31 05:33:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-31 05:33:47 --> Pagination Class Initialized
INFO - 2024-01-31 05:33:47 --> Form Validation Class Initialized
INFO - 2024-01-31 05:33:47 --> Controller Class Initialized
INFO - 2024-01-31 05:33:47 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-31 05:33:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:47 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:47 --> Model Class Initialized
INFO - 2024-01-31 05:33:47 --> Final output sent to browser
DEBUG - 2024-01-31 05:33:47 --> Total execution time: 0.0218
ERROR - 2024-01-31 05:33:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-31 05:33:48 --> Config Class Initialized
INFO - 2024-01-31 05:33:48 --> Hooks Class Initialized
DEBUG - 2024-01-31 05:33:48 --> UTF-8 Support Enabled
INFO - 2024-01-31 05:33:48 --> Utf8 Class Initialized
INFO - 2024-01-31 05:33:48 --> URI Class Initialized
INFO - 2024-01-31 05:33:48 --> Router Class Initialized
INFO - 2024-01-31 05:33:48 --> Output Class Initialized
INFO - 2024-01-31 05:33:48 --> Security Class Initialized
DEBUG - 2024-01-31 05:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-31 05:33:48 --> Input Class Initialized
INFO - 2024-01-31 05:33:48 --> Language Class Initialized
INFO - 2024-01-31 05:33:48 --> Loader Class Initialized
INFO - 2024-01-31 05:33:48 --> Helper loaded: url_helper
INFO - 2024-01-31 05:33:48 --> Helper loaded: file_helper
INFO - 2024-01-31 05:33:48 --> Helper loaded: html_helper
INFO - 2024-01-31 05:33:48 --> Helper loaded: text_helper
INFO - 2024-01-31 05:33:48 --> Helper loaded: form_helper
INFO - 2024-01-31 05:33:48 --> Helper loaded: lang_helper
INFO - 2024-01-31 05:33:48 --> Helper loaded: security_helper
INFO - 2024-01-31 05:33:48 --> Helper loaded: cookie_helper
INFO - 2024-01-31 05:33:48 --> Database Driver Class Initialized
INFO - 2024-01-31 05:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-31 05:33:48 --> Parser Class Initialized
INFO - 2024-01-31 05:33:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-31 05:33:48 --> Pagination Class Initialized
INFO - 2024-01-31 05:33:48 --> Form Validation Class Initialized
INFO - 2024-01-31 05:33:48 --> Controller Class Initialized
INFO - 2024-01-31 05:33:48 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-31 05:33:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:48 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:48 --> Model Class Initialized
INFO - 2024-01-31 05:33:48 --> Final output sent to browser
DEBUG - 2024-01-31 05:33:48 --> Total execution time: 0.0245
ERROR - 2024-01-31 05:33:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-31 05:33:58 --> Config Class Initialized
INFO - 2024-01-31 05:33:58 --> Hooks Class Initialized
DEBUG - 2024-01-31 05:33:58 --> UTF-8 Support Enabled
INFO - 2024-01-31 05:33:58 --> Utf8 Class Initialized
INFO - 2024-01-31 05:33:58 --> URI Class Initialized
INFO - 2024-01-31 05:33:58 --> Router Class Initialized
INFO - 2024-01-31 05:33:58 --> Output Class Initialized
INFO - 2024-01-31 05:33:58 --> Security Class Initialized
DEBUG - 2024-01-31 05:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-31 05:33:58 --> Input Class Initialized
INFO - 2024-01-31 05:33:58 --> Language Class Initialized
INFO - 2024-01-31 05:33:58 --> Loader Class Initialized
INFO - 2024-01-31 05:33:58 --> Helper loaded: url_helper
INFO - 2024-01-31 05:33:58 --> Helper loaded: file_helper
INFO - 2024-01-31 05:33:58 --> Helper loaded: html_helper
INFO - 2024-01-31 05:33:58 --> Helper loaded: text_helper
INFO - 2024-01-31 05:33:58 --> Helper loaded: form_helper
INFO - 2024-01-31 05:33:58 --> Helper loaded: lang_helper
INFO - 2024-01-31 05:33:58 --> Helper loaded: security_helper
INFO - 2024-01-31 05:33:58 --> Helper loaded: cookie_helper
INFO - 2024-01-31 05:33:58 --> Database Driver Class Initialized
INFO - 2024-01-31 05:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-31 05:33:58 --> Parser Class Initialized
INFO - 2024-01-31 05:33:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-31 05:33:58 --> Pagination Class Initialized
INFO - 2024-01-31 05:33:58 --> Form Validation Class Initialized
INFO - 2024-01-31 05:33:58 --> Controller Class Initialized
INFO - 2024-01-31 05:33:58 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-01-31 05:33:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:58 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:58 --> Model Class Initialized
DEBUG - 2024-01-31 05:33:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-01-31 05:33:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:33:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-31 05:33:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-31 05:33:58 --> Model Class Initialized
INFO - 2024-01-31 05:33:58 --> Model Class Initialized
INFO - 2024-01-31 05:33:58 --> Model Class Initialized
INFO - 2024-01-31 05:33:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-01-31 05:33:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-01-31 05:33:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-31 05:33:59 --> Final output sent to browser
DEBUG - 2024-01-31 05:33:59 --> Total execution time: 0.1804
ERROR - 2024-01-31 05:43:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-31 05:43:48 --> Config Class Initialized
INFO - 2024-01-31 05:43:48 --> Hooks Class Initialized
DEBUG - 2024-01-31 05:43:48 --> UTF-8 Support Enabled
INFO - 2024-01-31 05:43:48 --> Utf8 Class Initialized
INFO - 2024-01-31 05:43:48 --> URI Class Initialized
DEBUG - 2024-01-31 05:43:48 --> No URI present. Default controller set.
INFO - 2024-01-31 05:43:48 --> Router Class Initialized
INFO - 2024-01-31 05:43:48 --> Output Class Initialized
INFO - 2024-01-31 05:43:48 --> Security Class Initialized
DEBUG - 2024-01-31 05:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-31 05:43:48 --> Input Class Initialized
INFO - 2024-01-31 05:43:48 --> Language Class Initialized
INFO - 2024-01-31 05:43:48 --> Loader Class Initialized
INFO - 2024-01-31 05:43:48 --> Helper loaded: url_helper
INFO - 2024-01-31 05:43:48 --> Helper loaded: file_helper
INFO - 2024-01-31 05:43:48 --> Helper loaded: html_helper
INFO - 2024-01-31 05:43:48 --> Helper loaded: text_helper
INFO - 2024-01-31 05:43:48 --> Helper loaded: form_helper
INFO - 2024-01-31 05:43:48 --> Helper loaded: lang_helper
INFO - 2024-01-31 05:43:48 --> Helper loaded: security_helper
INFO - 2024-01-31 05:43:48 --> Helper loaded: cookie_helper
INFO - 2024-01-31 05:43:48 --> Database Driver Class Initialized
INFO - 2024-01-31 05:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-31 05:43:48 --> Parser Class Initialized
INFO - 2024-01-31 05:43:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-31 05:43:48 --> Pagination Class Initialized
INFO - 2024-01-31 05:43:48 --> Form Validation Class Initialized
INFO - 2024-01-31 05:43:48 --> Controller Class Initialized
INFO - 2024-01-31 05:43:48 --> Model Class Initialized
DEBUG - 2024-01-31 05:43:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-31 05:43:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-31 05:43:49 --> Config Class Initialized
INFO - 2024-01-31 05:43:49 --> Hooks Class Initialized
DEBUG - 2024-01-31 05:43:49 --> UTF-8 Support Enabled
INFO - 2024-01-31 05:43:49 --> Utf8 Class Initialized
INFO - 2024-01-31 05:43:49 --> URI Class Initialized
INFO - 2024-01-31 05:43:49 --> Router Class Initialized
INFO - 2024-01-31 05:43:49 --> Output Class Initialized
INFO - 2024-01-31 05:43:49 --> Security Class Initialized
DEBUG - 2024-01-31 05:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-31 05:43:49 --> Input Class Initialized
INFO - 2024-01-31 05:43:49 --> Language Class Initialized
INFO - 2024-01-31 05:43:49 --> Loader Class Initialized
INFO - 2024-01-31 05:43:49 --> Helper loaded: url_helper
INFO - 2024-01-31 05:43:49 --> Helper loaded: file_helper
INFO - 2024-01-31 05:43:49 --> Helper loaded: html_helper
INFO - 2024-01-31 05:43:49 --> Helper loaded: text_helper
INFO - 2024-01-31 05:43:49 --> Helper loaded: form_helper
INFO - 2024-01-31 05:43:49 --> Helper loaded: lang_helper
INFO - 2024-01-31 05:43:49 --> Helper loaded: security_helper
INFO - 2024-01-31 05:43:49 --> Helper loaded: cookie_helper
INFO - 2024-01-31 05:43:49 --> Database Driver Class Initialized
INFO - 2024-01-31 05:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-31 05:43:49 --> Parser Class Initialized
INFO - 2024-01-31 05:43:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-31 05:43:49 --> Pagination Class Initialized
INFO - 2024-01-31 05:43:49 --> Form Validation Class Initialized
INFO - 2024-01-31 05:43:49 --> Controller Class Initialized
INFO - 2024-01-31 05:43:49 --> Model Class Initialized
DEBUG - 2024-01-31 05:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:43:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-31 05:43:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-31 05:43:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-31 05:43:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-31 05:43:49 --> Model Class Initialized
INFO - 2024-01-31 05:43:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-31 05:43:49 --> Final output sent to browser
DEBUG - 2024-01-31 05:43:49 --> Total execution time: 0.0389
ERROR - 2024-01-31 08:23:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-31 08:23:18 --> Config Class Initialized
INFO - 2024-01-31 08:23:18 --> Hooks Class Initialized
DEBUG - 2024-01-31 08:23:18 --> UTF-8 Support Enabled
INFO - 2024-01-31 08:23:18 --> Utf8 Class Initialized
INFO - 2024-01-31 08:23:18 --> URI Class Initialized
DEBUG - 2024-01-31 08:23:18 --> No URI present. Default controller set.
INFO - 2024-01-31 08:23:18 --> Router Class Initialized
INFO - 2024-01-31 08:23:18 --> Output Class Initialized
INFO - 2024-01-31 08:23:18 --> Security Class Initialized
DEBUG - 2024-01-31 08:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-31 08:23:18 --> Input Class Initialized
INFO - 2024-01-31 08:23:18 --> Language Class Initialized
INFO - 2024-01-31 08:23:18 --> Loader Class Initialized
INFO - 2024-01-31 08:23:18 --> Helper loaded: url_helper
INFO - 2024-01-31 08:23:18 --> Helper loaded: file_helper
INFO - 2024-01-31 08:23:18 --> Helper loaded: html_helper
INFO - 2024-01-31 08:23:18 --> Helper loaded: text_helper
INFO - 2024-01-31 08:23:18 --> Helper loaded: form_helper
INFO - 2024-01-31 08:23:18 --> Helper loaded: lang_helper
INFO - 2024-01-31 08:23:18 --> Helper loaded: security_helper
INFO - 2024-01-31 08:23:18 --> Helper loaded: cookie_helper
INFO - 2024-01-31 08:23:18 --> Database Driver Class Initialized
INFO - 2024-01-31 08:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-31 08:23:18 --> Parser Class Initialized
INFO - 2024-01-31 08:23:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-31 08:23:18 --> Pagination Class Initialized
INFO - 2024-01-31 08:23:18 --> Form Validation Class Initialized
INFO - 2024-01-31 08:23:18 --> Controller Class Initialized
INFO - 2024-01-31 08:23:18 --> Model Class Initialized
DEBUG - 2024-01-31 08:23:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-31 16:04:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-31 16:04:14 --> Config Class Initialized
INFO - 2024-01-31 16:04:14 --> Hooks Class Initialized
DEBUG - 2024-01-31 16:04:14 --> UTF-8 Support Enabled
INFO - 2024-01-31 16:04:14 --> Utf8 Class Initialized
INFO - 2024-01-31 16:04:14 --> URI Class Initialized
INFO - 2024-01-31 16:04:14 --> Router Class Initialized
INFO - 2024-01-31 16:04:14 --> Output Class Initialized
INFO - 2024-01-31 16:04:14 --> Security Class Initialized
DEBUG - 2024-01-31 16:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-31 16:04:14 --> Input Class Initialized
INFO - 2024-01-31 16:04:14 --> Language Class Initialized
ERROR - 2024-01-31 16:04:14 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-01-31 16:37:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-31 16:37:42 --> Config Class Initialized
INFO - 2024-01-31 16:37:42 --> Hooks Class Initialized
DEBUG - 2024-01-31 16:37:42 --> UTF-8 Support Enabled
INFO - 2024-01-31 16:37:42 --> Utf8 Class Initialized
INFO - 2024-01-31 16:37:42 --> URI Class Initialized
INFO - 2024-01-31 16:37:42 --> Router Class Initialized
INFO - 2024-01-31 16:37:42 --> Output Class Initialized
INFO - 2024-01-31 16:37:42 --> Security Class Initialized
DEBUG - 2024-01-31 16:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-31 16:37:42 --> Input Class Initialized
INFO - 2024-01-31 16:37:42 --> Language Class Initialized
ERROR - 2024-01-31 16:37:42 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2024-01-31 19:17:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-31 19:17:46 --> Config Class Initialized
INFO - 2024-01-31 19:17:46 --> Hooks Class Initialized
DEBUG - 2024-01-31 19:17:46 --> UTF-8 Support Enabled
INFO - 2024-01-31 19:17:46 --> Utf8 Class Initialized
INFO - 2024-01-31 19:17:46 --> URI Class Initialized
DEBUG - 2024-01-31 19:17:46 --> No URI present. Default controller set.
INFO - 2024-01-31 19:17:46 --> Router Class Initialized
INFO - 2024-01-31 19:17:46 --> Output Class Initialized
INFO - 2024-01-31 19:17:46 --> Security Class Initialized
DEBUG - 2024-01-31 19:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-31 19:17:46 --> Input Class Initialized
INFO - 2024-01-31 19:17:46 --> Language Class Initialized
INFO - 2024-01-31 19:17:46 --> Loader Class Initialized
INFO - 2024-01-31 19:17:46 --> Helper loaded: url_helper
INFO - 2024-01-31 19:17:46 --> Helper loaded: file_helper
INFO - 2024-01-31 19:17:46 --> Helper loaded: html_helper
INFO - 2024-01-31 19:17:46 --> Helper loaded: text_helper
INFO - 2024-01-31 19:17:46 --> Helper loaded: form_helper
INFO - 2024-01-31 19:17:46 --> Helper loaded: lang_helper
INFO - 2024-01-31 19:17:46 --> Helper loaded: security_helper
INFO - 2024-01-31 19:17:46 --> Helper loaded: cookie_helper
INFO - 2024-01-31 19:17:46 --> Database Driver Class Initialized
INFO - 2024-01-31 19:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-31 19:17:46 --> Parser Class Initialized
INFO - 2024-01-31 19:17:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-31 19:17:46 --> Pagination Class Initialized
INFO - 2024-01-31 19:17:46 --> Form Validation Class Initialized
INFO - 2024-01-31 19:17:46 --> Controller Class Initialized
INFO - 2024-01-31 19:17:46 --> Model Class Initialized
DEBUG - 2024-01-31 19:17:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-01-31 19:17:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-01-31 19:17:49 --> Config Class Initialized
INFO - 2024-01-31 19:17:49 --> Hooks Class Initialized
DEBUG - 2024-01-31 19:17:49 --> UTF-8 Support Enabled
INFO - 2024-01-31 19:17:49 --> Utf8 Class Initialized
INFO - 2024-01-31 19:17:49 --> URI Class Initialized
INFO - 2024-01-31 19:17:49 --> Router Class Initialized
INFO - 2024-01-31 19:17:49 --> Output Class Initialized
INFO - 2024-01-31 19:17:49 --> Security Class Initialized
DEBUG - 2024-01-31 19:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-31 19:17:49 --> Input Class Initialized
INFO - 2024-01-31 19:17:49 --> Language Class Initialized
INFO - 2024-01-31 19:17:49 --> Loader Class Initialized
INFO - 2024-01-31 19:17:49 --> Helper loaded: url_helper
INFO - 2024-01-31 19:17:49 --> Helper loaded: file_helper
INFO - 2024-01-31 19:17:49 --> Helper loaded: html_helper
INFO - 2024-01-31 19:17:49 --> Helper loaded: text_helper
INFO - 2024-01-31 19:17:49 --> Helper loaded: form_helper
INFO - 2024-01-31 19:17:49 --> Helper loaded: lang_helper
INFO - 2024-01-31 19:17:49 --> Helper loaded: security_helper
INFO - 2024-01-31 19:17:49 --> Helper loaded: cookie_helper
INFO - 2024-01-31 19:17:49 --> Database Driver Class Initialized
INFO - 2024-01-31 19:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-31 19:17:49 --> Parser Class Initialized
INFO - 2024-01-31 19:17:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-01-31 19:17:49 --> Pagination Class Initialized
INFO - 2024-01-31 19:17:49 --> Form Validation Class Initialized
INFO - 2024-01-31 19:17:49 --> Controller Class Initialized
INFO - 2024-01-31 19:17:49 --> Model Class Initialized
DEBUG - 2024-01-31 19:17:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-01-31 19:17:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-01-31 19:17:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-01-31 19:17:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-01-31 19:17:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-01-31 19:17:49 --> Model Class Initialized
INFO - 2024-01-31 19:17:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-01-31 19:17:49 --> Final output sent to browser
DEBUG - 2024-01-31 19:17:49 --> Total execution time: 0.0328
