<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-16 04:23:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 04:23:40 --> Config Class Initialized
INFO - 2023-12-16 04:23:40 --> Hooks Class Initialized
DEBUG - 2023-12-16 04:23:40 --> UTF-8 Support Enabled
INFO - 2023-12-16 04:23:40 --> Utf8 Class Initialized
INFO - 2023-12-16 04:23:40 --> URI Class Initialized
DEBUG - 2023-12-16 04:23:40 --> No URI present. Default controller set.
INFO - 2023-12-16 04:23:40 --> Router Class Initialized
INFO - 2023-12-16 04:23:40 --> Output Class Initialized
INFO - 2023-12-16 04:23:40 --> Security Class Initialized
DEBUG - 2023-12-16 04:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 04:23:40 --> Input Class Initialized
INFO - 2023-12-16 04:23:40 --> Language Class Initialized
INFO - 2023-12-16 04:23:40 --> Loader Class Initialized
INFO - 2023-12-16 04:23:40 --> Helper loaded: url_helper
INFO - 2023-12-16 04:23:40 --> Helper loaded: file_helper
INFO - 2023-12-16 04:23:40 --> Helper loaded: html_helper
INFO - 2023-12-16 04:23:40 --> Helper loaded: text_helper
INFO - 2023-12-16 04:23:40 --> Helper loaded: form_helper
INFO - 2023-12-16 04:23:40 --> Helper loaded: lang_helper
INFO - 2023-12-16 04:23:40 --> Helper loaded: security_helper
INFO - 2023-12-16 04:23:40 --> Helper loaded: cookie_helper
INFO - 2023-12-16 04:23:40 --> Database Driver Class Initialized
INFO - 2023-12-16 04:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 04:23:40 --> Parser Class Initialized
INFO - 2023-12-16 04:23:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 04:23:40 --> Pagination Class Initialized
INFO - 2023-12-16 04:23:40 --> Form Validation Class Initialized
INFO - 2023-12-16 04:23:40 --> Controller Class Initialized
INFO - 2023-12-16 04:23:40 --> Model Class Initialized
DEBUG - 2023-12-16 04:23:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-16 04:23:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 04:23:40 --> Config Class Initialized
INFO - 2023-12-16 04:23:40 --> Hooks Class Initialized
DEBUG - 2023-12-16 04:23:40 --> UTF-8 Support Enabled
INFO - 2023-12-16 04:23:40 --> Utf8 Class Initialized
INFO - 2023-12-16 04:23:40 --> URI Class Initialized
DEBUG - 2023-12-16 04:23:40 --> No URI present. Default controller set.
INFO - 2023-12-16 04:23:40 --> Router Class Initialized
INFO - 2023-12-16 04:23:40 --> Output Class Initialized
INFO - 2023-12-16 04:23:40 --> Security Class Initialized
DEBUG - 2023-12-16 04:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 04:23:40 --> Input Class Initialized
INFO - 2023-12-16 04:23:40 --> Language Class Initialized
INFO - 2023-12-16 04:23:40 --> Loader Class Initialized
INFO - 2023-12-16 04:23:40 --> Helper loaded: url_helper
INFO - 2023-12-16 04:23:40 --> Helper loaded: file_helper
INFO - 2023-12-16 04:23:40 --> Helper loaded: html_helper
INFO - 2023-12-16 04:23:40 --> Helper loaded: text_helper
INFO - 2023-12-16 04:23:40 --> Helper loaded: form_helper
INFO - 2023-12-16 04:23:40 --> Helper loaded: lang_helper
INFO - 2023-12-16 04:23:40 --> Helper loaded: security_helper
INFO - 2023-12-16 04:23:40 --> Helper loaded: cookie_helper
INFO - 2023-12-16 04:23:40 --> Database Driver Class Initialized
INFO - 2023-12-16 04:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 04:23:40 --> Parser Class Initialized
INFO - 2023-12-16 04:23:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 04:23:40 --> Pagination Class Initialized
INFO - 2023-12-16 04:23:40 --> Form Validation Class Initialized
INFO - 2023-12-16 04:23:40 --> Controller Class Initialized
INFO - 2023-12-16 04:23:40 --> Model Class Initialized
DEBUG - 2023-12-16 04:23:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-16 04:23:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 04:23:41 --> Config Class Initialized
INFO - 2023-12-16 04:23:41 --> Hooks Class Initialized
DEBUG - 2023-12-16 04:23:41 --> UTF-8 Support Enabled
INFO - 2023-12-16 04:23:41 --> Utf8 Class Initialized
INFO - 2023-12-16 04:23:41 --> URI Class Initialized
DEBUG - 2023-12-16 04:23:41 --> No URI present. Default controller set.
INFO - 2023-12-16 04:23:41 --> Router Class Initialized
INFO - 2023-12-16 04:23:41 --> Output Class Initialized
INFO - 2023-12-16 04:23:41 --> Security Class Initialized
DEBUG - 2023-12-16 04:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 04:23:41 --> Input Class Initialized
INFO - 2023-12-16 04:23:41 --> Language Class Initialized
INFO - 2023-12-16 04:23:41 --> Loader Class Initialized
INFO - 2023-12-16 04:23:41 --> Helper loaded: url_helper
INFO - 2023-12-16 04:23:41 --> Helper loaded: file_helper
INFO - 2023-12-16 04:23:41 --> Helper loaded: html_helper
INFO - 2023-12-16 04:23:41 --> Helper loaded: text_helper
INFO - 2023-12-16 04:23:41 --> Helper loaded: form_helper
INFO - 2023-12-16 04:23:41 --> Helper loaded: lang_helper
INFO - 2023-12-16 04:23:41 --> Helper loaded: security_helper
INFO - 2023-12-16 04:23:41 --> Helper loaded: cookie_helper
INFO - 2023-12-16 04:23:41 --> Database Driver Class Initialized
INFO - 2023-12-16 04:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 04:23:41 --> Parser Class Initialized
INFO - 2023-12-16 04:23:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 04:23:41 --> Pagination Class Initialized
INFO - 2023-12-16 04:23:41 --> Form Validation Class Initialized
INFO - 2023-12-16 04:23:41 --> Controller Class Initialized
INFO - 2023-12-16 04:23:41 --> Model Class Initialized
DEBUG - 2023-12-16 04:23:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-16 04:23:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 04:23:41 --> Config Class Initialized
INFO - 2023-12-16 04:23:41 --> Hooks Class Initialized
DEBUG - 2023-12-16 04:23:41 --> UTF-8 Support Enabled
INFO - 2023-12-16 04:23:41 --> Utf8 Class Initialized
INFO - 2023-12-16 04:23:41 --> URI Class Initialized
DEBUG - 2023-12-16 04:23:41 --> No URI present. Default controller set.
INFO - 2023-12-16 04:23:41 --> Router Class Initialized
INFO - 2023-12-16 04:23:41 --> Output Class Initialized
INFO - 2023-12-16 04:23:41 --> Security Class Initialized
DEBUG - 2023-12-16 04:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 04:23:41 --> Input Class Initialized
INFO - 2023-12-16 04:23:41 --> Language Class Initialized
INFO - 2023-12-16 04:23:41 --> Loader Class Initialized
INFO - 2023-12-16 04:23:41 --> Helper loaded: url_helper
INFO - 2023-12-16 04:23:41 --> Helper loaded: file_helper
INFO - 2023-12-16 04:23:41 --> Helper loaded: html_helper
INFO - 2023-12-16 04:23:41 --> Helper loaded: text_helper
INFO - 2023-12-16 04:23:41 --> Helper loaded: form_helper
INFO - 2023-12-16 04:23:41 --> Helper loaded: lang_helper
INFO - 2023-12-16 04:23:41 --> Helper loaded: security_helper
INFO - 2023-12-16 04:23:41 --> Helper loaded: cookie_helper
INFO - 2023-12-16 04:23:41 --> Database Driver Class Initialized
INFO - 2023-12-16 04:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 04:23:41 --> Parser Class Initialized
INFO - 2023-12-16 04:23:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 04:23:41 --> Pagination Class Initialized
INFO - 2023-12-16 04:23:41 --> Form Validation Class Initialized
INFO - 2023-12-16 04:23:41 --> Controller Class Initialized
INFO - 2023-12-16 04:23:41 --> Model Class Initialized
DEBUG - 2023-12-16 04:23:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-16 05:19:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 05:19:26 --> Config Class Initialized
INFO - 2023-12-16 05:19:26 --> Hooks Class Initialized
DEBUG - 2023-12-16 05:19:26 --> UTF-8 Support Enabled
INFO - 2023-12-16 05:19:26 --> Utf8 Class Initialized
INFO - 2023-12-16 05:19:26 --> URI Class Initialized
DEBUG - 2023-12-16 05:19:26 --> No URI present. Default controller set.
INFO - 2023-12-16 05:19:26 --> Router Class Initialized
INFO - 2023-12-16 05:19:26 --> Output Class Initialized
INFO - 2023-12-16 05:19:26 --> Security Class Initialized
DEBUG - 2023-12-16 05:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 05:19:26 --> Input Class Initialized
INFO - 2023-12-16 05:19:26 --> Language Class Initialized
INFO - 2023-12-16 05:19:26 --> Loader Class Initialized
INFO - 2023-12-16 05:19:26 --> Helper loaded: url_helper
INFO - 2023-12-16 05:19:26 --> Helper loaded: file_helper
INFO - 2023-12-16 05:19:26 --> Helper loaded: html_helper
INFO - 2023-12-16 05:19:26 --> Helper loaded: text_helper
INFO - 2023-12-16 05:19:26 --> Helper loaded: form_helper
INFO - 2023-12-16 05:19:26 --> Helper loaded: lang_helper
INFO - 2023-12-16 05:19:26 --> Helper loaded: security_helper
INFO - 2023-12-16 05:19:26 --> Helper loaded: cookie_helper
INFO - 2023-12-16 05:19:26 --> Database Driver Class Initialized
INFO - 2023-12-16 05:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 05:19:26 --> Parser Class Initialized
INFO - 2023-12-16 05:19:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 05:19:26 --> Pagination Class Initialized
INFO - 2023-12-16 05:19:26 --> Form Validation Class Initialized
INFO - 2023-12-16 05:19:26 --> Controller Class Initialized
INFO - 2023-12-16 05:19:26 --> Model Class Initialized
DEBUG - 2023-12-16 05:19:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-16 05:19:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 05:19:27 --> Config Class Initialized
INFO - 2023-12-16 05:19:27 --> Hooks Class Initialized
DEBUG - 2023-12-16 05:19:27 --> UTF-8 Support Enabled
INFO - 2023-12-16 05:19:27 --> Utf8 Class Initialized
INFO - 2023-12-16 05:19:27 --> URI Class Initialized
INFO - 2023-12-16 05:19:27 --> Router Class Initialized
INFO - 2023-12-16 05:19:27 --> Output Class Initialized
INFO - 2023-12-16 05:19:27 --> Security Class Initialized
DEBUG - 2023-12-16 05:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 05:19:27 --> Input Class Initialized
INFO - 2023-12-16 05:19:27 --> Language Class Initialized
INFO - 2023-12-16 05:19:27 --> Loader Class Initialized
INFO - 2023-12-16 05:19:27 --> Helper loaded: url_helper
INFO - 2023-12-16 05:19:27 --> Helper loaded: file_helper
INFO - 2023-12-16 05:19:27 --> Helper loaded: html_helper
INFO - 2023-12-16 05:19:27 --> Helper loaded: text_helper
INFO - 2023-12-16 05:19:27 --> Helper loaded: form_helper
INFO - 2023-12-16 05:19:27 --> Helper loaded: lang_helper
INFO - 2023-12-16 05:19:27 --> Helper loaded: security_helper
INFO - 2023-12-16 05:19:27 --> Helper loaded: cookie_helper
INFO - 2023-12-16 05:19:27 --> Database Driver Class Initialized
INFO - 2023-12-16 05:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 05:19:27 --> Parser Class Initialized
INFO - 2023-12-16 05:19:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 05:19:27 --> Pagination Class Initialized
INFO - 2023-12-16 05:19:27 --> Form Validation Class Initialized
INFO - 2023-12-16 05:19:27 --> Controller Class Initialized
INFO - 2023-12-16 05:19:27 --> Model Class Initialized
DEBUG - 2023-12-16 05:19:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 05:19:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-16 05:19:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-16 05:19:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-16 05:19:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-16 05:19:27 --> Model Class Initialized
INFO - 2023-12-16 05:19:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-16 05:19:27 --> Final output sent to browser
DEBUG - 2023-12-16 05:19:27 --> Total execution time: 0.0302
ERROR - 2023-12-16 05:40:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 05:40:10 --> Config Class Initialized
INFO - 2023-12-16 05:40:10 --> Hooks Class Initialized
DEBUG - 2023-12-16 05:40:10 --> UTF-8 Support Enabled
INFO - 2023-12-16 05:40:10 --> Utf8 Class Initialized
INFO - 2023-12-16 05:40:10 --> URI Class Initialized
DEBUG - 2023-12-16 05:40:10 --> No URI present. Default controller set.
INFO - 2023-12-16 05:40:10 --> Router Class Initialized
INFO - 2023-12-16 05:40:10 --> Output Class Initialized
INFO - 2023-12-16 05:40:10 --> Security Class Initialized
DEBUG - 2023-12-16 05:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 05:40:10 --> Input Class Initialized
INFO - 2023-12-16 05:40:10 --> Language Class Initialized
INFO - 2023-12-16 05:40:10 --> Loader Class Initialized
INFO - 2023-12-16 05:40:10 --> Helper loaded: url_helper
INFO - 2023-12-16 05:40:10 --> Helper loaded: file_helper
INFO - 2023-12-16 05:40:10 --> Helper loaded: html_helper
INFO - 2023-12-16 05:40:10 --> Helper loaded: text_helper
INFO - 2023-12-16 05:40:10 --> Helper loaded: form_helper
INFO - 2023-12-16 05:40:10 --> Helper loaded: lang_helper
INFO - 2023-12-16 05:40:10 --> Helper loaded: security_helper
INFO - 2023-12-16 05:40:10 --> Helper loaded: cookie_helper
INFO - 2023-12-16 05:40:10 --> Database Driver Class Initialized
INFO - 2023-12-16 05:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 05:40:10 --> Parser Class Initialized
INFO - 2023-12-16 05:40:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 05:40:10 --> Pagination Class Initialized
INFO - 2023-12-16 05:40:10 --> Form Validation Class Initialized
INFO - 2023-12-16 05:40:10 --> Controller Class Initialized
INFO - 2023-12-16 05:40:10 --> Model Class Initialized
DEBUG - 2023-12-16 05:40:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-16 05:40:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 05:40:11 --> Config Class Initialized
INFO - 2023-12-16 05:40:11 --> Hooks Class Initialized
DEBUG - 2023-12-16 05:40:11 --> UTF-8 Support Enabled
INFO - 2023-12-16 05:40:11 --> Utf8 Class Initialized
INFO - 2023-12-16 05:40:11 --> URI Class Initialized
INFO - 2023-12-16 05:40:11 --> Router Class Initialized
INFO - 2023-12-16 05:40:11 --> Output Class Initialized
INFO - 2023-12-16 05:40:11 --> Security Class Initialized
DEBUG - 2023-12-16 05:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 05:40:11 --> Input Class Initialized
INFO - 2023-12-16 05:40:11 --> Language Class Initialized
INFO - 2023-12-16 05:40:11 --> Loader Class Initialized
INFO - 2023-12-16 05:40:11 --> Helper loaded: url_helper
INFO - 2023-12-16 05:40:11 --> Helper loaded: file_helper
INFO - 2023-12-16 05:40:11 --> Helper loaded: html_helper
INFO - 2023-12-16 05:40:11 --> Helper loaded: text_helper
INFO - 2023-12-16 05:40:11 --> Helper loaded: form_helper
INFO - 2023-12-16 05:40:11 --> Helper loaded: lang_helper
INFO - 2023-12-16 05:40:11 --> Helper loaded: security_helper
INFO - 2023-12-16 05:40:11 --> Helper loaded: cookie_helper
INFO - 2023-12-16 05:40:11 --> Database Driver Class Initialized
INFO - 2023-12-16 05:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 05:40:11 --> Parser Class Initialized
INFO - 2023-12-16 05:40:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 05:40:11 --> Pagination Class Initialized
INFO - 2023-12-16 05:40:11 --> Form Validation Class Initialized
INFO - 2023-12-16 05:40:11 --> Controller Class Initialized
INFO - 2023-12-16 05:40:11 --> Model Class Initialized
DEBUG - 2023-12-16 05:40:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 05:40:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-16 05:40:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-16 05:40:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-16 05:40:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-16 05:40:11 --> Model Class Initialized
INFO - 2023-12-16 05:40:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-16 05:40:11 --> Final output sent to browser
DEBUG - 2023-12-16 05:40:11 --> Total execution time: 0.0297
ERROR - 2023-12-16 05:40:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 05:40:16 --> Config Class Initialized
INFO - 2023-12-16 05:40:16 --> Hooks Class Initialized
DEBUG - 2023-12-16 05:40:16 --> UTF-8 Support Enabled
INFO - 2023-12-16 05:40:16 --> Utf8 Class Initialized
INFO - 2023-12-16 05:40:16 --> URI Class Initialized
INFO - 2023-12-16 05:40:16 --> Router Class Initialized
INFO - 2023-12-16 05:40:16 --> Output Class Initialized
INFO - 2023-12-16 05:40:16 --> Security Class Initialized
DEBUG - 2023-12-16 05:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 05:40:16 --> Input Class Initialized
INFO - 2023-12-16 05:40:16 --> Language Class Initialized
INFO - 2023-12-16 05:40:16 --> Loader Class Initialized
INFO - 2023-12-16 05:40:16 --> Helper loaded: url_helper
INFO - 2023-12-16 05:40:16 --> Helper loaded: file_helper
INFO - 2023-12-16 05:40:16 --> Helper loaded: html_helper
INFO - 2023-12-16 05:40:16 --> Helper loaded: text_helper
INFO - 2023-12-16 05:40:16 --> Helper loaded: form_helper
INFO - 2023-12-16 05:40:16 --> Helper loaded: lang_helper
INFO - 2023-12-16 05:40:16 --> Helper loaded: security_helper
INFO - 2023-12-16 05:40:16 --> Helper loaded: cookie_helper
INFO - 2023-12-16 05:40:16 --> Database Driver Class Initialized
INFO - 2023-12-16 05:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 05:40:16 --> Parser Class Initialized
INFO - 2023-12-16 05:40:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 05:40:16 --> Pagination Class Initialized
INFO - 2023-12-16 05:40:16 --> Form Validation Class Initialized
INFO - 2023-12-16 05:40:16 --> Controller Class Initialized
INFO - 2023-12-16 05:40:16 --> Model Class Initialized
DEBUG - 2023-12-16 05:40:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 05:40:16 --> Model Class Initialized
INFO - 2023-12-16 05:40:16 --> Final output sent to browser
DEBUG - 2023-12-16 05:40:16 --> Total execution time: 0.0207
ERROR - 2023-12-16 05:40:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 05:40:16 --> Config Class Initialized
INFO - 2023-12-16 05:40:16 --> Hooks Class Initialized
DEBUG - 2023-12-16 05:40:16 --> UTF-8 Support Enabled
INFO - 2023-12-16 05:40:16 --> Utf8 Class Initialized
INFO - 2023-12-16 05:40:16 --> URI Class Initialized
DEBUG - 2023-12-16 05:40:16 --> No URI present. Default controller set.
INFO - 2023-12-16 05:40:16 --> Router Class Initialized
INFO - 2023-12-16 05:40:16 --> Output Class Initialized
INFO - 2023-12-16 05:40:16 --> Security Class Initialized
DEBUG - 2023-12-16 05:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 05:40:16 --> Input Class Initialized
INFO - 2023-12-16 05:40:16 --> Language Class Initialized
INFO - 2023-12-16 05:40:16 --> Loader Class Initialized
INFO - 2023-12-16 05:40:16 --> Helper loaded: url_helper
INFO - 2023-12-16 05:40:16 --> Helper loaded: file_helper
INFO - 2023-12-16 05:40:16 --> Helper loaded: html_helper
INFO - 2023-12-16 05:40:16 --> Helper loaded: text_helper
INFO - 2023-12-16 05:40:16 --> Helper loaded: form_helper
INFO - 2023-12-16 05:40:16 --> Helper loaded: lang_helper
INFO - 2023-12-16 05:40:16 --> Helper loaded: security_helper
INFO - 2023-12-16 05:40:16 --> Helper loaded: cookie_helper
INFO - 2023-12-16 05:40:16 --> Database Driver Class Initialized
INFO - 2023-12-16 05:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 05:40:16 --> Parser Class Initialized
INFO - 2023-12-16 05:40:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 05:40:16 --> Pagination Class Initialized
INFO - 2023-12-16 05:40:16 --> Form Validation Class Initialized
INFO - 2023-12-16 05:40:16 --> Controller Class Initialized
INFO - 2023-12-16 05:40:16 --> Model Class Initialized
DEBUG - 2023-12-16 05:40:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 05:40:16 --> Model Class Initialized
DEBUG - 2023-12-16 05:40:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 05:40:16 --> Model Class Initialized
INFO - 2023-12-16 05:40:16 --> Model Class Initialized
INFO - 2023-12-16 05:40:16 --> Model Class Initialized
INFO - 2023-12-16 05:40:16 --> Model Class Initialized
DEBUG - 2023-12-16 05:40:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 05:40:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 05:40:16 --> Model Class Initialized
INFO - 2023-12-16 05:40:16 --> Model Class Initialized
INFO - 2023-12-16 05:40:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-16 05:40:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-16 05:40:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-16 05:40:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-16 05:40:17 --> Model Class Initialized
INFO - 2023-12-16 05:40:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-16 05:40:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-16 05:40:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-16 05:40:17 --> Final output sent to browser
DEBUG - 2023-12-16 05:40:17 --> Total execution time: 0.3722
ERROR - 2023-12-16 05:40:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 05:40:18 --> Config Class Initialized
INFO - 2023-12-16 05:40:18 --> Hooks Class Initialized
DEBUG - 2023-12-16 05:40:18 --> UTF-8 Support Enabled
INFO - 2023-12-16 05:40:18 --> Utf8 Class Initialized
INFO - 2023-12-16 05:40:18 --> URI Class Initialized
INFO - 2023-12-16 05:40:18 --> Router Class Initialized
INFO - 2023-12-16 05:40:18 --> Output Class Initialized
INFO - 2023-12-16 05:40:18 --> Security Class Initialized
DEBUG - 2023-12-16 05:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 05:40:18 --> Input Class Initialized
INFO - 2023-12-16 05:40:18 --> Language Class Initialized
INFO - 2023-12-16 05:40:18 --> Loader Class Initialized
INFO - 2023-12-16 05:40:18 --> Helper loaded: url_helper
INFO - 2023-12-16 05:40:18 --> Helper loaded: file_helper
INFO - 2023-12-16 05:40:18 --> Helper loaded: html_helper
INFO - 2023-12-16 05:40:18 --> Helper loaded: text_helper
INFO - 2023-12-16 05:40:18 --> Helper loaded: form_helper
INFO - 2023-12-16 05:40:18 --> Helper loaded: lang_helper
INFO - 2023-12-16 05:40:18 --> Helper loaded: security_helper
INFO - 2023-12-16 05:40:18 --> Helper loaded: cookie_helper
INFO - 2023-12-16 05:40:18 --> Database Driver Class Initialized
INFO - 2023-12-16 05:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 05:40:18 --> Parser Class Initialized
INFO - 2023-12-16 05:40:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 05:40:18 --> Pagination Class Initialized
INFO - 2023-12-16 05:40:18 --> Form Validation Class Initialized
INFO - 2023-12-16 05:40:18 --> Controller Class Initialized
DEBUG - 2023-12-16 05:40:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 05:40:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 05:40:18 --> Model Class Initialized
INFO - 2023-12-16 05:40:18 --> Final output sent to browser
DEBUG - 2023-12-16 05:40:18 --> Total execution time: 0.0135
ERROR - 2023-12-16 05:40:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 05:40:23 --> Config Class Initialized
INFO - 2023-12-16 05:40:23 --> Hooks Class Initialized
DEBUG - 2023-12-16 05:40:23 --> UTF-8 Support Enabled
INFO - 2023-12-16 05:40:23 --> Utf8 Class Initialized
INFO - 2023-12-16 05:40:23 --> URI Class Initialized
INFO - 2023-12-16 05:40:23 --> Router Class Initialized
INFO - 2023-12-16 05:40:23 --> Output Class Initialized
INFO - 2023-12-16 05:40:23 --> Security Class Initialized
DEBUG - 2023-12-16 05:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 05:40:23 --> Input Class Initialized
INFO - 2023-12-16 05:40:23 --> Language Class Initialized
INFO - 2023-12-16 05:40:23 --> Loader Class Initialized
INFO - 2023-12-16 05:40:23 --> Helper loaded: url_helper
INFO - 2023-12-16 05:40:23 --> Helper loaded: file_helper
INFO - 2023-12-16 05:40:23 --> Helper loaded: html_helper
INFO - 2023-12-16 05:40:23 --> Helper loaded: text_helper
INFO - 2023-12-16 05:40:23 --> Helper loaded: form_helper
INFO - 2023-12-16 05:40:23 --> Helper loaded: lang_helper
INFO - 2023-12-16 05:40:23 --> Helper loaded: security_helper
INFO - 2023-12-16 05:40:23 --> Helper loaded: cookie_helper
INFO - 2023-12-16 05:40:23 --> Database Driver Class Initialized
INFO - 2023-12-16 05:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 05:40:23 --> Parser Class Initialized
INFO - 2023-12-16 05:40:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 05:40:23 --> Pagination Class Initialized
INFO - 2023-12-16 05:40:23 --> Form Validation Class Initialized
INFO - 2023-12-16 05:40:23 --> Controller Class Initialized
DEBUG - 2023-12-16 05:40:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 05:40:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 05:40:23 --> Model Class Initialized
INFO - 2023-12-16 05:40:23 --> Model Class Initialized
DEBUG - 2023-12-16 05:40:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 05:40:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 05:40:23 --> Model Class Initialized
DEBUG - 2023-12-16 05:40:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 05:40:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gst/list.php
DEBUG - 2023-12-16 05:40:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-16 05:40:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-16 05:40:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-16 05:40:23 --> Model Class Initialized
INFO - 2023-12-16 05:40:23 --> Model Class Initialized
INFO - 2023-12-16 05:40:23 --> Model Class Initialized
INFO - 2023-12-16 05:40:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-16 05:40:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-16 05:40:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-16 05:40:23 --> Final output sent to browser
DEBUG - 2023-12-16 05:40:23 --> Total execution time: 0.1987
ERROR - 2023-12-16 05:40:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 05:40:33 --> Config Class Initialized
INFO - 2023-12-16 05:40:33 --> Hooks Class Initialized
DEBUG - 2023-12-16 05:40:33 --> UTF-8 Support Enabled
INFO - 2023-12-16 05:40:33 --> Utf8 Class Initialized
INFO - 2023-12-16 05:40:33 --> URI Class Initialized
INFO - 2023-12-16 05:40:33 --> Router Class Initialized
INFO - 2023-12-16 05:40:33 --> Output Class Initialized
INFO - 2023-12-16 05:40:33 --> Security Class Initialized
DEBUG - 2023-12-16 05:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 05:40:33 --> Input Class Initialized
INFO - 2023-12-16 05:40:33 --> Language Class Initialized
INFO - 2023-12-16 05:40:33 --> Loader Class Initialized
INFO - 2023-12-16 05:40:33 --> Helper loaded: url_helper
INFO - 2023-12-16 05:40:33 --> Helper loaded: file_helper
INFO - 2023-12-16 05:40:33 --> Helper loaded: html_helper
INFO - 2023-12-16 05:40:33 --> Helper loaded: text_helper
INFO - 2023-12-16 05:40:33 --> Helper loaded: form_helper
INFO - 2023-12-16 05:40:33 --> Helper loaded: lang_helper
INFO - 2023-12-16 05:40:33 --> Helper loaded: security_helper
INFO - 2023-12-16 05:40:33 --> Helper loaded: cookie_helper
INFO - 2023-12-16 05:40:33 --> Database Driver Class Initialized
INFO - 2023-12-16 05:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 05:40:33 --> Parser Class Initialized
INFO - 2023-12-16 05:40:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 05:40:33 --> Pagination Class Initialized
INFO - 2023-12-16 05:40:33 --> Form Validation Class Initialized
INFO - 2023-12-16 05:40:33 --> Controller Class Initialized
DEBUG - 2023-12-16 05:40:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 05:40:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 05:40:33 --> Model Class Initialized
DEBUG - 2023-12-16 05:40:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 05:40:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 05:40:33 --> Model Class Initialized
DEBUG - 2023-12-16 05:40:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 05:40:33 --> Model Class Initialized
INFO - 2023-12-16 05:40:33 --> Final output sent to browser
DEBUG - 2023-12-16 05:40:33 --> Total execution time: 0.0350
ERROR - 2023-12-16 05:47:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 05:47:23 --> Config Class Initialized
INFO - 2023-12-16 05:47:23 --> Hooks Class Initialized
DEBUG - 2023-12-16 05:47:23 --> UTF-8 Support Enabled
INFO - 2023-12-16 05:47:23 --> Utf8 Class Initialized
INFO - 2023-12-16 05:47:23 --> URI Class Initialized
INFO - 2023-12-16 05:47:23 --> Router Class Initialized
INFO - 2023-12-16 05:47:23 --> Output Class Initialized
INFO - 2023-12-16 05:47:23 --> Security Class Initialized
DEBUG - 2023-12-16 05:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 05:47:23 --> Input Class Initialized
INFO - 2023-12-16 05:47:23 --> Language Class Initialized
ERROR - 2023-12-16 05:47:23 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-12-16 06:04:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 06:04:42 --> Config Class Initialized
INFO - 2023-12-16 06:04:42 --> Hooks Class Initialized
DEBUG - 2023-12-16 06:04:42 --> UTF-8 Support Enabled
INFO - 2023-12-16 06:04:42 --> Utf8 Class Initialized
INFO - 2023-12-16 06:04:42 --> URI Class Initialized
DEBUG - 2023-12-16 06:04:42 --> No URI present. Default controller set.
INFO - 2023-12-16 06:04:42 --> Router Class Initialized
INFO - 2023-12-16 06:04:42 --> Output Class Initialized
INFO - 2023-12-16 06:04:42 --> Security Class Initialized
DEBUG - 2023-12-16 06:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 06:04:42 --> Input Class Initialized
INFO - 2023-12-16 06:04:42 --> Language Class Initialized
INFO - 2023-12-16 06:04:42 --> Loader Class Initialized
INFO - 2023-12-16 06:04:42 --> Helper loaded: url_helper
INFO - 2023-12-16 06:04:42 --> Helper loaded: file_helper
INFO - 2023-12-16 06:04:42 --> Helper loaded: html_helper
INFO - 2023-12-16 06:04:42 --> Helper loaded: text_helper
INFO - 2023-12-16 06:04:42 --> Helper loaded: form_helper
INFO - 2023-12-16 06:04:42 --> Helper loaded: lang_helper
INFO - 2023-12-16 06:04:42 --> Helper loaded: security_helper
INFO - 2023-12-16 06:04:42 --> Helper loaded: cookie_helper
INFO - 2023-12-16 06:04:42 --> Database Driver Class Initialized
INFO - 2023-12-16 06:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 06:04:42 --> Parser Class Initialized
INFO - 2023-12-16 06:04:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 06:04:42 --> Pagination Class Initialized
INFO - 2023-12-16 06:04:42 --> Form Validation Class Initialized
INFO - 2023-12-16 06:04:42 --> Controller Class Initialized
INFO - 2023-12-16 06:04:42 --> Model Class Initialized
DEBUG - 2023-12-16 06:04:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 06:04:42 --> Model Class Initialized
DEBUG - 2023-12-16 06:04:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 06:04:42 --> Model Class Initialized
INFO - 2023-12-16 06:04:42 --> Model Class Initialized
INFO - 2023-12-16 06:04:42 --> Model Class Initialized
INFO - 2023-12-16 06:04:42 --> Model Class Initialized
DEBUG - 2023-12-16 06:04:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 06:04:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 06:04:42 --> Model Class Initialized
INFO - 2023-12-16 06:04:42 --> Model Class Initialized
INFO - 2023-12-16 06:04:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-16 06:04:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-16 06:04:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-16 06:04:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-16 06:04:42 --> Model Class Initialized
INFO - 2023-12-16 06:04:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-16 06:04:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-16 06:04:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-16 06:04:42 --> Final output sent to browser
DEBUG - 2023-12-16 06:04:42 --> Total execution time: 0.3936
ERROR - 2023-12-16 07:17:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 07:17:11 --> Config Class Initialized
INFO - 2023-12-16 07:17:11 --> Hooks Class Initialized
DEBUG - 2023-12-16 07:17:11 --> UTF-8 Support Enabled
INFO - 2023-12-16 07:17:11 --> Utf8 Class Initialized
INFO - 2023-12-16 07:17:11 --> URI Class Initialized
DEBUG - 2023-12-16 07:17:11 --> No URI present. Default controller set.
INFO - 2023-12-16 07:17:11 --> Router Class Initialized
INFO - 2023-12-16 07:17:11 --> Output Class Initialized
INFO - 2023-12-16 07:17:11 --> Security Class Initialized
DEBUG - 2023-12-16 07:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 07:17:11 --> Input Class Initialized
INFO - 2023-12-16 07:17:11 --> Language Class Initialized
INFO - 2023-12-16 07:17:11 --> Loader Class Initialized
INFO - 2023-12-16 07:17:11 --> Helper loaded: url_helper
INFO - 2023-12-16 07:17:11 --> Helper loaded: file_helper
INFO - 2023-12-16 07:17:11 --> Helper loaded: html_helper
INFO - 2023-12-16 07:17:11 --> Helper loaded: text_helper
INFO - 2023-12-16 07:17:11 --> Helper loaded: form_helper
INFO - 2023-12-16 07:17:11 --> Helper loaded: lang_helper
INFO - 2023-12-16 07:17:11 --> Helper loaded: security_helper
INFO - 2023-12-16 07:17:11 --> Helper loaded: cookie_helper
INFO - 2023-12-16 07:17:11 --> Database Driver Class Initialized
INFO - 2023-12-16 07:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 07:17:11 --> Parser Class Initialized
INFO - 2023-12-16 07:17:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 07:17:11 --> Pagination Class Initialized
INFO - 2023-12-16 07:17:11 --> Form Validation Class Initialized
INFO - 2023-12-16 07:17:11 --> Controller Class Initialized
INFO - 2023-12-16 07:17:11 --> Model Class Initialized
DEBUG - 2023-12-16 07:17:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 07:17:11 --> Model Class Initialized
DEBUG - 2023-12-16 07:17:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 07:17:11 --> Model Class Initialized
INFO - 2023-12-16 07:17:11 --> Model Class Initialized
INFO - 2023-12-16 07:17:11 --> Model Class Initialized
INFO - 2023-12-16 07:17:11 --> Model Class Initialized
DEBUG - 2023-12-16 07:17:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 07:17:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 07:17:11 --> Model Class Initialized
INFO - 2023-12-16 07:17:11 --> Model Class Initialized
INFO - 2023-12-16 07:17:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-16 07:17:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-16 07:17:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-16 07:17:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-16 07:17:11 --> Model Class Initialized
INFO - 2023-12-16 07:17:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-16 07:17:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-16 07:17:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-16 07:17:11 --> Final output sent to browser
DEBUG - 2023-12-16 07:17:11 --> Total execution time: 0.3809
ERROR - 2023-12-16 13:17:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 13:17:34 --> Config Class Initialized
INFO - 2023-12-16 13:17:34 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:17:34 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:17:34 --> Utf8 Class Initialized
INFO - 2023-12-16 13:17:34 --> URI Class Initialized
INFO - 2023-12-16 13:17:34 --> Router Class Initialized
INFO - 2023-12-16 13:17:34 --> Output Class Initialized
INFO - 2023-12-16 13:17:34 --> Security Class Initialized
DEBUG - 2023-12-16 13:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:17:34 --> Input Class Initialized
INFO - 2023-12-16 13:17:34 --> Language Class Initialized
ERROR - 2023-12-16 13:17:34 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-12-16 14:05:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
ERROR - 2023-12-16 14:05:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 14:05:56 --> Config Class Initialized
INFO - 2023-12-16 14:05:56 --> Hooks Class Initialized
INFO - 2023-12-16 14:05:56 --> Config Class Initialized
INFO - 2023-12-16 14:05:56 --> Hooks Class Initialized
DEBUG - 2023-12-16 14:05:56 --> UTF-8 Support Enabled
INFO - 2023-12-16 14:05:56 --> Utf8 Class Initialized
DEBUG - 2023-12-16 14:05:56 --> UTF-8 Support Enabled
INFO - 2023-12-16 14:05:56 --> Utf8 Class Initialized
INFO - 2023-12-16 14:05:56 --> URI Class Initialized
INFO - 2023-12-16 14:05:56 --> URI Class Initialized
INFO - 2023-12-16 14:05:56 --> Router Class Initialized
INFO - 2023-12-16 14:05:56 --> Router Class Initialized
INFO - 2023-12-16 14:05:56 --> Output Class Initialized
INFO - 2023-12-16 14:05:56 --> Output Class Initialized
INFO - 2023-12-16 14:05:56 --> Security Class Initialized
INFO - 2023-12-16 14:05:56 --> Security Class Initialized
DEBUG - 2023-12-16 14:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-12-16 14:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 14:05:56 --> Input Class Initialized
INFO - 2023-12-16 14:05:56 --> Input Class Initialized
INFO - 2023-12-16 14:05:56 --> Language Class Initialized
ERROR - 2023-12-16 14:05:56 --> 404 Page Not Found: Wp-content/plugins
INFO - 2023-12-16 14:05:56 --> Language Class Initialized
ERROR - 2023-12-16 14:05:56 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2023-12-16 14:05:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 14:05:56 --> Config Class Initialized
INFO - 2023-12-16 14:05:56 --> Hooks Class Initialized
DEBUG - 2023-12-16 14:05:56 --> UTF-8 Support Enabled
INFO - 2023-12-16 14:05:56 --> Utf8 Class Initialized
INFO - 2023-12-16 14:05:56 --> URI Class Initialized
INFO - 2023-12-16 14:05:56 --> Router Class Initialized
INFO - 2023-12-16 14:05:56 --> Output Class Initialized
INFO - 2023-12-16 14:05:56 --> Security Class Initialized
DEBUG - 2023-12-16 14:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 14:05:56 --> Input Class Initialized
INFO - 2023-12-16 14:05:56 --> Language Class Initialized
ERROR - 2023-12-16 14:05:56 --> 404 Page Not Found: Wp-includes/js
ERROR - 2023-12-16 14:05:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 14:05:56 --> Config Class Initialized
INFO - 2023-12-16 14:05:56 --> Hooks Class Initialized
DEBUG - 2023-12-16 14:05:56 --> UTF-8 Support Enabled
INFO - 2023-12-16 14:05:56 --> Utf8 Class Initialized
INFO - 2023-12-16 14:05:56 --> URI Class Initialized
INFO - 2023-12-16 14:05:56 --> Router Class Initialized
INFO - 2023-12-16 14:05:56 --> Output Class Initialized
INFO - 2023-12-16 14:05:56 --> Security Class Initialized
DEBUG - 2023-12-16 14:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 14:05:56 --> Input Class Initialized
INFO - 2023-12-16 14:05:56 --> Language Class Initialized
ERROR - 2023-12-16 14:05:56 --> 404 Page Not Found: Magento_version/index
ERROR - 2023-12-16 15:32:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 15:32:59 --> Config Class Initialized
INFO - 2023-12-16 15:32:59 --> Hooks Class Initialized
DEBUG - 2023-12-16 15:32:59 --> UTF-8 Support Enabled
INFO - 2023-12-16 15:32:59 --> Utf8 Class Initialized
INFO - 2023-12-16 15:32:59 --> URI Class Initialized
DEBUG - 2023-12-16 15:32:59 --> No URI present. Default controller set.
INFO - 2023-12-16 15:32:59 --> Router Class Initialized
INFO - 2023-12-16 15:32:59 --> Output Class Initialized
INFO - 2023-12-16 15:32:59 --> Security Class Initialized
DEBUG - 2023-12-16 15:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 15:32:59 --> Input Class Initialized
INFO - 2023-12-16 15:32:59 --> Language Class Initialized
INFO - 2023-12-16 15:32:59 --> Loader Class Initialized
INFO - 2023-12-16 15:32:59 --> Helper loaded: url_helper
INFO - 2023-12-16 15:32:59 --> Helper loaded: file_helper
INFO - 2023-12-16 15:32:59 --> Helper loaded: html_helper
INFO - 2023-12-16 15:32:59 --> Helper loaded: text_helper
INFO - 2023-12-16 15:32:59 --> Helper loaded: form_helper
INFO - 2023-12-16 15:32:59 --> Helper loaded: lang_helper
INFO - 2023-12-16 15:32:59 --> Helper loaded: security_helper
INFO - 2023-12-16 15:32:59 --> Helper loaded: cookie_helper
INFO - 2023-12-16 15:32:59 --> Database Driver Class Initialized
INFO - 2023-12-16 15:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 15:32:59 --> Parser Class Initialized
INFO - 2023-12-16 15:32:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 15:32:59 --> Pagination Class Initialized
INFO - 2023-12-16 15:32:59 --> Form Validation Class Initialized
INFO - 2023-12-16 15:32:59 --> Controller Class Initialized
INFO - 2023-12-16 15:32:59 --> Model Class Initialized
DEBUG - 2023-12-16 15:32:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-12-16 15:32:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 15:32:59 --> Config Class Initialized
INFO - 2023-12-16 15:32:59 --> Hooks Class Initialized
DEBUG - 2023-12-16 15:32:59 --> UTF-8 Support Enabled
INFO - 2023-12-16 15:32:59 --> Utf8 Class Initialized
INFO - 2023-12-16 15:32:59 --> URI Class Initialized
INFO - 2023-12-16 15:32:59 --> Router Class Initialized
INFO - 2023-12-16 15:32:59 --> Output Class Initialized
INFO - 2023-12-16 15:32:59 --> Security Class Initialized
DEBUG - 2023-12-16 15:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 15:32:59 --> Input Class Initialized
INFO - 2023-12-16 15:32:59 --> Language Class Initialized
INFO - 2023-12-16 15:32:59 --> Loader Class Initialized
INFO - 2023-12-16 15:32:59 --> Helper loaded: url_helper
INFO - 2023-12-16 15:32:59 --> Helper loaded: file_helper
INFO - 2023-12-16 15:32:59 --> Helper loaded: html_helper
INFO - 2023-12-16 15:32:59 --> Helper loaded: text_helper
INFO - 2023-12-16 15:32:59 --> Helper loaded: form_helper
INFO - 2023-12-16 15:32:59 --> Helper loaded: lang_helper
INFO - 2023-12-16 15:32:59 --> Helper loaded: security_helper
INFO - 2023-12-16 15:32:59 --> Helper loaded: cookie_helper
INFO - 2023-12-16 15:32:59 --> Database Driver Class Initialized
INFO - 2023-12-16 15:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 15:32:59 --> Parser Class Initialized
INFO - 2023-12-16 15:32:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 15:32:59 --> Pagination Class Initialized
INFO - 2023-12-16 15:32:59 --> Form Validation Class Initialized
INFO - 2023-12-16 15:32:59 --> Controller Class Initialized
INFO - 2023-12-16 15:32:59 --> Model Class Initialized
DEBUG - 2023-12-16 15:32:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:32:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-12-16 15:32:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:32:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-16 15:32:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-16 15:32:59 --> Model Class Initialized
INFO - 2023-12-16 15:32:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-16 15:32:59 --> Final output sent to browser
DEBUG - 2023-12-16 15:32:59 --> Total execution time: 0.0387
ERROR - 2023-12-16 15:33:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 15:33:04 --> Config Class Initialized
INFO - 2023-12-16 15:33:04 --> Hooks Class Initialized
DEBUG - 2023-12-16 15:33:04 --> UTF-8 Support Enabled
INFO - 2023-12-16 15:33:04 --> Utf8 Class Initialized
INFO - 2023-12-16 15:33:04 --> URI Class Initialized
INFO - 2023-12-16 15:33:04 --> Router Class Initialized
INFO - 2023-12-16 15:33:04 --> Output Class Initialized
INFO - 2023-12-16 15:33:04 --> Security Class Initialized
DEBUG - 2023-12-16 15:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 15:33:04 --> Input Class Initialized
INFO - 2023-12-16 15:33:04 --> Language Class Initialized
INFO - 2023-12-16 15:33:04 --> Loader Class Initialized
INFO - 2023-12-16 15:33:04 --> Helper loaded: url_helper
INFO - 2023-12-16 15:33:04 --> Helper loaded: file_helper
INFO - 2023-12-16 15:33:04 --> Helper loaded: html_helper
INFO - 2023-12-16 15:33:04 --> Helper loaded: text_helper
INFO - 2023-12-16 15:33:04 --> Helper loaded: form_helper
INFO - 2023-12-16 15:33:04 --> Helper loaded: lang_helper
INFO - 2023-12-16 15:33:04 --> Helper loaded: security_helper
INFO - 2023-12-16 15:33:04 --> Helper loaded: cookie_helper
INFO - 2023-12-16 15:33:04 --> Database Driver Class Initialized
INFO - 2023-12-16 15:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 15:33:04 --> Parser Class Initialized
INFO - 2023-12-16 15:33:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 15:33:04 --> Pagination Class Initialized
INFO - 2023-12-16 15:33:04 --> Form Validation Class Initialized
INFO - 2023-12-16 15:33:04 --> Controller Class Initialized
INFO - 2023-12-16 15:33:04 --> Model Class Initialized
DEBUG - 2023-12-16 15:33:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:33:04 --> Model Class Initialized
INFO - 2023-12-16 15:33:04 --> Final output sent to browser
DEBUG - 2023-12-16 15:33:04 --> Total execution time: 0.0201
ERROR - 2023-12-16 15:33:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 15:33:04 --> Config Class Initialized
INFO - 2023-12-16 15:33:04 --> Hooks Class Initialized
DEBUG - 2023-12-16 15:33:04 --> UTF-8 Support Enabled
INFO - 2023-12-16 15:33:04 --> Utf8 Class Initialized
INFO - 2023-12-16 15:33:04 --> URI Class Initialized
DEBUG - 2023-12-16 15:33:04 --> No URI present. Default controller set.
INFO - 2023-12-16 15:33:04 --> Router Class Initialized
INFO - 2023-12-16 15:33:04 --> Output Class Initialized
INFO - 2023-12-16 15:33:04 --> Security Class Initialized
DEBUG - 2023-12-16 15:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 15:33:04 --> Input Class Initialized
INFO - 2023-12-16 15:33:04 --> Language Class Initialized
INFO - 2023-12-16 15:33:04 --> Loader Class Initialized
INFO - 2023-12-16 15:33:04 --> Helper loaded: url_helper
INFO - 2023-12-16 15:33:04 --> Helper loaded: file_helper
INFO - 2023-12-16 15:33:04 --> Helper loaded: html_helper
INFO - 2023-12-16 15:33:04 --> Helper loaded: text_helper
INFO - 2023-12-16 15:33:04 --> Helper loaded: form_helper
INFO - 2023-12-16 15:33:04 --> Helper loaded: lang_helper
INFO - 2023-12-16 15:33:04 --> Helper loaded: security_helper
INFO - 2023-12-16 15:33:04 --> Helper loaded: cookie_helper
INFO - 2023-12-16 15:33:04 --> Database Driver Class Initialized
INFO - 2023-12-16 15:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 15:33:04 --> Parser Class Initialized
INFO - 2023-12-16 15:33:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 15:33:04 --> Pagination Class Initialized
INFO - 2023-12-16 15:33:04 --> Form Validation Class Initialized
INFO - 2023-12-16 15:33:04 --> Controller Class Initialized
INFO - 2023-12-16 15:33:04 --> Model Class Initialized
DEBUG - 2023-12-16 15:33:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:33:04 --> Model Class Initialized
DEBUG - 2023-12-16 15:33:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:33:04 --> Model Class Initialized
INFO - 2023-12-16 15:33:04 --> Model Class Initialized
INFO - 2023-12-16 15:33:04 --> Model Class Initialized
INFO - 2023-12-16 15:33:04 --> Model Class Initialized
DEBUG - 2023-12-16 15:33:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 15:33:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:33:04 --> Model Class Initialized
INFO - 2023-12-16 15:33:04 --> Model Class Initialized
INFO - 2023-12-16 15:33:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-16 15:33:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:33:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-16 15:33:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-16 15:33:04 --> Model Class Initialized
INFO - 2023-12-16 15:33:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-16 15:33:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-16 15:33:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-16 15:33:05 --> Final output sent to browser
DEBUG - 2023-12-16 15:33:05 --> Total execution time: 0.4883
ERROR - 2023-12-16 15:33:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 15:33:05 --> Config Class Initialized
INFO - 2023-12-16 15:33:05 --> Hooks Class Initialized
DEBUG - 2023-12-16 15:33:05 --> UTF-8 Support Enabled
INFO - 2023-12-16 15:33:05 --> Utf8 Class Initialized
INFO - 2023-12-16 15:33:05 --> URI Class Initialized
INFO - 2023-12-16 15:33:05 --> Router Class Initialized
INFO - 2023-12-16 15:33:05 --> Output Class Initialized
INFO - 2023-12-16 15:33:05 --> Security Class Initialized
DEBUG - 2023-12-16 15:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 15:33:05 --> Input Class Initialized
INFO - 2023-12-16 15:33:05 --> Language Class Initialized
INFO - 2023-12-16 15:33:05 --> Loader Class Initialized
INFO - 2023-12-16 15:33:05 --> Helper loaded: url_helper
INFO - 2023-12-16 15:33:05 --> Helper loaded: file_helper
INFO - 2023-12-16 15:33:05 --> Helper loaded: html_helper
INFO - 2023-12-16 15:33:05 --> Helper loaded: text_helper
INFO - 2023-12-16 15:33:05 --> Helper loaded: form_helper
INFO - 2023-12-16 15:33:05 --> Helper loaded: lang_helper
INFO - 2023-12-16 15:33:05 --> Helper loaded: security_helper
INFO - 2023-12-16 15:33:05 --> Helper loaded: cookie_helper
INFO - 2023-12-16 15:33:05 --> Database Driver Class Initialized
INFO - 2023-12-16 15:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 15:33:05 --> Parser Class Initialized
INFO - 2023-12-16 15:33:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 15:33:05 --> Pagination Class Initialized
INFO - 2023-12-16 15:33:05 --> Form Validation Class Initialized
INFO - 2023-12-16 15:33:05 --> Controller Class Initialized
DEBUG - 2023-12-16 15:33:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 15:33:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:33:05 --> Model Class Initialized
INFO - 2023-12-16 15:33:05 --> Final output sent to browser
DEBUG - 2023-12-16 15:33:05 --> Total execution time: 0.0127
ERROR - 2023-12-16 15:46:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 15:46:16 --> Config Class Initialized
INFO - 2023-12-16 15:46:16 --> Hooks Class Initialized
DEBUG - 2023-12-16 15:46:16 --> UTF-8 Support Enabled
INFO - 2023-12-16 15:46:16 --> Utf8 Class Initialized
INFO - 2023-12-16 15:46:16 --> URI Class Initialized
INFO - 2023-12-16 15:46:16 --> Router Class Initialized
INFO - 2023-12-16 15:46:16 --> Output Class Initialized
INFO - 2023-12-16 15:46:16 --> Security Class Initialized
DEBUG - 2023-12-16 15:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 15:46:16 --> Input Class Initialized
INFO - 2023-12-16 15:46:16 --> Language Class Initialized
INFO - 2023-12-16 15:46:16 --> Loader Class Initialized
INFO - 2023-12-16 15:46:16 --> Helper loaded: url_helper
INFO - 2023-12-16 15:46:16 --> Helper loaded: file_helper
INFO - 2023-12-16 15:46:16 --> Helper loaded: html_helper
INFO - 2023-12-16 15:46:16 --> Helper loaded: text_helper
INFO - 2023-12-16 15:46:16 --> Helper loaded: form_helper
INFO - 2023-12-16 15:46:16 --> Helper loaded: lang_helper
INFO - 2023-12-16 15:46:16 --> Helper loaded: security_helper
INFO - 2023-12-16 15:46:16 --> Helper loaded: cookie_helper
INFO - 2023-12-16 15:46:16 --> Database Driver Class Initialized
INFO - 2023-12-16 15:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 15:46:16 --> Parser Class Initialized
INFO - 2023-12-16 15:46:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 15:46:16 --> Pagination Class Initialized
INFO - 2023-12-16 15:46:16 --> Form Validation Class Initialized
INFO - 2023-12-16 15:46:16 --> Controller Class Initialized
INFO - 2023-12-16 15:46:16 --> Model Class Initialized
DEBUG - 2023-12-16 15:46:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 15:46:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:46:16 --> Model Class Initialized
DEBUG - 2023-12-16 15:46:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:46:16 --> Model Class Initialized
INFO - 2023-12-16 15:46:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-16 15:46:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:46:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-16 15:46:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-16 15:46:16 --> Model Class Initialized
INFO - 2023-12-16 15:46:16 --> Model Class Initialized
INFO - 2023-12-16 15:46:16 --> Model Class Initialized
INFO - 2023-12-16 15:46:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-16 15:46:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-16 15:46:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-16 15:46:16 --> Final output sent to browser
DEBUG - 2023-12-16 15:46:16 --> Total execution time: 0.2356
ERROR - 2023-12-16 15:46:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 15:46:17 --> Config Class Initialized
INFO - 2023-12-16 15:46:17 --> Hooks Class Initialized
DEBUG - 2023-12-16 15:46:17 --> UTF-8 Support Enabled
INFO - 2023-12-16 15:46:17 --> Utf8 Class Initialized
INFO - 2023-12-16 15:46:17 --> URI Class Initialized
INFO - 2023-12-16 15:46:17 --> Router Class Initialized
INFO - 2023-12-16 15:46:17 --> Output Class Initialized
INFO - 2023-12-16 15:46:17 --> Security Class Initialized
DEBUG - 2023-12-16 15:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 15:46:17 --> Input Class Initialized
INFO - 2023-12-16 15:46:17 --> Language Class Initialized
INFO - 2023-12-16 15:46:17 --> Loader Class Initialized
INFO - 2023-12-16 15:46:17 --> Helper loaded: url_helper
INFO - 2023-12-16 15:46:17 --> Helper loaded: file_helper
INFO - 2023-12-16 15:46:17 --> Helper loaded: html_helper
INFO - 2023-12-16 15:46:17 --> Helper loaded: text_helper
INFO - 2023-12-16 15:46:17 --> Helper loaded: form_helper
INFO - 2023-12-16 15:46:17 --> Helper loaded: lang_helper
INFO - 2023-12-16 15:46:17 --> Helper loaded: security_helper
INFO - 2023-12-16 15:46:17 --> Helper loaded: cookie_helper
INFO - 2023-12-16 15:46:17 --> Database Driver Class Initialized
INFO - 2023-12-16 15:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 15:46:17 --> Parser Class Initialized
INFO - 2023-12-16 15:46:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 15:46:17 --> Pagination Class Initialized
INFO - 2023-12-16 15:46:17 --> Form Validation Class Initialized
INFO - 2023-12-16 15:46:17 --> Controller Class Initialized
INFO - 2023-12-16 15:46:17 --> Model Class Initialized
DEBUG - 2023-12-16 15:46:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 15:46:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:46:17 --> Model Class Initialized
DEBUG - 2023-12-16 15:46:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:46:17 --> Model Class Initialized
INFO - 2023-12-16 15:46:17 --> Final output sent to browser
DEBUG - 2023-12-16 15:46:17 --> Total execution time: 0.0570
ERROR - 2023-12-16 15:46:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 15:46:22 --> Config Class Initialized
INFO - 2023-12-16 15:46:22 --> Hooks Class Initialized
DEBUG - 2023-12-16 15:46:22 --> UTF-8 Support Enabled
INFO - 2023-12-16 15:46:22 --> Utf8 Class Initialized
INFO - 2023-12-16 15:46:22 --> URI Class Initialized
INFO - 2023-12-16 15:46:22 --> Router Class Initialized
INFO - 2023-12-16 15:46:22 --> Output Class Initialized
INFO - 2023-12-16 15:46:22 --> Security Class Initialized
DEBUG - 2023-12-16 15:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 15:46:22 --> Input Class Initialized
INFO - 2023-12-16 15:46:22 --> Language Class Initialized
INFO - 2023-12-16 15:46:22 --> Loader Class Initialized
INFO - 2023-12-16 15:46:22 --> Helper loaded: url_helper
INFO - 2023-12-16 15:46:22 --> Helper loaded: file_helper
INFO - 2023-12-16 15:46:22 --> Helper loaded: html_helper
INFO - 2023-12-16 15:46:22 --> Helper loaded: text_helper
INFO - 2023-12-16 15:46:22 --> Helper loaded: form_helper
INFO - 2023-12-16 15:46:22 --> Helper loaded: lang_helper
INFO - 2023-12-16 15:46:22 --> Helper loaded: security_helper
INFO - 2023-12-16 15:46:22 --> Helper loaded: cookie_helper
INFO - 2023-12-16 15:46:22 --> Database Driver Class Initialized
INFO - 2023-12-16 15:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 15:46:22 --> Parser Class Initialized
INFO - 2023-12-16 15:46:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 15:46:22 --> Pagination Class Initialized
INFO - 2023-12-16 15:46:22 --> Form Validation Class Initialized
INFO - 2023-12-16 15:46:22 --> Controller Class Initialized
INFO - 2023-12-16 15:46:22 --> Model Class Initialized
DEBUG - 2023-12-16 15:46:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 15:46:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:46:22 --> Model Class Initialized
DEBUG - 2023-12-16 15:46:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:46:22 --> Model Class Initialized
INFO - 2023-12-16 15:46:23 --> Final output sent to browser
DEBUG - 2023-12-16 15:46:23 --> Total execution time: 1.0660
ERROR - 2023-12-16 15:47:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 15:47:02 --> Config Class Initialized
INFO - 2023-12-16 15:47:02 --> Hooks Class Initialized
DEBUG - 2023-12-16 15:47:02 --> UTF-8 Support Enabled
INFO - 2023-12-16 15:47:02 --> Utf8 Class Initialized
INFO - 2023-12-16 15:47:02 --> URI Class Initialized
DEBUG - 2023-12-16 15:47:02 --> No URI present. Default controller set.
INFO - 2023-12-16 15:47:02 --> Router Class Initialized
INFO - 2023-12-16 15:47:02 --> Output Class Initialized
INFO - 2023-12-16 15:47:02 --> Security Class Initialized
DEBUG - 2023-12-16 15:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 15:47:02 --> Input Class Initialized
INFO - 2023-12-16 15:47:02 --> Language Class Initialized
INFO - 2023-12-16 15:47:02 --> Loader Class Initialized
INFO - 2023-12-16 15:47:02 --> Helper loaded: url_helper
INFO - 2023-12-16 15:47:02 --> Helper loaded: file_helper
INFO - 2023-12-16 15:47:02 --> Helper loaded: html_helper
INFO - 2023-12-16 15:47:02 --> Helper loaded: text_helper
INFO - 2023-12-16 15:47:02 --> Helper loaded: form_helper
INFO - 2023-12-16 15:47:02 --> Helper loaded: lang_helper
INFO - 2023-12-16 15:47:02 --> Helper loaded: security_helper
INFO - 2023-12-16 15:47:02 --> Helper loaded: cookie_helper
INFO - 2023-12-16 15:47:02 --> Database Driver Class Initialized
INFO - 2023-12-16 15:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 15:47:02 --> Parser Class Initialized
INFO - 2023-12-16 15:47:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 15:47:02 --> Pagination Class Initialized
INFO - 2023-12-16 15:47:02 --> Form Validation Class Initialized
INFO - 2023-12-16 15:47:02 --> Controller Class Initialized
INFO - 2023-12-16 15:47:02 --> Model Class Initialized
DEBUG - 2023-12-16 15:47:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:47:02 --> Model Class Initialized
DEBUG - 2023-12-16 15:47:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:47:02 --> Model Class Initialized
INFO - 2023-12-16 15:47:02 --> Model Class Initialized
INFO - 2023-12-16 15:47:02 --> Model Class Initialized
INFO - 2023-12-16 15:47:02 --> Model Class Initialized
DEBUG - 2023-12-16 15:47:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 15:47:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:47:02 --> Model Class Initialized
INFO - 2023-12-16 15:47:02 --> Model Class Initialized
INFO - 2023-12-16 15:47:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-16 15:47:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:47:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-16 15:47:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-16 15:47:02 --> Model Class Initialized
INFO - 2023-12-16 15:47:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-16 15:47:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-16 15:47:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-16 15:47:02 --> Final output sent to browser
DEBUG - 2023-12-16 15:47:02 --> Total execution time: 0.3889
ERROR - 2023-12-16 15:47:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 15:47:22 --> Config Class Initialized
INFO - 2023-12-16 15:47:22 --> Hooks Class Initialized
DEBUG - 2023-12-16 15:47:22 --> UTF-8 Support Enabled
INFO - 2023-12-16 15:47:22 --> Utf8 Class Initialized
INFO - 2023-12-16 15:47:22 --> URI Class Initialized
INFO - 2023-12-16 15:47:22 --> Router Class Initialized
INFO - 2023-12-16 15:47:22 --> Output Class Initialized
INFO - 2023-12-16 15:47:22 --> Security Class Initialized
DEBUG - 2023-12-16 15:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 15:47:22 --> Input Class Initialized
INFO - 2023-12-16 15:47:22 --> Language Class Initialized
INFO - 2023-12-16 15:47:22 --> Loader Class Initialized
INFO - 2023-12-16 15:47:22 --> Helper loaded: url_helper
INFO - 2023-12-16 15:47:22 --> Helper loaded: file_helper
INFO - 2023-12-16 15:47:22 --> Helper loaded: html_helper
INFO - 2023-12-16 15:47:22 --> Helper loaded: text_helper
INFO - 2023-12-16 15:47:22 --> Helper loaded: form_helper
INFO - 2023-12-16 15:47:22 --> Helper loaded: lang_helper
INFO - 2023-12-16 15:47:22 --> Helper loaded: security_helper
INFO - 2023-12-16 15:47:22 --> Helper loaded: cookie_helper
INFO - 2023-12-16 15:47:22 --> Database Driver Class Initialized
INFO - 2023-12-16 15:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 15:47:22 --> Parser Class Initialized
INFO - 2023-12-16 15:47:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 15:47:22 --> Pagination Class Initialized
INFO - 2023-12-16 15:47:22 --> Form Validation Class Initialized
INFO - 2023-12-16 15:47:22 --> Controller Class Initialized
INFO - 2023-12-16 15:47:22 --> Model Class Initialized
DEBUG - 2023-12-16 15:47:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 15:47:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:47:22 --> Model Class Initialized
DEBUG - 2023-12-16 15:47:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:47:22 --> Model Class Initialized
INFO - 2023-12-16 15:47:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-12-16 15:47:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:47:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-16 15:47:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-16 15:47:22 --> Model Class Initialized
INFO - 2023-12-16 15:47:22 --> Model Class Initialized
INFO - 2023-12-16 15:47:22 --> Model Class Initialized
INFO - 2023-12-16 15:47:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-16 15:47:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-16 15:47:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-16 15:47:22 --> Final output sent to browser
DEBUG - 2023-12-16 15:47:22 --> Total execution time: 0.2082
ERROR - 2023-12-16 15:47:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 15:47:22 --> Config Class Initialized
INFO - 2023-12-16 15:47:22 --> Hooks Class Initialized
DEBUG - 2023-12-16 15:47:22 --> UTF-8 Support Enabled
INFO - 2023-12-16 15:47:22 --> Utf8 Class Initialized
INFO - 2023-12-16 15:47:22 --> URI Class Initialized
INFO - 2023-12-16 15:47:22 --> Router Class Initialized
INFO - 2023-12-16 15:47:22 --> Output Class Initialized
INFO - 2023-12-16 15:47:22 --> Security Class Initialized
DEBUG - 2023-12-16 15:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 15:47:22 --> Input Class Initialized
INFO - 2023-12-16 15:47:22 --> Language Class Initialized
INFO - 2023-12-16 15:47:22 --> Loader Class Initialized
INFO - 2023-12-16 15:47:22 --> Helper loaded: url_helper
INFO - 2023-12-16 15:47:22 --> Helper loaded: file_helper
INFO - 2023-12-16 15:47:22 --> Helper loaded: html_helper
INFO - 2023-12-16 15:47:22 --> Helper loaded: text_helper
INFO - 2023-12-16 15:47:22 --> Helper loaded: form_helper
INFO - 2023-12-16 15:47:22 --> Helper loaded: lang_helper
INFO - 2023-12-16 15:47:22 --> Helper loaded: security_helper
INFO - 2023-12-16 15:47:22 --> Helper loaded: cookie_helper
INFO - 2023-12-16 15:47:22 --> Database Driver Class Initialized
INFO - 2023-12-16 15:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 15:47:22 --> Parser Class Initialized
INFO - 2023-12-16 15:47:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 15:47:22 --> Pagination Class Initialized
INFO - 2023-12-16 15:47:22 --> Form Validation Class Initialized
INFO - 2023-12-16 15:47:22 --> Controller Class Initialized
INFO - 2023-12-16 15:47:22 --> Model Class Initialized
DEBUG - 2023-12-16 15:47:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 15:47:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:47:22 --> Model Class Initialized
DEBUG - 2023-12-16 15:47:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:47:22 --> Model Class Initialized
INFO - 2023-12-16 15:47:22 --> Final output sent to browser
DEBUG - 2023-12-16 15:47:22 --> Total execution time: 0.0469
ERROR - 2023-12-16 15:47:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 15:47:26 --> Config Class Initialized
INFO - 2023-12-16 15:47:26 --> Hooks Class Initialized
DEBUG - 2023-12-16 15:47:26 --> UTF-8 Support Enabled
INFO - 2023-12-16 15:47:26 --> Utf8 Class Initialized
INFO - 2023-12-16 15:47:26 --> URI Class Initialized
INFO - 2023-12-16 15:47:26 --> Router Class Initialized
INFO - 2023-12-16 15:47:26 --> Output Class Initialized
INFO - 2023-12-16 15:47:26 --> Security Class Initialized
DEBUG - 2023-12-16 15:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 15:47:26 --> Input Class Initialized
INFO - 2023-12-16 15:47:26 --> Language Class Initialized
INFO - 2023-12-16 15:47:26 --> Loader Class Initialized
INFO - 2023-12-16 15:47:26 --> Helper loaded: url_helper
INFO - 2023-12-16 15:47:26 --> Helper loaded: file_helper
INFO - 2023-12-16 15:47:26 --> Helper loaded: html_helper
INFO - 2023-12-16 15:47:26 --> Helper loaded: text_helper
INFO - 2023-12-16 15:47:26 --> Helper loaded: form_helper
INFO - 2023-12-16 15:47:26 --> Helper loaded: lang_helper
INFO - 2023-12-16 15:47:26 --> Helper loaded: security_helper
INFO - 2023-12-16 15:47:26 --> Helper loaded: cookie_helper
INFO - 2023-12-16 15:47:26 --> Database Driver Class Initialized
INFO - 2023-12-16 15:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 15:47:26 --> Parser Class Initialized
INFO - 2023-12-16 15:47:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 15:47:26 --> Pagination Class Initialized
INFO - 2023-12-16 15:47:26 --> Form Validation Class Initialized
INFO - 2023-12-16 15:47:26 --> Controller Class Initialized
INFO - 2023-12-16 15:47:26 --> Model Class Initialized
DEBUG - 2023-12-16 15:47:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 15:47:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:47:26 --> Model Class Initialized
DEBUG - 2023-12-16 15:47:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:47:26 --> Model Class Initialized
INFO - 2023-12-16 15:47:26 --> Final output sent to browser
DEBUG - 2023-12-16 15:47:26 --> Total execution time: 0.1704
ERROR - 2023-12-16 15:47:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 15:47:39 --> Config Class Initialized
INFO - 2023-12-16 15:47:39 --> Hooks Class Initialized
DEBUG - 2023-12-16 15:47:39 --> UTF-8 Support Enabled
INFO - 2023-12-16 15:47:39 --> Utf8 Class Initialized
INFO - 2023-12-16 15:47:39 --> URI Class Initialized
INFO - 2023-12-16 15:47:39 --> Router Class Initialized
INFO - 2023-12-16 15:47:39 --> Output Class Initialized
INFO - 2023-12-16 15:47:39 --> Security Class Initialized
DEBUG - 2023-12-16 15:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 15:47:39 --> Input Class Initialized
INFO - 2023-12-16 15:47:39 --> Language Class Initialized
INFO - 2023-12-16 15:47:39 --> Loader Class Initialized
INFO - 2023-12-16 15:47:39 --> Helper loaded: url_helper
INFO - 2023-12-16 15:47:39 --> Helper loaded: file_helper
INFO - 2023-12-16 15:47:39 --> Helper loaded: html_helper
INFO - 2023-12-16 15:47:39 --> Helper loaded: text_helper
INFO - 2023-12-16 15:47:39 --> Helper loaded: form_helper
INFO - 2023-12-16 15:47:39 --> Helper loaded: lang_helper
INFO - 2023-12-16 15:47:39 --> Helper loaded: security_helper
INFO - 2023-12-16 15:47:39 --> Helper loaded: cookie_helper
INFO - 2023-12-16 15:47:39 --> Database Driver Class Initialized
INFO - 2023-12-16 15:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 15:47:39 --> Parser Class Initialized
INFO - 2023-12-16 15:47:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 15:47:39 --> Pagination Class Initialized
INFO - 2023-12-16 15:47:39 --> Form Validation Class Initialized
INFO - 2023-12-16 15:47:39 --> Controller Class Initialized
INFO - 2023-12-16 15:47:39 --> Model Class Initialized
DEBUG - 2023-12-16 15:47:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 15:47:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:47:39 --> Model Class Initialized
DEBUG - 2023-12-16 15:47:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:47:39 --> Model Class Initialized
INFO - 2023-12-16 15:47:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-12-16 15:47:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:47:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-16 15:47:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-16 15:47:39 --> Model Class Initialized
INFO - 2023-12-16 15:47:39 --> Model Class Initialized
INFO - 2023-12-16 15:47:39 --> Model Class Initialized
INFO - 2023-12-16 15:47:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-16 15:47:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-16 15:47:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-16 15:47:39 --> Final output sent to browser
DEBUG - 2023-12-16 15:47:39 --> Total execution time: 0.2072
ERROR - 2023-12-16 15:47:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 15:47:40 --> Config Class Initialized
INFO - 2023-12-16 15:47:40 --> Hooks Class Initialized
DEBUG - 2023-12-16 15:47:40 --> UTF-8 Support Enabled
INFO - 2023-12-16 15:47:40 --> Utf8 Class Initialized
INFO - 2023-12-16 15:47:40 --> URI Class Initialized
INFO - 2023-12-16 15:47:40 --> Router Class Initialized
INFO - 2023-12-16 15:47:40 --> Output Class Initialized
INFO - 2023-12-16 15:47:40 --> Security Class Initialized
DEBUG - 2023-12-16 15:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 15:47:40 --> Input Class Initialized
INFO - 2023-12-16 15:47:40 --> Language Class Initialized
INFO - 2023-12-16 15:47:40 --> Loader Class Initialized
INFO - 2023-12-16 15:47:40 --> Helper loaded: url_helper
INFO - 2023-12-16 15:47:40 --> Helper loaded: file_helper
INFO - 2023-12-16 15:47:40 --> Helper loaded: html_helper
INFO - 2023-12-16 15:47:40 --> Helper loaded: text_helper
INFO - 2023-12-16 15:47:40 --> Helper loaded: form_helper
INFO - 2023-12-16 15:47:40 --> Helper loaded: lang_helper
INFO - 2023-12-16 15:47:40 --> Helper loaded: security_helper
INFO - 2023-12-16 15:47:40 --> Helper loaded: cookie_helper
INFO - 2023-12-16 15:47:40 --> Database Driver Class Initialized
INFO - 2023-12-16 15:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 15:47:40 --> Parser Class Initialized
INFO - 2023-12-16 15:47:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 15:47:40 --> Pagination Class Initialized
INFO - 2023-12-16 15:47:40 --> Form Validation Class Initialized
INFO - 2023-12-16 15:47:40 --> Controller Class Initialized
INFO - 2023-12-16 15:47:40 --> Model Class Initialized
DEBUG - 2023-12-16 15:47:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 15:47:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:47:40 --> Model Class Initialized
DEBUG - 2023-12-16 15:47:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:47:40 --> Model Class Initialized
INFO - 2023-12-16 15:47:40 --> Final output sent to browser
DEBUG - 2023-12-16 15:47:40 --> Total execution time: 0.0647
ERROR - 2023-12-16 15:47:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 15:47:44 --> Config Class Initialized
INFO - 2023-12-16 15:47:44 --> Hooks Class Initialized
DEBUG - 2023-12-16 15:47:44 --> UTF-8 Support Enabled
INFO - 2023-12-16 15:47:44 --> Utf8 Class Initialized
INFO - 2023-12-16 15:47:44 --> URI Class Initialized
INFO - 2023-12-16 15:47:44 --> Router Class Initialized
INFO - 2023-12-16 15:47:44 --> Output Class Initialized
INFO - 2023-12-16 15:47:44 --> Security Class Initialized
DEBUG - 2023-12-16 15:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 15:47:44 --> Input Class Initialized
INFO - 2023-12-16 15:47:44 --> Language Class Initialized
INFO - 2023-12-16 15:47:44 --> Loader Class Initialized
INFO - 2023-12-16 15:47:44 --> Helper loaded: url_helper
INFO - 2023-12-16 15:47:44 --> Helper loaded: file_helper
INFO - 2023-12-16 15:47:44 --> Helper loaded: html_helper
INFO - 2023-12-16 15:47:44 --> Helper loaded: text_helper
INFO - 2023-12-16 15:47:44 --> Helper loaded: form_helper
INFO - 2023-12-16 15:47:44 --> Helper loaded: lang_helper
INFO - 2023-12-16 15:47:44 --> Helper loaded: security_helper
INFO - 2023-12-16 15:47:44 --> Helper loaded: cookie_helper
INFO - 2023-12-16 15:47:44 --> Database Driver Class Initialized
INFO - 2023-12-16 15:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 15:47:44 --> Parser Class Initialized
INFO - 2023-12-16 15:47:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 15:47:44 --> Pagination Class Initialized
INFO - 2023-12-16 15:47:44 --> Form Validation Class Initialized
INFO - 2023-12-16 15:47:44 --> Controller Class Initialized
INFO - 2023-12-16 15:47:44 --> Model Class Initialized
DEBUG - 2023-12-16 15:47:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 15:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:47:44 --> Model Class Initialized
DEBUG - 2023-12-16 15:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:47:44 --> Model Class Initialized
INFO - 2023-12-16 15:47:45 --> Final output sent to browser
DEBUG - 2023-12-16 15:47:45 --> Total execution time: 1.0170
ERROR - 2023-12-16 15:48:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 15:48:14 --> Config Class Initialized
INFO - 2023-12-16 15:48:14 --> Hooks Class Initialized
DEBUG - 2023-12-16 15:48:14 --> UTF-8 Support Enabled
INFO - 2023-12-16 15:48:14 --> Utf8 Class Initialized
INFO - 2023-12-16 15:48:14 --> URI Class Initialized
INFO - 2023-12-16 15:48:14 --> Router Class Initialized
INFO - 2023-12-16 15:48:14 --> Output Class Initialized
INFO - 2023-12-16 15:48:14 --> Security Class Initialized
DEBUG - 2023-12-16 15:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 15:48:14 --> Input Class Initialized
INFO - 2023-12-16 15:48:14 --> Language Class Initialized
INFO - 2023-12-16 15:48:14 --> Loader Class Initialized
INFO - 2023-12-16 15:48:14 --> Helper loaded: url_helper
INFO - 2023-12-16 15:48:14 --> Helper loaded: file_helper
INFO - 2023-12-16 15:48:14 --> Helper loaded: html_helper
INFO - 2023-12-16 15:48:14 --> Helper loaded: text_helper
INFO - 2023-12-16 15:48:14 --> Helper loaded: form_helper
INFO - 2023-12-16 15:48:14 --> Helper loaded: lang_helper
INFO - 2023-12-16 15:48:14 --> Helper loaded: security_helper
INFO - 2023-12-16 15:48:14 --> Helper loaded: cookie_helper
INFO - 2023-12-16 15:48:14 --> Database Driver Class Initialized
INFO - 2023-12-16 15:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 15:48:14 --> Parser Class Initialized
INFO - 2023-12-16 15:48:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 15:48:14 --> Pagination Class Initialized
INFO - 2023-12-16 15:48:14 --> Form Validation Class Initialized
INFO - 2023-12-16 15:48:14 --> Controller Class Initialized
INFO - 2023-12-16 15:48:14 --> Model Class Initialized
DEBUG - 2023-12-16 15:48:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 15:48:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:48:14 --> Model Class Initialized
DEBUG - 2023-12-16 15:48:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:48:14 --> Model Class Initialized
INFO - 2023-12-16 15:48:15 --> Final output sent to browser
DEBUG - 2023-12-16 15:48:15 --> Total execution time: 0.7871
ERROR - 2023-12-16 15:48:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 15:48:17 --> Config Class Initialized
INFO - 2023-12-16 15:48:17 --> Hooks Class Initialized
DEBUG - 2023-12-16 15:48:17 --> UTF-8 Support Enabled
INFO - 2023-12-16 15:48:17 --> Utf8 Class Initialized
INFO - 2023-12-16 15:48:17 --> URI Class Initialized
INFO - 2023-12-16 15:48:17 --> Router Class Initialized
INFO - 2023-12-16 15:48:17 --> Output Class Initialized
INFO - 2023-12-16 15:48:17 --> Security Class Initialized
DEBUG - 2023-12-16 15:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 15:48:17 --> Input Class Initialized
INFO - 2023-12-16 15:48:17 --> Language Class Initialized
INFO - 2023-12-16 15:48:17 --> Loader Class Initialized
INFO - 2023-12-16 15:48:17 --> Helper loaded: url_helper
INFO - 2023-12-16 15:48:17 --> Helper loaded: file_helper
INFO - 2023-12-16 15:48:17 --> Helper loaded: html_helper
INFO - 2023-12-16 15:48:17 --> Helper loaded: text_helper
INFO - 2023-12-16 15:48:17 --> Helper loaded: form_helper
INFO - 2023-12-16 15:48:17 --> Helper loaded: lang_helper
INFO - 2023-12-16 15:48:17 --> Helper loaded: security_helper
INFO - 2023-12-16 15:48:17 --> Helper loaded: cookie_helper
INFO - 2023-12-16 15:48:17 --> Database Driver Class Initialized
INFO - 2023-12-16 15:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 15:48:17 --> Parser Class Initialized
INFO - 2023-12-16 15:48:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 15:48:17 --> Pagination Class Initialized
INFO - 2023-12-16 15:48:17 --> Form Validation Class Initialized
INFO - 2023-12-16 15:48:17 --> Controller Class Initialized
INFO - 2023-12-16 15:48:17 --> Model Class Initialized
DEBUG - 2023-12-16 15:48:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 15:48:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:48:17 --> Model Class Initialized
DEBUG - 2023-12-16 15:48:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:48:17 --> Model Class Initialized
INFO - 2023-12-16 15:48:18 --> Final output sent to browser
DEBUG - 2023-12-16 15:48:18 --> Total execution time: 0.7977
ERROR - 2023-12-16 15:49:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 15:49:02 --> Config Class Initialized
INFO - 2023-12-16 15:49:02 --> Hooks Class Initialized
DEBUG - 2023-12-16 15:49:02 --> UTF-8 Support Enabled
INFO - 2023-12-16 15:49:02 --> Utf8 Class Initialized
INFO - 2023-12-16 15:49:02 --> URI Class Initialized
DEBUG - 2023-12-16 15:49:02 --> No URI present. Default controller set.
INFO - 2023-12-16 15:49:02 --> Router Class Initialized
INFO - 2023-12-16 15:49:02 --> Output Class Initialized
INFO - 2023-12-16 15:49:02 --> Security Class Initialized
DEBUG - 2023-12-16 15:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 15:49:02 --> Input Class Initialized
INFO - 2023-12-16 15:49:02 --> Language Class Initialized
INFO - 2023-12-16 15:49:02 --> Loader Class Initialized
INFO - 2023-12-16 15:49:02 --> Helper loaded: url_helper
INFO - 2023-12-16 15:49:02 --> Helper loaded: file_helper
INFO - 2023-12-16 15:49:02 --> Helper loaded: html_helper
INFO - 2023-12-16 15:49:02 --> Helper loaded: text_helper
INFO - 2023-12-16 15:49:02 --> Helper loaded: form_helper
INFO - 2023-12-16 15:49:02 --> Helper loaded: lang_helper
INFO - 2023-12-16 15:49:02 --> Helper loaded: security_helper
INFO - 2023-12-16 15:49:02 --> Helper loaded: cookie_helper
INFO - 2023-12-16 15:49:02 --> Database Driver Class Initialized
INFO - 2023-12-16 15:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 15:49:02 --> Parser Class Initialized
INFO - 2023-12-16 15:49:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 15:49:02 --> Pagination Class Initialized
INFO - 2023-12-16 15:49:02 --> Form Validation Class Initialized
INFO - 2023-12-16 15:49:02 --> Controller Class Initialized
INFO - 2023-12-16 15:49:02 --> Model Class Initialized
DEBUG - 2023-12-16 15:49:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:49:02 --> Model Class Initialized
DEBUG - 2023-12-16 15:49:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:49:02 --> Model Class Initialized
INFO - 2023-12-16 15:49:02 --> Model Class Initialized
INFO - 2023-12-16 15:49:02 --> Model Class Initialized
INFO - 2023-12-16 15:49:02 --> Model Class Initialized
DEBUG - 2023-12-16 15:49:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 15:49:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:49:02 --> Model Class Initialized
INFO - 2023-12-16 15:49:02 --> Model Class Initialized
INFO - 2023-12-16 15:49:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-16 15:49:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:49:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-16 15:49:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-16 15:49:02 --> Model Class Initialized
INFO - 2023-12-16 15:49:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-16 15:49:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-16 15:49:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-16 15:49:02 --> Final output sent to browser
DEBUG - 2023-12-16 15:49:02 --> Total execution time: 0.4064
ERROR - 2023-12-16 15:49:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 15:49:15 --> Config Class Initialized
INFO - 2023-12-16 15:49:15 --> Hooks Class Initialized
DEBUG - 2023-12-16 15:49:15 --> UTF-8 Support Enabled
INFO - 2023-12-16 15:49:15 --> Utf8 Class Initialized
INFO - 2023-12-16 15:49:15 --> URI Class Initialized
INFO - 2023-12-16 15:49:15 --> Router Class Initialized
INFO - 2023-12-16 15:49:15 --> Output Class Initialized
INFO - 2023-12-16 15:49:15 --> Security Class Initialized
DEBUG - 2023-12-16 15:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 15:49:15 --> Input Class Initialized
INFO - 2023-12-16 15:49:15 --> Language Class Initialized
INFO - 2023-12-16 15:49:15 --> Loader Class Initialized
INFO - 2023-12-16 15:49:15 --> Helper loaded: url_helper
INFO - 2023-12-16 15:49:15 --> Helper loaded: file_helper
INFO - 2023-12-16 15:49:15 --> Helper loaded: html_helper
INFO - 2023-12-16 15:49:15 --> Helper loaded: text_helper
INFO - 2023-12-16 15:49:15 --> Helper loaded: form_helper
INFO - 2023-12-16 15:49:15 --> Helper loaded: lang_helper
INFO - 2023-12-16 15:49:15 --> Helper loaded: security_helper
INFO - 2023-12-16 15:49:15 --> Helper loaded: cookie_helper
INFO - 2023-12-16 15:49:15 --> Database Driver Class Initialized
INFO - 2023-12-16 15:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 15:49:15 --> Parser Class Initialized
INFO - 2023-12-16 15:49:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 15:49:15 --> Pagination Class Initialized
INFO - 2023-12-16 15:49:15 --> Form Validation Class Initialized
INFO - 2023-12-16 15:49:15 --> Controller Class Initialized
DEBUG - 2023-12-16 15:49:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 15:49:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:49:15 --> Model Class Initialized
DEBUG - 2023-12-16 15:49:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:49:15 --> Model Class Initialized
DEBUG - 2023-12-16 15:49:15 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:49:15 --> Model Class Initialized
INFO - 2023-12-16 15:49:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-12-16 15:49:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:49:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-16 15:49:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-16 15:49:15 --> Model Class Initialized
INFO - 2023-12-16 15:49:15 --> Model Class Initialized
INFO - 2023-12-16 15:49:15 --> Model Class Initialized
INFO - 2023-12-16 15:49:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-16 15:49:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-16 15:49:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-16 15:49:16 --> Final output sent to browser
DEBUG - 2023-12-16 15:49:16 --> Total execution time: 0.2407
ERROR - 2023-12-16 15:49:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 15:49:16 --> Config Class Initialized
INFO - 2023-12-16 15:49:16 --> Hooks Class Initialized
DEBUG - 2023-12-16 15:49:16 --> UTF-8 Support Enabled
INFO - 2023-12-16 15:49:16 --> Utf8 Class Initialized
INFO - 2023-12-16 15:49:16 --> URI Class Initialized
INFO - 2023-12-16 15:49:16 --> Router Class Initialized
INFO - 2023-12-16 15:49:16 --> Output Class Initialized
INFO - 2023-12-16 15:49:16 --> Security Class Initialized
DEBUG - 2023-12-16 15:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 15:49:16 --> Input Class Initialized
INFO - 2023-12-16 15:49:16 --> Language Class Initialized
INFO - 2023-12-16 15:49:16 --> Loader Class Initialized
INFO - 2023-12-16 15:49:16 --> Helper loaded: url_helper
INFO - 2023-12-16 15:49:16 --> Helper loaded: file_helper
INFO - 2023-12-16 15:49:16 --> Helper loaded: html_helper
INFO - 2023-12-16 15:49:16 --> Helper loaded: text_helper
INFO - 2023-12-16 15:49:16 --> Helper loaded: form_helper
INFO - 2023-12-16 15:49:16 --> Helper loaded: lang_helper
INFO - 2023-12-16 15:49:16 --> Helper loaded: security_helper
INFO - 2023-12-16 15:49:16 --> Helper loaded: cookie_helper
INFO - 2023-12-16 15:49:16 --> Database Driver Class Initialized
INFO - 2023-12-16 15:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 15:49:16 --> Parser Class Initialized
INFO - 2023-12-16 15:49:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 15:49:16 --> Pagination Class Initialized
INFO - 2023-12-16 15:49:16 --> Form Validation Class Initialized
INFO - 2023-12-16 15:49:16 --> Controller Class Initialized
DEBUG - 2023-12-16 15:49:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 15:49:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:49:16 --> Model Class Initialized
DEBUG - 2023-12-16 15:49:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:49:16 --> Model Class Initialized
INFO - 2023-12-16 15:49:16 --> Final output sent to browser
DEBUG - 2023-12-16 15:49:16 --> Total execution time: 0.0325
ERROR - 2023-12-16 15:49:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 15:49:19 --> Config Class Initialized
INFO - 2023-12-16 15:49:19 --> Hooks Class Initialized
DEBUG - 2023-12-16 15:49:19 --> UTF-8 Support Enabled
INFO - 2023-12-16 15:49:19 --> Utf8 Class Initialized
INFO - 2023-12-16 15:49:19 --> URI Class Initialized
INFO - 2023-12-16 15:49:19 --> Router Class Initialized
INFO - 2023-12-16 15:49:19 --> Output Class Initialized
INFO - 2023-12-16 15:49:19 --> Security Class Initialized
DEBUG - 2023-12-16 15:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 15:49:19 --> Input Class Initialized
INFO - 2023-12-16 15:49:19 --> Language Class Initialized
INFO - 2023-12-16 15:49:19 --> Loader Class Initialized
INFO - 2023-12-16 15:49:19 --> Helper loaded: url_helper
INFO - 2023-12-16 15:49:19 --> Helper loaded: file_helper
INFO - 2023-12-16 15:49:19 --> Helper loaded: html_helper
INFO - 2023-12-16 15:49:19 --> Helper loaded: text_helper
INFO - 2023-12-16 15:49:19 --> Helper loaded: form_helper
INFO - 2023-12-16 15:49:19 --> Helper loaded: lang_helper
INFO - 2023-12-16 15:49:19 --> Helper loaded: security_helper
INFO - 2023-12-16 15:49:19 --> Helper loaded: cookie_helper
INFO - 2023-12-16 15:49:19 --> Database Driver Class Initialized
INFO - 2023-12-16 15:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 15:49:19 --> Parser Class Initialized
INFO - 2023-12-16 15:49:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 15:49:19 --> Pagination Class Initialized
INFO - 2023-12-16 15:49:19 --> Form Validation Class Initialized
INFO - 2023-12-16 15:49:19 --> Controller Class Initialized
DEBUG - 2023-12-16 15:49:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 15:49:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:49:19 --> Model Class Initialized
DEBUG - 2023-12-16 15:49:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:49:19 --> Model Class Initialized
INFO - 2023-12-16 15:49:19 --> Final output sent to browser
DEBUG - 2023-12-16 15:49:19 --> Total execution time: 0.1972
ERROR - 2023-12-16 15:49:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 15:49:28 --> Config Class Initialized
INFO - 2023-12-16 15:49:28 --> Hooks Class Initialized
DEBUG - 2023-12-16 15:49:28 --> UTF-8 Support Enabled
INFO - 2023-12-16 15:49:28 --> Utf8 Class Initialized
INFO - 2023-12-16 15:49:28 --> URI Class Initialized
DEBUG - 2023-12-16 15:49:28 --> No URI present. Default controller set.
INFO - 2023-12-16 15:49:28 --> Router Class Initialized
INFO - 2023-12-16 15:49:28 --> Output Class Initialized
INFO - 2023-12-16 15:49:28 --> Security Class Initialized
DEBUG - 2023-12-16 15:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 15:49:28 --> Input Class Initialized
INFO - 2023-12-16 15:49:28 --> Language Class Initialized
INFO - 2023-12-16 15:49:28 --> Loader Class Initialized
INFO - 2023-12-16 15:49:28 --> Helper loaded: url_helper
INFO - 2023-12-16 15:49:28 --> Helper loaded: file_helper
INFO - 2023-12-16 15:49:28 --> Helper loaded: html_helper
INFO - 2023-12-16 15:49:28 --> Helper loaded: text_helper
INFO - 2023-12-16 15:49:28 --> Helper loaded: form_helper
INFO - 2023-12-16 15:49:28 --> Helper loaded: lang_helper
INFO - 2023-12-16 15:49:28 --> Helper loaded: security_helper
INFO - 2023-12-16 15:49:28 --> Helper loaded: cookie_helper
INFO - 2023-12-16 15:49:28 --> Database Driver Class Initialized
INFO - 2023-12-16 15:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 15:49:28 --> Parser Class Initialized
INFO - 2023-12-16 15:49:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 15:49:28 --> Pagination Class Initialized
INFO - 2023-12-16 15:49:28 --> Form Validation Class Initialized
INFO - 2023-12-16 15:49:28 --> Controller Class Initialized
INFO - 2023-12-16 15:49:28 --> Model Class Initialized
DEBUG - 2023-12-16 15:49:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:49:28 --> Model Class Initialized
DEBUG - 2023-12-16 15:49:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:49:28 --> Model Class Initialized
INFO - 2023-12-16 15:49:28 --> Model Class Initialized
INFO - 2023-12-16 15:49:28 --> Model Class Initialized
INFO - 2023-12-16 15:49:28 --> Model Class Initialized
DEBUG - 2023-12-16 15:49:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 15:49:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:49:28 --> Model Class Initialized
INFO - 2023-12-16 15:49:28 --> Model Class Initialized
INFO - 2023-12-16 15:49:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-16 15:49:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:49:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-16 15:49:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-16 15:49:28 --> Model Class Initialized
INFO - 2023-12-16 15:49:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-16 15:49:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-16 15:49:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-16 15:49:28 --> Final output sent to browser
DEBUG - 2023-12-16 15:49:28 --> Total execution time: 0.4149
ERROR - 2023-12-16 15:52:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 15:52:41 --> Config Class Initialized
INFO - 2023-12-16 15:52:41 --> Hooks Class Initialized
DEBUG - 2023-12-16 15:52:41 --> UTF-8 Support Enabled
INFO - 2023-12-16 15:52:41 --> Utf8 Class Initialized
INFO - 2023-12-16 15:52:41 --> URI Class Initialized
DEBUG - 2023-12-16 15:52:41 --> No URI present. Default controller set.
INFO - 2023-12-16 15:52:41 --> Router Class Initialized
INFO - 2023-12-16 15:52:41 --> Output Class Initialized
INFO - 2023-12-16 15:52:41 --> Security Class Initialized
DEBUG - 2023-12-16 15:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 15:52:41 --> Input Class Initialized
INFO - 2023-12-16 15:52:41 --> Language Class Initialized
INFO - 2023-12-16 15:52:41 --> Loader Class Initialized
INFO - 2023-12-16 15:52:41 --> Helper loaded: url_helper
INFO - 2023-12-16 15:52:41 --> Helper loaded: file_helper
INFO - 2023-12-16 15:52:41 --> Helper loaded: html_helper
INFO - 2023-12-16 15:52:41 --> Helper loaded: text_helper
INFO - 2023-12-16 15:52:41 --> Helper loaded: form_helper
INFO - 2023-12-16 15:52:41 --> Helper loaded: lang_helper
INFO - 2023-12-16 15:52:41 --> Helper loaded: security_helper
INFO - 2023-12-16 15:52:41 --> Helper loaded: cookie_helper
INFO - 2023-12-16 15:52:41 --> Database Driver Class Initialized
INFO - 2023-12-16 15:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 15:52:41 --> Parser Class Initialized
INFO - 2023-12-16 15:52:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 15:52:41 --> Pagination Class Initialized
INFO - 2023-12-16 15:52:41 --> Form Validation Class Initialized
INFO - 2023-12-16 15:52:41 --> Controller Class Initialized
INFO - 2023-12-16 15:52:41 --> Model Class Initialized
DEBUG - 2023-12-16 15:52:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:52:41 --> Model Class Initialized
DEBUG - 2023-12-16 15:52:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:52:41 --> Model Class Initialized
INFO - 2023-12-16 15:52:41 --> Model Class Initialized
INFO - 2023-12-16 15:52:41 --> Model Class Initialized
INFO - 2023-12-16 15:52:41 --> Model Class Initialized
DEBUG - 2023-12-16 15:52:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 15:52:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:52:41 --> Model Class Initialized
INFO - 2023-12-16 15:52:41 --> Model Class Initialized
INFO - 2023-12-16 15:52:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-16 15:52:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-16 15:52:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-16 15:52:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-16 15:52:41 --> Model Class Initialized
INFO - 2023-12-16 15:52:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-16 15:52:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-16 15:52:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-16 15:52:41 --> Final output sent to browser
DEBUG - 2023-12-16 15:52:41 --> Total execution time: 0.3988
ERROR - 2023-12-16 16:14:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 16:14:19 --> Config Class Initialized
INFO - 2023-12-16 16:14:19 --> Hooks Class Initialized
DEBUG - 2023-12-16 16:14:19 --> UTF-8 Support Enabled
INFO - 2023-12-16 16:14:19 --> Utf8 Class Initialized
INFO - 2023-12-16 16:14:19 --> URI Class Initialized
DEBUG - 2023-12-16 16:14:19 --> No URI present. Default controller set.
INFO - 2023-12-16 16:14:19 --> Router Class Initialized
INFO - 2023-12-16 16:14:19 --> Output Class Initialized
INFO - 2023-12-16 16:14:19 --> Security Class Initialized
DEBUG - 2023-12-16 16:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 16:14:19 --> Input Class Initialized
INFO - 2023-12-16 16:14:19 --> Language Class Initialized
INFO - 2023-12-16 16:14:19 --> Loader Class Initialized
INFO - 2023-12-16 16:14:19 --> Helper loaded: url_helper
INFO - 2023-12-16 16:14:19 --> Helper loaded: file_helper
INFO - 2023-12-16 16:14:19 --> Helper loaded: html_helper
INFO - 2023-12-16 16:14:19 --> Helper loaded: text_helper
INFO - 2023-12-16 16:14:19 --> Helper loaded: form_helper
INFO - 2023-12-16 16:14:19 --> Helper loaded: lang_helper
INFO - 2023-12-16 16:14:19 --> Helper loaded: security_helper
INFO - 2023-12-16 16:14:19 --> Helper loaded: cookie_helper
INFO - 2023-12-16 16:14:19 --> Database Driver Class Initialized
INFO - 2023-12-16 16:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 16:14:19 --> Parser Class Initialized
INFO - 2023-12-16 16:14:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 16:14:19 --> Pagination Class Initialized
INFO - 2023-12-16 16:14:19 --> Form Validation Class Initialized
INFO - 2023-12-16 16:14:19 --> Controller Class Initialized
INFO - 2023-12-16 16:14:19 --> Model Class Initialized
DEBUG - 2023-12-16 16:14:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 16:14:19 --> Model Class Initialized
DEBUG - 2023-12-16 16:14:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 16:14:19 --> Model Class Initialized
INFO - 2023-12-16 16:14:19 --> Model Class Initialized
INFO - 2023-12-16 16:14:19 --> Model Class Initialized
INFO - 2023-12-16 16:14:19 --> Model Class Initialized
DEBUG - 2023-12-16 16:14:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 16:14:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 16:14:19 --> Model Class Initialized
INFO - 2023-12-16 16:14:19 --> Model Class Initialized
INFO - 2023-12-16 16:14:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-16 16:14:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-16 16:14:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-16 16:14:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-16 16:14:19 --> Model Class Initialized
INFO - 2023-12-16 16:14:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-16 16:14:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-16 16:14:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-16 16:14:20 --> Final output sent to browser
DEBUG - 2023-12-16 16:14:20 --> Total execution time: 0.4211
ERROR - 2023-12-16 16:32:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 16:32:52 --> Config Class Initialized
INFO - 2023-12-16 16:32:52 --> Hooks Class Initialized
DEBUG - 2023-12-16 16:32:52 --> UTF-8 Support Enabled
INFO - 2023-12-16 16:32:52 --> Utf8 Class Initialized
INFO - 2023-12-16 16:32:52 --> URI Class Initialized
DEBUG - 2023-12-16 16:32:52 --> No URI present. Default controller set.
INFO - 2023-12-16 16:32:52 --> Router Class Initialized
INFO - 2023-12-16 16:32:52 --> Output Class Initialized
INFO - 2023-12-16 16:32:52 --> Security Class Initialized
DEBUG - 2023-12-16 16:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 16:32:52 --> Input Class Initialized
INFO - 2023-12-16 16:32:52 --> Language Class Initialized
INFO - 2023-12-16 16:32:52 --> Loader Class Initialized
INFO - 2023-12-16 16:32:52 --> Helper loaded: url_helper
INFO - 2023-12-16 16:32:52 --> Helper loaded: file_helper
INFO - 2023-12-16 16:32:52 --> Helper loaded: html_helper
INFO - 2023-12-16 16:32:52 --> Helper loaded: text_helper
INFO - 2023-12-16 16:32:52 --> Helper loaded: form_helper
INFO - 2023-12-16 16:32:52 --> Helper loaded: lang_helper
INFO - 2023-12-16 16:32:52 --> Helper loaded: security_helper
INFO - 2023-12-16 16:32:52 --> Helper loaded: cookie_helper
INFO - 2023-12-16 16:32:52 --> Database Driver Class Initialized
INFO - 2023-12-16 16:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 16:32:52 --> Parser Class Initialized
INFO - 2023-12-16 16:32:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 16:32:52 --> Pagination Class Initialized
INFO - 2023-12-16 16:32:52 --> Form Validation Class Initialized
INFO - 2023-12-16 16:32:52 --> Controller Class Initialized
INFO - 2023-12-16 16:32:52 --> Model Class Initialized
DEBUG - 2023-12-16 16:32:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 16:32:52 --> Model Class Initialized
DEBUG - 2023-12-16 16:32:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 16:32:52 --> Model Class Initialized
INFO - 2023-12-16 16:32:52 --> Model Class Initialized
INFO - 2023-12-16 16:32:52 --> Model Class Initialized
INFO - 2023-12-16 16:32:52 --> Model Class Initialized
DEBUG - 2023-12-16 16:32:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 16:32:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 16:32:52 --> Model Class Initialized
INFO - 2023-12-16 16:32:52 --> Model Class Initialized
INFO - 2023-12-16 16:32:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-16 16:32:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-16 16:32:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-16 16:32:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-16 16:32:52 --> Model Class Initialized
INFO - 2023-12-16 16:32:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-16 16:32:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-16 16:32:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-16 16:32:53 --> Final output sent to browser
DEBUG - 2023-12-16 16:32:53 --> Total execution time: 0.3836
ERROR - 2023-12-16 16:34:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 16:34:58 --> Config Class Initialized
INFO - 2023-12-16 16:34:58 --> Hooks Class Initialized
DEBUG - 2023-12-16 16:34:58 --> UTF-8 Support Enabled
INFO - 2023-12-16 16:34:58 --> Utf8 Class Initialized
INFO - 2023-12-16 16:34:58 --> URI Class Initialized
DEBUG - 2023-12-16 16:34:58 --> No URI present. Default controller set.
INFO - 2023-12-16 16:34:58 --> Router Class Initialized
INFO - 2023-12-16 16:34:58 --> Output Class Initialized
INFO - 2023-12-16 16:34:58 --> Security Class Initialized
DEBUG - 2023-12-16 16:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 16:34:58 --> Input Class Initialized
INFO - 2023-12-16 16:34:58 --> Language Class Initialized
INFO - 2023-12-16 16:34:58 --> Loader Class Initialized
INFO - 2023-12-16 16:34:58 --> Helper loaded: url_helper
INFO - 2023-12-16 16:34:58 --> Helper loaded: file_helper
INFO - 2023-12-16 16:34:58 --> Helper loaded: html_helper
INFO - 2023-12-16 16:34:58 --> Helper loaded: text_helper
INFO - 2023-12-16 16:34:58 --> Helper loaded: form_helper
INFO - 2023-12-16 16:34:58 --> Helper loaded: lang_helper
INFO - 2023-12-16 16:34:59 --> Helper loaded: security_helper
INFO - 2023-12-16 16:34:59 --> Helper loaded: cookie_helper
INFO - 2023-12-16 16:34:59 --> Database Driver Class Initialized
INFO - 2023-12-16 16:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 16:34:59 --> Parser Class Initialized
INFO - 2023-12-16 16:34:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 16:34:59 --> Pagination Class Initialized
INFO - 2023-12-16 16:34:59 --> Form Validation Class Initialized
INFO - 2023-12-16 16:34:59 --> Controller Class Initialized
INFO - 2023-12-16 16:34:59 --> Model Class Initialized
DEBUG - 2023-12-16 16:34:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 16:34:59 --> Model Class Initialized
DEBUG - 2023-12-16 16:34:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 16:34:59 --> Model Class Initialized
INFO - 2023-12-16 16:34:59 --> Model Class Initialized
INFO - 2023-12-16 16:34:59 --> Model Class Initialized
INFO - 2023-12-16 16:34:59 --> Model Class Initialized
DEBUG - 2023-12-16 16:34:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 16:34:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 16:34:59 --> Model Class Initialized
INFO - 2023-12-16 16:34:59 --> Model Class Initialized
INFO - 2023-12-16 16:34:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-16 16:34:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-16 16:34:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-16 16:34:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-16 16:34:59 --> Model Class Initialized
ERROR - 2023-12-16 16:34:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 16:34:59 --> Config Class Initialized
INFO - 2023-12-16 16:34:59 --> Hooks Class Initialized
DEBUG - 2023-12-16 16:34:59 --> UTF-8 Support Enabled
INFO - 2023-12-16 16:34:59 --> Utf8 Class Initialized
INFO - 2023-12-16 16:34:59 --> URI Class Initialized
DEBUG - 2023-12-16 16:34:59 --> No URI present. Default controller set.
INFO - 2023-12-16 16:34:59 --> Router Class Initialized
INFO - 2023-12-16 16:34:59 --> Output Class Initialized
INFO - 2023-12-16 16:34:59 --> Security Class Initialized
DEBUG - 2023-12-16 16:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 16:34:59 --> Input Class Initialized
INFO - 2023-12-16 16:34:59 --> Language Class Initialized
INFO - 2023-12-16 16:34:59 --> Loader Class Initialized
INFO - 2023-12-16 16:34:59 --> Helper loaded: url_helper
INFO - 2023-12-16 16:34:59 --> Helper loaded: file_helper
INFO - 2023-12-16 16:34:59 --> Helper loaded: html_helper
INFO - 2023-12-16 16:34:59 --> Helper loaded: text_helper
INFO - 2023-12-16 16:34:59 --> Helper loaded: form_helper
INFO - 2023-12-16 16:34:59 --> Helper loaded: lang_helper
INFO - 2023-12-16 16:34:59 --> Helper loaded: security_helper
INFO - 2023-12-16 16:34:59 --> Helper loaded: cookie_helper
INFO - 2023-12-16 16:34:59 --> Database Driver Class Initialized
INFO - 2023-12-16 16:34:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-16 16:34:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-16 16:34:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-16 16:34:59 --> Final output sent to browser
DEBUG - 2023-12-16 16:34:59 --> Total execution time: 0.3934
INFO - 2023-12-16 16:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 16:34:59 --> Parser Class Initialized
INFO - 2023-12-16 16:34:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 16:34:59 --> Pagination Class Initialized
INFO - 2023-12-16 16:34:59 --> Form Validation Class Initialized
INFO - 2023-12-16 16:34:59 --> Controller Class Initialized
INFO - 2023-12-16 16:34:59 --> Model Class Initialized
DEBUG - 2023-12-16 16:34:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 16:34:59 --> Model Class Initialized
DEBUG - 2023-12-16 16:34:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 16:34:59 --> Model Class Initialized
INFO - 2023-12-16 16:34:59 --> Model Class Initialized
INFO - 2023-12-16 16:34:59 --> Model Class Initialized
INFO - 2023-12-16 16:34:59 --> Model Class Initialized
DEBUG - 2023-12-16 16:34:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 16:34:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 16:34:59 --> Model Class Initialized
INFO - 2023-12-16 16:34:59 --> Model Class Initialized
INFO - 2023-12-16 16:34:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-16 16:34:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-16 16:34:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-16 16:34:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-16 16:34:59 --> Model Class Initialized
INFO - 2023-12-16 16:34:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-16 16:34:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-16 16:34:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-16 16:34:59 --> Final output sent to browser
DEBUG - 2023-12-16 16:34:59 --> Total execution time: 0.5338
ERROR - 2023-12-16 16:35:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 16:35:00 --> Config Class Initialized
INFO - 2023-12-16 16:35:00 --> Hooks Class Initialized
DEBUG - 2023-12-16 16:35:00 --> UTF-8 Support Enabled
INFO - 2023-12-16 16:35:00 --> Utf8 Class Initialized
INFO - 2023-12-16 16:35:00 --> URI Class Initialized
INFO - 2023-12-16 16:35:00 --> Router Class Initialized
INFO - 2023-12-16 16:35:00 --> Output Class Initialized
INFO - 2023-12-16 16:35:00 --> Security Class Initialized
DEBUG - 2023-12-16 16:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 16:35:00 --> Input Class Initialized
INFO - 2023-12-16 16:35:00 --> Language Class Initialized
INFO - 2023-12-16 16:35:00 --> Loader Class Initialized
INFO - 2023-12-16 16:35:00 --> Helper loaded: url_helper
INFO - 2023-12-16 16:35:00 --> Helper loaded: file_helper
INFO - 2023-12-16 16:35:00 --> Helper loaded: html_helper
INFO - 2023-12-16 16:35:00 --> Helper loaded: text_helper
INFO - 2023-12-16 16:35:00 --> Helper loaded: form_helper
INFO - 2023-12-16 16:35:00 --> Helper loaded: lang_helper
INFO - 2023-12-16 16:35:00 --> Helper loaded: security_helper
INFO - 2023-12-16 16:35:00 --> Helper loaded: cookie_helper
INFO - 2023-12-16 16:35:00 --> Database Driver Class Initialized
INFO - 2023-12-16 16:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 16:35:00 --> Parser Class Initialized
INFO - 2023-12-16 16:35:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 16:35:00 --> Pagination Class Initialized
INFO - 2023-12-16 16:35:00 --> Form Validation Class Initialized
INFO - 2023-12-16 16:35:00 --> Controller Class Initialized
DEBUG - 2023-12-16 16:35:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 16:35:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 16:35:00 --> Model Class Initialized
DEBUG - 2023-12-16 16:35:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 16:35:00 --> Model Class Initialized
DEBUG - 2023-12-16 16:35:00 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-12-16 16:35:00 --> Model Class Initialized
INFO - 2023-12-16 16:35:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-12-16 16:35:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-16 16:35:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-16 16:35:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-16 16:35:00 --> Model Class Initialized
INFO - 2023-12-16 16:35:00 --> Model Class Initialized
INFO - 2023-12-16 16:35:00 --> Model Class Initialized
INFO - 2023-12-16 16:35:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-16 16:35:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-16 16:35:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-16 16:35:00 --> Final output sent to browser
DEBUG - 2023-12-16 16:35:00 --> Total execution time: 0.2140
ERROR - 2023-12-16 16:35:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 16:35:01 --> Config Class Initialized
INFO - 2023-12-16 16:35:01 --> Hooks Class Initialized
DEBUG - 2023-12-16 16:35:01 --> UTF-8 Support Enabled
INFO - 2023-12-16 16:35:01 --> Utf8 Class Initialized
INFO - 2023-12-16 16:35:01 --> URI Class Initialized
INFO - 2023-12-16 16:35:01 --> Router Class Initialized
INFO - 2023-12-16 16:35:01 --> Output Class Initialized
INFO - 2023-12-16 16:35:01 --> Security Class Initialized
DEBUG - 2023-12-16 16:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 16:35:01 --> Input Class Initialized
INFO - 2023-12-16 16:35:01 --> Language Class Initialized
INFO - 2023-12-16 16:35:01 --> Loader Class Initialized
INFO - 2023-12-16 16:35:01 --> Helper loaded: url_helper
INFO - 2023-12-16 16:35:01 --> Helper loaded: file_helper
INFO - 2023-12-16 16:35:01 --> Helper loaded: html_helper
INFO - 2023-12-16 16:35:01 --> Helper loaded: text_helper
INFO - 2023-12-16 16:35:01 --> Helper loaded: form_helper
INFO - 2023-12-16 16:35:01 --> Helper loaded: lang_helper
INFO - 2023-12-16 16:35:01 --> Helper loaded: security_helper
INFO - 2023-12-16 16:35:01 --> Helper loaded: cookie_helper
INFO - 2023-12-16 16:35:01 --> Database Driver Class Initialized
INFO - 2023-12-16 16:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 16:35:01 --> Parser Class Initialized
INFO - 2023-12-16 16:35:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 16:35:01 --> Pagination Class Initialized
INFO - 2023-12-16 16:35:01 --> Form Validation Class Initialized
INFO - 2023-12-16 16:35:01 --> Controller Class Initialized
DEBUG - 2023-12-16 16:35:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 16:35:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 16:35:01 --> Model Class Initialized
DEBUG - 2023-12-16 16:35:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 16:35:01 --> Model Class Initialized
INFO - 2023-12-16 16:35:01 --> Final output sent to browser
DEBUG - 2023-12-16 16:35:01 --> Total execution time: 0.0324
ERROR - 2023-12-16 16:35:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-12-16 16:35:17 --> Config Class Initialized
INFO - 2023-12-16 16:35:17 --> Hooks Class Initialized
DEBUG - 2023-12-16 16:35:17 --> UTF-8 Support Enabled
INFO - 2023-12-16 16:35:17 --> Utf8 Class Initialized
INFO - 2023-12-16 16:35:17 --> URI Class Initialized
DEBUG - 2023-12-16 16:35:17 --> No URI present. Default controller set.
INFO - 2023-12-16 16:35:17 --> Router Class Initialized
INFO - 2023-12-16 16:35:17 --> Output Class Initialized
INFO - 2023-12-16 16:35:17 --> Security Class Initialized
DEBUG - 2023-12-16 16:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 16:35:17 --> Input Class Initialized
INFO - 2023-12-16 16:35:17 --> Language Class Initialized
INFO - 2023-12-16 16:35:17 --> Loader Class Initialized
INFO - 2023-12-16 16:35:17 --> Helper loaded: url_helper
INFO - 2023-12-16 16:35:17 --> Helper loaded: file_helper
INFO - 2023-12-16 16:35:17 --> Helper loaded: html_helper
INFO - 2023-12-16 16:35:17 --> Helper loaded: text_helper
INFO - 2023-12-16 16:35:17 --> Helper loaded: form_helper
INFO - 2023-12-16 16:35:17 --> Helper loaded: lang_helper
INFO - 2023-12-16 16:35:17 --> Helper loaded: security_helper
INFO - 2023-12-16 16:35:17 --> Helper loaded: cookie_helper
INFO - 2023-12-16 16:35:17 --> Database Driver Class Initialized
INFO - 2023-12-16 16:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 16:35:17 --> Parser Class Initialized
INFO - 2023-12-16 16:35:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-12-16 16:35:17 --> Pagination Class Initialized
INFO - 2023-12-16 16:35:17 --> Form Validation Class Initialized
INFO - 2023-12-16 16:35:17 --> Controller Class Initialized
INFO - 2023-12-16 16:35:17 --> Model Class Initialized
DEBUG - 2023-12-16 16:35:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 16:35:17 --> Model Class Initialized
DEBUG - 2023-12-16 16:35:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 16:35:17 --> Model Class Initialized
INFO - 2023-12-16 16:35:17 --> Model Class Initialized
INFO - 2023-12-16 16:35:17 --> Model Class Initialized
INFO - 2023-12-16 16:35:17 --> Model Class Initialized
DEBUG - 2023-12-16 16:35:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-12-16 16:35:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-12-16 16:35:17 --> Model Class Initialized
INFO - 2023-12-16 16:35:17 --> Model Class Initialized
INFO - 2023-12-16 16:35:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-12-16 16:35:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-12-16 16:35:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-12-16 16:35:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-12-16 16:35:18 --> Model Class Initialized
INFO - 2023-12-16 16:35:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-12-16 16:35:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-12-16 16:35:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-12-16 16:35:18 --> Final output sent to browser
DEBUG - 2023-12-16 16:35:18 --> Total execution time: 0.4022
