<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-11 04:48:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 04:48:03 --> Config Class Initialized
INFO - 2023-09-11 04:48:03 --> Hooks Class Initialized
DEBUG - 2023-09-11 04:48:03 --> UTF-8 Support Enabled
INFO - 2023-09-11 04:48:03 --> Utf8 Class Initialized
INFO - 2023-09-11 04:48:03 --> URI Class Initialized
DEBUG - 2023-09-11 04:48:03 --> No URI present. Default controller set.
INFO - 2023-09-11 04:48:03 --> Router Class Initialized
INFO - 2023-09-11 04:48:03 --> Output Class Initialized
INFO - 2023-09-11 04:48:03 --> Security Class Initialized
DEBUG - 2023-09-11 04:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 04:48:03 --> Input Class Initialized
INFO - 2023-09-11 04:48:03 --> Language Class Initialized
INFO - 2023-09-11 04:48:03 --> Loader Class Initialized
INFO - 2023-09-11 04:48:03 --> Helper loaded: url_helper
INFO - 2023-09-11 04:48:03 --> Helper loaded: file_helper
INFO - 2023-09-11 04:48:03 --> Helper loaded: html_helper
INFO - 2023-09-11 04:48:03 --> Helper loaded: text_helper
INFO - 2023-09-11 04:48:03 --> Helper loaded: form_helper
INFO - 2023-09-11 04:48:03 --> Helper loaded: lang_helper
INFO - 2023-09-11 04:48:03 --> Helper loaded: security_helper
INFO - 2023-09-11 04:48:03 --> Helper loaded: cookie_helper
INFO - 2023-09-11 04:48:03 --> Database Driver Class Initialized
INFO - 2023-09-11 04:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 04:48:03 --> Parser Class Initialized
INFO - 2023-09-11 04:48:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 04:48:03 --> Pagination Class Initialized
INFO - 2023-09-11 04:48:03 --> Form Validation Class Initialized
INFO - 2023-09-11 04:48:03 --> Controller Class Initialized
INFO - 2023-09-11 04:48:03 --> Model Class Initialized
DEBUG - 2023-09-11 04:48:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-11 04:48:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 04:48:08 --> Config Class Initialized
INFO - 2023-09-11 04:48:08 --> Hooks Class Initialized
DEBUG - 2023-09-11 04:48:08 --> UTF-8 Support Enabled
INFO - 2023-09-11 04:48:08 --> Utf8 Class Initialized
INFO - 2023-09-11 04:48:08 --> URI Class Initialized
INFO - 2023-09-11 04:48:08 --> Router Class Initialized
INFO - 2023-09-11 04:48:08 --> Output Class Initialized
INFO - 2023-09-11 04:48:08 --> Security Class Initialized
DEBUG - 2023-09-11 04:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 04:48:08 --> Input Class Initialized
INFO - 2023-09-11 04:48:08 --> Language Class Initialized
INFO - 2023-09-11 04:48:08 --> Loader Class Initialized
INFO - 2023-09-11 04:48:08 --> Helper loaded: url_helper
INFO - 2023-09-11 04:48:08 --> Helper loaded: file_helper
INFO - 2023-09-11 04:48:08 --> Helper loaded: html_helper
INFO - 2023-09-11 04:48:08 --> Helper loaded: text_helper
INFO - 2023-09-11 04:48:08 --> Helper loaded: form_helper
INFO - 2023-09-11 04:48:08 --> Helper loaded: lang_helper
INFO - 2023-09-11 04:48:08 --> Helper loaded: security_helper
INFO - 2023-09-11 04:48:08 --> Helper loaded: cookie_helper
INFO - 2023-09-11 04:48:08 --> Database Driver Class Initialized
INFO - 2023-09-11 04:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 04:48:08 --> Parser Class Initialized
INFO - 2023-09-11 04:48:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 04:48:08 --> Pagination Class Initialized
INFO - 2023-09-11 04:48:08 --> Form Validation Class Initialized
INFO - 2023-09-11 04:48:08 --> Controller Class Initialized
INFO - 2023-09-11 04:48:08 --> Model Class Initialized
DEBUG - 2023-09-11 04:48:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 04:48:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-11 04:48:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-11 04:48:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-11 04:48:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-11 04:48:08 --> Model Class Initialized
INFO - 2023-09-11 04:48:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-11 04:48:08 --> Final output sent to browser
DEBUG - 2023-09-11 04:48:08 --> Total execution time: 0.0343
ERROR - 2023-09-11 04:48:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 04:48:19 --> Config Class Initialized
INFO - 2023-09-11 04:48:19 --> Hooks Class Initialized
DEBUG - 2023-09-11 04:48:19 --> UTF-8 Support Enabled
INFO - 2023-09-11 04:48:19 --> Utf8 Class Initialized
INFO - 2023-09-11 04:48:19 --> URI Class Initialized
INFO - 2023-09-11 04:48:19 --> Router Class Initialized
INFO - 2023-09-11 04:48:19 --> Output Class Initialized
INFO - 2023-09-11 04:48:19 --> Security Class Initialized
DEBUG - 2023-09-11 04:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 04:48:19 --> Input Class Initialized
INFO - 2023-09-11 04:48:19 --> Language Class Initialized
INFO - 2023-09-11 04:48:19 --> Loader Class Initialized
INFO - 2023-09-11 04:48:19 --> Helper loaded: url_helper
INFO - 2023-09-11 04:48:19 --> Helper loaded: file_helper
INFO - 2023-09-11 04:48:19 --> Helper loaded: html_helper
INFO - 2023-09-11 04:48:19 --> Helper loaded: text_helper
INFO - 2023-09-11 04:48:19 --> Helper loaded: form_helper
INFO - 2023-09-11 04:48:19 --> Helper loaded: lang_helper
INFO - 2023-09-11 04:48:19 --> Helper loaded: security_helper
INFO - 2023-09-11 04:48:19 --> Helper loaded: cookie_helper
INFO - 2023-09-11 04:48:19 --> Database Driver Class Initialized
INFO - 2023-09-11 04:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 04:48:19 --> Parser Class Initialized
INFO - 2023-09-11 04:48:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 04:48:19 --> Pagination Class Initialized
INFO - 2023-09-11 04:48:19 --> Form Validation Class Initialized
INFO - 2023-09-11 04:48:19 --> Controller Class Initialized
INFO - 2023-09-11 04:48:19 --> Model Class Initialized
DEBUG - 2023-09-11 04:48:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 04:48:19 --> Model Class Initialized
INFO - 2023-09-11 04:48:19 --> Final output sent to browser
DEBUG - 2023-09-11 04:48:19 --> Total execution time: 0.0206
ERROR - 2023-09-11 04:48:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 04:48:19 --> Config Class Initialized
INFO - 2023-09-11 04:48:19 --> Hooks Class Initialized
DEBUG - 2023-09-11 04:48:19 --> UTF-8 Support Enabled
INFO - 2023-09-11 04:48:19 --> Utf8 Class Initialized
INFO - 2023-09-11 04:48:19 --> URI Class Initialized
INFO - 2023-09-11 04:48:19 --> Router Class Initialized
INFO - 2023-09-11 04:48:19 --> Output Class Initialized
INFO - 2023-09-11 04:48:19 --> Security Class Initialized
DEBUG - 2023-09-11 04:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 04:48:19 --> Input Class Initialized
INFO - 2023-09-11 04:48:19 --> Language Class Initialized
INFO - 2023-09-11 04:48:19 --> Loader Class Initialized
INFO - 2023-09-11 04:48:19 --> Helper loaded: url_helper
INFO - 2023-09-11 04:48:19 --> Helper loaded: file_helper
INFO - 2023-09-11 04:48:19 --> Helper loaded: html_helper
INFO - 2023-09-11 04:48:19 --> Helper loaded: text_helper
INFO - 2023-09-11 04:48:19 --> Helper loaded: form_helper
INFO - 2023-09-11 04:48:19 --> Helper loaded: lang_helper
INFO - 2023-09-11 04:48:19 --> Helper loaded: security_helper
INFO - 2023-09-11 04:48:19 --> Helper loaded: cookie_helper
INFO - 2023-09-11 04:48:19 --> Database Driver Class Initialized
INFO - 2023-09-11 04:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 04:48:19 --> Parser Class Initialized
INFO - 2023-09-11 04:48:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 04:48:19 --> Pagination Class Initialized
INFO - 2023-09-11 04:48:19 --> Form Validation Class Initialized
INFO - 2023-09-11 04:48:19 --> Controller Class Initialized
INFO - 2023-09-11 04:48:19 --> Model Class Initialized
DEBUG - 2023-09-11 04:48:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 04:48:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-11 04:48:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-11 04:48:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-11 04:48:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-11 04:48:19 --> Model Class Initialized
INFO - 2023-09-11 04:48:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-11 04:48:19 --> Final output sent to browser
DEBUG - 2023-09-11 04:48:19 --> Total execution time: 0.0280
ERROR - 2023-09-11 04:48:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 04:48:23 --> Config Class Initialized
INFO - 2023-09-11 04:48:23 --> Hooks Class Initialized
DEBUG - 2023-09-11 04:48:23 --> UTF-8 Support Enabled
INFO - 2023-09-11 04:48:23 --> Utf8 Class Initialized
INFO - 2023-09-11 04:48:23 --> URI Class Initialized
INFO - 2023-09-11 04:48:23 --> Router Class Initialized
INFO - 2023-09-11 04:48:23 --> Output Class Initialized
INFO - 2023-09-11 04:48:23 --> Security Class Initialized
DEBUG - 2023-09-11 04:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 04:48:23 --> Input Class Initialized
INFO - 2023-09-11 04:48:23 --> Language Class Initialized
INFO - 2023-09-11 04:48:23 --> Loader Class Initialized
INFO - 2023-09-11 04:48:23 --> Helper loaded: url_helper
INFO - 2023-09-11 04:48:23 --> Helper loaded: file_helper
INFO - 2023-09-11 04:48:23 --> Helper loaded: html_helper
INFO - 2023-09-11 04:48:23 --> Helper loaded: text_helper
INFO - 2023-09-11 04:48:23 --> Helper loaded: form_helper
INFO - 2023-09-11 04:48:23 --> Helper loaded: lang_helper
INFO - 2023-09-11 04:48:23 --> Helper loaded: security_helper
INFO - 2023-09-11 04:48:23 --> Helper loaded: cookie_helper
INFO - 2023-09-11 04:48:23 --> Database Driver Class Initialized
INFO - 2023-09-11 04:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 04:48:23 --> Parser Class Initialized
INFO - 2023-09-11 04:48:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 04:48:23 --> Pagination Class Initialized
INFO - 2023-09-11 04:48:23 --> Form Validation Class Initialized
INFO - 2023-09-11 04:48:23 --> Controller Class Initialized
INFO - 2023-09-11 04:48:23 --> Model Class Initialized
DEBUG - 2023-09-11 04:48:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 04:48:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-11 04:48:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-11 04:48:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-11 04:48:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-11 04:48:23 --> Model Class Initialized
INFO - 2023-09-11 04:48:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-11 04:48:23 --> Final output sent to browser
DEBUG - 2023-09-11 04:48:23 --> Total execution time: 0.0344
ERROR - 2023-09-11 05:53:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 05:53:01 --> Config Class Initialized
INFO - 2023-09-11 05:53:01 --> Hooks Class Initialized
DEBUG - 2023-09-11 05:53:01 --> UTF-8 Support Enabled
INFO - 2023-09-11 05:53:01 --> Utf8 Class Initialized
INFO - 2023-09-11 05:53:01 --> URI Class Initialized
DEBUG - 2023-09-11 05:53:01 --> No URI present. Default controller set.
INFO - 2023-09-11 05:53:01 --> Router Class Initialized
INFO - 2023-09-11 05:53:01 --> Output Class Initialized
INFO - 2023-09-11 05:53:01 --> Security Class Initialized
DEBUG - 2023-09-11 05:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 05:53:01 --> Input Class Initialized
INFO - 2023-09-11 05:53:01 --> Language Class Initialized
INFO - 2023-09-11 05:53:01 --> Loader Class Initialized
INFO - 2023-09-11 05:53:01 --> Helper loaded: url_helper
INFO - 2023-09-11 05:53:01 --> Helper loaded: file_helper
INFO - 2023-09-11 05:53:01 --> Helper loaded: html_helper
INFO - 2023-09-11 05:53:01 --> Helper loaded: text_helper
INFO - 2023-09-11 05:53:01 --> Helper loaded: form_helper
INFO - 2023-09-11 05:53:01 --> Helper loaded: lang_helper
INFO - 2023-09-11 05:53:01 --> Helper loaded: security_helper
INFO - 2023-09-11 05:53:01 --> Helper loaded: cookie_helper
INFO - 2023-09-11 05:53:01 --> Database Driver Class Initialized
INFO - 2023-09-11 05:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 05:53:01 --> Parser Class Initialized
INFO - 2023-09-11 05:53:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 05:53:01 --> Pagination Class Initialized
INFO - 2023-09-11 05:53:01 --> Form Validation Class Initialized
INFO - 2023-09-11 05:53:01 --> Controller Class Initialized
INFO - 2023-09-11 05:53:01 --> Model Class Initialized
DEBUG - 2023-09-11 05:53:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-11 05:53:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 05:53:01 --> Config Class Initialized
INFO - 2023-09-11 05:53:01 --> Hooks Class Initialized
DEBUG - 2023-09-11 05:53:01 --> UTF-8 Support Enabled
INFO - 2023-09-11 05:53:01 --> Utf8 Class Initialized
INFO - 2023-09-11 05:53:01 --> URI Class Initialized
INFO - 2023-09-11 05:53:01 --> Router Class Initialized
INFO - 2023-09-11 05:53:01 --> Output Class Initialized
INFO - 2023-09-11 05:53:01 --> Security Class Initialized
DEBUG - 2023-09-11 05:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 05:53:01 --> Input Class Initialized
INFO - 2023-09-11 05:53:01 --> Language Class Initialized
INFO - 2023-09-11 05:53:01 --> Loader Class Initialized
INFO - 2023-09-11 05:53:01 --> Helper loaded: url_helper
INFO - 2023-09-11 05:53:01 --> Helper loaded: file_helper
INFO - 2023-09-11 05:53:01 --> Helper loaded: html_helper
INFO - 2023-09-11 05:53:01 --> Helper loaded: text_helper
INFO - 2023-09-11 05:53:01 --> Helper loaded: form_helper
INFO - 2023-09-11 05:53:01 --> Helper loaded: lang_helper
INFO - 2023-09-11 05:53:01 --> Helper loaded: security_helper
INFO - 2023-09-11 05:53:01 --> Helper loaded: cookie_helper
INFO - 2023-09-11 05:53:01 --> Database Driver Class Initialized
INFO - 2023-09-11 05:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 05:53:01 --> Parser Class Initialized
INFO - 2023-09-11 05:53:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 05:53:01 --> Pagination Class Initialized
INFO - 2023-09-11 05:53:01 --> Form Validation Class Initialized
INFO - 2023-09-11 05:53:01 --> Controller Class Initialized
INFO - 2023-09-11 05:53:01 --> Model Class Initialized
DEBUG - 2023-09-11 05:53:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 05:53:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-11 05:53:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-11 05:53:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-11 05:53:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-11 05:53:01 --> Model Class Initialized
INFO - 2023-09-11 05:53:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-11 05:53:01 --> Final output sent to browser
DEBUG - 2023-09-11 05:53:01 --> Total execution time: 0.0353
ERROR - 2023-09-11 08:28:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 08:28:36 --> Config Class Initialized
INFO - 2023-09-11 08:28:36 --> Hooks Class Initialized
DEBUG - 2023-09-11 08:28:36 --> UTF-8 Support Enabled
INFO - 2023-09-11 08:28:36 --> Utf8 Class Initialized
INFO - 2023-09-11 08:28:36 --> URI Class Initialized
DEBUG - 2023-09-11 08:28:36 --> No URI present. Default controller set.
INFO - 2023-09-11 08:28:36 --> Router Class Initialized
INFO - 2023-09-11 08:28:36 --> Output Class Initialized
INFO - 2023-09-11 08:28:36 --> Security Class Initialized
DEBUG - 2023-09-11 08:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 08:28:36 --> Input Class Initialized
INFO - 2023-09-11 08:28:36 --> Language Class Initialized
INFO - 2023-09-11 08:28:36 --> Loader Class Initialized
INFO - 2023-09-11 08:28:36 --> Helper loaded: url_helper
INFO - 2023-09-11 08:28:36 --> Helper loaded: file_helper
INFO - 2023-09-11 08:28:36 --> Helper loaded: html_helper
INFO - 2023-09-11 08:28:36 --> Helper loaded: text_helper
INFO - 2023-09-11 08:28:36 --> Helper loaded: form_helper
INFO - 2023-09-11 08:28:36 --> Helper loaded: lang_helper
INFO - 2023-09-11 08:28:36 --> Helper loaded: security_helper
INFO - 2023-09-11 08:28:36 --> Helper loaded: cookie_helper
INFO - 2023-09-11 08:28:36 --> Database Driver Class Initialized
INFO - 2023-09-11 08:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 08:28:36 --> Parser Class Initialized
INFO - 2023-09-11 08:28:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 08:28:36 --> Pagination Class Initialized
INFO - 2023-09-11 08:28:36 --> Form Validation Class Initialized
INFO - 2023-09-11 08:28:36 --> Controller Class Initialized
INFO - 2023-09-11 08:28:36 --> Model Class Initialized
DEBUG - 2023-09-11 08:28:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-11 08:28:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 08:28:36 --> Config Class Initialized
INFO - 2023-09-11 08:28:36 --> Hooks Class Initialized
DEBUG - 2023-09-11 08:28:36 --> UTF-8 Support Enabled
INFO - 2023-09-11 08:28:36 --> Utf8 Class Initialized
INFO - 2023-09-11 08:28:36 --> URI Class Initialized
INFO - 2023-09-11 08:28:36 --> Router Class Initialized
INFO - 2023-09-11 08:28:36 --> Output Class Initialized
INFO - 2023-09-11 08:28:36 --> Security Class Initialized
DEBUG - 2023-09-11 08:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 08:28:36 --> Input Class Initialized
INFO - 2023-09-11 08:28:36 --> Language Class Initialized
INFO - 2023-09-11 08:28:36 --> Loader Class Initialized
INFO - 2023-09-11 08:28:36 --> Helper loaded: url_helper
INFO - 2023-09-11 08:28:36 --> Helper loaded: file_helper
INFO - 2023-09-11 08:28:36 --> Helper loaded: html_helper
INFO - 2023-09-11 08:28:36 --> Helper loaded: text_helper
INFO - 2023-09-11 08:28:36 --> Helper loaded: form_helper
INFO - 2023-09-11 08:28:36 --> Helper loaded: lang_helper
INFO - 2023-09-11 08:28:36 --> Helper loaded: security_helper
INFO - 2023-09-11 08:28:36 --> Helper loaded: cookie_helper
INFO - 2023-09-11 08:28:36 --> Database Driver Class Initialized
INFO - 2023-09-11 08:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 08:28:36 --> Parser Class Initialized
INFO - 2023-09-11 08:28:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 08:28:36 --> Pagination Class Initialized
INFO - 2023-09-11 08:28:36 --> Form Validation Class Initialized
INFO - 2023-09-11 08:28:36 --> Controller Class Initialized
INFO - 2023-09-11 08:28:36 --> Model Class Initialized
DEBUG - 2023-09-11 08:28:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 08:28:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-11 08:28:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-11 08:28:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-11 08:28:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-11 08:28:36 --> Model Class Initialized
INFO - 2023-09-11 08:28:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-11 08:28:36 --> Final output sent to browser
DEBUG - 2023-09-11 08:28:36 --> Total execution time: 0.0332
ERROR - 2023-09-11 08:29:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 08:29:02 --> Config Class Initialized
INFO - 2023-09-11 08:29:02 --> Hooks Class Initialized
DEBUG - 2023-09-11 08:29:02 --> UTF-8 Support Enabled
INFO - 2023-09-11 08:29:02 --> Utf8 Class Initialized
INFO - 2023-09-11 08:29:02 --> URI Class Initialized
INFO - 2023-09-11 08:29:02 --> Router Class Initialized
INFO - 2023-09-11 08:29:02 --> Output Class Initialized
INFO - 2023-09-11 08:29:02 --> Security Class Initialized
DEBUG - 2023-09-11 08:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 08:29:02 --> Input Class Initialized
INFO - 2023-09-11 08:29:02 --> Language Class Initialized
INFO - 2023-09-11 08:29:02 --> Loader Class Initialized
INFO - 2023-09-11 08:29:02 --> Helper loaded: url_helper
INFO - 2023-09-11 08:29:02 --> Helper loaded: file_helper
INFO - 2023-09-11 08:29:02 --> Helper loaded: html_helper
INFO - 2023-09-11 08:29:02 --> Helper loaded: text_helper
INFO - 2023-09-11 08:29:02 --> Helper loaded: form_helper
INFO - 2023-09-11 08:29:02 --> Helper loaded: lang_helper
INFO - 2023-09-11 08:29:02 --> Helper loaded: security_helper
INFO - 2023-09-11 08:29:02 --> Helper loaded: cookie_helper
INFO - 2023-09-11 08:29:02 --> Database Driver Class Initialized
INFO - 2023-09-11 08:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 08:29:02 --> Parser Class Initialized
INFO - 2023-09-11 08:29:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 08:29:02 --> Pagination Class Initialized
INFO - 2023-09-11 08:29:02 --> Form Validation Class Initialized
INFO - 2023-09-11 08:29:02 --> Controller Class Initialized
INFO - 2023-09-11 08:29:02 --> Model Class Initialized
DEBUG - 2023-09-11 08:29:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 08:29:02 --> Model Class Initialized
INFO - 2023-09-11 08:29:02 --> Final output sent to browser
DEBUG - 2023-09-11 08:29:02 --> Total execution time: 0.0234
ERROR - 2023-09-11 08:29:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 08:29:02 --> Config Class Initialized
INFO - 2023-09-11 08:29:02 --> Hooks Class Initialized
DEBUG - 2023-09-11 08:29:02 --> UTF-8 Support Enabled
INFO - 2023-09-11 08:29:02 --> Utf8 Class Initialized
INFO - 2023-09-11 08:29:02 --> URI Class Initialized
DEBUG - 2023-09-11 08:29:02 --> No URI present. Default controller set.
INFO - 2023-09-11 08:29:02 --> Router Class Initialized
INFO - 2023-09-11 08:29:02 --> Output Class Initialized
INFO - 2023-09-11 08:29:02 --> Security Class Initialized
DEBUG - 2023-09-11 08:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 08:29:02 --> Input Class Initialized
INFO - 2023-09-11 08:29:02 --> Language Class Initialized
INFO - 2023-09-11 08:29:02 --> Loader Class Initialized
INFO - 2023-09-11 08:29:02 --> Helper loaded: url_helper
INFO - 2023-09-11 08:29:02 --> Helper loaded: file_helper
INFO - 2023-09-11 08:29:02 --> Helper loaded: html_helper
INFO - 2023-09-11 08:29:02 --> Helper loaded: text_helper
INFO - 2023-09-11 08:29:02 --> Helper loaded: form_helper
INFO - 2023-09-11 08:29:02 --> Helper loaded: lang_helper
INFO - 2023-09-11 08:29:02 --> Helper loaded: security_helper
INFO - 2023-09-11 08:29:02 --> Helper loaded: cookie_helper
INFO - 2023-09-11 08:29:02 --> Database Driver Class Initialized
INFO - 2023-09-11 08:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 08:29:02 --> Parser Class Initialized
INFO - 2023-09-11 08:29:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 08:29:02 --> Pagination Class Initialized
INFO - 2023-09-11 08:29:02 --> Form Validation Class Initialized
INFO - 2023-09-11 08:29:02 --> Controller Class Initialized
INFO - 2023-09-11 08:29:02 --> Model Class Initialized
DEBUG - 2023-09-11 08:29:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 08:29:02 --> Model Class Initialized
DEBUG - 2023-09-11 08:29:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 08:29:02 --> Model Class Initialized
INFO - 2023-09-11 08:29:02 --> Model Class Initialized
INFO - 2023-09-11 08:29:02 --> Model Class Initialized
INFO - 2023-09-11 08:29:02 --> Model Class Initialized
DEBUG - 2023-09-11 08:29:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 08:29:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 08:29:02 --> Model Class Initialized
INFO - 2023-09-11 08:29:02 --> Model Class Initialized
INFO - 2023-09-11 08:29:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-11 08:29:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-11 08:29:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-11 08:29:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-11 08:29:02 --> Model Class Initialized
INFO - 2023-09-11 08:29:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-11 08:29:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-11 08:29:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-11 08:29:02 --> Final output sent to browser
DEBUG - 2023-09-11 08:29:02 --> Total execution time: 0.0912
ERROR - 2023-09-11 08:29:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 08:29:55 --> Config Class Initialized
INFO - 2023-09-11 08:29:55 --> Hooks Class Initialized
DEBUG - 2023-09-11 08:29:55 --> UTF-8 Support Enabled
INFO - 2023-09-11 08:29:55 --> Utf8 Class Initialized
INFO - 2023-09-11 08:29:55 --> URI Class Initialized
INFO - 2023-09-11 08:29:55 --> Router Class Initialized
INFO - 2023-09-11 08:29:55 --> Output Class Initialized
INFO - 2023-09-11 08:29:55 --> Security Class Initialized
DEBUG - 2023-09-11 08:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 08:29:55 --> Input Class Initialized
INFO - 2023-09-11 08:29:55 --> Language Class Initialized
INFO - 2023-09-11 08:29:55 --> Loader Class Initialized
INFO - 2023-09-11 08:29:55 --> Helper loaded: url_helper
INFO - 2023-09-11 08:29:55 --> Helper loaded: file_helper
INFO - 2023-09-11 08:29:55 --> Helper loaded: html_helper
INFO - 2023-09-11 08:29:55 --> Helper loaded: text_helper
INFO - 2023-09-11 08:29:55 --> Helper loaded: form_helper
INFO - 2023-09-11 08:29:55 --> Helper loaded: lang_helper
INFO - 2023-09-11 08:29:55 --> Helper loaded: security_helper
INFO - 2023-09-11 08:29:55 --> Helper loaded: cookie_helper
INFO - 2023-09-11 08:29:55 --> Database Driver Class Initialized
INFO - 2023-09-11 08:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 08:29:55 --> Parser Class Initialized
INFO - 2023-09-11 08:29:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 08:29:55 --> Pagination Class Initialized
INFO - 2023-09-11 08:29:55 --> Form Validation Class Initialized
INFO - 2023-09-11 08:29:55 --> Controller Class Initialized
INFO - 2023-09-11 08:29:55 --> Model Class Initialized
DEBUG - 2023-09-11 08:29:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 08:29:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 08:29:55 --> Model Class Initialized
DEBUG - 2023-09-11 08:29:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 08:29:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-09-11 08:29:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-11 08:29:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-11 08:29:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-11 08:29:55 --> Model Class Initialized
INFO - 2023-09-11 08:29:55 --> Model Class Initialized
INFO - 2023-09-11 08:29:55 --> Model Class Initialized
INFO - 2023-09-11 08:29:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-11 08:29:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-11 08:29:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-11 08:29:55 --> Final output sent to browser
DEBUG - 2023-09-11 08:29:55 --> Total execution time: 0.0685
ERROR - 2023-09-11 12:04:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 12:04:44 --> Config Class Initialized
INFO - 2023-09-11 12:04:44 --> Hooks Class Initialized
DEBUG - 2023-09-11 12:04:44 --> UTF-8 Support Enabled
INFO - 2023-09-11 12:04:44 --> Utf8 Class Initialized
INFO - 2023-09-11 12:04:44 --> URI Class Initialized
DEBUG - 2023-09-11 12:04:44 --> No URI present. Default controller set.
INFO - 2023-09-11 12:04:44 --> Router Class Initialized
INFO - 2023-09-11 12:04:44 --> Output Class Initialized
INFO - 2023-09-11 12:04:44 --> Security Class Initialized
DEBUG - 2023-09-11 12:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 12:04:44 --> Input Class Initialized
INFO - 2023-09-11 12:04:44 --> Language Class Initialized
INFO - 2023-09-11 12:04:44 --> Loader Class Initialized
INFO - 2023-09-11 12:04:44 --> Helper loaded: url_helper
INFO - 2023-09-11 12:04:44 --> Helper loaded: file_helper
INFO - 2023-09-11 12:04:44 --> Helper loaded: html_helper
INFO - 2023-09-11 12:04:44 --> Helper loaded: text_helper
INFO - 2023-09-11 12:04:44 --> Helper loaded: form_helper
INFO - 2023-09-11 12:04:44 --> Helper loaded: lang_helper
INFO - 2023-09-11 12:04:44 --> Helper loaded: security_helper
INFO - 2023-09-11 12:04:44 --> Helper loaded: cookie_helper
INFO - 2023-09-11 12:04:44 --> Database Driver Class Initialized
INFO - 2023-09-11 12:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 12:04:44 --> Parser Class Initialized
INFO - 2023-09-11 12:04:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 12:04:44 --> Pagination Class Initialized
INFO - 2023-09-11 12:04:44 --> Form Validation Class Initialized
INFO - 2023-09-11 12:04:44 --> Controller Class Initialized
INFO - 2023-09-11 12:04:44 --> Model Class Initialized
DEBUG - 2023-09-11 12:04:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-11 12:04:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 12:04:45 --> Config Class Initialized
INFO - 2023-09-11 12:04:45 --> Hooks Class Initialized
DEBUG - 2023-09-11 12:04:45 --> UTF-8 Support Enabled
INFO - 2023-09-11 12:04:45 --> Utf8 Class Initialized
INFO - 2023-09-11 12:04:45 --> URI Class Initialized
INFO - 2023-09-11 12:04:45 --> Router Class Initialized
INFO - 2023-09-11 12:04:45 --> Output Class Initialized
INFO - 2023-09-11 12:04:45 --> Security Class Initialized
DEBUG - 2023-09-11 12:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 12:04:45 --> Input Class Initialized
INFO - 2023-09-11 12:04:45 --> Language Class Initialized
INFO - 2023-09-11 12:04:45 --> Loader Class Initialized
INFO - 2023-09-11 12:04:45 --> Helper loaded: url_helper
INFO - 2023-09-11 12:04:45 --> Helper loaded: file_helper
INFO - 2023-09-11 12:04:45 --> Helper loaded: html_helper
INFO - 2023-09-11 12:04:45 --> Helper loaded: text_helper
INFO - 2023-09-11 12:04:45 --> Helper loaded: form_helper
INFO - 2023-09-11 12:04:45 --> Helper loaded: lang_helper
INFO - 2023-09-11 12:04:45 --> Helper loaded: security_helper
INFO - 2023-09-11 12:04:45 --> Helper loaded: cookie_helper
INFO - 2023-09-11 12:04:45 --> Database Driver Class Initialized
INFO - 2023-09-11 12:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 12:04:45 --> Parser Class Initialized
INFO - 2023-09-11 12:04:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 12:04:45 --> Pagination Class Initialized
INFO - 2023-09-11 12:04:45 --> Form Validation Class Initialized
INFO - 2023-09-11 12:04:45 --> Controller Class Initialized
INFO - 2023-09-11 12:04:45 --> Model Class Initialized
DEBUG - 2023-09-11 12:04:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-11 12:04:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-11 12:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-11 12:04:45 --> Model Class Initialized
INFO - 2023-09-11 12:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-11 12:04:45 --> Final output sent to browser
DEBUG - 2023-09-11 12:04:45 --> Total execution time: 0.0363
ERROR - 2023-09-11 12:05:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 12:05:01 --> Config Class Initialized
INFO - 2023-09-11 12:05:01 --> Hooks Class Initialized
DEBUG - 2023-09-11 12:05:01 --> UTF-8 Support Enabled
INFO - 2023-09-11 12:05:01 --> Utf8 Class Initialized
INFO - 2023-09-11 12:05:01 --> URI Class Initialized
INFO - 2023-09-11 12:05:01 --> Router Class Initialized
INFO - 2023-09-11 12:05:01 --> Output Class Initialized
INFO - 2023-09-11 12:05:01 --> Security Class Initialized
DEBUG - 2023-09-11 12:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 12:05:01 --> Input Class Initialized
INFO - 2023-09-11 12:05:01 --> Language Class Initialized
INFO - 2023-09-11 12:05:01 --> Loader Class Initialized
INFO - 2023-09-11 12:05:01 --> Helper loaded: url_helper
INFO - 2023-09-11 12:05:01 --> Helper loaded: file_helper
INFO - 2023-09-11 12:05:01 --> Helper loaded: html_helper
INFO - 2023-09-11 12:05:01 --> Helper loaded: text_helper
INFO - 2023-09-11 12:05:01 --> Helper loaded: form_helper
INFO - 2023-09-11 12:05:01 --> Helper loaded: lang_helper
INFO - 2023-09-11 12:05:01 --> Helper loaded: security_helper
INFO - 2023-09-11 12:05:01 --> Helper loaded: cookie_helper
INFO - 2023-09-11 12:05:01 --> Database Driver Class Initialized
INFO - 2023-09-11 12:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 12:05:01 --> Parser Class Initialized
INFO - 2023-09-11 12:05:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 12:05:01 --> Pagination Class Initialized
INFO - 2023-09-11 12:05:01 --> Form Validation Class Initialized
INFO - 2023-09-11 12:05:01 --> Controller Class Initialized
INFO - 2023-09-11 12:05:01 --> Model Class Initialized
DEBUG - 2023-09-11 12:05:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:05:01 --> Model Class Initialized
INFO - 2023-09-11 12:05:01 --> Final output sent to browser
DEBUG - 2023-09-11 12:05:01 --> Total execution time: 0.0280
ERROR - 2023-09-11 12:05:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 12:05:01 --> Config Class Initialized
INFO - 2023-09-11 12:05:01 --> Hooks Class Initialized
DEBUG - 2023-09-11 12:05:01 --> UTF-8 Support Enabled
INFO - 2023-09-11 12:05:01 --> Utf8 Class Initialized
INFO - 2023-09-11 12:05:01 --> URI Class Initialized
DEBUG - 2023-09-11 12:05:01 --> No URI present. Default controller set.
INFO - 2023-09-11 12:05:01 --> Router Class Initialized
INFO - 2023-09-11 12:05:01 --> Output Class Initialized
INFO - 2023-09-11 12:05:01 --> Security Class Initialized
DEBUG - 2023-09-11 12:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 12:05:01 --> Input Class Initialized
INFO - 2023-09-11 12:05:01 --> Language Class Initialized
INFO - 2023-09-11 12:05:01 --> Loader Class Initialized
INFO - 2023-09-11 12:05:01 --> Helper loaded: url_helper
INFO - 2023-09-11 12:05:01 --> Helper loaded: file_helper
INFO - 2023-09-11 12:05:01 --> Helper loaded: html_helper
INFO - 2023-09-11 12:05:01 --> Helper loaded: text_helper
INFO - 2023-09-11 12:05:01 --> Helper loaded: form_helper
INFO - 2023-09-11 12:05:01 --> Helper loaded: lang_helper
INFO - 2023-09-11 12:05:01 --> Helper loaded: security_helper
INFO - 2023-09-11 12:05:01 --> Helper loaded: cookie_helper
INFO - 2023-09-11 12:05:01 --> Database Driver Class Initialized
INFO - 2023-09-11 12:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 12:05:01 --> Parser Class Initialized
INFO - 2023-09-11 12:05:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 12:05:01 --> Pagination Class Initialized
INFO - 2023-09-11 12:05:01 --> Form Validation Class Initialized
INFO - 2023-09-11 12:05:01 --> Controller Class Initialized
INFO - 2023-09-11 12:05:01 --> Model Class Initialized
DEBUG - 2023-09-11 12:05:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:05:01 --> Model Class Initialized
DEBUG - 2023-09-11 12:05:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:05:01 --> Model Class Initialized
INFO - 2023-09-11 12:05:01 --> Model Class Initialized
INFO - 2023-09-11 12:05:01 --> Model Class Initialized
INFO - 2023-09-11 12:05:01 --> Model Class Initialized
DEBUG - 2023-09-11 12:05:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:05:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:05:01 --> Model Class Initialized
INFO - 2023-09-11 12:05:01 --> Model Class Initialized
INFO - 2023-09-11 12:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-11 12:05:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-11 12:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-11 12:05:02 --> Model Class Initialized
INFO - 2023-09-11 12:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-11 12:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-11 12:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-11 12:05:02 --> Final output sent to browser
DEBUG - 2023-09-11 12:05:02 --> Total execution time: 0.1117
ERROR - 2023-09-11 12:05:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 12:05:02 --> Config Class Initialized
INFO - 2023-09-11 12:05:02 --> Hooks Class Initialized
DEBUG - 2023-09-11 12:05:02 --> UTF-8 Support Enabled
INFO - 2023-09-11 12:05:02 --> Utf8 Class Initialized
INFO - 2023-09-11 12:05:02 --> URI Class Initialized
INFO - 2023-09-11 12:05:02 --> Router Class Initialized
INFO - 2023-09-11 12:05:02 --> Output Class Initialized
INFO - 2023-09-11 12:05:02 --> Security Class Initialized
DEBUG - 2023-09-11 12:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 12:05:02 --> Input Class Initialized
INFO - 2023-09-11 12:05:02 --> Language Class Initialized
INFO - 2023-09-11 12:05:02 --> Loader Class Initialized
INFO - 2023-09-11 12:05:02 --> Helper loaded: url_helper
INFO - 2023-09-11 12:05:02 --> Helper loaded: file_helper
INFO - 2023-09-11 12:05:02 --> Helper loaded: html_helper
INFO - 2023-09-11 12:05:02 --> Helper loaded: text_helper
INFO - 2023-09-11 12:05:02 --> Helper loaded: form_helper
INFO - 2023-09-11 12:05:02 --> Helper loaded: lang_helper
INFO - 2023-09-11 12:05:02 --> Helper loaded: security_helper
INFO - 2023-09-11 12:05:02 --> Helper loaded: cookie_helper
INFO - 2023-09-11 12:05:02 --> Database Driver Class Initialized
INFO - 2023-09-11 12:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 12:05:02 --> Parser Class Initialized
INFO - 2023-09-11 12:05:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 12:05:02 --> Pagination Class Initialized
INFO - 2023-09-11 12:05:02 --> Form Validation Class Initialized
INFO - 2023-09-11 12:05:02 --> Controller Class Initialized
INFO - 2023-09-11 12:05:02 --> Model Class Initialized
DEBUG - 2023-09-11 12:05:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:05:02 --> Model Class Initialized
INFO - 2023-09-11 12:05:02 --> Final output sent to browser
DEBUG - 2023-09-11 12:05:02 --> Total execution time: 0.0176
ERROR - 2023-09-11 12:05:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 12:05:02 --> Config Class Initialized
INFO - 2023-09-11 12:05:02 --> Hooks Class Initialized
DEBUG - 2023-09-11 12:05:02 --> UTF-8 Support Enabled
INFO - 2023-09-11 12:05:02 --> Utf8 Class Initialized
INFO - 2023-09-11 12:05:02 --> URI Class Initialized
DEBUG - 2023-09-11 12:05:02 --> No URI present. Default controller set.
INFO - 2023-09-11 12:05:02 --> Router Class Initialized
INFO - 2023-09-11 12:05:02 --> Output Class Initialized
INFO - 2023-09-11 12:05:02 --> Security Class Initialized
DEBUG - 2023-09-11 12:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 12:05:02 --> Input Class Initialized
INFO - 2023-09-11 12:05:02 --> Language Class Initialized
INFO - 2023-09-11 12:05:02 --> Loader Class Initialized
INFO - 2023-09-11 12:05:02 --> Helper loaded: url_helper
INFO - 2023-09-11 12:05:02 --> Helper loaded: file_helper
INFO - 2023-09-11 12:05:02 --> Helper loaded: html_helper
INFO - 2023-09-11 12:05:02 --> Helper loaded: text_helper
INFO - 2023-09-11 12:05:02 --> Helper loaded: form_helper
INFO - 2023-09-11 12:05:02 --> Helper loaded: lang_helper
INFO - 2023-09-11 12:05:02 --> Helper loaded: security_helper
INFO - 2023-09-11 12:05:02 --> Helper loaded: cookie_helper
INFO - 2023-09-11 12:05:02 --> Database Driver Class Initialized
INFO - 2023-09-11 12:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 12:05:02 --> Parser Class Initialized
INFO - 2023-09-11 12:05:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 12:05:02 --> Pagination Class Initialized
INFO - 2023-09-11 12:05:02 --> Form Validation Class Initialized
INFO - 2023-09-11 12:05:02 --> Controller Class Initialized
INFO - 2023-09-11 12:05:02 --> Model Class Initialized
DEBUG - 2023-09-11 12:05:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:05:02 --> Model Class Initialized
DEBUG - 2023-09-11 12:05:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:05:02 --> Model Class Initialized
INFO - 2023-09-11 12:05:02 --> Model Class Initialized
INFO - 2023-09-11 12:05:02 --> Model Class Initialized
INFO - 2023-09-11 12:05:02 --> Model Class Initialized
DEBUG - 2023-09-11 12:05:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:05:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:05:02 --> Model Class Initialized
INFO - 2023-09-11 12:05:02 --> Model Class Initialized
INFO - 2023-09-11 12:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-11 12:05:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-11 12:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-11 12:05:02 --> Model Class Initialized
INFO - 2023-09-11 12:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-11 12:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-11 12:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-11 12:05:02 --> Final output sent to browser
DEBUG - 2023-09-11 12:05:02 --> Total execution time: 0.0856
ERROR - 2023-09-11 12:05:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 12:05:15 --> Config Class Initialized
INFO - 2023-09-11 12:05:15 --> Hooks Class Initialized
DEBUG - 2023-09-11 12:05:15 --> UTF-8 Support Enabled
INFO - 2023-09-11 12:05:15 --> Utf8 Class Initialized
INFO - 2023-09-11 12:05:15 --> URI Class Initialized
INFO - 2023-09-11 12:05:15 --> Router Class Initialized
INFO - 2023-09-11 12:05:15 --> Output Class Initialized
INFO - 2023-09-11 12:05:15 --> Security Class Initialized
DEBUG - 2023-09-11 12:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 12:05:15 --> Input Class Initialized
INFO - 2023-09-11 12:05:15 --> Language Class Initialized
INFO - 2023-09-11 12:05:15 --> Loader Class Initialized
INFO - 2023-09-11 12:05:15 --> Helper loaded: url_helper
INFO - 2023-09-11 12:05:15 --> Helper loaded: file_helper
INFO - 2023-09-11 12:05:15 --> Helper loaded: html_helper
INFO - 2023-09-11 12:05:15 --> Helper loaded: text_helper
INFO - 2023-09-11 12:05:15 --> Helper loaded: form_helper
INFO - 2023-09-11 12:05:15 --> Helper loaded: lang_helper
INFO - 2023-09-11 12:05:15 --> Helper loaded: security_helper
INFO - 2023-09-11 12:05:15 --> Helper loaded: cookie_helper
INFO - 2023-09-11 12:05:15 --> Database Driver Class Initialized
INFO - 2023-09-11 12:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 12:05:15 --> Parser Class Initialized
INFO - 2023-09-11 12:05:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 12:05:15 --> Pagination Class Initialized
INFO - 2023-09-11 12:05:15 --> Form Validation Class Initialized
INFO - 2023-09-11 12:05:15 --> Controller Class Initialized
INFO - 2023-09-11 12:05:15 --> Model Class Initialized
DEBUG - 2023-09-11 12:05:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:05:15 --> Model Class Initialized
DEBUG - 2023-09-11 12:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:05:15 --> Model Class Initialized
INFO - 2023-09-11 12:05:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-11 12:05:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:05:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-11 12:05:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-11 12:05:15 --> Model Class Initialized
INFO - 2023-09-11 12:05:15 --> Model Class Initialized
INFO - 2023-09-11 12:05:15 --> Model Class Initialized
INFO - 2023-09-11 12:05:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-11 12:05:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-11 12:05:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-11 12:05:15 --> Final output sent to browser
DEBUG - 2023-09-11 12:05:15 --> Total execution time: 0.0801
ERROR - 2023-09-11 12:05:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 12:05:17 --> Config Class Initialized
INFO - 2023-09-11 12:05:17 --> Hooks Class Initialized
DEBUG - 2023-09-11 12:05:17 --> UTF-8 Support Enabled
INFO - 2023-09-11 12:05:17 --> Utf8 Class Initialized
INFO - 2023-09-11 12:05:17 --> URI Class Initialized
DEBUG - 2023-09-11 12:05:17 --> No URI present. Default controller set.
INFO - 2023-09-11 12:05:17 --> Router Class Initialized
INFO - 2023-09-11 12:05:17 --> Output Class Initialized
INFO - 2023-09-11 12:05:17 --> Security Class Initialized
DEBUG - 2023-09-11 12:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 12:05:17 --> Input Class Initialized
INFO - 2023-09-11 12:05:17 --> Language Class Initialized
INFO - 2023-09-11 12:05:17 --> Loader Class Initialized
INFO - 2023-09-11 12:05:17 --> Helper loaded: url_helper
INFO - 2023-09-11 12:05:17 --> Helper loaded: file_helper
INFO - 2023-09-11 12:05:17 --> Helper loaded: html_helper
INFO - 2023-09-11 12:05:17 --> Helper loaded: text_helper
INFO - 2023-09-11 12:05:17 --> Helper loaded: form_helper
INFO - 2023-09-11 12:05:17 --> Helper loaded: lang_helper
INFO - 2023-09-11 12:05:17 --> Helper loaded: security_helper
INFO - 2023-09-11 12:05:17 --> Helper loaded: cookie_helper
INFO - 2023-09-11 12:05:17 --> Database Driver Class Initialized
INFO - 2023-09-11 12:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 12:05:17 --> Parser Class Initialized
INFO - 2023-09-11 12:05:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 12:05:17 --> Pagination Class Initialized
INFO - 2023-09-11 12:05:17 --> Form Validation Class Initialized
INFO - 2023-09-11 12:05:17 --> Controller Class Initialized
INFO - 2023-09-11 12:05:17 --> Model Class Initialized
DEBUG - 2023-09-11 12:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:05:17 --> Model Class Initialized
DEBUG - 2023-09-11 12:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:05:17 --> Model Class Initialized
INFO - 2023-09-11 12:05:17 --> Model Class Initialized
INFO - 2023-09-11 12:05:17 --> Model Class Initialized
INFO - 2023-09-11 12:05:17 --> Model Class Initialized
DEBUG - 2023-09-11 12:05:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:05:17 --> Model Class Initialized
INFO - 2023-09-11 12:05:17 --> Model Class Initialized
INFO - 2023-09-11 12:05:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-11 12:05:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:05:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-11 12:05:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-11 12:05:17 --> Model Class Initialized
INFO - 2023-09-11 12:05:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-11 12:05:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-11 12:05:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-11 12:05:17 --> Final output sent to browser
DEBUG - 2023-09-11 12:05:17 --> Total execution time: 0.0901
ERROR - 2023-09-11 12:05:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 12:05:18 --> Config Class Initialized
INFO - 2023-09-11 12:05:18 --> Hooks Class Initialized
DEBUG - 2023-09-11 12:05:18 --> UTF-8 Support Enabled
INFO - 2023-09-11 12:05:18 --> Utf8 Class Initialized
INFO - 2023-09-11 12:05:18 --> URI Class Initialized
INFO - 2023-09-11 12:05:18 --> Router Class Initialized
INFO - 2023-09-11 12:05:18 --> Output Class Initialized
INFO - 2023-09-11 12:05:18 --> Security Class Initialized
DEBUG - 2023-09-11 12:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 12:05:18 --> Input Class Initialized
INFO - 2023-09-11 12:05:18 --> Language Class Initialized
INFO - 2023-09-11 12:05:18 --> Loader Class Initialized
INFO - 2023-09-11 12:05:18 --> Helper loaded: url_helper
INFO - 2023-09-11 12:05:18 --> Helper loaded: file_helper
INFO - 2023-09-11 12:05:18 --> Helper loaded: html_helper
INFO - 2023-09-11 12:05:18 --> Helper loaded: text_helper
INFO - 2023-09-11 12:05:18 --> Helper loaded: form_helper
INFO - 2023-09-11 12:05:18 --> Helper loaded: lang_helper
INFO - 2023-09-11 12:05:18 --> Helper loaded: security_helper
INFO - 2023-09-11 12:05:18 --> Helper loaded: cookie_helper
INFO - 2023-09-11 12:05:18 --> Database Driver Class Initialized
INFO - 2023-09-11 12:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 12:05:18 --> Parser Class Initialized
INFO - 2023-09-11 12:05:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 12:05:18 --> Pagination Class Initialized
INFO - 2023-09-11 12:05:18 --> Form Validation Class Initialized
INFO - 2023-09-11 12:05:18 --> Controller Class Initialized
INFO - 2023-09-11 12:05:18 --> Model Class Initialized
DEBUG - 2023-09-11 12:05:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:05:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:05:18 --> Model Class Initialized
DEBUG - 2023-09-11 12:05:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:05:18 --> Model Class Initialized
INFO - 2023-09-11 12:05:18 --> Final output sent to browser
DEBUG - 2023-09-11 12:05:18 --> Total execution time: 0.0285
ERROR - 2023-09-11 12:05:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 12:05:28 --> Config Class Initialized
INFO - 2023-09-11 12:05:28 --> Hooks Class Initialized
DEBUG - 2023-09-11 12:05:28 --> UTF-8 Support Enabled
INFO - 2023-09-11 12:05:28 --> Utf8 Class Initialized
INFO - 2023-09-11 12:05:28 --> URI Class Initialized
INFO - 2023-09-11 12:05:28 --> Router Class Initialized
INFO - 2023-09-11 12:05:28 --> Output Class Initialized
INFO - 2023-09-11 12:05:28 --> Security Class Initialized
DEBUG - 2023-09-11 12:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 12:05:28 --> Input Class Initialized
INFO - 2023-09-11 12:05:28 --> Language Class Initialized
INFO - 2023-09-11 12:05:28 --> Loader Class Initialized
INFO - 2023-09-11 12:05:28 --> Helper loaded: url_helper
INFO - 2023-09-11 12:05:28 --> Helper loaded: file_helper
INFO - 2023-09-11 12:05:28 --> Helper loaded: html_helper
INFO - 2023-09-11 12:05:28 --> Helper loaded: text_helper
INFO - 2023-09-11 12:05:28 --> Helper loaded: form_helper
INFO - 2023-09-11 12:05:28 --> Helper loaded: lang_helper
INFO - 2023-09-11 12:05:28 --> Helper loaded: security_helper
INFO - 2023-09-11 12:05:28 --> Helper loaded: cookie_helper
INFO - 2023-09-11 12:05:28 --> Database Driver Class Initialized
INFO - 2023-09-11 12:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 12:05:28 --> Parser Class Initialized
INFO - 2023-09-11 12:05:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 12:05:28 --> Pagination Class Initialized
INFO - 2023-09-11 12:05:28 --> Form Validation Class Initialized
INFO - 2023-09-11 12:05:28 --> Controller Class Initialized
INFO - 2023-09-11 12:05:28 --> Model Class Initialized
DEBUG - 2023-09-11 12:05:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:05:28 --> Model Class Initialized
DEBUG - 2023-09-11 12:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:05:28 --> Model Class Initialized
INFO - 2023-09-11 12:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-11 12:05:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-11 12:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-11 12:05:28 --> Model Class Initialized
INFO - 2023-09-11 12:05:28 --> Model Class Initialized
INFO - 2023-09-11 12:05:28 --> Model Class Initialized
INFO - 2023-09-11 12:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-11 12:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-11 12:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-11 12:05:28 --> Final output sent to browser
DEBUG - 2023-09-11 12:05:28 --> Total execution time: 0.0817
ERROR - 2023-09-11 12:05:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 12:05:29 --> Config Class Initialized
INFO - 2023-09-11 12:05:29 --> Hooks Class Initialized
DEBUG - 2023-09-11 12:05:29 --> UTF-8 Support Enabled
INFO - 2023-09-11 12:05:29 --> Utf8 Class Initialized
INFO - 2023-09-11 12:05:29 --> URI Class Initialized
INFO - 2023-09-11 12:05:29 --> Router Class Initialized
INFO - 2023-09-11 12:05:29 --> Output Class Initialized
INFO - 2023-09-11 12:05:29 --> Security Class Initialized
DEBUG - 2023-09-11 12:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 12:05:29 --> Input Class Initialized
INFO - 2023-09-11 12:05:29 --> Language Class Initialized
INFO - 2023-09-11 12:05:29 --> Loader Class Initialized
INFO - 2023-09-11 12:05:29 --> Helper loaded: url_helper
INFO - 2023-09-11 12:05:29 --> Helper loaded: file_helper
INFO - 2023-09-11 12:05:29 --> Helper loaded: html_helper
INFO - 2023-09-11 12:05:29 --> Helper loaded: text_helper
INFO - 2023-09-11 12:05:29 --> Helper loaded: form_helper
INFO - 2023-09-11 12:05:29 --> Helper loaded: lang_helper
INFO - 2023-09-11 12:05:29 --> Helper loaded: security_helper
INFO - 2023-09-11 12:05:29 --> Helper loaded: cookie_helper
INFO - 2023-09-11 12:05:29 --> Database Driver Class Initialized
INFO - 2023-09-11 12:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 12:05:29 --> Parser Class Initialized
INFO - 2023-09-11 12:05:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 12:05:29 --> Pagination Class Initialized
INFO - 2023-09-11 12:05:29 --> Form Validation Class Initialized
INFO - 2023-09-11 12:05:29 --> Controller Class Initialized
INFO - 2023-09-11 12:05:29 --> Model Class Initialized
DEBUG - 2023-09-11 12:05:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:05:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:05:29 --> Model Class Initialized
DEBUG - 2023-09-11 12:05:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:05:29 --> Model Class Initialized
INFO - 2023-09-11 12:05:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-11 12:05:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:05:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-11 12:05:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-11 12:05:29 --> Model Class Initialized
INFO - 2023-09-11 12:05:29 --> Model Class Initialized
INFO - 2023-09-11 12:05:29 --> Model Class Initialized
INFO - 2023-09-11 12:05:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-11 12:05:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-11 12:05:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-11 12:05:29 --> Final output sent to browser
DEBUG - 2023-09-11 12:05:29 --> Total execution time: 0.0883
ERROR - 2023-09-11 12:05:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 12:05:30 --> Config Class Initialized
INFO - 2023-09-11 12:05:30 --> Hooks Class Initialized
DEBUG - 2023-09-11 12:05:30 --> UTF-8 Support Enabled
INFO - 2023-09-11 12:05:30 --> Utf8 Class Initialized
INFO - 2023-09-11 12:05:30 --> URI Class Initialized
INFO - 2023-09-11 12:05:30 --> Router Class Initialized
INFO - 2023-09-11 12:05:30 --> Output Class Initialized
INFO - 2023-09-11 12:05:30 --> Security Class Initialized
DEBUG - 2023-09-11 12:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 12:05:30 --> Input Class Initialized
INFO - 2023-09-11 12:05:30 --> Language Class Initialized
INFO - 2023-09-11 12:05:30 --> Loader Class Initialized
INFO - 2023-09-11 12:05:30 --> Helper loaded: url_helper
INFO - 2023-09-11 12:05:30 --> Helper loaded: file_helper
INFO - 2023-09-11 12:05:30 --> Helper loaded: html_helper
INFO - 2023-09-11 12:05:30 --> Helper loaded: text_helper
INFO - 2023-09-11 12:05:30 --> Helper loaded: form_helper
INFO - 2023-09-11 12:05:30 --> Helper loaded: lang_helper
INFO - 2023-09-11 12:05:30 --> Helper loaded: security_helper
INFO - 2023-09-11 12:05:30 --> Helper loaded: cookie_helper
INFO - 2023-09-11 12:05:30 --> Database Driver Class Initialized
INFO - 2023-09-11 12:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 12:05:30 --> Parser Class Initialized
INFO - 2023-09-11 12:05:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 12:05:30 --> Pagination Class Initialized
INFO - 2023-09-11 12:05:30 --> Form Validation Class Initialized
INFO - 2023-09-11 12:05:30 --> Controller Class Initialized
INFO - 2023-09-11 12:05:30 --> Model Class Initialized
DEBUG - 2023-09-11 12:05:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:05:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:05:30 --> Model Class Initialized
DEBUG - 2023-09-11 12:05:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:05:30 --> Model Class Initialized
INFO - 2023-09-11 12:05:30 --> Final output sent to browser
DEBUG - 2023-09-11 12:05:30 --> Total execution time: 0.0275
ERROR - 2023-09-11 12:06:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 12:06:09 --> Config Class Initialized
INFO - 2023-09-11 12:06:09 --> Hooks Class Initialized
DEBUG - 2023-09-11 12:06:09 --> UTF-8 Support Enabled
INFO - 2023-09-11 12:06:09 --> Utf8 Class Initialized
INFO - 2023-09-11 12:06:09 --> URI Class Initialized
INFO - 2023-09-11 12:06:09 --> Router Class Initialized
INFO - 2023-09-11 12:06:09 --> Output Class Initialized
INFO - 2023-09-11 12:06:09 --> Security Class Initialized
DEBUG - 2023-09-11 12:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 12:06:09 --> Input Class Initialized
INFO - 2023-09-11 12:06:09 --> Language Class Initialized
INFO - 2023-09-11 12:06:09 --> Loader Class Initialized
INFO - 2023-09-11 12:06:09 --> Helper loaded: url_helper
INFO - 2023-09-11 12:06:09 --> Helper loaded: file_helper
INFO - 2023-09-11 12:06:09 --> Helper loaded: html_helper
INFO - 2023-09-11 12:06:09 --> Helper loaded: text_helper
INFO - 2023-09-11 12:06:09 --> Helper loaded: form_helper
INFO - 2023-09-11 12:06:09 --> Helper loaded: lang_helper
INFO - 2023-09-11 12:06:09 --> Helper loaded: security_helper
INFO - 2023-09-11 12:06:09 --> Helper loaded: cookie_helper
INFO - 2023-09-11 12:06:09 --> Database Driver Class Initialized
INFO - 2023-09-11 12:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 12:06:09 --> Parser Class Initialized
INFO - 2023-09-11 12:06:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 12:06:09 --> Pagination Class Initialized
INFO - 2023-09-11 12:06:09 --> Form Validation Class Initialized
INFO - 2023-09-11 12:06:09 --> Controller Class Initialized
INFO - 2023-09-11 12:06:09 --> Model Class Initialized
DEBUG - 2023-09-11 12:06:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:06:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:06:09 --> Model Class Initialized
DEBUG - 2023-09-11 12:06:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:06:09 --> Model Class Initialized
DEBUG - 2023-09-11 12:06:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:06:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-09-11 12:06:09 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-09-11 12:06:09 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-09-11 12:06:09 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-09-11 12:06:09 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-09-11 12:06:09 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-09-11 12:06:09 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-09-11 12:06:09 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-09-11 12:06:09 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-09-11 12:06:09 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-09-11 12:06:09 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-09-11 12:06:09 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 623
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-09-11 12:06:10 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-09-11 12:06:10 --> Final output sent to browser
DEBUG - 2023-09-11 12:06:10 --> Total execution time: 0.3291
ERROR - 2023-09-11 12:06:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 12:06:10 --> Config Class Initialized
INFO - 2023-09-11 12:06:10 --> Hooks Class Initialized
DEBUG - 2023-09-11 12:06:10 --> UTF-8 Support Enabled
INFO - 2023-09-11 12:06:10 --> Utf8 Class Initialized
INFO - 2023-09-11 12:06:10 --> URI Class Initialized
INFO - 2023-09-11 12:06:10 --> Router Class Initialized
INFO - 2023-09-11 12:06:10 --> Output Class Initialized
INFO - 2023-09-11 12:06:10 --> Security Class Initialized
DEBUG - 2023-09-11 12:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 12:06:10 --> Input Class Initialized
INFO - 2023-09-11 12:06:10 --> Language Class Initialized
INFO - 2023-09-11 12:06:10 --> Loader Class Initialized
INFO - 2023-09-11 12:06:10 --> Helper loaded: url_helper
INFO - 2023-09-11 12:06:10 --> Helper loaded: file_helper
INFO - 2023-09-11 12:06:10 --> Helper loaded: html_helper
INFO - 2023-09-11 12:06:10 --> Helper loaded: text_helper
INFO - 2023-09-11 12:06:10 --> Helper loaded: form_helper
INFO - 2023-09-11 12:06:10 --> Helper loaded: lang_helper
INFO - 2023-09-11 12:06:10 --> Helper loaded: security_helper
INFO - 2023-09-11 12:06:10 --> Helper loaded: cookie_helper
INFO - 2023-09-11 12:06:10 --> Database Driver Class Initialized
INFO - 2023-09-11 12:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 12:06:10 --> Parser Class Initialized
INFO - 2023-09-11 12:06:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 12:06:10 --> Pagination Class Initialized
INFO - 2023-09-11 12:06:10 --> Form Validation Class Initialized
INFO - 2023-09-11 12:06:10 --> Controller Class Initialized
INFO - 2023-09-11 12:06:10 --> Model Class Initialized
DEBUG - 2023-09-11 12:06:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:06:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:06:10 --> Model Class Initialized
DEBUG - 2023-09-11 12:06:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:06:10 --> Model Class Initialized
DEBUG - 2023-09-11 12:06:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:06:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-09-11 12:06:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:06:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-11 12:06:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-11 12:06:10 --> Model Class Initialized
INFO - 2023-09-11 12:06:10 --> Model Class Initialized
INFO - 2023-09-11 12:06:10 --> Model Class Initialized
INFO - 2023-09-11 12:06:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-11 12:06:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-11 12:06:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-11 12:06:11 --> Final output sent to browser
DEBUG - 2023-09-11 12:06:11 --> Total execution time: 0.0894
ERROR - 2023-09-11 12:14:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 12:14:27 --> Config Class Initialized
INFO - 2023-09-11 12:14:27 --> Hooks Class Initialized
DEBUG - 2023-09-11 12:14:27 --> UTF-8 Support Enabled
INFO - 2023-09-11 12:14:27 --> Utf8 Class Initialized
INFO - 2023-09-11 12:14:27 --> URI Class Initialized
INFO - 2023-09-11 12:14:27 --> Router Class Initialized
INFO - 2023-09-11 12:14:27 --> Output Class Initialized
INFO - 2023-09-11 12:14:27 --> Security Class Initialized
DEBUG - 2023-09-11 12:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 12:14:27 --> Input Class Initialized
INFO - 2023-09-11 12:14:27 --> Language Class Initialized
INFO - 2023-09-11 12:14:27 --> Loader Class Initialized
INFO - 2023-09-11 12:14:27 --> Helper loaded: url_helper
INFO - 2023-09-11 12:14:27 --> Helper loaded: file_helper
INFO - 2023-09-11 12:14:27 --> Helper loaded: html_helper
INFO - 2023-09-11 12:14:27 --> Helper loaded: text_helper
INFO - 2023-09-11 12:14:27 --> Helper loaded: form_helper
INFO - 2023-09-11 12:14:27 --> Helper loaded: lang_helper
INFO - 2023-09-11 12:14:27 --> Helper loaded: security_helper
INFO - 2023-09-11 12:14:27 --> Helper loaded: cookie_helper
INFO - 2023-09-11 12:14:27 --> Database Driver Class Initialized
INFO - 2023-09-11 12:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 12:14:27 --> Parser Class Initialized
INFO - 2023-09-11 12:14:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 12:14:27 --> Pagination Class Initialized
INFO - 2023-09-11 12:14:27 --> Form Validation Class Initialized
INFO - 2023-09-11 12:14:27 --> Controller Class Initialized
INFO - 2023-09-11 12:14:27 --> Model Class Initialized
DEBUG - 2023-09-11 12:14:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:14:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:14:27 --> Model Class Initialized
DEBUG - 2023-09-11 12:14:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:14:27 --> Model Class Initialized
INFO - 2023-09-11 12:14:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-11 12:14:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:14:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-11 12:14:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-11 12:14:27 --> Model Class Initialized
INFO - 2023-09-11 12:14:27 --> Model Class Initialized
INFO - 2023-09-11 12:14:27 --> Model Class Initialized
INFO - 2023-09-11 12:14:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-11 12:14:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-11 12:14:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-11 12:14:27 --> Final output sent to browser
DEBUG - 2023-09-11 12:14:27 --> Total execution time: 0.0773
ERROR - 2023-09-11 12:14:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 12:14:28 --> Config Class Initialized
INFO - 2023-09-11 12:14:28 --> Hooks Class Initialized
DEBUG - 2023-09-11 12:14:28 --> UTF-8 Support Enabled
INFO - 2023-09-11 12:14:28 --> Utf8 Class Initialized
INFO - 2023-09-11 12:14:28 --> URI Class Initialized
INFO - 2023-09-11 12:14:28 --> Router Class Initialized
INFO - 2023-09-11 12:14:28 --> Output Class Initialized
INFO - 2023-09-11 12:14:28 --> Security Class Initialized
DEBUG - 2023-09-11 12:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 12:14:28 --> Input Class Initialized
INFO - 2023-09-11 12:14:28 --> Language Class Initialized
INFO - 2023-09-11 12:14:28 --> Loader Class Initialized
INFO - 2023-09-11 12:14:28 --> Helper loaded: url_helper
INFO - 2023-09-11 12:14:28 --> Helper loaded: file_helper
INFO - 2023-09-11 12:14:28 --> Helper loaded: html_helper
INFO - 2023-09-11 12:14:28 --> Helper loaded: text_helper
INFO - 2023-09-11 12:14:28 --> Helper loaded: form_helper
INFO - 2023-09-11 12:14:28 --> Helper loaded: lang_helper
INFO - 2023-09-11 12:14:28 --> Helper loaded: security_helper
INFO - 2023-09-11 12:14:28 --> Helper loaded: cookie_helper
INFO - 2023-09-11 12:14:28 --> Database Driver Class Initialized
INFO - 2023-09-11 12:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 12:14:28 --> Parser Class Initialized
INFO - 2023-09-11 12:14:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 12:14:28 --> Pagination Class Initialized
INFO - 2023-09-11 12:14:28 --> Form Validation Class Initialized
INFO - 2023-09-11 12:14:28 --> Controller Class Initialized
INFO - 2023-09-11 12:14:28 --> Model Class Initialized
DEBUG - 2023-09-11 12:14:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:14:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:14:28 --> Model Class Initialized
DEBUG - 2023-09-11 12:14:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 12:14:28 --> Model Class Initialized
INFO - 2023-09-11 12:14:28 --> Final output sent to browser
DEBUG - 2023-09-11 12:14:28 --> Total execution time: 0.0291
ERROR - 2023-09-11 15:28:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 15:28:44 --> Config Class Initialized
INFO - 2023-09-11 15:28:44 --> Hooks Class Initialized
DEBUG - 2023-09-11 15:28:44 --> UTF-8 Support Enabled
INFO - 2023-09-11 15:28:44 --> Utf8 Class Initialized
INFO - 2023-09-11 15:28:44 --> URI Class Initialized
INFO - 2023-09-11 15:28:45 --> Router Class Initialized
INFO - 2023-09-11 15:28:45 --> Output Class Initialized
INFO - 2023-09-11 15:28:45 --> Security Class Initialized
DEBUG - 2023-09-11 15:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 15:28:45 --> Input Class Initialized
INFO - 2023-09-11 15:28:45 --> Language Class Initialized
INFO - 2023-09-11 15:28:45 --> Loader Class Initialized
INFO - 2023-09-11 15:28:45 --> Helper loaded: url_helper
INFO - 2023-09-11 15:28:45 --> Helper loaded: file_helper
INFO - 2023-09-11 15:28:45 --> Helper loaded: html_helper
INFO - 2023-09-11 15:28:45 --> Helper loaded: text_helper
INFO - 2023-09-11 15:28:45 --> Helper loaded: form_helper
INFO - 2023-09-11 15:28:45 --> Helper loaded: lang_helper
INFO - 2023-09-11 15:28:45 --> Helper loaded: security_helper
INFO - 2023-09-11 15:28:45 --> Helper loaded: cookie_helper
INFO - 2023-09-11 15:28:45 --> Database Driver Class Initialized
INFO - 2023-09-11 15:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 15:28:45 --> Parser Class Initialized
INFO - 2023-09-11 15:28:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 15:28:45 --> Pagination Class Initialized
INFO - 2023-09-11 15:28:45 --> Form Validation Class Initialized
INFO - 2023-09-11 15:28:45 --> Controller Class Initialized
ERROR - 2023-09-11 15:28:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 15:28:45 --> Config Class Initialized
INFO - 2023-09-11 15:28:45 --> Hooks Class Initialized
DEBUG - 2023-09-11 15:28:45 --> UTF-8 Support Enabled
INFO - 2023-09-11 15:28:45 --> Utf8 Class Initialized
INFO - 2023-09-11 15:28:45 --> URI Class Initialized
INFO - 2023-09-11 15:28:45 --> Router Class Initialized
INFO - 2023-09-11 15:28:45 --> Output Class Initialized
INFO - 2023-09-11 15:28:45 --> Security Class Initialized
DEBUG - 2023-09-11 15:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 15:28:45 --> Input Class Initialized
INFO - 2023-09-11 15:28:45 --> Language Class Initialized
INFO - 2023-09-11 15:28:45 --> Loader Class Initialized
INFO - 2023-09-11 15:28:45 --> Helper loaded: url_helper
INFO - 2023-09-11 15:28:45 --> Helper loaded: file_helper
INFO - 2023-09-11 15:28:45 --> Helper loaded: html_helper
INFO - 2023-09-11 15:28:45 --> Helper loaded: text_helper
INFO - 2023-09-11 15:28:45 --> Helper loaded: form_helper
INFO - 2023-09-11 15:28:45 --> Helper loaded: lang_helper
INFO - 2023-09-11 15:28:45 --> Helper loaded: security_helper
INFO - 2023-09-11 15:28:45 --> Helper loaded: cookie_helper
INFO - 2023-09-11 15:28:45 --> Database Driver Class Initialized
INFO - 2023-09-11 15:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 15:28:45 --> Parser Class Initialized
INFO - 2023-09-11 15:28:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 15:28:45 --> Pagination Class Initialized
INFO - 2023-09-11 15:28:45 --> Form Validation Class Initialized
INFO - 2023-09-11 15:28:45 --> Controller Class Initialized
INFO - 2023-09-11 15:28:45 --> Model Class Initialized
DEBUG - 2023-09-11 15:28:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:28:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-11 15:28:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:28:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-11 15:28:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-11 15:28:45 --> Model Class Initialized
INFO - 2023-09-11 15:28:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-11 15:28:45 --> Final output sent to browser
DEBUG - 2023-09-11 15:28:45 --> Total execution time: 0.0340
ERROR - 2023-09-11 15:28:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 15:28:50 --> Config Class Initialized
INFO - 2023-09-11 15:28:50 --> Hooks Class Initialized
DEBUG - 2023-09-11 15:28:50 --> UTF-8 Support Enabled
INFO - 2023-09-11 15:28:50 --> Utf8 Class Initialized
INFO - 2023-09-11 15:28:50 --> URI Class Initialized
DEBUG - 2023-09-11 15:28:50 --> No URI present. Default controller set.
INFO - 2023-09-11 15:28:50 --> Router Class Initialized
INFO - 2023-09-11 15:28:50 --> Output Class Initialized
INFO - 2023-09-11 15:28:50 --> Security Class Initialized
DEBUG - 2023-09-11 15:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 15:28:50 --> Input Class Initialized
INFO - 2023-09-11 15:28:50 --> Language Class Initialized
INFO - 2023-09-11 15:28:50 --> Loader Class Initialized
INFO - 2023-09-11 15:28:50 --> Helper loaded: url_helper
INFO - 2023-09-11 15:28:50 --> Helper loaded: file_helper
INFO - 2023-09-11 15:28:50 --> Helper loaded: html_helper
INFO - 2023-09-11 15:28:50 --> Helper loaded: text_helper
INFO - 2023-09-11 15:28:50 --> Helper loaded: form_helper
INFO - 2023-09-11 15:28:50 --> Helper loaded: lang_helper
INFO - 2023-09-11 15:28:50 --> Helper loaded: security_helper
INFO - 2023-09-11 15:28:50 --> Helper loaded: cookie_helper
INFO - 2023-09-11 15:28:50 --> Database Driver Class Initialized
INFO - 2023-09-11 15:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 15:28:50 --> Parser Class Initialized
INFO - 2023-09-11 15:28:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 15:28:50 --> Pagination Class Initialized
INFO - 2023-09-11 15:28:50 --> Form Validation Class Initialized
INFO - 2023-09-11 15:28:50 --> Controller Class Initialized
INFO - 2023-09-11 15:28:50 --> Model Class Initialized
DEBUG - 2023-09-11 15:28:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-11 15:28:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 15:28:50 --> Config Class Initialized
INFO - 2023-09-11 15:28:50 --> Hooks Class Initialized
DEBUG - 2023-09-11 15:28:50 --> UTF-8 Support Enabled
INFO - 2023-09-11 15:28:50 --> Utf8 Class Initialized
INFO - 2023-09-11 15:28:50 --> URI Class Initialized
INFO - 2023-09-11 15:28:50 --> Router Class Initialized
INFO - 2023-09-11 15:28:50 --> Output Class Initialized
INFO - 2023-09-11 15:28:50 --> Security Class Initialized
DEBUG - 2023-09-11 15:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 15:28:50 --> Input Class Initialized
INFO - 2023-09-11 15:28:50 --> Language Class Initialized
INFO - 2023-09-11 15:28:50 --> Loader Class Initialized
INFO - 2023-09-11 15:28:50 --> Helper loaded: url_helper
INFO - 2023-09-11 15:28:50 --> Helper loaded: file_helper
INFO - 2023-09-11 15:28:50 --> Helper loaded: html_helper
INFO - 2023-09-11 15:28:50 --> Helper loaded: text_helper
INFO - 2023-09-11 15:28:50 --> Helper loaded: form_helper
INFO - 2023-09-11 15:28:50 --> Helper loaded: lang_helper
INFO - 2023-09-11 15:28:50 --> Helper loaded: security_helper
INFO - 2023-09-11 15:28:50 --> Helper loaded: cookie_helper
INFO - 2023-09-11 15:28:50 --> Database Driver Class Initialized
INFO - 2023-09-11 15:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 15:28:50 --> Parser Class Initialized
INFO - 2023-09-11 15:28:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 15:28:50 --> Pagination Class Initialized
INFO - 2023-09-11 15:28:50 --> Form Validation Class Initialized
INFO - 2023-09-11 15:28:50 --> Controller Class Initialized
INFO - 2023-09-11 15:28:50 --> Model Class Initialized
DEBUG - 2023-09-11 15:28:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:28:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-11 15:28:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:28:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-11 15:28:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-11 15:28:50 --> Model Class Initialized
INFO - 2023-09-11 15:28:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-11 15:28:50 --> Final output sent to browser
DEBUG - 2023-09-11 15:28:50 --> Total execution time: 0.0311
ERROR - 2023-09-11 15:28:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 15:28:58 --> Config Class Initialized
INFO - 2023-09-11 15:28:58 --> Hooks Class Initialized
DEBUG - 2023-09-11 15:28:58 --> UTF-8 Support Enabled
INFO - 2023-09-11 15:28:58 --> Utf8 Class Initialized
INFO - 2023-09-11 15:28:58 --> URI Class Initialized
DEBUG - 2023-09-11 15:28:58 --> No URI present. Default controller set.
INFO - 2023-09-11 15:28:58 --> Router Class Initialized
INFO - 2023-09-11 15:28:58 --> Output Class Initialized
INFO - 2023-09-11 15:28:58 --> Security Class Initialized
DEBUG - 2023-09-11 15:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 15:28:58 --> Input Class Initialized
INFO - 2023-09-11 15:28:58 --> Language Class Initialized
INFO - 2023-09-11 15:28:58 --> Loader Class Initialized
INFO - 2023-09-11 15:28:58 --> Helper loaded: url_helper
INFO - 2023-09-11 15:28:58 --> Helper loaded: file_helper
INFO - 2023-09-11 15:28:58 --> Helper loaded: html_helper
INFO - 2023-09-11 15:28:58 --> Helper loaded: text_helper
INFO - 2023-09-11 15:28:58 --> Helper loaded: form_helper
INFO - 2023-09-11 15:28:58 --> Helper loaded: lang_helper
INFO - 2023-09-11 15:28:58 --> Helper loaded: security_helper
INFO - 2023-09-11 15:28:58 --> Helper loaded: cookie_helper
INFO - 2023-09-11 15:28:58 --> Database Driver Class Initialized
INFO - 2023-09-11 15:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 15:28:58 --> Parser Class Initialized
INFO - 2023-09-11 15:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 15:28:58 --> Pagination Class Initialized
INFO - 2023-09-11 15:28:58 --> Form Validation Class Initialized
INFO - 2023-09-11 15:28:58 --> Controller Class Initialized
INFO - 2023-09-11 15:28:58 --> Model Class Initialized
DEBUG - 2023-09-11 15:28:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-09-11 15:29:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 15:29:00 --> Config Class Initialized
INFO - 2023-09-11 15:29:00 --> Hooks Class Initialized
DEBUG - 2023-09-11 15:29:00 --> UTF-8 Support Enabled
INFO - 2023-09-11 15:29:00 --> Utf8 Class Initialized
INFO - 2023-09-11 15:29:00 --> URI Class Initialized
INFO - 2023-09-11 15:29:00 --> Router Class Initialized
INFO - 2023-09-11 15:29:00 --> Output Class Initialized
INFO - 2023-09-11 15:29:00 --> Security Class Initialized
DEBUG - 2023-09-11 15:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 15:29:00 --> Input Class Initialized
INFO - 2023-09-11 15:29:00 --> Language Class Initialized
INFO - 2023-09-11 15:29:00 --> Loader Class Initialized
INFO - 2023-09-11 15:29:00 --> Helper loaded: url_helper
INFO - 2023-09-11 15:29:00 --> Helper loaded: file_helper
INFO - 2023-09-11 15:29:00 --> Helper loaded: html_helper
INFO - 2023-09-11 15:29:00 --> Helper loaded: text_helper
INFO - 2023-09-11 15:29:00 --> Helper loaded: form_helper
INFO - 2023-09-11 15:29:00 --> Helper loaded: lang_helper
INFO - 2023-09-11 15:29:00 --> Helper loaded: security_helper
INFO - 2023-09-11 15:29:00 --> Helper loaded: cookie_helper
INFO - 2023-09-11 15:29:00 --> Database Driver Class Initialized
INFO - 2023-09-11 15:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 15:29:00 --> Parser Class Initialized
INFO - 2023-09-11 15:29:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 15:29:00 --> Pagination Class Initialized
INFO - 2023-09-11 15:29:00 --> Form Validation Class Initialized
INFO - 2023-09-11 15:29:00 --> Controller Class Initialized
INFO - 2023-09-11 15:29:00 --> Model Class Initialized
DEBUG - 2023-09-11 15:29:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:29:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-09-11 15:29:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:29:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-11 15:29:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-11 15:29:00 --> Model Class Initialized
INFO - 2023-09-11 15:29:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-11 15:29:00 --> Final output sent to browser
DEBUG - 2023-09-11 15:29:00 --> Total execution time: 0.0323
ERROR - 2023-09-11 15:29:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 15:29:05 --> Config Class Initialized
INFO - 2023-09-11 15:29:05 --> Hooks Class Initialized
DEBUG - 2023-09-11 15:29:05 --> UTF-8 Support Enabled
INFO - 2023-09-11 15:29:05 --> Utf8 Class Initialized
INFO - 2023-09-11 15:29:05 --> URI Class Initialized
INFO - 2023-09-11 15:29:05 --> Router Class Initialized
INFO - 2023-09-11 15:29:05 --> Output Class Initialized
INFO - 2023-09-11 15:29:05 --> Security Class Initialized
DEBUG - 2023-09-11 15:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 15:29:05 --> Input Class Initialized
INFO - 2023-09-11 15:29:05 --> Language Class Initialized
INFO - 2023-09-11 15:29:05 --> Loader Class Initialized
INFO - 2023-09-11 15:29:05 --> Helper loaded: url_helper
INFO - 2023-09-11 15:29:05 --> Helper loaded: file_helper
INFO - 2023-09-11 15:29:05 --> Helper loaded: html_helper
INFO - 2023-09-11 15:29:05 --> Helper loaded: text_helper
INFO - 2023-09-11 15:29:05 --> Helper loaded: form_helper
INFO - 2023-09-11 15:29:05 --> Helper loaded: lang_helper
INFO - 2023-09-11 15:29:05 --> Helper loaded: security_helper
INFO - 2023-09-11 15:29:05 --> Helper loaded: cookie_helper
INFO - 2023-09-11 15:29:05 --> Database Driver Class Initialized
INFO - 2023-09-11 15:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 15:29:05 --> Parser Class Initialized
INFO - 2023-09-11 15:29:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 15:29:05 --> Pagination Class Initialized
INFO - 2023-09-11 15:29:05 --> Form Validation Class Initialized
INFO - 2023-09-11 15:29:05 --> Controller Class Initialized
INFO - 2023-09-11 15:29:05 --> Model Class Initialized
DEBUG - 2023-09-11 15:29:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:29:05 --> Model Class Initialized
INFO - 2023-09-11 15:29:05 --> Final output sent to browser
DEBUG - 2023-09-11 15:29:05 --> Total execution time: 0.0245
ERROR - 2023-09-11 15:29:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 15:29:05 --> Config Class Initialized
INFO - 2023-09-11 15:29:05 --> Hooks Class Initialized
DEBUG - 2023-09-11 15:29:05 --> UTF-8 Support Enabled
INFO - 2023-09-11 15:29:05 --> Utf8 Class Initialized
INFO - 2023-09-11 15:29:05 --> URI Class Initialized
DEBUG - 2023-09-11 15:29:05 --> No URI present. Default controller set.
INFO - 2023-09-11 15:29:05 --> Router Class Initialized
INFO - 2023-09-11 15:29:05 --> Output Class Initialized
INFO - 2023-09-11 15:29:05 --> Security Class Initialized
DEBUG - 2023-09-11 15:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 15:29:05 --> Input Class Initialized
INFO - 2023-09-11 15:29:05 --> Language Class Initialized
INFO - 2023-09-11 15:29:05 --> Loader Class Initialized
INFO - 2023-09-11 15:29:05 --> Helper loaded: url_helper
INFO - 2023-09-11 15:29:05 --> Helper loaded: file_helper
INFO - 2023-09-11 15:29:05 --> Helper loaded: html_helper
INFO - 2023-09-11 15:29:05 --> Helper loaded: text_helper
INFO - 2023-09-11 15:29:05 --> Helper loaded: form_helper
INFO - 2023-09-11 15:29:05 --> Helper loaded: lang_helper
INFO - 2023-09-11 15:29:05 --> Helper loaded: security_helper
INFO - 2023-09-11 15:29:05 --> Helper loaded: cookie_helper
INFO - 2023-09-11 15:29:05 --> Database Driver Class Initialized
INFO - 2023-09-11 15:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 15:29:05 --> Parser Class Initialized
INFO - 2023-09-11 15:29:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 15:29:05 --> Pagination Class Initialized
INFO - 2023-09-11 15:29:05 --> Form Validation Class Initialized
INFO - 2023-09-11 15:29:05 --> Controller Class Initialized
INFO - 2023-09-11 15:29:05 --> Model Class Initialized
DEBUG - 2023-09-11 15:29:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:29:05 --> Model Class Initialized
DEBUG - 2023-09-11 15:29:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:29:05 --> Model Class Initialized
INFO - 2023-09-11 15:29:05 --> Model Class Initialized
INFO - 2023-09-11 15:29:05 --> Model Class Initialized
INFO - 2023-09-11 15:29:05 --> Model Class Initialized
DEBUG - 2023-09-11 15:29:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 15:29:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:29:05 --> Model Class Initialized
INFO - 2023-09-11 15:29:05 --> Model Class Initialized
INFO - 2023-09-11 15:29:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-11 15:29:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:29:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-11 15:29:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-11 15:29:05 --> Model Class Initialized
INFO - 2023-09-11 15:29:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-11 15:29:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-11 15:29:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-11 15:29:05 --> Final output sent to browser
DEBUG - 2023-09-11 15:29:05 --> Total execution time: 0.1055
ERROR - 2023-09-11 15:29:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 15:29:10 --> Config Class Initialized
INFO - 2023-09-11 15:29:10 --> Hooks Class Initialized
DEBUG - 2023-09-11 15:29:10 --> UTF-8 Support Enabled
INFO - 2023-09-11 15:29:10 --> Utf8 Class Initialized
INFO - 2023-09-11 15:29:10 --> URI Class Initialized
INFO - 2023-09-11 15:29:10 --> Router Class Initialized
INFO - 2023-09-11 15:29:10 --> Output Class Initialized
INFO - 2023-09-11 15:29:10 --> Security Class Initialized
DEBUG - 2023-09-11 15:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 15:29:10 --> Input Class Initialized
INFO - 2023-09-11 15:29:10 --> Language Class Initialized
INFO - 2023-09-11 15:29:10 --> Loader Class Initialized
INFO - 2023-09-11 15:29:10 --> Helper loaded: url_helper
INFO - 2023-09-11 15:29:10 --> Helper loaded: file_helper
INFO - 2023-09-11 15:29:10 --> Helper loaded: html_helper
INFO - 2023-09-11 15:29:10 --> Helper loaded: text_helper
INFO - 2023-09-11 15:29:10 --> Helper loaded: form_helper
INFO - 2023-09-11 15:29:10 --> Helper loaded: lang_helper
INFO - 2023-09-11 15:29:10 --> Helper loaded: security_helper
INFO - 2023-09-11 15:29:10 --> Helper loaded: cookie_helper
INFO - 2023-09-11 15:29:10 --> Database Driver Class Initialized
INFO - 2023-09-11 15:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 15:29:10 --> Parser Class Initialized
INFO - 2023-09-11 15:29:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 15:29:10 --> Pagination Class Initialized
INFO - 2023-09-11 15:29:10 --> Form Validation Class Initialized
INFO - 2023-09-11 15:29:10 --> Controller Class Initialized
INFO - 2023-09-11 15:29:10 --> Model Class Initialized
DEBUG - 2023-09-11 15:29:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:29:10 --> Model Class Initialized
INFO - 2023-09-11 15:29:10 --> Final output sent to browser
DEBUG - 2023-09-11 15:29:10 --> Total execution time: 0.0185
ERROR - 2023-09-11 15:29:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 15:29:10 --> Config Class Initialized
INFO - 2023-09-11 15:29:10 --> Hooks Class Initialized
DEBUG - 2023-09-11 15:29:10 --> UTF-8 Support Enabled
INFO - 2023-09-11 15:29:10 --> Utf8 Class Initialized
INFO - 2023-09-11 15:29:10 --> URI Class Initialized
DEBUG - 2023-09-11 15:29:10 --> No URI present. Default controller set.
INFO - 2023-09-11 15:29:10 --> Router Class Initialized
INFO - 2023-09-11 15:29:10 --> Output Class Initialized
INFO - 2023-09-11 15:29:10 --> Security Class Initialized
DEBUG - 2023-09-11 15:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 15:29:10 --> Input Class Initialized
INFO - 2023-09-11 15:29:10 --> Language Class Initialized
INFO - 2023-09-11 15:29:10 --> Loader Class Initialized
INFO - 2023-09-11 15:29:10 --> Helper loaded: url_helper
INFO - 2023-09-11 15:29:10 --> Helper loaded: file_helper
INFO - 2023-09-11 15:29:10 --> Helper loaded: html_helper
INFO - 2023-09-11 15:29:10 --> Helper loaded: text_helper
INFO - 2023-09-11 15:29:10 --> Helper loaded: form_helper
INFO - 2023-09-11 15:29:10 --> Helper loaded: lang_helper
INFO - 2023-09-11 15:29:10 --> Helper loaded: security_helper
INFO - 2023-09-11 15:29:10 --> Helper loaded: cookie_helper
INFO - 2023-09-11 15:29:10 --> Database Driver Class Initialized
INFO - 2023-09-11 15:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 15:29:10 --> Parser Class Initialized
INFO - 2023-09-11 15:29:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 15:29:10 --> Pagination Class Initialized
INFO - 2023-09-11 15:29:10 --> Form Validation Class Initialized
INFO - 2023-09-11 15:29:10 --> Controller Class Initialized
INFO - 2023-09-11 15:29:10 --> Model Class Initialized
DEBUG - 2023-09-11 15:29:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:29:10 --> Model Class Initialized
DEBUG - 2023-09-11 15:29:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:29:10 --> Model Class Initialized
INFO - 2023-09-11 15:29:10 --> Model Class Initialized
INFO - 2023-09-11 15:29:10 --> Model Class Initialized
INFO - 2023-09-11 15:29:10 --> Model Class Initialized
DEBUG - 2023-09-11 15:29:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 15:29:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:29:10 --> Model Class Initialized
INFO - 2023-09-11 15:29:10 --> Model Class Initialized
INFO - 2023-09-11 15:29:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-11 15:29:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:29:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-11 15:29:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-11 15:29:10 --> Model Class Initialized
INFO - 2023-09-11 15:29:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-11 15:29:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-11 15:29:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-11 15:29:10 --> Final output sent to browser
DEBUG - 2023-09-11 15:29:10 --> Total execution time: 0.2123
ERROR - 2023-09-11 15:29:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 15:29:12 --> Config Class Initialized
INFO - 2023-09-11 15:29:12 --> Hooks Class Initialized
DEBUG - 2023-09-11 15:29:12 --> UTF-8 Support Enabled
INFO - 2023-09-11 15:29:12 --> Utf8 Class Initialized
INFO - 2023-09-11 15:29:12 --> URI Class Initialized
INFO - 2023-09-11 15:29:12 --> Router Class Initialized
INFO - 2023-09-11 15:29:12 --> Output Class Initialized
INFO - 2023-09-11 15:29:12 --> Security Class Initialized
DEBUG - 2023-09-11 15:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 15:29:12 --> Input Class Initialized
INFO - 2023-09-11 15:29:12 --> Language Class Initialized
INFO - 2023-09-11 15:29:12 --> Loader Class Initialized
INFO - 2023-09-11 15:29:12 --> Helper loaded: url_helper
INFO - 2023-09-11 15:29:12 --> Helper loaded: file_helper
INFO - 2023-09-11 15:29:12 --> Helper loaded: html_helper
INFO - 2023-09-11 15:29:12 --> Helper loaded: text_helper
INFO - 2023-09-11 15:29:12 --> Helper loaded: form_helper
INFO - 2023-09-11 15:29:12 --> Helper loaded: lang_helper
INFO - 2023-09-11 15:29:12 --> Helper loaded: security_helper
INFO - 2023-09-11 15:29:12 --> Helper loaded: cookie_helper
INFO - 2023-09-11 15:29:12 --> Database Driver Class Initialized
INFO - 2023-09-11 15:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 15:29:12 --> Parser Class Initialized
INFO - 2023-09-11 15:29:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 15:29:12 --> Pagination Class Initialized
INFO - 2023-09-11 15:29:12 --> Form Validation Class Initialized
INFO - 2023-09-11 15:29:12 --> Controller Class Initialized
DEBUG - 2023-09-11 15:29:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 15:29:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:29:12 --> Model Class Initialized
INFO - 2023-09-11 15:29:12 --> Final output sent to browser
DEBUG - 2023-09-11 15:29:12 --> Total execution time: 0.0144
ERROR - 2023-09-11 15:29:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 15:29:19 --> Config Class Initialized
INFO - 2023-09-11 15:29:19 --> Hooks Class Initialized
DEBUG - 2023-09-11 15:29:19 --> UTF-8 Support Enabled
INFO - 2023-09-11 15:29:19 --> Utf8 Class Initialized
INFO - 2023-09-11 15:29:19 --> URI Class Initialized
INFO - 2023-09-11 15:29:19 --> Router Class Initialized
INFO - 2023-09-11 15:29:19 --> Output Class Initialized
INFO - 2023-09-11 15:29:19 --> Security Class Initialized
DEBUG - 2023-09-11 15:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 15:29:19 --> Input Class Initialized
INFO - 2023-09-11 15:29:19 --> Language Class Initialized
INFO - 2023-09-11 15:29:19 --> Loader Class Initialized
INFO - 2023-09-11 15:29:19 --> Helper loaded: url_helper
INFO - 2023-09-11 15:29:19 --> Helper loaded: file_helper
INFO - 2023-09-11 15:29:19 --> Helper loaded: html_helper
INFO - 2023-09-11 15:29:19 --> Helper loaded: text_helper
INFO - 2023-09-11 15:29:19 --> Helper loaded: form_helper
INFO - 2023-09-11 15:29:19 --> Helper loaded: lang_helper
INFO - 2023-09-11 15:29:19 --> Helper loaded: security_helper
INFO - 2023-09-11 15:29:19 --> Helper loaded: cookie_helper
INFO - 2023-09-11 15:29:19 --> Database Driver Class Initialized
INFO - 2023-09-11 15:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 15:29:19 --> Parser Class Initialized
INFO - 2023-09-11 15:29:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 15:29:19 --> Pagination Class Initialized
INFO - 2023-09-11 15:29:19 --> Form Validation Class Initialized
INFO - 2023-09-11 15:29:19 --> Controller Class Initialized
INFO - 2023-09-11 15:29:19 --> Model Class Initialized
DEBUG - 2023-09-11 15:29:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 15:29:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:29:19 --> Model Class Initialized
DEBUG - 2023-09-11 15:29:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:29:19 --> Model Class Initialized
INFO - 2023-09-11 15:29:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-09-11 15:29:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:29:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-11 15:29:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-11 15:29:19 --> Model Class Initialized
INFO - 2023-09-11 15:29:19 --> Model Class Initialized
INFO - 2023-09-11 15:29:19 --> Model Class Initialized
INFO - 2023-09-11 15:29:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-11 15:29:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-11 15:29:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-11 15:29:19 --> Final output sent to browser
DEBUG - 2023-09-11 15:29:19 --> Total execution time: 0.0866
ERROR - 2023-09-11 15:29:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 15:29:20 --> Config Class Initialized
INFO - 2023-09-11 15:29:20 --> Hooks Class Initialized
DEBUG - 2023-09-11 15:29:20 --> UTF-8 Support Enabled
INFO - 2023-09-11 15:29:20 --> Utf8 Class Initialized
INFO - 2023-09-11 15:29:20 --> URI Class Initialized
INFO - 2023-09-11 15:29:20 --> Router Class Initialized
INFO - 2023-09-11 15:29:20 --> Output Class Initialized
INFO - 2023-09-11 15:29:20 --> Security Class Initialized
DEBUG - 2023-09-11 15:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 15:29:20 --> Input Class Initialized
INFO - 2023-09-11 15:29:20 --> Language Class Initialized
INFO - 2023-09-11 15:29:20 --> Loader Class Initialized
INFO - 2023-09-11 15:29:20 --> Helper loaded: url_helper
INFO - 2023-09-11 15:29:20 --> Helper loaded: file_helper
INFO - 2023-09-11 15:29:20 --> Helper loaded: html_helper
INFO - 2023-09-11 15:29:20 --> Helper loaded: text_helper
INFO - 2023-09-11 15:29:20 --> Helper loaded: form_helper
INFO - 2023-09-11 15:29:20 --> Helper loaded: lang_helper
INFO - 2023-09-11 15:29:20 --> Helper loaded: security_helper
INFO - 2023-09-11 15:29:20 --> Helper loaded: cookie_helper
INFO - 2023-09-11 15:29:20 --> Database Driver Class Initialized
INFO - 2023-09-11 15:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 15:29:20 --> Parser Class Initialized
INFO - 2023-09-11 15:29:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 15:29:20 --> Pagination Class Initialized
INFO - 2023-09-11 15:29:20 --> Form Validation Class Initialized
INFO - 2023-09-11 15:29:20 --> Controller Class Initialized
INFO - 2023-09-11 15:29:20 --> Model Class Initialized
DEBUG - 2023-09-11 15:29:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 15:29:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:29:20 --> Model Class Initialized
DEBUG - 2023-09-11 15:29:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:29:20 --> Model Class Initialized
INFO - 2023-09-11 15:29:20 --> Final output sent to browser
DEBUG - 2023-09-11 15:29:20 --> Total execution time: 0.0408
ERROR - 2023-09-11 15:29:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 15:29:26 --> Config Class Initialized
INFO - 2023-09-11 15:29:26 --> Hooks Class Initialized
DEBUG - 2023-09-11 15:29:26 --> UTF-8 Support Enabled
INFO - 2023-09-11 15:29:26 --> Utf8 Class Initialized
INFO - 2023-09-11 15:29:26 --> URI Class Initialized
INFO - 2023-09-11 15:29:26 --> Router Class Initialized
INFO - 2023-09-11 15:29:26 --> Output Class Initialized
INFO - 2023-09-11 15:29:26 --> Security Class Initialized
DEBUG - 2023-09-11 15:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 15:29:26 --> Input Class Initialized
INFO - 2023-09-11 15:29:26 --> Language Class Initialized
INFO - 2023-09-11 15:29:26 --> Loader Class Initialized
INFO - 2023-09-11 15:29:26 --> Helper loaded: url_helper
INFO - 2023-09-11 15:29:26 --> Helper loaded: file_helper
INFO - 2023-09-11 15:29:26 --> Helper loaded: html_helper
INFO - 2023-09-11 15:29:26 --> Helper loaded: text_helper
INFO - 2023-09-11 15:29:26 --> Helper loaded: form_helper
INFO - 2023-09-11 15:29:26 --> Helper loaded: lang_helper
INFO - 2023-09-11 15:29:26 --> Helper loaded: security_helper
INFO - 2023-09-11 15:29:26 --> Helper loaded: cookie_helper
INFO - 2023-09-11 15:29:26 --> Database Driver Class Initialized
INFO - 2023-09-11 15:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 15:29:26 --> Parser Class Initialized
INFO - 2023-09-11 15:29:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 15:29:26 --> Pagination Class Initialized
INFO - 2023-09-11 15:29:26 --> Form Validation Class Initialized
INFO - 2023-09-11 15:29:26 --> Controller Class Initialized
INFO - 2023-09-11 15:29:26 --> Model Class Initialized
DEBUG - 2023-09-11 15:29:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 15:29:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:29:26 --> Model Class Initialized
DEBUG - 2023-09-11 15:29:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:29:26 --> Model Class Initialized
INFO - 2023-09-11 15:29:26 --> Final output sent to browser
DEBUG - 2023-09-11 15:29:26 --> Total execution time: 0.3183
ERROR - 2023-09-11 15:51:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 15:51:15 --> Config Class Initialized
INFO - 2023-09-11 15:51:15 --> Hooks Class Initialized
DEBUG - 2023-09-11 15:51:15 --> UTF-8 Support Enabled
INFO - 2023-09-11 15:51:15 --> Utf8 Class Initialized
INFO - 2023-09-11 15:51:15 --> URI Class Initialized
DEBUG - 2023-09-11 15:51:15 --> No URI present. Default controller set.
INFO - 2023-09-11 15:51:15 --> Router Class Initialized
INFO - 2023-09-11 15:51:15 --> Output Class Initialized
INFO - 2023-09-11 15:51:15 --> Security Class Initialized
DEBUG - 2023-09-11 15:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 15:51:15 --> Input Class Initialized
INFO - 2023-09-11 15:51:15 --> Language Class Initialized
INFO - 2023-09-11 15:51:15 --> Loader Class Initialized
INFO - 2023-09-11 15:51:15 --> Helper loaded: url_helper
INFO - 2023-09-11 15:51:15 --> Helper loaded: file_helper
INFO - 2023-09-11 15:51:15 --> Helper loaded: html_helper
INFO - 2023-09-11 15:51:15 --> Helper loaded: text_helper
INFO - 2023-09-11 15:51:15 --> Helper loaded: form_helper
INFO - 2023-09-11 15:51:15 --> Helper loaded: lang_helper
INFO - 2023-09-11 15:51:15 --> Helper loaded: security_helper
INFO - 2023-09-11 15:51:15 --> Helper loaded: cookie_helper
INFO - 2023-09-11 15:51:15 --> Database Driver Class Initialized
INFO - 2023-09-11 15:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 15:51:15 --> Parser Class Initialized
INFO - 2023-09-11 15:51:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 15:51:15 --> Pagination Class Initialized
INFO - 2023-09-11 15:51:15 --> Form Validation Class Initialized
INFO - 2023-09-11 15:51:15 --> Controller Class Initialized
INFO - 2023-09-11 15:51:15 --> Model Class Initialized
DEBUG - 2023-09-11 15:51:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:51:15 --> Model Class Initialized
DEBUG - 2023-09-11 15:51:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:51:15 --> Model Class Initialized
INFO - 2023-09-11 15:51:15 --> Model Class Initialized
INFO - 2023-09-11 15:51:15 --> Model Class Initialized
INFO - 2023-09-11 15:51:15 --> Model Class Initialized
DEBUG - 2023-09-11 15:51:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 15:51:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:51:15 --> Model Class Initialized
INFO - 2023-09-11 15:51:15 --> Model Class Initialized
INFO - 2023-09-11 15:51:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-09-11 15:51:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:51:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-11 15:51:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-11 15:51:15 --> Model Class Initialized
INFO - 2023-09-11 15:51:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-11 15:51:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-11 15:51:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-11 15:51:15 --> Final output sent to browser
DEBUG - 2023-09-11 15:51:15 --> Total execution time: 0.1017
ERROR - 2023-09-11 15:51:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 15:51:26 --> Config Class Initialized
INFO - 2023-09-11 15:51:26 --> Hooks Class Initialized
DEBUG - 2023-09-11 15:51:26 --> UTF-8 Support Enabled
INFO - 2023-09-11 15:51:26 --> Utf8 Class Initialized
INFO - 2023-09-11 15:51:26 --> URI Class Initialized
INFO - 2023-09-11 15:51:26 --> Router Class Initialized
INFO - 2023-09-11 15:51:26 --> Output Class Initialized
INFO - 2023-09-11 15:51:26 --> Security Class Initialized
DEBUG - 2023-09-11 15:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 15:51:26 --> Input Class Initialized
INFO - 2023-09-11 15:51:26 --> Language Class Initialized
INFO - 2023-09-11 15:51:26 --> Loader Class Initialized
INFO - 2023-09-11 15:51:26 --> Helper loaded: url_helper
INFO - 2023-09-11 15:51:26 --> Helper loaded: file_helper
INFO - 2023-09-11 15:51:26 --> Helper loaded: html_helper
INFO - 2023-09-11 15:51:26 --> Helper loaded: text_helper
INFO - 2023-09-11 15:51:26 --> Helper loaded: form_helper
INFO - 2023-09-11 15:51:26 --> Helper loaded: lang_helper
INFO - 2023-09-11 15:51:26 --> Helper loaded: security_helper
INFO - 2023-09-11 15:51:26 --> Helper loaded: cookie_helper
INFO - 2023-09-11 15:51:26 --> Database Driver Class Initialized
INFO - 2023-09-11 15:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 15:51:26 --> Parser Class Initialized
INFO - 2023-09-11 15:51:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 15:51:26 --> Pagination Class Initialized
INFO - 2023-09-11 15:51:26 --> Form Validation Class Initialized
INFO - 2023-09-11 15:51:26 --> Controller Class Initialized
INFO - 2023-09-11 15:51:26 --> Model Class Initialized
DEBUG - 2023-09-11 15:51:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 15:51:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:51:26 --> Model Class Initialized
DEBUG - 2023-09-11 15:51:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:51:26 --> Model Class Initialized
INFO - 2023-09-11 15:51:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-09-11 15:51:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:51:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-09-11 15:51:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-09-11 15:51:26 --> Model Class Initialized
INFO - 2023-09-11 15:51:26 --> Model Class Initialized
INFO - 2023-09-11 15:51:26 --> Model Class Initialized
INFO - 2023-09-11 15:51:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-09-11 15:51:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-09-11 15:51:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-09-11 15:51:26 --> Final output sent to browser
DEBUG - 2023-09-11 15:51:26 --> Total execution time: 0.0880
ERROR - 2023-09-11 15:51:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 15:51:27 --> Config Class Initialized
INFO - 2023-09-11 15:51:27 --> Hooks Class Initialized
DEBUG - 2023-09-11 15:51:27 --> UTF-8 Support Enabled
INFO - 2023-09-11 15:51:27 --> Utf8 Class Initialized
INFO - 2023-09-11 15:51:27 --> URI Class Initialized
INFO - 2023-09-11 15:51:27 --> Router Class Initialized
INFO - 2023-09-11 15:51:27 --> Output Class Initialized
INFO - 2023-09-11 15:51:27 --> Security Class Initialized
DEBUG - 2023-09-11 15:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 15:51:27 --> Input Class Initialized
INFO - 2023-09-11 15:51:27 --> Language Class Initialized
INFO - 2023-09-11 15:51:27 --> Loader Class Initialized
INFO - 2023-09-11 15:51:27 --> Helper loaded: url_helper
INFO - 2023-09-11 15:51:27 --> Helper loaded: file_helper
INFO - 2023-09-11 15:51:27 --> Helper loaded: html_helper
INFO - 2023-09-11 15:51:27 --> Helper loaded: text_helper
INFO - 2023-09-11 15:51:27 --> Helper loaded: form_helper
INFO - 2023-09-11 15:51:27 --> Helper loaded: lang_helper
INFO - 2023-09-11 15:51:27 --> Helper loaded: security_helper
INFO - 2023-09-11 15:51:27 --> Helper loaded: cookie_helper
INFO - 2023-09-11 15:51:27 --> Database Driver Class Initialized
INFO - 2023-09-11 15:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 15:51:27 --> Parser Class Initialized
INFO - 2023-09-11 15:51:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 15:51:27 --> Pagination Class Initialized
INFO - 2023-09-11 15:51:27 --> Form Validation Class Initialized
INFO - 2023-09-11 15:51:27 --> Controller Class Initialized
INFO - 2023-09-11 15:51:27 --> Model Class Initialized
DEBUG - 2023-09-11 15:51:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 15:51:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:51:27 --> Model Class Initialized
DEBUG - 2023-09-11 15:51:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:51:27 --> Model Class Initialized
INFO - 2023-09-11 15:51:27 --> Final output sent to browser
DEBUG - 2023-09-11 15:51:27 --> Total execution time: 0.0496
ERROR - 2023-09-11 15:51:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-09-11 15:51:35 --> Config Class Initialized
INFO - 2023-09-11 15:51:35 --> Hooks Class Initialized
DEBUG - 2023-09-11 15:51:35 --> UTF-8 Support Enabled
INFO - 2023-09-11 15:51:35 --> Utf8 Class Initialized
INFO - 2023-09-11 15:51:35 --> URI Class Initialized
INFO - 2023-09-11 15:51:35 --> Router Class Initialized
INFO - 2023-09-11 15:51:35 --> Output Class Initialized
INFO - 2023-09-11 15:51:35 --> Security Class Initialized
DEBUG - 2023-09-11 15:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-11 15:51:35 --> Input Class Initialized
INFO - 2023-09-11 15:51:35 --> Language Class Initialized
INFO - 2023-09-11 15:51:35 --> Loader Class Initialized
INFO - 2023-09-11 15:51:35 --> Helper loaded: url_helper
INFO - 2023-09-11 15:51:35 --> Helper loaded: file_helper
INFO - 2023-09-11 15:51:35 --> Helper loaded: html_helper
INFO - 2023-09-11 15:51:35 --> Helper loaded: text_helper
INFO - 2023-09-11 15:51:35 --> Helper loaded: form_helper
INFO - 2023-09-11 15:51:35 --> Helper loaded: lang_helper
INFO - 2023-09-11 15:51:35 --> Helper loaded: security_helper
INFO - 2023-09-11 15:51:35 --> Helper loaded: cookie_helper
INFO - 2023-09-11 15:51:35 --> Database Driver Class Initialized
INFO - 2023-09-11 15:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-11 15:51:35 --> Parser Class Initialized
INFO - 2023-09-11 15:51:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-09-11 15:51:35 --> Pagination Class Initialized
INFO - 2023-09-11 15:51:35 --> Form Validation Class Initialized
INFO - 2023-09-11 15:51:35 --> Controller Class Initialized
INFO - 2023-09-11 15:51:35 --> Model Class Initialized
DEBUG - 2023-09-11 15:51:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 15:51:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:51:35 --> Model Class Initialized
DEBUG - 2023-09-11 15:51:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-09-11 15:51:35 --> Model Class Initialized
INFO - 2023-09-11 15:51:35 --> Final output sent to browser
DEBUG - 2023-09-11 15:51:35 --> Total execution time: 0.1103
