<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-25 01:15:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 01:15:16 --> Config Class Initialized
INFO - 2024-02-25 01:15:16 --> Hooks Class Initialized
DEBUG - 2024-02-25 01:15:16 --> UTF-8 Support Enabled
INFO - 2024-02-25 01:15:16 --> Utf8 Class Initialized
INFO - 2024-02-25 01:15:16 --> URI Class Initialized
DEBUG - 2024-02-25 01:15:16 --> No URI present. Default controller set.
INFO - 2024-02-25 01:15:16 --> Router Class Initialized
INFO - 2024-02-25 01:15:16 --> Output Class Initialized
INFO - 2024-02-25 01:15:16 --> Security Class Initialized
DEBUG - 2024-02-25 01:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 01:15:16 --> Input Class Initialized
INFO - 2024-02-25 01:15:16 --> Language Class Initialized
INFO - 2024-02-25 01:15:16 --> Loader Class Initialized
INFO - 2024-02-25 01:15:16 --> Helper loaded: url_helper
INFO - 2024-02-25 01:15:16 --> Helper loaded: file_helper
INFO - 2024-02-25 01:15:16 --> Helper loaded: html_helper
INFO - 2024-02-25 01:15:16 --> Helper loaded: text_helper
INFO - 2024-02-25 01:15:16 --> Helper loaded: form_helper
INFO - 2024-02-25 01:15:16 --> Helper loaded: lang_helper
INFO - 2024-02-25 01:15:16 --> Helper loaded: security_helper
INFO - 2024-02-25 01:15:16 --> Helper loaded: cookie_helper
INFO - 2024-02-25 01:15:16 --> Database Driver Class Initialized
INFO - 2024-02-25 01:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 01:15:16 --> Parser Class Initialized
INFO - 2024-02-25 01:15:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 01:15:16 --> Pagination Class Initialized
INFO - 2024-02-25 01:15:16 --> Form Validation Class Initialized
INFO - 2024-02-25 01:15:16 --> Controller Class Initialized
INFO - 2024-02-25 01:15:16 --> Model Class Initialized
DEBUG - 2024-02-25 01:15:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-25 01:15:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 01:15:16 --> Config Class Initialized
INFO - 2024-02-25 01:15:16 --> Hooks Class Initialized
DEBUG - 2024-02-25 01:15:16 --> UTF-8 Support Enabled
INFO - 2024-02-25 01:15:16 --> Utf8 Class Initialized
INFO - 2024-02-25 01:15:16 --> URI Class Initialized
INFO - 2024-02-25 01:15:16 --> Router Class Initialized
INFO - 2024-02-25 01:15:16 --> Output Class Initialized
INFO - 2024-02-25 01:15:16 --> Security Class Initialized
DEBUG - 2024-02-25 01:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 01:15:16 --> Input Class Initialized
INFO - 2024-02-25 01:15:16 --> Language Class Initialized
INFO - 2024-02-25 01:15:16 --> Loader Class Initialized
INFO - 2024-02-25 01:15:16 --> Helper loaded: url_helper
INFO - 2024-02-25 01:15:16 --> Helper loaded: file_helper
INFO - 2024-02-25 01:15:16 --> Helper loaded: html_helper
INFO - 2024-02-25 01:15:16 --> Helper loaded: text_helper
INFO - 2024-02-25 01:15:16 --> Helper loaded: form_helper
INFO - 2024-02-25 01:15:16 --> Helper loaded: lang_helper
INFO - 2024-02-25 01:15:16 --> Helper loaded: security_helper
INFO - 2024-02-25 01:15:16 --> Helper loaded: cookie_helper
INFO - 2024-02-25 01:15:16 --> Database Driver Class Initialized
INFO - 2024-02-25 01:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 01:15:16 --> Parser Class Initialized
INFO - 2024-02-25 01:15:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 01:15:16 --> Pagination Class Initialized
INFO - 2024-02-25 01:15:16 --> Form Validation Class Initialized
INFO - 2024-02-25 01:15:16 --> Controller Class Initialized
INFO - 2024-02-25 01:15:16 --> Model Class Initialized
DEBUG - 2024-02-25 01:15:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 01:15:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-25 01:15:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 01:15:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 01:15:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 01:15:16 --> Model Class Initialized
INFO - 2024-02-25 01:15:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 01:15:16 --> Final output sent to browser
DEBUG - 2024-02-25 01:15:16 --> Total execution time: 0.0405
ERROR - 2024-02-25 01:15:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 01:15:28 --> Config Class Initialized
INFO - 2024-02-25 01:15:28 --> Hooks Class Initialized
DEBUG - 2024-02-25 01:15:28 --> UTF-8 Support Enabled
INFO - 2024-02-25 01:15:28 --> Utf8 Class Initialized
INFO - 2024-02-25 01:15:28 --> URI Class Initialized
INFO - 2024-02-25 01:15:28 --> Router Class Initialized
INFO - 2024-02-25 01:15:28 --> Output Class Initialized
INFO - 2024-02-25 01:15:28 --> Security Class Initialized
DEBUG - 2024-02-25 01:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 01:15:28 --> Input Class Initialized
INFO - 2024-02-25 01:15:28 --> Language Class Initialized
INFO - 2024-02-25 01:15:28 --> Loader Class Initialized
INFO - 2024-02-25 01:15:28 --> Helper loaded: url_helper
INFO - 2024-02-25 01:15:28 --> Helper loaded: file_helper
INFO - 2024-02-25 01:15:28 --> Helper loaded: html_helper
INFO - 2024-02-25 01:15:28 --> Helper loaded: text_helper
INFO - 2024-02-25 01:15:28 --> Helper loaded: form_helper
INFO - 2024-02-25 01:15:28 --> Helper loaded: lang_helper
INFO - 2024-02-25 01:15:28 --> Helper loaded: security_helper
INFO - 2024-02-25 01:15:28 --> Helper loaded: cookie_helper
INFO - 2024-02-25 01:15:28 --> Database Driver Class Initialized
INFO - 2024-02-25 01:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 01:15:28 --> Parser Class Initialized
INFO - 2024-02-25 01:15:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 01:15:28 --> Pagination Class Initialized
INFO - 2024-02-25 01:15:28 --> Form Validation Class Initialized
INFO - 2024-02-25 01:15:28 --> Controller Class Initialized
INFO - 2024-02-25 01:15:28 --> Model Class Initialized
DEBUG - 2024-02-25 01:15:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 01:15:28 --> Model Class Initialized
INFO - 2024-02-25 01:15:28 --> Final output sent to browser
DEBUG - 2024-02-25 01:15:28 --> Total execution time: 0.0203
ERROR - 2024-02-25 01:15:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 01:15:29 --> Config Class Initialized
INFO - 2024-02-25 01:15:29 --> Hooks Class Initialized
DEBUG - 2024-02-25 01:15:29 --> UTF-8 Support Enabled
INFO - 2024-02-25 01:15:29 --> Utf8 Class Initialized
INFO - 2024-02-25 01:15:29 --> URI Class Initialized
DEBUG - 2024-02-25 01:15:29 --> No URI present. Default controller set.
INFO - 2024-02-25 01:15:29 --> Router Class Initialized
INFO - 2024-02-25 01:15:29 --> Output Class Initialized
INFO - 2024-02-25 01:15:29 --> Security Class Initialized
DEBUG - 2024-02-25 01:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 01:15:29 --> Input Class Initialized
INFO - 2024-02-25 01:15:29 --> Language Class Initialized
INFO - 2024-02-25 01:15:29 --> Loader Class Initialized
INFO - 2024-02-25 01:15:29 --> Helper loaded: url_helper
INFO - 2024-02-25 01:15:29 --> Helper loaded: file_helper
INFO - 2024-02-25 01:15:29 --> Helper loaded: html_helper
INFO - 2024-02-25 01:15:29 --> Helper loaded: text_helper
INFO - 2024-02-25 01:15:29 --> Helper loaded: form_helper
INFO - 2024-02-25 01:15:29 --> Helper loaded: lang_helper
INFO - 2024-02-25 01:15:29 --> Helper loaded: security_helper
INFO - 2024-02-25 01:15:29 --> Helper loaded: cookie_helper
INFO - 2024-02-25 01:15:29 --> Database Driver Class Initialized
INFO - 2024-02-25 01:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 01:15:29 --> Parser Class Initialized
INFO - 2024-02-25 01:15:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 01:15:29 --> Pagination Class Initialized
INFO - 2024-02-25 01:15:29 --> Form Validation Class Initialized
INFO - 2024-02-25 01:15:29 --> Controller Class Initialized
INFO - 2024-02-25 01:15:29 --> Model Class Initialized
DEBUG - 2024-02-25 01:15:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 01:15:29 --> Model Class Initialized
DEBUG - 2024-02-25 01:15:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 01:15:29 --> Model Class Initialized
INFO - 2024-02-25 01:15:29 --> Model Class Initialized
INFO - 2024-02-25 01:15:29 --> Model Class Initialized
INFO - 2024-02-25 01:15:29 --> Model Class Initialized
DEBUG - 2024-02-25 01:15:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 01:15:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 01:15:29 --> Model Class Initialized
INFO - 2024-02-25 01:15:29 --> Model Class Initialized
INFO - 2024-02-25 01:15:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-25 01:15:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 01:15:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 01:15:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 01:15:29 --> Model Class Initialized
INFO - 2024-02-25 01:15:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-25 01:15:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-25 01:15:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 01:15:29 --> Final output sent to browser
DEBUG - 2024-02-25 01:15:29 --> Total execution time: 0.2450
ERROR - 2024-02-25 01:15:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 01:15:36 --> Config Class Initialized
INFO - 2024-02-25 01:15:36 --> Hooks Class Initialized
DEBUG - 2024-02-25 01:15:36 --> UTF-8 Support Enabled
INFO - 2024-02-25 01:15:36 --> Utf8 Class Initialized
INFO - 2024-02-25 01:15:36 --> URI Class Initialized
INFO - 2024-02-25 01:15:36 --> Router Class Initialized
INFO - 2024-02-25 01:15:36 --> Output Class Initialized
INFO - 2024-02-25 01:15:36 --> Security Class Initialized
DEBUG - 2024-02-25 01:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 01:15:36 --> Input Class Initialized
INFO - 2024-02-25 01:15:36 --> Language Class Initialized
INFO - 2024-02-25 01:15:36 --> Loader Class Initialized
INFO - 2024-02-25 01:15:36 --> Helper loaded: url_helper
INFO - 2024-02-25 01:15:36 --> Helper loaded: file_helper
INFO - 2024-02-25 01:15:36 --> Helper loaded: html_helper
INFO - 2024-02-25 01:15:36 --> Helper loaded: text_helper
INFO - 2024-02-25 01:15:36 --> Helper loaded: form_helper
INFO - 2024-02-25 01:15:36 --> Helper loaded: lang_helper
INFO - 2024-02-25 01:15:36 --> Helper loaded: security_helper
INFO - 2024-02-25 01:15:36 --> Helper loaded: cookie_helper
INFO - 2024-02-25 01:15:36 --> Database Driver Class Initialized
INFO - 2024-02-25 01:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 01:15:36 --> Parser Class Initialized
INFO - 2024-02-25 01:15:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 01:15:36 --> Pagination Class Initialized
INFO - 2024-02-25 01:15:36 --> Form Validation Class Initialized
INFO - 2024-02-25 01:15:36 --> Controller Class Initialized
INFO - 2024-02-25 01:15:36 --> Model Class Initialized
DEBUG - 2024-02-25 01:15:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 01:15:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 01:15:36 --> Model Class Initialized
INFO - 2024-02-25 01:15:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2024-02-25 01:15:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 01:15:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 01:15:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 01:15:36 --> Model Class Initialized
INFO - 2024-02-25 01:15:36 --> Model Class Initialized
INFO - 2024-02-25 01:15:36 --> Model Class Initialized
INFO - 2024-02-25 01:15:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-25 01:15:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-25 01:15:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 01:15:36 --> Final output sent to browser
DEBUG - 2024-02-25 01:15:36 --> Total execution time: 0.1482
ERROR - 2024-02-25 01:15:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 01:15:36 --> Config Class Initialized
INFO - 2024-02-25 01:15:36 --> Hooks Class Initialized
DEBUG - 2024-02-25 01:15:36 --> UTF-8 Support Enabled
INFO - 2024-02-25 01:15:36 --> Utf8 Class Initialized
INFO - 2024-02-25 01:15:36 --> URI Class Initialized
INFO - 2024-02-25 01:15:36 --> Router Class Initialized
INFO - 2024-02-25 01:15:36 --> Output Class Initialized
INFO - 2024-02-25 01:15:36 --> Security Class Initialized
DEBUG - 2024-02-25 01:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 01:15:36 --> Input Class Initialized
INFO - 2024-02-25 01:15:36 --> Language Class Initialized
INFO - 2024-02-25 01:15:36 --> Loader Class Initialized
INFO - 2024-02-25 01:15:36 --> Helper loaded: url_helper
INFO - 2024-02-25 01:15:36 --> Helper loaded: file_helper
INFO - 2024-02-25 01:15:36 --> Helper loaded: html_helper
INFO - 2024-02-25 01:15:36 --> Helper loaded: text_helper
INFO - 2024-02-25 01:15:36 --> Helper loaded: form_helper
INFO - 2024-02-25 01:15:36 --> Helper loaded: lang_helper
INFO - 2024-02-25 01:15:36 --> Helper loaded: security_helper
INFO - 2024-02-25 01:15:36 --> Helper loaded: cookie_helper
INFO - 2024-02-25 01:15:36 --> Database Driver Class Initialized
INFO - 2024-02-25 01:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 01:15:36 --> Parser Class Initialized
INFO - 2024-02-25 01:15:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 01:15:36 --> Pagination Class Initialized
INFO - 2024-02-25 01:15:36 --> Form Validation Class Initialized
INFO - 2024-02-25 01:15:36 --> Controller Class Initialized
INFO - 2024-02-25 01:15:36 --> Model Class Initialized
DEBUG - 2024-02-25 01:15:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 01:15:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 01:15:36 --> Model Class Initialized
INFO - 2024-02-25 01:15:37 --> Final output sent to browser
DEBUG - 2024-02-25 01:15:37 --> Total execution time: 0.1979
ERROR - 2024-02-25 01:15:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 01:15:41 --> Config Class Initialized
INFO - 2024-02-25 01:15:41 --> Hooks Class Initialized
DEBUG - 2024-02-25 01:15:41 --> UTF-8 Support Enabled
INFO - 2024-02-25 01:15:41 --> Utf8 Class Initialized
INFO - 2024-02-25 01:15:41 --> URI Class Initialized
INFO - 2024-02-25 01:15:41 --> Router Class Initialized
INFO - 2024-02-25 01:15:41 --> Output Class Initialized
INFO - 2024-02-25 01:15:41 --> Security Class Initialized
DEBUG - 2024-02-25 01:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 01:15:41 --> Input Class Initialized
INFO - 2024-02-25 01:15:41 --> Language Class Initialized
INFO - 2024-02-25 01:15:41 --> Loader Class Initialized
INFO - 2024-02-25 01:15:41 --> Helper loaded: url_helper
INFO - 2024-02-25 01:15:41 --> Helper loaded: file_helper
INFO - 2024-02-25 01:15:41 --> Helper loaded: html_helper
INFO - 2024-02-25 01:15:41 --> Helper loaded: text_helper
INFO - 2024-02-25 01:15:41 --> Helper loaded: form_helper
INFO - 2024-02-25 01:15:41 --> Helper loaded: lang_helper
INFO - 2024-02-25 01:15:41 --> Helper loaded: security_helper
INFO - 2024-02-25 01:15:41 --> Helper loaded: cookie_helper
INFO - 2024-02-25 01:15:41 --> Database Driver Class Initialized
INFO - 2024-02-25 01:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 01:15:41 --> Parser Class Initialized
INFO - 2024-02-25 01:15:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 01:15:41 --> Pagination Class Initialized
INFO - 2024-02-25 01:15:41 --> Form Validation Class Initialized
INFO - 2024-02-25 01:15:41 --> Controller Class Initialized
INFO - 2024-02-25 01:15:41 --> Model Class Initialized
DEBUG - 2024-02-25 01:15:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 01:15:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 01:15:41 --> Model Class Initialized
INFO - 2024-02-25 01:15:42 --> Final output sent to browser
DEBUG - 2024-02-25 01:15:42 --> Total execution time: 0.1967
ERROR - 2024-02-25 01:28:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 01:28:28 --> Config Class Initialized
INFO - 2024-02-25 01:28:28 --> Hooks Class Initialized
DEBUG - 2024-02-25 01:28:28 --> UTF-8 Support Enabled
INFO - 2024-02-25 01:28:28 --> Utf8 Class Initialized
INFO - 2024-02-25 01:28:28 --> URI Class Initialized
DEBUG - 2024-02-25 01:28:28 --> No URI present. Default controller set.
INFO - 2024-02-25 01:28:28 --> Router Class Initialized
INFO - 2024-02-25 01:28:28 --> Output Class Initialized
INFO - 2024-02-25 01:28:28 --> Security Class Initialized
DEBUG - 2024-02-25 01:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 01:28:28 --> Input Class Initialized
INFO - 2024-02-25 01:28:28 --> Language Class Initialized
INFO - 2024-02-25 01:28:28 --> Loader Class Initialized
INFO - 2024-02-25 01:28:28 --> Helper loaded: url_helper
INFO - 2024-02-25 01:28:28 --> Helper loaded: file_helper
INFO - 2024-02-25 01:28:28 --> Helper loaded: html_helper
INFO - 2024-02-25 01:28:28 --> Helper loaded: text_helper
INFO - 2024-02-25 01:28:28 --> Helper loaded: form_helper
INFO - 2024-02-25 01:28:28 --> Helper loaded: lang_helper
INFO - 2024-02-25 01:28:28 --> Helper loaded: security_helper
INFO - 2024-02-25 01:28:28 --> Helper loaded: cookie_helper
INFO - 2024-02-25 01:28:28 --> Database Driver Class Initialized
INFO - 2024-02-25 01:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 01:28:28 --> Parser Class Initialized
INFO - 2024-02-25 01:28:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 01:28:28 --> Pagination Class Initialized
INFO - 2024-02-25 01:28:28 --> Form Validation Class Initialized
INFO - 2024-02-25 01:28:28 --> Controller Class Initialized
INFO - 2024-02-25 01:28:28 --> Model Class Initialized
DEBUG - 2024-02-25 01:28:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 01:28:28 --> Model Class Initialized
DEBUG - 2024-02-25 01:28:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 01:28:28 --> Model Class Initialized
INFO - 2024-02-25 01:28:28 --> Model Class Initialized
INFO - 2024-02-25 01:28:28 --> Model Class Initialized
INFO - 2024-02-25 01:28:28 --> Model Class Initialized
DEBUG - 2024-02-25 01:28:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 01:28:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 01:28:28 --> Model Class Initialized
INFO - 2024-02-25 01:28:28 --> Model Class Initialized
INFO - 2024-02-25 01:28:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-25 01:28:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 01:28:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 01:28:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 01:28:28 --> Model Class Initialized
INFO - 2024-02-25 01:28:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-25 01:28:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-25 01:28:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 01:28:28 --> Final output sent to browser
DEBUG - 2024-02-25 01:28:28 --> Total execution time: 0.2417
ERROR - 2024-02-25 01:28:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 01:28:32 --> Config Class Initialized
INFO - 2024-02-25 01:28:32 --> Hooks Class Initialized
DEBUG - 2024-02-25 01:28:32 --> UTF-8 Support Enabled
INFO - 2024-02-25 01:28:32 --> Utf8 Class Initialized
INFO - 2024-02-25 01:28:32 --> URI Class Initialized
INFO - 2024-02-25 01:28:32 --> Router Class Initialized
INFO - 2024-02-25 01:28:32 --> Output Class Initialized
INFO - 2024-02-25 01:28:32 --> Security Class Initialized
DEBUG - 2024-02-25 01:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 01:28:32 --> Input Class Initialized
INFO - 2024-02-25 01:28:32 --> Language Class Initialized
INFO - 2024-02-25 01:28:32 --> Loader Class Initialized
INFO - 2024-02-25 01:28:32 --> Helper loaded: url_helper
INFO - 2024-02-25 01:28:32 --> Helper loaded: file_helper
INFO - 2024-02-25 01:28:32 --> Helper loaded: html_helper
INFO - 2024-02-25 01:28:32 --> Helper loaded: text_helper
INFO - 2024-02-25 01:28:32 --> Helper loaded: form_helper
INFO - 2024-02-25 01:28:32 --> Helper loaded: lang_helper
INFO - 2024-02-25 01:28:32 --> Helper loaded: security_helper
INFO - 2024-02-25 01:28:32 --> Helper loaded: cookie_helper
INFO - 2024-02-25 01:28:32 --> Database Driver Class Initialized
INFO - 2024-02-25 01:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 01:28:32 --> Parser Class Initialized
INFO - 2024-02-25 01:28:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 01:28:32 --> Pagination Class Initialized
INFO - 2024-02-25 01:28:32 --> Form Validation Class Initialized
INFO - 2024-02-25 01:28:32 --> Controller Class Initialized
DEBUG - 2024-02-25 01:28:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 01:28:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 01:28:32 --> Model Class Initialized
DEBUG - 2024-02-25 01:28:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 01:28:32 --> Model Class Initialized
DEBUG - 2024-02-25 01:28:32 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-25 01:28:32 --> Model Class Initialized
INFO - 2024-02-25 01:28:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-25 01:28:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 01:28:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 01:28:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 01:28:32 --> Model Class Initialized
INFO - 2024-02-25 01:28:32 --> Model Class Initialized
INFO - 2024-02-25 01:28:32 --> Model Class Initialized
INFO - 2024-02-25 01:28:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-25 01:28:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-25 01:28:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 01:28:32 --> Final output sent to browser
DEBUG - 2024-02-25 01:28:32 --> Total execution time: 0.1585
ERROR - 2024-02-25 01:28:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 01:28:33 --> Config Class Initialized
INFO - 2024-02-25 01:28:33 --> Hooks Class Initialized
DEBUG - 2024-02-25 01:28:33 --> UTF-8 Support Enabled
INFO - 2024-02-25 01:28:33 --> Utf8 Class Initialized
INFO - 2024-02-25 01:28:33 --> URI Class Initialized
INFO - 2024-02-25 01:28:33 --> Router Class Initialized
INFO - 2024-02-25 01:28:33 --> Output Class Initialized
INFO - 2024-02-25 01:28:33 --> Security Class Initialized
DEBUG - 2024-02-25 01:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 01:28:33 --> Input Class Initialized
INFO - 2024-02-25 01:28:33 --> Language Class Initialized
INFO - 2024-02-25 01:28:33 --> Loader Class Initialized
INFO - 2024-02-25 01:28:33 --> Helper loaded: url_helper
INFO - 2024-02-25 01:28:33 --> Helper loaded: file_helper
INFO - 2024-02-25 01:28:33 --> Helper loaded: html_helper
INFO - 2024-02-25 01:28:33 --> Helper loaded: text_helper
INFO - 2024-02-25 01:28:33 --> Helper loaded: form_helper
INFO - 2024-02-25 01:28:33 --> Helper loaded: lang_helper
INFO - 2024-02-25 01:28:33 --> Helper loaded: security_helper
INFO - 2024-02-25 01:28:33 --> Helper loaded: cookie_helper
INFO - 2024-02-25 01:28:33 --> Database Driver Class Initialized
INFO - 2024-02-25 01:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 01:28:33 --> Parser Class Initialized
INFO - 2024-02-25 01:28:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 01:28:33 --> Pagination Class Initialized
INFO - 2024-02-25 01:28:33 --> Form Validation Class Initialized
INFO - 2024-02-25 01:28:33 --> Controller Class Initialized
DEBUG - 2024-02-25 01:28:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 01:28:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 01:28:33 --> Model Class Initialized
DEBUG - 2024-02-25 01:28:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 01:28:33 --> Model Class Initialized
INFO - 2024-02-25 01:28:33 --> Final output sent to browser
DEBUG - 2024-02-25 01:28:33 --> Total execution time: 0.0222
ERROR - 2024-02-25 01:28:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 01:28:38 --> Config Class Initialized
INFO - 2024-02-25 01:28:38 --> Hooks Class Initialized
DEBUG - 2024-02-25 01:28:38 --> UTF-8 Support Enabled
INFO - 2024-02-25 01:28:38 --> Utf8 Class Initialized
INFO - 2024-02-25 01:28:38 --> URI Class Initialized
INFO - 2024-02-25 01:28:38 --> Router Class Initialized
INFO - 2024-02-25 01:28:38 --> Output Class Initialized
INFO - 2024-02-25 01:28:38 --> Security Class Initialized
DEBUG - 2024-02-25 01:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 01:28:38 --> Input Class Initialized
INFO - 2024-02-25 01:28:38 --> Language Class Initialized
INFO - 2024-02-25 01:28:38 --> Loader Class Initialized
INFO - 2024-02-25 01:28:38 --> Helper loaded: url_helper
INFO - 2024-02-25 01:28:38 --> Helper loaded: file_helper
INFO - 2024-02-25 01:28:38 --> Helper loaded: html_helper
INFO - 2024-02-25 01:28:38 --> Helper loaded: text_helper
INFO - 2024-02-25 01:28:38 --> Helper loaded: form_helper
INFO - 2024-02-25 01:28:38 --> Helper loaded: lang_helper
INFO - 2024-02-25 01:28:38 --> Helper loaded: security_helper
INFO - 2024-02-25 01:28:38 --> Helper loaded: cookie_helper
INFO - 2024-02-25 01:28:38 --> Database Driver Class Initialized
INFO - 2024-02-25 01:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 01:28:38 --> Parser Class Initialized
INFO - 2024-02-25 01:28:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 01:28:38 --> Pagination Class Initialized
INFO - 2024-02-25 01:28:38 --> Form Validation Class Initialized
INFO - 2024-02-25 01:28:38 --> Controller Class Initialized
DEBUG - 2024-02-25 01:28:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 01:28:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 01:28:38 --> Model Class Initialized
DEBUG - 2024-02-25 01:28:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 01:28:38 --> Model Class Initialized
INFO - 2024-02-25 01:28:38 --> Final output sent to browser
DEBUG - 2024-02-25 01:28:38 --> Total execution time: 0.0407
ERROR - 2024-02-25 02:23:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 02:23:34 --> Config Class Initialized
INFO - 2024-02-25 02:23:34 --> Hooks Class Initialized
DEBUG - 2024-02-25 02:23:34 --> UTF-8 Support Enabled
INFO - 2024-02-25 02:23:34 --> Utf8 Class Initialized
INFO - 2024-02-25 02:23:34 --> URI Class Initialized
DEBUG - 2024-02-25 02:23:34 --> No URI present. Default controller set.
INFO - 2024-02-25 02:23:34 --> Router Class Initialized
INFO - 2024-02-25 02:23:34 --> Output Class Initialized
INFO - 2024-02-25 02:23:34 --> Security Class Initialized
DEBUG - 2024-02-25 02:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 02:23:34 --> Input Class Initialized
INFO - 2024-02-25 02:23:34 --> Language Class Initialized
INFO - 2024-02-25 02:23:34 --> Loader Class Initialized
INFO - 2024-02-25 02:23:34 --> Helper loaded: url_helper
INFO - 2024-02-25 02:23:34 --> Helper loaded: file_helper
INFO - 2024-02-25 02:23:34 --> Helper loaded: html_helper
INFO - 2024-02-25 02:23:34 --> Helper loaded: text_helper
INFO - 2024-02-25 02:23:34 --> Helper loaded: form_helper
INFO - 2024-02-25 02:23:34 --> Helper loaded: lang_helper
INFO - 2024-02-25 02:23:34 --> Helper loaded: security_helper
INFO - 2024-02-25 02:23:34 --> Helper loaded: cookie_helper
INFO - 2024-02-25 02:23:34 --> Database Driver Class Initialized
INFO - 2024-02-25 02:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 02:23:34 --> Parser Class Initialized
INFO - 2024-02-25 02:23:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 02:23:34 --> Pagination Class Initialized
INFO - 2024-02-25 02:23:34 --> Form Validation Class Initialized
INFO - 2024-02-25 02:23:34 --> Controller Class Initialized
INFO - 2024-02-25 02:23:34 --> Model Class Initialized
DEBUG - 2024-02-25 02:23:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 02:23:34 --> Model Class Initialized
DEBUG - 2024-02-25 02:23:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 02:23:34 --> Model Class Initialized
INFO - 2024-02-25 02:23:34 --> Model Class Initialized
INFO - 2024-02-25 02:23:34 --> Model Class Initialized
INFO - 2024-02-25 02:23:34 --> Model Class Initialized
DEBUG - 2024-02-25 02:23:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 02:23:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 02:23:34 --> Model Class Initialized
INFO - 2024-02-25 02:23:34 --> Model Class Initialized
INFO - 2024-02-25 02:23:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-25 02:23:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 02:23:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 02:23:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 02:23:34 --> Model Class Initialized
INFO - 2024-02-25 02:23:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-25 02:23:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-25 02:23:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 02:23:35 --> Final output sent to browser
DEBUG - 2024-02-25 02:23:35 --> Total execution time: 0.2573
ERROR - 2024-02-25 03:12:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 03:12:57 --> Config Class Initialized
INFO - 2024-02-25 03:12:57 --> Hooks Class Initialized
DEBUG - 2024-02-25 03:12:57 --> UTF-8 Support Enabled
INFO - 2024-02-25 03:12:57 --> Utf8 Class Initialized
INFO - 2024-02-25 03:12:57 --> URI Class Initialized
INFO - 2024-02-25 03:12:57 --> Router Class Initialized
INFO - 2024-02-25 03:12:57 --> Output Class Initialized
INFO - 2024-02-25 03:12:57 --> Security Class Initialized
DEBUG - 2024-02-25 03:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 03:12:57 --> Input Class Initialized
INFO - 2024-02-25 03:12:57 --> Language Class Initialized
ERROR - 2024-02-25 03:12:57 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-02-25 05:30:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 05:30:43 --> Config Class Initialized
INFO - 2024-02-25 05:30:43 --> Hooks Class Initialized
DEBUG - 2024-02-25 05:30:43 --> UTF-8 Support Enabled
INFO - 2024-02-25 05:30:43 --> Utf8 Class Initialized
INFO - 2024-02-25 05:30:43 --> URI Class Initialized
DEBUG - 2024-02-25 05:30:43 --> No URI present. Default controller set.
INFO - 2024-02-25 05:30:43 --> Router Class Initialized
INFO - 2024-02-25 05:30:43 --> Output Class Initialized
INFO - 2024-02-25 05:30:43 --> Security Class Initialized
DEBUG - 2024-02-25 05:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 05:30:43 --> Input Class Initialized
INFO - 2024-02-25 05:30:43 --> Language Class Initialized
INFO - 2024-02-25 05:30:43 --> Loader Class Initialized
INFO - 2024-02-25 05:30:43 --> Helper loaded: url_helper
INFO - 2024-02-25 05:30:43 --> Helper loaded: file_helper
INFO - 2024-02-25 05:30:43 --> Helper loaded: html_helper
INFO - 2024-02-25 05:30:43 --> Helper loaded: text_helper
INFO - 2024-02-25 05:30:43 --> Helper loaded: form_helper
INFO - 2024-02-25 05:30:43 --> Helper loaded: lang_helper
INFO - 2024-02-25 05:30:43 --> Helper loaded: security_helper
INFO - 2024-02-25 05:30:43 --> Helper loaded: cookie_helper
INFO - 2024-02-25 05:30:43 --> Database Driver Class Initialized
INFO - 2024-02-25 05:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 05:30:43 --> Parser Class Initialized
INFO - 2024-02-25 05:30:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 05:30:43 --> Pagination Class Initialized
INFO - 2024-02-25 05:30:43 --> Form Validation Class Initialized
INFO - 2024-02-25 05:30:43 --> Controller Class Initialized
INFO - 2024-02-25 05:30:43 --> Model Class Initialized
DEBUG - 2024-02-25 05:30:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-25 05:30:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 05:30:43 --> Config Class Initialized
INFO - 2024-02-25 05:30:43 --> Hooks Class Initialized
DEBUG - 2024-02-25 05:30:43 --> UTF-8 Support Enabled
INFO - 2024-02-25 05:30:43 --> Utf8 Class Initialized
INFO - 2024-02-25 05:30:43 --> URI Class Initialized
INFO - 2024-02-25 05:30:43 --> Router Class Initialized
INFO - 2024-02-25 05:30:43 --> Output Class Initialized
INFO - 2024-02-25 05:30:43 --> Security Class Initialized
DEBUG - 2024-02-25 05:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 05:30:43 --> Input Class Initialized
INFO - 2024-02-25 05:30:43 --> Language Class Initialized
INFO - 2024-02-25 05:30:43 --> Loader Class Initialized
INFO - 2024-02-25 05:30:43 --> Helper loaded: url_helper
INFO - 2024-02-25 05:30:43 --> Helper loaded: file_helper
INFO - 2024-02-25 05:30:43 --> Helper loaded: html_helper
INFO - 2024-02-25 05:30:43 --> Helper loaded: text_helper
INFO - 2024-02-25 05:30:43 --> Helper loaded: form_helper
INFO - 2024-02-25 05:30:43 --> Helper loaded: lang_helper
INFO - 2024-02-25 05:30:43 --> Helper loaded: security_helper
INFO - 2024-02-25 05:30:43 --> Helper loaded: cookie_helper
INFO - 2024-02-25 05:30:43 --> Database Driver Class Initialized
INFO - 2024-02-25 05:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 05:30:43 --> Parser Class Initialized
INFO - 2024-02-25 05:30:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 05:30:43 --> Pagination Class Initialized
INFO - 2024-02-25 05:30:43 --> Form Validation Class Initialized
INFO - 2024-02-25 05:30:43 --> Controller Class Initialized
INFO - 2024-02-25 05:30:43 --> Model Class Initialized
DEBUG - 2024-02-25 05:30:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 05:30:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-25 05:30:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 05:30:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 05:30:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 05:30:43 --> Model Class Initialized
INFO - 2024-02-25 05:30:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 05:30:43 --> Final output sent to browser
DEBUG - 2024-02-25 05:30:43 --> Total execution time: 0.0339
ERROR - 2024-02-25 05:40:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 05:40:09 --> Config Class Initialized
INFO - 2024-02-25 05:40:09 --> Hooks Class Initialized
DEBUG - 2024-02-25 05:40:09 --> UTF-8 Support Enabled
INFO - 2024-02-25 05:40:09 --> Utf8 Class Initialized
INFO - 2024-02-25 05:40:09 --> URI Class Initialized
DEBUG - 2024-02-25 05:40:09 --> No URI present. Default controller set.
INFO - 2024-02-25 05:40:09 --> Router Class Initialized
INFO - 2024-02-25 05:40:09 --> Output Class Initialized
INFO - 2024-02-25 05:40:09 --> Security Class Initialized
DEBUG - 2024-02-25 05:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 05:40:09 --> Input Class Initialized
INFO - 2024-02-25 05:40:09 --> Language Class Initialized
INFO - 2024-02-25 05:40:09 --> Loader Class Initialized
INFO - 2024-02-25 05:40:09 --> Helper loaded: url_helper
INFO - 2024-02-25 05:40:09 --> Helper loaded: file_helper
INFO - 2024-02-25 05:40:09 --> Helper loaded: html_helper
INFO - 2024-02-25 05:40:09 --> Helper loaded: text_helper
INFO - 2024-02-25 05:40:09 --> Helper loaded: form_helper
INFO - 2024-02-25 05:40:09 --> Helper loaded: lang_helper
INFO - 2024-02-25 05:40:09 --> Helper loaded: security_helper
INFO - 2024-02-25 05:40:09 --> Helper loaded: cookie_helper
INFO - 2024-02-25 05:40:09 --> Database Driver Class Initialized
INFO - 2024-02-25 05:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 05:40:09 --> Parser Class Initialized
INFO - 2024-02-25 05:40:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 05:40:09 --> Pagination Class Initialized
INFO - 2024-02-25 05:40:09 --> Form Validation Class Initialized
INFO - 2024-02-25 05:40:09 --> Controller Class Initialized
INFO - 2024-02-25 05:40:09 --> Model Class Initialized
DEBUG - 2024-02-25 05:40:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-25 05:40:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 05:40:09 --> Config Class Initialized
INFO - 2024-02-25 05:40:09 --> Hooks Class Initialized
DEBUG - 2024-02-25 05:40:09 --> UTF-8 Support Enabled
INFO - 2024-02-25 05:40:09 --> Utf8 Class Initialized
INFO - 2024-02-25 05:40:09 --> URI Class Initialized
INFO - 2024-02-25 05:40:09 --> Router Class Initialized
INFO - 2024-02-25 05:40:09 --> Output Class Initialized
INFO - 2024-02-25 05:40:09 --> Security Class Initialized
DEBUG - 2024-02-25 05:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 05:40:09 --> Input Class Initialized
INFO - 2024-02-25 05:40:09 --> Language Class Initialized
INFO - 2024-02-25 05:40:09 --> Loader Class Initialized
INFO - 2024-02-25 05:40:09 --> Helper loaded: url_helper
INFO - 2024-02-25 05:40:09 --> Helper loaded: file_helper
INFO - 2024-02-25 05:40:09 --> Helper loaded: html_helper
INFO - 2024-02-25 05:40:09 --> Helper loaded: text_helper
INFO - 2024-02-25 05:40:09 --> Helper loaded: form_helper
INFO - 2024-02-25 05:40:09 --> Helper loaded: lang_helper
INFO - 2024-02-25 05:40:09 --> Helper loaded: security_helper
INFO - 2024-02-25 05:40:09 --> Helper loaded: cookie_helper
INFO - 2024-02-25 05:40:09 --> Database Driver Class Initialized
INFO - 2024-02-25 05:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 05:40:09 --> Parser Class Initialized
INFO - 2024-02-25 05:40:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 05:40:09 --> Pagination Class Initialized
INFO - 2024-02-25 05:40:09 --> Form Validation Class Initialized
INFO - 2024-02-25 05:40:09 --> Controller Class Initialized
INFO - 2024-02-25 05:40:09 --> Model Class Initialized
DEBUG - 2024-02-25 05:40:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 05:40:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-25 05:40:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 05:40:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 05:40:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 05:40:09 --> Model Class Initialized
INFO - 2024-02-25 05:40:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 05:40:09 --> Final output sent to browser
DEBUG - 2024-02-25 05:40:09 --> Total execution time: 0.0316
ERROR - 2024-02-25 05:40:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 05:40:13 --> Config Class Initialized
INFO - 2024-02-25 05:40:13 --> Hooks Class Initialized
DEBUG - 2024-02-25 05:40:13 --> UTF-8 Support Enabled
INFO - 2024-02-25 05:40:13 --> Utf8 Class Initialized
INFO - 2024-02-25 05:40:13 --> URI Class Initialized
INFO - 2024-02-25 05:40:13 --> Router Class Initialized
INFO - 2024-02-25 05:40:13 --> Output Class Initialized
INFO - 2024-02-25 05:40:13 --> Security Class Initialized
DEBUG - 2024-02-25 05:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 05:40:13 --> Input Class Initialized
INFO - 2024-02-25 05:40:13 --> Language Class Initialized
INFO - 2024-02-25 05:40:13 --> Loader Class Initialized
INFO - 2024-02-25 05:40:13 --> Helper loaded: url_helper
INFO - 2024-02-25 05:40:13 --> Helper loaded: file_helper
INFO - 2024-02-25 05:40:13 --> Helper loaded: html_helper
INFO - 2024-02-25 05:40:13 --> Helper loaded: text_helper
INFO - 2024-02-25 05:40:13 --> Helper loaded: form_helper
INFO - 2024-02-25 05:40:13 --> Helper loaded: lang_helper
INFO - 2024-02-25 05:40:13 --> Helper loaded: security_helper
INFO - 2024-02-25 05:40:13 --> Helper loaded: cookie_helper
INFO - 2024-02-25 05:40:13 --> Database Driver Class Initialized
INFO - 2024-02-25 05:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 05:40:13 --> Parser Class Initialized
INFO - 2024-02-25 05:40:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 05:40:13 --> Pagination Class Initialized
INFO - 2024-02-25 05:40:13 --> Form Validation Class Initialized
INFO - 2024-02-25 05:40:13 --> Controller Class Initialized
INFO - 2024-02-25 05:40:13 --> Model Class Initialized
DEBUG - 2024-02-25 05:40:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 05:40:13 --> Model Class Initialized
INFO - 2024-02-25 05:40:13 --> Final output sent to browser
DEBUG - 2024-02-25 05:40:13 --> Total execution time: 0.0196
ERROR - 2024-02-25 05:40:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 05:40:13 --> Config Class Initialized
INFO - 2024-02-25 05:40:13 --> Hooks Class Initialized
DEBUG - 2024-02-25 05:40:13 --> UTF-8 Support Enabled
INFO - 2024-02-25 05:40:13 --> Utf8 Class Initialized
INFO - 2024-02-25 05:40:13 --> URI Class Initialized
DEBUG - 2024-02-25 05:40:13 --> No URI present. Default controller set.
INFO - 2024-02-25 05:40:13 --> Router Class Initialized
INFO - 2024-02-25 05:40:13 --> Output Class Initialized
INFO - 2024-02-25 05:40:13 --> Security Class Initialized
DEBUG - 2024-02-25 05:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 05:40:13 --> Input Class Initialized
INFO - 2024-02-25 05:40:13 --> Language Class Initialized
INFO - 2024-02-25 05:40:13 --> Loader Class Initialized
INFO - 2024-02-25 05:40:13 --> Helper loaded: url_helper
INFO - 2024-02-25 05:40:13 --> Helper loaded: file_helper
INFO - 2024-02-25 05:40:13 --> Helper loaded: html_helper
INFO - 2024-02-25 05:40:13 --> Helper loaded: text_helper
INFO - 2024-02-25 05:40:13 --> Helper loaded: form_helper
INFO - 2024-02-25 05:40:13 --> Helper loaded: lang_helper
INFO - 2024-02-25 05:40:13 --> Helper loaded: security_helper
INFO - 2024-02-25 05:40:13 --> Helper loaded: cookie_helper
INFO - 2024-02-25 05:40:13 --> Database Driver Class Initialized
INFO - 2024-02-25 05:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 05:40:13 --> Parser Class Initialized
INFO - 2024-02-25 05:40:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 05:40:13 --> Pagination Class Initialized
INFO - 2024-02-25 05:40:13 --> Form Validation Class Initialized
INFO - 2024-02-25 05:40:13 --> Controller Class Initialized
INFO - 2024-02-25 05:40:13 --> Model Class Initialized
DEBUG - 2024-02-25 05:40:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 05:40:13 --> Model Class Initialized
DEBUG - 2024-02-25 05:40:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 05:40:13 --> Model Class Initialized
INFO - 2024-02-25 05:40:13 --> Model Class Initialized
INFO - 2024-02-25 05:40:13 --> Model Class Initialized
INFO - 2024-02-25 05:40:13 --> Model Class Initialized
DEBUG - 2024-02-25 05:40:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 05:40:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 05:40:13 --> Model Class Initialized
INFO - 2024-02-25 05:40:13 --> Model Class Initialized
INFO - 2024-02-25 05:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-25 05:40:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 05:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 05:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 05:40:13 --> Model Class Initialized
INFO - 2024-02-25 05:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-25 05:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-25 05:40:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 05:40:13 --> Final output sent to browser
DEBUG - 2024-02-25 05:40:13 --> Total execution time: 0.4479
ERROR - 2024-02-25 05:40:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 05:40:15 --> Config Class Initialized
INFO - 2024-02-25 05:40:15 --> Hooks Class Initialized
DEBUG - 2024-02-25 05:40:15 --> UTF-8 Support Enabled
INFO - 2024-02-25 05:40:15 --> Utf8 Class Initialized
INFO - 2024-02-25 05:40:15 --> URI Class Initialized
INFO - 2024-02-25 05:40:15 --> Router Class Initialized
INFO - 2024-02-25 05:40:15 --> Output Class Initialized
INFO - 2024-02-25 05:40:15 --> Security Class Initialized
DEBUG - 2024-02-25 05:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 05:40:15 --> Input Class Initialized
INFO - 2024-02-25 05:40:15 --> Language Class Initialized
INFO - 2024-02-25 05:40:15 --> Loader Class Initialized
INFO - 2024-02-25 05:40:15 --> Helper loaded: url_helper
INFO - 2024-02-25 05:40:15 --> Helper loaded: file_helper
INFO - 2024-02-25 05:40:15 --> Helper loaded: html_helper
INFO - 2024-02-25 05:40:15 --> Helper loaded: text_helper
INFO - 2024-02-25 05:40:15 --> Helper loaded: form_helper
INFO - 2024-02-25 05:40:15 --> Helper loaded: lang_helper
INFO - 2024-02-25 05:40:15 --> Helper loaded: security_helper
INFO - 2024-02-25 05:40:15 --> Helper loaded: cookie_helper
INFO - 2024-02-25 05:40:15 --> Database Driver Class Initialized
INFO - 2024-02-25 05:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 05:40:15 --> Parser Class Initialized
INFO - 2024-02-25 05:40:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 05:40:15 --> Pagination Class Initialized
INFO - 2024-02-25 05:40:15 --> Form Validation Class Initialized
INFO - 2024-02-25 05:40:15 --> Controller Class Initialized
DEBUG - 2024-02-25 05:40:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 05:40:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 05:40:15 --> Model Class Initialized
INFO - 2024-02-25 05:40:15 --> Final output sent to browser
DEBUG - 2024-02-25 05:40:15 --> Total execution time: 0.0155
ERROR - 2024-02-25 05:40:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 05:40:22 --> Config Class Initialized
INFO - 2024-02-25 05:40:22 --> Hooks Class Initialized
DEBUG - 2024-02-25 05:40:22 --> UTF-8 Support Enabled
INFO - 2024-02-25 05:40:22 --> Utf8 Class Initialized
INFO - 2024-02-25 05:40:22 --> URI Class Initialized
INFO - 2024-02-25 05:40:22 --> Router Class Initialized
INFO - 2024-02-25 05:40:22 --> Output Class Initialized
INFO - 2024-02-25 05:40:22 --> Security Class Initialized
DEBUG - 2024-02-25 05:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 05:40:22 --> Input Class Initialized
INFO - 2024-02-25 05:40:22 --> Language Class Initialized
INFO - 2024-02-25 05:40:22 --> Loader Class Initialized
INFO - 2024-02-25 05:40:22 --> Helper loaded: url_helper
INFO - 2024-02-25 05:40:22 --> Helper loaded: file_helper
INFO - 2024-02-25 05:40:22 --> Helper loaded: html_helper
INFO - 2024-02-25 05:40:22 --> Helper loaded: text_helper
INFO - 2024-02-25 05:40:22 --> Helper loaded: form_helper
INFO - 2024-02-25 05:40:22 --> Helper loaded: lang_helper
INFO - 2024-02-25 05:40:22 --> Helper loaded: security_helper
INFO - 2024-02-25 05:40:22 --> Helper loaded: cookie_helper
INFO - 2024-02-25 05:40:22 --> Database Driver Class Initialized
INFO - 2024-02-25 05:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 05:40:22 --> Parser Class Initialized
INFO - 2024-02-25 05:40:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 05:40:22 --> Pagination Class Initialized
INFO - 2024-02-25 05:40:22 --> Form Validation Class Initialized
INFO - 2024-02-25 05:40:22 --> Controller Class Initialized
INFO - 2024-02-25 05:40:22 --> Model Class Initialized
DEBUG - 2024-02-25 05:40:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 05:40:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 05:40:22 --> Model Class Initialized
DEBUG - 2024-02-25 05:40:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 05:40:22 --> Model Class Initialized
INFO - 2024-02-25 05:40:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-25 05:40:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 05:40:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 05:40:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 05:40:22 --> Model Class Initialized
INFO - 2024-02-25 05:40:22 --> Model Class Initialized
INFO - 2024-02-25 05:40:22 --> Model Class Initialized
INFO - 2024-02-25 05:40:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-25 05:40:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-25 05:40:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 05:40:22 --> Final output sent to browser
DEBUG - 2024-02-25 05:40:22 --> Total execution time: 0.2396
ERROR - 2024-02-25 05:40:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 05:40:23 --> Config Class Initialized
INFO - 2024-02-25 05:40:23 --> Hooks Class Initialized
DEBUG - 2024-02-25 05:40:23 --> UTF-8 Support Enabled
INFO - 2024-02-25 05:40:23 --> Utf8 Class Initialized
INFO - 2024-02-25 05:40:23 --> URI Class Initialized
INFO - 2024-02-25 05:40:23 --> Router Class Initialized
INFO - 2024-02-25 05:40:23 --> Output Class Initialized
INFO - 2024-02-25 05:40:23 --> Security Class Initialized
DEBUG - 2024-02-25 05:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 05:40:23 --> Input Class Initialized
INFO - 2024-02-25 05:40:23 --> Language Class Initialized
INFO - 2024-02-25 05:40:23 --> Loader Class Initialized
INFO - 2024-02-25 05:40:23 --> Helper loaded: url_helper
INFO - 2024-02-25 05:40:23 --> Helper loaded: file_helper
INFO - 2024-02-25 05:40:23 --> Helper loaded: html_helper
INFO - 2024-02-25 05:40:23 --> Helper loaded: text_helper
INFO - 2024-02-25 05:40:23 --> Helper loaded: form_helper
INFO - 2024-02-25 05:40:23 --> Helper loaded: lang_helper
INFO - 2024-02-25 05:40:23 --> Helper loaded: security_helper
INFO - 2024-02-25 05:40:23 --> Helper loaded: cookie_helper
INFO - 2024-02-25 05:40:23 --> Database Driver Class Initialized
INFO - 2024-02-25 05:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 05:40:23 --> Parser Class Initialized
INFO - 2024-02-25 05:40:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 05:40:23 --> Pagination Class Initialized
INFO - 2024-02-25 05:40:23 --> Form Validation Class Initialized
INFO - 2024-02-25 05:40:23 --> Controller Class Initialized
INFO - 2024-02-25 05:40:23 --> Model Class Initialized
DEBUG - 2024-02-25 05:40:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 05:40:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 05:40:23 --> Model Class Initialized
DEBUG - 2024-02-25 05:40:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 05:40:23 --> Model Class Initialized
INFO - 2024-02-25 05:40:23 --> Final output sent to browser
DEBUG - 2024-02-25 05:40:23 --> Total execution time: 0.0625
ERROR - 2024-02-25 05:40:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 05:40:31 --> Config Class Initialized
INFO - 2024-02-25 05:40:31 --> Hooks Class Initialized
DEBUG - 2024-02-25 05:40:31 --> UTF-8 Support Enabled
INFO - 2024-02-25 05:40:31 --> Utf8 Class Initialized
INFO - 2024-02-25 05:40:31 --> URI Class Initialized
INFO - 2024-02-25 05:40:31 --> Router Class Initialized
INFO - 2024-02-25 05:40:31 --> Output Class Initialized
INFO - 2024-02-25 05:40:31 --> Security Class Initialized
DEBUG - 2024-02-25 05:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 05:40:31 --> Input Class Initialized
INFO - 2024-02-25 05:40:31 --> Language Class Initialized
INFO - 2024-02-25 05:40:31 --> Loader Class Initialized
INFO - 2024-02-25 05:40:31 --> Helper loaded: url_helper
INFO - 2024-02-25 05:40:31 --> Helper loaded: file_helper
INFO - 2024-02-25 05:40:31 --> Helper loaded: html_helper
INFO - 2024-02-25 05:40:31 --> Helper loaded: text_helper
INFO - 2024-02-25 05:40:31 --> Helper loaded: form_helper
INFO - 2024-02-25 05:40:31 --> Helper loaded: lang_helper
INFO - 2024-02-25 05:40:31 --> Helper loaded: security_helper
INFO - 2024-02-25 05:40:31 --> Helper loaded: cookie_helper
INFO - 2024-02-25 05:40:31 --> Database Driver Class Initialized
INFO - 2024-02-25 05:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 05:40:31 --> Parser Class Initialized
INFO - 2024-02-25 05:40:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 05:40:31 --> Pagination Class Initialized
INFO - 2024-02-25 05:40:31 --> Form Validation Class Initialized
INFO - 2024-02-25 05:40:31 --> Controller Class Initialized
INFO - 2024-02-25 05:40:31 --> Model Class Initialized
DEBUG - 2024-02-25 05:40:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 05:40:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 05:40:31 --> Model Class Initialized
DEBUG - 2024-02-25 05:40:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 05:40:31 --> Model Class Initialized
INFO - 2024-02-25 05:40:32 --> Final output sent to browser
DEBUG - 2024-02-25 05:40:32 --> Total execution time: 0.0606
ERROR - 2024-02-25 05:40:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 05:40:36 --> Config Class Initialized
INFO - 2024-02-25 05:40:36 --> Hooks Class Initialized
DEBUG - 2024-02-25 05:40:36 --> UTF-8 Support Enabled
INFO - 2024-02-25 05:40:36 --> Utf8 Class Initialized
INFO - 2024-02-25 05:40:36 --> URI Class Initialized
INFO - 2024-02-25 05:40:36 --> Router Class Initialized
INFO - 2024-02-25 05:40:36 --> Output Class Initialized
INFO - 2024-02-25 05:40:36 --> Security Class Initialized
DEBUG - 2024-02-25 05:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 05:40:36 --> Input Class Initialized
INFO - 2024-02-25 05:40:36 --> Language Class Initialized
INFO - 2024-02-25 05:40:36 --> Loader Class Initialized
INFO - 2024-02-25 05:40:36 --> Helper loaded: url_helper
INFO - 2024-02-25 05:40:36 --> Helper loaded: file_helper
INFO - 2024-02-25 05:40:36 --> Helper loaded: html_helper
INFO - 2024-02-25 05:40:36 --> Helper loaded: text_helper
INFO - 2024-02-25 05:40:36 --> Helper loaded: form_helper
INFO - 2024-02-25 05:40:36 --> Helper loaded: lang_helper
INFO - 2024-02-25 05:40:36 --> Helper loaded: security_helper
INFO - 2024-02-25 05:40:36 --> Helper loaded: cookie_helper
INFO - 2024-02-25 05:40:36 --> Database Driver Class Initialized
INFO - 2024-02-25 05:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 05:40:36 --> Parser Class Initialized
INFO - 2024-02-25 05:40:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 05:40:36 --> Pagination Class Initialized
INFO - 2024-02-25 05:40:36 --> Form Validation Class Initialized
INFO - 2024-02-25 05:40:36 --> Controller Class Initialized
INFO - 2024-02-25 05:40:36 --> Model Class Initialized
DEBUG - 2024-02-25 05:40:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 05:40:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 05:40:36 --> Model Class Initialized
DEBUG - 2024-02-25 05:40:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 05:40:36 --> Model Class Initialized
INFO - 2024-02-25 05:40:37 --> Final output sent to browser
DEBUG - 2024-02-25 05:40:37 --> Total execution time: 0.4226
ERROR - 2024-02-25 05:43:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 05:43:51 --> Config Class Initialized
INFO - 2024-02-25 05:43:51 --> Hooks Class Initialized
DEBUG - 2024-02-25 05:43:51 --> UTF-8 Support Enabled
INFO - 2024-02-25 05:43:51 --> Utf8 Class Initialized
INFO - 2024-02-25 05:43:51 --> URI Class Initialized
INFO - 2024-02-25 05:43:51 --> Router Class Initialized
INFO - 2024-02-25 05:43:51 --> Output Class Initialized
INFO - 2024-02-25 05:43:51 --> Security Class Initialized
DEBUG - 2024-02-25 05:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 05:43:51 --> Input Class Initialized
INFO - 2024-02-25 05:43:51 --> Language Class Initialized
INFO - 2024-02-25 05:43:51 --> Loader Class Initialized
INFO - 2024-02-25 05:43:51 --> Helper loaded: url_helper
INFO - 2024-02-25 05:43:51 --> Helper loaded: file_helper
INFO - 2024-02-25 05:43:51 --> Helper loaded: html_helper
INFO - 2024-02-25 05:43:51 --> Helper loaded: text_helper
INFO - 2024-02-25 05:43:51 --> Helper loaded: form_helper
INFO - 2024-02-25 05:43:51 --> Helper loaded: lang_helper
INFO - 2024-02-25 05:43:51 --> Helper loaded: security_helper
INFO - 2024-02-25 05:43:51 --> Helper loaded: cookie_helper
INFO - 2024-02-25 05:43:51 --> Database Driver Class Initialized
INFO - 2024-02-25 05:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 05:43:51 --> Parser Class Initialized
INFO - 2024-02-25 05:43:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 05:43:51 --> Pagination Class Initialized
INFO - 2024-02-25 05:43:51 --> Form Validation Class Initialized
INFO - 2024-02-25 05:43:51 --> Controller Class Initialized
INFO - 2024-02-25 05:43:51 --> Model Class Initialized
DEBUG - 2024-02-25 05:43:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 05:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 05:43:51 --> Model Class Initialized
DEBUG - 2024-02-25 05:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 05:43:51 --> Model Class Initialized
INFO - 2024-02-25 05:43:51 --> Final output sent to browser
DEBUG - 2024-02-25 05:43:51 --> Total execution time: 0.3494
ERROR - 2024-02-25 05:43:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 05:43:54 --> Config Class Initialized
INFO - 2024-02-25 05:43:54 --> Hooks Class Initialized
DEBUG - 2024-02-25 05:43:54 --> UTF-8 Support Enabled
INFO - 2024-02-25 05:43:54 --> Utf8 Class Initialized
INFO - 2024-02-25 05:43:54 --> URI Class Initialized
INFO - 2024-02-25 05:43:54 --> Router Class Initialized
INFO - 2024-02-25 05:43:54 --> Output Class Initialized
INFO - 2024-02-25 05:43:54 --> Security Class Initialized
DEBUG - 2024-02-25 05:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 05:43:54 --> Input Class Initialized
INFO - 2024-02-25 05:43:54 --> Language Class Initialized
INFO - 2024-02-25 05:43:54 --> Loader Class Initialized
INFO - 2024-02-25 05:43:54 --> Helper loaded: url_helper
INFO - 2024-02-25 05:43:54 --> Helper loaded: file_helper
INFO - 2024-02-25 05:43:54 --> Helper loaded: html_helper
INFO - 2024-02-25 05:43:54 --> Helper loaded: text_helper
INFO - 2024-02-25 05:43:54 --> Helper loaded: form_helper
INFO - 2024-02-25 05:43:54 --> Helper loaded: lang_helper
INFO - 2024-02-25 05:43:54 --> Helper loaded: security_helper
INFO - 2024-02-25 05:43:54 --> Helper loaded: cookie_helper
INFO - 2024-02-25 05:43:54 --> Database Driver Class Initialized
INFO - 2024-02-25 05:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 05:43:54 --> Parser Class Initialized
INFO - 2024-02-25 05:43:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 05:43:54 --> Pagination Class Initialized
INFO - 2024-02-25 05:43:54 --> Form Validation Class Initialized
INFO - 2024-02-25 05:43:54 --> Controller Class Initialized
INFO - 2024-02-25 05:43:54 --> Model Class Initialized
DEBUG - 2024-02-25 05:43:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 05:43:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 05:43:54 --> Model Class Initialized
DEBUG - 2024-02-25 05:43:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 05:43:54 --> Model Class Initialized
INFO - 2024-02-25 05:43:54 --> Final output sent to browser
DEBUG - 2024-02-25 05:43:54 --> Total execution time: 0.3425
ERROR - 2024-02-25 06:42:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 06:42:58 --> Config Class Initialized
INFO - 2024-02-25 06:42:58 --> Hooks Class Initialized
DEBUG - 2024-02-25 06:42:58 --> UTF-8 Support Enabled
INFO - 2024-02-25 06:42:58 --> Utf8 Class Initialized
INFO - 2024-02-25 06:42:58 --> URI Class Initialized
INFO - 2024-02-25 06:42:58 --> Router Class Initialized
INFO - 2024-02-25 06:42:58 --> Output Class Initialized
INFO - 2024-02-25 06:42:58 --> Security Class Initialized
DEBUG - 2024-02-25 06:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 06:42:58 --> Input Class Initialized
INFO - 2024-02-25 06:42:58 --> Language Class Initialized
ERROR - 2024-02-25 06:42:58 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-02-25 11:48:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 11:48:23 --> Config Class Initialized
INFO - 2024-02-25 11:48:23 --> Hooks Class Initialized
DEBUG - 2024-02-25 11:48:23 --> UTF-8 Support Enabled
INFO - 2024-02-25 11:48:23 --> Utf8 Class Initialized
INFO - 2024-02-25 11:48:23 --> URI Class Initialized
DEBUG - 2024-02-25 11:48:23 --> No URI present. Default controller set.
INFO - 2024-02-25 11:48:23 --> Router Class Initialized
INFO - 2024-02-25 11:48:23 --> Output Class Initialized
INFO - 2024-02-25 11:48:23 --> Security Class Initialized
DEBUG - 2024-02-25 11:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 11:48:23 --> Input Class Initialized
INFO - 2024-02-25 11:48:23 --> Language Class Initialized
INFO - 2024-02-25 11:48:23 --> Loader Class Initialized
INFO - 2024-02-25 11:48:23 --> Helper loaded: url_helper
INFO - 2024-02-25 11:48:23 --> Helper loaded: file_helper
INFO - 2024-02-25 11:48:23 --> Helper loaded: html_helper
INFO - 2024-02-25 11:48:23 --> Helper loaded: text_helper
INFO - 2024-02-25 11:48:23 --> Helper loaded: form_helper
INFO - 2024-02-25 11:48:23 --> Helper loaded: lang_helper
INFO - 2024-02-25 11:48:23 --> Helper loaded: security_helper
INFO - 2024-02-25 11:48:23 --> Helper loaded: cookie_helper
INFO - 2024-02-25 11:48:23 --> Database Driver Class Initialized
INFO - 2024-02-25 11:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 11:48:23 --> Parser Class Initialized
INFO - 2024-02-25 11:48:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 11:48:23 --> Pagination Class Initialized
INFO - 2024-02-25 11:48:23 --> Form Validation Class Initialized
INFO - 2024-02-25 11:48:23 --> Controller Class Initialized
INFO - 2024-02-25 11:48:23 --> Model Class Initialized
DEBUG - 2024-02-25 11:48:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-25 11:48:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 11:48:23 --> Config Class Initialized
INFO - 2024-02-25 11:48:23 --> Hooks Class Initialized
DEBUG - 2024-02-25 11:48:23 --> UTF-8 Support Enabled
INFO - 2024-02-25 11:48:23 --> Utf8 Class Initialized
INFO - 2024-02-25 11:48:23 --> URI Class Initialized
INFO - 2024-02-25 11:48:23 --> Router Class Initialized
INFO - 2024-02-25 11:48:23 --> Output Class Initialized
INFO - 2024-02-25 11:48:23 --> Security Class Initialized
DEBUG - 2024-02-25 11:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 11:48:23 --> Input Class Initialized
INFO - 2024-02-25 11:48:23 --> Language Class Initialized
INFO - 2024-02-25 11:48:23 --> Loader Class Initialized
INFO - 2024-02-25 11:48:23 --> Helper loaded: url_helper
INFO - 2024-02-25 11:48:23 --> Helper loaded: file_helper
INFO - 2024-02-25 11:48:23 --> Helper loaded: html_helper
INFO - 2024-02-25 11:48:23 --> Helper loaded: text_helper
INFO - 2024-02-25 11:48:23 --> Helper loaded: form_helper
INFO - 2024-02-25 11:48:23 --> Helper loaded: lang_helper
INFO - 2024-02-25 11:48:23 --> Helper loaded: security_helper
INFO - 2024-02-25 11:48:23 --> Helper loaded: cookie_helper
INFO - 2024-02-25 11:48:23 --> Database Driver Class Initialized
INFO - 2024-02-25 11:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 11:48:23 --> Parser Class Initialized
INFO - 2024-02-25 11:48:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 11:48:23 --> Pagination Class Initialized
INFO - 2024-02-25 11:48:23 --> Form Validation Class Initialized
INFO - 2024-02-25 11:48:23 --> Controller Class Initialized
INFO - 2024-02-25 11:48:23 --> Model Class Initialized
DEBUG - 2024-02-25 11:48:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 11:48:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-25 11:48:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 11:48:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 11:48:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 11:48:23 --> Model Class Initialized
INFO - 2024-02-25 11:48:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 11:48:23 --> Final output sent to browser
DEBUG - 2024-02-25 11:48:23 --> Total execution time: 0.0332
ERROR - 2024-02-25 11:48:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 11:48:53 --> Config Class Initialized
INFO - 2024-02-25 11:48:53 --> Hooks Class Initialized
DEBUG - 2024-02-25 11:48:53 --> UTF-8 Support Enabled
INFO - 2024-02-25 11:48:53 --> Utf8 Class Initialized
INFO - 2024-02-25 11:48:53 --> URI Class Initialized
INFO - 2024-02-25 11:48:53 --> Router Class Initialized
INFO - 2024-02-25 11:48:53 --> Output Class Initialized
INFO - 2024-02-25 11:48:53 --> Security Class Initialized
DEBUG - 2024-02-25 11:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 11:48:53 --> Input Class Initialized
INFO - 2024-02-25 11:48:53 --> Language Class Initialized
INFO - 2024-02-25 11:48:53 --> Loader Class Initialized
INFO - 2024-02-25 11:48:53 --> Helper loaded: url_helper
INFO - 2024-02-25 11:48:53 --> Helper loaded: file_helper
INFO - 2024-02-25 11:48:53 --> Helper loaded: html_helper
INFO - 2024-02-25 11:48:53 --> Helper loaded: text_helper
INFO - 2024-02-25 11:48:53 --> Helper loaded: form_helper
INFO - 2024-02-25 11:48:53 --> Helper loaded: lang_helper
INFO - 2024-02-25 11:48:53 --> Helper loaded: security_helper
INFO - 2024-02-25 11:48:53 --> Helper loaded: cookie_helper
INFO - 2024-02-25 11:48:53 --> Database Driver Class Initialized
INFO - 2024-02-25 11:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 11:48:53 --> Parser Class Initialized
INFO - 2024-02-25 11:48:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 11:48:53 --> Pagination Class Initialized
INFO - 2024-02-25 11:48:53 --> Form Validation Class Initialized
INFO - 2024-02-25 11:48:53 --> Controller Class Initialized
INFO - 2024-02-25 11:48:53 --> Model Class Initialized
DEBUG - 2024-02-25 11:48:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 11:48:53 --> Model Class Initialized
INFO - 2024-02-25 11:48:53 --> Final output sent to browser
DEBUG - 2024-02-25 11:48:53 --> Total execution time: 0.0210
ERROR - 2024-02-25 11:48:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 11:48:53 --> Config Class Initialized
INFO - 2024-02-25 11:48:53 --> Hooks Class Initialized
DEBUG - 2024-02-25 11:48:53 --> UTF-8 Support Enabled
INFO - 2024-02-25 11:48:53 --> Utf8 Class Initialized
INFO - 2024-02-25 11:48:53 --> URI Class Initialized
DEBUG - 2024-02-25 11:48:53 --> No URI present. Default controller set.
INFO - 2024-02-25 11:48:53 --> Router Class Initialized
INFO - 2024-02-25 11:48:53 --> Output Class Initialized
INFO - 2024-02-25 11:48:53 --> Security Class Initialized
DEBUG - 2024-02-25 11:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 11:48:53 --> Input Class Initialized
INFO - 2024-02-25 11:48:53 --> Language Class Initialized
INFO - 2024-02-25 11:48:53 --> Loader Class Initialized
INFO - 2024-02-25 11:48:53 --> Helper loaded: url_helper
INFO - 2024-02-25 11:48:53 --> Helper loaded: file_helper
INFO - 2024-02-25 11:48:53 --> Helper loaded: html_helper
INFO - 2024-02-25 11:48:53 --> Helper loaded: text_helper
INFO - 2024-02-25 11:48:53 --> Helper loaded: form_helper
INFO - 2024-02-25 11:48:53 --> Helper loaded: lang_helper
INFO - 2024-02-25 11:48:53 --> Helper loaded: security_helper
INFO - 2024-02-25 11:48:53 --> Helper loaded: cookie_helper
INFO - 2024-02-25 11:48:53 --> Database Driver Class Initialized
INFO - 2024-02-25 11:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 11:48:53 --> Parser Class Initialized
INFO - 2024-02-25 11:48:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 11:48:53 --> Pagination Class Initialized
INFO - 2024-02-25 11:48:53 --> Form Validation Class Initialized
INFO - 2024-02-25 11:48:53 --> Controller Class Initialized
INFO - 2024-02-25 11:48:53 --> Model Class Initialized
DEBUG - 2024-02-25 11:48:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 11:48:53 --> Model Class Initialized
DEBUG - 2024-02-25 11:48:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 11:48:53 --> Model Class Initialized
INFO - 2024-02-25 11:48:53 --> Model Class Initialized
INFO - 2024-02-25 11:48:53 --> Model Class Initialized
INFO - 2024-02-25 11:48:53 --> Model Class Initialized
DEBUG - 2024-02-25 11:48:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 11:48:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 11:48:53 --> Model Class Initialized
INFO - 2024-02-25 11:48:53 --> Model Class Initialized
INFO - 2024-02-25 11:48:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-25 11:48:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 11:48:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 11:48:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 11:48:53 --> Model Class Initialized
INFO - 2024-02-25 11:48:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-25 11:48:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-25 11:48:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 11:48:53 --> Final output sent to browser
DEBUG - 2024-02-25 11:48:53 --> Total execution time: 0.2451
ERROR - 2024-02-25 11:49:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 11:49:33 --> Config Class Initialized
INFO - 2024-02-25 11:49:33 --> Hooks Class Initialized
DEBUG - 2024-02-25 11:49:33 --> UTF-8 Support Enabled
INFO - 2024-02-25 11:49:33 --> Utf8 Class Initialized
INFO - 2024-02-25 11:49:33 --> URI Class Initialized
INFO - 2024-02-25 11:49:33 --> Router Class Initialized
INFO - 2024-02-25 11:49:33 --> Output Class Initialized
INFO - 2024-02-25 11:49:33 --> Security Class Initialized
DEBUG - 2024-02-25 11:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 11:49:33 --> Input Class Initialized
INFO - 2024-02-25 11:49:33 --> Language Class Initialized
INFO - 2024-02-25 11:49:33 --> Loader Class Initialized
INFO - 2024-02-25 11:49:33 --> Helper loaded: url_helper
INFO - 2024-02-25 11:49:33 --> Helper loaded: file_helper
INFO - 2024-02-25 11:49:33 --> Helper loaded: html_helper
INFO - 2024-02-25 11:49:33 --> Helper loaded: text_helper
INFO - 2024-02-25 11:49:33 --> Helper loaded: form_helper
INFO - 2024-02-25 11:49:33 --> Helper loaded: lang_helper
INFO - 2024-02-25 11:49:33 --> Helper loaded: security_helper
INFO - 2024-02-25 11:49:33 --> Helper loaded: cookie_helper
INFO - 2024-02-25 11:49:33 --> Database Driver Class Initialized
INFO - 2024-02-25 11:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 11:49:33 --> Parser Class Initialized
INFO - 2024-02-25 11:49:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 11:49:33 --> Pagination Class Initialized
INFO - 2024-02-25 11:49:33 --> Form Validation Class Initialized
INFO - 2024-02-25 11:49:33 --> Controller Class Initialized
INFO - 2024-02-25 11:49:33 --> Model Class Initialized
DEBUG - 2024-02-25 11:49:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 11:49:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-25 11:49:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 11:49:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 11:49:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 11:49:33 --> Model Class Initialized
INFO - 2024-02-25 11:49:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 11:49:33 --> Final output sent to browser
DEBUG - 2024-02-25 11:49:33 --> Total execution time: 0.0315
ERROR - 2024-02-25 11:49:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 11:49:33 --> Config Class Initialized
INFO - 2024-02-25 11:49:33 --> Hooks Class Initialized
DEBUG - 2024-02-25 11:49:33 --> UTF-8 Support Enabled
INFO - 2024-02-25 11:49:33 --> Utf8 Class Initialized
INFO - 2024-02-25 11:49:33 --> URI Class Initialized
INFO - 2024-02-25 11:49:33 --> Router Class Initialized
INFO - 2024-02-25 11:49:33 --> Output Class Initialized
INFO - 2024-02-25 11:49:33 --> Security Class Initialized
DEBUG - 2024-02-25 11:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 11:49:33 --> Input Class Initialized
INFO - 2024-02-25 11:49:33 --> Language Class Initialized
INFO - 2024-02-25 11:49:33 --> Loader Class Initialized
INFO - 2024-02-25 11:49:33 --> Helper loaded: url_helper
INFO - 2024-02-25 11:49:33 --> Helper loaded: file_helper
INFO - 2024-02-25 11:49:33 --> Helper loaded: html_helper
INFO - 2024-02-25 11:49:33 --> Helper loaded: text_helper
INFO - 2024-02-25 11:49:33 --> Helper loaded: form_helper
INFO - 2024-02-25 11:49:33 --> Helper loaded: lang_helper
INFO - 2024-02-25 11:49:33 --> Helper loaded: security_helper
INFO - 2024-02-25 11:49:33 --> Helper loaded: cookie_helper
INFO - 2024-02-25 11:49:33 --> Database Driver Class Initialized
INFO - 2024-02-25 11:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 11:49:33 --> Parser Class Initialized
INFO - 2024-02-25 11:49:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 11:49:33 --> Pagination Class Initialized
INFO - 2024-02-25 11:49:33 --> Form Validation Class Initialized
INFO - 2024-02-25 11:49:33 --> Controller Class Initialized
INFO - 2024-02-25 11:49:33 --> Model Class Initialized
DEBUG - 2024-02-25 11:49:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 11:49:33 --> Model Class Initialized
DEBUG - 2024-02-25 11:49:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 11:49:33 --> Model Class Initialized
INFO - 2024-02-25 11:49:33 --> Model Class Initialized
INFO - 2024-02-25 11:49:33 --> Model Class Initialized
INFO - 2024-02-25 11:49:33 --> Model Class Initialized
DEBUG - 2024-02-25 11:49:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 11:49:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 11:49:33 --> Model Class Initialized
INFO - 2024-02-25 11:49:33 --> Model Class Initialized
INFO - 2024-02-25 11:49:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-25 11:49:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 11:49:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 11:49:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 11:49:33 --> Model Class Initialized
INFO - 2024-02-25 11:49:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-25 11:49:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-25 11:49:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 11:49:33 --> Final output sent to browser
DEBUG - 2024-02-25 11:49:33 --> Total execution time: 0.2335
ERROR - 2024-02-25 14:11:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:11:10 --> Config Class Initialized
INFO - 2024-02-25 14:11:10 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:11:10 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:11:10 --> Utf8 Class Initialized
INFO - 2024-02-25 14:11:10 --> URI Class Initialized
DEBUG - 2024-02-25 14:11:10 --> No URI present. Default controller set.
INFO - 2024-02-25 14:11:10 --> Router Class Initialized
INFO - 2024-02-25 14:11:10 --> Output Class Initialized
INFO - 2024-02-25 14:11:10 --> Security Class Initialized
DEBUG - 2024-02-25 14:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:11:10 --> Input Class Initialized
INFO - 2024-02-25 14:11:10 --> Language Class Initialized
INFO - 2024-02-25 14:11:10 --> Loader Class Initialized
INFO - 2024-02-25 14:11:10 --> Helper loaded: url_helper
INFO - 2024-02-25 14:11:10 --> Helper loaded: file_helper
INFO - 2024-02-25 14:11:10 --> Helper loaded: html_helper
INFO - 2024-02-25 14:11:10 --> Helper loaded: text_helper
INFO - 2024-02-25 14:11:10 --> Helper loaded: form_helper
INFO - 2024-02-25 14:11:10 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:11:10 --> Helper loaded: security_helper
INFO - 2024-02-25 14:11:10 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:11:10 --> Database Driver Class Initialized
INFO - 2024-02-25 14:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:11:10 --> Parser Class Initialized
INFO - 2024-02-25 14:11:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:11:10 --> Pagination Class Initialized
INFO - 2024-02-25 14:11:10 --> Form Validation Class Initialized
INFO - 2024-02-25 14:11:10 --> Controller Class Initialized
INFO - 2024-02-25 14:11:10 --> Model Class Initialized
DEBUG - 2024-02-25 14:11:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-25 14:11:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:11:10 --> Config Class Initialized
INFO - 2024-02-25 14:11:10 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:11:10 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:11:10 --> Utf8 Class Initialized
INFO - 2024-02-25 14:11:10 --> URI Class Initialized
INFO - 2024-02-25 14:11:10 --> Router Class Initialized
INFO - 2024-02-25 14:11:10 --> Output Class Initialized
INFO - 2024-02-25 14:11:10 --> Security Class Initialized
DEBUG - 2024-02-25 14:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:11:10 --> Input Class Initialized
INFO - 2024-02-25 14:11:10 --> Language Class Initialized
INFO - 2024-02-25 14:11:10 --> Loader Class Initialized
INFO - 2024-02-25 14:11:10 --> Helper loaded: url_helper
INFO - 2024-02-25 14:11:10 --> Helper loaded: file_helper
INFO - 2024-02-25 14:11:10 --> Helper loaded: html_helper
INFO - 2024-02-25 14:11:10 --> Helper loaded: text_helper
INFO - 2024-02-25 14:11:10 --> Helper loaded: form_helper
INFO - 2024-02-25 14:11:10 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:11:10 --> Helper loaded: security_helper
INFO - 2024-02-25 14:11:10 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:11:10 --> Database Driver Class Initialized
INFO - 2024-02-25 14:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:11:10 --> Parser Class Initialized
INFO - 2024-02-25 14:11:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:11:10 --> Pagination Class Initialized
INFO - 2024-02-25 14:11:10 --> Form Validation Class Initialized
INFO - 2024-02-25 14:11:10 --> Controller Class Initialized
INFO - 2024-02-25 14:11:10 --> Model Class Initialized
DEBUG - 2024-02-25 14:11:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:11:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-25 14:11:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:11:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 14:11:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 14:11:10 --> Model Class Initialized
INFO - 2024-02-25 14:11:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 14:11:10 --> Final output sent to browser
DEBUG - 2024-02-25 14:11:10 --> Total execution time: 0.0335
ERROR - 2024-02-25 14:13:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:13:37 --> Config Class Initialized
INFO - 2024-02-25 14:13:37 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:13:37 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:13:37 --> Utf8 Class Initialized
INFO - 2024-02-25 14:13:37 --> URI Class Initialized
INFO - 2024-02-25 14:13:37 --> Router Class Initialized
INFO - 2024-02-25 14:13:37 --> Output Class Initialized
INFO - 2024-02-25 14:13:37 --> Security Class Initialized
DEBUG - 2024-02-25 14:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:13:37 --> Input Class Initialized
INFO - 2024-02-25 14:13:37 --> Language Class Initialized
INFO - 2024-02-25 14:13:37 --> Loader Class Initialized
INFO - 2024-02-25 14:13:37 --> Helper loaded: url_helper
INFO - 2024-02-25 14:13:37 --> Helper loaded: file_helper
INFO - 2024-02-25 14:13:37 --> Helper loaded: html_helper
INFO - 2024-02-25 14:13:37 --> Helper loaded: text_helper
INFO - 2024-02-25 14:13:37 --> Helper loaded: form_helper
INFO - 2024-02-25 14:13:37 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:13:37 --> Helper loaded: security_helper
INFO - 2024-02-25 14:13:37 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:13:37 --> Database Driver Class Initialized
INFO - 2024-02-25 14:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:13:37 --> Parser Class Initialized
INFO - 2024-02-25 14:13:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:13:37 --> Pagination Class Initialized
INFO - 2024-02-25 14:13:37 --> Form Validation Class Initialized
INFO - 2024-02-25 14:13:37 --> Controller Class Initialized
INFO - 2024-02-25 14:13:37 --> Model Class Initialized
DEBUG - 2024-02-25 14:13:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:13:37 --> Model Class Initialized
INFO - 2024-02-25 14:13:37 --> Final output sent to browser
DEBUG - 2024-02-25 14:13:37 --> Total execution time: 0.0221
ERROR - 2024-02-25 14:13:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:13:37 --> Config Class Initialized
INFO - 2024-02-25 14:13:37 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:13:37 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:13:37 --> Utf8 Class Initialized
INFO - 2024-02-25 14:13:37 --> URI Class Initialized
DEBUG - 2024-02-25 14:13:37 --> No URI present. Default controller set.
INFO - 2024-02-25 14:13:37 --> Router Class Initialized
INFO - 2024-02-25 14:13:37 --> Output Class Initialized
INFO - 2024-02-25 14:13:37 --> Security Class Initialized
DEBUG - 2024-02-25 14:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:13:37 --> Input Class Initialized
INFO - 2024-02-25 14:13:37 --> Language Class Initialized
INFO - 2024-02-25 14:13:37 --> Loader Class Initialized
INFO - 2024-02-25 14:13:37 --> Helper loaded: url_helper
INFO - 2024-02-25 14:13:37 --> Helper loaded: file_helper
INFO - 2024-02-25 14:13:37 --> Helper loaded: html_helper
INFO - 2024-02-25 14:13:37 --> Helper loaded: text_helper
INFO - 2024-02-25 14:13:37 --> Helper loaded: form_helper
INFO - 2024-02-25 14:13:37 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:13:37 --> Helper loaded: security_helper
INFO - 2024-02-25 14:13:37 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:13:37 --> Database Driver Class Initialized
INFO - 2024-02-25 14:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:13:37 --> Parser Class Initialized
INFO - 2024-02-25 14:13:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:13:37 --> Pagination Class Initialized
INFO - 2024-02-25 14:13:37 --> Form Validation Class Initialized
INFO - 2024-02-25 14:13:37 --> Controller Class Initialized
INFO - 2024-02-25 14:13:37 --> Model Class Initialized
DEBUG - 2024-02-25 14:13:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:13:37 --> Model Class Initialized
DEBUG - 2024-02-25 14:13:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:13:37 --> Model Class Initialized
INFO - 2024-02-25 14:13:37 --> Model Class Initialized
INFO - 2024-02-25 14:13:37 --> Model Class Initialized
INFO - 2024-02-25 14:13:37 --> Model Class Initialized
DEBUG - 2024-02-25 14:13:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:13:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:13:37 --> Model Class Initialized
INFO - 2024-02-25 14:13:37 --> Model Class Initialized
INFO - 2024-02-25 14:13:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-25 14:13:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:13:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 14:13:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 14:13:37 --> Model Class Initialized
INFO - 2024-02-25 14:13:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-25 14:13:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-25 14:13:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 14:13:37 --> Final output sent to browser
DEBUG - 2024-02-25 14:13:37 --> Total execution time: 0.2739
ERROR - 2024-02-25 14:13:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:13:49 --> Config Class Initialized
INFO - 2024-02-25 14:13:49 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:13:49 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:13:49 --> Utf8 Class Initialized
INFO - 2024-02-25 14:13:49 --> URI Class Initialized
INFO - 2024-02-25 14:13:49 --> Router Class Initialized
INFO - 2024-02-25 14:13:49 --> Output Class Initialized
INFO - 2024-02-25 14:13:49 --> Security Class Initialized
DEBUG - 2024-02-25 14:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:13:49 --> Input Class Initialized
INFO - 2024-02-25 14:13:49 --> Language Class Initialized
INFO - 2024-02-25 14:13:49 --> Loader Class Initialized
INFO - 2024-02-25 14:13:49 --> Helper loaded: url_helper
INFO - 2024-02-25 14:13:49 --> Helper loaded: file_helper
INFO - 2024-02-25 14:13:49 --> Helper loaded: html_helper
INFO - 2024-02-25 14:13:49 --> Helper loaded: text_helper
INFO - 2024-02-25 14:13:49 --> Helper loaded: form_helper
INFO - 2024-02-25 14:13:49 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:13:49 --> Helper loaded: security_helper
INFO - 2024-02-25 14:13:49 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:13:49 --> Database Driver Class Initialized
INFO - 2024-02-25 14:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:13:49 --> Parser Class Initialized
INFO - 2024-02-25 14:13:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:13:49 --> Pagination Class Initialized
INFO - 2024-02-25 14:13:49 --> Form Validation Class Initialized
INFO - 2024-02-25 14:13:49 --> Controller Class Initialized
INFO - 2024-02-25 14:13:49 --> Model Class Initialized
DEBUG - 2024-02-25 14:13:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:13:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:13:49 --> Model Class Initialized
DEBUG - 2024-02-25 14:13:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:13:49 --> Model Class Initialized
INFO - 2024-02-25 14:13:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-25 14:13:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:13:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 14:13:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 14:13:49 --> Model Class Initialized
INFO - 2024-02-25 14:13:49 --> Model Class Initialized
INFO - 2024-02-25 14:13:49 --> Model Class Initialized
INFO - 2024-02-25 14:13:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-25 14:13:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-25 14:13:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 14:13:49 --> Final output sent to browser
DEBUG - 2024-02-25 14:13:49 --> Total execution time: 0.1659
ERROR - 2024-02-25 14:13:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:13:57 --> Config Class Initialized
INFO - 2024-02-25 14:13:57 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:13:57 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:13:57 --> Utf8 Class Initialized
INFO - 2024-02-25 14:13:57 --> URI Class Initialized
INFO - 2024-02-25 14:13:57 --> Router Class Initialized
INFO - 2024-02-25 14:13:57 --> Output Class Initialized
INFO - 2024-02-25 14:13:57 --> Security Class Initialized
DEBUG - 2024-02-25 14:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:13:57 --> Input Class Initialized
INFO - 2024-02-25 14:13:57 --> Language Class Initialized
INFO - 2024-02-25 14:13:57 --> Loader Class Initialized
INFO - 2024-02-25 14:13:57 --> Helper loaded: url_helper
INFO - 2024-02-25 14:13:57 --> Helper loaded: file_helper
INFO - 2024-02-25 14:13:57 --> Helper loaded: html_helper
INFO - 2024-02-25 14:13:57 --> Helper loaded: text_helper
INFO - 2024-02-25 14:13:57 --> Helper loaded: form_helper
INFO - 2024-02-25 14:13:57 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:13:57 --> Helper loaded: security_helper
INFO - 2024-02-25 14:13:57 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:13:57 --> Database Driver Class Initialized
INFO - 2024-02-25 14:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:13:57 --> Parser Class Initialized
INFO - 2024-02-25 14:13:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:13:57 --> Pagination Class Initialized
INFO - 2024-02-25 14:13:57 --> Form Validation Class Initialized
INFO - 2024-02-25 14:13:57 --> Controller Class Initialized
INFO - 2024-02-25 14:13:57 --> Model Class Initialized
DEBUG - 2024-02-25 14:13:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:13:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:13:57 --> Model Class Initialized
DEBUG - 2024-02-25 14:13:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:13:57 --> Model Class Initialized
INFO - 2024-02-25 14:13:57 --> Final output sent to browser
DEBUG - 2024-02-25 14:13:57 --> Total execution time: 0.0457
ERROR - 2024-02-25 14:14:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:14:02 --> Config Class Initialized
INFO - 2024-02-25 14:14:02 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:14:02 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:14:02 --> Utf8 Class Initialized
INFO - 2024-02-25 14:14:02 --> URI Class Initialized
INFO - 2024-02-25 14:14:02 --> Router Class Initialized
INFO - 2024-02-25 14:14:02 --> Output Class Initialized
INFO - 2024-02-25 14:14:02 --> Security Class Initialized
DEBUG - 2024-02-25 14:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:14:02 --> Input Class Initialized
INFO - 2024-02-25 14:14:02 --> Language Class Initialized
INFO - 2024-02-25 14:14:02 --> Loader Class Initialized
INFO - 2024-02-25 14:14:02 --> Helper loaded: url_helper
INFO - 2024-02-25 14:14:02 --> Helper loaded: file_helper
INFO - 2024-02-25 14:14:02 --> Helper loaded: html_helper
INFO - 2024-02-25 14:14:02 --> Helper loaded: text_helper
INFO - 2024-02-25 14:14:02 --> Helper loaded: form_helper
INFO - 2024-02-25 14:14:02 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:14:02 --> Helper loaded: security_helper
INFO - 2024-02-25 14:14:02 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:14:02 --> Database Driver Class Initialized
INFO - 2024-02-25 14:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:14:02 --> Parser Class Initialized
INFO - 2024-02-25 14:14:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:14:02 --> Pagination Class Initialized
INFO - 2024-02-25 14:14:02 --> Form Validation Class Initialized
INFO - 2024-02-25 14:14:02 --> Controller Class Initialized
INFO - 2024-02-25 14:14:02 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:14:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:02 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:02 --> Model Class Initialized
INFO - 2024-02-25 14:14:02 --> Final output sent to browser
DEBUG - 2024-02-25 14:14:02 --> Total execution time: 0.0514
ERROR - 2024-02-25 14:14:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:14:02 --> Config Class Initialized
INFO - 2024-02-25 14:14:02 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:14:02 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:14:02 --> Utf8 Class Initialized
INFO - 2024-02-25 14:14:02 --> URI Class Initialized
INFO - 2024-02-25 14:14:02 --> Router Class Initialized
INFO - 2024-02-25 14:14:02 --> Output Class Initialized
INFO - 2024-02-25 14:14:02 --> Security Class Initialized
DEBUG - 2024-02-25 14:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:14:02 --> Input Class Initialized
INFO - 2024-02-25 14:14:02 --> Language Class Initialized
INFO - 2024-02-25 14:14:02 --> Loader Class Initialized
INFO - 2024-02-25 14:14:02 --> Helper loaded: url_helper
INFO - 2024-02-25 14:14:02 --> Helper loaded: file_helper
INFO - 2024-02-25 14:14:02 --> Helper loaded: html_helper
INFO - 2024-02-25 14:14:02 --> Helper loaded: text_helper
INFO - 2024-02-25 14:14:02 --> Helper loaded: form_helper
INFO - 2024-02-25 14:14:02 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:14:02 --> Helper loaded: security_helper
INFO - 2024-02-25 14:14:02 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:14:02 --> Database Driver Class Initialized
INFO - 2024-02-25 14:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:14:02 --> Parser Class Initialized
INFO - 2024-02-25 14:14:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:14:02 --> Pagination Class Initialized
INFO - 2024-02-25 14:14:02 --> Form Validation Class Initialized
INFO - 2024-02-25 14:14:02 --> Controller Class Initialized
INFO - 2024-02-25 14:14:02 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:14:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:02 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:02 --> Model Class Initialized
INFO - 2024-02-25 14:14:02 --> Final output sent to browser
DEBUG - 2024-02-25 14:14:02 --> Total execution time: 0.0559
ERROR - 2024-02-25 14:14:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:14:07 --> Config Class Initialized
INFO - 2024-02-25 14:14:07 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:14:07 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:14:07 --> Utf8 Class Initialized
INFO - 2024-02-25 14:14:07 --> URI Class Initialized
INFO - 2024-02-25 14:14:07 --> Router Class Initialized
INFO - 2024-02-25 14:14:07 --> Output Class Initialized
INFO - 2024-02-25 14:14:07 --> Security Class Initialized
DEBUG - 2024-02-25 14:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:14:07 --> Input Class Initialized
INFO - 2024-02-25 14:14:07 --> Language Class Initialized
INFO - 2024-02-25 14:14:07 --> Loader Class Initialized
INFO - 2024-02-25 14:14:07 --> Helper loaded: url_helper
INFO - 2024-02-25 14:14:07 --> Helper loaded: file_helper
INFO - 2024-02-25 14:14:07 --> Helper loaded: html_helper
INFO - 2024-02-25 14:14:07 --> Helper loaded: text_helper
INFO - 2024-02-25 14:14:07 --> Helper loaded: form_helper
INFO - 2024-02-25 14:14:07 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:14:07 --> Helper loaded: security_helper
INFO - 2024-02-25 14:14:07 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:14:07 --> Database Driver Class Initialized
INFO - 2024-02-25 14:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:14:07 --> Parser Class Initialized
INFO - 2024-02-25 14:14:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:14:07 --> Pagination Class Initialized
INFO - 2024-02-25 14:14:07 --> Form Validation Class Initialized
INFO - 2024-02-25 14:14:07 --> Controller Class Initialized
INFO - 2024-02-25 14:14:07 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:14:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:07 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:07 --> Model Class Initialized
INFO - 2024-02-25 14:14:07 --> Final output sent to browser
DEBUG - 2024-02-25 14:14:07 --> Total execution time: 0.0224
ERROR - 2024-02-25 14:14:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:14:07 --> Config Class Initialized
INFO - 2024-02-25 14:14:07 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:14:07 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:14:07 --> Utf8 Class Initialized
INFO - 2024-02-25 14:14:07 --> URI Class Initialized
INFO - 2024-02-25 14:14:07 --> Router Class Initialized
INFO - 2024-02-25 14:14:07 --> Output Class Initialized
INFO - 2024-02-25 14:14:07 --> Security Class Initialized
DEBUG - 2024-02-25 14:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:14:07 --> Input Class Initialized
INFO - 2024-02-25 14:14:07 --> Language Class Initialized
INFO - 2024-02-25 14:14:07 --> Loader Class Initialized
INFO - 2024-02-25 14:14:07 --> Helper loaded: url_helper
INFO - 2024-02-25 14:14:07 --> Helper loaded: file_helper
INFO - 2024-02-25 14:14:07 --> Helper loaded: html_helper
INFO - 2024-02-25 14:14:07 --> Helper loaded: text_helper
INFO - 2024-02-25 14:14:07 --> Helper loaded: form_helper
INFO - 2024-02-25 14:14:07 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:14:07 --> Helper loaded: security_helper
INFO - 2024-02-25 14:14:07 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:14:07 --> Database Driver Class Initialized
INFO - 2024-02-25 14:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:14:07 --> Parser Class Initialized
INFO - 2024-02-25 14:14:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:14:07 --> Pagination Class Initialized
INFO - 2024-02-25 14:14:07 --> Form Validation Class Initialized
INFO - 2024-02-25 14:14:07 --> Controller Class Initialized
INFO - 2024-02-25 14:14:07 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:14:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:07 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:07 --> Model Class Initialized
INFO - 2024-02-25 14:14:07 --> Final output sent to browser
DEBUG - 2024-02-25 14:14:07 --> Total execution time: 0.0214
ERROR - 2024-02-25 14:14:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:14:08 --> Config Class Initialized
INFO - 2024-02-25 14:14:08 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:14:08 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:14:08 --> Utf8 Class Initialized
INFO - 2024-02-25 14:14:08 --> URI Class Initialized
INFO - 2024-02-25 14:14:08 --> Router Class Initialized
INFO - 2024-02-25 14:14:08 --> Output Class Initialized
INFO - 2024-02-25 14:14:08 --> Security Class Initialized
DEBUG - 2024-02-25 14:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:14:08 --> Input Class Initialized
INFO - 2024-02-25 14:14:08 --> Language Class Initialized
INFO - 2024-02-25 14:14:08 --> Loader Class Initialized
INFO - 2024-02-25 14:14:08 --> Helper loaded: url_helper
INFO - 2024-02-25 14:14:08 --> Helper loaded: file_helper
INFO - 2024-02-25 14:14:08 --> Helper loaded: html_helper
INFO - 2024-02-25 14:14:08 --> Helper loaded: text_helper
INFO - 2024-02-25 14:14:08 --> Helper loaded: form_helper
INFO - 2024-02-25 14:14:08 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:14:08 --> Helper loaded: security_helper
INFO - 2024-02-25 14:14:08 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:14:08 --> Database Driver Class Initialized
INFO - 2024-02-25 14:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:14:08 --> Parser Class Initialized
INFO - 2024-02-25 14:14:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:14:08 --> Pagination Class Initialized
INFO - 2024-02-25 14:14:08 --> Form Validation Class Initialized
INFO - 2024-02-25 14:14:08 --> Controller Class Initialized
INFO - 2024-02-25 14:14:08 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:14:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:08 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:08 --> Model Class Initialized
INFO - 2024-02-25 14:14:08 --> Final output sent to browser
DEBUG - 2024-02-25 14:14:08 --> Total execution time: 0.0264
ERROR - 2024-02-25 14:14:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:14:09 --> Config Class Initialized
INFO - 2024-02-25 14:14:09 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:14:09 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:14:09 --> Utf8 Class Initialized
INFO - 2024-02-25 14:14:09 --> URI Class Initialized
INFO - 2024-02-25 14:14:09 --> Router Class Initialized
INFO - 2024-02-25 14:14:09 --> Output Class Initialized
INFO - 2024-02-25 14:14:09 --> Security Class Initialized
DEBUG - 2024-02-25 14:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:14:09 --> Input Class Initialized
INFO - 2024-02-25 14:14:09 --> Language Class Initialized
INFO - 2024-02-25 14:14:09 --> Loader Class Initialized
INFO - 2024-02-25 14:14:09 --> Helper loaded: url_helper
INFO - 2024-02-25 14:14:09 --> Helper loaded: file_helper
INFO - 2024-02-25 14:14:09 --> Helper loaded: html_helper
INFO - 2024-02-25 14:14:09 --> Helper loaded: text_helper
INFO - 2024-02-25 14:14:09 --> Helper loaded: form_helper
INFO - 2024-02-25 14:14:09 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:14:09 --> Helper loaded: security_helper
INFO - 2024-02-25 14:14:09 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:14:09 --> Database Driver Class Initialized
INFO - 2024-02-25 14:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:14:09 --> Parser Class Initialized
INFO - 2024-02-25 14:14:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:14:09 --> Pagination Class Initialized
INFO - 2024-02-25 14:14:09 --> Form Validation Class Initialized
INFO - 2024-02-25 14:14:09 --> Controller Class Initialized
INFO - 2024-02-25 14:14:09 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:14:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:09 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:09 --> Model Class Initialized
INFO - 2024-02-25 14:14:09 --> Final output sent to browser
DEBUG - 2024-02-25 14:14:09 --> Total execution time: 0.0453
ERROR - 2024-02-25 14:14:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:14:11 --> Config Class Initialized
INFO - 2024-02-25 14:14:11 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:14:11 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:14:11 --> Utf8 Class Initialized
INFO - 2024-02-25 14:14:11 --> URI Class Initialized
INFO - 2024-02-25 14:14:11 --> Router Class Initialized
INFO - 2024-02-25 14:14:11 --> Output Class Initialized
INFO - 2024-02-25 14:14:11 --> Security Class Initialized
DEBUG - 2024-02-25 14:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:14:11 --> Input Class Initialized
INFO - 2024-02-25 14:14:11 --> Language Class Initialized
INFO - 2024-02-25 14:14:11 --> Loader Class Initialized
INFO - 2024-02-25 14:14:11 --> Helper loaded: url_helper
INFO - 2024-02-25 14:14:11 --> Helper loaded: file_helper
INFO - 2024-02-25 14:14:11 --> Helper loaded: html_helper
INFO - 2024-02-25 14:14:11 --> Helper loaded: text_helper
INFO - 2024-02-25 14:14:11 --> Helper loaded: form_helper
INFO - 2024-02-25 14:14:11 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:14:11 --> Helper loaded: security_helper
INFO - 2024-02-25 14:14:11 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:14:11 --> Database Driver Class Initialized
INFO - 2024-02-25 14:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:14:11 --> Parser Class Initialized
INFO - 2024-02-25 14:14:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:14:11 --> Pagination Class Initialized
INFO - 2024-02-25 14:14:11 --> Form Validation Class Initialized
INFO - 2024-02-25 14:14:11 --> Controller Class Initialized
INFO - 2024-02-25 14:14:11 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:14:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:11 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:11 --> Model Class Initialized
INFO - 2024-02-25 14:14:11 --> Final output sent to browser
DEBUG - 2024-02-25 14:14:11 --> Total execution time: 0.0468
ERROR - 2024-02-25 14:14:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:14:23 --> Config Class Initialized
INFO - 2024-02-25 14:14:23 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:14:23 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:14:23 --> Utf8 Class Initialized
INFO - 2024-02-25 14:14:23 --> URI Class Initialized
INFO - 2024-02-25 14:14:23 --> Router Class Initialized
INFO - 2024-02-25 14:14:23 --> Output Class Initialized
INFO - 2024-02-25 14:14:23 --> Security Class Initialized
DEBUG - 2024-02-25 14:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:14:23 --> Input Class Initialized
INFO - 2024-02-25 14:14:23 --> Language Class Initialized
INFO - 2024-02-25 14:14:23 --> Loader Class Initialized
INFO - 2024-02-25 14:14:23 --> Helper loaded: url_helper
INFO - 2024-02-25 14:14:23 --> Helper loaded: file_helper
INFO - 2024-02-25 14:14:23 --> Helper loaded: html_helper
INFO - 2024-02-25 14:14:23 --> Helper loaded: text_helper
INFO - 2024-02-25 14:14:23 --> Helper loaded: form_helper
INFO - 2024-02-25 14:14:23 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:14:23 --> Helper loaded: security_helper
INFO - 2024-02-25 14:14:23 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:14:23 --> Database Driver Class Initialized
INFO - 2024-02-25 14:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:14:23 --> Parser Class Initialized
INFO - 2024-02-25 14:14:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:14:23 --> Pagination Class Initialized
INFO - 2024-02-25 14:14:23 --> Form Validation Class Initialized
INFO - 2024-02-25 14:14:23 --> Controller Class Initialized
INFO - 2024-02-25 14:14:23 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:14:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:23 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:23 --> Model Class Initialized
INFO - 2024-02-25 14:14:23 --> Final output sent to browser
DEBUG - 2024-02-25 14:14:23 --> Total execution time: 0.0421
ERROR - 2024-02-25 14:14:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:14:23 --> Config Class Initialized
INFO - 2024-02-25 14:14:23 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:14:23 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:14:23 --> Utf8 Class Initialized
INFO - 2024-02-25 14:14:23 --> URI Class Initialized
INFO - 2024-02-25 14:14:23 --> Router Class Initialized
INFO - 2024-02-25 14:14:23 --> Output Class Initialized
INFO - 2024-02-25 14:14:23 --> Security Class Initialized
DEBUG - 2024-02-25 14:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:14:23 --> Input Class Initialized
INFO - 2024-02-25 14:14:23 --> Language Class Initialized
INFO - 2024-02-25 14:14:23 --> Loader Class Initialized
INFO - 2024-02-25 14:14:23 --> Helper loaded: url_helper
INFO - 2024-02-25 14:14:23 --> Helper loaded: file_helper
INFO - 2024-02-25 14:14:23 --> Helper loaded: html_helper
INFO - 2024-02-25 14:14:23 --> Helper loaded: text_helper
INFO - 2024-02-25 14:14:23 --> Helper loaded: form_helper
INFO - 2024-02-25 14:14:23 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:14:23 --> Helper loaded: security_helper
INFO - 2024-02-25 14:14:23 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:14:23 --> Database Driver Class Initialized
INFO - 2024-02-25 14:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:14:23 --> Parser Class Initialized
INFO - 2024-02-25 14:14:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:14:23 --> Pagination Class Initialized
INFO - 2024-02-25 14:14:23 --> Form Validation Class Initialized
INFO - 2024-02-25 14:14:23 --> Controller Class Initialized
INFO - 2024-02-25 14:14:23 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:14:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:23 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:23 --> Model Class Initialized
INFO - 2024-02-25 14:14:23 --> Final output sent to browser
DEBUG - 2024-02-25 14:14:23 --> Total execution time: 0.0496
ERROR - 2024-02-25 14:14:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:14:24 --> Config Class Initialized
INFO - 2024-02-25 14:14:24 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:14:24 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:14:24 --> Utf8 Class Initialized
INFO - 2024-02-25 14:14:24 --> URI Class Initialized
INFO - 2024-02-25 14:14:24 --> Router Class Initialized
INFO - 2024-02-25 14:14:24 --> Output Class Initialized
INFO - 2024-02-25 14:14:24 --> Security Class Initialized
DEBUG - 2024-02-25 14:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:14:24 --> Input Class Initialized
INFO - 2024-02-25 14:14:24 --> Language Class Initialized
INFO - 2024-02-25 14:14:24 --> Loader Class Initialized
INFO - 2024-02-25 14:14:24 --> Helper loaded: url_helper
INFO - 2024-02-25 14:14:24 --> Helper loaded: file_helper
INFO - 2024-02-25 14:14:24 --> Helper loaded: html_helper
INFO - 2024-02-25 14:14:24 --> Helper loaded: text_helper
INFO - 2024-02-25 14:14:24 --> Helper loaded: form_helper
INFO - 2024-02-25 14:14:24 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:14:24 --> Helper loaded: security_helper
INFO - 2024-02-25 14:14:24 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:14:24 --> Database Driver Class Initialized
INFO - 2024-02-25 14:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:14:24 --> Parser Class Initialized
INFO - 2024-02-25 14:14:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:14:24 --> Pagination Class Initialized
INFO - 2024-02-25 14:14:24 --> Form Validation Class Initialized
INFO - 2024-02-25 14:14:24 --> Controller Class Initialized
INFO - 2024-02-25 14:14:24 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:14:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:24 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:24 --> Model Class Initialized
INFO - 2024-02-25 14:14:24 --> Final output sent to browser
DEBUG - 2024-02-25 14:14:24 --> Total execution time: 0.0480
ERROR - 2024-02-25 14:14:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:14:25 --> Config Class Initialized
INFO - 2024-02-25 14:14:25 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:14:25 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:14:25 --> Utf8 Class Initialized
INFO - 2024-02-25 14:14:25 --> URI Class Initialized
INFO - 2024-02-25 14:14:25 --> Router Class Initialized
INFO - 2024-02-25 14:14:25 --> Output Class Initialized
INFO - 2024-02-25 14:14:25 --> Security Class Initialized
DEBUG - 2024-02-25 14:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:14:25 --> Input Class Initialized
INFO - 2024-02-25 14:14:25 --> Language Class Initialized
INFO - 2024-02-25 14:14:25 --> Loader Class Initialized
INFO - 2024-02-25 14:14:25 --> Helper loaded: url_helper
INFO - 2024-02-25 14:14:25 --> Helper loaded: file_helper
INFO - 2024-02-25 14:14:25 --> Helper loaded: html_helper
INFO - 2024-02-25 14:14:25 --> Helper loaded: text_helper
INFO - 2024-02-25 14:14:25 --> Helper loaded: form_helper
INFO - 2024-02-25 14:14:25 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:14:25 --> Helper loaded: security_helper
INFO - 2024-02-25 14:14:25 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:14:25 --> Database Driver Class Initialized
INFO - 2024-02-25 14:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:14:25 --> Parser Class Initialized
INFO - 2024-02-25 14:14:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:14:25 --> Pagination Class Initialized
INFO - 2024-02-25 14:14:25 --> Form Validation Class Initialized
INFO - 2024-02-25 14:14:25 --> Controller Class Initialized
INFO - 2024-02-25 14:14:25 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:14:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:25 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:25 --> Model Class Initialized
INFO - 2024-02-25 14:14:25 --> Final output sent to browser
DEBUG - 2024-02-25 14:14:25 --> Total execution time: 0.0502
ERROR - 2024-02-25 14:14:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:14:26 --> Config Class Initialized
INFO - 2024-02-25 14:14:26 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:14:26 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:14:26 --> Utf8 Class Initialized
INFO - 2024-02-25 14:14:26 --> URI Class Initialized
INFO - 2024-02-25 14:14:26 --> Router Class Initialized
INFO - 2024-02-25 14:14:26 --> Output Class Initialized
INFO - 2024-02-25 14:14:26 --> Security Class Initialized
DEBUG - 2024-02-25 14:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:14:26 --> Input Class Initialized
INFO - 2024-02-25 14:14:26 --> Language Class Initialized
INFO - 2024-02-25 14:14:26 --> Loader Class Initialized
INFO - 2024-02-25 14:14:26 --> Helper loaded: url_helper
INFO - 2024-02-25 14:14:26 --> Helper loaded: file_helper
INFO - 2024-02-25 14:14:26 --> Helper loaded: html_helper
INFO - 2024-02-25 14:14:26 --> Helper loaded: text_helper
INFO - 2024-02-25 14:14:26 --> Helper loaded: form_helper
INFO - 2024-02-25 14:14:26 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:14:26 --> Helper loaded: security_helper
INFO - 2024-02-25 14:14:26 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:14:26 --> Database Driver Class Initialized
INFO - 2024-02-25 14:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:14:26 --> Parser Class Initialized
INFO - 2024-02-25 14:14:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:14:26 --> Pagination Class Initialized
INFO - 2024-02-25 14:14:26 --> Form Validation Class Initialized
INFO - 2024-02-25 14:14:26 --> Controller Class Initialized
INFO - 2024-02-25 14:14:26 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:14:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:26 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:26 --> Model Class Initialized
INFO - 2024-02-25 14:14:26 --> Final output sent to browser
DEBUG - 2024-02-25 14:14:26 --> Total execution time: 0.0455
ERROR - 2024-02-25 14:14:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:14:26 --> Config Class Initialized
INFO - 2024-02-25 14:14:26 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:14:26 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:14:26 --> Utf8 Class Initialized
INFO - 2024-02-25 14:14:26 --> URI Class Initialized
INFO - 2024-02-25 14:14:26 --> Router Class Initialized
INFO - 2024-02-25 14:14:26 --> Output Class Initialized
INFO - 2024-02-25 14:14:26 --> Security Class Initialized
DEBUG - 2024-02-25 14:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:14:26 --> Input Class Initialized
INFO - 2024-02-25 14:14:26 --> Language Class Initialized
INFO - 2024-02-25 14:14:26 --> Loader Class Initialized
INFO - 2024-02-25 14:14:26 --> Helper loaded: url_helper
INFO - 2024-02-25 14:14:26 --> Helper loaded: file_helper
INFO - 2024-02-25 14:14:26 --> Helper loaded: html_helper
INFO - 2024-02-25 14:14:26 --> Helper loaded: text_helper
INFO - 2024-02-25 14:14:26 --> Helper loaded: form_helper
INFO - 2024-02-25 14:14:26 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:14:26 --> Helper loaded: security_helper
INFO - 2024-02-25 14:14:26 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:14:26 --> Database Driver Class Initialized
INFO - 2024-02-25 14:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:14:26 --> Parser Class Initialized
INFO - 2024-02-25 14:14:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:14:26 --> Pagination Class Initialized
INFO - 2024-02-25 14:14:26 --> Form Validation Class Initialized
INFO - 2024-02-25 14:14:26 --> Controller Class Initialized
INFO - 2024-02-25 14:14:26 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:14:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:26 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:26 --> Model Class Initialized
INFO - 2024-02-25 14:14:26 --> Final output sent to browser
DEBUG - 2024-02-25 14:14:26 --> Total execution time: 0.0490
ERROR - 2024-02-25 14:14:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:14:26 --> Config Class Initialized
INFO - 2024-02-25 14:14:26 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:14:26 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:14:26 --> Utf8 Class Initialized
INFO - 2024-02-25 14:14:26 --> URI Class Initialized
INFO - 2024-02-25 14:14:26 --> Router Class Initialized
INFO - 2024-02-25 14:14:26 --> Output Class Initialized
INFO - 2024-02-25 14:14:26 --> Security Class Initialized
DEBUG - 2024-02-25 14:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:14:26 --> Input Class Initialized
INFO - 2024-02-25 14:14:26 --> Language Class Initialized
INFO - 2024-02-25 14:14:26 --> Loader Class Initialized
INFO - 2024-02-25 14:14:26 --> Helper loaded: url_helper
INFO - 2024-02-25 14:14:26 --> Helper loaded: file_helper
INFO - 2024-02-25 14:14:26 --> Helper loaded: html_helper
INFO - 2024-02-25 14:14:26 --> Helper loaded: text_helper
INFO - 2024-02-25 14:14:26 --> Helper loaded: form_helper
INFO - 2024-02-25 14:14:26 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:14:26 --> Helper loaded: security_helper
INFO - 2024-02-25 14:14:26 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:14:26 --> Database Driver Class Initialized
INFO - 2024-02-25 14:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:14:26 --> Parser Class Initialized
INFO - 2024-02-25 14:14:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:14:26 --> Pagination Class Initialized
INFO - 2024-02-25 14:14:26 --> Form Validation Class Initialized
INFO - 2024-02-25 14:14:26 --> Controller Class Initialized
INFO - 2024-02-25 14:14:26 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:14:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:26 --> Model Class Initialized
DEBUG - 2024-02-25 14:14:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:14:26 --> Model Class Initialized
INFO - 2024-02-25 14:14:26 --> Final output sent to browser
DEBUG - 2024-02-25 14:14:26 --> Total execution time: 0.0436
ERROR - 2024-02-25 14:38:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:38:54 --> Config Class Initialized
INFO - 2024-02-25 14:38:54 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:38:54 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:38:54 --> Utf8 Class Initialized
INFO - 2024-02-25 14:38:54 --> URI Class Initialized
INFO - 2024-02-25 14:38:54 --> Router Class Initialized
INFO - 2024-02-25 14:38:54 --> Output Class Initialized
INFO - 2024-02-25 14:38:54 --> Security Class Initialized
DEBUG - 2024-02-25 14:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:38:54 --> Input Class Initialized
INFO - 2024-02-25 14:38:54 --> Language Class Initialized
INFO - 2024-02-25 14:38:54 --> Loader Class Initialized
INFO - 2024-02-25 14:38:54 --> Helper loaded: url_helper
INFO - 2024-02-25 14:38:54 --> Helper loaded: file_helper
INFO - 2024-02-25 14:38:54 --> Helper loaded: html_helper
INFO - 2024-02-25 14:38:54 --> Helper loaded: text_helper
INFO - 2024-02-25 14:38:54 --> Helper loaded: form_helper
INFO - 2024-02-25 14:38:54 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:38:54 --> Helper loaded: security_helper
INFO - 2024-02-25 14:38:54 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:38:54 --> Database Driver Class Initialized
INFO - 2024-02-25 14:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:38:54 --> Parser Class Initialized
INFO - 2024-02-25 14:38:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:38:54 --> Pagination Class Initialized
INFO - 2024-02-25 14:38:54 --> Form Validation Class Initialized
INFO - 2024-02-25 14:38:54 --> Controller Class Initialized
INFO - 2024-02-25 14:38:54 --> Model Class Initialized
DEBUG - 2024-02-25 14:38:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:38:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:38:54 --> Model Class Initialized
DEBUG - 2024-02-25 14:38:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:38:54 --> Model Class Initialized
INFO - 2024-02-25 14:38:54 --> Final output sent to browser
DEBUG - 2024-02-25 14:38:54 --> Total execution time: 0.0568
ERROR - 2024-02-25 14:38:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:38:54 --> Config Class Initialized
INFO - 2024-02-25 14:38:54 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:38:54 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:38:54 --> Utf8 Class Initialized
INFO - 2024-02-25 14:38:54 --> URI Class Initialized
INFO - 2024-02-25 14:38:54 --> Router Class Initialized
INFO - 2024-02-25 14:38:54 --> Output Class Initialized
INFO - 2024-02-25 14:38:54 --> Security Class Initialized
DEBUG - 2024-02-25 14:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:38:54 --> Input Class Initialized
INFO - 2024-02-25 14:38:54 --> Language Class Initialized
INFO - 2024-02-25 14:38:54 --> Loader Class Initialized
INFO - 2024-02-25 14:38:54 --> Helper loaded: url_helper
INFO - 2024-02-25 14:38:54 --> Helper loaded: file_helper
INFO - 2024-02-25 14:38:54 --> Helper loaded: html_helper
INFO - 2024-02-25 14:38:54 --> Helper loaded: text_helper
INFO - 2024-02-25 14:38:54 --> Helper loaded: form_helper
INFO - 2024-02-25 14:38:54 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:38:54 --> Helper loaded: security_helper
INFO - 2024-02-25 14:38:54 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:38:54 --> Database Driver Class Initialized
INFO - 2024-02-25 14:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:38:54 --> Parser Class Initialized
INFO - 2024-02-25 14:38:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:38:54 --> Pagination Class Initialized
INFO - 2024-02-25 14:38:54 --> Form Validation Class Initialized
INFO - 2024-02-25 14:38:54 --> Controller Class Initialized
INFO - 2024-02-25 14:38:54 --> Model Class Initialized
DEBUG - 2024-02-25 14:38:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:38:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:38:54 --> Model Class Initialized
DEBUG - 2024-02-25 14:38:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:38:54 --> Model Class Initialized
INFO - 2024-02-25 14:38:54 --> Final output sent to browser
DEBUG - 2024-02-25 14:38:54 --> Total execution time: 0.0556
ERROR - 2024-02-25 14:38:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:38:55 --> Config Class Initialized
INFO - 2024-02-25 14:38:55 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:38:55 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:38:55 --> Utf8 Class Initialized
INFO - 2024-02-25 14:38:55 --> URI Class Initialized
INFO - 2024-02-25 14:38:55 --> Router Class Initialized
INFO - 2024-02-25 14:38:55 --> Output Class Initialized
INFO - 2024-02-25 14:38:55 --> Security Class Initialized
DEBUG - 2024-02-25 14:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:38:55 --> Input Class Initialized
INFO - 2024-02-25 14:38:55 --> Language Class Initialized
INFO - 2024-02-25 14:38:55 --> Loader Class Initialized
INFO - 2024-02-25 14:38:55 --> Helper loaded: url_helper
INFO - 2024-02-25 14:38:55 --> Helper loaded: file_helper
INFO - 2024-02-25 14:38:55 --> Helper loaded: html_helper
INFO - 2024-02-25 14:38:55 --> Helper loaded: text_helper
INFO - 2024-02-25 14:38:55 --> Helper loaded: form_helper
INFO - 2024-02-25 14:38:55 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:38:55 --> Helper loaded: security_helper
INFO - 2024-02-25 14:38:55 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:38:55 --> Database Driver Class Initialized
INFO - 2024-02-25 14:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:38:55 --> Parser Class Initialized
INFO - 2024-02-25 14:38:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:38:55 --> Pagination Class Initialized
INFO - 2024-02-25 14:38:55 --> Form Validation Class Initialized
INFO - 2024-02-25 14:38:55 --> Controller Class Initialized
INFO - 2024-02-25 14:38:55 --> Model Class Initialized
DEBUG - 2024-02-25 14:38:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:38:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:38:55 --> Model Class Initialized
DEBUG - 2024-02-25 14:38:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:38:55 --> Model Class Initialized
INFO - 2024-02-25 14:38:55 --> Final output sent to browser
DEBUG - 2024-02-25 14:38:55 --> Total execution time: 0.0473
ERROR - 2024-02-25 14:38:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:38:55 --> Config Class Initialized
INFO - 2024-02-25 14:38:55 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:38:55 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:38:55 --> Utf8 Class Initialized
INFO - 2024-02-25 14:38:55 --> URI Class Initialized
INFO - 2024-02-25 14:38:55 --> Router Class Initialized
INFO - 2024-02-25 14:38:55 --> Output Class Initialized
INFO - 2024-02-25 14:38:55 --> Security Class Initialized
DEBUG - 2024-02-25 14:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:38:55 --> Input Class Initialized
INFO - 2024-02-25 14:38:55 --> Language Class Initialized
INFO - 2024-02-25 14:38:55 --> Loader Class Initialized
INFO - 2024-02-25 14:38:55 --> Helper loaded: url_helper
INFO - 2024-02-25 14:38:55 --> Helper loaded: file_helper
INFO - 2024-02-25 14:38:55 --> Helper loaded: html_helper
INFO - 2024-02-25 14:38:55 --> Helper loaded: text_helper
INFO - 2024-02-25 14:38:55 --> Helper loaded: form_helper
INFO - 2024-02-25 14:38:55 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:38:55 --> Helper loaded: security_helper
INFO - 2024-02-25 14:38:55 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:38:55 --> Database Driver Class Initialized
INFO - 2024-02-25 14:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:38:55 --> Parser Class Initialized
INFO - 2024-02-25 14:38:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:38:55 --> Pagination Class Initialized
INFO - 2024-02-25 14:38:55 --> Form Validation Class Initialized
INFO - 2024-02-25 14:38:55 --> Controller Class Initialized
INFO - 2024-02-25 14:38:55 --> Model Class Initialized
DEBUG - 2024-02-25 14:38:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:38:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:38:55 --> Model Class Initialized
DEBUG - 2024-02-25 14:38:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:38:55 --> Model Class Initialized
INFO - 2024-02-25 14:38:55 --> Final output sent to browser
DEBUG - 2024-02-25 14:38:55 --> Total execution time: 0.0449
ERROR - 2024-02-25 14:38:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:38:56 --> Config Class Initialized
INFO - 2024-02-25 14:38:56 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:38:56 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:38:56 --> Utf8 Class Initialized
INFO - 2024-02-25 14:38:56 --> URI Class Initialized
INFO - 2024-02-25 14:38:56 --> Router Class Initialized
INFO - 2024-02-25 14:38:56 --> Output Class Initialized
INFO - 2024-02-25 14:38:56 --> Security Class Initialized
DEBUG - 2024-02-25 14:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:38:56 --> Input Class Initialized
INFO - 2024-02-25 14:38:56 --> Language Class Initialized
INFO - 2024-02-25 14:38:56 --> Loader Class Initialized
INFO - 2024-02-25 14:38:56 --> Helper loaded: url_helper
INFO - 2024-02-25 14:38:56 --> Helper loaded: file_helper
INFO - 2024-02-25 14:38:56 --> Helper loaded: html_helper
INFO - 2024-02-25 14:38:56 --> Helper loaded: text_helper
INFO - 2024-02-25 14:38:56 --> Helper loaded: form_helper
INFO - 2024-02-25 14:38:56 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:38:56 --> Helper loaded: security_helper
INFO - 2024-02-25 14:38:56 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:38:56 --> Database Driver Class Initialized
INFO - 2024-02-25 14:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:38:56 --> Parser Class Initialized
INFO - 2024-02-25 14:38:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:38:56 --> Pagination Class Initialized
INFO - 2024-02-25 14:38:56 --> Form Validation Class Initialized
INFO - 2024-02-25 14:38:56 --> Controller Class Initialized
INFO - 2024-02-25 14:38:56 --> Model Class Initialized
DEBUG - 2024-02-25 14:38:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:38:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:38:56 --> Model Class Initialized
DEBUG - 2024-02-25 14:38:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:38:56 --> Model Class Initialized
INFO - 2024-02-25 14:38:56 --> Final output sent to browser
DEBUG - 2024-02-25 14:38:56 --> Total execution time: 0.0447
ERROR - 2024-02-25 14:38:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:38:57 --> Config Class Initialized
INFO - 2024-02-25 14:38:57 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:38:57 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:38:57 --> Utf8 Class Initialized
INFO - 2024-02-25 14:38:57 --> URI Class Initialized
INFO - 2024-02-25 14:38:57 --> Router Class Initialized
INFO - 2024-02-25 14:38:57 --> Output Class Initialized
INFO - 2024-02-25 14:38:57 --> Security Class Initialized
DEBUG - 2024-02-25 14:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:38:57 --> Input Class Initialized
INFO - 2024-02-25 14:38:57 --> Language Class Initialized
INFO - 2024-02-25 14:38:57 --> Loader Class Initialized
INFO - 2024-02-25 14:38:57 --> Helper loaded: url_helper
INFO - 2024-02-25 14:38:57 --> Helper loaded: file_helper
INFO - 2024-02-25 14:38:57 --> Helper loaded: html_helper
INFO - 2024-02-25 14:38:57 --> Helper loaded: text_helper
INFO - 2024-02-25 14:38:57 --> Helper loaded: form_helper
INFO - 2024-02-25 14:38:57 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:38:57 --> Helper loaded: security_helper
INFO - 2024-02-25 14:38:57 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:38:57 --> Database Driver Class Initialized
INFO - 2024-02-25 14:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:38:57 --> Parser Class Initialized
INFO - 2024-02-25 14:38:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:38:57 --> Pagination Class Initialized
INFO - 2024-02-25 14:38:57 --> Form Validation Class Initialized
INFO - 2024-02-25 14:38:57 --> Controller Class Initialized
INFO - 2024-02-25 14:38:57 --> Model Class Initialized
DEBUG - 2024-02-25 14:38:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:38:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:38:57 --> Model Class Initialized
DEBUG - 2024-02-25 14:38:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:38:57 --> Model Class Initialized
INFO - 2024-02-25 14:38:57 --> Final output sent to browser
DEBUG - 2024-02-25 14:38:57 --> Total execution time: 0.0372
ERROR - 2024-02-25 14:38:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:38:57 --> Config Class Initialized
INFO - 2024-02-25 14:38:57 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:38:57 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:38:57 --> Utf8 Class Initialized
INFO - 2024-02-25 14:38:57 --> URI Class Initialized
INFO - 2024-02-25 14:38:57 --> Router Class Initialized
INFO - 2024-02-25 14:38:57 --> Output Class Initialized
INFO - 2024-02-25 14:38:57 --> Security Class Initialized
DEBUG - 2024-02-25 14:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:38:57 --> Input Class Initialized
INFO - 2024-02-25 14:38:57 --> Language Class Initialized
INFO - 2024-02-25 14:38:57 --> Loader Class Initialized
INFO - 2024-02-25 14:38:57 --> Helper loaded: url_helper
INFO - 2024-02-25 14:38:57 --> Helper loaded: file_helper
INFO - 2024-02-25 14:38:57 --> Helper loaded: html_helper
INFO - 2024-02-25 14:38:57 --> Helper loaded: text_helper
INFO - 2024-02-25 14:38:57 --> Helper loaded: form_helper
INFO - 2024-02-25 14:38:57 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:38:57 --> Helper loaded: security_helper
INFO - 2024-02-25 14:38:57 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:38:57 --> Database Driver Class Initialized
INFO - 2024-02-25 14:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:38:57 --> Parser Class Initialized
INFO - 2024-02-25 14:38:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:38:57 --> Pagination Class Initialized
INFO - 2024-02-25 14:38:57 --> Form Validation Class Initialized
INFO - 2024-02-25 14:38:57 --> Controller Class Initialized
INFO - 2024-02-25 14:38:57 --> Model Class Initialized
DEBUG - 2024-02-25 14:38:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:38:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:38:57 --> Model Class Initialized
DEBUG - 2024-02-25 14:38:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:38:57 --> Model Class Initialized
INFO - 2024-02-25 14:38:57 --> Final output sent to browser
DEBUG - 2024-02-25 14:38:57 --> Total execution time: 0.0219
ERROR - 2024-02-25 14:38:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:38:58 --> Config Class Initialized
INFO - 2024-02-25 14:38:58 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:38:58 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:38:58 --> Utf8 Class Initialized
INFO - 2024-02-25 14:38:58 --> URI Class Initialized
INFO - 2024-02-25 14:38:58 --> Router Class Initialized
INFO - 2024-02-25 14:38:58 --> Output Class Initialized
INFO - 2024-02-25 14:38:58 --> Security Class Initialized
DEBUG - 2024-02-25 14:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:38:58 --> Input Class Initialized
INFO - 2024-02-25 14:38:58 --> Language Class Initialized
INFO - 2024-02-25 14:38:58 --> Loader Class Initialized
INFO - 2024-02-25 14:38:58 --> Helper loaded: url_helper
INFO - 2024-02-25 14:38:58 --> Helper loaded: file_helper
INFO - 2024-02-25 14:38:58 --> Helper loaded: html_helper
INFO - 2024-02-25 14:38:58 --> Helper loaded: text_helper
INFO - 2024-02-25 14:38:58 --> Helper loaded: form_helper
INFO - 2024-02-25 14:38:58 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:38:58 --> Helper loaded: security_helper
INFO - 2024-02-25 14:38:58 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:38:58 --> Database Driver Class Initialized
INFO - 2024-02-25 14:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:38:58 --> Parser Class Initialized
INFO - 2024-02-25 14:38:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:38:58 --> Pagination Class Initialized
INFO - 2024-02-25 14:38:58 --> Form Validation Class Initialized
INFO - 2024-02-25 14:38:58 --> Controller Class Initialized
INFO - 2024-02-25 14:38:58 --> Model Class Initialized
DEBUG - 2024-02-25 14:38:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:38:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:38:58 --> Model Class Initialized
DEBUG - 2024-02-25 14:38:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:38:58 --> Model Class Initialized
INFO - 2024-02-25 14:38:58 --> Final output sent to browser
DEBUG - 2024-02-25 14:38:58 --> Total execution time: 0.0240
ERROR - 2024-02-25 14:38:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:38:59 --> Config Class Initialized
INFO - 2024-02-25 14:38:59 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:38:59 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:38:59 --> Utf8 Class Initialized
INFO - 2024-02-25 14:38:59 --> URI Class Initialized
INFO - 2024-02-25 14:38:59 --> Router Class Initialized
INFO - 2024-02-25 14:38:59 --> Output Class Initialized
INFO - 2024-02-25 14:38:59 --> Security Class Initialized
DEBUG - 2024-02-25 14:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:38:59 --> Input Class Initialized
INFO - 2024-02-25 14:38:59 --> Language Class Initialized
INFO - 2024-02-25 14:38:59 --> Loader Class Initialized
INFO - 2024-02-25 14:38:59 --> Helper loaded: url_helper
INFO - 2024-02-25 14:38:59 --> Helper loaded: file_helper
INFO - 2024-02-25 14:38:59 --> Helper loaded: html_helper
INFO - 2024-02-25 14:38:59 --> Helper loaded: text_helper
INFO - 2024-02-25 14:38:59 --> Helper loaded: form_helper
INFO - 2024-02-25 14:38:59 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:38:59 --> Helper loaded: security_helper
INFO - 2024-02-25 14:38:59 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:38:59 --> Database Driver Class Initialized
INFO - 2024-02-25 14:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:38:59 --> Parser Class Initialized
INFO - 2024-02-25 14:38:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:38:59 --> Pagination Class Initialized
INFO - 2024-02-25 14:38:59 --> Form Validation Class Initialized
INFO - 2024-02-25 14:38:59 --> Controller Class Initialized
INFO - 2024-02-25 14:38:59 --> Model Class Initialized
DEBUG - 2024-02-25 14:38:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:38:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:38:59 --> Model Class Initialized
DEBUG - 2024-02-25 14:38:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:38:59 --> Model Class Initialized
INFO - 2024-02-25 14:38:59 --> Final output sent to browser
DEBUG - 2024-02-25 14:38:59 --> Total execution time: 0.0249
ERROR - 2024-02-25 14:39:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:39:00 --> Config Class Initialized
INFO - 2024-02-25 14:39:00 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:39:00 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:39:00 --> Utf8 Class Initialized
INFO - 2024-02-25 14:39:00 --> URI Class Initialized
INFO - 2024-02-25 14:39:00 --> Router Class Initialized
INFO - 2024-02-25 14:39:00 --> Output Class Initialized
INFO - 2024-02-25 14:39:00 --> Security Class Initialized
DEBUG - 2024-02-25 14:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:39:00 --> Input Class Initialized
INFO - 2024-02-25 14:39:00 --> Language Class Initialized
INFO - 2024-02-25 14:39:00 --> Loader Class Initialized
INFO - 2024-02-25 14:39:00 --> Helper loaded: url_helper
INFO - 2024-02-25 14:39:00 --> Helper loaded: file_helper
INFO - 2024-02-25 14:39:00 --> Helper loaded: html_helper
INFO - 2024-02-25 14:39:00 --> Helper loaded: text_helper
INFO - 2024-02-25 14:39:00 --> Helper loaded: form_helper
INFO - 2024-02-25 14:39:00 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:39:00 --> Helper loaded: security_helper
INFO - 2024-02-25 14:39:00 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:39:00 --> Database Driver Class Initialized
INFO - 2024-02-25 14:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:39:00 --> Parser Class Initialized
INFO - 2024-02-25 14:39:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:39:00 --> Pagination Class Initialized
INFO - 2024-02-25 14:39:00 --> Form Validation Class Initialized
INFO - 2024-02-25 14:39:00 --> Controller Class Initialized
INFO - 2024-02-25 14:39:00 --> Model Class Initialized
DEBUG - 2024-02-25 14:39:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:39:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:39:00 --> Model Class Initialized
DEBUG - 2024-02-25 14:39:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:39:00 --> Model Class Initialized
INFO - 2024-02-25 14:39:00 --> Final output sent to browser
DEBUG - 2024-02-25 14:39:00 --> Total execution time: 0.0462
ERROR - 2024-02-25 14:39:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:39:04 --> Config Class Initialized
INFO - 2024-02-25 14:39:04 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:39:04 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:39:04 --> Utf8 Class Initialized
INFO - 2024-02-25 14:39:04 --> URI Class Initialized
INFO - 2024-02-25 14:39:04 --> Router Class Initialized
INFO - 2024-02-25 14:39:04 --> Output Class Initialized
INFO - 2024-02-25 14:39:04 --> Security Class Initialized
DEBUG - 2024-02-25 14:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:39:04 --> Input Class Initialized
INFO - 2024-02-25 14:39:04 --> Language Class Initialized
INFO - 2024-02-25 14:39:04 --> Loader Class Initialized
INFO - 2024-02-25 14:39:04 --> Helper loaded: url_helper
INFO - 2024-02-25 14:39:04 --> Helper loaded: file_helper
INFO - 2024-02-25 14:39:04 --> Helper loaded: html_helper
INFO - 2024-02-25 14:39:04 --> Helper loaded: text_helper
INFO - 2024-02-25 14:39:04 --> Helper loaded: form_helper
INFO - 2024-02-25 14:39:04 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:39:04 --> Helper loaded: security_helper
INFO - 2024-02-25 14:39:04 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:39:04 --> Database Driver Class Initialized
INFO - 2024-02-25 14:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:39:04 --> Parser Class Initialized
INFO - 2024-02-25 14:39:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:39:04 --> Pagination Class Initialized
INFO - 2024-02-25 14:39:04 --> Form Validation Class Initialized
INFO - 2024-02-25 14:39:04 --> Controller Class Initialized
INFO - 2024-02-25 14:39:04 --> Model Class Initialized
DEBUG - 2024-02-25 14:39:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:39:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:39:04 --> Model Class Initialized
DEBUG - 2024-02-25 14:39:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:39:04 --> Model Class Initialized
INFO - 2024-02-25 14:39:05 --> Final output sent to browser
DEBUG - 2024-02-25 14:39:05 --> Total execution time: 0.0381
ERROR - 2024-02-25 14:39:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:39:05 --> Config Class Initialized
INFO - 2024-02-25 14:39:05 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:39:05 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:39:05 --> Utf8 Class Initialized
INFO - 2024-02-25 14:39:05 --> URI Class Initialized
INFO - 2024-02-25 14:39:05 --> Router Class Initialized
INFO - 2024-02-25 14:39:05 --> Output Class Initialized
INFO - 2024-02-25 14:39:05 --> Security Class Initialized
DEBUG - 2024-02-25 14:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:39:05 --> Input Class Initialized
INFO - 2024-02-25 14:39:05 --> Language Class Initialized
INFO - 2024-02-25 14:39:05 --> Loader Class Initialized
INFO - 2024-02-25 14:39:05 --> Helper loaded: url_helper
INFO - 2024-02-25 14:39:05 --> Helper loaded: file_helper
INFO - 2024-02-25 14:39:05 --> Helper loaded: html_helper
INFO - 2024-02-25 14:39:05 --> Helper loaded: text_helper
INFO - 2024-02-25 14:39:05 --> Helper loaded: form_helper
INFO - 2024-02-25 14:39:05 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:39:05 --> Helper loaded: security_helper
INFO - 2024-02-25 14:39:05 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:39:05 --> Database Driver Class Initialized
INFO - 2024-02-25 14:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:39:05 --> Parser Class Initialized
INFO - 2024-02-25 14:39:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:39:05 --> Pagination Class Initialized
INFO - 2024-02-25 14:39:05 --> Form Validation Class Initialized
INFO - 2024-02-25 14:39:05 --> Controller Class Initialized
INFO - 2024-02-25 14:39:05 --> Model Class Initialized
DEBUG - 2024-02-25 14:39:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:39:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:39:05 --> Model Class Initialized
DEBUG - 2024-02-25 14:39:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:39:05 --> Model Class Initialized
INFO - 2024-02-25 14:39:05 --> Final output sent to browser
DEBUG - 2024-02-25 14:39:05 --> Total execution time: 0.0378
ERROR - 2024-02-25 14:39:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 14:39:06 --> Config Class Initialized
INFO - 2024-02-25 14:39:06 --> Hooks Class Initialized
DEBUG - 2024-02-25 14:39:06 --> UTF-8 Support Enabled
INFO - 2024-02-25 14:39:06 --> Utf8 Class Initialized
INFO - 2024-02-25 14:39:06 --> URI Class Initialized
INFO - 2024-02-25 14:39:06 --> Router Class Initialized
INFO - 2024-02-25 14:39:06 --> Output Class Initialized
INFO - 2024-02-25 14:39:06 --> Security Class Initialized
DEBUG - 2024-02-25 14:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 14:39:06 --> Input Class Initialized
INFO - 2024-02-25 14:39:06 --> Language Class Initialized
INFO - 2024-02-25 14:39:06 --> Loader Class Initialized
INFO - 2024-02-25 14:39:06 --> Helper loaded: url_helper
INFO - 2024-02-25 14:39:06 --> Helper loaded: file_helper
INFO - 2024-02-25 14:39:06 --> Helper loaded: html_helper
INFO - 2024-02-25 14:39:06 --> Helper loaded: text_helper
INFO - 2024-02-25 14:39:06 --> Helper loaded: form_helper
INFO - 2024-02-25 14:39:06 --> Helper loaded: lang_helper
INFO - 2024-02-25 14:39:06 --> Helper loaded: security_helper
INFO - 2024-02-25 14:39:06 --> Helper loaded: cookie_helper
INFO - 2024-02-25 14:39:06 --> Database Driver Class Initialized
INFO - 2024-02-25 14:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 14:39:06 --> Parser Class Initialized
INFO - 2024-02-25 14:39:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 14:39:06 --> Pagination Class Initialized
INFO - 2024-02-25 14:39:06 --> Form Validation Class Initialized
INFO - 2024-02-25 14:39:06 --> Controller Class Initialized
INFO - 2024-02-25 14:39:06 --> Model Class Initialized
DEBUG - 2024-02-25 14:39:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 14:39:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:39:06 --> Model Class Initialized
DEBUG - 2024-02-25 14:39:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 14:39:06 --> Model Class Initialized
INFO - 2024-02-25 14:39:06 --> Final output sent to browser
DEBUG - 2024-02-25 14:39:06 --> Total execution time: 0.0406
ERROR - 2024-02-25 15:15:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:15:27 --> Config Class Initialized
INFO - 2024-02-25 15:15:27 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:15:27 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:15:27 --> Utf8 Class Initialized
INFO - 2024-02-25 15:15:27 --> URI Class Initialized
DEBUG - 2024-02-25 15:15:27 --> No URI present. Default controller set.
INFO - 2024-02-25 15:15:27 --> Router Class Initialized
INFO - 2024-02-25 15:15:27 --> Output Class Initialized
INFO - 2024-02-25 15:15:27 --> Security Class Initialized
DEBUG - 2024-02-25 15:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:15:27 --> Input Class Initialized
INFO - 2024-02-25 15:15:27 --> Language Class Initialized
INFO - 2024-02-25 15:15:27 --> Loader Class Initialized
INFO - 2024-02-25 15:15:27 --> Helper loaded: url_helper
INFO - 2024-02-25 15:15:27 --> Helper loaded: file_helper
INFO - 2024-02-25 15:15:27 --> Helper loaded: html_helper
INFO - 2024-02-25 15:15:27 --> Helper loaded: text_helper
INFO - 2024-02-25 15:15:27 --> Helper loaded: form_helper
INFO - 2024-02-25 15:15:27 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:15:27 --> Helper loaded: security_helper
INFO - 2024-02-25 15:15:27 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:15:27 --> Database Driver Class Initialized
INFO - 2024-02-25 15:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:15:27 --> Parser Class Initialized
INFO - 2024-02-25 15:15:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:15:27 --> Pagination Class Initialized
INFO - 2024-02-25 15:15:27 --> Form Validation Class Initialized
INFO - 2024-02-25 15:15:27 --> Controller Class Initialized
INFO - 2024-02-25 15:15:27 --> Model Class Initialized
DEBUG - 2024-02-25 15:15:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-25 15:15:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:15:28 --> Config Class Initialized
INFO - 2024-02-25 15:15:28 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:15:28 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:15:28 --> Utf8 Class Initialized
INFO - 2024-02-25 15:15:28 --> URI Class Initialized
DEBUG - 2024-02-25 15:15:28 --> No URI present. Default controller set.
INFO - 2024-02-25 15:15:28 --> Router Class Initialized
INFO - 2024-02-25 15:15:28 --> Output Class Initialized
INFO - 2024-02-25 15:15:28 --> Security Class Initialized
DEBUG - 2024-02-25 15:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:15:28 --> Input Class Initialized
INFO - 2024-02-25 15:15:28 --> Language Class Initialized
INFO - 2024-02-25 15:15:28 --> Loader Class Initialized
INFO - 2024-02-25 15:15:28 --> Helper loaded: url_helper
INFO - 2024-02-25 15:15:28 --> Helper loaded: file_helper
INFO - 2024-02-25 15:15:28 --> Helper loaded: html_helper
INFO - 2024-02-25 15:15:28 --> Helper loaded: text_helper
INFO - 2024-02-25 15:15:28 --> Helper loaded: form_helper
INFO - 2024-02-25 15:15:28 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:15:28 --> Helper loaded: security_helper
INFO - 2024-02-25 15:15:28 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:15:28 --> Database Driver Class Initialized
INFO - 2024-02-25 15:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:15:28 --> Parser Class Initialized
INFO - 2024-02-25 15:15:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:15:28 --> Pagination Class Initialized
INFO - 2024-02-25 15:15:28 --> Form Validation Class Initialized
INFO - 2024-02-25 15:15:28 --> Controller Class Initialized
INFO - 2024-02-25 15:15:28 --> Model Class Initialized
DEBUG - 2024-02-25 15:15:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-25 15:15:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:15:28 --> Config Class Initialized
INFO - 2024-02-25 15:15:28 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:15:28 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:15:28 --> Utf8 Class Initialized
INFO - 2024-02-25 15:15:28 --> URI Class Initialized
INFO - 2024-02-25 15:15:28 --> Router Class Initialized
INFO - 2024-02-25 15:15:28 --> Output Class Initialized
INFO - 2024-02-25 15:15:28 --> Security Class Initialized
DEBUG - 2024-02-25 15:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:15:28 --> Input Class Initialized
INFO - 2024-02-25 15:15:28 --> Language Class Initialized
INFO - 2024-02-25 15:15:28 --> Loader Class Initialized
INFO - 2024-02-25 15:15:28 --> Helper loaded: url_helper
INFO - 2024-02-25 15:15:28 --> Helper loaded: file_helper
INFO - 2024-02-25 15:15:28 --> Helper loaded: html_helper
INFO - 2024-02-25 15:15:28 --> Helper loaded: text_helper
INFO - 2024-02-25 15:15:28 --> Helper loaded: form_helper
INFO - 2024-02-25 15:15:28 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:15:28 --> Helper loaded: security_helper
INFO - 2024-02-25 15:15:28 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:15:28 --> Database Driver Class Initialized
INFO - 2024-02-25 15:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:15:28 --> Parser Class Initialized
INFO - 2024-02-25 15:15:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:15:28 --> Pagination Class Initialized
INFO - 2024-02-25 15:15:28 --> Form Validation Class Initialized
INFO - 2024-02-25 15:15:28 --> Controller Class Initialized
INFO - 2024-02-25 15:15:28 --> Model Class Initialized
DEBUG - 2024-02-25 15:15:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:15:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-25 15:15:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:15:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 15:15:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 15:15:28 --> Model Class Initialized
INFO - 2024-02-25 15:15:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 15:15:28 --> Final output sent to browser
DEBUG - 2024-02-25 15:15:28 --> Total execution time: 0.0398
ERROR - 2024-02-25 15:17:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:17:39 --> Config Class Initialized
INFO - 2024-02-25 15:17:39 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:17:39 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:17:39 --> Utf8 Class Initialized
INFO - 2024-02-25 15:17:39 --> URI Class Initialized
DEBUG - 2024-02-25 15:17:39 --> No URI present. Default controller set.
INFO - 2024-02-25 15:17:39 --> Router Class Initialized
INFO - 2024-02-25 15:17:39 --> Output Class Initialized
INFO - 2024-02-25 15:17:39 --> Security Class Initialized
DEBUG - 2024-02-25 15:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:17:39 --> Input Class Initialized
INFO - 2024-02-25 15:17:39 --> Language Class Initialized
INFO - 2024-02-25 15:17:39 --> Loader Class Initialized
INFO - 2024-02-25 15:17:39 --> Helper loaded: url_helper
INFO - 2024-02-25 15:17:39 --> Helper loaded: file_helper
INFO - 2024-02-25 15:17:39 --> Helper loaded: html_helper
INFO - 2024-02-25 15:17:39 --> Helper loaded: text_helper
INFO - 2024-02-25 15:17:39 --> Helper loaded: form_helper
INFO - 2024-02-25 15:17:39 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:17:39 --> Helper loaded: security_helper
INFO - 2024-02-25 15:17:39 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:17:39 --> Database Driver Class Initialized
INFO - 2024-02-25 15:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:17:39 --> Parser Class Initialized
INFO - 2024-02-25 15:17:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:17:39 --> Pagination Class Initialized
INFO - 2024-02-25 15:17:39 --> Form Validation Class Initialized
INFO - 2024-02-25 15:17:39 --> Controller Class Initialized
INFO - 2024-02-25 15:17:39 --> Model Class Initialized
DEBUG - 2024-02-25 15:17:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-25 15:17:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:17:40 --> Config Class Initialized
INFO - 2024-02-25 15:17:40 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:17:40 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:17:40 --> Utf8 Class Initialized
INFO - 2024-02-25 15:17:40 --> URI Class Initialized
INFO - 2024-02-25 15:17:40 --> Router Class Initialized
INFO - 2024-02-25 15:17:40 --> Output Class Initialized
INFO - 2024-02-25 15:17:40 --> Security Class Initialized
DEBUG - 2024-02-25 15:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:17:40 --> Input Class Initialized
INFO - 2024-02-25 15:17:40 --> Language Class Initialized
INFO - 2024-02-25 15:17:40 --> Loader Class Initialized
INFO - 2024-02-25 15:17:40 --> Helper loaded: url_helper
INFO - 2024-02-25 15:17:40 --> Helper loaded: file_helper
INFO - 2024-02-25 15:17:40 --> Helper loaded: html_helper
INFO - 2024-02-25 15:17:40 --> Helper loaded: text_helper
INFO - 2024-02-25 15:17:40 --> Helper loaded: form_helper
INFO - 2024-02-25 15:17:40 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:17:40 --> Helper loaded: security_helper
INFO - 2024-02-25 15:17:40 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:17:40 --> Database Driver Class Initialized
INFO - 2024-02-25 15:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:17:40 --> Parser Class Initialized
INFO - 2024-02-25 15:17:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:17:40 --> Pagination Class Initialized
INFO - 2024-02-25 15:17:40 --> Form Validation Class Initialized
INFO - 2024-02-25 15:17:40 --> Controller Class Initialized
INFO - 2024-02-25 15:17:40 --> Model Class Initialized
DEBUG - 2024-02-25 15:17:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:17:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-25 15:17:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:17:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 15:17:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 15:17:40 --> Model Class Initialized
INFO - 2024-02-25 15:17:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 15:17:40 --> Final output sent to browser
DEBUG - 2024-02-25 15:17:40 --> Total execution time: 0.0312
ERROR - 2024-02-25 15:17:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:17:43 --> Config Class Initialized
INFO - 2024-02-25 15:17:43 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:17:43 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:17:43 --> Utf8 Class Initialized
INFO - 2024-02-25 15:17:43 --> URI Class Initialized
INFO - 2024-02-25 15:17:43 --> Router Class Initialized
INFO - 2024-02-25 15:17:43 --> Output Class Initialized
INFO - 2024-02-25 15:17:43 --> Security Class Initialized
DEBUG - 2024-02-25 15:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:17:43 --> Input Class Initialized
INFO - 2024-02-25 15:17:43 --> Language Class Initialized
INFO - 2024-02-25 15:17:43 --> Loader Class Initialized
INFO - 2024-02-25 15:17:43 --> Helper loaded: url_helper
INFO - 2024-02-25 15:17:43 --> Helper loaded: file_helper
INFO - 2024-02-25 15:17:43 --> Helper loaded: html_helper
INFO - 2024-02-25 15:17:43 --> Helper loaded: text_helper
INFO - 2024-02-25 15:17:43 --> Helper loaded: form_helper
INFO - 2024-02-25 15:17:43 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:17:43 --> Helper loaded: security_helper
INFO - 2024-02-25 15:17:43 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:17:43 --> Database Driver Class Initialized
INFO - 2024-02-25 15:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:17:43 --> Parser Class Initialized
INFO - 2024-02-25 15:17:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:17:43 --> Pagination Class Initialized
INFO - 2024-02-25 15:17:43 --> Form Validation Class Initialized
INFO - 2024-02-25 15:17:43 --> Controller Class Initialized
INFO - 2024-02-25 15:17:43 --> Model Class Initialized
DEBUG - 2024-02-25 15:17:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:17:43 --> Model Class Initialized
INFO - 2024-02-25 15:17:43 --> Final output sent to browser
DEBUG - 2024-02-25 15:17:43 --> Total execution time: 0.0193
ERROR - 2024-02-25 15:17:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:17:44 --> Config Class Initialized
INFO - 2024-02-25 15:17:44 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:17:44 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:17:44 --> Utf8 Class Initialized
INFO - 2024-02-25 15:17:44 --> URI Class Initialized
DEBUG - 2024-02-25 15:17:44 --> No URI present. Default controller set.
INFO - 2024-02-25 15:17:44 --> Router Class Initialized
INFO - 2024-02-25 15:17:44 --> Output Class Initialized
INFO - 2024-02-25 15:17:44 --> Security Class Initialized
DEBUG - 2024-02-25 15:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:17:44 --> Input Class Initialized
INFO - 2024-02-25 15:17:44 --> Language Class Initialized
INFO - 2024-02-25 15:17:44 --> Loader Class Initialized
INFO - 2024-02-25 15:17:44 --> Helper loaded: url_helper
INFO - 2024-02-25 15:17:44 --> Helper loaded: file_helper
INFO - 2024-02-25 15:17:44 --> Helper loaded: html_helper
INFO - 2024-02-25 15:17:44 --> Helper loaded: text_helper
INFO - 2024-02-25 15:17:44 --> Helper loaded: form_helper
INFO - 2024-02-25 15:17:44 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:17:44 --> Helper loaded: security_helper
INFO - 2024-02-25 15:17:44 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:17:44 --> Database Driver Class Initialized
INFO - 2024-02-25 15:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:17:44 --> Parser Class Initialized
INFO - 2024-02-25 15:17:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:17:44 --> Pagination Class Initialized
INFO - 2024-02-25 15:17:44 --> Form Validation Class Initialized
INFO - 2024-02-25 15:17:44 --> Controller Class Initialized
INFO - 2024-02-25 15:17:44 --> Model Class Initialized
DEBUG - 2024-02-25 15:17:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:17:44 --> Model Class Initialized
DEBUG - 2024-02-25 15:17:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:17:44 --> Model Class Initialized
INFO - 2024-02-25 15:17:44 --> Model Class Initialized
INFO - 2024-02-25 15:17:44 --> Model Class Initialized
INFO - 2024-02-25 15:17:44 --> Model Class Initialized
DEBUG - 2024-02-25 15:17:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:17:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:17:44 --> Model Class Initialized
INFO - 2024-02-25 15:17:44 --> Model Class Initialized
INFO - 2024-02-25 15:17:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-25 15:17:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:17:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 15:17:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 15:17:44 --> Model Class Initialized
INFO - 2024-02-25 15:17:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-25 15:17:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-25 15:17:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 15:17:44 --> Final output sent to browser
DEBUG - 2024-02-25 15:17:44 --> Total execution time: 0.4268
ERROR - 2024-02-25 15:17:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:17:45 --> Config Class Initialized
INFO - 2024-02-25 15:17:45 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:17:45 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:17:45 --> Utf8 Class Initialized
INFO - 2024-02-25 15:17:45 --> URI Class Initialized
INFO - 2024-02-25 15:17:45 --> Router Class Initialized
INFO - 2024-02-25 15:17:45 --> Output Class Initialized
INFO - 2024-02-25 15:17:45 --> Security Class Initialized
DEBUG - 2024-02-25 15:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:17:45 --> Input Class Initialized
INFO - 2024-02-25 15:17:45 --> Language Class Initialized
INFO - 2024-02-25 15:17:45 --> Loader Class Initialized
INFO - 2024-02-25 15:17:45 --> Helper loaded: url_helper
INFO - 2024-02-25 15:17:45 --> Helper loaded: file_helper
INFO - 2024-02-25 15:17:45 --> Helper loaded: html_helper
INFO - 2024-02-25 15:17:45 --> Helper loaded: text_helper
INFO - 2024-02-25 15:17:45 --> Helper loaded: form_helper
INFO - 2024-02-25 15:17:45 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:17:45 --> Helper loaded: security_helper
INFO - 2024-02-25 15:17:45 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:17:45 --> Database Driver Class Initialized
INFO - 2024-02-25 15:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:17:45 --> Parser Class Initialized
INFO - 2024-02-25 15:17:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:17:45 --> Pagination Class Initialized
INFO - 2024-02-25 15:17:45 --> Form Validation Class Initialized
INFO - 2024-02-25 15:17:45 --> Controller Class Initialized
DEBUG - 2024-02-25 15:17:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:17:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:17:45 --> Model Class Initialized
INFO - 2024-02-25 15:17:45 --> Final output sent to browser
DEBUG - 2024-02-25 15:17:45 --> Total execution time: 0.0136
ERROR - 2024-02-25 15:17:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:17:56 --> Config Class Initialized
INFO - 2024-02-25 15:17:56 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:17:56 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:17:56 --> Utf8 Class Initialized
INFO - 2024-02-25 15:17:56 --> URI Class Initialized
INFO - 2024-02-25 15:17:56 --> Router Class Initialized
INFO - 2024-02-25 15:17:56 --> Output Class Initialized
INFO - 2024-02-25 15:17:56 --> Security Class Initialized
DEBUG - 2024-02-25 15:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:17:56 --> Input Class Initialized
INFO - 2024-02-25 15:17:56 --> Language Class Initialized
INFO - 2024-02-25 15:17:56 --> Loader Class Initialized
INFO - 2024-02-25 15:17:56 --> Helper loaded: url_helper
INFO - 2024-02-25 15:17:56 --> Helper loaded: file_helper
INFO - 2024-02-25 15:17:56 --> Helper loaded: html_helper
INFO - 2024-02-25 15:17:56 --> Helper loaded: text_helper
INFO - 2024-02-25 15:17:56 --> Helper loaded: form_helper
INFO - 2024-02-25 15:17:56 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:17:56 --> Helper loaded: security_helper
INFO - 2024-02-25 15:17:56 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:17:56 --> Database Driver Class Initialized
INFO - 2024-02-25 15:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:17:56 --> Parser Class Initialized
INFO - 2024-02-25 15:17:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:17:56 --> Pagination Class Initialized
INFO - 2024-02-25 15:17:56 --> Form Validation Class Initialized
INFO - 2024-02-25 15:17:56 --> Controller Class Initialized
INFO - 2024-02-25 15:17:56 --> Model Class Initialized
DEBUG - 2024-02-25 15:17:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:17:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:17:56 --> Model Class Initialized
DEBUG - 2024-02-25 15:17:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:17:56 --> Model Class Initialized
INFO - 2024-02-25 15:17:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-25 15:17:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:17:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 15:17:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 15:17:56 --> Model Class Initialized
INFO - 2024-02-25 15:17:56 --> Model Class Initialized
INFO - 2024-02-25 15:17:56 --> Model Class Initialized
INFO - 2024-02-25 15:17:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-25 15:17:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-25 15:17:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 15:17:56 --> Final output sent to browser
DEBUG - 2024-02-25 15:17:56 --> Total execution time: 0.2214
ERROR - 2024-02-25 15:17:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:17:57 --> Config Class Initialized
INFO - 2024-02-25 15:17:57 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:17:57 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:17:57 --> Utf8 Class Initialized
INFO - 2024-02-25 15:17:57 --> URI Class Initialized
INFO - 2024-02-25 15:17:57 --> Router Class Initialized
INFO - 2024-02-25 15:17:57 --> Output Class Initialized
INFO - 2024-02-25 15:17:57 --> Security Class Initialized
DEBUG - 2024-02-25 15:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:17:57 --> Input Class Initialized
INFO - 2024-02-25 15:17:57 --> Language Class Initialized
INFO - 2024-02-25 15:17:57 --> Loader Class Initialized
INFO - 2024-02-25 15:17:57 --> Helper loaded: url_helper
INFO - 2024-02-25 15:17:57 --> Helper loaded: file_helper
INFO - 2024-02-25 15:17:57 --> Helper loaded: html_helper
INFO - 2024-02-25 15:17:57 --> Helper loaded: text_helper
INFO - 2024-02-25 15:17:57 --> Helper loaded: form_helper
INFO - 2024-02-25 15:17:57 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:17:57 --> Helper loaded: security_helper
INFO - 2024-02-25 15:17:57 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:17:57 --> Database Driver Class Initialized
INFO - 2024-02-25 15:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:17:57 --> Parser Class Initialized
INFO - 2024-02-25 15:17:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:17:57 --> Pagination Class Initialized
INFO - 2024-02-25 15:17:57 --> Form Validation Class Initialized
INFO - 2024-02-25 15:17:57 --> Controller Class Initialized
INFO - 2024-02-25 15:17:57 --> Model Class Initialized
DEBUG - 2024-02-25 15:17:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:17:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:17:57 --> Model Class Initialized
DEBUG - 2024-02-25 15:17:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:17:57 --> Model Class Initialized
INFO - 2024-02-25 15:17:57 --> Final output sent to browser
DEBUG - 2024-02-25 15:17:57 --> Total execution time: 0.0617
ERROR - 2024-02-25 15:18:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:18:04 --> Config Class Initialized
INFO - 2024-02-25 15:18:04 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:18:04 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:18:04 --> Utf8 Class Initialized
INFO - 2024-02-25 15:18:04 --> URI Class Initialized
INFO - 2024-02-25 15:18:04 --> Router Class Initialized
INFO - 2024-02-25 15:18:04 --> Output Class Initialized
INFO - 2024-02-25 15:18:04 --> Security Class Initialized
DEBUG - 2024-02-25 15:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:18:04 --> Input Class Initialized
INFO - 2024-02-25 15:18:04 --> Language Class Initialized
INFO - 2024-02-25 15:18:04 --> Loader Class Initialized
INFO - 2024-02-25 15:18:04 --> Helper loaded: url_helper
INFO - 2024-02-25 15:18:04 --> Helper loaded: file_helper
INFO - 2024-02-25 15:18:04 --> Helper loaded: html_helper
INFO - 2024-02-25 15:18:04 --> Helper loaded: text_helper
INFO - 2024-02-25 15:18:04 --> Helper loaded: form_helper
INFO - 2024-02-25 15:18:04 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:18:04 --> Helper loaded: security_helper
INFO - 2024-02-25 15:18:04 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:18:04 --> Database Driver Class Initialized
INFO - 2024-02-25 15:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:18:04 --> Parser Class Initialized
INFO - 2024-02-25 15:18:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:18:04 --> Pagination Class Initialized
INFO - 2024-02-25 15:18:04 --> Form Validation Class Initialized
INFO - 2024-02-25 15:18:04 --> Controller Class Initialized
INFO - 2024-02-25 15:18:04 --> Model Class Initialized
DEBUG - 2024-02-25 15:18:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:18:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:18:04 --> Model Class Initialized
DEBUG - 2024-02-25 15:18:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:18:04 --> Model Class Initialized
INFO - 2024-02-25 15:18:06 --> Final output sent to browser
DEBUG - 2024-02-25 15:18:06 --> Total execution time: 1.2424
ERROR - 2024-02-25 15:18:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:18:11 --> Config Class Initialized
INFO - 2024-02-25 15:18:11 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:18:11 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:18:11 --> Utf8 Class Initialized
INFO - 2024-02-25 15:18:11 --> URI Class Initialized
DEBUG - 2024-02-25 15:18:11 --> No URI present. Default controller set.
INFO - 2024-02-25 15:18:11 --> Router Class Initialized
INFO - 2024-02-25 15:18:11 --> Output Class Initialized
INFO - 2024-02-25 15:18:11 --> Security Class Initialized
DEBUG - 2024-02-25 15:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:18:11 --> Input Class Initialized
INFO - 2024-02-25 15:18:11 --> Language Class Initialized
INFO - 2024-02-25 15:18:11 --> Loader Class Initialized
INFO - 2024-02-25 15:18:11 --> Helper loaded: url_helper
INFO - 2024-02-25 15:18:11 --> Helper loaded: file_helper
INFO - 2024-02-25 15:18:11 --> Helper loaded: html_helper
INFO - 2024-02-25 15:18:11 --> Helper loaded: text_helper
INFO - 2024-02-25 15:18:11 --> Helper loaded: form_helper
INFO - 2024-02-25 15:18:11 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:18:11 --> Helper loaded: security_helper
INFO - 2024-02-25 15:18:11 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:18:11 --> Database Driver Class Initialized
INFO - 2024-02-25 15:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:18:11 --> Parser Class Initialized
INFO - 2024-02-25 15:18:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:18:11 --> Pagination Class Initialized
INFO - 2024-02-25 15:18:11 --> Form Validation Class Initialized
INFO - 2024-02-25 15:18:11 --> Controller Class Initialized
INFO - 2024-02-25 15:18:11 --> Model Class Initialized
DEBUG - 2024-02-25 15:18:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:18:11 --> Model Class Initialized
DEBUG - 2024-02-25 15:18:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:18:11 --> Model Class Initialized
INFO - 2024-02-25 15:18:11 --> Model Class Initialized
INFO - 2024-02-25 15:18:11 --> Model Class Initialized
INFO - 2024-02-25 15:18:11 --> Model Class Initialized
DEBUG - 2024-02-25 15:18:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:18:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:18:11 --> Model Class Initialized
INFO - 2024-02-25 15:18:11 --> Model Class Initialized
INFO - 2024-02-25 15:18:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-25 15:18:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:18:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 15:18:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 15:18:11 --> Model Class Initialized
INFO - 2024-02-25 15:18:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-25 15:18:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-25 15:18:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 15:18:11 --> Final output sent to browser
DEBUG - 2024-02-25 15:18:11 --> Total execution time: 0.4374
ERROR - 2024-02-25 15:18:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:18:19 --> Config Class Initialized
INFO - 2024-02-25 15:18:19 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:18:19 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:18:19 --> Utf8 Class Initialized
INFO - 2024-02-25 15:18:19 --> URI Class Initialized
INFO - 2024-02-25 15:18:19 --> Router Class Initialized
INFO - 2024-02-25 15:18:19 --> Output Class Initialized
INFO - 2024-02-25 15:18:19 --> Security Class Initialized
DEBUG - 2024-02-25 15:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:18:19 --> Input Class Initialized
INFO - 2024-02-25 15:18:19 --> Language Class Initialized
INFO - 2024-02-25 15:18:19 --> Loader Class Initialized
INFO - 2024-02-25 15:18:19 --> Helper loaded: url_helper
INFO - 2024-02-25 15:18:19 --> Helper loaded: file_helper
INFO - 2024-02-25 15:18:19 --> Helper loaded: html_helper
INFO - 2024-02-25 15:18:19 --> Helper loaded: text_helper
INFO - 2024-02-25 15:18:19 --> Helper loaded: form_helper
INFO - 2024-02-25 15:18:19 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:18:19 --> Helper loaded: security_helper
INFO - 2024-02-25 15:18:19 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:18:19 --> Database Driver Class Initialized
INFO - 2024-02-25 15:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:18:19 --> Parser Class Initialized
INFO - 2024-02-25 15:18:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:18:19 --> Pagination Class Initialized
INFO - 2024-02-25 15:18:19 --> Form Validation Class Initialized
INFO - 2024-02-25 15:18:19 --> Controller Class Initialized
INFO - 2024-02-25 15:18:19 --> Model Class Initialized
DEBUG - 2024-02-25 15:18:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:18:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:18:19 --> Model Class Initialized
DEBUG - 2024-02-25 15:18:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:18:19 --> Model Class Initialized
INFO - 2024-02-25 15:18:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-25 15:18:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:18:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 15:18:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 15:18:19 --> Model Class Initialized
INFO - 2024-02-25 15:18:19 --> Model Class Initialized
INFO - 2024-02-25 15:18:19 --> Model Class Initialized
INFO - 2024-02-25 15:18:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-25 15:18:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-25 15:18:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 15:18:19 --> Final output sent to browser
DEBUG - 2024-02-25 15:18:19 --> Total execution time: 0.2373
ERROR - 2024-02-25 15:18:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:18:20 --> Config Class Initialized
INFO - 2024-02-25 15:18:20 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:18:20 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:18:20 --> Utf8 Class Initialized
INFO - 2024-02-25 15:18:20 --> URI Class Initialized
INFO - 2024-02-25 15:18:20 --> Router Class Initialized
INFO - 2024-02-25 15:18:20 --> Output Class Initialized
INFO - 2024-02-25 15:18:20 --> Security Class Initialized
DEBUG - 2024-02-25 15:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:18:20 --> Input Class Initialized
INFO - 2024-02-25 15:18:20 --> Language Class Initialized
INFO - 2024-02-25 15:18:20 --> Loader Class Initialized
INFO - 2024-02-25 15:18:20 --> Helper loaded: url_helper
INFO - 2024-02-25 15:18:20 --> Helper loaded: file_helper
INFO - 2024-02-25 15:18:20 --> Helper loaded: html_helper
INFO - 2024-02-25 15:18:20 --> Helper loaded: text_helper
INFO - 2024-02-25 15:18:20 --> Helper loaded: form_helper
INFO - 2024-02-25 15:18:20 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:18:20 --> Helper loaded: security_helper
INFO - 2024-02-25 15:18:20 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:18:20 --> Database Driver Class Initialized
INFO - 2024-02-25 15:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:18:20 --> Parser Class Initialized
INFO - 2024-02-25 15:18:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:18:20 --> Pagination Class Initialized
INFO - 2024-02-25 15:18:20 --> Form Validation Class Initialized
INFO - 2024-02-25 15:18:20 --> Controller Class Initialized
INFO - 2024-02-25 15:18:20 --> Model Class Initialized
DEBUG - 2024-02-25 15:18:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:18:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:18:20 --> Model Class Initialized
DEBUG - 2024-02-25 15:18:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:18:20 --> Model Class Initialized
INFO - 2024-02-25 15:18:20 --> Final output sent to browser
DEBUG - 2024-02-25 15:18:20 --> Total execution time: 0.0614
ERROR - 2024-02-25 15:23:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:23:24 --> Config Class Initialized
INFO - 2024-02-25 15:23:24 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:23:24 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:23:24 --> Utf8 Class Initialized
INFO - 2024-02-25 15:23:24 --> URI Class Initialized
INFO - 2024-02-25 15:23:24 --> Router Class Initialized
INFO - 2024-02-25 15:23:24 --> Output Class Initialized
INFO - 2024-02-25 15:23:24 --> Security Class Initialized
DEBUG - 2024-02-25 15:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:23:24 --> Input Class Initialized
INFO - 2024-02-25 15:23:24 --> Language Class Initialized
INFO - 2024-02-25 15:23:24 --> Loader Class Initialized
INFO - 2024-02-25 15:23:24 --> Helper loaded: url_helper
INFO - 2024-02-25 15:23:24 --> Helper loaded: file_helper
INFO - 2024-02-25 15:23:24 --> Helper loaded: html_helper
INFO - 2024-02-25 15:23:24 --> Helper loaded: text_helper
INFO - 2024-02-25 15:23:24 --> Helper loaded: form_helper
INFO - 2024-02-25 15:23:24 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:23:24 --> Helper loaded: security_helper
INFO - 2024-02-25 15:23:24 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:23:24 --> Database Driver Class Initialized
INFO - 2024-02-25 15:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:23:24 --> Parser Class Initialized
INFO - 2024-02-25 15:23:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:23:24 --> Pagination Class Initialized
INFO - 2024-02-25 15:23:24 --> Form Validation Class Initialized
INFO - 2024-02-25 15:23:24 --> Controller Class Initialized
INFO - 2024-02-25 15:23:24 --> Model Class Initialized
DEBUG - 2024-02-25 15:23:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:23:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:23:24 --> Model Class Initialized
DEBUG - 2024-02-25 15:23:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:23:24 --> Model Class Initialized
INFO - 2024-02-25 15:23:24 --> Final output sent to browser
DEBUG - 2024-02-25 15:23:24 --> Total execution time: 0.0620
ERROR - 2024-02-25 15:23:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:23:26 --> Config Class Initialized
INFO - 2024-02-25 15:23:26 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:23:26 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:23:26 --> Utf8 Class Initialized
INFO - 2024-02-25 15:23:26 --> URI Class Initialized
INFO - 2024-02-25 15:23:26 --> Router Class Initialized
INFO - 2024-02-25 15:23:26 --> Output Class Initialized
INFO - 2024-02-25 15:23:26 --> Security Class Initialized
DEBUG - 2024-02-25 15:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:23:26 --> Input Class Initialized
INFO - 2024-02-25 15:23:26 --> Language Class Initialized
INFO - 2024-02-25 15:23:26 --> Loader Class Initialized
INFO - 2024-02-25 15:23:26 --> Helper loaded: url_helper
INFO - 2024-02-25 15:23:26 --> Helper loaded: file_helper
INFO - 2024-02-25 15:23:26 --> Helper loaded: html_helper
INFO - 2024-02-25 15:23:26 --> Helper loaded: text_helper
INFO - 2024-02-25 15:23:26 --> Helper loaded: form_helper
INFO - 2024-02-25 15:23:26 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:23:26 --> Helper loaded: security_helper
INFO - 2024-02-25 15:23:26 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:23:26 --> Database Driver Class Initialized
INFO - 2024-02-25 15:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:23:26 --> Parser Class Initialized
INFO - 2024-02-25 15:23:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:23:26 --> Pagination Class Initialized
INFO - 2024-02-25 15:23:26 --> Form Validation Class Initialized
INFO - 2024-02-25 15:23:26 --> Controller Class Initialized
INFO - 2024-02-25 15:23:26 --> Model Class Initialized
DEBUG - 2024-02-25 15:23:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:23:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:23:26 --> Model Class Initialized
DEBUG - 2024-02-25 15:23:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:23:26 --> Model Class Initialized
INFO - 2024-02-25 15:23:26 --> Final output sent to browser
DEBUG - 2024-02-25 15:23:26 --> Total execution time: 0.0665
ERROR - 2024-02-25 15:29:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:29:54 --> Config Class Initialized
INFO - 2024-02-25 15:29:54 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:29:54 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:29:54 --> Utf8 Class Initialized
INFO - 2024-02-25 15:29:54 --> URI Class Initialized
INFO - 2024-02-25 15:29:54 --> Router Class Initialized
INFO - 2024-02-25 15:29:54 --> Output Class Initialized
INFO - 2024-02-25 15:29:54 --> Security Class Initialized
DEBUG - 2024-02-25 15:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:29:54 --> Input Class Initialized
INFO - 2024-02-25 15:29:54 --> Language Class Initialized
INFO - 2024-02-25 15:29:54 --> Loader Class Initialized
INFO - 2024-02-25 15:29:54 --> Helper loaded: url_helper
INFO - 2024-02-25 15:29:54 --> Helper loaded: file_helper
INFO - 2024-02-25 15:29:54 --> Helper loaded: html_helper
INFO - 2024-02-25 15:29:54 --> Helper loaded: text_helper
INFO - 2024-02-25 15:29:54 --> Helper loaded: form_helper
INFO - 2024-02-25 15:29:54 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:29:54 --> Helper loaded: security_helper
INFO - 2024-02-25 15:29:54 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:29:54 --> Database Driver Class Initialized
INFO - 2024-02-25 15:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:29:54 --> Parser Class Initialized
INFO - 2024-02-25 15:29:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:29:54 --> Pagination Class Initialized
INFO - 2024-02-25 15:29:54 --> Form Validation Class Initialized
INFO - 2024-02-25 15:29:54 --> Controller Class Initialized
INFO - 2024-02-25 15:29:54 --> Model Class Initialized
DEBUG - 2024-02-25 15:29:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:29:54 --> Final output sent to browser
DEBUG - 2024-02-25 15:29:54 --> Total execution time: 0.0167
ERROR - 2024-02-25 15:29:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:29:54 --> Config Class Initialized
INFO - 2024-02-25 15:29:54 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:29:54 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:29:54 --> Utf8 Class Initialized
INFO - 2024-02-25 15:29:54 --> URI Class Initialized
INFO - 2024-02-25 15:29:54 --> Router Class Initialized
INFO - 2024-02-25 15:29:54 --> Output Class Initialized
INFO - 2024-02-25 15:29:54 --> Security Class Initialized
DEBUG - 2024-02-25 15:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:29:54 --> Input Class Initialized
INFO - 2024-02-25 15:29:54 --> Language Class Initialized
INFO - 2024-02-25 15:29:54 --> Loader Class Initialized
INFO - 2024-02-25 15:29:54 --> Helper loaded: url_helper
INFO - 2024-02-25 15:29:54 --> Helper loaded: file_helper
INFO - 2024-02-25 15:29:54 --> Helper loaded: html_helper
INFO - 2024-02-25 15:29:54 --> Helper loaded: text_helper
INFO - 2024-02-25 15:29:54 --> Helper loaded: form_helper
INFO - 2024-02-25 15:29:54 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:29:54 --> Helper loaded: security_helper
INFO - 2024-02-25 15:29:54 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:29:54 --> Database Driver Class Initialized
INFO - 2024-02-25 15:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:29:54 --> Parser Class Initialized
INFO - 2024-02-25 15:29:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:29:54 --> Pagination Class Initialized
INFO - 2024-02-25 15:29:54 --> Form Validation Class Initialized
INFO - 2024-02-25 15:29:54 --> Controller Class Initialized
INFO - 2024-02-25 15:29:54 --> Model Class Initialized
DEBUG - 2024-02-25 15:29:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:29:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-25 15:29:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:29:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 15:29:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 15:29:54 --> Model Class Initialized
INFO - 2024-02-25 15:29:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 15:29:54 --> Final output sent to browser
DEBUG - 2024-02-25 15:29:54 --> Total execution time: 0.0326
ERROR - 2024-02-25 15:33:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:33:40 --> Config Class Initialized
INFO - 2024-02-25 15:33:40 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:33:40 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:33:40 --> Utf8 Class Initialized
INFO - 2024-02-25 15:33:40 --> URI Class Initialized
INFO - 2024-02-25 15:33:40 --> Router Class Initialized
INFO - 2024-02-25 15:33:40 --> Output Class Initialized
INFO - 2024-02-25 15:33:40 --> Security Class Initialized
DEBUG - 2024-02-25 15:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:33:40 --> Input Class Initialized
INFO - 2024-02-25 15:33:40 --> Language Class Initialized
INFO - 2024-02-25 15:33:40 --> Loader Class Initialized
INFO - 2024-02-25 15:33:40 --> Helper loaded: url_helper
INFO - 2024-02-25 15:33:40 --> Helper loaded: file_helper
INFO - 2024-02-25 15:33:40 --> Helper loaded: html_helper
INFO - 2024-02-25 15:33:40 --> Helper loaded: text_helper
INFO - 2024-02-25 15:33:40 --> Helper loaded: form_helper
INFO - 2024-02-25 15:33:40 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:33:40 --> Helper loaded: security_helper
INFO - 2024-02-25 15:33:40 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:33:40 --> Database Driver Class Initialized
INFO - 2024-02-25 15:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:33:40 --> Parser Class Initialized
INFO - 2024-02-25 15:33:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:33:40 --> Pagination Class Initialized
INFO - 2024-02-25 15:33:40 --> Form Validation Class Initialized
INFO - 2024-02-25 15:33:40 --> Controller Class Initialized
INFO - 2024-02-25 15:33:40 --> Model Class Initialized
DEBUG - 2024-02-25 15:33:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:33:40 --> Model Class Initialized
INFO - 2024-02-25 15:33:40 --> Final output sent to browser
DEBUG - 2024-02-25 15:33:40 --> Total execution time: 0.0196
ERROR - 2024-02-25 15:33:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:33:41 --> Config Class Initialized
INFO - 2024-02-25 15:33:41 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:33:41 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:33:41 --> Utf8 Class Initialized
INFO - 2024-02-25 15:33:41 --> URI Class Initialized
DEBUG - 2024-02-25 15:33:41 --> No URI present. Default controller set.
INFO - 2024-02-25 15:33:41 --> Router Class Initialized
INFO - 2024-02-25 15:33:41 --> Output Class Initialized
INFO - 2024-02-25 15:33:41 --> Security Class Initialized
DEBUG - 2024-02-25 15:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:33:41 --> Input Class Initialized
INFO - 2024-02-25 15:33:41 --> Language Class Initialized
INFO - 2024-02-25 15:33:41 --> Loader Class Initialized
INFO - 2024-02-25 15:33:41 --> Helper loaded: url_helper
INFO - 2024-02-25 15:33:41 --> Helper loaded: file_helper
INFO - 2024-02-25 15:33:41 --> Helper loaded: html_helper
INFO - 2024-02-25 15:33:41 --> Helper loaded: text_helper
INFO - 2024-02-25 15:33:41 --> Helper loaded: form_helper
INFO - 2024-02-25 15:33:41 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:33:41 --> Helper loaded: security_helper
INFO - 2024-02-25 15:33:41 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:33:41 --> Database Driver Class Initialized
INFO - 2024-02-25 15:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:33:41 --> Parser Class Initialized
INFO - 2024-02-25 15:33:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:33:41 --> Pagination Class Initialized
INFO - 2024-02-25 15:33:41 --> Form Validation Class Initialized
INFO - 2024-02-25 15:33:41 --> Controller Class Initialized
INFO - 2024-02-25 15:33:41 --> Model Class Initialized
DEBUG - 2024-02-25 15:33:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:33:41 --> Model Class Initialized
DEBUG - 2024-02-25 15:33:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:33:41 --> Model Class Initialized
INFO - 2024-02-25 15:33:41 --> Model Class Initialized
INFO - 2024-02-25 15:33:41 --> Model Class Initialized
INFO - 2024-02-25 15:33:41 --> Model Class Initialized
DEBUG - 2024-02-25 15:33:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:33:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:33:41 --> Model Class Initialized
INFO - 2024-02-25 15:33:41 --> Model Class Initialized
INFO - 2024-02-25 15:33:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-25 15:33:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:33:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 15:33:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 15:33:41 --> Model Class Initialized
INFO - 2024-02-25 15:33:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-25 15:33:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-25 15:33:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 15:33:41 --> Final output sent to browser
DEBUG - 2024-02-25 15:33:41 --> Total execution time: 0.4148
ERROR - 2024-02-25 15:33:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:33:42 --> Config Class Initialized
INFO - 2024-02-25 15:33:42 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:33:42 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:33:42 --> Utf8 Class Initialized
INFO - 2024-02-25 15:33:42 --> URI Class Initialized
INFO - 2024-02-25 15:33:42 --> Router Class Initialized
INFO - 2024-02-25 15:33:42 --> Output Class Initialized
INFO - 2024-02-25 15:33:42 --> Security Class Initialized
DEBUG - 2024-02-25 15:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:33:42 --> Input Class Initialized
INFO - 2024-02-25 15:33:42 --> Language Class Initialized
INFO - 2024-02-25 15:33:42 --> Loader Class Initialized
INFO - 2024-02-25 15:33:42 --> Helper loaded: url_helper
INFO - 2024-02-25 15:33:42 --> Helper loaded: file_helper
INFO - 2024-02-25 15:33:42 --> Helper loaded: html_helper
INFO - 2024-02-25 15:33:42 --> Helper loaded: text_helper
INFO - 2024-02-25 15:33:42 --> Helper loaded: form_helper
INFO - 2024-02-25 15:33:42 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:33:42 --> Helper loaded: security_helper
INFO - 2024-02-25 15:33:42 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:33:42 --> Database Driver Class Initialized
INFO - 2024-02-25 15:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:33:42 --> Parser Class Initialized
INFO - 2024-02-25 15:33:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:33:42 --> Pagination Class Initialized
INFO - 2024-02-25 15:33:42 --> Form Validation Class Initialized
INFO - 2024-02-25 15:33:42 --> Controller Class Initialized
DEBUG - 2024-02-25 15:33:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:33:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:33:42 --> Model Class Initialized
INFO - 2024-02-25 15:33:42 --> Final output sent to browser
DEBUG - 2024-02-25 15:33:42 --> Total execution time: 0.0128
ERROR - 2024-02-25 15:33:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:33:56 --> Config Class Initialized
INFO - 2024-02-25 15:33:56 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:33:56 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:33:56 --> Utf8 Class Initialized
INFO - 2024-02-25 15:33:56 --> URI Class Initialized
INFO - 2024-02-25 15:33:56 --> Router Class Initialized
INFO - 2024-02-25 15:33:56 --> Output Class Initialized
INFO - 2024-02-25 15:33:56 --> Security Class Initialized
DEBUG - 2024-02-25 15:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:33:56 --> Input Class Initialized
INFO - 2024-02-25 15:33:56 --> Language Class Initialized
INFO - 2024-02-25 15:33:56 --> Loader Class Initialized
INFO - 2024-02-25 15:33:56 --> Helper loaded: url_helper
INFO - 2024-02-25 15:33:56 --> Helper loaded: file_helper
INFO - 2024-02-25 15:33:56 --> Helper loaded: html_helper
INFO - 2024-02-25 15:33:56 --> Helper loaded: text_helper
INFO - 2024-02-25 15:33:56 --> Helper loaded: form_helper
INFO - 2024-02-25 15:33:56 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:33:56 --> Helper loaded: security_helper
INFO - 2024-02-25 15:33:56 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:33:56 --> Database Driver Class Initialized
INFO - 2024-02-25 15:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:33:56 --> Parser Class Initialized
INFO - 2024-02-25 15:33:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:33:56 --> Pagination Class Initialized
INFO - 2024-02-25 15:33:56 --> Form Validation Class Initialized
INFO - 2024-02-25 15:33:56 --> Controller Class Initialized
DEBUG - 2024-02-25 15:33:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:33:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:33:56 --> Model Class Initialized
DEBUG - 2024-02-25 15:33:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:33:56 --> Model Class Initialized
DEBUG - 2024-02-25 15:33:56 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:33:56 --> Model Class Initialized
INFO - 2024-02-25 15:33:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-25 15:33:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:33:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 15:33:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 15:33:56 --> Model Class Initialized
INFO - 2024-02-25 15:33:56 --> Model Class Initialized
INFO - 2024-02-25 15:33:56 --> Model Class Initialized
INFO - 2024-02-25 15:33:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-25 15:33:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-25 15:33:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 15:33:57 --> Final output sent to browser
DEBUG - 2024-02-25 15:33:57 --> Total execution time: 0.2227
ERROR - 2024-02-25 15:33:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:33:57 --> Config Class Initialized
INFO - 2024-02-25 15:33:57 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:33:57 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:33:57 --> Utf8 Class Initialized
INFO - 2024-02-25 15:33:57 --> URI Class Initialized
INFO - 2024-02-25 15:33:57 --> Router Class Initialized
INFO - 2024-02-25 15:33:57 --> Output Class Initialized
INFO - 2024-02-25 15:33:57 --> Security Class Initialized
DEBUG - 2024-02-25 15:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:33:57 --> Input Class Initialized
INFO - 2024-02-25 15:33:57 --> Language Class Initialized
INFO - 2024-02-25 15:33:57 --> Loader Class Initialized
INFO - 2024-02-25 15:33:57 --> Helper loaded: url_helper
INFO - 2024-02-25 15:33:57 --> Helper loaded: file_helper
INFO - 2024-02-25 15:33:57 --> Helper loaded: html_helper
INFO - 2024-02-25 15:33:57 --> Helper loaded: text_helper
INFO - 2024-02-25 15:33:57 --> Helper loaded: form_helper
INFO - 2024-02-25 15:33:57 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:33:57 --> Helper loaded: security_helper
INFO - 2024-02-25 15:33:57 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:33:57 --> Database Driver Class Initialized
INFO - 2024-02-25 15:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:33:57 --> Parser Class Initialized
INFO - 2024-02-25 15:33:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:33:57 --> Pagination Class Initialized
INFO - 2024-02-25 15:33:57 --> Form Validation Class Initialized
INFO - 2024-02-25 15:33:57 --> Controller Class Initialized
DEBUG - 2024-02-25 15:33:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:33:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:33:57 --> Model Class Initialized
DEBUG - 2024-02-25 15:33:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:33:57 --> Model Class Initialized
INFO - 2024-02-25 15:33:57 --> Final output sent to browser
DEBUG - 2024-02-25 15:33:57 --> Total execution time: 0.0323
ERROR - 2024-02-25 15:34:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:34:01 --> Config Class Initialized
INFO - 2024-02-25 15:34:01 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:34:01 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:34:01 --> Utf8 Class Initialized
INFO - 2024-02-25 15:34:01 --> URI Class Initialized
INFO - 2024-02-25 15:34:01 --> Router Class Initialized
INFO - 2024-02-25 15:34:01 --> Output Class Initialized
INFO - 2024-02-25 15:34:01 --> Security Class Initialized
DEBUG - 2024-02-25 15:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:34:01 --> Input Class Initialized
INFO - 2024-02-25 15:34:01 --> Language Class Initialized
INFO - 2024-02-25 15:34:01 --> Loader Class Initialized
INFO - 2024-02-25 15:34:01 --> Helper loaded: url_helper
INFO - 2024-02-25 15:34:01 --> Helper loaded: file_helper
INFO - 2024-02-25 15:34:01 --> Helper loaded: html_helper
INFO - 2024-02-25 15:34:01 --> Helper loaded: text_helper
INFO - 2024-02-25 15:34:01 --> Helper loaded: form_helper
INFO - 2024-02-25 15:34:01 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:34:01 --> Helper loaded: security_helper
INFO - 2024-02-25 15:34:01 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:34:01 --> Database Driver Class Initialized
INFO - 2024-02-25 15:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:34:01 --> Parser Class Initialized
INFO - 2024-02-25 15:34:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:34:01 --> Pagination Class Initialized
INFO - 2024-02-25 15:34:01 --> Form Validation Class Initialized
INFO - 2024-02-25 15:34:01 --> Controller Class Initialized
DEBUG - 2024-02-25 15:34:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:34:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:34:01 --> Model Class Initialized
DEBUG - 2024-02-25 15:34:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:34:01 --> Model Class Initialized
INFO - 2024-02-25 15:34:01 --> Final output sent to browser
DEBUG - 2024-02-25 15:34:01 --> Total execution time: 0.2620
ERROR - 2024-02-25 15:35:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:35:33 --> Config Class Initialized
INFO - 2024-02-25 15:35:33 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:35:33 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:35:33 --> Utf8 Class Initialized
INFO - 2024-02-25 15:35:33 --> URI Class Initialized
INFO - 2024-02-25 15:35:33 --> Router Class Initialized
INFO - 2024-02-25 15:35:33 --> Output Class Initialized
INFO - 2024-02-25 15:35:33 --> Security Class Initialized
DEBUG - 2024-02-25 15:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:35:33 --> Input Class Initialized
INFO - 2024-02-25 15:35:33 --> Language Class Initialized
INFO - 2024-02-25 15:35:33 --> Loader Class Initialized
INFO - 2024-02-25 15:35:33 --> Helper loaded: url_helper
INFO - 2024-02-25 15:35:33 --> Helper loaded: file_helper
INFO - 2024-02-25 15:35:33 --> Helper loaded: html_helper
INFO - 2024-02-25 15:35:33 --> Helper loaded: text_helper
INFO - 2024-02-25 15:35:33 --> Helper loaded: form_helper
INFO - 2024-02-25 15:35:33 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:35:33 --> Helper loaded: security_helper
INFO - 2024-02-25 15:35:33 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:35:33 --> Database Driver Class Initialized
INFO - 2024-02-25 15:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:35:33 --> Parser Class Initialized
INFO - 2024-02-25 15:35:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:35:33 --> Pagination Class Initialized
INFO - 2024-02-25 15:35:33 --> Form Validation Class Initialized
INFO - 2024-02-25 15:35:33 --> Controller Class Initialized
DEBUG - 2024-02-25 15:35:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:35:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:35:33 --> Model Class Initialized
DEBUG - 2024-02-25 15:35:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:35:33 --> Model Class Initialized
DEBUG - 2024-02-25 15:35:33 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:35:33 --> Model Class Initialized
INFO - 2024-02-25 15:35:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-25 15:35:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:35:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 15:35:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 15:35:33 --> Model Class Initialized
INFO - 2024-02-25 15:35:34 --> Model Class Initialized
INFO - 2024-02-25 15:35:34 --> Model Class Initialized
INFO - 2024-02-25 15:35:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-25 15:35:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-25 15:35:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 15:35:34 --> Final output sent to browser
DEBUG - 2024-02-25 15:35:34 --> Total execution time: 0.2349
ERROR - 2024-02-25 15:35:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:35:34 --> Config Class Initialized
INFO - 2024-02-25 15:35:34 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:35:34 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:35:34 --> Utf8 Class Initialized
INFO - 2024-02-25 15:35:34 --> URI Class Initialized
INFO - 2024-02-25 15:35:34 --> Router Class Initialized
INFO - 2024-02-25 15:35:34 --> Output Class Initialized
INFO - 2024-02-25 15:35:34 --> Security Class Initialized
DEBUG - 2024-02-25 15:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:35:34 --> Input Class Initialized
INFO - 2024-02-25 15:35:34 --> Language Class Initialized
INFO - 2024-02-25 15:35:34 --> Loader Class Initialized
INFO - 2024-02-25 15:35:34 --> Helper loaded: url_helper
INFO - 2024-02-25 15:35:34 --> Helper loaded: file_helper
INFO - 2024-02-25 15:35:34 --> Helper loaded: html_helper
INFO - 2024-02-25 15:35:34 --> Helper loaded: text_helper
INFO - 2024-02-25 15:35:34 --> Helper loaded: form_helper
INFO - 2024-02-25 15:35:34 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:35:34 --> Helper loaded: security_helper
INFO - 2024-02-25 15:35:34 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:35:34 --> Database Driver Class Initialized
INFO - 2024-02-25 15:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:35:34 --> Parser Class Initialized
INFO - 2024-02-25 15:35:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:35:34 --> Pagination Class Initialized
INFO - 2024-02-25 15:35:34 --> Form Validation Class Initialized
INFO - 2024-02-25 15:35:34 --> Controller Class Initialized
DEBUG - 2024-02-25 15:35:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:35:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:35:34 --> Model Class Initialized
DEBUG - 2024-02-25 15:35:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:35:34 --> Model Class Initialized
INFO - 2024-02-25 15:35:34 --> Final output sent to browser
DEBUG - 2024-02-25 15:35:34 --> Total execution time: 0.0326
ERROR - 2024-02-25 15:35:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:35:42 --> Config Class Initialized
INFO - 2024-02-25 15:35:42 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:35:42 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:35:42 --> Utf8 Class Initialized
INFO - 2024-02-25 15:35:42 --> URI Class Initialized
INFO - 2024-02-25 15:35:42 --> Router Class Initialized
INFO - 2024-02-25 15:35:42 --> Output Class Initialized
INFO - 2024-02-25 15:35:42 --> Security Class Initialized
DEBUG - 2024-02-25 15:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:35:42 --> Input Class Initialized
INFO - 2024-02-25 15:35:42 --> Language Class Initialized
INFO - 2024-02-25 15:35:42 --> Loader Class Initialized
INFO - 2024-02-25 15:35:42 --> Helper loaded: url_helper
INFO - 2024-02-25 15:35:42 --> Helper loaded: file_helper
INFO - 2024-02-25 15:35:42 --> Helper loaded: html_helper
INFO - 2024-02-25 15:35:42 --> Helper loaded: text_helper
INFO - 2024-02-25 15:35:42 --> Helper loaded: form_helper
INFO - 2024-02-25 15:35:42 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:35:42 --> Helper loaded: security_helper
INFO - 2024-02-25 15:35:42 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:35:42 --> Database Driver Class Initialized
INFO - 2024-02-25 15:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:35:42 --> Parser Class Initialized
INFO - 2024-02-25 15:35:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:35:42 --> Pagination Class Initialized
INFO - 2024-02-25 15:35:42 --> Form Validation Class Initialized
INFO - 2024-02-25 15:35:42 --> Controller Class Initialized
DEBUG - 2024-02-25 15:35:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:35:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:35:42 --> Model Class Initialized
DEBUG - 2024-02-25 15:35:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:35:42 --> Model Class Initialized
DEBUG - 2024-02-25 15:35:42 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:35:42 --> Model Class Initialized
INFO - 2024-02-25 15:35:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-25 15:35:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:35:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 15:35:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 15:35:42 --> Model Class Initialized
INFO - 2024-02-25 15:35:42 --> Model Class Initialized
INFO - 2024-02-25 15:35:42 --> Model Class Initialized
INFO - 2024-02-25 15:35:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-25 15:35:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-25 15:35:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 15:35:42 --> Final output sent to browser
DEBUG - 2024-02-25 15:35:42 --> Total execution time: 0.2520
ERROR - 2024-02-25 15:35:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:35:43 --> Config Class Initialized
INFO - 2024-02-25 15:35:43 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:35:43 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:35:43 --> Utf8 Class Initialized
INFO - 2024-02-25 15:35:43 --> URI Class Initialized
INFO - 2024-02-25 15:35:43 --> Router Class Initialized
INFO - 2024-02-25 15:35:43 --> Output Class Initialized
INFO - 2024-02-25 15:35:43 --> Security Class Initialized
DEBUG - 2024-02-25 15:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:35:43 --> Input Class Initialized
INFO - 2024-02-25 15:35:43 --> Language Class Initialized
INFO - 2024-02-25 15:35:43 --> Loader Class Initialized
INFO - 2024-02-25 15:35:43 --> Helper loaded: url_helper
INFO - 2024-02-25 15:35:43 --> Helper loaded: file_helper
INFO - 2024-02-25 15:35:43 --> Helper loaded: html_helper
INFO - 2024-02-25 15:35:43 --> Helper loaded: text_helper
INFO - 2024-02-25 15:35:43 --> Helper loaded: form_helper
INFO - 2024-02-25 15:35:43 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:35:43 --> Helper loaded: security_helper
INFO - 2024-02-25 15:35:43 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:35:43 --> Database Driver Class Initialized
INFO - 2024-02-25 15:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:35:43 --> Parser Class Initialized
INFO - 2024-02-25 15:35:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:35:43 --> Pagination Class Initialized
INFO - 2024-02-25 15:35:43 --> Form Validation Class Initialized
INFO - 2024-02-25 15:35:43 --> Controller Class Initialized
DEBUG - 2024-02-25 15:35:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:35:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:35:43 --> Model Class Initialized
DEBUG - 2024-02-25 15:35:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:35:43 --> Model Class Initialized
INFO - 2024-02-25 15:35:43 --> Final output sent to browser
DEBUG - 2024-02-25 15:35:43 --> Total execution time: 0.0314
ERROR - 2024-02-25 15:39:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:39:39 --> Config Class Initialized
INFO - 2024-02-25 15:39:39 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:39:39 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:39:39 --> Utf8 Class Initialized
INFO - 2024-02-25 15:39:39 --> URI Class Initialized
DEBUG - 2024-02-25 15:39:39 --> No URI present. Default controller set.
INFO - 2024-02-25 15:39:39 --> Router Class Initialized
INFO - 2024-02-25 15:39:39 --> Output Class Initialized
INFO - 2024-02-25 15:39:39 --> Security Class Initialized
DEBUG - 2024-02-25 15:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:39:39 --> Input Class Initialized
INFO - 2024-02-25 15:39:39 --> Language Class Initialized
INFO - 2024-02-25 15:39:39 --> Loader Class Initialized
INFO - 2024-02-25 15:39:39 --> Helper loaded: url_helper
INFO - 2024-02-25 15:39:39 --> Helper loaded: file_helper
INFO - 2024-02-25 15:39:39 --> Helper loaded: html_helper
INFO - 2024-02-25 15:39:39 --> Helper loaded: text_helper
INFO - 2024-02-25 15:39:39 --> Helper loaded: form_helper
INFO - 2024-02-25 15:39:39 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:39:39 --> Helper loaded: security_helper
INFO - 2024-02-25 15:39:39 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:39:39 --> Database Driver Class Initialized
INFO - 2024-02-25 15:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:39:39 --> Parser Class Initialized
INFO - 2024-02-25 15:39:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:39:39 --> Pagination Class Initialized
INFO - 2024-02-25 15:39:39 --> Form Validation Class Initialized
INFO - 2024-02-25 15:39:39 --> Controller Class Initialized
INFO - 2024-02-25 15:39:39 --> Model Class Initialized
DEBUG - 2024-02-25 15:39:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:39:39 --> Model Class Initialized
DEBUG - 2024-02-25 15:39:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:39:39 --> Model Class Initialized
INFO - 2024-02-25 15:39:39 --> Model Class Initialized
INFO - 2024-02-25 15:39:39 --> Model Class Initialized
INFO - 2024-02-25 15:39:39 --> Model Class Initialized
DEBUG - 2024-02-25 15:39:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:39:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:39:39 --> Model Class Initialized
INFO - 2024-02-25 15:39:39 --> Model Class Initialized
INFO - 2024-02-25 15:39:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-25 15:39:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:39:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 15:39:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 15:39:40 --> Model Class Initialized
INFO - 2024-02-25 15:39:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-25 15:39:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-25 15:39:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 15:39:40 --> Final output sent to browser
DEBUG - 2024-02-25 15:39:40 --> Total execution time: 0.4268
ERROR - 2024-02-25 15:39:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:39:50 --> Config Class Initialized
INFO - 2024-02-25 15:39:50 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:39:50 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:39:50 --> Utf8 Class Initialized
INFO - 2024-02-25 15:39:50 --> URI Class Initialized
INFO - 2024-02-25 15:39:50 --> Router Class Initialized
INFO - 2024-02-25 15:39:50 --> Output Class Initialized
INFO - 2024-02-25 15:39:50 --> Security Class Initialized
DEBUG - 2024-02-25 15:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:39:50 --> Input Class Initialized
INFO - 2024-02-25 15:39:50 --> Language Class Initialized
INFO - 2024-02-25 15:39:50 --> Loader Class Initialized
INFO - 2024-02-25 15:39:50 --> Helper loaded: url_helper
INFO - 2024-02-25 15:39:50 --> Helper loaded: file_helper
INFO - 2024-02-25 15:39:50 --> Helper loaded: html_helper
INFO - 2024-02-25 15:39:50 --> Helper loaded: text_helper
INFO - 2024-02-25 15:39:50 --> Helper loaded: form_helper
INFO - 2024-02-25 15:39:50 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:39:50 --> Helper loaded: security_helper
INFO - 2024-02-25 15:39:50 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:39:50 --> Database Driver Class Initialized
INFO - 2024-02-25 15:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:39:50 --> Parser Class Initialized
INFO - 2024-02-25 15:39:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:39:50 --> Pagination Class Initialized
INFO - 2024-02-25 15:39:50 --> Form Validation Class Initialized
INFO - 2024-02-25 15:39:50 --> Controller Class Initialized
DEBUG - 2024-02-25 15:39:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:39:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:39:50 --> Model Class Initialized
DEBUG - 2024-02-25 15:39:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:39:50 --> Model Class Initialized
DEBUG - 2024-02-25 15:39:50 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:39:50 --> Model Class Initialized
INFO - 2024-02-25 15:39:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-25 15:39:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:39:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 15:39:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 15:39:50 --> Model Class Initialized
INFO - 2024-02-25 15:39:50 --> Model Class Initialized
INFO - 2024-02-25 15:39:50 --> Model Class Initialized
INFO - 2024-02-25 15:39:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-25 15:39:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-25 15:39:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 15:39:51 --> Final output sent to browser
DEBUG - 2024-02-25 15:39:51 --> Total execution time: 0.2321
ERROR - 2024-02-25 15:39:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:39:51 --> Config Class Initialized
INFO - 2024-02-25 15:39:51 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:39:51 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:39:51 --> Utf8 Class Initialized
INFO - 2024-02-25 15:39:51 --> URI Class Initialized
INFO - 2024-02-25 15:39:51 --> Router Class Initialized
INFO - 2024-02-25 15:39:51 --> Output Class Initialized
INFO - 2024-02-25 15:39:51 --> Security Class Initialized
DEBUG - 2024-02-25 15:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:39:51 --> Input Class Initialized
INFO - 2024-02-25 15:39:51 --> Language Class Initialized
INFO - 2024-02-25 15:39:51 --> Loader Class Initialized
INFO - 2024-02-25 15:39:51 --> Helper loaded: url_helper
INFO - 2024-02-25 15:39:51 --> Helper loaded: file_helper
INFO - 2024-02-25 15:39:51 --> Helper loaded: html_helper
INFO - 2024-02-25 15:39:51 --> Helper loaded: text_helper
INFO - 2024-02-25 15:39:51 --> Helper loaded: form_helper
INFO - 2024-02-25 15:39:51 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:39:51 --> Helper loaded: security_helper
INFO - 2024-02-25 15:39:51 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:39:51 --> Database Driver Class Initialized
INFO - 2024-02-25 15:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:39:51 --> Parser Class Initialized
INFO - 2024-02-25 15:39:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:39:51 --> Pagination Class Initialized
INFO - 2024-02-25 15:39:51 --> Form Validation Class Initialized
INFO - 2024-02-25 15:39:51 --> Controller Class Initialized
DEBUG - 2024-02-25 15:39:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:39:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:39:51 --> Model Class Initialized
DEBUG - 2024-02-25 15:39:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:39:51 --> Model Class Initialized
INFO - 2024-02-25 15:39:51 --> Final output sent to browser
DEBUG - 2024-02-25 15:39:51 --> Total execution time: 0.0335
ERROR - 2024-02-25 15:39:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:39:54 --> Config Class Initialized
INFO - 2024-02-25 15:39:54 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:39:54 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:39:54 --> Utf8 Class Initialized
INFO - 2024-02-25 15:39:54 --> URI Class Initialized
INFO - 2024-02-25 15:39:54 --> Router Class Initialized
INFO - 2024-02-25 15:39:54 --> Output Class Initialized
INFO - 2024-02-25 15:39:54 --> Security Class Initialized
DEBUG - 2024-02-25 15:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:39:54 --> Input Class Initialized
INFO - 2024-02-25 15:39:54 --> Language Class Initialized
INFO - 2024-02-25 15:39:54 --> Loader Class Initialized
INFO - 2024-02-25 15:39:54 --> Helper loaded: url_helper
INFO - 2024-02-25 15:39:54 --> Helper loaded: file_helper
INFO - 2024-02-25 15:39:54 --> Helper loaded: html_helper
INFO - 2024-02-25 15:39:54 --> Helper loaded: text_helper
INFO - 2024-02-25 15:39:54 --> Helper loaded: form_helper
INFO - 2024-02-25 15:39:54 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:39:54 --> Helper loaded: security_helper
INFO - 2024-02-25 15:39:54 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:39:54 --> Database Driver Class Initialized
INFO - 2024-02-25 15:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:39:54 --> Parser Class Initialized
INFO - 2024-02-25 15:39:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:39:54 --> Pagination Class Initialized
INFO - 2024-02-25 15:39:54 --> Form Validation Class Initialized
INFO - 2024-02-25 15:39:54 --> Controller Class Initialized
DEBUG - 2024-02-25 15:39:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:39:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:39:54 --> Model Class Initialized
DEBUG - 2024-02-25 15:39:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:39:54 --> Model Class Initialized
INFO - 2024-02-25 15:39:55 --> Final output sent to browser
DEBUG - 2024-02-25 15:39:55 --> Total execution time: 0.2739
ERROR - 2024-02-25 15:41:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:41:54 --> Config Class Initialized
INFO - 2024-02-25 15:41:54 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:41:54 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:41:54 --> Utf8 Class Initialized
INFO - 2024-02-25 15:41:54 --> URI Class Initialized
DEBUG - 2024-02-25 15:41:54 --> No URI present. Default controller set.
INFO - 2024-02-25 15:41:54 --> Router Class Initialized
INFO - 2024-02-25 15:41:54 --> Output Class Initialized
INFO - 2024-02-25 15:41:54 --> Security Class Initialized
DEBUG - 2024-02-25 15:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:41:54 --> Input Class Initialized
INFO - 2024-02-25 15:41:54 --> Language Class Initialized
INFO - 2024-02-25 15:41:54 --> Loader Class Initialized
INFO - 2024-02-25 15:41:54 --> Helper loaded: url_helper
INFO - 2024-02-25 15:41:54 --> Helper loaded: file_helper
INFO - 2024-02-25 15:41:54 --> Helper loaded: html_helper
INFO - 2024-02-25 15:41:54 --> Helper loaded: text_helper
INFO - 2024-02-25 15:41:54 --> Helper loaded: form_helper
INFO - 2024-02-25 15:41:54 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:41:54 --> Helper loaded: security_helper
INFO - 2024-02-25 15:41:54 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:41:54 --> Database Driver Class Initialized
INFO - 2024-02-25 15:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:41:54 --> Parser Class Initialized
INFO - 2024-02-25 15:41:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:41:54 --> Pagination Class Initialized
INFO - 2024-02-25 15:41:54 --> Form Validation Class Initialized
INFO - 2024-02-25 15:41:54 --> Controller Class Initialized
INFO - 2024-02-25 15:41:54 --> Model Class Initialized
DEBUG - 2024-02-25 15:41:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:41:54 --> Model Class Initialized
DEBUG - 2024-02-25 15:41:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:41:54 --> Model Class Initialized
INFO - 2024-02-25 15:41:54 --> Model Class Initialized
INFO - 2024-02-25 15:41:54 --> Model Class Initialized
INFO - 2024-02-25 15:41:54 --> Model Class Initialized
DEBUG - 2024-02-25 15:41:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:41:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:41:54 --> Model Class Initialized
INFO - 2024-02-25 15:41:54 --> Model Class Initialized
INFO - 2024-02-25 15:41:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-25 15:41:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:41:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 15:41:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 15:41:54 --> Model Class Initialized
INFO - 2024-02-25 15:41:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-25 15:41:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-25 15:41:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 15:41:54 --> Final output sent to browser
DEBUG - 2024-02-25 15:41:54 --> Total execution time: 0.4217
ERROR - 2024-02-25 15:42:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:42:23 --> Config Class Initialized
INFO - 2024-02-25 15:42:23 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:42:23 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:42:23 --> Utf8 Class Initialized
INFO - 2024-02-25 15:42:23 --> URI Class Initialized
INFO - 2024-02-25 15:42:23 --> Router Class Initialized
INFO - 2024-02-25 15:42:23 --> Output Class Initialized
INFO - 2024-02-25 15:42:23 --> Security Class Initialized
DEBUG - 2024-02-25 15:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:42:23 --> Input Class Initialized
INFO - 2024-02-25 15:42:23 --> Language Class Initialized
INFO - 2024-02-25 15:42:23 --> Loader Class Initialized
INFO - 2024-02-25 15:42:23 --> Helper loaded: url_helper
INFO - 2024-02-25 15:42:23 --> Helper loaded: file_helper
INFO - 2024-02-25 15:42:23 --> Helper loaded: html_helper
INFO - 2024-02-25 15:42:23 --> Helper loaded: text_helper
INFO - 2024-02-25 15:42:23 --> Helper loaded: form_helper
INFO - 2024-02-25 15:42:23 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:42:23 --> Helper loaded: security_helper
INFO - 2024-02-25 15:42:23 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:42:23 --> Database Driver Class Initialized
INFO - 2024-02-25 15:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:42:23 --> Parser Class Initialized
INFO - 2024-02-25 15:42:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:42:23 --> Pagination Class Initialized
INFO - 2024-02-25 15:42:23 --> Form Validation Class Initialized
INFO - 2024-02-25 15:42:23 --> Controller Class Initialized
INFO - 2024-02-25 15:42:23 --> Model Class Initialized
DEBUG - 2024-02-25 15:42:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:42:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:42:23 --> Model Class Initialized
DEBUG - 2024-02-25 15:42:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:42:23 --> Model Class Initialized
INFO - 2024-02-25 15:42:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-25 15:42:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:42:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 15:42:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 15:42:23 --> Model Class Initialized
INFO - 2024-02-25 15:42:23 --> Model Class Initialized
INFO - 2024-02-25 15:42:23 --> Model Class Initialized
INFO - 2024-02-25 15:42:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-25 15:42:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-25 15:42:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 15:42:23 --> Final output sent to browser
DEBUG - 2024-02-25 15:42:23 --> Total execution time: 0.2396
ERROR - 2024-02-25 15:42:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:42:23 --> Config Class Initialized
INFO - 2024-02-25 15:42:23 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:42:23 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:42:23 --> Utf8 Class Initialized
INFO - 2024-02-25 15:42:23 --> URI Class Initialized
INFO - 2024-02-25 15:42:23 --> Router Class Initialized
INFO - 2024-02-25 15:42:23 --> Output Class Initialized
INFO - 2024-02-25 15:42:23 --> Security Class Initialized
DEBUG - 2024-02-25 15:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:42:23 --> Input Class Initialized
INFO - 2024-02-25 15:42:23 --> Language Class Initialized
INFO - 2024-02-25 15:42:23 --> Loader Class Initialized
INFO - 2024-02-25 15:42:23 --> Helper loaded: url_helper
INFO - 2024-02-25 15:42:23 --> Helper loaded: file_helper
INFO - 2024-02-25 15:42:23 --> Helper loaded: html_helper
INFO - 2024-02-25 15:42:23 --> Helper loaded: text_helper
INFO - 2024-02-25 15:42:23 --> Helper loaded: form_helper
INFO - 2024-02-25 15:42:23 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:42:23 --> Helper loaded: security_helper
INFO - 2024-02-25 15:42:23 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:42:23 --> Database Driver Class Initialized
INFO - 2024-02-25 15:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:42:23 --> Parser Class Initialized
INFO - 2024-02-25 15:42:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:42:23 --> Pagination Class Initialized
INFO - 2024-02-25 15:42:23 --> Form Validation Class Initialized
INFO - 2024-02-25 15:42:23 --> Controller Class Initialized
INFO - 2024-02-25 15:42:23 --> Model Class Initialized
DEBUG - 2024-02-25 15:42:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:42:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:42:23 --> Model Class Initialized
DEBUG - 2024-02-25 15:42:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:42:23 --> Model Class Initialized
INFO - 2024-02-25 15:42:23 --> Final output sent to browser
DEBUG - 2024-02-25 15:42:23 --> Total execution time: 0.0638
ERROR - 2024-02-25 15:42:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:42:26 --> Config Class Initialized
INFO - 2024-02-25 15:42:26 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:42:26 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:42:26 --> Utf8 Class Initialized
INFO - 2024-02-25 15:42:26 --> URI Class Initialized
INFO - 2024-02-25 15:42:26 --> Router Class Initialized
INFO - 2024-02-25 15:42:26 --> Output Class Initialized
INFO - 2024-02-25 15:42:26 --> Security Class Initialized
DEBUG - 2024-02-25 15:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:42:26 --> Input Class Initialized
INFO - 2024-02-25 15:42:26 --> Language Class Initialized
INFO - 2024-02-25 15:42:26 --> Loader Class Initialized
INFO - 2024-02-25 15:42:26 --> Helper loaded: url_helper
INFO - 2024-02-25 15:42:26 --> Helper loaded: file_helper
INFO - 2024-02-25 15:42:26 --> Helper loaded: html_helper
INFO - 2024-02-25 15:42:26 --> Helper loaded: text_helper
INFO - 2024-02-25 15:42:26 --> Helper loaded: form_helper
INFO - 2024-02-25 15:42:26 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:42:26 --> Helper loaded: security_helper
INFO - 2024-02-25 15:42:26 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:42:26 --> Database Driver Class Initialized
INFO - 2024-02-25 15:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:42:26 --> Parser Class Initialized
INFO - 2024-02-25 15:42:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:42:26 --> Pagination Class Initialized
INFO - 2024-02-25 15:42:26 --> Form Validation Class Initialized
INFO - 2024-02-25 15:42:26 --> Controller Class Initialized
INFO - 2024-02-25 15:42:26 --> Model Class Initialized
DEBUG - 2024-02-25 15:42:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:42:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:42:26 --> Model Class Initialized
DEBUG - 2024-02-25 15:42:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:42:26 --> Model Class Initialized
INFO - 2024-02-25 15:42:28 --> Final output sent to browser
DEBUG - 2024-02-25 15:42:28 --> Total execution time: 1.4592
ERROR - 2024-02-25 15:42:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:42:43 --> Config Class Initialized
INFO - 2024-02-25 15:42:43 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:42:43 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:42:43 --> Utf8 Class Initialized
INFO - 2024-02-25 15:42:43 --> URI Class Initialized
DEBUG - 2024-02-25 15:42:43 --> No URI present. Default controller set.
INFO - 2024-02-25 15:42:43 --> Router Class Initialized
INFO - 2024-02-25 15:42:43 --> Output Class Initialized
INFO - 2024-02-25 15:42:43 --> Security Class Initialized
DEBUG - 2024-02-25 15:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:42:43 --> Input Class Initialized
INFO - 2024-02-25 15:42:43 --> Language Class Initialized
INFO - 2024-02-25 15:42:43 --> Loader Class Initialized
INFO - 2024-02-25 15:42:43 --> Helper loaded: url_helper
INFO - 2024-02-25 15:42:43 --> Helper loaded: file_helper
INFO - 2024-02-25 15:42:43 --> Helper loaded: html_helper
INFO - 2024-02-25 15:42:43 --> Helper loaded: text_helper
INFO - 2024-02-25 15:42:43 --> Helper loaded: form_helper
INFO - 2024-02-25 15:42:43 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:42:43 --> Helper loaded: security_helper
INFO - 2024-02-25 15:42:43 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:42:43 --> Database Driver Class Initialized
INFO - 2024-02-25 15:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:42:43 --> Parser Class Initialized
INFO - 2024-02-25 15:42:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:42:43 --> Pagination Class Initialized
INFO - 2024-02-25 15:42:43 --> Form Validation Class Initialized
INFO - 2024-02-25 15:42:43 --> Controller Class Initialized
INFO - 2024-02-25 15:42:43 --> Model Class Initialized
DEBUG - 2024-02-25 15:42:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:42:43 --> Model Class Initialized
DEBUG - 2024-02-25 15:42:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:42:43 --> Model Class Initialized
INFO - 2024-02-25 15:42:43 --> Model Class Initialized
INFO - 2024-02-25 15:42:43 --> Model Class Initialized
INFO - 2024-02-25 15:42:43 --> Model Class Initialized
DEBUG - 2024-02-25 15:42:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:42:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:42:43 --> Model Class Initialized
INFO - 2024-02-25 15:42:43 --> Model Class Initialized
INFO - 2024-02-25 15:42:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-25 15:42:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:42:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 15:42:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 15:42:43 --> Model Class Initialized
INFO - 2024-02-25 15:42:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-25 15:42:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-25 15:42:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 15:42:43 --> Final output sent to browser
DEBUG - 2024-02-25 15:42:43 --> Total execution time: 0.4455
ERROR - 2024-02-25 15:42:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:42:56 --> Config Class Initialized
INFO - 2024-02-25 15:42:56 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:42:56 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:42:56 --> Utf8 Class Initialized
INFO - 2024-02-25 15:42:56 --> URI Class Initialized
DEBUG - 2024-02-25 15:42:56 --> No URI present. Default controller set.
INFO - 2024-02-25 15:42:56 --> Router Class Initialized
INFO - 2024-02-25 15:42:56 --> Output Class Initialized
INFO - 2024-02-25 15:42:56 --> Security Class Initialized
DEBUG - 2024-02-25 15:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:42:56 --> Input Class Initialized
INFO - 2024-02-25 15:42:56 --> Language Class Initialized
INFO - 2024-02-25 15:42:56 --> Loader Class Initialized
INFO - 2024-02-25 15:42:56 --> Helper loaded: url_helper
INFO - 2024-02-25 15:42:56 --> Helper loaded: file_helper
INFO - 2024-02-25 15:42:56 --> Helper loaded: html_helper
INFO - 2024-02-25 15:42:56 --> Helper loaded: text_helper
INFO - 2024-02-25 15:42:56 --> Helper loaded: form_helper
INFO - 2024-02-25 15:42:56 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:42:56 --> Helper loaded: security_helper
INFO - 2024-02-25 15:42:56 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:42:56 --> Database Driver Class Initialized
INFO - 2024-02-25 15:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:42:56 --> Parser Class Initialized
INFO - 2024-02-25 15:42:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:42:56 --> Pagination Class Initialized
INFO - 2024-02-25 15:42:56 --> Form Validation Class Initialized
INFO - 2024-02-25 15:42:56 --> Controller Class Initialized
INFO - 2024-02-25 15:42:56 --> Model Class Initialized
DEBUG - 2024-02-25 15:42:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:42:56 --> Model Class Initialized
DEBUG - 2024-02-25 15:42:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:42:56 --> Model Class Initialized
INFO - 2024-02-25 15:42:56 --> Model Class Initialized
INFO - 2024-02-25 15:42:56 --> Model Class Initialized
INFO - 2024-02-25 15:42:56 --> Model Class Initialized
DEBUG - 2024-02-25 15:42:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:42:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:42:56 --> Model Class Initialized
INFO - 2024-02-25 15:42:56 --> Model Class Initialized
INFO - 2024-02-25 15:42:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-25 15:42:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:42:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 15:42:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 15:42:56 --> Model Class Initialized
INFO - 2024-02-25 15:42:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-25 15:42:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-25 15:42:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 15:42:56 --> Final output sent to browser
DEBUG - 2024-02-25 15:42:56 --> Total execution time: 0.4360
ERROR - 2024-02-25 15:43:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:43:17 --> Config Class Initialized
INFO - 2024-02-25 15:43:17 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:43:17 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:43:17 --> Utf8 Class Initialized
INFO - 2024-02-25 15:43:17 --> URI Class Initialized
DEBUG - 2024-02-25 15:43:17 --> No URI present. Default controller set.
INFO - 2024-02-25 15:43:17 --> Router Class Initialized
INFO - 2024-02-25 15:43:17 --> Output Class Initialized
INFO - 2024-02-25 15:43:17 --> Security Class Initialized
DEBUG - 2024-02-25 15:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:43:17 --> Input Class Initialized
INFO - 2024-02-25 15:43:17 --> Language Class Initialized
INFO - 2024-02-25 15:43:17 --> Loader Class Initialized
INFO - 2024-02-25 15:43:17 --> Helper loaded: url_helper
INFO - 2024-02-25 15:43:17 --> Helper loaded: file_helper
INFO - 2024-02-25 15:43:17 --> Helper loaded: html_helper
INFO - 2024-02-25 15:43:17 --> Helper loaded: text_helper
INFO - 2024-02-25 15:43:17 --> Helper loaded: form_helper
INFO - 2024-02-25 15:43:17 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:43:17 --> Helper loaded: security_helper
INFO - 2024-02-25 15:43:17 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:43:17 --> Database Driver Class Initialized
INFO - 2024-02-25 15:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:43:17 --> Parser Class Initialized
INFO - 2024-02-25 15:43:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:43:17 --> Pagination Class Initialized
INFO - 2024-02-25 15:43:17 --> Form Validation Class Initialized
INFO - 2024-02-25 15:43:17 --> Controller Class Initialized
INFO - 2024-02-25 15:43:17 --> Model Class Initialized
DEBUG - 2024-02-25 15:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:43:17 --> Model Class Initialized
DEBUG - 2024-02-25 15:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:43:17 --> Model Class Initialized
INFO - 2024-02-25 15:43:17 --> Model Class Initialized
INFO - 2024-02-25 15:43:17 --> Model Class Initialized
INFO - 2024-02-25 15:43:17 --> Model Class Initialized
DEBUG - 2024-02-25 15:43:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:43:17 --> Model Class Initialized
INFO - 2024-02-25 15:43:17 --> Model Class Initialized
INFO - 2024-02-25 15:43:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-25 15:43:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:43:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 15:43:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 15:43:17 --> Model Class Initialized
INFO - 2024-02-25 15:43:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-25 15:43:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-25 15:43:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 15:43:17 --> Final output sent to browser
DEBUG - 2024-02-25 15:43:17 --> Total execution time: 0.4172
ERROR - 2024-02-25 15:43:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:43:27 --> Config Class Initialized
INFO - 2024-02-25 15:43:27 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:43:27 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:43:27 --> Utf8 Class Initialized
INFO - 2024-02-25 15:43:27 --> URI Class Initialized
INFO - 2024-02-25 15:43:27 --> Router Class Initialized
INFO - 2024-02-25 15:43:27 --> Output Class Initialized
INFO - 2024-02-25 15:43:27 --> Security Class Initialized
DEBUG - 2024-02-25 15:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:43:27 --> Input Class Initialized
INFO - 2024-02-25 15:43:27 --> Language Class Initialized
INFO - 2024-02-25 15:43:27 --> Loader Class Initialized
INFO - 2024-02-25 15:43:27 --> Helper loaded: url_helper
INFO - 2024-02-25 15:43:27 --> Helper loaded: file_helper
INFO - 2024-02-25 15:43:27 --> Helper loaded: html_helper
INFO - 2024-02-25 15:43:27 --> Helper loaded: text_helper
INFO - 2024-02-25 15:43:27 --> Helper loaded: form_helper
INFO - 2024-02-25 15:43:27 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:43:27 --> Helper loaded: security_helper
INFO - 2024-02-25 15:43:27 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:43:27 --> Database Driver Class Initialized
INFO - 2024-02-25 15:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:43:27 --> Parser Class Initialized
INFO - 2024-02-25 15:43:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:43:27 --> Pagination Class Initialized
INFO - 2024-02-25 15:43:27 --> Form Validation Class Initialized
INFO - 2024-02-25 15:43:27 --> Controller Class Initialized
DEBUG - 2024-02-25 15:43:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:43:27 --> Model Class Initialized
DEBUG - 2024-02-25 15:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:43:27 --> Model Class Initialized
DEBUG - 2024-02-25 15:43:27 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:43:27 --> Model Class Initialized
INFO - 2024-02-25 15:43:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-25 15:43:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:43:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 15:43:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 15:43:27 --> Model Class Initialized
INFO - 2024-02-25 15:43:27 --> Model Class Initialized
INFO - 2024-02-25 15:43:27 --> Model Class Initialized
INFO - 2024-02-25 15:43:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-25 15:43:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-25 15:43:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 15:43:28 --> Final output sent to browser
DEBUG - 2024-02-25 15:43:28 --> Total execution time: 0.2399
ERROR - 2024-02-25 15:43:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:43:28 --> Config Class Initialized
INFO - 2024-02-25 15:43:28 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:43:28 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:43:28 --> Utf8 Class Initialized
INFO - 2024-02-25 15:43:28 --> URI Class Initialized
INFO - 2024-02-25 15:43:28 --> Router Class Initialized
INFO - 2024-02-25 15:43:28 --> Output Class Initialized
INFO - 2024-02-25 15:43:28 --> Security Class Initialized
DEBUG - 2024-02-25 15:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:43:28 --> Input Class Initialized
INFO - 2024-02-25 15:43:28 --> Language Class Initialized
INFO - 2024-02-25 15:43:28 --> Loader Class Initialized
INFO - 2024-02-25 15:43:28 --> Helper loaded: url_helper
INFO - 2024-02-25 15:43:28 --> Helper loaded: file_helper
INFO - 2024-02-25 15:43:28 --> Helper loaded: html_helper
INFO - 2024-02-25 15:43:28 --> Helper loaded: text_helper
INFO - 2024-02-25 15:43:28 --> Helper loaded: form_helper
INFO - 2024-02-25 15:43:28 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:43:28 --> Helper loaded: security_helper
INFO - 2024-02-25 15:43:28 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:43:28 --> Database Driver Class Initialized
INFO - 2024-02-25 15:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:43:28 --> Parser Class Initialized
INFO - 2024-02-25 15:43:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:43:28 --> Pagination Class Initialized
INFO - 2024-02-25 15:43:28 --> Form Validation Class Initialized
INFO - 2024-02-25 15:43:28 --> Controller Class Initialized
DEBUG - 2024-02-25 15:43:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:43:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:43:28 --> Model Class Initialized
DEBUG - 2024-02-25 15:43:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:43:28 --> Model Class Initialized
INFO - 2024-02-25 15:43:28 --> Final output sent to browser
DEBUG - 2024-02-25 15:43:28 --> Total execution time: 0.0331
ERROR - 2024-02-25 15:43:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 15:43:32 --> Config Class Initialized
INFO - 2024-02-25 15:43:32 --> Hooks Class Initialized
DEBUG - 2024-02-25 15:43:32 --> UTF-8 Support Enabled
INFO - 2024-02-25 15:43:32 --> Utf8 Class Initialized
INFO - 2024-02-25 15:43:32 --> URI Class Initialized
INFO - 2024-02-25 15:43:32 --> Router Class Initialized
INFO - 2024-02-25 15:43:32 --> Output Class Initialized
INFO - 2024-02-25 15:43:32 --> Security Class Initialized
DEBUG - 2024-02-25 15:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 15:43:32 --> Input Class Initialized
INFO - 2024-02-25 15:43:32 --> Language Class Initialized
INFO - 2024-02-25 15:43:32 --> Loader Class Initialized
INFO - 2024-02-25 15:43:32 --> Helper loaded: url_helper
INFO - 2024-02-25 15:43:32 --> Helper loaded: file_helper
INFO - 2024-02-25 15:43:32 --> Helper loaded: html_helper
INFO - 2024-02-25 15:43:32 --> Helper loaded: text_helper
INFO - 2024-02-25 15:43:32 --> Helper loaded: form_helper
INFO - 2024-02-25 15:43:32 --> Helper loaded: lang_helper
INFO - 2024-02-25 15:43:32 --> Helper loaded: security_helper
INFO - 2024-02-25 15:43:32 --> Helper loaded: cookie_helper
INFO - 2024-02-25 15:43:32 --> Database Driver Class Initialized
INFO - 2024-02-25 15:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 15:43:32 --> Parser Class Initialized
INFO - 2024-02-25 15:43:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 15:43:32 --> Pagination Class Initialized
INFO - 2024-02-25 15:43:32 --> Form Validation Class Initialized
INFO - 2024-02-25 15:43:32 --> Controller Class Initialized
DEBUG - 2024-02-25 15:43:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-25 15:43:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:43:32 --> Model Class Initialized
DEBUG - 2024-02-25 15:43:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 15:43:32 --> Model Class Initialized
INFO - 2024-02-25 15:43:32 --> Final output sent to browser
DEBUG - 2024-02-25 15:43:32 --> Total execution time: 0.2648
ERROR - 2024-02-25 17:29:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 17:29:24 --> Config Class Initialized
INFO - 2024-02-25 17:29:24 --> Hooks Class Initialized
DEBUG - 2024-02-25 17:29:24 --> UTF-8 Support Enabled
INFO - 2024-02-25 17:29:24 --> Utf8 Class Initialized
INFO - 2024-02-25 17:29:24 --> URI Class Initialized
INFO - 2024-02-25 17:29:24 --> Router Class Initialized
INFO - 2024-02-25 17:29:24 --> Output Class Initialized
INFO - 2024-02-25 17:29:24 --> Security Class Initialized
DEBUG - 2024-02-25 17:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 17:29:24 --> Input Class Initialized
INFO - 2024-02-25 17:29:24 --> Language Class Initialized
ERROR - 2024-02-25 17:29:24 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2024-02-25 23:17:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 23:17:06 --> Config Class Initialized
INFO - 2024-02-25 23:17:06 --> Hooks Class Initialized
DEBUG - 2024-02-25 23:17:06 --> UTF-8 Support Enabled
INFO - 2024-02-25 23:17:06 --> Utf8 Class Initialized
INFO - 2024-02-25 23:17:06 --> URI Class Initialized
DEBUG - 2024-02-25 23:17:06 --> No URI present. Default controller set.
INFO - 2024-02-25 23:17:06 --> Router Class Initialized
INFO - 2024-02-25 23:17:06 --> Output Class Initialized
INFO - 2024-02-25 23:17:06 --> Security Class Initialized
DEBUG - 2024-02-25 23:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 23:17:06 --> Input Class Initialized
INFO - 2024-02-25 23:17:06 --> Language Class Initialized
INFO - 2024-02-25 23:17:06 --> Loader Class Initialized
INFO - 2024-02-25 23:17:06 --> Helper loaded: url_helper
INFO - 2024-02-25 23:17:06 --> Helper loaded: file_helper
INFO - 2024-02-25 23:17:06 --> Helper loaded: html_helper
INFO - 2024-02-25 23:17:06 --> Helper loaded: text_helper
INFO - 2024-02-25 23:17:06 --> Helper loaded: form_helper
INFO - 2024-02-25 23:17:06 --> Helper loaded: lang_helper
INFO - 2024-02-25 23:17:06 --> Helper loaded: security_helper
INFO - 2024-02-25 23:17:06 --> Helper loaded: cookie_helper
INFO - 2024-02-25 23:17:06 --> Database Driver Class Initialized
INFO - 2024-02-25 23:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 23:17:06 --> Parser Class Initialized
INFO - 2024-02-25 23:17:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 23:17:06 --> Pagination Class Initialized
INFO - 2024-02-25 23:17:06 --> Form Validation Class Initialized
INFO - 2024-02-25 23:17:06 --> Controller Class Initialized
INFO - 2024-02-25 23:17:06 --> Model Class Initialized
DEBUG - 2024-02-25 23:17:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-25 23:17:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-25 23:17:08 --> Config Class Initialized
INFO - 2024-02-25 23:17:08 --> Hooks Class Initialized
DEBUG - 2024-02-25 23:17:08 --> UTF-8 Support Enabled
INFO - 2024-02-25 23:17:08 --> Utf8 Class Initialized
INFO - 2024-02-25 23:17:08 --> URI Class Initialized
INFO - 2024-02-25 23:17:08 --> Router Class Initialized
INFO - 2024-02-25 23:17:08 --> Output Class Initialized
INFO - 2024-02-25 23:17:08 --> Security Class Initialized
DEBUG - 2024-02-25 23:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-25 23:17:08 --> Input Class Initialized
INFO - 2024-02-25 23:17:08 --> Language Class Initialized
INFO - 2024-02-25 23:17:08 --> Loader Class Initialized
INFO - 2024-02-25 23:17:08 --> Helper loaded: url_helper
INFO - 2024-02-25 23:17:08 --> Helper loaded: file_helper
INFO - 2024-02-25 23:17:08 --> Helper loaded: html_helper
INFO - 2024-02-25 23:17:08 --> Helper loaded: text_helper
INFO - 2024-02-25 23:17:08 --> Helper loaded: form_helper
INFO - 2024-02-25 23:17:08 --> Helper loaded: lang_helper
INFO - 2024-02-25 23:17:08 --> Helper loaded: security_helper
INFO - 2024-02-25 23:17:08 --> Helper loaded: cookie_helper
INFO - 2024-02-25 23:17:08 --> Database Driver Class Initialized
INFO - 2024-02-25 23:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-25 23:17:08 --> Parser Class Initialized
INFO - 2024-02-25 23:17:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-25 23:17:08 --> Pagination Class Initialized
INFO - 2024-02-25 23:17:08 --> Form Validation Class Initialized
INFO - 2024-02-25 23:17:08 --> Controller Class Initialized
INFO - 2024-02-25 23:17:08 --> Model Class Initialized
DEBUG - 2024-02-25 23:17:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-25 23:17:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-25 23:17:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-25 23:17:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-25 23:17:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-25 23:17:08 --> Model Class Initialized
INFO - 2024-02-25 23:17:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-25 23:17:08 --> Final output sent to browser
DEBUG - 2024-02-25 23:17:08 --> Total execution time: 0.0339
