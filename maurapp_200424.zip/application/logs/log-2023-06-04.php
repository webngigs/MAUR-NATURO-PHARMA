<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-04 01:45:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 01:45:52 --> Config Class Initialized
INFO - 2023-06-04 01:45:52 --> Hooks Class Initialized
DEBUG - 2023-06-04 01:45:52 --> UTF-8 Support Enabled
INFO - 2023-06-04 01:45:52 --> Utf8 Class Initialized
INFO - 2023-06-04 01:45:52 --> URI Class Initialized
INFO - 2023-06-04 01:45:52 --> Router Class Initialized
INFO - 2023-06-04 01:45:52 --> Output Class Initialized
INFO - 2023-06-04 01:45:52 --> Security Class Initialized
DEBUG - 2023-06-04 01:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 01:45:52 --> Input Class Initialized
INFO - 2023-06-04 01:45:52 --> Language Class Initialized
ERROR - 2023-06-04 01:45:52 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-06-04 01:45:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 01:45:53 --> Config Class Initialized
INFO - 2023-06-04 01:45:53 --> Hooks Class Initialized
DEBUG - 2023-06-04 01:45:53 --> UTF-8 Support Enabled
INFO - 2023-06-04 01:45:53 --> Utf8 Class Initialized
INFO - 2023-06-04 01:45:53 --> URI Class Initialized
DEBUG - 2023-06-04 01:45:53 --> No URI present. Default controller set.
INFO - 2023-06-04 01:45:53 --> Router Class Initialized
INFO - 2023-06-04 01:45:53 --> Output Class Initialized
INFO - 2023-06-04 01:45:53 --> Security Class Initialized
DEBUG - 2023-06-04 01:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 01:45:53 --> Input Class Initialized
INFO - 2023-06-04 01:45:53 --> Language Class Initialized
INFO - 2023-06-04 01:45:53 --> Loader Class Initialized
INFO - 2023-06-04 01:45:53 --> Helper loaded: url_helper
INFO - 2023-06-04 01:45:53 --> Helper loaded: file_helper
INFO - 2023-06-04 01:45:53 --> Helper loaded: html_helper
INFO - 2023-06-04 01:45:53 --> Helper loaded: text_helper
INFO - 2023-06-04 01:45:53 --> Helper loaded: form_helper
INFO - 2023-06-04 01:45:53 --> Helper loaded: lang_helper
INFO - 2023-06-04 01:45:53 --> Helper loaded: security_helper
INFO - 2023-06-04 01:45:53 --> Helper loaded: cookie_helper
INFO - 2023-06-04 01:45:53 --> Database Driver Class Initialized
INFO - 2023-06-04 01:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 01:45:53 --> Parser Class Initialized
INFO - 2023-06-04 01:45:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 01:45:53 --> Pagination Class Initialized
INFO - 2023-06-04 01:45:53 --> Form Validation Class Initialized
INFO - 2023-06-04 01:45:53 --> Controller Class Initialized
INFO - 2023-06-04 01:45:53 --> Model Class Initialized
DEBUG - 2023-06-04 01:45:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-04 04:10:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:10:09 --> Config Class Initialized
INFO - 2023-06-04 04:10:09 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:10:09 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:10:09 --> Utf8 Class Initialized
INFO - 2023-06-04 04:10:09 --> URI Class Initialized
DEBUG - 2023-06-04 04:10:09 --> No URI present. Default controller set.
INFO - 2023-06-04 04:10:09 --> Router Class Initialized
INFO - 2023-06-04 04:10:09 --> Output Class Initialized
INFO - 2023-06-04 04:10:09 --> Security Class Initialized
DEBUG - 2023-06-04 04:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:10:09 --> Input Class Initialized
INFO - 2023-06-04 04:10:09 --> Language Class Initialized
INFO - 2023-06-04 04:10:09 --> Loader Class Initialized
INFO - 2023-06-04 04:10:09 --> Helper loaded: url_helper
INFO - 2023-06-04 04:10:09 --> Helper loaded: file_helper
INFO - 2023-06-04 04:10:09 --> Helper loaded: html_helper
INFO - 2023-06-04 04:10:09 --> Helper loaded: text_helper
INFO - 2023-06-04 04:10:09 --> Helper loaded: form_helper
INFO - 2023-06-04 04:10:09 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:10:09 --> Helper loaded: security_helper
INFO - 2023-06-04 04:10:09 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:10:09 --> Database Driver Class Initialized
INFO - 2023-06-04 04:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:10:09 --> Parser Class Initialized
INFO - 2023-06-04 04:10:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:10:09 --> Pagination Class Initialized
INFO - 2023-06-04 04:10:09 --> Form Validation Class Initialized
INFO - 2023-06-04 04:10:09 --> Controller Class Initialized
INFO - 2023-06-04 04:10:09 --> Model Class Initialized
DEBUG - 2023-06-04 04:10:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-04 04:10:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:10:10 --> Config Class Initialized
INFO - 2023-06-04 04:10:10 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:10:10 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:10:10 --> Utf8 Class Initialized
INFO - 2023-06-04 04:10:10 --> URI Class Initialized
INFO - 2023-06-04 04:10:10 --> Router Class Initialized
INFO - 2023-06-04 04:10:10 --> Output Class Initialized
INFO - 2023-06-04 04:10:10 --> Security Class Initialized
DEBUG - 2023-06-04 04:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:10:10 --> Input Class Initialized
INFO - 2023-06-04 04:10:10 --> Language Class Initialized
INFO - 2023-06-04 04:10:10 --> Loader Class Initialized
INFO - 2023-06-04 04:10:10 --> Helper loaded: url_helper
INFO - 2023-06-04 04:10:10 --> Helper loaded: file_helper
INFO - 2023-06-04 04:10:10 --> Helper loaded: html_helper
INFO - 2023-06-04 04:10:10 --> Helper loaded: text_helper
INFO - 2023-06-04 04:10:10 --> Helper loaded: form_helper
INFO - 2023-06-04 04:10:10 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:10:10 --> Helper loaded: security_helper
INFO - 2023-06-04 04:10:10 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:10:10 --> Database Driver Class Initialized
INFO - 2023-06-04 04:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:10:10 --> Parser Class Initialized
INFO - 2023-06-04 04:10:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:10:10 --> Pagination Class Initialized
INFO - 2023-06-04 04:10:10 --> Form Validation Class Initialized
INFO - 2023-06-04 04:10:10 --> Controller Class Initialized
INFO - 2023-06-04 04:10:10 --> Model Class Initialized
DEBUG - 2023-06-04 04:10:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:10:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-04 04:10:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:10:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:10:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:10:10 --> Model Class Initialized
INFO - 2023-06-04 04:10:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:10:10 --> Final output sent to browser
DEBUG - 2023-06-04 04:10:10 --> Total execution time: 0.0324
ERROR - 2023-06-04 04:10:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:10:27 --> Config Class Initialized
INFO - 2023-06-04 04:10:27 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:10:27 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:10:27 --> Utf8 Class Initialized
INFO - 2023-06-04 04:10:27 --> URI Class Initialized
INFO - 2023-06-04 04:10:27 --> Router Class Initialized
INFO - 2023-06-04 04:10:27 --> Output Class Initialized
INFO - 2023-06-04 04:10:27 --> Security Class Initialized
DEBUG - 2023-06-04 04:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:10:27 --> Input Class Initialized
INFO - 2023-06-04 04:10:27 --> Language Class Initialized
INFO - 2023-06-04 04:10:27 --> Loader Class Initialized
INFO - 2023-06-04 04:10:27 --> Helper loaded: url_helper
INFO - 2023-06-04 04:10:27 --> Helper loaded: file_helper
INFO - 2023-06-04 04:10:27 --> Helper loaded: html_helper
INFO - 2023-06-04 04:10:27 --> Helper loaded: text_helper
INFO - 2023-06-04 04:10:27 --> Helper loaded: form_helper
INFO - 2023-06-04 04:10:27 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:10:27 --> Helper loaded: security_helper
INFO - 2023-06-04 04:10:27 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:10:27 --> Database Driver Class Initialized
INFO - 2023-06-04 04:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:10:27 --> Parser Class Initialized
INFO - 2023-06-04 04:10:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:10:27 --> Pagination Class Initialized
INFO - 2023-06-04 04:10:27 --> Form Validation Class Initialized
INFO - 2023-06-04 04:10:27 --> Controller Class Initialized
INFO - 2023-06-04 04:10:27 --> Model Class Initialized
DEBUG - 2023-06-04 04:10:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:10:27 --> Model Class Initialized
INFO - 2023-06-04 04:10:27 --> Final output sent to browser
DEBUG - 2023-06-04 04:10:27 --> Total execution time: 0.0219
ERROR - 2023-06-04 04:10:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:10:28 --> Config Class Initialized
INFO - 2023-06-04 04:10:28 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:10:28 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:10:28 --> Utf8 Class Initialized
INFO - 2023-06-04 04:10:28 --> URI Class Initialized
DEBUG - 2023-06-04 04:10:28 --> No URI present. Default controller set.
INFO - 2023-06-04 04:10:28 --> Router Class Initialized
INFO - 2023-06-04 04:10:28 --> Output Class Initialized
INFO - 2023-06-04 04:10:28 --> Security Class Initialized
DEBUG - 2023-06-04 04:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:10:28 --> Input Class Initialized
INFO - 2023-06-04 04:10:28 --> Language Class Initialized
INFO - 2023-06-04 04:10:28 --> Loader Class Initialized
INFO - 2023-06-04 04:10:28 --> Helper loaded: url_helper
INFO - 2023-06-04 04:10:28 --> Helper loaded: file_helper
INFO - 2023-06-04 04:10:28 --> Helper loaded: html_helper
INFO - 2023-06-04 04:10:28 --> Helper loaded: text_helper
INFO - 2023-06-04 04:10:28 --> Helper loaded: form_helper
INFO - 2023-06-04 04:10:28 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:10:28 --> Helper loaded: security_helper
INFO - 2023-06-04 04:10:28 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:10:28 --> Database Driver Class Initialized
INFO - 2023-06-04 04:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:10:28 --> Parser Class Initialized
INFO - 2023-06-04 04:10:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:10:28 --> Pagination Class Initialized
INFO - 2023-06-04 04:10:28 --> Form Validation Class Initialized
INFO - 2023-06-04 04:10:28 --> Controller Class Initialized
INFO - 2023-06-04 04:10:28 --> Model Class Initialized
DEBUG - 2023-06-04 04:10:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:10:28 --> Model Class Initialized
DEBUG - 2023-06-04 04:10:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:10:28 --> Model Class Initialized
INFO - 2023-06-04 04:10:28 --> Model Class Initialized
INFO - 2023-06-04 04:10:28 --> Model Class Initialized
INFO - 2023-06-04 04:10:28 --> Model Class Initialized
DEBUG - 2023-06-04 04:10:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:10:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:10:28 --> Model Class Initialized
INFO - 2023-06-04 04:10:28 --> Model Class Initialized
INFO - 2023-06-04 04:10:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-04 04:10:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:10:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:10:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:10:28 --> Model Class Initialized
INFO - 2023-06-04 04:10:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:10:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:10:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:10:28 --> Final output sent to browser
DEBUG - 2023-06-04 04:10:28 --> Total execution time: 0.0922
ERROR - 2023-06-04 04:10:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:10:45 --> Config Class Initialized
INFO - 2023-06-04 04:10:45 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:10:45 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:10:45 --> Utf8 Class Initialized
INFO - 2023-06-04 04:10:45 --> URI Class Initialized
INFO - 2023-06-04 04:10:45 --> Router Class Initialized
INFO - 2023-06-04 04:10:45 --> Output Class Initialized
INFO - 2023-06-04 04:10:45 --> Security Class Initialized
DEBUG - 2023-06-04 04:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:10:45 --> Input Class Initialized
INFO - 2023-06-04 04:10:45 --> Language Class Initialized
INFO - 2023-06-04 04:10:45 --> Loader Class Initialized
INFO - 2023-06-04 04:10:45 --> Helper loaded: url_helper
INFO - 2023-06-04 04:10:45 --> Helper loaded: file_helper
INFO - 2023-06-04 04:10:45 --> Helper loaded: html_helper
INFO - 2023-06-04 04:10:45 --> Helper loaded: text_helper
INFO - 2023-06-04 04:10:45 --> Helper loaded: form_helper
INFO - 2023-06-04 04:10:45 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:10:45 --> Helper loaded: security_helper
INFO - 2023-06-04 04:10:45 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:10:45 --> Database Driver Class Initialized
INFO - 2023-06-04 04:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:10:45 --> Parser Class Initialized
INFO - 2023-06-04 04:10:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:10:45 --> Pagination Class Initialized
INFO - 2023-06-04 04:10:45 --> Form Validation Class Initialized
INFO - 2023-06-04 04:10:45 --> Controller Class Initialized
INFO - 2023-06-04 04:10:45 --> Model Class Initialized
DEBUG - 2023-06-04 04:10:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:10:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:10:45 --> Model Class Initialized
INFO - 2023-06-04 04:10:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-06-04 04:10:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:10:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:10:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:10:45 --> Model Class Initialized
INFO - 2023-06-04 04:10:45 --> Model Class Initialized
INFO - 2023-06-04 04:10:45 --> Model Class Initialized
INFO - 2023-06-04 04:10:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:10:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:10:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:10:45 --> Final output sent to browser
DEBUG - 2023-06-04 04:10:45 --> Total execution time: 0.0706
ERROR - 2023-06-04 04:10:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:10:46 --> Config Class Initialized
INFO - 2023-06-04 04:10:46 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:10:46 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:10:46 --> Utf8 Class Initialized
INFO - 2023-06-04 04:10:46 --> URI Class Initialized
INFO - 2023-06-04 04:10:46 --> Router Class Initialized
INFO - 2023-06-04 04:10:46 --> Output Class Initialized
INFO - 2023-06-04 04:10:46 --> Security Class Initialized
DEBUG - 2023-06-04 04:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:10:46 --> Input Class Initialized
INFO - 2023-06-04 04:10:46 --> Language Class Initialized
INFO - 2023-06-04 04:10:46 --> Loader Class Initialized
INFO - 2023-06-04 04:10:46 --> Helper loaded: url_helper
INFO - 2023-06-04 04:10:46 --> Helper loaded: file_helper
INFO - 2023-06-04 04:10:46 --> Helper loaded: html_helper
INFO - 2023-06-04 04:10:46 --> Helper loaded: text_helper
INFO - 2023-06-04 04:10:46 --> Helper loaded: form_helper
INFO - 2023-06-04 04:10:46 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:10:46 --> Helper loaded: security_helper
INFO - 2023-06-04 04:10:46 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:10:46 --> Database Driver Class Initialized
INFO - 2023-06-04 04:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:10:46 --> Parser Class Initialized
INFO - 2023-06-04 04:10:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:10:46 --> Pagination Class Initialized
INFO - 2023-06-04 04:10:46 --> Form Validation Class Initialized
INFO - 2023-06-04 04:10:46 --> Controller Class Initialized
INFO - 2023-06-04 04:10:46 --> Model Class Initialized
DEBUG - 2023-06-04 04:10:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:10:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:10:46 --> Model Class Initialized
INFO - 2023-06-04 04:10:46 --> Final output sent to browser
DEBUG - 2023-06-04 04:10:46 --> Total execution time: 0.0276
ERROR - 2023-06-04 04:10:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:10:50 --> Config Class Initialized
INFO - 2023-06-04 04:10:50 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:10:50 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:10:50 --> Utf8 Class Initialized
INFO - 2023-06-04 04:10:50 --> URI Class Initialized
INFO - 2023-06-04 04:10:50 --> Router Class Initialized
INFO - 2023-06-04 04:10:50 --> Output Class Initialized
INFO - 2023-06-04 04:10:50 --> Security Class Initialized
DEBUG - 2023-06-04 04:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:10:50 --> Input Class Initialized
INFO - 2023-06-04 04:10:50 --> Language Class Initialized
INFO - 2023-06-04 04:10:50 --> Loader Class Initialized
INFO - 2023-06-04 04:10:50 --> Helper loaded: url_helper
INFO - 2023-06-04 04:10:50 --> Helper loaded: file_helper
INFO - 2023-06-04 04:10:50 --> Helper loaded: html_helper
INFO - 2023-06-04 04:10:50 --> Helper loaded: text_helper
INFO - 2023-06-04 04:10:50 --> Helper loaded: form_helper
INFO - 2023-06-04 04:10:50 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:10:50 --> Helper loaded: security_helper
INFO - 2023-06-04 04:10:50 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:10:50 --> Database Driver Class Initialized
INFO - 2023-06-04 04:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:10:50 --> Parser Class Initialized
INFO - 2023-06-04 04:10:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:10:50 --> Pagination Class Initialized
INFO - 2023-06-04 04:10:50 --> Form Validation Class Initialized
INFO - 2023-06-04 04:10:50 --> Controller Class Initialized
INFO - 2023-06-04 04:10:50 --> Model Class Initialized
DEBUG - 2023-06-04 04:10:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:10:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:10:50 --> Model Class Initialized
INFO - 2023-06-04 04:10:50 --> Final output sent to browser
DEBUG - 2023-06-04 04:10:50 --> Total execution time: 0.0251
ERROR - 2023-06-04 04:11:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:11:49 --> Config Class Initialized
INFO - 2023-06-04 04:11:49 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:11:49 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:11:49 --> Utf8 Class Initialized
INFO - 2023-06-04 04:11:49 --> URI Class Initialized
DEBUG - 2023-06-04 04:11:49 --> No URI present. Default controller set.
INFO - 2023-06-04 04:11:49 --> Router Class Initialized
INFO - 2023-06-04 04:11:49 --> Output Class Initialized
INFO - 2023-06-04 04:11:49 --> Security Class Initialized
DEBUG - 2023-06-04 04:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:11:49 --> Input Class Initialized
INFO - 2023-06-04 04:11:49 --> Language Class Initialized
INFO - 2023-06-04 04:11:49 --> Loader Class Initialized
INFO - 2023-06-04 04:11:49 --> Helper loaded: url_helper
INFO - 2023-06-04 04:11:49 --> Helper loaded: file_helper
INFO - 2023-06-04 04:11:49 --> Helper loaded: html_helper
INFO - 2023-06-04 04:11:49 --> Helper loaded: text_helper
INFO - 2023-06-04 04:11:49 --> Helper loaded: form_helper
INFO - 2023-06-04 04:11:49 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:11:49 --> Helper loaded: security_helper
INFO - 2023-06-04 04:11:49 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:11:49 --> Database Driver Class Initialized
INFO - 2023-06-04 04:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:11:49 --> Parser Class Initialized
INFO - 2023-06-04 04:11:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:11:49 --> Pagination Class Initialized
INFO - 2023-06-04 04:11:49 --> Form Validation Class Initialized
INFO - 2023-06-04 04:11:49 --> Controller Class Initialized
INFO - 2023-06-04 04:11:49 --> Model Class Initialized
DEBUG - 2023-06-04 04:11:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:11:49 --> Model Class Initialized
DEBUG - 2023-06-04 04:11:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:11:49 --> Model Class Initialized
INFO - 2023-06-04 04:11:49 --> Model Class Initialized
INFO - 2023-06-04 04:11:49 --> Model Class Initialized
INFO - 2023-06-04 04:11:49 --> Model Class Initialized
DEBUG - 2023-06-04 04:11:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:11:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:11:49 --> Model Class Initialized
INFO - 2023-06-04 04:11:49 --> Model Class Initialized
INFO - 2023-06-04 04:11:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-04 04:11:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:11:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:11:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:11:49 --> Model Class Initialized
INFO - 2023-06-04 04:11:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:11:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:11:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:11:49 --> Final output sent to browser
DEBUG - 2023-06-04 04:11:49 --> Total execution time: 0.0721
ERROR - 2023-06-04 04:12:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:12:10 --> Config Class Initialized
INFO - 2023-06-04 04:12:10 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:12:10 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:12:10 --> Utf8 Class Initialized
INFO - 2023-06-04 04:12:10 --> URI Class Initialized
INFO - 2023-06-04 04:12:10 --> Router Class Initialized
INFO - 2023-06-04 04:12:10 --> Output Class Initialized
INFO - 2023-06-04 04:12:10 --> Security Class Initialized
DEBUG - 2023-06-04 04:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:12:10 --> Input Class Initialized
INFO - 2023-06-04 04:12:10 --> Language Class Initialized
INFO - 2023-06-04 04:12:10 --> Loader Class Initialized
INFO - 2023-06-04 04:12:10 --> Helper loaded: url_helper
INFO - 2023-06-04 04:12:10 --> Helper loaded: file_helper
INFO - 2023-06-04 04:12:10 --> Helper loaded: html_helper
INFO - 2023-06-04 04:12:10 --> Helper loaded: text_helper
INFO - 2023-06-04 04:12:10 --> Helper loaded: form_helper
INFO - 2023-06-04 04:12:10 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:12:10 --> Helper loaded: security_helper
INFO - 2023-06-04 04:12:10 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:12:10 --> Database Driver Class Initialized
INFO - 2023-06-04 04:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:12:10 --> Parser Class Initialized
INFO - 2023-06-04 04:12:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:12:10 --> Pagination Class Initialized
INFO - 2023-06-04 04:12:10 --> Form Validation Class Initialized
INFO - 2023-06-04 04:12:10 --> Controller Class Initialized
INFO - 2023-06-04 04:12:10 --> Model Class Initialized
DEBUG - 2023-06-04 04:12:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:12:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:12:10 --> Model Class Initialized
INFO - 2023-06-04 04:12:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-06-04 04:12:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:12:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:12:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:12:10 --> Model Class Initialized
INFO - 2023-06-04 04:12:10 --> Model Class Initialized
INFO - 2023-06-04 04:12:10 --> Model Class Initialized
INFO - 2023-06-04 04:12:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:12:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:12:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:12:10 --> Final output sent to browser
DEBUG - 2023-06-04 04:12:10 --> Total execution time: 0.0677
ERROR - 2023-06-04 04:12:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:12:11 --> Config Class Initialized
INFO - 2023-06-04 04:12:11 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:12:11 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:12:11 --> Utf8 Class Initialized
INFO - 2023-06-04 04:12:11 --> URI Class Initialized
INFO - 2023-06-04 04:12:11 --> Router Class Initialized
INFO - 2023-06-04 04:12:11 --> Output Class Initialized
INFO - 2023-06-04 04:12:11 --> Security Class Initialized
DEBUG - 2023-06-04 04:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:12:11 --> Input Class Initialized
INFO - 2023-06-04 04:12:11 --> Language Class Initialized
INFO - 2023-06-04 04:12:11 --> Loader Class Initialized
INFO - 2023-06-04 04:12:11 --> Helper loaded: url_helper
INFO - 2023-06-04 04:12:11 --> Helper loaded: file_helper
INFO - 2023-06-04 04:12:11 --> Helper loaded: html_helper
INFO - 2023-06-04 04:12:11 --> Helper loaded: text_helper
INFO - 2023-06-04 04:12:11 --> Helper loaded: form_helper
INFO - 2023-06-04 04:12:11 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:12:11 --> Helper loaded: security_helper
INFO - 2023-06-04 04:12:11 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:12:11 --> Database Driver Class Initialized
INFO - 2023-06-04 04:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:12:11 --> Parser Class Initialized
INFO - 2023-06-04 04:12:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:12:11 --> Pagination Class Initialized
INFO - 2023-06-04 04:12:11 --> Form Validation Class Initialized
INFO - 2023-06-04 04:12:11 --> Controller Class Initialized
INFO - 2023-06-04 04:12:11 --> Model Class Initialized
DEBUG - 2023-06-04 04:12:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:12:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:12:11 --> Model Class Initialized
INFO - 2023-06-04 04:12:11 --> Final output sent to browser
DEBUG - 2023-06-04 04:12:11 --> Total execution time: 0.0253
ERROR - 2023-06-04 04:12:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:12:36 --> Config Class Initialized
INFO - 2023-06-04 04:12:36 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:12:36 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:12:36 --> Utf8 Class Initialized
INFO - 2023-06-04 04:12:36 --> URI Class Initialized
INFO - 2023-06-04 04:12:36 --> Router Class Initialized
INFO - 2023-06-04 04:12:36 --> Output Class Initialized
INFO - 2023-06-04 04:12:36 --> Security Class Initialized
DEBUG - 2023-06-04 04:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:12:36 --> Input Class Initialized
INFO - 2023-06-04 04:12:36 --> Language Class Initialized
INFO - 2023-06-04 04:12:36 --> Loader Class Initialized
INFO - 2023-06-04 04:12:36 --> Helper loaded: url_helper
INFO - 2023-06-04 04:12:36 --> Helper loaded: file_helper
INFO - 2023-06-04 04:12:36 --> Helper loaded: html_helper
INFO - 2023-06-04 04:12:36 --> Helper loaded: text_helper
INFO - 2023-06-04 04:12:36 --> Helper loaded: form_helper
INFO - 2023-06-04 04:12:36 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:12:36 --> Helper loaded: security_helper
INFO - 2023-06-04 04:12:36 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:12:36 --> Database Driver Class Initialized
INFO - 2023-06-04 04:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:12:36 --> Parser Class Initialized
INFO - 2023-06-04 04:12:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:12:36 --> Pagination Class Initialized
INFO - 2023-06-04 04:12:36 --> Form Validation Class Initialized
INFO - 2023-06-04 04:12:36 --> Controller Class Initialized
INFO - 2023-06-04 04:12:36 --> Model Class Initialized
DEBUG - 2023-06-04 04:12:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:12:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:12:36 --> Model Class Initialized
INFO - 2023-06-04 04:12:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/upcoming.php
DEBUG - 2023-06-04 04:12:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:12:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:12:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:12:36 --> Model Class Initialized
INFO - 2023-06-04 04:12:36 --> Model Class Initialized
INFO - 2023-06-04 04:12:36 --> Model Class Initialized
INFO - 2023-06-04 04:12:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:12:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:12:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:12:36 --> Final output sent to browser
DEBUG - 2023-06-04 04:12:36 --> Total execution time: 0.0628
ERROR - 2023-06-04 04:12:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:12:37 --> Config Class Initialized
INFO - 2023-06-04 04:12:37 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:12:37 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:12:37 --> Utf8 Class Initialized
INFO - 2023-06-04 04:12:37 --> URI Class Initialized
INFO - 2023-06-04 04:12:37 --> Router Class Initialized
INFO - 2023-06-04 04:12:37 --> Output Class Initialized
INFO - 2023-06-04 04:12:37 --> Security Class Initialized
DEBUG - 2023-06-04 04:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:12:37 --> Input Class Initialized
INFO - 2023-06-04 04:12:37 --> Language Class Initialized
INFO - 2023-06-04 04:12:37 --> Loader Class Initialized
INFO - 2023-06-04 04:12:37 --> Helper loaded: url_helper
INFO - 2023-06-04 04:12:37 --> Helper loaded: file_helper
INFO - 2023-06-04 04:12:37 --> Helper loaded: html_helper
INFO - 2023-06-04 04:12:37 --> Helper loaded: text_helper
INFO - 2023-06-04 04:12:37 --> Helper loaded: form_helper
INFO - 2023-06-04 04:12:37 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:12:37 --> Helper loaded: security_helper
INFO - 2023-06-04 04:12:37 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:12:37 --> Database Driver Class Initialized
INFO - 2023-06-04 04:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:12:37 --> Parser Class Initialized
INFO - 2023-06-04 04:12:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:12:37 --> Pagination Class Initialized
INFO - 2023-06-04 04:12:37 --> Form Validation Class Initialized
INFO - 2023-06-04 04:12:37 --> Controller Class Initialized
INFO - 2023-06-04 04:12:37 --> Model Class Initialized
DEBUG - 2023-06-04 04:12:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:12:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:12:37 --> Model Class Initialized
INFO - 2023-06-04 04:12:37 --> Final output sent to browser
DEBUG - 2023-06-04 04:12:37 --> Total execution time: 0.0193
ERROR - 2023-06-04 04:12:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:12:44 --> Config Class Initialized
INFO - 2023-06-04 04:12:44 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:12:44 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:12:44 --> Utf8 Class Initialized
INFO - 2023-06-04 04:12:44 --> URI Class Initialized
INFO - 2023-06-04 04:12:44 --> Router Class Initialized
INFO - 2023-06-04 04:12:44 --> Output Class Initialized
INFO - 2023-06-04 04:12:44 --> Security Class Initialized
DEBUG - 2023-06-04 04:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:12:44 --> Input Class Initialized
INFO - 2023-06-04 04:12:44 --> Language Class Initialized
INFO - 2023-06-04 04:12:44 --> Loader Class Initialized
INFO - 2023-06-04 04:12:44 --> Helper loaded: url_helper
INFO - 2023-06-04 04:12:44 --> Helper loaded: file_helper
INFO - 2023-06-04 04:12:44 --> Helper loaded: html_helper
INFO - 2023-06-04 04:12:44 --> Helper loaded: text_helper
INFO - 2023-06-04 04:12:44 --> Helper loaded: form_helper
INFO - 2023-06-04 04:12:44 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:12:44 --> Helper loaded: security_helper
INFO - 2023-06-04 04:12:44 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:12:44 --> Database Driver Class Initialized
INFO - 2023-06-04 04:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:12:44 --> Parser Class Initialized
INFO - 2023-06-04 04:12:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:12:44 --> Pagination Class Initialized
INFO - 2023-06-04 04:12:44 --> Form Validation Class Initialized
INFO - 2023-06-04 04:12:44 --> Controller Class Initialized
INFO - 2023-06-04 04:12:44 --> Model Class Initialized
DEBUG - 2023-06-04 04:12:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:12:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:12:44 --> Model Class Initialized
INFO - 2023-06-04 04:12:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-06-04 04:12:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:12:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:12:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:12:44 --> Model Class Initialized
INFO - 2023-06-04 04:12:44 --> Model Class Initialized
INFO - 2023-06-04 04:12:44 --> Model Class Initialized
INFO - 2023-06-04 04:12:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:12:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:12:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:12:44 --> Final output sent to browser
DEBUG - 2023-06-04 04:12:44 --> Total execution time: 0.0690
ERROR - 2023-06-04 04:12:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:12:45 --> Config Class Initialized
INFO - 2023-06-04 04:12:45 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:12:45 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:12:45 --> Utf8 Class Initialized
INFO - 2023-06-04 04:12:45 --> URI Class Initialized
INFO - 2023-06-04 04:12:45 --> Router Class Initialized
INFO - 2023-06-04 04:12:45 --> Output Class Initialized
INFO - 2023-06-04 04:12:45 --> Security Class Initialized
DEBUG - 2023-06-04 04:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:12:45 --> Input Class Initialized
INFO - 2023-06-04 04:12:45 --> Language Class Initialized
INFO - 2023-06-04 04:12:45 --> Loader Class Initialized
INFO - 2023-06-04 04:12:45 --> Helper loaded: url_helper
INFO - 2023-06-04 04:12:45 --> Helper loaded: file_helper
INFO - 2023-06-04 04:12:45 --> Helper loaded: html_helper
INFO - 2023-06-04 04:12:45 --> Helper loaded: text_helper
INFO - 2023-06-04 04:12:45 --> Helper loaded: form_helper
INFO - 2023-06-04 04:12:45 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:12:45 --> Helper loaded: security_helper
INFO - 2023-06-04 04:12:45 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:12:45 --> Database Driver Class Initialized
INFO - 2023-06-04 04:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:12:45 --> Parser Class Initialized
INFO - 2023-06-04 04:12:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:12:45 --> Pagination Class Initialized
INFO - 2023-06-04 04:12:45 --> Form Validation Class Initialized
INFO - 2023-06-04 04:12:45 --> Controller Class Initialized
INFO - 2023-06-04 04:12:45 --> Model Class Initialized
DEBUG - 2023-06-04 04:12:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:12:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:12:45 --> Model Class Initialized
INFO - 2023-06-04 04:12:45 --> Final output sent to browser
DEBUG - 2023-06-04 04:12:45 --> Total execution time: 0.0331
ERROR - 2023-06-04 04:12:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:12:50 --> Config Class Initialized
INFO - 2023-06-04 04:12:50 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:12:50 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:12:50 --> Utf8 Class Initialized
INFO - 2023-06-04 04:12:50 --> URI Class Initialized
INFO - 2023-06-04 04:12:50 --> Router Class Initialized
INFO - 2023-06-04 04:12:50 --> Output Class Initialized
INFO - 2023-06-04 04:12:50 --> Security Class Initialized
DEBUG - 2023-06-04 04:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:12:50 --> Input Class Initialized
INFO - 2023-06-04 04:12:50 --> Language Class Initialized
INFO - 2023-06-04 04:12:50 --> Loader Class Initialized
INFO - 2023-06-04 04:12:50 --> Helper loaded: url_helper
INFO - 2023-06-04 04:12:50 --> Helper loaded: file_helper
INFO - 2023-06-04 04:12:50 --> Helper loaded: html_helper
INFO - 2023-06-04 04:12:50 --> Helper loaded: text_helper
INFO - 2023-06-04 04:12:50 --> Helper loaded: form_helper
INFO - 2023-06-04 04:12:50 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:12:50 --> Helper loaded: security_helper
INFO - 2023-06-04 04:12:50 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:12:50 --> Database Driver Class Initialized
INFO - 2023-06-04 04:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:12:50 --> Parser Class Initialized
INFO - 2023-06-04 04:12:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:12:50 --> Pagination Class Initialized
INFO - 2023-06-04 04:12:50 --> Form Validation Class Initialized
INFO - 2023-06-04 04:12:50 --> Controller Class Initialized
INFO - 2023-06-04 04:12:50 --> Model Class Initialized
DEBUG - 2023-06-04 04:12:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:12:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:12:50 --> Model Class Initialized
INFO - 2023-06-04 04:12:50 --> Final output sent to browser
DEBUG - 2023-06-04 04:12:50 --> Total execution time: 0.0253
ERROR - 2023-06-04 04:14:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:14:39 --> Config Class Initialized
INFO - 2023-06-04 04:14:39 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:14:39 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:14:39 --> Utf8 Class Initialized
INFO - 2023-06-04 04:14:39 --> URI Class Initialized
INFO - 2023-06-04 04:14:39 --> Router Class Initialized
INFO - 2023-06-04 04:14:39 --> Output Class Initialized
INFO - 2023-06-04 04:14:39 --> Security Class Initialized
DEBUG - 2023-06-04 04:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:14:39 --> Input Class Initialized
INFO - 2023-06-04 04:14:39 --> Language Class Initialized
INFO - 2023-06-04 04:14:39 --> Loader Class Initialized
INFO - 2023-06-04 04:14:39 --> Helper loaded: url_helper
INFO - 2023-06-04 04:14:39 --> Helper loaded: file_helper
INFO - 2023-06-04 04:14:39 --> Helper loaded: html_helper
INFO - 2023-06-04 04:14:39 --> Helper loaded: text_helper
INFO - 2023-06-04 04:14:39 --> Helper loaded: form_helper
INFO - 2023-06-04 04:14:39 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:14:39 --> Helper loaded: security_helper
INFO - 2023-06-04 04:14:39 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:14:39 --> Database Driver Class Initialized
INFO - 2023-06-04 04:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:14:39 --> Parser Class Initialized
INFO - 2023-06-04 04:14:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:14:39 --> Pagination Class Initialized
INFO - 2023-06-04 04:14:39 --> Form Validation Class Initialized
INFO - 2023-06-04 04:14:39 --> Controller Class Initialized
INFO - 2023-06-04 04:14:39 --> Model Class Initialized
DEBUG - 2023-06-04 04:14:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:14:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:14:39 --> Model Class Initialized
INFO - 2023-06-04 04:14:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-06-04 04:14:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:14:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:14:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:14:39 --> Model Class Initialized
INFO - 2023-06-04 04:14:39 --> Model Class Initialized
INFO - 2023-06-04 04:14:39 --> Model Class Initialized
INFO - 2023-06-04 04:14:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:14:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:14:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:14:39 --> Final output sent to browser
DEBUG - 2023-06-04 04:14:39 --> Total execution time: 0.0720
ERROR - 2023-06-04 04:14:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:14:40 --> Config Class Initialized
INFO - 2023-06-04 04:14:40 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:14:40 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:14:40 --> Utf8 Class Initialized
INFO - 2023-06-04 04:14:40 --> URI Class Initialized
INFO - 2023-06-04 04:14:40 --> Router Class Initialized
INFO - 2023-06-04 04:14:40 --> Output Class Initialized
INFO - 2023-06-04 04:14:40 --> Security Class Initialized
DEBUG - 2023-06-04 04:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:14:40 --> Input Class Initialized
INFO - 2023-06-04 04:14:40 --> Language Class Initialized
INFO - 2023-06-04 04:14:40 --> Loader Class Initialized
INFO - 2023-06-04 04:14:40 --> Helper loaded: url_helper
INFO - 2023-06-04 04:14:40 --> Helper loaded: file_helper
INFO - 2023-06-04 04:14:40 --> Helper loaded: html_helper
INFO - 2023-06-04 04:14:40 --> Helper loaded: text_helper
INFO - 2023-06-04 04:14:40 --> Helper loaded: form_helper
INFO - 2023-06-04 04:14:40 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:14:40 --> Helper loaded: security_helper
INFO - 2023-06-04 04:14:40 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:14:40 --> Database Driver Class Initialized
INFO - 2023-06-04 04:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:14:40 --> Parser Class Initialized
INFO - 2023-06-04 04:14:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:14:40 --> Pagination Class Initialized
INFO - 2023-06-04 04:14:40 --> Form Validation Class Initialized
INFO - 2023-06-04 04:14:40 --> Controller Class Initialized
INFO - 2023-06-04 04:14:40 --> Model Class Initialized
DEBUG - 2023-06-04 04:14:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:14:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:14:40 --> Model Class Initialized
INFO - 2023-06-04 04:14:40 --> Final output sent to browser
DEBUG - 2023-06-04 04:14:40 --> Total execution time: 0.0269
ERROR - 2023-06-04 04:14:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:14:50 --> Config Class Initialized
INFO - 2023-06-04 04:14:50 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:14:50 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:14:50 --> Utf8 Class Initialized
INFO - 2023-06-04 04:14:50 --> URI Class Initialized
INFO - 2023-06-04 04:14:50 --> Router Class Initialized
INFO - 2023-06-04 04:14:50 --> Output Class Initialized
INFO - 2023-06-04 04:14:50 --> Security Class Initialized
DEBUG - 2023-06-04 04:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:14:50 --> Input Class Initialized
INFO - 2023-06-04 04:14:50 --> Language Class Initialized
INFO - 2023-06-04 04:14:50 --> Loader Class Initialized
INFO - 2023-06-04 04:14:50 --> Helper loaded: url_helper
INFO - 2023-06-04 04:14:50 --> Helper loaded: file_helper
INFO - 2023-06-04 04:14:50 --> Helper loaded: html_helper
INFO - 2023-06-04 04:14:50 --> Helper loaded: text_helper
INFO - 2023-06-04 04:14:50 --> Helper loaded: form_helper
INFO - 2023-06-04 04:14:50 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:14:50 --> Helper loaded: security_helper
INFO - 2023-06-04 04:14:50 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:14:50 --> Database Driver Class Initialized
INFO - 2023-06-04 04:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:14:50 --> Parser Class Initialized
INFO - 2023-06-04 04:14:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:14:50 --> Pagination Class Initialized
INFO - 2023-06-04 04:14:50 --> Form Validation Class Initialized
INFO - 2023-06-04 04:14:50 --> Controller Class Initialized
INFO - 2023-06-04 04:14:50 --> Model Class Initialized
DEBUG - 2023-06-04 04:14:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:14:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:14:50 --> Model Class Initialized
DEBUG - 2023-06-04 04:14:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:14:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-06-04 04:14:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:14:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:14:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:14:50 --> Model Class Initialized
INFO - 2023-06-04 04:14:50 --> Model Class Initialized
INFO - 2023-06-04 04:14:50 --> Model Class Initialized
INFO - 2023-06-04 04:14:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:14:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:14:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:14:50 --> Final output sent to browser
DEBUG - 2023-06-04 04:14:50 --> Total execution time: 0.0722
ERROR - 2023-06-04 04:15:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:15:34 --> Config Class Initialized
INFO - 2023-06-04 04:15:34 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:15:34 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:15:34 --> Utf8 Class Initialized
INFO - 2023-06-04 04:15:34 --> URI Class Initialized
INFO - 2023-06-04 04:15:34 --> Router Class Initialized
INFO - 2023-06-04 04:15:34 --> Output Class Initialized
INFO - 2023-06-04 04:15:34 --> Security Class Initialized
DEBUG - 2023-06-04 04:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:15:34 --> Input Class Initialized
INFO - 2023-06-04 04:15:34 --> Language Class Initialized
INFO - 2023-06-04 04:15:34 --> Loader Class Initialized
INFO - 2023-06-04 04:15:34 --> Helper loaded: url_helper
INFO - 2023-06-04 04:15:34 --> Helper loaded: file_helper
INFO - 2023-06-04 04:15:34 --> Helper loaded: html_helper
INFO - 2023-06-04 04:15:34 --> Helper loaded: text_helper
INFO - 2023-06-04 04:15:34 --> Helper loaded: form_helper
INFO - 2023-06-04 04:15:34 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:15:34 --> Helper loaded: security_helper
INFO - 2023-06-04 04:15:34 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:15:34 --> Database Driver Class Initialized
INFO - 2023-06-04 04:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:15:34 --> Parser Class Initialized
INFO - 2023-06-04 04:15:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:15:34 --> Pagination Class Initialized
INFO - 2023-06-04 04:15:34 --> Form Validation Class Initialized
INFO - 2023-06-04 04:15:34 --> Controller Class Initialized
INFO - 2023-06-04 04:15:34 --> Model Class Initialized
DEBUG - 2023-06-04 04:15:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:15:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:15:34 --> Model Class Initialized
INFO - 2023-06-04 04:15:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-06-04 04:15:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:15:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:15:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:15:34 --> Model Class Initialized
INFO - 2023-06-04 04:15:34 --> Model Class Initialized
INFO - 2023-06-04 04:15:34 --> Model Class Initialized
INFO - 2023-06-04 04:15:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:15:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:15:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:15:34 --> Final output sent to browser
DEBUG - 2023-06-04 04:15:34 --> Total execution time: 0.0776
ERROR - 2023-06-04 04:15:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:15:35 --> Config Class Initialized
INFO - 2023-06-04 04:15:35 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:15:35 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:15:35 --> Utf8 Class Initialized
INFO - 2023-06-04 04:15:35 --> URI Class Initialized
INFO - 2023-06-04 04:15:35 --> Router Class Initialized
INFO - 2023-06-04 04:15:35 --> Output Class Initialized
INFO - 2023-06-04 04:15:35 --> Security Class Initialized
DEBUG - 2023-06-04 04:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:15:35 --> Input Class Initialized
INFO - 2023-06-04 04:15:35 --> Language Class Initialized
INFO - 2023-06-04 04:15:35 --> Loader Class Initialized
INFO - 2023-06-04 04:15:35 --> Helper loaded: url_helper
INFO - 2023-06-04 04:15:35 --> Helper loaded: file_helper
INFO - 2023-06-04 04:15:35 --> Helper loaded: html_helper
INFO - 2023-06-04 04:15:35 --> Helper loaded: text_helper
INFO - 2023-06-04 04:15:35 --> Helper loaded: form_helper
INFO - 2023-06-04 04:15:35 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:15:35 --> Helper loaded: security_helper
INFO - 2023-06-04 04:15:35 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:15:35 --> Database Driver Class Initialized
INFO - 2023-06-04 04:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:15:35 --> Parser Class Initialized
INFO - 2023-06-04 04:15:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:15:35 --> Pagination Class Initialized
INFO - 2023-06-04 04:15:35 --> Form Validation Class Initialized
INFO - 2023-06-04 04:15:35 --> Controller Class Initialized
INFO - 2023-06-04 04:15:35 --> Model Class Initialized
DEBUG - 2023-06-04 04:15:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:15:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:15:35 --> Model Class Initialized
INFO - 2023-06-04 04:15:35 --> Final output sent to browser
DEBUG - 2023-06-04 04:15:35 --> Total execution time: 0.0363
ERROR - 2023-06-04 04:15:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:15:37 --> Config Class Initialized
INFO - 2023-06-04 04:15:37 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:15:37 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:15:37 --> Utf8 Class Initialized
INFO - 2023-06-04 04:15:37 --> URI Class Initialized
INFO - 2023-06-04 04:15:37 --> Router Class Initialized
INFO - 2023-06-04 04:15:37 --> Output Class Initialized
INFO - 2023-06-04 04:15:37 --> Security Class Initialized
DEBUG - 2023-06-04 04:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:15:37 --> Input Class Initialized
INFO - 2023-06-04 04:15:37 --> Language Class Initialized
INFO - 2023-06-04 04:15:37 --> Loader Class Initialized
INFO - 2023-06-04 04:15:37 --> Helper loaded: url_helper
INFO - 2023-06-04 04:15:37 --> Helper loaded: file_helper
INFO - 2023-06-04 04:15:37 --> Helper loaded: html_helper
INFO - 2023-06-04 04:15:37 --> Helper loaded: text_helper
INFO - 2023-06-04 04:15:37 --> Helper loaded: form_helper
INFO - 2023-06-04 04:15:37 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:15:37 --> Helper loaded: security_helper
INFO - 2023-06-04 04:15:37 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:15:37 --> Database Driver Class Initialized
INFO - 2023-06-04 04:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:15:37 --> Parser Class Initialized
INFO - 2023-06-04 04:15:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:15:37 --> Pagination Class Initialized
INFO - 2023-06-04 04:15:37 --> Form Validation Class Initialized
INFO - 2023-06-04 04:15:37 --> Controller Class Initialized
INFO - 2023-06-04 04:15:37 --> Model Class Initialized
DEBUG - 2023-06-04 04:15:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:15:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:15:37 --> Model Class Initialized
DEBUG - 2023-06-04 04:15:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:15:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-06-04 04:15:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:15:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:15:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:15:37 --> Model Class Initialized
INFO - 2023-06-04 04:15:37 --> Model Class Initialized
INFO - 2023-06-04 04:15:37 --> Model Class Initialized
INFO - 2023-06-04 04:15:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:15:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:15:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:15:37 --> Final output sent to browser
DEBUG - 2023-06-04 04:15:37 --> Total execution time: 0.0736
ERROR - 2023-06-04 04:15:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:15:43 --> Config Class Initialized
INFO - 2023-06-04 04:15:43 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:15:43 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:15:43 --> Utf8 Class Initialized
INFO - 2023-06-04 04:15:43 --> URI Class Initialized
INFO - 2023-06-04 04:15:43 --> Router Class Initialized
INFO - 2023-06-04 04:15:43 --> Output Class Initialized
INFO - 2023-06-04 04:15:43 --> Security Class Initialized
DEBUG - 2023-06-04 04:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:15:43 --> Input Class Initialized
INFO - 2023-06-04 04:15:43 --> Language Class Initialized
INFO - 2023-06-04 04:15:43 --> Loader Class Initialized
INFO - 2023-06-04 04:15:43 --> Helper loaded: url_helper
INFO - 2023-06-04 04:15:43 --> Helper loaded: file_helper
INFO - 2023-06-04 04:15:43 --> Helper loaded: html_helper
INFO - 2023-06-04 04:15:43 --> Helper loaded: text_helper
INFO - 2023-06-04 04:15:43 --> Helper loaded: form_helper
INFO - 2023-06-04 04:15:43 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:15:43 --> Helper loaded: security_helper
INFO - 2023-06-04 04:15:43 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:15:43 --> Database Driver Class Initialized
INFO - 2023-06-04 04:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:15:43 --> Parser Class Initialized
INFO - 2023-06-04 04:15:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:15:43 --> Pagination Class Initialized
INFO - 2023-06-04 04:15:43 --> Form Validation Class Initialized
INFO - 2023-06-04 04:15:43 --> Controller Class Initialized
INFO - 2023-06-04 04:15:43 --> Model Class Initialized
DEBUG - 2023-06-04 04:15:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:15:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:15:43 --> Model Class Initialized
INFO - 2023-06-04 04:15:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-06-04 04:15:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:15:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:15:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:15:43 --> Model Class Initialized
INFO - 2023-06-04 04:15:43 --> Model Class Initialized
INFO - 2023-06-04 04:15:43 --> Model Class Initialized
INFO - 2023-06-04 04:15:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:15:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:15:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:15:43 --> Final output sent to browser
DEBUG - 2023-06-04 04:15:43 --> Total execution time: 0.0687
ERROR - 2023-06-04 04:15:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:15:44 --> Config Class Initialized
INFO - 2023-06-04 04:15:44 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:15:44 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:15:44 --> Utf8 Class Initialized
INFO - 2023-06-04 04:15:44 --> URI Class Initialized
INFO - 2023-06-04 04:15:44 --> Router Class Initialized
INFO - 2023-06-04 04:15:44 --> Output Class Initialized
INFO - 2023-06-04 04:15:44 --> Security Class Initialized
DEBUG - 2023-06-04 04:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:15:44 --> Input Class Initialized
INFO - 2023-06-04 04:15:44 --> Language Class Initialized
INFO - 2023-06-04 04:15:44 --> Loader Class Initialized
INFO - 2023-06-04 04:15:44 --> Helper loaded: url_helper
INFO - 2023-06-04 04:15:44 --> Helper loaded: file_helper
INFO - 2023-06-04 04:15:44 --> Helper loaded: html_helper
INFO - 2023-06-04 04:15:44 --> Helper loaded: text_helper
INFO - 2023-06-04 04:15:44 --> Helper loaded: form_helper
INFO - 2023-06-04 04:15:44 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:15:44 --> Helper loaded: security_helper
INFO - 2023-06-04 04:15:44 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:15:44 --> Database Driver Class Initialized
INFO - 2023-06-04 04:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:15:44 --> Parser Class Initialized
INFO - 2023-06-04 04:15:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:15:44 --> Pagination Class Initialized
INFO - 2023-06-04 04:15:44 --> Form Validation Class Initialized
INFO - 2023-06-04 04:15:44 --> Controller Class Initialized
INFO - 2023-06-04 04:15:44 --> Model Class Initialized
DEBUG - 2023-06-04 04:15:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:15:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:15:44 --> Model Class Initialized
INFO - 2023-06-04 04:15:44 --> Final output sent to browser
DEBUG - 2023-06-04 04:15:44 --> Total execution time: 0.0273
ERROR - 2023-06-04 04:15:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:15:52 --> Config Class Initialized
INFO - 2023-06-04 04:15:52 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:15:52 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:15:52 --> Utf8 Class Initialized
INFO - 2023-06-04 04:15:52 --> URI Class Initialized
INFO - 2023-06-04 04:15:52 --> Router Class Initialized
INFO - 2023-06-04 04:15:52 --> Output Class Initialized
INFO - 2023-06-04 04:15:52 --> Security Class Initialized
DEBUG - 2023-06-04 04:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:15:52 --> Input Class Initialized
INFO - 2023-06-04 04:15:52 --> Language Class Initialized
INFO - 2023-06-04 04:15:52 --> Loader Class Initialized
INFO - 2023-06-04 04:15:52 --> Helper loaded: url_helper
INFO - 2023-06-04 04:15:52 --> Helper loaded: file_helper
INFO - 2023-06-04 04:15:52 --> Helper loaded: html_helper
INFO - 2023-06-04 04:15:52 --> Helper loaded: text_helper
INFO - 2023-06-04 04:15:52 --> Helper loaded: form_helper
INFO - 2023-06-04 04:15:52 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:15:52 --> Helper loaded: security_helper
INFO - 2023-06-04 04:15:52 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:15:52 --> Database Driver Class Initialized
INFO - 2023-06-04 04:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:15:52 --> Parser Class Initialized
INFO - 2023-06-04 04:15:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:15:52 --> Pagination Class Initialized
INFO - 2023-06-04 04:15:52 --> Form Validation Class Initialized
INFO - 2023-06-04 04:15:52 --> Controller Class Initialized
INFO - 2023-06-04 04:15:52 --> Model Class Initialized
DEBUG - 2023-06-04 04:15:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:15:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:15:52 --> Model Class Initialized
DEBUG - 2023-06-04 04:15:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:15:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-06-04 04:15:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:15:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:15:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:15:52 --> Model Class Initialized
INFO - 2023-06-04 04:15:52 --> Model Class Initialized
INFO - 2023-06-04 04:15:52 --> Model Class Initialized
INFO - 2023-06-04 04:15:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:15:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:15:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:15:52 --> Final output sent to browser
DEBUG - 2023-06-04 04:15:52 --> Total execution time: 0.0762
ERROR - 2023-06-04 04:16:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:16:19 --> Config Class Initialized
INFO - 2023-06-04 04:16:19 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:16:19 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:16:19 --> Utf8 Class Initialized
INFO - 2023-06-04 04:16:19 --> URI Class Initialized
INFO - 2023-06-04 04:16:19 --> Router Class Initialized
INFO - 2023-06-04 04:16:19 --> Output Class Initialized
INFO - 2023-06-04 04:16:19 --> Security Class Initialized
DEBUG - 2023-06-04 04:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:16:19 --> Input Class Initialized
INFO - 2023-06-04 04:16:19 --> Language Class Initialized
INFO - 2023-06-04 04:16:19 --> Loader Class Initialized
INFO - 2023-06-04 04:16:19 --> Helper loaded: url_helper
INFO - 2023-06-04 04:16:19 --> Helper loaded: file_helper
INFO - 2023-06-04 04:16:19 --> Helper loaded: html_helper
INFO - 2023-06-04 04:16:19 --> Helper loaded: text_helper
INFO - 2023-06-04 04:16:19 --> Helper loaded: form_helper
INFO - 2023-06-04 04:16:19 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:16:19 --> Helper loaded: security_helper
INFO - 2023-06-04 04:16:19 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:16:19 --> Database Driver Class Initialized
INFO - 2023-06-04 04:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:16:19 --> Parser Class Initialized
INFO - 2023-06-04 04:16:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:16:19 --> Pagination Class Initialized
INFO - 2023-06-04 04:16:19 --> Form Validation Class Initialized
INFO - 2023-06-04 04:16:19 --> Controller Class Initialized
INFO - 2023-06-04 04:16:19 --> Model Class Initialized
DEBUG - 2023-06-04 04:16:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:16:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:16:19 --> Model Class Initialized
INFO - 2023-06-04 04:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-06-04 04:16:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:16:19 --> Model Class Initialized
INFO - 2023-06-04 04:16:19 --> Model Class Initialized
INFO - 2023-06-04 04:16:19 --> Model Class Initialized
INFO - 2023-06-04 04:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:16:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:16:19 --> Final output sent to browser
DEBUG - 2023-06-04 04:16:19 --> Total execution time: 0.0746
ERROR - 2023-06-04 04:16:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:16:20 --> Config Class Initialized
INFO - 2023-06-04 04:16:20 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:16:20 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:16:20 --> Utf8 Class Initialized
INFO - 2023-06-04 04:16:20 --> URI Class Initialized
INFO - 2023-06-04 04:16:20 --> Router Class Initialized
INFO - 2023-06-04 04:16:20 --> Output Class Initialized
INFO - 2023-06-04 04:16:20 --> Security Class Initialized
DEBUG - 2023-06-04 04:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:16:20 --> Input Class Initialized
INFO - 2023-06-04 04:16:20 --> Language Class Initialized
INFO - 2023-06-04 04:16:20 --> Loader Class Initialized
INFO - 2023-06-04 04:16:20 --> Helper loaded: url_helper
INFO - 2023-06-04 04:16:20 --> Helper loaded: file_helper
INFO - 2023-06-04 04:16:20 --> Helper loaded: html_helper
INFO - 2023-06-04 04:16:20 --> Helper loaded: text_helper
INFO - 2023-06-04 04:16:20 --> Helper loaded: form_helper
INFO - 2023-06-04 04:16:20 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:16:20 --> Helper loaded: security_helper
INFO - 2023-06-04 04:16:20 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:16:20 --> Database Driver Class Initialized
INFO - 2023-06-04 04:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:16:20 --> Parser Class Initialized
INFO - 2023-06-04 04:16:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:16:20 --> Pagination Class Initialized
INFO - 2023-06-04 04:16:20 --> Form Validation Class Initialized
INFO - 2023-06-04 04:16:20 --> Controller Class Initialized
INFO - 2023-06-04 04:16:20 --> Model Class Initialized
DEBUG - 2023-06-04 04:16:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:16:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:16:20 --> Model Class Initialized
INFO - 2023-06-04 04:16:20 --> Final output sent to browser
DEBUG - 2023-06-04 04:16:20 --> Total execution time: 0.0283
ERROR - 2023-06-04 04:16:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:16:24 --> Config Class Initialized
INFO - 2023-06-04 04:16:24 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:16:24 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:16:24 --> Utf8 Class Initialized
INFO - 2023-06-04 04:16:24 --> URI Class Initialized
INFO - 2023-06-04 04:16:24 --> Router Class Initialized
INFO - 2023-06-04 04:16:24 --> Output Class Initialized
INFO - 2023-06-04 04:16:24 --> Security Class Initialized
DEBUG - 2023-06-04 04:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:16:24 --> Input Class Initialized
INFO - 2023-06-04 04:16:24 --> Language Class Initialized
INFO - 2023-06-04 04:16:24 --> Loader Class Initialized
INFO - 2023-06-04 04:16:24 --> Helper loaded: url_helper
INFO - 2023-06-04 04:16:24 --> Helper loaded: file_helper
INFO - 2023-06-04 04:16:24 --> Helper loaded: html_helper
INFO - 2023-06-04 04:16:24 --> Helper loaded: text_helper
INFO - 2023-06-04 04:16:24 --> Helper loaded: form_helper
INFO - 2023-06-04 04:16:24 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:16:24 --> Helper loaded: security_helper
INFO - 2023-06-04 04:16:24 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:16:24 --> Database Driver Class Initialized
INFO - 2023-06-04 04:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:16:24 --> Parser Class Initialized
INFO - 2023-06-04 04:16:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:16:24 --> Pagination Class Initialized
INFO - 2023-06-04 04:16:24 --> Form Validation Class Initialized
INFO - 2023-06-04 04:16:24 --> Controller Class Initialized
INFO - 2023-06-04 04:16:24 --> Model Class Initialized
DEBUG - 2023-06-04 04:16:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:16:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:16:24 --> Model Class Initialized
INFO - 2023-06-04 04:16:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-06-04 04:16:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:16:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:16:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:16:24 --> Model Class Initialized
INFO - 2023-06-04 04:16:24 --> Model Class Initialized
INFO - 2023-06-04 04:16:24 --> Model Class Initialized
INFO - 2023-06-04 04:16:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:16:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:16:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:16:24 --> Final output sent to browser
DEBUG - 2023-06-04 04:16:24 --> Total execution time: 0.0750
ERROR - 2023-06-04 04:16:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:16:25 --> Config Class Initialized
INFO - 2023-06-04 04:16:25 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:16:25 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:16:25 --> Utf8 Class Initialized
INFO - 2023-06-04 04:16:25 --> URI Class Initialized
INFO - 2023-06-04 04:16:25 --> Router Class Initialized
INFO - 2023-06-04 04:16:25 --> Output Class Initialized
INFO - 2023-06-04 04:16:25 --> Security Class Initialized
DEBUG - 2023-06-04 04:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:16:25 --> Input Class Initialized
INFO - 2023-06-04 04:16:25 --> Language Class Initialized
INFO - 2023-06-04 04:16:25 --> Loader Class Initialized
INFO - 2023-06-04 04:16:25 --> Helper loaded: url_helper
INFO - 2023-06-04 04:16:25 --> Helper loaded: file_helper
INFO - 2023-06-04 04:16:25 --> Helper loaded: html_helper
INFO - 2023-06-04 04:16:25 --> Helper loaded: text_helper
INFO - 2023-06-04 04:16:25 --> Helper loaded: form_helper
INFO - 2023-06-04 04:16:25 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:16:25 --> Helper loaded: security_helper
INFO - 2023-06-04 04:16:25 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:16:25 --> Database Driver Class Initialized
INFO - 2023-06-04 04:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:16:25 --> Parser Class Initialized
INFO - 2023-06-04 04:16:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:16:25 --> Pagination Class Initialized
INFO - 2023-06-04 04:16:25 --> Form Validation Class Initialized
INFO - 2023-06-04 04:16:25 --> Controller Class Initialized
INFO - 2023-06-04 04:16:25 --> Model Class Initialized
DEBUG - 2023-06-04 04:16:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:16:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:16:25 --> Model Class Initialized
INFO - 2023-06-04 04:16:25 --> Final output sent to browser
DEBUG - 2023-06-04 04:16:25 --> Total execution time: 0.0291
ERROR - 2023-06-04 04:16:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:16:26 --> Config Class Initialized
INFO - 2023-06-04 04:16:26 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:16:26 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:16:26 --> Utf8 Class Initialized
INFO - 2023-06-04 04:16:26 --> URI Class Initialized
INFO - 2023-06-04 04:16:26 --> Router Class Initialized
INFO - 2023-06-04 04:16:26 --> Output Class Initialized
INFO - 2023-06-04 04:16:26 --> Security Class Initialized
DEBUG - 2023-06-04 04:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:16:26 --> Input Class Initialized
INFO - 2023-06-04 04:16:26 --> Language Class Initialized
INFO - 2023-06-04 04:16:26 --> Loader Class Initialized
INFO - 2023-06-04 04:16:26 --> Helper loaded: url_helper
INFO - 2023-06-04 04:16:26 --> Helper loaded: file_helper
INFO - 2023-06-04 04:16:26 --> Helper loaded: html_helper
INFO - 2023-06-04 04:16:26 --> Helper loaded: text_helper
INFO - 2023-06-04 04:16:26 --> Helper loaded: form_helper
INFO - 2023-06-04 04:16:26 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:16:26 --> Helper loaded: security_helper
INFO - 2023-06-04 04:16:26 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:16:26 --> Database Driver Class Initialized
INFO - 2023-06-04 04:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:16:26 --> Parser Class Initialized
INFO - 2023-06-04 04:16:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:16:26 --> Pagination Class Initialized
INFO - 2023-06-04 04:16:26 --> Form Validation Class Initialized
INFO - 2023-06-04 04:16:26 --> Controller Class Initialized
INFO - 2023-06-04 04:16:26 --> Model Class Initialized
DEBUG - 2023-06-04 04:16:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:16:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:16:26 --> Model Class Initialized
INFO - 2023-06-04 04:16:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/upcoming.php
DEBUG - 2023-06-04 04:16:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:16:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:16:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:16:26 --> Model Class Initialized
INFO - 2023-06-04 04:16:26 --> Model Class Initialized
INFO - 2023-06-04 04:16:26 --> Model Class Initialized
INFO - 2023-06-04 04:16:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:16:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:16:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:16:26 --> Final output sent to browser
DEBUG - 2023-06-04 04:16:26 --> Total execution time: 0.0628
ERROR - 2023-06-04 04:16:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:16:27 --> Config Class Initialized
INFO - 2023-06-04 04:16:27 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:16:27 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:16:27 --> Utf8 Class Initialized
INFO - 2023-06-04 04:16:27 --> URI Class Initialized
INFO - 2023-06-04 04:16:27 --> Router Class Initialized
INFO - 2023-06-04 04:16:27 --> Output Class Initialized
INFO - 2023-06-04 04:16:27 --> Security Class Initialized
DEBUG - 2023-06-04 04:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:16:27 --> Input Class Initialized
INFO - 2023-06-04 04:16:27 --> Language Class Initialized
INFO - 2023-06-04 04:16:27 --> Loader Class Initialized
INFO - 2023-06-04 04:16:27 --> Helper loaded: url_helper
INFO - 2023-06-04 04:16:27 --> Helper loaded: file_helper
INFO - 2023-06-04 04:16:27 --> Helper loaded: html_helper
INFO - 2023-06-04 04:16:27 --> Helper loaded: text_helper
INFO - 2023-06-04 04:16:27 --> Helper loaded: form_helper
INFO - 2023-06-04 04:16:27 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:16:27 --> Helper loaded: security_helper
INFO - 2023-06-04 04:16:27 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:16:27 --> Database Driver Class Initialized
INFO - 2023-06-04 04:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:16:27 --> Parser Class Initialized
INFO - 2023-06-04 04:16:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:16:27 --> Pagination Class Initialized
INFO - 2023-06-04 04:16:27 --> Form Validation Class Initialized
INFO - 2023-06-04 04:16:27 --> Controller Class Initialized
INFO - 2023-06-04 04:16:27 --> Model Class Initialized
DEBUG - 2023-06-04 04:16:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:16:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:16:27 --> Model Class Initialized
INFO - 2023-06-04 04:16:27 --> Final output sent to browser
DEBUG - 2023-06-04 04:16:27 --> Total execution time: 0.0175
ERROR - 2023-06-04 04:16:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:16:27 --> Config Class Initialized
INFO - 2023-06-04 04:16:27 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:16:27 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:16:27 --> Utf8 Class Initialized
INFO - 2023-06-04 04:16:27 --> URI Class Initialized
INFO - 2023-06-04 04:16:27 --> Router Class Initialized
INFO - 2023-06-04 04:16:27 --> Output Class Initialized
INFO - 2023-06-04 04:16:27 --> Security Class Initialized
DEBUG - 2023-06-04 04:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:16:27 --> Input Class Initialized
INFO - 2023-06-04 04:16:27 --> Language Class Initialized
INFO - 2023-06-04 04:16:27 --> Loader Class Initialized
INFO - 2023-06-04 04:16:27 --> Helper loaded: url_helper
INFO - 2023-06-04 04:16:27 --> Helper loaded: file_helper
INFO - 2023-06-04 04:16:27 --> Helper loaded: html_helper
INFO - 2023-06-04 04:16:27 --> Helper loaded: text_helper
INFO - 2023-06-04 04:16:27 --> Helper loaded: form_helper
INFO - 2023-06-04 04:16:27 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:16:27 --> Helper loaded: security_helper
INFO - 2023-06-04 04:16:27 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:16:27 --> Database Driver Class Initialized
INFO - 2023-06-04 04:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:16:27 --> Parser Class Initialized
INFO - 2023-06-04 04:16:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:16:27 --> Pagination Class Initialized
INFO - 2023-06-04 04:16:27 --> Form Validation Class Initialized
INFO - 2023-06-04 04:16:27 --> Controller Class Initialized
INFO - 2023-06-04 04:16:27 --> Model Class Initialized
DEBUG - 2023-06-04 04:16:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:16:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:16:27 --> Model Class Initialized
INFO - 2023-06-04 04:16:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-06-04 04:16:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:16:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:16:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:16:27 --> Model Class Initialized
INFO - 2023-06-04 04:16:27 --> Model Class Initialized
INFO - 2023-06-04 04:16:27 --> Model Class Initialized
INFO - 2023-06-04 04:16:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:16:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:16:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:16:27 --> Final output sent to browser
DEBUG - 2023-06-04 04:16:27 --> Total execution time: 0.0722
ERROR - 2023-06-04 04:16:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:16:28 --> Config Class Initialized
INFO - 2023-06-04 04:16:28 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:16:28 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:16:28 --> Utf8 Class Initialized
INFO - 2023-06-04 04:16:28 --> URI Class Initialized
INFO - 2023-06-04 04:16:28 --> Router Class Initialized
INFO - 2023-06-04 04:16:28 --> Output Class Initialized
INFO - 2023-06-04 04:16:28 --> Security Class Initialized
DEBUG - 2023-06-04 04:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:16:28 --> Input Class Initialized
INFO - 2023-06-04 04:16:28 --> Language Class Initialized
INFO - 2023-06-04 04:16:28 --> Loader Class Initialized
INFO - 2023-06-04 04:16:28 --> Helper loaded: url_helper
INFO - 2023-06-04 04:16:28 --> Helper loaded: file_helper
INFO - 2023-06-04 04:16:28 --> Helper loaded: html_helper
INFO - 2023-06-04 04:16:28 --> Helper loaded: text_helper
INFO - 2023-06-04 04:16:28 --> Helper loaded: form_helper
INFO - 2023-06-04 04:16:28 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:16:28 --> Helper loaded: security_helper
INFO - 2023-06-04 04:16:28 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:16:28 --> Database Driver Class Initialized
INFO - 2023-06-04 04:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:16:28 --> Parser Class Initialized
INFO - 2023-06-04 04:16:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:16:28 --> Pagination Class Initialized
INFO - 2023-06-04 04:16:28 --> Form Validation Class Initialized
INFO - 2023-06-04 04:16:28 --> Controller Class Initialized
INFO - 2023-06-04 04:16:28 --> Model Class Initialized
DEBUG - 2023-06-04 04:16:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:16:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:16:28 --> Model Class Initialized
INFO - 2023-06-04 04:16:28 --> Final output sent to browser
DEBUG - 2023-06-04 04:16:28 --> Total execution time: 0.0254
ERROR - 2023-06-04 04:16:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:16:28 --> Config Class Initialized
INFO - 2023-06-04 04:16:28 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:16:28 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:16:28 --> Utf8 Class Initialized
INFO - 2023-06-04 04:16:28 --> URI Class Initialized
DEBUG - 2023-06-04 04:16:28 --> No URI present. Default controller set.
INFO - 2023-06-04 04:16:28 --> Router Class Initialized
INFO - 2023-06-04 04:16:28 --> Output Class Initialized
INFO - 2023-06-04 04:16:28 --> Security Class Initialized
DEBUG - 2023-06-04 04:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:16:28 --> Input Class Initialized
INFO - 2023-06-04 04:16:28 --> Language Class Initialized
INFO - 2023-06-04 04:16:28 --> Loader Class Initialized
INFO - 2023-06-04 04:16:28 --> Helper loaded: url_helper
INFO - 2023-06-04 04:16:28 --> Helper loaded: file_helper
INFO - 2023-06-04 04:16:28 --> Helper loaded: html_helper
INFO - 2023-06-04 04:16:28 --> Helper loaded: text_helper
INFO - 2023-06-04 04:16:28 --> Helper loaded: form_helper
INFO - 2023-06-04 04:16:28 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:16:28 --> Helper loaded: security_helper
INFO - 2023-06-04 04:16:28 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:16:28 --> Database Driver Class Initialized
INFO - 2023-06-04 04:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:16:28 --> Parser Class Initialized
INFO - 2023-06-04 04:16:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:16:28 --> Pagination Class Initialized
INFO - 2023-06-04 04:16:28 --> Form Validation Class Initialized
INFO - 2023-06-04 04:16:28 --> Controller Class Initialized
INFO - 2023-06-04 04:16:28 --> Model Class Initialized
DEBUG - 2023-06-04 04:16:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:16:28 --> Model Class Initialized
DEBUG - 2023-06-04 04:16:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:16:28 --> Model Class Initialized
INFO - 2023-06-04 04:16:28 --> Model Class Initialized
INFO - 2023-06-04 04:16:28 --> Model Class Initialized
INFO - 2023-06-04 04:16:28 --> Model Class Initialized
DEBUG - 2023-06-04 04:16:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:16:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:16:28 --> Model Class Initialized
INFO - 2023-06-04 04:16:28 --> Model Class Initialized
INFO - 2023-06-04 04:16:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-04 04:16:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:16:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:16:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:16:28 --> Model Class Initialized
INFO - 2023-06-04 04:16:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:16:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:16:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:16:28 --> Final output sent to browser
DEBUG - 2023-06-04 04:16:28 --> Total execution time: 0.0807
ERROR - 2023-06-04 04:16:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:16:41 --> Config Class Initialized
INFO - 2023-06-04 04:16:41 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:16:41 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:16:41 --> Utf8 Class Initialized
INFO - 2023-06-04 04:16:41 --> URI Class Initialized
INFO - 2023-06-04 04:16:41 --> Router Class Initialized
INFO - 2023-06-04 04:16:41 --> Output Class Initialized
INFO - 2023-06-04 04:16:41 --> Security Class Initialized
DEBUG - 2023-06-04 04:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:16:41 --> Input Class Initialized
INFO - 2023-06-04 04:16:41 --> Language Class Initialized
INFO - 2023-06-04 04:16:41 --> Loader Class Initialized
INFO - 2023-06-04 04:16:41 --> Helper loaded: url_helper
INFO - 2023-06-04 04:16:41 --> Helper loaded: file_helper
INFO - 2023-06-04 04:16:41 --> Helper loaded: html_helper
INFO - 2023-06-04 04:16:41 --> Helper loaded: text_helper
INFO - 2023-06-04 04:16:41 --> Helper loaded: form_helper
INFO - 2023-06-04 04:16:41 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:16:41 --> Helper loaded: security_helper
INFO - 2023-06-04 04:16:41 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:16:41 --> Database Driver Class Initialized
INFO - 2023-06-04 04:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:16:41 --> Parser Class Initialized
INFO - 2023-06-04 04:16:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:16:41 --> Pagination Class Initialized
INFO - 2023-06-04 04:16:41 --> Form Validation Class Initialized
INFO - 2023-06-04 04:16:41 --> Controller Class Initialized
INFO - 2023-06-04 04:16:41 --> Model Class Initialized
DEBUG - 2023-06-04 04:16:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:16:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:16:41 --> Model Class Initialized
DEBUG - 2023-06-04 04:16:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:16:41 --> Model Class Initialized
INFO - 2023-06-04 04:16:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-04 04:16:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:16:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:16:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:16:41 --> Model Class Initialized
INFO - 2023-06-04 04:16:41 --> Model Class Initialized
INFO - 2023-06-04 04:16:41 --> Model Class Initialized
INFO - 2023-06-04 04:16:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:16:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:16:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:16:41 --> Final output sent to browser
DEBUG - 2023-06-04 04:16:41 --> Total execution time: 0.0733
ERROR - 2023-06-04 04:16:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:16:42 --> Config Class Initialized
INFO - 2023-06-04 04:16:42 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:16:42 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:16:42 --> Utf8 Class Initialized
INFO - 2023-06-04 04:16:42 --> URI Class Initialized
INFO - 2023-06-04 04:16:42 --> Router Class Initialized
INFO - 2023-06-04 04:16:42 --> Output Class Initialized
INFO - 2023-06-04 04:16:42 --> Security Class Initialized
DEBUG - 2023-06-04 04:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:16:42 --> Input Class Initialized
INFO - 2023-06-04 04:16:42 --> Language Class Initialized
INFO - 2023-06-04 04:16:42 --> Loader Class Initialized
INFO - 2023-06-04 04:16:42 --> Helper loaded: url_helper
INFO - 2023-06-04 04:16:42 --> Helper loaded: file_helper
INFO - 2023-06-04 04:16:42 --> Helper loaded: html_helper
INFO - 2023-06-04 04:16:42 --> Helper loaded: text_helper
INFO - 2023-06-04 04:16:42 --> Helper loaded: form_helper
INFO - 2023-06-04 04:16:42 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:16:42 --> Helper loaded: security_helper
INFO - 2023-06-04 04:16:42 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:16:42 --> Database Driver Class Initialized
INFO - 2023-06-04 04:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:16:42 --> Parser Class Initialized
INFO - 2023-06-04 04:16:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:16:42 --> Pagination Class Initialized
INFO - 2023-06-04 04:16:42 --> Form Validation Class Initialized
INFO - 2023-06-04 04:16:42 --> Controller Class Initialized
INFO - 2023-06-04 04:16:42 --> Model Class Initialized
DEBUG - 2023-06-04 04:16:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:16:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:16:42 --> Model Class Initialized
DEBUG - 2023-06-04 04:16:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:16:42 --> Model Class Initialized
INFO - 2023-06-04 04:16:42 --> Final output sent to browser
DEBUG - 2023-06-04 04:16:42 --> Total execution time: 0.0387
ERROR - 2023-06-04 04:17:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:17:27 --> Config Class Initialized
INFO - 2023-06-04 04:17:27 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:17:27 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:17:27 --> Utf8 Class Initialized
INFO - 2023-06-04 04:17:27 --> URI Class Initialized
DEBUG - 2023-06-04 04:17:27 --> No URI present. Default controller set.
INFO - 2023-06-04 04:17:27 --> Router Class Initialized
INFO - 2023-06-04 04:17:27 --> Output Class Initialized
INFO - 2023-06-04 04:17:27 --> Security Class Initialized
DEBUG - 2023-06-04 04:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:17:27 --> Input Class Initialized
INFO - 2023-06-04 04:17:27 --> Language Class Initialized
INFO - 2023-06-04 04:17:27 --> Loader Class Initialized
INFO - 2023-06-04 04:17:27 --> Helper loaded: url_helper
INFO - 2023-06-04 04:17:27 --> Helper loaded: file_helper
INFO - 2023-06-04 04:17:27 --> Helper loaded: html_helper
INFO - 2023-06-04 04:17:27 --> Helper loaded: text_helper
INFO - 2023-06-04 04:17:27 --> Helper loaded: form_helper
INFO - 2023-06-04 04:17:27 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:17:27 --> Helper loaded: security_helper
INFO - 2023-06-04 04:17:27 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:17:27 --> Database Driver Class Initialized
INFO - 2023-06-04 04:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:17:27 --> Parser Class Initialized
INFO - 2023-06-04 04:17:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:17:27 --> Pagination Class Initialized
INFO - 2023-06-04 04:17:27 --> Form Validation Class Initialized
INFO - 2023-06-04 04:17:27 --> Controller Class Initialized
INFO - 2023-06-04 04:17:27 --> Model Class Initialized
DEBUG - 2023-06-04 04:17:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:17:27 --> Model Class Initialized
DEBUG - 2023-06-04 04:17:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:17:27 --> Model Class Initialized
INFO - 2023-06-04 04:17:27 --> Model Class Initialized
INFO - 2023-06-04 04:17:27 --> Model Class Initialized
INFO - 2023-06-04 04:17:27 --> Model Class Initialized
DEBUG - 2023-06-04 04:17:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:17:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:17:27 --> Model Class Initialized
INFO - 2023-06-04 04:17:27 --> Model Class Initialized
INFO - 2023-06-04 04:17:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-04 04:17:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:17:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:17:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:17:27 --> Model Class Initialized
INFO - 2023-06-04 04:17:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:17:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:17:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:17:27 --> Final output sent to browser
DEBUG - 2023-06-04 04:17:27 --> Total execution time: 0.0804
ERROR - 2023-06-04 04:17:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:17:29 --> Config Class Initialized
INFO - 2023-06-04 04:17:29 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:17:29 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:17:29 --> Utf8 Class Initialized
INFO - 2023-06-04 04:17:29 --> URI Class Initialized
INFO - 2023-06-04 04:17:29 --> Router Class Initialized
INFO - 2023-06-04 04:17:29 --> Output Class Initialized
INFO - 2023-06-04 04:17:29 --> Security Class Initialized
DEBUG - 2023-06-04 04:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:17:29 --> Input Class Initialized
INFO - 2023-06-04 04:17:29 --> Language Class Initialized
INFO - 2023-06-04 04:17:29 --> Loader Class Initialized
INFO - 2023-06-04 04:17:29 --> Helper loaded: url_helper
INFO - 2023-06-04 04:17:29 --> Helper loaded: file_helper
INFO - 2023-06-04 04:17:29 --> Helper loaded: html_helper
INFO - 2023-06-04 04:17:29 --> Helper loaded: text_helper
INFO - 2023-06-04 04:17:29 --> Helper loaded: form_helper
INFO - 2023-06-04 04:17:29 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:17:29 --> Helper loaded: security_helper
INFO - 2023-06-04 04:17:29 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:17:29 --> Database Driver Class Initialized
INFO - 2023-06-04 04:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:17:29 --> Parser Class Initialized
INFO - 2023-06-04 04:17:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:17:29 --> Pagination Class Initialized
INFO - 2023-06-04 04:17:29 --> Form Validation Class Initialized
INFO - 2023-06-04 04:17:29 --> Controller Class Initialized
INFO - 2023-06-04 04:17:29 --> Model Class Initialized
DEBUG - 2023-06-04 04:17:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:17:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:17:29 --> Model Class Initialized
DEBUG - 2023-06-04 04:17:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:17:29 --> Model Class Initialized
INFO - 2023-06-04 04:17:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-04 04:17:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:17:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:17:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:17:29 --> Model Class Initialized
INFO - 2023-06-04 04:17:29 --> Model Class Initialized
INFO - 2023-06-04 04:17:29 --> Model Class Initialized
INFO - 2023-06-04 04:17:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:17:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:17:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:17:29 --> Final output sent to browser
DEBUG - 2023-06-04 04:17:29 --> Total execution time: 0.0851
ERROR - 2023-06-04 04:17:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:17:30 --> Config Class Initialized
INFO - 2023-06-04 04:17:30 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:17:30 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:17:30 --> Utf8 Class Initialized
INFO - 2023-06-04 04:17:30 --> URI Class Initialized
INFO - 2023-06-04 04:17:30 --> Router Class Initialized
INFO - 2023-06-04 04:17:30 --> Output Class Initialized
INFO - 2023-06-04 04:17:30 --> Security Class Initialized
DEBUG - 2023-06-04 04:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:17:30 --> Input Class Initialized
INFO - 2023-06-04 04:17:30 --> Language Class Initialized
INFO - 2023-06-04 04:17:30 --> Loader Class Initialized
INFO - 2023-06-04 04:17:30 --> Helper loaded: url_helper
INFO - 2023-06-04 04:17:30 --> Helper loaded: file_helper
INFO - 2023-06-04 04:17:30 --> Helper loaded: html_helper
INFO - 2023-06-04 04:17:30 --> Helper loaded: text_helper
INFO - 2023-06-04 04:17:30 --> Helper loaded: form_helper
INFO - 2023-06-04 04:17:30 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:17:30 --> Helper loaded: security_helper
INFO - 2023-06-04 04:17:30 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:17:30 --> Database Driver Class Initialized
INFO - 2023-06-04 04:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:17:30 --> Parser Class Initialized
INFO - 2023-06-04 04:17:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:17:30 --> Pagination Class Initialized
INFO - 2023-06-04 04:17:30 --> Form Validation Class Initialized
INFO - 2023-06-04 04:17:30 --> Controller Class Initialized
INFO - 2023-06-04 04:17:30 --> Model Class Initialized
DEBUG - 2023-06-04 04:17:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:17:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:17:30 --> Model Class Initialized
DEBUG - 2023-06-04 04:17:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:17:30 --> Model Class Initialized
INFO - 2023-06-04 04:17:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-04 04:17:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:17:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:17:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:17:30 --> Model Class Initialized
INFO - 2023-06-04 04:17:30 --> Model Class Initialized
INFO - 2023-06-04 04:17:30 --> Model Class Initialized
INFO - 2023-06-04 04:17:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:17:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:17:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:17:30 --> Final output sent to browser
DEBUG - 2023-06-04 04:17:30 --> Total execution time: 0.0701
ERROR - 2023-06-04 04:17:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:17:30 --> Config Class Initialized
INFO - 2023-06-04 04:17:30 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:17:30 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:17:30 --> Utf8 Class Initialized
INFO - 2023-06-04 04:17:30 --> URI Class Initialized
INFO - 2023-06-04 04:17:30 --> Router Class Initialized
INFO - 2023-06-04 04:17:30 --> Output Class Initialized
INFO - 2023-06-04 04:17:30 --> Security Class Initialized
DEBUG - 2023-06-04 04:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:17:30 --> Input Class Initialized
INFO - 2023-06-04 04:17:30 --> Language Class Initialized
INFO - 2023-06-04 04:17:30 --> Loader Class Initialized
INFO - 2023-06-04 04:17:30 --> Helper loaded: url_helper
INFO - 2023-06-04 04:17:30 --> Helper loaded: file_helper
INFO - 2023-06-04 04:17:30 --> Helper loaded: html_helper
INFO - 2023-06-04 04:17:30 --> Helper loaded: text_helper
INFO - 2023-06-04 04:17:30 --> Helper loaded: form_helper
INFO - 2023-06-04 04:17:30 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:17:30 --> Helper loaded: security_helper
INFO - 2023-06-04 04:17:30 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:17:30 --> Database Driver Class Initialized
INFO - 2023-06-04 04:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:17:30 --> Parser Class Initialized
INFO - 2023-06-04 04:17:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:17:30 --> Pagination Class Initialized
INFO - 2023-06-04 04:17:30 --> Form Validation Class Initialized
INFO - 2023-06-04 04:17:30 --> Controller Class Initialized
INFO - 2023-06-04 04:17:30 --> Model Class Initialized
DEBUG - 2023-06-04 04:17:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:17:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:17:30 --> Model Class Initialized
DEBUG - 2023-06-04 04:17:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:17:30 --> Model Class Initialized
INFO - 2023-06-04 04:17:30 --> Final output sent to browser
DEBUG - 2023-06-04 04:17:30 --> Total execution time: 0.0421
ERROR - 2023-06-04 04:17:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:17:49 --> Config Class Initialized
INFO - 2023-06-04 04:17:49 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:17:49 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:17:49 --> Utf8 Class Initialized
INFO - 2023-06-04 04:17:49 --> URI Class Initialized
INFO - 2023-06-04 04:17:49 --> Router Class Initialized
INFO - 2023-06-04 04:17:49 --> Output Class Initialized
INFO - 2023-06-04 04:17:49 --> Security Class Initialized
DEBUG - 2023-06-04 04:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:17:49 --> Input Class Initialized
INFO - 2023-06-04 04:17:49 --> Language Class Initialized
INFO - 2023-06-04 04:17:49 --> Loader Class Initialized
INFO - 2023-06-04 04:17:49 --> Helper loaded: url_helper
INFO - 2023-06-04 04:17:49 --> Helper loaded: file_helper
INFO - 2023-06-04 04:17:49 --> Helper loaded: html_helper
INFO - 2023-06-04 04:17:49 --> Helper loaded: text_helper
INFO - 2023-06-04 04:17:49 --> Helper loaded: form_helper
INFO - 2023-06-04 04:17:49 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:17:49 --> Helper loaded: security_helper
INFO - 2023-06-04 04:17:49 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:17:49 --> Database Driver Class Initialized
INFO - 2023-06-04 04:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:17:49 --> Parser Class Initialized
INFO - 2023-06-04 04:17:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:17:49 --> Pagination Class Initialized
INFO - 2023-06-04 04:17:49 --> Form Validation Class Initialized
INFO - 2023-06-04 04:17:49 --> Controller Class Initialized
INFO - 2023-06-04 04:17:49 --> Model Class Initialized
DEBUG - 2023-06-04 04:17:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:17:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:17:49 --> Model Class Initialized
DEBUG - 2023-06-04 04:17:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:17:49 --> Model Class Initialized
INFO - 2023-06-04 04:17:49 --> Final output sent to browser
DEBUG - 2023-06-04 04:17:49 --> Total execution time: 0.0420
ERROR - 2023-06-04 04:17:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:17:52 --> Config Class Initialized
INFO - 2023-06-04 04:17:52 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:17:52 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:17:52 --> Utf8 Class Initialized
INFO - 2023-06-04 04:17:52 --> URI Class Initialized
INFO - 2023-06-04 04:17:52 --> Router Class Initialized
INFO - 2023-06-04 04:17:52 --> Output Class Initialized
INFO - 2023-06-04 04:17:52 --> Security Class Initialized
DEBUG - 2023-06-04 04:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:17:52 --> Input Class Initialized
INFO - 2023-06-04 04:17:52 --> Language Class Initialized
INFO - 2023-06-04 04:17:52 --> Loader Class Initialized
INFO - 2023-06-04 04:17:52 --> Helper loaded: url_helper
INFO - 2023-06-04 04:17:52 --> Helper loaded: file_helper
INFO - 2023-06-04 04:17:52 --> Helper loaded: html_helper
INFO - 2023-06-04 04:17:52 --> Helper loaded: text_helper
INFO - 2023-06-04 04:17:52 --> Helper loaded: form_helper
INFO - 2023-06-04 04:17:52 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:17:52 --> Helper loaded: security_helper
INFO - 2023-06-04 04:17:52 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:17:52 --> Database Driver Class Initialized
INFO - 2023-06-04 04:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:17:52 --> Parser Class Initialized
INFO - 2023-06-04 04:17:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:17:52 --> Pagination Class Initialized
INFO - 2023-06-04 04:17:52 --> Form Validation Class Initialized
INFO - 2023-06-04 04:17:52 --> Controller Class Initialized
INFO - 2023-06-04 04:17:52 --> Model Class Initialized
DEBUG - 2023-06-04 04:17:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:17:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:17:52 --> Model Class Initialized
DEBUG - 2023-06-04 04:17:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:17:52 --> Model Class Initialized
INFO - 2023-06-04 04:17:52 --> Final output sent to browser
DEBUG - 2023-06-04 04:17:52 --> Total execution time: 0.0397
ERROR - 2023-06-04 04:17:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:17:53 --> Config Class Initialized
INFO - 2023-06-04 04:17:53 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:17:53 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:17:53 --> Utf8 Class Initialized
INFO - 2023-06-04 04:17:53 --> URI Class Initialized
INFO - 2023-06-04 04:17:53 --> Router Class Initialized
INFO - 2023-06-04 04:17:53 --> Output Class Initialized
INFO - 2023-06-04 04:17:53 --> Security Class Initialized
DEBUG - 2023-06-04 04:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:17:53 --> Input Class Initialized
INFO - 2023-06-04 04:17:53 --> Language Class Initialized
INFO - 2023-06-04 04:17:53 --> Loader Class Initialized
INFO - 2023-06-04 04:17:53 --> Helper loaded: url_helper
INFO - 2023-06-04 04:17:53 --> Helper loaded: file_helper
INFO - 2023-06-04 04:17:53 --> Helper loaded: html_helper
INFO - 2023-06-04 04:17:53 --> Helper loaded: text_helper
INFO - 2023-06-04 04:17:53 --> Helper loaded: form_helper
INFO - 2023-06-04 04:17:53 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:17:53 --> Helper loaded: security_helper
INFO - 2023-06-04 04:17:53 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:17:53 --> Database Driver Class Initialized
INFO - 2023-06-04 04:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:17:53 --> Parser Class Initialized
INFO - 2023-06-04 04:17:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:17:53 --> Pagination Class Initialized
INFO - 2023-06-04 04:17:53 --> Form Validation Class Initialized
INFO - 2023-06-04 04:17:53 --> Controller Class Initialized
INFO - 2023-06-04 04:17:53 --> Model Class Initialized
DEBUG - 2023-06-04 04:17:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:17:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:17:53 --> Model Class Initialized
DEBUG - 2023-06-04 04:17:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:17:53 --> Model Class Initialized
INFO - 2023-06-04 04:17:53 --> Final output sent to browser
DEBUG - 2023-06-04 04:17:53 --> Total execution time: 0.0421
ERROR - 2023-06-04 04:17:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:17:54 --> Config Class Initialized
INFO - 2023-06-04 04:17:54 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:17:54 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:17:54 --> Utf8 Class Initialized
INFO - 2023-06-04 04:17:54 --> URI Class Initialized
INFO - 2023-06-04 04:17:54 --> Router Class Initialized
INFO - 2023-06-04 04:17:54 --> Output Class Initialized
INFO - 2023-06-04 04:17:54 --> Security Class Initialized
DEBUG - 2023-06-04 04:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:17:54 --> Input Class Initialized
INFO - 2023-06-04 04:17:54 --> Language Class Initialized
INFO - 2023-06-04 04:17:54 --> Loader Class Initialized
INFO - 2023-06-04 04:17:54 --> Helper loaded: url_helper
INFO - 2023-06-04 04:17:54 --> Helper loaded: file_helper
INFO - 2023-06-04 04:17:54 --> Helper loaded: html_helper
INFO - 2023-06-04 04:17:54 --> Helper loaded: text_helper
INFO - 2023-06-04 04:17:54 --> Helper loaded: form_helper
INFO - 2023-06-04 04:17:54 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:17:54 --> Helper loaded: security_helper
INFO - 2023-06-04 04:17:54 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:17:54 --> Database Driver Class Initialized
INFO - 2023-06-04 04:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:17:54 --> Parser Class Initialized
INFO - 2023-06-04 04:17:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:17:54 --> Pagination Class Initialized
INFO - 2023-06-04 04:17:54 --> Form Validation Class Initialized
INFO - 2023-06-04 04:17:54 --> Controller Class Initialized
INFO - 2023-06-04 04:17:54 --> Model Class Initialized
DEBUG - 2023-06-04 04:17:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:17:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:17:54 --> Model Class Initialized
DEBUG - 2023-06-04 04:17:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:17:54 --> Model Class Initialized
INFO - 2023-06-04 04:17:54 --> Final output sent to browser
DEBUG - 2023-06-04 04:17:54 --> Total execution time: 0.0390
ERROR - 2023-06-04 04:17:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:17:55 --> Config Class Initialized
INFO - 2023-06-04 04:17:55 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:17:55 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:17:55 --> Utf8 Class Initialized
INFO - 2023-06-04 04:17:55 --> URI Class Initialized
INFO - 2023-06-04 04:17:55 --> Router Class Initialized
INFO - 2023-06-04 04:17:55 --> Output Class Initialized
INFO - 2023-06-04 04:17:55 --> Security Class Initialized
DEBUG - 2023-06-04 04:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:17:55 --> Input Class Initialized
INFO - 2023-06-04 04:17:55 --> Language Class Initialized
INFO - 2023-06-04 04:17:55 --> Loader Class Initialized
INFO - 2023-06-04 04:17:55 --> Helper loaded: url_helper
INFO - 2023-06-04 04:17:55 --> Helper loaded: file_helper
INFO - 2023-06-04 04:17:55 --> Helper loaded: html_helper
INFO - 2023-06-04 04:17:55 --> Helper loaded: text_helper
INFO - 2023-06-04 04:17:55 --> Helper loaded: form_helper
INFO - 2023-06-04 04:17:55 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:17:55 --> Helper loaded: security_helper
INFO - 2023-06-04 04:17:55 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:17:55 --> Database Driver Class Initialized
INFO - 2023-06-04 04:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:17:55 --> Parser Class Initialized
INFO - 2023-06-04 04:17:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:17:55 --> Pagination Class Initialized
INFO - 2023-06-04 04:17:55 --> Form Validation Class Initialized
INFO - 2023-06-04 04:17:55 --> Controller Class Initialized
INFO - 2023-06-04 04:17:55 --> Model Class Initialized
DEBUG - 2023-06-04 04:17:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:17:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:17:55 --> Model Class Initialized
DEBUG - 2023-06-04 04:17:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:17:55 --> Model Class Initialized
INFO - 2023-06-04 04:17:55 --> Final output sent to browser
DEBUG - 2023-06-04 04:17:55 --> Total execution time: 0.0839
ERROR - 2023-06-04 04:17:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:17:56 --> Config Class Initialized
INFO - 2023-06-04 04:17:56 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:17:56 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:17:56 --> Utf8 Class Initialized
INFO - 2023-06-04 04:17:56 --> URI Class Initialized
INFO - 2023-06-04 04:17:56 --> Router Class Initialized
INFO - 2023-06-04 04:17:56 --> Output Class Initialized
INFO - 2023-06-04 04:17:56 --> Security Class Initialized
DEBUG - 2023-06-04 04:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:17:56 --> Input Class Initialized
INFO - 2023-06-04 04:17:56 --> Language Class Initialized
INFO - 2023-06-04 04:17:56 --> Loader Class Initialized
INFO - 2023-06-04 04:17:56 --> Helper loaded: url_helper
INFO - 2023-06-04 04:17:56 --> Helper loaded: file_helper
INFO - 2023-06-04 04:17:56 --> Helper loaded: html_helper
INFO - 2023-06-04 04:17:56 --> Helper loaded: text_helper
INFO - 2023-06-04 04:17:56 --> Helper loaded: form_helper
INFO - 2023-06-04 04:17:56 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:17:56 --> Helper loaded: security_helper
INFO - 2023-06-04 04:17:56 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:17:56 --> Database Driver Class Initialized
INFO - 2023-06-04 04:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:17:56 --> Parser Class Initialized
INFO - 2023-06-04 04:17:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:17:56 --> Pagination Class Initialized
INFO - 2023-06-04 04:17:56 --> Form Validation Class Initialized
INFO - 2023-06-04 04:17:56 --> Controller Class Initialized
INFO - 2023-06-04 04:17:56 --> Model Class Initialized
DEBUG - 2023-06-04 04:17:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:17:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:17:56 --> Model Class Initialized
DEBUG - 2023-06-04 04:17:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:17:56 --> Model Class Initialized
INFO - 2023-06-04 04:17:56 --> Final output sent to browser
DEBUG - 2023-06-04 04:17:56 --> Total execution time: 0.0797
ERROR - 2023-06-04 04:19:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:19:23 --> Config Class Initialized
INFO - 2023-06-04 04:19:23 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:19:23 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:19:23 --> Utf8 Class Initialized
INFO - 2023-06-04 04:19:23 --> URI Class Initialized
DEBUG - 2023-06-04 04:19:23 --> No URI present. Default controller set.
INFO - 2023-06-04 04:19:23 --> Router Class Initialized
INFO - 2023-06-04 04:19:23 --> Output Class Initialized
INFO - 2023-06-04 04:19:23 --> Security Class Initialized
DEBUG - 2023-06-04 04:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:19:23 --> Input Class Initialized
INFO - 2023-06-04 04:19:23 --> Language Class Initialized
INFO - 2023-06-04 04:19:23 --> Loader Class Initialized
INFO - 2023-06-04 04:19:23 --> Helper loaded: url_helper
INFO - 2023-06-04 04:19:23 --> Helper loaded: file_helper
INFO - 2023-06-04 04:19:23 --> Helper loaded: html_helper
INFO - 2023-06-04 04:19:23 --> Helper loaded: text_helper
INFO - 2023-06-04 04:19:23 --> Helper loaded: form_helper
INFO - 2023-06-04 04:19:23 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:19:23 --> Helper loaded: security_helper
INFO - 2023-06-04 04:19:23 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:19:23 --> Database Driver Class Initialized
INFO - 2023-06-04 04:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:19:23 --> Parser Class Initialized
INFO - 2023-06-04 04:19:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:19:23 --> Pagination Class Initialized
INFO - 2023-06-04 04:19:23 --> Form Validation Class Initialized
INFO - 2023-06-04 04:19:23 --> Controller Class Initialized
INFO - 2023-06-04 04:19:23 --> Model Class Initialized
DEBUG - 2023-06-04 04:19:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:19:23 --> Model Class Initialized
DEBUG - 2023-06-04 04:19:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:19:23 --> Model Class Initialized
INFO - 2023-06-04 04:19:23 --> Model Class Initialized
INFO - 2023-06-04 04:19:23 --> Model Class Initialized
INFO - 2023-06-04 04:19:23 --> Model Class Initialized
DEBUG - 2023-06-04 04:19:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:19:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:19:23 --> Model Class Initialized
INFO - 2023-06-04 04:19:23 --> Model Class Initialized
INFO - 2023-06-04 04:19:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-04 04:19:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:19:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:19:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:19:23 --> Model Class Initialized
INFO - 2023-06-04 04:19:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:19:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:19:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:19:23 --> Final output sent to browser
DEBUG - 2023-06-04 04:19:23 --> Total execution time: 0.0883
ERROR - 2023-06-04 04:19:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:19:39 --> Config Class Initialized
INFO - 2023-06-04 04:19:39 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:19:39 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:19:39 --> Utf8 Class Initialized
INFO - 2023-06-04 04:19:39 --> URI Class Initialized
INFO - 2023-06-04 04:19:39 --> Router Class Initialized
INFO - 2023-06-04 04:19:39 --> Output Class Initialized
INFO - 2023-06-04 04:19:39 --> Security Class Initialized
DEBUG - 2023-06-04 04:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:19:39 --> Input Class Initialized
INFO - 2023-06-04 04:19:39 --> Language Class Initialized
INFO - 2023-06-04 04:19:39 --> Loader Class Initialized
INFO - 2023-06-04 04:19:39 --> Helper loaded: url_helper
INFO - 2023-06-04 04:19:39 --> Helper loaded: file_helper
INFO - 2023-06-04 04:19:39 --> Helper loaded: html_helper
INFO - 2023-06-04 04:19:39 --> Helper loaded: text_helper
INFO - 2023-06-04 04:19:39 --> Helper loaded: form_helper
INFO - 2023-06-04 04:19:39 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:19:39 --> Helper loaded: security_helper
INFO - 2023-06-04 04:19:39 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:19:39 --> Database Driver Class Initialized
INFO - 2023-06-04 04:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:19:39 --> Parser Class Initialized
INFO - 2023-06-04 04:19:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:19:39 --> Pagination Class Initialized
INFO - 2023-06-04 04:19:39 --> Form Validation Class Initialized
INFO - 2023-06-04 04:19:39 --> Controller Class Initialized
DEBUG - 2023-06-04 04:19:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:19:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:19:39 --> Model Class Initialized
DEBUG - 2023-06-04 04:19:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:19:39 --> Model Class Initialized
DEBUG - 2023-06-04 04:19:39 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:19:39 --> Model Class Initialized
INFO - 2023-06-04 04:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-06-04 04:19:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:19:39 --> Model Class Initialized
INFO - 2023-06-04 04:19:39 --> Model Class Initialized
INFO - 2023-06-04 04:19:39 --> Model Class Initialized
INFO - 2023-06-04 04:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:19:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:19:39 --> Final output sent to browser
DEBUG - 2023-06-04 04:19:39 --> Total execution time: 0.0821
ERROR - 2023-06-04 04:19:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:19:39 --> Config Class Initialized
INFO - 2023-06-04 04:19:39 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:19:39 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:19:39 --> Utf8 Class Initialized
INFO - 2023-06-04 04:19:39 --> URI Class Initialized
INFO - 2023-06-04 04:19:39 --> Router Class Initialized
INFO - 2023-06-04 04:19:39 --> Output Class Initialized
INFO - 2023-06-04 04:19:39 --> Security Class Initialized
DEBUG - 2023-06-04 04:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:19:39 --> Input Class Initialized
INFO - 2023-06-04 04:19:39 --> Language Class Initialized
INFO - 2023-06-04 04:19:39 --> Loader Class Initialized
INFO - 2023-06-04 04:19:39 --> Helper loaded: url_helper
INFO - 2023-06-04 04:19:39 --> Helper loaded: file_helper
INFO - 2023-06-04 04:19:39 --> Helper loaded: html_helper
INFO - 2023-06-04 04:19:39 --> Helper loaded: text_helper
INFO - 2023-06-04 04:19:39 --> Helper loaded: form_helper
INFO - 2023-06-04 04:19:39 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:19:39 --> Helper loaded: security_helper
INFO - 2023-06-04 04:19:39 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:19:39 --> Database Driver Class Initialized
INFO - 2023-06-04 04:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:19:39 --> Parser Class Initialized
INFO - 2023-06-04 04:19:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:19:39 --> Pagination Class Initialized
INFO - 2023-06-04 04:19:39 --> Form Validation Class Initialized
INFO - 2023-06-04 04:19:39 --> Controller Class Initialized
DEBUG - 2023-06-04 04:19:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:19:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:19:39 --> Model Class Initialized
DEBUG - 2023-06-04 04:19:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:19:39 --> Model Class Initialized
INFO - 2023-06-04 04:19:40 --> Final output sent to browser
DEBUG - 2023-06-04 04:19:40 --> Total execution time: 0.0202
ERROR - 2023-06-04 04:20:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:20:02 --> Config Class Initialized
INFO - 2023-06-04 04:20:02 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:20:02 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:20:02 --> Utf8 Class Initialized
INFO - 2023-06-04 04:20:02 --> URI Class Initialized
DEBUG - 2023-06-04 04:20:02 --> No URI present. Default controller set.
INFO - 2023-06-04 04:20:02 --> Router Class Initialized
INFO - 2023-06-04 04:20:02 --> Output Class Initialized
INFO - 2023-06-04 04:20:02 --> Security Class Initialized
DEBUG - 2023-06-04 04:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:20:02 --> Input Class Initialized
INFO - 2023-06-04 04:20:02 --> Language Class Initialized
INFO - 2023-06-04 04:20:02 --> Loader Class Initialized
INFO - 2023-06-04 04:20:02 --> Helper loaded: url_helper
INFO - 2023-06-04 04:20:02 --> Helper loaded: file_helper
INFO - 2023-06-04 04:20:02 --> Helper loaded: html_helper
INFO - 2023-06-04 04:20:02 --> Helper loaded: text_helper
INFO - 2023-06-04 04:20:02 --> Helper loaded: form_helper
INFO - 2023-06-04 04:20:02 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:20:02 --> Helper loaded: security_helper
INFO - 2023-06-04 04:20:02 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:20:02 --> Database Driver Class Initialized
INFO - 2023-06-04 04:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:20:02 --> Parser Class Initialized
INFO - 2023-06-04 04:20:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:20:02 --> Pagination Class Initialized
INFO - 2023-06-04 04:20:02 --> Form Validation Class Initialized
INFO - 2023-06-04 04:20:02 --> Controller Class Initialized
INFO - 2023-06-04 04:20:02 --> Model Class Initialized
DEBUG - 2023-06-04 04:20:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:20:02 --> Model Class Initialized
DEBUG - 2023-06-04 04:20:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:20:02 --> Model Class Initialized
INFO - 2023-06-04 04:20:02 --> Model Class Initialized
INFO - 2023-06-04 04:20:02 --> Model Class Initialized
INFO - 2023-06-04 04:20:02 --> Model Class Initialized
DEBUG - 2023-06-04 04:20:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:20:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:20:02 --> Model Class Initialized
INFO - 2023-06-04 04:20:02 --> Model Class Initialized
INFO - 2023-06-04 04:20:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-04 04:20:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:20:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:20:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:20:02 --> Model Class Initialized
INFO - 2023-06-04 04:20:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:20:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:20:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:20:02 --> Final output sent to browser
DEBUG - 2023-06-04 04:20:02 --> Total execution time: 0.0837
ERROR - 2023-06-04 04:20:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:20:31 --> Config Class Initialized
INFO - 2023-06-04 04:20:31 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:20:31 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:20:31 --> Utf8 Class Initialized
INFO - 2023-06-04 04:20:31 --> URI Class Initialized
INFO - 2023-06-04 04:20:31 --> Router Class Initialized
INFO - 2023-06-04 04:20:31 --> Output Class Initialized
INFO - 2023-06-04 04:20:31 --> Security Class Initialized
DEBUG - 2023-06-04 04:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:20:31 --> Input Class Initialized
INFO - 2023-06-04 04:20:31 --> Language Class Initialized
INFO - 2023-06-04 04:20:31 --> Loader Class Initialized
INFO - 2023-06-04 04:20:31 --> Helper loaded: url_helper
INFO - 2023-06-04 04:20:31 --> Helper loaded: file_helper
INFO - 2023-06-04 04:20:31 --> Helper loaded: html_helper
INFO - 2023-06-04 04:20:31 --> Helper loaded: text_helper
INFO - 2023-06-04 04:20:31 --> Helper loaded: form_helper
INFO - 2023-06-04 04:20:31 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:20:31 --> Helper loaded: security_helper
INFO - 2023-06-04 04:20:31 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:20:31 --> Database Driver Class Initialized
INFO - 2023-06-04 04:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:20:31 --> Parser Class Initialized
INFO - 2023-06-04 04:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:20:31 --> Pagination Class Initialized
INFO - 2023-06-04 04:20:31 --> Form Validation Class Initialized
INFO - 2023-06-04 04:20:31 --> Controller Class Initialized
DEBUG - 2023-06-04 04:20:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:20:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:20:31 --> Model Class Initialized
DEBUG - 2023-06-04 04:20:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:20:31 --> Model Class Initialized
INFO - 2023-06-04 04:20:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2023-06-04 04:20:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:20:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:20:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:20:31 --> Model Class Initialized
INFO - 2023-06-04 04:20:31 --> Model Class Initialized
INFO - 2023-06-04 04:20:31 --> Model Class Initialized
INFO - 2023-06-04 04:20:31 --> Model Class Initialized
INFO - 2023-06-04 04:20:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:20:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:20:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:20:31 --> Final output sent to browser
DEBUG - 2023-06-04 04:20:31 --> Total execution time: 0.1146
ERROR - 2023-06-04 04:21:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:21:46 --> Config Class Initialized
INFO - 2023-06-04 04:21:46 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:21:46 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:21:46 --> Utf8 Class Initialized
INFO - 2023-06-04 04:21:46 --> URI Class Initialized
DEBUG - 2023-06-04 04:21:46 --> No URI present. Default controller set.
INFO - 2023-06-04 04:21:46 --> Router Class Initialized
INFO - 2023-06-04 04:21:46 --> Output Class Initialized
INFO - 2023-06-04 04:21:46 --> Security Class Initialized
DEBUG - 2023-06-04 04:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:21:46 --> Input Class Initialized
INFO - 2023-06-04 04:21:46 --> Language Class Initialized
INFO - 2023-06-04 04:21:46 --> Loader Class Initialized
INFO - 2023-06-04 04:21:46 --> Helper loaded: url_helper
INFO - 2023-06-04 04:21:46 --> Helper loaded: file_helper
INFO - 2023-06-04 04:21:46 --> Helper loaded: html_helper
INFO - 2023-06-04 04:21:46 --> Helper loaded: text_helper
INFO - 2023-06-04 04:21:46 --> Helper loaded: form_helper
INFO - 2023-06-04 04:21:46 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:21:46 --> Helper loaded: security_helper
INFO - 2023-06-04 04:21:46 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:21:46 --> Database Driver Class Initialized
INFO - 2023-06-04 04:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:21:46 --> Parser Class Initialized
INFO - 2023-06-04 04:21:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:21:46 --> Pagination Class Initialized
INFO - 2023-06-04 04:21:46 --> Form Validation Class Initialized
INFO - 2023-06-04 04:21:46 --> Controller Class Initialized
INFO - 2023-06-04 04:21:46 --> Model Class Initialized
DEBUG - 2023-06-04 04:21:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:21:46 --> Model Class Initialized
DEBUG - 2023-06-04 04:21:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:21:46 --> Model Class Initialized
INFO - 2023-06-04 04:21:46 --> Model Class Initialized
INFO - 2023-06-04 04:21:46 --> Model Class Initialized
INFO - 2023-06-04 04:21:46 --> Model Class Initialized
DEBUG - 2023-06-04 04:21:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:21:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:21:46 --> Model Class Initialized
INFO - 2023-06-04 04:21:46 --> Model Class Initialized
INFO - 2023-06-04 04:21:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-04 04:21:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:21:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:21:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:21:46 --> Model Class Initialized
INFO - 2023-06-04 04:21:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:21:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:21:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:21:46 --> Final output sent to browser
DEBUG - 2023-06-04 04:21:46 --> Total execution time: 0.0820
ERROR - 2023-06-04 04:22:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:22:23 --> Config Class Initialized
INFO - 2023-06-04 04:22:23 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:22:23 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:22:23 --> Utf8 Class Initialized
INFO - 2023-06-04 04:22:23 --> URI Class Initialized
INFO - 2023-06-04 04:22:23 --> Router Class Initialized
INFO - 2023-06-04 04:22:23 --> Output Class Initialized
INFO - 2023-06-04 04:22:23 --> Security Class Initialized
DEBUG - 2023-06-04 04:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:22:23 --> Input Class Initialized
INFO - 2023-06-04 04:22:23 --> Language Class Initialized
INFO - 2023-06-04 04:22:23 --> Loader Class Initialized
INFO - 2023-06-04 04:22:23 --> Helper loaded: url_helper
INFO - 2023-06-04 04:22:23 --> Helper loaded: file_helper
INFO - 2023-06-04 04:22:23 --> Helper loaded: html_helper
INFO - 2023-06-04 04:22:23 --> Helper loaded: text_helper
INFO - 2023-06-04 04:22:23 --> Helper loaded: form_helper
INFO - 2023-06-04 04:22:23 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:22:23 --> Helper loaded: security_helper
INFO - 2023-06-04 04:22:23 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:22:23 --> Database Driver Class Initialized
INFO - 2023-06-04 04:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:22:23 --> Parser Class Initialized
INFO - 2023-06-04 04:22:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:22:23 --> Pagination Class Initialized
INFO - 2023-06-04 04:22:23 --> Form Validation Class Initialized
INFO - 2023-06-04 04:22:23 --> Controller Class Initialized
INFO - 2023-06-04 04:22:23 --> Model Class Initialized
DEBUG - 2023-06-04 04:22:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:22:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:22:23 --> Model Class Initialized
DEBUG - 2023-06-04 04:22:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:22:23 --> Model Class Initialized
INFO - 2023-06-04 04:22:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-04 04:22:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:22:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:22:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:22:23 --> Model Class Initialized
INFO - 2023-06-04 04:22:23 --> Model Class Initialized
INFO - 2023-06-04 04:22:23 --> Model Class Initialized
INFO - 2023-06-04 04:22:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:22:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:22:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:22:23 --> Final output sent to browser
DEBUG - 2023-06-04 04:22:23 --> Total execution time: 0.0792
ERROR - 2023-06-04 04:22:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:22:24 --> Config Class Initialized
INFO - 2023-06-04 04:22:24 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:22:24 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:22:24 --> Utf8 Class Initialized
INFO - 2023-06-04 04:22:24 --> URI Class Initialized
INFO - 2023-06-04 04:22:24 --> Router Class Initialized
INFO - 2023-06-04 04:22:24 --> Output Class Initialized
INFO - 2023-06-04 04:22:24 --> Security Class Initialized
DEBUG - 2023-06-04 04:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:22:24 --> Input Class Initialized
INFO - 2023-06-04 04:22:24 --> Language Class Initialized
INFO - 2023-06-04 04:22:24 --> Loader Class Initialized
INFO - 2023-06-04 04:22:24 --> Helper loaded: url_helper
INFO - 2023-06-04 04:22:24 --> Helper loaded: file_helper
INFO - 2023-06-04 04:22:24 --> Helper loaded: html_helper
INFO - 2023-06-04 04:22:24 --> Helper loaded: text_helper
INFO - 2023-06-04 04:22:24 --> Helper loaded: form_helper
INFO - 2023-06-04 04:22:24 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:22:24 --> Helper loaded: security_helper
INFO - 2023-06-04 04:22:24 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:22:24 --> Database Driver Class Initialized
INFO - 2023-06-04 04:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:22:24 --> Parser Class Initialized
INFO - 2023-06-04 04:22:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:22:24 --> Pagination Class Initialized
INFO - 2023-06-04 04:22:24 --> Form Validation Class Initialized
INFO - 2023-06-04 04:22:24 --> Controller Class Initialized
INFO - 2023-06-04 04:22:24 --> Model Class Initialized
DEBUG - 2023-06-04 04:22:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:22:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:22:24 --> Model Class Initialized
DEBUG - 2023-06-04 04:22:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:22:24 --> Model Class Initialized
INFO - 2023-06-04 04:22:24 --> Final output sent to browser
DEBUG - 2023-06-04 04:22:24 --> Total execution time: 0.0375
ERROR - 2023-06-04 04:22:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:22:30 --> Config Class Initialized
INFO - 2023-06-04 04:22:30 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:22:30 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:22:30 --> Utf8 Class Initialized
INFO - 2023-06-04 04:22:30 --> URI Class Initialized
INFO - 2023-06-04 04:22:30 --> Router Class Initialized
INFO - 2023-06-04 04:22:30 --> Output Class Initialized
INFO - 2023-06-04 04:22:30 --> Security Class Initialized
DEBUG - 2023-06-04 04:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:22:30 --> Input Class Initialized
INFO - 2023-06-04 04:22:30 --> Language Class Initialized
INFO - 2023-06-04 04:22:30 --> Loader Class Initialized
INFO - 2023-06-04 04:22:30 --> Helper loaded: url_helper
INFO - 2023-06-04 04:22:30 --> Helper loaded: file_helper
INFO - 2023-06-04 04:22:30 --> Helper loaded: html_helper
INFO - 2023-06-04 04:22:30 --> Helper loaded: text_helper
INFO - 2023-06-04 04:22:30 --> Helper loaded: form_helper
INFO - 2023-06-04 04:22:30 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:22:30 --> Helper loaded: security_helper
INFO - 2023-06-04 04:22:30 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:22:30 --> Database Driver Class Initialized
INFO - 2023-06-04 04:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:22:30 --> Parser Class Initialized
INFO - 2023-06-04 04:22:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:22:30 --> Pagination Class Initialized
INFO - 2023-06-04 04:22:30 --> Form Validation Class Initialized
INFO - 2023-06-04 04:22:30 --> Controller Class Initialized
INFO - 2023-06-04 04:22:30 --> Model Class Initialized
DEBUG - 2023-06-04 04:22:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:22:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:22:30 --> Model Class Initialized
DEBUG - 2023-06-04 04:22:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:22:30 --> Model Class Initialized
INFO - 2023-06-04 04:22:30 --> Final output sent to browser
DEBUG - 2023-06-04 04:22:30 --> Total execution time: 0.0428
ERROR - 2023-06-04 04:22:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:22:32 --> Config Class Initialized
INFO - 2023-06-04 04:22:32 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:22:32 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:22:32 --> Utf8 Class Initialized
INFO - 2023-06-04 04:22:32 --> URI Class Initialized
INFO - 2023-06-04 04:22:32 --> Router Class Initialized
INFO - 2023-06-04 04:22:32 --> Output Class Initialized
INFO - 2023-06-04 04:22:32 --> Security Class Initialized
DEBUG - 2023-06-04 04:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:22:32 --> Input Class Initialized
INFO - 2023-06-04 04:22:32 --> Language Class Initialized
INFO - 2023-06-04 04:22:32 --> Loader Class Initialized
INFO - 2023-06-04 04:22:32 --> Helper loaded: url_helper
INFO - 2023-06-04 04:22:32 --> Helper loaded: file_helper
INFO - 2023-06-04 04:22:32 --> Helper loaded: html_helper
INFO - 2023-06-04 04:22:32 --> Helper loaded: text_helper
INFO - 2023-06-04 04:22:32 --> Helper loaded: form_helper
INFO - 2023-06-04 04:22:32 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:22:32 --> Helper loaded: security_helper
INFO - 2023-06-04 04:22:32 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:22:32 --> Database Driver Class Initialized
INFO - 2023-06-04 04:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:22:32 --> Parser Class Initialized
INFO - 2023-06-04 04:22:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:22:32 --> Pagination Class Initialized
INFO - 2023-06-04 04:22:32 --> Form Validation Class Initialized
INFO - 2023-06-04 04:22:32 --> Controller Class Initialized
INFO - 2023-06-04 04:22:32 --> Model Class Initialized
DEBUG - 2023-06-04 04:22:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:22:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:22:32 --> Model Class Initialized
DEBUG - 2023-06-04 04:22:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:22:32 --> Model Class Initialized
INFO - 2023-06-04 04:22:32 --> Final output sent to browser
DEBUG - 2023-06-04 04:22:32 --> Total execution time: 0.0407
ERROR - 2023-06-04 04:22:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:22:34 --> Config Class Initialized
INFO - 2023-06-04 04:22:34 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:22:34 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:22:34 --> Utf8 Class Initialized
INFO - 2023-06-04 04:22:34 --> URI Class Initialized
INFO - 2023-06-04 04:22:34 --> Router Class Initialized
INFO - 2023-06-04 04:22:34 --> Output Class Initialized
INFO - 2023-06-04 04:22:34 --> Security Class Initialized
DEBUG - 2023-06-04 04:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:22:34 --> Input Class Initialized
INFO - 2023-06-04 04:22:34 --> Language Class Initialized
INFO - 2023-06-04 04:22:34 --> Loader Class Initialized
INFO - 2023-06-04 04:22:34 --> Helper loaded: url_helper
INFO - 2023-06-04 04:22:34 --> Helper loaded: file_helper
INFO - 2023-06-04 04:22:34 --> Helper loaded: html_helper
INFO - 2023-06-04 04:22:34 --> Helper loaded: text_helper
INFO - 2023-06-04 04:22:34 --> Helper loaded: form_helper
INFO - 2023-06-04 04:22:34 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:22:34 --> Helper loaded: security_helper
INFO - 2023-06-04 04:22:34 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:22:34 --> Database Driver Class Initialized
INFO - 2023-06-04 04:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:22:34 --> Parser Class Initialized
INFO - 2023-06-04 04:22:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:22:34 --> Pagination Class Initialized
INFO - 2023-06-04 04:22:34 --> Form Validation Class Initialized
INFO - 2023-06-04 04:22:34 --> Controller Class Initialized
INFO - 2023-06-04 04:22:34 --> Model Class Initialized
DEBUG - 2023-06-04 04:22:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:22:34 --> Model Class Initialized
DEBUG - 2023-06-04 04:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:22:34 --> Model Class Initialized
INFO - 2023-06-04 04:22:34 --> Final output sent to browser
DEBUG - 2023-06-04 04:22:34 --> Total execution time: 0.0416
ERROR - 2023-06-04 04:23:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:23:04 --> Config Class Initialized
INFO - 2023-06-04 04:23:04 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:23:04 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:23:04 --> Utf8 Class Initialized
INFO - 2023-06-04 04:23:04 --> URI Class Initialized
DEBUG - 2023-06-04 04:23:04 --> No URI present. Default controller set.
INFO - 2023-06-04 04:23:04 --> Router Class Initialized
INFO - 2023-06-04 04:23:04 --> Output Class Initialized
INFO - 2023-06-04 04:23:04 --> Security Class Initialized
DEBUG - 2023-06-04 04:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:23:04 --> Input Class Initialized
INFO - 2023-06-04 04:23:04 --> Language Class Initialized
INFO - 2023-06-04 04:23:04 --> Loader Class Initialized
INFO - 2023-06-04 04:23:04 --> Helper loaded: url_helper
INFO - 2023-06-04 04:23:04 --> Helper loaded: file_helper
INFO - 2023-06-04 04:23:04 --> Helper loaded: html_helper
INFO - 2023-06-04 04:23:04 --> Helper loaded: text_helper
INFO - 2023-06-04 04:23:04 --> Helper loaded: form_helper
INFO - 2023-06-04 04:23:04 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:23:04 --> Helper loaded: security_helper
INFO - 2023-06-04 04:23:04 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:23:04 --> Database Driver Class Initialized
INFO - 2023-06-04 04:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:23:04 --> Parser Class Initialized
INFO - 2023-06-04 04:23:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:23:04 --> Pagination Class Initialized
INFO - 2023-06-04 04:23:05 --> Form Validation Class Initialized
INFO - 2023-06-04 04:23:05 --> Controller Class Initialized
INFO - 2023-06-04 04:23:05 --> Model Class Initialized
DEBUG - 2023-06-04 04:23:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:23:05 --> Model Class Initialized
DEBUG - 2023-06-04 04:23:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:23:05 --> Model Class Initialized
INFO - 2023-06-04 04:23:05 --> Model Class Initialized
INFO - 2023-06-04 04:23:05 --> Model Class Initialized
INFO - 2023-06-04 04:23:05 --> Model Class Initialized
DEBUG - 2023-06-04 04:23:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:23:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:23:05 --> Model Class Initialized
INFO - 2023-06-04 04:23:05 --> Model Class Initialized
INFO - 2023-06-04 04:23:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-04 04:23:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:23:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:23:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:23:05 --> Model Class Initialized
INFO - 2023-06-04 04:23:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:23:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:23:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:23:05 --> Final output sent to browser
DEBUG - 2023-06-04 04:23:05 --> Total execution time: 0.0810
ERROR - 2023-06-04 04:23:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:23:15 --> Config Class Initialized
INFO - 2023-06-04 04:23:15 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:23:15 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:23:15 --> Utf8 Class Initialized
INFO - 2023-06-04 04:23:15 --> URI Class Initialized
INFO - 2023-06-04 04:23:15 --> Router Class Initialized
INFO - 2023-06-04 04:23:15 --> Output Class Initialized
INFO - 2023-06-04 04:23:15 --> Security Class Initialized
DEBUG - 2023-06-04 04:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:23:15 --> Input Class Initialized
INFO - 2023-06-04 04:23:15 --> Language Class Initialized
INFO - 2023-06-04 04:23:15 --> Loader Class Initialized
INFO - 2023-06-04 04:23:15 --> Helper loaded: url_helper
INFO - 2023-06-04 04:23:15 --> Helper loaded: file_helper
INFO - 2023-06-04 04:23:15 --> Helper loaded: html_helper
INFO - 2023-06-04 04:23:15 --> Helper loaded: text_helper
INFO - 2023-06-04 04:23:15 --> Helper loaded: form_helper
INFO - 2023-06-04 04:23:15 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:23:15 --> Helper loaded: security_helper
INFO - 2023-06-04 04:23:15 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:23:15 --> Database Driver Class Initialized
INFO - 2023-06-04 04:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:23:15 --> Parser Class Initialized
INFO - 2023-06-04 04:23:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:23:15 --> Pagination Class Initialized
INFO - 2023-06-04 04:23:15 --> Form Validation Class Initialized
INFO - 2023-06-04 04:23:15 --> Controller Class Initialized
INFO - 2023-06-04 04:23:15 --> Model Class Initialized
DEBUG - 2023-06-04 04:23:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:23:15 --> Model Class Initialized
DEBUG - 2023-06-04 04:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:23:15 --> Model Class Initialized
INFO - 2023-06-04 04:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-04 04:23:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 04:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 04:23:15 --> Model Class Initialized
INFO - 2023-06-04 04:23:15 --> Model Class Initialized
INFO - 2023-06-04 04:23:15 --> Model Class Initialized
INFO - 2023-06-04 04:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-04 04:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-04 04:23:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 04:23:15 --> Final output sent to browser
DEBUG - 2023-06-04 04:23:15 --> Total execution time: 0.0787
ERROR - 2023-06-04 04:23:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:23:16 --> Config Class Initialized
INFO - 2023-06-04 04:23:16 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:23:16 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:23:16 --> Utf8 Class Initialized
INFO - 2023-06-04 04:23:16 --> URI Class Initialized
INFO - 2023-06-04 04:23:16 --> Router Class Initialized
INFO - 2023-06-04 04:23:16 --> Output Class Initialized
INFO - 2023-06-04 04:23:16 --> Security Class Initialized
DEBUG - 2023-06-04 04:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:23:16 --> Input Class Initialized
INFO - 2023-06-04 04:23:16 --> Language Class Initialized
INFO - 2023-06-04 04:23:16 --> Loader Class Initialized
INFO - 2023-06-04 04:23:16 --> Helper loaded: url_helper
INFO - 2023-06-04 04:23:16 --> Helper loaded: file_helper
INFO - 2023-06-04 04:23:16 --> Helper loaded: html_helper
INFO - 2023-06-04 04:23:16 --> Helper loaded: text_helper
INFO - 2023-06-04 04:23:16 --> Helper loaded: form_helper
INFO - 2023-06-04 04:23:16 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:23:16 --> Helper loaded: security_helper
INFO - 2023-06-04 04:23:16 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:23:16 --> Database Driver Class Initialized
INFO - 2023-06-04 04:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:23:16 --> Parser Class Initialized
INFO - 2023-06-04 04:23:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:23:16 --> Pagination Class Initialized
INFO - 2023-06-04 04:23:16 --> Form Validation Class Initialized
INFO - 2023-06-04 04:23:16 --> Controller Class Initialized
INFO - 2023-06-04 04:23:16 --> Model Class Initialized
DEBUG - 2023-06-04 04:23:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:23:16 --> Model Class Initialized
DEBUG - 2023-06-04 04:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:23:16 --> Model Class Initialized
INFO - 2023-06-04 04:23:16 --> Final output sent to browser
DEBUG - 2023-06-04 04:23:16 --> Total execution time: 0.0459
ERROR - 2023-06-04 04:23:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:23:42 --> Config Class Initialized
INFO - 2023-06-04 04:23:42 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:23:42 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:23:42 --> Utf8 Class Initialized
INFO - 2023-06-04 04:23:42 --> URI Class Initialized
INFO - 2023-06-04 04:23:42 --> Router Class Initialized
INFO - 2023-06-04 04:23:42 --> Output Class Initialized
INFO - 2023-06-04 04:23:42 --> Security Class Initialized
DEBUG - 2023-06-04 04:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:23:42 --> Input Class Initialized
INFO - 2023-06-04 04:23:42 --> Language Class Initialized
INFO - 2023-06-04 04:23:42 --> Loader Class Initialized
INFO - 2023-06-04 04:23:42 --> Helper loaded: url_helper
INFO - 2023-06-04 04:23:42 --> Helper loaded: file_helper
INFO - 2023-06-04 04:23:42 --> Helper loaded: html_helper
INFO - 2023-06-04 04:23:42 --> Helper loaded: text_helper
INFO - 2023-06-04 04:23:42 --> Helper loaded: form_helper
INFO - 2023-06-04 04:23:42 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:23:42 --> Helper loaded: security_helper
INFO - 2023-06-04 04:23:42 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:23:42 --> Database Driver Class Initialized
INFO - 2023-06-04 04:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:23:42 --> Parser Class Initialized
INFO - 2023-06-04 04:23:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:23:42 --> Pagination Class Initialized
INFO - 2023-06-04 04:23:42 --> Form Validation Class Initialized
INFO - 2023-06-04 04:23:42 --> Controller Class Initialized
INFO - 2023-06-04 04:23:42 --> Model Class Initialized
DEBUG - 2023-06-04 04:23:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:23:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:23:42 --> Model Class Initialized
DEBUG - 2023-06-04 04:23:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:23:42 --> Model Class Initialized
INFO - 2023-06-04 04:23:42 --> Final output sent to browser
DEBUG - 2023-06-04 04:23:42 --> Total execution time: 0.0397
ERROR - 2023-06-04 04:23:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 04:23:53 --> Config Class Initialized
INFO - 2023-06-04 04:23:53 --> Hooks Class Initialized
DEBUG - 2023-06-04 04:23:53 --> UTF-8 Support Enabled
INFO - 2023-06-04 04:23:53 --> Utf8 Class Initialized
INFO - 2023-06-04 04:23:53 --> URI Class Initialized
INFO - 2023-06-04 04:23:53 --> Router Class Initialized
INFO - 2023-06-04 04:23:53 --> Output Class Initialized
INFO - 2023-06-04 04:23:53 --> Security Class Initialized
DEBUG - 2023-06-04 04:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 04:23:53 --> Input Class Initialized
INFO - 2023-06-04 04:23:53 --> Language Class Initialized
INFO - 2023-06-04 04:23:53 --> Loader Class Initialized
INFO - 2023-06-04 04:23:53 --> Helper loaded: url_helper
INFO - 2023-06-04 04:23:53 --> Helper loaded: file_helper
INFO - 2023-06-04 04:23:53 --> Helper loaded: html_helper
INFO - 2023-06-04 04:23:53 --> Helper loaded: text_helper
INFO - 2023-06-04 04:23:53 --> Helper loaded: form_helper
INFO - 2023-06-04 04:23:53 --> Helper loaded: lang_helper
INFO - 2023-06-04 04:23:53 --> Helper loaded: security_helper
INFO - 2023-06-04 04:23:53 --> Helper loaded: cookie_helper
INFO - 2023-06-04 04:23:53 --> Database Driver Class Initialized
INFO - 2023-06-04 04:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 04:23:53 --> Parser Class Initialized
INFO - 2023-06-04 04:23:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 04:23:53 --> Pagination Class Initialized
INFO - 2023-06-04 04:23:53 --> Form Validation Class Initialized
INFO - 2023-06-04 04:23:53 --> Controller Class Initialized
INFO - 2023-06-04 04:23:53 --> Model Class Initialized
DEBUG - 2023-06-04 04:23:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-04 04:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:23:53 --> Model Class Initialized
DEBUG - 2023-06-04 04:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 04:23:53 --> Model Class Initialized
INFO - 2023-06-04 04:23:53 --> Final output sent to browser
DEBUG - 2023-06-04 04:23:53 --> Total execution time: 0.0810
ERROR - 2023-06-04 05:33:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 05:33:17 --> Config Class Initialized
INFO - 2023-06-04 05:33:17 --> Hooks Class Initialized
DEBUG - 2023-06-04 05:33:17 --> UTF-8 Support Enabled
INFO - 2023-06-04 05:33:17 --> Utf8 Class Initialized
INFO - 2023-06-04 05:33:17 --> URI Class Initialized
DEBUG - 2023-06-04 05:33:17 --> No URI present. Default controller set.
INFO - 2023-06-04 05:33:17 --> Router Class Initialized
INFO - 2023-06-04 05:33:17 --> Output Class Initialized
INFO - 2023-06-04 05:33:17 --> Security Class Initialized
DEBUG - 2023-06-04 05:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 05:33:17 --> Input Class Initialized
INFO - 2023-06-04 05:33:17 --> Language Class Initialized
INFO - 2023-06-04 05:33:17 --> Loader Class Initialized
INFO - 2023-06-04 05:33:17 --> Helper loaded: url_helper
INFO - 2023-06-04 05:33:17 --> Helper loaded: file_helper
INFO - 2023-06-04 05:33:17 --> Helper loaded: html_helper
INFO - 2023-06-04 05:33:17 --> Helper loaded: text_helper
INFO - 2023-06-04 05:33:17 --> Helper loaded: form_helper
INFO - 2023-06-04 05:33:17 --> Helper loaded: lang_helper
INFO - 2023-06-04 05:33:17 --> Helper loaded: security_helper
INFO - 2023-06-04 05:33:17 --> Helper loaded: cookie_helper
INFO - 2023-06-04 05:33:17 --> Database Driver Class Initialized
INFO - 2023-06-04 05:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 05:33:17 --> Parser Class Initialized
INFO - 2023-06-04 05:33:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 05:33:17 --> Pagination Class Initialized
INFO - 2023-06-04 05:33:17 --> Form Validation Class Initialized
INFO - 2023-06-04 05:33:17 --> Controller Class Initialized
INFO - 2023-06-04 05:33:17 --> Model Class Initialized
DEBUG - 2023-06-04 05:33:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-04 05:33:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 05:33:40 --> Config Class Initialized
INFO - 2023-06-04 05:33:40 --> Hooks Class Initialized
DEBUG - 2023-06-04 05:33:40 --> UTF-8 Support Enabled
INFO - 2023-06-04 05:33:40 --> Utf8 Class Initialized
INFO - 2023-06-04 05:33:40 --> URI Class Initialized
INFO - 2023-06-04 05:33:40 --> Router Class Initialized
INFO - 2023-06-04 05:33:40 --> Output Class Initialized
INFO - 2023-06-04 05:33:40 --> Security Class Initialized
DEBUG - 2023-06-04 05:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 05:33:40 --> Input Class Initialized
INFO - 2023-06-04 05:33:40 --> Language Class Initialized
INFO - 2023-06-04 05:33:40 --> Loader Class Initialized
INFO - 2023-06-04 05:33:40 --> Helper loaded: url_helper
INFO - 2023-06-04 05:33:40 --> Helper loaded: file_helper
INFO - 2023-06-04 05:33:40 --> Helper loaded: html_helper
INFO - 2023-06-04 05:33:40 --> Helper loaded: text_helper
INFO - 2023-06-04 05:33:40 --> Helper loaded: form_helper
INFO - 2023-06-04 05:33:40 --> Helper loaded: lang_helper
INFO - 2023-06-04 05:33:40 --> Helper loaded: security_helper
INFO - 2023-06-04 05:33:40 --> Helper loaded: cookie_helper
INFO - 2023-06-04 05:33:40 --> Database Driver Class Initialized
INFO - 2023-06-04 05:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 05:33:40 --> Parser Class Initialized
INFO - 2023-06-04 05:33:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 05:33:40 --> Pagination Class Initialized
INFO - 2023-06-04 05:33:40 --> Form Validation Class Initialized
INFO - 2023-06-04 05:33:40 --> Controller Class Initialized
ERROR - 2023-06-04 05:42:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 05:42:16 --> Config Class Initialized
INFO - 2023-06-04 05:42:16 --> Hooks Class Initialized
DEBUG - 2023-06-04 05:42:16 --> UTF-8 Support Enabled
INFO - 2023-06-04 05:42:16 --> Utf8 Class Initialized
INFO - 2023-06-04 05:42:16 --> URI Class Initialized
INFO - 2023-06-04 05:42:16 --> Router Class Initialized
INFO - 2023-06-04 05:42:16 --> Output Class Initialized
INFO - 2023-06-04 05:42:16 --> Security Class Initialized
DEBUG - 2023-06-04 05:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 05:42:16 --> Input Class Initialized
INFO - 2023-06-04 05:42:16 --> Language Class Initialized
INFO - 2023-06-04 05:42:16 --> Loader Class Initialized
INFO - 2023-06-04 05:42:16 --> Helper loaded: url_helper
INFO - 2023-06-04 05:42:16 --> Helper loaded: file_helper
INFO - 2023-06-04 05:42:16 --> Helper loaded: html_helper
INFO - 2023-06-04 05:42:16 --> Helper loaded: text_helper
INFO - 2023-06-04 05:42:16 --> Helper loaded: form_helper
INFO - 2023-06-04 05:42:16 --> Helper loaded: lang_helper
INFO - 2023-06-04 05:42:16 --> Helper loaded: security_helper
INFO - 2023-06-04 05:42:16 --> Helper loaded: cookie_helper
INFO - 2023-06-04 05:42:16 --> Database Driver Class Initialized
INFO - 2023-06-04 05:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 05:42:16 --> Parser Class Initialized
INFO - 2023-06-04 05:42:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 05:42:16 --> Pagination Class Initialized
INFO - 2023-06-04 05:42:16 --> Form Validation Class Initialized
INFO - 2023-06-04 05:42:16 --> Controller Class Initialized
ERROR - 2023-06-04 05:47:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 05:47:21 --> Config Class Initialized
INFO - 2023-06-04 05:47:21 --> Hooks Class Initialized
DEBUG - 2023-06-04 05:47:21 --> UTF-8 Support Enabled
INFO - 2023-06-04 05:47:21 --> Utf8 Class Initialized
INFO - 2023-06-04 05:47:21 --> URI Class Initialized
INFO - 2023-06-04 05:47:21 --> Router Class Initialized
INFO - 2023-06-04 05:47:21 --> Output Class Initialized
INFO - 2023-06-04 05:47:21 --> Security Class Initialized
DEBUG - 2023-06-04 05:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 05:47:21 --> Input Class Initialized
INFO - 2023-06-04 05:47:21 --> Language Class Initialized
INFO - 2023-06-04 05:47:21 --> Loader Class Initialized
INFO - 2023-06-04 05:47:21 --> Helper loaded: url_helper
INFO - 2023-06-04 05:47:21 --> Helper loaded: file_helper
INFO - 2023-06-04 05:47:21 --> Helper loaded: html_helper
INFO - 2023-06-04 05:47:21 --> Helper loaded: text_helper
INFO - 2023-06-04 05:47:21 --> Helper loaded: form_helper
INFO - 2023-06-04 05:47:21 --> Helper loaded: lang_helper
INFO - 2023-06-04 05:47:21 --> Helper loaded: security_helper
INFO - 2023-06-04 05:47:21 --> Helper loaded: cookie_helper
INFO - 2023-06-04 05:47:21 --> Database Driver Class Initialized
INFO - 2023-06-04 05:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 05:47:21 --> Parser Class Initialized
INFO - 2023-06-04 05:47:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 05:47:21 --> Pagination Class Initialized
INFO - 2023-06-04 05:47:21 --> Form Validation Class Initialized
INFO - 2023-06-04 05:47:21 --> Controller Class Initialized
ERROR - 2023-06-04 05:47:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 05:47:49 --> Config Class Initialized
INFO - 2023-06-04 05:47:49 --> Hooks Class Initialized
DEBUG - 2023-06-04 05:47:49 --> UTF-8 Support Enabled
INFO - 2023-06-04 05:47:49 --> Utf8 Class Initialized
INFO - 2023-06-04 05:47:49 --> URI Class Initialized
INFO - 2023-06-04 05:47:49 --> Router Class Initialized
INFO - 2023-06-04 05:47:49 --> Output Class Initialized
INFO - 2023-06-04 05:47:49 --> Security Class Initialized
DEBUG - 2023-06-04 05:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 05:47:49 --> Input Class Initialized
INFO - 2023-06-04 05:47:49 --> Language Class Initialized
INFO - 2023-06-04 05:47:49 --> Loader Class Initialized
INFO - 2023-06-04 05:47:49 --> Helper loaded: url_helper
INFO - 2023-06-04 05:47:49 --> Helper loaded: file_helper
INFO - 2023-06-04 05:47:49 --> Helper loaded: html_helper
INFO - 2023-06-04 05:47:49 --> Helper loaded: text_helper
INFO - 2023-06-04 05:47:49 --> Helper loaded: form_helper
INFO - 2023-06-04 05:47:49 --> Helper loaded: lang_helper
INFO - 2023-06-04 05:47:49 --> Helper loaded: security_helper
INFO - 2023-06-04 05:47:49 --> Helper loaded: cookie_helper
INFO - 2023-06-04 05:47:49 --> Database Driver Class Initialized
INFO - 2023-06-04 05:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 05:47:49 --> Parser Class Initialized
INFO - 2023-06-04 05:47:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 05:47:49 --> Pagination Class Initialized
INFO - 2023-06-04 05:47:49 --> Form Validation Class Initialized
INFO - 2023-06-04 05:47:49 --> Controller Class Initialized
ERROR - 2023-06-04 05:49:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 05:49:21 --> Config Class Initialized
INFO - 2023-06-04 05:49:21 --> Hooks Class Initialized
DEBUG - 2023-06-04 05:49:21 --> UTF-8 Support Enabled
INFO - 2023-06-04 05:49:21 --> Utf8 Class Initialized
INFO - 2023-06-04 05:49:21 --> URI Class Initialized
INFO - 2023-06-04 05:49:21 --> Router Class Initialized
INFO - 2023-06-04 05:49:21 --> Output Class Initialized
INFO - 2023-06-04 05:49:21 --> Security Class Initialized
DEBUG - 2023-06-04 05:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 05:49:21 --> Input Class Initialized
INFO - 2023-06-04 05:49:21 --> Language Class Initialized
INFO - 2023-06-04 05:49:21 --> Loader Class Initialized
INFO - 2023-06-04 05:49:21 --> Helper loaded: url_helper
INFO - 2023-06-04 05:49:21 --> Helper loaded: file_helper
INFO - 2023-06-04 05:49:21 --> Helper loaded: html_helper
INFO - 2023-06-04 05:49:21 --> Helper loaded: text_helper
INFO - 2023-06-04 05:49:21 --> Helper loaded: form_helper
INFO - 2023-06-04 05:49:21 --> Helper loaded: lang_helper
INFO - 2023-06-04 05:49:21 --> Helper loaded: security_helper
INFO - 2023-06-04 05:49:21 --> Helper loaded: cookie_helper
INFO - 2023-06-04 05:49:22 --> Database Driver Class Initialized
INFO - 2023-06-04 05:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 05:49:22 --> Parser Class Initialized
INFO - 2023-06-04 05:49:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 05:49:22 --> Pagination Class Initialized
INFO - 2023-06-04 05:49:22 --> Form Validation Class Initialized
INFO - 2023-06-04 05:49:22 --> Controller Class Initialized
ERROR - 2023-06-04 16:39:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 16:39:44 --> Config Class Initialized
INFO - 2023-06-04 16:39:44 --> Hooks Class Initialized
DEBUG - 2023-06-04 16:39:44 --> UTF-8 Support Enabled
INFO - 2023-06-04 16:39:44 --> Utf8 Class Initialized
INFO - 2023-06-04 16:39:44 --> URI Class Initialized
DEBUG - 2023-06-04 16:39:44 --> No URI present. Default controller set.
INFO - 2023-06-04 16:39:44 --> Router Class Initialized
INFO - 2023-06-04 16:39:44 --> Output Class Initialized
INFO - 2023-06-04 16:39:44 --> Security Class Initialized
DEBUG - 2023-06-04 16:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 16:39:44 --> Input Class Initialized
INFO - 2023-06-04 16:39:44 --> Language Class Initialized
INFO - 2023-06-04 16:39:44 --> Loader Class Initialized
INFO - 2023-06-04 16:39:44 --> Helper loaded: url_helper
INFO - 2023-06-04 16:39:44 --> Helper loaded: file_helper
INFO - 2023-06-04 16:39:44 --> Helper loaded: html_helper
INFO - 2023-06-04 16:39:44 --> Helper loaded: text_helper
INFO - 2023-06-04 16:39:44 --> Helper loaded: form_helper
INFO - 2023-06-04 16:39:44 --> Helper loaded: lang_helper
INFO - 2023-06-04 16:39:44 --> Helper loaded: security_helper
INFO - 2023-06-04 16:39:44 --> Helper loaded: cookie_helper
INFO - 2023-06-04 16:39:44 --> Database Driver Class Initialized
INFO - 2023-06-04 16:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 16:39:44 --> Parser Class Initialized
INFO - 2023-06-04 16:39:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 16:39:44 --> Pagination Class Initialized
INFO - 2023-06-04 16:39:44 --> Form Validation Class Initialized
INFO - 2023-06-04 16:39:44 --> Controller Class Initialized
INFO - 2023-06-04 16:39:44 --> Model Class Initialized
DEBUG - 2023-06-04 16:39:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-04 16:39:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-04 16:39:50 --> Config Class Initialized
INFO - 2023-06-04 16:39:50 --> Hooks Class Initialized
DEBUG - 2023-06-04 16:39:50 --> UTF-8 Support Enabled
INFO - 2023-06-04 16:39:50 --> Utf8 Class Initialized
INFO - 2023-06-04 16:39:50 --> URI Class Initialized
INFO - 2023-06-04 16:39:50 --> Router Class Initialized
INFO - 2023-06-04 16:39:50 --> Output Class Initialized
INFO - 2023-06-04 16:39:50 --> Security Class Initialized
DEBUG - 2023-06-04 16:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-04 16:39:50 --> Input Class Initialized
INFO - 2023-06-04 16:39:50 --> Language Class Initialized
INFO - 2023-06-04 16:39:50 --> Loader Class Initialized
INFO - 2023-06-04 16:39:50 --> Helper loaded: url_helper
INFO - 2023-06-04 16:39:50 --> Helper loaded: file_helper
INFO - 2023-06-04 16:39:50 --> Helper loaded: html_helper
INFO - 2023-06-04 16:39:50 --> Helper loaded: text_helper
INFO - 2023-06-04 16:39:50 --> Helper loaded: form_helper
INFO - 2023-06-04 16:39:50 --> Helper loaded: lang_helper
INFO - 2023-06-04 16:39:50 --> Helper loaded: security_helper
INFO - 2023-06-04 16:39:50 --> Helper loaded: cookie_helper
INFO - 2023-06-04 16:39:50 --> Database Driver Class Initialized
INFO - 2023-06-04 16:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-04 16:39:50 --> Parser Class Initialized
INFO - 2023-06-04 16:39:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-04 16:39:50 --> Pagination Class Initialized
INFO - 2023-06-04 16:39:50 --> Form Validation Class Initialized
INFO - 2023-06-04 16:39:50 --> Controller Class Initialized
INFO - 2023-06-04 16:39:50 --> Model Class Initialized
DEBUG - 2023-06-04 16:39:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-04 16:39:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-04 16:39:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-04 16:39:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-04 16:39:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-04 16:39:50 --> Model Class Initialized
INFO - 2023-06-04 16:39:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-04 16:39:50 --> Final output sent to browser
DEBUG - 2023-06-04 16:39:50 --> Total execution time: 0.0339
