<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-27 01:44:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 01:44:00 --> Config Class Initialized
INFO - 2023-06-27 01:44:00 --> Hooks Class Initialized
DEBUG - 2023-06-27 01:44:00 --> UTF-8 Support Enabled
INFO - 2023-06-27 01:44:00 --> Utf8 Class Initialized
INFO - 2023-06-27 01:44:00 --> URI Class Initialized
DEBUG - 2023-06-27 01:44:00 --> No URI present. Default controller set.
INFO - 2023-06-27 01:44:00 --> Router Class Initialized
INFO - 2023-06-27 01:44:00 --> Output Class Initialized
INFO - 2023-06-27 01:44:00 --> Security Class Initialized
DEBUG - 2023-06-27 01:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 01:44:00 --> Input Class Initialized
INFO - 2023-06-27 01:44:00 --> Language Class Initialized
INFO - 2023-06-27 01:44:00 --> Loader Class Initialized
INFO - 2023-06-27 01:44:00 --> Helper loaded: url_helper
INFO - 2023-06-27 01:44:00 --> Helper loaded: file_helper
INFO - 2023-06-27 01:44:00 --> Helper loaded: html_helper
INFO - 2023-06-27 01:44:00 --> Helper loaded: text_helper
INFO - 2023-06-27 01:44:00 --> Helper loaded: form_helper
INFO - 2023-06-27 01:44:00 --> Helper loaded: lang_helper
INFO - 2023-06-27 01:44:00 --> Helper loaded: security_helper
INFO - 2023-06-27 01:44:00 --> Helper loaded: cookie_helper
INFO - 2023-06-27 01:44:00 --> Database Driver Class Initialized
INFO - 2023-06-27 01:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 01:44:00 --> Parser Class Initialized
INFO - 2023-06-27 01:44:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 01:44:00 --> Pagination Class Initialized
INFO - 2023-06-27 01:44:00 --> Form Validation Class Initialized
INFO - 2023-06-27 01:44:00 --> Controller Class Initialized
INFO - 2023-06-27 01:44:00 --> Model Class Initialized
DEBUG - 2023-06-27 01:44:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-27 01:44:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 01:44:00 --> Config Class Initialized
INFO - 2023-06-27 01:44:00 --> Hooks Class Initialized
DEBUG - 2023-06-27 01:44:00 --> UTF-8 Support Enabled
INFO - 2023-06-27 01:44:00 --> Utf8 Class Initialized
INFO - 2023-06-27 01:44:00 --> URI Class Initialized
INFO - 2023-06-27 01:44:00 --> Router Class Initialized
INFO - 2023-06-27 01:44:00 --> Output Class Initialized
INFO - 2023-06-27 01:44:00 --> Security Class Initialized
DEBUG - 2023-06-27 01:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 01:44:00 --> Input Class Initialized
INFO - 2023-06-27 01:44:00 --> Language Class Initialized
INFO - 2023-06-27 01:44:00 --> Loader Class Initialized
INFO - 2023-06-27 01:44:00 --> Helper loaded: url_helper
INFO - 2023-06-27 01:44:00 --> Helper loaded: file_helper
INFO - 2023-06-27 01:44:00 --> Helper loaded: html_helper
INFO - 2023-06-27 01:44:00 --> Helper loaded: text_helper
INFO - 2023-06-27 01:44:00 --> Helper loaded: form_helper
INFO - 2023-06-27 01:44:00 --> Helper loaded: lang_helper
INFO - 2023-06-27 01:44:00 --> Helper loaded: security_helper
INFO - 2023-06-27 01:44:00 --> Helper loaded: cookie_helper
INFO - 2023-06-27 01:44:00 --> Database Driver Class Initialized
INFO - 2023-06-27 01:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 01:44:00 --> Parser Class Initialized
INFO - 2023-06-27 01:44:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 01:44:00 --> Pagination Class Initialized
INFO - 2023-06-27 01:44:00 --> Form Validation Class Initialized
INFO - 2023-06-27 01:44:00 --> Controller Class Initialized
INFO - 2023-06-27 01:44:00 --> Model Class Initialized
DEBUG - 2023-06-27 01:44:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 01:44:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-27 01:44:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 01:44:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 01:44:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 01:44:00 --> Model Class Initialized
INFO - 2023-06-27 01:44:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 01:44:00 --> Final output sent to browser
DEBUG - 2023-06-27 01:44:00 --> Total execution time: 0.0305
ERROR - 2023-06-27 01:44:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 01:44:14 --> Config Class Initialized
INFO - 2023-06-27 01:44:14 --> Hooks Class Initialized
DEBUG - 2023-06-27 01:44:14 --> UTF-8 Support Enabled
INFO - 2023-06-27 01:44:14 --> Utf8 Class Initialized
INFO - 2023-06-27 01:44:14 --> URI Class Initialized
INFO - 2023-06-27 01:44:14 --> Router Class Initialized
INFO - 2023-06-27 01:44:14 --> Output Class Initialized
INFO - 2023-06-27 01:44:14 --> Security Class Initialized
DEBUG - 2023-06-27 01:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 01:44:14 --> Input Class Initialized
INFO - 2023-06-27 01:44:14 --> Language Class Initialized
INFO - 2023-06-27 01:44:14 --> Loader Class Initialized
INFO - 2023-06-27 01:44:14 --> Helper loaded: url_helper
INFO - 2023-06-27 01:44:14 --> Helper loaded: file_helper
INFO - 2023-06-27 01:44:14 --> Helper loaded: html_helper
INFO - 2023-06-27 01:44:14 --> Helper loaded: text_helper
INFO - 2023-06-27 01:44:14 --> Helper loaded: form_helper
INFO - 2023-06-27 01:44:14 --> Helper loaded: lang_helper
INFO - 2023-06-27 01:44:14 --> Helper loaded: security_helper
INFO - 2023-06-27 01:44:14 --> Helper loaded: cookie_helper
INFO - 2023-06-27 01:44:14 --> Database Driver Class Initialized
INFO - 2023-06-27 01:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 01:44:14 --> Parser Class Initialized
INFO - 2023-06-27 01:44:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 01:44:14 --> Pagination Class Initialized
INFO - 2023-06-27 01:44:14 --> Form Validation Class Initialized
INFO - 2023-06-27 01:44:14 --> Controller Class Initialized
INFO - 2023-06-27 01:44:14 --> Model Class Initialized
DEBUG - 2023-06-27 01:44:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 01:44:14 --> Model Class Initialized
INFO - 2023-06-27 01:44:14 --> Final output sent to browser
DEBUG - 2023-06-27 01:44:14 --> Total execution time: 0.0323
ERROR - 2023-06-27 01:44:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 01:44:15 --> Config Class Initialized
INFO - 2023-06-27 01:44:15 --> Hooks Class Initialized
DEBUG - 2023-06-27 01:44:15 --> UTF-8 Support Enabled
INFO - 2023-06-27 01:44:15 --> Utf8 Class Initialized
INFO - 2023-06-27 01:44:15 --> URI Class Initialized
INFO - 2023-06-27 01:44:15 --> Router Class Initialized
INFO - 2023-06-27 01:44:15 --> Output Class Initialized
INFO - 2023-06-27 01:44:15 --> Security Class Initialized
DEBUG - 2023-06-27 01:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 01:44:15 --> Input Class Initialized
INFO - 2023-06-27 01:44:15 --> Language Class Initialized
INFO - 2023-06-27 01:44:15 --> Loader Class Initialized
INFO - 2023-06-27 01:44:15 --> Helper loaded: url_helper
INFO - 2023-06-27 01:44:15 --> Helper loaded: file_helper
INFO - 2023-06-27 01:44:15 --> Helper loaded: html_helper
INFO - 2023-06-27 01:44:15 --> Helper loaded: text_helper
INFO - 2023-06-27 01:44:15 --> Helper loaded: form_helper
INFO - 2023-06-27 01:44:15 --> Helper loaded: lang_helper
INFO - 2023-06-27 01:44:15 --> Helper loaded: security_helper
INFO - 2023-06-27 01:44:15 --> Helper loaded: cookie_helper
INFO - 2023-06-27 01:44:15 --> Database Driver Class Initialized
INFO - 2023-06-27 01:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 01:44:15 --> Parser Class Initialized
INFO - 2023-06-27 01:44:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 01:44:15 --> Pagination Class Initialized
INFO - 2023-06-27 01:44:15 --> Form Validation Class Initialized
INFO - 2023-06-27 01:44:15 --> Controller Class Initialized
INFO - 2023-06-27 01:44:15 --> Model Class Initialized
DEBUG - 2023-06-27 01:44:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 01:44:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-27 01:44:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 01:44:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 01:44:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 01:44:15 --> Model Class Initialized
INFO - 2023-06-27 01:44:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 01:44:15 --> Final output sent to browser
DEBUG - 2023-06-27 01:44:15 --> Total execution time: 0.0291
ERROR - 2023-06-27 01:44:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 01:44:30 --> Config Class Initialized
INFO - 2023-06-27 01:44:30 --> Hooks Class Initialized
DEBUG - 2023-06-27 01:44:30 --> UTF-8 Support Enabled
INFO - 2023-06-27 01:44:30 --> Utf8 Class Initialized
INFO - 2023-06-27 01:44:30 --> URI Class Initialized
INFO - 2023-06-27 01:44:30 --> Router Class Initialized
INFO - 2023-06-27 01:44:30 --> Output Class Initialized
INFO - 2023-06-27 01:44:30 --> Security Class Initialized
DEBUG - 2023-06-27 01:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 01:44:30 --> Input Class Initialized
INFO - 2023-06-27 01:44:30 --> Language Class Initialized
INFO - 2023-06-27 01:44:30 --> Loader Class Initialized
INFO - 2023-06-27 01:44:30 --> Helper loaded: url_helper
INFO - 2023-06-27 01:44:30 --> Helper loaded: file_helper
INFO - 2023-06-27 01:44:30 --> Helper loaded: html_helper
INFO - 2023-06-27 01:44:30 --> Helper loaded: text_helper
INFO - 2023-06-27 01:44:30 --> Helper loaded: form_helper
INFO - 2023-06-27 01:44:30 --> Helper loaded: lang_helper
INFO - 2023-06-27 01:44:30 --> Helper loaded: security_helper
INFO - 2023-06-27 01:44:30 --> Helper loaded: cookie_helper
INFO - 2023-06-27 01:44:30 --> Database Driver Class Initialized
INFO - 2023-06-27 01:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 01:44:30 --> Parser Class Initialized
INFO - 2023-06-27 01:44:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 01:44:30 --> Pagination Class Initialized
INFO - 2023-06-27 01:44:30 --> Form Validation Class Initialized
INFO - 2023-06-27 01:44:30 --> Controller Class Initialized
INFO - 2023-06-27 01:44:30 --> Model Class Initialized
DEBUG - 2023-06-27 01:44:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 01:44:30 --> Model Class Initialized
INFO - 2023-06-27 01:44:30 --> Final output sent to browser
DEBUG - 2023-06-27 01:44:30 --> Total execution time: 0.0190
ERROR - 2023-06-27 01:44:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 01:44:31 --> Config Class Initialized
INFO - 2023-06-27 01:44:31 --> Hooks Class Initialized
DEBUG - 2023-06-27 01:44:31 --> UTF-8 Support Enabled
INFO - 2023-06-27 01:44:31 --> Utf8 Class Initialized
INFO - 2023-06-27 01:44:31 --> URI Class Initialized
DEBUG - 2023-06-27 01:44:31 --> No URI present. Default controller set.
INFO - 2023-06-27 01:44:31 --> Router Class Initialized
INFO - 2023-06-27 01:44:31 --> Output Class Initialized
INFO - 2023-06-27 01:44:31 --> Security Class Initialized
DEBUG - 2023-06-27 01:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 01:44:31 --> Input Class Initialized
INFO - 2023-06-27 01:44:31 --> Language Class Initialized
INFO - 2023-06-27 01:44:31 --> Loader Class Initialized
INFO - 2023-06-27 01:44:31 --> Helper loaded: url_helper
INFO - 2023-06-27 01:44:31 --> Helper loaded: file_helper
INFO - 2023-06-27 01:44:31 --> Helper loaded: html_helper
INFO - 2023-06-27 01:44:31 --> Helper loaded: text_helper
INFO - 2023-06-27 01:44:31 --> Helper loaded: form_helper
INFO - 2023-06-27 01:44:31 --> Helper loaded: lang_helper
INFO - 2023-06-27 01:44:31 --> Helper loaded: security_helper
INFO - 2023-06-27 01:44:31 --> Helper loaded: cookie_helper
INFO - 2023-06-27 01:44:31 --> Database Driver Class Initialized
INFO - 2023-06-27 01:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 01:44:31 --> Parser Class Initialized
INFO - 2023-06-27 01:44:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 01:44:31 --> Pagination Class Initialized
INFO - 2023-06-27 01:44:31 --> Form Validation Class Initialized
INFO - 2023-06-27 01:44:31 --> Controller Class Initialized
INFO - 2023-06-27 01:44:31 --> Model Class Initialized
DEBUG - 2023-06-27 01:44:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 01:44:31 --> Model Class Initialized
DEBUG - 2023-06-27 01:44:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 01:44:31 --> Model Class Initialized
INFO - 2023-06-27 01:44:31 --> Model Class Initialized
INFO - 2023-06-27 01:44:31 --> Model Class Initialized
INFO - 2023-06-27 01:44:31 --> Model Class Initialized
DEBUG - 2023-06-27 01:44:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 01:44:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 01:44:31 --> Model Class Initialized
INFO - 2023-06-27 01:44:31 --> Model Class Initialized
INFO - 2023-06-27 01:44:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 01:44:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 01:44:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 01:44:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 01:44:31 --> Model Class Initialized
INFO - 2023-06-27 01:44:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 01:44:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 01:44:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 01:44:31 --> Final output sent to browser
DEBUG - 2023-06-27 01:44:31 --> Total execution time: 0.0825
ERROR - 2023-06-27 01:45:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 01:45:25 --> Config Class Initialized
INFO - 2023-06-27 01:45:25 --> Hooks Class Initialized
DEBUG - 2023-06-27 01:45:25 --> UTF-8 Support Enabled
INFO - 2023-06-27 01:45:25 --> Utf8 Class Initialized
INFO - 2023-06-27 01:45:25 --> URI Class Initialized
INFO - 2023-06-27 01:45:25 --> Router Class Initialized
INFO - 2023-06-27 01:45:25 --> Output Class Initialized
INFO - 2023-06-27 01:45:25 --> Security Class Initialized
DEBUG - 2023-06-27 01:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 01:45:25 --> Input Class Initialized
INFO - 2023-06-27 01:45:25 --> Language Class Initialized
INFO - 2023-06-27 01:45:25 --> Loader Class Initialized
INFO - 2023-06-27 01:45:25 --> Helper loaded: url_helper
INFO - 2023-06-27 01:45:25 --> Helper loaded: file_helper
INFO - 2023-06-27 01:45:25 --> Helper loaded: html_helper
INFO - 2023-06-27 01:45:25 --> Helper loaded: text_helper
INFO - 2023-06-27 01:45:25 --> Helper loaded: form_helper
INFO - 2023-06-27 01:45:25 --> Helper loaded: lang_helper
INFO - 2023-06-27 01:45:25 --> Helper loaded: security_helper
INFO - 2023-06-27 01:45:25 --> Helper loaded: cookie_helper
INFO - 2023-06-27 01:45:25 --> Database Driver Class Initialized
INFO - 2023-06-27 01:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 01:45:25 --> Parser Class Initialized
INFO - 2023-06-27 01:45:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 01:45:25 --> Pagination Class Initialized
INFO - 2023-06-27 01:45:25 --> Form Validation Class Initialized
INFO - 2023-06-27 01:45:25 --> Controller Class Initialized
DEBUG - 2023-06-27 01:45:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 01:45:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 01:45:25 --> Model Class Initialized
DEBUG - 2023-06-27 01:45:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 01:45:25 --> Model Class Initialized
DEBUG - 2023-06-27 01:45:25 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-06-27 01:45:25 --> Model Class Initialized
INFO - 2023-06-27 01:45:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-06-27 01:45:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 01:45:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 01:45:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 01:45:25 --> Model Class Initialized
INFO - 2023-06-27 01:45:25 --> Model Class Initialized
INFO - 2023-06-27 01:45:25 --> Model Class Initialized
INFO - 2023-06-27 01:45:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 01:45:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 01:45:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 01:45:25 --> Final output sent to browser
DEBUG - 2023-06-27 01:45:25 --> Total execution time: 0.0698
ERROR - 2023-06-27 01:45:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 01:45:26 --> Config Class Initialized
INFO - 2023-06-27 01:45:26 --> Hooks Class Initialized
DEBUG - 2023-06-27 01:45:26 --> UTF-8 Support Enabled
INFO - 2023-06-27 01:45:26 --> Utf8 Class Initialized
INFO - 2023-06-27 01:45:26 --> URI Class Initialized
INFO - 2023-06-27 01:45:26 --> Router Class Initialized
INFO - 2023-06-27 01:45:26 --> Output Class Initialized
INFO - 2023-06-27 01:45:26 --> Security Class Initialized
DEBUG - 2023-06-27 01:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 01:45:26 --> Input Class Initialized
INFO - 2023-06-27 01:45:26 --> Language Class Initialized
INFO - 2023-06-27 01:45:26 --> Loader Class Initialized
INFO - 2023-06-27 01:45:26 --> Helper loaded: url_helper
INFO - 2023-06-27 01:45:26 --> Helper loaded: file_helper
INFO - 2023-06-27 01:45:26 --> Helper loaded: html_helper
INFO - 2023-06-27 01:45:26 --> Helper loaded: text_helper
INFO - 2023-06-27 01:45:26 --> Helper loaded: form_helper
INFO - 2023-06-27 01:45:26 --> Helper loaded: lang_helper
INFO - 2023-06-27 01:45:26 --> Helper loaded: security_helper
INFO - 2023-06-27 01:45:26 --> Helper loaded: cookie_helper
INFO - 2023-06-27 01:45:26 --> Database Driver Class Initialized
INFO - 2023-06-27 01:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 01:45:26 --> Parser Class Initialized
INFO - 2023-06-27 01:45:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 01:45:26 --> Pagination Class Initialized
INFO - 2023-06-27 01:45:26 --> Form Validation Class Initialized
INFO - 2023-06-27 01:45:26 --> Controller Class Initialized
DEBUG - 2023-06-27 01:45:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 01:45:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 01:45:26 --> Model Class Initialized
DEBUG - 2023-06-27 01:45:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 01:45:26 --> Model Class Initialized
INFO - 2023-06-27 01:45:26 --> Final output sent to browser
DEBUG - 2023-06-27 01:45:26 --> Total execution time: 0.0213
ERROR - 2023-06-27 01:45:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 01:45:48 --> Config Class Initialized
INFO - 2023-06-27 01:45:48 --> Hooks Class Initialized
DEBUG - 2023-06-27 01:45:48 --> UTF-8 Support Enabled
INFO - 2023-06-27 01:45:48 --> Utf8 Class Initialized
INFO - 2023-06-27 01:45:48 --> URI Class Initialized
INFO - 2023-06-27 01:45:48 --> Router Class Initialized
INFO - 2023-06-27 01:45:48 --> Output Class Initialized
INFO - 2023-06-27 01:45:48 --> Security Class Initialized
DEBUG - 2023-06-27 01:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 01:45:48 --> Input Class Initialized
INFO - 2023-06-27 01:45:48 --> Language Class Initialized
INFO - 2023-06-27 01:45:48 --> Loader Class Initialized
INFO - 2023-06-27 01:45:48 --> Helper loaded: url_helper
INFO - 2023-06-27 01:45:48 --> Helper loaded: file_helper
INFO - 2023-06-27 01:45:48 --> Helper loaded: html_helper
INFO - 2023-06-27 01:45:48 --> Helper loaded: text_helper
INFO - 2023-06-27 01:45:48 --> Helper loaded: form_helper
INFO - 2023-06-27 01:45:48 --> Helper loaded: lang_helper
INFO - 2023-06-27 01:45:48 --> Helper loaded: security_helper
INFO - 2023-06-27 01:45:48 --> Helper loaded: cookie_helper
INFO - 2023-06-27 01:45:48 --> Database Driver Class Initialized
INFO - 2023-06-27 01:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 01:45:48 --> Parser Class Initialized
INFO - 2023-06-27 01:45:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 01:45:48 --> Pagination Class Initialized
INFO - 2023-06-27 01:45:48 --> Form Validation Class Initialized
INFO - 2023-06-27 01:45:48 --> Controller Class Initialized
DEBUG - 2023-06-27 01:45:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 01:45:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 01:45:48 --> Model Class Initialized
DEBUG - 2023-06-27 01:45:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 01:45:48 --> Model Class Initialized
INFO - 2023-06-27 01:45:48 --> Final output sent to browser
DEBUG - 2023-06-27 01:45:48 --> Total execution time: 0.0260
ERROR - 2023-06-27 01:46:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 01:46:28 --> Config Class Initialized
INFO - 2023-06-27 01:46:28 --> Hooks Class Initialized
DEBUG - 2023-06-27 01:46:28 --> UTF-8 Support Enabled
INFO - 2023-06-27 01:46:28 --> Utf8 Class Initialized
INFO - 2023-06-27 01:46:28 --> URI Class Initialized
INFO - 2023-06-27 01:46:28 --> Router Class Initialized
INFO - 2023-06-27 01:46:28 --> Output Class Initialized
INFO - 2023-06-27 01:46:28 --> Security Class Initialized
DEBUG - 2023-06-27 01:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 01:46:28 --> Input Class Initialized
INFO - 2023-06-27 01:46:28 --> Language Class Initialized
INFO - 2023-06-27 01:46:28 --> Loader Class Initialized
INFO - 2023-06-27 01:46:28 --> Helper loaded: url_helper
INFO - 2023-06-27 01:46:28 --> Helper loaded: file_helper
INFO - 2023-06-27 01:46:28 --> Helper loaded: html_helper
INFO - 2023-06-27 01:46:28 --> Helper loaded: text_helper
INFO - 2023-06-27 01:46:28 --> Helper loaded: form_helper
INFO - 2023-06-27 01:46:28 --> Helper loaded: lang_helper
INFO - 2023-06-27 01:46:28 --> Helper loaded: security_helper
INFO - 2023-06-27 01:46:28 --> Helper loaded: cookie_helper
INFO - 2023-06-27 01:46:28 --> Database Driver Class Initialized
INFO - 2023-06-27 01:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 01:46:28 --> Parser Class Initialized
INFO - 2023-06-27 01:46:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 01:46:28 --> Pagination Class Initialized
INFO - 2023-06-27 01:46:28 --> Form Validation Class Initialized
INFO - 2023-06-27 01:46:28 --> Controller Class Initialized
DEBUG - 2023-06-27 01:46:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 01:46:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 01:46:28 --> Model Class Initialized
DEBUG - 2023-06-27 01:46:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 01:46:28 --> Model Class Initialized
INFO - 2023-06-27 01:46:28 --> Final output sent to browser
DEBUG - 2023-06-27 01:46:28 --> Total execution time: 0.0246
ERROR - 2023-06-27 01:46:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 01:46:36 --> Config Class Initialized
INFO - 2023-06-27 01:46:36 --> Hooks Class Initialized
DEBUG - 2023-06-27 01:46:36 --> UTF-8 Support Enabled
INFO - 2023-06-27 01:46:36 --> Utf8 Class Initialized
INFO - 2023-06-27 01:46:36 --> URI Class Initialized
INFO - 2023-06-27 01:46:36 --> Router Class Initialized
INFO - 2023-06-27 01:46:36 --> Output Class Initialized
INFO - 2023-06-27 01:46:36 --> Security Class Initialized
DEBUG - 2023-06-27 01:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 01:46:36 --> Input Class Initialized
INFO - 2023-06-27 01:46:36 --> Language Class Initialized
INFO - 2023-06-27 01:46:36 --> Loader Class Initialized
INFO - 2023-06-27 01:46:36 --> Helper loaded: url_helper
INFO - 2023-06-27 01:46:36 --> Helper loaded: file_helper
INFO - 2023-06-27 01:46:36 --> Helper loaded: html_helper
INFO - 2023-06-27 01:46:36 --> Helper loaded: text_helper
INFO - 2023-06-27 01:46:36 --> Helper loaded: form_helper
INFO - 2023-06-27 01:46:36 --> Helper loaded: lang_helper
INFO - 2023-06-27 01:46:36 --> Helper loaded: security_helper
INFO - 2023-06-27 01:46:36 --> Helper loaded: cookie_helper
INFO - 2023-06-27 01:46:36 --> Database Driver Class Initialized
INFO - 2023-06-27 01:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 01:46:36 --> Parser Class Initialized
INFO - 2023-06-27 01:46:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 01:46:36 --> Pagination Class Initialized
INFO - 2023-06-27 01:46:36 --> Form Validation Class Initialized
INFO - 2023-06-27 01:46:36 --> Controller Class Initialized
DEBUG - 2023-06-27 01:46:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 01:46:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 01:46:36 --> Model Class Initialized
DEBUG - 2023-06-27 01:46:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 01:46:36 --> Model Class Initialized
INFO - 2023-06-27 01:46:36 --> Final output sent to browser
DEBUG - 2023-06-27 01:46:36 --> Total execution time: 0.0284
ERROR - 2023-06-27 02:38:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 02:38:30 --> Config Class Initialized
INFO - 2023-06-27 02:38:30 --> Hooks Class Initialized
DEBUG - 2023-06-27 02:38:30 --> UTF-8 Support Enabled
INFO - 2023-06-27 02:38:30 --> Utf8 Class Initialized
INFO - 2023-06-27 02:38:30 --> URI Class Initialized
INFO - 2023-06-27 02:38:30 --> Router Class Initialized
INFO - 2023-06-27 02:38:30 --> Output Class Initialized
INFO - 2023-06-27 02:38:30 --> Security Class Initialized
DEBUG - 2023-06-27 02:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 02:38:30 --> Input Class Initialized
INFO - 2023-06-27 02:38:30 --> Language Class Initialized
INFO - 2023-06-27 02:38:30 --> Loader Class Initialized
INFO - 2023-06-27 02:38:30 --> Helper loaded: url_helper
INFO - 2023-06-27 02:38:30 --> Helper loaded: file_helper
INFO - 2023-06-27 02:38:30 --> Helper loaded: html_helper
INFO - 2023-06-27 02:38:30 --> Helper loaded: text_helper
INFO - 2023-06-27 02:38:30 --> Helper loaded: form_helper
INFO - 2023-06-27 02:38:30 --> Helper loaded: lang_helper
INFO - 2023-06-27 02:38:30 --> Helper loaded: security_helper
INFO - 2023-06-27 02:38:30 --> Helper loaded: cookie_helper
INFO - 2023-06-27 02:38:30 --> Database Driver Class Initialized
INFO - 2023-06-27 02:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 02:38:30 --> Parser Class Initialized
INFO - 2023-06-27 02:38:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 02:38:30 --> Pagination Class Initialized
INFO - 2023-06-27 02:38:30 --> Form Validation Class Initialized
INFO - 2023-06-27 02:38:30 --> Controller Class Initialized
INFO - 2023-06-27 02:38:30 --> Model Class Initialized
DEBUG - 2023-06-27 02:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 02:38:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-27 02:38:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 02:38:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 02:38:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 02:38:30 --> Model Class Initialized
INFO - 2023-06-27 02:38:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 02:38:30 --> Final output sent to browser
DEBUG - 2023-06-27 02:38:30 --> Total execution time: 0.0317
ERROR - 2023-06-27 02:40:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 02:40:03 --> Config Class Initialized
INFO - 2023-06-27 02:40:03 --> Hooks Class Initialized
DEBUG - 2023-06-27 02:40:03 --> UTF-8 Support Enabled
INFO - 2023-06-27 02:40:03 --> Utf8 Class Initialized
INFO - 2023-06-27 02:40:03 --> URI Class Initialized
DEBUG - 2023-06-27 02:40:03 --> No URI present. Default controller set.
INFO - 2023-06-27 02:40:03 --> Router Class Initialized
INFO - 2023-06-27 02:40:03 --> Output Class Initialized
INFO - 2023-06-27 02:40:03 --> Security Class Initialized
DEBUG - 2023-06-27 02:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 02:40:03 --> Input Class Initialized
INFO - 2023-06-27 02:40:03 --> Language Class Initialized
INFO - 2023-06-27 02:40:03 --> Loader Class Initialized
INFO - 2023-06-27 02:40:03 --> Helper loaded: url_helper
INFO - 2023-06-27 02:40:03 --> Helper loaded: file_helper
INFO - 2023-06-27 02:40:03 --> Helper loaded: html_helper
INFO - 2023-06-27 02:40:03 --> Helper loaded: text_helper
INFO - 2023-06-27 02:40:03 --> Helper loaded: form_helper
INFO - 2023-06-27 02:40:03 --> Helper loaded: lang_helper
INFO - 2023-06-27 02:40:03 --> Helper loaded: security_helper
INFO - 2023-06-27 02:40:03 --> Helper loaded: cookie_helper
INFO - 2023-06-27 02:40:03 --> Database Driver Class Initialized
INFO - 2023-06-27 02:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 02:40:03 --> Parser Class Initialized
INFO - 2023-06-27 02:40:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 02:40:03 --> Pagination Class Initialized
INFO - 2023-06-27 02:40:03 --> Form Validation Class Initialized
INFO - 2023-06-27 02:40:03 --> Controller Class Initialized
INFO - 2023-06-27 02:40:03 --> Model Class Initialized
DEBUG - 2023-06-27 02:40:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-27 03:03:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 03:03:49 --> Config Class Initialized
INFO - 2023-06-27 03:03:49 --> Hooks Class Initialized
DEBUG - 2023-06-27 03:03:49 --> UTF-8 Support Enabled
INFO - 2023-06-27 03:03:49 --> Utf8 Class Initialized
INFO - 2023-06-27 03:03:49 --> URI Class Initialized
DEBUG - 2023-06-27 03:03:49 --> No URI present. Default controller set.
INFO - 2023-06-27 03:03:49 --> Router Class Initialized
INFO - 2023-06-27 03:03:49 --> Output Class Initialized
INFO - 2023-06-27 03:03:49 --> Security Class Initialized
DEBUG - 2023-06-27 03:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 03:03:49 --> Input Class Initialized
INFO - 2023-06-27 03:03:49 --> Language Class Initialized
INFO - 2023-06-27 03:03:49 --> Loader Class Initialized
INFO - 2023-06-27 03:03:49 --> Helper loaded: url_helper
INFO - 2023-06-27 03:03:49 --> Helper loaded: file_helper
INFO - 2023-06-27 03:03:49 --> Helper loaded: html_helper
INFO - 2023-06-27 03:03:49 --> Helper loaded: text_helper
INFO - 2023-06-27 03:03:49 --> Helper loaded: form_helper
INFO - 2023-06-27 03:03:49 --> Helper loaded: lang_helper
INFO - 2023-06-27 03:03:49 --> Helper loaded: security_helper
INFO - 2023-06-27 03:03:49 --> Helper loaded: cookie_helper
INFO - 2023-06-27 03:03:49 --> Database Driver Class Initialized
INFO - 2023-06-27 03:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 03:03:49 --> Parser Class Initialized
INFO - 2023-06-27 03:03:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 03:03:49 --> Pagination Class Initialized
INFO - 2023-06-27 03:03:49 --> Form Validation Class Initialized
INFO - 2023-06-27 03:03:49 --> Controller Class Initialized
INFO - 2023-06-27 03:03:49 --> Model Class Initialized
DEBUG - 2023-06-27 03:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 03:03:49 --> Model Class Initialized
DEBUG - 2023-06-27 03:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 03:03:49 --> Model Class Initialized
INFO - 2023-06-27 03:03:49 --> Model Class Initialized
INFO - 2023-06-27 03:03:49 --> Model Class Initialized
INFO - 2023-06-27 03:03:49 --> Model Class Initialized
DEBUG - 2023-06-27 03:03:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 03:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 03:03:49 --> Model Class Initialized
INFO - 2023-06-27 03:03:49 --> Model Class Initialized
INFO - 2023-06-27 03:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 03:03:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 03:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 03:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 03:03:49 --> Model Class Initialized
INFO - 2023-06-27 03:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 03:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 03:03:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 03:03:49 --> Final output sent to browser
DEBUG - 2023-06-27 03:03:49 --> Total execution time: 0.0822
ERROR - 2023-06-27 03:03:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 03:03:55 --> Config Class Initialized
INFO - 2023-06-27 03:03:55 --> Hooks Class Initialized
DEBUG - 2023-06-27 03:03:55 --> UTF-8 Support Enabled
INFO - 2023-06-27 03:03:55 --> Utf8 Class Initialized
INFO - 2023-06-27 03:03:55 --> URI Class Initialized
INFO - 2023-06-27 03:03:55 --> Router Class Initialized
INFO - 2023-06-27 03:03:55 --> Output Class Initialized
INFO - 2023-06-27 03:03:55 --> Security Class Initialized
DEBUG - 2023-06-27 03:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 03:03:55 --> Input Class Initialized
INFO - 2023-06-27 03:03:55 --> Language Class Initialized
INFO - 2023-06-27 03:03:55 --> Loader Class Initialized
INFO - 2023-06-27 03:03:55 --> Helper loaded: url_helper
INFO - 2023-06-27 03:03:55 --> Helper loaded: file_helper
INFO - 2023-06-27 03:03:55 --> Helper loaded: html_helper
INFO - 2023-06-27 03:03:55 --> Helper loaded: text_helper
INFO - 2023-06-27 03:03:55 --> Helper loaded: form_helper
INFO - 2023-06-27 03:03:55 --> Helper loaded: lang_helper
INFO - 2023-06-27 03:03:55 --> Helper loaded: security_helper
INFO - 2023-06-27 03:03:55 --> Helper loaded: cookie_helper
INFO - 2023-06-27 03:03:55 --> Database Driver Class Initialized
INFO - 2023-06-27 03:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 03:03:55 --> Parser Class Initialized
INFO - 2023-06-27 03:03:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 03:03:55 --> Pagination Class Initialized
INFO - 2023-06-27 03:03:55 --> Form Validation Class Initialized
INFO - 2023-06-27 03:03:55 --> Controller Class Initialized
DEBUG - 2023-06-27 03:03:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 03:03:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 03:03:55 --> Model Class Initialized
DEBUG - 2023-06-27 03:03:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 03:03:55 --> Model Class Initialized
DEBUG - 2023-06-27 03:03:55 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-06-27 03:03:55 --> Model Class Initialized
INFO - 2023-06-27 03:03:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-06-27 03:03:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 03:03:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 03:03:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 03:03:55 --> Model Class Initialized
INFO - 2023-06-27 03:03:55 --> Model Class Initialized
INFO - 2023-06-27 03:03:55 --> Model Class Initialized
INFO - 2023-06-27 03:03:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 03:03:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 03:03:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 03:03:55 --> Final output sent to browser
DEBUG - 2023-06-27 03:03:55 --> Total execution time: 0.0683
ERROR - 2023-06-27 03:03:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 03:03:55 --> Config Class Initialized
INFO - 2023-06-27 03:03:55 --> Hooks Class Initialized
DEBUG - 2023-06-27 03:03:55 --> UTF-8 Support Enabled
INFO - 2023-06-27 03:03:55 --> Utf8 Class Initialized
INFO - 2023-06-27 03:03:55 --> URI Class Initialized
INFO - 2023-06-27 03:03:55 --> Router Class Initialized
INFO - 2023-06-27 03:03:55 --> Output Class Initialized
INFO - 2023-06-27 03:03:55 --> Security Class Initialized
DEBUG - 2023-06-27 03:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 03:03:55 --> Input Class Initialized
INFO - 2023-06-27 03:03:55 --> Language Class Initialized
INFO - 2023-06-27 03:03:55 --> Loader Class Initialized
INFO - 2023-06-27 03:03:55 --> Helper loaded: url_helper
INFO - 2023-06-27 03:03:55 --> Helper loaded: file_helper
INFO - 2023-06-27 03:03:55 --> Helper loaded: html_helper
INFO - 2023-06-27 03:03:55 --> Helper loaded: text_helper
INFO - 2023-06-27 03:03:55 --> Helper loaded: form_helper
INFO - 2023-06-27 03:03:55 --> Helper loaded: lang_helper
INFO - 2023-06-27 03:03:55 --> Helper loaded: security_helper
INFO - 2023-06-27 03:03:55 --> Helper loaded: cookie_helper
INFO - 2023-06-27 03:03:55 --> Database Driver Class Initialized
INFO - 2023-06-27 03:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 03:03:55 --> Parser Class Initialized
INFO - 2023-06-27 03:03:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 03:03:55 --> Pagination Class Initialized
INFO - 2023-06-27 03:03:55 --> Form Validation Class Initialized
INFO - 2023-06-27 03:03:55 --> Controller Class Initialized
DEBUG - 2023-06-27 03:03:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 03:03:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 03:03:55 --> Model Class Initialized
DEBUG - 2023-06-27 03:03:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 03:03:55 --> Model Class Initialized
INFO - 2023-06-27 03:03:55 --> Final output sent to browser
DEBUG - 2023-06-27 03:03:55 --> Total execution time: 0.0210
ERROR - 2023-06-27 03:03:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 03:03:59 --> Config Class Initialized
INFO - 2023-06-27 03:03:59 --> Hooks Class Initialized
DEBUG - 2023-06-27 03:03:59 --> UTF-8 Support Enabled
INFO - 2023-06-27 03:03:59 --> Utf8 Class Initialized
INFO - 2023-06-27 03:03:59 --> URI Class Initialized
INFO - 2023-06-27 03:03:59 --> Router Class Initialized
INFO - 2023-06-27 03:03:59 --> Output Class Initialized
INFO - 2023-06-27 03:03:59 --> Security Class Initialized
DEBUG - 2023-06-27 03:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 03:03:59 --> Input Class Initialized
INFO - 2023-06-27 03:03:59 --> Language Class Initialized
INFO - 2023-06-27 03:03:59 --> Loader Class Initialized
INFO - 2023-06-27 03:03:59 --> Helper loaded: url_helper
INFO - 2023-06-27 03:03:59 --> Helper loaded: file_helper
INFO - 2023-06-27 03:03:59 --> Helper loaded: html_helper
INFO - 2023-06-27 03:03:59 --> Helper loaded: text_helper
INFO - 2023-06-27 03:03:59 --> Helper loaded: form_helper
INFO - 2023-06-27 03:03:59 --> Helper loaded: lang_helper
INFO - 2023-06-27 03:03:59 --> Helper loaded: security_helper
INFO - 2023-06-27 03:03:59 --> Helper loaded: cookie_helper
INFO - 2023-06-27 03:03:59 --> Database Driver Class Initialized
INFO - 2023-06-27 03:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 03:03:59 --> Parser Class Initialized
INFO - 2023-06-27 03:03:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 03:03:59 --> Pagination Class Initialized
INFO - 2023-06-27 03:03:59 --> Form Validation Class Initialized
INFO - 2023-06-27 03:03:59 --> Controller Class Initialized
DEBUG - 2023-06-27 03:03:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 03:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 03:03:59 --> Model Class Initialized
DEBUG - 2023-06-27 03:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 03:03:59 --> Model Class Initialized
INFO - 2023-06-27 03:03:59 --> Final output sent to browser
DEBUG - 2023-06-27 03:03:59 --> Total execution time: 0.0315
ERROR - 2023-06-27 03:04:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 03:04:03 --> Config Class Initialized
INFO - 2023-06-27 03:04:03 --> Hooks Class Initialized
DEBUG - 2023-06-27 03:04:03 --> UTF-8 Support Enabled
INFO - 2023-06-27 03:04:03 --> Utf8 Class Initialized
INFO - 2023-06-27 03:04:03 --> URI Class Initialized
INFO - 2023-06-27 03:04:03 --> Router Class Initialized
INFO - 2023-06-27 03:04:03 --> Output Class Initialized
INFO - 2023-06-27 03:04:03 --> Security Class Initialized
DEBUG - 2023-06-27 03:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 03:04:03 --> Input Class Initialized
INFO - 2023-06-27 03:04:03 --> Language Class Initialized
INFO - 2023-06-27 03:04:03 --> Loader Class Initialized
INFO - 2023-06-27 03:04:03 --> Helper loaded: url_helper
INFO - 2023-06-27 03:04:03 --> Helper loaded: file_helper
INFO - 2023-06-27 03:04:03 --> Helper loaded: html_helper
INFO - 2023-06-27 03:04:03 --> Helper loaded: text_helper
INFO - 2023-06-27 03:04:03 --> Helper loaded: form_helper
INFO - 2023-06-27 03:04:03 --> Helper loaded: lang_helper
INFO - 2023-06-27 03:04:03 --> Helper loaded: security_helper
INFO - 2023-06-27 03:04:03 --> Helper loaded: cookie_helper
INFO - 2023-06-27 03:04:03 --> Database Driver Class Initialized
INFO - 2023-06-27 03:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 03:04:03 --> Parser Class Initialized
INFO - 2023-06-27 03:04:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 03:04:03 --> Pagination Class Initialized
INFO - 2023-06-27 03:04:03 --> Form Validation Class Initialized
INFO - 2023-06-27 03:04:03 --> Controller Class Initialized
DEBUG - 2023-06-27 03:04:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 03:04:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 03:04:03 --> Model Class Initialized
DEBUG - 2023-06-27 03:04:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 03:04:03 --> Model Class Initialized
INFO - 2023-06-27 03:04:03 --> Final output sent to browser
DEBUG - 2023-06-27 03:04:03 --> Total execution time: 0.0233
ERROR - 2023-06-27 03:04:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 03:04:21 --> Config Class Initialized
INFO - 2023-06-27 03:04:21 --> Hooks Class Initialized
DEBUG - 2023-06-27 03:04:21 --> UTF-8 Support Enabled
INFO - 2023-06-27 03:04:21 --> Utf8 Class Initialized
INFO - 2023-06-27 03:04:21 --> URI Class Initialized
INFO - 2023-06-27 03:04:21 --> Router Class Initialized
INFO - 2023-06-27 03:04:21 --> Output Class Initialized
INFO - 2023-06-27 03:04:21 --> Security Class Initialized
DEBUG - 2023-06-27 03:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 03:04:21 --> Input Class Initialized
INFO - 2023-06-27 03:04:21 --> Language Class Initialized
INFO - 2023-06-27 03:04:21 --> Loader Class Initialized
INFO - 2023-06-27 03:04:21 --> Helper loaded: url_helper
INFO - 2023-06-27 03:04:21 --> Helper loaded: file_helper
INFO - 2023-06-27 03:04:21 --> Helper loaded: html_helper
INFO - 2023-06-27 03:04:21 --> Helper loaded: text_helper
INFO - 2023-06-27 03:04:21 --> Helper loaded: form_helper
INFO - 2023-06-27 03:04:21 --> Helper loaded: lang_helper
INFO - 2023-06-27 03:04:21 --> Helper loaded: security_helper
INFO - 2023-06-27 03:04:21 --> Helper loaded: cookie_helper
INFO - 2023-06-27 03:04:21 --> Database Driver Class Initialized
INFO - 2023-06-27 03:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 03:04:21 --> Parser Class Initialized
INFO - 2023-06-27 03:04:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 03:04:21 --> Pagination Class Initialized
INFO - 2023-06-27 03:04:21 --> Form Validation Class Initialized
INFO - 2023-06-27 03:04:21 --> Controller Class Initialized
DEBUG - 2023-06-27 03:04:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 03:04:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 03:04:21 --> Model Class Initialized
DEBUG - 2023-06-27 03:04:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 03:04:21 --> Model Class Initialized
INFO - 2023-06-27 03:04:21 --> Final output sent to browser
DEBUG - 2023-06-27 03:04:21 --> Total execution time: 0.0339
ERROR - 2023-06-27 08:00:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:00:47 --> Config Class Initialized
INFO - 2023-06-27 08:00:47 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:00:47 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:00:47 --> Utf8 Class Initialized
INFO - 2023-06-27 08:00:47 --> URI Class Initialized
DEBUG - 2023-06-27 08:00:47 --> No URI present. Default controller set.
INFO - 2023-06-27 08:00:47 --> Router Class Initialized
INFO - 2023-06-27 08:00:47 --> Output Class Initialized
INFO - 2023-06-27 08:00:47 --> Security Class Initialized
DEBUG - 2023-06-27 08:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:00:47 --> Input Class Initialized
INFO - 2023-06-27 08:00:47 --> Language Class Initialized
INFO - 2023-06-27 08:00:47 --> Loader Class Initialized
INFO - 2023-06-27 08:00:47 --> Helper loaded: url_helper
INFO - 2023-06-27 08:00:47 --> Helper loaded: file_helper
INFO - 2023-06-27 08:00:47 --> Helper loaded: html_helper
INFO - 2023-06-27 08:00:47 --> Helper loaded: text_helper
INFO - 2023-06-27 08:00:47 --> Helper loaded: form_helper
INFO - 2023-06-27 08:00:47 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:00:47 --> Helper loaded: security_helper
INFO - 2023-06-27 08:00:47 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:00:47 --> Database Driver Class Initialized
INFO - 2023-06-27 08:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:00:47 --> Parser Class Initialized
INFO - 2023-06-27 08:00:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:00:47 --> Pagination Class Initialized
INFO - 2023-06-27 08:00:47 --> Form Validation Class Initialized
INFO - 2023-06-27 08:00:47 --> Controller Class Initialized
INFO - 2023-06-27 08:00:47 --> Model Class Initialized
DEBUG - 2023-06-27 08:00:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-27 08:00:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:00:47 --> Config Class Initialized
INFO - 2023-06-27 08:00:47 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:00:47 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:00:47 --> Utf8 Class Initialized
INFO - 2023-06-27 08:00:47 --> URI Class Initialized
INFO - 2023-06-27 08:00:47 --> Router Class Initialized
INFO - 2023-06-27 08:00:47 --> Output Class Initialized
INFO - 2023-06-27 08:00:47 --> Security Class Initialized
DEBUG - 2023-06-27 08:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:00:47 --> Input Class Initialized
INFO - 2023-06-27 08:00:47 --> Language Class Initialized
INFO - 2023-06-27 08:00:47 --> Loader Class Initialized
INFO - 2023-06-27 08:00:47 --> Helper loaded: url_helper
INFO - 2023-06-27 08:00:47 --> Helper loaded: file_helper
INFO - 2023-06-27 08:00:47 --> Helper loaded: html_helper
INFO - 2023-06-27 08:00:47 --> Helper loaded: text_helper
INFO - 2023-06-27 08:00:47 --> Helper loaded: form_helper
INFO - 2023-06-27 08:00:47 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:00:47 --> Helper loaded: security_helper
INFO - 2023-06-27 08:00:47 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:00:47 --> Database Driver Class Initialized
INFO - 2023-06-27 08:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:00:47 --> Parser Class Initialized
INFO - 2023-06-27 08:00:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:00:47 --> Pagination Class Initialized
INFO - 2023-06-27 08:00:47 --> Form Validation Class Initialized
INFO - 2023-06-27 08:00:47 --> Controller Class Initialized
INFO - 2023-06-27 08:00:47 --> Model Class Initialized
DEBUG - 2023-06-27 08:00:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:00:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-27 08:00:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:00:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:00:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:00:47 --> Model Class Initialized
INFO - 2023-06-27 08:00:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:00:47 --> Final output sent to browser
DEBUG - 2023-06-27 08:00:47 --> Total execution time: 0.0320
ERROR - 2023-06-27 08:22:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:22:15 --> Config Class Initialized
INFO - 2023-06-27 08:22:15 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:22:15 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:22:15 --> Utf8 Class Initialized
INFO - 2023-06-27 08:22:15 --> URI Class Initialized
DEBUG - 2023-06-27 08:22:15 --> No URI present. Default controller set.
INFO - 2023-06-27 08:22:15 --> Router Class Initialized
INFO - 2023-06-27 08:22:15 --> Output Class Initialized
INFO - 2023-06-27 08:22:15 --> Security Class Initialized
DEBUG - 2023-06-27 08:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:22:15 --> Input Class Initialized
INFO - 2023-06-27 08:22:15 --> Language Class Initialized
INFO - 2023-06-27 08:22:15 --> Loader Class Initialized
INFO - 2023-06-27 08:22:15 --> Helper loaded: url_helper
INFO - 2023-06-27 08:22:15 --> Helper loaded: file_helper
INFO - 2023-06-27 08:22:15 --> Helper loaded: html_helper
INFO - 2023-06-27 08:22:15 --> Helper loaded: text_helper
INFO - 2023-06-27 08:22:15 --> Helper loaded: form_helper
INFO - 2023-06-27 08:22:15 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:22:15 --> Helper loaded: security_helper
INFO - 2023-06-27 08:22:15 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:22:15 --> Database Driver Class Initialized
INFO - 2023-06-27 08:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:22:15 --> Parser Class Initialized
INFO - 2023-06-27 08:22:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:22:15 --> Pagination Class Initialized
INFO - 2023-06-27 08:22:15 --> Form Validation Class Initialized
INFO - 2023-06-27 08:22:15 --> Controller Class Initialized
INFO - 2023-06-27 08:22:15 --> Model Class Initialized
DEBUG - 2023-06-27 08:22:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-27 08:22:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:22:15 --> Config Class Initialized
INFO - 2023-06-27 08:22:15 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:22:15 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:22:15 --> Utf8 Class Initialized
INFO - 2023-06-27 08:22:15 --> URI Class Initialized
INFO - 2023-06-27 08:22:15 --> Router Class Initialized
INFO - 2023-06-27 08:22:15 --> Output Class Initialized
INFO - 2023-06-27 08:22:15 --> Security Class Initialized
DEBUG - 2023-06-27 08:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:22:15 --> Input Class Initialized
INFO - 2023-06-27 08:22:15 --> Language Class Initialized
INFO - 2023-06-27 08:22:15 --> Loader Class Initialized
INFO - 2023-06-27 08:22:15 --> Helper loaded: url_helper
INFO - 2023-06-27 08:22:15 --> Helper loaded: file_helper
INFO - 2023-06-27 08:22:15 --> Helper loaded: html_helper
INFO - 2023-06-27 08:22:15 --> Helper loaded: text_helper
INFO - 2023-06-27 08:22:15 --> Helper loaded: form_helper
INFO - 2023-06-27 08:22:15 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:22:15 --> Helper loaded: security_helper
INFO - 2023-06-27 08:22:15 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:22:15 --> Database Driver Class Initialized
INFO - 2023-06-27 08:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:22:15 --> Parser Class Initialized
INFO - 2023-06-27 08:22:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:22:15 --> Pagination Class Initialized
INFO - 2023-06-27 08:22:15 --> Form Validation Class Initialized
INFO - 2023-06-27 08:22:15 --> Controller Class Initialized
INFO - 2023-06-27 08:22:15 --> Model Class Initialized
DEBUG - 2023-06-27 08:22:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:22:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-27 08:22:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:22:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:22:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:22:15 --> Model Class Initialized
INFO - 2023-06-27 08:22:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:22:15 --> Final output sent to browser
DEBUG - 2023-06-27 08:22:15 --> Total execution time: 0.0342
ERROR - 2023-06-27 08:22:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:22:19 --> Config Class Initialized
INFO - 2023-06-27 08:22:19 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:22:19 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:22:19 --> Utf8 Class Initialized
INFO - 2023-06-27 08:22:19 --> URI Class Initialized
INFO - 2023-06-27 08:22:19 --> Router Class Initialized
INFO - 2023-06-27 08:22:19 --> Output Class Initialized
INFO - 2023-06-27 08:22:19 --> Security Class Initialized
DEBUG - 2023-06-27 08:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:22:19 --> Input Class Initialized
INFO - 2023-06-27 08:22:19 --> Language Class Initialized
INFO - 2023-06-27 08:22:19 --> Loader Class Initialized
INFO - 2023-06-27 08:22:19 --> Helper loaded: url_helper
INFO - 2023-06-27 08:22:19 --> Helper loaded: file_helper
INFO - 2023-06-27 08:22:19 --> Helper loaded: html_helper
INFO - 2023-06-27 08:22:19 --> Helper loaded: text_helper
INFO - 2023-06-27 08:22:19 --> Helper loaded: form_helper
INFO - 2023-06-27 08:22:19 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:22:19 --> Helper loaded: security_helper
INFO - 2023-06-27 08:22:19 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:22:19 --> Database Driver Class Initialized
INFO - 2023-06-27 08:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:22:19 --> Parser Class Initialized
INFO - 2023-06-27 08:22:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:22:19 --> Pagination Class Initialized
INFO - 2023-06-27 08:22:19 --> Form Validation Class Initialized
INFO - 2023-06-27 08:22:19 --> Controller Class Initialized
INFO - 2023-06-27 08:22:19 --> Model Class Initialized
DEBUG - 2023-06-27 08:22:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:22:19 --> Model Class Initialized
INFO - 2023-06-27 08:22:19 --> Final output sent to browser
DEBUG - 2023-06-27 08:22:19 --> Total execution time: 0.0232
ERROR - 2023-06-27 08:22:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:22:19 --> Config Class Initialized
INFO - 2023-06-27 08:22:19 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:22:19 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:22:19 --> Utf8 Class Initialized
INFO - 2023-06-27 08:22:19 --> URI Class Initialized
DEBUG - 2023-06-27 08:22:19 --> No URI present. Default controller set.
INFO - 2023-06-27 08:22:19 --> Router Class Initialized
INFO - 2023-06-27 08:22:19 --> Output Class Initialized
INFO - 2023-06-27 08:22:19 --> Security Class Initialized
DEBUG - 2023-06-27 08:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:22:19 --> Input Class Initialized
INFO - 2023-06-27 08:22:19 --> Language Class Initialized
INFO - 2023-06-27 08:22:19 --> Loader Class Initialized
INFO - 2023-06-27 08:22:19 --> Helper loaded: url_helper
INFO - 2023-06-27 08:22:19 --> Helper loaded: file_helper
INFO - 2023-06-27 08:22:19 --> Helper loaded: html_helper
INFO - 2023-06-27 08:22:19 --> Helper loaded: text_helper
INFO - 2023-06-27 08:22:19 --> Helper loaded: form_helper
INFO - 2023-06-27 08:22:19 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:22:19 --> Helper loaded: security_helper
INFO - 2023-06-27 08:22:19 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:22:19 --> Database Driver Class Initialized
INFO - 2023-06-27 08:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:22:19 --> Parser Class Initialized
INFO - 2023-06-27 08:22:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:22:19 --> Pagination Class Initialized
INFO - 2023-06-27 08:22:19 --> Form Validation Class Initialized
INFO - 2023-06-27 08:22:19 --> Controller Class Initialized
INFO - 2023-06-27 08:22:19 --> Model Class Initialized
DEBUG - 2023-06-27 08:22:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:22:19 --> Model Class Initialized
DEBUG - 2023-06-27 08:22:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:22:19 --> Model Class Initialized
INFO - 2023-06-27 08:22:19 --> Model Class Initialized
INFO - 2023-06-27 08:22:19 --> Model Class Initialized
INFO - 2023-06-27 08:22:19 --> Model Class Initialized
DEBUG - 2023-06-27 08:22:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:22:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:22:19 --> Model Class Initialized
INFO - 2023-06-27 08:22:19 --> Model Class Initialized
INFO - 2023-06-27 08:22:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 08:22:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:22:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:22:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:22:19 --> Model Class Initialized
INFO - 2023-06-27 08:22:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:22:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:22:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:22:19 --> Final output sent to browser
DEBUG - 2023-06-27 08:22:19 --> Total execution time: 0.0885
ERROR - 2023-06-27 08:22:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:22:23 --> Config Class Initialized
INFO - 2023-06-27 08:22:23 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:22:23 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:22:23 --> Utf8 Class Initialized
INFO - 2023-06-27 08:22:23 --> URI Class Initialized
INFO - 2023-06-27 08:22:23 --> Router Class Initialized
INFO - 2023-06-27 08:22:23 --> Output Class Initialized
INFO - 2023-06-27 08:22:23 --> Security Class Initialized
DEBUG - 2023-06-27 08:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:22:23 --> Input Class Initialized
INFO - 2023-06-27 08:22:23 --> Language Class Initialized
INFO - 2023-06-27 08:22:23 --> Loader Class Initialized
INFO - 2023-06-27 08:22:23 --> Helper loaded: url_helper
INFO - 2023-06-27 08:22:23 --> Helper loaded: file_helper
INFO - 2023-06-27 08:22:23 --> Helper loaded: html_helper
INFO - 2023-06-27 08:22:23 --> Helper loaded: text_helper
INFO - 2023-06-27 08:22:23 --> Helper loaded: form_helper
INFO - 2023-06-27 08:22:23 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:22:23 --> Helper loaded: security_helper
INFO - 2023-06-27 08:22:23 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:22:23 --> Database Driver Class Initialized
INFO - 2023-06-27 08:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:22:23 --> Parser Class Initialized
INFO - 2023-06-27 08:22:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:22:23 --> Pagination Class Initialized
INFO - 2023-06-27 08:22:23 --> Form Validation Class Initialized
INFO - 2023-06-27 08:22:23 --> Controller Class Initialized
INFO - 2023-06-27 08:22:23 --> Model Class Initialized
DEBUG - 2023-06-27 08:22:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:22:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:22:23 --> Model Class Initialized
DEBUG - 2023-06-27 08:22:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:22:23 --> Model Class Initialized
INFO - 2023-06-27 08:22:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-06-27 08:22:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:22:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:22:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:22:23 --> Model Class Initialized
INFO - 2023-06-27 08:22:23 --> Model Class Initialized
INFO - 2023-06-27 08:22:23 --> Model Class Initialized
INFO - 2023-06-27 08:22:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:22:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:22:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:22:23 --> Final output sent to browser
DEBUG - 2023-06-27 08:22:23 --> Total execution time: 0.1032
ERROR - 2023-06-27 08:22:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:22:28 --> Config Class Initialized
INFO - 2023-06-27 08:22:28 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:22:28 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:22:28 --> Utf8 Class Initialized
INFO - 2023-06-27 08:22:28 --> URI Class Initialized
INFO - 2023-06-27 08:22:28 --> Router Class Initialized
INFO - 2023-06-27 08:22:28 --> Output Class Initialized
INFO - 2023-06-27 08:22:28 --> Security Class Initialized
DEBUG - 2023-06-27 08:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:22:28 --> Input Class Initialized
INFO - 2023-06-27 08:22:28 --> Language Class Initialized
INFO - 2023-06-27 08:22:28 --> Loader Class Initialized
INFO - 2023-06-27 08:22:28 --> Helper loaded: url_helper
INFO - 2023-06-27 08:22:28 --> Helper loaded: file_helper
INFO - 2023-06-27 08:22:28 --> Helper loaded: html_helper
INFO - 2023-06-27 08:22:28 --> Helper loaded: text_helper
INFO - 2023-06-27 08:22:28 --> Helper loaded: form_helper
INFO - 2023-06-27 08:22:28 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:22:28 --> Helper loaded: security_helper
INFO - 2023-06-27 08:22:28 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:22:28 --> Database Driver Class Initialized
INFO - 2023-06-27 08:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:22:28 --> Parser Class Initialized
INFO - 2023-06-27 08:22:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:22:28 --> Pagination Class Initialized
INFO - 2023-06-27 08:22:28 --> Form Validation Class Initialized
INFO - 2023-06-27 08:22:28 --> Controller Class Initialized
INFO - 2023-06-27 08:22:28 --> Model Class Initialized
DEBUG - 2023-06-27 08:22:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:22:28 --> Final output sent to browser
DEBUG - 2023-06-27 08:22:28 --> Total execution time: 0.0198
ERROR - 2023-06-27 08:22:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:22:29 --> Config Class Initialized
INFO - 2023-06-27 08:22:29 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:22:29 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:22:29 --> Utf8 Class Initialized
INFO - 2023-06-27 08:22:29 --> URI Class Initialized
INFO - 2023-06-27 08:22:29 --> Router Class Initialized
INFO - 2023-06-27 08:22:29 --> Output Class Initialized
INFO - 2023-06-27 08:22:29 --> Security Class Initialized
DEBUG - 2023-06-27 08:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:22:29 --> Input Class Initialized
INFO - 2023-06-27 08:22:29 --> Language Class Initialized
INFO - 2023-06-27 08:22:29 --> Loader Class Initialized
INFO - 2023-06-27 08:22:29 --> Helper loaded: url_helper
INFO - 2023-06-27 08:22:29 --> Helper loaded: file_helper
INFO - 2023-06-27 08:22:29 --> Helper loaded: html_helper
INFO - 2023-06-27 08:22:29 --> Helper loaded: text_helper
INFO - 2023-06-27 08:22:29 --> Helper loaded: form_helper
INFO - 2023-06-27 08:22:29 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:22:29 --> Helper loaded: security_helper
INFO - 2023-06-27 08:22:29 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:22:29 --> Database Driver Class Initialized
INFO - 2023-06-27 08:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:22:29 --> Parser Class Initialized
INFO - 2023-06-27 08:22:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:22:29 --> Pagination Class Initialized
INFO - 2023-06-27 08:22:29 --> Form Validation Class Initialized
INFO - 2023-06-27 08:22:29 --> Controller Class Initialized
INFO - 2023-06-27 08:22:29 --> Final output sent to browser
DEBUG - 2023-06-27 08:22:29 --> Total execution time: 0.0132
ERROR - 2023-06-27 08:22:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:22:39 --> Config Class Initialized
INFO - 2023-06-27 08:22:39 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:22:39 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:22:39 --> Utf8 Class Initialized
INFO - 2023-06-27 08:22:39 --> URI Class Initialized
INFO - 2023-06-27 08:22:39 --> Router Class Initialized
INFO - 2023-06-27 08:22:39 --> Output Class Initialized
INFO - 2023-06-27 08:22:39 --> Security Class Initialized
DEBUG - 2023-06-27 08:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:22:39 --> Input Class Initialized
INFO - 2023-06-27 08:22:39 --> Language Class Initialized
INFO - 2023-06-27 08:22:39 --> Loader Class Initialized
INFO - 2023-06-27 08:22:39 --> Helper loaded: url_helper
INFO - 2023-06-27 08:22:39 --> Helper loaded: file_helper
INFO - 2023-06-27 08:22:39 --> Helper loaded: html_helper
INFO - 2023-06-27 08:22:39 --> Helper loaded: text_helper
INFO - 2023-06-27 08:22:39 --> Helper loaded: form_helper
INFO - 2023-06-27 08:22:39 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:22:39 --> Helper loaded: security_helper
INFO - 2023-06-27 08:22:39 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:22:39 --> Database Driver Class Initialized
INFO - 2023-06-27 08:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:22:39 --> Parser Class Initialized
INFO - 2023-06-27 08:22:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:22:39 --> Pagination Class Initialized
INFO - 2023-06-27 08:22:39 --> Form Validation Class Initialized
INFO - 2023-06-27 08:22:39 --> Controller Class Initialized
INFO - 2023-06-27 08:22:39 --> Model Class Initialized
DEBUG - 2023-06-27 08:22:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:22:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:22:39 --> Model Class Initialized
DEBUG - 2023-06-27 08:22:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:22:39 --> Model Class Initialized
INFO - 2023-06-27 08:22:39 --> Final output sent to browser
DEBUG - 2023-06-27 08:22:39 --> Total execution time: 0.0431
ERROR - 2023-06-27 08:22:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:22:40 --> Config Class Initialized
INFO - 2023-06-27 08:22:40 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:22:40 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:22:40 --> Utf8 Class Initialized
INFO - 2023-06-27 08:22:40 --> URI Class Initialized
INFO - 2023-06-27 08:22:40 --> Router Class Initialized
INFO - 2023-06-27 08:22:40 --> Output Class Initialized
INFO - 2023-06-27 08:22:40 --> Security Class Initialized
DEBUG - 2023-06-27 08:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:22:40 --> Input Class Initialized
INFO - 2023-06-27 08:22:40 --> Language Class Initialized
INFO - 2023-06-27 08:22:40 --> Loader Class Initialized
INFO - 2023-06-27 08:22:40 --> Helper loaded: url_helper
INFO - 2023-06-27 08:22:40 --> Helper loaded: file_helper
INFO - 2023-06-27 08:22:40 --> Helper loaded: html_helper
INFO - 2023-06-27 08:22:40 --> Helper loaded: text_helper
INFO - 2023-06-27 08:22:40 --> Helper loaded: form_helper
INFO - 2023-06-27 08:22:40 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:22:40 --> Helper loaded: security_helper
INFO - 2023-06-27 08:22:40 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:22:40 --> Database Driver Class Initialized
INFO - 2023-06-27 08:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:22:40 --> Parser Class Initialized
INFO - 2023-06-27 08:22:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:22:40 --> Pagination Class Initialized
INFO - 2023-06-27 08:22:40 --> Form Validation Class Initialized
INFO - 2023-06-27 08:22:40 --> Controller Class Initialized
INFO - 2023-06-27 08:22:40 --> Model Class Initialized
DEBUG - 2023-06-27 08:22:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:22:40 --> Model Class Initialized
DEBUG - 2023-06-27 08:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:22:40 --> Model Class Initialized
INFO - 2023-06-27 08:22:40 --> Final output sent to browser
DEBUG - 2023-06-27 08:22:40 --> Total execution time: 0.0263
ERROR - 2023-06-27 08:22:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:22:43 --> Config Class Initialized
INFO - 2023-06-27 08:22:43 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:22:43 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:22:43 --> Utf8 Class Initialized
INFO - 2023-06-27 08:22:43 --> URI Class Initialized
INFO - 2023-06-27 08:22:43 --> Router Class Initialized
INFO - 2023-06-27 08:22:43 --> Output Class Initialized
INFO - 2023-06-27 08:22:43 --> Security Class Initialized
DEBUG - 2023-06-27 08:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:22:43 --> Input Class Initialized
INFO - 2023-06-27 08:22:43 --> Language Class Initialized
INFO - 2023-06-27 08:22:43 --> Loader Class Initialized
INFO - 2023-06-27 08:22:43 --> Helper loaded: url_helper
INFO - 2023-06-27 08:22:43 --> Helper loaded: file_helper
INFO - 2023-06-27 08:22:43 --> Helper loaded: html_helper
INFO - 2023-06-27 08:22:43 --> Helper loaded: text_helper
INFO - 2023-06-27 08:22:43 --> Helper loaded: form_helper
INFO - 2023-06-27 08:22:43 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:22:43 --> Helper loaded: security_helper
INFO - 2023-06-27 08:22:43 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:22:43 --> Database Driver Class Initialized
INFO - 2023-06-27 08:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:22:43 --> Parser Class Initialized
INFO - 2023-06-27 08:22:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:22:43 --> Pagination Class Initialized
INFO - 2023-06-27 08:22:43 --> Form Validation Class Initialized
INFO - 2023-06-27 08:22:43 --> Controller Class Initialized
INFO - 2023-06-27 08:22:43 --> Model Class Initialized
DEBUG - 2023-06-27 08:22:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:22:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:22:43 --> Model Class Initialized
INFO - 2023-06-27 08:22:43 --> Model Class Initialized
INFO - 2023-06-27 08:22:43 --> Final output sent to browser
DEBUG - 2023-06-27 08:22:43 --> Total execution time: 0.0225
ERROR - 2023-06-27 08:22:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:22:43 --> Config Class Initialized
INFO - 2023-06-27 08:22:43 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:22:43 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:22:43 --> Utf8 Class Initialized
INFO - 2023-06-27 08:22:43 --> URI Class Initialized
INFO - 2023-06-27 08:22:43 --> Router Class Initialized
INFO - 2023-06-27 08:22:43 --> Output Class Initialized
INFO - 2023-06-27 08:22:43 --> Security Class Initialized
DEBUG - 2023-06-27 08:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:22:43 --> Input Class Initialized
INFO - 2023-06-27 08:22:43 --> Language Class Initialized
INFO - 2023-06-27 08:22:43 --> Loader Class Initialized
INFO - 2023-06-27 08:22:43 --> Helper loaded: url_helper
INFO - 2023-06-27 08:22:43 --> Helper loaded: file_helper
INFO - 2023-06-27 08:22:43 --> Helper loaded: html_helper
INFO - 2023-06-27 08:22:43 --> Helper loaded: text_helper
INFO - 2023-06-27 08:22:43 --> Helper loaded: form_helper
INFO - 2023-06-27 08:22:43 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:22:43 --> Helper loaded: security_helper
INFO - 2023-06-27 08:22:43 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:22:43 --> Database Driver Class Initialized
INFO - 2023-06-27 08:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:22:43 --> Parser Class Initialized
INFO - 2023-06-27 08:22:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:22:43 --> Pagination Class Initialized
INFO - 2023-06-27 08:22:43 --> Form Validation Class Initialized
INFO - 2023-06-27 08:22:43 --> Controller Class Initialized
INFO - 2023-06-27 08:22:43 --> Model Class Initialized
DEBUG - 2023-06-27 08:22:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:22:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:22:43 --> Model Class Initialized
DEBUG - 2023-06-27 08:22:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:22:43 --> Model Class Initialized
INFO - 2023-06-27 08:22:43 --> Final output sent to browser
DEBUG - 2023-06-27 08:22:43 --> Total execution time: 0.0184
ERROR - 2023-06-27 08:22:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:22:46 --> Config Class Initialized
INFO - 2023-06-27 08:22:46 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:22:46 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:22:46 --> Utf8 Class Initialized
INFO - 2023-06-27 08:22:46 --> URI Class Initialized
INFO - 2023-06-27 08:22:46 --> Router Class Initialized
INFO - 2023-06-27 08:22:46 --> Output Class Initialized
INFO - 2023-06-27 08:22:46 --> Security Class Initialized
DEBUG - 2023-06-27 08:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:22:46 --> Input Class Initialized
INFO - 2023-06-27 08:22:46 --> Language Class Initialized
INFO - 2023-06-27 08:22:46 --> Loader Class Initialized
INFO - 2023-06-27 08:22:46 --> Helper loaded: url_helper
INFO - 2023-06-27 08:22:46 --> Helper loaded: file_helper
INFO - 2023-06-27 08:22:46 --> Helper loaded: html_helper
INFO - 2023-06-27 08:22:46 --> Helper loaded: text_helper
INFO - 2023-06-27 08:22:46 --> Helper loaded: form_helper
INFO - 2023-06-27 08:22:46 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:22:46 --> Helper loaded: security_helper
INFO - 2023-06-27 08:22:46 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:22:46 --> Database Driver Class Initialized
INFO - 2023-06-27 08:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:22:46 --> Parser Class Initialized
INFO - 2023-06-27 08:22:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:22:46 --> Pagination Class Initialized
INFO - 2023-06-27 08:22:46 --> Form Validation Class Initialized
INFO - 2023-06-27 08:22:46 --> Controller Class Initialized
INFO - 2023-06-27 08:22:46 --> Model Class Initialized
DEBUG - 2023-06-27 08:22:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:22:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:22:46 --> Model Class Initialized
INFO - 2023-06-27 08:22:46 --> Final output sent to browser
DEBUG - 2023-06-27 08:22:46 --> Total execution time: 0.0165
ERROR - 2023-06-27 08:23:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:23:35 --> Config Class Initialized
INFO - 2023-06-27 08:23:35 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:23:35 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:23:35 --> Utf8 Class Initialized
INFO - 2023-06-27 08:23:35 --> URI Class Initialized
DEBUG - 2023-06-27 08:23:35 --> No URI present. Default controller set.
INFO - 2023-06-27 08:23:35 --> Router Class Initialized
INFO - 2023-06-27 08:23:35 --> Output Class Initialized
INFO - 2023-06-27 08:23:35 --> Security Class Initialized
DEBUG - 2023-06-27 08:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:23:35 --> Input Class Initialized
INFO - 2023-06-27 08:23:35 --> Language Class Initialized
INFO - 2023-06-27 08:23:35 --> Loader Class Initialized
INFO - 2023-06-27 08:23:35 --> Helper loaded: url_helper
INFO - 2023-06-27 08:23:35 --> Helper loaded: file_helper
INFO - 2023-06-27 08:23:35 --> Helper loaded: html_helper
INFO - 2023-06-27 08:23:35 --> Helper loaded: text_helper
INFO - 2023-06-27 08:23:35 --> Helper loaded: form_helper
INFO - 2023-06-27 08:23:35 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:23:35 --> Helper loaded: security_helper
INFO - 2023-06-27 08:23:35 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:23:35 --> Database Driver Class Initialized
INFO - 2023-06-27 08:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:23:35 --> Parser Class Initialized
INFO - 2023-06-27 08:23:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:23:35 --> Pagination Class Initialized
INFO - 2023-06-27 08:23:35 --> Form Validation Class Initialized
INFO - 2023-06-27 08:23:35 --> Controller Class Initialized
INFO - 2023-06-27 08:23:35 --> Model Class Initialized
DEBUG - 2023-06-27 08:23:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-27 08:23:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:23:35 --> Config Class Initialized
INFO - 2023-06-27 08:23:35 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:23:35 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:23:35 --> Utf8 Class Initialized
INFO - 2023-06-27 08:23:35 --> URI Class Initialized
INFO - 2023-06-27 08:23:35 --> Router Class Initialized
INFO - 2023-06-27 08:23:35 --> Output Class Initialized
INFO - 2023-06-27 08:23:35 --> Security Class Initialized
DEBUG - 2023-06-27 08:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:23:35 --> Input Class Initialized
INFO - 2023-06-27 08:23:35 --> Language Class Initialized
INFO - 2023-06-27 08:23:35 --> Loader Class Initialized
INFO - 2023-06-27 08:23:35 --> Helper loaded: url_helper
INFO - 2023-06-27 08:23:35 --> Helper loaded: file_helper
INFO - 2023-06-27 08:23:35 --> Helper loaded: html_helper
INFO - 2023-06-27 08:23:35 --> Helper loaded: text_helper
INFO - 2023-06-27 08:23:35 --> Helper loaded: form_helper
INFO - 2023-06-27 08:23:35 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:23:35 --> Helper loaded: security_helper
INFO - 2023-06-27 08:23:35 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:23:35 --> Database Driver Class Initialized
INFO - 2023-06-27 08:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:23:35 --> Parser Class Initialized
INFO - 2023-06-27 08:23:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:23:35 --> Pagination Class Initialized
INFO - 2023-06-27 08:23:35 --> Form Validation Class Initialized
INFO - 2023-06-27 08:23:35 --> Controller Class Initialized
INFO - 2023-06-27 08:23:35 --> Model Class Initialized
DEBUG - 2023-06-27 08:23:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:23:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-27 08:23:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:23:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:23:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:23:35 --> Model Class Initialized
INFO - 2023-06-27 08:23:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:23:35 --> Final output sent to browser
DEBUG - 2023-06-27 08:23:35 --> Total execution time: 0.0305
ERROR - 2023-06-27 08:23:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:23:38 --> Config Class Initialized
INFO - 2023-06-27 08:23:38 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:23:38 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:23:38 --> Utf8 Class Initialized
INFO - 2023-06-27 08:23:38 --> URI Class Initialized
INFO - 2023-06-27 08:23:38 --> Router Class Initialized
INFO - 2023-06-27 08:23:38 --> Output Class Initialized
INFO - 2023-06-27 08:23:38 --> Security Class Initialized
DEBUG - 2023-06-27 08:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:23:38 --> Input Class Initialized
INFO - 2023-06-27 08:23:38 --> Language Class Initialized
INFO - 2023-06-27 08:23:38 --> Loader Class Initialized
INFO - 2023-06-27 08:23:38 --> Helper loaded: url_helper
INFO - 2023-06-27 08:23:38 --> Helper loaded: file_helper
INFO - 2023-06-27 08:23:38 --> Helper loaded: html_helper
INFO - 2023-06-27 08:23:38 --> Helper loaded: text_helper
INFO - 2023-06-27 08:23:38 --> Helper loaded: form_helper
INFO - 2023-06-27 08:23:38 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:23:38 --> Helper loaded: security_helper
INFO - 2023-06-27 08:23:38 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:23:38 --> Database Driver Class Initialized
INFO - 2023-06-27 08:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:23:38 --> Parser Class Initialized
INFO - 2023-06-27 08:23:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:23:38 --> Pagination Class Initialized
INFO - 2023-06-27 08:23:38 --> Form Validation Class Initialized
INFO - 2023-06-27 08:23:38 --> Controller Class Initialized
INFO - 2023-06-27 08:23:38 --> Model Class Initialized
DEBUG - 2023-06-27 08:23:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:23:38 --> Model Class Initialized
INFO - 2023-06-27 08:23:38 --> Final output sent to browser
DEBUG - 2023-06-27 08:23:38 --> Total execution time: 0.0207
ERROR - 2023-06-27 08:23:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:23:39 --> Config Class Initialized
INFO - 2023-06-27 08:23:39 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:23:39 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:23:39 --> Utf8 Class Initialized
INFO - 2023-06-27 08:23:39 --> URI Class Initialized
DEBUG - 2023-06-27 08:23:39 --> No URI present. Default controller set.
INFO - 2023-06-27 08:23:39 --> Router Class Initialized
INFO - 2023-06-27 08:23:39 --> Output Class Initialized
INFO - 2023-06-27 08:23:39 --> Security Class Initialized
DEBUG - 2023-06-27 08:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:23:39 --> Input Class Initialized
INFO - 2023-06-27 08:23:39 --> Language Class Initialized
INFO - 2023-06-27 08:23:39 --> Loader Class Initialized
INFO - 2023-06-27 08:23:39 --> Helper loaded: url_helper
INFO - 2023-06-27 08:23:39 --> Helper loaded: file_helper
INFO - 2023-06-27 08:23:39 --> Helper loaded: html_helper
INFO - 2023-06-27 08:23:39 --> Helper loaded: text_helper
INFO - 2023-06-27 08:23:39 --> Helper loaded: form_helper
INFO - 2023-06-27 08:23:39 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:23:39 --> Helper loaded: security_helper
INFO - 2023-06-27 08:23:39 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:23:39 --> Database Driver Class Initialized
INFO - 2023-06-27 08:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:23:39 --> Parser Class Initialized
INFO - 2023-06-27 08:23:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:23:39 --> Pagination Class Initialized
INFO - 2023-06-27 08:23:39 --> Form Validation Class Initialized
INFO - 2023-06-27 08:23:39 --> Controller Class Initialized
INFO - 2023-06-27 08:23:39 --> Model Class Initialized
DEBUG - 2023-06-27 08:23:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:23:39 --> Model Class Initialized
DEBUG - 2023-06-27 08:23:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:23:39 --> Model Class Initialized
INFO - 2023-06-27 08:23:39 --> Model Class Initialized
INFO - 2023-06-27 08:23:39 --> Model Class Initialized
INFO - 2023-06-27 08:23:39 --> Model Class Initialized
DEBUG - 2023-06-27 08:23:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:23:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:23:39 --> Model Class Initialized
INFO - 2023-06-27 08:23:39 --> Model Class Initialized
INFO - 2023-06-27 08:23:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 08:23:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:23:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:23:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:23:39 --> Model Class Initialized
INFO - 2023-06-27 08:23:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:23:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:23:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:23:39 --> Final output sent to browser
DEBUG - 2023-06-27 08:23:39 --> Total execution time: 0.1789
ERROR - 2023-06-27 08:23:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:23:39 --> Config Class Initialized
INFO - 2023-06-27 08:23:39 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:23:39 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:23:39 --> Utf8 Class Initialized
INFO - 2023-06-27 08:23:39 --> URI Class Initialized
INFO - 2023-06-27 08:23:39 --> Router Class Initialized
INFO - 2023-06-27 08:23:39 --> Output Class Initialized
INFO - 2023-06-27 08:23:39 --> Security Class Initialized
DEBUG - 2023-06-27 08:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:23:39 --> Input Class Initialized
INFO - 2023-06-27 08:23:39 --> Language Class Initialized
INFO - 2023-06-27 08:23:39 --> Loader Class Initialized
INFO - 2023-06-27 08:23:39 --> Helper loaded: url_helper
INFO - 2023-06-27 08:23:39 --> Helper loaded: file_helper
INFO - 2023-06-27 08:23:39 --> Helper loaded: html_helper
INFO - 2023-06-27 08:23:39 --> Helper loaded: text_helper
INFO - 2023-06-27 08:23:39 --> Helper loaded: form_helper
INFO - 2023-06-27 08:23:39 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:23:39 --> Helper loaded: security_helper
INFO - 2023-06-27 08:23:39 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:23:39 --> Database Driver Class Initialized
INFO - 2023-06-27 08:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:23:39 --> Parser Class Initialized
INFO - 2023-06-27 08:23:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:23:39 --> Pagination Class Initialized
INFO - 2023-06-27 08:23:39 --> Form Validation Class Initialized
INFO - 2023-06-27 08:23:39 --> Controller Class Initialized
DEBUG - 2023-06-27 08:23:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:23:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:23:39 --> Model Class Initialized
INFO - 2023-06-27 08:23:39 --> Final output sent to browser
DEBUG - 2023-06-27 08:23:39 --> Total execution time: 0.0141
ERROR - 2023-06-27 08:23:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:23:56 --> Config Class Initialized
INFO - 2023-06-27 08:23:56 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:23:56 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:23:56 --> Utf8 Class Initialized
INFO - 2023-06-27 08:23:56 --> URI Class Initialized
INFO - 2023-06-27 08:23:56 --> Router Class Initialized
INFO - 2023-06-27 08:23:56 --> Output Class Initialized
INFO - 2023-06-27 08:23:56 --> Security Class Initialized
DEBUG - 2023-06-27 08:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:23:56 --> Input Class Initialized
INFO - 2023-06-27 08:23:56 --> Language Class Initialized
INFO - 2023-06-27 08:23:56 --> Loader Class Initialized
INFO - 2023-06-27 08:23:56 --> Helper loaded: url_helper
INFO - 2023-06-27 08:23:56 --> Helper loaded: file_helper
INFO - 2023-06-27 08:23:56 --> Helper loaded: html_helper
INFO - 2023-06-27 08:23:56 --> Helper loaded: text_helper
INFO - 2023-06-27 08:23:56 --> Helper loaded: form_helper
INFO - 2023-06-27 08:23:56 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:23:56 --> Helper loaded: security_helper
INFO - 2023-06-27 08:23:56 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:23:56 --> Database Driver Class Initialized
INFO - 2023-06-27 08:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:23:56 --> Parser Class Initialized
INFO - 2023-06-27 08:23:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:23:56 --> Pagination Class Initialized
INFO - 2023-06-27 08:23:56 --> Form Validation Class Initialized
INFO - 2023-06-27 08:23:56 --> Controller Class Initialized
INFO - 2023-06-27 08:23:56 --> Model Class Initialized
DEBUG - 2023-06-27 08:23:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:23:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:23:56 --> Model Class Initialized
DEBUG - 2023-06-27 08:23:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:23:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/add_stockrequest_form.php
DEBUG - 2023-06-27 08:23:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:23:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:23:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:23:56 --> Model Class Initialized
INFO - 2023-06-27 08:23:56 --> Model Class Initialized
INFO - 2023-06-27 08:23:56 --> Model Class Initialized
INFO - 2023-06-27 08:23:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:23:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:23:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:23:56 --> Final output sent to browser
DEBUG - 2023-06-27 08:23:56 --> Total execution time: 0.1537
ERROR - 2023-06-27 08:24:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:24:02 --> Config Class Initialized
INFO - 2023-06-27 08:24:02 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:24:02 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:24:02 --> Utf8 Class Initialized
INFO - 2023-06-27 08:24:02 --> URI Class Initialized
INFO - 2023-06-27 08:24:02 --> Router Class Initialized
INFO - 2023-06-27 08:24:02 --> Output Class Initialized
INFO - 2023-06-27 08:24:02 --> Security Class Initialized
DEBUG - 2023-06-27 08:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:24:02 --> Input Class Initialized
INFO - 2023-06-27 08:24:02 --> Language Class Initialized
INFO - 2023-06-27 08:24:02 --> Loader Class Initialized
INFO - 2023-06-27 08:24:02 --> Helper loaded: url_helper
INFO - 2023-06-27 08:24:02 --> Helper loaded: file_helper
INFO - 2023-06-27 08:24:02 --> Helper loaded: html_helper
INFO - 2023-06-27 08:24:02 --> Helper loaded: text_helper
INFO - 2023-06-27 08:24:02 --> Helper loaded: form_helper
INFO - 2023-06-27 08:24:02 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:24:02 --> Helper loaded: security_helper
INFO - 2023-06-27 08:24:02 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:24:02 --> Database Driver Class Initialized
INFO - 2023-06-27 08:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:24:02 --> Parser Class Initialized
INFO - 2023-06-27 08:24:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:24:02 --> Pagination Class Initialized
INFO - 2023-06-27 08:24:02 --> Form Validation Class Initialized
INFO - 2023-06-27 08:24:02 --> Controller Class Initialized
INFO - 2023-06-27 08:24:02 --> Model Class Initialized
ERROR - 2023-06-27 08:24:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cstockrequest.php 204
INFO - 2023-06-27 08:24:02 --> Final output sent to browser
DEBUG - 2023-06-27 08:24:02 --> Total execution time: 0.0146
ERROR - 2023-06-27 08:24:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:24:03 --> Config Class Initialized
INFO - 2023-06-27 08:24:03 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:24:03 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:24:03 --> Utf8 Class Initialized
INFO - 2023-06-27 08:24:03 --> URI Class Initialized
INFO - 2023-06-27 08:24:03 --> Router Class Initialized
INFO - 2023-06-27 08:24:03 --> Output Class Initialized
INFO - 2023-06-27 08:24:03 --> Security Class Initialized
DEBUG - 2023-06-27 08:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:24:03 --> Input Class Initialized
INFO - 2023-06-27 08:24:03 --> Language Class Initialized
INFO - 2023-06-27 08:24:03 --> Loader Class Initialized
INFO - 2023-06-27 08:24:03 --> Helper loaded: url_helper
INFO - 2023-06-27 08:24:03 --> Helper loaded: file_helper
INFO - 2023-06-27 08:24:03 --> Helper loaded: html_helper
INFO - 2023-06-27 08:24:03 --> Helper loaded: text_helper
INFO - 2023-06-27 08:24:03 --> Helper loaded: form_helper
INFO - 2023-06-27 08:24:03 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:24:03 --> Helper loaded: security_helper
INFO - 2023-06-27 08:24:03 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:24:03 --> Database Driver Class Initialized
INFO - 2023-06-27 08:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:24:03 --> Parser Class Initialized
INFO - 2023-06-27 08:24:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:24:03 --> Pagination Class Initialized
INFO - 2023-06-27 08:24:03 --> Form Validation Class Initialized
INFO - 2023-06-27 08:24:03 --> Controller Class Initialized
INFO - 2023-06-27 08:24:03 --> Model Class Initialized
ERROR - 2023-06-27 08:24:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cstockrequest.php 204
INFO - 2023-06-27 08:24:03 --> Final output sent to browser
DEBUG - 2023-06-27 08:24:03 --> Total execution time: 0.0142
ERROR - 2023-06-27 08:24:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:24:04 --> Config Class Initialized
INFO - 2023-06-27 08:24:04 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:24:04 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:24:04 --> Utf8 Class Initialized
INFO - 2023-06-27 08:24:04 --> URI Class Initialized
INFO - 2023-06-27 08:24:04 --> Router Class Initialized
INFO - 2023-06-27 08:24:04 --> Output Class Initialized
INFO - 2023-06-27 08:24:04 --> Security Class Initialized
DEBUG - 2023-06-27 08:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:24:04 --> Input Class Initialized
INFO - 2023-06-27 08:24:04 --> Language Class Initialized
INFO - 2023-06-27 08:24:04 --> Loader Class Initialized
INFO - 2023-06-27 08:24:04 --> Helper loaded: url_helper
INFO - 2023-06-27 08:24:04 --> Helper loaded: file_helper
INFO - 2023-06-27 08:24:04 --> Helper loaded: html_helper
INFO - 2023-06-27 08:24:04 --> Helper loaded: text_helper
INFO - 2023-06-27 08:24:04 --> Helper loaded: form_helper
INFO - 2023-06-27 08:24:04 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:24:04 --> Helper loaded: security_helper
INFO - 2023-06-27 08:24:04 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:24:04 --> Database Driver Class Initialized
INFO - 2023-06-27 08:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:24:04 --> Parser Class Initialized
INFO - 2023-06-27 08:24:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:24:04 --> Pagination Class Initialized
INFO - 2023-06-27 08:24:04 --> Form Validation Class Initialized
INFO - 2023-06-27 08:24:04 --> Controller Class Initialized
INFO - 2023-06-27 08:24:04 --> Model Class Initialized
INFO - 2023-06-27 08:24:04 --> Final output sent to browser
DEBUG - 2023-06-27 08:24:04 --> Total execution time: 0.0131
ERROR - 2023-06-27 08:24:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:24:05 --> Config Class Initialized
INFO - 2023-06-27 08:24:05 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:24:05 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:24:05 --> Utf8 Class Initialized
INFO - 2023-06-27 08:24:05 --> URI Class Initialized
INFO - 2023-06-27 08:24:05 --> Router Class Initialized
INFO - 2023-06-27 08:24:05 --> Output Class Initialized
INFO - 2023-06-27 08:24:05 --> Security Class Initialized
DEBUG - 2023-06-27 08:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:24:05 --> Input Class Initialized
INFO - 2023-06-27 08:24:05 --> Language Class Initialized
INFO - 2023-06-27 08:24:05 --> Loader Class Initialized
INFO - 2023-06-27 08:24:05 --> Helper loaded: url_helper
INFO - 2023-06-27 08:24:05 --> Helper loaded: file_helper
INFO - 2023-06-27 08:24:05 --> Helper loaded: html_helper
INFO - 2023-06-27 08:24:05 --> Helper loaded: text_helper
INFO - 2023-06-27 08:24:05 --> Helper loaded: form_helper
INFO - 2023-06-27 08:24:05 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:24:05 --> Helper loaded: security_helper
INFO - 2023-06-27 08:24:05 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:24:05 --> Database Driver Class Initialized
INFO - 2023-06-27 08:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:24:05 --> Parser Class Initialized
INFO - 2023-06-27 08:24:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:24:05 --> Pagination Class Initialized
INFO - 2023-06-27 08:24:05 --> Form Validation Class Initialized
INFO - 2023-06-27 08:24:05 --> Controller Class Initialized
INFO - 2023-06-27 08:24:05 --> Model Class Initialized
INFO - 2023-06-27 08:24:05 --> Final output sent to browser
DEBUG - 2023-06-27 08:24:05 --> Total execution time: 0.0174
ERROR - 2023-06-27 08:24:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:24:13 --> Config Class Initialized
INFO - 2023-06-27 08:24:13 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:24:13 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:24:13 --> Utf8 Class Initialized
INFO - 2023-06-27 08:24:13 --> URI Class Initialized
INFO - 2023-06-27 08:24:13 --> Router Class Initialized
INFO - 2023-06-27 08:24:13 --> Output Class Initialized
INFO - 2023-06-27 08:24:13 --> Security Class Initialized
DEBUG - 2023-06-27 08:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:24:13 --> Input Class Initialized
INFO - 2023-06-27 08:24:13 --> Language Class Initialized
INFO - 2023-06-27 08:24:13 --> Loader Class Initialized
INFO - 2023-06-27 08:24:13 --> Helper loaded: url_helper
INFO - 2023-06-27 08:24:13 --> Helper loaded: file_helper
INFO - 2023-06-27 08:24:13 --> Helper loaded: html_helper
INFO - 2023-06-27 08:24:13 --> Helper loaded: text_helper
INFO - 2023-06-27 08:24:13 --> Helper loaded: form_helper
INFO - 2023-06-27 08:24:13 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:24:13 --> Helper loaded: security_helper
INFO - 2023-06-27 08:24:13 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:24:13 --> Database Driver Class Initialized
INFO - 2023-06-27 08:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:24:13 --> Parser Class Initialized
INFO - 2023-06-27 08:24:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:24:13 --> Pagination Class Initialized
INFO - 2023-06-27 08:24:13 --> Form Validation Class Initialized
INFO - 2023-06-27 08:24:13 --> Controller Class Initialized
INFO - 2023-06-27 08:24:13 --> Model Class Initialized
DEBUG - 2023-06-27 08:24:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:24:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:13 --> Model Class Initialized
DEBUG - 2023-06-27 08:24:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:13 --> Model Class Initialized
INFO - 2023-06-27 08:24:13 --> Final output sent to browser
DEBUG - 2023-06-27 08:24:13 --> Total execution time: 0.0180
ERROR - 2023-06-27 08:24:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:24:16 --> Config Class Initialized
INFO - 2023-06-27 08:24:16 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:24:16 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:24:16 --> Utf8 Class Initialized
INFO - 2023-06-27 08:24:16 --> URI Class Initialized
INFO - 2023-06-27 08:24:16 --> Router Class Initialized
INFO - 2023-06-27 08:24:16 --> Output Class Initialized
INFO - 2023-06-27 08:24:16 --> Security Class Initialized
DEBUG - 2023-06-27 08:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:24:16 --> Input Class Initialized
INFO - 2023-06-27 08:24:16 --> Language Class Initialized
INFO - 2023-06-27 08:24:16 --> Loader Class Initialized
INFO - 2023-06-27 08:24:16 --> Helper loaded: url_helper
INFO - 2023-06-27 08:24:16 --> Helper loaded: file_helper
INFO - 2023-06-27 08:24:16 --> Helper loaded: html_helper
INFO - 2023-06-27 08:24:16 --> Helper loaded: text_helper
INFO - 2023-06-27 08:24:16 --> Helper loaded: form_helper
INFO - 2023-06-27 08:24:16 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:24:16 --> Helper loaded: security_helper
INFO - 2023-06-27 08:24:16 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:24:16 --> Database Driver Class Initialized
INFO - 2023-06-27 08:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:24:16 --> Parser Class Initialized
INFO - 2023-06-27 08:24:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:24:16 --> Pagination Class Initialized
INFO - 2023-06-27 08:24:16 --> Form Validation Class Initialized
INFO - 2023-06-27 08:24:16 --> Controller Class Initialized
INFO - 2023-06-27 08:24:16 --> Model Class Initialized
DEBUG - 2023-06-27 08:24:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:24:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:16 --> Model Class Initialized
DEBUG - 2023-06-27 08:24:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:16 --> Model Class Initialized
INFO - 2023-06-27 08:24:16 --> Final output sent to browser
DEBUG - 2023-06-27 08:24:16 --> Total execution time: 0.0182
ERROR - 2023-06-27 08:24:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:24:18 --> Config Class Initialized
INFO - 2023-06-27 08:24:18 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:24:18 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:24:18 --> Utf8 Class Initialized
INFO - 2023-06-27 08:24:18 --> URI Class Initialized
INFO - 2023-06-27 08:24:18 --> Router Class Initialized
INFO - 2023-06-27 08:24:18 --> Output Class Initialized
INFO - 2023-06-27 08:24:18 --> Security Class Initialized
DEBUG - 2023-06-27 08:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:24:18 --> Input Class Initialized
INFO - 2023-06-27 08:24:18 --> Language Class Initialized
INFO - 2023-06-27 08:24:18 --> Loader Class Initialized
INFO - 2023-06-27 08:24:18 --> Helper loaded: url_helper
INFO - 2023-06-27 08:24:18 --> Helper loaded: file_helper
INFO - 2023-06-27 08:24:18 --> Helper loaded: html_helper
INFO - 2023-06-27 08:24:18 --> Helper loaded: text_helper
INFO - 2023-06-27 08:24:18 --> Helper loaded: form_helper
INFO - 2023-06-27 08:24:18 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:24:18 --> Helper loaded: security_helper
INFO - 2023-06-27 08:24:18 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:24:18 --> Database Driver Class Initialized
INFO - 2023-06-27 08:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:24:18 --> Parser Class Initialized
INFO - 2023-06-27 08:24:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:24:18 --> Pagination Class Initialized
INFO - 2023-06-27 08:24:18 --> Form Validation Class Initialized
INFO - 2023-06-27 08:24:18 --> Controller Class Initialized
INFO - 2023-06-27 08:24:18 --> Model Class Initialized
DEBUG - 2023-06-27 08:24:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:24:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:18 --> Model Class Initialized
DEBUG - 2023-06-27 08:24:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:18 --> Model Class Initialized
INFO - 2023-06-27 08:24:18 --> Final output sent to browser
DEBUG - 2023-06-27 08:24:18 --> Total execution time: 0.0186
ERROR - 2023-06-27 08:24:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:24:19 --> Config Class Initialized
INFO - 2023-06-27 08:24:19 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:24:19 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:24:19 --> Utf8 Class Initialized
INFO - 2023-06-27 08:24:19 --> URI Class Initialized
INFO - 2023-06-27 08:24:19 --> Router Class Initialized
INFO - 2023-06-27 08:24:19 --> Output Class Initialized
INFO - 2023-06-27 08:24:19 --> Security Class Initialized
DEBUG - 2023-06-27 08:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:24:19 --> Input Class Initialized
INFO - 2023-06-27 08:24:19 --> Language Class Initialized
INFO - 2023-06-27 08:24:19 --> Loader Class Initialized
INFO - 2023-06-27 08:24:19 --> Helper loaded: url_helper
INFO - 2023-06-27 08:24:19 --> Helper loaded: file_helper
INFO - 2023-06-27 08:24:19 --> Helper loaded: html_helper
INFO - 2023-06-27 08:24:19 --> Helper loaded: text_helper
INFO - 2023-06-27 08:24:19 --> Helper loaded: form_helper
INFO - 2023-06-27 08:24:19 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:24:19 --> Helper loaded: security_helper
INFO - 2023-06-27 08:24:19 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:24:19 --> Database Driver Class Initialized
INFO - 2023-06-27 08:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:24:19 --> Parser Class Initialized
INFO - 2023-06-27 08:24:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:24:19 --> Pagination Class Initialized
INFO - 2023-06-27 08:24:19 --> Form Validation Class Initialized
INFO - 2023-06-27 08:24:19 --> Controller Class Initialized
INFO - 2023-06-27 08:24:19 --> Model Class Initialized
DEBUG - 2023-06-27 08:24:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:24:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:19 --> Model Class Initialized
DEBUG - 2023-06-27 08:24:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:19 --> Model Class Initialized
INFO - 2023-06-27 08:24:19 --> Final output sent to browser
DEBUG - 2023-06-27 08:24:19 --> Total execution time: 0.0178
ERROR - 2023-06-27 08:24:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:24:20 --> Config Class Initialized
INFO - 2023-06-27 08:24:20 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:24:20 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:24:20 --> Utf8 Class Initialized
INFO - 2023-06-27 08:24:20 --> URI Class Initialized
INFO - 2023-06-27 08:24:20 --> Router Class Initialized
INFO - 2023-06-27 08:24:20 --> Output Class Initialized
INFO - 2023-06-27 08:24:20 --> Security Class Initialized
DEBUG - 2023-06-27 08:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:24:20 --> Input Class Initialized
INFO - 2023-06-27 08:24:20 --> Language Class Initialized
INFO - 2023-06-27 08:24:20 --> Loader Class Initialized
INFO - 2023-06-27 08:24:20 --> Helper loaded: url_helper
INFO - 2023-06-27 08:24:20 --> Helper loaded: file_helper
INFO - 2023-06-27 08:24:20 --> Helper loaded: html_helper
INFO - 2023-06-27 08:24:20 --> Helper loaded: text_helper
INFO - 2023-06-27 08:24:20 --> Helper loaded: form_helper
INFO - 2023-06-27 08:24:20 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:24:20 --> Helper loaded: security_helper
INFO - 2023-06-27 08:24:20 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:24:20 --> Database Driver Class Initialized
INFO - 2023-06-27 08:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:24:20 --> Parser Class Initialized
INFO - 2023-06-27 08:24:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:24:20 --> Pagination Class Initialized
INFO - 2023-06-27 08:24:20 --> Form Validation Class Initialized
INFO - 2023-06-27 08:24:20 --> Controller Class Initialized
INFO - 2023-06-27 08:24:20 --> Model Class Initialized
DEBUG - 2023-06-27 08:24:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:24:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:20 --> Model Class Initialized
DEBUG - 2023-06-27 08:24:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:20 --> Model Class Initialized
INFO - 2023-06-27 08:24:20 --> Final output sent to browser
DEBUG - 2023-06-27 08:24:20 --> Total execution time: 0.0181
ERROR - 2023-06-27 08:24:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:24:22 --> Config Class Initialized
INFO - 2023-06-27 08:24:22 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:24:22 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:24:22 --> Utf8 Class Initialized
INFO - 2023-06-27 08:24:22 --> URI Class Initialized
INFO - 2023-06-27 08:24:22 --> Router Class Initialized
INFO - 2023-06-27 08:24:22 --> Output Class Initialized
INFO - 2023-06-27 08:24:22 --> Security Class Initialized
DEBUG - 2023-06-27 08:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:24:22 --> Input Class Initialized
INFO - 2023-06-27 08:24:22 --> Language Class Initialized
INFO - 2023-06-27 08:24:22 --> Loader Class Initialized
INFO - 2023-06-27 08:24:22 --> Helper loaded: url_helper
INFO - 2023-06-27 08:24:22 --> Helper loaded: file_helper
INFO - 2023-06-27 08:24:22 --> Helper loaded: html_helper
INFO - 2023-06-27 08:24:22 --> Helper loaded: text_helper
INFO - 2023-06-27 08:24:22 --> Helper loaded: form_helper
INFO - 2023-06-27 08:24:22 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:24:22 --> Helper loaded: security_helper
INFO - 2023-06-27 08:24:22 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:24:22 --> Database Driver Class Initialized
INFO - 2023-06-27 08:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:24:22 --> Parser Class Initialized
INFO - 2023-06-27 08:24:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:24:22 --> Pagination Class Initialized
INFO - 2023-06-27 08:24:22 --> Form Validation Class Initialized
INFO - 2023-06-27 08:24:22 --> Controller Class Initialized
INFO - 2023-06-27 08:24:22 --> Model Class Initialized
DEBUG - 2023-06-27 08:24:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:24:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:22 --> Model Class Initialized
DEBUG - 2023-06-27 08:24:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:22 --> Model Class Initialized
INFO - 2023-06-27 08:24:22 --> Model Class Initialized
INFO - 2023-06-27 08:24:22 --> Final output sent to browser
DEBUG - 2023-06-27 08:24:22 --> Total execution time: 0.0216
ERROR - 2023-06-27 08:24:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:24:24 --> Config Class Initialized
INFO - 2023-06-27 08:24:24 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:24:24 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:24:24 --> Utf8 Class Initialized
INFO - 2023-06-27 08:24:24 --> URI Class Initialized
INFO - 2023-06-27 08:24:24 --> Router Class Initialized
INFO - 2023-06-27 08:24:24 --> Output Class Initialized
INFO - 2023-06-27 08:24:24 --> Security Class Initialized
DEBUG - 2023-06-27 08:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:24:24 --> Input Class Initialized
INFO - 2023-06-27 08:24:24 --> Language Class Initialized
INFO - 2023-06-27 08:24:24 --> Loader Class Initialized
INFO - 2023-06-27 08:24:24 --> Helper loaded: url_helper
INFO - 2023-06-27 08:24:24 --> Helper loaded: file_helper
INFO - 2023-06-27 08:24:24 --> Helper loaded: html_helper
INFO - 2023-06-27 08:24:24 --> Helper loaded: text_helper
INFO - 2023-06-27 08:24:24 --> Helper loaded: form_helper
INFO - 2023-06-27 08:24:24 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:24:24 --> Helper loaded: security_helper
INFO - 2023-06-27 08:24:24 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:24:24 --> Database Driver Class Initialized
INFO - 2023-06-27 08:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:24:24 --> Parser Class Initialized
INFO - 2023-06-27 08:24:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:24:24 --> Pagination Class Initialized
INFO - 2023-06-27 08:24:24 --> Form Validation Class Initialized
INFO - 2023-06-27 08:24:24 --> Controller Class Initialized
INFO - 2023-06-27 08:24:24 --> Model Class Initialized
DEBUG - 2023-06-27 08:24:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:24:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:24 --> Model Class Initialized
DEBUG - 2023-06-27 08:24:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:24 --> Model Class Initialized
INFO - 2023-06-27 08:24:24 --> Final output sent to browser
DEBUG - 2023-06-27 08:24:24 --> Total execution time: 0.0185
ERROR - 2023-06-27 08:24:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:24:32 --> Config Class Initialized
INFO - 2023-06-27 08:24:32 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:24:32 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:24:32 --> Utf8 Class Initialized
INFO - 2023-06-27 08:24:32 --> URI Class Initialized
INFO - 2023-06-27 08:24:32 --> Router Class Initialized
INFO - 2023-06-27 08:24:32 --> Output Class Initialized
INFO - 2023-06-27 08:24:32 --> Security Class Initialized
DEBUG - 2023-06-27 08:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:24:32 --> Input Class Initialized
INFO - 2023-06-27 08:24:32 --> Language Class Initialized
INFO - 2023-06-27 08:24:32 --> Loader Class Initialized
INFO - 2023-06-27 08:24:32 --> Helper loaded: url_helper
INFO - 2023-06-27 08:24:32 --> Helper loaded: file_helper
INFO - 2023-06-27 08:24:32 --> Helper loaded: html_helper
INFO - 2023-06-27 08:24:32 --> Helper loaded: text_helper
INFO - 2023-06-27 08:24:32 --> Helper loaded: form_helper
INFO - 2023-06-27 08:24:32 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:24:32 --> Helper loaded: security_helper
INFO - 2023-06-27 08:24:32 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:24:32 --> Database Driver Class Initialized
INFO - 2023-06-27 08:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:24:32 --> Parser Class Initialized
INFO - 2023-06-27 08:24:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:24:32 --> Pagination Class Initialized
INFO - 2023-06-27 08:24:32 --> Form Validation Class Initialized
INFO - 2023-06-27 08:24:32 --> Controller Class Initialized
INFO - 2023-06-27 08:24:32 --> Model Class Initialized
DEBUG - 2023-06-27 08:24:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:24:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:32 --> Model Class Initialized
INFO - 2023-06-27 08:24:32 --> Email Class Initialized
INFO - 2023-06-27 08:24:32 --> Language file loaded: language/english/email_lang.php
ERROR - 2023-06-27 08:24:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:24:32 --> Config Class Initialized
INFO - 2023-06-27 08:24:32 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:24:32 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:24:32 --> Utf8 Class Initialized
INFO - 2023-06-27 08:24:32 --> URI Class Initialized
INFO - 2023-06-27 08:24:32 --> Router Class Initialized
INFO - 2023-06-27 08:24:32 --> Output Class Initialized
INFO - 2023-06-27 08:24:32 --> Security Class Initialized
DEBUG - 2023-06-27 08:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:24:32 --> Input Class Initialized
INFO - 2023-06-27 08:24:32 --> Language Class Initialized
INFO - 2023-06-27 08:24:32 --> Loader Class Initialized
INFO - 2023-06-27 08:24:32 --> Helper loaded: url_helper
INFO - 2023-06-27 08:24:32 --> Helper loaded: file_helper
INFO - 2023-06-27 08:24:32 --> Helper loaded: html_helper
INFO - 2023-06-27 08:24:32 --> Helper loaded: text_helper
INFO - 2023-06-27 08:24:32 --> Helper loaded: form_helper
INFO - 2023-06-27 08:24:32 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:24:32 --> Helper loaded: security_helper
INFO - 2023-06-27 08:24:32 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:24:32 --> Database Driver Class Initialized
INFO - 2023-06-27 08:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:24:32 --> Parser Class Initialized
INFO - 2023-06-27 08:24:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:24:32 --> Pagination Class Initialized
INFO - 2023-06-27 08:24:32 --> Form Validation Class Initialized
INFO - 2023-06-27 08:24:32 --> Controller Class Initialized
INFO - 2023-06-27 08:24:32 --> Model Class Initialized
DEBUG - 2023-06-27 08:24:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:24:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:32 --> Model Class Initialized
DEBUG - 2023-06-27 08:24:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-06-27 08:24:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:24:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:24:32 --> Model Class Initialized
INFO - 2023-06-27 08:24:32 --> Model Class Initialized
INFO - 2023-06-27 08:24:32 --> Model Class Initialized
INFO - 2023-06-27 08:24:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:24:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:24:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:24:32 --> Final output sent to browser
DEBUG - 2023-06-27 08:24:32 --> Total execution time: 0.1387
ERROR - 2023-06-27 08:24:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:24:43 --> Config Class Initialized
INFO - 2023-06-27 08:24:43 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:24:43 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:24:43 --> Utf8 Class Initialized
INFO - 2023-06-27 08:24:43 --> URI Class Initialized
INFO - 2023-06-27 08:24:43 --> Router Class Initialized
INFO - 2023-06-27 08:24:43 --> Output Class Initialized
INFO - 2023-06-27 08:24:43 --> Security Class Initialized
DEBUG - 2023-06-27 08:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:24:43 --> Input Class Initialized
INFO - 2023-06-27 08:24:43 --> Language Class Initialized
INFO - 2023-06-27 08:24:43 --> Loader Class Initialized
INFO - 2023-06-27 08:24:43 --> Helper loaded: url_helper
INFO - 2023-06-27 08:24:43 --> Helper loaded: file_helper
INFO - 2023-06-27 08:24:43 --> Helper loaded: html_helper
INFO - 2023-06-27 08:24:43 --> Helper loaded: text_helper
INFO - 2023-06-27 08:24:43 --> Helper loaded: form_helper
INFO - 2023-06-27 08:24:43 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:24:43 --> Helper loaded: security_helper
INFO - 2023-06-27 08:24:43 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:24:43 --> Database Driver Class Initialized
INFO - 2023-06-27 08:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:24:43 --> Parser Class Initialized
INFO - 2023-06-27 08:24:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:24:43 --> Pagination Class Initialized
INFO - 2023-06-27 08:24:43 --> Form Validation Class Initialized
INFO - 2023-06-27 08:24:43 --> Controller Class Initialized
INFO - 2023-06-27 08:24:43 --> Model Class Initialized
DEBUG - 2023-06-27 08:24:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:24:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:43 --> Model Class Initialized
INFO - 2023-06-27 08:24:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-06-27 08:24:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:24:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:24:43 --> Model Class Initialized
INFO - 2023-06-27 08:24:43 --> Model Class Initialized
INFO - 2023-06-27 08:24:43 --> Model Class Initialized
INFO - 2023-06-27 08:24:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:24:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:24:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:24:43 --> Final output sent to browser
DEBUG - 2023-06-27 08:24:43 --> Total execution time: 0.0734
ERROR - 2023-06-27 08:24:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:24:44 --> Config Class Initialized
INFO - 2023-06-27 08:24:44 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:24:44 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:24:44 --> Utf8 Class Initialized
INFO - 2023-06-27 08:24:44 --> URI Class Initialized
INFO - 2023-06-27 08:24:44 --> Router Class Initialized
INFO - 2023-06-27 08:24:44 --> Output Class Initialized
INFO - 2023-06-27 08:24:44 --> Security Class Initialized
DEBUG - 2023-06-27 08:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:24:44 --> Input Class Initialized
INFO - 2023-06-27 08:24:44 --> Language Class Initialized
INFO - 2023-06-27 08:24:44 --> Loader Class Initialized
INFO - 2023-06-27 08:24:44 --> Helper loaded: url_helper
INFO - 2023-06-27 08:24:44 --> Helper loaded: file_helper
INFO - 2023-06-27 08:24:44 --> Helper loaded: html_helper
INFO - 2023-06-27 08:24:44 --> Helper loaded: text_helper
INFO - 2023-06-27 08:24:44 --> Helper loaded: form_helper
INFO - 2023-06-27 08:24:44 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:24:44 --> Helper loaded: security_helper
INFO - 2023-06-27 08:24:44 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:24:44 --> Database Driver Class Initialized
INFO - 2023-06-27 08:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:24:44 --> Parser Class Initialized
INFO - 2023-06-27 08:24:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:24:44 --> Pagination Class Initialized
INFO - 2023-06-27 08:24:44 --> Form Validation Class Initialized
INFO - 2023-06-27 08:24:44 --> Controller Class Initialized
INFO - 2023-06-27 08:24:44 --> Model Class Initialized
DEBUG - 2023-06-27 08:24:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:24:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:44 --> Model Class Initialized
INFO - 2023-06-27 08:24:44 --> Final output sent to browser
DEBUG - 2023-06-27 08:24:44 --> Total execution time: 0.0265
ERROR - 2023-06-27 08:24:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:24:47 --> Config Class Initialized
INFO - 2023-06-27 08:24:47 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:24:47 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:24:47 --> Utf8 Class Initialized
INFO - 2023-06-27 08:24:47 --> URI Class Initialized
INFO - 2023-06-27 08:24:47 --> Router Class Initialized
INFO - 2023-06-27 08:24:47 --> Output Class Initialized
INFO - 2023-06-27 08:24:47 --> Security Class Initialized
DEBUG - 2023-06-27 08:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:24:47 --> Input Class Initialized
INFO - 2023-06-27 08:24:47 --> Language Class Initialized
INFO - 2023-06-27 08:24:47 --> Loader Class Initialized
INFO - 2023-06-27 08:24:47 --> Helper loaded: url_helper
INFO - 2023-06-27 08:24:47 --> Helper loaded: file_helper
INFO - 2023-06-27 08:24:47 --> Helper loaded: html_helper
INFO - 2023-06-27 08:24:47 --> Helper loaded: text_helper
INFO - 2023-06-27 08:24:47 --> Helper loaded: form_helper
INFO - 2023-06-27 08:24:47 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:24:47 --> Helper loaded: security_helper
INFO - 2023-06-27 08:24:47 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:24:47 --> Database Driver Class Initialized
INFO - 2023-06-27 08:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:24:47 --> Parser Class Initialized
INFO - 2023-06-27 08:24:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:24:47 --> Pagination Class Initialized
INFO - 2023-06-27 08:24:47 --> Form Validation Class Initialized
INFO - 2023-06-27 08:24:47 --> Controller Class Initialized
INFO - 2023-06-27 08:24:47 --> Model Class Initialized
DEBUG - 2023-06-27 08:24:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:47 --> Model Class Initialized
DEBUG - 2023-06-27 08:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-06-27 08:24:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:24:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:24:47 --> Model Class Initialized
INFO - 2023-06-27 08:24:47 --> Model Class Initialized
INFO - 2023-06-27 08:24:47 --> Model Class Initialized
INFO - 2023-06-27 08:24:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:24:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:24:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:24:47 --> Final output sent to browser
DEBUG - 2023-06-27 08:24:47 --> Total execution time: 0.0780
ERROR - 2023-06-27 08:24:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:24:50 --> Config Class Initialized
INFO - 2023-06-27 08:24:50 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:24:50 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:24:50 --> Utf8 Class Initialized
INFO - 2023-06-27 08:24:50 --> URI Class Initialized
INFO - 2023-06-27 08:24:50 --> Router Class Initialized
INFO - 2023-06-27 08:24:50 --> Output Class Initialized
INFO - 2023-06-27 08:24:50 --> Security Class Initialized
DEBUG - 2023-06-27 08:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:24:50 --> Input Class Initialized
INFO - 2023-06-27 08:24:50 --> Language Class Initialized
INFO - 2023-06-27 08:24:50 --> Loader Class Initialized
INFO - 2023-06-27 08:24:50 --> Helper loaded: url_helper
INFO - 2023-06-27 08:24:50 --> Helper loaded: file_helper
INFO - 2023-06-27 08:24:50 --> Helper loaded: html_helper
INFO - 2023-06-27 08:24:50 --> Helper loaded: text_helper
INFO - 2023-06-27 08:24:50 --> Helper loaded: form_helper
INFO - 2023-06-27 08:24:50 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:24:50 --> Helper loaded: security_helper
INFO - 2023-06-27 08:24:50 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:24:50 --> Database Driver Class Initialized
INFO - 2023-06-27 08:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:24:50 --> Parser Class Initialized
INFO - 2023-06-27 08:24:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:24:50 --> Pagination Class Initialized
INFO - 2023-06-27 08:24:50 --> Form Validation Class Initialized
INFO - 2023-06-27 08:24:50 --> Controller Class Initialized
INFO - 2023-06-27 08:24:50 --> Final output sent to browser
DEBUG - 2023-06-27 08:24:50 --> Total execution time: 0.0126
ERROR - 2023-06-27 08:24:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:24:54 --> Config Class Initialized
INFO - 2023-06-27 08:24:54 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:24:54 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:24:54 --> Utf8 Class Initialized
INFO - 2023-06-27 08:24:54 --> URI Class Initialized
INFO - 2023-06-27 08:24:54 --> Router Class Initialized
INFO - 2023-06-27 08:24:54 --> Output Class Initialized
INFO - 2023-06-27 08:24:54 --> Security Class Initialized
DEBUG - 2023-06-27 08:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:24:54 --> Input Class Initialized
INFO - 2023-06-27 08:24:54 --> Language Class Initialized
INFO - 2023-06-27 08:24:54 --> Loader Class Initialized
INFO - 2023-06-27 08:24:54 --> Helper loaded: url_helper
INFO - 2023-06-27 08:24:54 --> Helper loaded: file_helper
INFO - 2023-06-27 08:24:54 --> Helper loaded: html_helper
INFO - 2023-06-27 08:24:54 --> Helper loaded: text_helper
INFO - 2023-06-27 08:24:54 --> Helper loaded: form_helper
INFO - 2023-06-27 08:24:54 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:24:54 --> Helper loaded: security_helper
INFO - 2023-06-27 08:24:54 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:24:54 --> Database Driver Class Initialized
INFO - 2023-06-27 08:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:24:54 --> Parser Class Initialized
INFO - 2023-06-27 08:24:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:24:54 --> Pagination Class Initialized
INFO - 2023-06-27 08:24:54 --> Form Validation Class Initialized
INFO - 2023-06-27 08:24:54 --> Controller Class Initialized
INFO - 2023-06-27 08:24:54 --> Model Class Initialized
DEBUG - 2023-06-27 08:24:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:24:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:54 --> Model Class Initialized
DEBUG - 2023-06-27 08:24:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest_html.php
DEBUG - 2023-06-27 08:24:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:24:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:24:54 --> Model Class Initialized
INFO - 2023-06-27 08:24:54 --> Model Class Initialized
INFO - 2023-06-27 08:24:54 --> Model Class Initialized
INFO - 2023-06-27 08:24:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:24:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:24:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:24:54 --> Final output sent to browser
DEBUG - 2023-06-27 08:24:54 --> Total execution time: 0.0739
ERROR - 2023-06-27 08:24:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:24:57 --> Config Class Initialized
INFO - 2023-06-27 08:24:57 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:24:57 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:24:57 --> Utf8 Class Initialized
INFO - 2023-06-27 08:24:57 --> URI Class Initialized
INFO - 2023-06-27 08:24:57 --> Router Class Initialized
INFO - 2023-06-27 08:24:57 --> Output Class Initialized
INFO - 2023-06-27 08:24:57 --> Security Class Initialized
DEBUG - 2023-06-27 08:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:24:57 --> Input Class Initialized
INFO - 2023-06-27 08:24:57 --> Language Class Initialized
INFO - 2023-06-27 08:24:57 --> Loader Class Initialized
INFO - 2023-06-27 08:24:57 --> Helper loaded: url_helper
INFO - 2023-06-27 08:24:57 --> Helper loaded: file_helper
INFO - 2023-06-27 08:24:57 --> Helper loaded: html_helper
INFO - 2023-06-27 08:24:57 --> Helper loaded: text_helper
INFO - 2023-06-27 08:24:57 --> Helper loaded: form_helper
INFO - 2023-06-27 08:24:57 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:24:57 --> Helper loaded: security_helper
INFO - 2023-06-27 08:24:57 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:24:57 --> Database Driver Class Initialized
INFO - 2023-06-27 08:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:24:57 --> Parser Class Initialized
INFO - 2023-06-27 08:24:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:24:57 --> Pagination Class Initialized
INFO - 2023-06-27 08:24:57 --> Form Validation Class Initialized
INFO - 2023-06-27 08:24:57 --> Controller Class Initialized
INFO - 2023-06-27 08:24:57 --> Model Class Initialized
DEBUG - 2023-06-27 08:24:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:24:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:57 --> Model Class Initialized
DEBUG - 2023-06-27 08:24:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:57 --> Model Class Initialized
INFO - 2023-06-27 08:24:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-27 08:24:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:24:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:24:57 --> Model Class Initialized
INFO - 2023-06-27 08:24:57 --> Model Class Initialized
INFO - 2023-06-27 08:24:57 --> Model Class Initialized
INFO - 2023-06-27 08:24:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:24:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:24:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:24:57 --> Final output sent to browser
DEBUG - 2023-06-27 08:24:57 --> Total execution time: 0.0726
ERROR - 2023-06-27 08:24:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:24:58 --> Config Class Initialized
INFO - 2023-06-27 08:24:58 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:24:58 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:24:58 --> Utf8 Class Initialized
INFO - 2023-06-27 08:24:58 --> URI Class Initialized
INFO - 2023-06-27 08:24:58 --> Router Class Initialized
INFO - 2023-06-27 08:24:58 --> Output Class Initialized
INFO - 2023-06-27 08:24:58 --> Security Class Initialized
DEBUG - 2023-06-27 08:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:24:58 --> Input Class Initialized
INFO - 2023-06-27 08:24:58 --> Language Class Initialized
INFO - 2023-06-27 08:24:58 --> Loader Class Initialized
INFO - 2023-06-27 08:24:58 --> Helper loaded: url_helper
INFO - 2023-06-27 08:24:58 --> Helper loaded: file_helper
INFO - 2023-06-27 08:24:58 --> Helper loaded: html_helper
INFO - 2023-06-27 08:24:58 --> Helper loaded: text_helper
INFO - 2023-06-27 08:24:58 --> Helper loaded: form_helper
INFO - 2023-06-27 08:24:58 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:24:58 --> Helper loaded: security_helper
INFO - 2023-06-27 08:24:58 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:24:58 --> Database Driver Class Initialized
INFO - 2023-06-27 08:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:24:58 --> Parser Class Initialized
INFO - 2023-06-27 08:24:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:24:58 --> Pagination Class Initialized
INFO - 2023-06-27 08:24:58 --> Form Validation Class Initialized
INFO - 2023-06-27 08:24:58 --> Controller Class Initialized
INFO - 2023-06-27 08:24:58 --> Model Class Initialized
DEBUG - 2023-06-27 08:24:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:24:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:58 --> Model Class Initialized
DEBUG - 2023-06-27 08:24:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:24:58 --> Model Class Initialized
INFO - 2023-06-27 08:24:58 --> Final output sent to browser
DEBUG - 2023-06-27 08:24:58 --> Total execution time: 0.0391
ERROR - 2023-06-27 08:25:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:25:01 --> Config Class Initialized
INFO - 2023-06-27 08:25:01 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:25:01 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:25:01 --> Utf8 Class Initialized
INFO - 2023-06-27 08:25:01 --> URI Class Initialized
INFO - 2023-06-27 08:25:01 --> Router Class Initialized
INFO - 2023-06-27 08:25:01 --> Output Class Initialized
INFO - 2023-06-27 08:25:01 --> Security Class Initialized
DEBUG - 2023-06-27 08:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:25:01 --> Input Class Initialized
INFO - 2023-06-27 08:25:01 --> Language Class Initialized
INFO - 2023-06-27 08:25:01 --> Loader Class Initialized
INFO - 2023-06-27 08:25:01 --> Helper loaded: url_helper
INFO - 2023-06-27 08:25:01 --> Helper loaded: file_helper
INFO - 2023-06-27 08:25:01 --> Helper loaded: html_helper
INFO - 2023-06-27 08:25:01 --> Helper loaded: text_helper
INFO - 2023-06-27 08:25:01 --> Helper loaded: form_helper
INFO - 2023-06-27 08:25:01 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:25:01 --> Helper loaded: security_helper
INFO - 2023-06-27 08:25:01 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:25:01 --> Database Driver Class Initialized
INFO - 2023-06-27 08:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:25:01 --> Parser Class Initialized
INFO - 2023-06-27 08:25:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:25:01 --> Pagination Class Initialized
INFO - 2023-06-27 08:25:01 --> Form Validation Class Initialized
INFO - 2023-06-27 08:25:01 --> Controller Class Initialized
INFO - 2023-06-27 08:25:01 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:25:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:01 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:01 --> Model Class Initialized
INFO - 2023-06-27 08:25:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-06-27 08:25:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:25:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:25:02 --> Model Class Initialized
INFO - 2023-06-27 08:25:02 --> Model Class Initialized
INFO - 2023-06-27 08:25:02 --> Model Class Initialized
INFO - 2023-06-27 08:25:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:25:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:25:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:25:02 --> Final output sent to browser
DEBUG - 2023-06-27 08:25:02 --> Total execution time: 0.1134
ERROR - 2023-06-27 08:25:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:25:05 --> Config Class Initialized
INFO - 2023-06-27 08:25:05 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:25:05 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:25:05 --> Utf8 Class Initialized
INFO - 2023-06-27 08:25:05 --> URI Class Initialized
INFO - 2023-06-27 08:25:05 --> Router Class Initialized
INFO - 2023-06-27 08:25:05 --> Output Class Initialized
INFO - 2023-06-27 08:25:05 --> Security Class Initialized
DEBUG - 2023-06-27 08:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:25:05 --> Input Class Initialized
INFO - 2023-06-27 08:25:05 --> Language Class Initialized
INFO - 2023-06-27 08:25:05 --> Loader Class Initialized
INFO - 2023-06-27 08:25:05 --> Helper loaded: url_helper
INFO - 2023-06-27 08:25:05 --> Helper loaded: file_helper
INFO - 2023-06-27 08:25:05 --> Helper loaded: html_helper
INFO - 2023-06-27 08:25:05 --> Helper loaded: text_helper
INFO - 2023-06-27 08:25:05 --> Helper loaded: form_helper
INFO - 2023-06-27 08:25:05 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:25:05 --> Helper loaded: security_helper
INFO - 2023-06-27 08:25:05 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:25:05 --> Database Driver Class Initialized
INFO - 2023-06-27 08:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:25:05 --> Parser Class Initialized
INFO - 2023-06-27 08:25:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:25:05 --> Pagination Class Initialized
INFO - 2023-06-27 08:25:05 --> Form Validation Class Initialized
INFO - 2023-06-27 08:25:05 --> Controller Class Initialized
INFO - 2023-06-27 08:25:05 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-27 08:25:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-06-27 08:25:05 --> Final output sent to browser
DEBUG - 2023-06-27 08:25:05 --> Total execution time: 0.0192
ERROR - 2023-06-27 08:25:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:25:08 --> Config Class Initialized
INFO - 2023-06-27 08:25:08 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:25:08 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:25:08 --> Utf8 Class Initialized
INFO - 2023-06-27 08:25:08 --> URI Class Initialized
INFO - 2023-06-27 08:25:08 --> Router Class Initialized
INFO - 2023-06-27 08:25:08 --> Output Class Initialized
INFO - 2023-06-27 08:25:08 --> Security Class Initialized
DEBUG - 2023-06-27 08:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:25:08 --> Input Class Initialized
INFO - 2023-06-27 08:25:08 --> Language Class Initialized
INFO - 2023-06-27 08:25:08 --> Loader Class Initialized
INFO - 2023-06-27 08:25:08 --> Helper loaded: url_helper
INFO - 2023-06-27 08:25:08 --> Helper loaded: file_helper
INFO - 2023-06-27 08:25:08 --> Helper loaded: html_helper
INFO - 2023-06-27 08:25:08 --> Helper loaded: text_helper
INFO - 2023-06-27 08:25:08 --> Helper loaded: form_helper
INFO - 2023-06-27 08:25:08 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:25:08 --> Helper loaded: security_helper
INFO - 2023-06-27 08:25:08 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:25:08 --> Database Driver Class Initialized
INFO - 2023-06-27 08:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:25:08 --> Parser Class Initialized
INFO - 2023-06-27 08:25:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:25:08 --> Pagination Class Initialized
INFO - 2023-06-27 08:25:08 --> Form Validation Class Initialized
INFO - 2023-06-27 08:25:08 --> Controller Class Initialized
INFO - 2023-06-27 08:25:08 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:08 --> Final output sent to browser
DEBUG - 2023-06-27 08:25:08 --> Total execution time: 0.0153
ERROR - 2023-06-27 08:25:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:25:08 --> Config Class Initialized
INFO - 2023-06-27 08:25:08 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:25:08 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:25:08 --> Utf8 Class Initialized
INFO - 2023-06-27 08:25:08 --> URI Class Initialized
INFO - 2023-06-27 08:25:08 --> Router Class Initialized
INFO - 2023-06-27 08:25:08 --> Output Class Initialized
INFO - 2023-06-27 08:25:08 --> Security Class Initialized
DEBUG - 2023-06-27 08:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:25:08 --> Input Class Initialized
INFO - 2023-06-27 08:25:08 --> Language Class Initialized
INFO - 2023-06-27 08:25:08 --> Loader Class Initialized
INFO - 2023-06-27 08:25:08 --> Helper loaded: url_helper
INFO - 2023-06-27 08:25:08 --> Helper loaded: file_helper
INFO - 2023-06-27 08:25:08 --> Helper loaded: html_helper
INFO - 2023-06-27 08:25:08 --> Helper loaded: text_helper
INFO - 2023-06-27 08:25:08 --> Helper loaded: form_helper
INFO - 2023-06-27 08:25:08 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:25:08 --> Helper loaded: security_helper
INFO - 2023-06-27 08:25:08 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:25:08 --> Database Driver Class Initialized
INFO - 2023-06-27 08:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:25:08 --> Parser Class Initialized
INFO - 2023-06-27 08:25:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:25:08 --> Pagination Class Initialized
INFO - 2023-06-27 08:25:08 --> Form Validation Class Initialized
INFO - 2023-06-27 08:25:08 --> Controller Class Initialized
INFO - 2023-06-27 08:25:08 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:08 --> Final output sent to browser
DEBUG - 2023-06-27 08:25:08 --> Total execution time: 0.0151
ERROR - 2023-06-27 08:25:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:25:08 --> Config Class Initialized
INFO - 2023-06-27 08:25:08 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:25:08 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:25:08 --> Utf8 Class Initialized
INFO - 2023-06-27 08:25:08 --> URI Class Initialized
INFO - 2023-06-27 08:25:08 --> Router Class Initialized
INFO - 2023-06-27 08:25:08 --> Output Class Initialized
INFO - 2023-06-27 08:25:08 --> Security Class Initialized
DEBUG - 2023-06-27 08:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:25:08 --> Input Class Initialized
INFO - 2023-06-27 08:25:08 --> Language Class Initialized
INFO - 2023-06-27 08:25:08 --> Loader Class Initialized
INFO - 2023-06-27 08:25:08 --> Helper loaded: url_helper
INFO - 2023-06-27 08:25:08 --> Helper loaded: file_helper
INFO - 2023-06-27 08:25:08 --> Helper loaded: html_helper
INFO - 2023-06-27 08:25:08 --> Helper loaded: text_helper
INFO - 2023-06-27 08:25:08 --> Helper loaded: form_helper
INFO - 2023-06-27 08:25:08 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:25:08 --> Helper loaded: security_helper
INFO - 2023-06-27 08:25:08 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:25:08 --> Database Driver Class Initialized
INFO - 2023-06-27 08:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:25:08 --> Parser Class Initialized
INFO - 2023-06-27 08:25:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:25:08 --> Pagination Class Initialized
INFO - 2023-06-27 08:25:08 --> Form Validation Class Initialized
INFO - 2023-06-27 08:25:08 --> Controller Class Initialized
INFO - 2023-06-27 08:25:08 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:08 --> Final output sent to browser
DEBUG - 2023-06-27 08:25:08 --> Total execution time: 0.0151
ERROR - 2023-06-27 08:25:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:25:10 --> Config Class Initialized
INFO - 2023-06-27 08:25:10 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:25:10 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:25:10 --> Utf8 Class Initialized
INFO - 2023-06-27 08:25:10 --> URI Class Initialized
INFO - 2023-06-27 08:25:10 --> Router Class Initialized
INFO - 2023-06-27 08:25:10 --> Output Class Initialized
INFO - 2023-06-27 08:25:10 --> Security Class Initialized
DEBUG - 2023-06-27 08:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:25:10 --> Input Class Initialized
INFO - 2023-06-27 08:25:10 --> Language Class Initialized
INFO - 2023-06-27 08:25:10 --> Loader Class Initialized
INFO - 2023-06-27 08:25:10 --> Helper loaded: url_helper
INFO - 2023-06-27 08:25:10 --> Helper loaded: file_helper
INFO - 2023-06-27 08:25:10 --> Helper loaded: html_helper
INFO - 2023-06-27 08:25:10 --> Helper loaded: text_helper
INFO - 2023-06-27 08:25:10 --> Helper loaded: form_helper
INFO - 2023-06-27 08:25:10 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:25:10 --> Helper loaded: security_helper
INFO - 2023-06-27 08:25:10 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:25:10 --> Database Driver Class Initialized
INFO - 2023-06-27 08:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:25:10 --> Parser Class Initialized
INFO - 2023-06-27 08:25:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:25:10 --> Pagination Class Initialized
INFO - 2023-06-27 08:25:10 --> Form Validation Class Initialized
INFO - 2023-06-27 08:25:10 --> Controller Class Initialized
INFO - 2023-06-27 08:25:10 --> Final output sent to browser
DEBUG - 2023-06-27 08:25:10 --> Total execution time: 0.0136
ERROR - 2023-06-27 08:25:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:25:12 --> Config Class Initialized
INFO - 2023-06-27 08:25:12 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:25:12 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:25:12 --> Utf8 Class Initialized
INFO - 2023-06-27 08:25:12 --> URI Class Initialized
INFO - 2023-06-27 08:25:12 --> Router Class Initialized
INFO - 2023-06-27 08:25:12 --> Output Class Initialized
INFO - 2023-06-27 08:25:12 --> Security Class Initialized
DEBUG - 2023-06-27 08:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:25:12 --> Input Class Initialized
INFO - 2023-06-27 08:25:12 --> Language Class Initialized
INFO - 2023-06-27 08:25:12 --> Loader Class Initialized
INFO - 2023-06-27 08:25:12 --> Helper loaded: url_helper
INFO - 2023-06-27 08:25:12 --> Helper loaded: file_helper
INFO - 2023-06-27 08:25:12 --> Helper loaded: html_helper
INFO - 2023-06-27 08:25:12 --> Helper loaded: text_helper
INFO - 2023-06-27 08:25:12 --> Helper loaded: form_helper
INFO - 2023-06-27 08:25:12 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:25:12 --> Helper loaded: security_helper
INFO - 2023-06-27 08:25:12 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:25:12 --> Database Driver Class Initialized
INFO - 2023-06-27 08:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:25:12 --> Parser Class Initialized
INFO - 2023-06-27 08:25:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:25:12 --> Pagination Class Initialized
INFO - 2023-06-27 08:25:12 --> Form Validation Class Initialized
INFO - 2023-06-27 08:25:12 --> Controller Class Initialized
INFO - 2023-06-27 08:25:12 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:25:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:12 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:12 --> Model Class Initialized
INFO - 2023-06-27 08:25:12 --> Final output sent to browser
DEBUG - 2023-06-27 08:25:12 --> Total execution time: 0.0435
ERROR - 2023-06-27 08:25:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:25:13 --> Config Class Initialized
INFO - 2023-06-27 08:25:13 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:25:13 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:25:13 --> Utf8 Class Initialized
INFO - 2023-06-27 08:25:13 --> URI Class Initialized
INFO - 2023-06-27 08:25:13 --> Router Class Initialized
INFO - 2023-06-27 08:25:13 --> Output Class Initialized
INFO - 2023-06-27 08:25:13 --> Security Class Initialized
DEBUG - 2023-06-27 08:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:25:13 --> Input Class Initialized
INFO - 2023-06-27 08:25:13 --> Language Class Initialized
INFO - 2023-06-27 08:25:13 --> Loader Class Initialized
INFO - 2023-06-27 08:25:13 --> Helper loaded: url_helper
INFO - 2023-06-27 08:25:13 --> Helper loaded: file_helper
INFO - 2023-06-27 08:25:13 --> Helper loaded: html_helper
INFO - 2023-06-27 08:25:13 --> Helper loaded: text_helper
INFO - 2023-06-27 08:25:13 --> Helper loaded: form_helper
INFO - 2023-06-27 08:25:13 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:25:13 --> Helper loaded: security_helper
INFO - 2023-06-27 08:25:13 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:25:13 --> Database Driver Class Initialized
INFO - 2023-06-27 08:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:25:13 --> Parser Class Initialized
INFO - 2023-06-27 08:25:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:25:13 --> Pagination Class Initialized
INFO - 2023-06-27 08:25:13 --> Form Validation Class Initialized
INFO - 2023-06-27 08:25:13 --> Controller Class Initialized
INFO - 2023-06-27 08:25:13 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:25:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:13 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:13 --> Model Class Initialized
INFO - 2023-06-27 08:25:13 --> Final output sent to browser
DEBUG - 2023-06-27 08:25:13 --> Total execution time: 0.0480
ERROR - 2023-06-27 08:25:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:25:14 --> Config Class Initialized
INFO - 2023-06-27 08:25:14 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:25:14 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:25:14 --> Utf8 Class Initialized
INFO - 2023-06-27 08:25:14 --> URI Class Initialized
INFO - 2023-06-27 08:25:14 --> Router Class Initialized
INFO - 2023-06-27 08:25:14 --> Output Class Initialized
INFO - 2023-06-27 08:25:14 --> Security Class Initialized
DEBUG - 2023-06-27 08:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:25:14 --> Input Class Initialized
INFO - 2023-06-27 08:25:14 --> Language Class Initialized
INFO - 2023-06-27 08:25:14 --> Loader Class Initialized
INFO - 2023-06-27 08:25:14 --> Helper loaded: url_helper
INFO - 2023-06-27 08:25:14 --> Helper loaded: file_helper
INFO - 2023-06-27 08:25:14 --> Helper loaded: html_helper
INFO - 2023-06-27 08:25:14 --> Helper loaded: text_helper
INFO - 2023-06-27 08:25:14 --> Helper loaded: form_helper
INFO - 2023-06-27 08:25:14 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:25:14 --> Helper loaded: security_helper
INFO - 2023-06-27 08:25:14 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:25:14 --> Database Driver Class Initialized
INFO - 2023-06-27 08:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:25:14 --> Parser Class Initialized
INFO - 2023-06-27 08:25:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:25:14 --> Pagination Class Initialized
INFO - 2023-06-27 08:25:14 --> Form Validation Class Initialized
INFO - 2023-06-27 08:25:14 --> Controller Class Initialized
INFO - 2023-06-27 08:25:14 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:25:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:14 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:14 --> Model Class Initialized
INFO - 2023-06-27 08:25:14 --> Final output sent to browser
DEBUG - 2023-06-27 08:25:14 --> Total execution time: 0.0428
ERROR - 2023-06-27 08:25:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:25:14 --> Config Class Initialized
INFO - 2023-06-27 08:25:14 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:25:14 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:25:14 --> Utf8 Class Initialized
INFO - 2023-06-27 08:25:14 --> URI Class Initialized
INFO - 2023-06-27 08:25:14 --> Router Class Initialized
INFO - 2023-06-27 08:25:14 --> Output Class Initialized
INFO - 2023-06-27 08:25:14 --> Security Class Initialized
DEBUG - 2023-06-27 08:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:25:14 --> Input Class Initialized
INFO - 2023-06-27 08:25:14 --> Language Class Initialized
INFO - 2023-06-27 08:25:14 --> Loader Class Initialized
INFO - 2023-06-27 08:25:14 --> Helper loaded: url_helper
INFO - 2023-06-27 08:25:14 --> Helper loaded: file_helper
INFO - 2023-06-27 08:25:14 --> Helper loaded: html_helper
INFO - 2023-06-27 08:25:14 --> Helper loaded: text_helper
INFO - 2023-06-27 08:25:14 --> Helper loaded: form_helper
INFO - 2023-06-27 08:25:14 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:25:14 --> Helper loaded: security_helper
INFO - 2023-06-27 08:25:14 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:25:14 --> Database Driver Class Initialized
INFO - 2023-06-27 08:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:25:14 --> Parser Class Initialized
INFO - 2023-06-27 08:25:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:25:14 --> Pagination Class Initialized
INFO - 2023-06-27 08:25:14 --> Form Validation Class Initialized
INFO - 2023-06-27 08:25:14 --> Controller Class Initialized
INFO - 2023-06-27 08:25:14 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:25:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:14 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:14 --> Model Class Initialized
INFO - 2023-06-27 08:25:15 --> Final output sent to browser
DEBUG - 2023-06-27 08:25:15 --> Total execution time: 0.0438
ERROR - 2023-06-27 08:25:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:25:16 --> Config Class Initialized
INFO - 2023-06-27 08:25:16 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:25:16 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:25:16 --> Utf8 Class Initialized
INFO - 2023-06-27 08:25:16 --> URI Class Initialized
INFO - 2023-06-27 08:25:16 --> Router Class Initialized
INFO - 2023-06-27 08:25:16 --> Output Class Initialized
INFO - 2023-06-27 08:25:16 --> Security Class Initialized
DEBUG - 2023-06-27 08:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:25:16 --> Input Class Initialized
INFO - 2023-06-27 08:25:16 --> Language Class Initialized
INFO - 2023-06-27 08:25:16 --> Loader Class Initialized
INFO - 2023-06-27 08:25:16 --> Helper loaded: url_helper
INFO - 2023-06-27 08:25:16 --> Helper loaded: file_helper
INFO - 2023-06-27 08:25:16 --> Helper loaded: html_helper
INFO - 2023-06-27 08:25:16 --> Helper loaded: text_helper
INFO - 2023-06-27 08:25:16 --> Helper loaded: form_helper
INFO - 2023-06-27 08:25:16 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:25:16 --> Helper loaded: security_helper
INFO - 2023-06-27 08:25:16 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:25:16 --> Database Driver Class Initialized
INFO - 2023-06-27 08:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:25:16 --> Parser Class Initialized
INFO - 2023-06-27 08:25:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:25:16 --> Pagination Class Initialized
INFO - 2023-06-27 08:25:16 --> Form Validation Class Initialized
INFO - 2023-06-27 08:25:16 --> Controller Class Initialized
INFO - 2023-06-27 08:25:16 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:25:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:16 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:16 --> Model Class Initialized
INFO - 2023-06-27 08:25:16 --> Final output sent to browser
DEBUG - 2023-06-27 08:25:16 --> Total execution time: 0.0448
ERROR - 2023-06-27 08:25:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:25:16 --> Config Class Initialized
INFO - 2023-06-27 08:25:16 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:25:16 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:25:16 --> Utf8 Class Initialized
INFO - 2023-06-27 08:25:16 --> URI Class Initialized
INFO - 2023-06-27 08:25:16 --> Router Class Initialized
INFO - 2023-06-27 08:25:16 --> Output Class Initialized
INFO - 2023-06-27 08:25:16 --> Security Class Initialized
DEBUG - 2023-06-27 08:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:25:16 --> Input Class Initialized
INFO - 2023-06-27 08:25:16 --> Language Class Initialized
INFO - 2023-06-27 08:25:16 --> Loader Class Initialized
INFO - 2023-06-27 08:25:16 --> Helper loaded: url_helper
INFO - 2023-06-27 08:25:16 --> Helper loaded: file_helper
INFO - 2023-06-27 08:25:16 --> Helper loaded: html_helper
INFO - 2023-06-27 08:25:16 --> Helper loaded: text_helper
INFO - 2023-06-27 08:25:16 --> Helper loaded: form_helper
INFO - 2023-06-27 08:25:16 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:25:16 --> Helper loaded: security_helper
INFO - 2023-06-27 08:25:16 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:25:16 --> Database Driver Class Initialized
INFO - 2023-06-27 08:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:25:16 --> Parser Class Initialized
INFO - 2023-06-27 08:25:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:25:16 --> Pagination Class Initialized
INFO - 2023-06-27 08:25:16 --> Form Validation Class Initialized
INFO - 2023-06-27 08:25:16 --> Controller Class Initialized
INFO - 2023-06-27 08:25:16 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:25:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:16 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:16 --> Model Class Initialized
INFO - 2023-06-27 08:25:16 --> Final output sent to browser
DEBUG - 2023-06-27 08:25:16 --> Total execution time: 0.0269
ERROR - 2023-06-27 08:25:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:25:26 --> Config Class Initialized
INFO - 2023-06-27 08:25:26 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:25:26 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:25:26 --> Utf8 Class Initialized
INFO - 2023-06-27 08:25:26 --> URI Class Initialized
INFO - 2023-06-27 08:25:26 --> Router Class Initialized
INFO - 2023-06-27 08:25:26 --> Output Class Initialized
INFO - 2023-06-27 08:25:26 --> Security Class Initialized
DEBUG - 2023-06-27 08:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:25:26 --> Input Class Initialized
INFO - 2023-06-27 08:25:26 --> Language Class Initialized
INFO - 2023-06-27 08:25:26 --> Loader Class Initialized
INFO - 2023-06-27 08:25:26 --> Helper loaded: url_helper
INFO - 2023-06-27 08:25:26 --> Helper loaded: file_helper
INFO - 2023-06-27 08:25:26 --> Helper loaded: html_helper
INFO - 2023-06-27 08:25:26 --> Helper loaded: text_helper
INFO - 2023-06-27 08:25:26 --> Helper loaded: form_helper
INFO - 2023-06-27 08:25:26 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:25:26 --> Helper loaded: security_helper
INFO - 2023-06-27 08:25:26 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:25:26 --> Database Driver Class Initialized
INFO - 2023-06-27 08:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:25:26 --> Parser Class Initialized
INFO - 2023-06-27 08:25:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:25:26 --> Pagination Class Initialized
INFO - 2023-06-27 08:25:26 --> Form Validation Class Initialized
INFO - 2023-06-27 08:25:26 --> Controller Class Initialized
INFO - 2023-06-27 08:25:26 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:25:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:26 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:26 --> Model Class Initialized
INFO - 2023-06-27 08:25:26 --> Final output sent to browser
DEBUG - 2023-06-27 08:25:26 --> Total execution time: 0.0454
ERROR - 2023-06-27 08:25:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:25:29 --> Config Class Initialized
INFO - 2023-06-27 08:25:29 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:25:29 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:25:29 --> Utf8 Class Initialized
INFO - 2023-06-27 08:25:29 --> URI Class Initialized
INFO - 2023-06-27 08:25:29 --> Router Class Initialized
INFO - 2023-06-27 08:25:29 --> Output Class Initialized
INFO - 2023-06-27 08:25:29 --> Security Class Initialized
DEBUG - 2023-06-27 08:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:25:29 --> Input Class Initialized
INFO - 2023-06-27 08:25:29 --> Language Class Initialized
INFO - 2023-06-27 08:25:29 --> Loader Class Initialized
INFO - 2023-06-27 08:25:29 --> Helper loaded: url_helper
INFO - 2023-06-27 08:25:29 --> Helper loaded: file_helper
INFO - 2023-06-27 08:25:29 --> Helper loaded: html_helper
INFO - 2023-06-27 08:25:29 --> Helper loaded: text_helper
INFO - 2023-06-27 08:25:29 --> Helper loaded: form_helper
INFO - 2023-06-27 08:25:29 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:25:29 --> Helper loaded: security_helper
INFO - 2023-06-27 08:25:29 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:25:29 --> Database Driver Class Initialized
INFO - 2023-06-27 08:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:25:29 --> Parser Class Initialized
INFO - 2023-06-27 08:25:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:25:29 --> Pagination Class Initialized
INFO - 2023-06-27 08:25:29 --> Form Validation Class Initialized
INFO - 2023-06-27 08:25:29 --> Controller Class Initialized
INFO - 2023-06-27 08:25:29 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:25:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:29 --> Model Class Initialized
INFO - 2023-06-27 08:25:29 --> Model Class Initialized
INFO - 2023-06-27 08:25:29 --> Final output sent to browser
DEBUG - 2023-06-27 08:25:29 --> Total execution time: 0.0222
ERROR - 2023-06-27 08:25:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:25:32 --> Config Class Initialized
INFO - 2023-06-27 08:25:32 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:25:32 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:25:32 --> Utf8 Class Initialized
INFO - 2023-06-27 08:25:32 --> URI Class Initialized
INFO - 2023-06-27 08:25:32 --> Router Class Initialized
INFO - 2023-06-27 08:25:32 --> Output Class Initialized
INFO - 2023-06-27 08:25:32 --> Security Class Initialized
DEBUG - 2023-06-27 08:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:25:32 --> Input Class Initialized
INFO - 2023-06-27 08:25:32 --> Language Class Initialized
INFO - 2023-06-27 08:25:32 --> Loader Class Initialized
INFO - 2023-06-27 08:25:32 --> Helper loaded: url_helper
INFO - 2023-06-27 08:25:32 --> Helper loaded: file_helper
INFO - 2023-06-27 08:25:32 --> Helper loaded: html_helper
INFO - 2023-06-27 08:25:32 --> Helper loaded: text_helper
INFO - 2023-06-27 08:25:32 --> Helper loaded: form_helper
INFO - 2023-06-27 08:25:32 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:25:32 --> Helper loaded: security_helper
INFO - 2023-06-27 08:25:32 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:25:32 --> Database Driver Class Initialized
INFO - 2023-06-27 08:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:25:32 --> Parser Class Initialized
INFO - 2023-06-27 08:25:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:25:32 --> Pagination Class Initialized
INFO - 2023-06-27 08:25:32 --> Form Validation Class Initialized
INFO - 2023-06-27 08:25:32 --> Controller Class Initialized
INFO - 2023-06-27 08:25:32 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:25:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:32 --> Model Class Initialized
INFO - 2023-06-27 08:25:32 --> Final output sent to browser
DEBUG - 2023-06-27 08:25:32 --> Total execution time: 0.0188
ERROR - 2023-06-27 08:25:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:25:51 --> Config Class Initialized
INFO - 2023-06-27 08:25:51 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:25:51 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:25:51 --> Utf8 Class Initialized
INFO - 2023-06-27 08:25:51 --> URI Class Initialized
INFO - 2023-06-27 08:25:51 --> Router Class Initialized
INFO - 2023-06-27 08:25:51 --> Output Class Initialized
INFO - 2023-06-27 08:25:51 --> Security Class Initialized
DEBUG - 2023-06-27 08:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:25:51 --> Input Class Initialized
INFO - 2023-06-27 08:25:51 --> Language Class Initialized
INFO - 2023-06-27 08:25:51 --> Loader Class Initialized
INFO - 2023-06-27 08:25:51 --> Helper loaded: url_helper
INFO - 2023-06-27 08:25:51 --> Helper loaded: file_helper
INFO - 2023-06-27 08:25:51 --> Helper loaded: html_helper
INFO - 2023-06-27 08:25:51 --> Helper loaded: text_helper
INFO - 2023-06-27 08:25:51 --> Helper loaded: form_helper
INFO - 2023-06-27 08:25:51 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:25:51 --> Helper loaded: security_helper
INFO - 2023-06-27 08:25:51 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:25:51 --> Database Driver Class Initialized
INFO - 2023-06-27 08:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:25:51 --> Parser Class Initialized
INFO - 2023-06-27 08:25:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:25:51 --> Pagination Class Initialized
INFO - 2023-06-27 08:25:51 --> Form Validation Class Initialized
INFO - 2023-06-27 08:25:51 --> Controller Class Initialized
INFO - 2023-06-27 08:25:51 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:25:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:51 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:51 --> Model Class Initialized
INFO - 2023-06-27 08:25:51 --> Final output sent to browser
DEBUG - 2023-06-27 08:25:51 --> Total execution time: 0.0515
ERROR - 2023-06-27 08:25:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:25:52 --> Config Class Initialized
INFO - 2023-06-27 08:25:52 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:25:52 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:25:52 --> Utf8 Class Initialized
INFO - 2023-06-27 08:25:52 --> URI Class Initialized
INFO - 2023-06-27 08:25:52 --> Router Class Initialized
INFO - 2023-06-27 08:25:52 --> Output Class Initialized
INFO - 2023-06-27 08:25:52 --> Security Class Initialized
DEBUG - 2023-06-27 08:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:25:52 --> Input Class Initialized
INFO - 2023-06-27 08:25:52 --> Language Class Initialized
INFO - 2023-06-27 08:25:52 --> Loader Class Initialized
INFO - 2023-06-27 08:25:52 --> Helper loaded: url_helper
INFO - 2023-06-27 08:25:52 --> Helper loaded: file_helper
INFO - 2023-06-27 08:25:52 --> Helper loaded: html_helper
INFO - 2023-06-27 08:25:52 --> Helper loaded: text_helper
INFO - 2023-06-27 08:25:52 --> Helper loaded: form_helper
INFO - 2023-06-27 08:25:52 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:25:52 --> Helper loaded: security_helper
INFO - 2023-06-27 08:25:52 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:25:52 --> Database Driver Class Initialized
INFO - 2023-06-27 08:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:25:52 --> Parser Class Initialized
INFO - 2023-06-27 08:25:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:25:52 --> Pagination Class Initialized
INFO - 2023-06-27 08:25:52 --> Form Validation Class Initialized
INFO - 2023-06-27 08:25:52 --> Controller Class Initialized
INFO - 2023-06-27 08:25:52 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:25:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:52 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:52 --> Model Class Initialized
INFO - 2023-06-27 08:25:52 --> Final output sent to browser
DEBUG - 2023-06-27 08:25:52 --> Total execution time: 0.0454
ERROR - 2023-06-27 08:25:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:25:56 --> Config Class Initialized
INFO - 2023-06-27 08:25:56 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:25:56 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:25:56 --> Utf8 Class Initialized
INFO - 2023-06-27 08:25:56 --> URI Class Initialized
INFO - 2023-06-27 08:25:56 --> Router Class Initialized
INFO - 2023-06-27 08:25:56 --> Output Class Initialized
INFO - 2023-06-27 08:25:56 --> Security Class Initialized
DEBUG - 2023-06-27 08:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:25:56 --> Input Class Initialized
INFO - 2023-06-27 08:25:56 --> Language Class Initialized
INFO - 2023-06-27 08:25:56 --> Loader Class Initialized
INFO - 2023-06-27 08:25:56 --> Helper loaded: url_helper
INFO - 2023-06-27 08:25:56 --> Helper loaded: file_helper
INFO - 2023-06-27 08:25:56 --> Helper loaded: html_helper
INFO - 2023-06-27 08:25:56 --> Helper loaded: text_helper
INFO - 2023-06-27 08:25:57 --> Helper loaded: form_helper
INFO - 2023-06-27 08:25:57 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:25:57 --> Helper loaded: security_helper
INFO - 2023-06-27 08:25:57 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:25:57 --> Database Driver Class Initialized
INFO - 2023-06-27 08:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:25:57 --> Parser Class Initialized
INFO - 2023-06-27 08:25:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:25:57 --> Pagination Class Initialized
INFO - 2023-06-27 08:25:57 --> Form Validation Class Initialized
INFO - 2023-06-27 08:25:57 --> Controller Class Initialized
INFO - 2023-06-27 08:25:57 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:25:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:57 --> Model Class Initialized
DEBUG - 2023-06-27 08:25:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:25:57 --> Model Class Initialized
INFO - 2023-06-27 08:25:57 --> Final output sent to browser
DEBUG - 2023-06-27 08:25:57 --> Total execution time: 0.0276
ERROR - 2023-06-27 08:26:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:26:03 --> Config Class Initialized
INFO - 2023-06-27 08:26:03 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:26:03 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:26:03 --> Utf8 Class Initialized
INFO - 2023-06-27 08:26:03 --> URI Class Initialized
INFO - 2023-06-27 08:26:03 --> Router Class Initialized
INFO - 2023-06-27 08:26:03 --> Output Class Initialized
INFO - 2023-06-27 08:26:03 --> Security Class Initialized
DEBUG - 2023-06-27 08:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:26:03 --> Input Class Initialized
INFO - 2023-06-27 08:26:03 --> Language Class Initialized
INFO - 2023-06-27 08:26:03 --> Loader Class Initialized
INFO - 2023-06-27 08:26:03 --> Helper loaded: url_helper
INFO - 2023-06-27 08:26:03 --> Helper loaded: file_helper
INFO - 2023-06-27 08:26:03 --> Helper loaded: html_helper
INFO - 2023-06-27 08:26:03 --> Helper loaded: text_helper
INFO - 2023-06-27 08:26:03 --> Helper loaded: form_helper
INFO - 2023-06-27 08:26:03 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:26:03 --> Helper loaded: security_helper
INFO - 2023-06-27 08:26:03 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:26:03 --> Database Driver Class Initialized
INFO - 2023-06-27 08:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:26:03 --> Parser Class Initialized
INFO - 2023-06-27 08:26:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:26:03 --> Pagination Class Initialized
INFO - 2023-06-27 08:26:03 --> Form Validation Class Initialized
INFO - 2023-06-27 08:26:03 --> Controller Class Initialized
INFO - 2023-06-27 08:26:03 --> Model Class Initialized
DEBUG - 2023-06-27 08:26:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:26:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:26:03 --> Model Class Initialized
INFO - 2023-06-27 08:26:03 --> Model Class Initialized
INFO - 2023-06-27 08:26:03 --> Final output sent to browser
DEBUG - 2023-06-27 08:26:03 --> Total execution time: 0.0177
ERROR - 2023-06-27 08:26:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:26:03 --> Config Class Initialized
INFO - 2023-06-27 08:26:03 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:26:03 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:26:03 --> Utf8 Class Initialized
INFO - 2023-06-27 08:26:03 --> URI Class Initialized
INFO - 2023-06-27 08:26:03 --> Router Class Initialized
INFO - 2023-06-27 08:26:03 --> Output Class Initialized
INFO - 2023-06-27 08:26:03 --> Security Class Initialized
DEBUG - 2023-06-27 08:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:26:03 --> Input Class Initialized
INFO - 2023-06-27 08:26:03 --> Language Class Initialized
INFO - 2023-06-27 08:26:03 --> Loader Class Initialized
INFO - 2023-06-27 08:26:03 --> Helper loaded: url_helper
INFO - 2023-06-27 08:26:03 --> Helper loaded: file_helper
INFO - 2023-06-27 08:26:03 --> Helper loaded: html_helper
INFO - 2023-06-27 08:26:03 --> Helper loaded: text_helper
INFO - 2023-06-27 08:26:03 --> Helper loaded: form_helper
INFO - 2023-06-27 08:26:03 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:26:03 --> Helper loaded: security_helper
INFO - 2023-06-27 08:26:03 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:26:03 --> Database Driver Class Initialized
INFO - 2023-06-27 08:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:26:03 --> Parser Class Initialized
INFO - 2023-06-27 08:26:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:26:03 --> Pagination Class Initialized
INFO - 2023-06-27 08:26:03 --> Form Validation Class Initialized
INFO - 2023-06-27 08:26:03 --> Controller Class Initialized
INFO - 2023-06-27 08:26:03 --> Model Class Initialized
DEBUG - 2023-06-27 08:26:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:26:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:26:03 --> Model Class Initialized
DEBUG - 2023-06-27 08:26:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:26:03 --> Model Class Initialized
INFO - 2023-06-27 08:26:03 --> Final output sent to browser
DEBUG - 2023-06-27 08:26:03 --> Total execution time: 0.0182
ERROR - 2023-06-27 08:26:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:26:06 --> Config Class Initialized
INFO - 2023-06-27 08:26:06 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:26:06 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:26:06 --> Utf8 Class Initialized
INFO - 2023-06-27 08:26:06 --> URI Class Initialized
INFO - 2023-06-27 08:26:06 --> Router Class Initialized
INFO - 2023-06-27 08:26:06 --> Output Class Initialized
INFO - 2023-06-27 08:26:06 --> Security Class Initialized
DEBUG - 2023-06-27 08:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:26:06 --> Input Class Initialized
INFO - 2023-06-27 08:26:06 --> Language Class Initialized
INFO - 2023-06-27 08:26:06 --> Loader Class Initialized
INFO - 2023-06-27 08:26:06 --> Helper loaded: url_helper
INFO - 2023-06-27 08:26:06 --> Helper loaded: file_helper
INFO - 2023-06-27 08:26:06 --> Helper loaded: html_helper
INFO - 2023-06-27 08:26:06 --> Helper loaded: text_helper
INFO - 2023-06-27 08:26:06 --> Helper loaded: form_helper
INFO - 2023-06-27 08:26:06 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:26:06 --> Helper loaded: security_helper
INFO - 2023-06-27 08:26:06 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:26:06 --> Database Driver Class Initialized
INFO - 2023-06-27 08:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:26:06 --> Parser Class Initialized
INFO - 2023-06-27 08:26:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:26:06 --> Pagination Class Initialized
INFO - 2023-06-27 08:26:06 --> Form Validation Class Initialized
INFO - 2023-06-27 08:26:06 --> Controller Class Initialized
INFO - 2023-06-27 08:26:06 --> Model Class Initialized
DEBUG - 2023-06-27 08:26:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:26:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:26:06 --> Model Class Initialized
INFO - 2023-06-27 08:26:06 --> Final output sent to browser
DEBUG - 2023-06-27 08:26:06 --> Total execution time: 0.0184
ERROR - 2023-06-27 08:27:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:27:06 --> Config Class Initialized
INFO - 2023-06-27 08:27:06 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:27:06 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:27:06 --> Utf8 Class Initialized
INFO - 2023-06-27 08:27:06 --> URI Class Initialized
INFO - 2023-06-27 08:27:06 --> Router Class Initialized
INFO - 2023-06-27 08:27:06 --> Output Class Initialized
INFO - 2023-06-27 08:27:06 --> Security Class Initialized
DEBUG - 2023-06-27 08:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:27:06 --> Input Class Initialized
INFO - 2023-06-27 08:27:06 --> Language Class Initialized
INFO - 2023-06-27 08:27:06 --> Loader Class Initialized
INFO - 2023-06-27 08:27:06 --> Helper loaded: url_helper
INFO - 2023-06-27 08:27:06 --> Helper loaded: file_helper
INFO - 2023-06-27 08:27:06 --> Helper loaded: html_helper
INFO - 2023-06-27 08:27:06 --> Helper loaded: text_helper
INFO - 2023-06-27 08:27:06 --> Helper loaded: form_helper
INFO - 2023-06-27 08:27:06 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:27:06 --> Helper loaded: security_helper
INFO - 2023-06-27 08:27:06 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:27:06 --> Database Driver Class Initialized
INFO - 2023-06-27 08:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:27:06 --> Parser Class Initialized
INFO - 2023-06-27 08:27:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:27:06 --> Pagination Class Initialized
INFO - 2023-06-27 08:27:06 --> Form Validation Class Initialized
INFO - 2023-06-27 08:27:06 --> Controller Class Initialized
INFO - 2023-06-27 08:27:06 --> Model Class Initialized
DEBUG - 2023-06-27 08:27:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:27:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:27:06 --> Model Class Initialized
DEBUG - 2023-06-27 08:27:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:27:06 --> Model Class Initialized
INFO - 2023-06-27 08:27:06 --> Email Class Initialized
DEBUG - 2023-06-27 08:27:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:27:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:27:06 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-06-27 08:27:06 --> Language file loaded: language/english/email_lang.php
INFO - 2023-06-27 08:27:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2023-06-27 08:27:06 --> Final output sent to browser
DEBUG - 2023-06-27 08:27:06 --> Total execution time: 0.5245
ERROR - 2023-06-27 08:27:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:27:10 --> Config Class Initialized
INFO - 2023-06-27 08:27:10 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:27:10 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:27:10 --> Utf8 Class Initialized
INFO - 2023-06-27 08:27:10 --> URI Class Initialized
INFO - 2023-06-27 08:27:10 --> Router Class Initialized
INFO - 2023-06-27 08:27:10 --> Output Class Initialized
INFO - 2023-06-27 08:27:10 --> Security Class Initialized
DEBUG - 2023-06-27 08:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:27:10 --> Input Class Initialized
INFO - 2023-06-27 08:27:10 --> Language Class Initialized
INFO - 2023-06-27 08:27:10 --> Loader Class Initialized
INFO - 2023-06-27 08:27:10 --> Helper loaded: url_helper
INFO - 2023-06-27 08:27:10 --> Helper loaded: file_helper
INFO - 2023-06-27 08:27:10 --> Helper loaded: html_helper
INFO - 2023-06-27 08:27:10 --> Helper loaded: text_helper
INFO - 2023-06-27 08:27:10 --> Helper loaded: form_helper
INFO - 2023-06-27 08:27:10 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:27:10 --> Helper loaded: security_helper
INFO - 2023-06-27 08:27:10 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:27:10 --> Database Driver Class Initialized
INFO - 2023-06-27 08:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:27:10 --> Parser Class Initialized
INFO - 2023-06-27 08:27:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:27:10 --> Pagination Class Initialized
INFO - 2023-06-27 08:27:10 --> Form Validation Class Initialized
INFO - 2023-06-27 08:27:10 --> Controller Class Initialized
INFO - 2023-06-27 08:27:10 --> Model Class Initialized
DEBUG - 2023-06-27 08:27:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:27:10 --> Model Class Initialized
DEBUG - 2023-06-27 08:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:27:10 --> Model Class Initialized
INFO - 2023-06-27 08:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-06-27 08:27:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:27:10 --> Model Class Initialized
INFO - 2023-06-27 08:27:10 --> Model Class Initialized
INFO - 2023-06-27 08:27:10 --> Model Class Initialized
INFO - 2023-06-27 08:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:27:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:27:10 --> Final output sent to browser
DEBUG - 2023-06-27 08:27:10 --> Total execution time: 0.1048
ERROR - 2023-06-27 08:27:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:27:40 --> Config Class Initialized
INFO - 2023-06-27 08:27:40 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:27:40 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:27:40 --> Utf8 Class Initialized
INFO - 2023-06-27 08:27:40 --> URI Class Initialized
INFO - 2023-06-27 08:27:40 --> Router Class Initialized
INFO - 2023-06-27 08:27:40 --> Output Class Initialized
INFO - 2023-06-27 08:27:40 --> Security Class Initialized
DEBUG - 2023-06-27 08:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:27:40 --> Input Class Initialized
INFO - 2023-06-27 08:27:40 --> Language Class Initialized
INFO - 2023-06-27 08:27:40 --> Loader Class Initialized
INFO - 2023-06-27 08:27:40 --> Helper loaded: url_helper
INFO - 2023-06-27 08:27:40 --> Helper loaded: file_helper
INFO - 2023-06-27 08:27:40 --> Helper loaded: html_helper
INFO - 2023-06-27 08:27:40 --> Helper loaded: text_helper
INFO - 2023-06-27 08:27:40 --> Helper loaded: form_helper
INFO - 2023-06-27 08:27:40 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:27:40 --> Helper loaded: security_helper
INFO - 2023-06-27 08:27:40 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:27:40 --> Database Driver Class Initialized
INFO - 2023-06-27 08:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:27:40 --> Parser Class Initialized
INFO - 2023-06-27 08:27:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:27:40 --> Pagination Class Initialized
INFO - 2023-06-27 08:27:40 --> Form Validation Class Initialized
INFO - 2023-06-27 08:27:40 --> Controller Class Initialized
INFO - 2023-06-27 08:27:40 --> Model Class Initialized
DEBUG - 2023-06-27 08:27:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:27:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:27:40 --> Model Class Initialized
DEBUG - 2023-06-27 08:27:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:27:40 --> Model Class Initialized
INFO - 2023-06-27 08:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-06-27 08:27:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:27:40 --> Model Class Initialized
INFO - 2023-06-27 08:27:40 --> Model Class Initialized
INFO - 2023-06-27 08:27:40 --> Model Class Initialized
INFO - 2023-06-27 08:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:27:40 --> Final output sent to browser
DEBUG - 2023-06-27 08:27:40 --> Total execution time: 0.1017
ERROR - 2023-06-27 08:27:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:27:42 --> Config Class Initialized
INFO - 2023-06-27 08:27:42 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:27:42 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:27:42 --> Utf8 Class Initialized
INFO - 2023-06-27 08:27:42 --> URI Class Initialized
DEBUG - 2023-06-27 08:27:42 --> No URI present. Default controller set.
INFO - 2023-06-27 08:27:42 --> Router Class Initialized
INFO - 2023-06-27 08:27:42 --> Output Class Initialized
INFO - 2023-06-27 08:27:42 --> Security Class Initialized
DEBUG - 2023-06-27 08:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:27:42 --> Input Class Initialized
INFO - 2023-06-27 08:27:42 --> Language Class Initialized
INFO - 2023-06-27 08:27:42 --> Loader Class Initialized
INFO - 2023-06-27 08:27:42 --> Helper loaded: url_helper
INFO - 2023-06-27 08:27:42 --> Helper loaded: file_helper
INFO - 2023-06-27 08:27:42 --> Helper loaded: html_helper
INFO - 2023-06-27 08:27:42 --> Helper loaded: text_helper
INFO - 2023-06-27 08:27:42 --> Helper loaded: form_helper
INFO - 2023-06-27 08:27:42 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:27:42 --> Helper loaded: security_helper
INFO - 2023-06-27 08:27:42 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:27:42 --> Database Driver Class Initialized
INFO - 2023-06-27 08:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:27:42 --> Parser Class Initialized
INFO - 2023-06-27 08:27:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:27:42 --> Pagination Class Initialized
INFO - 2023-06-27 08:27:42 --> Form Validation Class Initialized
INFO - 2023-06-27 08:27:42 --> Controller Class Initialized
INFO - 2023-06-27 08:27:42 --> Model Class Initialized
DEBUG - 2023-06-27 08:27:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-27 08:27:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:27:42 --> Config Class Initialized
INFO - 2023-06-27 08:27:42 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:27:42 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:27:42 --> Utf8 Class Initialized
INFO - 2023-06-27 08:27:42 --> URI Class Initialized
INFO - 2023-06-27 08:27:42 --> Router Class Initialized
INFO - 2023-06-27 08:27:42 --> Output Class Initialized
INFO - 2023-06-27 08:27:42 --> Security Class Initialized
DEBUG - 2023-06-27 08:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:27:42 --> Input Class Initialized
INFO - 2023-06-27 08:27:42 --> Language Class Initialized
INFO - 2023-06-27 08:27:42 --> Loader Class Initialized
INFO - 2023-06-27 08:27:42 --> Helper loaded: url_helper
INFO - 2023-06-27 08:27:42 --> Helper loaded: file_helper
INFO - 2023-06-27 08:27:42 --> Helper loaded: html_helper
INFO - 2023-06-27 08:27:42 --> Helper loaded: text_helper
INFO - 2023-06-27 08:27:42 --> Helper loaded: form_helper
INFO - 2023-06-27 08:27:42 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:27:42 --> Helper loaded: security_helper
INFO - 2023-06-27 08:27:42 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:27:42 --> Database Driver Class Initialized
INFO - 2023-06-27 08:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:27:42 --> Parser Class Initialized
INFO - 2023-06-27 08:27:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:27:42 --> Pagination Class Initialized
INFO - 2023-06-27 08:27:42 --> Form Validation Class Initialized
INFO - 2023-06-27 08:27:42 --> Controller Class Initialized
INFO - 2023-06-27 08:27:42 --> Model Class Initialized
DEBUG - 2023-06-27 08:27:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:27:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-27 08:27:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:27:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:27:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:27:42 --> Model Class Initialized
INFO - 2023-06-27 08:27:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:27:42 --> Final output sent to browser
DEBUG - 2023-06-27 08:27:42 --> Total execution time: 0.0289
ERROR - 2023-06-27 08:27:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:27:49 --> Config Class Initialized
INFO - 2023-06-27 08:27:49 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:27:49 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:27:49 --> Utf8 Class Initialized
INFO - 2023-06-27 08:27:49 --> URI Class Initialized
INFO - 2023-06-27 08:27:49 --> Router Class Initialized
INFO - 2023-06-27 08:27:49 --> Output Class Initialized
INFO - 2023-06-27 08:27:49 --> Security Class Initialized
DEBUG - 2023-06-27 08:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:27:49 --> Input Class Initialized
INFO - 2023-06-27 08:27:49 --> Language Class Initialized
INFO - 2023-06-27 08:27:49 --> Loader Class Initialized
INFO - 2023-06-27 08:27:49 --> Helper loaded: url_helper
INFO - 2023-06-27 08:27:49 --> Helper loaded: file_helper
INFO - 2023-06-27 08:27:49 --> Helper loaded: html_helper
INFO - 2023-06-27 08:27:49 --> Helper loaded: text_helper
INFO - 2023-06-27 08:27:49 --> Helper loaded: form_helper
INFO - 2023-06-27 08:27:49 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:27:49 --> Helper loaded: security_helper
INFO - 2023-06-27 08:27:49 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:27:49 --> Database Driver Class Initialized
INFO - 2023-06-27 08:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:27:49 --> Parser Class Initialized
INFO - 2023-06-27 08:27:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:27:49 --> Pagination Class Initialized
INFO - 2023-06-27 08:27:49 --> Form Validation Class Initialized
INFO - 2023-06-27 08:27:49 --> Controller Class Initialized
INFO - 2023-06-27 08:27:49 --> Model Class Initialized
DEBUG - 2023-06-27 08:27:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:27:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:27:49 --> Model Class Initialized
DEBUG - 2023-06-27 08:27:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:27:49 --> Model Class Initialized
INFO - 2023-06-27 08:27:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-27 08:27:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:27:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:27:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:27:49 --> Model Class Initialized
INFO - 2023-06-27 08:27:49 --> Model Class Initialized
INFO - 2023-06-27 08:27:49 --> Model Class Initialized
INFO - 2023-06-27 08:27:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:27:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:27:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:27:49 --> Final output sent to browser
DEBUG - 2023-06-27 08:27:49 --> Total execution time: 0.0716
ERROR - 2023-06-27 08:27:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:27:50 --> Config Class Initialized
INFO - 2023-06-27 08:27:50 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:27:50 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:27:50 --> Utf8 Class Initialized
INFO - 2023-06-27 08:27:50 --> URI Class Initialized
INFO - 2023-06-27 08:27:50 --> Router Class Initialized
INFO - 2023-06-27 08:27:50 --> Output Class Initialized
INFO - 2023-06-27 08:27:50 --> Security Class Initialized
DEBUG - 2023-06-27 08:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:27:50 --> Input Class Initialized
INFO - 2023-06-27 08:27:50 --> Language Class Initialized
INFO - 2023-06-27 08:27:50 --> Loader Class Initialized
INFO - 2023-06-27 08:27:50 --> Helper loaded: url_helper
INFO - 2023-06-27 08:27:50 --> Helper loaded: file_helper
INFO - 2023-06-27 08:27:50 --> Helper loaded: html_helper
INFO - 2023-06-27 08:27:50 --> Helper loaded: text_helper
INFO - 2023-06-27 08:27:50 --> Helper loaded: form_helper
INFO - 2023-06-27 08:27:50 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:27:50 --> Helper loaded: security_helper
INFO - 2023-06-27 08:27:50 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:27:50 --> Database Driver Class Initialized
INFO - 2023-06-27 08:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:27:50 --> Parser Class Initialized
INFO - 2023-06-27 08:27:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:27:50 --> Pagination Class Initialized
INFO - 2023-06-27 08:27:50 --> Form Validation Class Initialized
INFO - 2023-06-27 08:27:50 --> Controller Class Initialized
INFO - 2023-06-27 08:27:50 --> Model Class Initialized
DEBUG - 2023-06-27 08:27:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:27:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:27:50 --> Model Class Initialized
DEBUG - 2023-06-27 08:27:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:27:50 --> Model Class Initialized
INFO - 2023-06-27 08:27:50 --> Final output sent to browser
DEBUG - 2023-06-27 08:27:50 --> Total execution time: 0.0382
ERROR - 2023-06-27 08:27:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:27:56 --> Config Class Initialized
INFO - 2023-06-27 08:27:56 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:27:56 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:27:56 --> Utf8 Class Initialized
INFO - 2023-06-27 08:27:56 --> URI Class Initialized
INFO - 2023-06-27 08:27:56 --> Router Class Initialized
INFO - 2023-06-27 08:27:56 --> Output Class Initialized
INFO - 2023-06-27 08:27:56 --> Security Class Initialized
DEBUG - 2023-06-27 08:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:27:56 --> Input Class Initialized
INFO - 2023-06-27 08:27:56 --> Language Class Initialized
INFO - 2023-06-27 08:27:56 --> Loader Class Initialized
INFO - 2023-06-27 08:27:56 --> Helper loaded: url_helper
INFO - 2023-06-27 08:27:56 --> Helper loaded: file_helper
INFO - 2023-06-27 08:27:56 --> Helper loaded: html_helper
INFO - 2023-06-27 08:27:56 --> Helper loaded: text_helper
INFO - 2023-06-27 08:27:56 --> Helper loaded: form_helper
INFO - 2023-06-27 08:27:56 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:27:56 --> Helper loaded: security_helper
INFO - 2023-06-27 08:27:56 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:27:56 --> Database Driver Class Initialized
INFO - 2023-06-27 08:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:27:56 --> Parser Class Initialized
INFO - 2023-06-27 08:27:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:27:56 --> Pagination Class Initialized
INFO - 2023-06-27 08:27:56 --> Form Validation Class Initialized
INFO - 2023-06-27 08:27:56 --> Controller Class Initialized
INFO - 2023-06-27 08:27:56 --> Model Class Initialized
DEBUG - 2023-06-27 08:27:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:27:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:27:56 --> Model Class Initialized
DEBUG - 2023-06-27 08:27:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:27:56 --> Model Class Initialized
INFO - 2023-06-27 08:27:56 --> Final output sent to browser
DEBUG - 2023-06-27 08:27:56 --> Total execution time: 0.1287
ERROR - 2023-06-27 08:28:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:28:15 --> Config Class Initialized
INFO - 2023-06-27 08:28:15 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:28:15 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:28:15 --> Utf8 Class Initialized
INFO - 2023-06-27 08:28:15 --> URI Class Initialized
INFO - 2023-06-27 08:28:15 --> Router Class Initialized
INFO - 2023-06-27 08:28:15 --> Output Class Initialized
INFO - 2023-06-27 08:28:15 --> Security Class Initialized
DEBUG - 2023-06-27 08:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:28:15 --> Input Class Initialized
INFO - 2023-06-27 08:28:15 --> Language Class Initialized
INFO - 2023-06-27 08:28:15 --> Loader Class Initialized
INFO - 2023-06-27 08:28:15 --> Helper loaded: url_helper
INFO - 2023-06-27 08:28:15 --> Helper loaded: file_helper
INFO - 2023-06-27 08:28:15 --> Helper loaded: html_helper
INFO - 2023-06-27 08:28:15 --> Helper loaded: text_helper
INFO - 2023-06-27 08:28:15 --> Helper loaded: form_helper
INFO - 2023-06-27 08:28:15 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:28:15 --> Helper loaded: security_helper
INFO - 2023-06-27 08:28:15 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:28:15 --> Database Driver Class Initialized
INFO - 2023-06-27 08:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:28:15 --> Parser Class Initialized
INFO - 2023-06-27 08:28:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:28:15 --> Pagination Class Initialized
INFO - 2023-06-27 08:28:15 --> Form Validation Class Initialized
INFO - 2023-06-27 08:28:15 --> Controller Class Initialized
INFO - 2023-06-27 08:28:15 --> Model Class Initialized
DEBUG - 2023-06-27 08:28:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:28:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:28:15 --> Model Class Initialized
DEBUG - 2023-06-27 08:28:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:28:15 --> Model Class Initialized
DEBUG - 2023-06-27 08:28:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:28:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-06-27 08:28:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:28:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:28:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:28:15 --> Model Class Initialized
INFO - 2023-06-27 08:28:15 --> Model Class Initialized
INFO - 2023-06-27 08:28:15 --> Model Class Initialized
INFO - 2023-06-27 08:28:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:28:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:28:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:28:15 --> Final output sent to browser
DEBUG - 2023-06-27 08:28:15 --> Total execution time: 0.0844
ERROR - 2023-06-27 08:28:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:28:22 --> Config Class Initialized
INFO - 2023-06-27 08:28:22 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:28:22 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:28:22 --> Utf8 Class Initialized
INFO - 2023-06-27 08:28:22 --> URI Class Initialized
INFO - 2023-06-27 08:28:22 --> Router Class Initialized
INFO - 2023-06-27 08:28:22 --> Output Class Initialized
INFO - 2023-06-27 08:28:22 --> Security Class Initialized
DEBUG - 2023-06-27 08:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:28:22 --> Input Class Initialized
INFO - 2023-06-27 08:28:22 --> Language Class Initialized
INFO - 2023-06-27 08:28:22 --> Loader Class Initialized
INFO - 2023-06-27 08:28:22 --> Helper loaded: url_helper
INFO - 2023-06-27 08:28:22 --> Helper loaded: file_helper
INFO - 2023-06-27 08:28:22 --> Helper loaded: html_helper
INFO - 2023-06-27 08:28:22 --> Helper loaded: text_helper
INFO - 2023-06-27 08:28:22 --> Helper loaded: form_helper
INFO - 2023-06-27 08:28:22 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:28:22 --> Helper loaded: security_helper
INFO - 2023-06-27 08:28:22 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:28:22 --> Database Driver Class Initialized
INFO - 2023-06-27 08:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:28:22 --> Parser Class Initialized
INFO - 2023-06-27 08:28:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:28:22 --> Pagination Class Initialized
INFO - 2023-06-27 08:28:22 --> Form Validation Class Initialized
INFO - 2023-06-27 08:28:22 --> Controller Class Initialized
INFO - 2023-06-27 08:28:22 --> Model Class Initialized
DEBUG - 2023-06-27 08:28:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:28:22 --> Model Class Initialized
INFO - 2023-06-27 08:28:22 --> Final output sent to browser
DEBUG - 2023-06-27 08:28:22 --> Total execution time: 0.0176
ERROR - 2023-06-27 08:28:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:28:23 --> Config Class Initialized
INFO - 2023-06-27 08:28:23 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:28:23 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:28:23 --> Utf8 Class Initialized
INFO - 2023-06-27 08:28:23 --> URI Class Initialized
INFO - 2023-06-27 08:28:23 --> Router Class Initialized
INFO - 2023-06-27 08:28:23 --> Output Class Initialized
INFO - 2023-06-27 08:28:23 --> Security Class Initialized
DEBUG - 2023-06-27 08:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:28:23 --> Input Class Initialized
INFO - 2023-06-27 08:28:23 --> Language Class Initialized
INFO - 2023-06-27 08:28:23 --> Loader Class Initialized
INFO - 2023-06-27 08:28:23 --> Helper loaded: url_helper
INFO - 2023-06-27 08:28:23 --> Helper loaded: file_helper
INFO - 2023-06-27 08:28:23 --> Helper loaded: html_helper
INFO - 2023-06-27 08:28:23 --> Helper loaded: text_helper
INFO - 2023-06-27 08:28:23 --> Helper loaded: form_helper
INFO - 2023-06-27 08:28:23 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:28:23 --> Helper loaded: security_helper
INFO - 2023-06-27 08:28:23 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:28:23 --> Database Driver Class Initialized
INFO - 2023-06-27 08:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:28:23 --> Parser Class Initialized
INFO - 2023-06-27 08:28:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:28:23 --> Pagination Class Initialized
INFO - 2023-06-27 08:28:23 --> Form Validation Class Initialized
INFO - 2023-06-27 08:28:23 --> Controller Class Initialized
INFO - 2023-06-27 08:28:23 --> Model Class Initialized
DEBUG - 2023-06-27 08:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-27 08:28:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:28:23 --> Model Class Initialized
INFO - 2023-06-27 08:28:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:28:23 --> Final output sent to browser
DEBUG - 2023-06-27 08:28:23 --> Total execution time: 0.0333
ERROR - 2023-06-27 08:28:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:28:26 --> Config Class Initialized
INFO - 2023-06-27 08:28:26 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:28:26 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:28:26 --> Utf8 Class Initialized
INFO - 2023-06-27 08:28:26 --> URI Class Initialized
INFO - 2023-06-27 08:28:26 --> Router Class Initialized
INFO - 2023-06-27 08:28:26 --> Output Class Initialized
INFO - 2023-06-27 08:28:26 --> Security Class Initialized
DEBUG - 2023-06-27 08:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:28:26 --> Input Class Initialized
INFO - 2023-06-27 08:28:26 --> Language Class Initialized
INFO - 2023-06-27 08:28:26 --> Loader Class Initialized
INFO - 2023-06-27 08:28:26 --> Helper loaded: url_helper
INFO - 2023-06-27 08:28:26 --> Helper loaded: file_helper
INFO - 2023-06-27 08:28:26 --> Helper loaded: html_helper
INFO - 2023-06-27 08:28:26 --> Helper loaded: text_helper
INFO - 2023-06-27 08:28:26 --> Helper loaded: form_helper
INFO - 2023-06-27 08:28:26 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:28:26 --> Helper loaded: security_helper
INFO - 2023-06-27 08:28:26 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:28:26 --> Database Driver Class Initialized
INFO - 2023-06-27 08:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:28:26 --> Parser Class Initialized
INFO - 2023-06-27 08:28:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:28:26 --> Pagination Class Initialized
INFO - 2023-06-27 08:28:26 --> Form Validation Class Initialized
INFO - 2023-06-27 08:28:26 --> Controller Class Initialized
INFO - 2023-06-27 08:28:26 --> Model Class Initialized
DEBUG - 2023-06-27 08:28:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:28:26 --> Model Class Initialized
INFO - 2023-06-27 08:28:26 --> Final output sent to browser
DEBUG - 2023-06-27 08:28:26 --> Total execution time: 0.0172
ERROR - 2023-06-27 08:28:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:28:26 --> Config Class Initialized
INFO - 2023-06-27 08:28:26 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:28:26 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:28:26 --> Utf8 Class Initialized
INFO - 2023-06-27 08:28:26 --> URI Class Initialized
INFO - 2023-06-27 08:28:26 --> Router Class Initialized
INFO - 2023-06-27 08:28:26 --> Output Class Initialized
INFO - 2023-06-27 08:28:26 --> Security Class Initialized
DEBUG - 2023-06-27 08:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:28:26 --> Input Class Initialized
INFO - 2023-06-27 08:28:26 --> Language Class Initialized
INFO - 2023-06-27 08:28:26 --> Loader Class Initialized
INFO - 2023-06-27 08:28:26 --> Helper loaded: url_helper
INFO - 2023-06-27 08:28:26 --> Helper loaded: file_helper
INFO - 2023-06-27 08:28:26 --> Helper loaded: html_helper
INFO - 2023-06-27 08:28:26 --> Helper loaded: text_helper
INFO - 2023-06-27 08:28:26 --> Helper loaded: form_helper
INFO - 2023-06-27 08:28:26 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:28:26 --> Helper loaded: security_helper
INFO - 2023-06-27 08:28:26 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:28:26 --> Database Driver Class Initialized
INFO - 2023-06-27 08:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:28:26 --> Parser Class Initialized
INFO - 2023-06-27 08:28:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:28:26 --> Pagination Class Initialized
INFO - 2023-06-27 08:28:26 --> Form Validation Class Initialized
INFO - 2023-06-27 08:28:26 --> Controller Class Initialized
INFO - 2023-06-27 08:28:26 --> Model Class Initialized
DEBUG - 2023-06-27 08:28:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:28:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-27 08:28:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:28:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:28:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:28:26 --> Model Class Initialized
INFO - 2023-06-27 08:28:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:28:26 --> Final output sent to browser
DEBUG - 2023-06-27 08:28:26 --> Total execution time: 0.0297
ERROR - 2023-06-27 08:28:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:28:27 --> Config Class Initialized
INFO - 2023-06-27 08:28:27 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:28:27 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:28:27 --> Utf8 Class Initialized
INFO - 2023-06-27 08:28:27 --> URI Class Initialized
DEBUG - 2023-06-27 08:28:27 --> No URI present. Default controller set.
INFO - 2023-06-27 08:28:27 --> Router Class Initialized
INFO - 2023-06-27 08:28:27 --> Output Class Initialized
INFO - 2023-06-27 08:28:27 --> Security Class Initialized
DEBUG - 2023-06-27 08:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:28:27 --> Input Class Initialized
INFO - 2023-06-27 08:28:27 --> Language Class Initialized
INFO - 2023-06-27 08:28:27 --> Loader Class Initialized
INFO - 2023-06-27 08:28:27 --> Helper loaded: url_helper
INFO - 2023-06-27 08:28:27 --> Helper loaded: file_helper
INFO - 2023-06-27 08:28:27 --> Helper loaded: html_helper
INFO - 2023-06-27 08:28:27 --> Helper loaded: text_helper
INFO - 2023-06-27 08:28:27 --> Helper loaded: form_helper
INFO - 2023-06-27 08:28:27 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:28:27 --> Helper loaded: security_helper
INFO - 2023-06-27 08:28:27 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:28:27 --> Database Driver Class Initialized
INFO - 2023-06-27 08:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:28:27 --> Parser Class Initialized
INFO - 2023-06-27 08:28:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:28:27 --> Pagination Class Initialized
INFO - 2023-06-27 08:28:27 --> Form Validation Class Initialized
INFO - 2023-06-27 08:28:27 --> Controller Class Initialized
INFO - 2023-06-27 08:28:27 --> Model Class Initialized
DEBUG - 2023-06-27 08:28:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:28:27 --> Model Class Initialized
DEBUG - 2023-06-27 08:28:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:28:27 --> Model Class Initialized
INFO - 2023-06-27 08:28:27 --> Model Class Initialized
INFO - 2023-06-27 08:28:27 --> Model Class Initialized
INFO - 2023-06-27 08:28:27 --> Model Class Initialized
DEBUG - 2023-06-27 08:28:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:28:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:28:27 --> Model Class Initialized
INFO - 2023-06-27 08:28:27 --> Model Class Initialized
INFO - 2023-06-27 08:28:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 08:28:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:28:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:28:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:28:27 --> Model Class Initialized
INFO - 2023-06-27 08:28:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:28:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:28:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:28:27 --> Final output sent to browser
DEBUG - 2023-06-27 08:28:27 --> Total execution time: 0.0873
ERROR - 2023-06-27 08:28:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:28:37 --> Config Class Initialized
INFO - 2023-06-27 08:28:37 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:28:37 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:28:37 --> Utf8 Class Initialized
INFO - 2023-06-27 08:28:37 --> URI Class Initialized
INFO - 2023-06-27 08:28:37 --> Router Class Initialized
INFO - 2023-06-27 08:28:37 --> Output Class Initialized
INFO - 2023-06-27 08:28:37 --> Security Class Initialized
DEBUG - 2023-06-27 08:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:28:37 --> Input Class Initialized
INFO - 2023-06-27 08:28:37 --> Language Class Initialized
INFO - 2023-06-27 08:28:37 --> Loader Class Initialized
INFO - 2023-06-27 08:28:37 --> Helper loaded: url_helper
INFO - 2023-06-27 08:28:38 --> Helper loaded: file_helper
INFO - 2023-06-27 08:28:38 --> Helper loaded: html_helper
INFO - 2023-06-27 08:28:38 --> Helper loaded: text_helper
INFO - 2023-06-27 08:28:38 --> Helper loaded: form_helper
INFO - 2023-06-27 08:28:38 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:28:38 --> Helper loaded: security_helper
INFO - 2023-06-27 08:28:38 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:28:38 --> Database Driver Class Initialized
INFO - 2023-06-27 08:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:28:38 --> Parser Class Initialized
INFO - 2023-06-27 08:28:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:28:38 --> Pagination Class Initialized
INFO - 2023-06-27 08:28:38 --> Form Validation Class Initialized
INFO - 2023-06-27 08:28:38 --> Controller Class Initialized
INFO - 2023-06-27 08:28:38 --> Model Class Initialized
DEBUG - 2023-06-27 08:28:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:28:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:28:38 --> Model Class Initialized
DEBUG - 2023-06-27 08:28:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:28:38 --> Model Class Initialized
INFO - 2023-06-27 08:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-27 08:28:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:28:38 --> Model Class Initialized
INFO - 2023-06-27 08:28:38 --> Model Class Initialized
INFO - 2023-06-27 08:28:38 --> Model Class Initialized
INFO - 2023-06-27 08:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:28:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:28:38 --> Final output sent to browser
DEBUG - 2023-06-27 08:28:38 --> Total execution time: 0.0776
ERROR - 2023-06-27 08:28:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:28:38 --> Config Class Initialized
INFO - 2023-06-27 08:28:38 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:28:38 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:28:38 --> Utf8 Class Initialized
INFO - 2023-06-27 08:28:38 --> URI Class Initialized
INFO - 2023-06-27 08:28:38 --> Router Class Initialized
INFO - 2023-06-27 08:28:38 --> Output Class Initialized
INFO - 2023-06-27 08:28:38 --> Security Class Initialized
DEBUG - 2023-06-27 08:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:28:38 --> Input Class Initialized
INFO - 2023-06-27 08:28:38 --> Language Class Initialized
INFO - 2023-06-27 08:28:38 --> Loader Class Initialized
INFO - 2023-06-27 08:28:38 --> Helper loaded: url_helper
INFO - 2023-06-27 08:28:38 --> Helper loaded: file_helper
INFO - 2023-06-27 08:28:38 --> Helper loaded: html_helper
INFO - 2023-06-27 08:28:38 --> Helper loaded: text_helper
INFO - 2023-06-27 08:28:38 --> Helper loaded: form_helper
INFO - 2023-06-27 08:28:38 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:28:38 --> Helper loaded: security_helper
INFO - 2023-06-27 08:28:38 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:28:38 --> Database Driver Class Initialized
INFO - 2023-06-27 08:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:28:38 --> Parser Class Initialized
INFO - 2023-06-27 08:28:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:28:38 --> Pagination Class Initialized
INFO - 2023-06-27 08:28:38 --> Form Validation Class Initialized
INFO - 2023-06-27 08:28:38 --> Controller Class Initialized
INFO - 2023-06-27 08:28:38 --> Model Class Initialized
DEBUG - 2023-06-27 08:28:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:28:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:28:38 --> Model Class Initialized
DEBUG - 2023-06-27 08:28:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:28:38 --> Model Class Initialized
INFO - 2023-06-27 08:28:38 --> Final output sent to browser
DEBUG - 2023-06-27 08:28:38 --> Total execution time: 0.0405
ERROR - 2023-06-27 08:28:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:28:48 --> Config Class Initialized
INFO - 2023-06-27 08:28:48 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:28:48 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:28:48 --> Utf8 Class Initialized
INFO - 2023-06-27 08:28:48 --> URI Class Initialized
DEBUG - 2023-06-27 08:28:48 --> No URI present. Default controller set.
INFO - 2023-06-27 08:28:48 --> Router Class Initialized
INFO - 2023-06-27 08:28:48 --> Output Class Initialized
INFO - 2023-06-27 08:28:48 --> Security Class Initialized
DEBUG - 2023-06-27 08:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:28:48 --> Input Class Initialized
INFO - 2023-06-27 08:28:48 --> Language Class Initialized
INFO - 2023-06-27 08:28:48 --> Loader Class Initialized
INFO - 2023-06-27 08:28:48 --> Helper loaded: url_helper
INFO - 2023-06-27 08:28:48 --> Helper loaded: file_helper
INFO - 2023-06-27 08:28:48 --> Helper loaded: html_helper
INFO - 2023-06-27 08:28:48 --> Helper loaded: text_helper
INFO - 2023-06-27 08:28:48 --> Helper loaded: form_helper
INFO - 2023-06-27 08:28:48 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:28:48 --> Helper loaded: security_helper
INFO - 2023-06-27 08:28:48 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:28:48 --> Database Driver Class Initialized
INFO - 2023-06-27 08:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:28:48 --> Parser Class Initialized
INFO - 2023-06-27 08:28:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:28:48 --> Pagination Class Initialized
INFO - 2023-06-27 08:28:48 --> Form Validation Class Initialized
INFO - 2023-06-27 08:28:48 --> Controller Class Initialized
INFO - 2023-06-27 08:28:48 --> Model Class Initialized
DEBUG - 2023-06-27 08:28:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:28:48 --> Model Class Initialized
DEBUG - 2023-06-27 08:28:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:28:48 --> Model Class Initialized
INFO - 2023-06-27 08:28:48 --> Model Class Initialized
INFO - 2023-06-27 08:28:48 --> Model Class Initialized
INFO - 2023-06-27 08:28:48 --> Model Class Initialized
DEBUG - 2023-06-27 08:28:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:28:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:28:48 --> Model Class Initialized
INFO - 2023-06-27 08:28:48 --> Model Class Initialized
INFO - 2023-06-27 08:28:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 08:28:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:28:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:28:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:28:48 --> Model Class Initialized
INFO - 2023-06-27 08:28:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:28:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:28:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:28:48 --> Final output sent to browser
DEBUG - 2023-06-27 08:28:48 --> Total execution time: 0.1841
ERROR - 2023-06-27 08:28:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:28:53 --> Config Class Initialized
INFO - 2023-06-27 08:28:53 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:28:53 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:28:53 --> Utf8 Class Initialized
INFO - 2023-06-27 08:28:53 --> URI Class Initialized
INFO - 2023-06-27 08:28:53 --> Router Class Initialized
INFO - 2023-06-27 08:28:53 --> Output Class Initialized
INFO - 2023-06-27 08:28:53 --> Security Class Initialized
DEBUG - 2023-06-27 08:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:28:53 --> Input Class Initialized
INFO - 2023-06-27 08:28:53 --> Language Class Initialized
INFO - 2023-06-27 08:28:53 --> Loader Class Initialized
INFO - 2023-06-27 08:28:53 --> Helper loaded: url_helper
INFO - 2023-06-27 08:28:53 --> Helper loaded: file_helper
INFO - 2023-06-27 08:28:53 --> Helper loaded: html_helper
INFO - 2023-06-27 08:28:53 --> Helper loaded: text_helper
INFO - 2023-06-27 08:28:53 --> Helper loaded: form_helper
INFO - 2023-06-27 08:28:53 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:28:53 --> Helper loaded: security_helper
INFO - 2023-06-27 08:28:53 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:28:53 --> Database Driver Class Initialized
INFO - 2023-06-27 08:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:28:53 --> Parser Class Initialized
INFO - 2023-06-27 08:28:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:28:53 --> Pagination Class Initialized
INFO - 2023-06-27 08:28:53 --> Form Validation Class Initialized
INFO - 2023-06-27 08:28:53 --> Controller Class Initialized
INFO - 2023-06-27 08:28:53 --> Model Class Initialized
DEBUG - 2023-06-27 08:28:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:28:53 --> Model Class Initialized
INFO - 2023-06-27 08:28:53 --> Final output sent to browser
DEBUG - 2023-06-27 08:28:53 --> Total execution time: 0.0189
ERROR - 2023-06-27 08:28:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:28:53 --> Config Class Initialized
INFO - 2023-06-27 08:28:53 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:28:53 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:28:53 --> Utf8 Class Initialized
INFO - 2023-06-27 08:28:53 --> URI Class Initialized
INFO - 2023-06-27 08:28:53 --> Router Class Initialized
INFO - 2023-06-27 08:28:53 --> Output Class Initialized
INFO - 2023-06-27 08:28:53 --> Security Class Initialized
DEBUG - 2023-06-27 08:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:28:53 --> Input Class Initialized
INFO - 2023-06-27 08:28:53 --> Language Class Initialized
INFO - 2023-06-27 08:28:53 --> Loader Class Initialized
INFO - 2023-06-27 08:28:53 --> Helper loaded: url_helper
INFO - 2023-06-27 08:28:53 --> Helper loaded: file_helper
INFO - 2023-06-27 08:28:53 --> Helper loaded: html_helper
INFO - 2023-06-27 08:28:53 --> Helper loaded: text_helper
INFO - 2023-06-27 08:28:53 --> Helper loaded: form_helper
INFO - 2023-06-27 08:28:53 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:28:53 --> Helper loaded: security_helper
INFO - 2023-06-27 08:28:53 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:28:53 --> Database Driver Class Initialized
INFO - 2023-06-27 08:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:28:53 --> Parser Class Initialized
INFO - 2023-06-27 08:28:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:28:53 --> Pagination Class Initialized
INFO - 2023-06-27 08:28:53 --> Form Validation Class Initialized
INFO - 2023-06-27 08:28:53 --> Controller Class Initialized
INFO - 2023-06-27 08:28:53 --> Model Class Initialized
DEBUG - 2023-06-27 08:28:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:28:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-27 08:28:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:28:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:28:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:28:53 --> Model Class Initialized
INFO - 2023-06-27 08:28:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:28:53 --> Final output sent to browser
DEBUG - 2023-06-27 08:28:53 --> Total execution time: 0.0266
ERROR - 2023-06-27 08:29:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:29:11 --> Config Class Initialized
INFO - 2023-06-27 08:29:11 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:29:11 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:29:11 --> Utf8 Class Initialized
INFO - 2023-06-27 08:29:11 --> URI Class Initialized
INFO - 2023-06-27 08:29:11 --> Router Class Initialized
INFO - 2023-06-27 08:29:11 --> Output Class Initialized
INFO - 2023-06-27 08:29:11 --> Security Class Initialized
DEBUG - 2023-06-27 08:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:29:11 --> Input Class Initialized
INFO - 2023-06-27 08:29:11 --> Language Class Initialized
INFO - 2023-06-27 08:29:11 --> Loader Class Initialized
INFO - 2023-06-27 08:29:11 --> Helper loaded: url_helper
INFO - 2023-06-27 08:29:11 --> Helper loaded: file_helper
INFO - 2023-06-27 08:29:11 --> Helper loaded: html_helper
INFO - 2023-06-27 08:29:11 --> Helper loaded: text_helper
INFO - 2023-06-27 08:29:11 --> Helper loaded: form_helper
INFO - 2023-06-27 08:29:11 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:29:11 --> Helper loaded: security_helper
INFO - 2023-06-27 08:29:11 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:29:11 --> Database Driver Class Initialized
INFO - 2023-06-27 08:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:29:11 --> Parser Class Initialized
INFO - 2023-06-27 08:29:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:29:11 --> Pagination Class Initialized
INFO - 2023-06-27 08:29:11 --> Form Validation Class Initialized
INFO - 2023-06-27 08:29:11 --> Controller Class Initialized
DEBUG - 2023-06-27 08:29:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:29:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:29:11 --> Model Class Initialized
DEBUG - 2023-06-27 08:29:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:29:11 --> Model Class Initialized
DEBUG - 2023-06-27 08:29:11 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:29:11 --> Model Class Initialized
INFO - 2023-06-27 08:29:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-06-27 08:29:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:29:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:29:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:29:11 --> Model Class Initialized
INFO - 2023-06-27 08:29:11 --> Model Class Initialized
INFO - 2023-06-27 08:29:11 --> Model Class Initialized
INFO - 2023-06-27 08:29:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:29:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:29:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:29:12 --> Final output sent to browser
DEBUG - 2023-06-27 08:29:12 --> Total execution time: 0.1476
ERROR - 2023-06-27 08:29:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:29:13 --> Config Class Initialized
INFO - 2023-06-27 08:29:13 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:29:13 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:29:13 --> Utf8 Class Initialized
INFO - 2023-06-27 08:29:13 --> URI Class Initialized
INFO - 2023-06-27 08:29:13 --> Router Class Initialized
INFO - 2023-06-27 08:29:13 --> Output Class Initialized
INFO - 2023-06-27 08:29:13 --> Security Class Initialized
DEBUG - 2023-06-27 08:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:29:13 --> Input Class Initialized
INFO - 2023-06-27 08:29:13 --> Language Class Initialized
INFO - 2023-06-27 08:29:13 --> Loader Class Initialized
INFO - 2023-06-27 08:29:13 --> Helper loaded: url_helper
INFO - 2023-06-27 08:29:13 --> Helper loaded: file_helper
INFO - 2023-06-27 08:29:13 --> Helper loaded: html_helper
INFO - 2023-06-27 08:29:13 --> Helper loaded: text_helper
INFO - 2023-06-27 08:29:13 --> Helper loaded: form_helper
INFO - 2023-06-27 08:29:13 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:29:13 --> Helper loaded: security_helper
INFO - 2023-06-27 08:29:13 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:29:13 --> Database Driver Class Initialized
INFO - 2023-06-27 08:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:29:13 --> Parser Class Initialized
INFO - 2023-06-27 08:29:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:29:13 --> Pagination Class Initialized
INFO - 2023-06-27 08:29:13 --> Form Validation Class Initialized
INFO - 2023-06-27 08:29:13 --> Controller Class Initialized
DEBUG - 2023-06-27 08:29:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:29:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:29:13 --> Model Class Initialized
DEBUG - 2023-06-27 08:29:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:29:13 --> Model Class Initialized
INFO - 2023-06-27 08:29:13 --> Final output sent to browser
DEBUG - 2023-06-27 08:29:13 --> Total execution time: 0.0309
ERROR - 2023-06-27 08:29:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:29:19 --> Config Class Initialized
INFO - 2023-06-27 08:29:19 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:29:19 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:29:19 --> Utf8 Class Initialized
INFO - 2023-06-27 08:29:19 --> URI Class Initialized
INFO - 2023-06-27 08:29:19 --> Router Class Initialized
INFO - 2023-06-27 08:29:19 --> Output Class Initialized
INFO - 2023-06-27 08:29:19 --> Security Class Initialized
DEBUG - 2023-06-27 08:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:29:19 --> Input Class Initialized
INFO - 2023-06-27 08:29:19 --> Language Class Initialized
INFO - 2023-06-27 08:29:19 --> Loader Class Initialized
INFO - 2023-06-27 08:29:19 --> Helper loaded: url_helper
INFO - 2023-06-27 08:29:19 --> Helper loaded: file_helper
INFO - 2023-06-27 08:29:19 --> Helper loaded: html_helper
INFO - 2023-06-27 08:29:19 --> Helper loaded: text_helper
INFO - 2023-06-27 08:29:19 --> Helper loaded: form_helper
INFO - 2023-06-27 08:29:19 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:29:19 --> Helper loaded: security_helper
INFO - 2023-06-27 08:29:19 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:29:19 --> Database Driver Class Initialized
INFO - 2023-06-27 08:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:29:19 --> Parser Class Initialized
INFO - 2023-06-27 08:29:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:29:19 --> Pagination Class Initialized
INFO - 2023-06-27 08:29:19 --> Form Validation Class Initialized
INFO - 2023-06-27 08:29:19 --> Controller Class Initialized
DEBUG - 2023-06-27 08:29:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:29:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:29:19 --> Model Class Initialized
DEBUG - 2023-06-27 08:29:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:29:19 --> Model Class Initialized
INFO - 2023-06-27 08:29:19 --> Final output sent to browser
DEBUG - 2023-06-27 08:29:19 --> Total execution time: 0.1189
ERROR - 2023-06-27 08:29:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:29:37 --> Config Class Initialized
INFO - 2023-06-27 08:29:37 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:29:37 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:29:37 --> Utf8 Class Initialized
INFO - 2023-06-27 08:29:37 --> URI Class Initialized
INFO - 2023-06-27 08:29:37 --> Router Class Initialized
INFO - 2023-06-27 08:29:37 --> Output Class Initialized
INFO - 2023-06-27 08:29:37 --> Security Class Initialized
DEBUG - 2023-06-27 08:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:29:37 --> Input Class Initialized
INFO - 2023-06-27 08:29:37 --> Language Class Initialized
INFO - 2023-06-27 08:29:37 --> Loader Class Initialized
INFO - 2023-06-27 08:29:37 --> Helper loaded: url_helper
INFO - 2023-06-27 08:29:37 --> Helper loaded: file_helper
INFO - 2023-06-27 08:29:37 --> Helper loaded: html_helper
INFO - 2023-06-27 08:29:37 --> Helper loaded: text_helper
INFO - 2023-06-27 08:29:37 --> Helper loaded: form_helper
INFO - 2023-06-27 08:29:37 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:29:37 --> Helper loaded: security_helper
INFO - 2023-06-27 08:29:37 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:29:37 --> Database Driver Class Initialized
INFO - 2023-06-27 08:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:29:37 --> Parser Class Initialized
INFO - 2023-06-27 08:29:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:29:37 --> Pagination Class Initialized
INFO - 2023-06-27 08:29:37 --> Form Validation Class Initialized
INFO - 2023-06-27 08:29:37 --> Controller Class Initialized
INFO - 2023-06-27 08:29:37 --> Model Class Initialized
DEBUG - 2023-06-27 08:29:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:29:37 --> Model Class Initialized
INFO - 2023-06-27 08:29:37 --> Final output sent to browser
DEBUG - 2023-06-27 08:29:37 --> Total execution time: 0.0189
ERROR - 2023-06-27 08:29:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:29:37 --> Config Class Initialized
INFO - 2023-06-27 08:29:37 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:29:37 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:29:37 --> Utf8 Class Initialized
INFO - 2023-06-27 08:29:37 --> URI Class Initialized
DEBUG - 2023-06-27 08:29:37 --> No URI present. Default controller set.
INFO - 2023-06-27 08:29:37 --> Router Class Initialized
INFO - 2023-06-27 08:29:37 --> Output Class Initialized
INFO - 2023-06-27 08:29:37 --> Security Class Initialized
DEBUG - 2023-06-27 08:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:29:37 --> Input Class Initialized
INFO - 2023-06-27 08:29:37 --> Language Class Initialized
INFO - 2023-06-27 08:29:37 --> Loader Class Initialized
INFO - 2023-06-27 08:29:37 --> Helper loaded: url_helper
INFO - 2023-06-27 08:29:37 --> Helper loaded: file_helper
INFO - 2023-06-27 08:29:37 --> Helper loaded: html_helper
INFO - 2023-06-27 08:29:37 --> Helper loaded: text_helper
INFO - 2023-06-27 08:29:37 --> Helper loaded: form_helper
INFO - 2023-06-27 08:29:37 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:29:37 --> Helper loaded: security_helper
INFO - 2023-06-27 08:29:37 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:29:37 --> Database Driver Class Initialized
INFO - 2023-06-27 08:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:29:37 --> Parser Class Initialized
INFO - 2023-06-27 08:29:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:29:37 --> Pagination Class Initialized
INFO - 2023-06-27 08:29:37 --> Form Validation Class Initialized
INFO - 2023-06-27 08:29:37 --> Controller Class Initialized
INFO - 2023-06-27 08:29:37 --> Model Class Initialized
DEBUG - 2023-06-27 08:29:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:29:37 --> Model Class Initialized
DEBUG - 2023-06-27 08:29:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:29:37 --> Model Class Initialized
INFO - 2023-06-27 08:29:37 --> Model Class Initialized
INFO - 2023-06-27 08:29:37 --> Model Class Initialized
INFO - 2023-06-27 08:29:37 --> Model Class Initialized
DEBUG - 2023-06-27 08:29:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:29:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:29:37 --> Model Class Initialized
INFO - 2023-06-27 08:29:37 --> Model Class Initialized
INFO - 2023-06-27 08:29:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 08:29:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:29:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:29:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:29:37 --> Model Class Initialized
INFO - 2023-06-27 08:29:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:29:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:29:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:29:37 --> Final output sent to browser
DEBUG - 2023-06-27 08:29:37 --> Total execution time: 0.0648
ERROR - 2023-06-27 08:30:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:30:17 --> Config Class Initialized
INFO - 2023-06-27 08:30:17 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:30:17 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:30:17 --> Utf8 Class Initialized
INFO - 2023-06-27 08:30:17 --> URI Class Initialized
INFO - 2023-06-27 08:30:17 --> Router Class Initialized
INFO - 2023-06-27 08:30:17 --> Output Class Initialized
INFO - 2023-06-27 08:30:17 --> Security Class Initialized
DEBUG - 2023-06-27 08:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:30:17 --> Input Class Initialized
INFO - 2023-06-27 08:30:17 --> Language Class Initialized
INFO - 2023-06-27 08:30:17 --> Loader Class Initialized
INFO - 2023-06-27 08:30:17 --> Helper loaded: url_helper
INFO - 2023-06-27 08:30:17 --> Helper loaded: file_helper
INFO - 2023-06-27 08:30:17 --> Helper loaded: html_helper
INFO - 2023-06-27 08:30:17 --> Helper loaded: text_helper
INFO - 2023-06-27 08:30:17 --> Helper loaded: form_helper
INFO - 2023-06-27 08:30:17 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:30:17 --> Helper loaded: security_helper
INFO - 2023-06-27 08:30:17 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:30:17 --> Database Driver Class Initialized
INFO - 2023-06-27 08:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:30:17 --> Parser Class Initialized
INFO - 2023-06-27 08:30:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:30:17 --> Pagination Class Initialized
INFO - 2023-06-27 08:30:17 --> Form Validation Class Initialized
INFO - 2023-06-27 08:30:17 --> Controller Class Initialized
INFO - 2023-06-27 08:30:17 --> Model Class Initialized
DEBUG - 2023-06-27 08:30:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:30:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:30:17 --> Model Class Initialized
DEBUG - 2023-06-27 08:30:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:30:17 --> Model Class Initialized
INFO - 2023-06-27 08:30:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-27 08:30:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:30:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:30:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:30:17 --> Model Class Initialized
INFO - 2023-06-27 08:30:17 --> Model Class Initialized
INFO - 2023-06-27 08:30:17 --> Model Class Initialized
INFO - 2023-06-27 08:30:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:30:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:30:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:30:17 --> Final output sent to browser
DEBUG - 2023-06-27 08:30:17 --> Total execution time: 0.0724
ERROR - 2023-06-27 08:30:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:30:20 --> Config Class Initialized
INFO - 2023-06-27 08:30:20 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:30:20 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:30:20 --> Utf8 Class Initialized
INFO - 2023-06-27 08:30:20 --> URI Class Initialized
INFO - 2023-06-27 08:30:20 --> Router Class Initialized
INFO - 2023-06-27 08:30:20 --> Output Class Initialized
INFO - 2023-06-27 08:30:20 --> Security Class Initialized
DEBUG - 2023-06-27 08:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:30:20 --> Input Class Initialized
INFO - 2023-06-27 08:30:20 --> Language Class Initialized
INFO - 2023-06-27 08:30:20 --> Loader Class Initialized
INFO - 2023-06-27 08:30:20 --> Helper loaded: url_helper
INFO - 2023-06-27 08:30:20 --> Helper loaded: file_helper
INFO - 2023-06-27 08:30:20 --> Helper loaded: html_helper
INFO - 2023-06-27 08:30:20 --> Helper loaded: text_helper
INFO - 2023-06-27 08:30:20 --> Helper loaded: form_helper
INFO - 2023-06-27 08:30:20 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:30:20 --> Helper loaded: security_helper
INFO - 2023-06-27 08:30:20 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:30:20 --> Database Driver Class Initialized
INFO - 2023-06-27 08:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:30:20 --> Parser Class Initialized
INFO - 2023-06-27 08:30:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:30:20 --> Pagination Class Initialized
INFO - 2023-06-27 08:30:20 --> Form Validation Class Initialized
INFO - 2023-06-27 08:30:20 --> Controller Class Initialized
INFO - 2023-06-27 08:30:20 --> Model Class Initialized
DEBUG - 2023-06-27 08:30:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:30:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:30:20 --> Model Class Initialized
DEBUG - 2023-06-27 08:30:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:30:20 --> Model Class Initialized
INFO - 2023-06-27 08:30:20 --> Final output sent to browser
DEBUG - 2023-06-27 08:30:20 --> Total execution time: 0.0264
ERROR - 2023-06-27 08:30:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:30:55 --> Config Class Initialized
INFO - 2023-06-27 08:30:55 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:30:55 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:30:55 --> Utf8 Class Initialized
INFO - 2023-06-27 08:30:55 --> URI Class Initialized
INFO - 2023-06-27 08:30:55 --> Router Class Initialized
INFO - 2023-06-27 08:30:55 --> Output Class Initialized
INFO - 2023-06-27 08:30:55 --> Security Class Initialized
DEBUG - 2023-06-27 08:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:30:55 --> Input Class Initialized
INFO - 2023-06-27 08:30:55 --> Language Class Initialized
INFO - 2023-06-27 08:30:55 --> Loader Class Initialized
INFO - 2023-06-27 08:30:55 --> Helper loaded: url_helper
INFO - 2023-06-27 08:30:55 --> Helper loaded: file_helper
INFO - 2023-06-27 08:30:55 --> Helper loaded: html_helper
INFO - 2023-06-27 08:30:55 --> Helper loaded: text_helper
INFO - 2023-06-27 08:30:55 --> Helper loaded: form_helper
INFO - 2023-06-27 08:30:55 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:30:55 --> Helper loaded: security_helper
INFO - 2023-06-27 08:30:55 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:30:55 --> Database Driver Class Initialized
INFO - 2023-06-27 08:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:30:55 --> Parser Class Initialized
INFO - 2023-06-27 08:30:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:30:55 --> Pagination Class Initialized
INFO - 2023-06-27 08:30:55 --> Form Validation Class Initialized
INFO - 2023-06-27 08:30:55 --> Controller Class Initialized
INFO - 2023-06-27 08:30:55 --> Model Class Initialized
DEBUG - 2023-06-27 08:30:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:30:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:30:55 --> Model Class Initialized
DEBUG - 2023-06-27 08:30:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:30:55 --> Model Class Initialized
DEBUG - 2023-06-27 08:30:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:30:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-06-27 08:30:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:30:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:30:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:30:55 --> Model Class Initialized
INFO - 2023-06-27 08:30:55 --> Model Class Initialized
INFO - 2023-06-27 08:30:55 --> Model Class Initialized
INFO - 2023-06-27 08:30:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:30:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:30:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:30:55 --> Final output sent to browser
DEBUG - 2023-06-27 08:30:55 --> Total execution time: 0.0786
ERROR - 2023-06-27 08:31:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:31:34 --> Config Class Initialized
INFO - 2023-06-27 08:31:34 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:31:34 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:31:34 --> Utf8 Class Initialized
INFO - 2023-06-27 08:31:34 --> URI Class Initialized
INFO - 2023-06-27 08:31:34 --> Router Class Initialized
INFO - 2023-06-27 08:31:34 --> Output Class Initialized
INFO - 2023-06-27 08:31:34 --> Security Class Initialized
DEBUG - 2023-06-27 08:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:31:34 --> Input Class Initialized
INFO - 2023-06-27 08:31:34 --> Language Class Initialized
INFO - 2023-06-27 08:31:34 --> Loader Class Initialized
INFO - 2023-06-27 08:31:34 --> Helper loaded: url_helper
INFO - 2023-06-27 08:31:34 --> Helper loaded: file_helper
INFO - 2023-06-27 08:31:34 --> Helper loaded: html_helper
INFO - 2023-06-27 08:31:34 --> Helper loaded: text_helper
INFO - 2023-06-27 08:31:34 --> Helper loaded: form_helper
INFO - 2023-06-27 08:31:34 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:31:34 --> Helper loaded: security_helper
INFO - 2023-06-27 08:31:34 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:31:34 --> Database Driver Class Initialized
INFO - 2023-06-27 08:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:31:34 --> Parser Class Initialized
INFO - 2023-06-27 08:31:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:31:34 --> Pagination Class Initialized
INFO - 2023-06-27 08:31:34 --> Form Validation Class Initialized
INFO - 2023-06-27 08:31:34 --> Controller Class Initialized
INFO - 2023-06-27 08:31:34 --> Model Class Initialized
DEBUG - 2023-06-27 08:31:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:31:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:31:34 --> Model Class Initialized
DEBUG - 2023-06-27 08:31:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:31:34 --> Model Class Initialized
INFO - 2023-06-27 08:31:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-27 08:31:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:31:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:31:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:31:34 --> Model Class Initialized
INFO - 2023-06-27 08:31:34 --> Model Class Initialized
INFO - 2023-06-27 08:31:34 --> Model Class Initialized
INFO - 2023-06-27 08:31:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:31:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:31:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:31:34 --> Final output sent to browser
DEBUG - 2023-06-27 08:31:34 --> Total execution time: 0.0693
ERROR - 2023-06-27 08:31:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:31:37 --> Config Class Initialized
INFO - 2023-06-27 08:31:37 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:31:37 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:31:37 --> Utf8 Class Initialized
INFO - 2023-06-27 08:31:37 --> URI Class Initialized
INFO - 2023-06-27 08:31:37 --> Router Class Initialized
INFO - 2023-06-27 08:31:37 --> Output Class Initialized
INFO - 2023-06-27 08:31:37 --> Security Class Initialized
DEBUG - 2023-06-27 08:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:31:37 --> Input Class Initialized
INFO - 2023-06-27 08:31:37 --> Language Class Initialized
INFO - 2023-06-27 08:31:37 --> Loader Class Initialized
INFO - 2023-06-27 08:31:37 --> Helper loaded: url_helper
INFO - 2023-06-27 08:31:37 --> Helper loaded: file_helper
INFO - 2023-06-27 08:31:37 --> Helper loaded: html_helper
INFO - 2023-06-27 08:31:37 --> Helper loaded: text_helper
INFO - 2023-06-27 08:31:37 --> Helper loaded: form_helper
INFO - 2023-06-27 08:31:37 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:31:37 --> Helper loaded: security_helper
INFO - 2023-06-27 08:31:37 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:31:37 --> Database Driver Class Initialized
INFO - 2023-06-27 08:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:31:37 --> Parser Class Initialized
INFO - 2023-06-27 08:31:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:31:37 --> Pagination Class Initialized
INFO - 2023-06-27 08:31:37 --> Form Validation Class Initialized
INFO - 2023-06-27 08:31:37 --> Controller Class Initialized
INFO - 2023-06-27 08:31:37 --> Model Class Initialized
DEBUG - 2023-06-27 08:31:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:31:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:31:37 --> Model Class Initialized
DEBUG - 2023-06-27 08:31:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:31:37 --> Model Class Initialized
INFO - 2023-06-27 08:31:37 --> Final output sent to browser
DEBUG - 2023-06-27 08:31:37 --> Total execution time: 0.0285
ERROR - 2023-06-27 08:32:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:32:08 --> Config Class Initialized
INFO - 2023-06-27 08:32:08 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:32:08 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:32:08 --> Utf8 Class Initialized
INFO - 2023-06-27 08:32:08 --> URI Class Initialized
DEBUG - 2023-06-27 08:32:08 --> No URI present. Default controller set.
INFO - 2023-06-27 08:32:08 --> Router Class Initialized
INFO - 2023-06-27 08:32:08 --> Output Class Initialized
INFO - 2023-06-27 08:32:08 --> Security Class Initialized
DEBUG - 2023-06-27 08:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:32:08 --> Input Class Initialized
INFO - 2023-06-27 08:32:08 --> Language Class Initialized
INFO - 2023-06-27 08:32:08 --> Loader Class Initialized
INFO - 2023-06-27 08:32:08 --> Helper loaded: url_helper
INFO - 2023-06-27 08:32:08 --> Helper loaded: file_helper
INFO - 2023-06-27 08:32:08 --> Helper loaded: html_helper
INFO - 2023-06-27 08:32:08 --> Helper loaded: text_helper
INFO - 2023-06-27 08:32:08 --> Helper loaded: form_helper
INFO - 2023-06-27 08:32:08 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:32:08 --> Helper loaded: security_helper
INFO - 2023-06-27 08:32:08 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:32:08 --> Database Driver Class Initialized
INFO - 2023-06-27 08:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:32:08 --> Parser Class Initialized
INFO - 2023-06-27 08:32:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:32:08 --> Pagination Class Initialized
INFO - 2023-06-27 08:32:08 --> Form Validation Class Initialized
INFO - 2023-06-27 08:32:08 --> Controller Class Initialized
INFO - 2023-06-27 08:32:08 --> Model Class Initialized
DEBUG - 2023-06-27 08:32:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:32:08 --> Model Class Initialized
DEBUG - 2023-06-27 08:32:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:32:08 --> Model Class Initialized
INFO - 2023-06-27 08:32:08 --> Model Class Initialized
INFO - 2023-06-27 08:32:08 --> Model Class Initialized
INFO - 2023-06-27 08:32:08 --> Model Class Initialized
DEBUG - 2023-06-27 08:32:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:32:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:32:08 --> Model Class Initialized
INFO - 2023-06-27 08:32:08 --> Model Class Initialized
INFO - 2023-06-27 08:32:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 08:32:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:32:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:32:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:32:08 --> Model Class Initialized
INFO - 2023-06-27 08:32:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:32:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:32:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:32:08 --> Final output sent to browser
DEBUG - 2023-06-27 08:32:08 --> Total execution time: 0.0739
ERROR - 2023-06-27 08:32:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:32:20 --> Config Class Initialized
INFO - 2023-06-27 08:32:20 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:32:20 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:32:20 --> Utf8 Class Initialized
INFO - 2023-06-27 08:32:20 --> URI Class Initialized
INFO - 2023-06-27 08:32:20 --> Router Class Initialized
INFO - 2023-06-27 08:32:20 --> Output Class Initialized
INFO - 2023-06-27 08:32:20 --> Security Class Initialized
DEBUG - 2023-06-27 08:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:32:20 --> Input Class Initialized
INFO - 2023-06-27 08:32:20 --> Language Class Initialized
INFO - 2023-06-27 08:32:20 --> Loader Class Initialized
INFO - 2023-06-27 08:32:20 --> Helper loaded: url_helper
INFO - 2023-06-27 08:32:20 --> Helper loaded: file_helper
INFO - 2023-06-27 08:32:20 --> Helper loaded: html_helper
INFO - 2023-06-27 08:32:20 --> Helper loaded: text_helper
INFO - 2023-06-27 08:32:20 --> Helper loaded: form_helper
INFO - 2023-06-27 08:32:20 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:32:20 --> Helper loaded: security_helper
INFO - 2023-06-27 08:32:20 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:32:20 --> Database Driver Class Initialized
INFO - 2023-06-27 08:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:32:20 --> Parser Class Initialized
INFO - 2023-06-27 08:32:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:32:20 --> Pagination Class Initialized
INFO - 2023-06-27 08:32:20 --> Form Validation Class Initialized
INFO - 2023-06-27 08:32:20 --> Controller Class Initialized
INFO - 2023-06-27 08:32:20 --> Model Class Initialized
DEBUG - 2023-06-27 08:32:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:32:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:32:20 --> Model Class Initialized
DEBUG - 2023-06-27 08:32:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:32:20 --> Model Class Initialized
INFO - 2023-06-27 08:32:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-27 08:32:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:32:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:32:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:32:20 --> Model Class Initialized
INFO - 2023-06-27 08:32:20 --> Model Class Initialized
INFO - 2023-06-27 08:32:20 --> Model Class Initialized
INFO - 2023-06-27 08:32:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:32:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:32:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:32:20 --> Final output sent to browser
DEBUG - 2023-06-27 08:32:20 --> Total execution time: 0.0682
ERROR - 2023-06-27 08:32:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:32:20 --> Config Class Initialized
INFO - 2023-06-27 08:32:20 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:32:20 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:32:20 --> Utf8 Class Initialized
INFO - 2023-06-27 08:32:20 --> URI Class Initialized
INFO - 2023-06-27 08:32:20 --> Router Class Initialized
INFO - 2023-06-27 08:32:20 --> Output Class Initialized
INFO - 2023-06-27 08:32:20 --> Security Class Initialized
DEBUG - 2023-06-27 08:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:32:20 --> Input Class Initialized
INFO - 2023-06-27 08:32:20 --> Language Class Initialized
INFO - 2023-06-27 08:32:20 --> Loader Class Initialized
INFO - 2023-06-27 08:32:20 --> Helper loaded: url_helper
INFO - 2023-06-27 08:32:20 --> Helper loaded: file_helper
INFO - 2023-06-27 08:32:20 --> Helper loaded: html_helper
INFO - 2023-06-27 08:32:20 --> Helper loaded: text_helper
INFO - 2023-06-27 08:32:20 --> Helper loaded: form_helper
INFO - 2023-06-27 08:32:20 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:32:20 --> Helper loaded: security_helper
INFO - 2023-06-27 08:32:20 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:32:20 --> Database Driver Class Initialized
INFO - 2023-06-27 08:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:32:20 --> Parser Class Initialized
INFO - 2023-06-27 08:32:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:32:20 --> Pagination Class Initialized
INFO - 2023-06-27 08:32:20 --> Form Validation Class Initialized
INFO - 2023-06-27 08:32:20 --> Controller Class Initialized
INFO - 2023-06-27 08:32:20 --> Model Class Initialized
DEBUG - 2023-06-27 08:32:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:32:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:32:20 --> Model Class Initialized
DEBUG - 2023-06-27 08:32:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:32:20 --> Model Class Initialized
INFO - 2023-06-27 08:32:20 --> Final output sent to browser
DEBUG - 2023-06-27 08:32:20 --> Total execution time: 0.0263
ERROR - 2023-06-27 08:32:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:32:36 --> Config Class Initialized
INFO - 2023-06-27 08:32:36 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:32:36 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:32:36 --> Utf8 Class Initialized
INFO - 2023-06-27 08:32:36 --> URI Class Initialized
INFO - 2023-06-27 08:32:36 --> Router Class Initialized
INFO - 2023-06-27 08:32:36 --> Output Class Initialized
INFO - 2023-06-27 08:32:36 --> Security Class Initialized
DEBUG - 2023-06-27 08:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:32:36 --> Input Class Initialized
INFO - 2023-06-27 08:32:36 --> Language Class Initialized
INFO - 2023-06-27 08:32:36 --> Loader Class Initialized
INFO - 2023-06-27 08:32:36 --> Helper loaded: url_helper
INFO - 2023-06-27 08:32:36 --> Helper loaded: file_helper
INFO - 2023-06-27 08:32:36 --> Helper loaded: html_helper
INFO - 2023-06-27 08:32:36 --> Helper loaded: text_helper
INFO - 2023-06-27 08:32:36 --> Helper loaded: form_helper
INFO - 2023-06-27 08:32:36 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:32:36 --> Helper loaded: security_helper
INFO - 2023-06-27 08:32:36 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:32:36 --> Database Driver Class Initialized
INFO - 2023-06-27 08:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:32:36 --> Parser Class Initialized
INFO - 2023-06-27 08:32:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:32:36 --> Pagination Class Initialized
INFO - 2023-06-27 08:32:36 --> Form Validation Class Initialized
INFO - 2023-06-27 08:32:36 --> Controller Class Initialized
INFO - 2023-06-27 08:32:36 --> Model Class Initialized
DEBUG - 2023-06-27 08:32:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:32:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:32:36 --> Model Class Initialized
DEBUG - 2023-06-27 08:32:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:32:36 --> Model Class Initialized
DEBUG - 2023-06-27 08:32:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:32:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-06-27 08:32:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:32:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:32:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:32:36 --> Model Class Initialized
INFO - 2023-06-27 08:32:36 --> Model Class Initialized
INFO - 2023-06-27 08:32:36 --> Model Class Initialized
INFO - 2023-06-27 08:32:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:32:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:32:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:32:36 --> Final output sent to browser
DEBUG - 2023-06-27 08:32:36 --> Total execution time: 0.0828
ERROR - 2023-06-27 08:32:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:32:58 --> Config Class Initialized
INFO - 2023-06-27 08:32:58 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:32:58 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:32:58 --> Utf8 Class Initialized
INFO - 2023-06-27 08:32:58 --> URI Class Initialized
DEBUG - 2023-06-27 08:32:58 --> No URI present. Default controller set.
INFO - 2023-06-27 08:32:58 --> Router Class Initialized
INFO - 2023-06-27 08:32:58 --> Output Class Initialized
INFO - 2023-06-27 08:32:58 --> Security Class Initialized
DEBUG - 2023-06-27 08:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:32:58 --> Input Class Initialized
INFO - 2023-06-27 08:32:58 --> Language Class Initialized
INFO - 2023-06-27 08:32:58 --> Loader Class Initialized
INFO - 2023-06-27 08:32:58 --> Helper loaded: url_helper
INFO - 2023-06-27 08:32:58 --> Helper loaded: file_helper
INFO - 2023-06-27 08:32:58 --> Helper loaded: html_helper
INFO - 2023-06-27 08:32:58 --> Helper loaded: text_helper
INFO - 2023-06-27 08:32:58 --> Helper loaded: form_helper
INFO - 2023-06-27 08:32:58 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:32:58 --> Helper loaded: security_helper
INFO - 2023-06-27 08:32:58 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:32:58 --> Database Driver Class Initialized
INFO - 2023-06-27 08:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:32:58 --> Parser Class Initialized
INFO - 2023-06-27 08:32:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:32:58 --> Pagination Class Initialized
INFO - 2023-06-27 08:32:58 --> Form Validation Class Initialized
INFO - 2023-06-27 08:32:58 --> Controller Class Initialized
INFO - 2023-06-27 08:32:58 --> Model Class Initialized
DEBUG - 2023-06-27 08:32:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:32:58 --> Model Class Initialized
DEBUG - 2023-06-27 08:32:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:32:58 --> Model Class Initialized
INFO - 2023-06-27 08:32:58 --> Model Class Initialized
INFO - 2023-06-27 08:32:58 --> Model Class Initialized
INFO - 2023-06-27 08:32:58 --> Model Class Initialized
DEBUG - 2023-06-27 08:32:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:32:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:32:58 --> Model Class Initialized
INFO - 2023-06-27 08:32:58 --> Model Class Initialized
INFO - 2023-06-27 08:32:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 08:32:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:32:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:32:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:32:58 --> Model Class Initialized
INFO - 2023-06-27 08:32:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:32:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:32:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:32:58 --> Final output sent to browser
DEBUG - 2023-06-27 08:32:58 --> Total execution time: 0.0858
ERROR - 2023-06-27 08:33:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:33:20 --> Config Class Initialized
INFO - 2023-06-27 08:33:20 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:33:20 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:33:20 --> Utf8 Class Initialized
INFO - 2023-06-27 08:33:20 --> URI Class Initialized
INFO - 2023-06-27 08:33:20 --> Router Class Initialized
INFO - 2023-06-27 08:33:20 --> Output Class Initialized
INFO - 2023-06-27 08:33:20 --> Security Class Initialized
DEBUG - 2023-06-27 08:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:33:20 --> Input Class Initialized
INFO - 2023-06-27 08:33:20 --> Language Class Initialized
INFO - 2023-06-27 08:33:20 --> Loader Class Initialized
INFO - 2023-06-27 08:33:20 --> Helper loaded: url_helper
INFO - 2023-06-27 08:33:20 --> Helper loaded: file_helper
INFO - 2023-06-27 08:33:20 --> Helper loaded: html_helper
INFO - 2023-06-27 08:33:20 --> Helper loaded: text_helper
INFO - 2023-06-27 08:33:20 --> Helper loaded: form_helper
INFO - 2023-06-27 08:33:20 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:33:20 --> Helper loaded: security_helper
INFO - 2023-06-27 08:33:20 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:33:20 --> Database Driver Class Initialized
INFO - 2023-06-27 08:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:33:20 --> Parser Class Initialized
INFO - 2023-06-27 08:33:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:33:20 --> Pagination Class Initialized
INFO - 2023-06-27 08:33:20 --> Form Validation Class Initialized
INFO - 2023-06-27 08:33:20 --> Controller Class Initialized
INFO - 2023-06-27 08:33:20 --> Model Class Initialized
INFO - 2023-06-27 08:33:20 --> Model Class Initialized
INFO - 2023-06-27 08:33:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-06-27 08:33:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:33:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:33:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:33:20 --> Model Class Initialized
INFO - 2023-06-27 08:33:20 --> Model Class Initialized
INFO - 2023-06-27 08:33:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:33:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:33:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:33:20 --> Final output sent to browser
DEBUG - 2023-06-27 08:33:20 --> Total execution time: 0.0572
ERROR - 2023-06-27 08:33:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:33:21 --> Config Class Initialized
INFO - 2023-06-27 08:33:21 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:33:21 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:33:21 --> Utf8 Class Initialized
INFO - 2023-06-27 08:33:21 --> URI Class Initialized
INFO - 2023-06-27 08:33:21 --> Router Class Initialized
INFO - 2023-06-27 08:33:21 --> Output Class Initialized
INFO - 2023-06-27 08:33:21 --> Security Class Initialized
DEBUG - 2023-06-27 08:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:33:21 --> Input Class Initialized
INFO - 2023-06-27 08:33:21 --> Language Class Initialized
INFO - 2023-06-27 08:33:21 --> Loader Class Initialized
INFO - 2023-06-27 08:33:21 --> Helper loaded: url_helper
INFO - 2023-06-27 08:33:21 --> Helper loaded: file_helper
INFO - 2023-06-27 08:33:21 --> Helper loaded: html_helper
INFO - 2023-06-27 08:33:21 --> Helper loaded: text_helper
INFO - 2023-06-27 08:33:21 --> Helper loaded: form_helper
INFO - 2023-06-27 08:33:21 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:33:21 --> Helper loaded: security_helper
INFO - 2023-06-27 08:33:21 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:33:21 --> Database Driver Class Initialized
INFO - 2023-06-27 08:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:33:21 --> Parser Class Initialized
INFO - 2023-06-27 08:33:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:33:21 --> Pagination Class Initialized
INFO - 2023-06-27 08:33:21 --> Form Validation Class Initialized
INFO - 2023-06-27 08:33:21 --> Controller Class Initialized
INFO - 2023-06-27 08:33:21 --> Model Class Initialized
INFO - 2023-06-27 08:33:21 --> Model Class Initialized
INFO - 2023-06-27 08:33:21 --> Final output sent to browser
DEBUG - 2023-06-27 08:33:21 --> Total execution time: 0.0178
ERROR - 2023-06-27 08:33:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:33:35 --> Config Class Initialized
INFO - 2023-06-27 08:33:35 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:33:35 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:33:35 --> Utf8 Class Initialized
INFO - 2023-06-27 08:33:35 --> URI Class Initialized
DEBUG - 2023-06-27 08:33:35 --> No URI present. Default controller set.
INFO - 2023-06-27 08:33:35 --> Router Class Initialized
INFO - 2023-06-27 08:33:35 --> Output Class Initialized
INFO - 2023-06-27 08:33:35 --> Security Class Initialized
DEBUG - 2023-06-27 08:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:33:35 --> Input Class Initialized
INFO - 2023-06-27 08:33:35 --> Language Class Initialized
INFO - 2023-06-27 08:33:35 --> Loader Class Initialized
INFO - 2023-06-27 08:33:35 --> Helper loaded: url_helper
INFO - 2023-06-27 08:33:35 --> Helper loaded: file_helper
INFO - 2023-06-27 08:33:35 --> Helper loaded: html_helper
INFO - 2023-06-27 08:33:35 --> Helper loaded: text_helper
INFO - 2023-06-27 08:33:35 --> Helper loaded: form_helper
INFO - 2023-06-27 08:33:35 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:33:35 --> Helper loaded: security_helper
INFO - 2023-06-27 08:33:35 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:33:35 --> Database Driver Class Initialized
INFO - 2023-06-27 08:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:33:35 --> Parser Class Initialized
INFO - 2023-06-27 08:33:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:33:35 --> Pagination Class Initialized
INFO - 2023-06-27 08:33:35 --> Form Validation Class Initialized
INFO - 2023-06-27 08:33:35 --> Controller Class Initialized
INFO - 2023-06-27 08:33:35 --> Model Class Initialized
DEBUG - 2023-06-27 08:33:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:33:35 --> Model Class Initialized
DEBUG - 2023-06-27 08:33:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:33:35 --> Model Class Initialized
INFO - 2023-06-27 08:33:35 --> Model Class Initialized
INFO - 2023-06-27 08:33:35 --> Model Class Initialized
INFO - 2023-06-27 08:33:35 --> Model Class Initialized
DEBUG - 2023-06-27 08:33:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:33:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:33:35 --> Model Class Initialized
INFO - 2023-06-27 08:33:35 --> Model Class Initialized
INFO - 2023-06-27 08:33:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 08:33:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:33:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:33:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:33:35 --> Model Class Initialized
INFO - 2023-06-27 08:33:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:33:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:33:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:33:35 --> Final output sent to browser
DEBUG - 2023-06-27 08:33:35 --> Total execution time: 0.0849
ERROR - 2023-06-27 08:33:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:33:45 --> Config Class Initialized
INFO - 2023-06-27 08:33:45 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:33:45 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:33:45 --> Utf8 Class Initialized
INFO - 2023-06-27 08:33:45 --> URI Class Initialized
INFO - 2023-06-27 08:33:45 --> Router Class Initialized
INFO - 2023-06-27 08:33:45 --> Output Class Initialized
INFO - 2023-06-27 08:33:45 --> Security Class Initialized
DEBUG - 2023-06-27 08:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:33:45 --> Input Class Initialized
INFO - 2023-06-27 08:33:45 --> Language Class Initialized
INFO - 2023-06-27 08:33:45 --> Loader Class Initialized
INFO - 2023-06-27 08:33:45 --> Helper loaded: url_helper
INFO - 2023-06-27 08:33:45 --> Helper loaded: file_helper
INFO - 2023-06-27 08:33:45 --> Helper loaded: html_helper
INFO - 2023-06-27 08:33:45 --> Helper loaded: text_helper
INFO - 2023-06-27 08:33:45 --> Helper loaded: form_helper
INFO - 2023-06-27 08:33:45 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:33:45 --> Helper loaded: security_helper
INFO - 2023-06-27 08:33:45 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:33:45 --> Database Driver Class Initialized
INFO - 2023-06-27 08:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:33:45 --> Parser Class Initialized
INFO - 2023-06-27 08:33:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:33:45 --> Pagination Class Initialized
INFO - 2023-06-27 08:33:45 --> Form Validation Class Initialized
INFO - 2023-06-27 08:33:45 --> Controller Class Initialized
INFO - 2023-06-27 08:33:45 --> Model Class Initialized
DEBUG - 2023-06-27 08:33:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:33:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:33:45 --> Model Class Initialized
DEBUG - 2023-06-27 08:33:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:33:45 --> Model Class Initialized
DEBUG - 2023-06-27 08:33:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:33:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-06-27 08:33:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:33:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:33:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:33:45 --> Model Class Initialized
INFO - 2023-06-27 08:33:45 --> Model Class Initialized
INFO - 2023-06-27 08:33:45 --> Model Class Initialized
INFO - 2023-06-27 08:33:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:33:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:33:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:33:45 --> Final output sent to browser
DEBUG - 2023-06-27 08:33:45 --> Total execution time: 0.0771
ERROR - 2023-06-27 08:34:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:34:03 --> Config Class Initialized
INFO - 2023-06-27 08:34:03 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:34:03 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:34:03 --> Utf8 Class Initialized
INFO - 2023-06-27 08:34:03 --> URI Class Initialized
INFO - 2023-06-27 08:34:03 --> Router Class Initialized
INFO - 2023-06-27 08:34:03 --> Output Class Initialized
INFO - 2023-06-27 08:34:03 --> Security Class Initialized
DEBUG - 2023-06-27 08:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:34:03 --> Input Class Initialized
INFO - 2023-06-27 08:34:03 --> Language Class Initialized
INFO - 2023-06-27 08:34:03 --> Loader Class Initialized
INFO - 2023-06-27 08:34:03 --> Helper loaded: url_helper
INFO - 2023-06-27 08:34:03 --> Helper loaded: file_helper
INFO - 2023-06-27 08:34:03 --> Helper loaded: html_helper
INFO - 2023-06-27 08:34:03 --> Helper loaded: text_helper
INFO - 2023-06-27 08:34:03 --> Helper loaded: form_helper
INFO - 2023-06-27 08:34:03 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:34:03 --> Helper loaded: security_helper
INFO - 2023-06-27 08:34:03 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:34:03 --> Database Driver Class Initialized
INFO - 2023-06-27 08:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:34:03 --> Parser Class Initialized
INFO - 2023-06-27 08:34:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:34:03 --> Pagination Class Initialized
INFO - 2023-06-27 08:34:03 --> Form Validation Class Initialized
INFO - 2023-06-27 08:34:03 --> Controller Class Initialized
INFO - 2023-06-27 08:34:03 --> Model Class Initialized
DEBUG - 2023-06-27 08:34:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:34:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:34:03 --> Model Class Initialized
DEBUG - 2023-06-27 08:34:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:34:03 --> Model Class Initialized
INFO - 2023-06-27 08:34:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-27 08:34:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:34:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:34:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:34:03 --> Model Class Initialized
INFO - 2023-06-27 08:34:03 --> Model Class Initialized
INFO - 2023-06-27 08:34:03 --> Model Class Initialized
INFO - 2023-06-27 08:34:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:34:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:34:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:34:03 --> Final output sent to browser
DEBUG - 2023-06-27 08:34:03 --> Total execution time: 0.0610
ERROR - 2023-06-27 08:34:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:34:04 --> Config Class Initialized
INFO - 2023-06-27 08:34:04 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:34:04 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:34:04 --> Utf8 Class Initialized
INFO - 2023-06-27 08:34:04 --> URI Class Initialized
INFO - 2023-06-27 08:34:04 --> Router Class Initialized
INFO - 2023-06-27 08:34:04 --> Output Class Initialized
INFO - 2023-06-27 08:34:04 --> Security Class Initialized
DEBUG - 2023-06-27 08:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:34:04 --> Input Class Initialized
INFO - 2023-06-27 08:34:04 --> Language Class Initialized
INFO - 2023-06-27 08:34:04 --> Loader Class Initialized
INFO - 2023-06-27 08:34:04 --> Helper loaded: url_helper
INFO - 2023-06-27 08:34:04 --> Helper loaded: file_helper
INFO - 2023-06-27 08:34:04 --> Helper loaded: html_helper
INFO - 2023-06-27 08:34:04 --> Helper loaded: text_helper
INFO - 2023-06-27 08:34:04 --> Helper loaded: form_helper
INFO - 2023-06-27 08:34:04 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:34:04 --> Helper loaded: security_helper
INFO - 2023-06-27 08:34:04 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:34:04 --> Database Driver Class Initialized
INFO - 2023-06-27 08:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:34:04 --> Parser Class Initialized
INFO - 2023-06-27 08:34:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:34:04 --> Pagination Class Initialized
INFO - 2023-06-27 08:34:04 --> Form Validation Class Initialized
INFO - 2023-06-27 08:34:04 --> Controller Class Initialized
INFO - 2023-06-27 08:34:04 --> Model Class Initialized
DEBUG - 2023-06-27 08:34:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:34:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:34:04 --> Model Class Initialized
DEBUG - 2023-06-27 08:34:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:34:04 --> Model Class Initialized
INFO - 2023-06-27 08:34:04 --> Final output sent to browser
DEBUG - 2023-06-27 08:34:04 --> Total execution time: 0.0266
ERROR - 2023-06-27 08:34:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:34:07 --> Config Class Initialized
INFO - 2023-06-27 08:34:07 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:34:07 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:34:07 --> Utf8 Class Initialized
INFO - 2023-06-27 08:34:07 --> URI Class Initialized
INFO - 2023-06-27 08:34:07 --> Router Class Initialized
INFO - 2023-06-27 08:34:07 --> Output Class Initialized
INFO - 2023-06-27 08:34:07 --> Security Class Initialized
DEBUG - 2023-06-27 08:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:34:07 --> Input Class Initialized
INFO - 2023-06-27 08:34:07 --> Language Class Initialized
INFO - 2023-06-27 08:34:07 --> Loader Class Initialized
INFO - 2023-06-27 08:34:07 --> Helper loaded: url_helper
INFO - 2023-06-27 08:34:07 --> Helper loaded: file_helper
INFO - 2023-06-27 08:34:07 --> Helper loaded: html_helper
INFO - 2023-06-27 08:34:07 --> Helper loaded: text_helper
INFO - 2023-06-27 08:34:07 --> Helper loaded: form_helper
INFO - 2023-06-27 08:34:07 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:34:07 --> Helper loaded: security_helper
INFO - 2023-06-27 08:34:07 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:34:07 --> Database Driver Class Initialized
INFO - 2023-06-27 08:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:34:07 --> Parser Class Initialized
INFO - 2023-06-27 08:34:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:34:07 --> Pagination Class Initialized
INFO - 2023-06-27 08:34:07 --> Form Validation Class Initialized
INFO - 2023-06-27 08:34:07 --> Controller Class Initialized
INFO - 2023-06-27 08:34:07 --> Model Class Initialized
DEBUG - 2023-06-27 08:34:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:34:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:34:07 --> Model Class Initialized
DEBUG - 2023-06-27 08:34:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:34:07 --> Model Class Initialized
DEBUG - 2023-06-27 08:34:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:34:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-06-27 08:34:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:34:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:34:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:34:07 --> Model Class Initialized
INFO - 2023-06-27 08:34:07 --> Model Class Initialized
INFO - 2023-06-27 08:34:07 --> Model Class Initialized
INFO - 2023-06-27 08:34:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:34:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:34:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:34:07 --> Final output sent to browser
DEBUG - 2023-06-27 08:34:07 --> Total execution time: 0.0812
ERROR - 2023-06-27 08:34:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:34:15 --> Config Class Initialized
INFO - 2023-06-27 08:34:15 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:34:15 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:34:15 --> Utf8 Class Initialized
INFO - 2023-06-27 08:34:15 --> URI Class Initialized
DEBUG - 2023-06-27 08:34:15 --> No URI present. Default controller set.
INFO - 2023-06-27 08:34:15 --> Router Class Initialized
INFO - 2023-06-27 08:34:15 --> Output Class Initialized
INFO - 2023-06-27 08:34:15 --> Security Class Initialized
DEBUG - 2023-06-27 08:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:34:15 --> Input Class Initialized
INFO - 2023-06-27 08:34:15 --> Language Class Initialized
INFO - 2023-06-27 08:34:15 --> Loader Class Initialized
INFO - 2023-06-27 08:34:15 --> Helper loaded: url_helper
INFO - 2023-06-27 08:34:15 --> Helper loaded: file_helper
INFO - 2023-06-27 08:34:15 --> Helper loaded: html_helper
INFO - 2023-06-27 08:34:15 --> Helper loaded: text_helper
INFO - 2023-06-27 08:34:15 --> Helper loaded: form_helper
INFO - 2023-06-27 08:34:15 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:34:15 --> Helper loaded: security_helper
INFO - 2023-06-27 08:34:15 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:34:15 --> Database Driver Class Initialized
INFO - 2023-06-27 08:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:34:15 --> Parser Class Initialized
INFO - 2023-06-27 08:34:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:34:15 --> Pagination Class Initialized
INFO - 2023-06-27 08:34:15 --> Form Validation Class Initialized
INFO - 2023-06-27 08:34:15 --> Controller Class Initialized
INFO - 2023-06-27 08:34:15 --> Model Class Initialized
DEBUG - 2023-06-27 08:34:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:34:15 --> Model Class Initialized
DEBUG - 2023-06-27 08:34:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:34:15 --> Model Class Initialized
INFO - 2023-06-27 08:34:15 --> Model Class Initialized
INFO - 2023-06-27 08:34:15 --> Model Class Initialized
INFO - 2023-06-27 08:34:15 --> Model Class Initialized
DEBUG - 2023-06-27 08:34:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:34:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:34:15 --> Model Class Initialized
INFO - 2023-06-27 08:34:15 --> Model Class Initialized
INFO - 2023-06-27 08:34:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 08:34:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:34:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:34:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:34:15 --> Model Class Initialized
INFO - 2023-06-27 08:34:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:34:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:34:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:34:15 --> Final output sent to browser
DEBUG - 2023-06-27 08:34:15 --> Total execution time: 0.0678
ERROR - 2023-06-27 08:34:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:34:49 --> Config Class Initialized
INFO - 2023-06-27 08:34:49 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:34:49 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:34:49 --> Utf8 Class Initialized
INFO - 2023-06-27 08:34:49 --> URI Class Initialized
INFO - 2023-06-27 08:34:49 --> Router Class Initialized
INFO - 2023-06-27 08:34:49 --> Output Class Initialized
INFO - 2023-06-27 08:34:49 --> Security Class Initialized
DEBUG - 2023-06-27 08:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:34:49 --> Input Class Initialized
INFO - 2023-06-27 08:34:49 --> Language Class Initialized
INFO - 2023-06-27 08:34:49 --> Loader Class Initialized
INFO - 2023-06-27 08:34:49 --> Helper loaded: url_helper
INFO - 2023-06-27 08:34:49 --> Helper loaded: file_helper
INFO - 2023-06-27 08:34:49 --> Helper loaded: html_helper
INFO - 2023-06-27 08:34:49 --> Helper loaded: text_helper
INFO - 2023-06-27 08:34:49 --> Helper loaded: form_helper
INFO - 2023-06-27 08:34:49 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:34:49 --> Helper loaded: security_helper
INFO - 2023-06-27 08:34:49 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:34:49 --> Database Driver Class Initialized
INFO - 2023-06-27 08:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:34:49 --> Parser Class Initialized
INFO - 2023-06-27 08:34:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:34:49 --> Pagination Class Initialized
INFO - 2023-06-27 08:34:49 --> Form Validation Class Initialized
INFO - 2023-06-27 08:34:49 --> Controller Class Initialized
INFO - 2023-06-27 08:34:49 --> Model Class Initialized
DEBUG - 2023-06-27 08:34:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:34:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:34:49 --> Model Class Initialized
DEBUG - 2023-06-27 08:34:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:34:49 --> Model Class Initialized
INFO - 2023-06-27 08:34:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-27 08:34:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:34:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:34:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:34:49 --> Model Class Initialized
INFO - 2023-06-27 08:34:49 --> Model Class Initialized
INFO - 2023-06-27 08:34:49 --> Model Class Initialized
INFO - 2023-06-27 08:34:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:34:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:34:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:34:49 --> Final output sent to browser
DEBUG - 2023-06-27 08:34:49 --> Total execution time: 0.0784
ERROR - 2023-06-27 08:34:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:34:49 --> Config Class Initialized
INFO - 2023-06-27 08:34:49 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:34:49 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:34:49 --> Utf8 Class Initialized
INFO - 2023-06-27 08:34:49 --> URI Class Initialized
INFO - 2023-06-27 08:34:49 --> Router Class Initialized
INFO - 2023-06-27 08:34:49 --> Output Class Initialized
INFO - 2023-06-27 08:34:49 --> Security Class Initialized
DEBUG - 2023-06-27 08:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:34:49 --> Input Class Initialized
INFO - 2023-06-27 08:34:49 --> Language Class Initialized
INFO - 2023-06-27 08:34:49 --> Loader Class Initialized
INFO - 2023-06-27 08:34:49 --> Helper loaded: url_helper
INFO - 2023-06-27 08:34:49 --> Helper loaded: file_helper
INFO - 2023-06-27 08:34:49 --> Helper loaded: html_helper
INFO - 2023-06-27 08:34:49 --> Helper loaded: text_helper
INFO - 2023-06-27 08:34:49 --> Helper loaded: form_helper
INFO - 2023-06-27 08:34:49 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:34:49 --> Helper loaded: security_helper
INFO - 2023-06-27 08:34:49 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:34:49 --> Database Driver Class Initialized
INFO - 2023-06-27 08:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:34:49 --> Parser Class Initialized
INFO - 2023-06-27 08:34:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:34:49 --> Pagination Class Initialized
INFO - 2023-06-27 08:34:49 --> Form Validation Class Initialized
INFO - 2023-06-27 08:34:49 --> Controller Class Initialized
INFO - 2023-06-27 08:34:49 --> Model Class Initialized
DEBUG - 2023-06-27 08:34:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:34:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:34:49 --> Model Class Initialized
DEBUG - 2023-06-27 08:34:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:34:49 --> Model Class Initialized
INFO - 2023-06-27 08:34:49 --> Final output sent to browser
DEBUG - 2023-06-27 08:34:49 --> Total execution time: 0.0382
ERROR - 2023-06-27 08:34:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:34:53 --> Config Class Initialized
INFO - 2023-06-27 08:34:53 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:34:53 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:34:53 --> Utf8 Class Initialized
INFO - 2023-06-27 08:34:53 --> URI Class Initialized
INFO - 2023-06-27 08:34:53 --> Router Class Initialized
INFO - 2023-06-27 08:34:53 --> Output Class Initialized
INFO - 2023-06-27 08:34:53 --> Security Class Initialized
DEBUG - 2023-06-27 08:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:34:53 --> Input Class Initialized
INFO - 2023-06-27 08:34:53 --> Language Class Initialized
INFO - 2023-06-27 08:34:53 --> Loader Class Initialized
INFO - 2023-06-27 08:34:53 --> Helper loaded: url_helper
INFO - 2023-06-27 08:34:53 --> Helper loaded: file_helper
INFO - 2023-06-27 08:34:53 --> Helper loaded: html_helper
INFO - 2023-06-27 08:34:53 --> Helper loaded: text_helper
INFO - 2023-06-27 08:34:53 --> Helper loaded: form_helper
INFO - 2023-06-27 08:34:53 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:34:53 --> Helper loaded: security_helper
INFO - 2023-06-27 08:34:53 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:34:53 --> Database Driver Class Initialized
INFO - 2023-06-27 08:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:34:53 --> Parser Class Initialized
INFO - 2023-06-27 08:34:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:34:53 --> Pagination Class Initialized
INFO - 2023-06-27 08:34:53 --> Form Validation Class Initialized
INFO - 2023-06-27 08:34:53 --> Controller Class Initialized
INFO - 2023-06-27 08:34:53 --> Model Class Initialized
DEBUG - 2023-06-27 08:34:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:34:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:34:53 --> Model Class Initialized
DEBUG - 2023-06-27 08:34:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:34:53 --> Model Class Initialized
DEBUG - 2023-06-27 08:34:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:34:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 08:34:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-06-27 08:34:53 --> Final output sent to browser
DEBUG - 2023-06-27 08:34:53 --> Total execution time: 0.1843
ERROR - 2023-06-27 08:35:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:35:42 --> Config Class Initialized
INFO - 2023-06-27 08:35:42 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:35:42 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:35:42 --> Utf8 Class Initialized
INFO - 2023-06-27 08:35:42 --> URI Class Initialized
INFO - 2023-06-27 08:35:42 --> Router Class Initialized
INFO - 2023-06-27 08:35:42 --> Output Class Initialized
INFO - 2023-06-27 08:35:42 --> Security Class Initialized
DEBUG - 2023-06-27 08:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:35:42 --> Input Class Initialized
INFO - 2023-06-27 08:35:42 --> Language Class Initialized
INFO - 2023-06-27 08:35:42 --> Loader Class Initialized
INFO - 2023-06-27 08:35:42 --> Helper loaded: url_helper
INFO - 2023-06-27 08:35:42 --> Helper loaded: file_helper
INFO - 2023-06-27 08:35:42 --> Helper loaded: html_helper
INFO - 2023-06-27 08:35:42 --> Helper loaded: text_helper
INFO - 2023-06-27 08:35:42 --> Helper loaded: form_helper
INFO - 2023-06-27 08:35:42 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:35:42 --> Helper loaded: security_helper
INFO - 2023-06-27 08:35:42 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:35:42 --> Database Driver Class Initialized
INFO - 2023-06-27 08:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:35:42 --> Parser Class Initialized
INFO - 2023-06-27 08:35:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:35:42 --> Pagination Class Initialized
INFO - 2023-06-27 08:35:42 --> Form Validation Class Initialized
INFO - 2023-06-27 08:35:42 --> Controller Class Initialized
INFO - 2023-06-27 08:35:42 --> Model Class Initialized
DEBUG - 2023-06-27 08:35:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:35:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:35:42 --> Model Class Initialized
DEBUG - 2023-06-27 08:35:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:35:42 --> Model Class Initialized
INFO - 2023-06-27 08:35:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-27 08:35:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:35:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:35:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:35:42 --> Model Class Initialized
INFO - 2023-06-27 08:35:42 --> Model Class Initialized
INFO - 2023-06-27 08:35:42 --> Model Class Initialized
INFO - 2023-06-27 08:35:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:35:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:35:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:35:42 --> Final output sent to browser
DEBUG - 2023-06-27 08:35:42 --> Total execution time: 0.1417
ERROR - 2023-06-27 08:35:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:35:43 --> Config Class Initialized
INFO - 2023-06-27 08:35:43 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:35:43 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:35:43 --> Utf8 Class Initialized
INFO - 2023-06-27 08:35:43 --> URI Class Initialized
INFO - 2023-06-27 08:35:43 --> Router Class Initialized
INFO - 2023-06-27 08:35:43 --> Output Class Initialized
INFO - 2023-06-27 08:35:43 --> Security Class Initialized
DEBUG - 2023-06-27 08:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:35:43 --> Input Class Initialized
INFO - 2023-06-27 08:35:43 --> Language Class Initialized
INFO - 2023-06-27 08:35:43 --> Loader Class Initialized
INFO - 2023-06-27 08:35:43 --> Helper loaded: url_helper
INFO - 2023-06-27 08:35:43 --> Helper loaded: file_helper
INFO - 2023-06-27 08:35:43 --> Helper loaded: html_helper
INFO - 2023-06-27 08:35:43 --> Helper loaded: text_helper
INFO - 2023-06-27 08:35:43 --> Helper loaded: form_helper
INFO - 2023-06-27 08:35:43 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:35:43 --> Helper loaded: security_helper
INFO - 2023-06-27 08:35:43 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:35:43 --> Database Driver Class Initialized
INFO - 2023-06-27 08:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:35:43 --> Parser Class Initialized
INFO - 2023-06-27 08:35:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:35:43 --> Pagination Class Initialized
INFO - 2023-06-27 08:35:43 --> Form Validation Class Initialized
INFO - 2023-06-27 08:35:43 --> Controller Class Initialized
INFO - 2023-06-27 08:35:43 --> Model Class Initialized
DEBUG - 2023-06-27 08:35:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:35:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:35:43 --> Model Class Initialized
DEBUG - 2023-06-27 08:35:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:35:43 --> Model Class Initialized
INFO - 2023-06-27 08:35:43 --> Final output sent to browser
DEBUG - 2023-06-27 08:35:43 --> Total execution time: 0.0512
ERROR - 2023-06-27 08:35:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:35:49 --> Config Class Initialized
INFO - 2023-06-27 08:35:49 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:35:49 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:35:49 --> Utf8 Class Initialized
INFO - 2023-06-27 08:35:49 --> URI Class Initialized
INFO - 2023-06-27 08:35:49 --> Router Class Initialized
INFO - 2023-06-27 08:35:49 --> Output Class Initialized
INFO - 2023-06-27 08:35:49 --> Security Class Initialized
DEBUG - 2023-06-27 08:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:35:49 --> Input Class Initialized
INFO - 2023-06-27 08:35:49 --> Language Class Initialized
INFO - 2023-06-27 08:35:49 --> Loader Class Initialized
INFO - 2023-06-27 08:35:49 --> Helper loaded: url_helper
INFO - 2023-06-27 08:35:49 --> Helper loaded: file_helper
INFO - 2023-06-27 08:35:49 --> Helper loaded: html_helper
INFO - 2023-06-27 08:35:49 --> Helper loaded: text_helper
INFO - 2023-06-27 08:35:49 --> Helper loaded: form_helper
INFO - 2023-06-27 08:35:49 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:35:49 --> Helper loaded: security_helper
INFO - 2023-06-27 08:35:49 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:35:49 --> Database Driver Class Initialized
INFO - 2023-06-27 08:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:35:49 --> Parser Class Initialized
INFO - 2023-06-27 08:35:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:35:49 --> Pagination Class Initialized
INFO - 2023-06-27 08:35:49 --> Form Validation Class Initialized
INFO - 2023-06-27 08:35:49 --> Controller Class Initialized
INFO - 2023-06-27 08:35:49 --> Model Class Initialized
DEBUG - 2023-06-27 08:35:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:35:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:35:49 --> Model Class Initialized
DEBUG - 2023-06-27 08:35:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:35:49 --> Model Class Initialized
DEBUG - 2023-06-27 08:35:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:35:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-06-27 08:35:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:35:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:35:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:35:49 --> Model Class Initialized
INFO - 2023-06-27 08:35:49 --> Model Class Initialized
INFO - 2023-06-27 08:35:49 --> Model Class Initialized
INFO - 2023-06-27 08:35:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:35:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:35:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:35:49 --> Final output sent to browser
DEBUG - 2023-06-27 08:35:49 --> Total execution time: 0.1319
ERROR - 2023-06-27 08:37:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:37:53 --> Config Class Initialized
INFO - 2023-06-27 08:37:53 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:37:53 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:37:53 --> Utf8 Class Initialized
INFO - 2023-06-27 08:37:53 --> URI Class Initialized
DEBUG - 2023-06-27 08:37:53 --> No URI present. Default controller set.
INFO - 2023-06-27 08:37:53 --> Router Class Initialized
INFO - 2023-06-27 08:37:53 --> Output Class Initialized
INFO - 2023-06-27 08:37:53 --> Security Class Initialized
DEBUG - 2023-06-27 08:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:37:53 --> Input Class Initialized
INFO - 2023-06-27 08:37:53 --> Language Class Initialized
INFO - 2023-06-27 08:37:53 --> Loader Class Initialized
INFO - 2023-06-27 08:37:53 --> Helper loaded: url_helper
INFO - 2023-06-27 08:37:53 --> Helper loaded: file_helper
INFO - 2023-06-27 08:37:53 --> Helper loaded: html_helper
INFO - 2023-06-27 08:37:53 --> Helper loaded: text_helper
INFO - 2023-06-27 08:37:53 --> Helper loaded: form_helper
INFO - 2023-06-27 08:37:53 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:37:53 --> Helper loaded: security_helper
INFO - 2023-06-27 08:37:53 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:37:53 --> Database Driver Class Initialized
INFO - 2023-06-27 08:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:37:53 --> Parser Class Initialized
INFO - 2023-06-27 08:37:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:37:53 --> Pagination Class Initialized
INFO - 2023-06-27 08:37:53 --> Form Validation Class Initialized
INFO - 2023-06-27 08:37:53 --> Controller Class Initialized
INFO - 2023-06-27 08:37:53 --> Model Class Initialized
DEBUG - 2023-06-27 08:37:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:37:53 --> Model Class Initialized
DEBUG - 2023-06-27 08:37:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:37:53 --> Model Class Initialized
INFO - 2023-06-27 08:37:53 --> Model Class Initialized
INFO - 2023-06-27 08:37:53 --> Model Class Initialized
INFO - 2023-06-27 08:37:53 --> Model Class Initialized
DEBUG - 2023-06-27 08:37:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:37:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:37:53 --> Model Class Initialized
INFO - 2023-06-27 08:37:53 --> Model Class Initialized
INFO - 2023-06-27 08:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 08:37:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:37:53 --> Model Class Initialized
INFO - 2023-06-27 08:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:37:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:37:53 --> Final output sent to browser
DEBUG - 2023-06-27 08:37:53 --> Total execution time: 0.0775
ERROR - 2023-06-27 08:38:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:38:00 --> Config Class Initialized
INFO - 2023-06-27 08:38:00 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:38:00 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:38:00 --> Utf8 Class Initialized
INFO - 2023-06-27 08:38:00 --> URI Class Initialized
INFO - 2023-06-27 08:38:00 --> Router Class Initialized
INFO - 2023-06-27 08:38:00 --> Output Class Initialized
INFO - 2023-06-27 08:38:00 --> Security Class Initialized
DEBUG - 2023-06-27 08:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:38:00 --> Input Class Initialized
INFO - 2023-06-27 08:38:00 --> Language Class Initialized
INFO - 2023-06-27 08:38:00 --> Loader Class Initialized
INFO - 2023-06-27 08:38:00 --> Helper loaded: url_helper
INFO - 2023-06-27 08:38:00 --> Helper loaded: file_helper
INFO - 2023-06-27 08:38:00 --> Helper loaded: html_helper
INFO - 2023-06-27 08:38:00 --> Helper loaded: text_helper
INFO - 2023-06-27 08:38:00 --> Helper loaded: form_helper
INFO - 2023-06-27 08:38:00 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:38:00 --> Helper loaded: security_helper
INFO - 2023-06-27 08:38:00 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:38:00 --> Database Driver Class Initialized
INFO - 2023-06-27 08:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:38:00 --> Parser Class Initialized
INFO - 2023-06-27 08:38:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:38:00 --> Pagination Class Initialized
INFO - 2023-06-27 08:38:00 --> Form Validation Class Initialized
INFO - 2023-06-27 08:38:00 --> Controller Class Initialized
INFO - 2023-06-27 08:38:00 --> Model Class Initialized
DEBUG - 2023-06-27 08:38:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:38:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:38:00 --> Model Class Initialized
DEBUG - 2023-06-27 08:38:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:38:00 --> Model Class Initialized
INFO - 2023-06-27 08:38:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-27 08:38:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:38:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:38:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:38:00 --> Model Class Initialized
INFO - 2023-06-27 08:38:00 --> Model Class Initialized
INFO - 2023-06-27 08:38:00 --> Model Class Initialized
INFO - 2023-06-27 08:38:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:38:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:38:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:38:00 --> Final output sent to browser
DEBUG - 2023-06-27 08:38:00 --> Total execution time: 0.0663
ERROR - 2023-06-27 08:38:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:38:01 --> Config Class Initialized
INFO - 2023-06-27 08:38:01 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:38:01 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:38:01 --> Utf8 Class Initialized
INFO - 2023-06-27 08:38:01 --> URI Class Initialized
INFO - 2023-06-27 08:38:01 --> Router Class Initialized
INFO - 2023-06-27 08:38:01 --> Output Class Initialized
INFO - 2023-06-27 08:38:01 --> Security Class Initialized
DEBUG - 2023-06-27 08:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:38:01 --> Input Class Initialized
INFO - 2023-06-27 08:38:01 --> Language Class Initialized
INFO - 2023-06-27 08:38:01 --> Loader Class Initialized
INFO - 2023-06-27 08:38:01 --> Helper loaded: url_helper
INFO - 2023-06-27 08:38:01 --> Helper loaded: file_helper
INFO - 2023-06-27 08:38:01 --> Helper loaded: html_helper
INFO - 2023-06-27 08:38:01 --> Helper loaded: text_helper
INFO - 2023-06-27 08:38:01 --> Helper loaded: form_helper
INFO - 2023-06-27 08:38:01 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:38:01 --> Helper loaded: security_helper
INFO - 2023-06-27 08:38:01 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:38:01 --> Database Driver Class Initialized
INFO - 2023-06-27 08:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:38:01 --> Parser Class Initialized
INFO - 2023-06-27 08:38:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:38:01 --> Pagination Class Initialized
INFO - 2023-06-27 08:38:01 --> Form Validation Class Initialized
INFO - 2023-06-27 08:38:01 --> Controller Class Initialized
INFO - 2023-06-27 08:38:01 --> Model Class Initialized
DEBUG - 2023-06-27 08:38:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:38:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:38:01 --> Model Class Initialized
DEBUG - 2023-06-27 08:38:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:38:01 --> Model Class Initialized
INFO - 2023-06-27 08:38:01 --> Final output sent to browser
DEBUG - 2023-06-27 08:38:01 --> Total execution time: 0.0384
ERROR - 2023-06-27 08:38:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:38:07 --> Config Class Initialized
INFO - 2023-06-27 08:38:07 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:38:07 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:38:07 --> Utf8 Class Initialized
INFO - 2023-06-27 08:38:07 --> URI Class Initialized
INFO - 2023-06-27 08:38:07 --> Router Class Initialized
INFO - 2023-06-27 08:38:07 --> Output Class Initialized
INFO - 2023-06-27 08:38:07 --> Security Class Initialized
DEBUG - 2023-06-27 08:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:38:07 --> Input Class Initialized
INFO - 2023-06-27 08:38:07 --> Language Class Initialized
INFO - 2023-06-27 08:38:07 --> Loader Class Initialized
INFO - 2023-06-27 08:38:07 --> Helper loaded: url_helper
INFO - 2023-06-27 08:38:07 --> Helper loaded: file_helper
INFO - 2023-06-27 08:38:07 --> Helper loaded: html_helper
INFO - 2023-06-27 08:38:07 --> Helper loaded: text_helper
INFO - 2023-06-27 08:38:07 --> Helper loaded: form_helper
INFO - 2023-06-27 08:38:07 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:38:07 --> Helper loaded: security_helper
INFO - 2023-06-27 08:38:07 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:38:07 --> Database Driver Class Initialized
INFO - 2023-06-27 08:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:38:07 --> Parser Class Initialized
INFO - 2023-06-27 08:38:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:38:07 --> Pagination Class Initialized
INFO - 2023-06-27 08:38:07 --> Form Validation Class Initialized
INFO - 2023-06-27 08:38:07 --> Controller Class Initialized
INFO - 2023-06-27 08:38:07 --> Model Class Initialized
DEBUG - 2023-06-27 08:38:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:38:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:38:07 --> Model Class Initialized
DEBUG - 2023-06-27 08:38:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:38:07 --> Model Class Initialized
INFO - 2023-06-27 08:38:08 --> Final output sent to browser
DEBUG - 2023-06-27 08:38:08 --> Total execution time: 0.1156
ERROR - 2023-06-27 08:38:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:38:15 --> Config Class Initialized
INFO - 2023-06-27 08:38:15 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:38:15 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:38:15 --> Utf8 Class Initialized
INFO - 2023-06-27 08:38:15 --> URI Class Initialized
INFO - 2023-06-27 08:38:15 --> Router Class Initialized
INFO - 2023-06-27 08:38:15 --> Output Class Initialized
INFO - 2023-06-27 08:38:15 --> Security Class Initialized
DEBUG - 2023-06-27 08:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:38:15 --> Input Class Initialized
INFO - 2023-06-27 08:38:15 --> Language Class Initialized
INFO - 2023-06-27 08:38:15 --> Loader Class Initialized
INFO - 2023-06-27 08:38:15 --> Helper loaded: url_helper
INFO - 2023-06-27 08:38:15 --> Helper loaded: file_helper
INFO - 2023-06-27 08:38:15 --> Helper loaded: html_helper
INFO - 2023-06-27 08:38:15 --> Helper loaded: text_helper
INFO - 2023-06-27 08:38:15 --> Helper loaded: form_helper
INFO - 2023-06-27 08:38:15 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:38:15 --> Helper loaded: security_helper
INFO - 2023-06-27 08:38:15 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:38:15 --> Database Driver Class Initialized
INFO - 2023-06-27 08:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:38:15 --> Parser Class Initialized
INFO - 2023-06-27 08:38:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:38:15 --> Pagination Class Initialized
INFO - 2023-06-27 08:38:15 --> Form Validation Class Initialized
INFO - 2023-06-27 08:38:15 --> Controller Class Initialized
INFO - 2023-06-27 08:38:15 --> Model Class Initialized
DEBUG - 2023-06-27 08:38:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:38:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:38:15 --> Model Class Initialized
DEBUG - 2023-06-27 08:38:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:38:15 --> Model Class Initialized
DEBUG - 2023-06-27 08:38:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:38:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-06-27 08:38:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:38:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:38:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:38:16 --> Model Class Initialized
INFO - 2023-06-27 08:38:16 --> Model Class Initialized
INFO - 2023-06-27 08:38:16 --> Model Class Initialized
INFO - 2023-06-27 08:38:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:38:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:38:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:38:16 --> Final output sent to browser
DEBUG - 2023-06-27 08:38:16 --> Total execution time: 0.0720
ERROR - 2023-06-27 08:38:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:38:51 --> Config Class Initialized
INFO - 2023-06-27 08:38:51 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:38:51 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:38:51 --> Utf8 Class Initialized
INFO - 2023-06-27 08:38:51 --> URI Class Initialized
DEBUG - 2023-06-27 08:38:51 --> No URI present. Default controller set.
INFO - 2023-06-27 08:38:51 --> Router Class Initialized
INFO - 2023-06-27 08:38:51 --> Output Class Initialized
INFO - 2023-06-27 08:38:51 --> Security Class Initialized
DEBUG - 2023-06-27 08:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:38:51 --> Input Class Initialized
INFO - 2023-06-27 08:38:51 --> Language Class Initialized
INFO - 2023-06-27 08:38:51 --> Loader Class Initialized
INFO - 2023-06-27 08:38:51 --> Helper loaded: url_helper
INFO - 2023-06-27 08:38:51 --> Helper loaded: file_helper
INFO - 2023-06-27 08:38:51 --> Helper loaded: html_helper
INFO - 2023-06-27 08:38:51 --> Helper loaded: text_helper
INFO - 2023-06-27 08:38:51 --> Helper loaded: form_helper
INFO - 2023-06-27 08:38:51 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:38:51 --> Helper loaded: security_helper
INFO - 2023-06-27 08:38:51 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:38:51 --> Database Driver Class Initialized
INFO - 2023-06-27 08:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:38:51 --> Parser Class Initialized
INFO - 2023-06-27 08:38:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:38:51 --> Pagination Class Initialized
INFO - 2023-06-27 08:38:51 --> Form Validation Class Initialized
INFO - 2023-06-27 08:38:51 --> Controller Class Initialized
INFO - 2023-06-27 08:38:51 --> Model Class Initialized
DEBUG - 2023-06-27 08:38:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:38:51 --> Model Class Initialized
DEBUG - 2023-06-27 08:38:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:38:51 --> Model Class Initialized
INFO - 2023-06-27 08:38:51 --> Model Class Initialized
INFO - 2023-06-27 08:38:51 --> Model Class Initialized
INFO - 2023-06-27 08:38:51 --> Model Class Initialized
DEBUG - 2023-06-27 08:38:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:38:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:38:51 --> Model Class Initialized
INFO - 2023-06-27 08:38:51 --> Model Class Initialized
INFO - 2023-06-27 08:38:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 08:38:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:38:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:38:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:38:51 --> Model Class Initialized
INFO - 2023-06-27 08:38:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:38:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:38:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:38:51 --> Final output sent to browser
DEBUG - 2023-06-27 08:38:51 --> Total execution time: 0.1590
ERROR - 2023-06-27 08:38:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:38:57 --> Config Class Initialized
INFO - 2023-06-27 08:38:57 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:38:57 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:38:57 --> Utf8 Class Initialized
INFO - 2023-06-27 08:38:57 --> URI Class Initialized
INFO - 2023-06-27 08:38:57 --> Router Class Initialized
INFO - 2023-06-27 08:38:57 --> Output Class Initialized
INFO - 2023-06-27 08:38:57 --> Security Class Initialized
DEBUG - 2023-06-27 08:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:38:57 --> Input Class Initialized
INFO - 2023-06-27 08:38:57 --> Language Class Initialized
INFO - 2023-06-27 08:38:57 --> Loader Class Initialized
INFO - 2023-06-27 08:38:57 --> Helper loaded: url_helper
INFO - 2023-06-27 08:38:57 --> Helper loaded: file_helper
INFO - 2023-06-27 08:38:57 --> Helper loaded: html_helper
INFO - 2023-06-27 08:38:57 --> Helper loaded: text_helper
INFO - 2023-06-27 08:38:57 --> Helper loaded: form_helper
INFO - 2023-06-27 08:38:57 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:38:57 --> Helper loaded: security_helper
INFO - 2023-06-27 08:38:57 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:38:57 --> Database Driver Class Initialized
INFO - 2023-06-27 08:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:38:57 --> Parser Class Initialized
INFO - 2023-06-27 08:38:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:38:57 --> Pagination Class Initialized
INFO - 2023-06-27 08:38:57 --> Form Validation Class Initialized
INFO - 2023-06-27 08:38:57 --> Controller Class Initialized
INFO - 2023-06-27 08:38:57 --> Model Class Initialized
DEBUG - 2023-06-27 08:38:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:38:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:38:57 --> Model Class Initialized
DEBUG - 2023-06-27 08:38:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:38:57 --> Model Class Initialized
INFO - 2023-06-27 08:38:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-27 08:38:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:38:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:38:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:38:57 --> Model Class Initialized
INFO - 2023-06-27 08:38:57 --> Model Class Initialized
INFO - 2023-06-27 08:38:57 --> Model Class Initialized
INFO - 2023-06-27 08:38:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:38:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:38:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:38:57 --> Final output sent to browser
DEBUG - 2023-06-27 08:38:57 --> Total execution time: 0.1348
ERROR - 2023-06-27 08:38:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:38:57 --> Config Class Initialized
INFO - 2023-06-27 08:38:57 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:38:57 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:38:57 --> Utf8 Class Initialized
INFO - 2023-06-27 08:38:57 --> URI Class Initialized
INFO - 2023-06-27 08:38:57 --> Router Class Initialized
INFO - 2023-06-27 08:38:57 --> Output Class Initialized
INFO - 2023-06-27 08:38:57 --> Security Class Initialized
DEBUG - 2023-06-27 08:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:38:57 --> Input Class Initialized
INFO - 2023-06-27 08:38:57 --> Language Class Initialized
INFO - 2023-06-27 08:38:57 --> Loader Class Initialized
INFO - 2023-06-27 08:38:57 --> Helper loaded: url_helper
INFO - 2023-06-27 08:38:57 --> Helper loaded: file_helper
INFO - 2023-06-27 08:38:57 --> Helper loaded: html_helper
INFO - 2023-06-27 08:38:57 --> Helper loaded: text_helper
INFO - 2023-06-27 08:38:57 --> Helper loaded: form_helper
INFO - 2023-06-27 08:38:57 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:38:57 --> Helper loaded: security_helper
INFO - 2023-06-27 08:38:57 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:38:57 --> Database Driver Class Initialized
INFO - 2023-06-27 08:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:38:57 --> Parser Class Initialized
INFO - 2023-06-27 08:38:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:38:57 --> Pagination Class Initialized
INFO - 2023-06-27 08:38:57 --> Form Validation Class Initialized
INFO - 2023-06-27 08:38:57 --> Controller Class Initialized
INFO - 2023-06-27 08:38:57 --> Model Class Initialized
DEBUG - 2023-06-27 08:38:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:38:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:38:57 --> Model Class Initialized
DEBUG - 2023-06-27 08:38:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:38:57 --> Model Class Initialized
INFO - 2023-06-27 08:38:57 --> Final output sent to browser
DEBUG - 2023-06-27 08:38:57 --> Total execution time: 0.0512
ERROR - 2023-06-27 08:39:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:39:08 --> Config Class Initialized
INFO - 2023-06-27 08:39:08 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:39:08 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:39:08 --> Utf8 Class Initialized
INFO - 2023-06-27 08:39:08 --> URI Class Initialized
INFO - 2023-06-27 08:39:08 --> Router Class Initialized
INFO - 2023-06-27 08:39:08 --> Output Class Initialized
INFO - 2023-06-27 08:39:08 --> Security Class Initialized
DEBUG - 2023-06-27 08:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:39:08 --> Input Class Initialized
INFO - 2023-06-27 08:39:08 --> Language Class Initialized
INFO - 2023-06-27 08:39:08 --> Loader Class Initialized
INFO - 2023-06-27 08:39:08 --> Helper loaded: url_helper
INFO - 2023-06-27 08:39:08 --> Helper loaded: file_helper
INFO - 2023-06-27 08:39:08 --> Helper loaded: html_helper
INFO - 2023-06-27 08:39:08 --> Helper loaded: text_helper
INFO - 2023-06-27 08:39:08 --> Helper loaded: form_helper
INFO - 2023-06-27 08:39:08 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:39:08 --> Helper loaded: security_helper
INFO - 2023-06-27 08:39:08 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:39:08 --> Database Driver Class Initialized
INFO - 2023-06-27 08:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:39:08 --> Parser Class Initialized
INFO - 2023-06-27 08:39:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:39:08 --> Pagination Class Initialized
INFO - 2023-06-27 08:39:08 --> Form Validation Class Initialized
INFO - 2023-06-27 08:39:08 --> Controller Class Initialized
INFO - 2023-06-27 08:39:08 --> Model Class Initialized
DEBUG - 2023-06-27 08:39:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:39:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:39:08 --> Model Class Initialized
DEBUG - 2023-06-27 08:39:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:39:08 --> Model Class Initialized
INFO - 2023-06-27 08:39:08 --> Final output sent to browser
DEBUG - 2023-06-27 08:39:08 --> Total execution time: 0.2597
ERROR - 2023-06-27 08:39:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:39:21 --> Config Class Initialized
INFO - 2023-06-27 08:39:21 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:39:21 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:39:21 --> Utf8 Class Initialized
INFO - 2023-06-27 08:39:21 --> URI Class Initialized
INFO - 2023-06-27 08:39:21 --> Router Class Initialized
INFO - 2023-06-27 08:39:21 --> Output Class Initialized
INFO - 2023-06-27 08:39:21 --> Security Class Initialized
DEBUG - 2023-06-27 08:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:39:21 --> Input Class Initialized
INFO - 2023-06-27 08:39:21 --> Language Class Initialized
INFO - 2023-06-27 08:39:21 --> Loader Class Initialized
INFO - 2023-06-27 08:39:21 --> Helper loaded: url_helper
INFO - 2023-06-27 08:39:21 --> Helper loaded: file_helper
INFO - 2023-06-27 08:39:21 --> Helper loaded: html_helper
INFO - 2023-06-27 08:39:21 --> Helper loaded: text_helper
INFO - 2023-06-27 08:39:21 --> Helper loaded: form_helper
INFO - 2023-06-27 08:39:21 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:39:21 --> Helper loaded: security_helper
INFO - 2023-06-27 08:39:21 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:39:21 --> Database Driver Class Initialized
INFO - 2023-06-27 08:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:39:21 --> Parser Class Initialized
INFO - 2023-06-27 08:39:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:39:21 --> Pagination Class Initialized
INFO - 2023-06-27 08:39:21 --> Form Validation Class Initialized
INFO - 2023-06-27 08:39:21 --> Controller Class Initialized
INFO - 2023-06-27 08:39:21 --> Model Class Initialized
DEBUG - 2023-06-27 08:39:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:39:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:39:21 --> Model Class Initialized
DEBUG - 2023-06-27 08:39:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:39:21 --> Model Class Initialized
DEBUG - 2023-06-27 08:39:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:39:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-06-27 08:39:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:39:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:39:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:39:21 --> Model Class Initialized
INFO - 2023-06-27 08:39:21 --> Model Class Initialized
INFO - 2023-06-27 08:39:21 --> Model Class Initialized
INFO - 2023-06-27 08:39:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:39:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:39:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:39:21 --> Final output sent to browser
DEBUG - 2023-06-27 08:39:21 --> Total execution time: 0.1292
ERROR - 2023-06-27 08:39:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:39:37 --> Config Class Initialized
INFO - 2023-06-27 08:39:37 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:39:37 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:39:37 --> Utf8 Class Initialized
INFO - 2023-06-27 08:39:37 --> URI Class Initialized
INFO - 2023-06-27 08:39:37 --> Router Class Initialized
INFO - 2023-06-27 08:39:37 --> Output Class Initialized
INFO - 2023-06-27 08:39:37 --> Security Class Initialized
DEBUG - 2023-06-27 08:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:39:37 --> Input Class Initialized
INFO - 2023-06-27 08:39:37 --> Language Class Initialized
INFO - 2023-06-27 08:39:37 --> Loader Class Initialized
INFO - 2023-06-27 08:39:37 --> Helper loaded: url_helper
INFO - 2023-06-27 08:39:37 --> Helper loaded: file_helper
INFO - 2023-06-27 08:39:37 --> Helper loaded: html_helper
INFO - 2023-06-27 08:39:37 --> Helper loaded: text_helper
INFO - 2023-06-27 08:39:37 --> Helper loaded: form_helper
INFO - 2023-06-27 08:39:37 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:39:37 --> Helper loaded: security_helper
INFO - 2023-06-27 08:39:37 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:39:37 --> Database Driver Class Initialized
INFO - 2023-06-27 08:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:39:37 --> Parser Class Initialized
INFO - 2023-06-27 08:39:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:39:37 --> Pagination Class Initialized
INFO - 2023-06-27 08:39:37 --> Form Validation Class Initialized
INFO - 2023-06-27 08:39:37 --> Controller Class Initialized
INFO - 2023-06-27 08:39:37 --> Model Class Initialized
DEBUG - 2023-06-27 08:39:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:39:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:39:37 --> Model Class Initialized
DEBUG - 2023-06-27 08:39:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:39:37 --> Model Class Initialized
INFO - 2023-06-27 08:39:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-27 08:39:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:39:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:39:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:39:37 --> Model Class Initialized
INFO - 2023-06-27 08:39:37 --> Model Class Initialized
INFO - 2023-06-27 08:39:37 --> Model Class Initialized
INFO - 2023-06-27 08:39:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:39:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:39:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:39:37 --> Final output sent to browser
DEBUG - 2023-06-27 08:39:37 --> Total execution time: 0.1385
ERROR - 2023-06-27 08:39:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:39:38 --> Config Class Initialized
INFO - 2023-06-27 08:39:38 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:39:38 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:39:38 --> Utf8 Class Initialized
INFO - 2023-06-27 08:39:38 --> URI Class Initialized
INFO - 2023-06-27 08:39:38 --> Router Class Initialized
INFO - 2023-06-27 08:39:38 --> Output Class Initialized
INFO - 2023-06-27 08:39:38 --> Security Class Initialized
DEBUG - 2023-06-27 08:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:39:38 --> Input Class Initialized
INFO - 2023-06-27 08:39:38 --> Language Class Initialized
INFO - 2023-06-27 08:39:38 --> Loader Class Initialized
INFO - 2023-06-27 08:39:38 --> Helper loaded: url_helper
INFO - 2023-06-27 08:39:38 --> Helper loaded: file_helper
INFO - 2023-06-27 08:39:38 --> Helper loaded: html_helper
INFO - 2023-06-27 08:39:38 --> Helper loaded: text_helper
INFO - 2023-06-27 08:39:38 --> Helper loaded: form_helper
INFO - 2023-06-27 08:39:38 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:39:38 --> Helper loaded: security_helper
INFO - 2023-06-27 08:39:38 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:39:38 --> Database Driver Class Initialized
INFO - 2023-06-27 08:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:39:38 --> Parser Class Initialized
INFO - 2023-06-27 08:39:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:39:38 --> Pagination Class Initialized
INFO - 2023-06-27 08:39:38 --> Form Validation Class Initialized
INFO - 2023-06-27 08:39:38 --> Controller Class Initialized
INFO - 2023-06-27 08:39:38 --> Model Class Initialized
DEBUG - 2023-06-27 08:39:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:39:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:39:38 --> Model Class Initialized
DEBUG - 2023-06-27 08:39:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:39:38 --> Model Class Initialized
INFO - 2023-06-27 08:39:39 --> Final output sent to browser
DEBUG - 2023-06-27 08:39:39 --> Total execution time: 0.0551
ERROR - 2023-06-27 08:39:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:39:41 --> Config Class Initialized
INFO - 2023-06-27 08:39:41 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:39:41 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:39:41 --> Utf8 Class Initialized
INFO - 2023-06-27 08:39:41 --> URI Class Initialized
INFO - 2023-06-27 08:39:41 --> Router Class Initialized
INFO - 2023-06-27 08:39:41 --> Output Class Initialized
INFO - 2023-06-27 08:39:41 --> Security Class Initialized
DEBUG - 2023-06-27 08:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:39:41 --> Input Class Initialized
INFO - 2023-06-27 08:39:41 --> Language Class Initialized
INFO - 2023-06-27 08:39:41 --> Loader Class Initialized
INFO - 2023-06-27 08:39:41 --> Helper loaded: url_helper
INFO - 2023-06-27 08:39:41 --> Helper loaded: file_helper
INFO - 2023-06-27 08:39:41 --> Helper loaded: html_helper
INFO - 2023-06-27 08:39:41 --> Helper loaded: text_helper
INFO - 2023-06-27 08:39:41 --> Helper loaded: form_helper
INFO - 2023-06-27 08:39:41 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:39:41 --> Helper loaded: security_helper
INFO - 2023-06-27 08:39:41 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:39:41 --> Database Driver Class Initialized
INFO - 2023-06-27 08:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:39:41 --> Parser Class Initialized
INFO - 2023-06-27 08:39:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:39:41 --> Pagination Class Initialized
INFO - 2023-06-27 08:39:41 --> Form Validation Class Initialized
INFO - 2023-06-27 08:39:41 --> Controller Class Initialized
INFO - 2023-06-27 08:39:41 --> Model Class Initialized
DEBUG - 2023-06-27 08:39:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:39:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:39:41 --> Model Class Initialized
DEBUG - 2023-06-27 08:39:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:39:41 --> Model Class Initialized
INFO - 2023-06-27 08:39:41 --> Final output sent to browser
DEBUG - 2023-06-27 08:39:41 --> Total execution time: 0.2490
ERROR - 2023-06-27 08:39:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:39:54 --> Config Class Initialized
INFO - 2023-06-27 08:39:54 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:39:54 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:39:54 --> Utf8 Class Initialized
INFO - 2023-06-27 08:39:54 --> URI Class Initialized
INFO - 2023-06-27 08:39:54 --> Router Class Initialized
INFO - 2023-06-27 08:39:54 --> Output Class Initialized
INFO - 2023-06-27 08:39:54 --> Security Class Initialized
DEBUG - 2023-06-27 08:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:39:54 --> Input Class Initialized
INFO - 2023-06-27 08:39:54 --> Language Class Initialized
INFO - 2023-06-27 08:39:54 --> Loader Class Initialized
INFO - 2023-06-27 08:39:54 --> Helper loaded: url_helper
INFO - 2023-06-27 08:39:54 --> Helper loaded: file_helper
INFO - 2023-06-27 08:39:54 --> Helper loaded: html_helper
INFO - 2023-06-27 08:39:54 --> Helper loaded: text_helper
INFO - 2023-06-27 08:39:54 --> Helper loaded: form_helper
INFO - 2023-06-27 08:39:54 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:39:54 --> Helper loaded: security_helper
INFO - 2023-06-27 08:39:54 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:39:54 --> Database Driver Class Initialized
INFO - 2023-06-27 08:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:39:54 --> Parser Class Initialized
INFO - 2023-06-27 08:39:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:39:54 --> Pagination Class Initialized
INFO - 2023-06-27 08:39:54 --> Form Validation Class Initialized
INFO - 2023-06-27 08:39:54 --> Controller Class Initialized
INFO - 2023-06-27 08:39:54 --> Model Class Initialized
DEBUG - 2023-06-27 08:39:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:39:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:39:54 --> Model Class Initialized
DEBUG - 2023-06-27 08:39:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:39:54 --> Model Class Initialized
DEBUG - 2023-06-27 08:39:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:39:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-06-27 08:39:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:39:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:39:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:39:54 --> Model Class Initialized
INFO - 2023-06-27 08:39:54 --> Model Class Initialized
INFO - 2023-06-27 08:39:54 --> Model Class Initialized
INFO - 2023-06-27 08:39:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:39:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:39:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:39:54 --> Final output sent to browser
DEBUG - 2023-06-27 08:39:54 --> Total execution time: 0.1340
ERROR - 2023-06-27 08:40:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:40:21 --> Config Class Initialized
INFO - 2023-06-27 08:40:21 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:40:21 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:40:21 --> Utf8 Class Initialized
INFO - 2023-06-27 08:40:21 --> URI Class Initialized
INFO - 2023-06-27 08:40:21 --> Router Class Initialized
INFO - 2023-06-27 08:40:21 --> Output Class Initialized
INFO - 2023-06-27 08:40:21 --> Security Class Initialized
DEBUG - 2023-06-27 08:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:40:21 --> Input Class Initialized
INFO - 2023-06-27 08:40:21 --> Language Class Initialized
INFO - 2023-06-27 08:40:21 --> Loader Class Initialized
INFO - 2023-06-27 08:40:21 --> Helper loaded: url_helper
INFO - 2023-06-27 08:40:21 --> Helper loaded: file_helper
INFO - 2023-06-27 08:40:21 --> Helper loaded: html_helper
INFO - 2023-06-27 08:40:21 --> Helper loaded: text_helper
INFO - 2023-06-27 08:40:21 --> Helper loaded: form_helper
INFO - 2023-06-27 08:40:21 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:40:21 --> Helper loaded: security_helper
INFO - 2023-06-27 08:40:21 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:40:21 --> Database Driver Class Initialized
INFO - 2023-06-27 08:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:40:21 --> Parser Class Initialized
INFO - 2023-06-27 08:40:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:40:21 --> Pagination Class Initialized
INFO - 2023-06-27 08:40:21 --> Form Validation Class Initialized
INFO - 2023-06-27 08:40:21 --> Controller Class Initialized
INFO - 2023-06-27 08:40:21 --> Model Class Initialized
DEBUG - 2023-06-27 08:40:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:40:21 --> Model Class Initialized
DEBUG - 2023-06-27 08:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:40:21 --> Model Class Initialized
INFO - 2023-06-27 08:40:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-27 08:40:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:40:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:40:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:40:21 --> Model Class Initialized
INFO - 2023-06-27 08:40:21 --> Model Class Initialized
INFO - 2023-06-27 08:40:21 --> Model Class Initialized
INFO - 2023-06-27 08:40:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:40:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:40:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:40:21 --> Final output sent to browser
DEBUG - 2023-06-27 08:40:21 --> Total execution time: 0.1386
ERROR - 2023-06-27 08:40:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:40:22 --> Config Class Initialized
INFO - 2023-06-27 08:40:22 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:40:22 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:40:22 --> Utf8 Class Initialized
INFO - 2023-06-27 08:40:22 --> URI Class Initialized
INFO - 2023-06-27 08:40:22 --> Router Class Initialized
INFO - 2023-06-27 08:40:22 --> Output Class Initialized
INFO - 2023-06-27 08:40:22 --> Security Class Initialized
DEBUG - 2023-06-27 08:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:40:22 --> Input Class Initialized
INFO - 2023-06-27 08:40:22 --> Language Class Initialized
INFO - 2023-06-27 08:40:22 --> Loader Class Initialized
INFO - 2023-06-27 08:40:22 --> Helper loaded: url_helper
INFO - 2023-06-27 08:40:22 --> Helper loaded: file_helper
INFO - 2023-06-27 08:40:22 --> Helper loaded: html_helper
INFO - 2023-06-27 08:40:22 --> Helper loaded: text_helper
INFO - 2023-06-27 08:40:22 --> Helper loaded: form_helper
INFO - 2023-06-27 08:40:22 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:40:22 --> Helper loaded: security_helper
INFO - 2023-06-27 08:40:22 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:40:22 --> Database Driver Class Initialized
INFO - 2023-06-27 08:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:40:22 --> Parser Class Initialized
INFO - 2023-06-27 08:40:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:40:22 --> Pagination Class Initialized
INFO - 2023-06-27 08:40:22 --> Form Validation Class Initialized
INFO - 2023-06-27 08:40:22 --> Controller Class Initialized
INFO - 2023-06-27 08:40:22 --> Model Class Initialized
DEBUG - 2023-06-27 08:40:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:40:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:40:22 --> Model Class Initialized
DEBUG - 2023-06-27 08:40:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:40:22 --> Model Class Initialized
INFO - 2023-06-27 08:40:22 --> Final output sent to browser
DEBUG - 2023-06-27 08:40:22 --> Total execution time: 0.0581
ERROR - 2023-06-27 08:40:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:40:25 --> Config Class Initialized
INFO - 2023-06-27 08:40:25 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:40:25 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:40:25 --> Utf8 Class Initialized
INFO - 2023-06-27 08:40:25 --> URI Class Initialized
INFO - 2023-06-27 08:40:25 --> Router Class Initialized
INFO - 2023-06-27 08:40:25 --> Output Class Initialized
INFO - 2023-06-27 08:40:25 --> Security Class Initialized
DEBUG - 2023-06-27 08:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:40:25 --> Input Class Initialized
INFO - 2023-06-27 08:40:25 --> Language Class Initialized
INFO - 2023-06-27 08:40:25 --> Loader Class Initialized
INFO - 2023-06-27 08:40:25 --> Helper loaded: url_helper
INFO - 2023-06-27 08:40:25 --> Helper loaded: file_helper
INFO - 2023-06-27 08:40:25 --> Helper loaded: html_helper
INFO - 2023-06-27 08:40:25 --> Helper loaded: text_helper
INFO - 2023-06-27 08:40:25 --> Helper loaded: form_helper
INFO - 2023-06-27 08:40:25 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:40:25 --> Helper loaded: security_helper
INFO - 2023-06-27 08:40:25 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:40:25 --> Database Driver Class Initialized
INFO - 2023-06-27 08:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:40:25 --> Parser Class Initialized
INFO - 2023-06-27 08:40:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:40:25 --> Pagination Class Initialized
INFO - 2023-06-27 08:40:25 --> Form Validation Class Initialized
INFO - 2023-06-27 08:40:25 --> Controller Class Initialized
INFO - 2023-06-27 08:40:25 --> Model Class Initialized
DEBUG - 2023-06-27 08:40:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:40:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:40:25 --> Model Class Initialized
DEBUG - 2023-06-27 08:40:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:40:25 --> Model Class Initialized
INFO - 2023-06-27 08:40:26 --> Final output sent to browser
DEBUG - 2023-06-27 08:40:26 --> Total execution time: 0.2537
ERROR - 2023-06-27 08:40:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 08:40:37 --> Config Class Initialized
INFO - 2023-06-27 08:40:37 --> Hooks Class Initialized
DEBUG - 2023-06-27 08:40:37 --> UTF-8 Support Enabled
INFO - 2023-06-27 08:40:37 --> Utf8 Class Initialized
INFO - 2023-06-27 08:40:37 --> URI Class Initialized
INFO - 2023-06-27 08:40:37 --> Router Class Initialized
INFO - 2023-06-27 08:40:37 --> Output Class Initialized
INFO - 2023-06-27 08:40:37 --> Security Class Initialized
DEBUG - 2023-06-27 08:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 08:40:37 --> Input Class Initialized
INFO - 2023-06-27 08:40:37 --> Language Class Initialized
INFO - 2023-06-27 08:40:37 --> Loader Class Initialized
INFO - 2023-06-27 08:40:37 --> Helper loaded: url_helper
INFO - 2023-06-27 08:40:37 --> Helper loaded: file_helper
INFO - 2023-06-27 08:40:37 --> Helper loaded: html_helper
INFO - 2023-06-27 08:40:37 --> Helper loaded: text_helper
INFO - 2023-06-27 08:40:37 --> Helper loaded: form_helper
INFO - 2023-06-27 08:40:37 --> Helper loaded: lang_helper
INFO - 2023-06-27 08:40:37 --> Helper loaded: security_helper
INFO - 2023-06-27 08:40:37 --> Helper loaded: cookie_helper
INFO - 2023-06-27 08:40:37 --> Database Driver Class Initialized
INFO - 2023-06-27 08:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 08:40:37 --> Parser Class Initialized
INFO - 2023-06-27 08:40:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 08:40:37 --> Pagination Class Initialized
INFO - 2023-06-27 08:40:37 --> Form Validation Class Initialized
INFO - 2023-06-27 08:40:37 --> Controller Class Initialized
INFO - 2023-06-27 08:40:37 --> Model Class Initialized
DEBUG - 2023-06-27 08:40:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 08:40:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:40:37 --> Model Class Initialized
DEBUG - 2023-06-27 08:40:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:40:37 --> Model Class Initialized
DEBUG - 2023-06-27 08:40:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:40:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-06-27 08:40:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 08:40:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 08:40:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 08:40:37 --> Model Class Initialized
INFO - 2023-06-27 08:40:37 --> Model Class Initialized
INFO - 2023-06-27 08:40:37 --> Model Class Initialized
INFO - 2023-06-27 08:40:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 08:40:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 08:40:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 08:40:37 --> Final output sent to browser
DEBUG - 2023-06-27 08:40:37 --> Total execution time: 0.1525
ERROR - 2023-06-27 09:07:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:07:22 --> Config Class Initialized
INFO - 2023-06-27 09:07:22 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:07:22 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:07:22 --> Utf8 Class Initialized
INFO - 2023-06-27 09:07:22 --> URI Class Initialized
DEBUG - 2023-06-27 09:07:22 --> No URI present. Default controller set.
INFO - 2023-06-27 09:07:22 --> Router Class Initialized
INFO - 2023-06-27 09:07:22 --> Output Class Initialized
INFO - 2023-06-27 09:07:22 --> Security Class Initialized
DEBUG - 2023-06-27 09:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:07:22 --> Input Class Initialized
INFO - 2023-06-27 09:07:22 --> Language Class Initialized
INFO - 2023-06-27 09:07:22 --> Loader Class Initialized
INFO - 2023-06-27 09:07:22 --> Helper loaded: url_helper
INFO - 2023-06-27 09:07:22 --> Helper loaded: file_helper
INFO - 2023-06-27 09:07:22 --> Helper loaded: html_helper
INFO - 2023-06-27 09:07:22 --> Helper loaded: text_helper
INFO - 2023-06-27 09:07:22 --> Helper loaded: form_helper
INFO - 2023-06-27 09:07:22 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:07:22 --> Helper loaded: security_helper
INFO - 2023-06-27 09:07:22 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:07:22 --> Database Driver Class Initialized
INFO - 2023-06-27 09:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:07:22 --> Parser Class Initialized
INFO - 2023-06-27 09:07:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:07:22 --> Pagination Class Initialized
INFO - 2023-06-27 09:07:22 --> Form Validation Class Initialized
INFO - 2023-06-27 09:07:22 --> Controller Class Initialized
INFO - 2023-06-27 09:07:22 --> Model Class Initialized
DEBUG - 2023-06-27 09:07:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:07:22 --> Model Class Initialized
DEBUG - 2023-06-27 09:07:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:07:22 --> Model Class Initialized
INFO - 2023-06-27 09:07:22 --> Model Class Initialized
INFO - 2023-06-27 09:07:22 --> Model Class Initialized
INFO - 2023-06-27 09:07:22 --> Model Class Initialized
DEBUG - 2023-06-27 09:07:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:07:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:07:22 --> Model Class Initialized
INFO - 2023-06-27 09:07:22 --> Model Class Initialized
INFO - 2023-06-27 09:07:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 09:07:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:07:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 09:07:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 09:07:22 --> Model Class Initialized
INFO - 2023-06-27 09:07:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 09:07:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 09:07:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 09:07:22 --> Final output sent to browser
DEBUG - 2023-06-27 09:07:22 --> Total execution time: 0.0800
ERROR - 2023-06-27 09:07:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:07:29 --> Config Class Initialized
INFO - 2023-06-27 09:07:29 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:07:29 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:07:29 --> Utf8 Class Initialized
INFO - 2023-06-27 09:07:29 --> URI Class Initialized
INFO - 2023-06-27 09:07:29 --> Router Class Initialized
INFO - 2023-06-27 09:07:29 --> Output Class Initialized
INFO - 2023-06-27 09:07:29 --> Security Class Initialized
DEBUG - 2023-06-27 09:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:07:29 --> Input Class Initialized
INFO - 2023-06-27 09:07:29 --> Language Class Initialized
INFO - 2023-06-27 09:07:29 --> Loader Class Initialized
INFO - 2023-06-27 09:07:29 --> Helper loaded: url_helper
INFO - 2023-06-27 09:07:29 --> Helper loaded: file_helper
INFO - 2023-06-27 09:07:29 --> Helper loaded: html_helper
INFO - 2023-06-27 09:07:29 --> Helper loaded: text_helper
INFO - 2023-06-27 09:07:29 --> Helper loaded: form_helper
INFO - 2023-06-27 09:07:29 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:07:29 --> Helper loaded: security_helper
INFO - 2023-06-27 09:07:29 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:07:29 --> Database Driver Class Initialized
INFO - 2023-06-27 09:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:07:29 --> Parser Class Initialized
INFO - 2023-06-27 09:07:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:07:29 --> Pagination Class Initialized
INFO - 2023-06-27 09:07:29 --> Form Validation Class Initialized
INFO - 2023-06-27 09:07:29 --> Controller Class Initialized
INFO - 2023-06-27 09:07:29 --> Model Class Initialized
DEBUG - 2023-06-27 09:07:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:07:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:07:29 --> Model Class Initialized
DEBUG - 2023-06-27 09:07:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:07:29 --> Model Class Initialized
INFO - 2023-06-27 09:07:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-06-27 09:07:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:07:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 09:07:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 09:07:29 --> Model Class Initialized
INFO - 2023-06-27 09:07:29 --> Model Class Initialized
INFO - 2023-06-27 09:07:29 --> Model Class Initialized
INFO - 2023-06-27 09:07:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 09:07:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 09:07:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 09:07:29 --> Final output sent to browser
DEBUG - 2023-06-27 09:07:29 --> Total execution time: 0.1031
ERROR - 2023-06-27 09:07:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:07:33 --> Config Class Initialized
INFO - 2023-06-27 09:07:33 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:07:33 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:07:33 --> Utf8 Class Initialized
INFO - 2023-06-27 09:07:33 --> URI Class Initialized
INFO - 2023-06-27 09:07:33 --> Router Class Initialized
INFO - 2023-06-27 09:07:33 --> Output Class Initialized
INFO - 2023-06-27 09:07:33 --> Security Class Initialized
DEBUG - 2023-06-27 09:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:07:33 --> Input Class Initialized
INFO - 2023-06-27 09:07:33 --> Language Class Initialized
INFO - 2023-06-27 09:07:33 --> Loader Class Initialized
INFO - 2023-06-27 09:07:33 --> Helper loaded: url_helper
INFO - 2023-06-27 09:07:33 --> Helper loaded: file_helper
INFO - 2023-06-27 09:07:33 --> Helper loaded: html_helper
INFO - 2023-06-27 09:07:33 --> Helper loaded: text_helper
INFO - 2023-06-27 09:07:33 --> Helper loaded: form_helper
INFO - 2023-06-27 09:07:33 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:07:33 --> Helper loaded: security_helper
INFO - 2023-06-27 09:07:33 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:07:33 --> Database Driver Class Initialized
INFO - 2023-06-27 09:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:07:33 --> Parser Class Initialized
INFO - 2023-06-27 09:07:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:07:33 --> Pagination Class Initialized
INFO - 2023-06-27 09:07:33 --> Form Validation Class Initialized
INFO - 2023-06-27 09:07:33 --> Controller Class Initialized
INFO - 2023-06-27 09:07:33 --> Model Class Initialized
DEBUG - 2023-06-27 09:07:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:07:33 --> Final output sent to browser
DEBUG - 2023-06-27 09:07:33 --> Total execution time: 0.0183
ERROR - 2023-06-27 09:07:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:07:33 --> Config Class Initialized
INFO - 2023-06-27 09:07:33 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:07:33 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:07:33 --> Utf8 Class Initialized
INFO - 2023-06-27 09:07:33 --> URI Class Initialized
INFO - 2023-06-27 09:07:33 --> Router Class Initialized
INFO - 2023-06-27 09:07:33 --> Output Class Initialized
INFO - 2023-06-27 09:07:33 --> Security Class Initialized
DEBUG - 2023-06-27 09:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:07:33 --> Input Class Initialized
INFO - 2023-06-27 09:07:33 --> Language Class Initialized
INFO - 2023-06-27 09:07:33 --> Loader Class Initialized
INFO - 2023-06-27 09:07:33 --> Helper loaded: url_helper
INFO - 2023-06-27 09:07:33 --> Helper loaded: file_helper
INFO - 2023-06-27 09:07:33 --> Helper loaded: html_helper
INFO - 2023-06-27 09:07:33 --> Helper loaded: text_helper
INFO - 2023-06-27 09:07:33 --> Helper loaded: form_helper
INFO - 2023-06-27 09:07:33 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:07:33 --> Helper loaded: security_helper
INFO - 2023-06-27 09:07:33 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:07:33 --> Database Driver Class Initialized
INFO - 2023-06-27 09:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:07:33 --> Parser Class Initialized
INFO - 2023-06-27 09:07:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:07:33 --> Pagination Class Initialized
INFO - 2023-06-27 09:07:33 --> Form Validation Class Initialized
INFO - 2023-06-27 09:07:33 --> Controller Class Initialized
INFO - 2023-06-27 09:07:33 --> Model Class Initialized
DEBUG - 2023-06-27 09:07:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:07:33 --> Final output sent to browser
DEBUG - 2023-06-27 09:07:33 --> Total execution time: 0.0158
ERROR - 2023-06-27 09:07:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:07:35 --> Config Class Initialized
INFO - 2023-06-27 09:07:35 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:07:35 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:07:35 --> Utf8 Class Initialized
INFO - 2023-06-27 09:07:35 --> URI Class Initialized
INFO - 2023-06-27 09:07:35 --> Router Class Initialized
INFO - 2023-06-27 09:07:35 --> Output Class Initialized
INFO - 2023-06-27 09:07:35 --> Security Class Initialized
DEBUG - 2023-06-27 09:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:07:35 --> Input Class Initialized
INFO - 2023-06-27 09:07:35 --> Language Class Initialized
INFO - 2023-06-27 09:07:35 --> Loader Class Initialized
INFO - 2023-06-27 09:07:35 --> Helper loaded: url_helper
INFO - 2023-06-27 09:07:35 --> Helper loaded: file_helper
INFO - 2023-06-27 09:07:35 --> Helper loaded: html_helper
INFO - 2023-06-27 09:07:35 --> Helper loaded: text_helper
INFO - 2023-06-27 09:07:35 --> Helper loaded: form_helper
INFO - 2023-06-27 09:07:35 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:07:35 --> Helper loaded: security_helper
INFO - 2023-06-27 09:07:35 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:07:35 --> Database Driver Class Initialized
INFO - 2023-06-27 09:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:07:35 --> Parser Class Initialized
INFO - 2023-06-27 09:07:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:07:35 --> Pagination Class Initialized
INFO - 2023-06-27 09:07:35 --> Form Validation Class Initialized
INFO - 2023-06-27 09:07:35 --> Controller Class Initialized
INFO - 2023-06-27 09:07:35 --> Final output sent to browser
DEBUG - 2023-06-27 09:07:35 --> Total execution time: 0.0142
ERROR - 2023-06-27 09:07:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:07:38 --> Config Class Initialized
INFO - 2023-06-27 09:07:38 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:07:38 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:07:38 --> Utf8 Class Initialized
INFO - 2023-06-27 09:07:38 --> URI Class Initialized
INFO - 2023-06-27 09:07:38 --> Router Class Initialized
INFO - 2023-06-27 09:07:38 --> Output Class Initialized
INFO - 2023-06-27 09:07:38 --> Security Class Initialized
DEBUG - 2023-06-27 09:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:07:38 --> Input Class Initialized
INFO - 2023-06-27 09:07:38 --> Language Class Initialized
INFO - 2023-06-27 09:07:38 --> Loader Class Initialized
INFO - 2023-06-27 09:07:38 --> Helper loaded: url_helper
INFO - 2023-06-27 09:07:38 --> Helper loaded: file_helper
INFO - 2023-06-27 09:07:38 --> Helper loaded: html_helper
INFO - 2023-06-27 09:07:38 --> Helper loaded: text_helper
INFO - 2023-06-27 09:07:38 --> Helper loaded: form_helper
INFO - 2023-06-27 09:07:38 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:07:38 --> Helper loaded: security_helper
INFO - 2023-06-27 09:07:38 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:07:38 --> Database Driver Class Initialized
INFO - 2023-06-27 09:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:07:38 --> Parser Class Initialized
INFO - 2023-06-27 09:07:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:07:38 --> Pagination Class Initialized
INFO - 2023-06-27 09:07:38 --> Form Validation Class Initialized
INFO - 2023-06-27 09:07:38 --> Controller Class Initialized
INFO - 2023-06-27 09:07:38 --> Model Class Initialized
DEBUG - 2023-06-27 09:07:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:07:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:07:38 --> Model Class Initialized
DEBUG - 2023-06-27 09:07:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:07:38 --> Model Class Initialized
INFO - 2023-06-27 09:07:38 --> Final output sent to browser
DEBUG - 2023-06-27 09:07:38 --> Total execution time: 0.0466
ERROR - 2023-06-27 09:07:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:07:39 --> Config Class Initialized
INFO - 2023-06-27 09:07:39 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:07:39 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:07:39 --> Utf8 Class Initialized
INFO - 2023-06-27 09:07:39 --> URI Class Initialized
INFO - 2023-06-27 09:07:39 --> Router Class Initialized
INFO - 2023-06-27 09:07:39 --> Output Class Initialized
INFO - 2023-06-27 09:07:39 --> Security Class Initialized
DEBUG - 2023-06-27 09:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:07:39 --> Input Class Initialized
INFO - 2023-06-27 09:07:39 --> Language Class Initialized
INFO - 2023-06-27 09:07:39 --> Loader Class Initialized
INFO - 2023-06-27 09:07:39 --> Helper loaded: url_helper
INFO - 2023-06-27 09:07:39 --> Helper loaded: file_helper
INFO - 2023-06-27 09:07:39 --> Helper loaded: html_helper
INFO - 2023-06-27 09:07:39 --> Helper loaded: text_helper
INFO - 2023-06-27 09:07:39 --> Helper loaded: form_helper
INFO - 2023-06-27 09:07:39 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:07:39 --> Helper loaded: security_helper
INFO - 2023-06-27 09:07:39 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:07:39 --> Database Driver Class Initialized
INFO - 2023-06-27 09:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:07:39 --> Parser Class Initialized
INFO - 2023-06-27 09:07:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:07:39 --> Pagination Class Initialized
INFO - 2023-06-27 09:07:39 --> Form Validation Class Initialized
INFO - 2023-06-27 09:07:39 --> Controller Class Initialized
INFO - 2023-06-27 09:07:39 --> Model Class Initialized
DEBUG - 2023-06-27 09:07:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:07:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:07:39 --> Model Class Initialized
DEBUG - 2023-06-27 09:07:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:07:39 --> Model Class Initialized
INFO - 2023-06-27 09:07:39 --> Final output sent to browser
DEBUG - 2023-06-27 09:07:39 --> Total execution time: 0.0513
ERROR - 2023-06-27 09:07:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:07:41 --> Config Class Initialized
INFO - 2023-06-27 09:07:41 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:07:41 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:07:41 --> Utf8 Class Initialized
INFO - 2023-06-27 09:07:41 --> URI Class Initialized
INFO - 2023-06-27 09:07:41 --> Router Class Initialized
INFO - 2023-06-27 09:07:41 --> Output Class Initialized
INFO - 2023-06-27 09:07:41 --> Security Class Initialized
DEBUG - 2023-06-27 09:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:07:41 --> Input Class Initialized
INFO - 2023-06-27 09:07:41 --> Language Class Initialized
INFO - 2023-06-27 09:07:41 --> Loader Class Initialized
INFO - 2023-06-27 09:07:41 --> Helper loaded: url_helper
INFO - 2023-06-27 09:07:41 --> Helper loaded: file_helper
INFO - 2023-06-27 09:07:41 --> Helper loaded: html_helper
INFO - 2023-06-27 09:07:41 --> Helper loaded: text_helper
INFO - 2023-06-27 09:07:41 --> Helper loaded: form_helper
INFO - 2023-06-27 09:07:41 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:07:41 --> Helper loaded: security_helper
INFO - 2023-06-27 09:07:41 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:07:41 --> Database Driver Class Initialized
INFO - 2023-06-27 09:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:07:41 --> Parser Class Initialized
INFO - 2023-06-27 09:07:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:07:41 --> Pagination Class Initialized
INFO - 2023-06-27 09:07:41 --> Form Validation Class Initialized
INFO - 2023-06-27 09:07:41 --> Controller Class Initialized
INFO - 2023-06-27 09:07:41 --> Model Class Initialized
DEBUG - 2023-06-27 09:07:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:07:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:07:41 --> Model Class Initialized
DEBUG - 2023-06-27 09:07:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:07:41 --> Model Class Initialized
INFO - 2023-06-27 09:07:41 --> Final output sent to browser
DEBUG - 2023-06-27 09:07:41 --> Total execution time: 0.0253
ERROR - 2023-06-27 09:07:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:07:45 --> Config Class Initialized
INFO - 2023-06-27 09:07:45 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:07:45 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:07:45 --> Utf8 Class Initialized
INFO - 2023-06-27 09:07:45 --> URI Class Initialized
INFO - 2023-06-27 09:07:45 --> Router Class Initialized
INFO - 2023-06-27 09:07:45 --> Output Class Initialized
INFO - 2023-06-27 09:07:45 --> Security Class Initialized
DEBUG - 2023-06-27 09:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:07:45 --> Input Class Initialized
INFO - 2023-06-27 09:07:45 --> Language Class Initialized
INFO - 2023-06-27 09:07:45 --> Loader Class Initialized
INFO - 2023-06-27 09:07:45 --> Helper loaded: url_helper
INFO - 2023-06-27 09:07:45 --> Helper loaded: file_helper
INFO - 2023-06-27 09:07:45 --> Helper loaded: html_helper
INFO - 2023-06-27 09:07:45 --> Helper loaded: text_helper
INFO - 2023-06-27 09:07:45 --> Helper loaded: form_helper
INFO - 2023-06-27 09:07:45 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:07:45 --> Helper loaded: security_helper
INFO - 2023-06-27 09:07:45 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:07:45 --> Database Driver Class Initialized
INFO - 2023-06-27 09:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:07:45 --> Parser Class Initialized
INFO - 2023-06-27 09:07:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:07:45 --> Pagination Class Initialized
INFO - 2023-06-27 09:07:45 --> Form Validation Class Initialized
INFO - 2023-06-27 09:07:45 --> Controller Class Initialized
INFO - 2023-06-27 09:07:45 --> Model Class Initialized
DEBUG - 2023-06-27 09:07:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:07:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:07:45 --> Model Class Initialized
INFO - 2023-06-27 09:07:45 --> Model Class Initialized
INFO - 2023-06-27 09:07:45 --> Final output sent to browser
DEBUG - 2023-06-27 09:07:45 --> Total execution time: 0.0188
ERROR - 2023-06-27 09:07:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:07:49 --> Config Class Initialized
INFO - 2023-06-27 09:07:49 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:07:49 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:07:49 --> Utf8 Class Initialized
INFO - 2023-06-27 09:07:49 --> URI Class Initialized
INFO - 2023-06-27 09:07:49 --> Router Class Initialized
INFO - 2023-06-27 09:07:49 --> Output Class Initialized
INFO - 2023-06-27 09:07:49 --> Security Class Initialized
DEBUG - 2023-06-27 09:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:07:49 --> Input Class Initialized
INFO - 2023-06-27 09:07:49 --> Language Class Initialized
INFO - 2023-06-27 09:07:49 --> Loader Class Initialized
INFO - 2023-06-27 09:07:49 --> Helper loaded: url_helper
INFO - 2023-06-27 09:07:49 --> Helper loaded: file_helper
INFO - 2023-06-27 09:07:49 --> Helper loaded: html_helper
INFO - 2023-06-27 09:07:49 --> Helper loaded: text_helper
INFO - 2023-06-27 09:07:49 --> Helper loaded: form_helper
INFO - 2023-06-27 09:07:49 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:07:49 --> Helper loaded: security_helper
INFO - 2023-06-27 09:07:49 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:07:49 --> Database Driver Class Initialized
INFO - 2023-06-27 09:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:07:49 --> Parser Class Initialized
INFO - 2023-06-27 09:07:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:07:49 --> Pagination Class Initialized
INFO - 2023-06-27 09:07:49 --> Form Validation Class Initialized
INFO - 2023-06-27 09:07:49 --> Controller Class Initialized
INFO - 2023-06-27 09:07:49 --> Model Class Initialized
DEBUG - 2023-06-27 09:07:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:07:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:07:49 --> Model Class Initialized
INFO - 2023-06-27 09:07:49 --> Final output sent to browser
DEBUG - 2023-06-27 09:07:49 --> Total execution time: 0.0165
ERROR - 2023-06-27 09:08:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:08:15 --> Config Class Initialized
INFO - 2023-06-27 09:08:15 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:08:15 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:08:15 --> Utf8 Class Initialized
INFO - 2023-06-27 09:08:15 --> URI Class Initialized
INFO - 2023-06-27 09:08:15 --> Router Class Initialized
INFO - 2023-06-27 09:08:15 --> Output Class Initialized
INFO - 2023-06-27 09:08:15 --> Security Class Initialized
DEBUG - 2023-06-27 09:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:08:15 --> Input Class Initialized
INFO - 2023-06-27 09:08:15 --> Language Class Initialized
INFO - 2023-06-27 09:08:15 --> Loader Class Initialized
INFO - 2023-06-27 09:08:15 --> Helper loaded: url_helper
INFO - 2023-06-27 09:08:15 --> Helper loaded: file_helper
INFO - 2023-06-27 09:08:15 --> Helper loaded: html_helper
INFO - 2023-06-27 09:08:15 --> Helper loaded: text_helper
INFO - 2023-06-27 09:08:15 --> Helper loaded: form_helper
INFO - 2023-06-27 09:08:15 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:08:15 --> Helper loaded: security_helper
INFO - 2023-06-27 09:08:15 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:08:15 --> Database Driver Class Initialized
INFO - 2023-06-27 09:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:08:15 --> Parser Class Initialized
INFO - 2023-06-27 09:08:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:08:15 --> Pagination Class Initialized
INFO - 2023-06-27 09:08:15 --> Form Validation Class Initialized
INFO - 2023-06-27 09:08:15 --> Controller Class Initialized
INFO - 2023-06-27 09:08:15 --> Model Class Initialized
DEBUG - 2023-06-27 09:08:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:08:15 --> Model Class Initialized
DEBUG - 2023-06-27 09:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:08:15 --> Model Class Initialized
INFO - 2023-06-27 09:08:15 --> Final output sent to browser
DEBUG - 2023-06-27 09:08:15 --> Total execution time: 0.0506
ERROR - 2023-06-27 09:08:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:08:16 --> Config Class Initialized
INFO - 2023-06-27 09:08:16 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:08:16 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:08:16 --> Utf8 Class Initialized
INFO - 2023-06-27 09:08:16 --> URI Class Initialized
INFO - 2023-06-27 09:08:16 --> Router Class Initialized
INFO - 2023-06-27 09:08:16 --> Output Class Initialized
INFO - 2023-06-27 09:08:16 --> Security Class Initialized
DEBUG - 2023-06-27 09:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:08:16 --> Input Class Initialized
INFO - 2023-06-27 09:08:16 --> Language Class Initialized
INFO - 2023-06-27 09:08:16 --> Loader Class Initialized
INFO - 2023-06-27 09:08:16 --> Helper loaded: url_helper
INFO - 2023-06-27 09:08:16 --> Helper loaded: file_helper
INFO - 2023-06-27 09:08:16 --> Helper loaded: html_helper
INFO - 2023-06-27 09:08:16 --> Helper loaded: text_helper
INFO - 2023-06-27 09:08:16 --> Helper loaded: form_helper
INFO - 2023-06-27 09:08:16 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:08:16 --> Helper loaded: security_helper
INFO - 2023-06-27 09:08:16 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:08:16 --> Database Driver Class Initialized
INFO - 2023-06-27 09:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:08:16 --> Parser Class Initialized
INFO - 2023-06-27 09:08:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:08:16 --> Pagination Class Initialized
INFO - 2023-06-27 09:08:16 --> Form Validation Class Initialized
INFO - 2023-06-27 09:08:16 --> Controller Class Initialized
INFO - 2023-06-27 09:08:16 --> Model Class Initialized
DEBUG - 2023-06-27 09:08:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:08:16 --> Model Class Initialized
DEBUG - 2023-06-27 09:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:08:16 --> Model Class Initialized
INFO - 2023-06-27 09:08:16 --> Final output sent to browser
DEBUG - 2023-06-27 09:08:16 --> Total execution time: 0.0443
ERROR - 2023-06-27 09:08:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:08:17 --> Config Class Initialized
INFO - 2023-06-27 09:08:17 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:08:17 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:08:17 --> Utf8 Class Initialized
INFO - 2023-06-27 09:08:17 --> URI Class Initialized
INFO - 2023-06-27 09:08:17 --> Router Class Initialized
INFO - 2023-06-27 09:08:17 --> Output Class Initialized
INFO - 2023-06-27 09:08:17 --> Security Class Initialized
DEBUG - 2023-06-27 09:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:08:17 --> Input Class Initialized
INFO - 2023-06-27 09:08:17 --> Language Class Initialized
INFO - 2023-06-27 09:08:17 --> Loader Class Initialized
INFO - 2023-06-27 09:08:17 --> Helper loaded: url_helper
INFO - 2023-06-27 09:08:17 --> Helper loaded: file_helper
INFO - 2023-06-27 09:08:17 --> Helper loaded: html_helper
INFO - 2023-06-27 09:08:17 --> Helper loaded: text_helper
INFO - 2023-06-27 09:08:17 --> Helper loaded: form_helper
INFO - 2023-06-27 09:08:17 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:08:17 --> Helper loaded: security_helper
INFO - 2023-06-27 09:08:17 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:08:17 --> Database Driver Class Initialized
INFO - 2023-06-27 09:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:08:17 --> Parser Class Initialized
INFO - 2023-06-27 09:08:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:08:17 --> Pagination Class Initialized
INFO - 2023-06-27 09:08:17 --> Form Validation Class Initialized
INFO - 2023-06-27 09:08:17 --> Controller Class Initialized
INFO - 2023-06-27 09:08:17 --> Model Class Initialized
DEBUG - 2023-06-27 09:08:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:08:17 --> Model Class Initialized
DEBUG - 2023-06-27 09:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:08:17 --> Model Class Initialized
INFO - 2023-06-27 09:08:17 --> Final output sent to browser
DEBUG - 2023-06-27 09:08:17 --> Total execution time: 0.0208
ERROR - 2023-06-27 09:08:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:08:18 --> Config Class Initialized
INFO - 2023-06-27 09:08:18 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:08:18 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:08:18 --> Utf8 Class Initialized
INFO - 2023-06-27 09:08:18 --> URI Class Initialized
INFO - 2023-06-27 09:08:18 --> Router Class Initialized
INFO - 2023-06-27 09:08:18 --> Output Class Initialized
INFO - 2023-06-27 09:08:18 --> Security Class Initialized
DEBUG - 2023-06-27 09:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:08:18 --> Input Class Initialized
INFO - 2023-06-27 09:08:18 --> Language Class Initialized
INFO - 2023-06-27 09:08:18 --> Loader Class Initialized
INFO - 2023-06-27 09:08:18 --> Helper loaded: url_helper
INFO - 2023-06-27 09:08:18 --> Helper loaded: file_helper
INFO - 2023-06-27 09:08:18 --> Helper loaded: html_helper
INFO - 2023-06-27 09:08:18 --> Helper loaded: text_helper
INFO - 2023-06-27 09:08:18 --> Helper loaded: form_helper
INFO - 2023-06-27 09:08:18 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:08:18 --> Helper loaded: security_helper
INFO - 2023-06-27 09:08:18 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:08:18 --> Database Driver Class Initialized
INFO - 2023-06-27 09:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:08:18 --> Parser Class Initialized
INFO - 2023-06-27 09:08:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:08:18 --> Pagination Class Initialized
INFO - 2023-06-27 09:08:18 --> Form Validation Class Initialized
INFO - 2023-06-27 09:08:18 --> Controller Class Initialized
INFO - 2023-06-27 09:08:18 --> Model Class Initialized
DEBUG - 2023-06-27 09:08:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:08:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:08:18 --> Model Class Initialized
DEBUG - 2023-06-27 09:08:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:08:18 --> Model Class Initialized
INFO - 2023-06-27 09:08:18 --> Final output sent to browser
DEBUG - 2023-06-27 09:08:18 --> Total execution time: 0.0438
ERROR - 2023-06-27 09:08:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:08:19 --> Config Class Initialized
INFO - 2023-06-27 09:08:19 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:08:19 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:08:19 --> Utf8 Class Initialized
INFO - 2023-06-27 09:08:19 --> URI Class Initialized
INFO - 2023-06-27 09:08:19 --> Router Class Initialized
INFO - 2023-06-27 09:08:19 --> Output Class Initialized
INFO - 2023-06-27 09:08:19 --> Security Class Initialized
DEBUG - 2023-06-27 09:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:08:19 --> Input Class Initialized
INFO - 2023-06-27 09:08:19 --> Language Class Initialized
INFO - 2023-06-27 09:08:19 --> Loader Class Initialized
INFO - 2023-06-27 09:08:19 --> Helper loaded: url_helper
INFO - 2023-06-27 09:08:19 --> Helper loaded: file_helper
INFO - 2023-06-27 09:08:19 --> Helper loaded: html_helper
INFO - 2023-06-27 09:08:19 --> Helper loaded: text_helper
INFO - 2023-06-27 09:08:19 --> Helper loaded: form_helper
INFO - 2023-06-27 09:08:19 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:08:19 --> Helper loaded: security_helper
INFO - 2023-06-27 09:08:19 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:08:19 --> Database Driver Class Initialized
INFO - 2023-06-27 09:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:08:19 --> Parser Class Initialized
INFO - 2023-06-27 09:08:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:08:19 --> Pagination Class Initialized
INFO - 2023-06-27 09:08:19 --> Form Validation Class Initialized
INFO - 2023-06-27 09:08:19 --> Controller Class Initialized
INFO - 2023-06-27 09:08:19 --> Model Class Initialized
DEBUG - 2023-06-27 09:08:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:08:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:08:19 --> Model Class Initialized
DEBUG - 2023-06-27 09:08:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:08:19 --> Model Class Initialized
INFO - 2023-06-27 09:08:19 --> Final output sent to browser
DEBUG - 2023-06-27 09:08:19 --> Total execution time: 0.0207
ERROR - 2023-06-27 09:08:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:08:22 --> Config Class Initialized
INFO - 2023-06-27 09:08:22 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:08:22 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:08:22 --> Utf8 Class Initialized
INFO - 2023-06-27 09:08:22 --> URI Class Initialized
INFO - 2023-06-27 09:08:22 --> Router Class Initialized
INFO - 2023-06-27 09:08:22 --> Output Class Initialized
INFO - 2023-06-27 09:08:22 --> Security Class Initialized
DEBUG - 2023-06-27 09:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:08:22 --> Input Class Initialized
INFO - 2023-06-27 09:08:22 --> Language Class Initialized
INFO - 2023-06-27 09:08:22 --> Loader Class Initialized
INFO - 2023-06-27 09:08:22 --> Helper loaded: url_helper
INFO - 2023-06-27 09:08:22 --> Helper loaded: file_helper
INFO - 2023-06-27 09:08:22 --> Helper loaded: html_helper
INFO - 2023-06-27 09:08:22 --> Helper loaded: text_helper
INFO - 2023-06-27 09:08:22 --> Helper loaded: form_helper
INFO - 2023-06-27 09:08:22 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:08:22 --> Helper loaded: security_helper
INFO - 2023-06-27 09:08:22 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:08:22 --> Database Driver Class Initialized
INFO - 2023-06-27 09:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:08:22 --> Parser Class Initialized
INFO - 2023-06-27 09:08:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:08:22 --> Pagination Class Initialized
INFO - 2023-06-27 09:08:22 --> Form Validation Class Initialized
INFO - 2023-06-27 09:08:22 --> Controller Class Initialized
INFO - 2023-06-27 09:08:22 --> Model Class Initialized
DEBUG - 2023-06-27 09:08:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:08:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:08:22 --> Model Class Initialized
INFO - 2023-06-27 09:08:22 --> Model Class Initialized
INFO - 2023-06-27 09:08:22 --> Final output sent to browser
DEBUG - 2023-06-27 09:08:22 --> Total execution time: 0.0208
ERROR - 2023-06-27 09:08:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:08:25 --> Config Class Initialized
INFO - 2023-06-27 09:08:25 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:08:25 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:08:25 --> Utf8 Class Initialized
INFO - 2023-06-27 09:08:25 --> URI Class Initialized
INFO - 2023-06-27 09:08:25 --> Router Class Initialized
INFO - 2023-06-27 09:08:25 --> Output Class Initialized
INFO - 2023-06-27 09:08:25 --> Security Class Initialized
DEBUG - 2023-06-27 09:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:08:25 --> Input Class Initialized
INFO - 2023-06-27 09:08:25 --> Language Class Initialized
INFO - 2023-06-27 09:08:25 --> Loader Class Initialized
INFO - 2023-06-27 09:08:25 --> Helper loaded: url_helper
INFO - 2023-06-27 09:08:25 --> Helper loaded: file_helper
INFO - 2023-06-27 09:08:25 --> Helper loaded: html_helper
INFO - 2023-06-27 09:08:25 --> Helper loaded: text_helper
INFO - 2023-06-27 09:08:25 --> Helper loaded: form_helper
INFO - 2023-06-27 09:08:25 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:08:25 --> Helper loaded: security_helper
INFO - 2023-06-27 09:08:25 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:08:25 --> Database Driver Class Initialized
INFO - 2023-06-27 09:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:08:25 --> Parser Class Initialized
INFO - 2023-06-27 09:08:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:08:25 --> Pagination Class Initialized
INFO - 2023-06-27 09:08:25 --> Form Validation Class Initialized
INFO - 2023-06-27 09:08:25 --> Controller Class Initialized
INFO - 2023-06-27 09:08:25 --> Model Class Initialized
DEBUG - 2023-06-27 09:08:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:08:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:08:25 --> Model Class Initialized
INFO - 2023-06-27 09:08:25 --> Final output sent to browser
DEBUG - 2023-06-27 09:08:25 --> Total execution time: 0.0157
ERROR - 2023-06-27 09:08:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:08:41 --> Config Class Initialized
INFO - 2023-06-27 09:08:41 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:08:41 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:08:41 --> Utf8 Class Initialized
INFO - 2023-06-27 09:08:41 --> URI Class Initialized
INFO - 2023-06-27 09:08:41 --> Router Class Initialized
INFO - 2023-06-27 09:08:41 --> Output Class Initialized
INFO - 2023-06-27 09:08:41 --> Security Class Initialized
DEBUG - 2023-06-27 09:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:08:41 --> Input Class Initialized
INFO - 2023-06-27 09:08:41 --> Language Class Initialized
INFO - 2023-06-27 09:08:41 --> Loader Class Initialized
INFO - 2023-06-27 09:08:41 --> Helper loaded: url_helper
INFO - 2023-06-27 09:08:41 --> Helper loaded: file_helper
INFO - 2023-06-27 09:08:41 --> Helper loaded: html_helper
INFO - 2023-06-27 09:08:41 --> Helper loaded: text_helper
INFO - 2023-06-27 09:08:41 --> Helper loaded: form_helper
INFO - 2023-06-27 09:08:41 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:08:41 --> Helper loaded: security_helper
INFO - 2023-06-27 09:08:41 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:08:41 --> Database Driver Class Initialized
INFO - 2023-06-27 09:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:08:41 --> Parser Class Initialized
INFO - 2023-06-27 09:08:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:08:41 --> Pagination Class Initialized
INFO - 2023-06-27 09:08:41 --> Form Validation Class Initialized
INFO - 2023-06-27 09:08:41 --> Controller Class Initialized
INFO - 2023-06-27 09:08:41 --> Model Class Initialized
DEBUG - 2023-06-27 09:08:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:08:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:08:41 --> Model Class Initialized
DEBUG - 2023-06-27 09:08:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:08:41 --> Model Class Initialized
INFO - 2023-06-27 09:08:41 --> Final output sent to browser
DEBUG - 2023-06-27 09:08:41 --> Total execution time: 0.0584
ERROR - 2023-06-27 09:08:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:08:42 --> Config Class Initialized
INFO - 2023-06-27 09:08:42 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:08:42 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:08:42 --> Utf8 Class Initialized
INFO - 2023-06-27 09:08:42 --> URI Class Initialized
INFO - 2023-06-27 09:08:42 --> Router Class Initialized
INFO - 2023-06-27 09:08:42 --> Output Class Initialized
INFO - 2023-06-27 09:08:42 --> Security Class Initialized
DEBUG - 2023-06-27 09:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:08:42 --> Input Class Initialized
INFO - 2023-06-27 09:08:42 --> Language Class Initialized
INFO - 2023-06-27 09:08:42 --> Loader Class Initialized
INFO - 2023-06-27 09:08:42 --> Helper loaded: url_helper
INFO - 2023-06-27 09:08:42 --> Helper loaded: file_helper
INFO - 2023-06-27 09:08:42 --> Helper loaded: html_helper
INFO - 2023-06-27 09:08:42 --> Helper loaded: text_helper
INFO - 2023-06-27 09:08:42 --> Helper loaded: form_helper
INFO - 2023-06-27 09:08:42 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:08:42 --> Helper loaded: security_helper
INFO - 2023-06-27 09:08:42 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:08:42 --> Database Driver Class Initialized
INFO - 2023-06-27 09:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:08:42 --> Parser Class Initialized
INFO - 2023-06-27 09:08:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:08:42 --> Pagination Class Initialized
INFO - 2023-06-27 09:08:42 --> Form Validation Class Initialized
INFO - 2023-06-27 09:08:42 --> Controller Class Initialized
INFO - 2023-06-27 09:08:42 --> Model Class Initialized
DEBUG - 2023-06-27 09:08:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:08:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:08:42 --> Model Class Initialized
DEBUG - 2023-06-27 09:08:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:08:42 --> Model Class Initialized
INFO - 2023-06-27 09:08:42 --> Final output sent to browser
DEBUG - 2023-06-27 09:08:42 --> Total execution time: 0.0220
ERROR - 2023-06-27 09:08:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:08:44 --> Config Class Initialized
INFO - 2023-06-27 09:08:44 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:08:44 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:08:44 --> Utf8 Class Initialized
INFO - 2023-06-27 09:08:44 --> URI Class Initialized
INFO - 2023-06-27 09:08:44 --> Router Class Initialized
INFO - 2023-06-27 09:08:44 --> Output Class Initialized
INFO - 2023-06-27 09:08:44 --> Security Class Initialized
DEBUG - 2023-06-27 09:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:08:44 --> Input Class Initialized
INFO - 2023-06-27 09:08:44 --> Language Class Initialized
INFO - 2023-06-27 09:08:44 --> Loader Class Initialized
INFO - 2023-06-27 09:08:44 --> Helper loaded: url_helper
INFO - 2023-06-27 09:08:44 --> Helper loaded: file_helper
INFO - 2023-06-27 09:08:44 --> Helper loaded: html_helper
INFO - 2023-06-27 09:08:44 --> Helper loaded: text_helper
INFO - 2023-06-27 09:08:44 --> Helper loaded: form_helper
INFO - 2023-06-27 09:08:44 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:08:44 --> Helper loaded: security_helper
INFO - 2023-06-27 09:08:44 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:08:44 --> Database Driver Class Initialized
INFO - 2023-06-27 09:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:08:44 --> Parser Class Initialized
INFO - 2023-06-27 09:08:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:08:44 --> Pagination Class Initialized
INFO - 2023-06-27 09:08:44 --> Form Validation Class Initialized
INFO - 2023-06-27 09:08:44 --> Controller Class Initialized
INFO - 2023-06-27 09:08:44 --> Model Class Initialized
DEBUG - 2023-06-27 09:08:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:08:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:08:44 --> Model Class Initialized
INFO - 2023-06-27 09:08:44 --> Model Class Initialized
INFO - 2023-06-27 09:08:44 --> Final output sent to browser
DEBUG - 2023-06-27 09:08:44 --> Total execution time: 0.0186
ERROR - 2023-06-27 09:08:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:08:46 --> Config Class Initialized
INFO - 2023-06-27 09:08:46 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:08:46 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:08:46 --> Utf8 Class Initialized
INFO - 2023-06-27 09:08:46 --> URI Class Initialized
INFO - 2023-06-27 09:08:46 --> Router Class Initialized
INFO - 2023-06-27 09:08:46 --> Output Class Initialized
INFO - 2023-06-27 09:08:46 --> Security Class Initialized
DEBUG - 2023-06-27 09:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:08:46 --> Input Class Initialized
INFO - 2023-06-27 09:08:46 --> Language Class Initialized
INFO - 2023-06-27 09:08:46 --> Loader Class Initialized
INFO - 2023-06-27 09:08:46 --> Helper loaded: url_helper
INFO - 2023-06-27 09:08:46 --> Helper loaded: file_helper
INFO - 2023-06-27 09:08:46 --> Helper loaded: html_helper
INFO - 2023-06-27 09:08:46 --> Helper loaded: text_helper
INFO - 2023-06-27 09:08:46 --> Helper loaded: form_helper
INFO - 2023-06-27 09:08:46 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:08:46 --> Helper loaded: security_helper
INFO - 2023-06-27 09:08:46 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:08:46 --> Database Driver Class Initialized
INFO - 2023-06-27 09:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:08:46 --> Parser Class Initialized
INFO - 2023-06-27 09:08:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:08:46 --> Pagination Class Initialized
INFO - 2023-06-27 09:08:46 --> Form Validation Class Initialized
INFO - 2023-06-27 09:08:46 --> Controller Class Initialized
INFO - 2023-06-27 09:08:46 --> Model Class Initialized
DEBUG - 2023-06-27 09:08:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:08:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:08:46 --> Model Class Initialized
INFO - 2023-06-27 09:08:46 --> Final output sent to browser
DEBUG - 2023-06-27 09:08:46 --> Total execution time: 0.0165
ERROR - 2023-06-27 09:08:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:08:55 --> Config Class Initialized
INFO - 2023-06-27 09:08:55 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:08:55 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:08:55 --> Utf8 Class Initialized
INFO - 2023-06-27 09:08:55 --> URI Class Initialized
INFO - 2023-06-27 09:08:55 --> Router Class Initialized
INFO - 2023-06-27 09:08:55 --> Output Class Initialized
INFO - 2023-06-27 09:08:55 --> Security Class Initialized
DEBUG - 2023-06-27 09:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:08:55 --> Input Class Initialized
INFO - 2023-06-27 09:08:55 --> Language Class Initialized
INFO - 2023-06-27 09:08:55 --> Loader Class Initialized
INFO - 2023-06-27 09:08:55 --> Helper loaded: url_helper
INFO - 2023-06-27 09:08:55 --> Helper loaded: file_helper
INFO - 2023-06-27 09:08:55 --> Helper loaded: html_helper
INFO - 2023-06-27 09:08:55 --> Helper loaded: text_helper
INFO - 2023-06-27 09:08:55 --> Helper loaded: form_helper
INFO - 2023-06-27 09:08:55 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:08:55 --> Helper loaded: security_helper
INFO - 2023-06-27 09:08:55 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:08:55 --> Database Driver Class Initialized
INFO - 2023-06-27 09:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:08:55 --> Parser Class Initialized
INFO - 2023-06-27 09:08:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:08:55 --> Pagination Class Initialized
INFO - 2023-06-27 09:08:55 --> Form Validation Class Initialized
INFO - 2023-06-27 09:08:55 --> Controller Class Initialized
INFO - 2023-06-27 09:08:55 --> Model Class Initialized
DEBUG - 2023-06-27 09:08:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:08:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:08:55 --> Model Class Initialized
DEBUG - 2023-06-27 09:08:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:08:55 --> Model Class Initialized
INFO - 2023-06-27 09:08:56 --> Final output sent to browser
DEBUG - 2023-06-27 09:08:56 --> Total execution time: 0.0465
ERROR - 2023-06-27 09:08:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:08:56 --> Config Class Initialized
INFO - 2023-06-27 09:08:56 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:08:56 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:08:56 --> Utf8 Class Initialized
INFO - 2023-06-27 09:08:56 --> URI Class Initialized
INFO - 2023-06-27 09:08:56 --> Router Class Initialized
INFO - 2023-06-27 09:08:56 --> Output Class Initialized
INFO - 2023-06-27 09:08:56 --> Security Class Initialized
DEBUG - 2023-06-27 09:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:08:56 --> Input Class Initialized
INFO - 2023-06-27 09:08:56 --> Language Class Initialized
INFO - 2023-06-27 09:08:56 --> Loader Class Initialized
INFO - 2023-06-27 09:08:56 --> Helper loaded: url_helper
INFO - 2023-06-27 09:08:56 --> Helper loaded: file_helper
INFO - 2023-06-27 09:08:56 --> Helper loaded: html_helper
INFO - 2023-06-27 09:08:56 --> Helper loaded: text_helper
INFO - 2023-06-27 09:08:56 --> Helper loaded: form_helper
INFO - 2023-06-27 09:08:56 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:08:56 --> Helper loaded: security_helper
INFO - 2023-06-27 09:08:56 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:08:56 --> Database Driver Class Initialized
INFO - 2023-06-27 09:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:08:56 --> Parser Class Initialized
INFO - 2023-06-27 09:08:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:08:56 --> Pagination Class Initialized
INFO - 2023-06-27 09:08:56 --> Form Validation Class Initialized
INFO - 2023-06-27 09:08:56 --> Controller Class Initialized
INFO - 2023-06-27 09:08:56 --> Model Class Initialized
DEBUG - 2023-06-27 09:08:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:08:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:08:56 --> Model Class Initialized
DEBUG - 2023-06-27 09:08:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:08:56 --> Model Class Initialized
INFO - 2023-06-27 09:08:56 --> Final output sent to browser
DEBUG - 2023-06-27 09:08:56 --> Total execution time: 0.0498
ERROR - 2023-06-27 09:08:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:08:56 --> Config Class Initialized
INFO - 2023-06-27 09:08:56 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:08:56 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:08:56 --> Utf8 Class Initialized
INFO - 2023-06-27 09:08:56 --> URI Class Initialized
INFO - 2023-06-27 09:08:56 --> Router Class Initialized
INFO - 2023-06-27 09:08:56 --> Output Class Initialized
INFO - 2023-06-27 09:08:56 --> Security Class Initialized
DEBUG - 2023-06-27 09:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:08:56 --> Input Class Initialized
INFO - 2023-06-27 09:08:56 --> Language Class Initialized
INFO - 2023-06-27 09:08:56 --> Loader Class Initialized
INFO - 2023-06-27 09:08:56 --> Helper loaded: url_helper
INFO - 2023-06-27 09:08:56 --> Helper loaded: file_helper
INFO - 2023-06-27 09:08:56 --> Helper loaded: html_helper
INFO - 2023-06-27 09:08:56 --> Helper loaded: text_helper
INFO - 2023-06-27 09:08:56 --> Helper loaded: form_helper
INFO - 2023-06-27 09:08:56 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:08:56 --> Helper loaded: security_helper
INFO - 2023-06-27 09:08:56 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:08:56 --> Database Driver Class Initialized
INFO - 2023-06-27 09:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:08:56 --> Parser Class Initialized
INFO - 2023-06-27 09:08:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:08:56 --> Pagination Class Initialized
INFO - 2023-06-27 09:08:56 --> Form Validation Class Initialized
INFO - 2023-06-27 09:08:56 --> Controller Class Initialized
INFO - 2023-06-27 09:08:56 --> Model Class Initialized
DEBUG - 2023-06-27 09:08:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:08:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:08:56 --> Model Class Initialized
DEBUG - 2023-06-27 09:08:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:08:56 --> Model Class Initialized
INFO - 2023-06-27 09:08:56 --> Final output sent to browser
DEBUG - 2023-06-27 09:08:56 --> Total execution time: 0.0443
ERROR - 2023-06-27 09:08:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:08:57 --> Config Class Initialized
INFO - 2023-06-27 09:08:57 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:08:57 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:08:57 --> Utf8 Class Initialized
INFO - 2023-06-27 09:08:57 --> URI Class Initialized
INFO - 2023-06-27 09:08:57 --> Router Class Initialized
INFO - 2023-06-27 09:08:57 --> Output Class Initialized
INFO - 2023-06-27 09:08:57 --> Security Class Initialized
DEBUG - 2023-06-27 09:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:08:57 --> Input Class Initialized
INFO - 2023-06-27 09:08:57 --> Language Class Initialized
INFO - 2023-06-27 09:08:57 --> Loader Class Initialized
INFO - 2023-06-27 09:08:57 --> Helper loaded: url_helper
INFO - 2023-06-27 09:08:57 --> Helper loaded: file_helper
INFO - 2023-06-27 09:08:57 --> Helper loaded: html_helper
INFO - 2023-06-27 09:08:57 --> Helper loaded: text_helper
INFO - 2023-06-27 09:08:57 --> Helper loaded: form_helper
INFO - 2023-06-27 09:08:57 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:08:57 --> Helper loaded: security_helper
INFO - 2023-06-27 09:08:57 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:08:57 --> Database Driver Class Initialized
INFO - 2023-06-27 09:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:08:57 --> Parser Class Initialized
INFO - 2023-06-27 09:08:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:08:57 --> Pagination Class Initialized
INFO - 2023-06-27 09:08:57 --> Form Validation Class Initialized
INFO - 2023-06-27 09:08:57 --> Controller Class Initialized
INFO - 2023-06-27 09:08:57 --> Model Class Initialized
DEBUG - 2023-06-27 09:08:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:08:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:08:57 --> Model Class Initialized
DEBUG - 2023-06-27 09:08:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:08:57 --> Model Class Initialized
INFO - 2023-06-27 09:08:57 --> Final output sent to browser
DEBUG - 2023-06-27 09:08:57 --> Total execution time: 0.0240
ERROR - 2023-06-27 09:09:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:09:02 --> Config Class Initialized
INFO - 2023-06-27 09:09:02 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:09:02 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:09:02 --> Utf8 Class Initialized
INFO - 2023-06-27 09:09:02 --> URI Class Initialized
INFO - 2023-06-27 09:09:02 --> Router Class Initialized
INFO - 2023-06-27 09:09:02 --> Output Class Initialized
INFO - 2023-06-27 09:09:02 --> Security Class Initialized
DEBUG - 2023-06-27 09:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:09:02 --> Input Class Initialized
INFO - 2023-06-27 09:09:02 --> Language Class Initialized
INFO - 2023-06-27 09:09:02 --> Loader Class Initialized
INFO - 2023-06-27 09:09:02 --> Helper loaded: url_helper
INFO - 2023-06-27 09:09:02 --> Helper loaded: file_helper
INFO - 2023-06-27 09:09:02 --> Helper loaded: html_helper
INFO - 2023-06-27 09:09:02 --> Helper loaded: text_helper
INFO - 2023-06-27 09:09:02 --> Helper loaded: form_helper
INFO - 2023-06-27 09:09:02 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:09:02 --> Helper loaded: security_helper
INFO - 2023-06-27 09:09:02 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:09:02 --> Database Driver Class Initialized
INFO - 2023-06-27 09:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:09:02 --> Parser Class Initialized
INFO - 2023-06-27 09:09:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:09:02 --> Pagination Class Initialized
INFO - 2023-06-27 09:09:02 --> Form Validation Class Initialized
INFO - 2023-06-27 09:09:02 --> Controller Class Initialized
INFO - 2023-06-27 09:09:02 --> Model Class Initialized
DEBUG - 2023-06-27 09:09:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:09:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:09:02 --> Model Class Initialized
DEBUG - 2023-06-27 09:09:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:09:02 --> Model Class Initialized
INFO - 2023-06-27 09:09:02 --> Final output sent to browser
DEBUG - 2023-06-27 09:09:02 --> Total execution time: 0.0454
ERROR - 2023-06-27 09:09:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:09:04 --> Config Class Initialized
INFO - 2023-06-27 09:09:04 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:09:04 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:09:04 --> Utf8 Class Initialized
INFO - 2023-06-27 09:09:04 --> URI Class Initialized
INFO - 2023-06-27 09:09:04 --> Router Class Initialized
INFO - 2023-06-27 09:09:04 --> Output Class Initialized
INFO - 2023-06-27 09:09:04 --> Security Class Initialized
DEBUG - 2023-06-27 09:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:09:04 --> Input Class Initialized
INFO - 2023-06-27 09:09:04 --> Language Class Initialized
INFO - 2023-06-27 09:09:04 --> Loader Class Initialized
INFO - 2023-06-27 09:09:04 --> Helper loaded: url_helper
INFO - 2023-06-27 09:09:04 --> Helper loaded: file_helper
INFO - 2023-06-27 09:09:04 --> Helper loaded: html_helper
INFO - 2023-06-27 09:09:04 --> Helper loaded: text_helper
INFO - 2023-06-27 09:09:04 --> Helper loaded: form_helper
INFO - 2023-06-27 09:09:04 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:09:04 --> Helper loaded: security_helper
INFO - 2023-06-27 09:09:04 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:09:04 --> Database Driver Class Initialized
INFO - 2023-06-27 09:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:09:04 --> Parser Class Initialized
INFO - 2023-06-27 09:09:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:09:04 --> Pagination Class Initialized
INFO - 2023-06-27 09:09:04 --> Form Validation Class Initialized
INFO - 2023-06-27 09:09:04 --> Controller Class Initialized
INFO - 2023-06-27 09:09:04 --> Model Class Initialized
DEBUG - 2023-06-27 09:09:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:09:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:09:04 --> Model Class Initialized
DEBUG - 2023-06-27 09:09:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:09:04 --> Model Class Initialized
INFO - 2023-06-27 09:09:04 --> Final output sent to browser
DEBUG - 2023-06-27 09:09:04 --> Total execution time: 0.0248
ERROR - 2023-06-27 09:09:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:09:05 --> Config Class Initialized
INFO - 2023-06-27 09:09:05 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:09:05 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:09:05 --> Utf8 Class Initialized
INFO - 2023-06-27 09:09:05 --> URI Class Initialized
INFO - 2023-06-27 09:09:05 --> Router Class Initialized
INFO - 2023-06-27 09:09:05 --> Output Class Initialized
INFO - 2023-06-27 09:09:05 --> Security Class Initialized
DEBUG - 2023-06-27 09:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:09:05 --> Input Class Initialized
INFO - 2023-06-27 09:09:05 --> Language Class Initialized
INFO - 2023-06-27 09:09:05 --> Loader Class Initialized
INFO - 2023-06-27 09:09:05 --> Helper loaded: url_helper
INFO - 2023-06-27 09:09:05 --> Helper loaded: file_helper
INFO - 2023-06-27 09:09:05 --> Helper loaded: html_helper
INFO - 2023-06-27 09:09:05 --> Helper loaded: text_helper
INFO - 2023-06-27 09:09:05 --> Helper loaded: form_helper
INFO - 2023-06-27 09:09:05 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:09:05 --> Helper loaded: security_helper
INFO - 2023-06-27 09:09:05 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:09:05 --> Database Driver Class Initialized
INFO - 2023-06-27 09:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:09:05 --> Parser Class Initialized
INFO - 2023-06-27 09:09:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:09:05 --> Pagination Class Initialized
INFO - 2023-06-27 09:09:05 --> Form Validation Class Initialized
INFO - 2023-06-27 09:09:05 --> Controller Class Initialized
INFO - 2023-06-27 09:09:05 --> Model Class Initialized
DEBUG - 2023-06-27 09:09:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:09:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:09:05 --> Model Class Initialized
DEBUG - 2023-06-27 09:09:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:09:05 --> Model Class Initialized
INFO - 2023-06-27 09:09:05 --> Final output sent to browser
DEBUG - 2023-06-27 09:09:05 --> Total execution time: 0.0190
ERROR - 2023-06-27 09:09:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:09:07 --> Config Class Initialized
INFO - 2023-06-27 09:09:07 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:09:07 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:09:07 --> Utf8 Class Initialized
INFO - 2023-06-27 09:09:07 --> URI Class Initialized
INFO - 2023-06-27 09:09:07 --> Router Class Initialized
INFO - 2023-06-27 09:09:07 --> Output Class Initialized
INFO - 2023-06-27 09:09:07 --> Security Class Initialized
DEBUG - 2023-06-27 09:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:09:07 --> Input Class Initialized
INFO - 2023-06-27 09:09:07 --> Language Class Initialized
INFO - 2023-06-27 09:09:07 --> Loader Class Initialized
INFO - 2023-06-27 09:09:07 --> Helper loaded: url_helper
INFO - 2023-06-27 09:09:07 --> Helper loaded: file_helper
INFO - 2023-06-27 09:09:07 --> Helper loaded: html_helper
INFO - 2023-06-27 09:09:07 --> Helper loaded: text_helper
INFO - 2023-06-27 09:09:07 --> Helper loaded: form_helper
INFO - 2023-06-27 09:09:07 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:09:07 --> Helper loaded: security_helper
INFO - 2023-06-27 09:09:07 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:09:07 --> Database Driver Class Initialized
INFO - 2023-06-27 09:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:09:07 --> Parser Class Initialized
INFO - 2023-06-27 09:09:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:09:07 --> Pagination Class Initialized
INFO - 2023-06-27 09:09:07 --> Form Validation Class Initialized
INFO - 2023-06-27 09:09:07 --> Controller Class Initialized
INFO - 2023-06-27 09:09:07 --> Model Class Initialized
DEBUG - 2023-06-27 09:09:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:09:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:09:07 --> Model Class Initialized
INFO - 2023-06-27 09:09:07 --> Model Class Initialized
INFO - 2023-06-27 09:09:07 --> Final output sent to browser
DEBUG - 2023-06-27 09:09:07 --> Total execution time: 0.0190
ERROR - 2023-06-27 09:09:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:09:09 --> Config Class Initialized
INFO - 2023-06-27 09:09:09 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:09:09 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:09:09 --> Utf8 Class Initialized
INFO - 2023-06-27 09:09:09 --> URI Class Initialized
INFO - 2023-06-27 09:09:09 --> Router Class Initialized
INFO - 2023-06-27 09:09:09 --> Output Class Initialized
INFO - 2023-06-27 09:09:09 --> Security Class Initialized
DEBUG - 2023-06-27 09:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:09:09 --> Input Class Initialized
INFO - 2023-06-27 09:09:09 --> Language Class Initialized
INFO - 2023-06-27 09:09:09 --> Loader Class Initialized
INFO - 2023-06-27 09:09:09 --> Helper loaded: url_helper
INFO - 2023-06-27 09:09:09 --> Helper loaded: file_helper
INFO - 2023-06-27 09:09:09 --> Helper loaded: html_helper
INFO - 2023-06-27 09:09:09 --> Helper loaded: text_helper
INFO - 2023-06-27 09:09:09 --> Helper loaded: form_helper
INFO - 2023-06-27 09:09:09 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:09:09 --> Helper loaded: security_helper
INFO - 2023-06-27 09:09:09 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:09:09 --> Database Driver Class Initialized
INFO - 2023-06-27 09:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:09:09 --> Parser Class Initialized
INFO - 2023-06-27 09:09:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:09:09 --> Pagination Class Initialized
INFO - 2023-06-27 09:09:09 --> Form Validation Class Initialized
INFO - 2023-06-27 09:09:09 --> Controller Class Initialized
INFO - 2023-06-27 09:09:09 --> Model Class Initialized
DEBUG - 2023-06-27 09:09:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:09:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:09:09 --> Model Class Initialized
INFO - 2023-06-27 09:09:09 --> Final output sent to browser
DEBUG - 2023-06-27 09:09:09 --> Total execution time: 0.0165
ERROR - 2023-06-27 09:09:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:09:32 --> Config Class Initialized
INFO - 2023-06-27 09:09:32 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:09:32 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:09:32 --> Utf8 Class Initialized
INFO - 2023-06-27 09:09:32 --> URI Class Initialized
INFO - 2023-06-27 09:09:32 --> Router Class Initialized
INFO - 2023-06-27 09:09:32 --> Output Class Initialized
INFO - 2023-06-27 09:09:32 --> Security Class Initialized
DEBUG - 2023-06-27 09:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:09:32 --> Input Class Initialized
INFO - 2023-06-27 09:09:32 --> Language Class Initialized
INFO - 2023-06-27 09:09:32 --> Loader Class Initialized
INFO - 2023-06-27 09:09:32 --> Helper loaded: url_helper
INFO - 2023-06-27 09:09:32 --> Helper loaded: file_helper
INFO - 2023-06-27 09:09:32 --> Helper loaded: html_helper
INFO - 2023-06-27 09:09:32 --> Helper loaded: text_helper
INFO - 2023-06-27 09:09:32 --> Helper loaded: form_helper
INFO - 2023-06-27 09:09:32 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:09:32 --> Helper loaded: security_helper
INFO - 2023-06-27 09:09:32 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:09:32 --> Database Driver Class Initialized
INFO - 2023-06-27 09:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:09:32 --> Parser Class Initialized
INFO - 2023-06-27 09:09:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:09:32 --> Pagination Class Initialized
INFO - 2023-06-27 09:09:32 --> Form Validation Class Initialized
INFO - 2023-06-27 09:09:32 --> Controller Class Initialized
INFO - 2023-06-27 09:09:32 --> Model Class Initialized
DEBUG - 2023-06-27 09:09:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:09:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:09:32 --> Model Class Initialized
DEBUG - 2023-06-27 09:09:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:09:32 --> Model Class Initialized
INFO - 2023-06-27 09:09:32 --> Final output sent to browser
DEBUG - 2023-06-27 09:09:32 --> Total execution time: 0.0578
ERROR - 2023-06-27 09:09:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:09:33 --> Config Class Initialized
INFO - 2023-06-27 09:09:33 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:09:33 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:09:33 --> Utf8 Class Initialized
INFO - 2023-06-27 09:09:33 --> URI Class Initialized
INFO - 2023-06-27 09:09:33 --> Router Class Initialized
INFO - 2023-06-27 09:09:33 --> Output Class Initialized
INFO - 2023-06-27 09:09:33 --> Security Class Initialized
DEBUG - 2023-06-27 09:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:09:33 --> Input Class Initialized
INFO - 2023-06-27 09:09:33 --> Language Class Initialized
INFO - 2023-06-27 09:09:33 --> Loader Class Initialized
INFO - 2023-06-27 09:09:33 --> Helper loaded: url_helper
INFO - 2023-06-27 09:09:33 --> Helper loaded: file_helper
INFO - 2023-06-27 09:09:33 --> Helper loaded: html_helper
INFO - 2023-06-27 09:09:33 --> Helper loaded: text_helper
INFO - 2023-06-27 09:09:33 --> Helper loaded: form_helper
INFO - 2023-06-27 09:09:33 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:09:33 --> Helper loaded: security_helper
INFO - 2023-06-27 09:09:33 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:09:33 --> Database Driver Class Initialized
INFO - 2023-06-27 09:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:09:33 --> Parser Class Initialized
INFO - 2023-06-27 09:09:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:09:33 --> Pagination Class Initialized
INFO - 2023-06-27 09:09:33 --> Form Validation Class Initialized
INFO - 2023-06-27 09:09:33 --> Controller Class Initialized
INFO - 2023-06-27 09:09:33 --> Model Class Initialized
DEBUG - 2023-06-27 09:09:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:09:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:09:33 --> Model Class Initialized
DEBUG - 2023-06-27 09:09:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:09:33 --> Model Class Initialized
INFO - 2023-06-27 09:09:33 --> Final output sent to browser
DEBUG - 2023-06-27 09:09:33 --> Total execution time: 0.0513
ERROR - 2023-06-27 09:09:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:09:33 --> Config Class Initialized
INFO - 2023-06-27 09:09:33 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:09:33 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:09:33 --> Utf8 Class Initialized
INFO - 2023-06-27 09:09:33 --> URI Class Initialized
INFO - 2023-06-27 09:09:33 --> Router Class Initialized
INFO - 2023-06-27 09:09:33 --> Output Class Initialized
INFO - 2023-06-27 09:09:33 --> Security Class Initialized
DEBUG - 2023-06-27 09:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:09:33 --> Input Class Initialized
INFO - 2023-06-27 09:09:33 --> Language Class Initialized
INFO - 2023-06-27 09:09:33 --> Loader Class Initialized
INFO - 2023-06-27 09:09:33 --> Helper loaded: url_helper
INFO - 2023-06-27 09:09:33 --> Helper loaded: file_helper
INFO - 2023-06-27 09:09:33 --> Helper loaded: html_helper
INFO - 2023-06-27 09:09:33 --> Helper loaded: text_helper
INFO - 2023-06-27 09:09:33 --> Helper loaded: form_helper
INFO - 2023-06-27 09:09:33 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:09:33 --> Helper loaded: security_helper
INFO - 2023-06-27 09:09:33 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:09:33 --> Database Driver Class Initialized
INFO - 2023-06-27 09:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:09:33 --> Parser Class Initialized
INFO - 2023-06-27 09:09:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:09:33 --> Pagination Class Initialized
INFO - 2023-06-27 09:09:33 --> Form Validation Class Initialized
INFO - 2023-06-27 09:09:33 --> Controller Class Initialized
INFO - 2023-06-27 09:09:33 --> Model Class Initialized
DEBUG - 2023-06-27 09:09:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:09:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:09:33 --> Model Class Initialized
DEBUG - 2023-06-27 09:09:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:09:33 --> Model Class Initialized
INFO - 2023-06-27 09:09:33 --> Final output sent to browser
DEBUG - 2023-06-27 09:09:33 --> Total execution time: 0.0475
ERROR - 2023-06-27 09:09:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:09:33 --> Config Class Initialized
INFO - 2023-06-27 09:09:33 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:09:33 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:09:33 --> Utf8 Class Initialized
INFO - 2023-06-27 09:09:33 --> URI Class Initialized
INFO - 2023-06-27 09:09:33 --> Router Class Initialized
INFO - 2023-06-27 09:09:33 --> Output Class Initialized
INFO - 2023-06-27 09:09:33 --> Security Class Initialized
DEBUG - 2023-06-27 09:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:09:33 --> Input Class Initialized
INFO - 2023-06-27 09:09:33 --> Language Class Initialized
INFO - 2023-06-27 09:09:33 --> Loader Class Initialized
INFO - 2023-06-27 09:09:33 --> Helper loaded: url_helper
INFO - 2023-06-27 09:09:33 --> Helper loaded: file_helper
INFO - 2023-06-27 09:09:33 --> Helper loaded: html_helper
INFO - 2023-06-27 09:09:33 --> Helper loaded: text_helper
INFO - 2023-06-27 09:09:33 --> Helper loaded: form_helper
INFO - 2023-06-27 09:09:33 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:09:33 --> Helper loaded: security_helper
INFO - 2023-06-27 09:09:33 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:09:33 --> Database Driver Class Initialized
INFO - 2023-06-27 09:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:09:33 --> Parser Class Initialized
INFO - 2023-06-27 09:09:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:09:33 --> Pagination Class Initialized
INFO - 2023-06-27 09:09:33 --> Form Validation Class Initialized
INFO - 2023-06-27 09:09:33 --> Controller Class Initialized
INFO - 2023-06-27 09:09:33 --> Model Class Initialized
DEBUG - 2023-06-27 09:09:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:09:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:09:33 --> Model Class Initialized
DEBUG - 2023-06-27 09:09:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:09:33 --> Model Class Initialized
INFO - 2023-06-27 09:09:33 --> Final output sent to browser
DEBUG - 2023-06-27 09:09:33 --> Total execution time: 0.0203
ERROR - 2023-06-27 09:09:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:09:34 --> Config Class Initialized
INFO - 2023-06-27 09:09:34 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:09:34 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:09:34 --> Utf8 Class Initialized
INFO - 2023-06-27 09:09:34 --> URI Class Initialized
INFO - 2023-06-27 09:09:34 --> Router Class Initialized
INFO - 2023-06-27 09:09:34 --> Output Class Initialized
INFO - 2023-06-27 09:09:34 --> Security Class Initialized
DEBUG - 2023-06-27 09:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:09:34 --> Input Class Initialized
INFO - 2023-06-27 09:09:34 --> Language Class Initialized
INFO - 2023-06-27 09:09:34 --> Loader Class Initialized
INFO - 2023-06-27 09:09:34 --> Helper loaded: url_helper
INFO - 2023-06-27 09:09:34 --> Helper loaded: file_helper
INFO - 2023-06-27 09:09:34 --> Helper loaded: html_helper
INFO - 2023-06-27 09:09:34 --> Helper loaded: text_helper
INFO - 2023-06-27 09:09:34 --> Helper loaded: form_helper
INFO - 2023-06-27 09:09:34 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:09:34 --> Helper loaded: security_helper
INFO - 2023-06-27 09:09:34 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:09:34 --> Database Driver Class Initialized
INFO - 2023-06-27 09:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:09:34 --> Parser Class Initialized
INFO - 2023-06-27 09:09:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:09:34 --> Pagination Class Initialized
INFO - 2023-06-27 09:09:34 --> Form Validation Class Initialized
INFO - 2023-06-27 09:09:34 --> Controller Class Initialized
INFO - 2023-06-27 09:09:34 --> Model Class Initialized
DEBUG - 2023-06-27 09:09:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:09:34 --> Model Class Initialized
DEBUG - 2023-06-27 09:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:09:34 --> Model Class Initialized
INFO - 2023-06-27 09:09:34 --> Final output sent to browser
DEBUG - 2023-06-27 09:09:34 --> Total execution time: 0.0238
ERROR - 2023-06-27 09:09:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:09:36 --> Config Class Initialized
INFO - 2023-06-27 09:09:36 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:09:36 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:09:36 --> Utf8 Class Initialized
INFO - 2023-06-27 09:09:36 --> URI Class Initialized
INFO - 2023-06-27 09:09:36 --> Router Class Initialized
INFO - 2023-06-27 09:09:36 --> Output Class Initialized
INFO - 2023-06-27 09:09:36 --> Security Class Initialized
DEBUG - 2023-06-27 09:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:09:36 --> Input Class Initialized
INFO - 2023-06-27 09:09:36 --> Language Class Initialized
INFO - 2023-06-27 09:09:36 --> Loader Class Initialized
INFO - 2023-06-27 09:09:36 --> Helper loaded: url_helper
INFO - 2023-06-27 09:09:36 --> Helper loaded: file_helper
INFO - 2023-06-27 09:09:36 --> Helper loaded: html_helper
INFO - 2023-06-27 09:09:36 --> Helper loaded: text_helper
INFO - 2023-06-27 09:09:36 --> Helper loaded: form_helper
INFO - 2023-06-27 09:09:36 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:09:36 --> Helper loaded: security_helper
INFO - 2023-06-27 09:09:36 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:09:36 --> Database Driver Class Initialized
INFO - 2023-06-27 09:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:09:36 --> Parser Class Initialized
INFO - 2023-06-27 09:09:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:09:36 --> Pagination Class Initialized
INFO - 2023-06-27 09:09:36 --> Form Validation Class Initialized
INFO - 2023-06-27 09:09:36 --> Controller Class Initialized
INFO - 2023-06-27 09:09:36 --> Model Class Initialized
DEBUG - 2023-06-27 09:09:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:09:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:09:36 --> Model Class Initialized
INFO - 2023-06-27 09:09:36 --> Model Class Initialized
INFO - 2023-06-27 09:09:36 --> Final output sent to browser
DEBUG - 2023-06-27 09:09:36 --> Total execution time: 0.0236
ERROR - 2023-06-27 09:09:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:09:36 --> Config Class Initialized
INFO - 2023-06-27 09:09:36 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:09:36 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:09:36 --> Utf8 Class Initialized
INFO - 2023-06-27 09:09:36 --> URI Class Initialized
INFO - 2023-06-27 09:09:36 --> Router Class Initialized
INFO - 2023-06-27 09:09:36 --> Output Class Initialized
INFO - 2023-06-27 09:09:36 --> Security Class Initialized
DEBUG - 2023-06-27 09:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:09:36 --> Input Class Initialized
INFO - 2023-06-27 09:09:36 --> Language Class Initialized
INFO - 2023-06-27 09:09:36 --> Loader Class Initialized
INFO - 2023-06-27 09:09:36 --> Helper loaded: url_helper
INFO - 2023-06-27 09:09:36 --> Helper loaded: file_helper
INFO - 2023-06-27 09:09:36 --> Helper loaded: html_helper
INFO - 2023-06-27 09:09:36 --> Helper loaded: text_helper
INFO - 2023-06-27 09:09:36 --> Helper loaded: form_helper
INFO - 2023-06-27 09:09:36 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:09:36 --> Helper loaded: security_helper
INFO - 2023-06-27 09:09:36 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:09:36 --> Database Driver Class Initialized
INFO - 2023-06-27 09:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:09:36 --> Parser Class Initialized
INFO - 2023-06-27 09:09:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:09:36 --> Pagination Class Initialized
INFO - 2023-06-27 09:09:36 --> Form Validation Class Initialized
INFO - 2023-06-27 09:09:36 --> Controller Class Initialized
INFO - 2023-06-27 09:09:36 --> Model Class Initialized
DEBUG - 2023-06-27 09:09:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:09:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:09:36 --> Model Class Initialized
DEBUG - 2023-06-27 09:09:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:09:36 --> Model Class Initialized
INFO - 2023-06-27 09:09:36 --> Final output sent to browser
DEBUG - 2023-06-27 09:09:36 --> Total execution time: 0.0220
ERROR - 2023-06-27 09:09:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:09:38 --> Config Class Initialized
INFO - 2023-06-27 09:09:38 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:09:38 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:09:38 --> Utf8 Class Initialized
INFO - 2023-06-27 09:09:38 --> URI Class Initialized
INFO - 2023-06-27 09:09:38 --> Router Class Initialized
INFO - 2023-06-27 09:09:38 --> Output Class Initialized
INFO - 2023-06-27 09:09:38 --> Security Class Initialized
DEBUG - 2023-06-27 09:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:09:38 --> Input Class Initialized
INFO - 2023-06-27 09:09:38 --> Language Class Initialized
INFO - 2023-06-27 09:09:38 --> Loader Class Initialized
INFO - 2023-06-27 09:09:38 --> Helper loaded: url_helper
INFO - 2023-06-27 09:09:38 --> Helper loaded: file_helper
INFO - 2023-06-27 09:09:38 --> Helper loaded: html_helper
INFO - 2023-06-27 09:09:38 --> Helper loaded: text_helper
INFO - 2023-06-27 09:09:38 --> Helper loaded: form_helper
INFO - 2023-06-27 09:09:38 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:09:38 --> Helper loaded: security_helper
INFO - 2023-06-27 09:09:38 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:09:38 --> Database Driver Class Initialized
INFO - 2023-06-27 09:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:09:38 --> Parser Class Initialized
INFO - 2023-06-27 09:09:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:09:38 --> Pagination Class Initialized
INFO - 2023-06-27 09:09:38 --> Form Validation Class Initialized
INFO - 2023-06-27 09:09:38 --> Controller Class Initialized
INFO - 2023-06-27 09:09:38 --> Model Class Initialized
DEBUG - 2023-06-27 09:09:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 09:09:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 09:09:38 --> Model Class Initialized
INFO - 2023-06-27 09:09:38 --> Final output sent to browser
DEBUG - 2023-06-27 09:09:38 --> Total execution time: 0.0165
ERROR - 2023-06-27 09:17:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:17:27 --> Config Class Initialized
INFO - 2023-06-27 09:17:27 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:17:27 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:17:27 --> Utf8 Class Initialized
INFO - 2023-06-27 09:17:27 --> URI Class Initialized
INFO - 2023-06-27 09:17:27 --> Router Class Initialized
INFO - 2023-06-27 09:17:27 --> Output Class Initialized
INFO - 2023-06-27 09:17:27 --> Security Class Initialized
DEBUG - 2023-06-27 09:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:17:27 --> Input Class Initialized
INFO - 2023-06-27 09:17:27 --> Language Class Initialized
INFO - 2023-06-27 09:17:27 --> Loader Class Initialized
INFO - 2023-06-27 09:17:27 --> Helper loaded: url_helper
INFO - 2023-06-27 09:17:27 --> Helper loaded: file_helper
INFO - 2023-06-27 09:17:27 --> Helper loaded: html_helper
INFO - 2023-06-27 09:17:27 --> Helper loaded: text_helper
INFO - 2023-06-27 09:17:27 --> Helper loaded: form_helper
INFO - 2023-06-27 09:17:27 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:17:27 --> Helper loaded: security_helper
INFO - 2023-06-27 09:17:27 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:17:27 --> Database Driver Class Initialized
INFO - 2023-06-27 09:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:17:27 --> Parser Class Initialized
INFO - 2023-06-27 09:17:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:17:27 --> Pagination Class Initialized
INFO - 2023-06-27 09:17:27 --> Form Validation Class Initialized
INFO - 2023-06-27 09:17:27 --> Controller Class Initialized
ERROR - 2023-06-27 09:18:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:18:12 --> Config Class Initialized
INFO - 2023-06-27 09:18:12 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:18:12 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:18:12 --> Utf8 Class Initialized
INFO - 2023-06-27 09:18:12 --> URI Class Initialized
INFO - 2023-06-27 09:18:12 --> Router Class Initialized
INFO - 2023-06-27 09:18:12 --> Output Class Initialized
INFO - 2023-06-27 09:18:12 --> Security Class Initialized
DEBUG - 2023-06-27 09:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:18:12 --> Input Class Initialized
INFO - 2023-06-27 09:18:12 --> Language Class Initialized
INFO - 2023-06-27 09:18:12 --> Loader Class Initialized
INFO - 2023-06-27 09:18:12 --> Helper loaded: url_helper
INFO - 2023-06-27 09:18:12 --> Helper loaded: file_helper
INFO - 2023-06-27 09:18:12 --> Helper loaded: html_helper
INFO - 2023-06-27 09:18:12 --> Helper loaded: text_helper
INFO - 2023-06-27 09:18:12 --> Helper loaded: form_helper
INFO - 2023-06-27 09:18:12 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:18:12 --> Helper loaded: security_helper
INFO - 2023-06-27 09:18:12 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:18:12 --> Database Driver Class Initialized
INFO - 2023-06-27 09:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:18:12 --> Parser Class Initialized
INFO - 2023-06-27 09:18:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:18:12 --> Pagination Class Initialized
INFO - 2023-06-27 09:18:12 --> Form Validation Class Initialized
INFO - 2023-06-27 09:18:12 --> Controller Class Initialized
ERROR - 2023-06-27 09:19:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:19:57 --> Config Class Initialized
INFO - 2023-06-27 09:19:57 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:19:57 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:19:57 --> Utf8 Class Initialized
INFO - 2023-06-27 09:19:57 --> URI Class Initialized
INFO - 2023-06-27 09:19:57 --> Router Class Initialized
INFO - 2023-06-27 09:19:57 --> Output Class Initialized
INFO - 2023-06-27 09:19:57 --> Security Class Initialized
DEBUG - 2023-06-27 09:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:19:57 --> Input Class Initialized
INFO - 2023-06-27 09:19:57 --> Language Class Initialized
INFO - 2023-06-27 09:19:57 --> Loader Class Initialized
INFO - 2023-06-27 09:19:57 --> Helper loaded: url_helper
INFO - 2023-06-27 09:19:57 --> Helper loaded: file_helper
INFO - 2023-06-27 09:19:57 --> Helper loaded: html_helper
INFO - 2023-06-27 09:19:57 --> Helper loaded: text_helper
INFO - 2023-06-27 09:19:57 --> Helper loaded: form_helper
INFO - 2023-06-27 09:19:57 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:19:57 --> Helper loaded: security_helper
INFO - 2023-06-27 09:19:57 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:19:57 --> Database Driver Class Initialized
INFO - 2023-06-27 09:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:19:57 --> Parser Class Initialized
INFO - 2023-06-27 09:19:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:19:57 --> Pagination Class Initialized
INFO - 2023-06-27 09:19:57 --> Form Validation Class Initialized
INFO - 2023-06-27 09:19:57 --> Controller Class Initialized
ERROR - 2023-06-27 09:22:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:22:53 --> Config Class Initialized
INFO - 2023-06-27 09:22:53 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:22:53 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:22:53 --> Utf8 Class Initialized
INFO - 2023-06-27 09:22:53 --> URI Class Initialized
INFO - 2023-06-27 09:22:53 --> Router Class Initialized
INFO - 2023-06-27 09:22:53 --> Output Class Initialized
INFO - 2023-06-27 09:22:53 --> Security Class Initialized
DEBUG - 2023-06-27 09:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:22:53 --> Input Class Initialized
INFO - 2023-06-27 09:22:53 --> Language Class Initialized
INFO - 2023-06-27 09:22:53 --> Loader Class Initialized
INFO - 2023-06-27 09:22:53 --> Helper loaded: url_helper
INFO - 2023-06-27 09:22:53 --> Helper loaded: file_helper
INFO - 2023-06-27 09:22:53 --> Helper loaded: html_helper
INFO - 2023-06-27 09:22:53 --> Helper loaded: text_helper
INFO - 2023-06-27 09:22:53 --> Helper loaded: form_helper
INFO - 2023-06-27 09:22:53 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:22:53 --> Helper loaded: security_helper
INFO - 2023-06-27 09:22:53 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:22:53 --> Database Driver Class Initialized
INFO - 2023-06-27 09:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:22:53 --> Parser Class Initialized
INFO - 2023-06-27 09:22:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:22:53 --> Pagination Class Initialized
INFO - 2023-06-27 09:22:53 --> Form Validation Class Initialized
INFO - 2023-06-27 09:22:53 --> Controller Class Initialized
ERROR - 2023-06-27 09:24:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 09:24:21 --> Config Class Initialized
INFO - 2023-06-27 09:24:21 --> Hooks Class Initialized
DEBUG - 2023-06-27 09:24:21 --> UTF-8 Support Enabled
INFO - 2023-06-27 09:24:21 --> Utf8 Class Initialized
INFO - 2023-06-27 09:24:21 --> URI Class Initialized
INFO - 2023-06-27 09:24:21 --> Router Class Initialized
INFO - 2023-06-27 09:24:21 --> Output Class Initialized
INFO - 2023-06-27 09:24:21 --> Security Class Initialized
DEBUG - 2023-06-27 09:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 09:24:21 --> Input Class Initialized
INFO - 2023-06-27 09:24:21 --> Language Class Initialized
INFO - 2023-06-27 09:24:21 --> Loader Class Initialized
INFO - 2023-06-27 09:24:21 --> Helper loaded: url_helper
INFO - 2023-06-27 09:24:21 --> Helper loaded: file_helper
INFO - 2023-06-27 09:24:21 --> Helper loaded: html_helper
INFO - 2023-06-27 09:24:21 --> Helper loaded: text_helper
INFO - 2023-06-27 09:24:21 --> Helper loaded: form_helper
INFO - 2023-06-27 09:24:21 --> Helper loaded: lang_helper
INFO - 2023-06-27 09:24:21 --> Helper loaded: security_helper
INFO - 2023-06-27 09:24:21 --> Helper loaded: cookie_helper
INFO - 2023-06-27 09:24:21 --> Database Driver Class Initialized
INFO - 2023-06-27 09:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 09:24:21 --> Parser Class Initialized
INFO - 2023-06-27 09:24:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 09:24:21 --> Pagination Class Initialized
INFO - 2023-06-27 09:24:21 --> Form Validation Class Initialized
INFO - 2023-06-27 09:24:21 --> Controller Class Initialized
ERROR - 2023-06-27 10:30:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 10:30:34 --> Config Class Initialized
INFO - 2023-06-27 10:30:34 --> Hooks Class Initialized
DEBUG - 2023-06-27 10:30:34 --> UTF-8 Support Enabled
INFO - 2023-06-27 10:30:34 --> Utf8 Class Initialized
INFO - 2023-06-27 10:30:34 --> URI Class Initialized
DEBUG - 2023-06-27 10:30:34 --> No URI present. Default controller set.
INFO - 2023-06-27 10:30:34 --> Router Class Initialized
INFO - 2023-06-27 10:30:34 --> Output Class Initialized
INFO - 2023-06-27 10:30:34 --> Security Class Initialized
DEBUG - 2023-06-27 10:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 10:30:34 --> Input Class Initialized
INFO - 2023-06-27 10:30:34 --> Language Class Initialized
INFO - 2023-06-27 10:30:34 --> Loader Class Initialized
INFO - 2023-06-27 10:30:34 --> Helper loaded: url_helper
INFO - 2023-06-27 10:30:34 --> Helper loaded: file_helper
INFO - 2023-06-27 10:30:34 --> Helper loaded: html_helper
INFO - 2023-06-27 10:30:34 --> Helper loaded: text_helper
INFO - 2023-06-27 10:30:34 --> Helper loaded: form_helper
INFO - 2023-06-27 10:30:34 --> Helper loaded: lang_helper
INFO - 2023-06-27 10:30:34 --> Helper loaded: security_helper
INFO - 2023-06-27 10:30:34 --> Helper loaded: cookie_helper
INFO - 2023-06-27 10:30:34 --> Database Driver Class Initialized
INFO - 2023-06-27 10:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 10:30:34 --> Parser Class Initialized
INFO - 2023-06-27 10:30:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 10:30:34 --> Pagination Class Initialized
INFO - 2023-06-27 10:30:34 --> Form Validation Class Initialized
INFO - 2023-06-27 10:30:34 --> Controller Class Initialized
INFO - 2023-06-27 10:30:34 --> Model Class Initialized
DEBUG - 2023-06-27 10:30:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-27 10:30:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 10:30:35 --> Config Class Initialized
INFO - 2023-06-27 10:30:35 --> Hooks Class Initialized
DEBUG - 2023-06-27 10:30:35 --> UTF-8 Support Enabled
INFO - 2023-06-27 10:30:35 --> Utf8 Class Initialized
INFO - 2023-06-27 10:30:35 --> URI Class Initialized
INFO - 2023-06-27 10:30:35 --> Router Class Initialized
INFO - 2023-06-27 10:30:35 --> Output Class Initialized
INFO - 2023-06-27 10:30:35 --> Security Class Initialized
DEBUG - 2023-06-27 10:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 10:30:35 --> Input Class Initialized
INFO - 2023-06-27 10:30:35 --> Language Class Initialized
INFO - 2023-06-27 10:30:35 --> Loader Class Initialized
INFO - 2023-06-27 10:30:35 --> Helper loaded: url_helper
INFO - 2023-06-27 10:30:35 --> Helper loaded: file_helper
INFO - 2023-06-27 10:30:35 --> Helper loaded: html_helper
INFO - 2023-06-27 10:30:35 --> Helper loaded: text_helper
INFO - 2023-06-27 10:30:35 --> Helper loaded: form_helper
INFO - 2023-06-27 10:30:35 --> Helper loaded: lang_helper
INFO - 2023-06-27 10:30:35 --> Helper loaded: security_helper
INFO - 2023-06-27 10:30:35 --> Helper loaded: cookie_helper
INFO - 2023-06-27 10:30:35 --> Database Driver Class Initialized
INFO - 2023-06-27 10:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 10:30:35 --> Parser Class Initialized
INFO - 2023-06-27 10:30:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 10:30:35 --> Pagination Class Initialized
INFO - 2023-06-27 10:30:35 --> Form Validation Class Initialized
INFO - 2023-06-27 10:30:35 --> Controller Class Initialized
INFO - 2023-06-27 10:30:35 --> Model Class Initialized
DEBUG - 2023-06-27 10:30:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 10:30:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-27 10:30:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 10:30:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 10:30:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 10:30:35 --> Model Class Initialized
INFO - 2023-06-27 10:30:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 10:30:35 --> Final output sent to browser
DEBUG - 2023-06-27 10:30:35 --> Total execution time: 0.0347
ERROR - 2023-06-27 10:31:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 10:31:01 --> Config Class Initialized
INFO - 2023-06-27 10:31:01 --> Hooks Class Initialized
DEBUG - 2023-06-27 10:31:01 --> UTF-8 Support Enabled
INFO - 2023-06-27 10:31:01 --> Utf8 Class Initialized
INFO - 2023-06-27 10:31:01 --> URI Class Initialized
INFO - 2023-06-27 10:31:01 --> Router Class Initialized
INFO - 2023-06-27 10:31:01 --> Output Class Initialized
INFO - 2023-06-27 10:31:01 --> Security Class Initialized
DEBUG - 2023-06-27 10:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 10:31:01 --> Input Class Initialized
INFO - 2023-06-27 10:31:01 --> Language Class Initialized
INFO - 2023-06-27 10:31:01 --> Loader Class Initialized
INFO - 2023-06-27 10:31:01 --> Helper loaded: url_helper
INFO - 2023-06-27 10:31:01 --> Helper loaded: file_helper
INFO - 2023-06-27 10:31:01 --> Helper loaded: html_helper
INFO - 2023-06-27 10:31:01 --> Helper loaded: text_helper
INFO - 2023-06-27 10:31:01 --> Helper loaded: form_helper
INFO - 2023-06-27 10:31:01 --> Helper loaded: lang_helper
INFO - 2023-06-27 10:31:01 --> Helper loaded: security_helper
INFO - 2023-06-27 10:31:01 --> Helper loaded: cookie_helper
INFO - 2023-06-27 10:31:01 --> Database Driver Class Initialized
INFO - 2023-06-27 10:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 10:31:01 --> Parser Class Initialized
INFO - 2023-06-27 10:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 10:31:01 --> Pagination Class Initialized
INFO - 2023-06-27 10:31:01 --> Form Validation Class Initialized
INFO - 2023-06-27 10:31:01 --> Controller Class Initialized
INFO - 2023-06-27 10:31:01 --> Model Class Initialized
DEBUG - 2023-06-27 10:31:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 10:31:01 --> Model Class Initialized
INFO - 2023-06-27 10:31:01 --> Final output sent to browser
DEBUG - 2023-06-27 10:31:01 --> Total execution time: 0.0196
ERROR - 2023-06-27 10:31:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 10:31:01 --> Config Class Initialized
INFO - 2023-06-27 10:31:01 --> Hooks Class Initialized
DEBUG - 2023-06-27 10:31:01 --> UTF-8 Support Enabled
INFO - 2023-06-27 10:31:01 --> Utf8 Class Initialized
INFO - 2023-06-27 10:31:01 --> URI Class Initialized
DEBUG - 2023-06-27 10:31:01 --> No URI present. Default controller set.
INFO - 2023-06-27 10:31:01 --> Router Class Initialized
INFO - 2023-06-27 10:31:01 --> Output Class Initialized
INFO - 2023-06-27 10:31:01 --> Security Class Initialized
DEBUG - 2023-06-27 10:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 10:31:01 --> Input Class Initialized
INFO - 2023-06-27 10:31:01 --> Language Class Initialized
INFO - 2023-06-27 10:31:01 --> Loader Class Initialized
INFO - 2023-06-27 10:31:01 --> Helper loaded: url_helper
INFO - 2023-06-27 10:31:01 --> Helper loaded: file_helper
INFO - 2023-06-27 10:31:01 --> Helper loaded: html_helper
INFO - 2023-06-27 10:31:01 --> Helper loaded: text_helper
INFO - 2023-06-27 10:31:01 --> Helper loaded: form_helper
INFO - 2023-06-27 10:31:01 --> Helper loaded: lang_helper
INFO - 2023-06-27 10:31:01 --> Helper loaded: security_helper
INFO - 2023-06-27 10:31:01 --> Helper loaded: cookie_helper
INFO - 2023-06-27 10:31:01 --> Database Driver Class Initialized
INFO - 2023-06-27 10:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 10:31:01 --> Parser Class Initialized
INFO - 2023-06-27 10:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 10:31:01 --> Pagination Class Initialized
INFO - 2023-06-27 10:31:01 --> Form Validation Class Initialized
INFO - 2023-06-27 10:31:01 --> Controller Class Initialized
INFO - 2023-06-27 10:31:01 --> Model Class Initialized
DEBUG - 2023-06-27 10:31:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 10:31:01 --> Model Class Initialized
DEBUG - 2023-06-27 10:31:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 10:31:01 --> Model Class Initialized
INFO - 2023-06-27 10:31:01 --> Model Class Initialized
INFO - 2023-06-27 10:31:01 --> Model Class Initialized
INFO - 2023-06-27 10:31:01 --> Model Class Initialized
DEBUG - 2023-06-27 10:31:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 10:31:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 10:31:01 --> Model Class Initialized
INFO - 2023-06-27 10:31:01 --> Model Class Initialized
INFO - 2023-06-27 10:31:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 10:31:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 10:31:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 10:31:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 10:31:01 --> Model Class Initialized
INFO - 2023-06-27 10:31:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 10:31:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 10:31:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 10:31:01 --> Final output sent to browser
DEBUG - 2023-06-27 10:31:01 --> Total execution time: 0.0946
ERROR - 2023-06-27 11:09:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:09:24 --> Config Class Initialized
INFO - 2023-06-27 11:09:24 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:09:24 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:09:24 --> Utf8 Class Initialized
INFO - 2023-06-27 11:09:24 --> URI Class Initialized
DEBUG - 2023-06-27 11:09:24 --> No URI present. Default controller set.
INFO - 2023-06-27 11:09:24 --> Router Class Initialized
INFO - 2023-06-27 11:09:24 --> Output Class Initialized
INFO - 2023-06-27 11:09:24 --> Security Class Initialized
DEBUG - 2023-06-27 11:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:09:24 --> Input Class Initialized
INFO - 2023-06-27 11:09:24 --> Language Class Initialized
INFO - 2023-06-27 11:09:24 --> Loader Class Initialized
INFO - 2023-06-27 11:09:24 --> Helper loaded: url_helper
INFO - 2023-06-27 11:09:24 --> Helper loaded: file_helper
INFO - 2023-06-27 11:09:24 --> Helper loaded: html_helper
INFO - 2023-06-27 11:09:24 --> Helper loaded: text_helper
INFO - 2023-06-27 11:09:24 --> Helper loaded: form_helper
INFO - 2023-06-27 11:09:24 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:09:24 --> Helper loaded: security_helper
INFO - 2023-06-27 11:09:24 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:09:24 --> Database Driver Class Initialized
INFO - 2023-06-27 11:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:09:24 --> Parser Class Initialized
INFO - 2023-06-27 11:09:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:09:24 --> Pagination Class Initialized
INFO - 2023-06-27 11:09:24 --> Form Validation Class Initialized
INFO - 2023-06-27 11:09:24 --> Controller Class Initialized
INFO - 2023-06-27 11:09:24 --> Model Class Initialized
DEBUG - 2023-06-27 11:09:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:09:24 --> Model Class Initialized
DEBUG - 2023-06-27 11:09:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:09:24 --> Model Class Initialized
INFO - 2023-06-27 11:09:24 --> Model Class Initialized
INFO - 2023-06-27 11:09:24 --> Model Class Initialized
INFO - 2023-06-27 11:09:24 --> Model Class Initialized
DEBUG - 2023-06-27 11:09:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:09:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:09:24 --> Model Class Initialized
INFO - 2023-06-27 11:09:24 --> Model Class Initialized
INFO - 2023-06-27 11:09:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 11:09:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:09:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 11:09:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 11:09:24 --> Model Class Initialized
INFO - 2023-06-27 11:09:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 11:09:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 11:09:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 11:09:24 --> Final output sent to browser
DEBUG - 2023-06-27 11:09:24 --> Total execution time: 0.0863
ERROR - 2023-06-27 11:09:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:09:30 --> Config Class Initialized
INFO - 2023-06-27 11:09:30 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:09:30 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:09:30 --> Utf8 Class Initialized
INFO - 2023-06-27 11:09:30 --> URI Class Initialized
INFO - 2023-06-27 11:09:30 --> Router Class Initialized
INFO - 2023-06-27 11:09:30 --> Output Class Initialized
INFO - 2023-06-27 11:09:30 --> Security Class Initialized
DEBUG - 2023-06-27 11:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:09:30 --> Input Class Initialized
INFO - 2023-06-27 11:09:30 --> Language Class Initialized
INFO - 2023-06-27 11:09:30 --> Loader Class Initialized
INFO - 2023-06-27 11:09:30 --> Helper loaded: url_helper
INFO - 2023-06-27 11:09:30 --> Helper loaded: file_helper
INFO - 2023-06-27 11:09:30 --> Helper loaded: html_helper
INFO - 2023-06-27 11:09:30 --> Helper loaded: text_helper
INFO - 2023-06-27 11:09:30 --> Helper loaded: form_helper
INFO - 2023-06-27 11:09:30 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:09:30 --> Helper loaded: security_helper
INFO - 2023-06-27 11:09:30 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:09:30 --> Database Driver Class Initialized
INFO - 2023-06-27 11:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:09:30 --> Parser Class Initialized
INFO - 2023-06-27 11:09:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:09:30 --> Pagination Class Initialized
INFO - 2023-06-27 11:09:30 --> Form Validation Class Initialized
INFO - 2023-06-27 11:09:30 --> Controller Class Initialized
INFO - 2023-06-27 11:09:30 --> Model Class Initialized
DEBUG - 2023-06-27 11:09:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:09:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:09:30 --> Model Class Initialized
DEBUG - 2023-06-27 11:09:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:09:30 --> Model Class Initialized
INFO - 2023-06-27 11:09:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-06-27 11:09:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:09:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 11:09:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 11:09:30 --> Model Class Initialized
INFO - 2023-06-27 11:09:30 --> Model Class Initialized
INFO - 2023-06-27 11:09:30 --> Model Class Initialized
INFO - 2023-06-27 11:09:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 11:09:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 11:09:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 11:09:30 --> Final output sent to browser
DEBUG - 2023-06-27 11:09:30 --> Total execution time: 0.1026
ERROR - 2023-06-27 11:09:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:09:34 --> Config Class Initialized
INFO - 2023-06-27 11:09:34 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:09:34 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:09:34 --> Utf8 Class Initialized
INFO - 2023-06-27 11:09:34 --> URI Class Initialized
INFO - 2023-06-27 11:09:34 --> Router Class Initialized
INFO - 2023-06-27 11:09:34 --> Output Class Initialized
INFO - 2023-06-27 11:09:34 --> Security Class Initialized
DEBUG - 2023-06-27 11:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:09:34 --> Input Class Initialized
INFO - 2023-06-27 11:09:34 --> Language Class Initialized
INFO - 2023-06-27 11:09:34 --> Loader Class Initialized
INFO - 2023-06-27 11:09:34 --> Helper loaded: url_helper
INFO - 2023-06-27 11:09:34 --> Helper loaded: file_helper
INFO - 2023-06-27 11:09:34 --> Helper loaded: html_helper
INFO - 2023-06-27 11:09:34 --> Helper loaded: text_helper
INFO - 2023-06-27 11:09:34 --> Helper loaded: form_helper
INFO - 2023-06-27 11:09:34 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:09:34 --> Helper loaded: security_helper
INFO - 2023-06-27 11:09:34 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:09:34 --> Database Driver Class Initialized
INFO - 2023-06-27 11:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:09:34 --> Parser Class Initialized
INFO - 2023-06-27 11:09:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:09:34 --> Pagination Class Initialized
INFO - 2023-06-27 11:09:34 --> Form Validation Class Initialized
INFO - 2023-06-27 11:09:34 --> Controller Class Initialized
INFO - 2023-06-27 11:09:34 --> Model Class Initialized
DEBUG - 2023-06-27 11:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:09:34 --> Final output sent to browser
DEBUG - 2023-06-27 11:09:34 --> Total execution time: 0.0165
ERROR - 2023-06-27 11:09:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:09:36 --> Config Class Initialized
INFO - 2023-06-27 11:09:36 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:09:36 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:09:36 --> Utf8 Class Initialized
INFO - 2023-06-27 11:09:36 --> URI Class Initialized
INFO - 2023-06-27 11:09:36 --> Router Class Initialized
INFO - 2023-06-27 11:09:36 --> Output Class Initialized
INFO - 2023-06-27 11:09:36 --> Security Class Initialized
DEBUG - 2023-06-27 11:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:09:36 --> Input Class Initialized
INFO - 2023-06-27 11:09:36 --> Language Class Initialized
INFO - 2023-06-27 11:09:36 --> Loader Class Initialized
INFO - 2023-06-27 11:09:36 --> Helper loaded: url_helper
INFO - 2023-06-27 11:09:36 --> Helper loaded: file_helper
INFO - 2023-06-27 11:09:36 --> Helper loaded: html_helper
INFO - 2023-06-27 11:09:36 --> Helper loaded: text_helper
INFO - 2023-06-27 11:09:36 --> Helper loaded: form_helper
INFO - 2023-06-27 11:09:36 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:09:36 --> Helper loaded: security_helper
INFO - 2023-06-27 11:09:36 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:09:36 --> Database Driver Class Initialized
INFO - 2023-06-27 11:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:09:36 --> Parser Class Initialized
INFO - 2023-06-27 11:09:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:09:36 --> Pagination Class Initialized
INFO - 2023-06-27 11:09:36 --> Form Validation Class Initialized
INFO - 2023-06-27 11:09:36 --> Controller Class Initialized
INFO - 2023-06-27 11:09:36 --> Final output sent to browser
DEBUG - 2023-06-27 11:09:36 --> Total execution time: 0.0167
ERROR - 2023-06-27 11:09:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:09:39 --> Config Class Initialized
INFO - 2023-06-27 11:09:39 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:09:39 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:09:39 --> Utf8 Class Initialized
INFO - 2023-06-27 11:09:39 --> URI Class Initialized
INFO - 2023-06-27 11:09:39 --> Router Class Initialized
INFO - 2023-06-27 11:09:39 --> Output Class Initialized
INFO - 2023-06-27 11:09:39 --> Security Class Initialized
DEBUG - 2023-06-27 11:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:09:39 --> Input Class Initialized
INFO - 2023-06-27 11:09:39 --> Language Class Initialized
INFO - 2023-06-27 11:09:39 --> Loader Class Initialized
INFO - 2023-06-27 11:09:39 --> Helper loaded: url_helper
INFO - 2023-06-27 11:09:39 --> Helper loaded: file_helper
INFO - 2023-06-27 11:09:39 --> Helper loaded: html_helper
INFO - 2023-06-27 11:09:39 --> Helper loaded: text_helper
INFO - 2023-06-27 11:09:39 --> Helper loaded: form_helper
INFO - 2023-06-27 11:09:39 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:09:39 --> Helper loaded: security_helper
INFO - 2023-06-27 11:09:39 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:09:39 --> Database Driver Class Initialized
INFO - 2023-06-27 11:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:09:39 --> Parser Class Initialized
INFO - 2023-06-27 11:09:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:09:39 --> Pagination Class Initialized
INFO - 2023-06-27 11:09:39 --> Form Validation Class Initialized
INFO - 2023-06-27 11:09:39 --> Controller Class Initialized
INFO - 2023-06-27 11:09:39 --> Model Class Initialized
DEBUG - 2023-06-27 11:09:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:09:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:09:39 --> Model Class Initialized
DEBUG - 2023-06-27 11:09:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:09:39 --> Model Class Initialized
INFO - 2023-06-27 11:09:39 --> Final output sent to browser
DEBUG - 2023-06-27 11:09:39 --> Total execution time: 0.0458
ERROR - 2023-06-27 11:09:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:09:39 --> Config Class Initialized
INFO - 2023-06-27 11:09:39 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:09:39 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:09:39 --> Utf8 Class Initialized
INFO - 2023-06-27 11:09:39 --> URI Class Initialized
INFO - 2023-06-27 11:09:39 --> Router Class Initialized
INFO - 2023-06-27 11:09:39 --> Output Class Initialized
INFO - 2023-06-27 11:09:39 --> Security Class Initialized
DEBUG - 2023-06-27 11:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:09:39 --> Input Class Initialized
INFO - 2023-06-27 11:09:39 --> Language Class Initialized
INFO - 2023-06-27 11:09:39 --> Loader Class Initialized
INFO - 2023-06-27 11:09:39 --> Helper loaded: url_helper
INFO - 2023-06-27 11:09:39 --> Helper loaded: file_helper
INFO - 2023-06-27 11:09:39 --> Helper loaded: html_helper
INFO - 2023-06-27 11:09:39 --> Helper loaded: text_helper
INFO - 2023-06-27 11:09:39 --> Helper loaded: form_helper
INFO - 2023-06-27 11:09:39 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:09:39 --> Helper loaded: security_helper
INFO - 2023-06-27 11:09:39 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:09:39 --> Database Driver Class Initialized
INFO - 2023-06-27 11:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:09:39 --> Parser Class Initialized
INFO - 2023-06-27 11:09:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:09:39 --> Pagination Class Initialized
INFO - 2023-06-27 11:09:39 --> Form Validation Class Initialized
INFO - 2023-06-27 11:09:39 --> Controller Class Initialized
INFO - 2023-06-27 11:09:39 --> Model Class Initialized
DEBUG - 2023-06-27 11:09:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:09:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:09:39 --> Model Class Initialized
DEBUG - 2023-06-27 11:09:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:09:39 --> Model Class Initialized
INFO - 2023-06-27 11:09:40 --> Final output sent to browser
DEBUG - 2023-06-27 11:09:40 --> Total execution time: 0.0469
ERROR - 2023-06-27 11:09:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:09:40 --> Config Class Initialized
INFO - 2023-06-27 11:09:40 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:09:40 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:09:40 --> Utf8 Class Initialized
INFO - 2023-06-27 11:09:40 --> URI Class Initialized
INFO - 2023-06-27 11:09:40 --> Router Class Initialized
INFO - 2023-06-27 11:09:40 --> Output Class Initialized
INFO - 2023-06-27 11:09:40 --> Security Class Initialized
DEBUG - 2023-06-27 11:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:09:40 --> Input Class Initialized
INFO - 2023-06-27 11:09:40 --> Language Class Initialized
INFO - 2023-06-27 11:09:40 --> Loader Class Initialized
INFO - 2023-06-27 11:09:40 --> Helper loaded: url_helper
INFO - 2023-06-27 11:09:40 --> Helper loaded: file_helper
INFO - 2023-06-27 11:09:40 --> Helper loaded: html_helper
INFO - 2023-06-27 11:09:40 --> Helper loaded: text_helper
INFO - 2023-06-27 11:09:40 --> Helper loaded: form_helper
INFO - 2023-06-27 11:09:40 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:09:40 --> Helper loaded: security_helper
INFO - 2023-06-27 11:09:40 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:09:40 --> Database Driver Class Initialized
INFO - 2023-06-27 11:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:09:40 --> Parser Class Initialized
INFO - 2023-06-27 11:09:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:09:40 --> Pagination Class Initialized
INFO - 2023-06-27 11:09:40 --> Form Validation Class Initialized
INFO - 2023-06-27 11:09:40 --> Controller Class Initialized
INFO - 2023-06-27 11:09:40 --> Model Class Initialized
DEBUG - 2023-06-27 11:09:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:09:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:09:40 --> Model Class Initialized
DEBUG - 2023-06-27 11:09:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:09:40 --> Model Class Initialized
INFO - 2023-06-27 11:09:40 --> Final output sent to browser
DEBUG - 2023-06-27 11:09:40 --> Total execution time: 0.0468
ERROR - 2023-06-27 11:09:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:09:50 --> Config Class Initialized
INFO - 2023-06-27 11:09:50 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:09:50 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:09:50 --> Utf8 Class Initialized
INFO - 2023-06-27 11:09:50 --> URI Class Initialized
INFO - 2023-06-27 11:09:50 --> Router Class Initialized
INFO - 2023-06-27 11:09:50 --> Output Class Initialized
INFO - 2023-06-27 11:09:50 --> Security Class Initialized
DEBUG - 2023-06-27 11:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:09:50 --> Input Class Initialized
INFO - 2023-06-27 11:09:50 --> Language Class Initialized
INFO - 2023-06-27 11:09:50 --> Loader Class Initialized
INFO - 2023-06-27 11:09:50 --> Helper loaded: url_helper
INFO - 2023-06-27 11:09:50 --> Helper loaded: file_helper
INFO - 2023-06-27 11:09:50 --> Helper loaded: html_helper
INFO - 2023-06-27 11:09:50 --> Helper loaded: text_helper
INFO - 2023-06-27 11:09:50 --> Helper loaded: form_helper
INFO - 2023-06-27 11:09:50 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:09:50 --> Helper loaded: security_helper
INFO - 2023-06-27 11:09:50 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:09:50 --> Database Driver Class Initialized
INFO - 2023-06-27 11:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:09:50 --> Parser Class Initialized
INFO - 2023-06-27 11:09:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:09:50 --> Pagination Class Initialized
INFO - 2023-06-27 11:09:50 --> Form Validation Class Initialized
INFO - 2023-06-27 11:09:50 --> Controller Class Initialized
INFO - 2023-06-27 11:09:50 --> Model Class Initialized
DEBUG - 2023-06-27 11:09:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:09:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:09:50 --> Model Class Initialized
DEBUG - 2023-06-27 11:09:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:09:50 --> Model Class Initialized
INFO - 2023-06-27 11:09:50 --> Final output sent to browser
DEBUG - 2023-06-27 11:09:50 --> Total execution time: 0.0183
ERROR - 2023-06-27 11:09:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:09:53 --> Config Class Initialized
INFO - 2023-06-27 11:09:53 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:09:53 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:09:53 --> Utf8 Class Initialized
INFO - 2023-06-27 11:09:53 --> URI Class Initialized
INFO - 2023-06-27 11:09:53 --> Router Class Initialized
INFO - 2023-06-27 11:09:53 --> Output Class Initialized
INFO - 2023-06-27 11:09:53 --> Security Class Initialized
DEBUG - 2023-06-27 11:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:09:53 --> Input Class Initialized
INFO - 2023-06-27 11:09:53 --> Language Class Initialized
INFO - 2023-06-27 11:09:53 --> Loader Class Initialized
INFO - 2023-06-27 11:09:53 --> Helper loaded: url_helper
INFO - 2023-06-27 11:09:53 --> Helper loaded: file_helper
INFO - 2023-06-27 11:09:53 --> Helper loaded: html_helper
INFO - 2023-06-27 11:09:53 --> Helper loaded: text_helper
INFO - 2023-06-27 11:09:53 --> Helper loaded: form_helper
INFO - 2023-06-27 11:09:53 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:09:53 --> Helper loaded: security_helper
INFO - 2023-06-27 11:09:53 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:09:53 --> Database Driver Class Initialized
INFO - 2023-06-27 11:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:09:53 --> Parser Class Initialized
INFO - 2023-06-27 11:09:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:09:53 --> Pagination Class Initialized
INFO - 2023-06-27 11:09:53 --> Form Validation Class Initialized
INFO - 2023-06-27 11:09:53 --> Controller Class Initialized
INFO - 2023-06-27 11:09:53 --> Model Class Initialized
DEBUG - 2023-06-27 11:09:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:09:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:09:53 --> Model Class Initialized
DEBUG - 2023-06-27 11:09:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:09:53 --> Model Class Initialized
INFO - 2023-06-27 11:09:53 --> Final output sent to browser
DEBUG - 2023-06-27 11:09:53 --> Total execution time: 0.0193
ERROR - 2023-06-27 11:09:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:09:57 --> Config Class Initialized
INFO - 2023-06-27 11:09:57 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:09:57 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:09:57 --> Utf8 Class Initialized
INFO - 2023-06-27 11:09:57 --> URI Class Initialized
INFO - 2023-06-27 11:09:57 --> Router Class Initialized
INFO - 2023-06-27 11:09:57 --> Output Class Initialized
INFO - 2023-06-27 11:09:57 --> Security Class Initialized
DEBUG - 2023-06-27 11:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:09:57 --> Input Class Initialized
INFO - 2023-06-27 11:09:57 --> Language Class Initialized
INFO - 2023-06-27 11:09:57 --> Loader Class Initialized
INFO - 2023-06-27 11:09:57 --> Helper loaded: url_helper
INFO - 2023-06-27 11:09:57 --> Helper loaded: file_helper
INFO - 2023-06-27 11:09:57 --> Helper loaded: html_helper
INFO - 2023-06-27 11:09:57 --> Helper loaded: text_helper
INFO - 2023-06-27 11:09:57 --> Helper loaded: form_helper
INFO - 2023-06-27 11:09:57 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:09:57 --> Helper loaded: security_helper
INFO - 2023-06-27 11:09:57 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:09:57 --> Database Driver Class Initialized
INFO - 2023-06-27 11:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:09:57 --> Parser Class Initialized
INFO - 2023-06-27 11:09:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:09:57 --> Pagination Class Initialized
INFO - 2023-06-27 11:09:57 --> Form Validation Class Initialized
INFO - 2023-06-27 11:09:57 --> Controller Class Initialized
INFO - 2023-06-27 11:09:57 --> Model Class Initialized
DEBUG - 2023-06-27 11:09:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:09:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:09:57 --> Model Class Initialized
DEBUG - 2023-06-27 11:09:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:09:57 --> Model Class Initialized
INFO - 2023-06-27 11:09:57 --> Final output sent to browser
DEBUG - 2023-06-27 11:09:57 --> Total execution time: 0.0186
ERROR - 2023-06-27 11:09:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:09:58 --> Config Class Initialized
INFO - 2023-06-27 11:09:58 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:09:58 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:09:58 --> Utf8 Class Initialized
INFO - 2023-06-27 11:09:58 --> URI Class Initialized
INFO - 2023-06-27 11:09:58 --> Router Class Initialized
INFO - 2023-06-27 11:09:58 --> Output Class Initialized
INFO - 2023-06-27 11:09:58 --> Security Class Initialized
DEBUG - 2023-06-27 11:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:09:58 --> Input Class Initialized
INFO - 2023-06-27 11:09:58 --> Language Class Initialized
INFO - 2023-06-27 11:09:58 --> Loader Class Initialized
INFO - 2023-06-27 11:09:58 --> Helper loaded: url_helper
INFO - 2023-06-27 11:09:58 --> Helper loaded: file_helper
INFO - 2023-06-27 11:09:58 --> Helper loaded: html_helper
INFO - 2023-06-27 11:09:58 --> Helper loaded: text_helper
INFO - 2023-06-27 11:09:58 --> Helper loaded: form_helper
INFO - 2023-06-27 11:09:58 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:09:58 --> Helper loaded: security_helper
INFO - 2023-06-27 11:09:58 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:09:58 --> Database Driver Class Initialized
INFO - 2023-06-27 11:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:09:58 --> Parser Class Initialized
INFO - 2023-06-27 11:09:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:09:58 --> Pagination Class Initialized
INFO - 2023-06-27 11:09:58 --> Form Validation Class Initialized
INFO - 2023-06-27 11:09:58 --> Controller Class Initialized
INFO - 2023-06-27 11:09:58 --> Model Class Initialized
DEBUG - 2023-06-27 11:09:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:09:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:09:58 --> Model Class Initialized
DEBUG - 2023-06-27 11:09:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:09:58 --> Model Class Initialized
INFO - 2023-06-27 11:09:58 --> Final output sent to browser
DEBUG - 2023-06-27 11:09:58 --> Total execution time: 0.0466
ERROR - 2023-06-27 11:09:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:09:59 --> Config Class Initialized
INFO - 2023-06-27 11:09:59 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:09:59 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:09:59 --> Utf8 Class Initialized
INFO - 2023-06-27 11:09:59 --> URI Class Initialized
INFO - 2023-06-27 11:09:59 --> Router Class Initialized
INFO - 2023-06-27 11:09:59 --> Output Class Initialized
INFO - 2023-06-27 11:09:59 --> Security Class Initialized
DEBUG - 2023-06-27 11:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:09:59 --> Input Class Initialized
INFO - 2023-06-27 11:09:59 --> Language Class Initialized
INFO - 2023-06-27 11:09:59 --> Loader Class Initialized
INFO - 2023-06-27 11:09:59 --> Helper loaded: url_helper
INFO - 2023-06-27 11:09:59 --> Helper loaded: file_helper
INFO - 2023-06-27 11:09:59 --> Helper loaded: html_helper
INFO - 2023-06-27 11:09:59 --> Helper loaded: text_helper
INFO - 2023-06-27 11:09:59 --> Helper loaded: form_helper
INFO - 2023-06-27 11:09:59 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:09:59 --> Helper loaded: security_helper
INFO - 2023-06-27 11:09:59 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:09:59 --> Database Driver Class Initialized
INFO - 2023-06-27 11:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:09:59 --> Parser Class Initialized
INFO - 2023-06-27 11:09:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:09:59 --> Pagination Class Initialized
INFO - 2023-06-27 11:09:59 --> Form Validation Class Initialized
INFO - 2023-06-27 11:09:59 --> Controller Class Initialized
INFO - 2023-06-27 11:09:59 --> Model Class Initialized
DEBUG - 2023-06-27 11:09:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:09:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:09:59 --> Model Class Initialized
DEBUG - 2023-06-27 11:09:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:09:59 --> Model Class Initialized
INFO - 2023-06-27 11:09:59 --> Final output sent to browser
DEBUG - 2023-06-27 11:09:59 --> Total execution time: 0.0517
ERROR - 2023-06-27 11:09:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:09:59 --> Config Class Initialized
INFO - 2023-06-27 11:09:59 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:09:59 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:09:59 --> Utf8 Class Initialized
INFO - 2023-06-27 11:09:59 --> URI Class Initialized
INFO - 2023-06-27 11:09:59 --> Router Class Initialized
INFO - 2023-06-27 11:09:59 --> Output Class Initialized
INFO - 2023-06-27 11:09:59 --> Security Class Initialized
DEBUG - 2023-06-27 11:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:09:59 --> Input Class Initialized
INFO - 2023-06-27 11:09:59 --> Language Class Initialized
INFO - 2023-06-27 11:09:59 --> Loader Class Initialized
INFO - 2023-06-27 11:09:59 --> Helper loaded: url_helper
INFO - 2023-06-27 11:09:59 --> Helper loaded: file_helper
INFO - 2023-06-27 11:09:59 --> Helper loaded: html_helper
INFO - 2023-06-27 11:09:59 --> Helper loaded: text_helper
INFO - 2023-06-27 11:09:59 --> Helper loaded: form_helper
INFO - 2023-06-27 11:09:59 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:09:59 --> Helper loaded: security_helper
INFO - 2023-06-27 11:09:59 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:09:59 --> Database Driver Class Initialized
INFO - 2023-06-27 11:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:09:59 --> Parser Class Initialized
INFO - 2023-06-27 11:09:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:09:59 --> Pagination Class Initialized
INFO - 2023-06-27 11:09:59 --> Form Validation Class Initialized
INFO - 2023-06-27 11:09:59 --> Controller Class Initialized
INFO - 2023-06-27 11:09:59 --> Model Class Initialized
DEBUG - 2023-06-27 11:09:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:09:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:09:59 --> Model Class Initialized
DEBUG - 2023-06-27 11:09:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:09:59 --> Model Class Initialized
INFO - 2023-06-27 11:09:59 --> Final output sent to browser
DEBUG - 2023-06-27 11:09:59 --> Total execution time: 0.0493
ERROR - 2023-06-27 11:10:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:10:00 --> Config Class Initialized
INFO - 2023-06-27 11:10:00 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:10:00 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:10:00 --> Utf8 Class Initialized
INFO - 2023-06-27 11:10:00 --> URI Class Initialized
INFO - 2023-06-27 11:10:00 --> Router Class Initialized
INFO - 2023-06-27 11:10:00 --> Output Class Initialized
INFO - 2023-06-27 11:10:00 --> Security Class Initialized
DEBUG - 2023-06-27 11:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:10:00 --> Input Class Initialized
INFO - 2023-06-27 11:10:00 --> Language Class Initialized
INFO - 2023-06-27 11:10:00 --> Loader Class Initialized
INFO - 2023-06-27 11:10:00 --> Helper loaded: url_helper
INFO - 2023-06-27 11:10:00 --> Helper loaded: file_helper
INFO - 2023-06-27 11:10:00 --> Helper loaded: html_helper
INFO - 2023-06-27 11:10:00 --> Helper loaded: text_helper
INFO - 2023-06-27 11:10:00 --> Helper loaded: form_helper
INFO - 2023-06-27 11:10:00 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:10:00 --> Helper loaded: security_helper
INFO - 2023-06-27 11:10:00 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:10:00 --> Database Driver Class Initialized
INFO - 2023-06-27 11:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:10:00 --> Parser Class Initialized
INFO - 2023-06-27 11:10:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:10:00 --> Pagination Class Initialized
INFO - 2023-06-27 11:10:00 --> Form Validation Class Initialized
INFO - 2023-06-27 11:10:00 --> Controller Class Initialized
INFO - 2023-06-27 11:10:00 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:10:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:00 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:00 --> Model Class Initialized
INFO - 2023-06-27 11:10:00 --> Final output sent to browser
DEBUG - 2023-06-27 11:10:00 --> Total execution time: 0.0503
ERROR - 2023-06-27 11:10:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:10:00 --> Config Class Initialized
INFO - 2023-06-27 11:10:00 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:10:00 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:10:00 --> Utf8 Class Initialized
INFO - 2023-06-27 11:10:00 --> URI Class Initialized
INFO - 2023-06-27 11:10:00 --> Router Class Initialized
INFO - 2023-06-27 11:10:00 --> Output Class Initialized
INFO - 2023-06-27 11:10:00 --> Security Class Initialized
DEBUG - 2023-06-27 11:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:10:00 --> Input Class Initialized
INFO - 2023-06-27 11:10:00 --> Language Class Initialized
INFO - 2023-06-27 11:10:00 --> Loader Class Initialized
INFO - 2023-06-27 11:10:00 --> Helper loaded: url_helper
INFO - 2023-06-27 11:10:00 --> Helper loaded: file_helper
INFO - 2023-06-27 11:10:00 --> Helper loaded: html_helper
INFO - 2023-06-27 11:10:00 --> Helper loaded: text_helper
INFO - 2023-06-27 11:10:00 --> Helper loaded: form_helper
INFO - 2023-06-27 11:10:00 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:10:00 --> Helper loaded: security_helper
INFO - 2023-06-27 11:10:00 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:10:00 --> Database Driver Class Initialized
INFO - 2023-06-27 11:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:10:00 --> Parser Class Initialized
INFO - 2023-06-27 11:10:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:10:00 --> Pagination Class Initialized
INFO - 2023-06-27 11:10:00 --> Form Validation Class Initialized
INFO - 2023-06-27 11:10:00 --> Controller Class Initialized
INFO - 2023-06-27 11:10:00 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:10:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:00 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:00 --> Model Class Initialized
INFO - 2023-06-27 11:10:00 --> Final output sent to browser
DEBUG - 2023-06-27 11:10:00 --> Total execution time: 0.0472
ERROR - 2023-06-27 11:10:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:10:03 --> Config Class Initialized
INFO - 2023-06-27 11:10:03 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:10:03 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:10:03 --> Utf8 Class Initialized
INFO - 2023-06-27 11:10:03 --> URI Class Initialized
INFO - 2023-06-27 11:10:03 --> Router Class Initialized
INFO - 2023-06-27 11:10:03 --> Output Class Initialized
INFO - 2023-06-27 11:10:03 --> Security Class Initialized
DEBUG - 2023-06-27 11:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:10:03 --> Input Class Initialized
INFO - 2023-06-27 11:10:03 --> Language Class Initialized
INFO - 2023-06-27 11:10:03 --> Loader Class Initialized
INFO - 2023-06-27 11:10:03 --> Helper loaded: url_helper
INFO - 2023-06-27 11:10:03 --> Helper loaded: file_helper
INFO - 2023-06-27 11:10:03 --> Helper loaded: html_helper
INFO - 2023-06-27 11:10:03 --> Helper loaded: text_helper
INFO - 2023-06-27 11:10:03 --> Helper loaded: form_helper
INFO - 2023-06-27 11:10:03 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:10:03 --> Helper loaded: security_helper
INFO - 2023-06-27 11:10:03 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:10:03 --> Database Driver Class Initialized
INFO - 2023-06-27 11:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:10:03 --> Parser Class Initialized
INFO - 2023-06-27 11:10:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:10:03 --> Pagination Class Initialized
INFO - 2023-06-27 11:10:03 --> Form Validation Class Initialized
INFO - 2023-06-27 11:10:03 --> Controller Class Initialized
INFO - 2023-06-27 11:10:03 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:10:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:03 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:03 --> Model Class Initialized
INFO - 2023-06-27 11:10:03 --> Final output sent to browser
DEBUG - 2023-06-27 11:10:03 --> Total execution time: 0.0271
ERROR - 2023-06-27 11:10:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:10:03 --> Config Class Initialized
INFO - 2023-06-27 11:10:03 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:10:03 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:10:03 --> Utf8 Class Initialized
INFO - 2023-06-27 11:10:03 --> URI Class Initialized
INFO - 2023-06-27 11:10:03 --> Router Class Initialized
INFO - 2023-06-27 11:10:03 --> Output Class Initialized
INFO - 2023-06-27 11:10:03 --> Security Class Initialized
DEBUG - 2023-06-27 11:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:10:03 --> Input Class Initialized
INFO - 2023-06-27 11:10:03 --> Language Class Initialized
INFO - 2023-06-27 11:10:03 --> Loader Class Initialized
INFO - 2023-06-27 11:10:03 --> Helper loaded: url_helper
INFO - 2023-06-27 11:10:03 --> Helper loaded: file_helper
INFO - 2023-06-27 11:10:03 --> Helper loaded: html_helper
INFO - 2023-06-27 11:10:03 --> Helper loaded: text_helper
INFO - 2023-06-27 11:10:03 --> Helper loaded: form_helper
INFO - 2023-06-27 11:10:03 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:10:03 --> Helper loaded: security_helper
INFO - 2023-06-27 11:10:03 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:10:03 --> Database Driver Class Initialized
INFO - 2023-06-27 11:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:10:03 --> Parser Class Initialized
INFO - 2023-06-27 11:10:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:10:03 --> Pagination Class Initialized
INFO - 2023-06-27 11:10:03 --> Form Validation Class Initialized
INFO - 2023-06-27 11:10:03 --> Controller Class Initialized
INFO - 2023-06-27 11:10:03 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:10:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:03 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:03 --> Model Class Initialized
INFO - 2023-06-27 11:10:03 --> Final output sent to browser
DEBUG - 2023-06-27 11:10:03 --> Total execution time: 0.0266
ERROR - 2023-06-27 11:10:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:10:05 --> Config Class Initialized
INFO - 2023-06-27 11:10:05 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:10:05 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:10:05 --> Utf8 Class Initialized
INFO - 2023-06-27 11:10:05 --> URI Class Initialized
INFO - 2023-06-27 11:10:05 --> Router Class Initialized
INFO - 2023-06-27 11:10:05 --> Output Class Initialized
INFO - 2023-06-27 11:10:05 --> Security Class Initialized
DEBUG - 2023-06-27 11:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:10:05 --> Input Class Initialized
INFO - 2023-06-27 11:10:05 --> Language Class Initialized
INFO - 2023-06-27 11:10:05 --> Loader Class Initialized
INFO - 2023-06-27 11:10:05 --> Helper loaded: url_helper
INFO - 2023-06-27 11:10:05 --> Helper loaded: file_helper
INFO - 2023-06-27 11:10:05 --> Helper loaded: html_helper
INFO - 2023-06-27 11:10:05 --> Helper loaded: text_helper
INFO - 2023-06-27 11:10:05 --> Helper loaded: form_helper
INFO - 2023-06-27 11:10:05 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:10:05 --> Helper loaded: security_helper
INFO - 2023-06-27 11:10:05 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:10:05 --> Database Driver Class Initialized
INFO - 2023-06-27 11:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:10:05 --> Parser Class Initialized
INFO - 2023-06-27 11:10:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:10:05 --> Pagination Class Initialized
INFO - 2023-06-27 11:10:05 --> Form Validation Class Initialized
INFO - 2023-06-27 11:10:05 --> Controller Class Initialized
INFO - 2023-06-27 11:10:05 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:10:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:05 --> Model Class Initialized
INFO - 2023-06-27 11:10:05 --> Model Class Initialized
INFO - 2023-06-27 11:10:05 --> Final output sent to browser
DEBUG - 2023-06-27 11:10:05 --> Total execution time: 0.0209
ERROR - 2023-06-27 11:10:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:10:06 --> Config Class Initialized
INFO - 2023-06-27 11:10:06 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:10:06 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:10:06 --> Utf8 Class Initialized
INFO - 2023-06-27 11:10:06 --> URI Class Initialized
INFO - 2023-06-27 11:10:06 --> Router Class Initialized
INFO - 2023-06-27 11:10:06 --> Output Class Initialized
INFO - 2023-06-27 11:10:06 --> Security Class Initialized
DEBUG - 2023-06-27 11:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:10:06 --> Input Class Initialized
INFO - 2023-06-27 11:10:06 --> Language Class Initialized
INFO - 2023-06-27 11:10:06 --> Loader Class Initialized
INFO - 2023-06-27 11:10:06 --> Helper loaded: url_helper
INFO - 2023-06-27 11:10:06 --> Helper loaded: file_helper
INFO - 2023-06-27 11:10:06 --> Helper loaded: html_helper
INFO - 2023-06-27 11:10:06 --> Helper loaded: text_helper
INFO - 2023-06-27 11:10:06 --> Helper loaded: form_helper
INFO - 2023-06-27 11:10:06 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:10:06 --> Helper loaded: security_helper
INFO - 2023-06-27 11:10:06 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:10:06 --> Database Driver Class Initialized
INFO - 2023-06-27 11:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:10:06 --> Parser Class Initialized
INFO - 2023-06-27 11:10:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:10:06 --> Pagination Class Initialized
INFO - 2023-06-27 11:10:06 --> Form Validation Class Initialized
INFO - 2023-06-27 11:10:06 --> Controller Class Initialized
INFO - 2023-06-27 11:10:06 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:10:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:06 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:06 --> Model Class Initialized
INFO - 2023-06-27 11:10:06 --> Final output sent to browser
DEBUG - 2023-06-27 11:10:06 --> Total execution time: 0.0214
ERROR - 2023-06-27 11:10:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:10:08 --> Config Class Initialized
INFO - 2023-06-27 11:10:08 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:10:08 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:10:08 --> Utf8 Class Initialized
INFO - 2023-06-27 11:10:08 --> URI Class Initialized
INFO - 2023-06-27 11:10:08 --> Router Class Initialized
INFO - 2023-06-27 11:10:08 --> Output Class Initialized
INFO - 2023-06-27 11:10:08 --> Security Class Initialized
DEBUG - 2023-06-27 11:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:10:08 --> Input Class Initialized
INFO - 2023-06-27 11:10:08 --> Language Class Initialized
INFO - 2023-06-27 11:10:08 --> Loader Class Initialized
INFO - 2023-06-27 11:10:08 --> Helper loaded: url_helper
INFO - 2023-06-27 11:10:08 --> Helper loaded: file_helper
INFO - 2023-06-27 11:10:08 --> Helper loaded: html_helper
INFO - 2023-06-27 11:10:08 --> Helper loaded: text_helper
INFO - 2023-06-27 11:10:08 --> Helper loaded: form_helper
INFO - 2023-06-27 11:10:08 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:10:08 --> Helper loaded: security_helper
INFO - 2023-06-27 11:10:08 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:10:08 --> Database Driver Class Initialized
INFO - 2023-06-27 11:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:10:08 --> Parser Class Initialized
INFO - 2023-06-27 11:10:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:10:08 --> Pagination Class Initialized
INFO - 2023-06-27 11:10:08 --> Form Validation Class Initialized
INFO - 2023-06-27 11:10:08 --> Controller Class Initialized
INFO - 2023-06-27 11:10:08 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:10:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:08 --> Model Class Initialized
INFO - 2023-06-27 11:10:08 --> Final output sent to browser
DEBUG - 2023-06-27 11:10:08 --> Total execution time: 0.0173
ERROR - 2023-06-27 11:10:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:10:15 --> Config Class Initialized
INFO - 2023-06-27 11:10:15 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:10:15 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:10:15 --> Utf8 Class Initialized
INFO - 2023-06-27 11:10:15 --> URI Class Initialized
INFO - 2023-06-27 11:10:15 --> Router Class Initialized
INFO - 2023-06-27 11:10:15 --> Output Class Initialized
INFO - 2023-06-27 11:10:15 --> Security Class Initialized
DEBUG - 2023-06-27 11:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:10:15 --> Input Class Initialized
INFO - 2023-06-27 11:10:15 --> Language Class Initialized
INFO - 2023-06-27 11:10:15 --> Loader Class Initialized
INFO - 2023-06-27 11:10:15 --> Helper loaded: url_helper
INFO - 2023-06-27 11:10:15 --> Helper loaded: file_helper
INFO - 2023-06-27 11:10:15 --> Helper loaded: html_helper
INFO - 2023-06-27 11:10:15 --> Helper loaded: text_helper
INFO - 2023-06-27 11:10:15 --> Helper loaded: form_helper
INFO - 2023-06-27 11:10:15 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:10:15 --> Helper loaded: security_helper
INFO - 2023-06-27 11:10:15 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:10:15 --> Database Driver Class Initialized
INFO - 2023-06-27 11:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:10:15 --> Parser Class Initialized
INFO - 2023-06-27 11:10:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:10:15 --> Pagination Class Initialized
INFO - 2023-06-27 11:10:15 --> Form Validation Class Initialized
INFO - 2023-06-27 11:10:15 --> Controller Class Initialized
INFO - 2023-06-27 11:10:15 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:10:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:15 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:15 --> Model Class Initialized
INFO - 2023-06-27 11:10:15 --> Final output sent to browser
DEBUG - 2023-06-27 11:10:15 --> Total execution time: 0.0458
ERROR - 2023-06-27 11:10:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:10:16 --> Config Class Initialized
INFO - 2023-06-27 11:10:16 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:10:16 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:10:16 --> Utf8 Class Initialized
INFO - 2023-06-27 11:10:16 --> URI Class Initialized
INFO - 2023-06-27 11:10:16 --> Router Class Initialized
INFO - 2023-06-27 11:10:16 --> Output Class Initialized
INFO - 2023-06-27 11:10:16 --> Security Class Initialized
DEBUG - 2023-06-27 11:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:10:16 --> Input Class Initialized
INFO - 2023-06-27 11:10:16 --> Language Class Initialized
INFO - 2023-06-27 11:10:16 --> Loader Class Initialized
INFO - 2023-06-27 11:10:16 --> Helper loaded: url_helper
INFO - 2023-06-27 11:10:16 --> Helper loaded: file_helper
INFO - 2023-06-27 11:10:16 --> Helper loaded: html_helper
INFO - 2023-06-27 11:10:16 --> Helper loaded: text_helper
INFO - 2023-06-27 11:10:16 --> Helper loaded: form_helper
INFO - 2023-06-27 11:10:16 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:10:16 --> Helper loaded: security_helper
INFO - 2023-06-27 11:10:16 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:10:16 --> Database Driver Class Initialized
INFO - 2023-06-27 11:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:10:16 --> Parser Class Initialized
INFO - 2023-06-27 11:10:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:10:16 --> Pagination Class Initialized
INFO - 2023-06-27 11:10:16 --> Form Validation Class Initialized
INFO - 2023-06-27 11:10:16 --> Controller Class Initialized
INFO - 2023-06-27 11:10:16 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:10:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:16 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:16 --> Model Class Initialized
INFO - 2023-06-27 11:10:16 --> Final output sent to browser
DEBUG - 2023-06-27 11:10:16 --> Total execution time: 0.0452
ERROR - 2023-06-27 11:10:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:10:16 --> Config Class Initialized
INFO - 2023-06-27 11:10:16 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:10:16 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:10:16 --> Utf8 Class Initialized
INFO - 2023-06-27 11:10:16 --> URI Class Initialized
INFO - 2023-06-27 11:10:16 --> Router Class Initialized
INFO - 2023-06-27 11:10:16 --> Output Class Initialized
INFO - 2023-06-27 11:10:16 --> Security Class Initialized
DEBUG - 2023-06-27 11:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:10:16 --> Input Class Initialized
INFO - 2023-06-27 11:10:16 --> Language Class Initialized
INFO - 2023-06-27 11:10:16 --> Loader Class Initialized
INFO - 2023-06-27 11:10:16 --> Helper loaded: url_helper
INFO - 2023-06-27 11:10:16 --> Helper loaded: file_helper
INFO - 2023-06-27 11:10:16 --> Helper loaded: html_helper
INFO - 2023-06-27 11:10:16 --> Helper loaded: text_helper
INFO - 2023-06-27 11:10:16 --> Helper loaded: form_helper
INFO - 2023-06-27 11:10:16 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:10:16 --> Helper loaded: security_helper
INFO - 2023-06-27 11:10:16 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:10:16 --> Database Driver Class Initialized
INFO - 2023-06-27 11:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:10:16 --> Parser Class Initialized
INFO - 2023-06-27 11:10:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:10:16 --> Pagination Class Initialized
INFO - 2023-06-27 11:10:16 --> Form Validation Class Initialized
INFO - 2023-06-27 11:10:16 --> Controller Class Initialized
INFO - 2023-06-27 11:10:16 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:10:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:16 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:16 --> Model Class Initialized
INFO - 2023-06-27 11:10:16 --> Final output sent to browser
DEBUG - 2023-06-27 11:10:16 --> Total execution time: 0.0450
ERROR - 2023-06-27 11:10:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:10:16 --> Config Class Initialized
INFO - 2023-06-27 11:10:16 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:10:16 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:10:16 --> Utf8 Class Initialized
INFO - 2023-06-27 11:10:16 --> URI Class Initialized
INFO - 2023-06-27 11:10:16 --> Router Class Initialized
INFO - 2023-06-27 11:10:16 --> Output Class Initialized
INFO - 2023-06-27 11:10:16 --> Security Class Initialized
DEBUG - 2023-06-27 11:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:10:16 --> Input Class Initialized
INFO - 2023-06-27 11:10:16 --> Language Class Initialized
INFO - 2023-06-27 11:10:16 --> Loader Class Initialized
INFO - 2023-06-27 11:10:16 --> Helper loaded: url_helper
INFO - 2023-06-27 11:10:16 --> Helper loaded: file_helper
INFO - 2023-06-27 11:10:16 --> Helper loaded: html_helper
INFO - 2023-06-27 11:10:16 --> Helper loaded: text_helper
INFO - 2023-06-27 11:10:16 --> Helper loaded: form_helper
INFO - 2023-06-27 11:10:16 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:10:16 --> Helper loaded: security_helper
INFO - 2023-06-27 11:10:16 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:10:16 --> Database Driver Class Initialized
INFO - 2023-06-27 11:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:10:16 --> Parser Class Initialized
INFO - 2023-06-27 11:10:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:10:16 --> Pagination Class Initialized
INFO - 2023-06-27 11:10:16 --> Form Validation Class Initialized
INFO - 2023-06-27 11:10:16 --> Controller Class Initialized
INFO - 2023-06-27 11:10:16 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:10:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:16 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:16 --> Model Class Initialized
INFO - 2023-06-27 11:10:16 --> Final output sent to browser
DEBUG - 2023-06-27 11:10:16 --> Total execution time: 0.0206
ERROR - 2023-06-27 11:10:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:10:17 --> Config Class Initialized
INFO - 2023-06-27 11:10:17 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:10:17 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:10:17 --> Utf8 Class Initialized
INFO - 2023-06-27 11:10:17 --> URI Class Initialized
INFO - 2023-06-27 11:10:17 --> Router Class Initialized
INFO - 2023-06-27 11:10:17 --> Output Class Initialized
INFO - 2023-06-27 11:10:17 --> Security Class Initialized
DEBUG - 2023-06-27 11:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:10:17 --> Input Class Initialized
INFO - 2023-06-27 11:10:17 --> Language Class Initialized
INFO - 2023-06-27 11:10:17 --> Loader Class Initialized
INFO - 2023-06-27 11:10:17 --> Helper loaded: url_helper
INFO - 2023-06-27 11:10:17 --> Helper loaded: file_helper
INFO - 2023-06-27 11:10:17 --> Helper loaded: html_helper
INFO - 2023-06-27 11:10:17 --> Helper loaded: text_helper
INFO - 2023-06-27 11:10:17 --> Helper loaded: form_helper
INFO - 2023-06-27 11:10:17 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:10:17 --> Helper loaded: security_helper
INFO - 2023-06-27 11:10:17 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:10:17 --> Database Driver Class Initialized
INFO - 2023-06-27 11:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:10:17 --> Parser Class Initialized
INFO - 2023-06-27 11:10:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:10:17 --> Pagination Class Initialized
INFO - 2023-06-27 11:10:17 --> Form Validation Class Initialized
INFO - 2023-06-27 11:10:17 --> Controller Class Initialized
INFO - 2023-06-27 11:10:17 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:10:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:17 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:17 --> Model Class Initialized
INFO - 2023-06-27 11:10:17 --> Final output sent to browser
DEBUG - 2023-06-27 11:10:17 --> Total execution time: 0.0197
ERROR - 2023-06-27 11:10:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:10:19 --> Config Class Initialized
INFO - 2023-06-27 11:10:19 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:10:19 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:10:19 --> Utf8 Class Initialized
INFO - 2023-06-27 11:10:19 --> URI Class Initialized
INFO - 2023-06-27 11:10:19 --> Router Class Initialized
INFO - 2023-06-27 11:10:19 --> Output Class Initialized
INFO - 2023-06-27 11:10:19 --> Security Class Initialized
DEBUG - 2023-06-27 11:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:10:19 --> Input Class Initialized
INFO - 2023-06-27 11:10:19 --> Language Class Initialized
INFO - 2023-06-27 11:10:19 --> Loader Class Initialized
INFO - 2023-06-27 11:10:19 --> Helper loaded: url_helper
INFO - 2023-06-27 11:10:19 --> Helper loaded: file_helper
INFO - 2023-06-27 11:10:19 --> Helper loaded: html_helper
INFO - 2023-06-27 11:10:19 --> Helper loaded: text_helper
INFO - 2023-06-27 11:10:19 --> Helper loaded: form_helper
INFO - 2023-06-27 11:10:19 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:10:19 --> Helper loaded: security_helper
INFO - 2023-06-27 11:10:19 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:10:19 --> Database Driver Class Initialized
INFO - 2023-06-27 11:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:10:19 --> Parser Class Initialized
INFO - 2023-06-27 11:10:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:10:19 --> Pagination Class Initialized
INFO - 2023-06-27 11:10:19 --> Form Validation Class Initialized
INFO - 2023-06-27 11:10:19 --> Controller Class Initialized
INFO - 2023-06-27 11:10:19 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:10:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:19 --> Model Class Initialized
INFO - 2023-06-27 11:10:19 --> Model Class Initialized
INFO - 2023-06-27 11:10:19 --> Final output sent to browser
DEBUG - 2023-06-27 11:10:19 --> Total execution time: 0.0195
ERROR - 2023-06-27 11:10:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:10:19 --> Config Class Initialized
INFO - 2023-06-27 11:10:19 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:10:19 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:10:19 --> Utf8 Class Initialized
INFO - 2023-06-27 11:10:19 --> URI Class Initialized
INFO - 2023-06-27 11:10:19 --> Router Class Initialized
INFO - 2023-06-27 11:10:19 --> Output Class Initialized
INFO - 2023-06-27 11:10:19 --> Security Class Initialized
DEBUG - 2023-06-27 11:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:10:19 --> Input Class Initialized
INFO - 2023-06-27 11:10:19 --> Language Class Initialized
INFO - 2023-06-27 11:10:19 --> Loader Class Initialized
INFO - 2023-06-27 11:10:19 --> Helper loaded: url_helper
INFO - 2023-06-27 11:10:19 --> Helper loaded: file_helper
INFO - 2023-06-27 11:10:19 --> Helper loaded: html_helper
INFO - 2023-06-27 11:10:19 --> Helper loaded: text_helper
INFO - 2023-06-27 11:10:19 --> Helper loaded: form_helper
INFO - 2023-06-27 11:10:19 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:10:19 --> Helper loaded: security_helper
INFO - 2023-06-27 11:10:19 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:10:19 --> Database Driver Class Initialized
INFO - 2023-06-27 11:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:10:19 --> Parser Class Initialized
INFO - 2023-06-27 11:10:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:10:19 --> Pagination Class Initialized
INFO - 2023-06-27 11:10:19 --> Form Validation Class Initialized
INFO - 2023-06-27 11:10:19 --> Controller Class Initialized
INFO - 2023-06-27 11:10:19 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:10:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:19 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:19 --> Model Class Initialized
INFO - 2023-06-27 11:10:19 --> Final output sent to browser
DEBUG - 2023-06-27 11:10:19 --> Total execution time: 0.0204
ERROR - 2023-06-27 11:10:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:10:23 --> Config Class Initialized
INFO - 2023-06-27 11:10:23 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:10:23 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:10:23 --> Utf8 Class Initialized
INFO - 2023-06-27 11:10:23 --> URI Class Initialized
INFO - 2023-06-27 11:10:23 --> Router Class Initialized
INFO - 2023-06-27 11:10:23 --> Output Class Initialized
INFO - 2023-06-27 11:10:23 --> Security Class Initialized
DEBUG - 2023-06-27 11:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:10:23 --> Input Class Initialized
INFO - 2023-06-27 11:10:23 --> Language Class Initialized
INFO - 2023-06-27 11:10:23 --> Loader Class Initialized
INFO - 2023-06-27 11:10:23 --> Helper loaded: url_helper
INFO - 2023-06-27 11:10:23 --> Helper loaded: file_helper
INFO - 2023-06-27 11:10:23 --> Helper loaded: html_helper
INFO - 2023-06-27 11:10:23 --> Helper loaded: text_helper
INFO - 2023-06-27 11:10:23 --> Helper loaded: form_helper
INFO - 2023-06-27 11:10:23 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:10:23 --> Helper loaded: security_helper
INFO - 2023-06-27 11:10:23 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:10:23 --> Database Driver Class Initialized
INFO - 2023-06-27 11:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:10:23 --> Parser Class Initialized
INFO - 2023-06-27 11:10:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:10:23 --> Pagination Class Initialized
INFO - 2023-06-27 11:10:23 --> Form Validation Class Initialized
INFO - 2023-06-27 11:10:23 --> Controller Class Initialized
INFO - 2023-06-27 11:10:23 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:10:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:23 --> Model Class Initialized
INFO - 2023-06-27 11:10:23 --> Final output sent to browser
DEBUG - 2023-06-27 11:10:23 --> Total execution time: 0.0155
ERROR - 2023-06-27 11:10:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:10:56 --> Config Class Initialized
INFO - 2023-06-27 11:10:56 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:10:56 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:10:56 --> Utf8 Class Initialized
INFO - 2023-06-27 11:10:56 --> URI Class Initialized
INFO - 2023-06-27 11:10:56 --> Router Class Initialized
INFO - 2023-06-27 11:10:56 --> Output Class Initialized
INFO - 2023-06-27 11:10:56 --> Security Class Initialized
DEBUG - 2023-06-27 11:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:10:56 --> Input Class Initialized
INFO - 2023-06-27 11:10:56 --> Language Class Initialized
INFO - 2023-06-27 11:10:56 --> Loader Class Initialized
INFO - 2023-06-27 11:10:56 --> Helper loaded: url_helper
INFO - 2023-06-27 11:10:56 --> Helper loaded: file_helper
INFO - 2023-06-27 11:10:56 --> Helper loaded: html_helper
INFO - 2023-06-27 11:10:56 --> Helper loaded: text_helper
INFO - 2023-06-27 11:10:56 --> Helper loaded: form_helper
INFO - 2023-06-27 11:10:56 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:10:56 --> Helper loaded: security_helper
INFO - 2023-06-27 11:10:56 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:10:56 --> Database Driver Class Initialized
INFO - 2023-06-27 11:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:10:56 --> Parser Class Initialized
INFO - 2023-06-27 11:10:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:10:56 --> Pagination Class Initialized
INFO - 2023-06-27 11:10:57 --> Form Validation Class Initialized
INFO - 2023-06-27 11:10:57 --> Controller Class Initialized
INFO - 2023-06-27 11:10:57 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:10:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:57 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:57 --> Model Class Initialized
INFO - 2023-06-27 11:10:57 --> Final output sent to browser
DEBUG - 2023-06-27 11:10:57 --> Total execution time: 0.0520
ERROR - 2023-06-27 11:10:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:10:57 --> Config Class Initialized
INFO - 2023-06-27 11:10:57 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:10:57 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:10:57 --> Utf8 Class Initialized
INFO - 2023-06-27 11:10:57 --> URI Class Initialized
INFO - 2023-06-27 11:10:57 --> Router Class Initialized
INFO - 2023-06-27 11:10:57 --> Output Class Initialized
INFO - 2023-06-27 11:10:57 --> Security Class Initialized
DEBUG - 2023-06-27 11:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:10:57 --> Input Class Initialized
INFO - 2023-06-27 11:10:57 --> Language Class Initialized
INFO - 2023-06-27 11:10:57 --> Loader Class Initialized
INFO - 2023-06-27 11:10:57 --> Helper loaded: url_helper
INFO - 2023-06-27 11:10:57 --> Helper loaded: file_helper
INFO - 2023-06-27 11:10:57 --> Helper loaded: html_helper
INFO - 2023-06-27 11:10:57 --> Helper loaded: text_helper
INFO - 2023-06-27 11:10:57 --> Helper loaded: form_helper
INFO - 2023-06-27 11:10:57 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:10:57 --> Helper loaded: security_helper
INFO - 2023-06-27 11:10:57 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:10:57 --> Database Driver Class Initialized
INFO - 2023-06-27 11:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:10:57 --> Parser Class Initialized
INFO - 2023-06-27 11:10:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:10:57 --> Pagination Class Initialized
INFO - 2023-06-27 11:10:57 --> Form Validation Class Initialized
INFO - 2023-06-27 11:10:57 --> Controller Class Initialized
INFO - 2023-06-27 11:10:57 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:10:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:57 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:57 --> Model Class Initialized
INFO - 2023-06-27 11:10:57 --> Final output sent to browser
DEBUG - 2023-06-27 11:10:57 --> Total execution time: 0.0475
ERROR - 2023-06-27 11:10:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:10:57 --> Config Class Initialized
INFO - 2023-06-27 11:10:57 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:10:57 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:10:57 --> Utf8 Class Initialized
INFO - 2023-06-27 11:10:57 --> URI Class Initialized
INFO - 2023-06-27 11:10:57 --> Router Class Initialized
INFO - 2023-06-27 11:10:57 --> Output Class Initialized
INFO - 2023-06-27 11:10:57 --> Security Class Initialized
DEBUG - 2023-06-27 11:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:10:57 --> Input Class Initialized
INFO - 2023-06-27 11:10:57 --> Language Class Initialized
INFO - 2023-06-27 11:10:57 --> Loader Class Initialized
INFO - 2023-06-27 11:10:57 --> Helper loaded: url_helper
INFO - 2023-06-27 11:10:57 --> Helper loaded: file_helper
INFO - 2023-06-27 11:10:57 --> Helper loaded: html_helper
INFO - 2023-06-27 11:10:57 --> Helper loaded: text_helper
INFO - 2023-06-27 11:10:57 --> Helper loaded: form_helper
INFO - 2023-06-27 11:10:57 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:10:57 --> Helper loaded: security_helper
INFO - 2023-06-27 11:10:57 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:10:57 --> Database Driver Class Initialized
INFO - 2023-06-27 11:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:10:57 --> Parser Class Initialized
INFO - 2023-06-27 11:10:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:10:57 --> Pagination Class Initialized
INFO - 2023-06-27 11:10:57 --> Form Validation Class Initialized
INFO - 2023-06-27 11:10:57 --> Controller Class Initialized
INFO - 2023-06-27 11:10:57 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:10:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:57 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:57 --> Model Class Initialized
INFO - 2023-06-27 11:10:57 --> Final output sent to browser
DEBUG - 2023-06-27 11:10:57 --> Total execution time: 0.0554
ERROR - 2023-06-27 11:10:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:10:58 --> Config Class Initialized
INFO - 2023-06-27 11:10:58 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:10:58 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:10:58 --> Utf8 Class Initialized
INFO - 2023-06-27 11:10:58 --> URI Class Initialized
INFO - 2023-06-27 11:10:58 --> Router Class Initialized
INFO - 2023-06-27 11:10:58 --> Output Class Initialized
INFO - 2023-06-27 11:10:58 --> Security Class Initialized
DEBUG - 2023-06-27 11:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:10:58 --> Input Class Initialized
INFO - 2023-06-27 11:10:58 --> Language Class Initialized
INFO - 2023-06-27 11:10:58 --> Loader Class Initialized
INFO - 2023-06-27 11:10:58 --> Helper loaded: url_helper
INFO - 2023-06-27 11:10:58 --> Helper loaded: file_helper
INFO - 2023-06-27 11:10:58 --> Helper loaded: html_helper
INFO - 2023-06-27 11:10:58 --> Helper loaded: text_helper
INFO - 2023-06-27 11:10:58 --> Helper loaded: form_helper
INFO - 2023-06-27 11:10:58 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:10:58 --> Helper loaded: security_helper
INFO - 2023-06-27 11:10:58 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:10:58 --> Database Driver Class Initialized
INFO - 2023-06-27 11:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:10:58 --> Parser Class Initialized
INFO - 2023-06-27 11:10:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:10:58 --> Pagination Class Initialized
INFO - 2023-06-27 11:10:58 --> Form Validation Class Initialized
INFO - 2023-06-27 11:10:58 --> Controller Class Initialized
INFO - 2023-06-27 11:10:58 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:10:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:58 --> Model Class Initialized
DEBUG - 2023-06-27 11:10:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:10:58 --> Model Class Initialized
INFO - 2023-06-27 11:10:58 --> Final output sent to browser
DEBUG - 2023-06-27 11:10:58 --> Total execution time: 0.0561
ERROR - 2023-06-27 11:11:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:11:03 --> Config Class Initialized
INFO - 2023-06-27 11:11:03 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:11:03 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:11:03 --> Utf8 Class Initialized
INFO - 2023-06-27 11:11:03 --> URI Class Initialized
INFO - 2023-06-27 11:11:03 --> Router Class Initialized
INFO - 2023-06-27 11:11:03 --> Output Class Initialized
INFO - 2023-06-27 11:11:03 --> Security Class Initialized
DEBUG - 2023-06-27 11:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:11:03 --> Input Class Initialized
INFO - 2023-06-27 11:11:03 --> Language Class Initialized
INFO - 2023-06-27 11:11:03 --> Loader Class Initialized
INFO - 2023-06-27 11:11:03 --> Helper loaded: url_helper
INFO - 2023-06-27 11:11:03 --> Helper loaded: file_helper
INFO - 2023-06-27 11:11:03 --> Helper loaded: html_helper
INFO - 2023-06-27 11:11:03 --> Helper loaded: text_helper
INFO - 2023-06-27 11:11:03 --> Helper loaded: form_helper
INFO - 2023-06-27 11:11:03 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:11:03 --> Helper loaded: security_helper
INFO - 2023-06-27 11:11:03 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:11:03 --> Database Driver Class Initialized
INFO - 2023-06-27 11:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:11:03 --> Parser Class Initialized
INFO - 2023-06-27 11:11:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:11:03 --> Pagination Class Initialized
INFO - 2023-06-27 11:11:03 --> Form Validation Class Initialized
INFO - 2023-06-27 11:11:03 --> Controller Class Initialized
INFO - 2023-06-27 11:11:03 --> Model Class Initialized
DEBUG - 2023-06-27 11:11:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:11:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:11:03 --> Model Class Initialized
INFO - 2023-06-27 11:11:03 --> Model Class Initialized
INFO - 2023-06-27 11:11:03 --> Final output sent to browser
DEBUG - 2023-06-27 11:11:03 --> Total execution time: 0.0197
ERROR - 2023-06-27 11:11:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:11:06 --> Config Class Initialized
INFO - 2023-06-27 11:11:06 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:11:06 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:11:06 --> Utf8 Class Initialized
INFO - 2023-06-27 11:11:06 --> URI Class Initialized
INFO - 2023-06-27 11:11:06 --> Router Class Initialized
INFO - 2023-06-27 11:11:06 --> Output Class Initialized
INFO - 2023-06-27 11:11:06 --> Security Class Initialized
DEBUG - 2023-06-27 11:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:11:06 --> Input Class Initialized
INFO - 2023-06-27 11:11:06 --> Language Class Initialized
INFO - 2023-06-27 11:11:06 --> Loader Class Initialized
INFO - 2023-06-27 11:11:06 --> Helper loaded: url_helper
INFO - 2023-06-27 11:11:06 --> Helper loaded: file_helper
INFO - 2023-06-27 11:11:06 --> Helper loaded: html_helper
INFO - 2023-06-27 11:11:06 --> Helper loaded: text_helper
INFO - 2023-06-27 11:11:06 --> Helper loaded: form_helper
INFO - 2023-06-27 11:11:06 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:11:06 --> Helper loaded: security_helper
INFO - 2023-06-27 11:11:06 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:11:06 --> Database Driver Class Initialized
INFO - 2023-06-27 11:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:11:06 --> Parser Class Initialized
INFO - 2023-06-27 11:11:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:11:06 --> Pagination Class Initialized
INFO - 2023-06-27 11:11:06 --> Form Validation Class Initialized
INFO - 2023-06-27 11:11:06 --> Controller Class Initialized
INFO - 2023-06-27 11:11:06 --> Model Class Initialized
DEBUG - 2023-06-27 11:11:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:11:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:11:06 --> Model Class Initialized
INFO - 2023-06-27 11:11:06 --> Final output sent to browser
DEBUG - 2023-06-27 11:11:06 --> Total execution time: 0.0204
ERROR - 2023-06-27 11:11:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:11:12 --> Config Class Initialized
INFO - 2023-06-27 11:11:12 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:11:12 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:11:12 --> Utf8 Class Initialized
INFO - 2023-06-27 11:11:12 --> URI Class Initialized
INFO - 2023-06-27 11:11:12 --> Router Class Initialized
INFO - 2023-06-27 11:11:12 --> Output Class Initialized
INFO - 2023-06-27 11:11:12 --> Security Class Initialized
DEBUG - 2023-06-27 11:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:11:12 --> Input Class Initialized
INFO - 2023-06-27 11:11:12 --> Language Class Initialized
INFO - 2023-06-27 11:11:12 --> Loader Class Initialized
INFO - 2023-06-27 11:11:12 --> Helper loaded: url_helper
INFO - 2023-06-27 11:11:12 --> Helper loaded: file_helper
INFO - 2023-06-27 11:11:12 --> Helper loaded: html_helper
INFO - 2023-06-27 11:11:12 --> Helper loaded: text_helper
INFO - 2023-06-27 11:11:12 --> Helper loaded: form_helper
INFO - 2023-06-27 11:11:12 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:11:12 --> Helper loaded: security_helper
INFO - 2023-06-27 11:11:12 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:11:12 --> Database Driver Class Initialized
INFO - 2023-06-27 11:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:11:12 --> Parser Class Initialized
INFO - 2023-06-27 11:11:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:11:12 --> Pagination Class Initialized
INFO - 2023-06-27 11:11:12 --> Form Validation Class Initialized
INFO - 2023-06-27 11:11:12 --> Controller Class Initialized
INFO - 2023-06-27 11:11:12 --> Model Class Initialized
DEBUG - 2023-06-27 11:11:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:11:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:11:12 --> Model Class Initialized
DEBUG - 2023-06-27 11:11:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:11:12 --> Model Class Initialized
INFO - 2023-06-27 11:11:12 --> Email Class Initialized
DEBUG - 2023-06-27 11:11:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:11:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:11:12 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-06-27 11:11:12 --> Language file loaded: language/english/email_lang.php
INFO - 2023-06-27 11:11:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2023-06-27 11:11:12 --> Final output sent to browser
DEBUG - 2023-06-27 11:11:12 --> Total execution time: 0.5158
ERROR - 2023-06-27 11:11:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:11:15 --> Config Class Initialized
INFO - 2023-06-27 11:11:15 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:11:15 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:11:15 --> Utf8 Class Initialized
INFO - 2023-06-27 11:11:15 --> URI Class Initialized
INFO - 2023-06-27 11:11:15 --> Router Class Initialized
INFO - 2023-06-27 11:11:15 --> Output Class Initialized
INFO - 2023-06-27 11:11:15 --> Security Class Initialized
DEBUG - 2023-06-27 11:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:11:15 --> Input Class Initialized
INFO - 2023-06-27 11:11:15 --> Language Class Initialized
INFO - 2023-06-27 11:11:15 --> Loader Class Initialized
INFO - 2023-06-27 11:11:15 --> Helper loaded: url_helper
INFO - 2023-06-27 11:11:15 --> Helper loaded: file_helper
INFO - 2023-06-27 11:11:15 --> Helper loaded: html_helper
INFO - 2023-06-27 11:11:15 --> Helper loaded: text_helper
INFO - 2023-06-27 11:11:15 --> Helper loaded: form_helper
INFO - 2023-06-27 11:11:15 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:11:15 --> Helper loaded: security_helper
INFO - 2023-06-27 11:11:15 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:11:15 --> Database Driver Class Initialized
INFO - 2023-06-27 11:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:11:15 --> Parser Class Initialized
INFO - 2023-06-27 11:11:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:11:15 --> Pagination Class Initialized
INFO - 2023-06-27 11:11:15 --> Form Validation Class Initialized
INFO - 2023-06-27 11:11:15 --> Controller Class Initialized
INFO - 2023-06-27 11:11:15 --> Model Class Initialized
DEBUG - 2023-06-27 11:11:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:11:15 --> Model Class Initialized
DEBUG - 2023-06-27 11:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:11:15 --> Model Class Initialized
INFO - 2023-06-27 11:11:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-06-27 11:11:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:11:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 11:11:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 11:11:15 --> Model Class Initialized
INFO - 2023-06-27 11:11:15 --> Model Class Initialized
INFO - 2023-06-27 11:11:15 --> Model Class Initialized
INFO - 2023-06-27 11:11:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 11:11:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 11:11:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 11:11:15 --> Final output sent to browser
DEBUG - 2023-06-27 11:11:15 --> Total execution time: 0.0995
ERROR - 2023-06-27 11:11:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:11:19 --> Config Class Initialized
INFO - 2023-06-27 11:11:19 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:11:19 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:11:19 --> Utf8 Class Initialized
INFO - 2023-06-27 11:11:19 --> URI Class Initialized
DEBUG - 2023-06-27 11:11:19 --> No URI present. Default controller set.
INFO - 2023-06-27 11:11:19 --> Router Class Initialized
INFO - 2023-06-27 11:11:19 --> Output Class Initialized
INFO - 2023-06-27 11:11:19 --> Security Class Initialized
DEBUG - 2023-06-27 11:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:11:19 --> Input Class Initialized
INFO - 2023-06-27 11:11:19 --> Language Class Initialized
INFO - 2023-06-27 11:11:19 --> Loader Class Initialized
INFO - 2023-06-27 11:11:19 --> Helper loaded: url_helper
INFO - 2023-06-27 11:11:19 --> Helper loaded: file_helper
INFO - 2023-06-27 11:11:19 --> Helper loaded: html_helper
INFO - 2023-06-27 11:11:19 --> Helper loaded: text_helper
INFO - 2023-06-27 11:11:19 --> Helper loaded: form_helper
INFO - 2023-06-27 11:11:19 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:11:19 --> Helper loaded: security_helper
INFO - 2023-06-27 11:11:19 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:11:19 --> Database Driver Class Initialized
INFO - 2023-06-27 11:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:11:19 --> Parser Class Initialized
INFO - 2023-06-27 11:11:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:11:19 --> Pagination Class Initialized
INFO - 2023-06-27 11:11:19 --> Form Validation Class Initialized
INFO - 2023-06-27 11:11:19 --> Controller Class Initialized
INFO - 2023-06-27 11:11:19 --> Model Class Initialized
DEBUG - 2023-06-27 11:11:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:11:19 --> Model Class Initialized
DEBUG - 2023-06-27 11:11:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:11:19 --> Model Class Initialized
INFO - 2023-06-27 11:11:19 --> Model Class Initialized
INFO - 2023-06-27 11:11:19 --> Model Class Initialized
INFO - 2023-06-27 11:11:19 --> Model Class Initialized
DEBUG - 2023-06-27 11:11:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:11:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:11:19 --> Model Class Initialized
INFO - 2023-06-27 11:11:19 --> Model Class Initialized
INFO - 2023-06-27 11:11:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 11:11:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:11:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 11:11:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 11:11:19 --> Model Class Initialized
INFO - 2023-06-27 11:11:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 11:11:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 11:11:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 11:11:19 --> Final output sent to browser
DEBUG - 2023-06-27 11:11:19 --> Total execution time: 0.0877
ERROR - 2023-06-27 11:11:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:11:46 --> Config Class Initialized
INFO - 2023-06-27 11:11:46 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:11:46 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:11:46 --> Utf8 Class Initialized
INFO - 2023-06-27 11:11:46 --> URI Class Initialized
DEBUG - 2023-06-27 11:11:46 --> No URI present. Default controller set.
INFO - 2023-06-27 11:11:46 --> Router Class Initialized
INFO - 2023-06-27 11:11:46 --> Output Class Initialized
INFO - 2023-06-27 11:11:46 --> Security Class Initialized
DEBUG - 2023-06-27 11:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:11:46 --> Input Class Initialized
INFO - 2023-06-27 11:11:46 --> Language Class Initialized
INFO - 2023-06-27 11:11:46 --> Loader Class Initialized
INFO - 2023-06-27 11:11:46 --> Helper loaded: url_helper
INFO - 2023-06-27 11:11:46 --> Helper loaded: file_helper
INFO - 2023-06-27 11:11:46 --> Helper loaded: html_helper
INFO - 2023-06-27 11:11:46 --> Helper loaded: text_helper
INFO - 2023-06-27 11:11:46 --> Helper loaded: form_helper
INFO - 2023-06-27 11:11:46 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:11:46 --> Helper loaded: security_helper
INFO - 2023-06-27 11:11:46 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:11:46 --> Database Driver Class Initialized
INFO - 2023-06-27 11:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:11:46 --> Parser Class Initialized
INFO - 2023-06-27 11:11:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:11:46 --> Pagination Class Initialized
INFO - 2023-06-27 11:11:46 --> Form Validation Class Initialized
INFO - 2023-06-27 11:11:46 --> Controller Class Initialized
INFO - 2023-06-27 11:11:46 --> Model Class Initialized
DEBUG - 2023-06-27 11:11:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:11:46 --> Model Class Initialized
DEBUG - 2023-06-27 11:11:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:11:46 --> Model Class Initialized
INFO - 2023-06-27 11:11:46 --> Model Class Initialized
INFO - 2023-06-27 11:11:46 --> Model Class Initialized
INFO - 2023-06-27 11:11:46 --> Model Class Initialized
DEBUG - 2023-06-27 11:11:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:11:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:11:46 --> Model Class Initialized
INFO - 2023-06-27 11:11:46 --> Model Class Initialized
INFO - 2023-06-27 11:11:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 11:11:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:11:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 11:11:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 11:11:46 --> Model Class Initialized
INFO - 2023-06-27 11:11:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 11:11:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 11:11:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 11:11:46 --> Final output sent to browser
DEBUG - 2023-06-27 11:11:46 --> Total execution time: 0.0878
ERROR - 2023-06-27 11:12:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:12:11 --> Config Class Initialized
INFO - 2023-06-27 11:12:11 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:12:11 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:12:11 --> Utf8 Class Initialized
INFO - 2023-06-27 11:12:11 --> URI Class Initialized
DEBUG - 2023-06-27 11:12:11 --> No URI present. Default controller set.
INFO - 2023-06-27 11:12:11 --> Router Class Initialized
INFO - 2023-06-27 11:12:11 --> Output Class Initialized
INFO - 2023-06-27 11:12:11 --> Security Class Initialized
DEBUG - 2023-06-27 11:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:12:11 --> Input Class Initialized
INFO - 2023-06-27 11:12:11 --> Language Class Initialized
INFO - 2023-06-27 11:12:11 --> Loader Class Initialized
INFO - 2023-06-27 11:12:11 --> Helper loaded: url_helper
INFO - 2023-06-27 11:12:11 --> Helper loaded: file_helper
INFO - 2023-06-27 11:12:11 --> Helper loaded: html_helper
INFO - 2023-06-27 11:12:11 --> Helper loaded: text_helper
INFO - 2023-06-27 11:12:11 --> Helper loaded: form_helper
INFO - 2023-06-27 11:12:11 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:12:11 --> Helper loaded: security_helper
INFO - 2023-06-27 11:12:11 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:12:11 --> Database Driver Class Initialized
INFO - 2023-06-27 11:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:12:11 --> Parser Class Initialized
INFO - 2023-06-27 11:12:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:12:11 --> Pagination Class Initialized
INFO - 2023-06-27 11:12:11 --> Form Validation Class Initialized
INFO - 2023-06-27 11:12:11 --> Controller Class Initialized
INFO - 2023-06-27 11:12:11 --> Model Class Initialized
DEBUG - 2023-06-27 11:12:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-27 11:12:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:12:11 --> Config Class Initialized
INFO - 2023-06-27 11:12:11 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:12:11 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:12:11 --> Utf8 Class Initialized
INFO - 2023-06-27 11:12:11 --> URI Class Initialized
INFO - 2023-06-27 11:12:11 --> Router Class Initialized
INFO - 2023-06-27 11:12:11 --> Output Class Initialized
INFO - 2023-06-27 11:12:11 --> Security Class Initialized
DEBUG - 2023-06-27 11:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:12:11 --> Input Class Initialized
INFO - 2023-06-27 11:12:11 --> Language Class Initialized
INFO - 2023-06-27 11:12:11 --> Loader Class Initialized
INFO - 2023-06-27 11:12:11 --> Helper loaded: url_helper
INFO - 2023-06-27 11:12:11 --> Helper loaded: file_helper
INFO - 2023-06-27 11:12:11 --> Helper loaded: html_helper
INFO - 2023-06-27 11:12:11 --> Helper loaded: text_helper
INFO - 2023-06-27 11:12:11 --> Helper loaded: form_helper
INFO - 2023-06-27 11:12:11 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:12:11 --> Helper loaded: security_helper
INFO - 2023-06-27 11:12:11 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:12:11 --> Database Driver Class Initialized
INFO - 2023-06-27 11:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:12:11 --> Parser Class Initialized
INFO - 2023-06-27 11:12:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:12:11 --> Pagination Class Initialized
INFO - 2023-06-27 11:12:11 --> Form Validation Class Initialized
INFO - 2023-06-27 11:12:11 --> Controller Class Initialized
INFO - 2023-06-27 11:12:11 --> Model Class Initialized
DEBUG - 2023-06-27 11:12:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:12:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-27 11:12:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:12:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 11:12:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 11:12:11 --> Model Class Initialized
INFO - 2023-06-27 11:12:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 11:12:11 --> Final output sent to browser
DEBUG - 2023-06-27 11:12:11 --> Total execution time: 0.0357
ERROR - 2023-06-27 11:12:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:12:14 --> Config Class Initialized
INFO - 2023-06-27 11:12:14 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:12:14 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:12:14 --> Utf8 Class Initialized
INFO - 2023-06-27 11:12:14 --> URI Class Initialized
INFO - 2023-06-27 11:12:14 --> Router Class Initialized
INFO - 2023-06-27 11:12:14 --> Output Class Initialized
INFO - 2023-06-27 11:12:14 --> Security Class Initialized
DEBUG - 2023-06-27 11:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:12:14 --> Input Class Initialized
INFO - 2023-06-27 11:12:14 --> Language Class Initialized
INFO - 2023-06-27 11:12:14 --> Loader Class Initialized
INFO - 2023-06-27 11:12:14 --> Helper loaded: url_helper
INFO - 2023-06-27 11:12:14 --> Helper loaded: file_helper
INFO - 2023-06-27 11:12:14 --> Helper loaded: html_helper
INFO - 2023-06-27 11:12:14 --> Helper loaded: text_helper
INFO - 2023-06-27 11:12:14 --> Helper loaded: form_helper
INFO - 2023-06-27 11:12:14 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:12:14 --> Helper loaded: security_helper
INFO - 2023-06-27 11:12:14 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:12:14 --> Database Driver Class Initialized
INFO - 2023-06-27 11:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:12:14 --> Parser Class Initialized
INFO - 2023-06-27 11:12:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:12:14 --> Pagination Class Initialized
INFO - 2023-06-27 11:12:14 --> Form Validation Class Initialized
INFO - 2023-06-27 11:12:14 --> Controller Class Initialized
INFO - 2023-06-27 11:12:14 --> Model Class Initialized
DEBUG - 2023-06-27 11:12:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:12:14 --> Model Class Initialized
INFO - 2023-06-27 11:12:14 --> Final output sent to browser
DEBUG - 2023-06-27 11:12:14 --> Total execution time: 0.0223
ERROR - 2023-06-27 11:12:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:12:15 --> Config Class Initialized
INFO - 2023-06-27 11:12:15 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:12:15 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:12:15 --> Utf8 Class Initialized
INFO - 2023-06-27 11:12:15 --> URI Class Initialized
DEBUG - 2023-06-27 11:12:15 --> No URI present. Default controller set.
INFO - 2023-06-27 11:12:15 --> Router Class Initialized
INFO - 2023-06-27 11:12:15 --> Output Class Initialized
INFO - 2023-06-27 11:12:15 --> Security Class Initialized
DEBUG - 2023-06-27 11:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:12:15 --> Input Class Initialized
INFO - 2023-06-27 11:12:15 --> Language Class Initialized
INFO - 2023-06-27 11:12:15 --> Loader Class Initialized
INFO - 2023-06-27 11:12:15 --> Helper loaded: url_helper
INFO - 2023-06-27 11:12:15 --> Helper loaded: file_helper
INFO - 2023-06-27 11:12:15 --> Helper loaded: html_helper
INFO - 2023-06-27 11:12:15 --> Helper loaded: text_helper
INFO - 2023-06-27 11:12:15 --> Helper loaded: form_helper
INFO - 2023-06-27 11:12:15 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:12:15 --> Helper loaded: security_helper
INFO - 2023-06-27 11:12:15 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:12:15 --> Database Driver Class Initialized
INFO - 2023-06-27 11:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:12:15 --> Parser Class Initialized
INFO - 2023-06-27 11:12:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:12:15 --> Pagination Class Initialized
INFO - 2023-06-27 11:12:15 --> Form Validation Class Initialized
INFO - 2023-06-27 11:12:15 --> Controller Class Initialized
INFO - 2023-06-27 11:12:15 --> Model Class Initialized
DEBUG - 2023-06-27 11:12:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:12:15 --> Model Class Initialized
DEBUG - 2023-06-27 11:12:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:12:15 --> Model Class Initialized
INFO - 2023-06-27 11:12:15 --> Model Class Initialized
INFO - 2023-06-27 11:12:15 --> Model Class Initialized
INFO - 2023-06-27 11:12:15 --> Model Class Initialized
DEBUG - 2023-06-27 11:12:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:12:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:12:15 --> Model Class Initialized
INFO - 2023-06-27 11:12:15 --> Model Class Initialized
INFO - 2023-06-27 11:12:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 11:12:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:12:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 11:12:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 11:12:15 --> Model Class Initialized
INFO - 2023-06-27 11:12:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 11:12:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 11:12:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 11:12:15 --> Final output sent to browser
DEBUG - 2023-06-27 11:12:15 --> Total execution time: 0.1901
ERROR - 2023-06-27 11:12:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:12:16 --> Config Class Initialized
INFO - 2023-06-27 11:12:16 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:12:16 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:12:16 --> Utf8 Class Initialized
INFO - 2023-06-27 11:12:16 --> URI Class Initialized
INFO - 2023-06-27 11:12:16 --> Router Class Initialized
INFO - 2023-06-27 11:12:16 --> Output Class Initialized
INFO - 2023-06-27 11:12:16 --> Security Class Initialized
DEBUG - 2023-06-27 11:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:12:16 --> Input Class Initialized
INFO - 2023-06-27 11:12:16 --> Language Class Initialized
INFO - 2023-06-27 11:12:16 --> Loader Class Initialized
INFO - 2023-06-27 11:12:16 --> Helper loaded: url_helper
INFO - 2023-06-27 11:12:16 --> Helper loaded: file_helper
INFO - 2023-06-27 11:12:16 --> Helper loaded: html_helper
INFO - 2023-06-27 11:12:16 --> Helper loaded: text_helper
INFO - 2023-06-27 11:12:16 --> Helper loaded: form_helper
INFO - 2023-06-27 11:12:16 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:12:16 --> Helper loaded: security_helper
INFO - 2023-06-27 11:12:16 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:12:16 --> Database Driver Class Initialized
INFO - 2023-06-27 11:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:12:16 --> Parser Class Initialized
INFO - 2023-06-27 11:12:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:12:16 --> Pagination Class Initialized
INFO - 2023-06-27 11:12:16 --> Form Validation Class Initialized
INFO - 2023-06-27 11:12:16 --> Controller Class Initialized
DEBUG - 2023-06-27 11:12:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:12:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:12:16 --> Model Class Initialized
INFO - 2023-06-27 11:12:16 --> Final output sent to browser
DEBUG - 2023-06-27 11:12:16 --> Total execution time: 0.0162
ERROR - 2023-06-27 11:12:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:12:22 --> Config Class Initialized
INFO - 2023-06-27 11:12:22 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:12:22 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:12:22 --> Utf8 Class Initialized
INFO - 2023-06-27 11:12:22 --> URI Class Initialized
INFO - 2023-06-27 11:12:22 --> Router Class Initialized
INFO - 2023-06-27 11:12:22 --> Output Class Initialized
INFO - 2023-06-27 11:12:22 --> Security Class Initialized
DEBUG - 2023-06-27 11:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:12:22 --> Input Class Initialized
INFO - 2023-06-27 11:12:22 --> Language Class Initialized
INFO - 2023-06-27 11:12:22 --> Loader Class Initialized
INFO - 2023-06-27 11:12:22 --> Helper loaded: url_helper
INFO - 2023-06-27 11:12:22 --> Helper loaded: file_helper
INFO - 2023-06-27 11:12:22 --> Helper loaded: html_helper
INFO - 2023-06-27 11:12:22 --> Helper loaded: text_helper
INFO - 2023-06-27 11:12:22 --> Helper loaded: form_helper
INFO - 2023-06-27 11:12:22 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:12:22 --> Helper loaded: security_helper
INFO - 2023-06-27 11:12:22 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:12:22 --> Database Driver Class Initialized
INFO - 2023-06-27 11:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:12:22 --> Parser Class Initialized
INFO - 2023-06-27 11:12:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:12:22 --> Pagination Class Initialized
INFO - 2023-06-27 11:12:22 --> Form Validation Class Initialized
INFO - 2023-06-27 11:12:22 --> Controller Class Initialized
DEBUG - 2023-06-27 11:12:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:12:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:12:22 --> Model Class Initialized
DEBUG - 2023-06-27 11:12:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:12:22 --> Model Class Initialized
DEBUG - 2023-06-27 11:12:22 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:12:22 --> Model Class Initialized
INFO - 2023-06-27 11:12:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-06-27 11:12:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:12:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 11:12:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 11:12:22 --> Model Class Initialized
INFO - 2023-06-27 11:12:22 --> Model Class Initialized
INFO - 2023-06-27 11:12:22 --> Model Class Initialized
INFO - 2023-06-27 11:12:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 11:12:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 11:12:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 11:12:22 --> Final output sent to browser
DEBUG - 2023-06-27 11:12:22 --> Total execution time: 0.1532
ERROR - 2023-06-27 11:12:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:12:23 --> Config Class Initialized
INFO - 2023-06-27 11:12:23 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:12:23 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:12:23 --> Utf8 Class Initialized
INFO - 2023-06-27 11:12:23 --> URI Class Initialized
INFO - 2023-06-27 11:12:23 --> Router Class Initialized
INFO - 2023-06-27 11:12:23 --> Output Class Initialized
INFO - 2023-06-27 11:12:23 --> Security Class Initialized
DEBUG - 2023-06-27 11:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:12:23 --> Input Class Initialized
INFO - 2023-06-27 11:12:23 --> Language Class Initialized
INFO - 2023-06-27 11:12:23 --> Loader Class Initialized
INFO - 2023-06-27 11:12:23 --> Helper loaded: url_helper
INFO - 2023-06-27 11:12:23 --> Helper loaded: file_helper
INFO - 2023-06-27 11:12:23 --> Helper loaded: html_helper
INFO - 2023-06-27 11:12:23 --> Helper loaded: text_helper
INFO - 2023-06-27 11:12:23 --> Helper loaded: form_helper
INFO - 2023-06-27 11:12:23 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:12:23 --> Helper loaded: security_helper
INFO - 2023-06-27 11:12:23 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:12:23 --> Database Driver Class Initialized
INFO - 2023-06-27 11:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:12:23 --> Parser Class Initialized
INFO - 2023-06-27 11:12:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:12:23 --> Pagination Class Initialized
INFO - 2023-06-27 11:12:23 --> Form Validation Class Initialized
INFO - 2023-06-27 11:12:23 --> Controller Class Initialized
DEBUG - 2023-06-27 11:12:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:12:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:12:23 --> Model Class Initialized
DEBUG - 2023-06-27 11:12:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:12:23 --> Model Class Initialized
INFO - 2023-06-27 11:12:23 --> Final output sent to browser
DEBUG - 2023-06-27 11:12:23 --> Total execution time: 0.0344
ERROR - 2023-06-27 11:12:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:12:29 --> Config Class Initialized
INFO - 2023-06-27 11:12:29 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:12:29 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:12:29 --> Utf8 Class Initialized
INFO - 2023-06-27 11:12:29 --> URI Class Initialized
INFO - 2023-06-27 11:12:29 --> Router Class Initialized
INFO - 2023-06-27 11:12:29 --> Output Class Initialized
INFO - 2023-06-27 11:12:29 --> Security Class Initialized
DEBUG - 2023-06-27 11:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:12:29 --> Input Class Initialized
INFO - 2023-06-27 11:12:29 --> Language Class Initialized
INFO - 2023-06-27 11:12:29 --> Loader Class Initialized
INFO - 2023-06-27 11:12:29 --> Helper loaded: url_helper
INFO - 2023-06-27 11:12:29 --> Helper loaded: file_helper
INFO - 2023-06-27 11:12:29 --> Helper loaded: html_helper
INFO - 2023-06-27 11:12:29 --> Helper loaded: text_helper
INFO - 2023-06-27 11:12:29 --> Helper loaded: form_helper
INFO - 2023-06-27 11:12:29 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:12:29 --> Helper loaded: security_helper
INFO - 2023-06-27 11:12:29 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:12:29 --> Database Driver Class Initialized
INFO - 2023-06-27 11:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:12:29 --> Parser Class Initialized
INFO - 2023-06-27 11:12:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:12:29 --> Pagination Class Initialized
INFO - 2023-06-27 11:12:29 --> Form Validation Class Initialized
INFO - 2023-06-27 11:12:29 --> Controller Class Initialized
DEBUG - 2023-06-27 11:12:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:12:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:12:29 --> Model Class Initialized
DEBUG - 2023-06-27 11:12:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:12:29 --> Model Class Initialized
INFO - 2023-06-27 11:12:30 --> Final output sent to browser
DEBUG - 2023-06-27 11:12:30 --> Total execution time: 0.1212
ERROR - 2023-06-27 11:12:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:12:42 --> Config Class Initialized
INFO - 2023-06-27 11:12:42 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:12:42 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:12:42 --> Utf8 Class Initialized
INFO - 2023-06-27 11:12:42 --> URI Class Initialized
INFO - 2023-06-27 11:12:42 --> Router Class Initialized
INFO - 2023-06-27 11:12:42 --> Output Class Initialized
INFO - 2023-06-27 11:12:42 --> Security Class Initialized
DEBUG - 2023-06-27 11:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:12:42 --> Input Class Initialized
INFO - 2023-06-27 11:12:42 --> Language Class Initialized
INFO - 2023-06-27 11:12:42 --> Loader Class Initialized
INFO - 2023-06-27 11:12:42 --> Helper loaded: url_helper
INFO - 2023-06-27 11:12:42 --> Helper loaded: file_helper
INFO - 2023-06-27 11:12:42 --> Helper loaded: html_helper
INFO - 2023-06-27 11:12:42 --> Helper loaded: text_helper
INFO - 2023-06-27 11:12:42 --> Helper loaded: form_helper
INFO - 2023-06-27 11:12:42 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:12:42 --> Helper loaded: security_helper
INFO - 2023-06-27 11:12:42 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:12:42 --> Database Driver Class Initialized
INFO - 2023-06-27 11:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:12:42 --> Parser Class Initialized
INFO - 2023-06-27 11:12:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:12:42 --> Pagination Class Initialized
INFO - 2023-06-27 11:12:42 --> Form Validation Class Initialized
INFO - 2023-06-27 11:12:42 --> Controller Class Initialized
DEBUG - 2023-06-27 11:12:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:12:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:12:42 --> Model Class Initialized
DEBUG - 2023-06-27 11:12:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:12:42 --> Model Class Initialized
INFO - 2023-06-27 11:12:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-06-27 11:12:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:12:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 11:12:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 11:12:42 --> Model Class Initialized
INFO - 2023-06-27 11:12:42 --> Model Class Initialized
INFO - 2023-06-27 11:12:42 --> Model Class Initialized
INFO - 2023-06-27 11:12:42 --> Model Class Initialized
INFO - 2023-06-27 11:12:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 11:12:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 11:12:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 11:12:42 --> Final output sent to browser
DEBUG - 2023-06-27 11:12:42 --> Total execution time: 0.1591
ERROR - 2023-06-27 11:13:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:13:10 --> Config Class Initialized
INFO - 2023-06-27 11:13:10 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:13:10 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:13:10 --> Utf8 Class Initialized
INFO - 2023-06-27 11:13:10 --> URI Class Initialized
DEBUG - 2023-06-27 11:13:10 --> No URI present. Default controller set.
INFO - 2023-06-27 11:13:10 --> Router Class Initialized
INFO - 2023-06-27 11:13:10 --> Output Class Initialized
INFO - 2023-06-27 11:13:10 --> Security Class Initialized
DEBUG - 2023-06-27 11:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:13:10 --> Input Class Initialized
INFO - 2023-06-27 11:13:10 --> Language Class Initialized
INFO - 2023-06-27 11:13:10 --> Loader Class Initialized
INFO - 2023-06-27 11:13:10 --> Helper loaded: url_helper
INFO - 2023-06-27 11:13:10 --> Helper loaded: file_helper
INFO - 2023-06-27 11:13:10 --> Helper loaded: html_helper
INFO - 2023-06-27 11:13:10 --> Helper loaded: text_helper
INFO - 2023-06-27 11:13:10 --> Helper loaded: form_helper
INFO - 2023-06-27 11:13:10 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:13:10 --> Helper loaded: security_helper
INFO - 2023-06-27 11:13:10 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:13:10 --> Database Driver Class Initialized
INFO - 2023-06-27 11:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:13:10 --> Parser Class Initialized
INFO - 2023-06-27 11:13:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:13:10 --> Pagination Class Initialized
INFO - 2023-06-27 11:13:10 --> Form Validation Class Initialized
INFO - 2023-06-27 11:13:10 --> Controller Class Initialized
INFO - 2023-06-27 11:13:10 --> Model Class Initialized
DEBUG - 2023-06-27 11:13:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-27 11:13:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:13:10 --> Config Class Initialized
INFO - 2023-06-27 11:13:10 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:13:10 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:13:10 --> Utf8 Class Initialized
INFO - 2023-06-27 11:13:10 --> URI Class Initialized
INFO - 2023-06-27 11:13:10 --> Router Class Initialized
INFO - 2023-06-27 11:13:10 --> Output Class Initialized
INFO - 2023-06-27 11:13:10 --> Security Class Initialized
DEBUG - 2023-06-27 11:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:13:10 --> Input Class Initialized
INFO - 2023-06-27 11:13:10 --> Language Class Initialized
INFO - 2023-06-27 11:13:10 --> Loader Class Initialized
INFO - 2023-06-27 11:13:10 --> Helper loaded: url_helper
INFO - 2023-06-27 11:13:10 --> Helper loaded: file_helper
INFO - 2023-06-27 11:13:10 --> Helper loaded: html_helper
INFO - 2023-06-27 11:13:10 --> Helper loaded: text_helper
INFO - 2023-06-27 11:13:10 --> Helper loaded: form_helper
INFO - 2023-06-27 11:13:10 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:13:10 --> Helper loaded: security_helper
INFO - 2023-06-27 11:13:10 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:13:10 --> Database Driver Class Initialized
INFO - 2023-06-27 11:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:13:10 --> Parser Class Initialized
INFO - 2023-06-27 11:13:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:13:10 --> Pagination Class Initialized
INFO - 2023-06-27 11:13:10 --> Form Validation Class Initialized
INFO - 2023-06-27 11:13:10 --> Controller Class Initialized
INFO - 2023-06-27 11:13:10 --> Model Class Initialized
DEBUG - 2023-06-27 11:13:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:13:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-27 11:13:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:13:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 11:13:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 11:13:10 --> Model Class Initialized
INFO - 2023-06-27 11:13:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 11:13:10 --> Final output sent to browser
DEBUG - 2023-06-27 11:13:10 --> Total execution time: 0.0372
ERROR - 2023-06-27 11:13:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:13:32 --> Config Class Initialized
INFO - 2023-06-27 11:13:32 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:13:32 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:13:32 --> Utf8 Class Initialized
INFO - 2023-06-27 11:13:32 --> URI Class Initialized
INFO - 2023-06-27 11:13:32 --> Router Class Initialized
INFO - 2023-06-27 11:13:32 --> Output Class Initialized
INFO - 2023-06-27 11:13:32 --> Security Class Initialized
DEBUG - 2023-06-27 11:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:13:32 --> Input Class Initialized
INFO - 2023-06-27 11:13:32 --> Language Class Initialized
INFO - 2023-06-27 11:13:32 --> Loader Class Initialized
INFO - 2023-06-27 11:13:32 --> Helper loaded: url_helper
INFO - 2023-06-27 11:13:32 --> Helper loaded: file_helper
INFO - 2023-06-27 11:13:32 --> Helper loaded: html_helper
INFO - 2023-06-27 11:13:32 --> Helper loaded: text_helper
INFO - 2023-06-27 11:13:32 --> Helper loaded: form_helper
INFO - 2023-06-27 11:13:32 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:13:32 --> Helper loaded: security_helper
INFO - 2023-06-27 11:13:32 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:13:32 --> Database Driver Class Initialized
INFO - 2023-06-27 11:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:13:32 --> Parser Class Initialized
INFO - 2023-06-27 11:13:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:13:32 --> Pagination Class Initialized
INFO - 2023-06-27 11:13:32 --> Form Validation Class Initialized
INFO - 2023-06-27 11:13:32 --> Controller Class Initialized
INFO - 2023-06-27 11:13:32 --> Model Class Initialized
DEBUG - 2023-06-27 11:13:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:13:32 --> Model Class Initialized
INFO - 2023-06-27 11:13:32 --> Final output sent to browser
DEBUG - 2023-06-27 11:13:32 --> Total execution time: 0.0199
ERROR - 2023-06-27 11:13:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:13:32 --> Config Class Initialized
INFO - 2023-06-27 11:13:32 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:13:32 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:13:32 --> Utf8 Class Initialized
INFO - 2023-06-27 11:13:32 --> URI Class Initialized
DEBUG - 2023-06-27 11:13:32 --> No URI present. Default controller set.
INFO - 2023-06-27 11:13:32 --> Router Class Initialized
INFO - 2023-06-27 11:13:32 --> Output Class Initialized
INFO - 2023-06-27 11:13:32 --> Security Class Initialized
DEBUG - 2023-06-27 11:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:13:32 --> Input Class Initialized
INFO - 2023-06-27 11:13:32 --> Language Class Initialized
INFO - 2023-06-27 11:13:32 --> Loader Class Initialized
INFO - 2023-06-27 11:13:32 --> Helper loaded: url_helper
INFO - 2023-06-27 11:13:32 --> Helper loaded: file_helper
INFO - 2023-06-27 11:13:32 --> Helper loaded: html_helper
INFO - 2023-06-27 11:13:32 --> Helper loaded: text_helper
INFO - 2023-06-27 11:13:32 --> Helper loaded: form_helper
INFO - 2023-06-27 11:13:32 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:13:32 --> Helper loaded: security_helper
INFO - 2023-06-27 11:13:32 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:13:32 --> Database Driver Class Initialized
INFO - 2023-06-27 11:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:13:32 --> Parser Class Initialized
INFO - 2023-06-27 11:13:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:13:32 --> Pagination Class Initialized
INFO - 2023-06-27 11:13:32 --> Form Validation Class Initialized
INFO - 2023-06-27 11:13:32 --> Controller Class Initialized
INFO - 2023-06-27 11:13:32 --> Model Class Initialized
DEBUG - 2023-06-27 11:13:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:13:32 --> Model Class Initialized
DEBUG - 2023-06-27 11:13:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:13:32 --> Model Class Initialized
INFO - 2023-06-27 11:13:32 --> Model Class Initialized
INFO - 2023-06-27 11:13:32 --> Model Class Initialized
INFO - 2023-06-27 11:13:32 --> Model Class Initialized
DEBUG - 2023-06-27 11:13:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:13:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:13:32 --> Model Class Initialized
INFO - 2023-06-27 11:13:32 --> Model Class Initialized
INFO - 2023-06-27 11:13:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 11:13:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:13:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 11:13:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 11:13:32 --> Model Class Initialized
INFO - 2023-06-27 11:13:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 11:13:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 11:13:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 11:13:32 --> Final output sent to browser
DEBUG - 2023-06-27 11:13:32 --> Total execution time: 0.0753
ERROR - 2023-06-27 11:13:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:13:46 --> Config Class Initialized
INFO - 2023-06-27 11:13:46 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:13:46 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:13:46 --> Utf8 Class Initialized
INFO - 2023-06-27 11:13:46 --> URI Class Initialized
INFO - 2023-06-27 11:13:46 --> Router Class Initialized
INFO - 2023-06-27 11:13:46 --> Output Class Initialized
INFO - 2023-06-27 11:13:46 --> Security Class Initialized
DEBUG - 2023-06-27 11:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:13:46 --> Input Class Initialized
INFO - 2023-06-27 11:13:46 --> Language Class Initialized
INFO - 2023-06-27 11:13:46 --> Loader Class Initialized
INFO - 2023-06-27 11:13:46 --> Helper loaded: url_helper
INFO - 2023-06-27 11:13:46 --> Helper loaded: file_helper
INFO - 2023-06-27 11:13:46 --> Helper loaded: html_helper
INFO - 2023-06-27 11:13:46 --> Helper loaded: text_helper
INFO - 2023-06-27 11:13:46 --> Helper loaded: form_helper
INFO - 2023-06-27 11:13:46 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:13:46 --> Helper loaded: security_helper
INFO - 2023-06-27 11:13:46 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:13:46 --> Database Driver Class Initialized
INFO - 2023-06-27 11:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:13:46 --> Parser Class Initialized
INFO - 2023-06-27 11:13:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:13:46 --> Pagination Class Initialized
INFO - 2023-06-27 11:13:46 --> Form Validation Class Initialized
INFO - 2023-06-27 11:13:46 --> Controller Class Initialized
INFO - 2023-06-27 11:13:46 --> Model Class Initialized
DEBUG - 2023-06-27 11:13:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:13:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:13:46 --> Model Class Initialized
DEBUG - 2023-06-27 11:13:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:13:46 --> Model Class Initialized
INFO - 2023-06-27 11:13:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-27 11:13:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:13:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 11:13:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 11:13:46 --> Model Class Initialized
INFO - 2023-06-27 11:13:46 --> Model Class Initialized
INFO - 2023-06-27 11:13:46 --> Model Class Initialized
INFO - 2023-06-27 11:13:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 11:13:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 11:13:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 11:13:46 --> Final output sent to browser
DEBUG - 2023-06-27 11:13:46 --> Total execution time: 0.0700
ERROR - 2023-06-27 11:13:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:13:47 --> Config Class Initialized
INFO - 2023-06-27 11:13:47 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:13:47 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:13:47 --> Utf8 Class Initialized
INFO - 2023-06-27 11:13:47 --> URI Class Initialized
INFO - 2023-06-27 11:13:47 --> Router Class Initialized
INFO - 2023-06-27 11:13:47 --> Output Class Initialized
INFO - 2023-06-27 11:13:47 --> Security Class Initialized
DEBUG - 2023-06-27 11:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:13:47 --> Input Class Initialized
INFO - 2023-06-27 11:13:47 --> Language Class Initialized
INFO - 2023-06-27 11:13:47 --> Loader Class Initialized
INFO - 2023-06-27 11:13:47 --> Helper loaded: url_helper
INFO - 2023-06-27 11:13:47 --> Helper loaded: file_helper
INFO - 2023-06-27 11:13:47 --> Helper loaded: html_helper
INFO - 2023-06-27 11:13:47 --> Helper loaded: text_helper
INFO - 2023-06-27 11:13:47 --> Helper loaded: form_helper
INFO - 2023-06-27 11:13:47 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:13:47 --> Helper loaded: security_helper
INFO - 2023-06-27 11:13:47 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:13:47 --> Database Driver Class Initialized
INFO - 2023-06-27 11:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:13:47 --> Parser Class Initialized
INFO - 2023-06-27 11:13:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:13:47 --> Pagination Class Initialized
INFO - 2023-06-27 11:13:47 --> Form Validation Class Initialized
INFO - 2023-06-27 11:13:47 --> Controller Class Initialized
INFO - 2023-06-27 11:13:47 --> Model Class Initialized
DEBUG - 2023-06-27 11:13:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:13:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:13:47 --> Model Class Initialized
DEBUG - 2023-06-27 11:13:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:13:47 --> Model Class Initialized
INFO - 2023-06-27 11:13:47 --> Final output sent to browser
DEBUG - 2023-06-27 11:13:47 --> Total execution time: 0.0310
ERROR - 2023-06-27 11:13:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:13:57 --> Config Class Initialized
INFO - 2023-06-27 11:13:57 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:13:57 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:13:57 --> Utf8 Class Initialized
INFO - 2023-06-27 11:13:57 --> URI Class Initialized
DEBUG - 2023-06-27 11:13:57 --> No URI present. Default controller set.
INFO - 2023-06-27 11:13:57 --> Router Class Initialized
INFO - 2023-06-27 11:13:57 --> Output Class Initialized
INFO - 2023-06-27 11:13:57 --> Security Class Initialized
DEBUG - 2023-06-27 11:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:13:57 --> Input Class Initialized
INFO - 2023-06-27 11:13:57 --> Language Class Initialized
INFO - 2023-06-27 11:13:57 --> Loader Class Initialized
INFO - 2023-06-27 11:13:57 --> Helper loaded: url_helper
INFO - 2023-06-27 11:13:57 --> Helper loaded: file_helper
INFO - 2023-06-27 11:13:57 --> Helper loaded: html_helper
INFO - 2023-06-27 11:13:57 --> Helper loaded: text_helper
INFO - 2023-06-27 11:13:57 --> Helper loaded: form_helper
INFO - 2023-06-27 11:13:57 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:13:57 --> Helper loaded: security_helper
INFO - 2023-06-27 11:13:57 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:13:57 --> Database Driver Class Initialized
INFO - 2023-06-27 11:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:13:57 --> Parser Class Initialized
INFO - 2023-06-27 11:13:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:13:57 --> Pagination Class Initialized
INFO - 2023-06-27 11:13:57 --> Form Validation Class Initialized
INFO - 2023-06-27 11:13:57 --> Controller Class Initialized
INFO - 2023-06-27 11:13:57 --> Model Class Initialized
DEBUG - 2023-06-27 11:13:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:13:57 --> Model Class Initialized
DEBUG - 2023-06-27 11:13:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:13:57 --> Model Class Initialized
INFO - 2023-06-27 11:13:57 --> Model Class Initialized
INFO - 2023-06-27 11:13:57 --> Model Class Initialized
INFO - 2023-06-27 11:13:57 --> Model Class Initialized
DEBUG - 2023-06-27 11:13:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:13:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:13:57 --> Model Class Initialized
INFO - 2023-06-27 11:13:57 --> Model Class Initialized
INFO - 2023-06-27 11:13:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 11:13:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:13:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 11:13:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 11:13:57 --> Model Class Initialized
INFO - 2023-06-27 11:13:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 11:13:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 11:13:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 11:13:57 --> Final output sent to browser
DEBUG - 2023-06-27 11:13:57 --> Total execution time: 0.0796
ERROR - 2023-06-27 11:14:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:14:07 --> Config Class Initialized
INFO - 2023-06-27 11:14:07 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:14:07 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:14:07 --> Utf8 Class Initialized
INFO - 2023-06-27 11:14:07 --> URI Class Initialized
INFO - 2023-06-27 11:14:07 --> Router Class Initialized
INFO - 2023-06-27 11:14:07 --> Output Class Initialized
INFO - 2023-06-27 11:14:07 --> Security Class Initialized
DEBUG - 2023-06-27 11:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:14:07 --> Input Class Initialized
INFO - 2023-06-27 11:14:07 --> Language Class Initialized
INFO - 2023-06-27 11:14:07 --> Loader Class Initialized
INFO - 2023-06-27 11:14:07 --> Helper loaded: url_helper
INFO - 2023-06-27 11:14:07 --> Helper loaded: file_helper
INFO - 2023-06-27 11:14:07 --> Helper loaded: html_helper
INFO - 2023-06-27 11:14:07 --> Helper loaded: text_helper
INFO - 2023-06-27 11:14:07 --> Helper loaded: form_helper
INFO - 2023-06-27 11:14:07 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:14:07 --> Helper loaded: security_helper
INFO - 2023-06-27 11:14:07 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:14:07 --> Database Driver Class Initialized
INFO - 2023-06-27 11:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:14:08 --> Parser Class Initialized
INFO - 2023-06-27 11:14:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:14:08 --> Pagination Class Initialized
INFO - 2023-06-27 11:14:08 --> Form Validation Class Initialized
INFO - 2023-06-27 11:14:08 --> Controller Class Initialized
INFO - 2023-06-27 11:14:08 --> Model Class Initialized
DEBUG - 2023-06-27 11:14:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:14:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:14:08 --> Model Class Initialized
DEBUG - 2023-06-27 11:14:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:14:08 --> Model Class Initialized
INFO - 2023-06-27 11:14:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-27 11:14:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:14:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 11:14:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 11:14:08 --> Model Class Initialized
INFO - 2023-06-27 11:14:08 --> Model Class Initialized
INFO - 2023-06-27 11:14:08 --> Model Class Initialized
INFO - 2023-06-27 11:14:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 11:14:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 11:14:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 11:14:08 --> Final output sent to browser
DEBUG - 2023-06-27 11:14:08 --> Total execution time: 0.0823
ERROR - 2023-06-27 11:14:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:14:08 --> Config Class Initialized
INFO - 2023-06-27 11:14:08 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:14:08 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:14:08 --> Utf8 Class Initialized
INFO - 2023-06-27 11:14:08 --> URI Class Initialized
INFO - 2023-06-27 11:14:08 --> Router Class Initialized
INFO - 2023-06-27 11:14:08 --> Output Class Initialized
INFO - 2023-06-27 11:14:08 --> Security Class Initialized
DEBUG - 2023-06-27 11:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:14:08 --> Input Class Initialized
INFO - 2023-06-27 11:14:08 --> Language Class Initialized
INFO - 2023-06-27 11:14:08 --> Loader Class Initialized
INFO - 2023-06-27 11:14:08 --> Helper loaded: url_helper
INFO - 2023-06-27 11:14:08 --> Helper loaded: file_helper
INFO - 2023-06-27 11:14:08 --> Helper loaded: html_helper
INFO - 2023-06-27 11:14:08 --> Helper loaded: text_helper
INFO - 2023-06-27 11:14:08 --> Helper loaded: form_helper
INFO - 2023-06-27 11:14:08 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:14:08 --> Helper loaded: security_helper
INFO - 2023-06-27 11:14:08 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:14:08 --> Database Driver Class Initialized
INFO - 2023-06-27 11:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:14:08 --> Parser Class Initialized
INFO - 2023-06-27 11:14:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:14:08 --> Pagination Class Initialized
INFO - 2023-06-27 11:14:08 --> Form Validation Class Initialized
INFO - 2023-06-27 11:14:08 --> Controller Class Initialized
INFO - 2023-06-27 11:14:08 --> Model Class Initialized
DEBUG - 2023-06-27 11:14:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:14:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:14:08 --> Model Class Initialized
DEBUG - 2023-06-27 11:14:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:14:08 --> Model Class Initialized
INFO - 2023-06-27 11:14:08 --> Final output sent to browser
DEBUG - 2023-06-27 11:14:08 --> Total execution time: 0.0277
ERROR - 2023-06-27 11:14:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:14:13 --> Config Class Initialized
INFO - 2023-06-27 11:14:13 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:14:13 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:14:13 --> Utf8 Class Initialized
INFO - 2023-06-27 11:14:13 --> URI Class Initialized
INFO - 2023-06-27 11:14:13 --> Router Class Initialized
INFO - 2023-06-27 11:14:13 --> Output Class Initialized
INFO - 2023-06-27 11:14:13 --> Security Class Initialized
DEBUG - 2023-06-27 11:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:14:13 --> Input Class Initialized
INFO - 2023-06-27 11:14:13 --> Language Class Initialized
INFO - 2023-06-27 11:14:13 --> Loader Class Initialized
INFO - 2023-06-27 11:14:13 --> Helper loaded: url_helper
INFO - 2023-06-27 11:14:13 --> Helper loaded: file_helper
INFO - 2023-06-27 11:14:13 --> Helper loaded: html_helper
INFO - 2023-06-27 11:14:13 --> Helper loaded: text_helper
INFO - 2023-06-27 11:14:13 --> Helper loaded: form_helper
INFO - 2023-06-27 11:14:13 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:14:13 --> Helper loaded: security_helper
INFO - 2023-06-27 11:14:13 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:14:13 --> Database Driver Class Initialized
INFO - 2023-06-27 11:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:14:13 --> Parser Class Initialized
INFO - 2023-06-27 11:14:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:14:13 --> Pagination Class Initialized
INFO - 2023-06-27 11:14:13 --> Form Validation Class Initialized
INFO - 2023-06-27 11:14:13 --> Controller Class Initialized
INFO - 2023-06-27 11:14:13 --> Model Class Initialized
DEBUG - 2023-06-27 11:14:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:14:13 --> Model Class Initialized
DEBUG - 2023-06-27 11:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:14:13 --> Model Class Initialized
DEBUG - 2023-06-27 11:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:14:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-06-27 11:14:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:14:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 11:14:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 11:14:13 --> Model Class Initialized
INFO - 2023-06-27 11:14:13 --> Model Class Initialized
INFO - 2023-06-27 11:14:13 --> Model Class Initialized
INFO - 2023-06-27 11:14:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 11:14:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 11:14:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 11:14:13 --> Final output sent to browser
DEBUG - 2023-06-27 11:14:13 --> Total execution time: 0.0839
ERROR - 2023-06-27 11:14:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:14:13 --> Config Class Initialized
INFO - 2023-06-27 11:14:13 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:14:13 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:14:13 --> Utf8 Class Initialized
INFO - 2023-06-27 11:14:13 --> URI Class Initialized
DEBUG - 2023-06-27 11:14:13 --> No URI present. Default controller set.
INFO - 2023-06-27 11:14:13 --> Router Class Initialized
INFO - 2023-06-27 11:14:13 --> Output Class Initialized
INFO - 2023-06-27 11:14:13 --> Security Class Initialized
DEBUG - 2023-06-27 11:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:14:13 --> Input Class Initialized
INFO - 2023-06-27 11:14:13 --> Language Class Initialized
INFO - 2023-06-27 11:14:13 --> Loader Class Initialized
INFO - 2023-06-27 11:14:13 --> Helper loaded: url_helper
INFO - 2023-06-27 11:14:13 --> Helper loaded: file_helper
INFO - 2023-06-27 11:14:13 --> Helper loaded: html_helper
INFO - 2023-06-27 11:14:13 --> Helper loaded: text_helper
INFO - 2023-06-27 11:14:13 --> Helper loaded: form_helper
INFO - 2023-06-27 11:14:13 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:14:13 --> Helper loaded: security_helper
INFO - 2023-06-27 11:14:13 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:14:13 --> Database Driver Class Initialized
INFO - 2023-06-27 11:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:14:13 --> Parser Class Initialized
INFO - 2023-06-27 11:14:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:14:13 --> Pagination Class Initialized
INFO - 2023-06-27 11:14:13 --> Form Validation Class Initialized
INFO - 2023-06-27 11:14:13 --> Controller Class Initialized
INFO - 2023-06-27 11:14:13 --> Model Class Initialized
DEBUG - 2023-06-27 11:14:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-27 11:14:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:14:14 --> Config Class Initialized
INFO - 2023-06-27 11:14:14 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:14:14 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:14:14 --> Utf8 Class Initialized
INFO - 2023-06-27 11:14:14 --> URI Class Initialized
INFO - 2023-06-27 11:14:14 --> Router Class Initialized
INFO - 2023-06-27 11:14:14 --> Output Class Initialized
INFO - 2023-06-27 11:14:14 --> Security Class Initialized
DEBUG - 2023-06-27 11:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:14:14 --> Input Class Initialized
INFO - 2023-06-27 11:14:14 --> Language Class Initialized
INFO - 2023-06-27 11:14:14 --> Loader Class Initialized
INFO - 2023-06-27 11:14:14 --> Helper loaded: url_helper
INFO - 2023-06-27 11:14:14 --> Helper loaded: file_helper
INFO - 2023-06-27 11:14:14 --> Helper loaded: html_helper
INFO - 2023-06-27 11:14:14 --> Helper loaded: text_helper
INFO - 2023-06-27 11:14:14 --> Helper loaded: form_helper
INFO - 2023-06-27 11:14:14 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:14:14 --> Helper loaded: security_helper
INFO - 2023-06-27 11:14:14 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:14:14 --> Database Driver Class Initialized
INFO - 2023-06-27 11:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:14:14 --> Parser Class Initialized
INFO - 2023-06-27 11:14:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:14:14 --> Pagination Class Initialized
INFO - 2023-06-27 11:14:14 --> Form Validation Class Initialized
INFO - 2023-06-27 11:14:14 --> Controller Class Initialized
INFO - 2023-06-27 11:14:14 --> Model Class Initialized
DEBUG - 2023-06-27 11:14:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-27 11:14:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 11:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 11:14:14 --> Model Class Initialized
INFO - 2023-06-27 11:14:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 11:14:14 --> Final output sent to browser
DEBUG - 2023-06-27 11:14:14 --> Total execution time: 0.0300
ERROR - 2023-06-27 11:14:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:14:25 --> Config Class Initialized
INFO - 2023-06-27 11:14:25 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:14:25 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:14:25 --> Utf8 Class Initialized
INFO - 2023-06-27 11:14:25 --> URI Class Initialized
INFO - 2023-06-27 11:14:25 --> Router Class Initialized
INFO - 2023-06-27 11:14:25 --> Output Class Initialized
INFO - 2023-06-27 11:14:25 --> Security Class Initialized
DEBUG - 2023-06-27 11:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:14:25 --> Input Class Initialized
INFO - 2023-06-27 11:14:25 --> Language Class Initialized
INFO - 2023-06-27 11:14:25 --> Loader Class Initialized
INFO - 2023-06-27 11:14:25 --> Helper loaded: url_helper
INFO - 2023-06-27 11:14:25 --> Helper loaded: file_helper
INFO - 2023-06-27 11:14:25 --> Helper loaded: html_helper
INFO - 2023-06-27 11:14:25 --> Helper loaded: text_helper
INFO - 2023-06-27 11:14:25 --> Helper loaded: form_helper
INFO - 2023-06-27 11:14:25 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:14:25 --> Helper loaded: security_helper
INFO - 2023-06-27 11:14:25 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:14:25 --> Database Driver Class Initialized
INFO - 2023-06-27 11:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:14:25 --> Parser Class Initialized
INFO - 2023-06-27 11:14:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:14:25 --> Pagination Class Initialized
INFO - 2023-06-27 11:14:25 --> Form Validation Class Initialized
INFO - 2023-06-27 11:14:25 --> Controller Class Initialized
INFO - 2023-06-27 11:14:25 --> Model Class Initialized
DEBUG - 2023-06-27 11:14:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:14:25 --> Model Class Initialized
INFO - 2023-06-27 11:14:25 --> Final output sent to browser
DEBUG - 2023-06-27 11:14:25 --> Total execution time: 0.0176
ERROR - 2023-06-27 11:14:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:14:25 --> Config Class Initialized
INFO - 2023-06-27 11:14:25 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:14:25 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:14:25 --> Utf8 Class Initialized
INFO - 2023-06-27 11:14:25 --> URI Class Initialized
INFO - 2023-06-27 11:14:25 --> Router Class Initialized
INFO - 2023-06-27 11:14:25 --> Output Class Initialized
INFO - 2023-06-27 11:14:25 --> Security Class Initialized
DEBUG - 2023-06-27 11:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:14:25 --> Input Class Initialized
INFO - 2023-06-27 11:14:25 --> Language Class Initialized
INFO - 2023-06-27 11:14:25 --> Loader Class Initialized
INFO - 2023-06-27 11:14:25 --> Helper loaded: url_helper
INFO - 2023-06-27 11:14:25 --> Helper loaded: file_helper
INFO - 2023-06-27 11:14:25 --> Helper loaded: html_helper
INFO - 2023-06-27 11:14:25 --> Helper loaded: text_helper
INFO - 2023-06-27 11:14:25 --> Helper loaded: form_helper
INFO - 2023-06-27 11:14:25 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:14:25 --> Helper loaded: security_helper
INFO - 2023-06-27 11:14:25 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:14:25 --> Database Driver Class Initialized
INFO - 2023-06-27 11:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:14:25 --> Parser Class Initialized
INFO - 2023-06-27 11:14:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:14:25 --> Pagination Class Initialized
INFO - 2023-06-27 11:14:25 --> Form Validation Class Initialized
INFO - 2023-06-27 11:14:25 --> Controller Class Initialized
INFO - 2023-06-27 11:14:25 --> Model Class Initialized
DEBUG - 2023-06-27 11:14:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:14:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-27 11:14:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:14:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 11:14:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 11:14:25 --> Model Class Initialized
INFO - 2023-06-27 11:14:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 11:14:25 --> Final output sent to browser
DEBUG - 2023-06-27 11:14:25 --> Total execution time: 0.0362
ERROR - 2023-06-27 11:15:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:15:10 --> Config Class Initialized
INFO - 2023-06-27 11:15:10 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:15:10 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:15:10 --> Utf8 Class Initialized
INFO - 2023-06-27 11:15:10 --> URI Class Initialized
INFO - 2023-06-27 11:15:10 --> Router Class Initialized
INFO - 2023-06-27 11:15:10 --> Output Class Initialized
INFO - 2023-06-27 11:15:10 --> Security Class Initialized
DEBUG - 2023-06-27 11:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:15:10 --> Input Class Initialized
INFO - 2023-06-27 11:15:10 --> Language Class Initialized
INFO - 2023-06-27 11:15:10 --> Loader Class Initialized
INFO - 2023-06-27 11:15:10 --> Helper loaded: url_helper
INFO - 2023-06-27 11:15:10 --> Helper loaded: file_helper
INFO - 2023-06-27 11:15:10 --> Helper loaded: html_helper
INFO - 2023-06-27 11:15:10 --> Helper loaded: text_helper
INFO - 2023-06-27 11:15:10 --> Helper loaded: form_helper
INFO - 2023-06-27 11:15:10 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:15:10 --> Helper loaded: security_helper
INFO - 2023-06-27 11:15:10 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:15:10 --> Database Driver Class Initialized
INFO - 2023-06-27 11:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:15:10 --> Parser Class Initialized
INFO - 2023-06-27 11:15:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:15:10 --> Pagination Class Initialized
INFO - 2023-06-27 11:15:10 --> Form Validation Class Initialized
INFO - 2023-06-27 11:15:10 --> Controller Class Initialized
INFO - 2023-06-27 11:15:10 --> Model Class Initialized
DEBUG - 2023-06-27 11:15:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:15:10 --> Model Class Initialized
INFO - 2023-06-27 11:15:10 --> Final output sent to browser
DEBUG - 2023-06-27 11:15:10 --> Total execution time: 0.0211
ERROR - 2023-06-27 11:15:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:15:10 --> Config Class Initialized
INFO - 2023-06-27 11:15:10 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:15:10 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:15:10 --> Utf8 Class Initialized
INFO - 2023-06-27 11:15:10 --> URI Class Initialized
DEBUG - 2023-06-27 11:15:10 --> No URI present. Default controller set.
INFO - 2023-06-27 11:15:10 --> Router Class Initialized
INFO - 2023-06-27 11:15:10 --> Output Class Initialized
INFO - 2023-06-27 11:15:10 --> Security Class Initialized
DEBUG - 2023-06-27 11:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:15:10 --> Input Class Initialized
INFO - 2023-06-27 11:15:10 --> Language Class Initialized
INFO - 2023-06-27 11:15:10 --> Loader Class Initialized
INFO - 2023-06-27 11:15:10 --> Helper loaded: url_helper
INFO - 2023-06-27 11:15:10 --> Helper loaded: file_helper
INFO - 2023-06-27 11:15:10 --> Helper loaded: html_helper
INFO - 2023-06-27 11:15:10 --> Helper loaded: text_helper
INFO - 2023-06-27 11:15:10 --> Helper loaded: form_helper
INFO - 2023-06-27 11:15:10 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:15:10 --> Helper loaded: security_helper
INFO - 2023-06-27 11:15:10 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:15:10 --> Database Driver Class Initialized
INFO - 2023-06-27 11:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:15:10 --> Parser Class Initialized
INFO - 2023-06-27 11:15:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:15:10 --> Pagination Class Initialized
INFO - 2023-06-27 11:15:10 --> Form Validation Class Initialized
INFO - 2023-06-27 11:15:10 --> Controller Class Initialized
INFO - 2023-06-27 11:15:10 --> Model Class Initialized
DEBUG - 2023-06-27 11:15:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:15:10 --> Model Class Initialized
DEBUG - 2023-06-27 11:15:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:15:10 --> Model Class Initialized
INFO - 2023-06-27 11:15:10 --> Model Class Initialized
INFO - 2023-06-27 11:15:10 --> Model Class Initialized
INFO - 2023-06-27 11:15:10 --> Model Class Initialized
DEBUG - 2023-06-27 11:15:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:15:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:15:10 --> Model Class Initialized
INFO - 2023-06-27 11:15:10 --> Model Class Initialized
INFO - 2023-06-27 11:15:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 11:15:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:15:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 11:15:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 11:15:10 --> Model Class Initialized
INFO - 2023-06-27 11:15:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 11:15:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 11:15:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 11:15:10 --> Final output sent to browser
DEBUG - 2023-06-27 11:15:10 --> Total execution time: 0.0799
ERROR - 2023-06-27 11:15:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:15:25 --> Config Class Initialized
INFO - 2023-06-27 11:15:25 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:15:25 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:15:25 --> Utf8 Class Initialized
INFO - 2023-06-27 11:15:25 --> URI Class Initialized
INFO - 2023-06-27 11:15:25 --> Router Class Initialized
INFO - 2023-06-27 11:15:25 --> Output Class Initialized
INFO - 2023-06-27 11:15:25 --> Security Class Initialized
DEBUG - 2023-06-27 11:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:15:25 --> Input Class Initialized
INFO - 2023-06-27 11:15:25 --> Language Class Initialized
INFO - 2023-06-27 11:15:25 --> Loader Class Initialized
INFO - 2023-06-27 11:15:25 --> Helper loaded: url_helper
INFO - 2023-06-27 11:15:25 --> Helper loaded: file_helper
INFO - 2023-06-27 11:15:25 --> Helper loaded: html_helper
INFO - 2023-06-27 11:15:25 --> Helper loaded: text_helper
INFO - 2023-06-27 11:15:25 --> Helper loaded: form_helper
INFO - 2023-06-27 11:15:25 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:15:25 --> Helper loaded: security_helper
INFO - 2023-06-27 11:15:25 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:15:25 --> Database Driver Class Initialized
INFO - 2023-06-27 11:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:15:25 --> Parser Class Initialized
INFO - 2023-06-27 11:15:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:15:25 --> Pagination Class Initialized
INFO - 2023-06-27 11:15:25 --> Form Validation Class Initialized
INFO - 2023-06-27 11:15:25 --> Controller Class Initialized
INFO - 2023-06-27 11:15:25 --> Model Class Initialized
DEBUG - 2023-06-27 11:15:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:15:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:15:25 --> Model Class Initialized
DEBUG - 2023-06-27 11:15:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:15:25 --> Model Class Initialized
INFO - 2023-06-27 11:15:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-27 11:15:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:15:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 11:15:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 11:15:25 --> Model Class Initialized
INFO - 2023-06-27 11:15:25 --> Model Class Initialized
INFO - 2023-06-27 11:15:25 --> Model Class Initialized
INFO - 2023-06-27 11:15:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 11:15:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 11:15:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 11:15:25 --> Final output sent to browser
DEBUG - 2023-06-27 11:15:25 --> Total execution time: 0.0696
ERROR - 2023-06-27 11:15:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:15:26 --> Config Class Initialized
INFO - 2023-06-27 11:15:26 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:15:26 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:15:26 --> Utf8 Class Initialized
INFO - 2023-06-27 11:15:26 --> URI Class Initialized
INFO - 2023-06-27 11:15:26 --> Router Class Initialized
INFO - 2023-06-27 11:15:26 --> Output Class Initialized
INFO - 2023-06-27 11:15:26 --> Security Class Initialized
DEBUG - 2023-06-27 11:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:15:26 --> Input Class Initialized
INFO - 2023-06-27 11:15:26 --> Language Class Initialized
INFO - 2023-06-27 11:15:26 --> Loader Class Initialized
INFO - 2023-06-27 11:15:26 --> Helper loaded: url_helper
INFO - 2023-06-27 11:15:26 --> Helper loaded: file_helper
INFO - 2023-06-27 11:15:26 --> Helper loaded: html_helper
INFO - 2023-06-27 11:15:26 --> Helper loaded: text_helper
INFO - 2023-06-27 11:15:26 --> Helper loaded: form_helper
INFO - 2023-06-27 11:15:26 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:15:26 --> Helper loaded: security_helper
INFO - 2023-06-27 11:15:26 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:15:26 --> Database Driver Class Initialized
INFO - 2023-06-27 11:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:15:26 --> Parser Class Initialized
INFO - 2023-06-27 11:15:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:15:26 --> Pagination Class Initialized
INFO - 2023-06-27 11:15:26 --> Form Validation Class Initialized
INFO - 2023-06-27 11:15:26 --> Controller Class Initialized
INFO - 2023-06-27 11:15:26 --> Model Class Initialized
DEBUG - 2023-06-27 11:15:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:15:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:15:26 --> Model Class Initialized
DEBUG - 2023-06-27 11:15:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:15:26 --> Model Class Initialized
INFO - 2023-06-27 11:15:26 --> Final output sent to browser
DEBUG - 2023-06-27 11:15:26 --> Total execution time: 0.0256
ERROR - 2023-06-27 11:15:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:15:53 --> Config Class Initialized
INFO - 2023-06-27 11:15:53 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:15:53 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:15:53 --> Utf8 Class Initialized
INFO - 2023-06-27 11:15:53 --> URI Class Initialized
INFO - 2023-06-27 11:15:53 --> Router Class Initialized
INFO - 2023-06-27 11:15:53 --> Output Class Initialized
INFO - 2023-06-27 11:15:53 --> Security Class Initialized
DEBUG - 2023-06-27 11:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:15:53 --> Input Class Initialized
INFO - 2023-06-27 11:15:53 --> Language Class Initialized
INFO - 2023-06-27 11:15:53 --> Loader Class Initialized
INFO - 2023-06-27 11:15:53 --> Helper loaded: url_helper
INFO - 2023-06-27 11:15:53 --> Helper loaded: file_helper
INFO - 2023-06-27 11:15:53 --> Helper loaded: html_helper
INFO - 2023-06-27 11:15:53 --> Helper loaded: text_helper
INFO - 2023-06-27 11:15:53 --> Helper loaded: form_helper
INFO - 2023-06-27 11:15:53 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:15:53 --> Helper loaded: security_helper
INFO - 2023-06-27 11:15:53 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:15:53 --> Database Driver Class Initialized
INFO - 2023-06-27 11:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:15:53 --> Parser Class Initialized
INFO - 2023-06-27 11:15:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:15:53 --> Pagination Class Initialized
INFO - 2023-06-27 11:15:53 --> Form Validation Class Initialized
INFO - 2023-06-27 11:15:53 --> Controller Class Initialized
INFO - 2023-06-27 11:15:53 --> Model Class Initialized
DEBUG - 2023-06-27 11:15:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:15:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:15:53 --> Model Class Initialized
DEBUG - 2023-06-27 11:15:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:15:53 --> Model Class Initialized
DEBUG - 2023-06-27 11:15:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:15:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:15:53 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-06-27 11:15:54 --> Final output sent to browser
DEBUG - 2023-06-27 11:15:54 --> Total execution time: 0.2020
ERROR - 2023-06-27 11:16:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:16:07 --> Config Class Initialized
INFO - 2023-06-27 11:16:07 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:16:07 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:16:07 --> Utf8 Class Initialized
INFO - 2023-06-27 11:16:07 --> URI Class Initialized
INFO - 2023-06-27 11:16:07 --> Router Class Initialized
INFO - 2023-06-27 11:16:07 --> Output Class Initialized
INFO - 2023-06-27 11:16:07 --> Security Class Initialized
DEBUG - 2023-06-27 11:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:16:07 --> Input Class Initialized
INFO - 2023-06-27 11:16:07 --> Language Class Initialized
INFO - 2023-06-27 11:16:07 --> Loader Class Initialized
INFO - 2023-06-27 11:16:07 --> Helper loaded: url_helper
INFO - 2023-06-27 11:16:07 --> Helper loaded: file_helper
INFO - 2023-06-27 11:16:07 --> Helper loaded: html_helper
INFO - 2023-06-27 11:16:07 --> Helper loaded: text_helper
INFO - 2023-06-27 11:16:07 --> Helper loaded: form_helper
INFO - 2023-06-27 11:16:07 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:16:07 --> Helper loaded: security_helper
INFO - 2023-06-27 11:16:07 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:16:07 --> Database Driver Class Initialized
INFO - 2023-06-27 11:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:16:07 --> Parser Class Initialized
INFO - 2023-06-27 11:16:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:16:07 --> Pagination Class Initialized
INFO - 2023-06-27 11:16:07 --> Form Validation Class Initialized
INFO - 2023-06-27 11:16:07 --> Controller Class Initialized
INFO - 2023-06-27 11:16:07 --> Model Class Initialized
DEBUG - 2023-06-27 11:16:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:16:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:16:07 --> Model Class Initialized
DEBUG - 2023-06-27 11:16:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:16:07 --> Model Class Initialized
DEBUG - 2023-06-27 11:16:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:16:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-06-27 11:16:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:16:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 11:16:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 11:16:07 --> Model Class Initialized
INFO - 2023-06-27 11:16:07 --> Model Class Initialized
INFO - 2023-06-27 11:16:07 --> Model Class Initialized
INFO - 2023-06-27 11:16:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 11:16:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 11:16:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 11:16:07 --> Final output sent to browser
DEBUG - 2023-06-27 11:16:07 --> Total execution time: 0.0764
ERROR - 2023-06-27 11:55:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:55:00 --> Config Class Initialized
INFO - 2023-06-27 11:55:00 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:55:00 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:55:00 --> Utf8 Class Initialized
INFO - 2023-06-27 11:55:00 --> URI Class Initialized
DEBUG - 2023-06-27 11:55:00 --> No URI present. Default controller set.
INFO - 2023-06-27 11:55:00 --> Router Class Initialized
INFO - 2023-06-27 11:55:00 --> Output Class Initialized
INFO - 2023-06-27 11:55:00 --> Security Class Initialized
DEBUG - 2023-06-27 11:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:55:00 --> Input Class Initialized
INFO - 2023-06-27 11:55:00 --> Language Class Initialized
INFO - 2023-06-27 11:55:00 --> Loader Class Initialized
INFO - 2023-06-27 11:55:00 --> Helper loaded: url_helper
INFO - 2023-06-27 11:55:00 --> Helper loaded: file_helper
INFO - 2023-06-27 11:55:00 --> Helper loaded: html_helper
INFO - 2023-06-27 11:55:00 --> Helper loaded: text_helper
INFO - 2023-06-27 11:55:00 --> Helper loaded: form_helper
INFO - 2023-06-27 11:55:00 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:55:00 --> Helper loaded: security_helper
INFO - 2023-06-27 11:55:00 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:55:00 --> Database Driver Class Initialized
INFO - 2023-06-27 11:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:55:00 --> Parser Class Initialized
INFO - 2023-06-27 11:55:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:55:00 --> Pagination Class Initialized
INFO - 2023-06-27 11:55:00 --> Form Validation Class Initialized
INFO - 2023-06-27 11:55:00 --> Controller Class Initialized
INFO - 2023-06-27 11:55:00 --> Model Class Initialized
DEBUG - 2023-06-27 11:55:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:55:00 --> Model Class Initialized
DEBUG - 2023-06-27 11:55:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:55:00 --> Model Class Initialized
INFO - 2023-06-27 11:55:00 --> Model Class Initialized
INFO - 2023-06-27 11:55:00 --> Model Class Initialized
INFO - 2023-06-27 11:55:00 --> Model Class Initialized
DEBUG - 2023-06-27 11:55:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:55:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:55:00 --> Model Class Initialized
INFO - 2023-06-27 11:55:00 --> Model Class Initialized
INFO - 2023-06-27 11:55:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 11:55:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:55:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 11:55:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 11:55:00 --> Model Class Initialized
INFO - 2023-06-27 11:55:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 11:55:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 11:55:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 11:55:00 --> Final output sent to browser
DEBUG - 2023-06-27 11:55:00 --> Total execution time: 0.0899
ERROR - 2023-06-27 11:55:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:55:08 --> Config Class Initialized
INFO - 2023-06-27 11:55:08 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:55:08 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:55:08 --> Utf8 Class Initialized
INFO - 2023-06-27 11:55:08 --> URI Class Initialized
INFO - 2023-06-27 11:55:08 --> Router Class Initialized
INFO - 2023-06-27 11:55:08 --> Output Class Initialized
INFO - 2023-06-27 11:55:08 --> Security Class Initialized
DEBUG - 2023-06-27 11:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:55:08 --> Input Class Initialized
INFO - 2023-06-27 11:55:08 --> Language Class Initialized
INFO - 2023-06-27 11:55:08 --> Loader Class Initialized
INFO - 2023-06-27 11:55:08 --> Helper loaded: url_helper
INFO - 2023-06-27 11:55:08 --> Helper loaded: file_helper
INFO - 2023-06-27 11:55:08 --> Helper loaded: html_helper
INFO - 2023-06-27 11:55:08 --> Helper loaded: text_helper
INFO - 2023-06-27 11:55:08 --> Helper loaded: form_helper
INFO - 2023-06-27 11:55:08 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:55:08 --> Helper loaded: security_helper
INFO - 2023-06-27 11:55:08 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:55:08 --> Database Driver Class Initialized
INFO - 2023-06-27 11:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:55:08 --> Parser Class Initialized
INFO - 2023-06-27 11:55:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:55:08 --> Pagination Class Initialized
INFO - 2023-06-27 11:55:08 --> Form Validation Class Initialized
INFO - 2023-06-27 11:55:08 --> Controller Class Initialized
INFO - 2023-06-27 11:55:08 --> Model Class Initialized
DEBUG - 2023-06-27 11:55:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:55:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:55:08 --> Model Class Initialized
DEBUG - 2023-06-27 11:55:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:55:08 --> Model Class Initialized
INFO - 2023-06-27 11:55:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-06-27 11:55:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:55:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 11:55:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 11:55:08 --> Model Class Initialized
INFO - 2023-06-27 11:55:08 --> Model Class Initialized
INFO - 2023-06-27 11:55:08 --> Model Class Initialized
INFO - 2023-06-27 11:55:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 11:55:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 11:55:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 11:55:08 --> Final output sent to browser
DEBUG - 2023-06-27 11:55:08 --> Total execution time: 0.1045
ERROR - 2023-06-27 11:55:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:55:14 --> Config Class Initialized
INFO - 2023-06-27 11:55:14 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:55:14 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:55:14 --> Utf8 Class Initialized
INFO - 2023-06-27 11:55:14 --> URI Class Initialized
INFO - 2023-06-27 11:55:14 --> Router Class Initialized
INFO - 2023-06-27 11:55:14 --> Output Class Initialized
INFO - 2023-06-27 11:55:14 --> Security Class Initialized
DEBUG - 2023-06-27 11:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:55:14 --> Input Class Initialized
INFO - 2023-06-27 11:55:14 --> Language Class Initialized
INFO - 2023-06-27 11:55:14 --> Loader Class Initialized
INFO - 2023-06-27 11:55:14 --> Helper loaded: url_helper
INFO - 2023-06-27 11:55:14 --> Helper loaded: file_helper
INFO - 2023-06-27 11:55:14 --> Helper loaded: html_helper
INFO - 2023-06-27 11:55:14 --> Helper loaded: text_helper
INFO - 2023-06-27 11:55:14 --> Helper loaded: form_helper
INFO - 2023-06-27 11:55:14 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:55:14 --> Helper loaded: security_helper
INFO - 2023-06-27 11:55:14 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:55:14 --> Database Driver Class Initialized
INFO - 2023-06-27 11:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:55:14 --> Parser Class Initialized
INFO - 2023-06-27 11:55:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:55:14 --> Pagination Class Initialized
INFO - 2023-06-27 11:55:14 --> Form Validation Class Initialized
INFO - 2023-06-27 11:55:14 --> Controller Class Initialized
INFO - 2023-06-27 11:55:14 --> Model Class Initialized
DEBUG - 2023-06-27 11:55:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:55:14 --> Final output sent to browser
DEBUG - 2023-06-27 11:55:14 --> Total execution time: 0.0157
ERROR - 2023-06-27 11:55:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:55:16 --> Config Class Initialized
INFO - 2023-06-27 11:55:16 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:55:16 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:55:16 --> Utf8 Class Initialized
INFO - 2023-06-27 11:55:16 --> URI Class Initialized
INFO - 2023-06-27 11:55:16 --> Router Class Initialized
INFO - 2023-06-27 11:55:16 --> Output Class Initialized
INFO - 2023-06-27 11:55:16 --> Security Class Initialized
DEBUG - 2023-06-27 11:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:55:16 --> Input Class Initialized
INFO - 2023-06-27 11:55:16 --> Language Class Initialized
INFO - 2023-06-27 11:55:16 --> Loader Class Initialized
INFO - 2023-06-27 11:55:16 --> Helper loaded: url_helper
INFO - 2023-06-27 11:55:16 --> Helper loaded: file_helper
INFO - 2023-06-27 11:55:16 --> Helper loaded: html_helper
INFO - 2023-06-27 11:55:16 --> Helper loaded: text_helper
INFO - 2023-06-27 11:55:16 --> Helper loaded: form_helper
INFO - 2023-06-27 11:55:16 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:55:16 --> Helper loaded: security_helper
INFO - 2023-06-27 11:55:16 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:55:16 --> Database Driver Class Initialized
INFO - 2023-06-27 11:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:55:16 --> Parser Class Initialized
INFO - 2023-06-27 11:55:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:55:16 --> Pagination Class Initialized
INFO - 2023-06-27 11:55:16 --> Form Validation Class Initialized
INFO - 2023-06-27 11:55:16 --> Controller Class Initialized
INFO - 2023-06-27 11:55:16 --> Final output sent to browser
DEBUG - 2023-06-27 11:55:16 --> Total execution time: 0.0143
ERROR - 2023-06-27 11:55:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:55:23 --> Config Class Initialized
INFO - 2023-06-27 11:55:23 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:55:23 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:55:23 --> Utf8 Class Initialized
INFO - 2023-06-27 11:55:23 --> URI Class Initialized
INFO - 2023-06-27 11:55:23 --> Router Class Initialized
INFO - 2023-06-27 11:55:23 --> Output Class Initialized
INFO - 2023-06-27 11:55:23 --> Security Class Initialized
DEBUG - 2023-06-27 11:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:55:23 --> Input Class Initialized
INFO - 2023-06-27 11:55:23 --> Language Class Initialized
INFO - 2023-06-27 11:55:23 --> Loader Class Initialized
INFO - 2023-06-27 11:55:23 --> Helper loaded: url_helper
INFO - 2023-06-27 11:55:23 --> Helper loaded: file_helper
INFO - 2023-06-27 11:55:23 --> Helper loaded: html_helper
INFO - 2023-06-27 11:55:23 --> Helper loaded: text_helper
INFO - 2023-06-27 11:55:23 --> Helper loaded: form_helper
INFO - 2023-06-27 11:55:23 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:55:23 --> Helper loaded: security_helper
INFO - 2023-06-27 11:55:23 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:55:23 --> Database Driver Class Initialized
INFO - 2023-06-27 11:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:55:23 --> Parser Class Initialized
INFO - 2023-06-27 11:55:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:55:23 --> Pagination Class Initialized
INFO - 2023-06-27 11:55:23 --> Form Validation Class Initialized
INFO - 2023-06-27 11:55:23 --> Controller Class Initialized
INFO - 2023-06-27 11:55:23 --> Model Class Initialized
DEBUG - 2023-06-27 11:55:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:55:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:55:23 --> Model Class Initialized
DEBUG - 2023-06-27 11:55:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:55:23 --> Model Class Initialized
INFO - 2023-06-27 11:55:23 --> Final output sent to browser
DEBUG - 2023-06-27 11:55:23 --> Total execution time: 0.0183
ERROR - 2023-06-27 11:55:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:55:24 --> Config Class Initialized
INFO - 2023-06-27 11:55:24 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:55:24 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:55:24 --> Utf8 Class Initialized
INFO - 2023-06-27 11:55:24 --> URI Class Initialized
INFO - 2023-06-27 11:55:24 --> Router Class Initialized
INFO - 2023-06-27 11:55:24 --> Output Class Initialized
INFO - 2023-06-27 11:55:24 --> Security Class Initialized
DEBUG - 2023-06-27 11:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:55:24 --> Input Class Initialized
INFO - 2023-06-27 11:55:24 --> Language Class Initialized
INFO - 2023-06-27 11:55:24 --> Loader Class Initialized
INFO - 2023-06-27 11:55:24 --> Helper loaded: url_helper
INFO - 2023-06-27 11:55:24 --> Helper loaded: file_helper
INFO - 2023-06-27 11:55:24 --> Helper loaded: html_helper
INFO - 2023-06-27 11:55:24 --> Helper loaded: text_helper
INFO - 2023-06-27 11:55:24 --> Helper loaded: form_helper
INFO - 2023-06-27 11:55:24 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:55:24 --> Helper loaded: security_helper
INFO - 2023-06-27 11:55:24 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:55:24 --> Database Driver Class Initialized
INFO - 2023-06-27 11:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:55:24 --> Parser Class Initialized
INFO - 2023-06-27 11:55:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:55:24 --> Pagination Class Initialized
INFO - 2023-06-27 11:55:24 --> Form Validation Class Initialized
INFO - 2023-06-27 11:55:24 --> Controller Class Initialized
INFO - 2023-06-27 11:55:24 --> Model Class Initialized
DEBUG - 2023-06-27 11:55:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:55:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:55:24 --> Model Class Initialized
DEBUG - 2023-06-27 11:55:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:55:24 --> Model Class Initialized
INFO - 2023-06-27 11:55:24 --> Final output sent to browser
DEBUG - 2023-06-27 11:55:24 --> Total execution time: 0.0448
ERROR - 2023-06-27 11:55:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:55:26 --> Config Class Initialized
INFO - 2023-06-27 11:55:26 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:55:26 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:55:26 --> Utf8 Class Initialized
INFO - 2023-06-27 11:55:26 --> URI Class Initialized
INFO - 2023-06-27 11:55:26 --> Router Class Initialized
INFO - 2023-06-27 11:55:26 --> Output Class Initialized
INFO - 2023-06-27 11:55:26 --> Security Class Initialized
DEBUG - 2023-06-27 11:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:55:26 --> Input Class Initialized
INFO - 2023-06-27 11:55:26 --> Language Class Initialized
INFO - 2023-06-27 11:55:26 --> Loader Class Initialized
INFO - 2023-06-27 11:55:26 --> Helper loaded: url_helper
INFO - 2023-06-27 11:55:26 --> Helper loaded: file_helper
INFO - 2023-06-27 11:55:26 --> Helper loaded: html_helper
INFO - 2023-06-27 11:55:26 --> Helper loaded: text_helper
INFO - 2023-06-27 11:55:26 --> Helper loaded: form_helper
INFO - 2023-06-27 11:55:26 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:55:26 --> Helper loaded: security_helper
INFO - 2023-06-27 11:55:26 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:55:26 --> Database Driver Class Initialized
INFO - 2023-06-27 11:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:55:26 --> Parser Class Initialized
INFO - 2023-06-27 11:55:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:55:26 --> Pagination Class Initialized
INFO - 2023-06-27 11:55:26 --> Form Validation Class Initialized
INFO - 2023-06-27 11:55:26 --> Controller Class Initialized
INFO - 2023-06-27 11:55:26 --> Model Class Initialized
DEBUG - 2023-06-27 11:55:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:55:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:55:26 --> Model Class Initialized
DEBUG - 2023-06-27 11:55:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:55:26 --> Model Class Initialized
INFO - 2023-06-27 11:55:26 --> Final output sent to browser
DEBUG - 2023-06-27 11:55:26 --> Total execution time: 0.0454
ERROR - 2023-06-27 11:55:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:55:29 --> Config Class Initialized
INFO - 2023-06-27 11:55:29 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:55:29 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:55:29 --> Utf8 Class Initialized
INFO - 2023-06-27 11:55:29 --> URI Class Initialized
INFO - 2023-06-27 11:55:29 --> Router Class Initialized
INFO - 2023-06-27 11:55:29 --> Output Class Initialized
INFO - 2023-06-27 11:55:29 --> Security Class Initialized
DEBUG - 2023-06-27 11:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:55:29 --> Input Class Initialized
INFO - 2023-06-27 11:55:29 --> Language Class Initialized
INFO - 2023-06-27 11:55:29 --> Loader Class Initialized
INFO - 2023-06-27 11:55:29 --> Helper loaded: url_helper
INFO - 2023-06-27 11:55:29 --> Helper loaded: file_helper
INFO - 2023-06-27 11:55:29 --> Helper loaded: html_helper
INFO - 2023-06-27 11:55:29 --> Helper loaded: text_helper
INFO - 2023-06-27 11:55:29 --> Helper loaded: form_helper
INFO - 2023-06-27 11:55:29 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:55:29 --> Helper loaded: security_helper
INFO - 2023-06-27 11:55:29 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:55:29 --> Database Driver Class Initialized
INFO - 2023-06-27 11:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:55:29 --> Parser Class Initialized
INFO - 2023-06-27 11:55:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:55:29 --> Pagination Class Initialized
INFO - 2023-06-27 11:55:29 --> Form Validation Class Initialized
INFO - 2023-06-27 11:55:29 --> Controller Class Initialized
INFO - 2023-06-27 11:55:29 --> Model Class Initialized
DEBUG - 2023-06-27 11:55:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:55:29 --> Model Class Initialized
DEBUG - 2023-06-27 11:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:55:29 --> Model Class Initialized
INFO - 2023-06-27 11:55:29 --> Final output sent to browser
DEBUG - 2023-06-27 11:55:29 --> Total execution time: 0.0496
ERROR - 2023-06-27 11:55:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:55:30 --> Config Class Initialized
INFO - 2023-06-27 11:55:30 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:55:30 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:55:30 --> Utf8 Class Initialized
INFO - 2023-06-27 11:55:30 --> URI Class Initialized
INFO - 2023-06-27 11:55:30 --> Router Class Initialized
INFO - 2023-06-27 11:55:30 --> Output Class Initialized
INFO - 2023-06-27 11:55:30 --> Security Class Initialized
DEBUG - 2023-06-27 11:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:55:30 --> Input Class Initialized
INFO - 2023-06-27 11:55:30 --> Language Class Initialized
INFO - 2023-06-27 11:55:30 --> Loader Class Initialized
INFO - 2023-06-27 11:55:30 --> Helper loaded: url_helper
INFO - 2023-06-27 11:55:30 --> Helper loaded: file_helper
INFO - 2023-06-27 11:55:30 --> Helper loaded: html_helper
INFO - 2023-06-27 11:55:30 --> Helper loaded: text_helper
INFO - 2023-06-27 11:55:30 --> Helper loaded: form_helper
INFO - 2023-06-27 11:55:30 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:55:30 --> Helper loaded: security_helper
INFO - 2023-06-27 11:55:30 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:55:30 --> Database Driver Class Initialized
INFO - 2023-06-27 11:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:55:30 --> Parser Class Initialized
INFO - 2023-06-27 11:55:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:55:30 --> Pagination Class Initialized
INFO - 2023-06-27 11:55:30 --> Form Validation Class Initialized
INFO - 2023-06-27 11:55:30 --> Controller Class Initialized
INFO - 2023-06-27 11:55:30 --> Model Class Initialized
DEBUG - 2023-06-27 11:55:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:55:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:55:30 --> Model Class Initialized
DEBUG - 2023-06-27 11:55:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:55:30 --> Model Class Initialized
INFO - 2023-06-27 11:55:30 --> Final output sent to browser
DEBUG - 2023-06-27 11:55:30 --> Total execution time: 0.0220
ERROR - 2023-06-27 11:55:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:55:30 --> Config Class Initialized
INFO - 2023-06-27 11:55:30 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:55:30 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:55:30 --> Utf8 Class Initialized
INFO - 2023-06-27 11:55:30 --> URI Class Initialized
INFO - 2023-06-27 11:55:30 --> Router Class Initialized
INFO - 2023-06-27 11:55:30 --> Output Class Initialized
INFO - 2023-06-27 11:55:30 --> Security Class Initialized
DEBUG - 2023-06-27 11:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:55:30 --> Input Class Initialized
INFO - 2023-06-27 11:55:30 --> Language Class Initialized
INFO - 2023-06-27 11:55:30 --> Loader Class Initialized
INFO - 2023-06-27 11:55:30 --> Helper loaded: url_helper
INFO - 2023-06-27 11:55:30 --> Helper loaded: file_helper
INFO - 2023-06-27 11:55:30 --> Helper loaded: html_helper
INFO - 2023-06-27 11:55:30 --> Helper loaded: text_helper
INFO - 2023-06-27 11:55:30 --> Helper loaded: form_helper
INFO - 2023-06-27 11:55:30 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:55:30 --> Helper loaded: security_helper
INFO - 2023-06-27 11:55:30 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:55:30 --> Database Driver Class Initialized
INFO - 2023-06-27 11:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:55:30 --> Parser Class Initialized
INFO - 2023-06-27 11:55:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:55:30 --> Pagination Class Initialized
INFO - 2023-06-27 11:55:30 --> Form Validation Class Initialized
INFO - 2023-06-27 11:55:30 --> Controller Class Initialized
INFO - 2023-06-27 11:55:30 --> Model Class Initialized
DEBUG - 2023-06-27 11:55:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:55:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:55:30 --> Model Class Initialized
DEBUG - 2023-06-27 11:55:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:55:30 --> Model Class Initialized
INFO - 2023-06-27 11:55:30 --> Final output sent to browser
DEBUG - 2023-06-27 11:55:30 --> Total execution time: 0.0216
ERROR - 2023-06-27 11:55:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:55:31 --> Config Class Initialized
INFO - 2023-06-27 11:55:31 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:55:31 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:55:31 --> Utf8 Class Initialized
INFO - 2023-06-27 11:55:31 --> URI Class Initialized
INFO - 2023-06-27 11:55:31 --> Router Class Initialized
INFO - 2023-06-27 11:55:31 --> Output Class Initialized
INFO - 2023-06-27 11:55:31 --> Security Class Initialized
DEBUG - 2023-06-27 11:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:55:31 --> Input Class Initialized
INFO - 2023-06-27 11:55:31 --> Language Class Initialized
INFO - 2023-06-27 11:55:31 --> Loader Class Initialized
INFO - 2023-06-27 11:55:31 --> Helper loaded: url_helper
INFO - 2023-06-27 11:55:31 --> Helper loaded: file_helper
INFO - 2023-06-27 11:55:31 --> Helper loaded: html_helper
INFO - 2023-06-27 11:55:31 --> Helper loaded: text_helper
INFO - 2023-06-27 11:55:31 --> Helper loaded: form_helper
INFO - 2023-06-27 11:55:31 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:55:31 --> Helper loaded: security_helper
INFO - 2023-06-27 11:55:31 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:55:31 --> Database Driver Class Initialized
INFO - 2023-06-27 11:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:55:31 --> Parser Class Initialized
INFO - 2023-06-27 11:55:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:55:31 --> Pagination Class Initialized
INFO - 2023-06-27 11:55:31 --> Form Validation Class Initialized
INFO - 2023-06-27 11:55:31 --> Controller Class Initialized
INFO - 2023-06-27 11:55:31 --> Model Class Initialized
DEBUG - 2023-06-27 11:55:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:55:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:55:31 --> Model Class Initialized
DEBUG - 2023-06-27 11:55:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:55:31 --> Model Class Initialized
INFO - 2023-06-27 11:55:31 --> Final output sent to browser
DEBUG - 2023-06-27 11:55:31 --> Total execution time: 0.0205
ERROR - 2023-06-27 11:55:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:55:33 --> Config Class Initialized
INFO - 2023-06-27 11:55:33 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:55:33 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:55:33 --> Utf8 Class Initialized
INFO - 2023-06-27 11:55:33 --> URI Class Initialized
INFO - 2023-06-27 11:55:33 --> Router Class Initialized
INFO - 2023-06-27 11:55:33 --> Output Class Initialized
INFO - 2023-06-27 11:55:33 --> Security Class Initialized
DEBUG - 2023-06-27 11:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:55:33 --> Input Class Initialized
INFO - 2023-06-27 11:55:33 --> Language Class Initialized
INFO - 2023-06-27 11:55:33 --> Loader Class Initialized
INFO - 2023-06-27 11:55:33 --> Helper loaded: url_helper
INFO - 2023-06-27 11:55:33 --> Helper loaded: file_helper
INFO - 2023-06-27 11:55:33 --> Helper loaded: html_helper
INFO - 2023-06-27 11:55:33 --> Helper loaded: text_helper
INFO - 2023-06-27 11:55:33 --> Helper loaded: form_helper
INFO - 2023-06-27 11:55:33 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:55:33 --> Helper loaded: security_helper
INFO - 2023-06-27 11:55:33 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:55:33 --> Database Driver Class Initialized
INFO - 2023-06-27 11:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:55:33 --> Parser Class Initialized
INFO - 2023-06-27 11:55:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:55:33 --> Pagination Class Initialized
INFO - 2023-06-27 11:55:33 --> Form Validation Class Initialized
INFO - 2023-06-27 11:55:33 --> Controller Class Initialized
INFO - 2023-06-27 11:55:33 --> Model Class Initialized
DEBUG - 2023-06-27 11:55:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:55:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:55:33 --> Model Class Initialized
INFO - 2023-06-27 11:55:33 --> Model Class Initialized
INFO - 2023-06-27 11:55:33 --> Final output sent to browser
DEBUG - 2023-06-27 11:55:33 --> Total execution time: 0.0211
ERROR - 2023-06-27 11:55:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:55:36 --> Config Class Initialized
INFO - 2023-06-27 11:55:36 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:55:36 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:55:36 --> Utf8 Class Initialized
INFO - 2023-06-27 11:55:36 --> URI Class Initialized
INFO - 2023-06-27 11:55:36 --> Router Class Initialized
INFO - 2023-06-27 11:55:36 --> Output Class Initialized
INFO - 2023-06-27 11:55:36 --> Security Class Initialized
DEBUG - 2023-06-27 11:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:55:36 --> Input Class Initialized
INFO - 2023-06-27 11:55:36 --> Language Class Initialized
INFO - 2023-06-27 11:55:36 --> Loader Class Initialized
INFO - 2023-06-27 11:55:36 --> Helper loaded: url_helper
INFO - 2023-06-27 11:55:36 --> Helper loaded: file_helper
INFO - 2023-06-27 11:55:36 --> Helper loaded: html_helper
INFO - 2023-06-27 11:55:36 --> Helper loaded: text_helper
INFO - 2023-06-27 11:55:36 --> Helper loaded: form_helper
INFO - 2023-06-27 11:55:36 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:55:36 --> Helper loaded: security_helper
INFO - 2023-06-27 11:55:36 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:55:36 --> Database Driver Class Initialized
INFO - 2023-06-27 11:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:55:36 --> Parser Class Initialized
INFO - 2023-06-27 11:55:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:55:36 --> Pagination Class Initialized
INFO - 2023-06-27 11:55:36 --> Form Validation Class Initialized
INFO - 2023-06-27 11:55:36 --> Controller Class Initialized
INFO - 2023-06-27 11:55:36 --> Model Class Initialized
DEBUG - 2023-06-27 11:55:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:55:36 --> Model Class Initialized
INFO - 2023-06-27 11:55:36 --> Final output sent to browser
DEBUG - 2023-06-27 11:55:36 --> Total execution time: 0.0190
ERROR - 2023-06-27 11:55:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:55:58 --> Config Class Initialized
INFO - 2023-06-27 11:55:58 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:55:58 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:55:58 --> Utf8 Class Initialized
INFO - 2023-06-27 11:55:58 --> URI Class Initialized
INFO - 2023-06-27 11:55:58 --> Router Class Initialized
INFO - 2023-06-27 11:55:58 --> Output Class Initialized
INFO - 2023-06-27 11:55:58 --> Security Class Initialized
DEBUG - 2023-06-27 11:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:55:58 --> Input Class Initialized
INFO - 2023-06-27 11:55:58 --> Language Class Initialized
INFO - 2023-06-27 11:55:58 --> Loader Class Initialized
INFO - 2023-06-27 11:55:58 --> Helper loaded: url_helper
INFO - 2023-06-27 11:55:58 --> Helper loaded: file_helper
INFO - 2023-06-27 11:55:58 --> Helper loaded: html_helper
INFO - 2023-06-27 11:55:58 --> Helper loaded: text_helper
INFO - 2023-06-27 11:55:58 --> Helper loaded: form_helper
INFO - 2023-06-27 11:55:58 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:55:58 --> Helper loaded: security_helper
INFO - 2023-06-27 11:55:58 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:55:58 --> Database Driver Class Initialized
INFO - 2023-06-27 11:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:55:58 --> Parser Class Initialized
INFO - 2023-06-27 11:55:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:55:58 --> Pagination Class Initialized
INFO - 2023-06-27 11:55:58 --> Form Validation Class Initialized
INFO - 2023-06-27 11:55:58 --> Controller Class Initialized
INFO - 2023-06-27 11:55:59 --> Model Class Initialized
DEBUG - 2023-06-27 11:55:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:55:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:55:59 --> Model Class Initialized
DEBUG - 2023-06-27 11:55:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:55:59 --> Model Class Initialized
INFO - 2023-06-27 11:55:59 --> Email Class Initialized
DEBUG - 2023-06-27 11:55:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:55:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-06-27 11:55:59 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-06-27 11:55:59 --> Language file loaded: language/english/email_lang.php
INFO - 2023-06-27 11:55:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2023-06-27 11:55:59 --> Final output sent to browser
DEBUG - 2023-06-27 11:55:59 --> Total execution time: 0.5155
ERROR - 2023-06-27 11:56:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:56:02 --> Config Class Initialized
INFO - 2023-06-27 11:56:02 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:56:02 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:56:02 --> Utf8 Class Initialized
INFO - 2023-06-27 11:56:02 --> URI Class Initialized
INFO - 2023-06-27 11:56:02 --> Router Class Initialized
INFO - 2023-06-27 11:56:02 --> Output Class Initialized
INFO - 2023-06-27 11:56:02 --> Security Class Initialized
DEBUG - 2023-06-27 11:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:56:02 --> Input Class Initialized
INFO - 2023-06-27 11:56:02 --> Language Class Initialized
INFO - 2023-06-27 11:56:02 --> Loader Class Initialized
INFO - 2023-06-27 11:56:02 --> Helper loaded: url_helper
INFO - 2023-06-27 11:56:02 --> Helper loaded: file_helper
INFO - 2023-06-27 11:56:02 --> Helper loaded: html_helper
INFO - 2023-06-27 11:56:02 --> Helper loaded: text_helper
INFO - 2023-06-27 11:56:02 --> Helper loaded: form_helper
INFO - 2023-06-27 11:56:02 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:56:02 --> Helper loaded: security_helper
INFO - 2023-06-27 11:56:02 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:56:02 --> Database Driver Class Initialized
INFO - 2023-06-27 11:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:56:02 --> Parser Class Initialized
INFO - 2023-06-27 11:56:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:56:02 --> Pagination Class Initialized
INFO - 2023-06-27 11:56:02 --> Form Validation Class Initialized
INFO - 2023-06-27 11:56:02 --> Controller Class Initialized
INFO - 2023-06-27 11:56:02 --> Model Class Initialized
DEBUG - 2023-06-27 11:56:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:56:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:56:02 --> Model Class Initialized
DEBUG - 2023-06-27 11:56:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:56:02 --> Model Class Initialized
INFO - 2023-06-27 11:56:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-06-27 11:56:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:56:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 11:56:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 11:56:02 --> Model Class Initialized
INFO - 2023-06-27 11:56:02 --> Model Class Initialized
INFO - 2023-06-27 11:56:02 --> Model Class Initialized
INFO - 2023-06-27 11:56:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 11:56:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 11:56:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 11:56:02 --> Final output sent to browser
DEBUG - 2023-06-27 11:56:02 --> Total execution time: 0.1112
ERROR - 2023-06-27 11:56:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:56:05 --> Config Class Initialized
INFO - 2023-06-27 11:56:05 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:56:05 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:56:05 --> Utf8 Class Initialized
INFO - 2023-06-27 11:56:05 --> URI Class Initialized
DEBUG - 2023-06-27 11:56:05 --> No URI present. Default controller set.
INFO - 2023-06-27 11:56:05 --> Router Class Initialized
INFO - 2023-06-27 11:56:05 --> Output Class Initialized
INFO - 2023-06-27 11:56:05 --> Security Class Initialized
DEBUG - 2023-06-27 11:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:56:05 --> Input Class Initialized
INFO - 2023-06-27 11:56:05 --> Language Class Initialized
INFO - 2023-06-27 11:56:05 --> Loader Class Initialized
INFO - 2023-06-27 11:56:05 --> Helper loaded: url_helper
INFO - 2023-06-27 11:56:05 --> Helper loaded: file_helper
INFO - 2023-06-27 11:56:05 --> Helper loaded: html_helper
INFO - 2023-06-27 11:56:05 --> Helper loaded: text_helper
INFO - 2023-06-27 11:56:05 --> Helper loaded: form_helper
INFO - 2023-06-27 11:56:05 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:56:05 --> Helper loaded: security_helper
INFO - 2023-06-27 11:56:05 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:56:05 --> Database Driver Class Initialized
INFO - 2023-06-27 11:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:56:05 --> Parser Class Initialized
INFO - 2023-06-27 11:56:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:56:05 --> Pagination Class Initialized
INFO - 2023-06-27 11:56:05 --> Form Validation Class Initialized
INFO - 2023-06-27 11:56:05 --> Controller Class Initialized
INFO - 2023-06-27 11:56:05 --> Model Class Initialized
DEBUG - 2023-06-27 11:56:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:56:05 --> Model Class Initialized
DEBUG - 2023-06-27 11:56:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:56:05 --> Model Class Initialized
INFO - 2023-06-27 11:56:05 --> Model Class Initialized
INFO - 2023-06-27 11:56:05 --> Model Class Initialized
INFO - 2023-06-27 11:56:05 --> Model Class Initialized
DEBUG - 2023-06-27 11:56:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:56:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:56:05 --> Model Class Initialized
INFO - 2023-06-27 11:56:05 --> Model Class Initialized
INFO - 2023-06-27 11:56:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 11:56:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:56:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 11:56:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 11:56:05 --> Model Class Initialized
INFO - 2023-06-27 11:56:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 11:56:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 11:56:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 11:56:05 --> Final output sent to browser
DEBUG - 2023-06-27 11:56:05 --> Total execution time: 0.0924
ERROR - 2023-06-27 11:56:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:56:11 --> Config Class Initialized
INFO - 2023-06-27 11:56:11 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:56:11 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:56:11 --> Utf8 Class Initialized
INFO - 2023-06-27 11:56:11 --> URI Class Initialized
INFO - 2023-06-27 11:56:11 --> Router Class Initialized
INFO - 2023-06-27 11:56:11 --> Output Class Initialized
INFO - 2023-06-27 11:56:11 --> Security Class Initialized
DEBUG - 2023-06-27 11:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:56:11 --> Input Class Initialized
INFO - 2023-06-27 11:56:11 --> Language Class Initialized
INFO - 2023-06-27 11:56:11 --> Loader Class Initialized
INFO - 2023-06-27 11:56:11 --> Helper loaded: url_helper
INFO - 2023-06-27 11:56:11 --> Helper loaded: file_helper
INFO - 2023-06-27 11:56:11 --> Helper loaded: html_helper
INFO - 2023-06-27 11:56:11 --> Helper loaded: text_helper
INFO - 2023-06-27 11:56:11 --> Helper loaded: form_helper
INFO - 2023-06-27 11:56:11 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:56:11 --> Helper loaded: security_helper
INFO - 2023-06-27 11:56:11 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:56:11 --> Database Driver Class Initialized
INFO - 2023-06-27 11:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:56:11 --> Parser Class Initialized
INFO - 2023-06-27 11:56:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:56:11 --> Pagination Class Initialized
INFO - 2023-06-27 11:56:11 --> Form Validation Class Initialized
INFO - 2023-06-27 11:56:11 --> Controller Class Initialized
INFO - 2023-06-27 11:56:11 --> Model Class Initialized
DEBUG - 2023-06-27 11:56:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:56:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:56:11 --> Model Class Initialized
DEBUG - 2023-06-27 11:56:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:56:11 --> Model Class Initialized
INFO - 2023-06-27 11:56:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-27 11:56:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:56:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 11:56:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 11:56:11 --> Model Class Initialized
INFO - 2023-06-27 11:56:11 --> Model Class Initialized
INFO - 2023-06-27 11:56:11 --> Model Class Initialized
INFO - 2023-06-27 11:56:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 11:56:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 11:56:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 11:56:11 --> Final output sent to browser
DEBUG - 2023-06-27 11:56:11 --> Total execution time: 0.0861
ERROR - 2023-06-27 11:56:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 11:56:12 --> Config Class Initialized
INFO - 2023-06-27 11:56:12 --> Hooks Class Initialized
DEBUG - 2023-06-27 11:56:12 --> UTF-8 Support Enabled
INFO - 2023-06-27 11:56:12 --> Utf8 Class Initialized
INFO - 2023-06-27 11:56:12 --> URI Class Initialized
INFO - 2023-06-27 11:56:12 --> Router Class Initialized
INFO - 2023-06-27 11:56:12 --> Output Class Initialized
INFO - 2023-06-27 11:56:12 --> Security Class Initialized
DEBUG - 2023-06-27 11:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 11:56:12 --> Input Class Initialized
INFO - 2023-06-27 11:56:12 --> Language Class Initialized
INFO - 2023-06-27 11:56:12 --> Loader Class Initialized
INFO - 2023-06-27 11:56:12 --> Helper loaded: url_helper
INFO - 2023-06-27 11:56:12 --> Helper loaded: file_helper
INFO - 2023-06-27 11:56:12 --> Helper loaded: html_helper
INFO - 2023-06-27 11:56:12 --> Helper loaded: text_helper
INFO - 2023-06-27 11:56:12 --> Helper loaded: form_helper
INFO - 2023-06-27 11:56:12 --> Helper loaded: lang_helper
INFO - 2023-06-27 11:56:12 --> Helper loaded: security_helper
INFO - 2023-06-27 11:56:12 --> Helper loaded: cookie_helper
INFO - 2023-06-27 11:56:12 --> Database Driver Class Initialized
INFO - 2023-06-27 11:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 11:56:12 --> Parser Class Initialized
INFO - 2023-06-27 11:56:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 11:56:12 --> Pagination Class Initialized
INFO - 2023-06-27 11:56:12 --> Form Validation Class Initialized
INFO - 2023-06-27 11:56:12 --> Controller Class Initialized
INFO - 2023-06-27 11:56:12 --> Model Class Initialized
DEBUG - 2023-06-27 11:56:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 11:56:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:56:12 --> Model Class Initialized
DEBUG - 2023-06-27 11:56:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 11:56:12 --> Model Class Initialized
INFO - 2023-06-27 11:56:12 --> Final output sent to browser
DEBUG - 2023-06-27 11:56:12 --> Total execution time: 0.0437
ERROR - 2023-06-27 12:17:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 12:17:45 --> Config Class Initialized
INFO - 2023-06-27 12:17:45 --> Hooks Class Initialized
DEBUG - 2023-06-27 12:17:45 --> UTF-8 Support Enabled
INFO - 2023-06-27 12:17:45 --> Utf8 Class Initialized
INFO - 2023-06-27 12:17:45 --> URI Class Initialized
INFO - 2023-06-27 12:17:45 --> Router Class Initialized
INFO - 2023-06-27 12:17:45 --> Output Class Initialized
INFO - 2023-06-27 12:17:45 --> Security Class Initialized
DEBUG - 2023-06-27 12:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 12:17:45 --> Input Class Initialized
INFO - 2023-06-27 12:17:45 --> Language Class Initialized
INFO - 2023-06-27 12:17:45 --> Loader Class Initialized
INFO - 2023-06-27 12:17:45 --> Helper loaded: url_helper
INFO - 2023-06-27 12:17:45 --> Helper loaded: file_helper
INFO - 2023-06-27 12:17:45 --> Helper loaded: html_helper
INFO - 2023-06-27 12:17:45 --> Helper loaded: text_helper
INFO - 2023-06-27 12:17:45 --> Helper loaded: form_helper
INFO - 2023-06-27 12:17:45 --> Helper loaded: lang_helper
INFO - 2023-06-27 12:17:45 --> Helper loaded: security_helper
INFO - 2023-06-27 12:17:45 --> Helper loaded: cookie_helper
INFO - 2023-06-27 12:17:45 --> Database Driver Class Initialized
INFO - 2023-06-27 12:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 12:17:45 --> Parser Class Initialized
INFO - 2023-06-27 12:17:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 12:17:45 --> Pagination Class Initialized
INFO - 2023-06-27 12:17:45 --> Form Validation Class Initialized
INFO - 2023-06-27 12:17:45 --> Controller Class Initialized
INFO - 2023-06-27 12:17:45 --> Model Class Initialized
DEBUG - 2023-06-27 12:17:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 12:17:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 12:17:45 --> Model Class Initialized
DEBUG - 2023-06-27 12:17:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 12:17:45 --> Model Class Initialized
INFO - 2023-06-27 12:17:45 --> Final output sent to browser
DEBUG - 2023-06-27 12:17:45 --> Total execution time: 0.0451
ERROR - 2023-06-27 12:17:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 12:17:57 --> Config Class Initialized
INFO - 2023-06-27 12:17:57 --> Hooks Class Initialized
DEBUG - 2023-06-27 12:17:57 --> UTF-8 Support Enabled
INFO - 2023-06-27 12:17:57 --> Utf8 Class Initialized
INFO - 2023-06-27 12:17:57 --> URI Class Initialized
INFO - 2023-06-27 12:17:57 --> Router Class Initialized
INFO - 2023-06-27 12:17:57 --> Output Class Initialized
INFO - 2023-06-27 12:17:57 --> Security Class Initialized
DEBUG - 2023-06-27 12:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 12:17:57 --> Input Class Initialized
INFO - 2023-06-27 12:17:57 --> Language Class Initialized
INFO - 2023-06-27 12:17:57 --> Loader Class Initialized
INFO - 2023-06-27 12:17:57 --> Helper loaded: url_helper
INFO - 2023-06-27 12:17:57 --> Helper loaded: file_helper
INFO - 2023-06-27 12:17:57 --> Helper loaded: html_helper
INFO - 2023-06-27 12:17:57 --> Helper loaded: text_helper
INFO - 2023-06-27 12:17:57 --> Helper loaded: form_helper
INFO - 2023-06-27 12:17:57 --> Helper loaded: lang_helper
INFO - 2023-06-27 12:17:57 --> Helper loaded: security_helper
INFO - 2023-06-27 12:17:57 --> Helper loaded: cookie_helper
INFO - 2023-06-27 12:17:57 --> Database Driver Class Initialized
INFO - 2023-06-27 12:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 12:17:57 --> Parser Class Initialized
INFO - 2023-06-27 12:17:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 12:17:57 --> Pagination Class Initialized
INFO - 2023-06-27 12:17:57 --> Form Validation Class Initialized
INFO - 2023-06-27 12:17:57 --> Controller Class Initialized
INFO - 2023-06-27 12:17:57 --> Model Class Initialized
DEBUG - 2023-06-27 12:17:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 12:17:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 12:17:57 --> Model Class Initialized
DEBUG - 2023-06-27 12:17:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 12:17:57 --> Model Class Initialized
INFO - 2023-06-27 12:17:57 --> Final output sent to browser
DEBUG - 2023-06-27 12:17:57 --> Total execution time: 0.0873
ERROR - 2023-06-27 12:18:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 12:18:06 --> Config Class Initialized
INFO - 2023-06-27 12:18:06 --> Hooks Class Initialized
DEBUG - 2023-06-27 12:18:06 --> UTF-8 Support Enabled
INFO - 2023-06-27 12:18:06 --> Utf8 Class Initialized
INFO - 2023-06-27 12:18:06 --> URI Class Initialized
INFO - 2023-06-27 12:18:06 --> Router Class Initialized
INFO - 2023-06-27 12:18:06 --> Output Class Initialized
INFO - 2023-06-27 12:18:06 --> Security Class Initialized
DEBUG - 2023-06-27 12:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 12:18:06 --> Input Class Initialized
INFO - 2023-06-27 12:18:06 --> Language Class Initialized
INFO - 2023-06-27 12:18:06 --> Loader Class Initialized
INFO - 2023-06-27 12:18:06 --> Helper loaded: url_helper
INFO - 2023-06-27 12:18:06 --> Helper loaded: file_helper
INFO - 2023-06-27 12:18:06 --> Helper loaded: html_helper
INFO - 2023-06-27 12:18:06 --> Helper loaded: text_helper
INFO - 2023-06-27 12:18:06 --> Helper loaded: form_helper
INFO - 2023-06-27 12:18:06 --> Helper loaded: lang_helper
INFO - 2023-06-27 12:18:06 --> Helper loaded: security_helper
INFO - 2023-06-27 12:18:06 --> Helper loaded: cookie_helper
INFO - 2023-06-27 12:18:06 --> Database Driver Class Initialized
INFO - 2023-06-27 12:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 12:18:06 --> Parser Class Initialized
INFO - 2023-06-27 12:18:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 12:18:06 --> Pagination Class Initialized
INFO - 2023-06-27 12:18:06 --> Form Validation Class Initialized
INFO - 2023-06-27 12:18:06 --> Controller Class Initialized
INFO - 2023-06-27 12:18:06 --> Model Class Initialized
DEBUG - 2023-06-27 12:18:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 12:18:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 12:18:06 --> Model Class Initialized
DEBUG - 2023-06-27 12:18:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 12:18:06 --> Model Class Initialized
INFO - 2023-06-27 12:18:06 --> Final output sent to browser
DEBUG - 2023-06-27 12:18:06 --> Total execution time: 0.0683
ERROR - 2023-06-27 12:18:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 12:18:17 --> Config Class Initialized
INFO - 2023-06-27 12:18:17 --> Hooks Class Initialized
DEBUG - 2023-06-27 12:18:17 --> UTF-8 Support Enabled
INFO - 2023-06-27 12:18:17 --> Utf8 Class Initialized
INFO - 2023-06-27 12:18:17 --> URI Class Initialized
INFO - 2023-06-27 12:18:17 --> Router Class Initialized
INFO - 2023-06-27 12:18:17 --> Output Class Initialized
INFO - 2023-06-27 12:18:17 --> Security Class Initialized
DEBUG - 2023-06-27 12:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 12:18:17 --> Input Class Initialized
INFO - 2023-06-27 12:18:17 --> Language Class Initialized
INFO - 2023-06-27 12:18:17 --> Loader Class Initialized
INFO - 2023-06-27 12:18:17 --> Helper loaded: url_helper
INFO - 2023-06-27 12:18:17 --> Helper loaded: file_helper
INFO - 2023-06-27 12:18:17 --> Helper loaded: html_helper
INFO - 2023-06-27 12:18:17 --> Helper loaded: text_helper
INFO - 2023-06-27 12:18:17 --> Helper loaded: form_helper
INFO - 2023-06-27 12:18:17 --> Helper loaded: lang_helper
INFO - 2023-06-27 12:18:17 --> Helper loaded: security_helper
INFO - 2023-06-27 12:18:17 --> Helper loaded: cookie_helper
INFO - 2023-06-27 12:18:17 --> Database Driver Class Initialized
INFO - 2023-06-27 12:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 12:18:17 --> Parser Class Initialized
INFO - 2023-06-27 12:18:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 12:18:17 --> Pagination Class Initialized
INFO - 2023-06-27 12:18:17 --> Form Validation Class Initialized
INFO - 2023-06-27 12:18:17 --> Controller Class Initialized
INFO - 2023-06-27 12:18:17 --> Model Class Initialized
DEBUG - 2023-06-27 12:18:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 12:18:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 12:18:17 --> Model Class Initialized
DEBUG - 2023-06-27 12:18:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 12:18:17 --> Model Class Initialized
INFO - 2023-06-27 12:18:17 --> Final output sent to browser
DEBUG - 2023-06-27 12:18:17 --> Total execution time: 0.0742
ERROR - 2023-06-27 12:25:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 12:25:05 --> Config Class Initialized
INFO - 2023-06-27 12:25:05 --> Hooks Class Initialized
DEBUG - 2023-06-27 12:25:05 --> UTF-8 Support Enabled
INFO - 2023-06-27 12:25:05 --> Utf8 Class Initialized
INFO - 2023-06-27 12:25:05 --> URI Class Initialized
INFO - 2023-06-27 12:25:05 --> Router Class Initialized
INFO - 2023-06-27 12:25:05 --> Output Class Initialized
INFO - 2023-06-27 12:25:05 --> Security Class Initialized
DEBUG - 2023-06-27 12:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 12:25:05 --> Input Class Initialized
INFO - 2023-06-27 12:25:05 --> Language Class Initialized
INFO - 2023-06-27 12:25:05 --> Loader Class Initialized
INFO - 2023-06-27 12:25:05 --> Helper loaded: url_helper
INFO - 2023-06-27 12:25:05 --> Helper loaded: file_helper
INFO - 2023-06-27 12:25:05 --> Helper loaded: html_helper
INFO - 2023-06-27 12:25:05 --> Helper loaded: text_helper
INFO - 2023-06-27 12:25:05 --> Helper loaded: form_helper
INFO - 2023-06-27 12:25:05 --> Helper loaded: lang_helper
INFO - 2023-06-27 12:25:05 --> Helper loaded: security_helper
INFO - 2023-06-27 12:25:05 --> Helper loaded: cookie_helper
INFO - 2023-06-27 12:25:05 --> Database Driver Class Initialized
INFO - 2023-06-27 12:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 12:25:05 --> Parser Class Initialized
INFO - 2023-06-27 12:25:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 12:25:05 --> Pagination Class Initialized
INFO - 2023-06-27 12:25:05 --> Form Validation Class Initialized
INFO - 2023-06-27 12:25:05 --> Controller Class Initialized
INFO - 2023-06-27 12:25:05 --> Model Class Initialized
DEBUG - 2023-06-27 12:25:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 12:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 12:25:05 --> Model Class Initialized
DEBUG - 2023-06-27 12:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 12:25:05 --> Model Class Initialized
DEBUG - 2023-06-27 12:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 12:25:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-06-27 12:25:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 12:25:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 12:25:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 12:25:05 --> Model Class Initialized
INFO - 2023-06-27 12:25:05 --> Model Class Initialized
INFO - 2023-06-27 12:25:05 --> Model Class Initialized
INFO - 2023-06-27 12:25:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 12:25:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 12:25:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 12:25:05 --> Final output sent to browser
DEBUG - 2023-06-27 12:25:05 --> Total execution time: 0.0897
ERROR - 2023-06-27 16:11:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 16:11:29 --> Config Class Initialized
INFO - 2023-06-27 16:11:29 --> Hooks Class Initialized
DEBUG - 2023-06-27 16:11:29 --> UTF-8 Support Enabled
INFO - 2023-06-27 16:11:29 --> Utf8 Class Initialized
INFO - 2023-06-27 16:11:29 --> URI Class Initialized
DEBUG - 2023-06-27 16:11:29 --> No URI present. Default controller set.
INFO - 2023-06-27 16:11:29 --> Router Class Initialized
INFO - 2023-06-27 16:11:29 --> Output Class Initialized
INFO - 2023-06-27 16:11:29 --> Security Class Initialized
DEBUG - 2023-06-27 16:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 16:11:29 --> Input Class Initialized
INFO - 2023-06-27 16:11:29 --> Language Class Initialized
INFO - 2023-06-27 16:11:29 --> Loader Class Initialized
INFO - 2023-06-27 16:11:29 --> Helper loaded: url_helper
INFO - 2023-06-27 16:11:29 --> Helper loaded: file_helper
INFO - 2023-06-27 16:11:29 --> Helper loaded: html_helper
INFO - 2023-06-27 16:11:29 --> Helper loaded: text_helper
INFO - 2023-06-27 16:11:29 --> Helper loaded: form_helper
INFO - 2023-06-27 16:11:29 --> Helper loaded: lang_helper
INFO - 2023-06-27 16:11:29 --> Helper loaded: security_helper
INFO - 2023-06-27 16:11:29 --> Helper loaded: cookie_helper
INFO - 2023-06-27 16:11:29 --> Database Driver Class Initialized
INFO - 2023-06-27 16:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 16:11:29 --> Parser Class Initialized
INFO - 2023-06-27 16:11:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 16:11:29 --> Pagination Class Initialized
INFO - 2023-06-27 16:11:29 --> Form Validation Class Initialized
INFO - 2023-06-27 16:11:29 --> Controller Class Initialized
INFO - 2023-06-27 16:11:29 --> Model Class Initialized
DEBUG - 2023-06-27 16:11:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-27 16:11:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 16:11:29 --> Config Class Initialized
INFO - 2023-06-27 16:11:29 --> Hooks Class Initialized
DEBUG - 2023-06-27 16:11:29 --> UTF-8 Support Enabled
INFO - 2023-06-27 16:11:29 --> Utf8 Class Initialized
INFO - 2023-06-27 16:11:29 --> URI Class Initialized
INFO - 2023-06-27 16:11:29 --> Router Class Initialized
INFO - 2023-06-27 16:11:29 --> Output Class Initialized
INFO - 2023-06-27 16:11:29 --> Security Class Initialized
DEBUG - 2023-06-27 16:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 16:11:29 --> Input Class Initialized
INFO - 2023-06-27 16:11:29 --> Language Class Initialized
INFO - 2023-06-27 16:11:29 --> Loader Class Initialized
INFO - 2023-06-27 16:11:29 --> Helper loaded: url_helper
INFO - 2023-06-27 16:11:29 --> Helper loaded: file_helper
INFO - 2023-06-27 16:11:29 --> Helper loaded: html_helper
INFO - 2023-06-27 16:11:29 --> Helper loaded: text_helper
INFO - 2023-06-27 16:11:29 --> Helper loaded: form_helper
INFO - 2023-06-27 16:11:29 --> Helper loaded: lang_helper
INFO - 2023-06-27 16:11:29 --> Helper loaded: security_helper
INFO - 2023-06-27 16:11:29 --> Helper loaded: cookie_helper
INFO - 2023-06-27 16:11:29 --> Database Driver Class Initialized
INFO - 2023-06-27 16:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 16:11:29 --> Parser Class Initialized
INFO - 2023-06-27 16:11:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 16:11:29 --> Pagination Class Initialized
INFO - 2023-06-27 16:11:29 --> Form Validation Class Initialized
INFO - 2023-06-27 16:11:29 --> Controller Class Initialized
INFO - 2023-06-27 16:11:29 --> Model Class Initialized
DEBUG - 2023-06-27 16:11:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:11:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-27 16:11:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:11:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 16:11:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 16:11:29 --> Model Class Initialized
INFO - 2023-06-27 16:11:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 16:11:29 --> Final output sent to browser
DEBUG - 2023-06-27 16:11:29 --> Total execution time: 0.0368
ERROR - 2023-06-27 16:11:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 16:11:49 --> Config Class Initialized
INFO - 2023-06-27 16:11:49 --> Hooks Class Initialized
DEBUG - 2023-06-27 16:11:49 --> UTF-8 Support Enabled
INFO - 2023-06-27 16:11:49 --> Utf8 Class Initialized
INFO - 2023-06-27 16:11:49 --> URI Class Initialized
INFO - 2023-06-27 16:11:49 --> Router Class Initialized
INFO - 2023-06-27 16:11:49 --> Output Class Initialized
INFO - 2023-06-27 16:11:49 --> Security Class Initialized
DEBUG - 2023-06-27 16:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 16:11:49 --> Input Class Initialized
INFO - 2023-06-27 16:11:49 --> Language Class Initialized
INFO - 2023-06-27 16:11:49 --> Loader Class Initialized
INFO - 2023-06-27 16:11:49 --> Helper loaded: url_helper
INFO - 2023-06-27 16:11:49 --> Helper loaded: file_helper
INFO - 2023-06-27 16:11:49 --> Helper loaded: html_helper
INFO - 2023-06-27 16:11:49 --> Helper loaded: text_helper
INFO - 2023-06-27 16:11:49 --> Helper loaded: form_helper
INFO - 2023-06-27 16:11:49 --> Helper loaded: lang_helper
INFO - 2023-06-27 16:11:49 --> Helper loaded: security_helper
INFO - 2023-06-27 16:11:49 --> Helper loaded: cookie_helper
INFO - 2023-06-27 16:11:49 --> Database Driver Class Initialized
INFO - 2023-06-27 16:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 16:11:49 --> Parser Class Initialized
INFO - 2023-06-27 16:11:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 16:11:49 --> Pagination Class Initialized
INFO - 2023-06-27 16:11:49 --> Form Validation Class Initialized
INFO - 2023-06-27 16:11:49 --> Controller Class Initialized
INFO - 2023-06-27 16:11:49 --> Model Class Initialized
DEBUG - 2023-06-27 16:11:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:11:49 --> Model Class Initialized
INFO - 2023-06-27 16:11:49 --> Final output sent to browser
DEBUG - 2023-06-27 16:11:49 --> Total execution time: 0.0209
ERROR - 2023-06-27 16:11:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 16:11:49 --> Config Class Initialized
INFO - 2023-06-27 16:11:49 --> Hooks Class Initialized
DEBUG - 2023-06-27 16:11:49 --> UTF-8 Support Enabled
INFO - 2023-06-27 16:11:49 --> Utf8 Class Initialized
INFO - 2023-06-27 16:11:49 --> URI Class Initialized
DEBUG - 2023-06-27 16:11:49 --> No URI present. Default controller set.
INFO - 2023-06-27 16:11:49 --> Router Class Initialized
INFO - 2023-06-27 16:11:49 --> Output Class Initialized
INFO - 2023-06-27 16:11:49 --> Security Class Initialized
DEBUG - 2023-06-27 16:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 16:11:49 --> Input Class Initialized
INFO - 2023-06-27 16:11:49 --> Language Class Initialized
INFO - 2023-06-27 16:11:49 --> Loader Class Initialized
INFO - 2023-06-27 16:11:49 --> Helper loaded: url_helper
INFO - 2023-06-27 16:11:49 --> Helper loaded: file_helper
INFO - 2023-06-27 16:11:49 --> Helper loaded: html_helper
INFO - 2023-06-27 16:11:49 --> Helper loaded: text_helper
INFO - 2023-06-27 16:11:49 --> Helper loaded: form_helper
INFO - 2023-06-27 16:11:49 --> Helper loaded: lang_helper
INFO - 2023-06-27 16:11:49 --> Helper loaded: security_helper
INFO - 2023-06-27 16:11:49 --> Helper loaded: cookie_helper
INFO - 2023-06-27 16:11:49 --> Database Driver Class Initialized
INFO - 2023-06-27 16:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 16:11:49 --> Parser Class Initialized
INFO - 2023-06-27 16:11:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 16:11:49 --> Pagination Class Initialized
INFO - 2023-06-27 16:11:49 --> Form Validation Class Initialized
INFO - 2023-06-27 16:11:49 --> Controller Class Initialized
INFO - 2023-06-27 16:11:49 --> Model Class Initialized
DEBUG - 2023-06-27 16:11:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:11:49 --> Model Class Initialized
DEBUG - 2023-06-27 16:11:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:11:49 --> Model Class Initialized
INFO - 2023-06-27 16:11:49 --> Model Class Initialized
INFO - 2023-06-27 16:11:49 --> Model Class Initialized
INFO - 2023-06-27 16:11:49 --> Model Class Initialized
DEBUG - 2023-06-27 16:11:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 16:11:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:11:49 --> Model Class Initialized
INFO - 2023-06-27 16:11:49 --> Model Class Initialized
INFO - 2023-06-27 16:11:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 16:11:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:11:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 16:11:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 16:11:49 --> Model Class Initialized
INFO - 2023-06-27 16:11:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 16:11:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 16:11:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 16:11:49 --> Final output sent to browser
DEBUG - 2023-06-27 16:11:49 --> Total execution time: 0.0777
ERROR - 2023-06-27 16:12:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 16:12:19 --> Config Class Initialized
INFO - 2023-06-27 16:12:19 --> Hooks Class Initialized
DEBUG - 2023-06-27 16:12:19 --> UTF-8 Support Enabled
INFO - 2023-06-27 16:12:19 --> Utf8 Class Initialized
INFO - 2023-06-27 16:12:19 --> URI Class Initialized
INFO - 2023-06-27 16:12:19 --> Router Class Initialized
INFO - 2023-06-27 16:12:19 --> Output Class Initialized
INFO - 2023-06-27 16:12:19 --> Security Class Initialized
DEBUG - 2023-06-27 16:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 16:12:19 --> Input Class Initialized
INFO - 2023-06-27 16:12:19 --> Language Class Initialized
INFO - 2023-06-27 16:12:19 --> Loader Class Initialized
INFO - 2023-06-27 16:12:19 --> Helper loaded: url_helper
INFO - 2023-06-27 16:12:19 --> Helper loaded: file_helper
INFO - 2023-06-27 16:12:19 --> Helper loaded: html_helper
INFO - 2023-06-27 16:12:19 --> Helper loaded: text_helper
INFO - 2023-06-27 16:12:19 --> Helper loaded: form_helper
INFO - 2023-06-27 16:12:19 --> Helper loaded: lang_helper
INFO - 2023-06-27 16:12:19 --> Helper loaded: security_helper
INFO - 2023-06-27 16:12:19 --> Helper loaded: cookie_helper
INFO - 2023-06-27 16:12:19 --> Database Driver Class Initialized
INFO - 2023-06-27 16:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 16:12:19 --> Parser Class Initialized
INFO - 2023-06-27 16:12:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 16:12:19 --> Pagination Class Initialized
INFO - 2023-06-27 16:12:19 --> Form Validation Class Initialized
INFO - 2023-06-27 16:12:19 --> Controller Class Initialized
INFO - 2023-06-27 16:12:19 --> Model Class Initialized
DEBUG - 2023-06-27 16:12:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 16:12:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:12:19 --> Model Class Initialized
DEBUG - 2023-06-27 16:12:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:12:19 --> Model Class Initialized
INFO - 2023-06-27 16:12:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-27 16:12:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:12:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 16:12:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 16:12:19 --> Model Class Initialized
INFO - 2023-06-27 16:12:19 --> Model Class Initialized
INFO - 2023-06-27 16:12:19 --> Model Class Initialized
INFO - 2023-06-27 16:12:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 16:12:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 16:12:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 16:12:19 --> Final output sent to browser
DEBUG - 2023-06-27 16:12:19 --> Total execution time: 0.0863
ERROR - 2023-06-27 16:12:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 16:12:20 --> Config Class Initialized
INFO - 2023-06-27 16:12:20 --> Hooks Class Initialized
DEBUG - 2023-06-27 16:12:20 --> UTF-8 Support Enabled
INFO - 2023-06-27 16:12:20 --> Utf8 Class Initialized
INFO - 2023-06-27 16:12:20 --> URI Class Initialized
INFO - 2023-06-27 16:12:20 --> Router Class Initialized
INFO - 2023-06-27 16:12:20 --> Output Class Initialized
INFO - 2023-06-27 16:12:20 --> Security Class Initialized
DEBUG - 2023-06-27 16:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 16:12:20 --> Input Class Initialized
INFO - 2023-06-27 16:12:20 --> Language Class Initialized
INFO - 2023-06-27 16:12:20 --> Loader Class Initialized
INFO - 2023-06-27 16:12:20 --> Helper loaded: url_helper
INFO - 2023-06-27 16:12:20 --> Helper loaded: file_helper
INFO - 2023-06-27 16:12:20 --> Helper loaded: html_helper
INFO - 2023-06-27 16:12:20 --> Helper loaded: text_helper
INFO - 2023-06-27 16:12:20 --> Helper loaded: form_helper
INFO - 2023-06-27 16:12:20 --> Helper loaded: lang_helper
INFO - 2023-06-27 16:12:20 --> Helper loaded: security_helper
INFO - 2023-06-27 16:12:20 --> Helper loaded: cookie_helper
INFO - 2023-06-27 16:12:20 --> Database Driver Class Initialized
INFO - 2023-06-27 16:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 16:12:20 --> Parser Class Initialized
INFO - 2023-06-27 16:12:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 16:12:20 --> Pagination Class Initialized
INFO - 2023-06-27 16:12:20 --> Form Validation Class Initialized
INFO - 2023-06-27 16:12:20 --> Controller Class Initialized
INFO - 2023-06-27 16:12:20 --> Model Class Initialized
DEBUG - 2023-06-27 16:12:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 16:12:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:12:20 --> Model Class Initialized
DEBUG - 2023-06-27 16:12:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:12:20 --> Model Class Initialized
INFO - 2023-06-27 16:12:20 --> Final output sent to browser
DEBUG - 2023-06-27 16:12:20 --> Total execution time: 0.0364
ERROR - 2023-06-27 16:12:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 16:12:33 --> Config Class Initialized
INFO - 2023-06-27 16:12:33 --> Hooks Class Initialized
DEBUG - 2023-06-27 16:12:33 --> UTF-8 Support Enabled
INFO - 2023-06-27 16:12:33 --> Utf8 Class Initialized
INFO - 2023-06-27 16:12:33 --> URI Class Initialized
INFO - 2023-06-27 16:12:33 --> Router Class Initialized
INFO - 2023-06-27 16:12:33 --> Output Class Initialized
INFO - 2023-06-27 16:12:33 --> Security Class Initialized
DEBUG - 2023-06-27 16:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 16:12:33 --> Input Class Initialized
INFO - 2023-06-27 16:12:33 --> Language Class Initialized
INFO - 2023-06-27 16:12:33 --> Loader Class Initialized
INFO - 2023-06-27 16:12:33 --> Helper loaded: url_helper
INFO - 2023-06-27 16:12:33 --> Helper loaded: file_helper
INFO - 2023-06-27 16:12:33 --> Helper loaded: html_helper
INFO - 2023-06-27 16:12:33 --> Helper loaded: text_helper
INFO - 2023-06-27 16:12:33 --> Helper loaded: form_helper
INFO - 2023-06-27 16:12:33 --> Helper loaded: lang_helper
INFO - 2023-06-27 16:12:33 --> Helper loaded: security_helper
INFO - 2023-06-27 16:12:33 --> Helper loaded: cookie_helper
INFO - 2023-06-27 16:12:33 --> Database Driver Class Initialized
INFO - 2023-06-27 16:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 16:12:33 --> Parser Class Initialized
INFO - 2023-06-27 16:12:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 16:12:33 --> Pagination Class Initialized
INFO - 2023-06-27 16:12:33 --> Form Validation Class Initialized
INFO - 2023-06-27 16:12:33 --> Controller Class Initialized
INFO - 2023-06-27 16:12:33 --> Model Class Initialized
DEBUG - 2023-06-27 16:12:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 16:12:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:12:33 --> Model Class Initialized
DEBUG - 2023-06-27 16:12:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:12:33 --> Model Class Initialized
INFO - 2023-06-27 16:12:33 --> Final output sent to browser
DEBUG - 2023-06-27 16:12:33 --> Total execution time: 0.0439
ERROR - 2023-06-27 16:12:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 16:12:33 --> Config Class Initialized
INFO - 2023-06-27 16:12:33 --> Hooks Class Initialized
DEBUG - 2023-06-27 16:12:33 --> UTF-8 Support Enabled
INFO - 2023-06-27 16:12:33 --> Utf8 Class Initialized
INFO - 2023-06-27 16:12:33 --> URI Class Initialized
INFO - 2023-06-27 16:12:33 --> Router Class Initialized
INFO - 2023-06-27 16:12:33 --> Output Class Initialized
INFO - 2023-06-27 16:12:33 --> Security Class Initialized
DEBUG - 2023-06-27 16:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 16:12:33 --> Input Class Initialized
INFO - 2023-06-27 16:12:33 --> Language Class Initialized
INFO - 2023-06-27 16:12:33 --> Loader Class Initialized
INFO - 2023-06-27 16:12:33 --> Helper loaded: url_helper
INFO - 2023-06-27 16:12:33 --> Helper loaded: file_helper
INFO - 2023-06-27 16:12:33 --> Helper loaded: html_helper
INFO - 2023-06-27 16:12:33 --> Helper loaded: text_helper
INFO - 2023-06-27 16:12:33 --> Helper loaded: form_helper
INFO - 2023-06-27 16:12:33 --> Helper loaded: lang_helper
INFO - 2023-06-27 16:12:33 --> Helper loaded: security_helper
INFO - 2023-06-27 16:12:33 --> Helper loaded: cookie_helper
INFO - 2023-06-27 16:12:33 --> Database Driver Class Initialized
INFO - 2023-06-27 16:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 16:12:33 --> Parser Class Initialized
INFO - 2023-06-27 16:12:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 16:12:33 --> Pagination Class Initialized
INFO - 2023-06-27 16:12:33 --> Form Validation Class Initialized
INFO - 2023-06-27 16:12:33 --> Controller Class Initialized
INFO - 2023-06-27 16:12:33 --> Model Class Initialized
DEBUG - 2023-06-27 16:12:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 16:12:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:12:33 --> Model Class Initialized
DEBUG - 2023-06-27 16:12:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:12:33 --> Model Class Initialized
INFO - 2023-06-27 16:12:33 --> Final output sent to browser
DEBUG - 2023-06-27 16:12:33 --> Total execution time: 0.0701
ERROR - 2023-06-27 16:12:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 16:12:35 --> Config Class Initialized
INFO - 2023-06-27 16:12:35 --> Hooks Class Initialized
DEBUG - 2023-06-27 16:12:35 --> UTF-8 Support Enabled
INFO - 2023-06-27 16:12:35 --> Utf8 Class Initialized
INFO - 2023-06-27 16:12:35 --> URI Class Initialized
INFO - 2023-06-27 16:12:35 --> Router Class Initialized
INFO - 2023-06-27 16:12:35 --> Output Class Initialized
INFO - 2023-06-27 16:12:35 --> Security Class Initialized
DEBUG - 2023-06-27 16:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 16:12:35 --> Input Class Initialized
INFO - 2023-06-27 16:12:35 --> Language Class Initialized
INFO - 2023-06-27 16:12:35 --> Loader Class Initialized
INFO - 2023-06-27 16:12:35 --> Helper loaded: url_helper
INFO - 2023-06-27 16:12:35 --> Helper loaded: file_helper
INFO - 2023-06-27 16:12:35 --> Helper loaded: html_helper
INFO - 2023-06-27 16:12:35 --> Helper loaded: text_helper
INFO - 2023-06-27 16:12:35 --> Helper loaded: form_helper
INFO - 2023-06-27 16:12:35 --> Helper loaded: lang_helper
INFO - 2023-06-27 16:12:35 --> Helper loaded: security_helper
INFO - 2023-06-27 16:12:35 --> Helper loaded: cookie_helper
INFO - 2023-06-27 16:12:35 --> Database Driver Class Initialized
INFO - 2023-06-27 16:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 16:12:35 --> Parser Class Initialized
INFO - 2023-06-27 16:12:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 16:12:35 --> Pagination Class Initialized
INFO - 2023-06-27 16:12:35 --> Form Validation Class Initialized
INFO - 2023-06-27 16:12:35 --> Controller Class Initialized
INFO - 2023-06-27 16:12:35 --> Model Class Initialized
DEBUG - 2023-06-27 16:12:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 16:12:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:12:35 --> Model Class Initialized
DEBUG - 2023-06-27 16:12:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:12:35 --> Model Class Initialized
INFO - 2023-06-27 16:12:35 --> Final output sent to browser
DEBUG - 2023-06-27 16:12:35 --> Total execution time: 0.0637
ERROR - 2023-06-27 16:13:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 16:13:26 --> Config Class Initialized
INFO - 2023-06-27 16:13:26 --> Hooks Class Initialized
DEBUG - 2023-06-27 16:13:26 --> UTF-8 Support Enabled
INFO - 2023-06-27 16:13:26 --> Utf8 Class Initialized
INFO - 2023-06-27 16:13:26 --> URI Class Initialized
DEBUG - 2023-06-27 16:13:26 --> No URI present. Default controller set.
INFO - 2023-06-27 16:13:26 --> Router Class Initialized
INFO - 2023-06-27 16:13:26 --> Output Class Initialized
INFO - 2023-06-27 16:13:26 --> Security Class Initialized
DEBUG - 2023-06-27 16:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 16:13:26 --> Input Class Initialized
INFO - 2023-06-27 16:13:26 --> Language Class Initialized
INFO - 2023-06-27 16:13:26 --> Loader Class Initialized
INFO - 2023-06-27 16:13:26 --> Helper loaded: url_helper
INFO - 2023-06-27 16:13:26 --> Helper loaded: file_helper
INFO - 2023-06-27 16:13:26 --> Helper loaded: html_helper
INFO - 2023-06-27 16:13:26 --> Helper loaded: text_helper
INFO - 2023-06-27 16:13:26 --> Helper loaded: form_helper
INFO - 2023-06-27 16:13:26 --> Helper loaded: lang_helper
INFO - 2023-06-27 16:13:26 --> Helper loaded: security_helper
INFO - 2023-06-27 16:13:26 --> Helper loaded: cookie_helper
INFO - 2023-06-27 16:13:26 --> Database Driver Class Initialized
INFO - 2023-06-27 16:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 16:13:26 --> Parser Class Initialized
INFO - 2023-06-27 16:13:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 16:13:26 --> Pagination Class Initialized
INFO - 2023-06-27 16:13:26 --> Form Validation Class Initialized
INFO - 2023-06-27 16:13:26 --> Controller Class Initialized
INFO - 2023-06-27 16:13:26 --> Model Class Initialized
DEBUG - 2023-06-27 16:13:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:13:26 --> Model Class Initialized
DEBUG - 2023-06-27 16:13:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:13:26 --> Model Class Initialized
INFO - 2023-06-27 16:13:26 --> Model Class Initialized
INFO - 2023-06-27 16:13:26 --> Model Class Initialized
INFO - 2023-06-27 16:13:26 --> Model Class Initialized
DEBUG - 2023-06-27 16:13:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 16:13:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:13:26 --> Model Class Initialized
INFO - 2023-06-27 16:13:26 --> Model Class Initialized
INFO - 2023-06-27 16:13:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 16:13:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:13:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 16:13:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 16:13:26 --> Model Class Initialized
INFO - 2023-06-27 16:13:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 16:13:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 16:13:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 16:13:26 --> Final output sent to browser
DEBUG - 2023-06-27 16:13:26 --> Total execution time: 0.0893
ERROR - 2023-06-27 16:13:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 16:13:37 --> Config Class Initialized
INFO - 2023-06-27 16:13:37 --> Hooks Class Initialized
DEBUG - 2023-06-27 16:13:37 --> UTF-8 Support Enabled
INFO - 2023-06-27 16:13:37 --> Utf8 Class Initialized
INFO - 2023-06-27 16:13:37 --> URI Class Initialized
INFO - 2023-06-27 16:13:37 --> Router Class Initialized
INFO - 2023-06-27 16:13:37 --> Output Class Initialized
INFO - 2023-06-27 16:13:37 --> Security Class Initialized
DEBUG - 2023-06-27 16:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 16:13:37 --> Input Class Initialized
INFO - 2023-06-27 16:13:37 --> Language Class Initialized
INFO - 2023-06-27 16:13:37 --> Loader Class Initialized
INFO - 2023-06-27 16:13:37 --> Helper loaded: url_helper
INFO - 2023-06-27 16:13:37 --> Helper loaded: file_helper
INFO - 2023-06-27 16:13:37 --> Helper loaded: html_helper
INFO - 2023-06-27 16:13:37 --> Helper loaded: text_helper
INFO - 2023-06-27 16:13:37 --> Helper loaded: form_helper
INFO - 2023-06-27 16:13:37 --> Helper loaded: lang_helper
INFO - 2023-06-27 16:13:37 --> Helper loaded: security_helper
INFO - 2023-06-27 16:13:37 --> Helper loaded: cookie_helper
INFO - 2023-06-27 16:13:37 --> Database Driver Class Initialized
INFO - 2023-06-27 16:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 16:13:37 --> Parser Class Initialized
INFO - 2023-06-27 16:13:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 16:13:37 --> Pagination Class Initialized
INFO - 2023-06-27 16:13:37 --> Form Validation Class Initialized
INFO - 2023-06-27 16:13:37 --> Controller Class Initialized
INFO - 2023-06-27 16:13:38 --> Model Class Initialized
DEBUG - 2023-06-27 16:13:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 16:13:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:13:38 --> Model Class Initialized
DEBUG - 2023-06-27 16:13:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:13:38 --> Model Class Initialized
INFO - 2023-06-27 16:13:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-06-27 16:13:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:13:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 16:13:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 16:13:38 --> Model Class Initialized
INFO - 2023-06-27 16:13:38 --> Model Class Initialized
INFO - 2023-06-27 16:13:38 --> Model Class Initialized
INFO - 2023-06-27 16:13:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 16:13:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 16:13:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 16:13:38 --> Final output sent to browser
DEBUG - 2023-06-27 16:13:38 --> Total execution time: 0.0697
ERROR - 2023-06-27 16:13:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 16:13:38 --> Config Class Initialized
INFO - 2023-06-27 16:13:38 --> Hooks Class Initialized
DEBUG - 2023-06-27 16:13:38 --> UTF-8 Support Enabled
INFO - 2023-06-27 16:13:38 --> Utf8 Class Initialized
INFO - 2023-06-27 16:13:38 --> URI Class Initialized
INFO - 2023-06-27 16:13:38 --> Router Class Initialized
INFO - 2023-06-27 16:13:38 --> Output Class Initialized
INFO - 2023-06-27 16:13:38 --> Security Class Initialized
DEBUG - 2023-06-27 16:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 16:13:38 --> Input Class Initialized
INFO - 2023-06-27 16:13:38 --> Language Class Initialized
INFO - 2023-06-27 16:13:38 --> Loader Class Initialized
INFO - 2023-06-27 16:13:38 --> Helper loaded: url_helper
INFO - 2023-06-27 16:13:38 --> Helper loaded: file_helper
INFO - 2023-06-27 16:13:38 --> Helper loaded: html_helper
INFO - 2023-06-27 16:13:38 --> Helper loaded: text_helper
INFO - 2023-06-27 16:13:38 --> Helper loaded: form_helper
INFO - 2023-06-27 16:13:38 --> Helper loaded: lang_helper
INFO - 2023-06-27 16:13:38 --> Helper loaded: security_helper
INFO - 2023-06-27 16:13:38 --> Helper loaded: cookie_helper
INFO - 2023-06-27 16:13:38 --> Database Driver Class Initialized
INFO - 2023-06-27 16:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 16:13:38 --> Parser Class Initialized
INFO - 2023-06-27 16:13:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 16:13:38 --> Pagination Class Initialized
INFO - 2023-06-27 16:13:38 --> Form Validation Class Initialized
INFO - 2023-06-27 16:13:38 --> Controller Class Initialized
INFO - 2023-06-27 16:13:38 --> Model Class Initialized
DEBUG - 2023-06-27 16:13:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 16:13:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:13:38 --> Model Class Initialized
DEBUG - 2023-06-27 16:13:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:13:38 --> Model Class Initialized
INFO - 2023-06-27 16:13:38 --> Final output sent to browser
DEBUG - 2023-06-27 16:13:38 --> Total execution time: 0.0615
ERROR - 2023-06-27 16:14:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 16:14:24 --> Config Class Initialized
INFO - 2023-06-27 16:14:24 --> Hooks Class Initialized
DEBUG - 2023-06-27 16:14:24 --> UTF-8 Support Enabled
INFO - 2023-06-27 16:14:24 --> Utf8 Class Initialized
INFO - 2023-06-27 16:14:24 --> URI Class Initialized
INFO - 2023-06-27 16:14:24 --> Router Class Initialized
INFO - 2023-06-27 16:14:24 --> Output Class Initialized
INFO - 2023-06-27 16:14:24 --> Security Class Initialized
DEBUG - 2023-06-27 16:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 16:14:24 --> Input Class Initialized
INFO - 2023-06-27 16:14:24 --> Language Class Initialized
INFO - 2023-06-27 16:14:24 --> Loader Class Initialized
INFO - 2023-06-27 16:14:24 --> Helper loaded: url_helper
INFO - 2023-06-27 16:14:24 --> Helper loaded: file_helper
INFO - 2023-06-27 16:14:24 --> Helper loaded: html_helper
INFO - 2023-06-27 16:14:24 --> Helper loaded: text_helper
INFO - 2023-06-27 16:14:24 --> Helper loaded: form_helper
INFO - 2023-06-27 16:14:24 --> Helper loaded: lang_helper
INFO - 2023-06-27 16:14:24 --> Helper loaded: security_helper
INFO - 2023-06-27 16:14:24 --> Helper loaded: cookie_helper
INFO - 2023-06-27 16:14:24 --> Database Driver Class Initialized
INFO - 2023-06-27 16:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 16:14:24 --> Parser Class Initialized
INFO - 2023-06-27 16:14:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 16:14:24 --> Pagination Class Initialized
INFO - 2023-06-27 16:14:24 --> Form Validation Class Initialized
INFO - 2023-06-27 16:14:24 --> Controller Class Initialized
INFO - 2023-06-27 16:14:24 --> Model Class Initialized
DEBUG - 2023-06-27 16:14:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 16:14:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:14:24 --> Model Class Initialized
DEBUG - 2023-06-27 16:14:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:14:24 --> Model Class Initialized
INFO - 2023-06-27 16:14:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice_html.php
DEBUG - 2023-06-27 16:14:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:14:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 16:14:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 16:14:24 --> Model Class Initialized
INFO - 2023-06-27 16:14:24 --> Model Class Initialized
INFO - 2023-06-27 16:14:24 --> Model Class Initialized
INFO - 2023-06-27 16:14:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 16:14:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 16:14:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 16:14:24 --> Final output sent to browser
DEBUG - 2023-06-27 16:14:24 --> Total execution time: 0.0829
ERROR - 2023-06-27 16:17:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 16:17:25 --> Config Class Initialized
INFO - 2023-06-27 16:17:25 --> Hooks Class Initialized
DEBUG - 2023-06-27 16:17:25 --> UTF-8 Support Enabled
INFO - 2023-06-27 16:17:25 --> Utf8 Class Initialized
INFO - 2023-06-27 16:17:25 --> URI Class Initialized
INFO - 2023-06-27 16:17:25 --> Router Class Initialized
INFO - 2023-06-27 16:17:25 --> Output Class Initialized
INFO - 2023-06-27 16:17:25 --> Security Class Initialized
DEBUG - 2023-06-27 16:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 16:17:25 --> Input Class Initialized
INFO - 2023-06-27 16:17:25 --> Language Class Initialized
INFO - 2023-06-27 16:17:25 --> Loader Class Initialized
INFO - 2023-06-27 16:17:25 --> Helper loaded: url_helper
INFO - 2023-06-27 16:17:25 --> Helper loaded: file_helper
INFO - 2023-06-27 16:17:25 --> Helper loaded: html_helper
INFO - 2023-06-27 16:17:25 --> Helper loaded: text_helper
INFO - 2023-06-27 16:17:25 --> Helper loaded: form_helper
INFO - 2023-06-27 16:17:25 --> Helper loaded: lang_helper
INFO - 2023-06-27 16:17:25 --> Helper loaded: security_helper
INFO - 2023-06-27 16:17:25 --> Helper loaded: cookie_helper
INFO - 2023-06-27 16:17:25 --> Database Driver Class Initialized
INFO - 2023-06-27 16:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 16:17:25 --> Parser Class Initialized
INFO - 2023-06-27 16:17:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 16:17:25 --> Pagination Class Initialized
INFO - 2023-06-27 16:17:25 --> Form Validation Class Initialized
INFO - 2023-06-27 16:17:25 --> Controller Class Initialized
INFO - 2023-06-27 16:17:25 --> Model Class Initialized
DEBUG - 2023-06-27 16:17:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 16:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:17:25 --> Model Class Initialized
DEBUG - 2023-06-27 16:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:17:25 --> Model Class Initialized
INFO - 2023-06-27 16:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-06-27 16:17:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 16:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 16:17:25 --> Model Class Initialized
INFO - 2023-06-27 16:17:25 --> Model Class Initialized
INFO - 2023-06-27 16:17:25 --> Model Class Initialized
INFO - 2023-06-27 16:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 16:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 16:17:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 16:17:25 --> Final output sent to browser
DEBUG - 2023-06-27 16:17:25 --> Total execution time: 0.0764
ERROR - 2023-06-27 16:17:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 16:17:26 --> Config Class Initialized
INFO - 2023-06-27 16:17:26 --> Hooks Class Initialized
DEBUG - 2023-06-27 16:17:26 --> UTF-8 Support Enabled
INFO - 2023-06-27 16:17:26 --> Utf8 Class Initialized
INFO - 2023-06-27 16:17:26 --> URI Class Initialized
INFO - 2023-06-27 16:17:26 --> Router Class Initialized
INFO - 2023-06-27 16:17:26 --> Output Class Initialized
INFO - 2023-06-27 16:17:26 --> Security Class Initialized
DEBUG - 2023-06-27 16:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 16:17:26 --> Input Class Initialized
INFO - 2023-06-27 16:17:26 --> Language Class Initialized
INFO - 2023-06-27 16:17:26 --> Loader Class Initialized
INFO - 2023-06-27 16:17:26 --> Helper loaded: url_helper
INFO - 2023-06-27 16:17:26 --> Helper loaded: file_helper
INFO - 2023-06-27 16:17:26 --> Helper loaded: html_helper
INFO - 2023-06-27 16:17:26 --> Helper loaded: text_helper
INFO - 2023-06-27 16:17:26 --> Helper loaded: form_helper
INFO - 2023-06-27 16:17:26 --> Helper loaded: lang_helper
INFO - 2023-06-27 16:17:26 --> Helper loaded: security_helper
INFO - 2023-06-27 16:17:26 --> Helper loaded: cookie_helper
INFO - 2023-06-27 16:17:26 --> Database Driver Class Initialized
INFO - 2023-06-27 16:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 16:17:26 --> Parser Class Initialized
INFO - 2023-06-27 16:17:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 16:17:26 --> Pagination Class Initialized
INFO - 2023-06-27 16:17:26 --> Form Validation Class Initialized
INFO - 2023-06-27 16:17:26 --> Controller Class Initialized
INFO - 2023-06-27 16:17:26 --> Model Class Initialized
DEBUG - 2023-06-27 16:17:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 16:17:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:17:26 --> Model Class Initialized
DEBUG - 2023-06-27 16:17:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 16:17:26 --> Model Class Initialized
INFO - 2023-06-27 16:17:26 --> Final output sent to browser
DEBUG - 2023-06-27 16:17:26 --> Total execution time: 0.0543
ERROR - 2023-06-27 17:13:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 17:13:42 --> Config Class Initialized
INFO - 2023-06-27 17:13:42 --> Hooks Class Initialized
DEBUG - 2023-06-27 17:13:42 --> UTF-8 Support Enabled
INFO - 2023-06-27 17:13:42 --> Utf8 Class Initialized
INFO - 2023-06-27 17:13:42 --> URI Class Initialized
DEBUG - 2023-06-27 17:13:42 --> No URI present. Default controller set.
INFO - 2023-06-27 17:13:42 --> Router Class Initialized
INFO - 2023-06-27 17:13:42 --> Output Class Initialized
INFO - 2023-06-27 17:13:42 --> Security Class Initialized
DEBUG - 2023-06-27 17:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 17:13:42 --> Input Class Initialized
INFO - 2023-06-27 17:13:42 --> Language Class Initialized
INFO - 2023-06-27 17:13:42 --> Loader Class Initialized
INFO - 2023-06-27 17:13:42 --> Helper loaded: url_helper
INFO - 2023-06-27 17:13:42 --> Helper loaded: file_helper
INFO - 2023-06-27 17:13:42 --> Helper loaded: html_helper
INFO - 2023-06-27 17:13:42 --> Helper loaded: text_helper
INFO - 2023-06-27 17:13:42 --> Helper loaded: form_helper
INFO - 2023-06-27 17:13:42 --> Helper loaded: lang_helper
INFO - 2023-06-27 17:13:42 --> Helper loaded: security_helper
INFO - 2023-06-27 17:13:42 --> Helper loaded: cookie_helper
INFO - 2023-06-27 17:13:42 --> Database Driver Class Initialized
INFO - 2023-06-27 17:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 17:13:42 --> Parser Class Initialized
INFO - 2023-06-27 17:13:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 17:13:42 --> Pagination Class Initialized
INFO - 2023-06-27 17:13:42 --> Form Validation Class Initialized
INFO - 2023-06-27 17:13:42 --> Controller Class Initialized
INFO - 2023-06-27 17:13:42 --> Model Class Initialized
DEBUG - 2023-06-27 17:13:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-27 17:13:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 17:13:43 --> Config Class Initialized
INFO - 2023-06-27 17:13:43 --> Hooks Class Initialized
DEBUG - 2023-06-27 17:13:43 --> UTF-8 Support Enabled
INFO - 2023-06-27 17:13:43 --> Utf8 Class Initialized
INFO - 2023-06-27 17:13:43 --> URI Class Initialized
INFO - 2023-06-27 17:13:43 --> Router Class Initialized
INFO - 2023-06-27 17:13:43 --> Output Class Initialized
INFO - 2023-06-27 17:13:43 --> Security Class Initialized
DEBUG - 2023-06-27 17:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 17:13:43 --> Input Class Initialized
INFO - 2023-06-27 17:13:43 --> Language Class Initialized
INFO - 2023-06-27 17:13:43 --> Loader Class Initialized
INFO - 2023-06-27 17:13:43 --> Helper loaded: url_helper
INFO - 2023-06-27 17:13:43 --> Helper loaded: file_helper
INFO - 2023-06-27 17:13:43 --> Helper loaded: html_helper
INFO - 2023-06-27 17:13:43 --> Helper loaded: text_helper
INFO - 2023-06-27 17:13:43 --> Helper loaded: form_helper
INFO - 2023-06-27 17:13:43 --> Helper loaded: lang_helper
INFO - 2023-06-27 17:13:43 --> Helper loaded: security_helper
INFO - 2023-06-27 17:13:43 --> Helper loaded: cookie_helper
INFO - 2023-06-27 17:13:43 --> Database Driver Class Initialized
INFO - 2023-06-27 17:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 17:13:43 --> Parser Class Initialized
INFO - 2023-06-27 17:13:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 17:13:43 --> Pagination Class Initialized
INFO - 2023-06-27 17:13:43 --> Form Validation Class Initialized
INFO - 2023-06-27 17:13:43 --> Controller Class Initialized
INFO - 2023-06-27 17:13:43 --> Model Class Initialized
DEBUG - 2023-06-27 17:13:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:13:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-27 17:13:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:13:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 17:13:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 17:13:43 --> Model Class Initialized
INFO - 2023-06-27 17:13:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 17:13:43 --> Final output sent to browser
DEBUG - 2023-06-27 17:13:43 --> Total execution time: 0.0292
ERROR - 2023-06-27 17:13:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 17:13:47 --> Config Class Initialized
INFO - 2023-06-27 17:13:47 --> Hooks Class Initialized
DEBUG - 2023-06-27 17:13:47 --> UTF-8 Support Enabled
INFO - 2023-06-27 17:13:47 --> Utf8 Class Initialized
INFO - 2023-06-27 17:13:47 --> URI Class Initialized
INFO - 2023-06-27 17:13:47 --> Router Class Initialized
INFO - 2023-06-27 17:13:47 --> Output Class Initialized
INFO - 2023-06-27 17:13:47 --> Security Class Initialized
DEBUG - 2023-06-27 17:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 17:13:47 --> Input Class Initialized
INFO - 2023-06-27 17:13:47 --> Language Class Initialized
INFO - 2023-06-27 17:13:47 --> Loader Class Initialized
INFO - 2023-06-27 17:13:47 --> Helper loaded: url_helper
INFO - 2023-06-27 17:13:47 --> Helper loaded: file_helper
INFO - 2023-06-27 17:13:47 --> Helper loaded: html_helper
INFO - 2023-06-27 17:13:47 --> Helper loaded: text_helper
INFO - 2023-06-27 17:13:47 --> Helper loaded: form_helper
INFO - 2023-06-27 17:13:47 --> Helper loaded: lang_helper
INFO - 2023-06-27 17:13:47 --> Helper loaded: security_helper
INFO - 2023-06-27 17:13:47 --> Helper loaded: cookie_helper
INFO - 2023-06-27 17:13:47 --> Database Driver Class Initialized
INFO - 2023-06-27 17:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 17:13:47 --> Parser Class Initialized
INFO - 2023-06-27 17:13:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 17:13:47 --> Pagination Class Initialized
INFO - 2023-06-27 17:13:47 --> Form Validation Class Initialized
INFO - 2023-06-27 17:13:47 --> Controller Class Initialized
INFO - 2023-06-27 17:13:47 --> Model Class Initialized
DEBUG - 2023-06-27 17:13:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:13:47 --> Model Class Initialized
INFO - 2023-06-27 17:13:47 --> Final output sent to browser
DEBUG - 2023-06-27 17:13:47 --> Total execution time: 0.0186
ERROR - 2023-06-27 17:13:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 17:13:47 --> Config Class Initialized
INFO - 2023-06-27 17:13:47 --> Hooks Class Initialized
DEBUG - 2023-06-27 17:13:47 --> UTF-8 Support Enabled
INFO - 2023-06-27 17:13:47 --> Utf8 Class Initialized
INFO - 2023-06-27 17:13:47 --> URI Class Initialized
DEBUG - 2023-06-27 17:13:47 --> No URI present. Default controller set.
INFO - 2023-06-27 17:13:47 --> Router Class Initialized
INFO - 2023-06-27 17:13:47 --> Output Class Initialized
INFO - 2023-06-27 17:13:47 --> Security Class Initialized
DEBUG - 2023-06-27 17:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 17:13:47 --> Input Class Initialized
INFO - 2023-06-27 17:13:47 --> Language Class Initialized
INFO - 2023-06-27 17:13:47 --> Loader Class Initialized
INFO - 2023-06-27 17:13:47 --> Helper loaded: url_helper
INFO - 2023-06-27 17:13:47 --> Helper loaded: file_helper
INFO - 2023-06-27 17:13:47 --> Helper loaded: html_helper
INFO - 2023-06-27 17:13:47 --> Helper loaded: text_helper
INFO - 2023-06-27 17:13:47 --> Helper loaded: form_helper
INFO - 2023-06-27 17:13:47 --> Helper loaded: lang_helper
INFO - 2023-06-27 17:13:47 --> Helper loaded: security_helper
INFO - 2023-06-27 17:13:47 --> Helper loaded: cookie_helper
INFO - 2023-06-27 17:13:47 --> Database Driver Class Initialized
INFO - 2023-06-27 17:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 17:13:47 --> Parser Class Initialized
INFO - 2023-06-27 17:13:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 17:13:47 --> Pagination Class Initialized
INFO - 2023-06-27 17:13:47 --> Form Validation Class Initialized
INFO - 2023-06-27 17:13:47 --> Controller Class Initialized
INFO - 2023-06-27 17:13:47 --> Model Class Initialized
DEBUG - 2023-06-27 17:13:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:13:48 --> Model Class Initialized
DEBUG - 2023-06-27 17:13:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:13:48 --> Model Class Initialized
INFO - 2023-06-27 17:13:48 --> Model Class Initialized
INFO - 2023-06-27 17:13:48 --> Model Class Initialized
INFO - 2023-06-27 17:13:48 --> Model Class Initialized
DEBUG - 2023-06-27 17:13:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 17:13:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:13:48 --> Model Class Initialized
INFO - 2023-06-27 17:13:48 --> Model Class Initialized
INFO - 2023-06-27 17:13:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 17:13:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:13:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 17:13:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 17:13:48 --> Model Class Initialized
INFO - 2023-06-27 17:13:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 17:13:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 17:13:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 17:13:48 --> Final output sent to browser
DEBUG - 2023-06-27 17:13:48 --> Total execution time: 0.0763
ERROR - 2023-06-27 17:13:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 17:13:53 --> Config Class Initialized
INFO - 2023-06-27 17:13:53 --> Hooks Class Initialized
DEBUG - 2023-06-27 17:13:53 --> UTF-8 Support Enabled
INFO - 2023-06-27 17:13:53 --> Utf8 Class Initialized
INFO - 2023-06-27 17:13:53 --> URI Class Initialized
INFO - 2023-06-27 17:13:53 --> Router Class Initialized
INFO - 2023-06-27 17:13:53 --> Output Class Initialized
INFO - 2023-06-27 17:13:53 --> Security Class Initialized
DEBUG - 2023-06-27 17:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 17:13:53 --> Input Class Initialized
INFO - 2023-06-27 17:13:53 --> Language Class Initialized
INFO - 2023-06-27 17:13:53 --> Loader Class Initialized
INFO - 2023-06-27 17:13:53 --> Helper loaded: url_helper
INFO - 2023-06-27 17:13:53 --> Helper loaded: file_helper
INFO - 2023-06-27 17:13:53 --> Helper loaded: html_helper
INFO - 2023-06-27 17:13:53 --> Helper loaded: text_helper
INFO - 2023-06-27 17:13:53 --> Helper loaded: form_helper
INFO - 2023-06-27 17:13:53 --> Helper loaded: lang_helper
INFO - 2023-06-27 17:13:53 --> Helper loaded: security_helper
INFO - 2023-06-27 17:13:53 --> Helper loaded: cookie_helper
INFO - 2023-06-27 17:13:53 --> Database Driver Class Initialized
INFO - 2023-06-27 17:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 17:13:53 --> Parser Class Initialized
INFO - 2023-06-27 17:13:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 17:13:53 --> Pagination Class Initialized
INFO - 2023-06-27 17:13:53 --> Form Validation Class Initialized
INFO - 2023-06-27 17:13:53 --> Controller Class Initialized
INFO - 2023-06-27 17:13:53 --> Model Class Initialized
DEBUG - 2023-06-27 17:13:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 17:13:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:13:53 --> Model Class Initialized
DEBUG - 2023-06-27 17:13:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:13:53 --> Model Class Initialized
INFO - 2023-06-27 17:13:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-27 17:13:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:13:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 17:13:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 17:13:53 --> Model Class Initialized
INFO - 2023-06-27 17:13:53 --> Model Class Initialized
INFO - 2023-06-27 17:13:53 --> Model Class Initialized
INFO - 2023-06-27 17:13:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 17:13:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 17:13:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 17:13:53 --> Final output sent to browser
DEBUG - 2023-06-27 17:13:53 --> Total execution time: 0.0730
ERROR - 2023-06-27 17:13:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 17:13:54 --> Config Class Initialized
INFO - 2023-06-27 17:13:54 --> Hooks Class Initialized
DEBUG - 2023-06-27 17:13:54 --> UTF-8 Support Enabled
INFO - 2023-06-27 17:13:54 --> Utf8 Class Initialized
INFO - 2023-06-27 17:13:54 --> URI Class Initialized
INFO - 2023-06-27 17:13:54 --> Router Class Initialized
INFO - 2023-06-27 17:13:54 --> Output Class Initialized
INFO - 2023-06-27 17:13:54 --> Security Class Initialized
DEBUG - 2023-06-27 17:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 17:13:54 --> Input Class Initialized
INFO - 2023-06-27 17:13:54 --> Language Class Initialized
INFO - 2023-06-27 17:13:54 --> Loader Class Initialized
INFO - 2023-06-27 17:13:54 --> Helper loaded: url_helper
INFO - 2023-06-27 17:13:54 --> Helper loaded: file_helper
INFO - 2023-06-27 17:13:54 --> Helper loaded: html_helper
INFO - 2023-06-27 17:13:54 --> Helper loaded: text_helper
INFO - 2023-06-27 17:13:54 --> Helper loaded: form_helper
INFO - 2023-06-27 17:13:54 --> Helper loaded: lang_helper
INFO - 2023-06-27 17:13:54 --> Helper loaded: security_helper
INFO - 2023-06-27 17:13:54 --> Helper loaded: cookie_helper
INFO - 2023-06-27 17:13:54 --> Database Driver Class Initialized
INFO - 2023-06-27 17:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 17:13:54 --> Parser Class Initialized
INFO - 2023-06-27 17:13:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 17:13:54 --> Pagination Class Initialized
INFO - 2023-06-27 17:13:54 --> Form Validation Class Initialized
INFO - 2023-06-27 17:13:54 --> Controller Class Initialized
INFO - 2023-06-27 17:13:54 --> Model Class Initialized
DEBUG - 2023-06-27 17:13:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 17:13:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:13:54 --> Model Class Initialized
DEBUG - 2023-06-27 17:13:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:13:54 --> Model Class Initialized
INFO - 2023-06-27 17:13:54 --> Final output sent to browser
DEBUG - 2023-06-27 17:13:54 --> Total execution time: 0.0408
ERROR - 2023-06-27 17:14:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 17:14:02 --> Config Class Initialized
INFO - 2023-06-27 17:14:02 --> Hooks Class Initialized
DEBUG - 2023-06-27 17:14:02 --> UTF-8 Support Enabled
INFO - 2023-06-27 17:14:02 --> Utf8 Class Initialized
INFO - 2023-06-27 17:14:02 --> URI Class Initialized
INFO - 2023-06-27 17:14:02 --> Router Class Initialized
INFO - 2023-06-27 17:14:02 --> Output Class Initialized
INFO - 2023-06-27 17:14:02 --> Security Class Initialized
DEBUG - 2023-06-27 17:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 17:14:02 --> Input Class Initialized
INFO - 2023-06-27 17:14:02 --> Language Class Initialized
INFO - 2023-06-27 17:14:02 --> Loader Class Initialized
INFO - 2023-06-27 17:14:02 --> Helper loaded: url_helper
INFO - 2023-06-27 17:14:02 --> Helper loaded: file_helper
INFO - 2023-06-27 17:14:02 --> Helper loaded: html_helper
INFO - 2023-06-27 17:14:02 --> Helper loaded: text_helper
INFO - 2023-06-27 17:14:02 --> Helper loaded: form_helper
INFO - 2023-06-27 17:14:02 --> Helper loaded: lang_helper
INFO - 2023-06-27 17:14:02 --> Helper loaded: security_helper
INFO - 2023-06-27 17:14:02 --> Helper loaded: cookie_helper
INFO - 2023-06-27 17:14:02 --> Database Driver Class Initialized
INFO - 2023-06-27 17:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 17:14:02 --> Parser Class Initialized
INFO - 2023-06-27 17:14:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 17:14:02 --> Pagination Class Initialized
INFO - 2023-06-27 17:14:02 --> Form Validation Class Initialized
INFO - 2023-06-27 17:14:02 --> Controller Class Initialized
INFO - 2023-06-27 17:14:02 --> Model Class Initialized
DEBUG - 2023-06-27 17:14:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 17:14:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:14:02 --> Model Class Initialized
DEBUG - 2023-06-27 17:14:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:14:02 --> Model Class Initialized
INFO - 2023-06-27 17:14:02 --> Final output sent to browser
DEBUG - 2023-06-27 17:14:02 --> Total execution time: 0.0407
ERROR - 2023-06-27 17:14:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 17:14:05 --> Config Class Initialized
INFO - 2023-06-27 17:14:05 --> Hooks Class Initialized
DEBUG - 2023-06-27 17:14:05 --> UTF-8 Support Enabled
INFO - 2023-06-27 17:14:05 --> Utf8 Class Initialized
INFO - 2023-06-27 17:14:05 --> URI Class Initialized
INFO - 2023-06-27 17:14:05 --> Router Class Initialized
INFO - 2023-06-27 17:14:05 --> Output Class Initialized
INFO - 2023-06-27 17:14:05 --> Security Class Initialized
DEBUG - 2023-06-27 17:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 17:14:05 --> Input Class Initialized
INFO - 2023-06-27 17:14:05 --> Language Class Initialized
INFO - 2023-06-27 17:14:05 --> Loader Class Initialized
INFO - 2023-06-27 17:14:05 --> Helper loaded: url_helper
INFO - 2023-06-27 17:14:05 --> Helper loaded: file_helper
INFO - 2023-06-27 17:14:05 --> Helper loaded: html_helper
INFO - 2023-06-27 17:14:05 --> Helper loaded: text_helper
INFO - 2023-06-27 17:14:05 --> Helper loaded: form_helper
INFO - 2023-06-27 17:14:05 --> Helper loaded: lang_helper
INFO - 2023-06-27 17:14:05 --> Helper loaded: security_helper
INFO - 2023-06-27 17:14:05 --> Helper loaded: cookie_helper
INFO - 2023-06-27 17:14:05 --> Database Driver Class Initialized
INFO - 2023-06-27 17:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 17:14:05 --> Parser Class Initialized
INFO - 2023-06-27 17:14:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 17:14:05 --> Pagination Class Initialized
INFO - 2023-06-27 17:14:05 --> Form Validation Class Initialized
INFO - 2023-06-27 17:14:05 --> Controller Class Initialized
INFO - 2023-06-27 17:14:05 --> Model Class Initialized
DEBUG - 2023-06-27 17:14:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 17:14:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:14:05 --> Model Class Initialized
DEBUG - 2023-06-27 17:14:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:14:05 --> Model Class Initialized
INFO - 2023-06-27 17:14:06 --> Final output sent to browser
DEBUG - 2023-06-27 17:14:06 --> Total execution time: 0.0482
ERROR - 2023-06-27 17:14:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 17:14:09 --> Config Class Initialized
INFO - 2023-06-27 17:14:09 --> Hooks Class Initialized
DEBUG - 2023-06-27 17:14:09 --> UTF-8 Support Enabled
INFO - 2023-06-27 17:14:09 --> Utf8 Class Initialized
INFO - 2023-06-27 17:14:09 --> URI Class Initialized
INFO - 2023-06-27 17:14:09 --> Router Class Initialized
INFO - 2023-06-27 17:14:09 --> Output Class Initialized
INFO - 2023-06-27 17:14:09 --> Security Class Initialized
DEBUG - 2023-06-27 17:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 17:14:09 --> Input Class Initialized
INFO - 2023-06-27 17:14:09 --> Language Class Initialized
INFO - 2023-06-27 17:14:09 --> Loader Class Initialized
INFO - 2023-06-27 17:14:09 --> Helper loaded: url_helper
INFO - 2023-06-27 17:14:09 --> Helper loaded: file_helper
INFO - 2023-06-27 17:14:09 --> Helper loaded: html_helper
INFO - 2023-06-27 17:14:09 --> Helper loaded: text_helper
INFO - 2023-06-27 17:14:09 --> Helper loaded: form_helper
INFO - 2023-06-27 17:14:09 --> Helper loaded: lang_helper
INFO - 2023-06-27 17:14:09 --> Helper loaded: security_helper
INFO - 2023-06-27 17:14:09 --> Helper loaded: cookie_helper
INFO - 2023-06-27 17:14:09 --> Database Driver Class Initialized
INFO - 2023-06-27 17:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 17:14:09 --> Parser Class Initialized
INFO - 2023-06-27 17:14:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 17:14:09 --> Pagination Class Initialized
INFO - 2023-06-27 17:14:09 --> Form Validation Class Initialized
INFO - 2023-06-27 17:14:09 --> Controller Class Initialized
INFO - 2023-06-27 17:14:09 --> Model Class Initialized
DEBUG - 2023-06-27 17:14:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 17:14:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:14:09 --> Model Class Initialized
DEBUG - 2023-06-27 17:14:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:14:09 --> Model Class Initialized
INFO - 2023-06-27 17:14:09 --> Final output sent to browser
DEBUG - 2023-06-27 17:14:09 --> Total execution time: 0.0667
ERROR - 2023-06-27 17:15:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 17:15:40 --> Config Class Initialized
INFO - 2023-06-27 17:15:40 --> Hooks Class Initialized
DEBUG - 2023-06-27 17:15:40 --> UTF-8 Support Enabled
INFO - 2023-06-27 17:15:40 --> Utf8 Class Initialized
INFO - 2023-06-27 17:15:40 --> URI Class Initialized
INFO - 2023-06-27 17:15:40 --> Router Class Initialized
INFO - 2023-06-27 17:15:40 --> Output Class Initialized
INFO - 2023-06-27 17:15:40 --> Security Class Initialized
DEBUG - 2023-06-27 17:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 17:15:40 --> Input Class Initialized
INFO - 2023-06-27 17:15:40 --> Language Class Initialized
INFO - 2023-06-27 17:15:40 --> Loader Class Initialized
INFO - 2023-06-27 17:15:40 --> Helper loaded: url_helper
INFO - 2023-06-27 17:15:40 --> Helper loaded: file_helper
INFO - 2023-06-27 17:15:40 --> Helper loaded: html_helper
INFO - 2023-06-27 17:15:40 --> Helper loaded: text_helper
INFO - 2023-06-27 17:15:40 --> Helper loaded: form_helper
INFO - 2023-06-27 17:15:40 --> Helper loaded: lang_helper
INFO - 2023-06-27 17:15:40 --> Helper loaded: security_helper
INFO - 2023-06-27 17:15:40 --> Helper loaded: cookie_helper
INFO - 2023-06-27 17:15:40 --> Database Driver Class Initialized
INFO - 2023-06-27 17:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 17:15:40 --> Parser Class Initialized
INFO - 2023-06-27 17:15:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 17:15:40 --> Pagination Class Initialized
INFO - 2023-06-27 17:15:40 --> Form Validation Class Initialized
INFO - 2023-06-27 17:15:40 --> Controller Class Initialized
INFO - 2023-06-27 17:15:40 --> Model Class Initialized
DEBUG - 2023-06-27 17:15:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 17:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:15:40 --> Model Class Initialized
DEBUG - 2023-06-27 17:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:15:40 --> Model Class Initialized
DEBUG - 2023-06-27 17:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:15:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-06-27 17:15:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:15:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 17:15:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 17:15:40 --> Model Class Initialized
INFO - 2023-06-27 17:15:40 --> Model Class Initialized
INFO - 2023-06-27 17:15:40 --> Model Class Initialized
INFO - 2023-06-27 17:15:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 17:15:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 17:15:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 17:15:40 --> Final output sent to browser
DEBUG - 2023-06-27 17:15:40 --> Total execution time: 0.0781
ERROR - 2023-06-27 17:16:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 17:16:04 --> Config Class Initialized
INFO - 2023-06-27 17:16:04 --> Hooks Class Initialized
DEBUG - 2023-06-27 17:16:04 --> UTF-8 Support Enabled
INFO - 2023-06-27 17:16:04 --> Utf8 Class Initialized
INFO - 2023-06-27 17:16:04 --> URI Class Initialized
DEBUG - 2023-06-27 17:16:04 --> No URI present. Default controller set.
INFO - 2023-06-27 17:16:04 --> Router Class Initialized
INFO - 2023-06-27 17:16:04 --> Output Class Initialized
INFO - 2023-06-27 17:16:04 --> Security Class Initialized
DEBUG - 2023-06-27 17:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 17:16:04 --> Input Class Initialized
INFO - 2023-06-27 17:16:04 --> Language Class Initialized
INFO - 2023-06-27 17:16:04 --> Loader Class Initialized
INFO - 2023-06-27 17:16:04 --> Helper loaded: url_helper
INFO - 2023-06-27 17:16:04 --> Helper loaded: file_helper
INFO - 2023-06-27 17:16:04 --> Helper loaded: html_helper
INFO - 2023-06-27 17:16:04 --> Helper loaded: text_helper
INFO - 2023-06-27 17:16:04 --> Helper loaded: form_helper
INFO - 2023-06-27 17:16:04 --> Helper loaded: lang_helper
INFO - 2023-06-27 17:16:04 --> Helper loaded: security_helper
INFO - 2023-06-27 17:16:04 --> Helper loaded: cookie_helper
INFO - 2023-06-27 17:16:04 --> Database Driver Class Initialized
INFO - 2023-06-27 17:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 17:16:04 --> Parser Class Initialized
INFO - 2023-06-27 17:16:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 17:16:04 --> Pagination Class Initialized
INFO - 2023-06-27 17:16:04 --> Form Validation Class Initialized
INFO - 2023-06-27 17:16:04 --> Controller Class Initialized
INFO - 2023-06-27 17:16:04 --> Model Class Initialized
DEBUG - 2023-06-27 17:16:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:16:04 --> Model Class Initialized
DEBUG - 2023-06-27 17:16:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:16:04 --> Model Class Initialized
INFO - 2023-06-27 17:16:04 --> Model Class Initialized
INFO - 2023-06-27 17:16:04 --> Model Class Initialized
INFO - 2023-06-27 17:16:04 --> Model Class Initialized
DEBUG - 2023-06-27 17:16:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 17:16:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:16:04 --> Model Class Initialized
INFO - 2023-06-27 17:16:04 --> Model Class Initialized
INFO - 2023-06-27 17:16:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-27 17:16:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:16:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 17:16:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 17:16:04 --> Model Class Initialized
INFO - 2023-06-27 17:16:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 17:16:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 17:16:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 17:16:04 --> Final output sent to browser
DEBUG - 2023-06-27 17:16:04 --> Total execution time: 0.0784
ERROR - 2023-06-27 17:16:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 17:16:08 --> Config Class Initialized
INFO - 2023-06-27 17:16:08 --> Hooks Class Initialized
DEBUG - 2023-06-27 17:16:08 --> UTF-8 Support Enabled
INFO - 2023-06-27 17:16:08 --> Utf8 Class Initialized
INFO - 2023-06-27 17:16:08 --> URI Class Initialized
INFO - 2023-06-27 17:16:08 --> Router Class Initialized
INFO - 2023-06-27 17:16:08 --> Output Class Initialized
INFO - 2023-06-27 17:16:08 --> Security Class Initialized
DEBUG - 2023-06-27 17:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 17:16:08 --> Input Class Initialized
INFO - 2023-06-27 17:16:08 --> Language Class Initialized
INFO - 2023-06-27 17:16:08 --> Loader Class Initialized
INFO - 2023-06-27 17:16:08 --> Helper loaded: url_helper
INFO - 2023-06-27 17:16:08 --> Helper loaded: file_helper
INFO - 2023-06-27 17:16:08 --> Helper loaded: html_helper
INFO - 2023-06-27 17:16:08 --> Helper loaded: text_helper
INFO - 2023-06-27 17:16:08 --> Helper loaded: form_helper
INFO - 2023-06-27 17:16:08 --> Helper loaded: lang_helper
INFO - 2023-06-27 17:16:08 --> Helper loaded: security_helper
INFO - 2023-06-27 17:16:08 --> Helper loaded: cookie_helper
INFO - 2023-06-27 17:16:08 --> Database Driver Class Initialized
INFO - 2023-06-27 17:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 17:16:08 --> Parser Class Initialized
INFO - 2023-06-27 17:16:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 17:16:08 --> Pagination Class Initialized
INFO - 2023-06-27 17:16:08 --> Form Validation Class Initialized
INFO - 2023-06-27 17:16:08 --> Controller Class Initialized
INFO - 2023-06-27 17:16:08 --> Model Class Initialized
DEBUG - 2023-06-27 17:16:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 17:16:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:16:08 --> Model Class Initialized
DEBUG - 2023-06-27 17:16:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:16:08 --> Model Class Initialized
INFO - 2023-06-27 17:16:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-27 17:16:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:16:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-27 17:16:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-27 17:16:09 --> Model Class Initialized
INFO - 2023-06-27 17:16:09 --> Model Class Initialized
INFO - 2023-06-27 17:16:09 --> Model Class Initialized
INFO - 2023-06-27 17:16:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-27 17:16:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-27 17:16:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-27 17:16:09 --> Final output sent to browser
DEBUG - 2023-06-27 17:16:09 --> Total execution time: 0.0727
ERROR - 2023-06-27 17:16:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 17:16:09 --> Config Class Initialized
INFO - 2023-06-27 17:16:09 --> Hooks Class Initialized
DEBUG - 2023-06-27 17:16:09 --> UTF-8 Support Enabled
INFO - 2023-06-27 17:16:09 --> Utf8 Class Initialized
INFO - 2023-06-27 17:16:09 --> URI Class Initialized
INFO - 2023-06-27 17:16:09 --> Router Class Initialized
INFO - 2023-06-27 17:16:09 --> Output Class Initialized
INFO - 2023-06-27 17:16:09 --> Security Class Initialized
DEBUG - 2023-06-27 17:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 17:16:09 --> Input Class Initialized
INFO - 2023-06-27 17:16:09 --> Language Class Initialized
INFO - 2023-06-27 17:16:09 --> Loader Class Initialized
INFO - 2023-06-27 17:16:09 --> Helper loaded: url_helper
INFO - 2023-06-27 17:16:09 --> Helper loaded: file_helper
INFO - 2023-06-27 17:16:09 --> Helper loaded: html_helper
INFO - 2023-06-27 17:16:09 --> Helper loaded: text_helper
INFO - 2023-06-27 17:16:09 --> Helper loaded: form_helper
INFO - 2023-06-27 17:16:09 --> Helper loaded: lang_helper
INFO - 2023-06-27 17:16:09 --> Helper loaded: security_helper
INFO - 2023-06-27 17:16:09 --> Helper loaded: cookie_helper
INFO - 2023-06-27 17:16:09 --> Database Driver Class Initialized
INFO - 2023-06-27 17:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 17:16:09 --> Parser Class Initialized
INFO - 2023-06-27 17:16:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 17:16:09 --> Pagination Class Initialized
INFO - 2023-06-27 17:16:09 --> Form Validation Class Initialized
INFO - 2023-06-27 17:16:09 --> Controller Class Initialized
INFO - 2023-06-27 17:16:09 --> Model Class Initialized
DEBUG - 2023-06-27 17:16:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-27 17:16:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:16:09 --> Model Class Initialized
DEBUG - 2023-06-27 17:16:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-27 17:16:09 --> Model Class Initialized
INFO - 2023-06-27 17:16:09 --> Final output sent to browser
DEBUG - 2023-06-27 17:16:09 --> Total execution time: 0.0390
ERROR - 2023-06-27 17:16:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-27 17:16:37 --> Config Class Initialized
INFO - 2023-06-27 17:16:37 --> Hooks Class Initialized
DEBUG - 2023-06-27 17:16:37 --> UTF-8 Support Enabled
INFO - 2023-06-27 17:16:37 --> Utf8 Class Initialized
INFO - 2023-06-27 17:16:37 --> URI Class Initialized
INFO - 2023-06-27 17:16:37 --> Router Class Initialized
INFO - 2023-06-27 17:16:37 --> Output Class Initialized
INFO - 2023-06-27 17:16:37 --> Security Class Initialized
DEBUG - 2023-06-27 17:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-27 17:16:37 --> Input Class Initialized
INFO - 2023-06-27 17:16:37 --> Language Class Initialized
INFO - 2023-06-27 17:16:37 --> Loader Class Initialized
INFO - 2023-06-27 17:16:37 --> Helper loaded: url_helper
INFO - 2023-06-27 17:16:37 --> Helper loaded: file_helper
INFO - 2023-06-27 17:16:37 --> Helper loaded: html_helper
INFO - 2023-06-27 17:16:37 --> Helper loaded: text_helper
INFO - 2023-06-27 17:16:37 --> Helper loaded: form_helper
INFO - 2023-06-27 17:16:37 --> Helper loaded: lang_helper
INFO - 2023-06-27 17:16:37 --> Helper loaded: security_helper
INFO - 2023-06-27 17:16:37 --> Helper loaded: cookie_helper
INFO - 2023-06-27 17:16:37 --> Database Driver Class Initialized
INFO - 2023-06-27 17:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-27 17:16:37 --> Parser Class Initialized
INFO - 2023-06-27 17:16:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-27 17:16:37 --> Pagination Class Initialized
INFO - 2023-06-27 17:16:37 --> Form Validation Class Initialized
INFO - 2023-06-27 17:16:37 --> Controller Class Initialized
