<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-23 14:20:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-23 14:20:27 --> Config Class Initialized
INFO - 2023-06-23 14:20:27 --> Hooks Class Initialized
DEBUG - 2023-06-23 14:20:27 --> UTF-8 Support Enabled
INFO - 2023-06-23 14:20:27 --> Utf8 Class Initialized
INFO - 2023-06-23 14:20:27 --> URI Class Initialized
DEBUG - 2023-06-23 14:20:27 --> No URI present. Default controller set.
INFO - 2023-06-23 14:20:27 --> Router Class Initialized
INFO - 2023-06-23 14:20:27 --> Output Class Initialized
INFO - 2023-06-23 14:20:27 --> Security Class Initialized
DEBUG - 2023-06-23 14:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 14:20:27 --> Input Class Initialized
INFO - 2023-06-23 14:20:27 --> Language Class Initialized
INFO - 2023-06-23 14:20:27 --> Loader Class Initialized
INFO - 2023-06-23 14:20:27 --> Helper loaded: url_helper
INFO - 2023-06-23 14:20:27 --> Helper loaded: file_helper
INFO - 2023-06-23 14:20:27 --> Helper loaded: html_helper
INFO - 2023-06-23 14:20:27 --> Helper loaded: text_helper
INFO - 2023-06-23 14:20:27 --> Helper loaded: form_helper
INFO - 2023-06-23 14:20:27 --> Helper loaded: lang_helper
INFO - 2023-06-23 14:20:27 --> Helper loaded: security_helper
INFO - 2023-06-23 14:20:27 --> Helper loaded: cookie_helper
INFO - 2023-06-23 14:20:27 --> Database Driver Class Initialized
INFO - 2023-06-23 14:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 14:20:27 --> Parser Class Initialized
INFO - 2023-06-23 14:20:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-23 14:20:27 --> Pagination Class Initialized
INFO - 2023-06-23 14:20:27 --> Form Validation Class Initialized
INFO - 2023-06-23 14:20:27 --> Controller Class Initialized
INFO - 2023-06-23 14:20:27 --> Model Class Initialized
DEBUG - 2023-06-23 14:20:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-23 14:20:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-23 14:20:27 --> Config Class Initialized
INFO - 2023-06-23 14:20:27 --> Hooks Class Initialized
DEBUG - 2023-06-23 14:20:27 --> UTF-8 Support Enabled
INFO - 2023-06-23 14:20:27 --> Utf8 Class Initialized
INFO - 2023-06-23 14:20:27 --> URI Class Initialized
INFO - 2023-06-23 14:20:27 --> Router Class Initialized
INFO - 2023-06-23 14:20:27 --> Output Class Initialized
INFO - 2023-06-23 14:20:27 --> Security Class Initialized
DEBUG - 2023-06-23 14:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 14:20:27 --> Input Class Initialized
INFO - 2023-06-23 14:20:27 --> Language Class Initialized
INFO - 2023-06-23 14:20:27 --> Loader Class Initialized
INFO - 2023-06-23 14:20:27 --> Helper loaded: url_helper
INFO - 2023-06-23 14:20:27 --> Helper loaded: file_helper
INFO - 2023-06-23 14:20:27 --> Helper loaded: html_helper
INFO - 2023-06-23 14:20:27 --> Helper loaded: text_helper
INFO - 2023-06-23 14:20:27 --> Helper loaded: form_helper
INFO - 2023-06-23 14:20:27 --> Helper loaded: lang_helper
INFO - 2023-06-23 14:20:27 --> Helper loaded: security_helper
INFO - 2023-06-23 14:20:27 --> Helper loaded: cookie_helper
INFO - 2023-06-23 14:20:27 --> Database Driver Class Initialized
INFO - 2023-06-23 14:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 14:20:27 --> Parser Class Initialized
INFO - 2023-06-23 14:20:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-23 14:20:27 --> Pagination Class Initialized
INFO - 2023-06-23 14:20:27 --> Form Validation Class Initialized
INFO - 2023-06-23 14:20:27 --> Controller Class Initialized
INFO - 2023-06-23 14:20:27 --> Model Class Initialized
DEBUG - 2023-06-23 14:20:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:20:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-23 14:20:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:20:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-23 14:20:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-23 14:20:27 --> Model Class Initialized
INFO - 2023-06-23 14:20:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-23 14:20:27 --> Final output sent to browser
DEBUG - 2023-06-23 14:20:27 --> Total execution time: 0.0368
ERROR - 2023-06-23 14:20:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-23 14:20:40 --> Config Class Initialized
INFO - 2023-06-23 14:20:40 --> Hooks Class Initialized
DEBUG - 2023-06-23 14:20:40 --> UTF-8 Support Enabled
INFO - 2023-06-23 14:20:40 --> Utf8 Class Initialized
INFO - 2023-06-23 14:20:40 --> URI Class Initialized
INFO - 2023-06-23 14:20:40 --> Router Class Initialized
INFO - 2023-06-23 14:20:40 --> Output Class Initialized
INFO - 2023-06-23 14:20:40 --> Security Class Initialized
DEBUG - 2023-06-23 14:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 14:20:40 --> Input Class Initialized
INFO - 2023-06-23 14:20:40 --> Language Class Initialized
INFO - 2023-06-23 14:20:40 --> Loader Class Initialized
INFO - 2023-06-23 14:20:40 --> Helper loaded: url_helper
INFO - 2023-06-23 14:20:40 --> Helper loaded: file_helper
INFO - 2023-06-23 14:20:40 --> Helper loaded: html_helper
INFO - 2023-06-23 14:20:40 --> Helper loaded: text_helper
INFO - 2023-06-23 14:20:40 --> Helper loaded: form_helper
INFO - 2023-06-23 14:20:40 --> Helper loaded: lang_helper
INFO - 2023-06-23 14:20:40 --> Helper loaded: security_helper
INFO - 2023-06-23 14:20:40 --> Helper loaded: cookie_helper
INFO - 2023-06-23 14:20:40 --> Database Driver Class Initialized
INFO - 2023-06-23 14:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 14:20:40 --> Parser Class Initialized
INFO - 2023-06-23 14:20:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-23 14:20:40 --> Pagination Class Initialized
INFO - 2023-06-23 14:20:40 --> Form Validation Class Initialized
INFO - 2023-06-23 14:20:40 --> Controller Class Initialized
INFO - 2023-06-23 14:20:40 --> Model Class Initialized
DEBUG - 2023-06-23 14:20:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:20:40 --> Model Class Initialized
INFO - 2023-06-23 14:20:40 --> Final output sent to browser
DEBUG - 2023-06-23 14:20:40 --> Total execution time: 0.0207
ERROR - 2023-06-23 14:20:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-23 14:20:41 --> Config Class Initialized
INFO - 2023-06-23 14:20:41 --> Hooks Class Initialized
DEBUG - 2023-06-23 14:20:41 --> UTF-8 Support Enabled
INFO - 2023-06-23 14:20:41 --> Utf8 Class Initialized
INFO - 2023-06-23 14:20:41 --> URI Class Initialized
DEBUG - 2023-06-23 14:20:41 --> No URI present. Default controller set.
INFO - 2023-06-23 14:20:41 --> Router Class Initialized
INFO - 2023-06-23 14:20:41 --> Output Class Initialized
INFO - 2023-06-23 14:20:41 --> Security Class Initialized
DEBUG - 2023-06-23 14:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 14:20:41 --> Input Class Initialized
INFO - 2023-06-23 14:20:41 --> Language Class Initialized
INFO - 2023-06-23 14:20:41 --> Loader Class Initialized
INFO - 2023-06-23 14:20:41 --> Helper loaded: url_helper
INFO - 2023-06-23 14:20:41 --> Helper loaded: file_helper
INFO - 2023-06-23 14:20:41 --> Helper loaded: html_helper
INFO - 2023-06-23 14:20:41 --> Helper loaded: text_helper
INFO - 2023-06-23 14:20:41 --> Helper loaded: form_helper
INFO - 2023-06-23 14:20:41 --> Helper loaded: lang_helper
INFO - 2023-06-23 14:20:41 --> Helper loaded: security_helper
INFO - 2023-06-23 14:20:41 --> Helper loaded: cookie_helper
INFO - 2023-06-23 14:20:41 --> Database Driver Class Initialized
INFO - 2023-06-23 14:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 14:20:41 --> Parser Class Initialized
INFO - 2023-06-23 14:20:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-23 14:20:41 --> Pagination Class Initialized
INFO - 2023-06-23 14:20:41 --> Form Validation Class Initialized
INFO - 2023-06-23 14:20:41 --> Controller Class Initialized
INFO - 2023-06-23 14:20:41 --> Model Class Initialized
DEBUG - 2023-06-23 14:20:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:20:41 --> Model Class Initialized
DEBUG - 2023-06-23 14:20:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:20:41 --> Model Class Initialized
INFO - 2023-06-23 14:20:41 --> Model Class Initialized
INFO - 2023-06-23 14:20:41 --> Model Class Initialized
INFO - 2023-06-23 14:20:41 --> Model Class Initialized
DEBUG - 2023-06-23 14:20:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-23 14:20:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:20:41 --> Model Class Initialized
INFO - 2023-06-23 14:20:41 --> Model Class Initialized
INFO - 2023-06-23 14:20:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-23 14:20:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:20:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-23 14:20:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-23 14:20:41 --> Model Class Initialized
INFO - 2023-06-23 14:20:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-23 14:20:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-23 14:20:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-23 14:20:41 --> Final output sent to browser
DEBUG - 2023-06-23 14:20:41 --> Total execution time: 0.0837
ERROR - 2023-06-23 14:21:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-23 14:21:02 --> Config Class Initialized
INFO - 2023-06-23 14:21:02 --> Hooks Class Initialized
DEBUG - 2023-06-23 14:21:02 --> UTF-8 Support Enabled
INFO - 2023-06-23 14:21:02 --> Utf8 Class Initialized
INFO - 2023-06-23 14:21:02 --> URI Class Initialized
INFO - 2023-06-23 14:21:02 --> Router Class Initialized
INFO - 2023-06-23 14:21:02 --> Output Class Initialized
INFO - 2023-06-23 14:21:02 --> Security Class Initialized
DEBUG - 2023-06-23 14:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 14:21:02 --> Input Class Initialized
INFO - 2023-06-23 14:21:02 --> Language Class Initialized
INFO - 2023-06-23 14:21:02 --> Loader Class Initialized
INFO - 2023-06-23 14:21:02 --> Helper loaded: url_helper
INFO - 2023-06-23 14:21:02 --> Helper loaded: file_helper
INFO - 2023-06-23 14:21:02 --> Helper loaded: html_helper
INFO - 2023-06-23 14:21:02 --> Helper loaded: text_helper
INFO - 2023-06-23 14:21:02 --> Helper loaded: form_helper
INFO - 2023-06-23 14:21:02 --> Helper loaded: lang_helper
INFO - 2023-06-23 14:21:02 --> Helper loaded: security_helper
INFO - 2023-06-23 14:21:02 --> Helper loaded: cookie_helper
INFO - 2023-06-23 14:21:02 --> Database Driver Class Initialized
INFO - 2023-06-23 14:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 14:21:02 --> Parser Class Initialized
INFO - 2023-06-23 14:21:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-23 14:21:02 --> Pagination Class Initialized
INFO - 2023-06-23 14:21:02 --> Form Validation Class Initialized
INFO - 2023-06-23 14:21:02 --> Controller Class Initialized
INFO - 2023-06-23 14:21:02 --> Model Class Initialized
DEBUG - 2023-06-23 14:21:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-23 14:21:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:21:02 --> Model Class Initialized
DEBUG - 2023-06-23 14:21:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:21:02 --> Model Class Initialized
INFO - 2023-06-23 14:21:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-23 14:21:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:21:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-23 14:21:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-23 14:21:03 --> Model Class Initialized
INFO - 2023-06-23 14:21:03 --> Model Class Initialized
INFO - 2023-06-23 14:21:03 --> Model Class Initialized
INFO - 2023-06-23 14:21:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-23 14:21:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-23 14:21:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-23 14:21:03 --> Final output sent to browser
DEBUG - 2023-06-23 14:21:03 --> Total execution time: 0.0777
ERROR - 2023-06-23 14:21:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-23 14:21:04 --> Config Class Initialized
INFO - 2023-06-23 14:21:04 --> Hooks Class Initialized
DEBUG - 2023-06-23 14:21:04 --> UTF-8 Support Enabled
INFO - 2023-06-23 14:21:04 --> Utf8 Class Initialized
INFO - 2023-06-23 14:21:04 --> URI Class Initialized
INFO - 2023-06-23 14:21:04 --> Router Class Initialized
INFO - 2023-06-23 14:21:04 --> Output Class Initialized
INFO - 2023-06-23 14:21:04 --> Security Class Initialized
DEBUG - 2023-06-23 14:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 14:21:04 --> Input Class Initialized
INFO - 2023-06-23 14:21:04 --> Language Class Initialized
INFO - 2023-06-23 14:21:04 --> Loader Class Initialized
INFO - 2023-06-23 14:21:04 --> Helper loaded: url_helper
INFO - 2023-06-23 14:21:04 --> Helper loaded: file_helper
INFO - 2023-06-23 14:21:04 --> Helper loaded: html_helper
INFO - 2023-06-23 14:21:04 --> Helper loaded: text_helper
INFO - 2023-06-23 14:21:04 --> Helper loaded: form_helper
INFO - 2023-06-23 14:21:04 --> Helper loaded: lang_helper
INFO - 2023-06-23 14:21:04 --> Helper loaded: security_helper
INFO - 2023-06-23 14:21:04 --> Helper loaded: cookie_helper
INFO - 2023-06-23 14:21:04 --> Database Driver Class Initialized
INFO - 2023-06-23 14:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 14:21:04 --> Parser Class Initialized
INFO - 2023-06-23 14:21:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-23 14:21:04 --> Pagination Class Initialized
INFO - 2023-06-23 14:21:04 --> Form Validation Class Initialized
INFO - 2023-06-23 14:21:04 --> Controller Class Initialized
INFO - 2023-06-23 14:21:04 --> Model Class Initialized
DEBUG - 2023-06-23 14:21:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-23 14:21:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:21:04 --> Model Class Initialized
DEBUG - 2023-06-23 14:21:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:21:04 --> Model Class Initialized
INFO - 2023-06-23 14:21:04 --> Final output sent to browser
DEBUG - 2023-06-23 14:21:04 --> Total execution time: 0.0460
ERROR - 2023-06-23 14:21:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-23 14:21:14 --> Config Class Initialized
INFO - 2023-06-23 14:21:14 --> Hooks Class Initialized
DEBUG - 2023-06-23 14:21:14 --> UTF-8 Support Enabled
INFO - 2023-06-23 14:21:14 --> Utf8 Class Initialized
INFO - 2023-06-23 14:21:14 --> URI Class Initialized
DEBUG - 2023-06-23 14:21:14 --> No URI present. Default controller set.
INFO - 2023-06-23 14:21:14 --> Router Class Initialized
INFO - 2023-06-23 14:21:14 --> Output Class Initialized
INFO - 2023-06-23 14:21:14 --> Security Class Initialized
DEBUG - 2023-06-23 14:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 14:21:14 --> Input Class Initialized
INFO - 2023-06-23 14:21:14 --> Language Class Initialized
INFO - 2023-06-23 14:21:14 --> Loader Class Initialized
INFO - 2023-06-23 14:21:14 --> Helper loaded: url_helper
INFO - 2023-06-23 14:21:14 --> Helper loaded: file_helper
INFO - 2023-06-23 14:21:14 --> Helper loaded: html_helper
INFO - 2023-06-23 14:21:14 --> Helper loaded: text_helper
INFO - 2023-06-23 14:21:14 --> Helper loaded: form_helper
INFO - 2023-06-23 14:21:14 --> Helper loaded: lang_helper
INFO - 2023-06-23 14:21:14 --> Helper loaded: security_helper
INFO - 2023-06-23 14:21:14 --> Helper loaded: cookie_helper
INFO - 2023-06-23 14:21:14 --> Database Driver Class Initialized
INFO - 2023-06-23 14:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 14:21:14 --> Parser Class Initialized
INFO - 2023-06-23 14:21:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-23 14:21:14 --> Pagination Class Initialized
INFO - 2023-06-23 14:21:14 --> Form Validation Class Initialized
INFO - 2023-06-23 14:21:14 --> Controller Class Initialized
INFO - 2023-06-23 14:21:14 --> Model Class Initialized
DEBUG - 2023-06-23 14:21:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:21:14 --> Model Class Initialized
DEBUG - 2023-06-23 14:21:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:21:14 --> Model Class Initialized
INFO - 2023-06-23 14:21:14 --> Model Class Initialized
INFO - 2023-06-23 14:21:14 --> Model Class Initialized
INFO - 2023-06-23 14:21:14 --> Model Class Initialized
DEBUG - 2023-06-23 14:21:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-23 14:21:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:21:14 --> Model Class Initialized
INFO - 2023-06-23 14:21:14 --> Model Class Initialized
INFO - 2023-06-23 14:21:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-23 14:21:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:21:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-23 14:21:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-23 14:21:14 --> Model Class Initialized
INFO - 2023-06-23 14:21:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-23 14:21:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-23 14:21:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-23 14:21:14 --> Final output sent to browser
DEBUG - 2023-06-23 14:21:14 --> Total execution time: 0.0769
ERROR - 2023-06-23 14:21:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-23 14:21:19 --> Config Class Initialized
INFO - 2023-06-23 14:21:19 --> Hooks Class Initialized
DEBUG - 2023-06-23 14:21:19 --> UTF-8 Support Enabled
INFO - 2023-06-23 14:21:19 --> Utf8 Class Initialized
INFO - 2023-06-23 14:21:19 --> URI Class Initialized
INFO - 2023-06-23 14:21:19 --> Router Class Initialized
INFO - 2023-06-23 14:21:19 --> Output Class Initialized
INFO - 2023-06-23 14:21:19 --> Security Class Initialized
DEBUG - 2023-06-23 14:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 14:21:19 --> Input Class Initialized
INFO - 2023-06-23 14:21:19 --> Language Class Initialized
INFO - 2023-06-23 14:21:19 --> Loader Class Initialized
INFO - 2023-06-23 14:21:19 --> Helper loaded: url_helper
INFO - 2023-06-23 14:21:19 --> Helper loaded: file_helper
INFO - 2023-06-23 14:21:19 --> Helper loaded: html_helper
INFO - 2023-06-23 14:21:19 --> Helper loaded: text_helper
INFO - 2023-06-23 14:21:19 --> Helper loaded: form_helper
INFO - 2023-06-23 14:21:19 --> Helper loaded: lang_helper
INFO - 2023-06-23 14:21:19 --> Helper loaded: security_helper
INFO - 2023-06-23 14:21:19 --> Helper loaded: cookie_helper
INFO - 2023-06-23 14:21:19 --> Database Driver Class Initialized
INFO - 2023-06-23 14:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 14:21:19 --> Parser Class Initialized
INFO - 2023-06-23 14:21:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-23 14:21:19 --> Pagination Class Initialized
INFO - 2023-06-23 14:21:19 --> Form Validation Class Initialized
INFO - 2023-06-23 14:21:19 --> Controller Class Initialized
INFO - 2023-06-23 14:21:19 --> Model Class Initialized
DEBUG - 2023-06-23 14:21:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:21:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-23 14:21:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:21:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-23 14:21:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-23 14:21:19 --> Model Class Initialized
INFO - 2023-06-23 14:21:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-23 14:21:19 --> Final output sent to browser
DEBUG - 2023-06-23 14:21:19 --> Total execution time: 0.0284
ERROR - 2023-06-23 14:21:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-23 14:21:19 --> Config Class Initialized
INFO - 2023-06-23 14:21:19 --> Hooks Class Initialized
DEBUG - 2023-06-23 14:21:19 --> UTF-8 Support Enabled
INFO - 2023-06-23 14:21:19 --> Utf8 Class Initialized
INFO - 2023-06-23 14:21:19 --> URI Class Initialized
INFO - 2023-06-23 14:21:19 --> Router Class Initialized
INFO - 2023-06-23 14:21:19 --> Output Class Initialized
INFO - 2023-06-23 14:21:19 --> Security Class Initialized
DEBUG - 2023-06-23 14:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 14:21:19 --> Input Class Initialized
INFO - 2023-06-23 14:21:19 --> Language Class Initialized
INFO - 2023-06-23 14:21:19 --> Loader Class Initialized
INFO - 2023-06-23 14:21:19 --> Helper loaded: url_helper
INFO - 2023-06-23 14:21:19 --> Helper loaded: file_helper
INFO - 2023-06-23 14:21:19 --> Helper loaded: html_helper
INFO - 2023-06-23 14:21:19 --> Helper loaded: text_helper
INFO - 2023-06-23 14:21:19 --> Helper loaded: form_helper
INFO - 2023-06-23 14:21:19 --> Helper loaded: lang_helper
INFO - 2023-06-23 14:21:19 --> Helper loaded: security_helper
INFO - 2023-06-23 14:21:19 --> Helper loaded: cookie_helper
INFO - 2023-06-23 14:21:19 --> Database Driver Class Initialized
INFO - 2023-06-23 14:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 14:21:19 --> Parser Class Initialized
INFO - 2023-06-23 14:21:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-23 14:21:19 --> Pagination Class Initialized
INFO - 2023-06-23 14:21:19 --> Form Validation Class Initialized
INFO - 2023-06-23 14:21:19 --> Controller Class Initialized
INFO - 2023-06-23 14:21:19 --> Model Class Initialized
DEBUG - 2023-06-23 14:21:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:21:19 --> Model Class Initialized
DEBUG - 2023-06-23 14:21:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:21:19 --> Model Class Initialized
INFO - 2023-06-23 14:21:19 --> Model Class Initialized
INFO - 2023-06-23 14:21:19 --> Model Class Initialized
INFO - 2023-06-23 14:21:19 --> Model Class Initialized
DEBUG - 2023-06-23 14:21:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-23 14:21:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:21:19 --> Model Class Initialized
INFO - 2023-06-23 14:21:19 --> Model Class Initialized
INFO - 2023-06-23 14:21:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-23 14:21:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:21:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-23 14:21:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-23 14:21:19 --> Model Class Initialized
INFO - 2023-06-23 14:21:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-23 14:21:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-23 14:21:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-23 14:21:19 --> Final output sent to browser
DEBUG - 2023-06-23 14:21:19 --> Total execution time: 0.0963
ERROR - 2023-06-23 14:21:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-23 14:21:23 --> Config Class Initialized
INFO - 2023-06-23 14:21:23 --> Hooks Class Initialized
DEBUG - 2023-06-23 14:21:23 --> UTF-8 Support Enabled
INFO - 2023-06-23 14:21:23 --> Utf8 Class Initialized
INFO - 2023-06-23 14:21:23 --> URI Class Initialized
INFO - 2023-06-23 14:21:23 --> Router Class Initialized
INFO - 2023-06-23 14:21:23 --> Output Class Initialized
INFO - 2023-06-23 14:21:23 --> Security Class Initialized
DEBUG - 2023-06-23 14:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 14:21:23 --> Input Class Initialized
INFO - 2023-06-23 14:21:23 --> Language Class Initialized
INFO - 2023-06-23 14:21:23 --> Loader Class Initialized
INFO - 2023-06-23 14:21:23 --> Helper loaded: url_helper
INFO - 2023-06-23 14:21:23 --> Helper loaded: file_helper
INFO - 2023-06-23 14:21:23 --> Helper loaded: html_helper
INFO - 2023-06-23 14:21:23 --> Helper loaded: text_helper
INFO - 2023-06-23 14:21:23 --> Helper loaded: form_helper
INFO - 2023-06-23 14:21:23 --> Helper loaded: lang_helper
INFO - 2023-06-23 14:21:23 --> Helper loaded: security_helper
INFO - 2023-06-23 14:21:23 --> Helper loaded: cookie_helper
INFO - 2023-06-23 14:21:23 --> Database Driver Class Initialized
INFO - 2023-06-23 14:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 14:21:23 --> Parser Class Initialized
INFO - 2023-06-23 14:21:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-23 14:21:23 --> Pagination Class Initialized
INFO - 2023-06-23 14:21:23 --> Form Validation Class Initialized
INFO - 2023-06-23 14:21:23 --> Controller Class Initialized
INFO - 2023-06-23 14:21:23 --> Model Class Initialized
DEBUG - 2023-06-23 14:21:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-23 14:21:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:21:23 --> Model Class Initialized
DEBUG - 2023-06-23 14:21:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:21:23 --> Model Class Initialized
INFO - 2023-06-23 14:21:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-23 14:21:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:21:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-23 14:21:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-23 14:21:23 --> Model Class Initialized
INFO - 2023-06-23 14:21:23 --> Model Class Initialized
INFO - 2023-06-23 14:21:23 --> Model Class Initialized
INFO - 2023-06-23 14:21:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-23 14:21:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-23 14:21:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-23 14:21:23 --> Final output sent to browser
DEBUG - 2023-06-23 14:21:23 --> Total execution time: 0.0688
ERROR - 2023-06-23 14:21:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-23 14:21:24 --> Config Class Initialized
INFO - 2023-06-23 14:21:24 --> Hooks Class Initialized
DEBUG - 2023-06-23 14:21:24 --> UTF-8 Support Enabled
INFO - 2023-06-23 14:21:24 --> Utf8 Class Initialized
INFO - 2023-06-23 14:21:24 --> URI Class Initialized
INFO - 2023-06-23 14:21:24 --> Router Class Initialized
INFO - 2023-06-23 14:21:24 --> Output Class Initialized
INFO - 2023-06-23 14:21:24 --> Security Class Initialized
DEBUG - 2023-06-23 14:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 14:21:24 --> Input Class Initialized
INFO - 2023-06-23 14:21:24 --> Language Class Initialized
INFO - 2023-06-23 14:21:24 --> Loader Class Initialized
INFO - 2023-06-23 14:21:24 --> Helper loaded: url_helper
INFO - 2023-06-23 14:21:24 --> Helper loaded: file_helper
INFO - 2023-06-23 14:21:24 --> Helper loaded: html_helper
INFO - 2023-06-23 14:21:24 --> Helper loaded: text_helper
INFO - 2023-06-23 14:21:24 --> Helper loaded: form_helper
INFO - 2023-06-23 14:21:24 --> Helper loaded: lang_helper
INFO - 2023-06-23 14:21:24 --> Helper loaded: security_helper
INFO - 2023-06-23 14:21:24 --> Helper loaded: cookie_helper
INFO - 2023-06-23 14:21:24 --> Database Driver Class Initialized
INFO - 2023-06-23 14:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 14:21:24 --> Parser Class Initialized
INFO - 2023-06-23 14:21:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-23 14:21:24 --> Pagination Class Initialized
INFO - 2023-06-23 14:21:24 --> Form Validation Class Initialized
INFO - 2023-06-23 14:21:24 --> Controller Class Initialized
INFO - 2023-06-23 14:21:24 --> Model Class Initialized
DEBUG - 2023-06-23 14:21:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-23 14:21:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:21:24 --> Model Class Initialized
DEBUG - 2023-06-23 14:21:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:21:24 --> Model Class Initialized
INFO - 2023-06-23 14:21:24 --> Final output sent to browser
DEBUG - 2023-06-23 14:21:24 --> Total execution time: 0.0366
ERROR - 2023-06-23 14:21:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-23 14:21:42 --> Config Class Initialized
INFO - 2023-06-23 14:21:42 --> Hooks Class Initialized
DEBUG - 2023-06-23 14:21:42 --> UTF-8 Support Enabled
INFO - 2023-06-23 14:21:42 --> Utf8 Class Initialized
INFO - 2023-06-23 14:21:42 --> URI Class Initialized
INFO - 2023-06-23 14:21:42 --> Router Class Initialized
INFO - 2023-06-23 14:21:42 --> Output Class Initialized
INFO - 2023-06-23 14:21:42 --> Security Class Initialized
DEBUG - 2023-06-23 14:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 14:21:42 --> Input Class Initialized
INFO - 2023-06-23 14:21:42 --> Language Class Initialized
INFO - 2023-06-23 14:21:42 --> Loader Class Initialized
INFO - 2023-06-23 14:21:42 --> Helper loaded: url_helper
INFO - 2023-06-23 14:21:42 --> Helper loaded: file_helper
INFO - 2023-06-23 14:21:42 --> Helper loaded: html_helper
INFO - 2023-06-23 14:21:42 --> Helper loaded: text_helper
INFO - 2023-06-23 14:21:42 --> Helper loaded: form_helper
INFO - 2023-06-23 14:21:42 --> Helper loaded: lang_helper
INFO - 2023-06-23 14:21:42 --> Helper loaded: security_helper
INFO - 2023-06-23 14:21:42 --> Helper loaded: cookie_helper
INFO - 2023-06-23 14:21:42 --> Database Driver Class Initialized
INFO - 2023-06-23 14:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 14:21:42 --> Parser Class Initialized
INFO - 2023-06-23 14:21:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-23 14:21:42 --> Pagination Class Initialized
INFO - 2023-06-23 14:21:42 --> Form Validation Class Initialized
INFO - 2023-06-23 14:21:42 --> Controller Class Initialized
INFO - 2023-06-23 14:21:42 --> Model Class Initialized
DEBUG - 2023-06-23 14:21:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-23 14:21:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:21:42 --> Model Class Initialized
DEBUG - 2023-06-23 14:21:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:21:42 --> Model Class Initialized
INFO - 2023-06-23 14:21:42 --> Final output sent to browser
DEBUG - 2023-06-23 14:21:42 --> Total execution time: 0.0435
ERROR - 2023-06-23 14:21:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-23 14:21:44 --> Config Class Initialized
INFO - 2023-06-23 14:21:44 --> Hooks Class Initialized
DEBUG - 2023-06-23 14:21:44 --> UTF-8 Support Enabled
INFO - 2023-06-23 14:21:44 --> Utf8 Class Initialized
INFO - 2023-06-23 14:21:44 --> URI Class Initialized
INFO - 2023-06-23 14:21:44 --> Router Class Initialized
INFO - 2023-06-23 14:21:44 --> Output Class Initialized
INFO - 2023-06-23 14:21:44 --> Security Class Initialized
DEBUG - 2023-06-23 14:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 14:21:44 --> Input Class Initialized
INFO - 2023-06-23 14:21:44 --> Language Class Initialized
INFO - 2023-06-23 14:21:44 --> Loader Class Initialized
INFO - 2023-06-23 14:21:44 --> Helper loaded: url_helper
INFO - 2023-06-23 14:21:44 --> Helper loaded: file_helper
INFO - 2023-06-23 14:21:44 --> Helper loaded: html_helper
INFO - 2023-06-23 14:21:44 --> Helper loaded: text_helper
INFO - 2023-06-23 14:21:44 --> Helper loaded: form_helper
INFO - 2023-06-23 14:21:44 --> Helper loaded: lang_helper
INFO - 2023-06-23 14:21:44 --> Helper loaded: security_helper
INFO - 2023-06-23 14:21:44 --> Helper loaded: cookie_helper
INFO - 2023-06-23 14:21:44 --> Database Driver Class Initialized
INFO - 2023-06-23 14:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 14:21:44 --> Parser Class Initialized
INFO - 2023-06-23 14:21:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-23 14:21:44 --> Pagination Class Initialized
INFO - 2023-06-23 14:21:44 --> Form Validation Class Initialized
INFO - 2023-06-23 14:21:44 --> Controller Class Initialized
INFO - 2023-06-23 14:21:44 --> Model Class Initialized
DEBUG - 2023-06-23 14:21:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-23 14:21:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:21:44 --> Model Class Initialized
DEBUG - 2023-06-23 14:21:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:21:44 --> Model Class Initialized
INFO - 2023-06-23 14:21:44 --> Final output sent to browser
DEBUG - 2023-06-23 14:21:44 --> Total execution time: 0.0358
ERROR - 2023-06-23 14:22:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-23 14:22:00 --> Config Class Initialized
INFO - 2023-06-23 14:22:00 --> Hooks Class Initialized
DEBUG - 2023-06-23 14:22:00 --> UTF-8 Support Enabled
INFO - 2023-06-23 14:22:00 --> Utf8 Class Initialized
INFO - 2023-06-23 14:22:00 --> URI Class Initialized
INFO - 2023-06-23 14:22:00 --> Router Class Initialized
INFO - 2023-06-23 14:22:00 --> Output Class Initialized
INFO - 2023-06-23 14:22:00 --> Security Class Initialized
DEBUG - 2023-06-23 14:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 14:22:00 --> Input Class Initialized
INFO - 2023-06-23 14:22:00 --> Language Class Initialized
INFO - 2023-06-23 14:22:00 --> Loader Class Initialized
INFO - 2023-06-23 14:22:00 --> Helper loaded: url_helper
INFO - 2023-06-23 14:22:00 --> Helper loaded: file_helper
INFO - 2023-06-23 14:22:00 --> Helper loaded: html_helper
INFO - 2023-06-23 14:22:00 --> Helper loaded: text_helper
INFO - 2023-06-23 14:22:00 --> Helper loaded: form_helper
INFO - 2023-06-23 14:22:00 --> Helper loaded: lang_helper
INFO - 2023-06-23 14:22:00 --> Helper loaded: security_helper
INFO - 2023-06-23 14:22:00 --> Helper loaded: cookie_helper
INFO - 2023-06-23 14:22:00 --> Database Driver Class Initialized
INFO - 2023-06-23 14:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 14:22:00 --> Parser Class Initialized
INFO - 2023-06-23 14:22:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-23 14:22:00 --> Pagination Class Initialized
INFO - 2023-06-23 14:22:00 --> Form Validation Class Initialized
INFO - 2023-06-23 14:22:00 --> Controller Class Initialized
INFO - 2023-06-23 14:22:00 --> Model Class Initialized
DEBUG - 2023-06-23 14:22:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-23 14:22:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:22:00 --> Model Class Initialized
DEBUG - 2023-06-23 14:22:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:22:00 --> Model Class Initialized
INFO - 2023-06-23 14:22:00 --> Final output sent to browser
DEBUG - 2023-06-23 14:22:00 --> Total execution time: 0.0743
ERROR - 2023-06-23 14:23:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-23 14:23:16 --> Config Class Initialized
INFO - 2023-06-23 14:23:16 --> Hooks Class Initialized
DEBUG - 2023-06-23 14:23:16 --> UTF-8 Support Enabled
INFO - 2023-06-23 14:23:16 --> Utf8 Class Initialized
INFO - 2023-06-23 14:23:16 --> URI Class Initialized
INFO - 2023-06-23 14:23:16 --> Router Class Initialized
INFO - 2023-06-23 14:23:16 --> Output Class Initialized
INFO - 2023-06-23 14:23:16 --> Security Class Initialized
DEBUG - 2023-06-23 14:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 14:23:16 --> Input Class Initialized
INFO - 2023-06-23 14:23:16 --> Language Class Initialized
INFO - 2023-06-23 14:23:16 --> Loader Class Initialized
INFO - 2023-06-23 14:23:16 --> Helper loaded: url_helper
INFO - 2023-06-23 14:23:16 --> Helper loaded: file_helper
INFO - 2023-06-23 14:23:16 --> Helper loaded: html_helper
INFO - 2023-06-23 14:23:16 --> Helper loaded: text_helper
INFO - 2023-06-23 14:23:16 --> Helper loaded: form_helper
INFO - 2023-06-23 14:23:16 --> Helper loaded: lang_helper
INFO - 2023-06-23 14:23:16 --> Helper loaded: security_helper
INFO - 2023-06-23 14:23:16 --> Helper loaded: cookie_helper
INFO - 2023-06-23 14:23:16 --> Database Driver Class Initialized
INFO - 2023-06-23 14:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 14:23:16 --> Parser Class Initialized
INFO - 2023-06-23 14:23:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-23 14:23:16 --> Pagination Class Initialized
INFO - 2023-06-23 14:23:16 --> Form Validation Class Initialized
INFO - 2023-06-23 14:23:16 --> Controller Class Initialized
INFO - 2023-06-23 14:23:16 --> Model Class Initialized
DEBUG - 2023-06-23 14:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:23:16 --> Model Class Initialized
DEBUG - 2023-06-23 14:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:23:16 --> Model Class Initialized
INFO - 2023-06-23 14:23:16 --> Model Class Initialized
INFO - 2023-06-23 14:23:16 --> Model Class Initialized
INFO - 2023-06-23 14:23:16 --> Model Class Initialized
DEBUG - 2023-06-23 14:23:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-23 14:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:23:16 --> Model Class Initialized
INFO - 2023-06-23 14:23:16 --> Model Class Initialized
INFO - 2023-06-23 14:23:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-23 14:23:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:23:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-23 14:23:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-23 14:23:16 --> Model Class Initialized
INFO - 2023-06-23 14:23:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-23 14:23:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-23 14:23:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-23 14:23:16 --> Final output sent to browser
DEBUG - 2023-06-23 14:23:16 --> Total execution time: 0.0790
ERROR - 2023-06-23 14:23:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-23 14:23:36 --> Config Class Initialized
INFO - 2023-06-23 14:23:36 --> Hooks Class Initialized
DEBUG - 2023-06-23 14:23:36 --> UTF-8 Support Enabled
INFO - 2023-06-23 14:23:36 --> Utf8 Class Initialized
INFO - 2023-06-23 14:23:36 --> URI Class Initialized
INFO - 2023-06-23 14:23:36 --> Router Class Initialized
INFO - 2023-06-23 14:23:36 --> Output Class Initialized
INFO - 2023-06-23 14:23:36 --> Security Class Initialized
DEBUG - 2023-06-23 14:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 14:23:36 --> Input Class Initialized
INFO - 2023-06-23 14:23:36 --> Language Class Initialized
INFO - 2023-06-23 14:23:36 --> Loader Class Initialized
INFO - 2023-06-23 14:23:36 --> Helper loaded: url_helper
INFO - 2023-06-23 14:23:36 --> Helper loaded: file_helper
INFO - 2023-06-23 14:23:36 --> Helper loaded: html_helper
INFO - 2023-06-23 14:23:36 --> Helper loaded: text_helper
INFO - 2023-06-23 14:23:36 --> Helper loaded: form_helper
INFO - 2023-06-23 14:23:36 --> Helper loaded: lang_helper
INFO - 2023-06-23 14:23:36 --> Helper loaded: security_helper
INFO - 2023-06-23 14:23:36 --> Helper loaded: cookie_helper
INFO - 2023-06-23 14:23:36 --> Database Driver Class Initialized
INFO - 2023-06-23 14:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 14:23:36 --> Parser Class Initialized
INFO - 2023-06-23 14:23:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-23 14:23:36 --> Pagination Class Initialized
INFO - 2023-06-23 14:23:36 --> Form Validation Class Initialized
INFO - 2023-06-23 14:23:36 --> Controller Class Initialized
INFO - 2023-06-23 14:23:36 --> Model Class Initialized
DEBUG - 2023-06-23 14:23:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-23 14:23:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:23:36 --> Model Class Initialized
DEBUG - 2023-06-23 14:23:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:23:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-06-23 14:23:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:23:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-23 14:23:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-23 14:23:36 --> Model Class Initialized
INFO - 2023-06-23 14:23:36 --> Model Class Initialized
INFO - 2023-06-23 14:23:36 --> Model Class Initialized
INFO - 2023-06-23 14:23:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-23 14:23:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-23 14:23:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-23 14:23:36 --> Final output sent to browser
DEBUG - 2023-06-23 14:23:36 --> Total execution time: 0.0823
ERROR - 2023-06-23 14:23:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-23 14:23:40 --> Config Class Initialized
INFO - 2023-06-23 14:23:40 --> Hooks Class Initialized
DEBUG - 2023-06-23 14:23:40 --> UTF-8 Support Enabled
INFO - 2023-06-23 14:23:40 --> Utf8 Class Initialized
INFO - 2023-06-23 14:23:40 --> URI Class Initialized
INFO - 2023-06-23 14:23:40 --> Router Class Initialized
INFO - 2023-06-23 14:23:40 --> Output Class Initialized
INFO - 2023-06-23 14:23:40 --> Security Class Initialized
DEBUG - 2023-06-23 14:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 14:23:40 --> Input Class Initialized
INFO - 2023-06-23 14:23:40 --> Language Class Initialized
INFO - 2023-06-23 14:23:40 --> Loader Class Initialized
INFO - 2023-06-23 14:23:40 --> Helper loaded: url_helper
INFO - 2023-06-23 14:23:40 --> Helper loaded: file_helper
INFO - 2023-06-23 14:23:40 --> Helper loaded: html_helper
INFO - 2023-06-23 14:23:40 --> Helper loaded: text_helper
INFO - 2023-06-23 14:23:40 --> Helper loaded: form_helper
INFO - 2023-06-23 14:23:40 --> Helper loaded: lang_helper
INFO - 2023-06-23 14:23:40 --> Helper loaded: security_helper
INFO - 2023-06-23 14:23:40 --> Helper loaded: cookie_helper
INFO - 2023-06-23 14:23:40 --> Database Driver Class Initialized
INFO - 2023-06-23 14:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 14:23:40 --> Parser Class Initialized
INFO - 2023-06-23 14:23:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-23 14:23:40 --> Pagination Class Initialized
INFO - 2023-06-23 14:23:40 --> Form Validation Class Initialized
INFO - 2023-06-23 14:23:40 --> Controller Class Initialized
INFO - 2023-06-23 14:23:40 --> Model Class Initialized
DEBUG - 2023-06-23 14:23:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:23:40 --> Model Class Initialized
DEBUG - 2023-06-23 14:23:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:23:40 --> Model Class Initialized
INFO - 2023-06-23 14:23:40 --> Model Class Initialized
INFO - 2023-06-23 14:23:40 --> Model Class Initialized
INFO - 2023-06-23 14:23:40 --> Model Class Initialized
DEBUG - 2023-06-23 14:23:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-23 14:23:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:23:40 --> Model Class Initialized
INFO - 2023-06-23 14:23:40 --> Model Class Initialized
INFO - 2023-06-23 14:23:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-23 14:23:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:23:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-23 14:23:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-23 14:23:40 --> Model Class Initialized
INFO - 2023-06-23 14:23:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-23 14:23:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-23 14:23:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-23 14:23:40 --> Final output sent to browser
DEBUG - 2023-06-23 14:23:40 --> Total execution time: 0.0850
ERROR - 2023-06-23 14:23:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-23 14:23:46 --> Config Class Initialized
INFO - 2023-06-23 14:23:46 --> Hooks Class Initialized
DEBUG - 2023-06-23 14:23:46 --> UTF-8 Support Enabled
INFO - 2023-06-23 14:23:46 --> Utf8 Class Initialized
INFO - 2023-06-23 14:23:46 --> URI Class Initialized
INFO - 2023-06-23 14:23:46 --> Router Class Initialized
INFO - 2023-06-23 14:23:46 --> Output Class Initialized
INFO - 2023-06-23 14:23:46 --> Security Class Initialized
DEBUG - 2023-06-23 14:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 14:23:46 --> Input Class Initialized
INFO - 2023-06-23 14:23:46 --> Language Class Initialized
INFO - 2023-06-23 14:23:46 --> Loader Class Initialized
INFO - 2023-06-23 14:23:46 --> Helper loaded: url_helper
INFO - 2023-06-23 14:23:46 --> Helper loaded: file_helper
INFO - 2023-06-23 14:23:46 --> Helper loaded: html_helper
INFO - 2023-06-23 14:23:46 --> Helper loaded: text_helper
INFO - 2023-06-23 14:23:46 --> Helper loaded: form_helper
INFO - 2023-06-23 14:23:46 --> Helper loaded: lang_helper
INFO - 2023-06-23 14:23:46 --> Helper loaded: security_helper
INFO - 2023-06-23 14:23:46 --> Helper loaded: cookie_helper
INFO - 2023-06-23 14:23:46 --> Database Driver Class Initialized
INFO - 2023-06-23 14:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 14:23:46 --> Parser Class Initialized
INFO - 2023-06-23 14:23:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-23 14:23:46 --> Pagination Class Initialized
INFO - 2023-06-23 14:23:46 --> Form Validation Class Initialized
INFO - 2023-06-23 14:23:46 --> Controller Class Initialized
INFO - 2023-06-23 14:23:46 --> Model Class Initialized
DEBUG - 2023-06-23 14:23:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-23 14:23:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:23:46 --> Model Class Initialized
INFO - 2023-06-23 14:23:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-06-23 14:23:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:23:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-23 14:23:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-23 14:23:46 --> Model Class Initialized
INFO - 2023-06-23 14:23:46 --> Model Class Initialized
INFO - 2023-06-23 14:23:46 --> Model Class Initialized
INFO - 2023-06-23 14:23:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-23 14:23:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-23 14:23:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-23 14:23:46 --> Final output sent to browser
DEBUG - 2023-06-23 14:23:46 --> Total execution time: 0.0682
ERROR - 2023-06-23 14:23:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-23 14:23:47 --> Config Class Initialized
INFO - 2023-06-23 14:23:47 --> Hooks Class Initialized
DEBUG - 2023-06-23 14:23:47 --> UTF-8 Support Enabled
INFO - 2023-06-23 14:23:47 --> Utf8 Class Initialized
INFO - 2023-06-23 14:23:47 --> URI Class Initialized
INFO - 2023-06-23 14:23:47 --> Router Class Initialized
INFO - 2023-06-23 14:23:47 --> Output Class Initialized
INFO - 2023-06-23 14:23:47 --> Security Class Initialized
DEBUG - 2023-06-23 14:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 14:23:47 --> Input Class Initialized
INFO - 2023-06-23 14:23:47 --> Language Class Initialized
INFO - 2023-06-23 14:23:47 --> Loader Class Initialized
INFO - 2023-06-23 14:23:47 --> Helper loaded: url_helper
INFO - 2023-06-23 14:23:47 --> Helper loaded: file_helper
INFO - 2023-06-23 14:23:47 --> Helper loaded: html_helper
INFO - 2023-06-23 14:23:47 --> Helper loaded: text_helper
INFO - 2023-06-23 14:23:47 --> Helper loaded: form_helper
INFO - 2023-06-23 14:23:47 --> Helper loaded: lang_helper
INFO - 2023-06-23 14:23:47 --> Helper loaded: security_helper
INFO - 2023-06-23 14:23:47 --> Helper loaded: cookie_helper
INFO - 2023-06-23 14:23:47 --> Database Driver Class Initialized
INFO - 2023-06-23 14:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 14:23:47 --> Parser Class Initialized
INFO - 2023-06-23 14:23:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-23 14:23:47 --> Pagination Class Initialized
INFO - 2023-06-23 14:23:47 --> Form Validation Class Initialized
INFO - 2023-06-23 14:23:47 --> Controller Class Initialized
INFO - 2023-06-23 14:23:47 --> Model Class Initialized
DEBUG - 2023-06-23 14:23:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-23 14:23:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:23:47 --> Model Class Initialized
INFO - 2023-06-23 14:23:47 --> Final output sent to browser
DEBUG - 2023-06-23 14:23:47 --> Total execution time: 0.0270
ERROR - 2023-06-23 14:23:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-23 14:23:53 --> Config Class Initialized
INFO - 2023-06-23 14:23:53 --> Hooks Class Initialized
DEBUG - 2023-06-23 14:23:53 --> UTF-8 Support Enabled
INFO - 2023-06-23 14:23:53 --> Utf8 Class Initialized
INFO - 2023-06-23 14:23:53 --> URI Class Initialized
INFO - 2023-06-23 14:23:53 --> Router Class Initialized
INFO - 2023-06-23 14:23:53 --> Output Class Initialized
INFO - 2023-06-23 14:23:53 --> Security Class Initialized
DEBUG - 2023-06-23 14:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 14:23:53 --> Input Class Initialized
INFO - 2023-06-23 14:23:53 --> Language Class Initialized
INFO - 2023-06-23 14:23:53 --> Loader Class Initialized
INFO - 2023-06-23 14:23:53 --> Helper loaded: url_helper
INFO - 2023-06-23 14:23:53 --> Helper loaded: file_helper
INFO - 2023-06-23 14:23:53 --> Helper loaded: html_helper
INFO - 2023-06-23 14:23:53 --> Helper loaded: text_helper
INFO - 2023-06-23 14:23:53 --> Helper loaded: form_helper
INFO - 2023-06-23 14:23:53 --> Helper loaded: lang_helper
INFO - 2023-06-23 14:23:53 --> Helper loaded: security_helper
INFO - 2023-06-23 14:23:53 --> Helper loaded: cookie_helper
INFO - 2023-06-23 14:23:53 --> Database Driver Class Initialized
INFO - 2023-06-23 14:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 14:23:53 --> Parser Class Initialized
INFO - 2023-06-23 14:23:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-23 14:23:53 --> Pagination Class Initialized
INFO - 2023-06-23 14:23:53 --> Form Validation Class Initialized
INFO - 2023-06-23 14:23:53 --> Controller Class Initialized
INFO - 2023-06-23 14:23:53 --> Model Class Initialized
DEBUG - 2023-06-23 14:23:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-23 14:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 14:23:53 --> Model Class Initialized
INFO - 2023-06-23 14:23:53 --> Final output sent to browser
DEBUG - 2023-06-23 14:23:53 --> Total execution time: 0.0260
ERROR - 2023-06-23 15:24:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-23 15:24:20 --> Config Class Initialized
INFO - 2023-06-23 15:24:20 --> Hooks Class Initialized
DEBUG - 2023-06-23 15:24:20 --> UTF-8 Support Enabled
INFO - 2023-06-23 15:24:20 --> Utf8 Class Initialized
INFO - 2023-06-23 15:24:20 --> URI Class Initialized
DEBUG - 2023-06-23 15:24:20 --> No URI present. Default controller set.
INFO - 2023-06-23 15:24:20 --> Router Class Initialized
INFO - 2023-06-23 15:24:20 --> Output Class Initialized
INFO - 2023-06-23 15:24:20 --> Security Class Initialized
DEBUG - 2023-06-23 15:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 15:24:20 --> Input Class Initialized
INFO - 2023-06-23 15:24:20 --> Language Class Initialized
INFO - 2023-06-23 15:24:20 --> Loader Class Initialized
INFO - 2023-06-23 15:24:20 --> Helper loaded: url_helper
INFO - 2023-06-23 15:24:20 --> Helper loaded: file_helper
INFO - 2023-06-23 15:24:20 --> Helper loaded: html_helper
INFO - 2023-06-23 15:24:20 --> Helper loaded: text_helper
INFO - 2023-06-23 15:24:20 --> Helper loaded: form_helper
INFO - 2023-06-23 15:24:20 --> Helper loaded: lang_helper
INFO - 2023-06-23 15:24:20 --> Helper loaded: security_helper
INFO - 2023-06-23 15:24:20 --> Helper loaded: cookie_helper
INFO - 2023-06-23 15:24:20 --> Database Driver Class Initialized
INFO - 2023-06-23 15:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 15:24:20 --> Parser Class Initialized
INFO - 2023-06-23 15:24:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-23 15:24:20 --> Pagination Class Initialized
INFO - 2023-06-23 15:24:20 --> Form Validation Class Initialized
INFO - 2023-06-23 15:24:20 --> Controller Class Initialized
INFO - 2023-06-23 15:24:20 --> Model Class Initialized
DEBUG - 2023-06-23 15:24:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-23 15:28:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-23 15:28:47 --> Config Class Initialized
INFO - 2023-06-23 15:28:47 --> Hooks Class Initialized
DEBUG - 2023-06-23 15:28:47 --> UTF-8 Support Enabled
INFO - 2023-06-23 15:28:47 --> Utf8 Class Initialized
INFO - 2023-06-23 15:28:47 --> URI Class Initialized
DEBUG - 2023-06-23 15:28:47 --> No URI present. Default controller set.
INFO - 2023-06-23 15:28:47 --> Router Class Initialized
INFO - 2023-06-23 15:28:47 --> Output Class Initialized
INFO - 2023-06-23 15:28:47 --> Security Class Initialized
DEBUG - 2023-06-23 15:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 15:28:47 --> Input Class Initialized
INFO - 2023-06-23 15:28:47 --> Language Class Initialized
INFO - 2023-06-23 15:28:47 --> Loader Class Initialized
INFO - 2023-06-23 15:28:47 --> Helper loaded: url_helper
INFO - 2023-06-23 15:28:47 --> Helper loaded: file_helper
INFO - 2023-06-23 15:28:47 --> Helper loaded: html_helper
INFO - 2023-06-23 15:28:47 --> Helper loaded: text_helper
INFO - 2023-06-23 15:28:47 --> Helper loaded: form_helper
INFO - 2023-06-23 15:28:47 --> Helper loaded: lang_helper
INFO - 2023-06-23 15:28:47 --> Helper loaded: security_helper
INFO - 2023-06-23 15:28:47 --> Helper loaded: cookie_helper
INFO - 2023-06-23 15:28:47 --> Database Driver Class Initialized
INFO - 2023-06-23 15:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 15:28:47 --> Parser Class Initialized
INFO - 2023-06-23 15:28:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-23 15:28:47 --> Pagination Class Initialized
INFO - 2023-06-23 15:28:47 --> Form Validation Class Initialized
INFO - 2023-06-23 15:28:47 --> Controller Class Initialized
INFO - 2023-06-23 15:28:47 --> Model Class Initialized
DEBUG - 2023-06-23 15:28:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-23 15:29:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-23 15:29:56 --> Config Class Initialized
INFO - 2023-06-23 15:29:56 --> Hooks Class Initialized
DEBUG - 2023-06-23 15:29:56 --> UTF-8 Support Enabled
INFO - 2023-06-23 15:29:56 --> Utf8 Class Initialized
INFO - 2023-06-23 15:29:56 --> URI Class Initialized
INFO - 2023-06-23 15:29:56 --> Router Class Initialized
INFO - 2023-06-23 15:29:56 --> Output Class Initialized
INFO - 2023-06-23 15:29:56 --> Security Class Initialized
DEBUG - 2023-06-23 15:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 15:29:56 --> Input Class Initialized
INFO - 2023-06-23 15:29:56 --> Language Class Initialized
INFO - 2023-06-23 15:29:56 --> Loader Class Initialized
INFO - 2023-06-23 15:29:56 --> Helper loaded: url_helper
INFO - 2023-06-23 15:29:56 --> Helper loaded: file_helper
INFO - 2023-06-23 15:29:56 --> Helper loaded: html_helper
INFO - 2023-06-23 15:29:56 --> Helper loaded: text_helper
INFO - 2023-06-23 15:29:56 --> Helper loaded: form_helper
INFO - 2023-06-23 15:29:56 --> Helper loaded: lang_helper
INFO - 2023-06-23 15:29:56 --> Helper loaded: security_helper
INFO - 2023-06-23 15:29:56 --> Helper loaded: cookie_helper
INFO - 2023-06-23 15:29:56 --> Database Driver Class Initialized
INFO - 2023-06-23 15:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 15:29:56 --> Parser Class Initialized
INFO - 2023-06-23 15:29:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-23 15:29:56 --> Pagination Class Initialized
INFO - 2023-06-23 15:29:56 --> Form Validation Class Initialized
INFO - 2023-06-23 15:29:56 --> Controller Class Initialized
ERROR - 2023-06-23 15:31:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-23 15:31:24 --> Config Class Initialized
INFO - 2023-06-23 15:31:24 --> Hooks Class Initialized
DEBUG - 2023-06-23 15:31:24 --> UTF-8 Support Enabled
INFO - 2023-06-23 15:31:24 --> Utf8 Class Initialized
INFO - 2023-06-23 15:31:24 --> URI Class Initialized
DEBUG - 2023-06-23 15:31:24 --> No URI present. Default controller set.
INFO - 2023-06-23 15:31:24 --> Router Class Initialized
INFO - 2023-06-23 15:31:24 --> Output Class Initialized
INFO - 2023-06-23 15:31:24 --> Security Class Initialized
DEBUG - 2023-06-23 15:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 15:31:24 --> Input Class Initialized
INFO - 2023-06-23 15:31:24 --> Language Class Initialized
INFO - 2023-06-23 15:31:24 --> Loader Class Initialized
INFO - 2023-06-23 15:31:24 --> Helper loaded: url_helper
INFO - 2023-06-23 15:31:24 --> Helper loaded: file_helper
INFO - 2023-06-23 15:31:24 --> Helper loaded: html_helper
INFO - 2023-06-23 15:31:24 --> Helper loaded: text_helper
INFO - 2023-06-23 15:31:24 --> Helper loaded: form_helper
INFO - 2023-06-23 15:31:24 --> Helper loaded: lang_helper
INFO - 2023-06-23 15:31:24 --> Helper loaded: security_helper
INFO - 2023-06-23 15:31:24 --> Helper loaded: cookie_helper
INFO - 2023-06-23 15:31:24 --> Database Driver Class Initialized
INFO - 2023-06-23 15:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 15:31:24 --> Parser Class Initialized
INFO - 2023-06-23 15:31:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-23 15:31:24 --> Pagination Class Initialized
INFO - 2023-06-23 15:31:24 --> Form Validation Class Initialized
INFO - 2023-06-23 15:31:24 --> Controller Class Initialized
INFO - 2023-06-23 15:31:24 --> Model Class Initialized
DEBUG - 2023-06-23 15:31:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-23 15:31:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-23 15:31:25 --> Config Class Initialized
INFO - 2023-06-23 15:31:25 --> Hooks Class Initialized
DEBUG - 2023-06-23 15:31:25 --> UTF-8 Support Enabled
INFO - 2023-06-23 15:31:25 --> Utf8 Class Initialized
INFO - 2023-06-23 15:31:25 --> URI Class Initialized
INFO - 2023-06-23 15:31:25 --> Router Class Initialized
INFO - 2023-06-23 15:31:25 --> Output Class Initialized
INFO - 2023-06-23 15:31:25 --> Security Class Initialized
DEBUG - 2023-06-23 15:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 15:31:25 --> Input Class Initialized
INFO - 2023-06-23 15:31:25 --> Language Class Initialized
INFO - 2023-06-23 15:31:25 --> Loader Class Initialized
INFO - 2023-06-23 15:31:25 --> Helper loaded: url_helper
INFO - 2023-06-23 15:31:25 --> Helper loaded: file_helper
INFO - 2023-06-23 15:31:25 --> Helper loaded: html_helper
INFO - 2023-06-23 15:31:25 --> Helper loaded: text_helper
INFO - 2023-06-23 15:31:25 --> Helper loaded: form_helper
INFO - 2023-06-23 15:31:25 --> Helper loaded: lang_helper
INFO - 2023-06-23 15:31:25 --> Helper loaded: security_helper
INFO - 2023-06-23 15:31:25 --> Helper loaded: cookie_helper
INFO - 2023-06-23 15:31:25 --> Database Driver Class Initialized
INFO - 2023-06-23 15:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 15:31:25 --> Parser Class Initialized
INFO - 2023-06-23 15:31:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-23 15:31:25 --> Pagination Class Initialized
INFO - 2023-06-23 15:31:25 --> Form Validation Class Initialized
INFO - 2023-06-23 15:31:25 --> Controller Class Initialized
INFO - 2023-06-23 15:31:25 --> Model Class Initialized
DEBUG - 2023-06-23 15:31:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 15:31:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-23 15:31:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-23 15:31:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-23 15:31:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-23 15:31:25 --> Model Class Initialized
INFO - 2023-06-23 15:31:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-23 15:31:25 --> Final output sent to browser
DEBUG - 2023-06-23 15:31:25 --> Total execution time: 0.0282
ERROR - 2023-06-23 15:38:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-23 15:38:59 --> Config Class Initialized
INFO - 2023-06-23 15:38:59 --> Hooks Class Initialized
DEBUG - 2023-06-23 15:38:59 --> UTF-8 Support Enabled
INFO - 2023-06-23 15:38:59 --> Utf8 Class Initialized
INFO - 2023-06-23 15:38:59 --> URI Class Initialized
INFO - 2023-06-23 15:38:59 --> Router Class Initialized
INFO - 2023-06-23 15:38:59 --> Output Class Initialized
INFO - 2023-06-23 15:38:59 --> Security Class Initialized
DEBUG - 2023-06-23 15:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 15:38:59 --> Input Class Initialized
INFO - 2023-06-23 15:38:59 --> Language Class Initialized
INFO - 2023-06-23 15:38:59 --> Loader Class Initialized
INFO - 2023-06-23 15:38:59 --> Helper loaded: url_helper
INFO - 2023-06-23 15:38:59 --> Helper loaded: file_helper
INFO - 2023-06-23 15:38:59 --> Helper loaded: html_helper
INFO - 2023-06-23 15:38:59 --> Helper loaded: text_helper
INFO - 2023-06-23 15:38:59 --> Helper loaded: form_helper
INFO - 2023-06-23 15:38:59 --> Helper loaded: lang_helper
INFO - 2023-06-23 15:38:59 --> Helper loaded: security_helper
INFO - 2023-06-23 15:38:59 --> Helper loaded: cookie_helper
INFO - 2023-06-23 15:38:59 --> Database Driver Class Initialized
INFO - 2023-06-23 15:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 15:38:59 --> Parser Class Initialized
INFO - 2023-06-23 15:38:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-23 15:38:59 --> Pagination Class Initialized
INFO - 2023-06-23 15:38:59 --> Form Validation Class Initialized
INFO - 2023-06-23 15:38:59 --> Controller Class Initialized
INFO - 2023-06-23 15:38:59 --> Model Class Initialized
DEBUG - 2023-06-23 15:38:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-23 15:39:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-23 15:39:00 --> Config Class Initialized
INFO - 2023-06-23 15:39:00 --> Hooks Class Initialized
DEBUG - 2023-06-23 15:39:00 --> UTF-8 Support Enabled
INFO - 2023-06-23 15:39:00 --> Utf8 Class Initialized
INFO - 2023-06-23 15:39:00 --> URI Class Initialized
INFO - 2023-06-23 15:39:00 --> Router Class Initialized
INFO - 2023-06-23 15:39:00 --> Output Class Initialized
INFO - 2023-06-23 15:39:00 --> Security Class Initialized
DEBUG - 2023-06-23 15:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-23 15:39:00 --> Input Class Initialized
INFO - 2023-06-23 15:39:00 --> Language Class Initialized
INFO - 2023-06-23 15:39:00 --> Loader Class Initialized
INFO - 2023-06-23 15:39:00 --> Helper loaded: url_helper
INFO - 2023-06-23 15:39:00 --> Helper loaded: file_helper
INFO - 2023-06-23 15:39:00 --> Helper loaded: html_helper
INFO - 2023-06-23 15:39:00 --> Helper loaded: text_helper
INFO - 2023-06-23 15:39:00 --> Helper loaded: form_helper
INFO - 2023-06-23 15:39:00 --> Helper loaded: lang_helper
INFO - 2023-06-23 15:39:00 --> Helper loaded: security_helper
INFO - 2023-06-23 15:39:00 --> Helper loaded: cookie_helper
INFO - 2023-06-23 15:39:00 --> Database Driver Class Initialized
INFO - 2023-06-23 15:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-23 15:39:00 --> Parser Class Initialized
INFO - 2023-06-23 15:39:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-23 15:39:00 --> Pagination Class Initialized
INFO - 2023-06-23 15:39:00 --> Form Validation Class Initialized
INFO - 2023-06-23 15:39:00 --> Controller Class Initialized
INFO - 2023-06-23 15:39:00 --> Model Class Initialized
DEBUG - 2023-06-23 15:39:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-23 15:39:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-23 15:39:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-23 15:39:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-23 15:39:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-23 15:39:00 --> Model Class Initialized
INFO - 2023-06-23 15:39:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-23 15:39:00 --> Final output sent to browser
DEBUG - 2023-06-23 15:39:00 --> Total execution time: 0.0294
