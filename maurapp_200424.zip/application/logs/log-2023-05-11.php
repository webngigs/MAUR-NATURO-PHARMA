<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-11 06:24:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 06:24:58 --> Config Class Initialized
INFO - 2023-05-11 06:24:58 --> Hooks Class Initialized
DEBUG - 2023-05-11 06:24:58 --> UTF-8 Support Enabled
INFO - 2023-05-11 06:24:58 --> Utf8 Class Initialized
INFO - 2023-05-11 06:24:58 --> URI Class Initialized
DEBUG - 2023-05-11 06:24:58 --> No URI present. Default controller set.
INFO - 2023-05-11 06:24:58 --> Router Class Initialized
INFO - 2023-05-11 06:24:58 --> Output Class Initialized
INFO - 2023-05-11 06:24:58 --> Security Class Initialized
DEBUG - 2023-05-11 06:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 06:24:58 --> Input Class Initialized
INFO - 2023-05-11 06:24:58 --> Language Class Initialized
INFO - 2023-05-11 06:24:58 --> Loader Class Initialized
INFO - 2023-05-11 06:24:58 --> Helper loaded: url_helper
INFO - 2023-05-11 06:24:58 --> Helper loaded: file_helper
INFO - 2023-05-11 06:24:58 --> Helper loaded: html_helper
INFO - 2023-05-11 06:24:58 --> Helper loaded: text_helper
INFO - 2023-05-11 06:24:58 --> Helper loaded: form_helper
INFO - 2023-05-11 06:24:58 --> Helper loaded: lang_helper
INFO - 2023-05-11 06:24:58 --> Helper loaded: security_helper
INFO - 2023-05-11 06:24:58 --> Helper loaded: cookie_helper
INFO - 2023-05-11 06:24:58 --> Database Driver Class Initialized
INFO - 2023-05-11 06:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 06:24:58 --> Parser Class Initialized
INFO - 2023-05-11 06:24:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 06:24:58 --> Pagination Class Initialized
INFO - 2023-05-11 06:24:58 --> Form Validation Class Initialized
INFO - 2023-05-11 06:24:58 --> Controller Class Initialized
INFO - 2023-05-11 06:24:58 --> Model Class Initialized
DEBUG - 2023-05-11 06:24:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-11 06:26:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 06:26:22 --> Config Class Initialized
INFO - 2023-05-11 06:26:22 --> Hooks Class Initialized
DEBUG - 2023-05-11 06:26:22 --> UTF-8 Support Enabled
INFO - 2023-05-11 06:26:22 --> Utf8 Class Initialized
INFO - 2023-05-11 06:26:22 --> URI Class Initialized
DEBUG - 2023-05-11 06:26:22 --> No URI present. Default controller set.
INFO - 2023-05-11 06:26:22 --> Router Class Initialized
INFO - 2023-05-11 06:26:22 --> Output Class Initialized
INFO - 2023-05-11 06:26:22 --> Security Class Initialized
DEBUG - 2023-05-11 06:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 06:26:22 --> Input Class Initialized
INFO - 2023-05-11 06:26:22 --> Language Class Initialized
INFO - 2023-05-11 06:26:22 --> Loader Class Initialized
INFO - 2023-05-11 06:26:22 --> Helper loaded: url_helper
INFO - 2023-05-11 06:26:22 --> Helper loaded: file_helper
INFO - 2023-05-11 06:26:22 --> Helper loaded: html_helper
INFO - 2023-05-11 06:26:22 --> Helper loaded: text_helper
INFO - 2023-05-11 06:26:22 --> Helper loaded: form_helper
INFO - 2023-05-11 06:26:22 --> Helper loaded: lang_helper
INFO - 2023-05-11 06:26:22 --> Helper loaded: security_helper
INFO - 2023-05-11 06:26:22 --> Helper loaded: cookie_helper
INFO - 2023-05-11 06:26:22 --> Database Driver Class Initialized
INFO - 2023-05-11 06:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 06:26:22 --> Parser Class Initialized
INFO - 2023-05-11 06:26:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 06:26:22 --> Pagination Class Initialized
INFO - 2023-05-11 06:26:22 --> Form Validation Class Initialized
INFO - 2023-05-11 06:26:22 --> Controller Class Initialized
INFO - 2023-05-11 06:26:22 --> Model Class Initialized
DEBUG - 2023-05-11 06:26:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-11 06:26:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 06:26:24 --> Config Class Initialized
INFO - 2023-05-11 06:26:24 --> Hooks Class Initialized
DEBUG - 2023-05-11 06:26:24 --> UTF-8 Support Enabled
INFO - 2023-05-11 06:26:24 --> Utf8 Class Initialized
INFO - 2023-05-11 06:26:24 --> URI Class Initialized
INFO - 2023-05-11 06:26:24 --> Router Class Initialized
INFO - 2023-05-11 06:26:24 --> Output Class Initialized
INFO - 2023-05-11 06:26:24 --> Security Class Initialized
DEBUG - 2023-05-11 06:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 06:26:24 --> Input Class Initialized
INFO - 2023-05-11 06:26:24 --> Language Class Initialized
INFO - 2023-05-11 06:26:24 --> Loader Class Initialized
INFO - 2023-05-11 06:26:24 --> Helper loaded: url_helper
INFO - 2023-05-11 06:26:24 --> Helper loaded: file_helper
INFO - 2023-05-11 06:26:24 --> Helper loaded: html_helper
INFO - 2023-05-11 06:26:24 --> Helper loaded: text_helper
INFO - 2023-05-11 06:26:24 --> Helper loaded: form_helper
INFO - 2023-05-11 06:26:24 --> Helper loaded: lang_helper
INFO - 2023-05-11 06:26:24 --> Helper loaded: security_helper
INFO - 2023-05-11 06:26:24 --> Helper loaded: cookie_helper
INFO - 2023-05-11 06:26:24 --> Database Driver Class Initialized
INFO - 2023-05-11 06:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 06:26:24 --> Parser Class Initialized
INFO - 2023-05-11 06:26:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 06:26:24 --> Pagination Class Initialized
INFO - 2023-05-11 06:26:24 --> Form Validation Class Initialized
INFO - 2023-05-11 06:26:24 --> Controller Class Initialized
INFO - 2023-05-11 06:26:24 --> Model Class Initialized
DEBUG - 2023-05-11 06:26:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 06:26:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-11 06:26:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 06:26:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 06:26:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 06:26:24 --> Model Class Initialized
INFO - 2023-05-11 06:26:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 06:26:24 --> Final output sent to browser
DEBUG - 2023-05-11 06:26:24 --> Total execution time: 0.0326
ERROR - 2023-05-11 06:26:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 06:26:28 --> Config Class Initialized
INFO - 2023-05-11 06:26:28 --> Hooks Class Initialized
DEBUG - 2023-05-11 06:26:28 --> UTF-8 Support Enabled
INFO - 2023-05-11 06:26:28 --> Utf8 Class Initialized
INFO - 2023-05-11 06:26:28 --> URI Class Initialized
INFO - 2023-05-11 06:26:28 --> Router Class Initialized
INFO - 2023-05-11 06:26:28 --> Output Class Initialized
INFO - 2023-05-11 06:26:28 --> Security Class Initialized
DEBUG - 2023-05-11 06:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 06:26:28 --> Input Class Initialized
INFO - 2023-05-11 06:26:28 --> Language Class Initialized
INFO - 2023-05-11 06:26:28 --> Loader Class Initialized
INFO - 2023-05-11 06:26:28 --> Helper loaded: url_helper
INFO - 2023-05-11 06:26:28 --> Helper loaded: file_helper
INFO - 2023-05-11 06:26:28 --> Helper loaded: html_helper
INFO - 2023-05-11 06:26:28 --> Helper loaded: text_helper
INFO - 2023-05-11 06:26:28 --> Helper loaded: form_helper
INFO - 2023-05-11 06:26:28 --> Helper loaded: lang_helper
INFO - 2023-05-11 06:26:28 --> Helper loaded: security_helper
INFO - 2023-05-11 06:26:28 --> Helper loaded: cookie_helper
INFO - 2023-05-11 06:26:28 --> Database Driver Class Initialized
INFO - 2023-05-11 06:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 06:26:28 --> Parser Class Initialized
INFO - 2023-05-11 06:26:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 06:26:28 --> Pagination Class Initialized
INFO - 2023-05-11 06:26:28 --> Form Validation Class Initialized
INFO - 2023-05-11 06:26:28 --> Controller Class Initialized
INFO - 2023-05-11 06:26:28 --> Model Class Initialized
DEBUG - 2023-05-11 06:26:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 06:26:28 --> Model Class Initialized
INFO - 2023-05-11 06:26:28 --> Final output sent to browser
DEBUG - 2023-05-11 06:26:28 --> Total execution time: 0.0177
ERROR - 2023-05-11 06:26:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 06:26:28 --> Config Class Initialized
INFO - 2023-05-11 06:26:28 --> Hooks Class Initialized
DEBUG - 2023-05-11 06:26:28 --> UTF-8 Support Enabled
INFO - 2023-05-11 06:26:28 --> Utf8 Class Initialized
INFO - 2023-05-11 06:26:28 --> URI Class Initialized
DEBUG - 2023-05-11 06:26:28 --> No URI present. Default controller set.
INFO - 2023-05-11 06:26:28 --> Router Class Initialized
INFO - 2023-05-11 06:26:28 --> Output Class Initialized
INFO - 2023-05-11 06:26:28 --> Security Class Initialized
DEBUG - 2023-05-11 06:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 06:26:28 --> Input Class Initialized
INFO - 2023-05-11 06:26:28 --> Language Class Initialized
INFO - 2023-05-11 06:26:28 --> Loader Class Initialized
INFO - 2023-05-11 06:26:28 --> Helper loaded: url_helper
INFO - 2023-05-11 06:26:28 --> Helper loaded: file_helper
INFO - 2023-05-11 06:26:28 --> Helper loaded: html_helper
INFO - 2023-05-11 06:26:28 --> Helper loaded: text_helper
INFO - 2023-05-11 06:26:28 --> Helper loaded: form_helper
INFO - 2023-05-11 06:26:28 --> Helper loaded: lang_helper
INFO - 2023-05-11 06:26:28 --> Helper loaded: security_helper
INFO - 2023-05-11 06:26:28 --> Helper loaded: cookie_helper
INFO - 2023-05-11 06:26:28 --> Database Driver Class Initialized
INFO - 2023-05-11 06:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 06:26:28 --> Parser Class Initialized
INFO - 2023-05-11 06:26:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 06:26:28 --> Pagination Class Initialized
INFO - 2023-05-11 06:26:28 --> Form Validation Class Initialized
INFO - 2023-05-11 06:26:28 --> Controller Class Initialized
INFO - 2023-05-11 06:26:28 --> Model Class Initialized
DEBUG - 2023-05-11 06:26:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 06:26:28 --> Model Class Initialized
DEBUG - 2023-05-11 06:26:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 06:26:28 --> Model Class Initialized
INFO - 2023-05-11 06:26:28 --> Model Class Initialized
INFO - 2023-05-11 06:26:28 --> Model Class Initialized
INFO - 2023-05-11 06:26:28 --> Model Class Initialized
DEBUG - 2023-05-11 06:26:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 06:26:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 06:26:28 --> Model Class Initialized
INFO - 2023-05-11 06:26:28 --> Model Class Initialized
INFO - 2023-05-11 06:26:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-11 06:26:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 06:26:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 06:26:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 06:26:28 --> Model Class Initialized
INFO - 2023-05-11 06:26:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 06:26:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 06:26:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 06:26:28 --> Final output sent to browser
DEBUG - 2023-05-11 06:26:28 --> Total execution time: 0.1694
ERROR - 2023-05-11 06:26:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 06:26:30 --> Config Class Initialized
INFO - 2023-05-11 06:26:30 --> Hooks Class Initialized
DEBUG - 2023-05-11 06:26:30 --> UTF-8 Support Enabled
INFO - 2023-05-11 06:26:30 --> Utf8 Class Initialized
INFO - 2023-05-11 06:26:30 --> URI Class Initialized
INFO - 2023-05-11 06:26:30 --> Router Class Initialized
INFO - 2023-05-11 06:26:30 --> Output Class Initialized
INFO - 2023-05-11 06:26:30 --> Security Class Initialized
DEBUG - 2023-05-11 06:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 06:26:30 --> Input Class Initialized
INFO - 2023-05-11 06:26:30 --> Language Class Initialized
INFO - 2023-05-11 06:26:30 --> Loader Class Initialized
INFO - 2023-05-11 06:26:30 --> Helper loaded: url_helper
INFO - 2023-05-11 06:26:30 --> Helper loaded: file_helper
INFO - 2023-05-11 06:26:30 --> Helper loaded: html_helper
INFO - 2023-05-11 06:26:30 --> Helper loaded: text_helper
INFO - 2023-05-11 06:26:30 --> Helper loaded: form_helper
INFO - 2023-05-11 06:26:30 --> Helper loaded: lang_helper
INFO - 2023-05-11 06:26:30 --> Helper loaded: security_helper
INFO - 2023-05-11 06:26:30 --> Helper loaded: cookie_helper
INFO - 2023-05-11 06:26:30 --> Database Driver Class Initialized
INFO - 2023-05-11 06:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 06:26:30 --> Parser Class Initialized
INFO - 2023-05-11 06:26:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 06:26:30 --> Pagination Class Initialized
INFO - 2023-05-11 06:26:30 --> Form Validation Class Initialized
INFO - 2023-05-11 06:26:30 --> Controller Class Initialized
DEBUG - 2023-05-11 06:26:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 06:26:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 06:26:30 --> Model Class Initialized
INFO - 2023-05-11 06:26:30 --> Final output sent to browser
DEBUG - 2023-05-11 06:26:30 --> Total execution time: 0.0132
ERROR - 2023-05-11 08:34:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 08:34:32 --> Config Class Initialized
INFO - 2023-05-11 08:34:32 --> Hooks Class Initialized
DEBUG - 2023-05-11 08:34:32 --> UTF-8 Support Enabled
INFO - 2023-05-11 08:34:32 --> Utf8 Class Initialized
INFO - 2023-05-11 08:34:32 --> URI Class Initialized
DEBUG - 2023-05-11 08:34:32 --> No URI present. Default controller set.
INFO - 2023-05-11 08:34:32 --> Router Class Initialized
INFO - 2023-05-11 08:34:32 --> Output Class Initialized
INFO - 2023-05-11 08:34:32 --> Security Class Initialized
DEBUG - 2023-05-11 08:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 08:34:32 --> Input Class Initialized
INFO - 2023-05-11 08:34:32 --> Language Class Initialized
INFO - 2023-05-11 08:34:32 --> Loader Class Initialized
INFO - 2023-05-11 08:34:32 --> Helper loaded: url_helper
INFO - 2023-05-11 08:34:32 --> Helper loaded: file_helper
INFO - 2023-05-11 08:34:32 --> Helper loaded: html_helper
INFO - 2023-05-11 08:34:32 --> Helper loaded: text_helper
INFO - 2023-05-11 08:34:32 --> Helper loaded: form_helper
INFO - 2023-05-11 08:34:32 --> Helper loaded: lang_helper
INFO - 2023-05-11 08:34:32 --> Helper loaded: security_helper
INFO - 2023-05-11 08:34:32 --> Helper loaded: cookie_helper
INFO - 2023-05-11 08:34:32 --> Database Driver Class Initialized
INFO - 2023-05-11 08:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 08:34:32 --> Parser Class Initialized
INFO - 2023-05-11 08:34:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 08:34:32 --> Pagination Class Initialized
INFO - 2023-05-11 08:34:32 --> Form Validation Class Initialized
INFO - 2023-05-11 08:34:32 --> Controller Class Initialized
INFO - 2023-05-11 08:34:32 --> Model Class Initialized
DEBUG - 2023-05-11 08:34:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-11 08:34:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 08:34:33 --> Config Class Initialized
INFO - 2023-05-11 08:34:33 --> Hooks Class Initialized
DEBUG - 2023-05-11 08:34:33 --> UTF-8 Support Enabled
INFO - 2023-05-11 08:34:33 --> Utf8 Class Initialized
INFO - 2023-05-11 08:34:33 --> URI Class Initialized
INFO - 2023-05-11 08:34:33 --> Router Class Initialized
INFO - 2023-05-11 08:34:33 --> Output Class Initialized
INFO - 2023-05-11 08:34:33 --> Security Class Initialized
DEBUG - 2023-05-11 08:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 08:34:33 --> Input Class Initialized
INFO - 2023-05-11 08:34:33 --> Language Class Initialized
INFO - 2023-05-11 08:34:33 --> Loader Class Initialized
INFO - 2023-05-11 08:34:33 --> Helper loaded: url_helper
INFO - 2023-05-11 08:34:33 --> Helper loaded: file_helper
INFO - 2023-05-11 08:34:33 --> Helper loaded: html_helper
INFO - 2023-05-11 08:34:33 --> Helper loaded: text_helper
INFO - 2023-05-11 08:34:33 --> Helper loaded: form_helper
INFO - 2023-05-11 08:34:33 --> Helper loaded: lang_helper
INFO - 2023-05-11 08:34:33 --> Helper loaded: security_helper
INFO - 2023-05-11 08:34:33 --> Helper loaded: cookie_helper
INFO - 2023-05-11 08:34:33 --> Database Driver Class Initialized
INFO - 2023-05-11 08:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 08:34:33 --> Parser Class Initialized
INFO - 2023-05-11 08:34:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 08:34:33 --> Pagination Class Initialized
INFO - 2023-05-11 08:34:33 --> Form Validation Class Initialized
INFO - 2023-05-11 08:34:33 --> Controller Class Initialized
INFO - 2023-05-11 08:34:33 --> Model Class Initialized
DEBUG - 2023-05-11 08:34:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 08:34:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-11 08:34:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 08:34:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 08:34:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 08:34:33 --> Model Class Initialized
INFO - 2023-05-11 08:34:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 08:34:33 --> Final output sent to browser
DEBUG - 2023-05-11 08:34:33 --> Total execution time: 0.0350
ERROR - 2023-05-11 09:09:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:09:55 --> Config Class Initialized
INFO - 2023-05-11 09:09:55 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:09:55 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:09:55 --> Utf8 Class Initialized
INFO - 2023-05-11 09:09:55 --> URI Class Initialized
DEBUG - 2023-05-11 09:09:55 --> No URI present. Default controller set.
INFO - 2023-05-11 09:09:55 --> Router Class Initialized
INFO - 2023-05-11 09:09:55 --> Output Class Initialized
INFO - 2023-05-11 09:09:55 --> Security Class Initialized
DEBUG - 2023-05-11 09:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:09:55 --> Input Class Initialized
INFO - 2023-05-11 09:09:55 --> Language Class Initialized
INFO - 2023-05-11 09:09:55 --> Loader Class Initialized
INFO - 2023-05-11 09:09:55 --> Helper loaded: url_helper
INFO - 2023-05-11 09:09:55 --> Helper loaded: file_helper
INFO - 2023-05-11 09:09:55 --> Helper loaded: html_helper
INFO - 2023-05-11 09:09:55 --> Helper loaded: text_helper
INFO - 2023-05-11 09:09:55 --> Helper loaded: form_helper
INFO - 2023-05-11 09:09:55 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:09:55 --> Helper loaded: security_helper
INFO - 2023-05-11 09:09:55 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:09:55 --> Database Driver Class Initialized
INFO - 2023-05-11 09:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:09:55 --> Parser Class Initialized
INFO - 2023-05-11 09:09:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:09:55 --> Pagination Class Initialized
INFO - 2023-05-11 09:09:55 --> Form Validation Class Initialized
INFO - 2023-05-11 09:09:55 --> Controller Class Initialized
INFO - 2023-05-11 09:09:55 --> Model Class Initialized
DEBUG - 2023-05-11 09:09:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-11 09:09:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:09:56 --> Config Class Initialized
INFO - 2023-05-11 09:09:56 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:09:56 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:09:56 --> Utf8 Class Initialized
INFO - 2023-05-11 09:09:56 --> URI Class Initialized
INFO - 2023-05-11 09:09:56 --> Router Class Initialized
INFO - 2023-05-11 09:09:56 --> Output Class Initialized
INFO - 2023-05-11 09:09:56 --> Security Class Initialized
DEBUG - 2023-05-11 09:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:09:56 --> Input Class Initialized
INFO - 2023-05-11 09:09:56 --> Language Class Initialized
INFO - 2023-05-11 09:09:56 --> Loader Class Initialized
INFO - 2023-05-11 09:09:56 --> Helper loaded: url_helper
INFO - 2023-05-11 09:09:56 --> Helper loaded: file_helper
INFO - 2023-05-11 09:09:56 --> Helper loaded: html_helper
INFO - 2023-05-11 09:09:56 --> Helper loaded: text_helper
INFO - 2023-05-11 09:09:56 --> Helper loaded: form_helper
INFO - 2023-05-11 09:09:56 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:09:56 --> Helper loaded: security_helper
INFO - 2023-05-11 09:09:56 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:09:56 --> Database Driver Class Initialized
INFO - 2023-05-11 09:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:09:56 --> Parser Class Initialized
INFO - 2023-05-11 09:09:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:09:56 --> Pagination Class Initialized
INFO - 2023-05-11 09:09:56 --> Form Validation Class Initialized
INFO - 2023-05-11 09:09:56 --> Controller Class Initialized
INFO - 2023-05-11 09:09:56 --> Model Class Initialized
DEBUG - 2023-05-11 09:09:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:09:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-11 09:09:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:09:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 09:09:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 09:09:56 --> Model Class Initialized
INFO - 2023-05-11 09:09:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 09:09:56 --> Final output sent to browser
DEBUG - 2023-05-11 09:09:56 --> Total execution time: 0.0326
ERROR - 2023-05-11 09:10:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:10:16 --> Config Class Initialized
INFO - 2023-05-11 09:10:16 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:10:16 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:10:16 --> Utf8 Class Initialized
INFO - 2023-05-11 09:10:16 --> URI Class Initialized
INFO - 2023-05-11 09:10:16 --> Router Class Initialized
INFO - 2023-05-11 09:10:16 --> Output Class Initialized
INFO - 2023-05-11 09:10:16 --> Security Class Initialized
DEBUG - 2023-05-11 09:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:10:16 --> Input Class Initialized
INFO - 2023-05-11 09:10:16 --> Language Class Initialized
INFO - 2023-05-11 09:10:16 --> Loader Class Initialized
INFO - 2023-05-11 09:10:16 --> Helper loaded: url_helper
INFO - 2023-05-11 09:10:16 --> Helper loaded: file_helper
INFO - 2023-05-11 09:10:16 --> Helper loaded: html_helper
INFO - 2023-05-11 09:10:16 --> Helper loaded: text_helper
INFO - 2023-05-11 09:10:16 --> Helper loaded: form_helper
INFO - 2023-05-11 09:10:16 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:10:16 --> Helper loaded: security_helper
INFO - 2023-05-11 09:10:16 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:10:16 --> Database Driver Class Initialized
INFO - 2023-05-11 09:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:10:16 --> Parser Class Initialized
INFO - 2023-05-11 09:10:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:10:16 --> Pagination Class Initialized
INFO - 2023-05-11 09:10:16 --> Form Validation Class Initialized
INFO - 2023-05-11 09:10:16 --> Controller Class Initialized
INFO - 2023-05-11 09:10:16 --> Model Class Initialized
DEBUG - 2023-05-11 09:10:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:10:16 --> Model Class Initialized
INFO - 2023-05-11 09:10:16 --> Final output sent to browser
DEBUG - 2023-05-11 09:10:16 --> Total execution time: 0.0219
ERROR - 2023-05-11 09:10:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:10:16 --> Config Class Initialized
INFO - 2023-05-11 09:10:16 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:10:16 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:10:16 --> Utf8 Class Initialized
INFO - 2023-05-11 09:10:16 --> URI Class Initialized
DEBUG - 2023-05-11 09:10:16 --> No URI present. Default controller set.
INFO - 2023-05-11 09:10:16 --> Router Class Initialized
INFO - 2023-05-11 09:10:16 --> Output Class Initialized
INFO - 2023-05-11 09:10:16 --> Security Class Initialized
DEBUG - 2023-05-11 09:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:10:16 --> Input Class Initialized
INFO - 2023-05-11 09:10:16 --> Language Class Initialized
INFO - 2023-05-11 09:10:16 --> Loader Class Initialized
INFO - 2023-05-11 09:10:16 --> Helper loaded: url_helper
INFO - 2023-05-11 09:10:16 --> Helper loaded: file_helper
INFO - 2023-05-11 09:10:16 --> Helper loaded: html_helper
INFO - 2023-05-11 09:10:16 --> Helper loaded: text_helper
INFO - 2023-05-11 09:10:16 --> Helper loaded: form_helper
INFO - 2023-05-11 09:10:16 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:10:16 --> Helper loaded: security_helper
INFO - 2023-05-11 09:10:16 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:10:16 --> Database Driver Class Initialized
INFO - 2023-05-11 09:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:10:16 --> Parser Class Initialized
INFO - 2023-05-11 09:10:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:10:16 --> Pagination Class Initialized
INFO - 2023-05-11 09:10:16 --> Form Validation Class Initialized
INFO - 2023-05-11 09:10:16 --> Controller Class Initialized
INFO - 2023-05-11 09:10:16 --> Model Class Initialized
DEBUG - 2023-05-11 09:10:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:10:16 --> Model Class Initialized
DEBUG - 2023-05-11 09:10:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:10:16 --> Model Class Initialized
INFO - 2023-05-11 09:10:16 --> Model Class Initialized
INFO - 2023-05-11 09:10:16 --> Model Class Initialized
INFO - 2023-05-11 09:10:16 --> Model Class Initialized
DEBUG - 2023-05-11 09:10:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:10:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:10:16 --> Model Class Initialized
INFO - 2023-05-11 09:10:16 --> Model Class Initialized
INFO - 2023-05-11 09:10:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-11 09:10:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:10:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 09:10:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 09:10:16 --> Model Class Initialized
INFO - 2023-05-11 09:10:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 09:10:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 09:10:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 09:10:16 --> Final output sent to browser
DEBUG - 2023-05-11 09:10:16 --> Total execution time: 0.1791
ERROR - 2023-05-11 09:10:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:10:17 --> Config Class Initialized
INFO - 2023-05-11 09:10:17 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:10:17 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:10:17 --> Utf8 Class Initialized
INFO - 2023-05-11 09:10:17 --> URI Class Initialized
INFO - 2023-05-11 09:10:17 --> Router Class Initialized
INFO - 2023-05-11 09:10:17 --> Output Class Initialized
INFO - 2023-05-11 09:10:17 --> Security Class Initialized
DEBUG - 2023-05-11 09:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:10:17 --> Input Class Initialized
INFO - 2023-05-11 09:10:17 --> Language Class Initialized
INFO - 2023-05-11 09:10:17 --> Loader Class Initialized
INFO - 2023-05-11 09:10:17 --> Helper loaded: url_helper
INFO - 2023-05-11 09:10:17 --> Helper loaded: file_helper
INFO - 2023-05-11 09:10:17 --> Helper loaded: html_helper
INFO - 2023-05-11 09:10:17 --> Helper loaded: text_helper
INFO - 2023-05-11 09:10:17 --> Helper loaded: form_helper
INFO - 2023-05-11 09:10:17 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:10:17 --> Helper loaded: security_helper
INFO - 2023-05-11 09:10:17 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:10:17 --> Database Driver Class Initialized
INFO - 2023-05-11 09:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:10:17 --> Parser Class Initialized
INFO - 2023-05-11 09:10:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:10:17 --> Pagination Class Initialized
INFO - 2023-05-11 09:10:17 --> Form Validation Class Initialized
INFO - 2023-05-11 09:10:17 --> Controller Class Initialized
DEBUG - 2023-05-11 09:10:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:10:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:10:17 --> Model Class Initialized
INFO - 2023-05-11 09:10:17 --> Final output sent to browser
DEBUG - 2023-05-11 09:10:17 --> Total execution time: 0.0124
ERROR - 2023-05-11 09:10:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:10:33 --> Config Class Initialized
INFO - 2023-05-11 09:10:33 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:10:33 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:10:33 --> Utf8 Class Initialized
INFO - 2023-05-11 09:10:33 --> URI Class Initialized
INFO - 2023-05-11 09:10:33 --> Router Class Initialized
INFO - 2023-05-11 09:10:33 --> Output Class Initialized
INFO - 2023-05-11 09:10:33 --> Security Class Initialized
DEBUG - 2023-05-11 09:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:10:33 --> Input Class Initialized
INFO - 2023-05-11 09:10:33 --> Language Class Initialized
INFO - 2023-05-11 09:10:33 --> Loader Class Initialized
INFO - 2023-05-11 09:10:33 --> Helper loaded: url_helper
INFO - 2023-05-11 09:10:33 --> Helper loaded: file_helper
INFO - 2023-05-11 09:10:33 --> Helper loaded: html_helper
INFO - 2023-05-11 09:10:33 --> Helper loaded: text_helper
INFO - 2023-05-11 09:10:33 --> Helper loaded: form_helper
INFO - 2023-05-11 09:10:33 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:10:33 --> Helper loaded: security_helper
INFO - 2023-05-11 09:10:33 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:10:33 --> Database Driver Class Initialized
INFO - 2023-05-11 09:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:10:33 --> Parser Class Initialized
INFO - 2023-05-11 09:10:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:10:33 --> Pagination Class Initialized
INFO - 2023-05-11 09:10:33 --> Form Validation Class Initialized
INFO - 2023-05-11 09:10:33 --> Controller Class Initialized
INFO - 2023-05-11 09:10:33 --> Model Class Initialized
INFO - 2023-05-11 09:10:33 --> Model Class Initialized
INFO - 2023-05-11 09:10:33 --> Model Class Initialized
INFO - 2023-05-11 09:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/stock_report_batch_wise.php
DEBUG - 2023-05-11 09:10:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 09:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 09:10:33 --> Model Class Initialized
INFO - 2023-05-11 09:10:33 --> Model Class Initialized
INFO - 2023-05-11 09:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 09:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 09:10:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 09:10:33 --> Final output sent to browser
DEBUG - 2023-05-11 09:10:33 --> Total execution time: 0.1543
ERROR - 2023-05-11 09:10:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:10:34 --> Config Class Initialized
INFO - 2023-05-11 09:10:34 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:10:34 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:10:34 --> Utf8 Class Initialized
INFO - 2023-05-11 09:10:34 --> URI Class Initialized
INFO - 2023-05-11 09:10:34 --> Router Class Initialized
INFO - 2023-05-11 09:10:34 --> Output Class Initialized
INFO - 2023-05-11 09:10:34 --> Security Class Initialized
DEBUG - 2023-05-11 09:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:10:34 --> Input Class Initialized
INFO - 2023-05-11 09:10:34 --> Language Class Initialized
INFO - 2023-05-11 09:10:34 --> Loader Class Initialized
INFO - 2023-05-11 09:10:34 --> Helper loaded: url_helper
INFO - 2023-05-11 09:10:34 --> Helper loaded: file_helper
INFO - 2023-05-11 09:10:34 --> Helper loaded: html_helper
INFO - 2023-05-11 09:10:34 --> Helper loaded: text_helper
INFO - 2023-05-11 09:10:34 --> Helper loaded: form_helper
INFO - 2023-05-11 09:10:34 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:10:34 --> Helper loaded: security_helper
INFO - 2023-05-11 09:10:34 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:10:34 --> Database Driver Class Initialized
INFO - 2023-05-11 09:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:10:34 --> Parser Class Initialized
INFO - 2023-05-11 09:10:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:10:34 --> Pagination Class Initialized
INFO - 2023-05-11 09:10:34 --> Form Validation Class Initialized
INFO - 2023-05-11 09:10:34 --> Controller Class Initialized
INFO - 2023-05-11 09:10:34 --> Model Class Initialized
INFO - 2023-05-11 09:10:34 --> Model Class Initialized
INFO - 2023-05-11 09:10:34 --> Final output sent to browser
DEBUG - 2023-05-11 09:10:34 --> Total execution time: 0.0233
ERROR - 2023-05-11 09:12:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:12:41 --> Config Class Initialized
INFO - 2023-05-11 09:12:41 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:12:41 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:12:41 --> Utf8 Class Initialized
INFO - 2023-05-11 09:12:41 --> URI Class Initialized
INFO - 2023-05-11 09:12:41 --> Router Class Initialized
INFO - 2023-05-11 09:12:41 --> Output Class Initialized
INFO - 2023-05-11 09:12:41 --> Security Class Initialized
DEBUG - 2023-05-11 09:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:12:41 --> Input Class Initialized
INFO - 2023-05-11 09:12:41 --> Language Class Initialized
INFO - 2023-05-11 09:12:41 --> Loader Class Initialized
INFO - 2023-05-11 09:12:41 --> Helper loaded: url_helper
INFO - 2023-05-11 09:12:41 --> Helper loaded: file_helper
INFO - 2023-05-11 09:12:41 --> Helper loaded: html_helper
INFO - 2023-05-11 09:12:41 --> Helper loaded: text_helper
INFO - 2023-05-11 09:12:41 --> Helper loaded: form_helper
INFO - 2023-05-11 09:12:41 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:12:41 --> Helper loaded: security_helper
INFO - 2023-05-11 09:12:41 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:12:41 --> Database Driver Class Initialized
INFO - 2023-05-11 09:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:12:41 --> Parser Class Initialized
INFO - 2023-05-11 09:12:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:12:41 --> Pagination Class Initialized
INFO - 2023-05-11 09:12:41 --> Form Validation Class Initialized
INFO - 2023-05-11 09:12:41 --> Controller Class Initialized
INFO - 2023-05-11 09:12:41 --> Model Class Initialized
INFO - 2023-05-11 09:12:41 --> Model Class Initialized
INFO - 2023-05-11 09:12:41 --> Final output sent to browser
DEBUG - 2023-05-11 09:12:41 --> Total execution time: 0.0332
ERROR - 2023-05-11 09:16:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:16:05 --> Config Class Initialized
INFO - 2023-05-11 09:16:05 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:16:05 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:16:05 --> Utf8 Class Initialized
INFO - 2023-05-11 09:16:05 --> URI Class Initialized
INFO - 2023-05-11 09:16:05 --> Router Class Initialized
INFO - 2023-05-11 09:16:05 --> Output Class Initialized
INFO - 2023-05-11 09:16:05 --> Security Class Initialized
DEBUG - 2023-05-11 09:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:16:05 --> Input Class Initialized
INFO - 2023-05-11 09:16:05 --> Language Class Initialized
INFO - 2023-05-11 09:16:05 --> Loader Class Initialized
INFO - 2023-05-11 09:16:05 --> Helper loaded: url_helper
INFO - 2023-05-11 09:16:05 --> Helper loaded: file_helper
INFO - 2023-05-11 09:16:05 --> Helper loaded: html_helper
INFO - 2023-05-11 09:16:05 --> Helper loaded: text_helper
INFO - 2023-05-11 09:16:05 --> Helper loaded: form_helper
INFO - 2023-05-11 09:16:05 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:16:05 --> Helper loaded: security_helper
INFO - 2023-05-11 09:16:05 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:16:05 --> Database Driver Class Initialized
INFO - 2023-05-11 09:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:16:05 --> Parser Class Initialized
INFO - 2023-05-11 09:16:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:16:05 --> Pagination Class Initialized
INFO - 2023-05-11 09:16:05 --> Form Validation Class Initialized
INFO - 2023-05-11 09:16:05 --> Controller Class Initialized
DEBUG - 2023-05-11 09:16:05 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:16:05 --> Model Class Initialized
INFO - 2023-05-11 09:16:05 --> Model Class Initialized
INFO - 2023-05-11 09:16:05 --> Model Class Initialized
INFO - 2023-05-11 09:16:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/product/product_details.php
DEBUG - 2023-05-11 09:16:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:16:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 09:16:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 09:16:05 --> Model Class Initialized
INFO - 2023-05-11 09:16:05 --> Model Class Initialized
INFO - 2023-05-11 09:16:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 09:16:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 09:16:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 09:16:06 --> Final output sent to browser
DEBUG - 2023-05-11 09:16:06 --> Total execution time: 0.1598
ERROR - 2023-05-11 09:17:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:17:16 --> Config Class Initialized
INFO - 2023-05-11 09:17:16 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:17:16 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:17:16 --> Utf8 Class Initialized
INFO - 2023-05-11 09:17:16 --> URI Class Initialized
DEBUG - 2023-05-11 09:17:16 --> No URI present. Default controller set.
INFO - 2023-05-11 09:17:16 --> Router Class Initialized
INFO - 2023-05-11 09:17:16 --> Output Class Initialized
INFO - 2023-05-11 09:17:16 --> Security Class Initialized
DEBUG - 2023-05-11 09:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:17:16 --> Input Class Initialized
INFO - 2023-05-11 09:17:16 --> Language Class Initialized
INFO - 2023-05-11 09:17:16 --> Loader Class Initialized
INFO - 2023-05-11 09:17:16 --> Helper loaded: url_helper
INFO - 2023-05-11 09:17:16 --> Helper loaded: file_helper
INFO - 2023-05-11 09:17:16 --> Helper loaded: html_helper
INFO - 2023-05-11 09:17:16 --> Helper loaded: text_helper
INFO - 2023-05-11 09:17:16 --> Helper loaded: form_helper
INFO - 2023-05-11 09:17:16 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:17:16 --> Helper loaded: security_helper
INFO - 2023-05-11 09:17:16 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:17:16 --> Database Driver Class Initialized
INFO - 2023-05-11 09:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:17:16 --> Parser Class Initialized
INFO - 2023-05-11 09:17:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:17:16 --> Pagination Class Initialized
INFO - 2023-05-11 09:17:16 --> Form Validation Class Initialized
INFO - 2023-05-11 09:17:16 --> Controller Class Initialized
INFO - 2023-05-11 09:17:16 --> Model Class Initialized
DEBUG - 2023-05-11 09:17:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:17:16 --> Model Class Initialized
DEBUG - 2023-05-11 09:17:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:17:16 --> Model Class Initialized
INFO - 2023-05-11 09:17:16 --> Model Class Initialized
INFO - 2023-05-11 09:17:16 --> Model Class Initialized
INFO - 2023-05-11 09:17:16 --> Model Class Initialized
DEBUG - 2023-05-11 09:17:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:17:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:17:16 --> Model Class Initialized
INFO - 2023-05-11 09:17:16 --> Model Class Initialized
INFO - 2023-05-11 09:17:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-11 09:17:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:17:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 09:17:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 09:17:16 --> Model Class Initialized
INFO - 2023-05-11 09:17:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 09:17:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 09:17:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 09:17:16 --> Final output sent to browser
DEBUG - 2023-05-11 09:17:16 --> Total execution time: 0.1893
ERROR - 2023-05-11 09:20:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:20:26 --> Config Class Initialized
INFO - 2023-05-11 09:20:26 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:20:26 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:20:26 --> Utf8 Class Initialized
INFO - 2023-05-11 09:20:26 --> URI Class Initialized
INFO - 2023-05-11 09:20:26 --> Router Class Initialized
INFO - 2023-05-11 09:20:26 --> Output Class Initialized
INFO - 2023-05-11 09:20:26 --> Security Class Initialized
DEBUG - 2023-05-11 09:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:20:26 --> Input Class Initialized
INFO - 2023-05-11 09:20:26 --> Language Class Initialized
INFO - 2023-05-11 09:20:26 --> Loader Class Initialized
INFO - 2023-05-11 09:20:26 --> Helper loaded: url_helper
INFO - 2023-05-11 09:20:26 --> Helper loaded: file_helper
INFO - 2023-05-11 09:20:26 --> Helper loaded: html_helper
INFO - 2023-05-11 09:20:26 --> Helper loaded: text_helper
INFO - 2023-05-11 09:20:26 --> Helper loaded: form_helper
INFO - 2023-05-11 09:20:26 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:20:26 --> Helper loaded: security_helper
INFO - 2023-05-11 09:20:26 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:20:26 --> Database Driver Class Initialized
INFO - 2023-05-11 09:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:20:26 --> Parser Class Initialized
INFO - 2023-05-11 09:20:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:20:26 --> Pagination Class Initialized
INFO - 2023-05-11 09:20:26 --> Form Validation Class Initialized
INFO - 2023-05-11 09:20:26 --> Controller Class Initialized
INFO - 2023-05-11 09:20:26 --> Model Class Initialized
DEBUG - 2023-05-11 09:20:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:20:26 --> Model Class Initialized
INFO - 2023-05-11 09:20:26 --> Model Class Initialized
INFO - 2023-05-11 15:20:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/profit_product_report.php
DEBUG - 2023-05-11 15:20:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 15:20:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 15:20:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 15:20:26 --> Model Class Initialized
INFO - 2023-05-11 15:20:26 --> Model Class Initialized
INFO - 2023-05-11 15:20:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 15:20:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 15:20:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 15:20:26 --> Final output sent to browser
DEBUG - 2023-05-11 15:20:26 --> Total execution time: 0.1415
ERROR - 2023-05-11 09:20:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:20:32 --> Config Class Initialized
INFO - 2023-05-11 09:20:32 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:20:32 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:20:32 --> Utf8 Class Initialized
INFO - 2023-05-11 09:20:32 --> URI Class Initialized
INFO - 2023-05-11 09:20:32 --> Router Class Initialized
INFO - 2023-05-11 09:20:32 --> Output Class Initialized
INFO - 2023-05-11 09:20:32 --> Security Class Initialized
DEBUG - 2023-05-11 09:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:20:32 --> Input Class Initialized
INFO - 2023-05-11 09:20:32 --> Language Class Initialized
INFO - 2023-05-11 09:20:32 --> Loader Class Initialized
INFO - 2023-05-11 09:20:32 --> Helper loaded: url_helper
INFO - 2023-05-11 09:20:32 --> Helper loaded: file_helper
INFO - 2023-05-11 09:20:32 --> Helper loaded: html_helper
INFO - 2023-05-11 09:20:32 --> Helper loaded: text_helper
INFO - 2023-05-11 09:20:32 --> Helper loaded: form_helper
INFO - 2023-05-11 09:20:32 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:20:32 --> Helper loaded: security_helper
INFO - 2023-05-11 09:20:32 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:20:32 --> Database Driver Class Initialized
INFO - 2023-05-11 09:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:20:32 --> Parser Class Initialized
INFO - 2023-05-11 09:20:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:20:32 --> Pagination Class Initialized
INFO - 2023-05-11 09:20:32 --> Form Validation Class Initialized
INFO - 2023-05-11 09:20:32 --> Controller Class Initialized
INFO - 2023-05-11 09:20:32 --> Model Class Initialized
DEBUG - 2023-05-11 09:20:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:20:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:20:32 --> Model Class Initialized
DEBUG - 2023-05-11 09:20:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:20:32 --> Model Class Initialized
INFO - 2023-05-11 09:20:32 --> Final output sent to browser
DEBUG - 2023-05-11 09:20:32 --> Total execution time: 0.0188
ERROR - 2023-05-11 09:20:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:20:43 --> Config Class Initialized
INFO - 2023-05-11 09:20:43 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:20:43 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:20:43 --> Utf8 Class Initialized
INFO - 2023-05-11 09:20:43 --> URI Class Initialized
INFO - 2023-05-11 09:20:43 --> Router Class Initialized
INFO - 2023-05-11 09:20:43 --> Output Class Initialized
INFO - 2023-05-11 09:20:43 --> Security Class Initialized
DEBUG - 2023-05-11 09:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:20:43 --> Input Class Initialized
INFO - 2023-05-11 09:20:43 --> Language Class Initialized
INFO - 2023-05-11 09:20:43 --> Loader Class Initialized
INFO - 2023-05-11 09:20:43 --> Helper loaded: url_helper
INFO - 2023-05-11 09:20:43 --> Helper loaded: file_helper
INFO - 2023-05-11 09:20:43 --> Helper loaded: html_helper
INFO - 2023-05-11 09:20:43 --> Helper loaded: text_helper
INFO - 2023-05-11 09:20:43 --> Helper loaded: form_helper
INFO - 2023-05-11 09:20:43 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:20:43 --> Helper loaded: security_helper
INFO - 2023-05-11 09:20:43 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:20:43 --> Database Driver Class Initialized
INFO - 2023-05-11 09:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:20:43 --> Parser Class Initialized
INFO - 2023-05-11 09:20:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:20:43 --> Pagination Class Initialized
INFO - 2023-05-11 09:20:43 --> Form Validation Class Initialized
INFO - 2023-05-11 09:20:43 --> Controller Class Initialized
INFO - 2023-05-11 09:20:43 --> Model Class Initialized
DEBUG - 2023-05-11 09:20:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:20:43 --> Model Class Initialized
INFO - 2023-05-11 09:20:43 --> Model Class Initialized
INFO - 2023-05-11 15:20:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/productwise_profit_view.php
DEBUG - 2023-05-11 15:20:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 15:20:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 15:20:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 15:20:43 --> Model Class Initialized
INFO - 2023-05-11 15:20:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 15:20:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 15:20:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 15:20:43 --> Final output sent to browser
DEBUG - 2023-05-11 15:20:43 --> Total execution time: 0.1470
ERROR - 2023-05-11 09:20:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:20:52 --> Config Class Initialized
INFO - 2023-05-11 09:20:52 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:20:52 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:20:52 --> Utf8 Class Initialized
INFO - 2023-05-11 09:20:52 --> URI Class Initialized
INFO - 2023-05-11 09:20:52 --> Router Class Initialized
INFO - 2023-05-11 09:20:52 --> Output Class Initialized
INFO - 2023-05-11 09:20:52 --> Security Class Initialized
DEBUG - 2023-05-11 09:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:20:52 --> Input Class Initialized
INFO - 2023-05-11 09:20:52 --> Language Class Initialized
INFO - 2023-05-11 09:20:52 --> Loader Class Initialized
INFO - 2023-05-11 09:20:52 --> Helper loaded: url_helper
INFO - 2023-05-11 09:20:52 --> Helper loaded: file_helper
INFO - 2023-05-11 09:20:52 --> Helper loaded: html_helper
INFO - 2023-05-11 09:20:52 --> Helper loaded: text_helper
INFO - 2023-05-11 09:20:52 --> Helper loaded: form_helper
INFO - 2023-05-11 09:20:52 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:20:52 --> Helper loaded: security_helper
INFO - 2023-05-11 09:20:52 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:20:52 --> Database Driver Class Initialized
INFO - 2023-05-11 09:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:20:52 --> Parser Class Initialized
INFO - 2023-05-11 09:20:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:20:52 --> Pagination Class Initialized
INFO - 2023-05-11 09:20:52 --> Form Validation Class Initialized
INFO - 2023-05-11 09:20:52 --> Controller Class Initialized
INFO - 2023-05-11 09:20:52 --> Model Class Initialized
DEBUG - 2023-05-11 09:20:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:20:52 --> Model Class Initialized
INFO - 2023-05-11 15:20:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/product_report.php
DEBUG - 2023-05-11 15:20:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 15:20:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 15:20:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 15:20:52 --> Model Class Initialized
INFO - 2023-05-11 15:20:52 --> Model Class Initialized
INFO - 2023-05-11 15:20:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 15:20:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 15:20:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 15:20:52 --> Final output sent to browser
DEBUG - 2023-05-11 15:20:52 --> Total execution time: 0.1508
ERROR - 2023-05-11 09:25:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:25:50 --> Config Class Initialized
INFO - 2023-05-11 09:25:50 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:25:50 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:25:50 --> Utf8 Class Initialized
INFO - 2023-05-11 09:25:50 --> URI Class Initialized
DEBUG - 2023-05-11 09:25:50 --> No URI present. Default controller set.
INFO - 2023-05-11 09:25:50 --> Router Class Initialized
INFO - 2023-05-11 09:25:50 --> Output Class Initialized
INFO - 2023-05-11 09:25:50 --> Security Class Initialized
DEBUG - 2023-05-11 09:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:25:50 --> Input Class Initialized
INFO - 2023-05-11 09:25:50 --> Language Class Initialized
INFO - 2023-05-11 09:25:50 --> Loader Class Initialized
INFO - 2023-05-11 09:25:50 --> Helper loaded: url_helper
INFO - 2023-05-11 09:25:50 --> Helper loaded: file_helper
INFO - 2023-05-11 09:25:50 --> Helper loaded: html_helper
INFO - 2023-05-11 09:25:50 --> Helper loaded: text_helper
INFO - 2023-05-11 09:25:50 --> Helper loaded: form_helper
INFO - 2023-05-11 09:25:50 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:25:50 --> Helper loaded: security_helper
INFO - 2023-05-11 09:25:50 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:25:50 --> Database Driver Class Initialized
INFO - 2023-05-11 09:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:25:50 --> Parser Class Initialized
INFO - 2023-05-11 09:25:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:25:50 --> Pagination Class Initialized
INFO - 2023-05-11 09:25:50 --> Form Validation Class Initialized
INFO - 2023-05-11 09:25:50 --> Controller Class Initialized
INFO - 2023-05-11 09:25:50 --> Model Class Initialized
DEBUG - 2023-05-11 09:25:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:25:50 --> Model Class Initialized
DEBUG - 2023-05-11 09:25:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:25:50 --> Model Class Initialized
INFO - 2023-05-11 09:25:50 --> Model Class Initialized
INFO - 2023-05-11 09:25:50 --> Model Class Initialized
INFO - 2023-05-11 09:25:50 --> Model Class Initialized
DEBUG - 2023-05-11 09:25:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:25:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:25:50 --> Model Class Initialized
INFO - 2023-05-11 09:25:50 --> Model Class Initialized
INFO - 2023-05-11 09:25:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-11 09:25:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:25:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 09:25:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 09:25:50 --> Model Class Initialized
INFO - 2023-05-11 09:25:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 09:25:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 09:25:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 09:25:50 --> Final output sent to browser
DEBUG - 2023-05-11 09:25:50 --> Total execution time: 0.1910
ERROR - 2023-05-11 09:26:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:26:38 --> Config Class Initialized
INFO - 2023-05-11 09:26:38 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:26:38 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:26:38 --> Utf8 Class Initialized
INFO - 2023-05-11 09:26:38 --> URI Class Initialized
DEBUG - 2023-05-11 09:26:38 --> No URI present. Default controller set.
INFO - 2023-05-11 09:26:38 --> Router Class Initialized
INFO - 2023-05-11 09:26:38 --> Output Class Initialized
INFO - 2023-05-11 09:26:38 --> Security Class Initialized
DEBUG - 2023-05-11 09:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:26:38 --> Input Class Initialized
INFO - 2023-05-11 09:26:38 --> Language Class Initialized
INFO - 2023-05-11 09:26:38 --> Loader Class Initialized
INFO - 2023-05-11 09:26:38 --> Helper loaded: url_helper
INFO - 2023-05-11 09:26:38 --> Helper loaded: file_helper
INFO - 2023-05-11 09:26:38 --> Helper loaded: html_helper
INFO - 2023-05-11 09:26:38 --> Helper loaded: text_helper
INFO - 2023-05-11 09:26:38 --> Helper loaded: form_helper
INFO - 2023-05-11 09:26:38 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:26:38 --> Helper loaded: security_helper
INFO - 2023-05-11 09:26:38 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:26:38 --> Database Driver Class Initialized
INFO - 2023-05-11 09:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:26:38 --> Parser Class Initialized
INFO - 2023-05-11 09:26:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:26:38 --> Pagination Class Initialized
INFO - 2023-05-11 09:26:38 --> Form Validation Class Initialized
INFO - 2023-05-11 09:26:38 --> Controller Class Initialized
INFO - 2023-05-11 09:26:38 --> Model Class Initialized
DEBUG - 2023-05-11 09:26:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-11 09:26:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:26:38 --> Config Class Initialized
INFO - 2023-05-11 09:26:38 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:26:38 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:26:38 --> Utf8 Class Initialized
INFO - 2023-05-11 09:26:38 --> URI Class Initialized
INFO - 2023-05-11 09:26:38 --> Router Class Initialized
INFO - 2023-05-11 09:26:38 --> Output Class Initialized
INFO - 2023-05-11 09:26:38 --> Security Class Initialized
DEBUG - 2023-05-11 09:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:26:38 --> Input Class Initialized
INFO - 2023-05-11 09:26:38 --> Language Class Initialized
INFO - 2023-05-11 09:26:38 --> Loader Class Initialized
INFO - 2023-05-11 09:26:38 --> Helper loaded: url_helper
INFO - 2023-05-11 09:26:38 --> Helper loaded: file_helper
INFO - 2023-05-11 09:26:38 --> Helper loaded: html_helper
INFO - 2023-05-11 09:26:38 --> Helper loaded: text_helper
INFO - 2023-05-11 09:26:38 --> Helper loaded: form_helper
INFO - 2023-05-11 09:26:38 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:26:38 --> Helper loaded: security_helper
INFO - 2023-05-11 09:26:38 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:26:38 --> Database Driver Class Initialized
INFO - 2023-05-11 09:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:26:38 --> Parser Class Initialized
INFO - 2023-05-11 09:26:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:26:38 --> Pagination Class Initialized
INFO - 2023-05-11 09:26:38 --> Form Validation Class Initialized
INFO - 2023-05-11 09:26:38 --> Controller Class Initialized
INFO - 2023-05-11 09:26:38 --> Model Class Initialized
DEBUG - 2023-05-11 09:26:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:26:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-11 09:26:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:26:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 09:26:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 09:26:38 --> Model Class Initialized
INFO - 2023-05-11 09:26:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 09:26:38 --> Final output sent to browser
DEBUG - 2023-05-11 09:26:38 --> Total execution time: 0.0349
ERROR - 2023-05-11 09:26:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:26:54 --> Config Class Initialized
INFO - 2023-05-11 09:26:54 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:26:54 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:26:54 --> Utf8 Class Initialized
INFO - 2023-05-11 09:26:54 --> URI Class Initialized
INFO - 2023-05-11 09:26:54 --> Router Class Initialized
INFO - 2023-05-11 09:26:54 --> Output Class Initialized
INFO - 2023-05-11 09:26:54 --> Security Class Initialized
DEBUG - 2023-05-11 09:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:26:54 --> Input Class Initialized
INFO - 2023-05-11 09:26:54 --> Language Class Initialized
INFO - 2023-05-11 09:26:54 --> Loader Class Initialized
INFO - 2023-05-11 09:26:54 --> Helper loaded: url_helper
INFO - 2023-05-11 09:26:54 --> Helper loaded: file_helper
INFO - 2023-05-11 09:26:54 --> Helper loaded: html_helper
INFO - 2023-05-11 09:26:54 --> Helper loaded: text_helper
INFO - 2023-05-11 09:26:54 --> Helper loaded: form_helper
INFO - 2023-05-11 09:26:54 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:26:54 --> Helper loaded: security_helper
INFO - 2023-05-11 09:26:54 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:26:54 --> Database Driver Class Initialized
INFO - 2023-05-11 09:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:26:54 --> Parser Class Initialized
INFO - 2023-05-11 09:26:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:26:54 --> Pagination Class Initialized
INFO - 2023-05-11 09:26:54 --> Form Validation Class Initialized
INFO - 2023-05-11 09:26:54 --> Controller Class Initialized
DEBUG - 2023-05-11 09:26:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:26:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:26:54 --> Model Class Initialized
DEBUG - 2023-05-11 09:26:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:26:54 --> Model Class Initialized
DEBUG - 2023-05-11 09:26:54 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:26:54 --> Model Class Initialized
INFO - 2023-05-11 09:26:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-05-11 09:26:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:26:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 09:26:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 09:26:54 --> Model Class Initialized
INFO - 2023-05-11 09:26:54 --> Model Class Initialized
INFO - 2023-05-11 09:26:54 --> Model Class Initialized
INFO - 2023-05-11 09:26:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 09:26:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 09:26:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 09:26:54 --> Final output sent to browser
DEBUG - 2023-05-11 09:26:54 --> Total execution time: 0.1445
ERROR - 2023-05-11 09:26:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:26:55 --> Config Class Initialized
INFO - 2023-05-11 09:26:55 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:26:55 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:26:55 --> Utf8 Class Initialized
INFO - 2023-05-11 09:26:55 --> URI Class Initialized
INFO - 2023-05-11 09:26:55 --> Router Class Initialized
INFO - 2023-05-11 09:26:55 --> Output Class Initialized
INFO - 2023-05-11 09:26:55 --> Security Class Initialized
DEBUG - 2023-05-11 09:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:26:55 --> Input Class Initialized
INFO - 2023-05-11 09:26:55 --> Language Class Initialized
INFO - 2023-05-11 09:26:55 --> Loader Class Initialized
INFO - 2023-05-11 09:26:55 --> Helper loaded: url_helper
INFO - 2023-05-11 09:26:55 --> Helper loaded: file_helper
INFO - 2023-05-11 09:26:55 --> Helper loaded: html_helper
INFO - 2023-05-11 09:26:55 --> Helper loaded: text_helper
INFO - 2023-05-11 09:26:55 --> Helper loaded: form_helper
INFO - 2023-05-11 09:26:55 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:26:55 --> Helper loaded: security_helper
INFO - 2023-05-11 09:26:55 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:26:55 --> Database Driver Class Initialized
INFO - 2023-05-11 09:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:26:55 --> Parser Class Initialized
INFO - 2023-05-11 09:26:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:26:55 --> Pagination Class Initialized
INFO - 2023-05-11 09:26:55 --> Form Validation Class Initialized
INFO - 2023-05-11 09:26:55 --> Controller Class Initialized
DEBUG - 2023-05-11 09:26:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:26:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:26:55 --> Model Class Initialized
DEBUG - 2023-05-11 09:26:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:26:55 --> Model Class Initialized
INFO - 2023-05-11 09:26:55 --> Final output sent to browser
DEBUG - 2023-05-11 09:26:55 --> Total execution time: 0.0374
ERROR - 2023-05-11 09:27:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:27:17 --> Config Class Initialized
INFO - 2023-05-11 09:27:17 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:27:17 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:27:17 --> Utf8 Class Initialized
INFO - 2023-05-11 09:27:17 --> URI Class Initialized
INFO - 2023-05-11 09:27:17 --> Router Class Initialized
INFO - 2023-05-11 09:27:17 --> Output Class Initialized
INFO - 2023-05-11 09:27:17 --> Security Class Initialized
DEBUG - 2023-05-11 09:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:27:17 --> Input Class Initialized
INFO - 2023-05-11 09:27:17 --> Language Class Initialized
INFO - 2023-05-11 09:27:17 --> Loader Class Initialized
INFO - 2023-05-11 09:27:17 --> Helper loaded: url_helper
INFO - 2023-05-11 09:27:17 --> Helper loaded: file_helper
INFO - 2023-05-11 09:27:17 --> Helper loaded: html_helper
INFO - 2023-05-11 09:27:17 --> Helper loaded: text_helper
INFO - 2023-05-11 09:27:17 --> Helper loaded: form_helper
INFO - 2023-05-11 09:27:17 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:27:17 --> Helper loaded: security_helper
INFO - 2023-05-11 09:27:17 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:27:17 --> Database Driver Class Initialized
INFO - 2023-05-11 09:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:27:17 --> Parser Class Initialized
INFO - 2023-05-11 09:27:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:27:17 --> Pagination Class Initialized
INFO - 2023-05-11 09:27:17 --> Form Validation Class Initialized
INFO - 2023-05-11 09:27:17 --> Controller Class Initialized
DEBUG - 2023-05-11 09:27:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:27:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:27:17 --> Model Class Initialized
DEBUG - 2023-05-11 09:27:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:27:17 --> Model Class Initialized
INFO - 2023-05-11 09:27:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-05-11 09:27:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:27:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 09:27:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 09:27:17 --> Model Class Initialized
INFO - 2023-05-11 09:27:17 --> Model Class Initialized
INFO - 2023-05-11 09:27:17 --> Model Class Initialized
INFO - 2023-05-11 09:27:17 --> Model Class Initialized
INFO - 2023-05-11 09:27:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 09:27:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 09:27:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 09:27:17 --> Final output sent to browser
DEBUG - 2023-05-11 09:27:17 --> Total execution time: 0.1445
ERROR - 2023-05-11 09:27:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:27:39 --> Config Class Initialized
INFO - 2023-05-11 09:27:39 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:27:39 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:27:39 --> Utf8 Class Initialized
INFO - 2023-05-11 09:27:39 --> URI Class Initialized
INFO - 2023-05-11 09:27:39 --> Router Class Initialized
INFO - 2023-05-11 09:27:39 --> Output Class Initialized
INFO - 2023-05-11 09:27:39 --> Security Class Initialized
DEBUG - 2023-05-11 09:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:27:39 --> Input Class Initialized
INFO - 2023-05-11 09:27:39 --> Language Class Initialized
INFO - 2023-05-11 09:27:39 --> Loader Class Initialized
INFO - 2023-05-11 09:27:39 --> Helper loaded: url_helper
INFO - 2023-05-11 09:27:39 --> Helper loaded: file_helper
INFO - 2023-05-11 09:27:39 --> Helper loaded: html_helper
INFO - 2023-05-11 09:27:39 --> Helper loaded: text_helper
INFO - 2023-05-11 09:27:39 --> Helper loaded: form_helper
INFO - 2023-05-11 09:27:39 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:27:39 --> Helper loaded: security_helper
INFO - 2023-05-11 09:27:39 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:27:39 --> Database Driver Class Initialized
INFO - 2023-05-11 09:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:27:39 --> Parser Class Initialized
INFO - 2023-05-11 09:27:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:27:39 --> Pagination Class Initialized
INFO - 2023-05-11 09:27:39 --> Form Validation Class Initialized
INFO - 2023-05-11 09:27:39 --> Controller Class Initialized
INFO - 2023-05-11 09:27:39 --> Model Class Initialized
DEBUG - 2023-05-11 09:27:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:27:39 --> Model Class Initialized
INFO - 2023-05-11 09:27:39 --> Final output sent to browser
DEBUG - 2023-05-11 09:27:39 --> Total execution time: 0.0189
ERROR - 2023-05-11 09:27:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:27:40 --> Config Class Initialized
INFO - 2023-05-11 09:27:40 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:27:40 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:27:40 --> Utf8 Class Initialized
INFO - 2023-05-11 09:27:40 --> URI Class Initialized
DEBUG - 2023-05-11 09:27:40 --> No URI present. Default controller set.
INFO - 2023-05-11 09:27:40 --> Router Class Initialized
INFO - 2023-05-11 09:27:40 --> Output Class Initialized
INFO - 2023-05-11 09:27:40 --> Security Class Initialized
DEBUG - 2023-05-11 09:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:27:40 --> Input Class Initialized
INFO - 2023-05-11 09:27:40 --> Language Class Initialized
INFO - 2023-05-11 09:27:40 --> Loader Class Initialized
INFO - 2023-05-11 09:27:40 --> Helper loaded: url_helper
INFO - 2023-05-11 09:27:40 --> Helper loaded: file_helper
INFO - 2023-05-11 09:27:40 --> Helper loaded: html_helper
INFO - 2023-05-11 09:27:40 --> Helper loaded: text_helper
INFO - 2023-05-11 09:27:40 --> Helper loaded: form_helper
INFO - 2023-05-11 09:27:40 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:27:40 --> Helper loaded: security_helper
INFO - 2023-05-11 09:27:40 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:27:40 --> Database Driver Class Initialized
INFO - 2023-05-11 09:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:27:40 --> Parser Class Initialized
INFO - 2023-05-11 09:27:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:27:40 --> Pagination Class Initialized
INFO - 2023-05-11 09:27:40 --> Form Validation Class Initialized
INFO - 2023-05-11 09:27:40 --> Controller Class Initialized
INFO - 2023-05-11 09:27:40 --> Model Class Initialized
DEBUG - 2023-05-11 09:27:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:27:40 --> Model Class Initialized
DEBUG - 2023-05-11 09:27:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:27:40 --> Model Class Initialized
INFO - 2023-05-11 09:27:40 --> Model Class Initialized
INFO - 2023-05-11 09:27:40 --> Model Class Initialized
INFO - 2023-05-11 09:27:40 --> Model Class Initialized
DEBUG - 2023-05-11 09:27:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:27:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:27:40 --> Model Class Initialized
INFO - 2023-05-11 09:27:40 --> Model Class Initialized
INFO - 2023-05-11 09:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-11 09:27:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 09:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 09:27:40 --> Model Class Initialized
INFO - 2023-05-11 09:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 09:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 09:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 09:27:40 --> Final output sent to browser
DEBUG - 2023-05-11 09:27:40 --> Total execution time: 0.0658
ERROR - 2023-05-11 09:34:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:34:53 --> Config Class Initialized
INFO - 2023-05-11 09:34:53 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:34:53 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:34:53 --> Utf8 Class Initialized
INFO - 2023-05-11 09:34:53 --> URI Class Initialized
DEBUG - 2023-05-11 09:34:53 --> No URI present. Default controller set.
INFO - 2023-05-11 09:34:53 --> Router Class Initialized
INFO - 2023-05-11 09:34:53 --> Output Class Initialized
INFO - 2023-05-11 09:34:53 --> Security Class Initialized
DEBUG - 2023-05-11 09:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:34:53 --> Input Class Initialized
INFO - 2023-05-11 09:34:53 --> Language Class Initialized
INFO - 2023-05-11 09:34:53 --> Loader Class Initialized
INFO - 2023-05-11 09:34:53 --> Helper loaded: url_helper
INFO - 2023-05-11 09:34:53 --> Helper loaded: file_helper
INFO - 2023-05-11 09:34:53 --> Helper loaded: html_helper
INFO - 2023-05-11 09:34:53 --> Helper loaded: text_helper
INFO - 2023-05-11 09:34:53 --> Helper loaded: form_helper
INFO - 2023-05-11 09:34:53 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:34:53 --> Helper loaded: security_helper
INFO - 2023-05-11 09:34:53 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:34:53 --> Database Driver Class Initialized
INFO - 2023-05-11 09:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:34:53 --> Parser Class Initialized
INFO - 2023-05-11 09:34:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:34:53 --> Pagination Class Initialized
INFO - 2023-05-11 09:34:53 --> Form Validation Class Initialized
INFO - 2023-05-11 09:34:53 --> Controller Class Initialized
INFO - 2023-05-11 09:34:53 --> Model Class Initialized
DEBUG - 2023-05-11 09:34:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:34:53 --> Model Class Initialized
DEBUG - 2023-05-11 09:34:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:34:53 --> Model Class Initialized
INFO - 2023-05-11 09:34:53 --> Model Class Initialized
INFO - 2023-05-11 09:34:53 --> Model Class Initialized
INFO - 2023-05-11 09:34:53 --> Model Class Initialized
DEBUG - 2023-05-11 09:34:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:34:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:34:53 --> Model Class Initialized
INFO - 2023-05-11 09:34:53 --> Model Class Initialized
INFO - 2023-05-11 09:34:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-11 09:34:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:34:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 09:34:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 09:34:53 --> Model Class Initialized
INFO - 2023-05-11 09:34:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 09:34:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 09:34:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 09:34:53 --> Final output sent to browser
DEBUG - 2023-05-11 09:34:53 --> Total execution time: 0.1830
ERROR - 2023-05-11 09:35:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:35:34 --> Config Class Initialized
INFO - 2023-05-11 09:35:34 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:35:34 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:35:34 --> Utf8 Class Initialized
INFO - 2023-05-11 09:35:34 --> URI Class Initialized
INFO - 2023-05-11 09:35:34 --> Router Class Initialized
INFO - 2023-05-11 09:35:34 --> Output Class Initialized
INFO - 2023-05-11 09:35:34 --> Security Class Initialized
DEBUG - 2023-05-11 09:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:35:34 --> Input Class Initialized
INFO - 2023-05-11 09:35:34 --> Language Class Initialized
INFO - 2023-05-11 09:35:34 --> Loader Class Initialized
INFO - 2023-05-11 09:35:34 --> Helper loaded: url_helper
INFO - 2023-05-11 09:35:34 --> Helper loaded: file_helper
INFO - 2023-05-11 09:35:34 --> Helper loaded: html_helper
INFO - 2023-05-11 09:35:34 --> Helper loaded: text_helper
INFO - 2023-05-11 09:35:34 --> Helper loaded: form_helper
INFO - 2023-05-11 09:35:34 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:35:34 --> Helper loaded: security_helper
INFO - 2023-05-11 09:35:34 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:35:34 --> Database Driver Class Initialized
INFO - 2023-05-11 09:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:35:34 --> Parser Class Initialized
INFO - 2023-05-11 09:35:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:35:34 --> Pagination Class Initialized
INFO - 2023-05-11 09:35:34 --> Form Validation Class Initialized
INFO - 2023-05-11 09:35:34 --> Controller Class Initialized
INFO - 2023-05-11 09:35:34 --> Model Class Initialized
DEBUG - 2023-05-11 09:35:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:35:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:35:34 --> Model Class Initialized
DEBUG - 2023-05-11 09:35:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:35:34 --> Model Class Initialized
INFO - 2023-05-11 09:35:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-11 09:35:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:35:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 09:35:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 09:35:34 --> Model Class Initialized
INFO - 2023-05-11 09:35:34 --> Model Class Initialized
INFO - 2023-05-11 09:35:34 --> Model Class Initialized
INFO - 2023-05-11 09:35:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 09:35:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 09:35:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 09:35:34 --> Final output sent to browser
DEBUG - 2023-05-11 09:35:34 --> Total execution time: 0.1984
ERROR - 2023-05-11 09:35:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:35:35 --> Config Class Initialized
INFO - 2023-05-11 09:35:35 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:35:35 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:35:35 --> Utf8 Class Initialized
INFO - 2023-05-11 09:35:35 --> URI Class Initialized
INFO - 2023-05-11 09:35:35 --> Router Class Initialized
INFO - 2023-05-11 09:35:35 --> Output Class Initialized
INFO - 2023-05-11 09:35:35 --> Security Class Initialized
DEBUG - 2023-05-11 09:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:35:35 --> Input Class Initialized
INFO - 2023-05-11 09:35:35 --> Language Class Initialized
INFO - 2023-05-11 09:35:35 --> Loader Class Initialized
INFO - 2023-05-11 09:35:35 --> Helper loaded: url_helper
INFO - 2023-05-11 09:35:35 --> Helper loaded: file_helper
INFO - 2023-05-11 09:35:35 --> Helper loaded: html_helper
INFO - 2023-05-11 09:35:35 --> Helper loaded: text_helper
INFO - 2023-05-11 09:35:35 --> Helper loaded: form_helper
INFO - 2023-05-11 09:35:35 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:35:35 --> Helper loaded: security_helper
INFO - 2023-05-11 09:35:35 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:35:35 --> Database Driver Class Initialized
INFO - 2023-05-11 09:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:35:35 --> Parser Class Initialized
INFO - 2023-05-11 09:35:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:35:35 --> Pagination Class Initialized
INFO - 2023-05-11 09:35:35 --> Form Validation Class Initialized
INFO - 2023-05-11 09:35:35 --> Controller Class Initialized
INFO - 2023-05-11 09:35:35 --> Model Class Initialized
DEBUG - 2023-05-11 09:35:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:35:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:35:35 --> Model Class Initialized
DEBUG - 2023-05-11 09:35:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:35:35 --> Model Class Initialized
INFO - 2023-05-11 09:35:35 --> Final output sent to browser
DEBUG - 2023-05-11 09:35:35 --> Total execution time: 0.0564
ERROR - 2023-05-11 09:35:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:35:43 --> Config Class Initialized
INFO - 2023-05-11 09:35:43 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:35:43 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:35:43 --> Utf8 Class Initialized
INFO - 2023-05-11 09:35:43 --> URI Class Initialized
INFO - 2023-05-11 09:35:43 --> Router Class Initialized
INFO - 2023-05-11 09:35:43 --> Output Class Initialized
INFO - 2023-05-11 09:35:43 --> Security Class Initialized
DEBUG - 2023-05-11 09:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:35:43 --> Input Class Initialized
INFO - 2023-05-11 09:35:43 --> Language Class Initialized
INFO - 2023-05-11 09:35:43 --> Loader Class Initialized
INFO - 2023-05-11 09:35:43 --> Helper loaded: url_helper
INFO - 2023-05-11 09:35:43 --> Helper loaded: file_helper
INFO - 2023-05-11 09:35:43 --> Helper loaded: html_helper
INFO - 2023-05-11 09:35:43 --> Helper loaded: text_helper
INFO - 2023-05-11 09:35:43 --> Helper loaded: form_helper
INFO - 2023-05-11 09:35:43 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:35:43 --> Helper loaded: security_helper
INFO - 2023-05-11 09:35:43 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:35:43 --> Database Driver Class Initialized
INFO - 2023-05-11 09:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:35:43 --> Parser Class Initialized
INFO - 2023-05-11 09:35:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:35:43 --> Pagination Class Initialized
INFO - 2023-05-11 09:35:43 --> Form Validation Class Initialized
INFO - 2023-05-11 09:35:43 --> Controller Class Initialized
INFO - 2023-05-11 09:35:43 --> Model Class Initialized
DEBUG - 2023-05-11 09:35:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:35:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:35:43 --> Model Class Initialized
DEBUG - 2023-05-11 09:35:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:35:43 --> Model Class Initialized
INFO - 2023-05-11 09:35:43 --> Final output sent to browser
DEBUG - 2023-05-11 09:35:43 --> Total execution time: 0.0530
ERROR - 2023-05-11 09:35:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:35:45 --> Config Class Initialized
INFO - 2023-05-11 09:35:45 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:35:45 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:35:45 --> Utf8 Class Initialized
INFO - 2023-05-11 09:35:45 --> URI Class Initialized
INFO - 2023-05-11 09:35:45 --> Router Class Initialized
INFO - 2023-05-11 09:35:45 --> Output Class Initialized
INFO - 2023-05-11 09:35:45 --> Security Class Initialized
DEBUG - 2023-05-11 09:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:35:45 --> Input Class Initialized
INFO - 2023-05-11 09:35:45 --> Language Class Initialized
INFO - 2023-05-11 09:35:45 --> Loader Class Initialized
INFO - 2023-05-11 09:35:45 --> Helper loaded: url_helper
INFO - 2023-05-11 09:35:45 --> Helper loaded: file_helper
INFO - 2023-05-11 09:35:45 --> Helper loaded: html_helper
INFO - 2023-05-11 09:35:45 --> Helper loaded: text_helper
INFO - 2023-05-11 09:35:45 --> Helper loaded: form_helper
INFO - 2023-05-11 09:35:45 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:35:45 --> Helper loaded: security_helper
INFO - 2023-05-11 09:35:45 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:35:45 --> Database Driver Class Initialized
INFO - 2023-05-11 09:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:35:45 --> Parser Class Initialized
INFO - 2023-05-11 09:35:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:35:45 --> Pagination Class Initialized
INFO - 2023-05-11 09:35:45 --> Form Validation Class Initialized
INFO - 2023-05-11 09:35:45 --> Controller Class Initialized
INFO - 2023-05-11 09:35:45 --> Model Class Initialized
DEBUG - 2023-05-11 09:35:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:35:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:35:45 --> Model Class Initialized
DEBUG - 2023-05-11 09:35:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:35:45 --> Model Class Initialized
INFO - 2023-05-11 09:35:45 --> Final output sent to browser
DEBUG - 2023-05-11 09:35:45 --> Total execution time: 0.0510
ERROR - 2023-05-11 09:52:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:52:25 --> Config Class Initialized
INFO - 2023-05-11 09:52:25 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:52:25 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:52:25 --> Utf8 Class Initialized
INFO - 2023-05-11 09:52:25 --> URI Class Initialized
DEBUG - 2023-05-11 09:52:25 --> No URI present. Default controller set.
INFO - 2023-05-11 09:52:25 --> Router Class Initialized
INFO - 2023-05-11 09:52:25 --> Output Class Initialized
INFO - 2023-05-11 09:52:25 --> Security Class Initialized
DEBUG - 2023-05-11 09:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:52:25 --> Input Class Initialized
INFO - 2023-05-11 09:52:25 --> Language Class Initialized
INFO - 2023-05-11 09:52:25 --> Loader Class Initialized
INFO - 2023-05-11 09:52:25 --> Helper loaded: url_helper
INFO - 2023-05-11 09:52:25 --> Helper loaded: file_helper
INFO - 2023-05-11 09:52:25 --> Helper loaded: html_helper
INFO - 2023-05-11 09:52:25 --> Helper loaded: text_helper
INFO - 2023-05-11 09:52:25 --> Helper loaded: form_helper
INFO - 2023-05-11 09:52:25 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:52:25 --> Helper loaded: security_helper
INFO - 2023-05-11 09:52:25 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:52:25 --> Database Driver Class Initialized
INFO - 2023-05-11 09:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:52:25 --> Parser Class Initialized
INFO - 2023-05-11 09:52:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:52:25 --> Pagination Class Initialized
INFO - 2023-05-11 09:52:25 --> Form Validation Class Initialized
INFO - 2023-05-11 09:52:25 --> Controller Class Initialized
INFO - 2023-05-11 09:52:25 --> Model Class Initialized
DEBUG - 2023-05-11 09:52:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:52:25 --> Model Class Initialized
DEBUG - 2023-05-11 09:52:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:52:25 --> Model Class Initialized
INFO - 2023-05-11 09:52:25 --> Model Class Initialized
INFO - 2023-05-11 09:52:25 --> Model Class Initialized
INFO - 2023-05-11 09:52:25 --> Model Class Initialized
DEBUG - 2023-05-11 09:52:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:52:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:52:25 --> Model Class Initialized
INFO - 2023-05-11 09:52:25 --> Model Class Initialized
INFO - 2023-05-11 09:52:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-11 09:52:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:52:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 09:52:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 09:52:25 --> Model Class Initialized
INFO - 2023-05-11 09:52:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 09:52:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 09:52:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 09:52:25 --> Final output sent to browser
DEBUG - 2023-05-11 09:52:25 --> Total execution time: 0.1807
ERROR - 2023-05-11 09:53:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:53:37 --> Config Class Initialized
INFO - 2023-05-11 09:53:37 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:53:37 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:53:37 --> Utf8 Class Initialized
INFO - 2023-05-11 09:53:37 --> URI Class Initialized
INFO - 2023-05-11 09:53:37 --> Router Class Initialized
INFO - 2023-05-11 09:53:37 --> Output Class Initialized
INFO - 2023-05-11 09:53:37 --> Security Class Initialized
DEBUG - 2023-05-11 09:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:53:37 --> Input Class Initialized
INFO - 2023-05-11 09:53:37 --> Language Class Initialized
INFO - 2023-05-11 09:53:37 --> Loader Class Initialized
INFO - 2023-05-11 09:53:37 --> Helper loaded: url_helper
INFO - 2023-05-11 09:53:37 --> Helper loaded: file_helper
INFO - 2023-05-11 09:53:37 --> Helper loaded: html_helper
INFO - 2023-05-11 09:53:37 --> Helper loaded: text_helper
INFO - 2023-05-11 09:53:37 --> Helper loaded: form_helper
INFO - 2023-05-11 09:53:37 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:53:37 --> Helper loaded: security_helper
INFO - 2023-05-11 09:53:37 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:53:37 --> Database Driver Class Initialized
INFO - 2023-05-11 09:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:53:37 --> Parser Class Initialized
INFO - 2023-05-11 09:53:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:53:37 --> Pagination Class Initialized
INFO - 2023-05-11 09:53:37 --> Form Validation Class Initialized
INFO - 2023-05-11 09:53:37 --> Controller Class Initialized
INFO - 2023-05-11 09:53:37 --> Model Class Initialized
DEBUG - 2023-05-11 09:53:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:53:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:53:37 --> Model Class Initialized
DEBUG - 2023-05-11 09:53:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:53:37 --> Model Class Initialized
INFO - 2023-05-11 09:53:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-11 09:53:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:53:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 09:53:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 09:53:37 --> Model Class Initialized
INFO - 2023-05-11 09:53:37 --> Model Class Initialized
INFO - 2023-05-11 09:53:37 --> Model Class Initialized
INFO - 2023-05-11 09:53:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 09:53:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 09:53:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 09:53:38 --> Final output sent to browser
DEBUG - 2023-05-11 09:53:38 --> Total execution time: 0.1713
ERROR - 2023-05-11 09:53:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:53:38 --> Config Class Initialized
INFO - 2023-05-11 09:53:38 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:53:38 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:53:38 --> Utf8 Class Initialized
INFO - 2023-05-11 09:53:38 --> URI Class Initialized
INFO - 2023-05-11 09:53:38 --> Router Class Initialized
INFO - 2023-05-11 09:53:38 --> Output Class Initialized
INFO - 2023-05-11 09:53:38 --> Security Class Initialized
DEBUG - 2023-05-11 09:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:53:38 --> Input Class Initialized
INFO - 2023-05-11 09:53:38 --> Language Class Initialized
INFO - 2023-05-11 09:53:38 --> Loader Class Initialized
INFO - 2023-05-11 09:53:38 --> Helper loaded: url_helper
INFO - 2023-05-11 09:53:38 --> Helper loaded: file_helper
INFO - 2023-05-11 09:53:38 --> Helper loaded: html_helper
INFO - 2023-05-11 09:53:38 --> Helper loaded: text_helper
INFO - 2023-05-11 09:53:38 --> Helper loaded: form_helper
INFO - 2023-05-11 09:53:38 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:53:38 --> Helper loaded: security_helper
INFO - 2023-05-11 09:53:38 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:53:38 --> Database Driver Class Initialized
INFO - 2023-05-11 09:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:53:38 --> Parser Class Initialized
INFO - 2023-05-11 09:53:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:53:38 --> Pagination Class Initialized
INFO - 2023-05-11 09:53:38 --> Form Validation Class Initialized
INFO - 2023-05-11 09:53:38 --> Controller Class Initialized
INFO - 2023-05-11 09:53:38 --> Model Class Initialized
DEBUG - 2023-05-11 09:53:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:53:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:53:38 --> Model Class Initialized
DEBUG - 2023-05-11 09:53:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:53:38 --> Model Class Initialized
INFO - 2023-05-11 09:53:38 --> Final output sent to browser
DEBUG - 2023-05-11 09:53:38 --> Total execution time: 0.0531
ERROR - 2023-05-11 09:54:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:54:26 --> Config Class Initialized
INFO - 2023-05-11 09:54:26 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:54:26 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:54:26 --> Utf8 Class Initialized
INFO - 2023-05-11 09:54:26 --> URI Class Initialized
DEBUG - 2023-05-11 09:54:26 --> No URI present. Default controller set.
INFO - 2023-05-11 09:54:26 --> Router Class Initialized
INFO - 2023-05-11 09:54:26 --> Output Class Initialized
INFO - 2023-05-11 09:54:26 --> Security Class Initialized
DEBUG - 2023-05-11 09:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:54:26 --> Input Class Initialized
INFO - 2023-05-11 09:54:26 --> Language Class Initialized
INFO - 2023-05-11 09:54:26 --> Loader Class Initialized
INFO - 2023-05-11 09:54:26 --> Helper loaded: url_helper
INFO - 2023-05-11 09:54:26 --> Helper loaded: file_helper
INFO - 2023-05-11 09:54:26 --> Helper loaded: html_helper
INFO - 2023-05-11 09:54:26 --> Helper loaded: text_helper
INFO - 2023-05-11 09:54:26 --> Helper loaded: form_helper
INFO - 2023-05-11 09:54:26 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:54:26 --> Helper loaded: security_helper
INFO - 2023-05-11 09:54:26 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:54:26 --> Database Driver Class Initialized
INFO - 2023-05-11 09:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:54:26 --> Parser Class Initialized
INFO - 2023-05-11 09:54:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:54:26 --> Pagination Class Initialized
INFO - 2023-05-11 09:54:26 --> Form Validation Class Initialized
INFO - 2023-05-11 09:54:26 --> Controller Class Initialized
INFO - 2023-05-11 09:54:26 --> Model Class Initialized
DEBUG - 2023-05-11 09:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:54:26 --> Model Class Initialized
DEBUG - 2023-05-11 09:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:54:26 --> Model Class Initialized
INFO - 2023-05-11 09:54:26 --> Model Class Initialized
INFO - 2023-05-11 09:54:26 --> Model Class Initialized
INFO - 2023-05-11 09:54:26 --> Model Class Initialized
DEBUG - 2023-05-11 09:54:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:54:26 --> Model Class Initialized
INFO - 2023-05-11 09:54:26 --> Model Class Initialized
INFO - 2023-05-11 09:54:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-11 09:54:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:54:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 09:54:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 09:54:26 --> Model Class Initialized
INFO - 2023-05-11 09:54:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 09:54:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 09:54:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 09:54:26 --> Final output sent to browser
DEBUG - 2023-05-11 09:54:26 --> Total execution time: 0.1780
ERROR - 2023-05-11 09:55:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:55:11 --> Config Class Initialized
INFO - 2023-05-11 09:55:11 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:55:11 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:55:11 --> Utf8 Class Initialized
INFO - 2023-05-11 09:55:11 --> URI Class Initialized
INFO - 2023-05-11 09:55:11 --> Router Class Initialized
INFO - 2023-05-11 09:55:11 --> Output Class Initialized
INFO - 2023-05-11 09:55:11 --> Security Class Initialized
DEBUG - 2023-05-11 09:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:55:11 --> Input Class Initialized
INFO - 2023-05-11 09:55:11 --> Language Class Initialized
INFO - 2023-05-11 09:55:11 --> Loader Class Initialized
INFO - 2023-05-11 09:55:11 --> Helper loaded: url_helper
INFO - 2023-05-11 09:55:11 --> Helper loaded: file_helper
INFO - 2023-05-11 09:55:11 --> Helper loaded: html_helper
INFO - 2023-05-11 09:55:11 --> Helper loaded: text_helper
INFO - 2023-05-11 09:55:11 --> Helper loaded: form_helper
INFO - 2023-05-11 09:55:11 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:55:11 --> Helper loaded: security_helper
INFO - 2023-05-11 09:55:11 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:55:11 --> Database Driver Class Initialized
INFO - 2023-05-11 09:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:55:11 --> Parser Class Initialized
INFO - 2023-05-11 09:55:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:55:11 --> Pagination Class Initialized
INFO - 2023-05-11 09:55:11 --> Form Validation Class Initialized
INFO - 2023-05-11 09:55:11 --> Controller Class Initialized
INFO - 2023-05-11 09:55:11 --> Model Class Initialized
DEBUG - 2023-05-11 09:55:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:55:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:55:11 --> Model Class Initialized
DEBUG - 2023-05-11 09:55:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:55:11 --> Model Class Initialized
INFO - 2023-05-11 09:55:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-05-11 09:55:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:55:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 09:55:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 09:55:11 --> Model Class Initialized
INFO - 2023-05-11 09:55:11 --> Model Class Initialized
INFO - 2023-05-11 09:55:11 --> Model Class Initialized
INFO - 2023-05-11 09:55:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 09:55:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 09:55:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 09:55:12 --> Final output sent to browser
DEBUG - 2023-05-11 09:55:12 --> Total execution time: 0.1676
ERROR - 2023-05-11 09:55:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:55:12 --> Config Class Initialized
INFO - 2023-05-11 09:55:12 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:55:12 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:55:12 --> Utf8 Class Initialized
INFO - 2023-05-11 09:55:12 --> URI Class Initialized
INFO - 2023-05-11 09:55:12 --> Router Class Initialized
INFO - 2023-05-11 09:55:12 --> Output Class Initialized
INFO - 2023-05-11 09:55:12 --> Security Class Initialized
DEBUG - 2023-05-11 09:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:55:12 --> Input Class Initialized
INFO - 2023-05-11 09:55:12 --> Language Class Initialized
INFO - 2023-05-11 09:55:12 --> Loader Class Initialized
INFO - 2023-05-11 09:55:12 --> Helper loaded: url_helper
INFO - 2023-05-11 09:55:12 --> Helper loaded: file_helper
INFO - 2023-05-11 09:55:12 --> Helper loaded: html_helper
INFO - 2023-05-11 09:55:12 --> Helper loaded: text_helper
INFO - 2023-05-11 09:55:12 --> Helper loaded: form_helper
INFO - 2023-05-11 09:55:12 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:55:12 --> Helper loaded: security_helper
INFO - 2023-05-11 09:55:12 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:55:12 --> Database Driver Class Initialized
INFO - 2023-05-11 09:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:55:12 --> Parser Class Initialized
INFO - 2023-05-11 09:55:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:55:12 --> Pagination Class Initialized
INFO - 2023-05-11 09:55:12 --> Form Validation Class Initialized
INFO - 2023-05-11 09:55:12 --> Controller Class Initialized
INFO - 2023-05-11 09:55:12 --> Model Class Initialized
DEBUG - 2023-05-11 09:55:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:55:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:55:12 --> Model Class Initialized
DEBUG - 2023-05-11 09:55:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:55:12 --> Model Class Initialized
INFO - 2023-05-11 09:55:12 --> Final output sent to browser
DEBUG - 2023-05-11 09:55:12 --> Total execution time: 0.0486
ERROR - 2023-05-11 09:55:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:55:20 --> Config Class Initialized
INFO - 2023-05-11 09:55:20 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:55:20 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:55:20 --> Utf8 Class Initialized
INFO - 2023-05-11 09:55:20 --> URI Class Initialized
INFO - 2023-05-11 09:55:20 --> Router Class Initialized
INFO - 2023-05-11 09:55:20 --> Output Class Initialized
INFO - 2023-05-11 09:55:20 --> Security Class Initialized
DEBUG - 2023-05-11 09:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:55:20 --> Input Class Initialized
INFO - 2023-05-11 09:55:20 --> Language Class Initialized
INFO - 2023-05-11 09:55:20 --> Loader Class Initialized
INFO - 2023-05-11 09:55:20 --> Helper loaded: url_helper
INFO - 2023-05-11 09:55:20 --> Helper loaded: file_helper
INFO - 2023-05-11 09:55:20 --> Helper loaded: html_helper
INFO - 2023-05-11 09:55:20 --> Helper loaded: text_helper
INFO - 2023-05-11 09:55:20 --> Helper loaded: form_helper
INFO - 2023-05-11 09:55:20 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:55:20 --> Helper loaded: security_helper
INFO - 2023-05-11 09:55:20 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:55:20 --> Database Driver Class Initialized
INFO - 2023-05-11 09:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:55:20 --> Parser Class Initialized
INFO - 2023-05-11 09:55:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:55:20 --> Pagination Class Initialized
INFO - 2023-05-11 09:55:20 --> Form Validation Class Initialized
INFO - 2023-05-11 09:55:20 --> Controller Class Initialized
INFO - 2023-05-11 09:55:20 --> Model Class Initialized
DEBUG - 2023-05-11 09:55:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:55:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:55:20 --> Model Class Initialized
DEBUG - 2023-05-11 09:55:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:55:20 --> Model Class Initialized
INFO - 2023-05-11 09:55:20 --> Final output sent to browser
DEBUG - 2023-05-11 09:55:20 --> Total execution time: 0.0513
ERROR - 2023-05-11 09:55:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:55:30 --> Config Class Initialized
INFO - 2023-05-11 09:55:30 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:55:30 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:55:30 --> Utf8 Class Initialized
INFO - 2023-05-11 09:55:30 --> URI Class Initialized
INFO - 2023-05-11 09:55:30 --> Router Class Initialized
INFO - 2023-05-11 09:55:30 --> Output Class Initialized
INFO - 2023-05-11 09:55:30 --> Security Class Initialized
DEBUG - 2023-05-11 09:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:55:30 --> Input Class Initialized
INFO - 2023-05-11 09:55:30 --> Language Class Initialized
INFO - 2023-05-11 09:55:30 --> Loader Class Initialized
INFO - 2023-05-11 09:55:30 --> Helper loaded: url_helper
INFO - 2023-05-11 09:55:30 --> Helper loaded: file_helper
INFO - 2023-05-11 09:55:30 --> Helper loaded: html_helper
INFO - 2023-05-11 09:55:30 --> Helper loaded: text_helper
INFO - 2023-05-11 09:55:30 --> Helper loaded: form_helper
INFO - 2023-05-11 09:55:30 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:55:30 --> Helper loaded: security_helper
INFO - 2023-05-11 09:55:30 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:55:30 --> Database Driver Class Initialized
INFO - 2023-05-11 09:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:55:30 --> Parser Class Initialized
INFO - 2023-05-11 09:55:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:55:30 --> Pagination Class Initialized
INFO - 2023-05-11 09:55:30 --> Form Validation Class Initialized
INFO - 2023-05-11 09:55:30 --> Controller Class Initialized
INFO - 2023-05-11 09:55:30 --> Model Class Initialized
DEBUG - 2023-05-11 09:55:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:55:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:55:30 --> Model Class Initialized
DEBUG - 2023-05-11 09:55:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:55:30 --> Model Class Initialized
INFO - 2023-05-11 09:55:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-11 09:55:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:55:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 09:55:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 09:55:30 --> Model Class Initialized
INFO - 2023-05-11 09:55:30 --> Model Class Initialized
INFO - 2023-05-11 09:55:30 --> Model Class Initialized
INFO - 2023-05-11 09:55:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 09:55:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 09:55:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 09:55:30 --> Final output sent to browser
DEBUG - 2023-05-11 09:55:30 --> Total execution time: 0.1495
ERROR - 2023-05-11 09:55:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:55:31 --> Config Class Initialized
INFO - 2023-05-11 09:55:31 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:55:31 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:55:31 --> Utf8 Class Initialized
INFO - 2023-05-11 09:55:31 --> URI Class Initialized
INFO - 2023-05-11 09:55:31 --> Router Class Initialized
INFO - 2023-05-11 09:55:31 --> Output Class Initialized
INFO - 2023-05-11 09:55:31 --> Security Class Initialized
DEBUG - 2023-05-11 09:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:55:31 --> Input Class Initialized
INFO - 2023-05-11 09:55:31 --> Language Class Initialized
INFO - 2023-05-11 09:55:31 --> Loader Class Initialized
INFO - 2023-05-11 09:55:31 --> Helper loaded: url_helper
INFO - 2023-05-11 09:55:31 --> Helper loaded: file_helper
INFO - 2023-05-11 09:55:31 --> Helper loaded: html_helper
INFO - 2023-05-11 09:55:31 --> Helper loaded: text_helper
INFO - 2023-05-11 09:55:31 --> Helper loaded: form_helper
INFO - 2023-05-11 09:55:31 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:55:31 --> Helper loaded: security_helper
INFO - 2023-05-11 09:55:31 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:55:31 --> Database Driver Class Initialized
INFO - 2023-05-11 09:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:55:31 --> Parser Class Initialized
INFO - 2023-05-11 09:55:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:55:31 --> Pagination Class Initialized
INFO - 2023-05-11 09:55:31 --> Form Validation Class Initialized
INFO - 2023-05-11 09:55:31 --> Controller Class Initialized
INFO - 2023-05-11 09:55:31 --> Model Class Initialized
DEBUG - 2023-05-11 09:55:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:55:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:55:31 --> Model Class Initialized
DEBUG - 2023-05-11 09:55:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:55:31 --> Model Class Initialized
INFO - 2023-05-11 09:55:31 --> Final output sent to browser
DEBUG - 2023-05-11 09:55:31 --> Total execution time: 0.0536
ERROR - 2023-05-11 09:55:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:55:34 --> Config Class Initialized
INFO - 2023-05-11 09:55:34 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:55:34 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:55:34 --> Utf8 Class Initialized
INFO - 2023-05-11 09:55:34 --> URI Class Initialized
INFO - 2023-05-11 09:55:34 --> Router Class Initialized
INFO - 2023-05-11 09:55:34 --> Output Class Initialized
INFO - 2023-05-11 09:55:34 --> Security Class Initialized
DEBUG - 2023-05-11 09:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:55:34 --> Input Class Initialized
INFO - 2023-05-11 09:55:34 --> Language Class Initialized
INFO - 2023-05-11 09:55:34 --> Loader Class Initialized
INFO - 2023-05-11 09:55:34 --> Helper loaded: url_helper
INFO - 2023-05-11 09:55:34 --> Helper loaded: file_helper
INFO - 2023-05-11 09:55:34 --> Helper loaded: html_helper
INFO - 2023-05-11 09:55:34 --> Helper loaded: text_helper
INFO - 2023-05-11 09:55:34 --> Helper loaded: form_helper
INFO - 2023-05-11 09:55:34 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:55:34 --> Helper loaded: security_helper
INFO - 2023-05-11 09:55:34 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:55:34 --> Database Driver Class Initialized
INFO - 2023-05-11 09:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:55:34 --> Parser Class Initialized
INFO - 2023-05-11 09:55:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:55:34 --> Pagination Class Initialized
INFO - 2023-05-11 09:55:34 --> Form Validation Class Initialized
INFO - 2023-05-11 09:55:34 --> Controller Class Initialized
INFO - 2023-05-11 09:55:34 --> Model Class Initialized
DEBUG - 2023-05-11 09:55:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:55:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:55:34 --> Model Class Initialized
DEBUG - 2023-05-11 09:55:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:55:34 --> Model Class Initialized
INFO - 2023-05-11 09:55:34 --> Final output sent to browser
DEBUG - 2023-05-11 09:55:34 --> Total execution time: 0.1248
ERROR - 2023-05-11 09:57:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:57:02 --> Config Class Initialized
INFO - 2023-05-11 09:57:02 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:57:02 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:57:02 --> Utf8 Class Initialized
INFO - 2023-05-11 09:57:02 --> URI Class Initialized
INFO - 2023-05-11 09:57:02 --> Router Class Initialized
INFO - 2023-05-11 09:57:02 --> Output Class Initialized
INFO - 2023-05-11 09:57:02 --> Security Class Initialized
DEBUG - 2023-05-11 09:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:57:02 --> Input Class Initialized
INFO - 2023-05-11 09:57:02 --> Language Class Initialized
INFO - 2023-05-11 09:57:02 --> Loader Class Initialized
INFO - 2023-05-11 09:57:02 --> Helper loaded: url_helper
INFO - 2023-05-11 09:57:02 --> Helper loaded: file_helper
INFO - 2023-05-11 09:57:02 --> Helper loaded: html_helper
INFO - 2023-05-11 09:57:02 --> Helper loaded: text_helper
INFO - 2023-05-11 09:57:02 --> Helper loaded: form_helper
INFO - 2023-05-11 09:57:02 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:57:02 --> Helper loaded: security_helper
INFO - 2023-05-11 09:57:02 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:57:02 --> Database Driver Class Initialized
INFO - 2023-05-11 09:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:57:02 --> Parser Class Initialized
INFO - 2023-05-11 09:57:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:57:02 --> Pagination Class Initialized
INFO - 2023-05-11 09:57:02 --> Form Validation Class Initialized
INFO - 2023-05-11 09:57:02 --> Controller Class Initialized
INFO - 2023-05-11 09:57:02 --> Model Class Initialized
DEBUG - 2023-05-11 09:57:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:57:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:57:02 --> Model Class Initialized
INFO - 2023-05-11 09:57:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-05-11 09:57:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:57:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 09:57:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 09:57:02 --> Model Class Initialized
INFO - 2023-05-11 09:57:02 --> Model Class Initialized
INFO - 2023-05-11 09:57:02 --> Model Class Initialized
INFO - 2023-05-11 09:57:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 09:57:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 09:57:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 09:57:02 --> Final output sent to browser
DEBUG - 2023-05-11 09:57:02 --> Total execution time: 0.1519
ERROR - 2023-05-11 09:57:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:57:02 --> Config Class Initialized
INFO - 2023-05-11 09:57:02 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:57:02 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:57:02 --> Utf8 Class Initialized
INFO - 2023-05-11 09:57:02 --> URI Class Initialized
INFO - 2023-05-11 09:57:02 --> Router Class Initialized
INFO - 2023-05-11 09:57:02 --> Output Class Initialized
INFO - 2023-05-11 09:57:02 --> Security Class Initialized
DEBUG - 2023-05-11 09:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:57:02 --> Input Class Initialized
INFO - 2023-05-11 09:57:02 --> Language Class Initialized
INFO - 2023-05-11 09:57:02 --> Loader Class Initialized
INFO - 2023-05-11 09:57:02 --> Helper loaded: url_helper
INFO - 2023-05-11 09:57:02 --> Helper loaded: file_helper
INFO - 2023-05-11 09:57:02 --> Helper loaded: html_helper
INFO - 2023-05-11 09:57:02 --> Helper loaded: text_helper
INFO - 2023-05-11 09:57:02 --> Helper loaded: form_helper
INFO - 2023-05-11 09:57:02 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:57:02 --> Helper loaded: security_helper
INFO - 2023-05-11 09:57:02 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:57:02 --> Database Driver Class Initialized
INFO - 2023-05-11 09:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:57:02 --> Parser Class Initialized
INFO - 2023-05-11 09:57:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:57:02 --> Pagination Class Initialized
INFO - 2023-05-11 09:57:02 --> Form Validation Class Initialized
INFO - 2023-05-11 09:57:02 --> Controller Class Initialized
INFO - 2023-05-11 09:57:02 --> Model Class Initialized
DEBUG - 2023-05-11 09:57:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:57:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:57:02 --> Model Class Initialized
INFO - 2023-05-11 09:57:02 --> Final output sent to browser
DEBUG - 2023-05-11 09:57:02 --> Total execution time: 0.0298
ERROR - 2023-05-11 09:58:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:58:28 --> Config Class Initialized
INFO - 2023-05-11 09:58:28 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:58:28 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:58:28 --> Utf8 Class Initialized
INFO - 2023-05-11 09:58:28 --> URI Class Initialized
INFO - 2023-05-11 09:58:28 --> Router Class Initialized
INFO - 2023-05-11 09:58:28 --> Output Class Initialized
INFO - 2023-05-11 09:58:28 --> Security Class Initialized
DEBUG - 2023-05-11 09:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:58:28 --> Input Class Initialized
INFO - 2023-05-11 09:58:28 --> Language Class Initialized
INFO - 2023-05-11 09:58:28 --> Loader Class Initialized
INFO - 2023-05-11 09:58:29 --> Helper loaded: url_helper
INFO - 2023-05-11 09:58:29 --> Helper loaded: file_helper
INFO - 2023-05-11 09:58:29 --> Helper loaded: html_helper
INFO - 2023-05-11 09:58:29 --> Helper loaded: text_helper
INFO - 2023-05-11 09:58:29 --> Helper loaded: form_helper
INFO - 2023-05-11 09:58:29 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:58:29 --> Helper loaded: security_helper
INFO - 2023-05-11 09:58:29 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:58:29 --> Database Driver Class Initialized
INFO - 2023-05-11 09:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:58:29 --> Parser Class Initialized
INFO - 2023-05-11 09:58:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:58:30 --> Pagination Class Initialized
INFO - 2023-05-11 09:58:30 --> Form Validation Class Initialized
INFO - 2023-05-11 09:58:30 --> Controller Class Initialized
INFO - 2023-05-11 09:58:30 --> Model Class Initialized
DEBUG - 2023-05-11 09:58:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:58:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:58:30 --> Model Class Initialized
DEBUG - 2023-05-11 09:58:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-11 09:58:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:58:30 --> Config Class Initialized
INFO - 2023-05-11 09:58:30 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:58:30 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:58:30 --> Utf8 Class Initialized
INFO - 2023-05-11 09:58:30 --> URI Class Initialized
INFO - 2023-05-11 09:58:30 --> Router Class Initialized
INFO - 2023-05-11 09:58:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
INFO - 2023-05-11 09:58:30 --> Output Class Initialized
DEBUG - 2023-05-11 09:58:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:58:30 --> Security Class Initialized
DEBUG - 2023-05-11 09:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:58:30 --> Input Class Initialized
INFO - 2023-05-11 09:58:30 --> Language Class Initialized
INFO - 2023-05-11 09:58:30 --> Loader Class Initialized
INFO - 2023-05-11 09:58:30 --> Helper loaded: url_helper
INFO - 2023-05-11 09:58:30 --> Helper loaded: file_helper
INFO - 2023-05-11 09:58:30 --> Helper loaded: html_helper
INFO - 2023-05-11 09:58:30 --> Helper loaded: text_helper
INFO - 2023-05-11 09:58:30 --> Helper loaded: form_helper
INFO - 2023-05-11 09:58:30 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:58:30 --> Helper loaded: security_helper
INFO - 2023-05-11 09:58:30 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:58:30 --> Database Driver Class Initialized
INFO - 2023-05-11 09:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:58:30 --> Parser Class Initialized
INFO - 2023-05-11 09:58:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:58:30 --> Pagination Class Initialized
INFO - 2023-05-11 09:58:30 --> Form Validation Class Initialized
INFO - 2023-05-11 09:58:30 --> Controller Class Initialized
INFO - 2023-05-11 09:58:30 --> Model Class Initialized
DEBUG - 2023-05-11 09:58:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 09:58:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:58:30 --> Model Class Initialized
DEBUG - 2023-05-11 09:58:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:58:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 09:58:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 09:58:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-05-11 09:58:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:58:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 09:58:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 09:58:30 --> Model Class Initialized
INFO - 2023-05-11 09:58:30 --> Model Class Initialized
INFO - 2023-05-11 09:58:30 --> Model Class Initialized
INFO - 2023-05-11 09:58:30 --> Model Class Initialized
INFO - 2023-05-11 09:58:30 --> Model Class Initialized
INFO - 2023-05-11 09:58:30 --> Model Class Initialized
INFO - 2023-05-11 09:58:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 09:58:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 09:58:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 09:58:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 09:58:30 --> Final output sent to browser
DEBUG - 2023-05-11 09:58:30 --> Total execution time: 0.4007
INFO - 2023-05-11 09:58:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 09:58:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 09:58:30 --> Final output sent to browser
DEBUG - 2023-05-11 09:58:30 --> Total execution time: 2.8515
ERROR - 2023-05-11 09:58:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:58:52 --> Config Class Initialized
INFO - 2023-05-11 09:58:52 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:58:52 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:58:52 --> Utf8 Class Initialized
INFO - 2023-05-11 09:58:52 --> URI Class Initialized
INFO - 2023-05-11 09:58:52 --> Router Class Initialized
INFO - 2023-05-11 09:58:52 --> Output Class Initialized
INFO - 2023-05-11 09:58:52 --> Security Class Initialized
DEBUG - 2023-05-11 09:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:58:52 --> Input Class Initialized
INFO - 2023-05-11 09:58:52 --> Language Class Initialized
INFO - 2023-05-11 09:58:52 --> Loader Class Initialized
INFO - 2023-05-11 09:58:52 --> Helper loaded: url_helper
INFO - 2023-05-11 09:58:52 --> Helper loaded: file_helper
INFO - 2023-05-11 09:58:52 --> Helper loaded: html_helper
INFO - 2023-05-11 09:58:52 --> Helper loaded: text_helper
INFO - 2023-05-11 09:58:52 --> Helper loaded: form_helper
INFO - 2023-05-11 09:58:52 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:58:52 --> Helper loaded: security_helper
INFO - 2023-05-11 09:58:52 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:58:52 --> Database Driver Class Initialized
INFO - 2023-05-11 09:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:58:52 --> Parser Class Initialized
INFO - 2023-05-11 09:58:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:58:52 --> Pagination Class Initialized
INFO - 2023-05-11 09:58:52 --> Form Validation Class Initialized
INFO - 2023-05-11 09:58:52 --> Controller Class Initialized
INFO - 2023-05-11 09:58:52 --> Model Class Initialized
DEBUG - 2023-05-11 09:58:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:58:52 --> Model Class Initialized
INFO - 2023-05-11 09:58:52 --> Model Class Initialized
INFO - 2023-05-11 15:58:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/profit_product_report.php
DEBUG - 2023-05-11 15:58:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 15:58:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 15:58:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 15:58:52 --> Model Class Initialized
INFO - 2023-05-11 15:58:52 --> Model Class Initialized
INFO - 2023-05-11 15:58:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 15:58:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 15:58:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 15:58:53 --> Final output sent to browser
DEBUG - 2023-05-11 15:58:53 --> Total execution time: 0.1398
ERROR - 2023-05-11 09:58:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 09:58:57 --> Config Class Initialized
INFO - 2023-05-11 09:58:57 --> Hooks Class Initialized
DEBUG - 2023-05-11 09:58:57 --> UTF-8 Support Enabled
INFO - 2023-05-11 09:58:57 --> Utf8 Class Initialized
INFO - 2023-05-11 09:58:57 --> URI Class Initialized
INFO - 2023-05-11 09:58:57 --> Router Class Initialized
INFO - 2023-05-11 09:58:57 --> Output Class Initialized
INFO - 2023-05-11 09:58:57 --> Security Class Initialized
DEBUG - 2023-05-11 09:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 09:58:57 --> Input Class Initialized
INFO - 2023-05-11 09:58:57 --> Language Class Initialized
INFO - 2023-05-11 09:58:57 --> Loader Class Initialized
INFO - 2023-05-11 09:58:57 --> Helper loaded: url_helper
INFO - 2023-05-11 09:58:57 --> Helper loaded: file_helper
INFO - 2023-05-11 09:58:57 --> Helper loaded: html_helper
INFO - 2023-05-11 09:58:57 --> Helper loaded: text_helper
INFO - 2023-05-11 09:58:57 --> Helper loaded: form_helper
INFO - 2023-05-11 09:58:57 --> Helper loaded: lang_helper
INFO - 2023-05-11 09:58:57 --> Helper loaded: security_helper
INFO - 2023-05-11 09:58:57 --> Helper loaded: cookie_helper
INFO - 2023-05-11 09:58:57 --> Database Driver Class Initialized
INFO - 2023-05-11 09:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 09:58:57 --> Parser Class Initialized
INFO - 2023-05-11 09:58:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 09:58:57 --> Pagination Class Initialized
INFO - 2023-05-11 09:58:57 --> Form Validation Class Initialized
INFO - 2023-05-11 09:58:57 --> Controller Class Initialized
INFO - 2023-05-11 09:58:57 --> Model Class Initialized
DEBUG - 2023-05-11 09:58:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:58:57 --> Model Class Initialized
INFO - 2023-05-11 09:58:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/all_report.php
DEBUG - 2023-05-11 09:58:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 09:58:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 09:58:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 09:58:57 --> Model Class Initialized
INFO - 2023-05-11 09:58:57 --> Model Class Initialized
INFO - 2023-05-11 09:58:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 09:58:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 09:58:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 09:58:57 --> Final output sent to browser
DEBUG - 2023-05-11 09:58:57 --> Total execution time: 0.1498
ERROR - 2023-05-11 10:01:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 10:01:03 --> Config Class Initialized
INFO - 2023-05-11 10:01:03 --> Hooks Class Initialized
DEBUG - 2023-05-11 10:01:03 --> UTF-8 Support Enabled
INFO - 2023-05-11 10:01:03 --> Utf8 Class Initialized
INFO - 2023-05-11 10:01:03 --> URI Class Initialized
INFO - 2023-05-11 10:01:03 --> Router Class Initialized
INFO - 2023-05-11 10:01:03 --> Output Class Initialized
INFO - 2023-05-11 10:01:03 --> Security Class Initialized
DEBUG - 2023-05-11 10:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 10:01:03 --> Input Class Initialized
INFO - 2023-05-11 10:01:03 --> Language Class Initialized
INFO - 2023-05-11 10:01:03 --> Loader Class Initialized
INFO - 2023-05-11 10:01:03 --> Helper loaded: url_helper
INFO - 2023-05-11 10:01:03 --> Helper loaded: file_helper
INFO - 2023-05-11 10:01:03 --> Helper loaded: html_helper
INFO - 2023-05-11 10:01:03 --> Helper loaded: text_helper
INFO - 2023-05-11 10:01:03 --> Helper loaded: form_helper
INFO - 2023-05-11 10:01:03 --> Helper loaded: lang_helper
INFO - 2023-05-11 10:01:03 --> Helper loaded: security_helper
INFO - 2023-05-11 10:01:03 --> Helper loaded: cookie_helper
INFO - 2023-05-11 10:01:03 --> Database Driver Class Initialized
INFO - 2023-05-11 10:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 10:01:03 --> Parser Class Initialized
INFO - 2023-05-11 10:01:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 10:01:03 --> Pagination Class Initialized
INFO - 2023-05-11 10:01:03 --> Form Validation Class Initialized
INFO - 2023-05-11 10:01:03 --> Controller Class Initialized
INFO - 2023-05-11 10:01:03 --> Model Class Initialized
DEBUG - 2023-05-11 10:01:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 10:01:03 --> Model Class Initialized
INFO - 2023-05-11 16:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/product_report.php
DEBUG - 2023-05-11 16:01:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 16:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 16:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 16:01:03 --> Model Class Initialized
INFO - 2023-05-11 16:01:03 --> Model Class Initialized
INFO - 2023-05-11 16:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 16:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 16:01:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 16:01:03 --> Final output sent to browser
DEBUG - 2023-05-11 16:01:03 --> Total execution time: 0.1539
ERROR - 2023-05-11 10:01:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 10:01:12 --> Config Class Initialized
INFO - 2023-05-11 10:01:12 --> Hooks Class Initialized
DEBUG - 2023-05-11 10:01:12 --> UTF-8 Support Enabled
INFO - 2023-05-11 10:01:12 --> Utf8 Class Initialized
INFO - 2023-05-11 10:01:12 --> URI Class Initialized
INFO - 2023-05-11 10:01:12 --> Router Class Initialized
INFO - 2023-05-11 10:01:12 --> Output Class Initialized
INFO - 2023-05-11 10:01:12 --> Security Class Initialized
DEBUG - 2023-05-11 10:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 10:01:12 --> Input Class Initialized
INFO - 2023-05-11 10:01:12 --> Language Class Initialized
INFO - 2023-05-11 10:01:12 --> Loader Class Initialized
INFO - 2023-05-11 10:01:12 --> Helper loaded: url_helper
INFO - 2023-05-11 10:01:12 --> Helper loaded: file_helper
INFO - 2023-05-11 10:01:12 --> Helper loaded: html_helper
INFO - 2023-05-11 10:01:12 --> Helper loaded: text_helper
INFO - 2023-05-11 10:01:12 --> Helper loaded: form_helper
INFO - 2023-05-11 10:01:12 --> Helper loaded: lang_helper
INFO - 2023-05-11 10:01:12 --> Helper loaded: security_helper
INFO - 2023-05-11 10:01:12 --> Helper loaded: cookie_helper
INFO - 2023-05-11 10:01:12 --> Database Driver Class Initialized
INFO - 2023-05-11 10:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 10:01:12 --> Parser Class Initialized
INFO - 2023-05-11 10:01:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 10:01:12 --> Pagination Class Initialized
INFO - 2023-05-11 10:01:12 --> Form Validation Class Initialized
INFO - 2023-05-11 10:01:12 --> Controller Class Initialized
INFO - 2023-05-11 10:01:12 --> Model Class Initialized
DEBUG - 2023-05-11 10:01:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 10:01:12 --> Model Class Initialized
INFO - 2023-05-11 16:01:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/product_report.php
DEBUG - 2023-05-11 16:01:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 16:01:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 16:01:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 16:01:13 --> Model Class Initialized
INFO - 2023-05-11 16:01:13 --> Model Class Initialized
INFO - 2023-05-11 16:01:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 16:01:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 16:01:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 16:01:13 --> Final output sent to browser
DEBUG - 2023-05-11 16:01:13 --> Total execution time: 0.1464
ERROR - 2023-05-11 10:03:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 10:03:24 --> Config Class Initialized
INFO - 2023-05-11 10:03:24 --> Hooks Class Initialized
DEBUG - 2023-05-11 10:03:24 --> UTF-8 Support Enabled
INFO - 2023-05-11 10:03:24 --> Utf8 Class Initialized
INFO - 2023-05-11 10:03:24 --> URI Class Initialized
INFO - 2023-05-11 10:03:24 --> Router Class Initialized
INFO - 2023-05-11 10:03:24 --> Output Class Initialized
INFO - 2023-05-11 10:03:24 --> Security Class Initialized
DEBUG - 2023-05-11 10:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 10:03:24 --> Input Class Initialized
INFO - 2023-05-11 10:03:24 --> Language Class Initialized
INFO - 2023-05-11 10:03:24 --> Loader Class Initialized
INFO - 2023-05-11 10:03:24 --> Helper loaded: url_helper
INFO - 2023-05-11 10:03:24 --> Helper loaded: file_helper
INFO - 2023-05-11 10:03:24 --> Helper loaded: html_helper
INFO - 2023-05-11 10:03:24 --> Helper loaded: text_helper
INFO - 2023-05-11 10:03:24 --> Helper loaded: form_helper
INFO - 2023-05-11 10:03:24 --> Helper loaded: lang_helper
INFO - 2023-05-11 10:03:24 --> Helper loaded: security_helper
INFO - 2023-05-11 10:03:24 --> Helper loaded: cookie_helper
INFO - 2023-05-11 10:03:24 --> Database Driver Class Initialized
INFO - 2023-05-11 10:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 10:03:24 --> Parser Class Initialized
INFO - 2023-05-11 10:03:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 10:03:24 --> Pagination Class Initialized
INFO - 2023-05-11 10:03:24 --> Form Validation Class Initialized
INFO - 2023-05-11 10:03:24 --> Controller Class Initialized
DEBUG - 2023-05-11 10:03:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 10:03:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 10:03:24 --> Model Class Initialized
INFO - 2023-05-11 10:03:24 --> Model Class Initialized
DEBUG - 2023-05-11 10:03:24 --> Lmr class already loaded. Second attempt ignored.
INFO - 2023-05-11 10:03:24 --> Model Class Initialized
INFO - 2023-05-11 10:03:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/mr/mr.php
DEBUG - 2023-05-11 10:03:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 10:03:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 10:03:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 10:03:24 --> Model Class Initialized
INFO - 2023-05-11 10:03:24 --> Model Class Initialized
INFO - 2023-05-11 10:03:24 --> Model Class Initialized
INFO - 2023-05-11 10:03:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 10:03:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 10:03:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 10:03:24 --> Final output sent to browser
DEBUG - 2023-05-11 10:03:24 --> Total execution time: 0.1535
ERROR - 2023-05-11 10:03:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 10:03:25 --> Config Class Initialized
INFO - 2023-05-11 10:03:25 --> Hooks Class Initialized
DEBUG - 2023-05-11 10:03:25 --> UTF-8 Support Enabled
INFO - 2023-05-11 10:03:25 --> Utf8 Class Initialized
INFO - 2023-05-11 10:03:25 --> URI Class Initialized
INFO - 2023-05-11 10:03:25 --> Router Class Initialized
INFO - 2023-05-11 10:03:25 --> Output Class Initialized
INFO - 2023-05-11 10:03:25 --> Security Class Initialized
DEBUG - 2023-05-11 10:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 10:03:25 --> Input Class Initialized
INFO - 2023-05-11 10:03:25 --> Language Class Initialized
INFO - 2023-05-11 10:03:25 --> Loader Class Initialized
INFO - 2023-05-11 10:03:25 --> Helper loaded: url_helper
INFO - 2023-05-11 10:03:25 --> Helper loaded: file_helper
INFO - 2023-05-11 10:03:25 --> Helper loaded: html_helper
INFO - 2023-05-11 10:03:25 --> Helper loaded: text_helper
INFO - 2023-05-11 10:03:25 --> Helper loaded: form_helper
INFO - 2023-05-11 10:03:25 --> Helper loaded: lang_helper
INFO - 2023-05-11 10:03:25 --> Helper loaded: security_helper
INFO - 2023-05-11 10:03:25 --> Helper loaded: cookie_helper
INFO - 2023-05-11 10:03:25 --> Database Driver Class Initialized
INFO - 2023-05-11 10:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 10:03:25 --> Parser Class Initialized
INFO - 2023-05-11 10:03:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 10:03:25 --> Pagination Class Initialized
INFO - 2023-05-11 10:03:25 --> Form Validation Class Initialized
INFO - 2023-05-11 10:03:25 --> Controller Class Initialized
DEBUG - 2023-05-11 10:03:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 10:03:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 10:03:25 --> Model Class Initialized
INFO - 2023-05-11 10:03:25 --> Model Class Initialized
INFO - 2023-05-11 10:03:25 --> Final output sent to browser
DEBUG - 2023-05-11 10:03:25 --> Total execution time: 0.0221
ERROR - 2023-05-11 11:47:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 11:47:46 --> Config Class Initialized
INFO - 2023-05-11 11:47:46 --> Hooks Class Initialized
DEBUG - 2023-05-11 11:47:46 --> UTF-8 Support Enabled
INFO - 2023-05-11 11:47:46 --> Utf8 Class Initialized
INFO - 2023-05-11 11:47:46 --> URI Class Initialized
INFO - 2023-05-11 11:47:46 --> Router Class Initialized
INFO - 2023-05-11 11:47:46 --> Output Class Initialized
INFO - 2023-05-11 11:47:46 --> Security Class Initialized
DEBUG - 2023-05-11 11:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 11:47:46 --> Input Class Initialized
INFO - 2023-05-11 11:47:46 --> Language Class Initialized
INFO - 2023-05-11 11:47:46 --> Loader Class Initialized
INFO - 2023-05-11 11:47:46 --> Helper loaded: url_helper
INFO - 2023-05-11 11:47:46 --> Helper loaded: file_helper
INFO - 2023-05-11 11:47:46 --> Helper loaded: html_helper
INFO - 2023-05-11 11:47:46 --> Helper loaded: text_helper
INFO - 2023-05-11 11:47:46 --> Helper loaded: form_helper
INFO - 2023-05-11 11:47:46 --> Helper loaded: lang_helper
INFO - 2023-05-11 11:47:46 --> Helper loaded: security_helper
INFO - 2023-05-11 11:47:46 --> Helper loaded: cookie_helper
INFO - 2023-05-11 11:47:46 --> Database Driver Class Initialized
INFO - 2023-05-11 11:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 11:47:46 --> Parser Class Initialized
INFO - 2023-05-11 11:47:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 11:47:46 --> Pagination Class Initialized
INFO - 2023-05-11 11:47:46 --> Form Validation Class Initialized
INFO - 2023-05-11 11:47:46 --> Controller Class Initialized
INFO - 2023-05-11 11:47:46 --> Model Class Initialized
DEBUG - 2023-05-11 11:47:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 11:47:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 11:47:46 --> Model Class Initialized
DEBUG - 2023-05-11 11:47:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 11:47:46 --> Model Class Initialized
INFO - 2023-05-11 11:47:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-05-11 11:47:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 11:47:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 11:47:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 11:47:46 --> Model Class Initialized
INFO - 2023-05-11 11:47:46 --> Model Class Initialized
INFO - 2023-05-11 11:47:46 --> Model Class Initialized
INFO - 2023-05-11 11:47:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 11:47:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 11:47:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 11:47:46 --> Final output sent to browser
DEBUG - 2023-05-11 11:47:46 --> Total execution time: 0.1573
ERROR - 2023-05-11 11:47:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 11:47:47 --> Config Class Initialized
INFO - 2023-05-11 11:47:47 --> Hooks Class Initialized
DEBUG - 2023-05-11 11:47:47 --> UTF-8 Support Enabled
INFO - 2023-05-11 11:47:47 --> Utf8 Class Initialized
INFO - 2023-05-11 11:47:47 --> URI Class Initialized
INFO - 2023-05-11 11:47:47 --> Router Class Initialized
INFO - 2023-05-11 11:47:47 --> Output Class Initialized
INFO - 2023-05-11 11:47:47 --> Security Class Initialized
DEBUG - 2023-05-11 11:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 11:47:47 --> Input Class Initialized
INFO - 2023-05-11 11:47:47 --> Language Class Initialized
INFO - 2023-05-11 11:47:47 --> Loader Class Initialized
INFO - 2023-05-11 11:47:47 --> Helper loaded: url_helper
INFO - 2023-05-11 11:47:47 --> Helper loaded: file_helper
INFO - 2023-05-11 11:47:47 --> Helper loaded: html_helper
INFO - 2023-05-11 11:47:47 --> Helper loaded: text_helper
INFO - 2023-05-11 11:47:47 --> Helper loaded: form_helper
INFO - 2023-05-11 11:47:47 --> Helper loaded: lang_helper
INFO - 2023-05-11 11:47:47 --> Helper loaded: security_helper
INFO - 2023-05-11 11:47:47 --> Helper loaded: cookie_helper
INFO - 2023-05-11 11:47:47 --> Database Driver Class Initialized
INFO - 2023-05-11 11:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 11:47:47 --> Parser Class Initialized
INFO - 2023-05-11 11:47:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 11:47:47 --> Pagination Class Initialized
INFO - 2023-05-11 11:47:47 --> Form Validation Class Initialized
INFO - 2023-05-11 11:47:47 --> Controller Class Initialized
INFO - 2023-05-11 11:47:47 --> Model Class Initialized
DEBUG - 2023-05-11 11:47:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 11:47:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 11:47:47 --> Model Class Initialized
DEBUG - 2023-05-11 11:47:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 11:47:47 --> Model Class Initialized
INFO - 2023-05-11 11:47:47 --> Final output sent to browser
DEBUG - 2023-05-11 11:47:47 --> Total execution time: 0.0534
ERROR - 2023-05-11 12:04:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:04:29 --> Config Class Initialized
INFO - 2023-05-11 12:04:29 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:04:29 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:04:29 --> Utf8 Class Initialized
INFO - 2023-05-11 12:04:29 --> URI Class Initialized
INFO - 2023-05-11 12:04:29 --> Router Class Initialized
INFO - 2023-05-11 12:04:29 --> Output Class Initialized
INFO - 2023-05-11 12:04:29 --> Security Class Initialized
DEBUG - 2023-05-11 12:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:04:29 --> Input Class Initialized
INFO - 2023-05-11 12:04:29 --> Language Class Initialized
INFO - 2023-05-11 12:04:29 --> Loader Class Initialized
INFO - 2023-05-11 12:04:29 --> Helper loaded: url_helper
INFO - 2023-05-11 12:04:29 --> Helper loaded: file_helper
INFO - 2023-05-11 12:04:29 --> Helper loaded: html_helper
INFO - 2023-05-11 12:04:29 --> Helper loaded: text_helper
INFO - 2023-05-11 12:04:29 --> Helper loaded: form_helper
INFO - 2023-05-11 12:04:29 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:04:29 --> Helper loaded: security_helper
INFO - 2023-05-11 12:04:29 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:04:29 --> Database Driver Class Initialized
INFO - 2023-05-11 12:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:04:29 --> Parser Class Initialized
INFO - 2023-05-11 12:04:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:04:29 --> Pagination Class Initialized
INFO - 2023-05-11 12:04:29 --> Form Validation Class Initialized
INFO - 2023-05-11 12:04:29 --> Controller Class Initialized
INFO - 2023-05-11 12:04:29 --> Model Class Initialized
DEBUG - 2023-05-11 12:04:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:04:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:04:29 --> Model Class Initialized
DEBUG - 2023-05-11 12:04:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:04:29 --> Model Class Initialized
INFO - 2023-05-11 12:04:29 --> Final output sent to browser
DEBUG - 2023-05-11 12:04:29 --> Total execution time: 0.0541
ERROR - 2023-05-11 12:04:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:04:34 --> Config Class Initialized
INFO - 2023-05-11 12:04:34 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:04:34 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:04:34 --> Utf8 Class Initialized
INFO - 2023-05-11 12:04:34 --> URI Class Initialized
DEBUG - 2023-05-11 12:04:34 --> No URI present. Default controller set.
INFO - 2023-05-11 12:04:34 --> Router Class Initialized
INFO - 2023-05-11 12:04:34 --> Output Class Initialized
INFO - 2023-05-11 12:04:34 --> Security Class Initialized
DEBUG - 2023-05-11 12:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:04:34 --> Input Class Initialized
INFO - 2023-05-11 12:04:34 --> Language Class Initialized
INFO - 2023-05-11 12:04:34 --> Loader Class Initialized
INFO - 2023-05-11 12:04:34 --> Helper loaded: url_helper
INFO - 2023-05-11 12:04:34 --> Helper loaded: file_helper
INFO - 2023-05-11 12:04:34 --> Helper loaded: html_helper
INFO - 2023-05-11 12:04:34 --> Helper loaded: text_helper
INFO - 2023-05-11 12:04:34 --> Helper loaded: form_helper
INFO - 2023-05-11 12:04:34 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:04:34 --> Helper loaded: security_helper
INFO - 2023-05-11 12:04:34 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:04:34 --> Database Driver Class Initialized
INFO - 2023-05-11 12:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:04:34 --> Parser Class Initialized
INFO - 2023-05-11 12:04:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:04:34 --> Pagination Class Initialized
INFO - 2023-05-11 12:04:34 --> Form Validation Class Initialized
INFO - 2023-05-11 12:04:34 --> Controller Class Initialized
INFO - 2023-05-11 12:04:34 --> Model Class Initialized
DEBUG - 2023-05-11 12:04:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:04:34 --> Model Class Initialized
DEBUG - 2023-05-11 12:04:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:04:34 --> Model Class Initialized
INFO - 2023-05-11 12:04:34 --> Model Class Initialized
INFO - 2023-05-11 12:04:34 --> Model Class Initialized
INFO - 2023-05-11 12:04:34 --> Model Class Initialized
DEBUG - 2023-05-11 12:04:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:04:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:04:34 --> Model Class Initialized
INFO - 2023-05-11 12:04:34 --> Model Class Initialized
INFO - 2023-05-11 12:04:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-11 12:04:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:04:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 12:04:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 12:04:34 --> Model Class Initialized
INFO - 2023-05-11 12:04:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 12:04:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 12:04:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 12:04:34 --> Final output sent to browser
DEBUG - 2023-05-11 12:04:34 --> Total execution time: 0.1848
ERROR - 2023-05-11 12:05:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:05:00 --> Config Class Initialized
INFO - 2023-05-11 12:05:00 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:05:00 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:05:00 --> Utf8 Class Initialized
INFO - 2023-05-11 12:05:00 --> URI Class Initialized
DEBUG - 2023-05-11 12:05:00 --> No URI present. Default controller set.
INFO - 2023-05-11 12:05:00 --> Router Class Initialized
INFO - 2023-05-11 12:05:00 --> Output Class Initialized
INFO - 2023-05-11 12:05:00 --> Security Class Initialized
DEBUG - 2023-05-11 12:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:05:00 --> Input Class Initialized
INFO - 2023-05-11 12:05:00 --> Language Class Initialized
INFO - 2023-05-11 12:05:00 --> Loader Class Initialized
INFO - 2023-05-11 12:05:00 --> Helper loaded: url_helper
INFO - 2023-05-11 12:05:00 --> Helper loaded: file_helper
INFO - 2023-05-11 12:05:00 --> Helper loaded: html_helper
INFO - 2023-05-11 12:05:00 --> Helper loaded: text_helper
INFO - 2023-05-11 12:05:00 --> Helper loaded: form_helper
INFO - 2023-05-11 12:05:00 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:05:00 --> Helper loaded: security_helper
INFO - 2023-05-11 12:05:00 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:05:00 --> Database Driver Class Initialized
INFO - 2023-05-11 12:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:05:00 --> Parser Class Initialized
INFO - 2023-05-11 12:05:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:05:00 --> Pagination Class Initialized
INFO - 2023-05-11 12:05:00 --> Form Validation Class Initialized
INFO - 2023-05-11 12:05:00 --> Controller Class Initialized
INFO - 2023-05-11 12:05:00 --> Model Class Initialized
DEBUG - 2023-05-11 12:05:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-11 12:05:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:05:01 --> Config Class Initialized
INFO - 2023-05-11 12:05:01 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:05:01 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:05:01 --> Utf8 Class Initialized
INFO - 2023-05-11 12:05:01 --> URI Class Initialized
INFO - 2023-05-11 12:05:01 --> Router Class Initialized
INFO - 2023-05-11 12:05:01 --> Output Class Initialized
INFO - 2023-05-11 12:05:01 --> Security Class Initialized
DEBUG - 2023-05-11 12:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:05:01 --> Input Class Initialized
INFO - 2023-05-11 12:05:01 --> Language Class Initialized
INFO - 2023-05-11 12:05:01 --> Loader Class Initialized
INFO - 2023-05-11 12:05:01 --> Helper loaded: url_helper
INFO - 2023-05-11 12:05:01 --> Helper loaded: file_helper
INFO - 2023-05-11 12:05:01 --> Helper loaded: html_helper
INFO - 2023-05-11 12:05:01 --> Helper loaded: text_helper
INFO - 2023-05-11 12:05:01 --> Helper loaded: form_helper
INFO - 2023-05-11 12:05:01 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:05:01 --> Helper loaded: security_helper
INFO - 2023-05-11 12:05:01 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:05:01 --> Database Driver Class Initialized
INFO - 2023-05-11 12:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:05:01 --> Parser Class Initialized
INFO - 2023-05-11 12:05:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:05:01 --> Pagination Class Initialized
INFO - 2023-05-11 12:05:01 --> Form Validation Class Initialized
INFO - 2023-05-11 12:05:01 --> Controller Class Initialized
INFO - 2023-05-11 12:05:01 --> Model Class Initialized
DEBUG - 2023-05-11 12:05:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:05:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-11 12:05:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:05:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 12:05:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 12:05:01 --> Model Class Initialized
INFO - 2023-05-11 12:05:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 12:05:01 --> Final output sent to browser
DEBUG - 2023-05-11 12:05:01 --> Total execution time: 0.0442
ERROR - 2023-05-11 12:05:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:05:06 --> Config Class Initialized
INFO - 2023-05-11 12:05:06 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:05:06 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:05:06 --> Utf8 Class Initialized
INFO - 2023-05-11 12:05:06 --> URI Class Initialized
INFO - 2023-05-11 12:05:06 --> Router Class Initialized
INFO - 2023-05-11 12:05:06 --> Output Class Initialized
INFO - 2023-05-11 12:05:06 --> Security Class Initialized
DEBUG - 2023-05-11 12:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:05:06 --> Input Class Initialized
INFO - 2023-05-11 12:05:06 --> Language Class Initialized
INFO - 2023-05-11 12:05:06 --> Loader Class Initialized
INFO - 2023-05-11 12:05:06 --> Helper loaded: url_helper
INFO - 2023-05-11 12:05:06 --> Helper loaded: file_helper
INFO - 2023-05-11 12:05:06 --> Helper loaded: html_helper
INFO - 2023-05-11 12:05:06 --> Helper loaded: text_helper
INFO - 2023-05-11 12:05:06 --> Helper loaded: form_helper
INFO - 2023-05-11 12:05:06 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:05:06 --> Helper loaded: security_helper
INFO - 2023-05-11 12:05:06 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:05:06 --> Database Driver Class Initialized
INFO - 2023-05-11 12:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:05:06 --> Parser Class Initialized
INFO - 2023-05-11 12:05:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:05:06 --> Pagination Class Initialized
INFO - 2023-05-11 12:05:06 --> Form Validation Class Initialized
INFO - 2023-05-11 12:05:06 --> Controller Class Initialized
INFO - 2023-05-11 12:05:06 --> Model Class Initialized
DEBUG - 2023-05-11 12:05:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:05:06 --> Model Class Initialized
INFO - 2023-05-11 12:05:06 --> Final output sent to browser
DEBUG - 2023-05-11 12:05:06 --> Total execution time: 0.0210
ERROR - 2023-05-11 12:05:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:05:06 --> Config Class Initialized
INFO - 2023-05-11 12:05:06 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:05:06 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:05:06 --> Utf8 Class Initialized
INFO - 2023-05-11 12:05:06 --> URI Class Initialized
DEBUG - 2023-05-11 12:05:06 --> No URI present. Default controller set.
INFO - 2023-05-11 12:05:06 --> Router Class Initialized
INFO - 2023-05-11 12:05:06 --> Output Class Initialized
INFO - 2023-05-11 12:05:06 --> Security Class Initialized
DEBUG - 2023-05-11 12:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:05:06 --> Input Class Initialized
INFO - 2023-05-11 12:05:06 --> Language Class Initialized
INFO - 2023-05-11 12:05:06 --> Loader Class Initialized
INFO - 2023-05-11 12:05:06 --> Helper loaded: url_helper
INFO - 2023-05-11 12:05:06 --> Helper loaded: file_helper
INFO - 2023-05-11 12:05:06 --> Helper loaded: html_helper
INFO - 2023-05-11 12:05:06 --> Helper loaded: text_helper
INFO - 2023-05-11 12:05:06 --> Helper loaded: form_helper
INFO - 2023-05-11 12:05:06 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:05:06 --> Helper loaded: security_helper
INFO - 2023-05-11 12:05:06 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:05:06 --> Database Driver Class Initialized
INFO - 2023-05-11 12:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:05:06 --> Parser Class Initialized
INFO - 2023-05-11 12:05:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:05:06 --> Pagination Class Initialized
INFO - 2023-05-11 12:05:06 --> Form Validation Class Initialized
INFO - 2023-05-11 12:05:06 --> Controller Class Initialized
INFO - 2023-05-11 12:05:06 --> Model Class Initialized
DEBUG - 2023-05-11 12:05:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:05:06 --> Model Class Initialized
DEBUG - 2023-05-11 12:05:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:05:06 --> Model Class Initialized
INFO - 2023-05-11 12:05:06 --> Model Class Initialized
INFO - 2023-05-11 12:05:06 --> Model Class Initialized
INFO - 2023-05-11 12:05:06 --> Model Class Initialized
DEBUG - 2023-05-11 12:05:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:05:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:05:06 --> Model Class Initialized
INFO - 2023-05-11 12:05:06 --> Model Class Initialized
INFO - 2023-05-11 12:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-11 12:05:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 12:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 12:05:06 --> Model Class Initialized
INFO - 2023-05-11 12:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 12:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 12:05:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 12:05:06 --> Final output sent to browser
DEBUG - 2023-05-11 12:05:06 --> Total execution time: 0.0882
ERROR - 2023-05-11 12:05:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:05:48 --> Config Class Initialized
INFO - 2023-05-11 12:05:48 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:05:48 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:05:48 --> Utf8 Class Initialized
INFO - 2023-05-11 12:05:48 --> URI Class Initialized
INFO - 2023-05-11 12:05:48 --> Router Class Initialized
INFO - 2023-05-11 12:05:48 --> Output Class Initialized
INFO - 2023-05-11 12:05:48 --> Security Class Initialized
DEBUG - 2023-05-11 12:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:05:48 --> Input Class Initialized
INFO - 2023-05-11 12:05:48 --> Language Class Initialized
INFO - 2023-05-11 12:05:48 --> Loader Class Initialized
INFO - 2023-05-11 12:05:48 --> Helper loaded: url_helper
INFO - 2023-05-11 12:05:48 --> Helper loaded: file_helper
INFO - 2023-05-11 12:05:48 --> Helper loaded: html_helper
INFO - 2023-05-11 12:05:48 --> Helper loaded: text_helper
INFO - 2023-05-11 12:05:48 --> Helper loaded: form_helper
INFO - 2023-05-11 12:05:48 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:05:48 --> Helper loaded: security_helper
INFO - 2023-05-11 12:05:48 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:05:48 --> Database Driver Class Initialized
INFO - 2023-05-11 12:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:05:48 --> Parser Class Initialized
INFO - 2023-05-11 12:05:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:05:48 --> Pagination Class Initialized
INFO - 2023-05-11 12:05:48 --> Form Validation Class Initialized
INFO - 2023-05-11 12:05:48 --> Controller Class Initialized
INFO - 2023-05-11 12:05:48 --> Model Class Initialized
DEBUG - 2023-05-11 12:05:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:05:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:05:48 --> Model Class Initialized
DEBUG - 2023-05-11 12:05:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:05:48 --> Model Class Initialized
INFO - 2023-05-11 12:05:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-11 12:05:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:05:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 12:05:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 12:05:48 --> Model Class Initialized
INFO - 2023-05-11 12:05:48 --> Model Class Initialized
INFO - 2023-05-11 12:05:48 --> Model Class Initialized
INFO - 2023-05-11 12:05:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 12:05:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 12:05:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 12:05:48 --> Final output sent to browser
DEBUG - 2023-05-11 12:05:48 --> Total execution time: 0.0804
ERROR - 2023-05-11 12:05:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:05:49 --> Config Class Initialized
INFO - 2023-05-11 12:05:49 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:05:49 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:05:49 --> Utf8 Class Initialized
INFO - 2023-05-11 12:05:49 --> URI Class Initialized
INFO - 2023-05-11 12:05:49 --> Router Class Initialized
INFO - 2023-05-11 12:05:49 --> Output Class Initialized
INFO - 2023-05-11 12:05:49 --> Security Class Initialized
DEBUG - 2023-05-11 12:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:05:49 --> Input Class Initialized
INFO - 2023-05-11 12:05:49 --> Language Class Initialized
INFO - 2023-05-11 12:05:49 --> Loader Class Initialized
INFO - 2023-05-11 12:05:49 --> Helper loaded: url_helper
INFO - 2023-05-11 12:05:49 --> Helper loaded: file_helper
INFO - 2023-05-11 12:05:49 --> Helper loaded: html_helper
INFO - 2023-05-11 12:05:49 --> Helper loaded: text_helper
INFO - 2023-05-11 12:05:49 --> Helper loaded: form_helper
INFO - 2023-05-11 12:05:49 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:05:49 --> Helper loaded: security_helper
INFO - 2023-05-11 12:05:49 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:05:49 --> Database Driver Class Initialized
INFO - 2023-05-11 12:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:05:49 --> Parser Class Initialized
INFO - 2023-05-11 12:05:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:05:49 --> Pagination Class Initialized
INFO - 2023-05-11 12:05:49 --> Form Validation Class Initialized
INFO - 2023-05-11 12:05:49 --> Controller Class Initialized
INFO - 2023-05-11 12:05:49 --> Model Class Initialized
DEBUG - 2023-05-11 12:05:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:05:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:05:49 --> Model Class Initialized
DEBUG - 2023-05-11 12:05:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:05:49 --> Model Class Initialized
INFO - 2023-05-11 12:05:49 --> Final output sent to browser
DEBUG - 2023-05-11 12:05:49 --> Total execution time: 0.0473
ERROR - 2023-05-11 12:05:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:05:55 --> Config Class Initialized
INFO - 2023-05-11 12:05:55 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:05:55 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:05:55 --> Utf8 Class Initialized
INFO - 2023-05-11 12:05:55 --> URI Class Initialized
INFO - 2023-05-11 12:05:55 --> Router Class Initialized
INFO - 2023-05-11 12:05:55 --> Output Class Initialized
INFO - 2023-05-11 12:05:55 --> Security Class Initialized
DEBUG - 2023-05-11 12:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:05:55 --> Input Class Initialized
INFO - 2023-05-11 12:05:55 --> Language Class Initialized
INFO - 2023-05-11 12:05:55 --> Loader Class Initialized
INFO - 2023-05-11 12:05:55 --> Helper loaded: url_helper
INFO - 2023-05-11 12:05:55 --> Helper loaded: file_helper
INFO - 2023-05-11 12:05:55 --> Helper loaded: html_helper
INFO - 2023-05-11 12:05:55 --> Helper loaded: text_helper
INFO - 2023-05-11 12:05:55 --> Helper loaded: form_helper
INFO - 2023-05-11 12:05:55 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:05:55 --> Helper loaded: security_helper
INFO - 2023-05-11 12:05:55 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:05:55 --> Database Driver Class Initialized
INFO - 2023-05-11 12:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:05:55 --> Parser Class Initialized
INFO - 2023-05-11 12:05:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:05:55 --> Pagination Class Initialized
INFO - 2023-05-11 12:05:55 --> Form Validation Class Initialized
INFO - 2023-05-11 12:05:55 --> Controller Class Initialized
INFO - 2023-05-11 12:05:55 --> Model Class Initialized
DEBUG - 2023-05-11 12:05:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:05:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:05:55 --> Model Class Initialized
DEBUG - 2023-05-11 12:05:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:05:55 --> Model Class Initialized
INFO - 2023-05-11 12:05:55 --> Final output sent to browser
DEBUG - 2023-05-11 12:05:55 --> Total execution time: 0.0817
ERROR - 2023-05-11 12:06:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:06:31 --> Config Class Initialized
INFO - 2023-05-11 12:06:31 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:06:31 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:06:31 --> Utf8 Class Initialized
INFO - 2023-05-11 12:06:31 --> URI Class Initialized
INFO - 2023-05-11 12:06:31 --> Router Class Initialized
INFO - 2023-05-11 12:06:31 --> Output Class Initialized
INFO - 2023-05-11 12:06:31 --> Security Class Initialized
DEBUG - 2023-05-11 12:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:06:31 --> Input Class Initialized
INFO - 2023-05-11 12:06:31 --> Language Class Initialized
INFO - 2023-05-11 12:06:31 --> Loader Class Initialized
INFO - 2023-05-11 12:06:31 --> Helper loaded: url_helper
INFO - 2023-05-11 12:06:31 --> Helper loaded: file_helper
INFO - 2023-05-11 12:06:31 --> Helper loaded: html_helper
INFO - 2023-05-11 12:06:31 --> Helper loaded: text_helper
INFO - 2023-05-11 12:06:31 --> Helper loaded: form_helper
INFO - 2023-05-11 12:06:31 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:06:31 --> Helper loaded: security_helper
INFO - 2023-05-11 12:06:31 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:06:31 --> Database Driver Class Initialized
INFO - 2023-05-11 12:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:06:31 --> Parser Class Initialized
INFO - 2023-05-11 12:06:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:06:31 --> Pagination Class Initialized
INFO - 2023-05-11 12:06:31 --> Form Validation Class Initialized
INFO - 2023-05-11 12:06:31 --> Controller Class Initialized
INFO - 2023-05-11 12:06:31 --> Model Class Initialized
DEBUG - 2023-05-11 12:06:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:06:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:06:31 --> Model Class Initialized
INFO - 2023-05-11 12:06:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-11 12:06:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:06:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 12:06:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 12:06:31 --> Model Class Initialized
INFO - 2023-05-11 12:06:31 --> Model Class Initialized
INFO - 2023-05-11 12:06:31 --> Model Class Initialized
INFO - 2023-05-11 12:06:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 12:06:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 12:06:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 12:06:31 --> Final output sent to browser
DEBUG - 2023-05-11 12:06:31 --> Total execution time: 0.0749
ERROR - 2023-05-11 12:06:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:06:31 --> Config Class Initialized
INFO - 2023-05-11 12:06:31 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:06:31 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:06:31 --> Utf8 Class Initialized
INFO - 2023-05-11 12:06:31 --> URI Class Initialized
INFO - 2023-05-11 12:06:31 --> Router Class Initialized
INFO - 2023-05-11 12:06:31 --> Output Class Initialized
INFO - 2023-05-11 12:06:31 --> Security Class Initialized
DEBUG - 2023-05-11 12:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:06:31 --> Input Class Initialized
INFO - 2023-05-11 12:06:31 --> Language Class Initialized
INFO - 2023-05-11 12:06:31 --> Loader Class Initialized
INFO - 2023-05-11 12:06:31 --> Helper loaded: url_helper
INFO - 2023-05-11 12:06:31 --> Helper loaded: file_helper
INFO - 2023-05-11 12:06:31 --> Helper loaded: html_helper
INFO - 2023-05-11 12:06:31 --> Helper loaded: text_helper
INFO - 2023-05-11 12:06:31 --> Helper loaded: form_helper
INFO - 2023-05-11 12:06:31 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:06:31 --> Helper loaded: security_helper
INFO - 2023-05-11 12:06:31 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:06:31 --> Database Driver Class Initialized
INFO - 2023-05-11 12:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:06:31 --> Parser Class Initialized
INFO - 2023-05-11 12:06:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:06:31 --> Pagination Class Initialized
INFO - 2023-05-11 12:06:31 --> Form Validation Class Initialized
INFO - 2023-05-11 12:06:31 --> Controller Class Initialized
INFO - 2023-05-11 12:06:31 --> Model Class Initialized
DEBUG - 2023-05-11 12:06:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:06:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:06:31 --> Model Class Initialized
INFO - 2023-05-11 12:06:31 --> Final output sent to browser
DEBUG - 2023-05-11 12:06:31 --> Total execution time: 0.0241
ERROR - 2023-05-11 12:06:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:06:35 --> Config Class Initialized
INFO - 2023-05-11 12:06:35 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:06:35 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:06:35 --> Utf8 Class Initialized
INFO - 2023-05-11 12:06:35 --> URI Class Initialized
INFO - 2023-05-11 12:06:35 --> Router Class Initialized
INFO - 2023-05-11 12:06:35 --> Output Class Initialized
INFO - 2023-05-11 12:06:35 --> Security Class Initialized
DEBUG - 2023-05-11 12:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:06:35 --> Input Class Initialized
INFO - 2023-05-11 12:06:35 --> Language Class Initialized
INFO - 2023-05-11 12:06:35 --> Loader Class Initialized
INFO - 2023-05-11 12:06:35 --> Helper loaded: url_helper
INFO - 2023-05-11 12:06:35 --> Helper loaded: file_helper
INFO - 2023-05-11 12:06:35 --> Helper loaded: html_helper
INFO - 2023-05-11 12:06:35 --> Helper loaded: text_helper
INFO - 2023-05-11 12:06:35 --> Helper loaded: form_helper
INFO - 2023-05-11 12:06:35 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:06:35 --> Helper loaded: security_helper
INFO - 2023-05-11 12:06:35 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:06:35 --> Database Driver Class Initialized
INFO - 2023-05-11 12:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:06:35 --> Parser Class Initialized
INFO - 2023-05-11 12:06:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:06:35 --> Pagination Class Initialized
INFO - 2023-05-11 12:06:35 --> Form Validation Class Initialized
INFO - 2023-05-11 12:06:35 --> Controller Class Initialized
INFO - 2023-05-11 12:06:35 --> Model Class Initialized
DEBUG - 2023-05-11 12:06:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:06:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:06:35 --> Model Class Initialized
INFO - 2023-05-11 12:06:35 --> Final output sent to browser
DEBUG - 2023-05-11 12:06:35 --> Total execution time: 0.0252
ERROR - 2023-05-11 12:17:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:17:13 --> Config Class Initialized
INFO - 2023-05-11 12:17:13 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:17:13 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:17:13 --> Utf8 Class Initialized
INFO - 2023-05-11 12:17:13 --> URI Class Initialized
INFO - 2023-05-11 12:17:13 --> Router Class Initialized
INFO - 2023-05-11 12:17:13 --> Output Class Initialized
INFO - 2023-05-11 12:17:13 --> Security Class Initialized
DEBUG - 2023-05-11 12:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:17:13 --> Input Class Initialized
INFO - 2023-05-11 12:17:13 --> Language Class Initialized
INFO - 2023-05-11 12:17:13 --> Loader Class Initialized
INFO - 2023-05-11 12:17:13 --> Helper loaded: url_helper
INFO - 2023-05-11 12:17:13 --> Helper loaded: file_helper
INFO - 2023-05-11 12:17:13 --> Helper loaded: html_helper
INFO - 2023-05-11 12:17:13 --> Helper loaded: text_helper
INFO - 2023-05-11 12:17:13 --> Helper loaded: form_helper
INFO - 2023-05-11 12:17:13 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:17:13 --> Helper loaded: security_helper
INFO - 2023-05-11 12:17:13 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:17:13 --> Database Driver Class Initialized
INFO - 2023-05-11 12:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:17:13 --> Parser Class Initialized
INFO - 2023-05-11 12:17:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:17:13 --> Pagination Class Initialized
INFO - 2023-05-11 12:17:13 --> Form Validation Class Initialized
INFO - 2023-05-11 12:17:13 --> Controller Class Initialized
INFO - 2023-05-11 12:17:13 --> Model Class Initialized
DEBUG - 2023-05-11 12:17:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:17:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:17:13 --> Model Class Initialized
DEBUG - 2023-05-11 12:17:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:17:13 --> Model Class Initialized
INFO - 2023-05-11 12:17:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-11 12:17:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:17:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 12:17:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 12:17:13 --> Model Class Initialized
INFO - 2023-05-11 12:17:13 --> Model Class Initialized
INFO - 2023-05-11 12:17:13 --> Model Class Initialized
INFO - 2023-05-11 12:17:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 12:17:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 12:17:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 12:17:13 --> Final output sent to browser
DEBUG - 2023-05-11 12:17:13 --> Total execution time: 0.1561
ERROR - 2023-05-11 12:17:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:17:14 --> Config Class Initialized
INFO - 2023-05-11 12:17:14 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:17:14 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:17:14 --> Utf8 Class Initialized
INFO - 2023-05-11 12:17:14 --> URI Class Initialized
INFO - 2023-05-11 12:17:14 --> Router Class Initialized
INFO - 2023-05-11 12:17:14 --> Output Class Initialized
INFO - 2023-05-11 12:17:14 --> Security Class Initialized
DEBUG - 2023-05-11 12:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:17:14 --> Input Class Initialized
INFO - 2023-05-11 12:17:14 --> Language Class Initialized
INFO - 2023-05-11 12:17:14 --> Loader Class Initialized
INFO - 2023-05-11 12:17:14 --> Helper loaded: url_helper
INFO - 2023-05-11 12:17:14 --> Helper loaded: file_helper
INFO - 2023-05-11 12:17:14 --> Helper loaded: html_helper
INFO - 2023-05-11 12:17:14 --> Helper loaded: text_helper
INFO - 2023-05-11 12:17:14 --> Helper loaded: form_helper
INFO - 2023-05-11 12:17:14 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:17:14 --> Helper loaded: security_helper
INFO - 2023-05-11 12:17:14 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:17:14 --> Database Driver Class Initialized
INFO - 2023-05-11 12:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:17:14 --> Parser Class Initialized
INFO - 2023-05-11 12:17:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:17:14 --> Pagination Class Initialized
INFO - 2023-05-11 12:17:14 --> Form Validation Class Initialized
INFO - 2023-05-11 12:17:14 --> Controller Class Initialized
INFO - 2023-05-11 12:17:14 --> Model Class Initialized
DEBUG - 2023-05-11 12:17:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:17:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:17:14 --> Model Class Initialized
DEBUG - 2023-05-11 12:17:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:17:14 --> Model Class Initialized
INFO - 2023-05-11 12:17:14 --> Final output sent to browser
DEBUG - 2023-05-11 12:17:14 --> Total execution time: 0.0552
ERROR - 2023-05-11 12:17:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:17:24 --> Config Class Initialized
INFO - 2023-05-11 12:17:24 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:17:24 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:17:24 --> Utf8 Class Initialized
INFO - 2023-05-11 12:17:24 --> URI Class Initialized
INFO - 2023-05-11 12:17:24 --> Router Class Initialized
INFO - 2023-05-11 12:17:24 --> Output Class Initialized
INFO - 2023-05-11 12:17:24 --> Security Class Initialized
DEBUG - 2023-05-11 12:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:17:24 --> Input Class Initialized
INFO - 2023-05-11 12:17:24 --> Language Class Initialized
INFO - 2023-05-11 12:17:24 --> Loader Class Initialized
INFO - 2023-05-11 12:17:24 --> Helper loaded: url_helper
INFO - 2023-05-11 12:17:24 --> Helper loaded: file_helper
INFO - 2023-05-11 12:17:24 --> Helper loaded: html_helper
INFO - 2023-05-11 12:17:24 --> Helper loaded: text_helper
INFO - 2023-05-11 12:17:24 --> Helper loaded: form_helper
INFO - 2023-05-11 12:17:24 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:17:24 --> Helper loaded: security_helper
INFO - 2023-05-11 12:17:24 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:17:24 --> Database Driver Class Initialized
INFO - 2023-05-11 12:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:17:24 --> Parser Class Initialized
INFO - 2023-05-11 12:17:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:17:24 --> Pagination Class Initialized
INFO - 2023-05-11 12:17:24 --> Form Validation Class Initialized
INFO - 2023-05-11 12:17:24 --> Controller Class Initialized
INFO - 2023-05-11 12:17:24 --> Model Class Initialized
DEBUG - 2023-05-11 12:17:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:17:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:17:24 --> Model Class Initialized
DEBUG - 2023-05-11 12:17:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:17:24 --> Model Class Initialized
INFO - 2023-05-11 12:17:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-11 12:17:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:17:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 12:17:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 12:17:24 --> Model Class Initialized
INFO - 2023-05-11 12:17:24 --> Model Class Initialized
INFO - 2023-05-11 12:17:24 --> Model Class Initialized
INFO - 2023-05-11 12:17:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 12:17:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 12:17:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 12:17:24 --> Final output sent to browser
DEBUG - 2023-05-11 12:17:24 --> Total execution time: 0.1504
ERROR - 2023-05-11 12:17:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:17:25 --> Config Class Initialized
INFO - 2023-05-11 12:17:25 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:17:25 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:17:25 --> Utf8 Class Initialized
INFO - 2023-05-11 12:17:25 --> URI Class Initialized
INFO - 2023-05-11 12:17:25 --> Router Class Initialized
INFO - 2023-05-11 12:17:25 --> Output Class Initialized
INFO - 2023-05-11 12:17:25 --> Security Class Initialized
DEBUG - 2023-05-11 12:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:17:25 --> Input Class Initialized
INFO - 2023-05-11 12:17:25 --> Language Class Initialized
INFO - 2023-05-11 12:17:25 --> Loader Class Initialized
INFO - 2023-05-11 12:17:25 --> Helper loaded: url_helper
INFO - 2023-05-11 12:17:25 --> Helper loaded: file_helper
INFO - 2023-05-11 12:17:25 --> Helper loaded: html_helper
INFO - 2023-05-11 12:17:25 --> Helper loaded: text_helper
INFO - 2023-05-11 12:17:25 --> Helper loaded: form_helper
INFO - 2023-05-11 12:17:25 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:17:25 --> Helper loaded: security_helper
INFO - 2023-05-11 12:17:25 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:17:25 --> Database Driver Class Initialized
INFO - 2023-05-11 12:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:17:25 --> Parser Class Initialized
INFO - 2023-05-11 12:17:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:17:25 --> Pagination Class Initialized
INFO - 2023-05-11 12:17:25 --> Form Validation Class Initialized
INFO - 2023-05-11 12:17:25 --> Controller Class Initialized
INFO - 2023-05-11 12:17:25 --> Model Class Initialized
DEBUG - 2023-05-11 12:17:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:17:25 --> Model Class Initialized
DEBUG - 2023-05-11 12:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:17:25 --> Model Class Initialized
INFO - 2023-05-11 12:17:25 --> Final output sent to browser
DEBUG - 2023-05-11 12:17:25 --> Total execution time: 0.0547
ERROR - 2023-05-11 12:17:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:17:29 --> Config Class Initialized
INFO - 2023-05-11 12:17:29 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:17:29 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:17:29 --> Utf8 Class Initialized
INFO - 2023-05-11 12:17:29 --> URI Class Initialized
INFO - 2023-05-11 12:17:29 --> Router Class Initialized
INFO - 2023-05-11 12:17:29 --> Output Class Initialized
INFO - 2023-05-11 12:17:29 --> Security Class Initialized
DEBUG - 2023-05-11 12:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:17:29 --> Input Class Initialized
INFO - 2023-05-11 12:17:29 --> Language Class Initialized
INFO - 2023-05-11 12:17:29 --> Loader Class Initialized
INFO - 2023-05-11 12:17:29 --> Helper loaded: url_helper
INFO - 2023-05-11 12:17:29 --> Helper loaded: file_helper
INFO - 2023-05-11 12:17:29 --> Helper loaded: html_helper
INFO - 2023-05-11 12:17:29 --> Helper loaded: text_helper
INFO - 2023-05-11 12:17:29 --> Helper loaded: form_helper
INFO - 2023-05-11 12:17:29 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:17:29 --> Helper loaded: security_helper
INFO - 2023-05-11 12:17:29 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:17:29 --> Database Driver Class Initialized
INFO - 2023-05-11 12:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:17:29 --> Parser Class Initialized
INFO - 2023-05-11 12:17:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:17:29 --> Pagination Class Initialized
INFO - 2023-05-11 12:17:29 --> Form Validation Class Initialized
INFO - 2023-05-11 12:17:29 --> Controller Class Initialized
INFO - 2023-05-11 12:17:29 --> Model Class Initialized
DEBUG - 2023-05-11 12:17:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:17:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:17:29 --> Model Class Initialized
DEBUG - 2023-05-11 12:17:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:17:29 --> Model Class Initialized
INFO - 2023-05-11 12:17:29 --> Final output sent to browser
DEBUG - 2023-05-11 12:17:29 --> Total execution time: 0.1423
ERROR - 2023-05-11 12:18:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:18:01 --> Config Class Initialized
INFO - 2023-05-11 12:18:01 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:18:01 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:18:01 --> Utf8 Class Initialized
INFO - 2023-05-11 12:18:01 --> URI Class Initialized
INFO - 2023-05-11 12:18:01 --> Router Class Initialized
INFO - 2023-05-11 12:18:01 --> Output Class Initialized
INFO - 2023-05-11 12:18:01 --> Security Class Initialized
DEBUG - 2023-05-11 12:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:18:01 --> Input Class Initialized
INFO - 2023-05-11 12:18:01 --> Language Class Initialized
INFO - 2023-05-11 12:18:01 --> Loader Class Initialized
INFO - 2023-05-11 12:18:01 --> Helper loaded: url_helper
INFO - 2023-05-11 12:18:01 --> Helper loaded: file_helper
INFO - 2023-05-11 12:18:01 --> Helper loaded: html_helper
INFO - 2023-05-11 12:18:01 --> Helper loaded: text_helper
INFO - 2023-05-11 12:18:01 --> Helper loaded: form_helper
INFO - 2023-05-11 12:18:01 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:18:01 --> Helper loaded: security_helper
INFO - 2023-05-11 12:18:01 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:18:01 --> Database Driver Class Initialized
INFO - 2023-05-11 12:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:18:01 --> Parser Class Initialized
INFO - 2023-05-11 12:18:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:18:01 --> Pagination Class Initialized
INFO - 2023-05-11 12:18:01 --> Form Validation Class Initialized
INFO - 2023-05-11 12:18:01 --> Controller Class Initialized
INFO - 2023-05-11 12:18:01 --> Model Class Initialized
DEBUG - 2023-05-11 12:18:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:18:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:18:01 --> Model Class Initialized
DEBUG - 2023-05-11 12:18:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:18:01 --> Model Class Initialized
INFO - 2023-05-11 12:18:01 --> Final output sent to browser
DEBUG - 2023-05-11 12:18:01 --> Total execution time: 0.0624
ERROR - 2023-05-11 12:18:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:18:04 --> Config Class Initialized
INFO - 2023-05-11 12:18:04 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:18:04 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:18:04 --> Utf8 Class Initialized
INFO - 2023-05-11 12:18:04 --> URI Class Initialized
INFO - 2023-05-11 12:18:04 --> Router Class Initialized
INFO - 2023-05-11 12:18:05 --> Output Class Initialized
INFO - 2023-05-11 12:18:05 --> Security Class Initialized
DEBUG - 2023-05-11 12:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:18:05 --> Input Class Initialized
INFO - 2023-05-11 12:18:05 --> Language Class Initialized
INFO - 2023-05-11 12:18:05 --> Loader Class Initialized
INFO - 2023-05-11 12:18:05 --> Helper loaded: url_helper
INFO - 2023-05-11 12:18:05 --> Helper loaded: file_helper
INFO - 2023-05-11 12:18:05 --> Helper loaded: html_helper
INFO - 2023-05-11 12:18:05 --> Helper loaded: text_helper
INFO - 2023-05-11 12:18:05 --> Helper loaded: form_helper
INFO - 2023-05-11 12:18:05 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:18:05 --> Helper loaded: security_helper
INFO - 2023-05-11 12:18:05 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:18:05 --> Database Driver Class Initialized
INFO - 2023-05-11 12:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:18:05 --> Parser Class Initialized
INFO - 2023-05-11 12:18:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:18:05 --> Pagination Class Initialized
INFO - 2023-05-11 12:18:05 --> Form Validation Class Initialized
INFO - 2023-05-11 12:18:05 --> Controller Class Initialized
INFO - 2023-05-11 12:18:05 --> Model Class Initialized
DEBUG - 2023-05-11 12:18:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:18:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:18:05 --> Model Class Initialized
DEBUG - 2023-05-11 12:18:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:18:05 --> Model Class Initialized
INFO - 2023-05-11 12:18:05 --> Final output sent to browser
DEBUG - 2023-05-11 12:18:05 --> Total execution time: 0.0613
ERROR - 2023-05-11 12:18:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:18:10 --> Config Class Initialized
INFO - 2023-05-11 12:18:10 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:18:10 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:18:10 --> Utf8 Class Initialized
INFO - 2023-05-11 12:18:10 --> URI Class Initialized
DEBUG - 2023-05-11 12:18:10 --> No URI present. Default controller set.
INFO - 2023-05-11 12:18:10 --> Router Class Initialized
INFO - 2023-05-11 12:18:10 --> Output Class Initialized
INFO - 2023-05-11 12:18:10 --> Security Class Initialized
DEBUG - 2023-05-11 12:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:18:10 --> Input Class Initialized
INFO - 2023-05-11 12:18:10 --> Language Class Initialized
INFO - 2023-05-11 12:18:10 --> Loader Class Initialized
INFO - 2023-05-11 12:18:10 --> Helper loaded: url_helper
INFO - 2023-05-11 12:18:10 --> Helper loaded: file_helper
INFO - 2023-05-11 12:18:10 --> Helper loaded: html_helper
INFO - 2023-05-11 12:18:10 --> Helper loaded: text_helper
INFO - 2023-05-11 12:18:10 --> Helper loaded: form_helper
INFO - 2023-05-11 12:18:10 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:18:10 --> Helper loaded: security_helper
INFO - 2023-05-11 12:18:10 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:18:10 --> Database Driver Class Initialized
INFO - 2023-05-11 12:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:18:10 --> Parser Class Initialized
INFO - 2023-05-11 12:18:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:18:10 --> Pagination Class Initialized
INFO - 2023-05-11 12:18:10 --> Form Validation Class Initialized
INFO - 2023-05-11 12:18:10 --> Controller Class Initialized
INFO - 2023-05-11 12:18:10 --> Model Class Initialized
DEBUG - 2023-05-11 12:18:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:18:10 --> Model Class Initialized
DEBUG - 2023-05-11 12:18:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:18:10 --> Model Class Initialized
INFO - 2023-05-11 12:18:10 --> Model Class Initialized
INFO - 2023-05-11 12:18:10 --> Model Class Initialized
INFO - 2023-05-11 12:18:10 --> Model Class Initialized
DEBUG - 2023-05-11 12:18:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:18:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:18:10 --> Model Class Initialized
INFO - 2023-05-11 12:18:10 --> Model Class Initialized
INFO - 2023-05-11 12:18:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-11 12:18:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:18:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 12:18:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 12:18:10 --> Model Class Initialized
INFO - 2023-05-11 12:18:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 12:18:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 12:18:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 12:18:10 --> Final output sent to browser
DEBUG - 2023-05-11 12:18:10 --> Total execution time: 0.1922
ERROR - 2023-05-11 12:18:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:18:14 --> Config Class Initialized
INFO - 2023-05-11 12:18:14 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:18:14 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:18:14 --> Utf8 Class Initialized
INFO - 2023-05-11 12:18:14 --> URI Class Initialized
DEBUG - 2023-05-11 12:18:14 --> No URI present. Default controller set.
INFO - 2023-05-11 12:18:14 --> Router Class Initialized
INFO - 2023-05-11 12:18:14 --> Output Class Initialized
INFO - 2023-05-11 12:18:14 --> Security Class Initialized
DEBUG - 2023-05-11 12:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:18:14 --> Input Class Initialized
INFO - 2023-05-11 12:18:14 --> Language Class Initialized
INFO - 2023-05-11 12:18:14 --> Loader Class Initialized
INFO - 2023-05-11 12:18:14 --> Helper loaded: url_helper
INFO - 2023-05-11 12:18:14 --> Helper loaded: file_helper
INFO - 2023-05-11 12:18:14 --> Helper loaded: html_helper
INFO - 2023-05-11 12:18:14 --> Helper loaded: text_helper
INFO - 2023-05-11 12:18:14 --> Helper loaded: form_helper
INFO - 2023-05-11 12:18:14 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:18:14 --> Helper loaded: security_helper
INFO - 2023-05-11 12:18:14 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:18:14 --> Database Driver Class Initialized
INFO - 2023-05-11 12:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:18:14 --> Parser Class Initialized
INFO - 2023-05-11 12:18:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:18:14 --> Pagination Class Initialized
INFO - 2023-05-11 12:18:14 --> Form Validation Class Initialized
INFO - 2023-05-11 12:18:14 --> Controller Class Initialized
INFO - 2023-05-11 12:18:14 --> Model Class Initialized
DEBUG - 2023-05-11 12:18:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:18:14 --> Model Class Initialized
DEBUG - 2023-05-11 12:18:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:18:14 --> Model Class Initialized
INFO - 2023-05-11 12:18:14 --> Model Class Initialized
INFO - 2023-05-11 12:18:14 --> Model Class Initialized
INFO - 2023-05-11 12:18:14 --> Model Class Initialized
DEBUG - 2023-05-11 12:18:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:18:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:18:14 --> Model Class Initialized
INFO - 2023-05-11 12:18:14 --> Model Class Initialized
INFO - 2023-05-11 12:18:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-11 12:18:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:18:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 12:18:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 12:18:14 --> Model Class Initialized
INFO - 2023-05-11 12:18:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 12:18:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 12:18:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 12:18:14 --> Final output sent to browser
DEBUG - 2023-05-11 12:18:14 --> Total execution time: 0.1923
ERROR - 2023-05-11 12:18:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:18:23 --> Config Class Initialized
INFO - 2023-05-11 12:18:23 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:18:23 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:18:23 --> Utf8 Class Initialized
INFO - 2023-05-11 12:18:23 --> URI Class Initialized
INFO - 2023-05-11 12:18:23 --> Router Class Initialized
INFO - 2023-05-11 12:18:23 --> Output Class Initialized
INFO - 2023-05-11 12:18:23 --> Security Class Initialized
DEBUG - 2023-05-11 12:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:18:23 --> Input Class Initialized
INFO - 2023-05-11 12:18:23 --> Language Class Initialized
INFO - 2023-05-11 12:18:23 --> Loader Class Initialized
INFO - 2023-05-11 12:18:23 --> Helper loaded: url_helper
INFO - 2023-05-11 12:18:23 --> Helper loaded: file_helper
INFO - 2023-05-11 12:18:23 --> Helper loaded: html_helper
INFO - 2023-05-11 12:18:23 --> Helper loaded: text_helper
INFO - 2023-05-11 12:18:23 --> Helper loaded: form_helper
INFO - 2023-05-11 12:18:23 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:18:23 --> Helper loaded: security_helper
INFO - 2023-05-11 12:18:23 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:18:23 --> Database Driver Class Initialized
INFO - 2023-05-11 12:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:18:23 --> Parser Class Initialized
INFO - 2023-05-11 12:18:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:18:23 --> Pagination Class Initialized
INFO - 2023-05-11 12:18:23 --> Form Validation Class Initialized
INFO - 2023-05-11 12:18:23 --> Controller Class Initialized
INFO - 2023-05-11 12:18:23 --> Model Class Initialized
DEBUG - 2023-05-11 12:18:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:18:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:18:23 --> Model Class Initialized
DEBUG - 2023-05-11 12:18:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:18:23 --> Model Class Initialized
INFO - 2023-05-11 12:18:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-11 12:18:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:18:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 12:18:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 12:18:23 --> Model Class Initialized
INFO - 2023-05-11 12:18:23 --> Model Class Initialized
INFO - 2023-05-11 12:18:23 --> Model Class Initialized
INFO - 2023-05-11 12:18:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 12:18:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 12:18:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 12:18:23 --> Final output sent to browser
DEBUG - 2023-05-11 12:18:23 --> Total execution time: 0.1527
ERROR - 2023-05-11 12:18:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:18:24 --> Config Class Initialized
INFO - 2023-05-11 12:18:24 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:18:24 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:18:24 --> Utf8 Class Initialized
INFO - 2023-05-11 12:18:24 --> URI Class Initialized
INFO - 2023-05-11 12:18:24 --> Router Class Initialized
INFO - 2023-05-11 12:18:24 --> Output Class Initialized
INFO - 2023-05-11 12:18:24 --> Security Class Initialized
DEBUG - 2023-05-11 12:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:18:24 --> Input Class Initialized
INFO - 2023-05-11 12:18:24 --> Language Class Initialized
INFO - 2023-05-11 12:18:24 --> Loader Class Initialized
INFO - 2023-05-11 12:18:24 --> Helper loaded: url_helper
INFO - 2023-05-11 12:18:24 --> Helper loaded: file_helper
INFO - 2023-05-11 12:18:24 --> Helper loaded: html_helper
INFO - 2023-05-11 12:18:24 --> Helper loaded: text_helper
INFO - 2023-05-11 12:18:24 --> Helper loaded: form_helper
INFO - 2023-05-11 12:18:24 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:18:24 --> Helper loaded: security_helper
INFO - 2023-05-11 12:18:24 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:18:24 --> Database Driver Class Initialized
INFO - 2023-05-11 12:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:18:24 --> Parser Class Initialized
INFO - 2023-05-11 12:18:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:18:24 --> Pagination Class Initialized
INFO - 2023-05-11 12:18:24 --> Form Validation Class Initialized
INFO - 2023-05-11 12:18:24 --> Controller Class Initialized
INFO - 2023-05-11 12:18:24 --> Model Class Initialized
DEBUG - 2023-05-11 12:18:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:18:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:18:24 --> Model Class Initialized
DEBUG - 2023-05-11 12:18:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:18:24 --> Model Class Initialized
INFO - 2023-05-11 12:18:24 --> Final output sent to browser
DEBUG - 2023-05-11 12:18:24 --> Total execution time: 0.0543
ERROR - 2023-05-11 12:18:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:18:31 --> Config Class Initialized
INFO - 2023-05-11 12:18:31 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:18:31 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:18:31 --> Utf8 Class Initialized
INFO - 2023-05-11 12:18:31 --> URI Class Initialized
INFO - 2023-05-11 12:18:31 --> Router Class Initialized
INFO - 2023-05-11 12:18:31 --> Output Class Initialized
INFO - 2023-05-11 12:18:31 --> Security Class Initialized
DEBUG - 2023-05-11 12:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:18:31 --> Input Class Initialized
INFO - 2023-05-11 12:18:31 --> Language Class Initialized
INFO - 2023-05-11 12:18:31 --> Loader Class Initialized
INFO - 2023-05-11 12:18:31 --> Helper loaded: url_helper
INFO - 2023-05-11 12:18:31 --> Helper loaded: file_helper
INFO - 2023-05-11 12:18:31 --> Helper loaded: html_helper
INFO - 2023-05-11 12:18:31 --> Helper loaded: text_helper
INFO - 2023-05-11 12:18:31 --> Helper loaded: form_helper
INFO - 2023-05-11 12:18:31 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:18:31 --> Helper loaded: security_helper
INFO - 2023-05-11 12:18:31 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:18:31 --> Database Driver Class Initialized
INFO - 2023-05-11 12:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:18:31 --> Parser Class Initialized
INFO - 2023-05-11 12:18:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:18:31 --> Pagination Class Initialized
INFO - 2023-05-11 12:18:31 --> Form Validation Class Initialized
INFO - 2023-05-11 12:18:31 --> Controller Class Initialized
INFO - 2023-05-11 12:18:31 --> Model Class Initialized
DEBUG - 2023-05-11 12:18:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:18:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:18:31 --> Model Class Initialized
DEBUG - 2023-05-11 12:18:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:18:31 --> Model Class Initialized
INFO - 2023-05-11 12:18:31 --> Final output sent to browser
DEBUG - 2023-05-11 12:18:31 --> Total execution time: 0.1517
ERROR - 2023-05-11 12:19:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:19:12 --> Config Class Initialized
INFO - 2023-05-11 12:19:12 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:19:12 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:19:12 --> Utf8 Class Initialized
INFO - 2023-05-11 12:19:12 --> URI Class Initialized
INFO - 2023-05-11 12:19:12 --> Router Class Initialized
INFO - 2023-05-11 12:19:12 --> Output Class Initialized
INFO - 2023-05-11 12:19:12 --> Security Class Initialized
DEBUG - 2023-05-11 12:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:19:12 --> Input Class Initialized
INFO - 2023-05-11 12:19:12 --> Language Class Initialized
INFO - 2023-05-11 12:19:12 --> Loader Class Initialized
INFO - 2023-05-11 12:19:12 --> Helper loaded: url_helper
INFO - 2023-05-11 12:19:12 --> Helper loaded: file_helper
INFO - 2023-05-11 12:19:12 --> Helper loaded: html_helper
INFO - 2023-05-11 12:19:12 --> Helper loaded: text_helper
INFO - 2023-05-11 12:19:12 --> Helper loaded: form_helper
INFO - 2023-05-11 12:19:12 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:19:12 --> Helper loaded: security_helper
INFO - 2023-05-11 12:19:12 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:19:12 --> Database Driver Class Initialized
INFO - 2023-05-11 12:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:19:12 --> Parser Class Initialized
INFO - 2023-05-11 12:19:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:19:12 --> Pagination Class Initialized
INFO - 2023-05-11 12:19:12 --> Form Validation Class Initialized
INFO - 2023-05-11 12:19:12 --> Controller Class Initialized
INFO - 2023-05-11 12:19:12 --> Model Class Initialized
DEBUG - 2023-05-11 12:19:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:19:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:19:12 --> Model Class Initialized
DEBUG - 2023-05-11 12:19:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:19:12 --> Model Class Initialized
INFO - 2023-05-11 12:19:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-11 12:19:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:19:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 12:19:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 12:19:12 --> Model Class Initialized
INFO - 2023-05-11 12:19:12 --> Model Class Initialized
INFO - 2023-05-11 12:19:12 --> Model Class Initialized
INFO - 2023-05-11 12:19:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 12:19:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 12:19:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 12:19:12 --> Final output sent to browser
DEBUG - 2023-05-11 12:19:12 --> Total execution time: 0.1494
ERROR - 2023-05-11 12:19:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:19:12 --> Config Class Initialized
INFO - 2023-05-11 12:19:12 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:19:12 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:19:12 --> Utf8 Class Initialized
INFO - 2023-05-11 12:19:12 --> URI Class Initialized
INFO - 2023-05-11 12:19:12 --> Router Class Initialized
INFO - 2023-05-11 12:19:12 --> Output Class Initialized
INFO - 2023-05-11 12:19:12 --> Security Class Initialized
DEBUG - 2023-05-11 12:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:19:12 --> Input Class Initialized
INFO - 2023-05-11 12:19:12 --> Language Class Initialized
INFO - 2023-05-11 12:19:12 --> Loader Class Initialized
INFO - 2023-05-11 12:19:12 --> Helper loaded: url_helper
INFO - 2023-05-11 12:19:12 --> Helper loaded: file_helper
INFO - 2023-05-11 12:19:12 --> Helper loaded: html_helper
INFO - 2023-05-11 12:19:12 --> Helper loaded: text_helper
INFO - 2023-05-11 12:19:12 --> Helper loaded: form_helper
INFO - 2023-05-11 12:19:12 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:19:12 --> Helper loaded: security_helper
INFO - 2023-05-11 12:19:12 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:19:12 --> Database Driver Class Initialized
INFO - 2023-05-11 12:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:19:12 --> Parser Class Initialized
INFO - 2023-05-11 12:19:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:19:12 --> Pagination Class Initialized
INFO - 2023-05-11 12:19:12 --> Form Validation Class Initialized
INFO - 2023-05-11 12:19:12 --> Controller Class Initialized
INFO - 2023-05-11 12:19:13 --> Model Class Initialized
DEBUG - 2023-05-11 12:19:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:19:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:19:13 --> Model Class Initialized
DEBUG - 2023-05-11 12:19:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:19:13 --> Model Class Initialized
INFO - 2023-05-11 12:19:13 --> Final output sent to browser
DEBUG - 2023-05-11 12:19:13 --> Total execution time: 0.0651
ERROR - 2023-05-11 12:19:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:19:26 --> Config Class Initialized
INFO - 2023-05-11 12:19:26 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:19:26 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:19:26 --> Utf8 Class Initialized
INFO - 2023-05-11 12:19:26 --> URI Class Initialized
DEBUG - 2023-05-11 12:19:26 --> No URI present. Default controller set.
INFO - 2023-05-11 12:19:26 --> Router Class Initialized
INFO - 2023-05-11 12:19:26 --> Output Class Initialized
INFO - 2023-05-11 12:19:26 --> Security Class Initialized
DEBUG - 2023-05-11 12:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:19:26 --> Input Class Initialized
INFO - 2023-05-11 12:19:26 --> Language Class Initialized
INFO - 2023-05-11 12:19:26 --> Loader Class Initialized
INFO - 2023-05-11 12:19:26 --> Helper loaded: url_helper
INFO - 2023-05-11 12:19:26 --> Helper loaded: file_helper
INFO - 2023-05-11 12:19:26 --> Helper loaded: html_helper
INFO - 2023-05-11 12:19:26 --> Helper loaded: text_helper
INFO - 2023-05-11 12:19:26 --> Helper loaded: form_helper
INFO - 2023-05-11 12:19:26 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:19:26 --> Helper loaded: security_helper
INFO - 2023-05-11 12:19:26 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:19:26 --> Database Driver Class Initialized
INFO - 2023-05-11 12:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:19:26 --> Parser Class Initialized
INFO - 2023-05-11 12:19:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:19:26 --> Pagination Class Initialized
INFO - 2023-05-11 12:19:26 --> Form Validation Class Initialized
INFO - 2023-05-11 12:19:26 --> Controller Class Initialized
INFO - 2023-05-11 12:19:26 --> Model Class Initialized
DEBUG - 2023-05-11 12:19:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:19:26 --> Model Class Initialized
DEBUG - 2023-05-11 12:19:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:19:26 --> Model Class Initialized
INFO - 2023-05-11 12:19:26 --> Model Class Initialized
INFO - 2023-05-11 12:19:26 --> Model Class Initialized
INFO - 2023-05-11 12:19:26 --> Model Class Initialized
DEBUG - 2023-05-11 12:19:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:19:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:19:26 --> Model Class Initialized
INFO - 2023-05-11 12:19:26 --> Model Class Initialized
INFO - 2023-05-11 12:19:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-11 12:19:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:19:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 12:19:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 12:19:26 --> Model Class Initialized
INFO - 2023-05-11 12:19:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 12:19:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 12:19:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 12:19:26 --> Final output sent to browser
DEBUG - 2023-05-11 12:19:26 --> Total execution time: 0.1902
ERROR - 2023-05-11 12:19:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:19:35 --> Config Class Initialized
INFO - 2023-05-11 12:19:35 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:19:35 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:19:35 --> Utf8 Class Initialized
INFO - 2023-05-11 12:19:35 --> URI Class Initialized
INFO - 2023-05-11 12:19:35 --> Router Class Initialized
INFO - 2023-05-11 12:19:35 --> Output Class Initialized
INFO - 2023-05-11 12:19:35 --> Security Class Initialized
DEBUG - 2023-05-11 12:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:19:35 --> Input Class Initialized
INFO - 2023-05-11 12:19:35 --> Language Class Initialized
INFO - 2023-05-11 12:19:35 --> Loader Class Initialized
INFO - 2023-05-11 12:19:35 --> Helper loaded: url_helper
INFO - 2023-05-11 12:19:35 --> Helper loaded: file_helper
INFO - 2023-05-11 12:19:35 --> Helper loaded: html_helper
INFO - 2023-05-11 12:19:35 --> Helper loaded: text_helper
INFO - 2023-05-11 12:19:35 --> Helper loaded: form_helper
INFO - 2023-05-11 12:19:35 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:19:35 --> Helper loaded: security_helper
INFO - 2023-05-11 12:19:35 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:19:35 --> Database Driver Class Initialized
INFO - 2023-05-11 12:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:19:35 --> Parser Class Initialized
INFO - 2023-05-11 12:19:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:19:35 --> Pagination Class Initialized
INFO - 2023-05-11 12:19:35 --> Form Validation Class Initialized
INFO - 2023-05-11 12:19:35 --> Controller Class Initialized
INFO - 2023-05-11 12:19:35 --> Model Class Initialized
DEBUG - 2023-05-11 12:19:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:19:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:19:35 --> Model Class Initialized
DEBUG - 2023-05-11 12:19:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:19:35 --> Model Class Initialized
INFO - 2023-05-11 12:19:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-11 12:19:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:19:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 12:19:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 12:19:35 --> Model Class Initialized
INFO - 2023-05-11 12:19:35 --> Model Class Initialized
INFO - 2023-05-11 12:19:35 --> Model Class Initialized
INFO - 2023-05-11 12:19:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 12:19:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 12:19:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 12:19:35 --> Final output sent to browser
DEBUG - 2023-05-11 12:19:35 --> Total execution time: 0.1330
ERROR - 2023-05-11 12:19:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:19:35 --> Config Class Initialized
INFO - 2023-05-11 12:19:35 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:19:35 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:19:35 --> Utf8 Class Initialized
INFO - 2023-05-11 12:19:35 --> URI Class Initialized
INFO - 2023-05-11 12:19:35 --> Router Class Initialized
INFO - 2023-05-11 12:19:35 --> Output Class Initialized
INFO - 2023-05-11 12:19:35 --> Security Class Initialized
DEBUG - 2023-05-11 12:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:19:35 --> Input Class Initialized
INFO - 2023-05-11 12:19:35 --> Language Class Initialized
INFO - 2023-05-11 12:19:35 --> Loader Class Initialized
INFO - 2023-05-11 12:19:35 --> Helper loaded: url_helper
INFO - 2023-05-11 12:19:35 --> Helper loaded: file_helper
INFO - 2023-05-11 12:19:35 --> Helper loaded: html_helper
INFO - 2023-05-11 12:19:35 --> Helper loaded: text_helper
INFO - 2023-05-11 12:19:35 --> Helper loaded: form_helper
INFO - 2023-05-11 12:19:35 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:19:35 --> Helper loaded: security_helper
INFO - 2023-05-11 12:19:35 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:19:35 --> Database Driver Class Initialized
INFO - 2023-05-11 12:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:19:35 --> Parser Class Initialized
INFO - 2023-05-11 12:19:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:19:35 --> Pagination Class Initialized
INFO - 2023-05-11 12:19:35 --> Form Validation Class Initialized
INFO - 2023-05-11 12:19:35 --> Controller Class Initialized
INFO - 2023-05-11 12:19:35 --> Model Class Initialized
DEBUG - 2023-05-11 12:19:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:19:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:19:35 --> Model Class Initialized
DEBUG - 2023-05-11 12:19:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:19:35 --> Model Class Initialized
INFO - 2023-05-11 12:19:35 --> Final output sent to browser
DEBUG - 2023-05-11 12:19:35 --> Total execution time: 0.0568
ERROR - 2023-05-11 12:19:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:19:41 --> Config Class Initialized
INFO - 2023-05-11 12:19:41 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:19:41 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:19:41 --> Utf8 Class Initialized
INFO - 2023-05-11 12:19:41 --> URI Class Initialized
DEBUG - 2023-05-11 12:19:41 --> No URI present. Default controller set.
INFO - 2023-05-11 12:19:41 --> Router Class Initialized
INFO - 2023-05-11 12:19:41 --> Output Class Initialized
INFO - 2023-05-11 12:19:41 --> Security Class Initialized
DEBUG - 2023-05-11 12:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:19:41 --> Input Class Initialized
INFO - 2023-05-11 12:19:41 --> Language Class Initialized
INFO - 2023-05-11 12:19:41 --> Loader Class Initialized
INFO - 2023-05-11 12:19:41 --> Helper loaded: url_helper
INFO - 2023-05-11 12:19:41 --> Helper loaded: file_helper
INFO - 2023-05-11 12:19:41 --> Helper loaded: html_helper
INFO - 2023-05-11 12:19:41 --> Helper loaded: text_helper
INFO - 2023-05-11 12:19:41 --> Helper loaded: form_helper
INFO - 2023-05-11 12:19:41 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:19:41 --> Helper loaded: security_helper
INFO - 2023-05-11 12:19:41 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:19:41 --> Database Driver Class Initialized
INFO - 2023-05-11 12:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:19:41 --> Parser Class Initialized
INFO - 2023-05-11 12:19:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:19:41 --> Pagination Class Initialized
INFO - 2023-05-11 12:19:41 --> Form Validation Class Initialized
INFO - 2023-05-11 12:19:41 --> Controller Class Initialized
INFO - 2023-05-11 12:19:41 --> Model Class Initialized
DEBUG - 2023-05-11 12:19:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:19:41 --> Model Class Initialized
DEBUG - 2023-05-11 12:19:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:19:41 --> Model Class Initialized
INFO - 2023-05-11 12:19:41 --> Model Class Initialized
INFO - 2023-05-11 12:19:41 --> Model Class Initialized
INFO - 2023-05-11 12:19:41 --> Model Class Initialized
DEBUG - 2023-05-11 12:19:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:19:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:19:41 --> Model Class Initialized
INFO - 2023-05-11 12:19:41 --> Model Class Initialized
INFO - 2023-05-11 12:19:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-11 12:19:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:19:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 12:19:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 12:19:41 --> Model Class Initialized
INFO - 2023-05-11 12:19:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 12:19:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 12:19:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 12:19:41 --> Final output sent to browser
DEBUG - 2023-05-11 12:19:41 --> Total execution time: 0.1940
ERROR - 2023-05-11 12:20:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:20:50 --> Config Class Initialized
INFO - 2023-05-11 12:20:50 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:20:50 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:20:50 --> Utf8 Class Initialized
INFO - 2023-05-11 12:20:50 --> URI Class Initialized
INFO - 2023-05-11 12:20:50 --> Router Class Initialized
INFO - 2023-05-11 12:20:50 --> Output Class Initialized
INFO - 2023-05-11 12:20:50 --> Security Class Initialized
DEBUG - 2023-05-11 12:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:20:50 --> Input Class Initialized
INFO - 2023-05-11 12:20:50 --> Language Class Initialized
INFO - 2023-05-11 12:20:50 --> Loader Class Initialized
INFO - 2023-05-11 12:20:50 --> Helper loaded: url_helper
INFO - 2023-05-11 12:20:50 --> Helper loaded: file_helper
INFO - 2023-05-11 12:20:50 --> Helper loaded: html_helper
INFO - 2023-05-11 12:20:50 --> Helper loaded: text_helper
INFO - 2023-05-11 12:20:50 --> Helper loaded: form_helper
INFO - 2023-05-11 12:20:50 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:20:50 --> Helper loaded: security_helper
INFO - 2023-05-11 12:20:50 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:20:50 --> Database Driver Class Initialized
INFO - 2023-05-11 12:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:20:50 --> Parser Class Initialized
INFO - 2023-05-11 12:20:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:20:50 --> Pagination Class Initialized
INFO - 2023-05-11 12:20:50 --> Form Validation Class Initialized
INFO - 2023-05-11 12:20:50 --> Controller Class Initialized
INFO - 2023-05-11 12:20:50 --> Model Class Initialized
DEBUG - 2023-05-11 12:20:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:20:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:20:50 --> Model Class Initialized
DEBUG - 2023-05-11 12:20:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:20:50 --> Model Class Initialized
INFO - 2023-05-11 12:20:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-11 12:20:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:20:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 12:20:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 12:20:50 --> Model Class Initialized
INFO - 2023-05-11 12:20:50 --> Model Class Initialized
INFO - 2023-05-11 12:20:50 --> Model Class Initialized
INFO - 2023-05-11 12:20:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 12:20:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 12:20:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 12:20:50 --> Final output sent to browser
DEBUG - 2023-05-11 12:20:50 --> Total execution time: 0.1638
ERROR - 2023-05-11 12:20:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:20:51 --> Config Class Initialized
INFO - 2023-05-11 12:20:51 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:20:51 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:20:51 --> Utf8 Class Initialized
INFO - 2023-05-11 12:20:51 --> URI Class Initialized
INFO - 2023-05-11 12:20:51 --> Router Class Initialized
INFO - 2023-05-11 12:20:51 --> Output Class Initialized
INFO - 2023-05-11 12:20:51 --> Security Class Initialized
DEBUG - 2023-05-11 12:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:20:51 --> Input Class Initialized
INFO - 2023-05-11 12:20:51 --> Language Class Initialized
INFO - 2023-05-11 12:20:51 --> Loader Class Initialized
INFO - 2023-05-11 12:20:51 --> Helper loaded: url_helper
INFO - 2023-05-11 12:20:51 --> Helper loaded: file_helper
INFO - 2023-05-11 12:20:51 --> Helper loaded: html_helper
INFO - 2023-05-11 12:20:51 --> Helper loaded: text_helper
INFO - 2023-05-11 12:20:51 --> Helper loaded: form_helper
INFO - 2023-05-11 12:20:51 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:20:51 --> Helper loaded: security_helper
INFO - 2023-05-11 12:20:51 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:20:51 --> Database Driver Class Initialized
INFO - 2023-05-11 12:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:20:51 --> Parser Class Initialized
INFO - 2023-05-11 12:20:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:20:51 --> Pagination Class Initialized
INFO - 2023-05-11 12:20:51 --> Form Validation Class Initialized
INFO - 2023-05-11 12:20:51 --> Controller Class Initialized
INFO - 2023-05-11 12:20:51 --> Model Class Initialized
DEBUG - 2023-05-11 12:20:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:20:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:20:51 --> Model Class Initialized
DEBUG - 2023-05-11 12:20:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:20:51 --> Model Class Initialized
INFO - 2023-05-11 12:20:51 --> Final output sent to browser
DEBUG - 2023-05-11 12:20:51 --> Total execution time: 0.0546
ERROR - 2023-05-11 12:20:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:20:56 --> Config Class Initialized
INFO - 2023-05-11 12:20:56 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:20:56 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:20:56 --> Utf8 Class Initialized
INFO - 2023-05-11 12:20:56 --> URI Class Initialized
INFO - 2023-05-11 12:20:56 --> Router Class Initialized
INFO - 2023-05-11 12:20:56 --> Output Class Initialized
INFO - 2023-05-11 12:20:56 --> Security Class Initialized
DEBUG - 2023-05-11 12:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:20:56 --> Input Class Initialized
INFO - 2023-05-11 12:20:56 --> Language Class Initialized
INFO - 2023-05-11 12:20:56 --> Loader Class Initialized
INFO - 2023-05-11 12:20:56 --> Helper loaded: url_helper
INFO - 2023-05-11 12:20:56 --> Helper loaded: file_helper
INFO - 2023-05-11 12:20:56 --> Helper loaded: html_helper
INFO - 2023-05-11 12:20:56 --> Helper loaded: text_helper
INFO - 2023-05-11 12:20:56 --> Helper loaded: form_helper
INFO - 2023-05-11 12:20:56 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:20:56 --> Helper loaded: security_helper
INFO - 2023-05-11 12:20:56 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:20:56 --> Database Driver Class Initialized
INFO - 2023-05-11 12:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:20:56 --> Parser Class Initialized
INFO - 2023-05-11 12:20:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:20:56 --> Pagination Class Initialized
INFO - 2023-05-11 12:20:56 --> Form Validation Class Initialized
INFO - 2023-05-11 12:20:56 --> Controller Class Initialized
INFO - 2023-05-11 12:20:56 --> Model Class Initialized
DEBUG - 2023-05-11 12:20:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:20:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:20:56 --> Model Class Initialized
DEBUG - 2023-05-11 12:20:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:20:56 --> Model Class Initialized
INFO - 2023-05-11 12:20:56 --> Final output sent to browser
DEBUG - 2023-05-11 12:20:56 --> Total execution time: 0.1405
ERROR - 2023-05-11 12:21:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:21:03 --> Config Class Initialized
INFO - 2023-05-11 12:21:03 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:21:03 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:21:03 --> Utf8 Class Initialized
INFO - 2023-05-11 12:21:03 --> URI Class Initialized
DEBUG - 2023-05-11 12:21:03 --> No URI present. Default controller set.
INFO - 2023-05-11 12:21:03 --> Router Class Initialized
INFO - 2023-05-11 12:21:03 --> Output Class Initialized
INFO - 2023-05-11 12:21:03 --> Security Class Initialized
DEBUG - 2023-05-11 12:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:21:03 --> Input Class Initialized
INFO - 2023-05-11 12:21:03 --> Language Class Initialized
INFO - 2023-05-11 12:21:03 --> Loader Class Initialized
INFO - 2023-05-11 12:21:03 --> Helper loaded: url_helper
INFO - 2023-05-11 12:21:03 --> Helper loaded: file_helper
INFO - 2023-05-11 12:21:03 --> Helper loaded: html_helper
INFO - 2023-05-11 12:21:03 --> Helper loaded: text_helper
INFO - 2023-05-11 12:21:03 --> Helper loaded: form_helper
INFO - 2023-05-11 12:21:03 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:21:03 --> Helper loaded: security_helper
INFO - 2023-05-11 12:21:03 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:21:03 --> Database Driver Class Initialized
INFO - 2023-05-11 12:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:21:03 --> Parser Class Initialized
INFO - 2023-05-11 12:21:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:21:03 --> Pagination Class Initialized
INFO - 2023-05-11 12:21:03 --> Form Validation Class Initialized
INFO - 2023-05-11 12:21:03 --> Controller Class Initialized
INFO - 2023-05-11 12:21:03 --> Model Class Initialized
DEBUG - 2023-05-11 12:21:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:21:03 --> Model Class Initialized
DEBUG - 2023-05-11 12:21:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:21:03 --> Model Class Initialized
INFO - 2023-05-11 12:21:03 --> Model Class Initialized
INFO - 2023-05-11 12:21:03 --> Model Class Initialized
INFO - 2023-05-11 12:21:03 --> Model Class Initialized
DEBUG - 2023-05-11 12:21:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:21:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:21:03 --> Model Class Initialized
INFO - 2023-05-11 12:21:03 --> Model Class Initialized
INFO - 2023-05-11 12:21:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-11 12:21:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:21:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 12:21:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 12:21:03 --> Model Class Initialized
INFO - 2023-05-11 12:21:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 12:21:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 12:21:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 12:21:03 --> Final output sent to browser
DEBUG - 2023-05-11 12:21:03 --> Total execution time: 0.2221
ERROR - 2023-05-11 12:21:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:21:17 --> Config Class Initialized
INFO - 2023-05-11 12:21:17 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:21:17 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:21:17 --> Utf8 Class Initialized
INFO - 2023-05-11 12:21:17 --> URI Class Initialized
INFO - 2023-05-11 12:21:17 --> Router Class Initialized
INFO - 2023-05-11 12:21:17 --> Output Class Initialized
INFO - 2023-05-11 12:21:17 --> Security Class Initialized
DEBUG - 2023-05-11 12:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:21:17 --> Input Class Initialized
INFO - 2023-05-11 12:21:17 --> Language Class Initialized
INFO - 2023-05-11 12:21:17 --> Loader Class Initialized
INFO - 2023-05-11 12:21:17 --> Helper loaded: url_helper
INFO - 2023-05-11 12:21:17 --> Helper loaded: file_helper
INFO - 2023-05-11 12:21:17 --> Helper loaded: html_helper
INFO - 2023-05-11 12:21:17 --> Helper loaded: text_helper
INFO - 2023-05-11 12:21:17 --> Helper loaded: form_helper
INFO - 2023-05-11 12:21:17 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:21:17 --> Helper loaded: security_helper
INFO - 2023-05-11 12:21:17 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:21:17 --> Database Driver Class Initialized
INFO - 2023-05-11 12:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:21:17 --> Parser Class Initialized
INFO - 2023-05-11 12:21:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:21:17 --> Pagination Class Initialized
INFO - 2023-05-11 12:21:17 --> Form Validation Class Initialized
INFO - 2023-05-11 12:21:17 --> Controller Class Initialized
INFO - 2023-05-11 12:21:17 --> Model Class Initialized
DEBUG - 2023-05-11 12:21:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:21:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:21:17 --> Model Class Initialized
DEBUG - 2023-05-11 12:21:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:21:17 --> Model Class Initialized
INFO - 2023-05-11 12:21:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-05-11 12:21:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:21:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 12:21:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 12:21:17 --> Model Class Initialized
INFO - 2023-05-11 12:21:17 --> Model Class Initialized
INFO - 2023-05-11 12:21:17 --> Model Class Initialized
INFO - 2023-05-11 12:21:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 12:21:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 12:21:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 12:21:17 --> Final output sent to browser
DEBUG - 2023-05-11 12:21:17 --> Total execution time: 0.1580
ERROR - 2023-05-11 12:21:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:21:18 --> Config Class Initialized
INFO - 2023-05-11 12:21:18 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:21:18 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:21:18 --> Utf8 Class Initialized
INFO - 2023-05-11 12:21:18 --> URI Class Initialized
INFO - 2023-05-11 12:21:18 --> Router Class Initialized
INFO - 2023-05-11 12:21:18 --> Output Class Initialized
INFO - 2023-05-11 12:21:18 --> Security Class Initialized
DEBUG - 2023-05-11 12:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:21:18 --> Input Class Initialized
INFO - 2023-05-11 12:21:18 --> Language Class Initialized
INFO - 2023-05-11 12:21:18 --> Loader Class Initialized
INFO - 2023-05-11 12:21:18 --> Helper loaded: url_helper
INFO - 2023-05-11 12:21:18 --> Helper loaded: file_helper
INFO - 2023-05-11 12:21:18 --> Helper loaded: html_helper
INFO - 2023-05-11 12:21:18 --> Helper loaded: text_helper
INFO - 2023-05-11 12:21:18 --> Helper loaded: form_helper
INFO - 2023-05-11 12:21:18 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:21:18 --> Helper loaded: security_helper
INFO - 2023-05-11 12:21:18 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:21:18 --> Database Driver Class Initialized
INFO - 2023-05-11 12:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:21:18 --> Parser Class Initialized
INFO - 2023-05-11 12:21:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:21:18 --> Pagination Class Initialized
INFO - 2023-05-11 12:21:18 --> Form Validation Class Initialized
INFO - 2023-05-11 12:21:18 --> Controller Class Initialized
INFO - 2023-05-11 12:21:18 --> Model Class Initialized
DEBUG - 2023-05-11 12:21:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:21:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:21:18 --> Model Class Initialized
DEBUG - 2023-05-11 12:21:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:21:18 --> Model Class Initialized
INFO - 2023-05-11 12:21:18 --> Final output sent to browser
DEBUG - 2023-05-11 12:21:18 --> Total execution time: 0.0520
ERROR - 2023-05-11 12:21:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:21:24 --> Config Class Initialized
INFO - 2023-05-11 12:21:24 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:21:24 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:21:24 --> Utf8 Class Initialized
INFO - 2023-05-11 12:21:24 --> URI Class Initialized
INFO - 2023-05-11 12:21:24 --> Router Class Initialized
INFO - 2023-05-11 12:21:24 --> Output Class Initialized
INFO - 2023-05-11 12:21:24 --> Security Class Initialized
DEBUG - 2023-05-11 12:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:21:24 --> Input Class Initialized
INFO - 2023-05-11 12:21:24 --> Language Class Initialized
INFO - 2023-05-11 12:21:24 --> Loader Class Initialized
INFO - 2023-05-11 12:21:24 --> Helper loaded: url_helper
INFO - 2023-05-11 12:21:24 --> Helper loaded: file_helper
INFO - 2023-05-11 12:21:24 --> Helper loaded: html_helper
INFO - 2023-05-11 12:21:24 --> Helper loaded: text_helper
INFO - 2023-05-11 12:21:24 --> Helper loaded: form_helper
INFO - 2023-05-11 12:21:24 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:21:24 --> Helper loaded: security_helper
INFO - 2023-05-11 12:21:24 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:21:24 --> Database Driver Class Initialized
INFO - 2023-05-11 12:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:21:24 --> Parser Class Initialized
INFO - 2023-05-11 12:21:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:21:24 --> Pagination Class Initialized
INFO - 2023-05-11 12:21:24 --> Form Validation Class Initialized
INFO - 2023-05-11 12:21:24 --> Controller Class Initialized
INFO - 2023-05-11 12:21:24 --> Model Class Initialized
DEBUG - 2023-05-11 12:21:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:21:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:21:24 --> Model Class Initialized
DEBUG - 2023-05-11 12:21:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:21:24 --> Model Class Initialized
INFO - 2023-05-11 12:21:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-05-11 12:21:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:21:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 12:21:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 12:21:24 --> Model Class Initialized
INFO - 2023-05-11 12:21:24 --> Model Class Initialized
INFO - 2023-05-11 12:21:24 --> Model Class Initialized
INFO - 2023-05-11 12:21:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 12:21:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 12:21:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 12:21:24 --> Final output sent to browser
DEBUG - 2023-05-11 12:21:24 --> Total execution time: 0.1652
ERROR - 2023-05-11 12:21:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:21:25 --> Config Class Initialized
INFO - 2023-05-11 12:21:25 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:21:25 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:21:25 --> Utf8 Class Initialized
INFO - 2023-05-11 12:21:25 --> URI Class Initialized
INFO - 2023-05-11 12:21:25 --> Router Class Initialized
INFO - 2023-05-11 12:21:25 --> Output Class Initialized
INFO - 2023-05-11 12:21:25 --> Security Class Initialized
DEBUG - 2023-05-11 12:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:21:25 --> Input Class Initialized
INFO - 2023-05-11 12:21:25 --> Language Class Initialized
INFO - 2023-05-11 12:21:25 --> Loader Class Initialized
INFO - 2023-05-11 12:21:25 --> Helper loaded: url_helper
INFO - 2023-05-11 12:21:25 --> Helper loaded: file_helper
INFO - 2023-05-11 12:21:25 --> Helper loaded: html_helper
INFO - 2023-05-11 12:21:25 --> Helper loaded: text_helper
INFO - 2023-05-11 12:21:25 --> Helper loaded: form_helper
INFO - 2023-05-11 12:21:25 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:21:25 --> Helper loaded: security_helper
INFO - 2023-05-11 12:21:25 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:21:25 --> Database Driver Class Initialized
INFO - 2023-05-11 12:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:21:25 --> Parser Class Initialized
INFO - 2023-05-11 12:21:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:21:25 --> Pagination Class Initialized
INFO - 2023-05-11 12:21:25 --> Form Validation Class Initialized
INFO - 2023-05-11 12:21:25 --> Controller Class Initialized
INFO - 2023-05-11 12:21:25 --> Model Class Initialized
DEBUG - 2023-05-11 12:21:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:21:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:21:25 --> Model Class Initialized
DEBUG - 2023-05-11 12:21:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:21:25 --> Model Class Initialized
INFO - 2023-05-11 12:21:25 --> Final output sent to browser
DEBUG - 2023-05-11 12:21:25 --> Total execution time: 0.0571
ERROR - 2023-05-11 12:21:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:21:29 --> Config Class Initialized
INFO - 2023-05-11 12:21:29 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:21:29 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:21:29 --> Utf8 Class Initialized
INFO - 2023-05-11 12:21:29 --> URI Class Initialized
INFO - 2023-05-11 12:21:29 --> Router Class Initialized
INFO - 2023-05-11 12:21:29 --> Output Class Initialized
INFO - 2023-05-11 12:21:29 --> Security Class Initialized
DEBUG - 2023-05-11 12:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:21:29 --> Input Class Initialized
INFO - 2023-05-11 12:21:29 --> Language Class Initialized
INFO - 2023-05-11 12:21:29 --> Loader Class Initialized
INFO - 2023-05-11 12:21:29 --> Helper loaded: url_helper
INFO - 2023-05-11 12:21:29 --> Helper loaded: file_helper
INFO - 2023-05-11 12:21:29 --> Helper loaded: html_helper
INFO - 2023-05-11 12:21:29 --> Helper loaded: text_helper
INFO - 2023-05-11 12:21:29 --> Helper loaded: form_helper
INFO - 2023-05-11 12:21:29 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:21:29 --> Helper loaded: security_helper
INFO - 2023-05-11 12:21:29 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:21:29 --> Database Driver Class Initialized
INFO - 2023-05-11 12:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:21:29 --> Parser Class Initialized
INFO - 2023-05-11 12:21:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:21:29 --> Pagination Class Initialized
INFO - 2023-05-11 12:21:29 --> Form Validation Class Initialized
INFO - 2023-05-11 12:21:29 --> Controller Class Initialized
INFO - 2023-05-11 12:21:29 --> Model Class Initialized
DEBUG - 2023-05-11 12:21:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:21:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:21:29 --> Model Class Initialized
DEBUG - 2023-05-11 12:21:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:21:29 --> Model Class Initialized
INFO - 2023-05-11 12:21:29 --> Final output sent to browser
DEBUG - 2023-05-11 12:21:29 --> Total execution time: 0.0526
ERROR - 2023-05-11 12:21:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:21:33 --> Config Class Initialized
INFO - 2023-05-11 12:21:33 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:21:33 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:21:33 --> Utf8 Class Initialized
INFO - 2023-05-11 12:21:33 --> URI Class Initialized
INFO - 2023-05-11 12:21:33 --> Router Class Initialized
INFO - 2023-05-11 12:21:33 --> Output Class Initialized
INFO - 2023-05-11 12:21:33 --> Security Class Initialized
DEBUG - 2023-05-11 12:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:21:33 --> Input Class Initialized
INFO - 2023-05-11 12:21:33 --> Language Class Initialized
INFO - 2023-05-11 12:21:33 --> Loader Class Initialized
INFO - 2023-05-11 12:21:33 --> Helper loaded: url_helper
INFO - 2023-05-11 12:21:33 --> Helper loaded: file_helper
INFO - 2023-05-11 12:21:33 --> Helper loaded: html_helper
INFO - 2023-05-11 12:21:33 --> Helper loaded: text_helper
INFO - 2023-05-11 12:21:33 --> Helper loaded: form_helper
INFO - 2023-05-11 12:21:33 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:21:33 --> Helper loaded: security_helper
INFO - 2023-05-11 12:21:33 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:21:33 --> Database Driver Class Initialized
INFO - 2023-05-11 12:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:21:33 --> Parser Class Initialized
INFO - 2023-05-11 12:21:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:21:33 --> Pagination Class Initialized
INFO - 2023-05-11 12:21:33 --> Form Validation Class Initialized
INFO - 2023-05-11 12:21:33 --> Controller Class Initialized
INFO - 2023-05-11 12:21:33 --> Model Class Initialized
DEBUG - 2023-05-11 12:21:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:21:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:21:33 --> Model Class Initialized
DEBUG - 2023-05-11 12:21:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:21:33 --> Model Class Initialized
INFO - 2023-05-11 12:21:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-05-11 12:21:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:21:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 12:21:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 12:21:33 --> Model Class Initialized
INFO - 2023-05-11 12:21:33 --> Model Class Initialized
INFO - 2023-05-11 12:21:33 --> Model Class Initialized
INFO - 2023-05-11 12:21:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 12:21:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 12:21:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 12:21:34 --> Final output sent to browser
DEBUG - 2023-05-11 12:21:34 --> Total execution time: 0.1642
ERROR - 2023-05-11 12:21:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:21:34 --> Config Class Initialized
INFO - 2023-05-11 12:21:34 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:21:34 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:21:34 --> Utf8 Class Initialized
INFO - 2023-05-11 12:21:34 --> URI Class Initialized
INFO - 2023-05-11 12:21:34 --> Router Class Initialized
INFO - 2023-05-11 12:21:34 --> Output Class Initialized
INFO - 2023-05-11 12:21:34 --> Security Class Initialized
DEBUG - 2023-05-11 12:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:21:34 --> Input Class Initialized
INFO - 2023-05-11 12:21:34 --> Language Class Initialized
INFO - 2023-05-11 12:21:34 --> Loader Class Initialized
INFO - 2023-05-11 12:21:34 --> Helper loaded: url_helper
INFO - 2023-05-11 12:21:34 --> Helper loaded: file_helper
INFO - 2023-05-11 12:21:34 --> Helper loaded: html_helper
INFO - 2023-05-11 12:21:34 --> Helper loaded: text_helper
INFO - 2023-05-11 12:21:34 --> Helper loaded: form_helper
INFO - 2023-05-11 12:21:34 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:21:34 --> Helper loaded: security_helper
INFO - 2023-05-11 12:21:34 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:21:34 --> Database Driver Class Initialized
INFO - 2023-05-11 12:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:21:34 --> Parser Class Initialized
INFO - 2023-05-11 12:21:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:21:34 --> Pagination Class Initialized
INFO - 2023-05-11 12:21:34 --> Form Validation Class Initialized
INFO - 2023-05-11 12:21:34 --> Controller Class Initialized
INFO - 2023-05-11 12:21:34 --> Model Class Initialized
DEBUG - 2023-05-11 12:21:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:21:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:21:34 --> Model Class Initialized
DEBUG - 2023-05-11 12:21:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:21:34 --> Model Class Initialized
INFO - 2023-05-11 12:21:34 --> Final output sent to browser
DEBUG - 2023-05-11 12:21:34 --> Total execution time: 0.0483
ERROR - 2023-05-11 12:27:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:27:27 --> Config Class Initialized
INFO - 2023-05-11 12:27:27 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:27:27 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:27:27 --> Utf8 Class Initialized
INFO - 2023-05-11 12:27:27 --> URI Class Initialized
INFO - 2023-05-11 12:27:27 --> Router Class Initialized
INFO - 2023-05-11 12:27:27 --> Output Class Initialized
INFO - 2023-05-11 12:27:27 --> Security Class Initialized
DEBUG - 2023-05-11 12:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:27:27 --> Input Class Initialized
INFO - 2023-05-11 12:27:27 --> Language Class Initialized
INFO - 2023-05-11 12:27:27 --> Loader Class Initialized
INFO - 2023-05-11 12:27:27 --> Helper loaded: url_helper
INFO - 2023-05-11 12:27:27 --> Helper loaded: file_helper
INFO - 2023-05-11 12:27:27 --> Helper loaded: html_helper
INFO - 2023-05-11 12:27:27 --> Helper loaded: text_helper
INFO - 2023-05-11 12:27:27 --> Helper loaded: form_helper
INFO - 2023-05-11 12:27:27 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:27:27 --> Helper loaded: security_helper
INFO - 2023-05-11 12:27:27 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:27:27 --> Database Driver Class Initialized
INFO - 2023-05-11 12:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:27:27 --> Parser Class Initialized
INFO - 2023-05-11 12:27:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:27:27 --> Pagination Class Initialized
INFO - 2023-05-11 12:27:27 --> Form Validation Class Initialized
INFO - 2023-05-11 12:27:27 --> Controller Class Initialized
INFO - 2023-05-11 12:27:27 --> Model Class Initialized
DEBUG - 2023-05-11 12:27:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:27:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:27:27 --> Model Class Initialized
DEBUG - 2023-05-11 12:27:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:27:27 --> Model Class Initialized
INFO - 2023-05-11 12:27:27 --> Final output sent to browser
DEBUG - 2023-05-11 12:27:27 --> Total execution time: 0.0590
ERROR - 2023-05-11 12:27:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:27:31 --> Config Class Initialized
INFO - 2023-05-11 12:27:31 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:27:31 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:27:31 --> Utf8 Class Initialized
INFO - 2023-05-11 12:27:31 --> URI Class Initialized
DEBUG - 2023-05-11 12:27:31 --> No URI present. Default controller set.
INFO - 2023-05-11 12:27:31 --> Router Class Initialized
INFO - 2023-05-11 12:27:31 --> Output Class Initialized
INFO - 2023-05-11 12:27:31 --> Security Class Initialized
DEBUG - 2023-05-11 12:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:27:31 --> Input Class Initialized
INFO - 2023-05-11 12:27:31 --> Language Class Initialized
INFO - 2023-05-11 12:27:31 --> Loader Class Initialized
INFO - 2023-05-11 12:27:31 --> Helper loaded: url_helper
INFO - 2023-05-11 12:27:31 --> Helper loaded: file_helper
INFO - 2023-05-11 12:27:31 --> Helper loaded: html_helper
INFO - 2023-05-11 12:27:31 --> Helper loaded: text_helper
INFO - 2023-05-11 12:27:31 --> Helper loaded: form_helper
INFO - 2023-05-11 12:27:31 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:27:31 --> Helper loaded: security_helper
INFO - 2023-05-11 12:27:31 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:27:31 --> Database Driver Class Initialized
INFO - 2023-05-11 12:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:27:31 --> Parser Class Initialized
INFO - 2023-05-11 12:27:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:27:31 --> Pagination Class Initialized
INFO - 2023-05-11 12:27:31 --> Form Validation Class Initialized
INFO - 2023-05-11 12:27:31 --> Controller Class Initialized
INFO - 2023-05-11 12:27:31 --> Model Class Initialized
DEBUG - 2023-05-11 12:27:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:27:31 --> Model Class Initialized
DEBUG - 2023-05-11 12:27:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:27:31 --> Model Class Initialized
INFO - 2023-05-11 12:27:31 --> Model Class Initialized
INFO - 2023-05-11 12:27:31 --> Model Class Initialized
INFO - 2023-05-11 12:27:31 --> Model Class Initialized
DEBUG - 2023-05-11 12:27:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:27:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:27:31 --> Model Class Initialized
INFO - 2023-05-11 12:27:31 --> Model Class Initialized
INFO - 2023-05-11 12:27:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-11 12:27:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:27:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 12:27:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 12:27:31 --> Model Class Initialized
INFO - 2023-05-11 12:27:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 12:27:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 12:27:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 12:27:32 --> Final output sent to browser
DEBUG - 2023-05-11 12:27:32 --> Total execution time: 0.2297
ERROR - 2023-05-11 12:27:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:27:40 --> Config Class Initialized
INFO - 2023-05-11 12:27:40 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:27:40 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:27:40 --> Utf8 Class Initialized
INFO - 2023-05-11 12:27:40 --> URI Class Initialized
INFO - 2023-05-11 12:27:40 --> Router Class Initialized
INFO - 2023-05-11 12:27:40 --> Output Class Initialized
INFO - 2023-05-11 12:27:40 --> Security Class Initialized
DEBUG - 2023-05-11 12:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:27:40 --> Input Class Initialized
INFO - 2023-05-11 12:27:40 --> Language Class Initialized
INFO - 2023-05-11 12:27:40 --> Loader Class Initialized
INFO - 2023-05-11 12:27:40 --> Helper loaded: url_helper
INFO - 2023-05-11 12:27:40 --> Helper loaded: file_helper
INFO - 2023-05-11 12:27:40 --> Helper loaded: html_helper
INFO - 2023-05-11 12:27:40 --> Helper loaded: text_helper
INFO - 2023-05-11 12:27:40 --> Helper loaded: form_helper
INFO - 2023-05-11 12:27:40 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:27:40 --> Helper loaded: security_helper
INFO - 2023-05-11 12:27:40 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:27:40 --> Database Driver Class Initialized
INFO - 2023-05-11 12:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:27:40 --> Parser Class Initialized
INFO - 2023-05-11 12:27:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:27:40 --> Pagination Class Initialized
INFO - 2023-05-11 12:27:40 --> Form Validation Class Initialized
INFO - 2023-05-11 12:27:40 --> Controller Class Initialized
INFO - 2023-05-11 12:27:40 --> Model Class Initialized
DEBUG - 2023-05-11 12:27:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:27:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:27:40 --> Model Class Initialized
DEBUG - 2023-05-11 12:27:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:27:40 --> Model Class Initialized
INFO - 2023-05-11 12:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-11 12:27:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 12:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 12:27:40 --> Model Class Initialized
INFO - 2023-05-11 12:27:40 --> Model Class Initialized
INFO - 2023-05-11 12:27:40 --> Model Class Initialized
INFO - 2023-05-11 12:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 12:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 12:27:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 12:27:40 --> Final output sent to browser
DEBUG - 2023-05-11 12:27:40 --> Total execution time: 0.1807
ERROR - 2023-05-11 12:27:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:27:41 --> Config Class Initialized
INFO - 2023-05-11 12:27:41 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:27:41 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:27:41 --> Utf8 Class Initialized
INFO - 2023-05-11 12:27:41 --> URI Class Initialized
INFO - 2023-05-11 12:27:41 --> Router Class Initialized
INFO - 2023-05-11 12:27:41 --> Output Class Initialized
INFO - 2023-05-11 12:27:41 --> Security Class Initialized
DEBUG - 2023-05-11 12:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:27:41 --> Input Class Initialized
INFO - 2023-05-11 12:27:41 --> Language Class Initialized
INFO - 2023-05-11 12:27:41 --> Loader Class Initialized
INFO - 2023-05-11 12:27:41 --> Helper loaded: url_helper
INFO - 2023-05-11 12:27:41 --> Helper loaded: file_helper
INFO - 2023-05-11 12:27:41 --> Helper loaded: html_helper
INFO - 2023-05-11 12:27:41 --> Helper loaded: text_helper
INFO - 2023-05-11 12:27:41 --> Helper loaded: form_helper
INFO - 2023-05-11 12:27:41 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:27:41 --> Helper loaded: security_helper
INFO - 2023-05-11 12:27:41 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:27:41 --> Database Driver Class Initialized
INFO - 2023-05-11 12:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:27:41 --> Parser Class Initialized
INFO - 2023-05-11 12:27:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:27:41 --> Pagination Class Initialized
INFO - 2023-05-11 12:27:41 --> Form Validation Class Initialized
INFO - 2023-05-11 12:27:41 --> Controller Class Initialized
INFO - 2023-05-11 12:27:41 --> Model Class Initialized
DEBUG - 2023-05-11 12:27:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:27:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:27:41 --> Model Class Initialized
DEBUG - 2023-05-11 12:27:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:27:41 --> Model Class Initialized
INFO - 2023-05-11 12:27:41 --> Final output sent to browser
DEBUG - 2023-05-11 12:27:41 --> Total execution time: 0.0579
ERROR - 2023-05-11 12:27:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:27:46 --> Config Class Initialized
INFO - 2023-05-11 12:27:46 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:27:46 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:27:46 --> Utf8 Class Initialized
INFO - 2023-05-11 12:27:46 --> URI Class Initialized
INFO - 2023-05-11 12:27:46 --> Router Class Initialized
INFO - 2023-05-11 12:27:46 --> Output Class Initialized
INFO - 2023-05-11 12:27:46 --> Security Class Initialized
DEBUG - 2023-05-11 12:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:27:46 --> Input Class Initialized
INFO - 2023-05-11 12:27:46 --> Language Class Initialized
INFO - 2023-05-11 12:27:46 --> Loader Class Initialized
INFO - 2023-05-11 12:27:46 --> Helper loaded: url_helper
INFO - 2023-05-11 12:27:46 --> Helper loaded: file_helper
INFO - 2023-05-11 12:27:46 --> Helper loaded: html_helper
INFO - 2023-05-11 12:27:46 --> Helper loaded: text_helper
INFO - 2023-05-11 12:27:46 --> Helper loaded: form_helper
INFO - 2023-05-11 12:27:46 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:27:46 --> Helper loaded: security_helper
INFO - 2023-05-11 12:27:46 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:27:46 --> Database Driver Class Initialized
INFO - 2023-05-11 12:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:27:46 --> Parser Class Initialized
INFO - 2023-05-11 12:27:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:27:46 --> Pagination Class Initialized
INFO - 2023-05-11 12:27:46 --> Form Validation Class Initialized
INFO - 2023-05-11 12:27:46 --> Controller Class Initialized
INFO - 2023-05-11 12:27:46 --> Model Class Initialized
DEBUG - 2023-05-11 12:27:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:27:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:27:46 --> Model Class Initialized
DEBUG - 2023-05-11 12:27:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:27:46 --> Model Class Initialized
INFO - 2023-05-11 12:27:46 --> Final output sent to browser
DEBUG - 2023-05-11 12:27:46 --> Total execution time: 0.1277
ERROR - 2023-05-11 12:27:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 12:27:53 --> Config Class Initialized
INFO - 2023-05-11 12:27:53 --> Hooks Class Initialized
DEBUG - 2023-05-11 12:27:53 --> UTF-8 Support Enabled
INFO - 2023-05-11 12:27:53 --> Utf8 Class Initialized
INFO - 2023-05-11 12:27:53 --> URI Class Initialized
DEBUG - 2023-05-11 12:27:53 --> No URI present. Default controller set.
INFO - 2023-05-11 12:27:53 --> Router Class Initialized
INFO - 2023-05-11 12:27:53 --> Output Class Initialized
INFO - 2023-05-11 12:27:53 --> Security Class Initialized
DEBUG - 2023-05-11 12:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 12:27:53 --> Input Class Initialized
INFO - 2023-05-11 12:27:53 --> Language Class Initialized
INFO - 2023-05-11 12:27:53 --> Loader Class Initialized
INFO - 2023-05-11 12:27:53 --> Helper loaded: url_helper
INFO - 2023-05-11 12:27:53 --> Helper loaded: file_helper
INFO - 2023-05-11 12:27:53 --> Helper loaded: html_helper
INFO - 2023-05-11 12:27:53 --> Helper loaded: text_helper
INFO - 2023-05-11 12:27:53 --> Helper loaded: form_helper
INFO - 2023-05-11 12:27:53 --> Helper loaded: lang_helper
INFO - 2023-05-11 12:27:53 --> Helper loaded: security_helper
INFO - 2023-05-11 12:27:53 --> Helper loaded: cookie_helper
INFO - 2023-05-11 12:27:53 --> Database Driver Class Initialized
INFO - 2023-05-11 12:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 12:27:53 --> Parser Class Initialized
INFO - 2023-05-11 12:27:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 12:27:53 --> Pagination Class Initialized
INFO - 2023-05-11 12:27:53 --> Form Validation Class Initialized
INFO - 2023-05-11 12:27:53 --> Controller Class Initialized
INFO - 2023-05-11 12:27:53 --> Model Class Initialized
DEBUG - 2023-05-11 12:27:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:27:53 --> Model Class Initialized
DEBUG - 2023-05-11 12:27:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:27:53 --> Model Class Initialized
INFO - 2023-05-11 12:27:53 --> Model Class Initialized
INFO - 2023-05-11 12:27:53 --> Model Class Initialized
INFO - 2023-05-11 12:27:53 --> Model Class Initialized
DEBUG - 2023-05-11 12:27:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 12:27:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:27:53 --> Model Class Initialized
INFO - 2023-05-11 12:27:53 --> Model Class Initialized
INFO - 2023-05-11 12:27:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-11 12:27:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 12:27:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 12:27:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 12:27:53 --> Model Class Initialized
INFO - 2023-05-11 12:27:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 12:27:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 12:27:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 12:27:53 --> Final output sent to browser
DEBUG - 2023-05-11 12:27:53 --> Total execution time: 0.2024
ERROR - 2023-05-11 14:47:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:47:30 --> Config Class Initialized
INFO - 2023-05-11 14:47:30 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:47:30 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:47:30 --> Utf8 Class Initialized
INFO - 2023-05-11 14:47:30 --> URI Class Initialized
DEBUG - 2023-05-11 14:47:30 --> No URI present. Default controller set.
INFO - 2023-05-11 14:47:30 --> Router Class Initialized
INFO - 2023-05-11 14:47:30 --> Output Class Initialized
INFO - 2023-05-11 14:47:30 --> Security Class Initialized
DEBUG - 2023-05-11 14:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:47:30 --> Input Class Initialized
INFO - 2023-05-11 14:47:30 --> Language Class Initialized
INFO - 2023-05-11 14:47:30 --> Loader Class Initialized
INFO - 2023-05-11 14:47:30 --> Helper loaded: url_helper
INFO - 2023-05-11 14:47:30 --> Helper loaded: file_helper
INFO - 2023-05-11 14:47:30 --> Helper loaded: html_helper
INFO - 2023-05-11 14:47:30 --> Helper loaded: text_helper
INFO - 2023-05-11 14:47:30 --> Helper loaded: form_helper
INFO - 2023-05-11 14:47:30 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:47:30 --> Helper loaded: security_helper
INFO - 2023-05-11 14:47:30 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:47:30 --> Database Driver Class Initialized
INFO - 2023-05-11 14:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:47:30 --> Parser Class Initialized
INFO - 2023-05-11 14:47:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:47:30 --> Pagination Class Initialized
INFO - 2023-05-11 14:47:30 --> Form Validation Class Initialized
INFO - 2023-05-11 14:47:30 --> Controller Class Initialized
INFO - 2023-05-11 14:47:30 --> Model Class Initialized
DEBUG - 2023-05-11 14:47:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-11 14:47:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:47:31 --> Config Class Initialized
INFO - 2023-05-11 14:47:31 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:47:31 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:47:31 --> Utf8 Class Initialized
INFO - 2023-05-11 14:47:31 --> URI Class Initialized
INFO - 2023-05-11 14:47:31 --> Router Class Initialized
INFO - 2023-05-11 14:47:31 --> Output Class Initialized
INFO - 2023-05-11 14:47:31 --> Security Class Initialized
DEBUG - 2023-05-11 14:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:47:31 --> Input Class Initialized
INFO - 2023-05-11 14:47:31 --> Language Class Initialized
INFO - 2023-05-11 14:47:31 --> Loader Class Initialized
INFO - 2023-05-11 14:47:31 --> Helper loaded: url_helper
INFO - 2023-05-11 14:47:31 --> Helper loaded: file_helper
INFO - 2023-05-11 14:47:31 --> Helper loaded: html_helper
INFO - 2023-05-11 14:47:31 --> Helper loaded: text_helper
INFO - 2023-05-11 14:47:31 --> Helper loaded: form_helper
INFO - 2023-05-11 14:47:31 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:47:31 --> Helper loaded: security_helper
INFO - 2023-05-11 14:47:31 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:47:31 --> Database Driver Class Initialized
INFO - 2023-05-11 14:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:47:31 --> Parser Class Initialized
INFO - 2023-05-11 14:47:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:47:31 --> Pagination Class Initialized
INFO - 2023-05-11 14:47:31 --> Form Validation Class Initialized
INFO - 2023-05-11 14:47:31 --> Controller Class Initialized
INFO - 2023-05-11 14:47:31 --> Model Class Initialized
DEBUG - 2023-05-11 14:47:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:47:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-11 14:47:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:47:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 14:47:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 14:47:31 --> Model Class Initialized
INFO - 2023-05-11 14:47:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 14:47:31 --> Final output sent to browser
DEBUG - 2023-05-11 14:47:31 --> Total execution time: 0.0331
ERROR - 2023-05-11 14:47:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:47:43 --> Config Class Initialized
INFO - 2023-05-11 14:47:43 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:47:43 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:47:43 --> Utf8 Class Initialized
INFO - 2023-05-11 14:47:43 --> URI Class Initialized
INFO - 2023-05-11 14:47:43 --> Router Class Initialized
INFO - 2023-05-11 14:47:43 --> Output Class Initialized
INFO - 2023-05-11 14:47:43 --> Security Class Initialized
DEBUG - 2023-05-11 14:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:47:43 --> Input Class Initialized
INFO - 2023-05-11 14:47:43 --> Language Class Initialized
INFO - 2023-05-11 14:47:43 --> Loader Class Initialized
INFO - 2023-05-11 14:47:43 --> Helper loaded: url_helper
INFO - 2023-05-11 14:47:43 --> Helper loaded: file_helper
INFO - 2023-05-11 14:47:43 --> Helper loaded: html_helper
INFO - 2023-05-11 14:47:43 --> Helper loaded: text_helper
INFO - 2023-05-11 14:47:43 --> Helper loaded: form_helper
INFO - 2023-05-11 14:47:43 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:47:43 --> Helper loaded: security_helper
INFO - 2023-05-11 14:47:43 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:47:43 --> Database Driver Class Initialized
INFO - 2023-05-11 14:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:47:43 --> Parser Class Initialized
INFO - 2023-05-11 14:47:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:47:43 --> Pagination Class Initialized
INFO - 2023-05-11 14:47:43 --> Form Validation Class Initialized
INFO - 2023-05-11 14:47:43 --> Controller Class Initialized
INFO - 2023-05-11 14:47:43 --> Model Class Initialized
DEBUG - 2023-05-11 14:47:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:47:43 --> Model Class Initialized
INFO - 2023-05-11 14:47:43 --> Final output sent to browser
DEBUG - 2023-05-11 14:47:43 --> Total execution time: 0.0211
ERROR - 2023-05-11 14:47:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:47:43 --> Config Class Initialized
INFO - 2023-05-11 14:47:43 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:47:43 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:47:43 --> Utf8 Class Initialized
INFO - 2023-05-11 14:47:43 --> URI Class Initialized
DEBUG - 2023-05-11 14:47:43 --> No URI present. Default controller set.
INFO - 2023-05-11 14:47:43 --> Router Class Initialized
INFO - 2023-05-11 14:47:43 --> Output Class Initialized
INFO - 2023-05-11 14:47:43 --> Security Class Initialized
DEBUG - 2023-05-11 14:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:47:43 --> Input Class Initialized
INFO - 2023-05-11 14:47:43 --> Language Class Initialized
INFO - 2023-05-11 14:47:43 --> Loader Class Initialized
INFO - 2023-05-11 14:47:43 --> Helper loaded: url_helper
INFO - 2023-05-11 14:47:43 --> Helper loaded: file_helper
INFO - 2023-05-11 14:47:43 --> Helper loaded: html_helper
INFO - 2023-05-11 14:47:43 --> Helper loaded: text_helper
INFO - 2023-05-11 14:47:43 --> Helper loaded: form_helper
INFO - 2023-05-11 14:47:43 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:47:43 --> Helper loaded: security_helper
INFO - 2023-05-11 14:47:43 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:47:43 --> Database Driver Class Initialized
INFO - 2023-05-11 14:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:47:43 --> Parser Class Initialized
INFO - 2023-05-11 14:47:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:47:43 --> Pagination Class Initialized
INFO - 2023-05-11 14:47:43 --> Form Validation Class Initialized
INFO - 2023-05-11 14:47:43 --> Controller Class Initialized
INFO - 2023-05-11 14:47:43 --> Model Class Initialized
DEBUG - 2023-05-11 14:47:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:47:43 --> Model Class Initialized
DEBUG - 2023-05-11 14:47:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:47:43 --> Model Class Initialized
INFO - 2023-05-11 14:47:43 --> Model Class Initialized
INFO - 2023-05-11 14:47:43 --> Model Class Initialized
INFO - 2023-05-11 14:47:43 --> Model Class Initialized
DEBUG - 2023-05-11 14:47:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:47:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:47:43 --> Model Class Initialized
INFO - 2023-05-11 14:47:43 --> Model Class Initialized
INFO - 2023-05-11 14:47:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-11 14:47:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:47:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 14:47:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 14:47:43 --> Model Class Initialized
INFO - 2023-05-11 14:47:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 14:47:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 14:47:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 14:47:43 --> Final output sent to browser
DEBUG - 2023-05-11 14:47:43 --> Total execution time: 0.0796
ERROR - 2023-05-11 14:47:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:47:56 --> Config Class Initialized
INFO - 2023-05-11 14:47:56 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:47:56 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:47:56 --> Utf8 Class Initialized
INFO - 2023-05-11 14:47:56 --> URI Class Initialized
INFO - 2023-05-11 14:47:56 --> Router Class Initialized
INFO - 2023-05-11 14:47:56 --> Output Class Initialized
INFO - 2023-05-11 14:47:56 --> Security Class Initialized
DEBUG - 2023-05-11 14:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:47:56 --> Input Class Initialized
INFO - 2023-05-11 14:47:56 --> Language Class Initialized
INFO - 2023-05-11 14:47:56 --> Loader Class Initialized
INFO - 2023-05-11 14:47:56 --> Helper loaded: url_helper
INFO - 2023-05-11 14:47:56 --> Helper loaded: file_helper
INFO - 2023-05-11 14:47:56 --> Helper loaded: html_helper
INFO - 2023-05-11 14:47:56 --> Helper loaded: text_helper
INFO - 2023-05-11 14:47:56 --> Helper loaded: form_helper
INFO - 2023-05-11 14:47:56 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:47:56 --> Helper loaded: security_helper
INFO - 2023-05-11 14:47:56 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:47:56 --> Database Driver Class Initialized
INFO - 2023-05-11 14:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:47:56 --> Parser Class Initialized
INFO - 2023-05-11 14:47:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:47:56 --> Pagination Class Initialized
INFO - 2023-05-11 14:47:56 --> Form Validation Class Initialized
INFO - 2023-05-11 14:47:56 --> Controller Class Initialized
INFO - 2023-05-11 14:47:56 --> Model Class Initialized
DEBUG - 2023-05-11 14:47:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:47:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:47:56 --> Model Class Initialized
DEBUG - 2023-05-11 14:47:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:47:56 --> Model Class Initialized
INFO - 2023-05-11 14:47:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-05-11 14:47:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:47:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 14:47:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 14:47:56 --> Model Class Initialized
INFO - 2023-05-11 14:47:56 --> Model Class Initialized
INFO - 2023-05-11 14:47:56 --> Model Class Initialized
INFO - 2023-05-11 14:47:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 14:47:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 14:47:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 14:47:56 --> Final output sent to browser
DEBUG - 2023-05-11 14:47:56 --> Total execution time: 0.1147
ERROR - 2023-05-11 14:48:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:48:01 --> Config Class Initialized
INFO - 2023-05-11 14:48:01 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:48:01 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:48:01 --> Utf8 Class Initialized
INFO - 2023-05-11 14:48:01 --> URI Class Initialized
INFO - 2023-05-11 14:48:01 --> Router Class Initialized
INFO - 2023-05-11 14:48:01 --> Output Class Initialized
INFO - 2023-05-11 14:48:01 --> Security Class Initialized
DEBUG - 2023-05-11 14:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:48:01 --> Input Class Initialized
INFO - 2023-05-11 14:48:01 --> Language Class Initialized
INFO - 2023-05-11 14:48:01 --> Loader Class Initialized
INFO - 2023-05-11 14:48:01 --> Helper loaded: url_helper
INFO - 2023-05-11 14:48:01 --> Helper loaded: file_helper
INFO - 2023-05-11 14:48:01 --> Helper loaded: html_helper
INFO - 2023-05-11 14:48:01 --> Helper loaded: text_helper
INFO - 2023-05-11 14:48:01 --> Helper loaded: form_helper
INFO - 2023-05-11 14:48:01 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:48:01 --> Helper loaded: security_helper
INFO - 2023-05-11 14:48:01 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:48:01 --> Database Driver Class Initialized
INFO - 2023-05-11 14:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:48:01 --> Parser Class Initialized
INFO - 2023-05-11 14:48:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:48:01 --> Pagination Class Initialized
INFO - 2023-05-11 14:48:01 --> Form Validation Class Initialized
INFO - 2023-05-11 14:48:01 --> Controller Class Initialized
INFO - 2023-05-11 14:48:01 --> Model Class Initialized
DEBUG - 2023-05-11 14:48:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:48:01 --> Final output sent to browser
DEBUG - 2023-05-11 14:48:01 --> Total execution time: 0.0166
ERROR - 2023-05-11 14:48:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:48:03 --> Config Class Initialized
INFO - 2023-05-11 14:48:03 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:48:03 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:48:03 --> Utf8 Class Initialized
INFO - 2023-05-11 14:48:03 --> URI Class Initialized
INFO - 2023-05-11 14:48:03 --> Router Class Initialized
INFO - 2023-05-11 14:48:03 --> Output Class Initialized
INFO - 2023-05-11 14:48:03 --> Security Class Initialized
DEBUG - 2023-05-11 14:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:48:03 --> Input Class Initialized
INFO - 2023-05-11 14:48:03 --> Language Class Initialized
INFO - 2023-05-11 14:48:03 --> Loader Class Initialized
INFO - 2023-05-11 14:48:03 --> Helper loaded: url_helper
INFO - 2023-05-11 14:48:03 --> Helper loaded: file_helper
INFO - 2023-05-11 14:48:03 --> Helper loaded: html_helper
INFO - 2023-05-11 14:48:03 --> Helper loaded: text_helper
INFO - 2023-05-11 14:48:03 --> Helper loaded: form_helper
INFO - 2023-05-11 14:48:03 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:48:03 --> Helper loaded: security_helper
INFO - 2023-05-11 14:48:03 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:48:03 --> Database Driver Class Initialized
INFO - 2023-05-11 14:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:48:03 --> Parser Class Initialized
INFO - 2023-05-11 14:48:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:48:03 --> Pagination Class Initialized
INFO - 2023-05-11 14:48:03 --> Form Validation Class Initialized
INFO - 2023-05-11 14:48:03 --> Controller Class Initialized
INFO - 2023-05-11 14:48:03 --> Model Class Initialized
DEBUG - 2023-05-11 14:48:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:48:03 --> Final output sent to browser
DEBUG - 2023-05-11 14:48:03 --> Total execution time: 0.0189
ERROR - 2023-05-11 14:48:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:48:05 --> Config Class Initialized
INFO - 2023-05-11 14:48:05 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:48:05 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:48:05 --> Utf8 Class Initialized
INFO - 2023-05-11 14:48:05 --> URI Class Initialized
INFO - 2023-05-11 14:48:05 --> Router Class Initialized
INFO - 2023-05-11 14:48:05 --> Output Class Initialized
INFO - 2023-05-11 14:48:05 --> Security Class Initialized
DEBUG - 2023-05-11 14:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:48:05 --> Input Class Initialized
INFO - 2023-05-11 14:48:05 --> Language Class Initialized
INFO - 2023-05-11 14:48:05 --> Loader Class Initialized
INFO - 2023-05-11 14:48:05 --> Helper loaded: url_helper
INFO - 2023-05-11 14:48:05 --> Helper loaded: file_helper
INFO - 2023-05-11 14:48:05 --> Helper loaded: html_helper
INFO - 2023-05-11 14:48:05 --> Helper loaded: text_helper
INFO - 2023-05-11 14:48:05 --> Helper loaded: form_helper
INFO - 2023-05-11 14:48:05 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:48:05 --> Helper loaded: security_helper
INFO - 2023-05-11 14:48:05 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:48:05 --> Database Driver Class Initialized
INFO - 2023-05-11 14:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:48:05 --> Parser Class Initialized
INFO - 2023-05-11 14:48:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:48:05 --> Pagination Class Initialized
INFO - 2023-05-11 14:48:05 --> Form Validation Class Initialized
INFO - 2023-05-11 14:48:05 --> Controller Class Initialized
INFO - 2023-05-11 14:48:05 --> Model Class Initialized
DEBUG - 2023-05-11 14:48:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:48:05 --> Final output sent to browser
DEBUG - 2023-05-11 14:48:05 --> Total execution time: 0.0162
ERROR - 2023-05-11 14:48:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:48:07 --> Config Class Initialized
INFO - 2023-05-11 14:48:07 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:48:07 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:48:07 --> Utf8 Class Initialized
INFO - 2023-05-11 14:48:07 --> URI Class Initialized
INFO - 2023-05-11 14:48:07 --> Router Class Initialized
INFO - 2023-05-11 14:48:07 --> Output Class Initialized
INFO - 2023-05-11 14:48:07 --> Security Class Initialized
DEBUG - 2023-05-11 14:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:48:07 --> Input Class Initialized
INFO - 2023-05-11 14:48:07 --> Language Class Initialized
INFO - 2023-05-11 14:48:07 --> Loader Class Initialized
INFO - 2023-05-11 14:48:07 --> Helper loaded: url_helper
INFO - 2023-05-11 14:48:07 --> Helper loaded: file_helper
INFO - 2023-05-11 14:48:07 --> Helper loaded: html_helper
INFO - 2023-05-11 14:48:07 --> Helper loaded: text_helper
INFO - 2023-05-11 14:48:07 --> Helper loaded: form_helper
INFO - 2023-05-11 14:48:07 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:48:07 --> Helper loaded: security_helper
INFO - 2023-05-11 14:48:07 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:48:07 --> Database Driver Class Initialized
INFO - 2023-05-11 14:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:48:07 --> Parser Class Initialized
INFO - 2023-05-11 14:48:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:48:07 --> Pagination Class Initialized
INFO - 2023-05-11 14:48:07 --> Form Validation Class Initialized
INFO - 2023-05-11 14:48:07 --> Controller Class Initialized
INFO - 2023-05-11 14:48:07 --> Model Class Initialized
DEBUG - 2023-05-11 14:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:48:07 --> Final output sent to browser
DEBUG - 2023-05-11 14:48:07 --> Total execution time: 0.0149
ERROR - 2023-05-11 14:48:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:48:07 --> Config Class Initialized
INFO - 2023-05-11 14:48:07 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:48:07 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:48:07 --> Utf8 Class Initialized
INFO - 2023-05-11 14:48:07 --> URI Class Initialized
INFO - 2023-05-11 14:48:07 --> Router Class Initialized
INFO - 2023-05-11 14:48:07 --> Output Class Initialized
INFO - 2023-05-11 14:48:07 --> Security Class Initialized
DEBUG - 2023-05-11 14:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:48:07 --> Input Class Initialized
INFO - 2023-05-11 14:48:07 --> Language Class Initialized
INFO - 2023-05-11 14:48:07 --> Loader Class Initialized
INFO - 2023-05-11 14:48:07 --> Helper loaded: url_helper
INFO - 2023-05-11 14:48:07 --> Helper loaded: file_helper
INFO - 2023-05-11 14:48:07 --> Helper loaded: html_helper
INFO - 2023-05-11 14:48:07 --> Helper loaded: text_helper
INFO - 2023-05-11 14:48:07 --> Helper loaded: form_helper
INFO - 2023-05-11 14:48:07 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:48:07 --> Helper loaded: security_helper
INFO - 2023-05-11 14:48:07 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:48:07 --> Database Driver Class Initialized
INFO - 2023-05-11 14:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:48:07 --> Parser Class Initialized
INFO - 2023-05-11 14:48:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:48:07 --> Pagination Class Initialized
INFO - 2023-05-11 14:48:07 --> Form Validation Class Initialized
INFO - 2023-05-11 14:48:07 --> Controller Class Initialized
INFO - 2023-05-11 14:48:07 --> Model Class Initialized
DEBUG - 2023-05-11 14:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:48:07 --> Final output sent to browser
DEBUG - 2023-05-11 14:48:07 --> Total execution time: 0.0155
ERROR - 2023-05-11 14:48:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:48:09 --> Config Class Initialized
INFO - 2023-05-11 14:48:09 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:48:09 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:48:09 --> Utf8 Class Initialized
INFO - 2023-05-11 14:48:09 --> URI Class Initialized
INFO - 2023-05-11 14:48:09 --> Router Class Initialized
INFO - 2023-05-11 14:48:09 --> Output Class Initialized
INFO - 2023-05-11 14:48:09 --> Security Class Initialized
DEBUG - 2023-05-11 14:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:48:09 --> Input Class Initialized
INFO - 2023-05-11 14:48:09 --> Language Class Initialized
INFO - 2023-05-11 14:48:09 --> Loader Class Initialized
INFO - 2023-05-11 14:48:09 --> Helper loaded: url_helper
INFO - 2023-05-11 14:48:09 --> Helper loaded: file_helper
INFO - 2023-05-11 14:48:09 --> Helper loaded: html_helper
INFO - 2023-05-11 14:48:09 --> Helper loaded: text_helper
INFO - 2023-05-11 14:48:09 --> Helper loaded: form_helper
INFO - 2023-05-11 14:48:09 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:48:09 --> Helper loaded: security_helper
INFO - 2023-05-11 14:48:09 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:48:09 --> Database Driver Class Initialized
INFO - 2023-05-11 14:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:48:09 --> Parser Class Initialized
INFO - 2023-05-11 14:48:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:48:09 --> Pagination Class Initialized
INFO - 2023-05-11 14:48:09 --> Form Validation Class Initialized
INFO - 2023-05-11 14:48:09 --> Controller Class Initialized
INFO - 2023-05-11 14:48:09 --> Model Class Initialized
DEBUG - 2023-05-11 14:48:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-11 14:48:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-05-11 14:48:09 --> Final output sent to browser
DEBUG - 2023-05-11 14:48:09 --> Total execution time: 0.0156
ERROR - 2023-05-11 14:48:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:48:10 --> Config Class Initialized
INFO - 2023-05-11 14:48:10 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:48:10 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:48:10 --> Utf8 Class Initialized
INFO - 2023-05-11 14:48:10 --> URI Class Initialized
INFO - 2023-05-11 14:48:10 --> Router Class Initialized
INFO - 2023-05-11 14:48:10 --> Output Class Initialized
INFO - 2023-05-11 14:48:10 --> Security Class Initialized
DEBUG - 2023-05-11 14:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:48:10 --> Input Class Initialized
INFO - 2023-05-11 14:48:10 --> Language Class Initialized
INFO - 2023-05-11 14:48:10 --> Loader Class Initialized
INFO - 2023-05-11 14:48:10 --> Helper loaded: url_helper
INFO - 2023-05-11 14:48:10 --> Helper loaded: file_helper
INFO - 2023-05-11 14:48:10 --> Helper loaded: html_helper
INFO - 2023-05-11 14:48:10 --> Helper loaded: text_helper
INFO - 2023-05-11 14:48:10 --> Helper loaded: form_helper
INFO - 2023-05-11 14:48:10 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:48:10 --> Helper loaded: security_helper
INFO - 2023-05-11 14:48:10 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:48:10 --> Database Driver Class Initialized
INFO - 2023-05-11 14:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:48:10 --> Parser Class Initialized
INFO - 2023-05-11 14:48:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:48:10 --> Pagination Class Initialized
INFO - 2023-05-11 14:48:10 --> Form Validation Class Initialized
INFO - 2023-05-11 14:48:10 --> Controller Class Initialized
INFO - 2023-05-11 14:48:10 --> Model Class Initialized
DEBUG - 2023-05-11 14:48:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-11 14:48:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-05-11 14:48:10 --> Final output sent to browser
DEBUG - 2023-05-11 14:48:10 --> Total execution time: 0.0150
ERROR - 2023-05-11 14:48:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:48:11 --> Config Class Initialized
INFO - 2023-05-11 14:48:11 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:48:11 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:48:11 --> Utf8 Class Initialized
INFO - 2023-05-11 14:48:11 --> URI Class Initialized
INFO - 2023-05-11 14:48:11 --> Router Class Initialized
INFO - 2023-05-11 14:48:11 --> Output Class Initialized
INFO - 2023-05-11 14:48:11 --> Security Class Initialized
DEBUG - 2023-05-11 14:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:48:11 --> Input Class Initialized
INFO - 2023-05-11 14:48:11 --> Language Class Initialized
INFO - 2023-05-11 14:48:11 --> Loader Class Initialized
INFO - 2023-05-11 14:48:11 --> Helper loaded: url_helper
INFO - 2023-05-11 14:48:11 --> Helper loaded: file_helper
INFO - 2023-05-11 14:48:11 --> Helper loaded: html_helper
INFO - 2023-05-11 14:48:11 --> Helper loaded: text_helper
INFO - 2023-05-11 14:48:11 --> Helper loaded: form_helper
INFO - 2023-05-11 14:48:11 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:48:11 --> Helper loaded: security_helper
INFO - 2023-05-11 14:48:11 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:48:11 --> Database Driver Class Initialized
INFO - 2023-05-11 14:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:48:11 --> Parser Class Initialized
INFO - 2023-05-11 14:48:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:48:11 --> Pagination Class Initialized
INFO - 2023-05-11 14:48:11 --> Form Validation Class Initialized
INFO - 2023-05-11 14:48:11 --> Controller Class Initialized
INFO - 2023-05-11 14:48:11 --> Model Class Initialized
DEBUG - 2023-05-11 14:48:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-11 14:48:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-05-11 14:48:11 --> Final output sent to browser
DEBUG - 2023-05-11 14:48:11 --> Total execution time: 0.0163
ERROR - 2023-05-11 14:48:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:48:14 --> Config Class Initialized
INFO - 2023-05-11 14:48:14 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:48:14 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:48:14 --> Utf8 Class Initialized
INFO - 2023-05-11 14:48:14 --> URI Class Initialized
INFO - 2023-05-11 14:48:14 --> Router Class Initialized
INFO - 2023-05-11 14:48:14 --> Output Class Initialized
INFO - 2023-05-11 14:48:14 --> Security Class Initialized
DEBUG - 2023-05-11 14:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:48:14 --> Input Class Initialized
INFO - 2023-05-11 14:48:14 --> Language Class Initialized
INFO - 2023-05-11 14:48:14 --> Loader Class Initialized
INFO - 2023-05-11 14:48:14 --> Helper loaded: url_helper
INFO - 2023-05-11 14:48:14 --> Helper loaded: file_helper
INFO - 2023-05-11 14:48:14 --> Helper loaded: html_helper
INFO - 2023-05-11 14:48:14 --> Helper loaded: text_helper
INFO - 2023-05-11 14:48:14 --> Helper loaded: form_helper
INFO - 2023-05-11 14:48:14 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:48:14 --> Helper loaded: security_helper
INFO - 2023-05-11 14:48:14 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:48:14 --> Database Driver Class Initialized
INFO - 2023-05-11 14:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:48:14 --> Parser Class Initialized
INFO - 2023-05-11 14:48:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:48:14 --> Pagination Class Initialized
INFO - 2023-05-11 14:48:14 --> Form Validation Class Initialized
INFO - 2023-05-11 14:48:14 --> Controller Class Initialized
INFO - 2023-05-11 14:48:14 --> Model Class Initialized
DEBUG - 2023-05-11 14:48:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:48:14 --> Final output sent to browser
DEBUG - 2023-05-11 14:48:14 --> Total execution time: 0.0150
ERROR - 2023-05-11 14:48:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:48:23 --> Config Class Initialized
INFO - 2023-05-11 14:48:23 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:48:23 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:48:23 --> Utf8 Class Initialized
INFO - 2023-05-11 14:48:23 --> URI Class Initialized
INFO - 2023-05-11 14:48:23 --> Router Class Initialized
INFO - 2023-05-11 14:48:23 --> Output Class Initialized
INFO - 2023-05-11 14:48:23 --> Security Class Initialized
DEBUG - 2023-05-11 14:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:48:23 --> Input Class Initialized
INFO - 2023-05-11 14:48:23 --> Language Class Initialized
INFO - 2023-05-11 14:48:23 --> Loader Class Initialized
INFO - 2023-05-11 14:48:23 --> Helper loaded: url_helper
INFO - 2023-05-11 14:48:23 --> Helper loaded: file_helper
INFO - 2023-05-11 14:48:23 --> Helper loaded: html_helper
INFO - 2023-05-11 14:48:23 --> Helper loaded: text_helper
INFO - 2023-05-11 14:48:23 --> Helper loaded: form_helper
INFO - 2023-05-11 14:48:23 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:48:23 --> Helper loaded: security_helper
INFO - 2023-05-11 14:48:23 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:48:23 --> Database Driver Class Initialized
INFO - 2023-05-11 14:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:48:24 --> Parser Class Initialized
INFO - 2023-05-11 14:48:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:48:24 --> Pagination Class Initialized
INFO - 2023-05-11 14:48:24 --> Form Validation Class Initialized
INFO - 2023-05-11 14:48:24 --> Controller Class Initialized
INFO - 2023-05-11 14:48:24 --> Model Class Initialized
DEBUG - 2023-05-11 14:48:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:48:24 --> Final output sent to browser
DEBUG - 2023-05-11 14:48:24 --> Total execution time: 0.0161
ERROR - 2023-05-11 14:48:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:48:26 --> Config Class Initialized
INFO - 2023-05-11 14:48:26 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:48:26 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:48:26 --> Utf8 Class Initialized
INFO - 2023-05-11 14:48:26 --> URI Class Initialized
INFO - 2023-05-11 14:48:26 --> Router Class Initialized
INFO - 2023-05-11 14:48:26 --> Output Class Initialized
INFO - 2023-05-11 14:48:26 --> Security Class Initialized
DEBUG - 2023-05-11 14:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:48:26 --> Input Class Initialized
INFO - 2023-05-11 14:48:26 --> Language Class Initialized
INFO - 2023-05-11 14:48:26 --> Loader Class Initialized
INFO - 2023-05-11 14:48:26 --> Helper loaded: url_helper
INFO - 2023-05-11 14:48:26 --> Helper loaded: file_helper
INFO - 2023-05-11 14:48:26 --> Helper loaded: html_helper
INFO - 2023-05-11 14:48:26 --> Helper loaded: text_helper
INFO - 2023-05-11 14:48:26 --> Helper loaded: form_helper
INFO - 2023-05-11 14:48:26 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:48:26 --> Helper loaded: security_helper
INFO - 2023-05-11 14:48:26 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:48:26 --> Database Driver Class Initialized
INFO - 2023-05-11 14:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:48:26 --> Parser Class Initialized
INFO - 2023-05-11 14:48:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:48:26 --> Pagination Class Initialized
INFO - 2023-05-11 14:48:26 --> Form Validation Class Initialized
INFO - 2023-05-11 14:48:26 --> Controller Class Initialized
INFO - 2023-05-11 14:48:26 --> Model Class Initialized
DEBUG - 2023-05-11 14:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:48:26 --> Final output sent to browser
DEBUG - 2023-05-11 14:48:26 --> Total execution time: 0.0150
ERROR - 2023-05-11 14:48:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:48:37 --> Config Class Initialized
INFO - 2023-05-11 14:48:37 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:48:37 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:48:37 --> Utf8 Class Initialized
INFO - 2023-05-11 14:48:37 --> URI Class Initialized
DEBUG - 2023-05-11 14:48:37 --> No URI present. Default controller set.
INFO - 2023-05-11 14:48:37 --> Router Class Initialized
INFO - 2023-05-11 14:48:37 --> Output Class Initialized
INFO - 2023-05-11 14:48:37 --> Security Class Initialized
DEBUG - 2023-05-11 14:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:48:37 --> Input Class Initialized
INFO - 2023-05-11 14:48:37 --> Language Class Initialized
INFO - 2023-05-11 14:48:37 --> Loader Class Initialized
INFO - 2023-05-11 14:48:37 --> Helper loaded: url_helper
INFO - 2023-05-11 14:48:37 --> Helper loaded: file_helper
INFO - 2023-05-11 14:48:37 --> Helper loaded: html_helper
INFO - 2023-05-11 14:48:37 --> Helper loaded: text_helper
INFO - 2023-05-11 14:48:37 --> Helper loaded: form_helper
INFO - 2023-05-11 14:48:37 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:48:37 --> Helper loaded: security_helper
INFO - 2023-05-11 14:48:37 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:48:37 --> Database Driver Class Initialized
INFO - 2023-05-11 14:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:48:37 --> Parser Class Initialized
INFO - 2023-05-11 14:48:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:48:37 --> Pagination Class Initialized
INFO - 2023-05-11 14:48:37 --> Form Validation Class Initialized
INFO - 2023-05-11 14:48:37 --> Controller Class Initialized
INFO - 2023-05-11 14:48:37 --> Model Class Initialized
DEBUG - 2023-05-11 14:48:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:48:37 --> Model Class Initialized
DEBUG - 2023-05-11 14:48:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:48:37 --> Model Class Initialized
INFO - 2023-05-11 14:48:37 --> Model Class Initialized
INFO - 2023-05-11 14:48:37 --> Model Class Initialized
INFO - 2023-05-11 14:48:37 --> Model Class Initialized
DEBUG - 2023-05-11 14:48:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:48:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:48:37 --> Model Class Initialized
INFO - 2023-05-11 14:48:37 --> Model Class Initialized
INFO - 2023-05-11 14:48:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-11 14:48:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:48:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 14:48:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 14:48:37 --> Model Class Initialized
INFO - 2023-05-11 14:48:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 14:48:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 14:48:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 14:48:37 --> Final output sent to browser
DEBUG - 2023-05-11 14:48:37 --> Total execution time: 0.0816
ERROR - 2023-05-11 14:48:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:48:48 --> Config Class Initialized
INFO - 2023-05-11 14:48:48 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:48:48 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:48:48 --> Utf8 Class Initialized
INFO - 2023-05-11 14:48:48 --> URI Class Initialized
INFO - 2023-05-11 14:48:48 --> Router Class Initialized
INFO - 2023-05-11 14:48:48 --> Output Class Initialized
INFO - 2023-05-11 14:48:48 --> Security Class Initialized
DEBUG - 2023-05-11 14:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:48:48 --> Input Class Initialized
INFO - 2023-05-11 14:48:48 --> Language Class Initialized
INFO - 2023-05-11 14:48:48 --> Loader Class Initialized
INFO - 2023-05-11 14:48:48 --> Helper loaded: url_helper
INFO - 2023-05-11 14:48:48 --> Helper loaded: file_helper
INFO - 2023-05-11 14:48:48 --> Helper loaded: html_helper
INFO - 2023-05-11 14:48:48 --> Helper loaded: text_helper
INFO - 2023-05-11 14:48:48 --> Helper loaded: form_helper
INFO - 2023-05-11 14:48:48 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:48:48 --> Helper loaded: security_helper
INFO - 2023-05-11 14:48:48 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:48:48 --> Database Driver Class Initialized
INFO - 2023-05-11 14:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:48:48 --> Parser Class Initialized
INFO - 2023-05-11 14:48:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:48:48 --> Pagination Class Initialized
INFO - 2023-05-11 14:48:48 --> Form Validation Class Initialized
INFO - 2023-05-11 14:48:48 --> Controller Class Initialized
INFO - 2023-05-11 14:48:48 --> Model Class Initialized
DEBUG - 2023-05-11 14:48:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:48:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:48:48 --> Model Class Initialized
DEBUG - 2023-05-11 14:48:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:48:48 --> Model Class Initialized
INFO - 2023-05-11 14:48:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-05-11 14:48:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:48:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 14:48:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 14:48:48 --> Model Class Initialized
INFO - 2023-05-11 14:48:48 --> Model Class Initialized
INFO - 2023-05-11 14:48:48 --> Model Class Initialized
INFO - 2023-05-11 14:48:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 14:48:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 14:48:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 14:48:48 --> Final output sent to browser
DEBUG - 2023-05-11 14:48:48 --> Total execution time: 0.0704
ERROR - 2023-05-11 14:48:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:48:49 --> Config Class Initialized
INFO - 2023-05-11 14:48:49 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:48:49 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:48:49 --> Utf8 Class Initialized
INFO - 2023-05-11 14:48:49 --> URI Class Initialized
INFO - 2023-05-11 14:48:49 --> Router Class Initialized
INFO - 2023-05-11 14:48:49 --> Output Class Initialized
INFO - 2023-05-11 14:48:49 --> Security Class Initialized
DEBUG - 2023-05-11 14:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:48:49 --> Input Class Initialized
INFO - 2023-05-11 14:48:49 --> Language Class Initialized
INFO - 2023-05-11 14:48:49 --> Loader Class Initialized
INFO - 2023-05-11 14:48:49 --> Helper loaded: url_helper
INFO - 2023-05-11 14:48:49 --> Helper loaded: file_helper
INFO - 2023-05-11 14:48:49 --> Helper loaded: html_helper
INFO - 2023-05-11 14:48:49 --> Helper loaded: text_helper
INFO - 2023-05-11 14:48:49 --> Helper loaded: form_helper
INFO - 2023-05-11 14:48:49 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:48:49 --> Helper loaded: security_helper
INFO - 2023-05-11 14:48:49 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:48:49 --> Database Driver Class Initialized
INFO - 2023-05-11 14:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:48:49 --> Parser Class Initialized
INFO - 2023-05-11 14:48:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:48:49 --> Pagination Class Initialized
INFO - 2023-05-11 14:48:49 --> Form Validation Class Initialized
INFO - 2023-05-11 14:48:49 --> Controller Class Initialized
INFO - 2023-05-11 14:48:49 --> Model Class Initialized
DEBUG - 2023-05-11 14:48:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:48:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:48:49 --> Model Class Initialized
DEBUG - 2023-05-11 14:48:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:48:49 --> Model Class Initialized
INFO - 2023-05-11 14:48:49 --> Final output sent to browser
DEBUG - 2023-05-11 14:48:49 --> Total execution time: 0.0465
ERROR - 2023-05-11 14:48:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:48:58 --> Config Class Initialized
INFO - 2023-05-11 14:48:58 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:48:58 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:48:58 --> Utf8 Class Initialized
INFO - 2023-05-11 14:48:58 --> URI Class Initialized
INFO - 2023-05-11 14:48:58 --> Router Class Initialized
INFO - 2023-05-11 14:48:58 --> Output Class Initialized
INFO - 2023-05-11 14:48:58 --> Security Class Initialized
DEBUG - 2023-05-11 14:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:48:58 --> Input Class Initialized
INFO - 2023-05-11 14:48:58 --> Language Class Initialized
INFO - 2023-05-11 14:48:58 --> Loader Class Initialized
INFO - 2023-05-11 14:48:58 --> Helper loaded: url_helper
INFO - 2023-05-11 14:48:58 --> Helper loaded: file_helper
INFO - 2023-05-11 14:48:58 --> Helper loaded: html_helper
INFO - 2023-05-11 14:48:58 --> Helper loaded: text_helper
INFO - 2023-05-11 14:48:58 --> Helper loaded: form_helper
INFO - 2023-05-11 14:48:58 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:48:58 --> Helper loaded: security_helper
INFO - 2023-05-11 14:48:58 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:48:58 --> Database Driver Class Initialized
INFO - 2023-05-11 14:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:48:58 --> Parser Class Initialized
INFO - 2023-05-11 14:48:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:48:58 --> Pagination Class Initialized
INFO - 2023-05-11 14:48:58 --> Form Validation Class Initialized
INFO - 2023-05-11 14:48:58 --> Controller Class Initialized
INFO - 2023-05-11 14:48:58 --> Model Class Initialized
DEBUG - 2023-05-11 14:48:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:48:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:48:58 --> Model Class Initialized
DEBUG - 2023-05-11 14:48:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:48:58 --> Model Class Initialized
INFO - 2023-05-11 14:48:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-05-11 14:48:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:48:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-11 14:48:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-11 14:48:58 --> Model Class Initialized
INFO - 2023-05-11 14:48:58 --> Model Class Initialized
INFO - 2023-05-11 14:48:58 --> Model Class Initialized
INFO - 2023-05-11 14:48:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-11 14:48:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-11 14:48:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-11 14:48:58 --> Final output sent to browser
DEBUG - 2023-05-11 14:48:58 --> Total execution time: 0.0887
ERROR - 2023-05-11 14:49:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:49:02 --> Config Class Initialized
INFO - 2023-05-11 14:49:02 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:49:02 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:49:02 --> Utf8 Class Initialized
INFO - 2023-05-11 14:49:02 --> URI Class Initialized
INFO - 2023-05-11 14:49:02 --> Router Class Initialized
INFO - 2023-05-11 14:49:02 --> Output Class Initialized
INFO - 2023-05-11 14:49:02 --> Security Class Initialized
DEBUG - 2023-05-11 14:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:49:02 --> Input Class Initialized
INFO - 2023-05-11 14:49:02 --> Language Class Initialized
INFO - 2023-05-11 14:49:02 --> Loader Class Initialized
INFO - 2023-05-11 14:49:02 --> Helper loaded: url_helper
INFO - 2023-05-11 14:49:02 --> Helper loaded: file_helper
INFO - 2023-05-11 14:49:02 --> Helper loaded: html_helper
INFO - 2023-05-11 14:49:02 --> Helper loaded: text_helper
INFO - 2023-05-11 14:49:02 --> Helper loaded: form_helper
INFO - 2023-05-11 14:49:02 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:49:02 --> Helper loaded: security_helper
INFO - 2023-05-11 14:49:02 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:49:02 --> Database Driver Class Initialized
INFO - 2023-05-11 14:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:49:02 --> Parser Class Initialized
INFO - 2023-05-11 14:49:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:49:02 --> Pagination Class Initialized
INFO - 2023-05-11 14:49:02 --> Form Validation Class Initialized
INFO - 2023-05-11 14:49:02 --> Controller Class Initialized
INFO - 2023-05-11 14:49:02 --> Model Class Initialized
DEBUG - 2023-05-11 14:49:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:49:02 --> Final output sent to browser
DEBUG - 2023-05-11 14:49:02 --> Total execution time: 0.0148
ERROR - 2023-05-11 14:49:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:49:02 --> Config Class Initialized
INFO - 2023-05-11 14:49:02 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:49:02 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:49:02 --> Utf8 Class Initialized
INFO - 2023-05-11 14:49:02 --> URI Class Initialized
INFO - 2023-05-11 14:49:02 --> Router Class Initialized
INFO - 2023-05-11 14:49:02 --> Output Class Initialized
INFO - 2023-05-11 14:49:02 --> Security Class Initialized
DEBUG - 2023-05-11 14:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:49:02 --> Input Class Initialized
INFO - 2023-05-11 14:49:02 --> Language Class Initialized
INFO - 2023-05-11 14:49:02 --> Loader Class Initialized
INFO - 2023-05-11 14:49:02 --> Helper loaded: url_helper
INFO - 2023-05-11 14:49:02 --> Helper loaded: file_helper
INFO - 2023-05-11 14:49:02 --> Helper loaded: html_helper
INFO - 2023-05-11 14:49:02 --> Helper loaded: text_helper
INFO - 2023-05-11 14:49:02 --> Helper loaded: form_helper
INFO - 2023-05-11 14:49:02 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:49:02 --> Helper loaded: security_helper
INFO - 2023-05-11 14:49:02 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:49:02 --> Database Driver Class Initialized
INFO - 2023-05-11 14:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:49:02 --> Parser Class Initialized
INFO - 2023-05-11 14:49:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:49:02 --> Pagination Class Initialized
INFO - 2023-05-11 14:49:02 --> Form Validation Class Initialized
INFO - 2023-05-11 14:49:02 --> Controller Class Initialized
INFO - 2023-05-11 14:49:02 --> Model Class Initialized
DEBUG - 2023-05-11 14:49:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:49:02 --> Final output sent to browser
DEBUG - 2023-05-11 14:49:02 --> Total execution time: 0.0160
ERROR - 2023-05-11 14:49:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:49:04 --> Config Class Initialized
INFO - 2023-05-11 14:49:04 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:49:04 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:49:04 --> Utf8 Class Initialized
INFO - 2023-05-11 14:49:04 --> URI Class Initialized
INFO - 2023-05-11 14:49:04 --> Router Class Initialized
INFO - 2023-05-11 14:49:04 --> Output Class Initialized
INFO - 2023-05-11 14:49:04 --> Security Class Initialized
DEBUG - 2023-05-11 14:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:49:04 --> Input Class Initialized
INFO - 2023-05-11 14:49:04 --> Language Class Initialized
INFO - 2023-05-11 14:49:04 --> Loader Class Initialized
INFO - 2023-05-11 14:49:04 --> Helper loaded: url_helper
INFO - 2023-05-11 14:49:04 --> Helper loaded: file_helper
INFO - 2023-05-11 14:49:04 --> Helper loaded: html_helper
INFO - 2023-05-11 14:49:04 --> Helper loaded: text_helper
INFO - 2023-05-11 14:49:04 --> Helper loaded: form_helper
INFO - 2023-05-11 14:49:04 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:49:04 --> Helper loaded: security_helper
INFO - 2023-05-11 14:49:04 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:49:04 --> Database Driver Class Initialized
INFO - 2023-05-11 14:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:49:04 --> Parser Class Initialized
INFO - 2023-05-11 14:49:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:49:04 --> Pagination Class Initialized
INFO - 2023-05-11 14:49:04 --> Form Validation Class Initialized
INFO - 2023-05-11 14:49:04 --> Controller Class Initialized
INFO - 2023-05-11 14:49:04 --> Model Class Initialized
DEBUG - 2023-05-11 14:49:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:49:04 --> Final output sent to browser
DEBUG - 2023-05-11 14:49:04 --> Total execution time: 0.0148
ERROR - 2023-05-11 14:49:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:49:04 --> Config Class Initialized
INFO - 2023-05-11 14:49:04 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:49:04 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:49:04 --> Utf8 Class Initialized
INFO - 2023-05-11 14:49:04 --> URI Class Initialized
INFO - 2023-05-11 14:49:04 --> Router Class Initialized
INFO - 2023-05-11 14:49:04 --> Output Class Initialized
INFO - 2023-05-11 14:49:04 --> Security Class Initialized
DEBUG - 2023-05-11 14:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:49:04 --> Input Class Initialized
INFO - 2023-05-11 14:49:04 --> Language Class Initialized
INFO - 2023-05-11 14:49:04 --> Loader Class Initialized
INFO - 2023-05-11 14:49:04 --> Helper loaded: url_helper
INFO - 2023-05-11 14:49:04 --> Helper loaded: file_helper
INFO - 2023-05-11 14:49:04 --> Helper loaded: html_helper
INFO - 2023-05-11 14:49:04 --> Helper loaded: text_helper
INFO - 2023-05-11 14:49:04 --> Helper loaded: form_helper
INFO - 2023-05-11 14:49:04 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:49:04 --> Helper loaded: security_helper
INFO - 2023-05-11 14:49:04 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:49:04 --> Database Driver Class Initialized
INFO - 2023-05-11 14:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:49:04 --> Parser Class Initialized
INFO - 2023-05-11 14:49:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:49:04 --> Pagination Class Initialized
INFO - 2023-05-11 14:49:04 --> Form Validation Class Initialized
INFO - 2023-05-11 14:49:04 --> Controller Class Initialized
INFO - 2023-05-11 14:49:04 --> Model Class Initialized
DEBUG - 2023-05-11 14:49:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:49:04 --> Final output sent to browser
DEBUG - 2023-05-11 14:49:04 --> Total execution time: 0.0178
ERROR - 2023-05-11 14:49:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:49:05 --> Config Class Initialized
INFO - 2023-05-11 14:49:05 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:49:05 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:49:05 --> Utf8 Class Initialized
INFO - 2023-05-11 14:49:05 --> URI Class Initialized
INFO - 2023-05-11 14:49:05 --> Router Class Initialized
INFO - 2023-05-11 14:49:05 --> Output Class Initialized
INFO - 2023-05-11 14:49:05 --> Security Class Initialized
DEBUG - 2023-05-11 14:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:49:05 --> Input Class Initialized
INFO - 2023-05-11 14:49:05 --> Language Class Initialized
INFO - 2023-05-11 14:49:05 --> Loader Class Initialized
INFO - 2023-05-11 14:49:05 --> Helper loaded: url_helper
INFO - 2023-05-11 14:49:05 --> Helper loaded: file_helper
INFO - 2023-05-11 14:49:05 --> Helper loaded: html_helper
INFO - 2023-05-11 14:49:05 --> Helper loaded: text_helper
INFO - 2023-05-11 14:49:05 --> Helper loaded: form_helper
INFO - 2023-05-11 14:49:05 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:49:05 --> Helper loaded: security_helper
INFO - 2023-05-11 14:49:05 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:49:05 --> Database Driver Class Initialized
INFO - 2023-05-11 14:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:49:05 --> Parser Class Initialized
INFO - 2023-05-11 14:49:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:49:05 --> Pagination Class Initialized
INFO - 2023-05-11 14:49:05 --> Form Validation Class Initialized
INFO - 2023-05-11 14:49:05 --> Controller Class Initialized
INFO - 2023-05-11 14:49:05 --> Model Class Initialized
DEBUG - 2023-05-11 14:49:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:49:05 --> Final output sent to browser
DEBUG - 2023-05-11 14:49:05 --> Total execution time: 0.0155
ERROR - 2023-05-11 14:49:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:49:07 --> Config Class Initialized
INFO - 2023-05-11 14:49:07 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:49:07 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:49:07 --> Utf8 Class Initialized
INFO - 2023-05-11 14:49:07 --> URI Class Initialized
INFO - 2023-05-11 14:49:07 --> Router Class Initialized
INFO - 2023-05-11 14:49:07 --> Output Class Initialized
INFO - 2023-05-11 14:49:07 --> Security Class Initialized
DEBUG - 2023-05-11 14:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:49:07 --> Input Class Initialized
INFO - 2023-05-11 14:49:07 --> Language Class Initialized
INFO - 2023-05-11 14:49:07 --> Loader Class Initialized
INFO - 2023-05-11 14:49:07 --> Helper loaded: url_helper
INFO - 2023-05-11 14:49:07 --> Helper loaded: file_helper
INFO - 2023-05-11 14:49:07 --> Helper loaded: html_helper
INFO - 2023-05-11 14:49:07 --> Helper loaded: text_helper
INFO - 2023-05-11 14:49:07 --> Helper loaded: form_helper
INFO - 2023-05-11 14:49:07 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:49:07 --> Helper loaded: security_helper
INFO - 2023-05-11 14:49:07 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:49:07 --> Database Driver Class Initialized
INFO - 2023-05-11 14:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:49:07 --> Parser Class Initialized
INFO - 2023-05-11 14:49:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:49:07 --> Pagination Class Initialized
INFO - 2023-05-11 14:49:07 --> Form Validation Class Initialized
INFO - 2023-05-11 14:49:07 --> Controller Class Initialized
INFO - 2023-05-11 14:49:07 --> Model Class Initialized
DEBUG - 2023-05-11 14:49:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:49:07 --> Final output sent to browser
DEBUG - 2023-05-11 14:49:07 --> Total execution time: 0.0189
ERROR - 2023-05-11 14:49:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:49:08 --> Config Class Initialized
INFO - 2023-05-11 14:49:08 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:49:08 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:49:08 --> Utf8 Class Initialized
INFO - 2023-05-11 14:49:08 --> URI Class Initialized
INFO - 2023-05-11 14:49:08 --> Router Class Initialized
INFO - 2023-05-11 14:49:08 --> Output Class Initialized
INFO - 2023-05-11 14:49:08 --> Security Class Initialized
DEBUG - 2023-05-11 14:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:49:08 --> Input Class Initialized
INFO - 2023-05-11 14:49:08 --> Language Class Initialized
INFO - 2023-05-11 14:49:08 --> Loader Class Initialized
INFO - 2023-05-11 14:49:08 --> Helper loaded: url_helper
INFO - 2023-05-11 14:49:08 --> Helper loaded: file_helper
INFO - 2023-05-11 14:49:08 --> Helper loaded: html_helper
INFO - 2023-05-11 14:49:08 --> Helper loaded: text_helper
INFO - 2023-05-11 14:49:08 --> Helper loaded: form_helper
INFO - 2023-05-11 14:49:08 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:49:08 --> Helper loaded: security_helper
INFO - 2023-05-11 14:49:08 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:49:08 --> Database Driver Class Initialized
INFO - 2023-05-11 14:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:49:08 --> Parser Class Initialized
INFO - 2023-05-11 14:49:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:49:08 --> Pagination Class Initialized
INFO - 2023-05-11 14:49:08 --> Form Validation Class Initialized
INFO - 2023-05-11 14:49:08 --> Controller Class Initialized
INFO - 2023-05-11 14:49:08 --> Model Class Initialized
DEBUG - 2023-05-11 14:49:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:49:08 --> Final output sent to browser
DEBUG - 2023-05-11 14:49:08 --> Total execution time: 0.0144
ERROR - 2023-05-11 14:49:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:49:08 --> Config Class Initialized
INFO - 2023-05-11 14:49:08 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:49:08 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:49:08 --> Utf8 Class Initialized
INFO - 2023-05-11 14:49:08 --> URI Class Initialized
INFO - 2023-05-11 14:49:08 --> Router Class Initialized
INFO - 2023-05-11 14:49:08 --> Output Class Initialized
INFO - 2023-05-11 14:49:08 --> Security Class Initialized
DEBUG - 2023-05-11 14:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:49:08 --> Input Class Initialized
INFO - 2023-05-11 14:49:08 --> Language Class Initialized
INFO - 2023-05-11 14:49:08 --> Loader Class Initialized
INFO - 2023-05-11 14:49:08 --> Helper loaded: url_helper
INFO - 2023-05-11 14:49:08 --> Helper loaded: file_helper
INFO - 2023-05-11 14:49:08 --> Helper loaded: html_helper
INFO - 2023-05-11 14:49:08 --> Helper loaded: text_helper
INFO - 2023-05-11 14:49:08 --> Helper loaded: form_helper
INFO - 2023-05-11 14:49:08 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:49:08 --> Helper loaded: security_helper
INFO - 2023-05-11 14:49:08 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:49:08 --> Database Driver Class Initialized
INFO - 2023-05-11 14:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:49:08 --> Parser Class Initialized
INFO - 2023-05-11 14:49:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:49:08 --> Pagination Class Initialized
INFO - 2023-05-11 14:49:08 --> Form Validation Class Initialized
INFO - 2023-05-11 14:49:08 --> Controller Class Initialized
INFO - 2023-05-11 14:49:08 --> Model Class Initialized
DEBUG - 2023-05-11 14:49:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:49:08 --> Final output sent to browser
DEBUG - 2023-05-11 14:49:08 --> Total execution time: 0.0141
ERROR - 2023-05-11 14:49:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:49:10 --> Config Class Initialized
INFO - 2023-05-11 14:49:10 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:49:10 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:49:10 --> Utf8 Class Initialized
INFO - 2023-05-11 14:49:10 --> URI Class Initialized
INFO - 2023-05-11 14:49:10 --> Router Class Initialized
INFO - 2023-05-11 14:49:10 --> Output Class Initialized
INFO - 2023-05-11 14:49:10 --> Security Class Initialized
DEBUG - 2023-05-11 14:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:49:10 --> Input Class Initialized
INFO - 2023-05-11 14:49:10 --> Language Class Initialized
INFO - 2023-05-11 14:49:10 --> Loader Class Initialized
INFO - 2023-05-11 14:49:10 --> Helper loaded: url_helper
INFO - 2023-05-11 14:49:10 --> Helper loaded: file_helper
INFO - 2023-05-11 14:49:10 --> Helper loaded: html_helper
INFO - 2023-05-11 14:49:10 --> Helper loaded: text_helper
INFO - 2023-05-11 14:49:10 --> Helper loaded: form_helper
INFO - 2023-05-11 14:49:10 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:49:10 --> Helper loaded: security_helper
INFO - 2023-05-11 14:49:10 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:49:10 --> Database Driver Class Initialized
INFO - 2023-05-11 14:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:49:10 --> Parser Class Initialized
INFO - 2023-05-11 14:49:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:49:10 --> Pagination Class Initialized
INFO - 2023-05-11 14:49:10 --> Form Validation Class Initialized
INFO - 2023-05-11 14:49:10 --> Controller Class Initialized
INFO - 2023-05-11 14:49:10 --> Model Class Initialized
DEBUG - 2023-05-11 14:49:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:49:10 --> Final output sent to browser
DEBUG - 2023-05-11 14:49:10 --> Total execution time: 0.0152
ERROR - 2023-05-11 14:49:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:49:12 --> Config Class Initialized
INFO - 2023-05-11 14:49:12 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:49:12 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:49:12 --> Utf8 Class Initialized
INFO - 2023-05-11 14:49:12 --> URI Class Initialized
INFO - 2023-05-11 14:49:12 --> Router Class Initialized
INFO - 2023-05-11 14:49:12 --> Output Class Initialized
INFO - 2023-05-11 14:49:12 --> Security Class Initialized
DEBUG - 2023-05-11 14:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:49:12 --> Input Class Initialized
INFO - 2023-05-11 14:49:12 --> Language Class Initialized
INFO - 2023-05-11 14:49:12 --> Loader Class Initialized
INFO - 2023-05-11 14:49:12 --> Helper loaded: url_helper
INFO - 2023-05-11 14:49:12 --> Helper loaded: file_helper
INFO - 2023-05-11 14:49:12 --> Helper loaded: html_helper
INFO - 2023-05-11 14:49:12 --> Helper loaded: text_helper
INFO - 2023-05-11 14:49:12 --> Helper loaded: form_helper
INFO - 2023-05-11 14:49:12 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:49:12 --> Helper loaded: security_helper
INFO - 2023-05-11 14:49:12 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:49:12 --> Database Driver Class Initialized
INFO - 2023-05-11 14:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:49:12 --> Parser Class Initialized
INFO - 2023-05-11 14:49:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:49:12 --> Pagination Class Initialized
INFO - 2023-05-11 14:49:12 --> Form Validation Class Initialized
INFO - 2023-05-11 14:49:12 --> Controller Class Initialized
INFO - 2023-05-11 14:49:12 --> Final output sent to browser
DEBUG - 2023-05-11 14:49:12 --> Total execution time: 0.0137
ERROR - 2023-05-11 14:51:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:51:05 --> Config Class Initialized
INFO - 2023-05-11 14:51:05 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:51:05 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:51:05 --> Utf8 Class Initialized
INFO - 2023-05-11 14:51:05 --> URI Class Initialized
INFO - 2023-05-11 14:51:05 --> Router Class Initialized
INFO - 2023-05-11 14:51:05 --> Output Class Initialized
INFO - 2023-05-11 14:51:05 --> Security Class Initialized
DEBUG - 2023-05-11 14:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:51:05 --> Input Class Initialized
INFO - 2023-05-11 14:51:05 --> Language Class Initialized
INFO - 2023-05-11 14:51:05 --> Loader Class Initialized
INFO - 2023-05-11 14:51:05 --> Helper loaded: url_helper
INFO - 2023-05-11 14:51:05 --> Helper loaded: file_helper
INFO - 2023-05-11 14:51:05 --> Helper loaded: html_helper
INFO - 2023-05-11 14:51:05 --> Helper loaded: text_helper
INFO - 2023-05-11 14:51:05 --> Helper loaded: form_helper
INFO - 2023-05-11 14:51:05 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:51:05 --> Helper loaded: security_helper
INFO - 2023-05-11 14:51:05 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:51:05 --> Database Driver Class Initialized
INFO - 2023-05-11 14:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:51:05 --> Parser Class Initialized
INFO - 2023-05-11 14:51:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:51:05 --> Pagination Class Initialized
INFO - 2023-05-11 14:51:05 --> Form Validation Class Initialized
INFO - 2023-05-11 14:51:05 --> Controller Class Initialized
INFO - 2023-05-11 14:51:05 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:05 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:05 --> Model Class Initialized
INFO - 2023-05-11 14:51:05 --> Final output sent to browser
DEBUG - 2023-05-11 14:51:05 --> Total execution time: 0.0379
ERROR - 2023-05-11 14:51:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:51:06 --> Config Class Initialized
INFO - 2023-05-11 14:51:06 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:51:06 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:51:06 --> Utf8 Class Initialized
INFO - 2023-05-11 14:51:06 --> URI Class Initialized
INFO - 2023-05-11 14:51:06 --> Router Class Initialized
INFO - 2023-05-11 14:51:06 --> Output Class Initialized
INFO - 2023-05-11 14:51:06 --> Security Class Initialized
DEBUG - 2023-05-11 14:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:51:06 --> Input Class Initialized
INFO - 2023-05-11 14:51:06 --> Language Class Initialized
INFO - 2023-05-11 14:51:06 --> Loader Class Initialized
INFO - 2023-05-11 14:51:06 --> Helper loaded: url_helper
INFO - 2023-05-11 14:51:06 --> Helper loaded: file_helper
INFO - 2023-05-11 14:51:06 --> Helper loaded: html_helper
INFO - 2023-05-11 14:51:06 --> Helper loaded: text_helper
INFO - 2023-05-11 14:51:06 --> Helper loaded: form_helper
INFO - 2023-05-11 14:51:06 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:51:06 --> Helper loaded: security_helper
INFO - 2023-05-11 14:51:06 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:51:06 --> Database Driver Class Initialized
INFO - 2023-05-11 14:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:51:06 --> Parser Class Initialized
INFO - 2023-05-11 14:51:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:51:06 --> Pagination Class Initialized
INFO - 2023-05-11 14:51:06 --> Form Validation Class Initialized
INFO - 2023-05-11 14:51:06 --> Controller Class Initialized
INFO - 2023-05-11 14:51:06 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:51:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:06 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:06 --> Model Class Initialized
INFO - 2023-05-11 14:51:06 --> Final output sent to browser
DEBUG - 2023-05-11 14:51:06 --> Total execution time: 0.0333
ERROR - 2023-05-11 14:51:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:51:06 --> Config Class Initialized
INFO - 2023-05-11 14:51:06 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:51:06 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:51:06 --> Utf8 Class Initialized
INFO - 2023-05-11 14:51:06 --> URI Class Initialized
INFO - 2023-05-11 14:51:06 --> Router Class Initialized
INFO - 2023-05-11 14:51:06 --> Output Class Initialized
INFO - 2023-05-11 14:51:06 --> Security Class Initialized
DEBUG - 2023-05-11 14:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:51:06 --> Input Class Initialized
INFO - 2023-05-11 14:51:06 --> Language Class Initialized
INFO - 2023-05-11 14:51:06 --> Loader Class Initialized
INFO - 2023-05-11 14:51:06 --> Helper loaded: url_helper
INFO - 2023-05-11 14:51:06 --> Helper loaded: file_helper
INFO - 2023-05-11 14:51:06 --> Helper loaded: html_helper
INFO - 2023-05-11 14:51:06 --> Helper loaded: text_helper
INFO - 2023-05-11 14:51:06 --> Helper loaded: form_helper
INFO - 2023-05-11 14:51:06 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:51:06 --> Helper loaded: security_helper
INFO - 2023-05-11 14:51:06 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:51:06 --> Database Driver Class Initialized
INFO - 2023-05-11 14:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:51:06 --> Parser Class Initialized
INFO - 2023-05-11 14:51:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:51:06 --> Pagination Class Initialized
INFO - 2023-05-11 14:51:06 --> Form Validation Class Initialized
INFO - 2023-05-11 14:51:06 --> Controller Class Initialized
INFO - 2023-05-11 14:51:06 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:51:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:06 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:06 --> Model Class Initialized
INFO - 2023-05-11 14:51:06 --> Final output sent to browser
DEBUG - 2023-05-11 14:51:06 --> Total execution time: 0.0350
ERROR - 2023-05-11 14:51:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:51:09 --> Config Class Initialized
INFO - 2023-05-11 14:51:09 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:51:09 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:51:09 --> Utf8 Class Initialized
INFO - 2023-05-11 14:51:09 --> URI Class Initialized
INFO - 2023-05-11 14:51:09 --> Router Class Initialized
INFO - 2023-05-11 14:51:09 --> Output Class Initialized
INFO - 2023-05-11 14:51:09 --> Security Class Initialized
DEBUG - 2023-05-11 14:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:51:09 --> Input Class Initialized
INFO - 2023-05-11 14:51:09 --> Language Class Initialized
INFO - 2023-05-11 14:51:09 --> Loader Class Initialized
INFO - 2023-05-11 14:51:09 --> Helper loaded: url_helper
INFO - 2023-05-11 14:51:09 --> Helper loaded: file_helper
INFO - 2023-05-11 14:51:09 --> Helper loaded: html_helper
INFO - 2023-05-11 14:51:09 --> Helper loaded: text_helper
INFO - 2023-05-11 14:51:09 --> Helper loaded: form_helper
INFO - 2023-05-11 14:51:09 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:51:09 --> Helper loaded: security_helper
INFO - 2023-05-11 14:51:09 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:51:09 --> Database Driver Class Initialized
INFO - 2023-05-11 14:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:51:09 --> Parser Class Initialized
INFO - 2023-05-11 14:51:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:51:09 --> Pagination Class Initialized
INFO - 2023-05-11 14:51:09 --> Form Validation Class Initialized
INFO - 2023-05-11 14:51:09 --> Controller Class Initialized
INFO - 2023-05-11 14:51:09 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:51:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:09 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:09 --> Model Class Initialized
INFO - 2023-05-11 14:51:09 --> Final output sent to browser
DEBUG - 2023-05-11 14:51:09 --> Total execution time: 0.0342
ERROR - 2023-05-11 14:51:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:51:10 --> Config Class Initialized
INFO - 2023-05-11 14:51:10 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:51:10 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:51:10 --> Utf8 Class Initialized
INFO - 2023-05-11 14:51:10 --> URI Class Initialized
INFO - 2023-05-11 14:51:10 --> Router Class Initialized
INFO - 2023-05-11 14:51:10 --> Output Class Initialized
INFO - 2023-05-11 14:51:10 --> Security Class Initialized
DEBUG - 2023-05-11 14:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:51:10 --> Input Class Initialized
INFO - 2023-05-11 14:51:10 --> Language Class Initialized
INFO - 2023-05-11 14:51:10 --> Loader Class Initialized
INFO - 2023-05-11 14:51:10 --> Helper loaded: url_helper
INFO - 2023-05-11 14:51:10 --> Helper loaded: file_helper
INFO - 2023-05-11 14:51:10 --> Helper loaded: html_helper
INFO - 2023-05-11 14:51:10 --> Helper loaded: text_helper
INFO - 2023-05-11 14:51:10 --> Helper loaded: form_helper
INFO - 2023-05-11 14:51:10 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:51:10 --> Helper loaded: security_helper
INFO - 2023-05-11 14:51:10 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:51:10 --> Database Driver Class Initialized
INFO - 2023-05-11 14:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:51:10 --> Parser Class Initialized
INFO - 2023-05-11 14:51:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:51:10 --> Pagination Class Initialized
INFO - 2023-05-11 14:51:10 --> Form Validation Class Initialized
INFO - 2023-05-11 14:51:10 --> Controller Class Initialized
INFO - 2023-05-11 14:51:10 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:10 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:10 --> Model Class Initialized
INFO - 2023-05-11 14:51:10 --> Final output sent to browser
DEBUG - 2023-05-11 14:51:10 --> Total execution time: 0.0388
ERROR - 2023-05-11 14:51:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:51:19 --> Config Class Initialized
INFO - 2023-05-11 14:51:19 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:51:19 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:51:19 --> Utf8 Class Initialized
INFO - 2023-05-11 14:51:19 --> URI Class Initialized
INFO - 2023-05-11 14:51:19 --> Router Class Initialized
INFO - 2023-05-11 14:51:19 --> Output Class Initialized
INFO - 2023-05-11 14:51:19 --> Security Class Initialized
DEBUG - 2023-05-11 14:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:51:19 --> Input Class Initialized
INFO - 2023-05-11 14:51:19 --> Language Class Initialized
INFO - 2023-05-11 14:51:19 --> Loader Class Initialized
INFO - 2023-05-11 14:51:19 --> Helper loaded: url_helper
INFO - 2023-05-11 14:51:19 --> Helper loaded: file_helper
INFO - 2023-05-11 14:51:19 --> Helper loaded: html_helper
INFO - 2023-05-11 14:51:19 --> Helper loaded: text_helper
INFO - 2023-05-11 14:51:19 --> Helper loaded: form_helper
INFO - 2023-05-11 14:51:19 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:51:19 --> Helper loaded: security_helper
INFO - 2023-05-11 14:51:19 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:51:19 --> Database Driver Class Initialized
INFO - 2023-05-11 14:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:51:19 --> Parser Class Initialized
INFO - 2023-05-11 14:51:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:51:19 --> Pagination Class Initialized
INFO - 2023-05-11 14:51:19 --> Form Validation Class Initialized
INFO - 2023-05-11 14:51:19 --> Controller Class Initialized
INFO - 2023-05-11 14:51:19 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:51:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:19 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:19 --> Model Class Initialized
INFO - 2023-05-11 14:51:19 --> Final output sent to browser
DEBUG - 2023-05-11 14:51:19 --> Total execution time: 0.0247
ERROR - 2023-05-11 14:51:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:51:26 --> Config Class Initialized
INFO - 2023-05-11 14:51:26 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:51:26 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:51:26 --> Utf8 Class Initialized
INFO - 2023-05-11 14:51:26 --> URI Class Initialized
INFO - 2023-05-11 14:51:26 --> Router Class Initialized
INFO - 2023-05-11 14:51:26 --> Output Class Initialized
INFO - 2023-05-11 14:51:26 --> Security Class Initialized
DEBUG - 2023-05-11 14:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:51:26 --> Input Class Initialized
INFO - 2023-05-11 14:51:26 --> Language Class Initialized
INFO - 2023-05-11 14:51:26 --> Loader Class Initialized
INFO - 2023-05-11 14:51:26 --> Helper loaded: url_helper
INFO - 2023-05-11 14:51:26 --> Helper loaded: file_helper
INFO - 2023-05-11 14:51:26 --> Helper loaded: html_helper
INFO - 2023-05-11 14:51:26 --> Helper loaded: text_helper
INFO - 2023-05-11 14:51:26 --> Helper loaded: form_helper
INFO - 2023-05-11 14:51:26 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:51:26 --> Helper loaded: security_helper
INFO - 2023-05-11 14:51:26 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:51:26 --> Database Driver Class Initialized
INFO - 2023-05-11 14:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:51:26 --> Parser Class Initialized
INFO - 2023-05-11 14:51:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:51:26 --> Pagination Class Initialized
INFO - 2023-05-11 14:51:26 --> Form Validation Class Initialized
INFO - 2023-05-11 14:51:26 --> Controller Class Initialized
INFO - 2023-05-11 14:51:26 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:51:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:26 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:26 --> Model Class Initialized
INFO - 2023-05-11 14:51:26 --> Final output sent to browser
DEBUG - 2023-05-11 14:51:26 --> Total execution time: 0.0392
ERROR - 2023-05-11 14:51:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:51:27 --> Config Class Initialized
INFO - 2023-05-11 14:51:27 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:51:27 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:51:27 --> Utf8 Class Initialized
INFO - 2023-05-11 14:51:27 --> URI Class Initialized
INFO - 2023-05-11 14:51:27 --> Router Class Initialized
INFO - 2023-05-11 14:51:27 --> Output Class Initialized
INFO - 2023-05-11 14:51:27 --> Security Class Initialized
DEBUG - 2023-05-11 14:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:51:27 --> Input Class Initialized
INFO - 2023-05-11 14:51:27 --> Language Class Initialized
INFO - 2023-05-11 14:51:27 --> Loader Class Initialized
INFO - 2023-05-11 14:51:27 --> Helper loaded: url_helper
INFO - 2023-05-11 14:51:27 --> Helper loaded: file_helper
INFO - 2023-05-11 14:51:27 --> Helper loaded: html_helper
INFO - 2023-05-11 14:51:27 --> Helper loaded: text_helper
INFO - 2023-05-11 14:51:27 --> Helper loaded: form_helper
INFO - 2023-05-11 14:51:27 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:51:27 --> Helper loaded: security_helper
INFO - 2023-05-11 14:51:27 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:51:27 --> Database Driver Class Initialized
INFO - 2023-05-11 14:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:51:27 --> Parser Class Initialized
INFO - 2023-05-11 14:51:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:51:27 --> Pagination Class Initialized
INFO - 2023-05-11 14:51:27 --> Form Validation Class Initialized
INFO - 2023-05-11 14:51:27 --> Controller Class Initialized
INFO - 2023-05-11 14:51:27 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:51:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:27 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:27 --> Model Class Initialized
INFO - 2023-05-11 14:51:27 --> Final output sent to browser
DEBUG - 2023-05-11 14:51:27 --> Total execution time: 0.0348
ERROR - 2023-05-11 14:51:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:51:28 --> Config Class Initialized
INFO - 2023-05-11 14:51:28 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:51:28 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:51:28 --> Utf8 Class Initialized
INFO - 2023-05-11 14:51:28 --> URI Class Initialized
INFO - 2023-05-11 14:51:28 --> Router Class Initialized
INFO - 2023-05-11 14:51:28 --> Output Class Initialized
INFO - 2023-05-11 14:51:28 --> Security Class Initialized
DEBUG - 2023-05-11 14:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:51:28 --> Input Class Initialized
INFO - 2023-05-11 14:51:28 --> Language Class Initialized
INFO - 2023-05-11 14:51:28 --> Loader Class Initialized
INFO - 2023-05-11 14:51:28 --> Helper loaded: url_helper
INFO - 2023-05-11 14:51:28 --> Helper loaded: file_helper
INFO - 2023-05-11 14:51:28 --> Helper loaded: html_helper
INFO - 2023-05-11 14:51:28 --> Helper loaded: text_helper
INFO - 2023-05-11 14:51:28 --> Helper loaded: form_helper
INFO - 2023-05-11 14:51:28 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:51:28 --> Helper loaded: security_helper
INFO - 2023-05-11 14:51:28 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:51:28 --> Database Driver Class Initialized
INFO - 2023-05-11 14:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:51:28 --> Parser Class Initialized
INFO - 2023-05-11 14:51:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:51:28 --> Pagination Class Initialized
INFO - 2023-05-11 14:51:28 --> Form Validation Class Initialized
INFO - 2023-05-11 14:51:28 --> Controller Class Initialized
INFO - 2023-05-11 14:51:28 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:28 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:28 --> Model Class Initialized
INFO - 2023-05-11 14:51:28 --> Final output sent to browser
DEBUG - 2023-05-11 14:51:28 --> Total execution time: 0.0339
ERROR - 2023-05-11 14:51:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:51:28 --> Config Class Initialized
INFO - 2023-05-11 14:51:28 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:51:28 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:51:28 --> Utf8 Class Initialized
INFO - 2023-05-11 14:51:28 --> URI Class Initialized
INFO - 2023-05-11 14:51:28 --> Router Class Initialized
INFO - 2023-05-11 14:51:28 --> Output Class Initialized
INFO - 2023-05-11 14:51:28 --> Security Class Initialized
DEBUG - 2023-05-11 14:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:51:28 --> Input Class Initialized
INFO - 2023-05-11 14:51:28 --> Language Class Initialized
INFO - 2023-05-11 14:51:28 --> Loader Class Initialized
INFO - 2023-05-11 14:51:28 --> Helper loaded: url_helper
INFO - 2023-05-11 14:51:28 --> Helper loaded: file_helper
INFO - 2023-05-11 14:51:28 --> Helper loaded: html_helper
INFO - 2023-05-11 14:51:28 --> Helper loaded: text_helper
INFO - 2023-05-11 14:51:28 --> Helper loaded: form_helper
INFO - 2023-05-11 14:51:28 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:51:28 --> Helper loaded: security_helper
INFO - 2023-05-11 14:51:28 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:51:28 --> Database Driver Class Initialized
INFO - 2023-05-11 14:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:51:28 --> Parser Class Initialized
INFO - 2023-05-11 14:51:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:51:28 --> Pagination Class Initialized
INFO - 2023-05-11 14:51:28 --> Form Validation Class Initialized
INFO - 2023-05-11 14:51:28 --> Controller Class Initialized
INFO - 2023-05-11 14:51:28 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:28 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:28 --> Model Class Initialized
INFO - 2023-05-11 14:51:28 --> Final output sent to browser
DEBUG - 2023-05-11 14:51:28 --> Total execution time: 0.0365
ERROR - 2023-05-11 14:51:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:51:29 --> Config Class Initialized
INFO - 2023-05-11 14:51:29 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:51:29 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:51:29 --> Utf8 Class Initialized
INFO - 2023-05-11 14:51:29 --> URI Class Initialized
INFO - 2023-05-11 14:51:29 --> Router Class Initialized
INFO - 2023-05-11 14:51:29 --> Output Class Initialized
INFO - 2023-05-11 14:51:29 --> Security Class Initialized
DEBUG - 2023-05-11 14:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:51:29 --> Input Class Initialized
INFO - 2023-05-11 14:51:29 --> Language Class Initialized
INFO - 2023-05-11 14:51:29 --> Loader Class Initialized
INFO - 2023-05-11 14:51:29 --> Helper loaded: url_helper
INFO - 2023-05-11 14:51:29 --> Helper loaded: file_helper
INFO - 2023-05-11 14:51:29 --> Helper loaded: html_helper
INFO - 2023-05-11 14:51:29 --> Helper loaded: text_helper
INFO - 2023-05-11 14:51:29 --> Helper loaded: form_helper
INFO - 2023-05-11 14:51:29 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:51:29 --> Helper loaded: security_helper
INFO - 2023-05-11 14:51:29 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:51:29 --> Database Driver Class Initialized
INFO - 2023-05-11 14:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:51:29 --> Parser Class Initialized
INFO - 2023-05-11 14:51:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:51:29 --> Pagination Class Initialized
INFO - 2023-05-11 14:51:29 --> Form Validation Class Initialized
INFO - 2023-05-11 14:51:29 --> Controller Class Initialized
INFO - 2023-05-11 14:51:29 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:51:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:29 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:29 --> Model Class Initialized
INFO - 2023-05-11 14:51:29 --> Final output sent to browser
DEBUG - 2023-05-11 14:51:29 --> Total execution time: 0.0408
ERROR - 2023-05-11 14:51:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:51:30 --> Config Class Initialized
INFO - 2023-05-11 14:51:30 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:51:30 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:51:30 --> Utf8 Class Initialized
INFO - 2023-05-11 14:51:30 --> URI Class Initialized
INFO - 2023-05-11 14:51:30 --> Router Class Initialized
INFO - 2023-05-11 14:51:30 --> Output Class Initialized
INFO - 2023-05-11 14:51:30 --> Security Class Initialized
DEBUG - 2023-05-11 14:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:51:30 --> Input Class Initialized
INFO - 2023-05-11 14:51:30 --> Language Class Initialized
INFO - 2023-05-11 14:51:30 --> Loader Class Initialized
INFO - 2023-05-11 14:51:30 --> Helper loaded: url_helper
INFO - 2023-05-11 14:51:30 --> Helper loaded: file_helper
INFO - 2023-05-11 14:51:30 --> Helper loaded: html_helper
INFO - 2023-05-11 14:51:30 --> Helper loaded: text_helper
INFO - 2023-05-11 14:51:30 --> Helper loaded: form_helper
INFO - 2023-05-11 14:51:30 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:51:30 --> Helper loaded: security_helper
INFO - 2023-05-11 14:51:30 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:51:30 --> Database Driver Class Initialized
INFO - 2023-05-11 14:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:51:30 --> Parser Class Initialized
INFO - 2023-05-11 14:51:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:51:30 --> Pagination Class Initialized
INFO - 2023-05-11 14:51:30 --> Form Validation Class Initialized
INFO - 2023-05-11 14:51:30 --> Controller Class Initialized
INFO - 2023-05-11 14:51:30 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:51:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:30 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:30 --> Model Class Initialized
INFO - 2023-05-11 14:51:30 --> Final output sent to browser
DEBUG - 2023-05-11 14:51:30 --> Total execution time: 0.0188
ERROR - 2023-05-11 14:51:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:51:31 --> Config Class Initialized
INFO - 2023-05-11 14:51:31 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:51:31 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:51:31 --> Utf8 Class Initialized
INFO - 2023-05-11 14:51:31 --> URI Class Initialized
INFO - 2023-05-11 14:51:31 --> Router Class Initialized
INFO - 2023-05-11 14:51:31 --> Output Class Initialized
INFO - 2023-05-11 14:51:31 --> Security Class Initialized
DEBUG - 2023-05-11 14:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:51:31 --> Input Class Initialized
INFO - 2023-05-11 14:51:31 --> Language Class Initialized
INFO - 2023-05-11 14:51:31 --> Loader Class Initialized
INFO - 2023-05-11 14:51:31 --> Helper loaded: url_helper
INFO - 2023-05-11 14:51:31 --> Helper loaded: file_helper
INFO - 2023-05-11 14:51:31 --> Helper loaded: html_helper
INFO - 2023-05-11 14:51:31 --> Helper loaded: text_helper
INFO - 2023-05-11 14:51:31 --> Helper loaded: form_helper
INFO - 2023-05-11 14:51:31 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:51:31 --> Helper loaded: security_helper
INFO - 2023-05-11 14:51:31 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:51:31 --> Database Driver Class Initialized
INFO - 2023-05-11 14:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:51:31 --> Parser Class Initialized
INFO - 2023-05-11 14:51:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:51:31 --> Pagination Class Initialized
INFO - 2023-05-11 14:51:31 --> Form Validation Class Initialized
INFO - 2023-05-11 14:51:31 --> Controller Class Initialized
INFO - 2023-05-11 14:51:31 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:51:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:31 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:31 --> Model Class Initialized
INFO - 2023-05-11 14:51:31 --> Final output sent to browser
DEBUG - 2023-05-11 14:51:31 --> Total execution time: 0.0177
ERROR - 2023-05-11 14:51:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:51:34 --> Config Class Initialized
INFO - 2023-05-11 14:51:34 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:51:34 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:51:34 --> Utf8 Class Initialized
INFO - 2023-05-11 14:51:34 --> URI Class Initialized
INFO - 2023-05-11 14:51:34 --> Router Class Initialized
INFO - 2023-05-11 14:51:34 --> Output Class Initialized
INFO - 2023-05-11 14:51:34 --> Security Class Initialized
DEBUG - 2023-05-11 14:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:51:34 --> Input Class Initialized
INFO - 2023-05-11 14:51:34 --> Language Class Initialized
INFO - 2023-05-11 14:51:34 --> Loader Class Initialized
INFO - 2023-05-11 14:51:34 --> Helper loaded: url_helper
INFO - 2023-05-11 14:51:34 --> Helper loaded: file_helper
INFO - 2023-05-11 14:51:34 --> Helper loaded: html_helper
INFO - 2023-05-11 14:51:34 --> Helper loaded: text_helper
INFO - 2023-05-11 14:51:34 --> Helper loaded: form_helper
INFO - 2023-05-11 14:51:34 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:51:34 --> Helper loaded: security_helper
INFO - 2023-05-11 14:51:34 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:51:34 --> Database Driver Class Initialized
INFO - 2023-05-11 14:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:51:34 --> Parser Class Initialized
INFO - 2023-05-11 14:51:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:51:34 --> Pagination Class Initialized
INFO - 2023-05-11 14:51:34 --> Form Validation Class Initialized
INFO - 2023-05-11 14:51:34 --> Controller Class Initialized
INFO - 2023-05-11 14:51:34 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:51:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:34 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:34 --> Model Class Initialized
INFO - 2023-05-11 14:51:34 --> Final output sent to browser
DEBUG - 2023-05-11 14:51:34 --> Total execution time: 0.0186
ERROR - 2023-05-11 14:51:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:51:36 --> Config Class Initialized
INFO - 2023-05-11 14:51:36 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:51:36 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:51:36 --> Utf8 Class Initialized
INFO - 2023-05-11 14:51:36 --> URI Class Initialized
INFO - 2023-05-11 14:51:36 --> Router Class Initialized
INFO - 2023-05-11 14:51:36 --> Output Class Initialized
INFO - 2023-05-11 14:51:36 --> Security Class Initialized
DEBUG - 2023-05-11 14:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:51:36 --> Input Class Initialized
INFO - 2023-05-11 14:51:36 --> Language Class Initialized
INFO - 2023-05-11 14:51:36 --> Loader Class Initialized
INFO - 2023-05-11 14:51:36 --> Helper loaded: url_helper
INFO - 2023-05-11 14:51:36 --> Helper loaded: file_helper
INFO - 2023-05-11 14:51:36 --> Helper loaded: html_helper
INFO - 2023-05-11 14:51:36 --> Helper loaded: text_helper
INFO - 2023-05-11 14:51:36 --> Helper loaded: form_helper
INFO - 2023-05-11 14:51:36 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:51:36 --> Helper loaded: security_helper
INFO - 2023-05-11 14:51:36 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:51:36 --> Database Driver Class Initialized
INFO - 2023-05-11 14:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:51:36 --> Parser Class Initialized
INFO - 2023-05-11 14:51:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:51:36 --> Pagination Class Initialized
INFO - 2023-05-11 14:51:36 --> Form Validation Class Initialized
INFO - 2023-05-11 14:51:36 --> Controller Class Initialized
INFO - 2023-05-11 14:51:36 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:51:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:36 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:36 --> Model Class Initialized
INFO - 2023-05-11 14:51:36 --> Final output sent to browser
DEBUG - 2023-05-11 14:51:36 --> Total execution time: 0.0169
ERROR - 2023-05-11 14:51:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:51:38 --> Config Class Initialized
INFO - 2023-05-11 14:51:38 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:51:38 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:51:38 --> Utf8 Class Initialized
INFO - 2023-05-11 14:51:38 --> URI Class Initialized
INFO - 2023-05-11 14:51:38 --> Router Class Initialized
INFO - 2023-05-11 14:51:38 --> Output Class Initialized
INFO - 2023-05-11 14:51:38 --> Security Class Initialized
DEBUG - 2023-05-11 14:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:51:38 --> Input Class Initialized
INFO - 2023-05-11 14:51:38 --> Language Class Initialized
INFO - 2023-05-11 14:51:38 --> Loader Class Initialized
INFO - 2023-05-11 14:51:38 --> Helper loaded: url_helper
INFO - 2023-05-11 14:51:38 --> Helper loaded: file_helper
INFO - 2023-05-11 14:51:38 --> Helper loaded: html_helper
INFO - 2023-05-11 14:51:38 --> Helper loaded: text_helper
INFO - 2023-05-11 14:51:38 --> Helper loaded: form_helper
INFO - 2023-05-11 14:51:38 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:51:38 --> Helper loaded: security_helper
INFO - 2023-05-11 14:51:38 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:51:38 --> Database Driver Class Initialized
INFO - 2023-05-11 14:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:51:38 --> Parser Class Initialized
INFO - 2023-05-11 14:51:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:51:38 --> Pagination Class Initialized
INFO - 2023-05-11 14:51:38 --> Form Validation Class Initialized
INFO - 2023-05-11 14:51:38 --> Controller Class Initialized
INFO - 2023-05-11 14:51:38 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:51:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:38 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:38 --> Model Class Initialized
INFO - 2023-05-11 14:51:38 --> Final output sent to browser
DEBUG - 2023-05-11 14:51:38 --> Total execution time: 0.0351
ERROR - 2023-05-11 14:51:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:51:39 --> Config Class Initialized
INFO - 2023-05-11 14:51:39 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:51:39 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:51:39 --> Utf8 Class Initialized
INFO - 2023-05-11 14:51:39 --> URI Class Initialized
INFO - 2023-05-11 14:51:39 --> Router Class Initialized
INFO - 2023-05-11 14:51:39 --> Output Class Initialized
INFO - 2023-05-11 14:51:39 --> Security Class Initialized
DEBUG - 2023-05-11 14:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:51:39 --> Input Class Initialized
INFO - 2023-05-11 14:51:39 --> Language Class Initialized
INFO - 2023-05-11 14:51:39 --> Loader Class Initialized
INFO - 2023-05-11 14:51:39 --> Helper loaded: url_helper
INFO - 2023-05-11 14:51:39 --> Helper loaded: file_helper
INFO - 2023-05-11 14:51:39 --> Helper loaded: html_helper
INFO - 2023-05-11 14:51:39 --> Helper loaded: text_helper
INFO - 2023-05-11 14:51:39 --> Helper loaded: form_helper
INFO - 2023-05-11 14:51:39 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:51:39 --> Helper loaded: security_helper
INFO - 2023-05-11 14:51:39 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:51:39 --> Database Driver Class Initialized
INFO - 2023-05-11 14:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:51:39 --> Parser Class Initialized
INFO - 2023-05-11 14:51:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:51:39 --> Pagination Class Initialized
INFO - 2023-05-11 14:51:39 --> Form Validation Class Initialized
INFO - 2023-05-11 14:51:39 --> Controller Class Initialized
INFO - 2023-05-11 14:51:39 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:51:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:39 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:39 --> Model Class Initialized
INFO - 2023-05-11 14:51:39 --> Final output sent to browser
DEBUG - 2023-05-11 14:51:39 --> Total execution time: 0.0426
ERROR - 2023-05-11 14:51:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:51:39 --> Config Class Initialized
INFO - 2023-05-11 14:51:39 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:51:39 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:51:39 --> Utf8 Class Initialized
INFO - 2023-05-11 14:51:39 --> URI Class Initialized
INFO - 2023-05-11 14:51:39 --> Router Class Initialized
INFO - 2023-05-11 14:51:39 --> Output Class Initialized
INFO - 2023-05-11 14:51:39 --> Security Class Initialized
DEBUG - 2023-05-11 14:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:51:39 --> Input Class Initialized
INFO - 2023-05-11 14:51:39 --> Language Class Initialized
INFO - 2023-05-11 14:51:39 --> Loader Class Initialized
INFO - 2023-05-11 14:51:39 --> Helper loaded: url_helper
INFO - 2023-05-11 14:51:39 --> Helper loaded: file_helper
INFO - 2023-05-11 14:51:39 --> Helper loaded: html_helper
INFO - 2023-05-11 14:51:39 --> Helper loaded: text_helper
INFO - 2023-05-11 14:51:39 --> Helper loaded: form_helper
INFO - 2023-05-11 14:51:39 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:51:39 --> Helper loaded: security_helper
INFO - 2023-05-11 14:51:39 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:51:39 --> Database Driver Class Initialized
INFO - 2023-05-11 14:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:51:39 --> Parser Class Initialized
INFO - 2023-05-11 14:51:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:51:39 --> Pagination Class Initialized
INFO - 2023-05-11 14:51:39 --> Form Validation Class Initialized
INFO - 2023-05-11 14:51:39 --> Controller Class Initialized
INFO - 2023-05-11 14:51:39 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:51:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:39 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:39 --> Model Class Initialized
INFO - 2023-05-11 14:51:39 --> Final output sent to browser
DEBUG - 2023-05-11 14:51:39 --> Total execution time: 0.0346
ERROR - 2023-05-11 14:51:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:51:40 --> Config Class Initialized
INFO - 2023-05-11 14:51:40 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:51:40 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:51:40 --> Utf8 Class Initialized
INFO - 2023-05-11 14:51:40 --> URI Class Initialized
INFO - 2023-05-11 14:51:40 --> Router Class Initialized
INFO - 2023-05-11 14:51:40 --> Output Class Initialized
INFO - 2023-05-11 14:51:40 --> Security Class Initialized
DEBUG - 2023-05-11 14:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:51:40 --> Input Class Initialized
INFO - 2023-05-11 14:51:40 --> Language Class Initialized
INFO - 2023-05-11 14:51:40 --> Loader Class Initialized
INFO - 2023-05-11 14:51:40 --> Helper loaded: url_helper
INFO - 2023-05-11 14:51:40 --> Helper loaded: file_helper
INFO - 2023-05-11 14:51:40 --> Helper loaded: html_helper
INFO - 2023-05-11 14:51:40 --> Helper loaded: text_helper
INFO - 2023-05-11 14:51:40 --> Helper loaded: form_helper
INFO - 2023-05-11 14:51:40 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:51:40 --> Helper loaded: security_helper
INFO - 2023-05-11 14:51:40 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:51:40 --> Database Driver Class Initialized
INFO - 2023-05-11 14:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:51:40 --> Parser Class Initialized
INFO - 2023-05-11 14:51:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:51:40 --> Pagination Class Initialized
INFO - 2023-05-11 14:51:40 --> Form Validation Class Initialized
INFO - 2023-05-11 14:51:40 --> Controller Class Initialized
INFO - 2023-05-11 14:51:40 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:51:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:40 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:40 --> Model Class Initialized
INFO - 2023-05-11 14:51:40 --> Final output sent to browser
DEBUG - 2023-05-11 14:51:40 --> Total execution time: 0.0359
ERROR - 2023-05-11 14:51:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:51:40 --> Config Class Initialized
INFO - 2023-05-11 14:51:40 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:51:40 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:51:40 --> Utf8 Class Initialized
INFO - 2023-05-11 14:51:40 --> URI Class Initialized
INFO - 2023-05-11 14:51:40 --> Router Class Initialized
INFO - 2023-05-11 14:51:40 --> Output Class Initialized
INFO - 2023-05-11 14:51:40 --> Security Class Initialized
DEBUG - 2023-05-11 14:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:51:40 --> Input Class Initialized
INFO - 2023-05-11 14:51:40 --> Language Class Initialized
INFO - 2023-05-11 14:51:40 --> Loader Class Initialized
INFO - 2023-05-11 14:51:40 --> Helper loaded: url_helper
INFO - 2023-05-11 14:51:40 --> Helper loaded: file_helper
INFO - 2023-05-11 14:51:40 --> Helper loaded: html_helper
INFO - 2023-05-11 14:51:40 --> Helper loaded: text_helper
INFO - 2023-05-11 14:51:40 --> Helper loaded: form_helper
INFO - 2023-05-11 14:51:40 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:51:40 --> Helper loaded: security_helper
INFO - 2023-05-11 14:51:40 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:51:40 --> Database Driver Class Initialized
INFO - 2023-05-11 14:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:51:40 --> Parser Class Initialized
INFO - 2023-05-11 14:51:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:51:40 --> Pagination Class Initialized
INFO - 2023-05-11 14:51:40 --> Form Validation Class Initialized
INFO - 2023-05-11 14:51:40 --> Controller Class Initialized
INFO - 2023-05-11 14:51:40 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:51:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:40 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:40 --> Model Class Initialized
INFO - 2023-05-11 14:51:40 --> Final output sent to browser
DEBUG - 2023-05-11 14:51:40 --> Total execution time: 0.0329
ERROR - 2023-05-11 14:51:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:51:41 --> Config Class Initialized
INFO - 2023-05-11 14:51:41 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:51:41 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:51:41 --> Utf8 Class Initialized
INFO - 2023-05-11 14:51:41 --> URI Class Initialized
INFO - 2023-05-11 14:51:41 --> Router Class Initialized
INFO - 2023-05-11 14:51:41 --> Output Class Initialized
INFO - 2023-05-11 14:51:41 --> Security Class Initialized
DEBUG - 2023-05-11 14:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:51:41 --> Input Class Initialized
INFO - 2023-05-11 14:51:41 --> Language Class Initialized
INFO - 2023-05-11 14:51:41 --> Loader Class Initialized
INFO - 2023-05-11 14:51:41 --> Helper loaded: url_helper
INFO - 2023-05-11 14:51:41 --> Helper loaded: file_helper
INFO - 2023-05-11 14:51:41 --> Helper loaded: html_helper
INFO - 2023-05-11 14:51:41 --> Helper loaded: text_helper
INFO - 2023-05-11 14:51:41 --> Helper loaded: form_helper
INFO - 2023-05-11 14:51:41 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:51:41 --> Helper loaded: security_helper
INFO - 2023-05-11 14:51:41 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:51:41 --> Database Driver Class Initialized
INFO - 2023-05-11 14:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:51:41 --> Parser Class Initialized
INFO - 2023-05-11 14:51:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:51:41 --> Pagination Class Initialized
INFO - 2023-05-11 14:51:41 --> Form Validation Class Initialized
INFO - 2023-05-11 14:51:41 --> Controller Class Initialized
INFO - 2023-05-11 14:51:41 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:51:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:41 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:41 --> Model Class Initialized
INFO - 2023-05-11 14:51:41 --> Final output sent to browser
DEBUG - 2023-05-11 14:51:41 --> Total execution time: 0.0199
ERROR - 2023-05-11 14:51:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:51:43 --> Config Class Initialized
INFO - 2023-05-11 14:51:43 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:51:43 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:51:43 --> Utf8 Class Initialized
INFO - 2023-05-11 14:51:43 --> URI Class Initialized
INFO - 2023-05-11 14:51:43 --> Router Class Initialized
INFO - 2023-05-11 14:51:43 --> Output Class Initialized
INFO - 2023-05-11 14:51:43 --> Security Class Initialized
DEBUG - 2023-05-11 14:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:51:43 --> Input Class Initialized
INFO - 2023-05-11 14:51:43 --> Language Class Initialized
INFO - 2023-05-11 14:51:43 --> Loader Class Initialized
INFO - 2023-05-11 14:51:43 --> Helper loaded: url_helper
INFO - 2023-05-11 14:51:43 --> Helper loaded: file_helper
INFO - 2023-05-11 14:51:43 --> Helper loaded: html_helper
INFO - 2023-05-11 14:51:43 --> Helper loaded: text_helper
INFO - 2023-05-11 14:51:43 --> Helper loaded: form_helper
INFO - 2023-05-11 14:51:43 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:51:43 --> Helper loaded: security_helper
INFO - 2023-05-11 14:51:43 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:51:43 --> Database Driver Class Initialized
INFO - 2023-05-11 14:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:51:43 --> Parser Class Initialized
INFO - 2023-05-11 14:51:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:51:43 --> Pagination Class Initialized
INFO - 2023-05-11 14:51:43 --> Form Validation Class Initialized
INFO - 2023-05-11 14:51:43 --> Controller Class Initialized
INFO - 2023-05-11 14:51:43 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:51:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:43 --> Model Class Initialized
INFO - 2023-05-11 14:51:43 --> Model Class Initialized
INFO - 2023-05-11 14:51:43 --> Final output sent to browser
DEBUG - 2023-05-11 14:51:43 --> Total execution time: 0.0194
ERROR - 2023-05-11 14:51:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:51:46 --> Config Class Initialized
INFO - 2023-05-11 14:51:46 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:51:46 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:51:46 --> Utf8 Class Initialized
INFO - 2023-05-11 14:51:46 --> URI Class Initialized
INFO - 2023-05-11 14:51:46 --> Router Class Initialized
INFO - 2023-05-11 14:51:46 --> Output Class Initialized
INFO - 2023-05-11 14:51:46 --> Security Class Initialized
DEBUG - 2023-05-11 14:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:51:46 --> Input Class Initialized
INFO - 2023-05-11 14:51:46 --> Language Class Initialized
INFO - 2023-05-11 14:51:46 --> Loader Class Initialized
INFO - 2023-05-11 14:51:46 --> Helper loaded: url_helper
INFO - 2023-05-11 14:51:46 --> Helper loaded: file_helper
INFO - 2023-05-11 14:51:46 --> Helper loaded: html_helper
INFO - 2023-05-11 14:51:46 --> Helper loaded: text_helper
INFO - 2023-05-11 14:51:46 --> Helper loaded: form_helper
INFO - 2023-05-11 14:51:46 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:51:46 --> Helper loaded: security_helper
INFO - 2023-05-11 14:51:46 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:51:46 --> Database Driver Class Initialized
INFO - 2023-05-11 14:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:51:46 --> Parser Class Initialized
INFO - 2023-05-11 14:51:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:51:46 --> Pagination Class Initialized
INFO - 2023-05-11 14:51:46 --> Form Validation Class Initialized
INFO - 2023-05-11 14:51:46 --> Controller Class Initialized
INFO - 2023-05-11 14:51:46 --> Model Class Initialized
DEBUG - 2023-05-11 14:51:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:51:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:51:46 --> Model Class Initialized
INFO - 2023-05-11 14:51:46 --> Final output sent to browser
DEBUG - 2023-05-11 14:51:46 --> Total execution time: 0.0157
ERROR - 2023-05-11 14:52:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:52:39 --> Config Class Initialized
INFO - 2023-05-11 14:52:39 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:52:39 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:52:39 --> Utf8 Class Initialized
INFO - 2023-05-11 14:52:39 --> URI Class Initialized
INFO - 2023-05-11 14:52:39 --> Router Class Initialized
INFO - 2023-05-11 14:52:39 --> Output Class Initialized
INFO - 2023-05-11 14:52:39 --> Security Class Initialized
DEBUG - 2023-05-11 14:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:52:39 --> Input Class Initialized
INFO - 2023-05-11 14:52:39 --> Language Class Initialized
INFO - 2023-05-11 14:52:39 --> Loader Class Initialized
INFO - 2023-05-11 14:52:39 --> Helper loaded: url_helper
INFO - 2023-05-11 14:52:39 --> Helper loaded: file_helper
INFO - 2023-05-11 14:52:39 --> Helper loaded: html_helper
INFO - 2023-05-11 14:52:39 --> Helper loaded: text_helper
INFO - 2023-05-11 14:52:39 --> Helper loaded: form_helper
INFO - 2023-05-11 14:52:39 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:52:39 --> Helper loaded: security_helper
INFO - 2023-05-11 14:52:39 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:52:39 --> Database Driver Class Initialized
INFO - 2023-05-11 14:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:52:39 --> Parser Class Initialized
INFO - 2023-05-11 14:52:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:52:39 --> Pagination Class Initialized
INFO - 2023-05-11 14:52:39 --> Form Validation Class Initialized
INFO - 2023-05-11 14:52:39 --> Controller Class Initialized
INFO - 2023-05-11 14:52:39 --> Model Class Initialized
DEBUG - 2023-05-11 14:52:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:52:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:52:39 --> Model Class Initialized
DEBUG - 2023-05-11 14:52:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:52:39 --> Model Class Initialized
INFO - 2023-05-11 14:52:39 --> Final output sent to browser
DEBUG - 2023-05-11 14:52:39 --> Total execution time: 0.0451
ERROR - 2023-05-11 14:52:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:52:39 --> Config Class Initialized
INFO - 2023-05-11 14:52:39 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:52:39 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:52:39 --> Utf8 Class Initialized
INFO - 2023-05-11 14:52:39 --> URI Class Initialized
INFO - 2023-05-11 14:52:39 --> Router Class Initialized
INFO - 2023-05-11 14:52:39 --> Output Class Initialized
INFO - 2023-05-11 14:52:39 --> Security Class Initialized
DEBUG - 2023-05-11 14:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:52:39 --> Input Class Initialized
INFO - 2023-05-11 14:52:39 --> Language Class Initialized
INFO - 2023-05-11 14:52:39 --> Loader Class Initialized
INFO - 2023-05-11 14:52:39 --> Helper loaded: url_helper
INFO - 2023-05-11 14:52:39 --> Helper loaded: file_helper
INFO - 2023-05-11 14:52:39 --> Helper loaded: html_helper
INFO - 2023-05-11 14:52:39 --> Helper loaded: text_helper
INFO - 2023-05-11 14:52:39 --> Helper loaded: form_helper
INFO - 2023-05-11 14:52:39 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:52:39 --> Helper loaded: security_helper
INFO - 2023-05-11 14:52:39 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:52:39 --> Database Driver Class Initialized
INFO - 2023-05-11 14:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:52:39 --> Parser Class Initialized
INFO - 2023-05-11 14:52:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:52:39 --> Pagination Class Initialized
INFO - 2023-05-11 14:52:39 --> Form Validation Class Initialized
INFO - 2023-05-11 14:52:39 --> Controller Class Initialized
INFO - 2023-05-11 14:52:39 --> Model Class Initialized
DEBUG - 2023-05-11 14:52:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:52:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:52:39 --> Model Class Initialized
DEBUG - 2023-05-11 14:52:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:52:39 --> Model Class Initialized
INFO - 2023-05-11 14:52:39 --> Final output sent to browser
DEBUG - 2023-05-11 14:52:39 --> Total execution time: 0.0391
ERROR - 2023-05-11 14:52:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:52:40 --> Config Class Initialized
INFO - 2023-05-11 14:52:40 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:52:40 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:52:40 --> Utf8 Class Initialized
INFO - 2023-05-11 14:52:40 --> URI Class Initialized
INFO - 2023-05-11 14:52:40 --> Router Class Initialized
INFO - 2023-05-11 14:52:40 --> Output Class Initialized
INFO - 2023-05-11 14:52:40 --> Security Class Initialized
DEBUG - 2023-05-11 14:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:52:40 --> Input Class Initialized
INFO - 2023-05-11 14:52:40 --> Language Class Initialized
INFO - 2023-05-11 14:52:40 --> Loader Class Initialized
INFO - 2023-05-11 14:52:40 --> Helper loaded: url_helper
INFO - 2023-05-11 14:52:40 --> Helper loaded: file_helper
INFO - 2023-05-11 14:52:40 --> Helper loaded: html_helper
INFO - 2023-05-11 14:52:40 --> Helper loaded: text_helper
INFO - 2023-05-11 14:52:40 --> Helper loaded: form_helper
INFO - 2023-05-11 14:52:40 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:52:40 --> Helper loaded: security_helper
INFO - 2023-05-11 14:52:40 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:52:40 --> Database Driver Class Initialized
INFO - 2023-05-11 14:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:52:40 --> Parser Class Initialized
INFO - 2023-05-11 14:52:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:52:40 --> Pagination Class Initialized
INFO - 2023-05-11 14:52:40 --> Form Validation Class Initialized
INFO - 2023-05-11 14:52:40 --> Controller Class Initialized
INFO - 2023-05-11 14:52:40 --> Model Class Initialized
DEBUG - 2023-05-11 14:52:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:52:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:52:40 --> Model Class Initialized
DEBUG - 2023-05-11 14:52:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:52:40 --> Model Class Initialized
INFO - 2023-05-11 14:52:40 --> Final output sent to browser
DEBUG - 2023-05-11 14:52:40 --> Total execution time: 0.0384
ERROR - 2023-05-11 14:52:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:52:40 --> Config Class Initialized
INFO - 2023-05-11 14:52:40 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:52:40 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:52:40 --> Utf8 Class Initialized
INFO - 2023-05-11 14:52:40 --> URI Class Initialized
INFO - 2023-05-11 14:52:40 --> Router Class Initialized
INFO - 2023-05-11 14:52:40 --> Output Class Initialized
INFO - 2023-05-11 14:52:40 --> Security Class Initialized
DEBUG - 2023-05-11 14:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:52:40 --> Input Class Initialized
INFO - 2023-05-11 14:52:40 --> Language Class Initialized
INFO - 2023-05-11 14:52:40 --> Loader Class Initialized
INFO - 2023-05-11 14:52:40 --> Helper loaded: url_helper
INFO - 2023-05-11 14:52:40 --> Helper loaded: file_helper
INFO - 2023-05-11 14:52:40 --> Helper loaded: html_helper
INFO - 2023-05-11 14:52:40 --> Helper loaded: text_helper
INFO - 2023-05-11 14:52:40 --> Helper loaded: form_helper
INFO - 2023-05-11 14:52:40 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:52:40 --> Helper loaded: security_helper
INFO - 2023-05-11 14:52:40 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:52:40 --> Database Driver Class Initialized
INFO - 2023-05-11 14:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:52:40 --> Parser Class Initialized
INFO - 2023-05-11 14:52:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:52:40 --> Pagination Class Initialized
INFO - 2023-05-11 14:52:40 --> Form Validation Class Initialized
INFO - 2023-05-11 14:52:40 --> Controller Class Initialized
INFO - 2023-05-11 14:52:40 --> Model Class Initialized
DEBUG - 2023-05-11 14:52:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:52:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:52:40 --> Model Class Initialized
DEBUG - 2023-05-11 14:52:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:52:40 --> Model Class Initialized
INFO - 2023-05-11 14:52:40 --> Final output sent to browser
DEBUG - 2023-05-11 14:52:40 --> Total execution time: 0.0336
ERROR - 2023-05-11 14:52:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:52:45 --> Config Class Initialized
INFO - 2023-05-11 14:52:45 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:52:45 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:52:45 --> Utf8 Class Initialized
INFO - 2023-05-11 14:52:45 --> URI Class Initialized
INFO - 2023-05-11 14:52:45 --> Router Class Initialized
INFO - 2023-05-11 14:52:45 --> Output Class Initialized
INFO - 2023-05-11 14:52:45 --> Security Class Initialized
DEBUG - 2023-05-11 14:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:52:45 --> Input Class Initialized
INFO - 2023-05-11 14:52:45 --> Language Class Initialized
INFO - 2023-05-11 14:52:45 --> Loader Class Initialized
INFO - 2023-05-11 14:52:45 --> Helper loaded: url_helper
INFO - 2023-05-11 14:52:45 --> Helper loaded: file_helper
INFO - 2023-05-11 14:52:45 --> Helper loaded: html_helper
INFO - 2023-05-11 14:52:45 --> Helper loaded: text_helper
INFO - 2023-05-11 14:52:45 --> Helper loaded: form_helper
INFO - 2023-05-11 14:52:45 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:52:45 --> Helper loaded: security_helper
INFO - 2023-05-11 14:52:45 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:52:45 --> Database Driver Class Initialized
INFO - 2023-05-11 14:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:52:45 --> Parser Class Initialized
INFO - 2023-05-11 14:52:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:52:45 --> Pagination Class Initialized
INFO - 2023-05-11 14:52:45 --> Form Validation Class Initialized
INFO - 2023-05-11 14:52:45 --> Controller Class Initialized
INFO - 2023-05-11 14:52:45 --> Model Class Initialized
DEBUG - 2023-05-11 14:52:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:52:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:52:45 --> Model Class Initialized
DEBUG - 2023-05-11 14:52:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:52:45 --> Model Class Initialized
INFO - 2023-05-11 14:52:45 --> Final output sent to browser
DEBUG - 2023-05-11 14:52:45 --> Total execution time: 0.0212
ERROR - 2023-05-11 14:52:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:52:47 --> Config Class Initialized
INFO - 2023-05-11 14:52:47 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:52:47 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:52:47 --> Utf8 Class Initialized
INFO - 2023-05-11 14:52:47 --> URI Class Initialized
INFO - 2023-05-11 14:52:47 --> Router Class Initialized
INFO - 2023-05-11 14:52:47 --> Output Class Initialized
INFO - 2023-05-11 14:52:47 --> Security Class Initialized
DEBUG - 2023-05-11 14:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:52:47 --> Input Class Initialized
INFO - 2023-05-11 14:52:47 --> Language Class Initialized
INFO - 2023-05-11 14:52:47 --> Loader Class Initialized
INFO - 2023-05-11 14:52:47 --> Helper loaded: url_helper
INFO - 2023-05-11 14:52:47 --> Helper loaded: file_helper
INFO - 2023-05-11 14:52:47 --> Helper loaded: html_helper
INFO - 2023-05-11 14:52:47 --> Helper loaded: text_helper
INFO - 2023-05-11 14:52:47 --> Helper loaded: form_helper
INFO - 2023-05-11 14:52:47 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:52:47 --> Helper loaded: security_helper
INFO - 2023-05-11 14:52:47 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:52:47 --> Database Driver Class Initialized
INFO - 2023-05-11 14:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:52:47 --> Parser Class Initialized
INFO - 2023-05-11 14:52:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:52:48 --> Pagination Class Initialized
INFO - 2023-05-11 14:52:48 --> Form Validation Class Initialized
INFO - 2023-05-11 14:52:48 --> Controller Class Initialized
INFO - 2023-05-11 14:52:48 --> Model Class Initialized
DEBUG - 2023-05-11 14:52:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:52:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:52:48 --> Model Class Initialized
DEBUG - 2023-05-11 14:52:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:52:48 --> Model Class Initialized
INFO - 2023-05-11 14:52:48 --> Final output sent to browser
DEBUG - 2023-05-11 14:52:48 --> Total execution time: 0.0344
ERROR - 2023-05-11 14:52:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:52:49 --> Config Class Initialized
INFO - 2023-05-11 14:52:49 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:52:49 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:52:49 --> Utf8 Class Initialized
INFO - 2023-05-11 14:52:49 --> URI Class Initialized
INFO - 2023-05-11 14:52:49 --> Router Class Initialized
INFO - 2023-05-11 14:52:49 --> Output Class Initialized
INFO - 2023-05-11 14:52:49 --> Security Class Initialized
DEBUG - 2023-05-11 14:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:52:49 --> Input Class Initialized
INFO - 2023-05-11 14:52:49 --> Language Class Initialized
INFO - 2023-05-11 14:52:49 --> Loader Class Initialized
INFO - 2023-05-11 14:52:49 --> Helper loaded: url_helper
INFO - 2023-05-11 14:52:49 --> Helper loaded: file_helper
INFO - 2023-05-11 14:52:49 --> Helper loaded: html_helper
INFO - 2023-05-11 14:52:49 --> Helper loaded: text_helper
INFO - 2023-05-11 14:52:49 --> Helper loaded: form_helper
INFO - 2023-05-11 14:52:49 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:52:49 --> Helper loaded: security_helper
INFO - 2023-05-11 14:52:49 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:52:49 --> Database Driver Class Initialized
INFO - 2023-05-11 14:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:52:49 --> Parser Class Initialized
INFO - 2023-05-11 14:52:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:52:49 --> Pagination Class Initialized
INFO - 2023-05-11 14:52:49 --> Form Validation Class Initialized
INFO - 2023-05-11 14:52:49 --> Controller Class Initialized
INFO - 2023-05-11 14:52:49 --> Model Class Initialized
DEBUG - 2023-05-11 14:52:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:52:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:52:49 --> Model Class Initialized
DEBUG - 2023-05-11 14:52:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:52:49 --> Model Class Initialized
INFO - 2023-05-11 14:52:49 --> Final output sent to browser
DEBUG - 2023-05-11 14:52:49 --> Total execution time: 0.0220
ERROR - 2023-05-11 14:52:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:52:49 --> Config Class Initialized
INFO - 2023-05-11 14:52:49 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:52:49 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:52:49 --> Utf8 Class Initialized
INFO - 2023-05-11 14:52:49 --> URI Class Initialized
INFO - 2023-05-11 14:52:49 --> Router Class Initialized
INFO - 2023-05-11 14:52:49 --> Output Class Initialized
INFO - 2023-05-11 14:52:49 --> Security Class Initialized
DEBUG - 2023-05-11 14:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:52:49 --> Input Class Initialized
INFO - 2023-05-11 14:52:49 --> Language Class Initialized
INFO - 2023-05-11 14:52:49 --> Loader Class Initialized
INFO - 2023-05-11 14:52:49 --> Helper loaded: url_helper
INFO - 2023-05-11 14:52:49 --> Helper loaded: file_helper
INFO - 2023-05-11 14:52:49 --> Helper loaded: html_helper
INFO - 2023-05-11 14:52:49 --> Helper loaded: text_helper
INFO - 2023-05-11 14:52:49 --> Helper loaded: form_helper
INFO - 2023-05-11 14:52:49 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:52:49 --> Helper loaded: security_helper
INFO - 2023-05-11 14:52:49 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:52:49 --> Database Driver Class Initialized
INFO - 2023-05-11 14:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:52:49 --> Parser Class Initialized
INFO - 2023-05-11 14:52:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:52:49 --> Pagination Class Initialized
INFO - 2023-05-11 14:52:49 --> Form Validation Class Initialized
INFO - 2023-05-11 14:52:49 --> Controller Class Initialized
INFO - 2023-05-11 14:52:49 --> Model Class Initialized
DEBUG - 2023-05-11 14:52:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:52:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:52:49 --> Model Class Initialized
DEBUG - 2023-05-11 14:52:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:52:49 --> Model Class Initialized
INFO - 2023-05-11 14:52:49 --> Final output sent to browser
DEBUG - 2023-05-11 14:52:49 --> Total execution time: 0.0188
ERROR - 2023-05-11 14:52:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:52:50 --> Config Class Initialized
INFO - 2023-05-11 14:52:50 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:52:50 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:52:50 --> Utf8 Class Initialized
INFO - 2023-05-11 14:52:50 --> URI Class Initialized
INFO - 2023-05-11 14:52:50 --> Router Class Initialized
INFO - 2023-05-11 14:52:50 --> Output Class Initialized
INFO - 2023-05-11 14:52:50 --> Security Class Initialized
DEBUG - 2023-05-11 14:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:52:50 --> Input Class Initialized
INFO - 2023-05-11 14:52:50 --> Language Class Initialized
INFO - 2023-05-11 14:52:50 --> Loader Class Initialized
INFO - 2023-05-11 14:52:50 --> Helper loaded: url_helper
INFO - 2023-05-11 14:52:50 --> Helper loaded: file_helper
INFO - 2023-05-11 14:52:50 --> Helper loaded: html_helper
INFO - 2023-05-11 14:52:50 --> Helper loaded: text_helper
INFO - 2023-05-11 14:52:50 --> Helper loaded: form_helper
INFO - 2023-05-11 14:52:50 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:52:50 --> Helper loaded: security_helper
INFO - 2023-05-11 14:52:50 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:52:50 --> Database Driver Class Initialized
INFO - 2023-05-11 14:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:52:50 --> Parser Class Initialized
INFO - 2023-05-11 14:52:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:52:50 --> Pagination Class Initialized
INFO - 2023-05-11 14:52:50 --> Form Validation Class Initialized
INFO - 2023-05-11 14:52:50 --> Controller Class Initialized
INFO - 2023-05-11 14:52:50 --> Model Class Initialized
DEBUG - 2023-05-11 14:52:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:52:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:52:50 --> Model Class Initialized
DEBUG - 2023-05-11 14:52:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:52:50 --> Model Class Initialized
INFO - 2023-05-11 14:52:50 --> Final output sent to browser
DEBUG - 2023-05-11 14:52:50 --> Total execution time: 0.0199
ERROR - 2023-05-11 14:52:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:52:51 --> Config Class Initialized
INFO - 2023-05-11 14:52:51 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:52:51 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:52:51 --> Utf8 Class Initialized
INFO - 2023-05-11 14:52:51 --> URI Class Initialized
INFO - 2023-05-11 14:52:51 --> Router Class Initialized
INFO - 2023-05-11 14:52:51 --> Output Class Initialized
INFO - 2023-05-11 14:52:51 --> Security Class Initialized
DEBUG - 2023-05-11 14:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:52:51 --> Input Class Initialized
INFO - 2023-05-11 14:52:51 --> Language Class Initialized
INFO - 2023-05-11 14:52:51 --> Loader Class Initialized
INFO - 2023-05-11 14:52:51 --> Helper loaded: url_helper
INFO - 2023-05-11 14:52:51 --> Helper loaded: file_helper
INFO - 2023-05-11 14:52:51 --> Helper loaded: html_helper
INFO - 2023-05-11 14:52:51 --> Helper loaded: text_helper
INFO - 2023-05-11 14:52:51 --> Helper loaded: form_helper
INFO - 2023-05-11 14:52:51 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:52:51 --> Helper loaded: security_helper
INFO - 2023-05-11 14:52:51 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:52:51 --> Database Driver Class Initialized
INFO - 2023-05-11 14:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:52:51 --> Parser Class Initialized
INFO - 2023-05-11 14:52:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:52:51 --> Pagination Class Initialized
INFO - 2023-05-11 14:52:51 --> Form Validation Class Initialized
INFO - 2023-05-11 14:52:51 --> Controller Class Initialized
INFO - 2023-05-11 14:52:51 --> Model Class Initialized
DEBUG - 2023-05-11 14:52:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:52:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:52:51 --> Model Class Initialized
DEBUG - 2023-05-11 14:52:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:52:51 --> Model Class Initialized
INFO - 2023-05-11 14:52:51 --> Final output sent to browser
DEBUG - 2023-05-11 14:52:51 --> Total execution time: 0.0367
ERROR - 2023-05-11 14:53:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:53:03 --> Config Class Initialized
INFO - 2023-05-11 14:53:03 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:53:03 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:53:03 --> Utf8 Class Initialized
INFO - 2023-05-11 14:53:03 --> URI Class Initialized
INFO - 2023-05-11 14:53:03 --> Router Class Initialized
INFO - 2023-05-11 14:53:03 --> Output Class Initialized
INFO - 2023-05-11 14:53:03 --> Security Class Initialized
DEBUG - 2023-05-11 14:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:53:03 --> Input Class Initialized
INFO - 2023-05-11 14:53:03 --> Language Class Initialized
INFO - 2023-05-11 14:53:03 --> Loader Class Initialized
INFO - 2023-05-11 14:53:03 --> Helper loaded: url_helper
INFO - 2023-05-11 14:53:03 --> Helper loaded: file_helper
INFO - 2023-05-11 14:53:03 --> Helper loaded: html_helper
INFO - 2023-05-11 14:53:03 --> Helper loaded: text_helper
INFO - 2023-05-11 14:53:03 --> Helper loaded: form_helper
INFO - 2023-05-11 14:53:03 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:53:03 --> Helper loaded: security_helper
INFO - 2023-05-11 14:53:03 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:53:03 --> Database Driver Class Initialized
INFO - 2023-05-11 14:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:53:03 --> Parser Class Initialized
INFO - 2023-05-11 14:53:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:53:03 --> Pagination Class Initialized
INFO - 2023-05-11 14:53:03 --> Form Validation Class Initialized
INFO - 2023-05-11 14:53:03 --> Controller Class Initialized
INFO - 2023-05-11 14:53:03 --> Model Class Initialized
DEBUG - 2023-05-11 14:53:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:53:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:53:03 --> Model Class Initialized
DEBUG - 2023-05-11 14:53:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:53:03 --> Model Class Initialized
INFO - 2023-05-11 14:53:03 --> Final output sent to browser
DEBUG - 2023-05-11 14:53:03 --> Total execution time: 0.0223
ERROR - 2023-05-11 14:53:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 14:53:05 --> Config Class Initialized
INFO - 2023-05-11 14:53:05 --> Hooks Class Initialized
DEBUG - 2023-05-11 14:53:05 --> UTF-8 Support Enabled
INFO - 2023-05-11 14:53:05 --> Utf8 Class Initialized
INFO - 2023-05-11 14:53:05 --> URI Class Initialized
INFO - 2023-05-11 14:53:05 --> Router Class Initialized
INFO - 2023-05-11 14:53:05 --> Output Class Initialized
INFO - 2023-05-11 14:53:05 --> Security Class Initialized
DEBUG - 2023-05-11 14:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 14:53:05 --> Input Class Initialized
INFO - 2023-05-11 14:53:05 --> Language Class Initialized
INFO - 2023-05-11 14:53:05 --> Loader Class Initialized
INFO - 2023-05-11 14:53:05 --> Helper loaded: url_helper
INFO - 2023-05-11 14:53:05 --> Helper loaded: file_helper
INFO - 2023-05-11 14:53:05 --> Helper loaded: html_helper
INFO - 2023-05-11 14:53:05 --> Helper loaded: text_helper
INFO - 2023-05-11 14:53:05 --> Helper loaded: form_helper
INFO - 2023-05-11 14:53:05 --> Helper loaded: lang_helper
INFO - 2023-05-11 14:53:05 --> Helper loaded: security_helper
INFO - 2023-05-11 14:53:05 --> Helper loaded: cookie_helper
INFO - 2023-05-11 14:53:05 --> Database Driver Class Initialized
INFO - 2023-05-11 14:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 14:53:05 --> Parser Class Initialized
INFO - 2023-05-11 14:53:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 14:53:05 --> Pagination Class Initialized
INFO - 2023-05-11 14:53:05 --> Form Validation Class Initialized
INFO - 2023-05-11 14:53:05 --> Controller Class Initialized
INFO - 2023-05-11 14:53:05 --> Model Class Initialized
DEBUG - 2023-05-11 14:53:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-11 14:53:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-11 14:53:05 --> Model Class Initialized
INFO - 2023-05-11 14:53:05 --> Model Class Initialized
INFO - 2023-05-11 14:53:05 --> Final output sent to browser
DEBUG - 2023-05-11 14:53:05 --> Total execution time: 0.0189
ERROR - 2023-05-11 23:04:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-11 23:04:02 --> Config Class Initialized
INFO - 2023-05-11 23:04:02 --> Hooks Class Initialized
DEBUG - 2023-05-11 23:04:02 --> UTF-8 Support Enabled
INFO - 2023-05-11 23:04:02 --> Utf8 Class Initialized
INFO - 2023-05-11 23:04:02 --> URI Class Initialized
DEBUG - 2023-05-11 23:04:02 --> No URI present. Default controller set.
INFO - 2023-05-11 23:04:02 --> Router Class Initialized
INFO - 2023-05-11 23:04:02 --> Output Class Initialized
INFO - 2023-05-11 23:04:02 --> Security Class Initialized
DEBUG - 2023-05-11 23:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-11 23:04:02 --> Input Class Initialized
INFO - 2023-05-11 23:04:02 --> Language Class Initialized
INFO - 2023-05-11 23:04:02 --> Loader Class Initialized
INFO - 2023-05-11 23:04:02 --> Helper loaded: url_helper
INFO - 2023-05-11 23:04:02 --> Helper loaded: file_helper
INFO - 2023-05-11 23:04:02 --> Helper loaded: html_helper
INFO - 2023-05-11 23:04:02 --> Helper loaded: text_helper
INFO - 2023-05-11 23:04:02 --> Helper loaded: form_helper
INFO - 2023-05-11 23:04:02 --> Helper loaded: lang_helper
INFO - 2023-05-11 23:04:02 --> Helper loaded: security_helper
INFO - 2023-05-11 23:04:02 --> Helper loaded: cookie_helper
INFO - 2023-05-11 23:04:02 --> Database Driver Class Initialized
INFO - 2023-05-11 23:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-11 23:04:02 --> Parser Class Initialized
INFO - 2023-05-11 23:04:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-11 23:04:02 --> Pagination Class Initialized
INFO - 2023-05-11 23:04:02 --> Form Validation Class Initialized
INFO - 2023-05-11 23:04:02 --> Controller Class Initialized
INFO - 2023-05-11 23:04:02 --> Model Class Initialized
DEBUG - 2023-05-11 23:04:02 --> Session class already loaded. Second attempt ignored.
