<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-25 03:57:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 03:57:53 --> Config Class Initialized
INFO - 2023-10-25 03:57:53 --> Hooks Class Initialized
DEBUG - 2023-10-25 03:57:53 --> UTF-8 Support Enabled
INFO - 2023-10-25 03:57:53 --> Utf8 Class Initialized
INFO - 2023-10-25 03:57:53 --> URI Class Initialized
INFO - 2023-10-25 03:57:53 --> Router Class Initialized
INFO - 2023-10-25 03:57:53 --> Output Class Initialized
INFO - 2023-10-25 03:57:53 --> Security Class Initialized
DEBUG - 2023-10-25 03:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 03:57:53 --> Input Class Initialized
INFO - 2023-10-25 03:57:53 --> Language Class Initialized
ERROR - 2023-10-25 03:57:53 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-10-25 05:07:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 05:07:44 --> Config Class Initialized
INFO - 2023-10-25 05:07:44 --> Hooks Class Initialized
DEBUG - 2023-10-25 05:07:44 --> UTF-8 Support Enabled
INFO - 2023-10-25 05:07:44 --> Utf8 Class Initialized
INFO - 2023-10-25 05:07:44 --> URI Class Initialized
INFO - 2023-10-25 05:07:44 --> Router Class Initialized
INFO - 2023-10-25 05:07:44 --> Output Class Initialized
INFO - 2023-10-25 05:07:44 --> Security Class Initialized
DEBUG - 2023-10-25 05:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 05:07:44 --> Input Class Initialized
INFO - 2023-10-25 05:07:44 --> Language Class Initialized
INFO - 2023-10-25 05:07:44 --> Loader Class Initialized
INFO - 2023-10-25 05:07:44 --> Helper loaded: url_helper
INFO - 2023-10-25 05:07:44 --> Helper loaded: file_helper
INFO - 2023-10-25 05:07:44 --> Helper loaded: html_helper
INFO - 2023-10-25 05:07:44 --> Helper loaded: text_helper
INFO - 2023-10-25 05:07:44 --> Helper loaded: form_helper
INFO - 2023-10-25 05:07:44 --> Helper loaded: lang_helper
INFO - 2023-10-25 05:07:44 --> Helper loaded: security_helper
INFO - 2023-10-25 05:07:44 --> Helper loaded: cookie_helper
INFO - 2023-10-25 05:07:44 --> Database Driver Class Initialized
INFO - 2023-10-25 05:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 05:07:44 --> Parser Class Initialized
INFO - 2023-10-25 05:07:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 05:07:44 --> Pagination Class Initialized
INFO - 2023-10-25 05:07:44 --> Form Validation Class Initialized
INFO - 2023-10-25 05:07:44 --> Controller Class Initialized
ERROR - 2023-10-25 05:07:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 05:07:45 --> Config Class Initialized
INFO - 2023-10-25 05:07:45 --> Hooks Class Initialized
DEBUG - 2023-10-25 05:07:45 --> UTF-8 Support Enabled
INFO - 2023-10-25 05:07:45 --> Utf8 Class Initialized
INFO - 2023-10-25 05:07:45 --> URI Class Initialized
INFO - 2023-10-25 05:07:45 --> Router Class Initialized
INFO - 2023-10-25 05:07:45 --> Output Class Initialized
INFO - 2023-10-25 05:07:45 --> Security Class Initialized
DEBUG - 2023-10-25 05:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 05:07:45 --> Input Class Initialized
INFO - 2023-10-25 05:07:45 --> Language Class Initialized
INFO - 2023-10-25 05:07:45 --> Loader Class Initialized
INFO - 2023-10-25 05:07:45 --> Helper loaded: url_helper
INFO - 2023-10-25 05:07:45 --> Helper loaded: file_helper
INFO - 2023-10-25 05:07:45 --> Helper loaded: html_helper
INFO - 2023-10-25 05:07:45 --> Helper loaded: text_helper
INFO - 2023-10-25 05:07:45 --> Helper loaded: form_helper
INFO - 2023-10-25 05:07:45 --> Helper loaded: lang_helper
INFO - 2023-10-25 05:07:45 --> Helper loaded: security_helper
INFO - 2023-10-25 05:07:45 --> Helper loaded: cookie_helper
INFO - 2023-10-25 05:07:45 --> Database Driver Class Initialized
INFO - 2023-10-25 05:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 05:07:45 --> Parser Class Initialized
INFO - 2023-10-25 05:07:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 05:07:45 --> Pagination Class Initialized
INFO - 2023-10-25 05:07:45 --> Form Validation Class Initialized
INFO - 2023-10-25 05:07:45 --> Controller Class Initialized
INFO - 2023-10-25 05:07:45 --> Model Class Initialized
DEBUG - 2023-10-25 05:07:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 05:07:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-25 05:07:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 05:07:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 05:07:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 05:07:45 --> Model Class Initialized
INFO - 2023-10-25 05:07:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 05:07:45 --> Final output sent to browser
DEBUG - 2023-10-25 05:07:45 --> Total execution time: 0.0318
ERROR - 2023-10-25 05:10:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 05:10:52 --> Config Class Initialized
INFO - 2023-10-25 05:10:52 --> Hooks Class Initialized
DEBUG - 2023-10-25 05:10:52 --> UTF-8 Support Enabled
INFO - 2023-10-25 05:10:52 --> Utf8 Class Initialized
INFO - 2023-10-25 05:10:52 --> URI Class Initialized
DEBUG - 2023-10-25 05:10:52 --> No URI present. Default controller set.
INFO - 2023-10-25 05:10:52 --> Router Class Initialized
INFO - 2023-10-25 05:10:52 --> Output Class Initialized
INFO - 2023-10-25 05:10:52 --> Security Class Initialized
DEBUG - 2023-10-25 05:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 05:10:52 --> Input Class Initialized
INFO - 2023-10-25 05:10:52 --> Language Class Initialized
INFO - 2023-10-25 05:10:52 --> Loader Class Initialized
INFO - 2023-10-25 05:10:52 --> Helper loaded: url_helper
INFO - 2023-10-25 05:10:52 --> Helper loaded: file_helper
INFO - 2023-10-25 05:10:52 --> Helper loaded: html_helper
INFO - 2023-10-25 05:10:52 --> Helper loaded: text_helper
INFO - 2023-10-25 05:10:52 --> Helper loaded: form_helper
INFO - 2023-10-25 05:10:52 --> Helper loaded: lang_helper
INFO - 2023-10-25 05:10:52 --> Helper loaded: security_helper
INFO - 2023-10-25 05:10:52 --> Helper loaded: cookie_helper
INFO - 2023-10-25 05:10:52 --> Database Driver Class Initialized
INFO - 2023-10-25 05:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 05:10:52 --> Parser Class Initialized
INFO - 2023-10-25 05:10:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 05:10:52 --> Pagination Class Initialized
INFO - 2023-10-25 05:10:52 --> Form Validation Class Initialized
INFO - 2023-10-25 05:10:52 --> Controller Class Initialized
INFO - 2023-10-25 05:10:52 --> Model Class Initialized
DEBUG - 2023-10-25 05:10:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-25 05:10:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 05:10:52 --> Config Class Initialized
INFO - 2023-10-25 05:10:52 --> Hooks Class Initialized
DEBUG - 2023-10-25 05:10:52 --> UTF-8 Support Enabled
INFO - 2023-10-25 05:10:52 --> Utf8 Class Initialized
INFO - 2023-10-25 05:10:52 --> URI Class Initialized
INFO - 2023-10-25 05:10:52 --> Router Class Initialized
INFO - 2023-10-25 05:10:52 --> Output Class Initialized
INFO - 2023-10-25 05:10:52 --> Security Class Initialized
DEBUG - 2023-10-25 05:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 05:10:52 --> Input Class Initialized
INFO - 2023-10-25 05:10:52 --> Language Class Initialized
INFO - 2023-10-25 05:10:52 --> Loader Class Initialized
INFO - 2023-10-25 05:10:52 --> Helper loaded: url_helper
INFO - 2023-10-25 05:10:52 --> Helper loaded: file_helper
INFO - 2023-10-25 05:10:52 --> Helper loaded: html_helper
INFO - 2023-10-25 05:10:52 --> Helper loaded: text_helper
INFO - 2023-10-25 05:10:52 --> Helper loaded: form_helper
INFO - 2023-10-25 05:10:52 --> Helper loaded: lang_helper
INFO - 2023-10-25 05:10:52 --> Helper loaded: security_helper
INFO - 2023-10-25 05:10:52 --> Helper loaded: cookie_helper
INFO - 2023-10-25 05:10:52 --> Database Driver Class Initialized
INFO - 2023-10-25 05:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 05:10:52 --> Parser Class Initialized
INFO - 2023-10-25 05:10:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 05:10:52 --> Pagination Class Initialized
INFO - 2023-10-25 05:10:52 --> Form Validation Class Initialized
INFO - 2023-10-25 05:10:52 --> Controller Class Initialized
INFO - 2023-10-25 05:10:52 --> Model Class Initialized
DEBUG - 2023-10-25 05:10:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 05:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-25 05:10:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 05:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 05:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 05:10:52 --> Model Class Initialized
INFO - 2023-10-25 05:10:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 05:10:52 --> Final output sent to browser
DEBUG - 2023-10-25 05:10:52 --> Total execution time: 0.0309
ERROR - 2023-10-25 05:20:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
ERROR - 2023-10-25 05:20:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 05:20:28 --> Config Class Initialized
INFO - 2023-10-25 05:20:28 --> Hooks Class Initialized
INFO - 2023-10-25 05:20:28 --> Config Class Initialized
INFO - 2023-10-25 05:20:28 --> Hooks Class Initialized
DEBUG - 2023-10-25 05:20:28 --> UTF-8 Support Enabled
INFO - 2023-10-25 05:20:28 --> Utf8 Class Initialized
DEBUG - 2023-10-25 05:20:28 --> UTF-8 Support Enabled
INFO - 2023-10-25 05:20:28 --> Utf8 Class Initialized
INFO - 2023-10-25 05:20:28 --> URI Class Initialized
INFO - 2023-10-25 05:20:28 --> URI Class Initialized
INFO - 2023-10-25 05:20:28 --> Router Class Initialized
INFO - 2023-10-25 05:20:28 --> Router Class Initialized
INFO - 2023-10-25 05:20:28 --> Output Class Initialized
INFO - 2023-10-25 05:20:28 --> Output Class Initialized
INFO - 2023-10-25 05:20:28 --> Security Class Initialized
INFO - 2023-10-25 05:20:28 --> Security Class Initialized
DEBUG - 2023-10-25 05:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 05:20:28 --> Input Class Initialized
INFO - 2023-10-25 05:20:28 --> Language Class Initialized
DEBUG - 2023-10-25 05:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 05:20:28 --> Input Class Initialized
ERROR - 2023-10-25 05:20:28 --> 404 Page Not Found: Assets/plugins
INFO - 2023-10-25 05:20:28 --> Language Class Initialized
ERROR - 2023-10-25 05:20:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2023-10-25 06:16:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 06:16:17 --> Config Class Initialized
INFO - 2023-10-25 06:16:17 --> Hooks Class Initialized
DEBUG - 2023-10-25 06:16:17 --> UTF-8 Support Enabled
INFO - 2023-10-25 06:16:17 --> Utf8 Class Initialized
INFO - 2023-10-25 06:16:17 --> URI Class Initialized
DEBUG - 2023-10-25 06:16:17 --> No URI present. Default controller set.
INFO - 2023-10-25 06:16:17 --> Router Class Initialized
INFO - 2023-10-25 06:16:17 --> Output Class Initialized
INFO - 2023-10-25 06:16:17 --> Security Class Initialized
DEBUG - 2023-10-25 06:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 06:16:17 --> Input Class Initialized
INFO - 2023-10-25 06:16:17 --> Language Class Initialized
INFO - 2023-10-25 06:16:17 --> Loader Class Initialized
INFO - 2023-10-25 06:16:17 --> Helper loaded: url_helper
INFO - 2023-10-25 06:16:17 --> Helper loaded: file_helper
INFO - 2023-10-25 06:16:17 --> Helper loaded: html_helper
INFO - 2023-10-25 06:16:17 --> Helper loaded: text_helper
INFO - 2023-10-25 06:16:17 --> Helper loaded: form_helper
INFO - 2023-10-25 06:16:17 --> Helper loaded: lang_helper
INFO - 2023-10-25 06:16:17 --> Helper loaded: security_helper
INFO - 2023-10-25 06:16:17 --> Helper loaded: cookie_helper
INFO - 2023-10-25 06:16:17 --> Database Driver Class Initialized
INFO - 2023-10-25 06:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 06:16:17 --> Parser Class Initialized
INFO - 2023-10-25 06:16:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 06:16:17 --> Pagination Class Initialized
INFO - 2023-10-25 06:16:17 --> Form Validation Class Initialized
INFO - 2023-10-25 06:16:17 --> Controller Class Initialized
INFO - 2023-10-25 06:16:17 --> Model Class Initialized
DEBUG - 2023-10-25 06:16:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-25 06:32:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 06:32:08 --> Config Class Initialized
INFO - 2023-10-25 06:32:08 --> Hooks Class Initialized
DEBUG - 2023-10-25 06:32:08 --> UTF-8 Support Enabled
INFO - 2023-10-25 06:32:08 --> Utf8 Class Initialized
INFO - 2023-10-25 06:32:08 --> URI Class Initialized
DEBUG - 2023-10-25 06:32:08 --> No URI present. Default controller set.
INFO - 2023-10-25 06:32:08 --> Router Class Initialized
INFO - 2023-10-25 06:32:08 --> Output Class Initialized
INFO - 2023-10-25 06:32:08 --> Security Class Initialized
DEBUG - 2023-10-25 06:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 06:32:08 --> Input Class Initialized
INFO - 2023-10-25 06:32:08 --> Language Class Initialized
INFO - 2023-10-25 06:32:08 --> Loader Class Initialized
INFO - 2023-10-25 06:32:08 --> Helper loaded: url_helper
INFO - 2023-10-25 06:32:08 --> Helper loaded: file_helper
INFO - 2023-10-25 06:32:08 --> Helper loaded: html_helper
INFO - 2023-10-25 06:32:08 --> Helper loaded: text_helper
INFO - 2023-10-25 06:32:08 --> Helper loaded: form_helper
INFO - 2023-10-25 06:32:08 --> Helper loaded: lang_helper
INFO - 2023-10-25 06:32:08 --> Helper loaded: security_helper
INFO - 2023-10-25 06:32:08 --> Helper loaded: cookie_helper
INFO - 2023-10-25 06:32:08 --> Database Driver Class Initialized
INFO - 2023-10-25 06:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 06:32:08 --> Parser Class Initialized
INFO - 2023-10-25 06:32:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 06:32:08 --> Pagination Class Initialized
INFO - 2023-10-25 06:32:08 --> Form Validation Class Initialized
INFO - 2023-10-25 06:32:08 --> Controller Class Initialized
INFO - 2023-10-25 06:32:08 --> Model Class Initialized
DEBUG - 2023-10-25 06:32:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-25 06:32:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 06:32:08 --> Config Class Initialized
INFO - 2023-10-25 06:32:08 --> Hooks Class Initialized
DEBUG - 2023-10-25 06:32:08 --> UTF-8 Support Enabled
INFO - 2023-10-25 06:32:08 --> Utf8 Class Initialized
INFO - 2023-10-25 06:32:08 --> URI Class Initialized
INFO - 2023-10-25 06:32:08 --> Router Class Initialized
INFO - 2023-10-25 06:32:08 --> Output Class Initialized
INFO - 2023-10-25 06:32:08 --> Security Class Initialized
DEBUG - 2023-10-25 06:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 06:32:08 --> Input Class Initialized
INFO - 2023-10-25 06:32:08 --> Language Class Initialized
INFO - 2023-10-25 06:32:08 --> Loader Class Initialized
INFO - 2023-10-25 06:32:08 --> Helper loaded: url_helper
INFO - 2023-10-25 06:32:08 --> Helper loaded: file_helper
INFO - 2023-10-25 06:32:08 --> Helper loaded: html_helper
INFO - 2023-10-25 06:32:08 --> Helper loaded: text_helper
INFO - 2023-10-25 06:32:08 --> Helper loaded: form_helper
INFO - 2023-10-25 06:32:08 --> Helper loaded: lang_helper
INFO - 2023-10-25 06:32:08 --> Helper loaded: security_helper
INFO - 2023-10-25 06:32:08 --> Helper loaded: cookie_helper
INFO - 2023-10-25 06:32:08 --> Database Driver Class Initialized
INFO - 2023-10-25 06:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 06:32:08 --> Parser Class Initialized
INFO - 2023-10-25 06:32:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 06:32:08 --> Pagination Class Initialized
INFO - 2023-10-25 06:32:08 --> Form Validation Class Initialized
INFO - 2023-10-25 06:32:08 --> Controller Class Initialized
INFO - 2023-10-25 06:32:08 --> Model Class Initialized
DEBUG - 2023-10-25 06:32:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 06:32:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-25 06:32:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 06:32:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 06:32:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 06:32:08 --> Model Class Initialized
INFO - 2023-10-25 06:32:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 06:32:08 --> Final output sent to browser
DEBUG - 2023-10-25 06:32:08 --> Total execution time: 0.0298
ERROR - 2023-10-25 07:33:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 07:33:49 --> Config Class Initialized
INFO - 2023-10-25 07:33:49 --> Hooks Class Initialized
DEBUG - 2023-10-25 07:33:49 --> UTF-8 Support Enabled
INFO - 2023-10-25 07:33:49 --> Utf8 Class Initialized
INFO - 2023-10-25 07:33:49 --> URI Class Initialized
DEBUG - 2023-10-25 07:33:49 --> No URI present. Default controller set.
INFO - 2023-10-25 07:33:49 --> Router Class Initialized
INFO - 2023-10-25 07:33:49 --> Output Class Initialized
INFO - 2023-10-25 07:33:49 --> Security Class Initialized
DEBUG - 2023-10-25 07:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 07:33:49 --> Input Class Initialized
INFO - 2023-10-25 07:33:49 --> Language Class Initialized
INFO - 2023-10-25 07:33:49 --> Loader Class Initialized
INFO - 2023-10-25 07:33:49 --> Helper loaded: url_helper
INFO - 2023-10-25 07:33:49 --> Helper loaded: file_helper
INFO - 2023-10-25 07:33:49 --> Helper loaded: html_helper
INFO - 2023-10-25 07:33:49 --> Helper loaded: text_helper
INFO - 2023-10-25 07:33:49 --> Helper loaded: form_helper
INFO - 2023-10-25 07:33:49 --> Helper loaded: lang_helper
INFO - 2023-10-25 07:33:49 --> Helper loaded: security_helper
INFO - 2023-10-25 07:33:49 --> Helper loaded: cookie_helper
INFO - 2023-10-25 07:33:49 --> Database Driver Class Initialized
INFO - 2023-10-25 07:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 07:33:49 --> Parser Class Initialized
INFO - 2023-10-25 07:33:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 07:33:49 --> Pagination Class Initialized
INFO - 2023-10-25 07:33:49 --> Form Validation Class Initialized
INFO - 2023-10-25 07:33:49 --> Controller Class Initialized
INFO - 2023-10-25 07:33:49 --> Model Class Initialized
DEBUG - 2023-10-25 07:33:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-25 07:33:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 07:33:50 --> Config Class Initialized
INFO - 2023-10-25 07:33:50 --> Hooks Class Initialized
DEBUG - 2023-10-25 07:33:50 --> UTF-8 Support Enabled
INFO - 2023-10-25 07:33:50 --> Utf8 Class Initialized
INFO - 2023-10-25 07:33:50 --> URI Class Initialized
INFO - 2023-10-25 07:33:50 --> Router Class Initialized
INFO - 2023-10-25 07:33:50 --> Output Class Initialized
INFO - 2023-10-25 07:33:50 --> Security Class Initialized
DEBUG - 2023-10-25 07:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 07:33:50 --> Input Class Initialized
INFO - 2023-10-25 07:33:50 --> Language Class Initialized
INFO - 2023-10-25 07:33:50 --> Loader Class Initialized
INFO - 2023-10-25 07:33:50 --> Helper loaded: url_helper
INFO - 2023-10-25 07:33:50 --> Helper loaded: file_helper
INFO - 2023-10-25 07:33:50 --> Helper loaded: html_helper
INFO - 2023-10-25 07:33:50 --> Helper loaded: text_helper
INFO - 2023-10-25 07:33:50 --> Helper loaded: form_helper
INFO - 2023-10-25 07:33:50 --> Helper loaded: lang_helper
INFO - 2023-10-25 07:33:50 --> Helper loaded: security_helper
INFO - 2023-10-25 07:33:50 --> Helper loaded: cookie_helper
INFO - 2023-10-25 07:33:50 --> Database Driver Class Initialized
INFO - 2023-10-25 07:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 07:33:50 --> Parser Class Initialized
INFO - 2023-10-25 07:33:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 07:33:50 --> Pagination Class Initialized
INFO - 2023-10-25 07:33:50 --> Form Validation Class Initialized
INFO - 2023-10-25 07:33:50 --> Controller Class Initialized
INFO - 2023-10-25 07:33:50 --> Model Class Initialized
DEBUG - 2023-10-25 07:33:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:33:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-25 07:33:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:33:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 07:33:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 07:33:50 --> Model Class Initialized
INFO - 2023-10-25 07:33:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 07:33:50 --> Final output sent to browser
DEBUG - 2023-10-25 07:33:50 --> Total execution time: 0.0287
ERROR - 2023-10-25 07:34:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 07:34:00 --> Config Class Initialized
INFO - 2023-10-25 07:34:00 --> Hooks Class Initialized
DEBUG - 2023-10-25 07:34:00 --> UTF-8 Support Enabled
INFO - 2023-10-25 07:34:00 --> Utf8 Class Initialized
INFO - 2023-10-25 07:34:00 --> URI Class Initialized
INFO - 2023-10-25 07:34:00 --> Router Class Initialized
INFO - 2023-10-25 07:34:00 --> Output Class Initialized
INFO - 2023-10-25 07:34:00 --> Security Class Initialized
DEBUG - 2023-10-25 07:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 07:34:00 --> Input Class Initialized
INFO - 2023-10-25 07:34:00 --> Language Class Initialized
INFO - 2023-10-25 07:34:00 --> Loader Class Initialized
INFO - 2023-10-25 07:34:00 --> Helper loaded: url_helper
INFO - 2023-10-25 07:34:00 --> Helper loaded: file_helper
INFO - 2023-10-25 07:34:00 --> Helper loaded: html_helper
INFO - 2023-10-25 07:34:00 --> Helper loaded: text_helper
INFO - 2023-10-25 07:34:00 --> Helper loaded: form_helper
INFO - 2023-10-25 07:34:00 --> Helper loaded: lang_helper
INFO - 2023-10-25 07:34:00 --> Helper loaded: security_helper
INFO - 2023-10-25 07:34:00 --> Helper loaded: cookie_helper
INFO - 2023-10-25 07:34:00 --> Database Driver Class Initialized
INFO - 2023-10-25 07:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 07:34:00 --> Parser Class Initialized
INFO - 2023-10-25 07:34:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 07:34:00 --> Pagination Class Initialized
INFO - 2023-10-25 07:34:00 --> Form Validation Class Initialized
INFO - 2023-10-25 07:34:00 --> Controller Class Initialized
INFO - 2023-10-25 07:34:00 --> Model Class Initialized
DEBUG - 2023-10-25 07:34:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:34:00 --> Model Class Initialized
INFO - 2023-10-25 07:34:00 --> Final output sent to browser
DEBUG - 2023-10-25 07:34:00 --> Total execution time: 0.0200
ERROR - 2023-10-25 07:34:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 07:34:00 --> Config Class Initialized
INFO - 2023-10-25 07:34:00 --> Hooks Class Initialized
DEBUG - 2023-10-25 07:34:00 --> UTF-8 Support Enabled
INFO - 2023-10-25 07:34:00 --> Utf8 Class Initialized
INFO - 2023-10-25 07:34:00 --> URI Class Initialized
DEBUG - 2023-10-25 07:34:00 --> No URI present. Default controller set.
INFO - 2023-10-25 07:34:00 --> Router Class Initialized
INFO - 2023-10-25 07:34:00 --> Output Class Initialized
INFO - 2023-10-25 07:34:00 --> Security Class Initialized
DEBUG - 2023-10-25 07:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 07:34:00 --> Input Class Initialized
INFO - 2023-10-25 07:34:00 --> Language Class Initialized
INFO - 2023-10-25 07:34:00 --> Loader Class Initialized
INFO - 2023-10-25 07:34:00 --> Helper loaded: url_helper
INFO - 2023-10-25 07:34:00 --> Helper loaded: file_helper
INFO - 2023-10-25 07:34:00 --> Helper loaded: html_helper
INFO - 2023-10-25 07:34:00 --> Helper loaded: text_helper
INFO - 2023-10-25 07:34:00 --> Helper loaded: form_helper
INFO - 2023-10-25 07:34:00 --> Helper loaded: lang_helper
INFO - 2023-10-25 07:34:00 --> Helper loaded: security_helper
INFO - 2023-10-25 07:34:00 --> Helper loaded: cookie_helper
INFO - 2023-10-25 07:34:00 --> Database Driver Class Initialized
INFO - 2023-10-25 07:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 07:34:01 --> Parser Class Initialized
INFO - 2023-10-25 07:34:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 07:34:01 --> Pagination Class Initialized
INFO - 2023-10-25 07:34:01 --> Form Validation Class Initialized
INFO - 2023-10-25 07:34:01 --> Controller Class Initialized
INFO - 2023-10-25 07:34:01 --> Model Class Initialized
DEBUG - 2023-10-25 07:34:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:34:01 --> Model Class Initialized
DEBUG - 2023-10-25 07:34:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:34:01 --> Model Class Initialized
INFO - 2023-10-25 07:34:01 --> Model Class Initialized
INFO - 2023-10-25 07:34:01 --> Model Class Initialized
INFO - 2023-10-25 07:34:01 --> Model Class Initialized
DEBUG - 2023-10-25 07:34:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 07:34:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:34:01 --> Model Class Initialized
INFO - 2023-10-25 07:34:01 --> Model Class Initialized
INFO - 2023-10-25 07:34:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-25 07:34:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:34:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 07:34:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 07:34:01 --> Model Class Initialized
INFO - 2023-10-25 07:34:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-25 07:34:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-25 07:34:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 07:34:01 --> Final output sent to browser
DEBUG - 2023-10-25 07:34:01 --> Total execution time: 0.3755
ERROR - 2023-10-25 07:34:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 07:34:28 --> Config Class Initialized
INFO - 2023-10-25 07:34:28 --> Hooks Class Initialized
DEBUG - 2023-10-25 07:34:28 --> UTF-8 Support Enabled
INFO - 2023-10-25 07:34:28 --> Utf8 Class Initialized
INFO - 2023-10-25 07:34:28 --> URI Class Initialized
INFO - 2023-10-25 07:34:28 --> Router Class Initialized
INFO - 2023-10-25 07:34:28 --> Output Class Initialized
INFO - 2023-10-25 07:34:28 --> Security Class Initialized
DEBUG - 2023-10-25 07:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 07:34:28 --> Input Class Initialized
INFO - 2023-10-25 07:34:28 --> Language Class Initialized
INFO - 2023-10-25 07:34:28 --> Loader Class Initialized
INFO - 2023-10-25 07:34:28 --> Helper loaded: url_helper
INFO - 2023-10-25 07:34:28 --> Helper loaded: file_helper
INFO - 2023-10-25 07:34:28 --> Helper loaded: html_helper
INFO - 2023-10-25 07:34:28 --> Helper loaded: text_helper
INFO - 2023-10-25 07:34:28 --> Helper loaded: form_helper
INFO - 2023-10-25 07:34:28 --> Helper loaded: lang_helper
INFO - 2023-10-25 07:34:28 --> Helper loaded: security_helper
INFO - 2023-10-25 07:34:28 --> Helper loaded: cookie_helper
INFO - 2023-10-25 07:34:28 --> Database Driver Class Initialized
INFO - 2023-10-25 07:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 07:34:28 --> Parser Class Initialized
INFO - 2023-10-25 07:34:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 07:34:28 --> Pagination Class Initialized
INFO - 2023-10-25 07:34:28 --> Form Validation Class Initialized
INFO - 2023-10-25 07:34:28 --> Controller Class Initialized
INFO - 2023-10-25 07:34:28 --> Model Class Initialized
DEBUG - 2023-10-25 07:34:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 07:34:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:34:28 --> Model Class Initialized
DEBUG - 2023-10-25 07:34:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:34:28 --> Model Class Initialized
INFO - 2023-10-25 07:34:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-25 07:34:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:34:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 07:34:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 07:34:28 --> Model Class Initialized
INFO - 2023-10-25 07:34:28 --> Model Class Initialized
INFO - 2023-10-25 07:34:28 --> Model Class Initialized
INFO - 2023-10-25 07:34:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-25 07:34:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-25 07:34:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 07:34:28 --> Final output sent to browser
DEBUG - 2023-10-25 07:34:28 --> Total execution time: 0.1327
ERROR - 2023-10-25 07:34:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 07:34:29 --> Config Class Initialized
INFO - 2023-10-25 07:34:29 --> Hooks Class Initialized
DEBUG - 2023-10-25 07:34:29 --> UTF-8 Support Enabled
INFO - 2023-10-25 07:34:29 --> Utf8 Class Initialized
INFO - 2023-10-25 07:34:29 --> URI Class Initialized
INFO - 2023-10-25 07:34:29 --> Router Class Initialized
INFO - 2023-10-25 07:34:29 --> Output Class Initialized
INFO - 2023-10-25 07:34:29 --> Security Class Initialized
DEBUG - 2023-10-25 07:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 07:34:29 --> Input Class Initialized
INFO - 2023-10-25 07:34:29 --> Language Class Initialized
INFO - 2023-10-25 07:34:29 --> Loader Class Initialized
INFO - 2023-10-25 07:34:29 --> Helper loaded: url_helper
INFO - 2023-10-25 07:34:29 --> Helper loaded: file_helper
INFO - 2023-10-25 07:34:29 --> Helper loaded: html_helper
INFO - 2023-10-25 07:34:29 --> Helper loaded: text_helper
INFO - 2023-10-25 07:34:29 --> Helper loaded: form_helper
INFO - 2023-10-25 07:34:29 --> Helper loaded: lang_helper
INFO - 2023-10-25 07:34:29 --> Helper loaded: security_helper
INFO - 2023-10-25 07:34:29 --> Helper loaded: cookie_helper
INFO - 2023-10-25 07:34:29 --> Database Driver Class Initialized
INFO - 2023-10-25 07:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 07:34:29 --> Parser Class Initialized
INFO - 2023-10-25 07:34:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 07:34:29 --> Pagination Class Initialized
INFO - 2023-10-25 07:34:29 --> Form Validation Class Initialized
INFO - 2023-10-25 07:34:29 --> Controller Class Initialized
INFO - 2023-10-25 07:34:29 --> Model Class Initialized
DEBUG - 2023-10-25 07:34:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 07:34:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:34:29 --> Model Class Initialized
DEBUG - 2023-10-25 07:34:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:34:29 --> Model Class Initialized
INFO - 2023-10-25 07:34:29 --> Final output sent to browser
DEBUG - 2023-10-25 07:34:29 --> Total execution time: 0.0383
ERROR - 2023-10-25 07:34:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 07:34:43 --> Config Class Initialized
INFO - 2023-10-25 07:34:43 --> Hooks Class Initialized
DEBUG - 2023-10-25 07:34:43 --> UTF-8 Support Enabled
INFO - 2023-10-25 07:34:43 --> Utf8 Class Initialized
INFO - 2023-10-25 07:34:43 --> URI Class Initialized
INFO - 2023-10-25 07:34:43 --> Router Class Initialized
INFO - 2023-10-25 07:34:43 --> Output Class Initialized
INFO - 2023-10-25 07:34:43 --> Security Class Initialized
DEBUG - 2023-10-25 07:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 07:34:43 --> Input Class Initialized
INFO - 2023-10-25 07:34:43 --> Language Class Initialized
INFO - 2023-10-25 07:34:43 --> Loader Class Initialized
INFO - 2023-10-25 07:34:43 --> Helper loaded: url_helper
INFO - 2023-10-25 07:34:43 --> Helper loaded: file_helper
INFO - 2023-10-25 07:34:43 --> Helper loaded: html_helper
INFO - 2023-10-25 07:34:43 --> Helper loaded: text_helper
INFO - 2023-10-25 07:34:43 --> Helper loaded: form_helper
INFO - 2023-10-25 07:34:43 --> Helper loaded: lang_helper
INFO - 2023-10-25 07:34:43 --> Helper loaded: security_helper
INFO - 2023-10-25 07:34:43 --> Helper loaded: cookie_helper
INFO - 2023-10-25 07:34:43 --> Database Driver Class Initialized
INFO - 2023-10-25 07:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 07:34:43 --> Parser Class Initialized
INFO - 2023-10-25 07:34:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 07:34:43 --> Pagination Class Initialized
INFO - 2023-10-25 07:34:43 --> Form Validation Class Initialized
INFO - 2023-10-25 07:34:43 --> Controller Class Initialized
INFO - 2023-10-25 07:34:43 --> Model Class Initialized
DEBUG - 2023-10-25 07:34:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 07:34:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:34:43 --> Model Class Initialized
DEBUG - 2023-10-25 07:34:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:34:43 --> Model Class Initialized
DEBUG - 2023-10-25 07:34:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:34:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-25 07:34:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:34:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 07:34:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 07:34:43 --> Model Class Initialized
INFO - 2023-10-25 07:34:43 --> Model Class Initialized
INFO - 2023-10-25 07:34:43 --> Model Class Initialized
INFO - 2023-10-25 07:34:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-25 07:34:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-25 07:34:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 07:34:43 --> Final output sent to browser
DEBUG - 2023-10-25 07:34:43 --> Total execution time: 0.1332
ERROR - 2023-10-25 07:34:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 07:34:49 --> Config Class Initialized
INFO - 2023-10-25 07:34:49 --> Hooks Class Initialized
DEBUG - 2023-10-25 07:34:49 --> UTF-8 Support Enabled
INFO - 2023-10-25 07:34:49 --> Utf8 Class Initialized
INFO - 2023-10-25 07:34:49 --> URI Class Initialized
INFO - 2023-10-25 07:34:49 --> Router Class Initialized
INFO - 2023-10-25 07:34:49 --> Output Class Initialized
INFO - 2023-10-25 07:34:49 --> Security Class Initialized
DEBUG - 2023-10-25 07:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 07:34:49 --> Input Class Initialized
INFO - 2023-10-25 07:34:49 --> Language Class Initialized
INFO - 2023-10-25 07:34:49 --> Loader Class Initialized
INFO - 2023-10-25 07:34:49 --> Helper loaded: url_helper
INFO - 2023-10-25 07:34:49 --> Helper loaded: file_helper
INFO - 2023-10-25 07:34:49 --> Helper loaded: html_helper
INFO - 2023-10-25 07:34:49 --> Helper loaded: text_helper
INFO - 2023-10-25 07:34:49 --> Helper loaded: form_helper
INFO - 2023-10-25 07:34:49 --> Helper loaded: lang_helper
INFO - 2023-10-25 07:34:49 --> Helper loaded: security_helper
INFO - 2023-10-25 07:34:49 --> Helper loaded: cookie_helper
INFO - 2023-10-25 07:34:49 --> Database Driver Class Initialized
INFO - 2023-10-25 07:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 07:34:49 --> Parser Class Initialized
INFO - 2023-10-25 07:34:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 07:34:49 --> Pagination Class Initialized
INFO - 2023-10-25 07:34:49 --> Form Validation Class Initialized
INFO - 2023-10-25 07:34:49 --> Controller Class Initialized
INFO - 2023-10-25 07:34:49 --> Model Class Initialized
DEBUG - 2023-10-25 07:34:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 07:34:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:34:49 --> Model Class Initialized
DEBUG - 2023-10-25 07:34:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:34:49 --> Model Class Initialized
INFO - 2023-10-25 07:34:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-25 07:34:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:34:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 07:34:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 07:34:49 --> Model Class Initialized
INFO - 2023-10-25 07:34:49 --> Model Class Initialized
INFO - 2023-10-25 07:34:49 --> Model Class Initialized
INFO - 2023-10-25 07:34:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-25 07:34:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-25 07:34:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 07:34:49 --> Final output sent to browser
DEBUG - 2023-10-25 07:34:49 --> Total execution time: 0.1280
ERROR - 2023-10-25 07:34:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 07:34:50 --> Config Class Initialized
INFO - 2023-10-25 07:34:50 --> Hooks Class Initialized
DEBUG - 2023-10-25 07:34:50 --> UTF-8 Support Enabled
INFO - 2023-10-25 07:34:50 --> Utf8 Class Initialized
INFO - 2023-10-25 07:34:50 --> URI Class Initialized
INFO - 2023-10-25 07:34:50 --> Router Class Initialized
INFO - 2023-10-25 07:34:50 --> Output Class Initialized
INFO - 2023-10-25 07:34:50 --> Security Class Initialized
DEBUG - 2023-10-25 07:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 07:34:50 --> Input Class Initialized
INFO - 2023-10-25 07:34:50 --> Language Class Initialized
INFO - 2023-10-25 07:34:50 --> Loader Class Initialized
INFO - 2023-10-25 07:34:50 --> Helper loaded: url_helper
INFO - 2023-10-25 07:34:50 --> Helper loaded: file_helper
INFO - 2023-10-25 07:34:50 --> Helper loaded: html_helper
INFO - 2023-10-25 07:34:50 --> Helper loaded: text_helper
INFO - 2023-10-25 07:34:50 --> Helper loaded: form_helper
INFO - 2023-10-25 07:34:50 --> Helper loaded: lang_helper
INFO - 2023-10-25 07:34:50 --> Helper loaded: security_helper
INFO - 2023-10-25 07:34:50 --> Helper loaded: cookie_helper
INFO - 2023-10-25 07:34:50 --> Database Driver Class Initialized
INFO - 2023-10-25 07:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 07:34:50 --> Parser Class Initialized
INFO - 2023-10-25 07:34:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 07:34:50 --> Pagination Class Initialized
INFO - 2023-10-25 07:34:50 --> Form Validation Class Initialized
INFO - 2023-10-25 07:34:50 --> Controller Class Initialized
INFO - 2023-10-25 07:34:50 --> Model Class Initialized
DEBUG - 2023-10-25 07:34:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 07:34:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:34:50 --> Model Class Initialized
DEBUG - 2023-10-25 07:34:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:34:50 --> Model Class Initialized
INFO - 2023-10-25 07:34:50 --> Final output sent to browser
DEBUG - 2023-10-25 07:34:50 --> Total execution time: 0.0374
ERROR - 2023-10-25 07:34:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 07:34:53 --> Config Class Initialized
INFO - 2023-10-25 07:34:53 --> Hooks Class Initialized
DEBUG - 2023-10-25 07:34:53 --> UTF-8 Support Enabled
INFO - 2023-10-25 07:34:53 --> Utf8 Class Initialized
INFO - 2023-10-25 07:34:53 --> URI Class Initialized
DEBUG - 2023-10-25 07:34:53 --> No URI present. Default controller set.
INFO - 2023-10-25 07:34:53 --> Router Class Initialized
INFO - 2023-10-25 07:34:53 --> Output Class Initialized
INFO - 2023-10-25 07:34:53 --> Security Class Initialized
DEBUG - 2023-10-25 07:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 07:34:53 --> Input Class Initialized
INFO - 2023-10-25 07:34:53 --> Language Class Initialized
INFO - 2023-10-25 07:34:53 --> Loader Class Initialized
INFO - 2023-10-25 07:34:53 --> Helper loaded: url_helper
INFO - 2023-10-25 07:34:53 --> Helper loaded: file_helper
INFO - 2023-10-25 07:34:53 --> Helper loaded: html_helper
INFO - 2023-10-25 07:34:53 --> Helper loaded: text_helper
INFO - 2023-10-25 07:34:53 --> Helper loaded: form_helper
INFO - 2023-10-25 07:34:53 --> Helper loaded: lang_helper
INFO - 2023-10-25 07:34:53 --> Helper loaded: security_helper
INFO - 2023-10-25 07:34:53 --> Helper loaded: cookie_helper
INFO - 2023-10-25 07:34:53 --> Database Driver Class Initialized
INFO - 2023-10-25 07:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 07:34:53 --> Parser Class Initialized
INFO - 2023-10-25 07:34:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 07:34:53 --> Pagination Class Initialized
INFO - 2023-10-25 07:34:53 --> Form Validation Class Initialized
INFO - 2023-10-25 07:34:53 --> Controller Class Initialized
INFO - 2023-10-25 07:34:53 --> Model Class Initialized
DEBUG - 2023-10-25 07:34:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:34:53 --> Model Class Initialized
DEBUG - 2023-10-25 07:34:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:34:53 --> Model Class Initialized
INFO - 2023-10-25 07:34:53 --> Model Class Initialized
INFO - 2023-10-25 07:34:53 --> Model Class Initialized
INFO - 2023-10-25 07:34:53 --> Model Class Initialized
DEBUG - 2023-10-25 07:34:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 07:34:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:34:53 --> Model Class Initialized
INFO - 2023-10-25 07:34:53 --> Model Class Initialized
INFO - 2023-10-25 07:34:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-25 07:34:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:34:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 07:34:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 07:34:53 --> Model Class Initialized
INFO - 2023-10-25 07:34:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-25 07:34:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-25 07:34:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 07:34:53 --> Final output sent to browser
DEBUG - 2023-10-25 07:34:53 --> Total execution time: 0.1935
ERROR - 2023-10-25 07:35:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 07:35:46 --> Config Class Initialized
INFO - 2023-10-25 07:35:46 --> Hooks Class Initialized
DEBUG - 2023-10-25 07:35:46 --> UTF-8 Support Enabled
INFO - 2023-10-25 07:35:46 --> Utf8 Class Initialized
INFO - 2023-10-25 07:35:46 --> URI Class Initialized
INFO - 2023-10-25 07:35:46 --> Router Class Initialized
INFO - 2023-10-25 07:35:46 --> Output Class Initialized
INFO - 2023-10-25 07:35:46 --> Security Class Initialized
DEBUG - 2023-10-25 07:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 07:35:46 --> Input Class Initialized
INFO - 2023-10-25 07:35:46 --> Language Class Initialized
INFO - 2023-10-25 07:35:46 --> Loader Class Initialized
INFO - 2023-10-25 07:35:46 --> Helper loaded: url_helper
INFO - 2023-10-25 07:35:46 --> Helper loaded: file_helper
INFO - 2023-10-25 07:35:46 --> Helper loaded: html_helper
INFO - 2023-10-25 07:35:46 --> Helper loaded: text_helper
INFO - 2023-10-25 07:35:46 --> Helper loaded: form_helper
INFO - 2023-10-25 07:35:46 --> Helper loaded: lang_helper
INFO - 2023-10-25 07:35:46 --> Helper loaded: security_helper
INFO - 2023-10-25 07:35:46 --> Helper loaded: cookie_helper
INFO - 2023-10-25 07:35:46 --> Database Driver Class Initialized
INFO - 2023-10-25 07:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 07:35:46 --> Parser Class Initialized
INFO - 2023-10-25 07:35:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 07:35:46 --> Pagination Class Initialized
INFO - 2023-10-25 07:35:46 --> Form Validation Class Initialized
INFO - 2023-10-25 07:35:46 --> Controller Class Initialized
INFO - 2023-10-25 07:35:46 --> Model Class Initialized
DEBUG - 2023-10-25 07:35:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:35:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-25 07:35:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:35:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 07:35:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 07:35:46 --> Model Class Initialized
INFO - 2023-10-25 07:35:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 07:35:46 --> Final output sent to browser
DEBUG - 2023-10-25 07:35:46 --> Total execution time: 0.0296
ERROR - 2023-10-25 07:35:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 07:35:46 --> Config Class Initialized
INFO - 2023-10-25 07:35:46 --> Hooks Class Initialized
DEBUG - 2023-10-25 07:35:46 --> UTF-8 Support Enabled
INFO - 2023-10-25 07:35:46 --> Utf8 Class Initialized
INFO - 2023-10-25 07:35:46 --> URI Class Initialized
INFO - 2023-10-25 07:35:46 --> Router Class Initialized
INFO - 2023-10-25 07:35:46 --> Output Class Initialized
INFO - 2023-10-25 07:35:46 --> Security Class Initialized
DEBUG - 2023-10-25 07:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 07:35:46 --> Input Class Initialized
INFO - 2023-10-25 07:35:46 --> Language Class Initialized
INFO - 2023-10-25 07:35:46 --> Loader Class Initialized
INFO - 2023-10-25 07:35:46 --> Helper loaded: url_helper
INFO - 2023-10-25 07:35:46 --> Helper loaded: file_helper
INFO - 2023-10-25 07:35:46 --> Helper loaded: html_helper
INFO - 2023-10-25 07:35:46 --> Helper loaded: text_helper
INFO - 2023-10-25 07:35:46 --> Helper loaded: form_helper
INFO - 2023-10-25 07:35:46 --> Helper loaded: lang_helper
INFO - 2023-10-25 07:35:46 --> Helper loaded: security_helper
INFO - 2023-10-25 07:35:46 --> Helper loaded: cookie_helper
INFO - 2023-10-25 07:35:46 --> Database Driver Class Initialized
INFO - 2023-10-25 07:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 07:35:46 --> Parser Class Initialized
INFO - 2023-10-25 07:35:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 07:35:46 --> Pagination Class Initialized
INFO - 2023-10-25 07:35:46 --> Form Validation Class Initialized
INFO - 2023-10-25 07:35:46 --> Controller Class Initialized
INFO - 2023-10-25 07:35:46 --> Model Class Initialized
DEBUG - 2023-10-25 07:35:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:35:46 --> Model Class Initialized
DEBUG - 2023-10-25 07:35:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:35:46 --> Model Class Initialized
INFO - 2023-10-25 07:35:46 --> Model Class Initialized
INFO - 2023-10-25 07:35:46 --> Model Class Initialized
INFO - 2023-10-25 07:35:46 --> Model Class Initialized
DEBUG - 2023-10-25 07:35:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 07:35:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:35:46 --> Model Class Initialized
INFO - 2023-10-25 07:35:46 --> Model Class Initialized
INFO - 2023-10-25 07:35:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-25 07:35:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:35:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 07:35:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 07:35:46 --> Model Class Initialized
INFO - 2023-10-25 07:35:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-25 07:35:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-25 07:35:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 07:35:46 --> Final output sent to browser
DEBUG - 2023-10-25 07:35:46 --> Total execution time: 0.1933
ERROR - 2023-10-25 07:36:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 07:36:15 --> Config Class Initialized
INFO - 2023-10-25 07:36:15 --> Hooks Class Initialized
DEBUG - 2023-10-25 07:36:15 --> UTF-8 Support Enabled
INFO - 2023-10-25 07:36:15 --> Utf8 Class Initialized
INFO - 2023-10-25 07:36:15 --> URI Class Initialized
INFO - 2023-10-25 07:36:15 --> Router Class Initialized
INFO - 2023-10-25 07:36:15 --> Output Class Initialized
INFO - 2023-10-25 07:36:15 --> Security Class Initialized
DEBUG - 2023-10-25 07:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 07:36:15 --> Input Class Initialized
INFO - 2023-10-25 07:36:15 --> Language Class Initialized
INFO - 2023-10-25 07:36:15 --> Loader Class Initialized
INFO - 2023-10-25 07:36:15 --> Helper loaded: url_helper
INFO - 2023-10-25 07:36:15 --> Helper loaded: file_helper
INFO - 2023-10-25 07:36:15 --> Helper loaded: html_helper
INFO - 2023-10-25 07:36:15 --> Helper loaded: text_helper
INFO - 2023-10-25 07:36:15 --> Helper loaded: form_helper
INFO - 2023-10-25 07:36:15 --> Helper loaded: lang_helper
INFO - 2023-10-25 07:36:15 --> Helper loaded: security_helper
INFO - 2023-10-25 07:36:15 --> Helper loaded: cookie_helper
INFO - 2023-10-25 07:36:15 --> Database Driver Class Initialized
INFO - 2023-10-25 07:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 07:36:15 --> Parser Class Initialized
INFO - 2023-10-25 07:36:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 07:36:15 --> Pagination Class Initialized
INFO - 2023-10-25 07:36:15 --> Form Validation Class Initialized
INFO - 2023-10-25 07:36:15 --> Controller Class Initialized
INFO - 2023-10-25 07:36:15 --> Model Class Initialized
INFO - 2023-10-25 07:36:15 --> Model Class Initialized
INFO - 2023-10-25 07:36:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-10-25 07:36:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:36:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 07:36:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 07:36:15 --> Model Class Initialized
INFO - 2023-10-25 07:36:15 --> Model Class Initialized
INFO - 2023-10-25 07:36:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-25 07:36:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-25 07:36:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 07:36:15 --> Final output sent to browser
DEBUG - 2023-10-25 07:36:15 --> Total execution time: 0.1301
ERROR - 2023-10-25 07:36:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 07:36:16 --> Config Class Initialized
INFO - 2023-10-25 07:36:16 --> Hooks Class Initialized
DEBUG - 2023-10-25 07:36:16 --> UTF-8 Support Enabled
INFO - 2023-10-25 07:36:16 --> Utf8 Class Initialized
INFO - 2023-10-25 07:36:16 --> URI Class Initialized
INFO - 2023-10-25 07:36:16 --> Router Class Initialized
INFO - 2023-10-25 07:36:16 --> Output Class Initialized
INFO - 2023-10-25 07:36:16 --> Security Class Initialized
DEBUG - 2023-10-25 07:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 07:36:16 --> Input Class Initialized
INFO - 2023-10-25 07:36:16 --> Language Class Initialized
INFO - 2023-10-25 07:36:16 --> Loader Class Initialized
INFO - 2023-10-25 07:36:16 --> Helper loaded: url_helper
INFO - 2023-10-25 07:36:16 --> Helper loaded: file_helper
INFO - 2023-10-25 07:36:16 --> Helper loaded: html_helper
INFO - 2023-10-25 07:36:16 --> Helper loaded: text_helper
INFO - 2023-10-25 07:36:16 --> Helper loaded: form_helper
INFO - 2023-10-25 07:36:16 --> Helper loaded: lang_helper
INFO - 2023-10-25 07:36:16 --> Helper loaded: security_helper
INFO - 2023-10-25 07:36:16 --> Helper loaded: cookie_helper
INFO - 2023-10-25 07:36:16 --> Database Driver Class Initialized
INFO - 2023-10-25 07:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 07:36:16 --> Parser Class Initialized
INFO - 2023-10-25 07:36:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 07:36:16 --> Pagination Class Initialized
INFO - 2023-10-25 07:36:16 --> Form Validation Class Initialized
INFO - 2023-10-25 07:36:16 --> Controller Class Initialized
INFO - 2023-10-25 07:36:16 --> Model Class Initialized
INFO - 2023-10-25 07:36:16 --> Model Class Initialized
INFO - 2023-10-25 07:36:16 --> Final output sent to browser
DEBUG - 2023-10-25 07:36:16 --> Total execution time: 0.0480
ERROR - 2023-10-25 07:36:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 07:36:23 --> Config Class Initialized
INFO - 2023-10-25 07:36:23 --> Hooks Class Initialized
DEBUG - 2023-10-25 07:36:23 --> UTF-8 Support Enabled
INFO - 2023-10-25 07:36:23 --> Utf8 Class Initialized
INFO - 2023-10-25 07:36:23 --> URI Class Initialized
INFO - 2023-10-25 07:36:23 --> Router Class Initialized
INFO - 2023-10-25 07:36:23 --> Output Class Initialized
INFO - 2023-10-25 07:36:23 --> Security Class Initialized
DEBUG - 2023-10-25 07:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 07:36:23 --> Input Class Initialized
INFO - 2023-10-25 07:36:23 --> Language Class Initialized
INFO - 2023-10-25 07:36:23 --> Loader Class Initialized
INFO - 2023-10-25 07:36:23 --> Helper loaded: url_helper
INFO - 2023-10-25 07:36:23 --> Helper loaded: file_helper
INFO - 2023-10-25 07:36:23 --> Helper loaded: html_helper
INFO - 2023-10-25 07:36:23 --> Helper loaded: text_helper
INFO - 2023-10-25 07:36:23 --> Helper loaded: form_helper
INFO - 2023-10-25 07:36:23 --> Helper loaded: lang_helper
INFO - 2023-10-25 07:36:23 --> Helper loaded: security_helper
INFO - 2023-10-25 07:36:23 --> Helper loaded: cookie_helper
INFO - 2023-10-25 07:36:23 --> Database Driver Class Initialized
INFO - 2023-10-25 07:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 07:36:23 --> Parser Class Initialized
INFO - 2023-10-25 07:36:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 07:36:23 --> Pagination Class Initialized
INFO - 2023-10-25 07:36:23 --> Form Validation Class Initialized
INFO - 2023-10-25 07:36:23 --> Controller Class Initialized
INFO - 2023-10-25 07:36:23 --> Model Class Initialized
DEBUG - 2023-10-25 07:36:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:36:23 --> Model Class Initialized
DEBUG - 2023-10-25 07:36:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:36:23 --> Model Class Initialized
INFO - 2023-10-25 07:36:23 --> Model Class Initialized
INFO - 2023-10-25 07:36:23 --> Model Class Initialized
INFO - 2023-10-25 07:36:23 --> Model Class Initialized
DEBUG - 2023-10-25 07:36:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 07:36:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:36:23 --> Model Class Initialized
INFO - 2023-10-25 07:36:23 --> Model Class Initialized
INFO - 2023-10-25 07:36:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-25 07:36:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:36:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 07:36:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 07:36:23 --> Model Class Initialized
INFO - 2023-10-25 07:36:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-25 07:36:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-25 07:36:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 07:36:23 --> Final output sent to browser
DEBUG - 2023-10-25 07:36:23 --> Total execution time: 0.2007
ERROR - 2023-10-25 07:36:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 07:36:34 --> Config Class Initialized
INFO - 2023-10-25 07:36:34 --> Hooks Class Initialized
DEBUG - 2023-10-25 07:36:34 --> UTF-8 Support Enabled
INFO - 2023-10-25 07:36:34 --> Utf8 Class Initialized
INFO - 2023-10-25 07:36:34 --> URI Class Initialized
INFO - 2023-10-25 07:36:34 --> Router Class Initialized
INFO - 2023-10-25 07:36:34 --> Output Class Initialized
INFO - 2023-10-25 07:36:34 --> Security Class Initialized
DEBUG - 2023-10-25 07:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 07:36:34 --> Input Class Initialized
INFO - 2023-10-25 07:36:34 --> Language Class Initialized
INFO - 2023-10-25 07:36:34 --> Loader Class Initialized
INFO - 2023-10-25 07:36:34 --> Helper loaded: url_helper
INFO - 2023-10-25 07:36:34 --> Helper loaded: file_helper
INFO - 2023-10-25 07:36:34 --> Helper loaded: html_helper
INFO - 2023-10-25 07:36:34 --> Helper loaded: text_helper
INFO - 2023-10-25 07:36:34 --> Helper loaded: form_helper
INFO - 2023-10-25 07:36:34 --> Helper loaded: lang_helper
INFO - 2023-10-25 07:36:34 --> Helper loaded: security_helper
INFO - 2023-10-25 07:36:34 --> Helper loaded: cookie_helper
INFO - 2023-10-25 07:36:34 --> Database Driver Class Initialized
INFO - 2023-10-25 07:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 07:36:34 --> Parser Class Initialized
INFO - 2023-10-25 07:36:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 07:36:34 --> Pagination Class Initialized
INFO - 2023-10-25 07:36:34 --> Form Validation Class Initialized
INFO - 2023-10-25 07:36:34 --> Controller Class Initialized
INFO - 2023-10-25 07:36:34 --> Model Class Initialized
DEBUG - 2023-10-25 07:36:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 07:36:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:36:34 --> Model Class Initialized
DEBUG - 2023-10-25 07:36:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:36:34 --> Model Class Initialized
INFO - 2023-10-25 07:36:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-25 07:36:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:36:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 07:36:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 07:36:34 --> Model Class Initialized
INFO - 2023-10-25 07:36:34 --> Model Class Initialized
INFO - 2023-10-25 07:36:34 --> Model Class Initialized
INFO - 2023-10-25 07:36:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-25 07:36:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-25 07:36:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 07:36:34 --> Final output sent to browser
DEBUG - 2023-10-25 07:36:34 --> Total execution time: 0.1322
ERROR - 2023-10-25 07:36:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 07:36:35 --> Config Class Initialized
INFO - 2023-10-25 07:36:35 --> Hooks Class Initialized
DEBUG - 2023-10-25 07:36:35 --> UTF-8 Support Enabled
INFO - 2023-10-25 07:36:35 --> Utf8 Class Initialized
INFO - 2023-10-25 07:36:35 --> URI Class Initialized
INFO - 2023-10-25 07:36:35 --> Router Class Initialized
INFO - 2023-10-25 07:36:35 --> Output Class Initialized
INFO - 2023-10-25 07:36:35 --> Security Class Initialized
DEBUG - 2023-10-25 07:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 07:36:35 --> Input Class Initialized
INFO - 2023-10-25 07:36:35 --> Language Class Initialized
INFO - 2023-10-25 07:36:35 --> Loader Class Initialized
INFO - 2023-10-25 07:36:35 --> Helper loaded: url_helper
INFO - 2023-10-25 07:36:35 --> Helper loaded: file_helper
INFO - 2023-10-25 07:36:35 --> Helper loaded: html_helper
INFO - 2023-10-25 07:36:35 --> Helper loaded: text_helper
INFO - 2023-10-25 07:36:35 --> Helper loaded: form_helper
INFO - 2023-10-25 07:36:35 --> Helper loaded: lang_helper
INFO - 2023-10-25 07:36:35 --> Helper loaded: security_helper
INFO - 2023-10-25 07:36:35 --> Helper loaded: cookie_helper
INFO - 2023-10-25 07:36:35 --> Database Driver Class Initialized
INFO - 2023-10-25 07:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 07:36:35 --> Parser Class Initialized
INFO - 2023-10-25 07:36:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 07:36:35 --> Pagination Class Initialized
INFO - 2023-10-25 07:36:35 --> Form Validation Class Initialized
INFO - 2023-10-25 07:36:35 --> Controller Class Initialized
INFO - 2023-10-25 07:36:35 --> Model Class Initialized
DEBUG - 2023-10-25 07:36:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 07:36:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:36:35 --> Model Class Initialized
DEBUG - 2023-10-25 07:36:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:36:35 --> Model Class Initialized
INFO - 2023-10-25 07:36:35 --> Final output sent to browser
DEBUG - 2023-10-25 07:36:35 --> Total execution time: 0.0424
ERROR - 2023-10-25 07:36:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 07:36:40 --> Config Class Initialized
INFO - 2023-10-25 07:36:40 --> Hooks Class Initialized
DEBUG - 2023-10-25 07:36:40 --> UTF-8 Support Enabled
INFO - 2023-10-25 07:36:40 --> Utf8 Class Initialized
INFO - 2023-10-25 07:36:40 --> URI Class Initialized
INFO - 2023-10-25 07:36:40 --> Router Class Initialized
INFO - 2023-10-25 07:36:40 --> Output Class Initialized
INFO - 2023-10-25 07:36:40 --> Security Class Initialized
DEBUG - 2023-10-25 07:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 07:36:40 --> Input Class Initialized
INFO - 2023-10-25 07:36:40 --> Language Class Initialized
INFO - 2023-10-25 07:36:40 --> Loader Class Initialized
INFO - 2023-10-25 07:36:40 --> Helper loaded: url_helper
INFO - 2023-10-25 07:36:40 --> Helper loaded: file_helper
INFO - 2023-10-25 07:36:40 --> Helper loaded: html_helper
INFO - 2023-10-25 07:36:40 --> Helper loaded: text_helper
INFO - 2023-10-25 07:36:40 --> Helper loaded: form_helper
INFO - 2023-10-25 07:36:40 --> Helper loaded: lang_helper
INFO - 2023-10-25 07:36:40 --> Helper loaded: security_helper
INFO - 2023-10-25 07:36:40 --> Helper loaded: cookie_helper
INFO - 2023-10-25 07:36:40 --> Database Driver Class Initialized
INFO - 2023-10-25 07:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 07:36:40 --> Parser Class Initialized
INFO - 2023-10-25 07:36:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 07:36:40 --> Pagination Class Initialized
INFO - 2023-10-25 07:36:40 --> Form Validation Class Initialized
INFO - 2023-10-25 07:36:40 --> Controller Class Initialized
INFO - 2023-10-25 07:36:40 --> Model Class Initialized
DEBUG - 2023-10-25 07:36:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:36:40 --> Model Class Initialized
DEBUG - 2023-10-25 07:36:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:36:40 --> Model Class Initialized
INFO - 2023-10-25 07:36:40 --> Model Class Initialized
INFO - 2023-10-25 07:36:40 --> Model Class Initialized
INFO - 2023-10-25 07:36:40 --> Model Class Initialized
DEBUG - 2023-10-25 07:36:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 07:36:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:36:40 --> Model Class Initialized
INFO - 2023-10-25 07:36:40 --> Model Class Initialized
INFO - 2023-10-25 07:36:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-25 07:36:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 07:36:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 07:36:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 07:36:40 --> Model Class Initialized
INFO - 2023-10-25 07:36:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-25 07:36:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-25 07:36:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 07:36:40 --> Final output sent to browser
DEBUG - 2023-10-25 07:36:40 --> Total execution time: 0.1900
ERROR - 2023-10-25 08:02:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 08:02:08 --> Config Class Initialized
INFO - 2023-10-25 08:02:08 --> Hooks Class Initialized
DEBUG - 2023-10-25 08:02:08 --> UTF-8 Support Enabled
INFO - 2023-10-25 08:02:08 --> Utf8 Class Initialized
INFO - 2023-10-25 08:02:08 --> URI Class Initialized
DEBUG - 2023-10-25 08:02:08 --> No URI present. Default controller set.
INFO - 2023-10-25 08:02:08 --> Router Class Initialized
INFO - 2023-10-25 08:02:08 --> Output Class Initialized
INFO - 2023-10-25 08:02:08 --> Security Class Initialized
DEBUG - 2023-10-25 08:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 08:02:08 --> Input Class Initialized
INFO - 2023-10-25 08:02:08 --> Language Class Initialized
INFO - 2023-10-25 08:02:08 --> Loader Class Initialized
INFO - 2023-10-25 08:02:08 --> Helper loaded: url_helper
INFO - 2023-10-25 08:02:08 --> Helper loaded: file_helper
INFO - 2023-10-25 08:02:08 --> Helper loaded: html_helper
INFO - 2023-10-25 08:02:08 --> Helper loaded: text_helper
INFO - 2023-10-25 08:02:08 --> Helper loaded: form_helper
INFO - 2023-10-25 08:02:08 --> Helper loaded: lang_helper
INFO - 2023-10-25 08:02:08 --> Helper loaded: security_helper
INFO - 2023-10-25 08:02:08 --> Helper loaded: cookie_helper
INFO - 2023-10-25 08:02:08 --> Database Driver Class Initialized
INFO - 2023-10-25 08:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 08:02:08 --> Parser Class Initialized
INFO - 2023-10-25 08:02:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 08:02:08 --> Pagination Class Initialized
INFO - 2023-10-25 08:02:08 --> Form Validation Class Initialized
INFO - 2023-10-25 08:02:08 --> Controller Class Initialized
INFO - 2023-10-25 08:02:08 --> Model Class Initialized
DEBUG - 2023-10-25 08:02:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-25 08:02:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 08:02:08 --> Config Class Initialized
INFO - 2023-10-25 08:02:08 --> Hooks Class Initialized
DEBUG - 2023-10-25 08:02:08 --> UTF-8 Support Enabled
INFO - 2023-10-25 08:02:08 --> Utf8 Class Initialized
INFO - 2023-10-25 08:02:08 --> URI Class Initialized
INFO - 2023-10-25 08:02:08 --> Router Class Initialized
INFO - 2023-10-25 08:02:08 --> Output Class Initialized
INFO - 2023-10-25 08:02:08 --> Security Class Initialized
DEBUG - 2023-10-25 08:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 08:02:08 --> Input Class Initialized
INFO - 2023-10-25 08:02:08 --> Language Class Initialized
INFO - 2023-10-25 08:02:08 --> Loader Class Initialized
INFO - 2023-10-25 08:02:08 --> Helper loaded: url_helper
INFO - 2023-10-25 08:02:08 --> Helper loaded: file_helper
INFO - 2023-10-25 08:02:08 --> Helper loaded: html_helper
INFO - 2023-10-25 08:02:08 --> Helper loaded: text_helper
INFO - 2023-10-25 08:02:08 --> Helper loaded: form_helper
INFO - 2023-10-25 08:02:08 --> Helper loaded: lang_helper
INFO - 2023-10-25 08:02:08 --> Helper loaded: security_helper
INFO - 2023-10-25 08:02:08 --> Helper loaded: cookie_helper
INFO - 2023-10-25 08:02:08 --> Database Driver Class Initialized
INFO - 2023-10-25 08:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 08:02:08 --> Parser Class Initialized
INFO - 2023-10-25 08:02:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 08:02:08 --> Pagination Class Initialized
INFO - 2023-10-25 08:02:08 --> Form Validation Class Initialized
INFO - 2023-10-25 08:02:08 --> Controller Class Initialized
INFO - 2023-10-25 08:02:08 --> Model Class Initialized
DEBUG - 2023-10-25 08:02:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 08:02:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-25 08:02:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 08:02:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 08:02:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 08:02:08 --> Model Class Initialized
INFO - 2023-10-25 08:02:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 08:02:08 --> Final output sent to browser
DEBUG - 2023-10-25 08:02:08 --> Total execution time: 0.0303
ERROR - 2023-10-25 09:37:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 09:37:41 --> Config Class Initialized
INFO - 2023-10-25 09:37:41 --> Hooks Class Initialized
DEBUG - 2023-10-25 09:37:41 --> UTF-8 Support Enabled
INFO - 2023-10-25 09:37:41 --> Utf8 Class Initialized
INFO - 2023-10-25 09:37:41 --> URI Class Initialized
DEBUG - 2023-10-25 09:37:41 --> No URI present. Default controller set.
INFO - 2023-10-25 09:37:41 --> Router Class Initialized
INFO - 2023-10-25 09:37:41 --> Output Class Initialized
INFO - 2023-10-25 09:37:41 --> Security Class Initialized
DEBUG - 2023-10-25 09:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 09:37:41 --> Input Class Initialized
INFO - 2023-10-25 09:37:41 --> Language Class Initialized
INFO - 2023-10-25 09:37:41 --> Loader Class Initialized
INFO - 2023-10-25 09:37:41 --> Helper loaded: url_helper
INFO - 2023-10-25 09:37:41 --> Helper loaded: file_helper
INFO - 2023-10-25 09:37:41 --> Helper loaded: html_helper
INFO - 2023-10-25 09:37:41 --> Helper loaded: text_helper
INFO - 2023-10-25 09:37:41 --> Helper loaded: form_helper
INFO - 2023-10-25 09:37:41 --> Helper loaded: lang_helper
INFO - 2023-10-25 09:37:41 --> Helper loaded: security_helper
INFO - 2023-10-25 09:37:41 --> Helper loaded: cookie_helper
INFO - 2023-10-25 09:37:41 --> Database Driver Class Initialized
INFO - 2023-10-25 09:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 09:37:41 --> Parser Class Initialized
INFO - 2023-10-25 09:37:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 09:37:41 --> Pagination Class Initialized
INFO - 2023-10-25 09:37:41 --> Form Validation Class Initialized
INFO - 2023-10-25 09:37:41 --> Controller Class Initialized
INFO - 2023-10-25 09:37:41 --> Model Class Initialized
DEBUG - 2023-10-25 09:37:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-25 09:37:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 09:37:41 --> Config Class Initialized
INFO - 2023-10-25 09:37:41 --> Hooks Class Initialized
DEBUG - 2023-10-25 09:37:41 --> UTF-8 Support Enabled
INFO - 2023-10-25 09:37:41 --> Utf8 Class Initialized
INFO - 2023-10-25 09:37:41 --> URI Class Initialized
INFO - 2023-10-25 09:37:41 --> Router Class Initialized
INFO - 2023-10-25 09:37:41 --> Output Class Initialized
INFO - 2023-10-25 09:37:41 --> Security Class Initialized
DEBUG - 2023-10-25 09:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 09:37:41 --> Input Class Initialized
INFO - 2023-10-25 09:37:41 --> Language Class Initialized
INFO - 2023-10-25 09:37:41 --> Loader Class Initialized
INFO - 2023-10-25 09:37:41 --> Helper loaded: url_helper
INFO - 2023-10-25 09:37:41 --> Helper loaded: file_helper
INFO - 2023-10-25 09:37:41 --> Helper loaded: html_helper
INFO - 2023-10-25 09:37:41 --> Helper loaded: text_helper
INFO - 2023-10-25 09:37:41 --> Helper loaded: form_helper
INFO - 2023-10-25 09:37:41 --> Helper loaded: lang_helper
INFO - 2023-10-25 09:37:41 --> Helper loaded: security_helper
INFO - 2023-10-25 09:37:41 --> Helper loaded: cookie_helper
INFO - 2023-10-25 09:37:41 --> Database Driver Class Initialized
INFO - 2023-10-25 09:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 09:37:41 --> Parser Class Initialized
INFO - 2023-10-25 09:37:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 09:37:41 --> Pagination Class Initialized
INFO - 2023-10-25 09:37:41 --> Form Validation Class Initialized
INFO - 2023-10-25 09:37:41 --> Controller Class Initialized
INFO - 2023-10-25 09:37:41 --> Model Class Initialized
DEBUG - 2023-10-25 09:37:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 09:37:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-25 09:37:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 09:37:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 09:37:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 09:37:41 --> Model Class Initialized
INFO - 2023-10-25 09:37:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 09:37:41 --> Final output sent to browser
DEBUG - 2023-10-25 09:37:41 --> Total execution time: 0.0382
ERROR - 2023-10-25 13:14:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 13:14:28 --> Config Class Initialized
INFO - 2023-10-25 13:14:28 --> Hooks Class Initialized
DEBUG - 2023-10-25 13:14:28 --> UTF-8 Support Enabled
INFO - 2023-10-25 13:14:28 --> Utf8 Class Initialized
INFO - 2023-10-25 13:14:28 --> URI Class Initialized
DEBUG - 2023-10-25 13:14:28 --> No URI present. Default controller set.
INFO - 2023-10-25 13:14:28 --> Router Class Initialized
INFO - 2023-10-25 13:14:28 --> Output Class Initialized
INFO - 2023-10-25 13:14:28 --> Security Class Initialized
DEBUG - 2023-10-25 13:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 13:14:28 --> Input Class Initialized
INFO - 2023-10-25 13:14:28 --> Language Class Initialized
INFO - 2023-10-25 13:14:28 --> Loader Class Initialized
INFO - 2023-10-25 13:14:28 --> Helper loaded: url_helper
INFO - 2023-10-25 13:14:28 --> Helper loaded: file_helper
INFO - 2023-10-25 13:14:28 --> Helper loaded: html_helper
INFO - 2023-10-25 13:14:28 --> Helper loaded: text_helper
INFO - 2023-10-25 13:14:28 --> Helper loaded: form_helper
INFO - 2023-10-25 13:14:28 --> Helper loaded: lang_helper
INFO - 2023-10-25 13:14:28 --> Helper loaded: security_helper
INFO - 2023-10-25 13:14:28 --> Helper loaded: cookie_helper
INFO - 2023-10-25 13:14:28 --> Database Driver Class Initialized
INFO - 2023-10-25 13:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 13:14:28 --> Parser Class Initialized
INFO - 2023-10-25 13:14:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 13:14:28 --> Pagination Class Initialized
INFO - 2023-10-25 13:14:28 --> Form Validation Class Initialized
INFO - 2023-10-25 13:14:28 --> Controller Class Initialized
INFO - 2023-10-25 13:14:28 --> Model Class Initialized
DEBUG - 2023-10-25 13:14:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-25 13:14:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 13:14:29 --> Config Class Initialized
INFO - 2023-10-25 13:14:29 --> Hooks Class Initialized
DEBUG - 2023-10-25 13:14:29 --> UTF-8 Support Enabled
INFO - 2023-10-25 13:14:29 --> Utf8 Class Initialized
INFO - 2023-10-25 13:14:29 --> URI Class Initialized
INFO - 2023-10-25 13:14:29 --> Router Class Initialized
INFO - 2023-10-25 13:14:29 --> Output Class Initialized
INFO - 2023-10-25 13:14:29 --> Security Class Initialized
DEBUG - 2023-10-25 13:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 13:14:29 --> Input Class Initialized
INFO - 2023-10-25 13:14:29 --> Language Class Initialized
INFO - 2023-10-25 13:14:29 --> Loader Class Initialized
INFO - 2023-10-25 13:14:29 --> Helper loaded: url_helper
INFO - 2023-10-25 13:14:29 --> Helper loaded: file_helper
INFO - 2023-10-25 13:14:29 --> Helper loaded: html_helper
INFO - 2023-10-25 13:14:29 --> Helper loaded: text_helper
INFO - 2023-10-25 13:14:29 --> Helper loaded: form_helper
INFO - 2023-10-25 13:14:29 --> Helper loaded: lang_helper
INFO - 2023-10-25 13:14:29 --> Helper loaded: security_helper
INFO - 2023-10-25 13:14:29 --> Helper loaded: cookie_helper
INFO - 2023-10-25 13:14:29 --> Database Driver Class Initialized
INFO - 2023-10-25 13:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 13:14:29 --> Parser Class Initialized
INFO - 2023-10-25 13:14:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 13:14:29 --> Pagination Class Initialized
INFO - 2023-10-25 13:14:29 --> Form Validation Class Initialized
INFO - 2023-10-25 13:14:29 --> Controller Class Initialized
INFO - 2023-10-25 13:14:29 --> Model Class Initialized
DEBUG - 2023-10-25 13:14:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 13:14:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-25 13:14:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 13:14:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 13:14:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 13:14:29 --> Model Class Initialized
INFO - 2023-10-25 13:14:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 13:14:29 --> Final output sent to browser
DEBUG - 2023-10-25 13:14:29 --> Total execution time: 0.0345
ERROR - 2023-10-25 13:14:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 13:14:46 --> Config Class Initialized
INFO - 2023-10-25 13:14:46 --> Hooks Class Initialized
DEBUG - 2023-10-25 13:14:46 --> UTF-8 Support Enabled
INFO - 2023-10-25 13:14:46 --> Utf8 Class Initialized
INFO - 2023-10-25 13:14:46 --> URI Class Initialized
INFO - 2023-10-25 13:14:46 --> Router Class Initialized
INFO - 2023-10-25 13:14:46 --> Output Class Initialized
INFO - 2023-10-25 13:14:46 --> Security Class Initialized
DEBUG - 2023-10-25 13:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 13:14:46 --> Input Class Initialized
INFO - 2023-10-25 13:14:46 --> Language Class Initialized
INFO - 2023-10-25 13:14:46 --> Loader Class Initialized
INFO - 2023-10-25 13:14:46 --> Helper loaded: url_helper
INFO - 2023-10-25 13:14:46 --> Helper loaded: file_helper
INFO - 2023-10-25 13:14:46 --> Helper loaded: html_helper
INFO - 2023-10-25 13:14:46 --> Helper loaded: text_helper
INFO - 2023-10-25 13:14:46 --> Helper loaded: form_helper
INFO - 2023-10-25 13:14:46 --> Helper loaded: lang_helper
INFO - 2023-10-25 13:14:46 --> Helper loaded: security_helper
INFO - 2023-10-25 13:14:46 --> Helper loaded: cookie_helper
INFO - 2023-10-25 13:14:46 --> Database Driver Class Initialized
INFO - 2023-10-25 13:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 13:14:46 --> Parser Class Initialized
INFO - 2023-10-25 13:14:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 13:14:46 --> Pagination Class Initialized
INFO - 2023-10-25 13:14:46 --> Form Validation Class Initialized
INFO - 2023-10-25 13:14:46 --> Controller Class Initialized
INFO - 2023-10-25 13:14:46 --> Model Class Initialized
DEBUG - 2023-10-25 13:14:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 13:14:46 --> Model Class Initialized
INFO - 2023-10-25 13:14:46 --> Final output sent to browser
DEBUG - 2023-10-25 13:14:46 --> Total execution time: 0.0212
ERROR - 2023-10-25 13:14:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 13:14:46 --> Config Class Initialized
INFO - 2023-10-25 13:14:46 --> Hooks Class Initialized
DEBUG - 2023-10-25 13:14:46 --> UTF-8 Support Enabled
INFO - 2023-10-25 13:14:46 --> Utf8 Class Initialized
INFO - 2023-10-25 13:14:46 --> URI Class Initialized
DEBUG - 2023-10-25 13:14:46 --> No URI present. Default controller set.
INFO - 2023-10-25 13:14:46 --> Router Class Initialized
INFO - 2023-10-25 13:14:46 --> Output Class Initialized
INFO - 2023-10-25 13:14:46 --> Security Class Initialized
DEBUG - 2023-10-25 13:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 13:14:46 --> Input Class Initialized
INFO - 2023-10-25 13:14:46 --> Language Class Initialized
INFO - 2023-10-25 13:14:46 --> Loader Class Initialized
INFO - 2023-10-25 13:14:46 --> Helper loaded: url_helper
INFO - 2023-10-25 13:14:46 --> Helper loaded: file_helper
INFO - 2023-10-25 13:14:46 --> Helper loaded: html_helper
INFO - 2023-10-25 13:14:46 --> Helper loaded: text_helper
INFO - 2023-10-25 13:14:46 --> Helper loaded: form_helper
INFO - 2023-10-25 13:14:46 --> Helper loaded: lang_helper
INFO - 2023-10-25 13:14:46 --> Helper loaded: security_helper
INFO - 2023-10-25 13:14:46 --> Helper loaded: cookie_helper
INFO - 2023-10-25 13:14:46 --> Database Driver Class Initialized
INFO - 2023-10-25 13:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 13:14:46 --> Parser Class Initialized
INFO - 2023-10-25 13:14:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 13:14:46 --> Pagination Class Initialized
INFO - 2023-10-25 13:14:46 --> Form Validation Class Initialized
INFO - 2023-10-25 13:14:46 --> Controller Class Initialized
INFO - 2023-10-25 13:14:46 --> Model Class Initialized
DEBUG - 2023-10-25 13:14:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 13:14:46 --> Model Class Initialized
DEBUG - 2023-10-25 13:14:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 13:14:46 --> Model Class Initialized
INFO - 2023-10-25 13:14:46 --> Model Class Initialized
INFO - 2023-10-25 13:14:46 --> Model Class Initialized
INFO - 2023-10-25 13:14:46 --> Model Class Initialized
DEBUG - 2023-10-25 13:14:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 13:14:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 13:14:46 --> Model Class Initialized
INFO - 2023-10-25 13:14:46 --> Model Class Initialized
INFO - 2023-10-25 13:14:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-25 13:14:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 13:14:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 13:14:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 13:14:46 --> Model Class Initialized
INFO - 2023-10-25 13:14:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-25 13:14:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-25 13:14:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 13:14:47 --> Final output sent to browser
DEBUG - 2023-10-25 13:14:47 --> Total execution time: 0.3881
ERROR - 2023-10-25 13:14:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 13:14:48 --> Config Class Initialized
INFO - 2023-10-25 13:14:48 --> Hooks Class Initialized
DEBUG - 2023-10-25 13:14:48 --> UTF-8 Support Enabled
INFO - 2023-10-25 13:14:48 --> Utf8 Class Initialized
INFO - 2023-10-25 13:14:48 --> URI Class Initialized
INFO - 2023-10-25 13:14:48 --> Router Class Initialized
INFO - 2023-10-25 13:14:48 --> Output Class Initialized
INFO - 2023-10-25 13:14:48 --> Security Class Initialized
DEBUG - 2023-10-25 13:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 13:14:48 --> Input Class Initialized
INFO - 2023-10-25 13:14:48 --> Language Class Initialized
INFO - 2023-10-25 13:14:48 --> Loader Class Initialized
INFO - 2023-10-25 13:14:48 --> Helper loaded: url_helper
INFO - 2023-10-25 13:14:48 --> Helper loaded: file_helper
INFO - 2023-10-25 13:14:48 --> Helper loaded: html_helper
INFO - 2023-10-25 13:14:48 --> Helper loaded: text_helper
INFO - 2023-10-25 13:14:48 --> Helper loaded: form_helper
INFO - 2023-10-25 13:14:48 --> Helper loaded: lang_helper
INFO - 2023-10-25 13:14:48 --> Helper loaded: security_helper
INFO - 2023-10-25 13:14:48 --> Helper loaded: cookie_helper
INFO - 2023-10-25 13:14:48 --> Database Driver Class Initialized
INFO - 2023-10-25 13:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 13:14:48 --> Parser Class Initialized
INFO - 2023-10-25 13:14:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 13:14:48 --> Pagination Class Initialized
INFO - 2023-10-25 13:14:48 --> Form Validation Class Initialized
INFO - 2023-10-25 13:14:48 --> Controller Class Initialized
DEBUG - 2023-10-25 13:14:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 13:14:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 13:14:48 --> Model Class Initialized
INFO - 2023-10-25 13:14:48 --> Final output sent to browser
DEBUG - 2023-10-25 13:14:48 --> Total execution time: 0.0130
ERROR - 2023-10-25 13:15:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 13:15:02 --> Config Class Initialized
INFO - 2023-10-25 13:15:02 --> Hooks Class Initialized
DEBUG - 2023-10-25 13:15:02 --> UTF-8 Support Enabled
INFO - 2023-10-25 13:15:02 --> Utf8 Class Initialized
INFO - 2023-10-25 13:15:02 --> URI Class Initialized
INFO - 2023-10-25 13:15:02 --> Router Class Initialized
INFO - 2023-10-25 13:15:02 --> Output Class Initialized
INFO - 2023-10-25 13:15:02 --> Security Class Initialized
DEBUG - 2023-10-25 13:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 13:15:02 --> Input Class Initialized
INFO - 2023-10-25 13:15:02 --> Language Class Initialized
INFO - 2023-10-25 13:15:02 --> Loader Class Initialized
INFO - 2023-10-25 13:15:02 --> Helper loaded: url_helper
INFO - 2023-10-25 13:15:02 --> Helper loaded: file_helper
INFO - 2023-10-25 13:15:02 --> Helper loaded: html_helper
INFO - 2023-10-25 13:15:02 --> Helper loaded: text_helper
INFO - 2023-10-25 13:15:02 --> Helper loaded: form_helper
INFO - 2023-10-25 13:15:02 --> Helper loaded: lang_helper
INFO - 2023-10-25 13:15:02 --> Helper loaded: security_helper
INFO - 2023-10-25 13:15:02 --> Helper loaded: cookie_helper
INFO - 2023-10-25 13:15:02 --> Database Driver Class Initialized
INFO - 2023-10-25 13:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 13:15:02 --> Parser Class Initialized
INFO - 2023-10-25 13:15:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 13:15:02 --> Pagination Class Initialized
INFO - 2023-10-25 13:15:02 --> Form Validation Class Initialized
INFO - 2023-10-25 13:15:02 --> Controller Class Initialized
DEBUG - 2023-10-25 13:15:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 13:15:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 13:15:02 --> Model Class Initialized
INFO - 2023-10-25 13:15:02 --> Model Class Initialized
DEBUG - 2023-10-25 13:15:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 13:15:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 13:15:02 --> Model Class Initialized
DEBUG - 2023-10-25 13:15:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 13:15:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gst/list.php
DEBUG - 2023-10-25 13:15:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 13:15:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 13:15:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 13:15:02 --> Model Class Initialized
INFO - 2023-10-25 13:15:02 --> Model Class Initialized
INFO - 2023-10-25 13:15:02 --> Model Class Initialized
INFO - 2023-10-25 13:15:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-25 13:15:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-25 13:15:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 13:15:02 --> Final output sent to browser
DEBUG - 2023-10-25 13:15:02 --> Total execution time: 0.2008
ERROR - 2023-10-25 13:15:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 13:15:17 --> Config Class Initialized
INFO - 2023-10-25 13:15:17 --> Hooks Class Initialized
DEBUG - 2023-10-25 13:15:17 --> UTF-8 Support Enabled
INFO - 2023-10-25 13:15:17 --> Utf8 Class Initialized
INFO - 2023-10-25 13:15:17 --> URI Class Initialized
INFO - 2023-10-25 13:15:17 --> Router Class Initialized
INFO - 2023-10-25 13:15:17 --> Output Class Initialized
INFO - 2023-10-25 13:15:17 --> Security Class Initialized
DEBUG - 2023-10-25 13:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 13:15:17 --> Input Class Initialized
INFO - 2023-10-25 13:15:17 --> Language Class Initialized
INFO - 2023-10-25 13:15:17 --> Loader Class Initialized
INFO - 2023-10-25 13:15:17 --> Helper loaded: url_helper
INFO - 2023-10-25 13:15:17 --> Helper loaded: file_helper
INFO - 2023-10-25 13:15:17 --> Helper loaded: html_helper
INFO - 2023-10-25 13:15:17 --> Helper loaded: text_helper
INFO - 2023-10-25 13:15:17 --> Helper loaded: form_helper
INFO - 2023-10-25 13:15:17 --> Helper loaded: lang_helper
INFO - 2023-10-25 13:15:17 --> Helper loaded: security_helper
INFO - 2023-10-25 13:15:17 --> Helper loaded: cookie_helper
INFO - 2023-10-25 13:15:17 --> Database Driver Class Initialized
INFO - 2023-10-25 13:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 13:15:17 --> Parser Class Initialized
INFO - 2023-10-25 13:15:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 13:15:17 --> Pagination Class Initialized
INFO - 2023-10-25 13:15:17 --> Form Validation Class Initialized
INFO - 2023-10-25 13:15:17 --> Controller Class Initialized
DEBUG - 2023-10-25 13:15:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 13:15:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 13:15:17 --> Model Class Initialized
DEBUG - 2023-10-25 13:15:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 13:15:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 13:15:17 --> Model Class Initialized
DEBUG - 2023-10-25 13:15:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 13:15:17 --> Model Class Initialized
INFO - 2023-10-25 13:15:17 --> Final output sent to browser
DEBUG - 2023-10-25 13:15:17 --> Total execution time: 0.0339
ERROR - 2023-10-25 14:00:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 14:00:06 --> Config Class Initialized
INFO - 2023-10-25 14:00:06 --> Hooks Class Initialized
DEBUG - 2023-10-25 14:00:06 --> UTF-8 Support Enabled
INFO - 2023-10-25 14:00:06 --> Utf8 Class Initialized
INFO - 2023-10-25 14:00:06 --> URI Class Initialized
DEBUG - 2023-10-25 14:00:06 --> No URI present. Default controller set.
INFO - 2023-10-25 14:00:06 --> Router Class Initialized
INFO - 2023-10-25 14:00:06 --> Output Class Initialized
INFO - 2023-10-25 14:00:06 --> Security Class Initialized
DEBUG - 2023-10-25 14:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 14:00:06 --> Input Class Initialized
INFO - 2023-10-25 14:00:06 --> Language Class Initialized
INFO - 2023-10-25 14:00:06 --> Loader Class Initialized
INFO - 2023-10-25 14:00:06 --> Helper loaded: url_helper
INFO - 2023-10-25 14:00:06 --> Helper loaded: file_helper
INFO - 2023-10-25 14:00:06 --> Helper loaded: html_helper
INFO - 2023-10-25 14:00:06 --> Helper loaded: text_helper
INFO - 2023-10-25 14:00:06 --> Helper loaded: form_helper
INFO - 2023-10-25 14:00:06 --> Helper loaded: lang_helper
INFO - 2023-10-25 14:00:06 --> Helper loaded: security_helper
INFO - 2023-10-25 14:00:06 --> Helper loaded: cookie_helper
INFO - 2023-10-25 14:00:06 --> Database Driver Class Initialized
INFO - 2023-10-25 14:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 14:00:06 --> Parser Class Initialized
INFO - 2023-10-25 14:00:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 14:00:06 --> Pagination Class Initialized
INFO - 2023-10-25 14:00:06 --> Form Validation Class Initialized
INFO - 2023-10-25 14:00:06 --> Controller Class Initialized
INFO - 2023-10-25 14:00:06 --> Model Class Initialized
DEBUG - 2023-10-25 14:00:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 14:00:06 --> Model Class Initialized
DEBUG - 2023-10-25 14:00:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 14:00:06 --> Model Class Initialized
INFO - 2023-10-25 14:00:06 --> Model Class Initialized
INFO - 2023-10-25 14:00:06 --> Model Class Initialized
INFO - 2023-10-25 14:00:06 --> Model Class Initialized
DEBUG - 2023-10-25 14:00:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 14:00:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 14:00:06 --> Model Class Initialized
INFO - 2023-10-25 14:00:06 --> Model Class Initialized
INFO - 2023-10-25 14:00:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-25 14:00:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 14:00:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 14:00:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 14:00:07 --> Model Class Initialized
INFO - 2023-10-25 14:00:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-25 14:00:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-25 14:00:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 14:00:07 --> Final output sent to browser
DEBUG - 2023-10-25 14:00:07 --> Total execution time: 0.4035
ERROR - 2023-10-25 15:02:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 15:02:11 --> Config Class Initialized
INFO - 2023-10-25 15:02:11 --> Hooks Class Initialized
DEBUG - 2023-10-25 15:02:11 --> UTF-8 Support Enabled
INFO - 2023-10-25 15:02:11 --> Utf8 Class Initialized
INFO - 2023-10-25 15:02:11 --> URI Class Initialized
DEBUG - 2023-10-25 15:02:11 --> No URI present. Default controller set.
INFO - 2023-10-25 15:02:11 --> Router Class Initialized
INFO - 2023-10-25 15:02:11 --> Output Class Initialized
INFO - 2023-10-25 15:02:11 --> Security Class Initialized
DEBUG - 2023-10-25 15:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 15:02:11 --> Input Class Initialized
INFO - 2023-10-25 15:02:11 --> Language Class Initialized
INFO - 2023-10-25 15:02:11 --> Loader Class Initialized
INFO - 2023-10-25 15:02:11 --> Helper loaded: url_helper
INFO - 2023-10-25 15:02:11 --> Helper loaded: file_helper
INFO - 2023-10-25 15:02:11 --> Helper loaded: html_helper
INFO - 2023-10-25 15:02:11 --> Helper loaded: text_helper
INFO - 2023-10-25 15:02:11 --> Helper loaded: form_helper
INFO - 2023-10-25 15:02:11 --> Helper loaded: lang_helper
INFO - 2023-10-25 15:02:11 --> Helper loaded: security_helper
INFO - 2023-10-25 15:02:11 --> Helper loaded: cookie_helper
INFO - 2023-10-25 15:02:11 --> Database Driver Class Initialized
INFO - 2023-10-25 15:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 15:02:11 --> Parser Class Initialized
INFO - 2023-10-25 15:02:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 15:02:11 --> Pagination Class Initialized
INFO - 2023-10-25 15:02:11 --> Form Validation Class Initialized
INFO - 2023-10-25 15:02:11 --> Controller Class Initialized
INFO - 2023-10-25 15:02:11 --> Model Class Initialized
DEBUG - 2023-10-25 15:02:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-25 15:02:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 15:02:11 --> Config Class Initialized
INFO - 2023-10-25 15:02:11 --> Hooks Class Initialized
DEBUG - 2023-10-25 15:02:11 --> UTF-8 Support Enabled
INFO - 2023-10-25 15:02:11 --> Utf8 Class Initialized
INFO - 2023-10-25 15:02:11 --> URI Class Initialized
INFO - 2023-10-25 15:02:11 --> Router Class Initialized
INFO - 2023-10-25 15:02:11 --> Output Class Initialized
INFO - 2023-10-25 15:02:11 --> Security Class Initialized
DEBUG - 2023-10-25 15:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 15:02:11 --> Input Class Initialized
INFO - 2023-10-25 15:02:11 --> Language Class Initialized
INFO - 2023-10-25 15:02:11 --> Loader Class Initialized
INFO - 2023-10-25 15:02:11 --> Helper loaded: url_helper
INFO - 2023-10-25 15:02:11 --> Helper loaded: file_helper
INFO - 2023-10-25 15:02:11 --> Helper loaded: html_helper
INFO - 2023-10-25 15:02:11 --> Helper loaded: text_helper
INFO - 2023-10-25 15:02:11 --> Helper loaded: form_helper
INFO - 2023-10-25 15:02:11 --> Helper loaded: lang_helper
INFO - 2023-10-25 15:02:11 --> Helper loaded: security_helper
INFO - 2023-10-25 15:02:11 --> Helper loaded: cookie_helper
INFO - 2023-10-25 15:02:11 --> Database Driver Class Initialized
INFO - 2023-10-25 15:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 15:02:11 --> Parser Class Initialized
INFO - 2023-10-25 15:02:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 15:02:11 --> Pagination Class Initialized
INFO - 2023-10-25 15:02:11 --> Form Validation Class Initialized
INFO - 2023-10-25 15:02:11 --> Controller Class Initialized
INFO - 2023-10-25 15:02:11 --> Model Class Initialized
DEBUG - 2023-10-25 15:02:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:02:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-25 15:02:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:02:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 15:02:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 15:02:11 --> Model Class Initialized
INFO - 2023-10-25 15:02:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 15:02:11 --> Final output sent to browser
DEBUG - 2023-10-25 15:02:11 --> Total execution time: 0.0318
ERROR - 2023-10-25 15:02:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 15:02:33 --> Config Class Initialized
INFO - 2023-10-25 15:02:33 --> Hooks Class Initialized
DEBUG - 2023-10-25 15:02:33 --> UTF-8 Support Enabled
INFO - 2023-10-25 15:02:33 --> Utf8 Class Initialized
INFO - 2023-10-25 15:02:33 --> URI Class Initialized
INFO - 2023-10-25 15:02:33 --> Router Class Initialized
INFO - 2023-10-25 15:02:33 --> Output Class Initialized
INFO - 2023-10-25 15:02:33 --> Security Class Initialized
DEBUG - 2023-10-25 15:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 15:02:33 --> Input Class Initialized
INFO - 2023-10-25 15:02:33 --> Language Class Initialized
INFO - 2023-10-25 15:02:33 --> Loader Class Initialized
INFO - 2023-10-25 15:02:33 --> Helper loaded: url_helper
INFO - 2023-10-25 15:02:33 --> Helper loaded: file_helper
INFO - 2023-10-25 15:02:33 --> Helper loaded: html_helper
INFO - 2023-10-25 15:02:33 --> Helper loaded: text_helper
INFO - 2023-10-25 15:02:33 --> Helper loaded: form_helper
INFO - 2023-10-25 15:02:33 --> Helper loaded: lang_helper
INFO - 2023-10-25 15:02:33 --> Helper loaded: security_helper
INFO - 2023-10-25 15:02:33 --> Helper loaded: cookie_helper
INFO - 2023-10-25 15:02:33 --> Database Driver Class Initialized
INFO - 2023-10-25 15:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 15:02:33 --> Parser Class Initialized
INFO - 2023-10-25 15:02:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 15:02:33 --> Pagination Class Initialized
INFO - 2023-10-25 15:02:33 --> Form Validation Class Initialized
INFO - 2023-10-25 15:02:33 --> Controller Class Initialized
INFO - 2023-10-25 15:02:33 --> Model Class Initialized
DEBUG - 2023-10-25 15:02:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:02:33 --> Model Class Initialized
INFO - 2023-10-25 15:02:33 --> Final output sent to browser
DEBUG - 2023-10-25 15:02:33 --> Total execution time: 0.0210
ERROR - 2023-10-25 15:02:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 15:02:33 --> Config Class Initialized
INFO - 2023-10-25 15:02:33 --> Hooks Class Initialized
DEBUG - 2023-10-25 15:02:33 --> UTF-8 Support Enabled
INFO - 2023-10-25 15:02:33 --> Utf8 Class Initialized
INFO - 2023-10-25 15:02:33 --> URI Class Initialized
DEBUG - 2023-10-25 15:02:33 --> No URI present. Default controller set.
INFO - 2023-10-25 15:02:33 --> Router Class Initialized
INFO - 2023-10-25 15:02:33 --> Output Class Initialized
INFO - 2023-10-25 15:02:33 --> Security Class Initialized
DEBUG - 2023-10-25 15:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 15:02:33 --> Input Class Initialized
INFO - 2023-10-25 15:02:33 --> Language Class Initialized
INFO - 2023-10-25 15:02:33 --> Loader Class Initialized
INFO - 2023-10-25 15:02:33 --> Helper loaded: url_helper
INFO - 2023-10-25 15:02:33 --> Helper loaded: file_helper
INFO - 2023-10-25 15:02:33 --> Helper loaded: html_helper
INFO - 2023-10-25 15:02:33 --> Helper loaded: text_helper
INFO - 2023-10-25 15:02:33 --> Helper loaded: form_helper
INFO - 2023-10-25 15:02:33 --> Helper loaded: lang_helper
INFO - 2023-10-25 15:02:33 --> Helper loaded: security_helper
INFO - 2023-10-25 15:02:33 --> Helper loaded: cookie_helper
INFO - 2023-10-25 15:02:33 --> Database Driver Class Initialized
INFO - 2023-10-25 15:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 15:02:33 --> Parser Class Initialized
INFO - 2023-10-25 15:02:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 15:02:33 --> Pagination Class Initialized
INFO - 2023-10-25 15:02:33 --> Form Validation Class Initialized
INFO - 2023-10-25 15:02:33 --> Controller Class Initialized
INFO - 2023-10-25 15:02:33 --> Model Class Initialized
DEBUG - 2023-10-25 15:02:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:02:33 --> Model Class Initialized
DEBUG - 2023-10-25 15:02:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:02:33 --> Model Class Initialized
INFO - 2023-10-25 15:02:33 --> Model Class Initialized
INFO - 2023-10-25 15:02:33 --> Model Class Initialized
INFO - 2023-10-25 15:02:33 --> Model Class Initialized
DEBUG - 2023-10-25 15:02:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 15:02:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:02:33 --> Model Class Initialized
INFO - 2023-10-25 15:02:33 --> Model Class Initialized
INFO - 2023-10-25 15:02:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-25 15:02:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:02:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 15:02:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 15:02:34 --> Model Class Initialized
INFO - 2023-10-25 15:02:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-25 15:02:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-25 15:02:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 15:02:34 --> Final output sent to browser
DEBUG - 2023-10-25 15:02:34 --> Total execution time: 0.2097
ERROR - 2023-10-25 15:02:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 15:02:49 --> Config Class Initialized
INFO - 2023-10-25 15:02:49 --> Hooks Class Initialized
DEBUG - 2023-10-25 15:02:49 --> UTF-8 Support Enabled
INFO - 2023-10-25 15:02:49 --> Utf8 Class Initialized
INFO - 2023-10-25 15:02:49 --> URI Class Initialized
INFO - 2023-10-25 15:02:49 --> Router Class Initialized
INFO - 2023-10-25 15:02:49 --> Output Class Initialized
INFO - 2023-10-25 15:02:49 --> Security Class Initialized
DEBUG - 2023-10-25 15:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 15:02:49 --> Input Class Initialized
INFO - 2023-10-25 15:02:49 --> Language Class Initialized
INFO - 2023-10-25 15:02:49 --> Loader Class Initialized
INFO - 2023-10-25 15:02:49 --> Helper loaded: url_helper
INFO - 2023-10-25 15:02:49 --> Helper loaded: file_helper
INFO - 2023-10-25 15:02:49 --> Helper loaded: html_helper
INFO - 2023-10-25 15:02:49 --> Helper loaded: text_helper
INFO - 2023-10-25 15:02:49 --> Helper loaded: form_helper
INFO - 2023-10-25 15:02:49 --> Helper loaded: lang_helper
INFO - 2023-10-25 15:02:49 --> Helper loaded: security_helper
INFO - 2023-10-25 15:02:49 --> Helper loaded: cookie_helper
INFO - 2023-10-25 15:02:49 --> Database Driver Class Initialized
INFO - 2023-10-25 15:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 15:02:49 --> Parser Class Initialized
INFO - 2023-10-25 15:02:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 15:02:49 --> Pagination Class Initialized
INFO - 2023-10-25 15:02:49 --> Form Validation Class Initialized
INFO - 2023-10-25 15:02:49 --> Controller Class Initialized
INFO - 2023-10-25 15:02:49 --> Model Class Initialized
DEBUG - 2023-10-25 15:02:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 15:02:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:02:49 --> Model Class Initialized
DEBUG - 2023-10-25 15:02:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:02:49 --> Model Class Initialized
INFO - 2023-10-25 15:02:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-25 15:02:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:02:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 15:02:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 15:02:49 --> Model Class Initialized
INFO - 2023-10-25 15:02:49 --> Model Class Initialized
INFO - 2023-10-25 15:02:49 --> Model Class Initialized
INFO - 2023-10-25 15:02:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-25 15:02:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-25 15:02:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 15:02:49 --> Final output sent to browser
DEBUG - 2023-10-25 15:02:49 --> Total execution time: 0.1472
ERROR - 2023-10-25 15:02:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 15:02:50 --> Config Class Initialized
INFO - 2023-10-25 15:02:50 --> Hooks Class Initialized
DEBUG - 2023-10-25 15:02:50 --> UTF-8 Support Enabled
INFO - 2023-10-25 15:02:50 --> Utf8 Class Initialized
INFO - 2023-10-25 15:02:50 --> URI Class Initialized
INFO - 2023-10-25 15:02:50 --> Router Class Initialized
INFO - 2023-10-25 15:02:50 --> Output Class Initialized
INFO - 2023-10-25 15:02:50 --> Security Class Initialized
DEBUG - 2023-10-25 15:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 15:02:50 --> Input Class Initialized
INFO - 2023-10-25 15:02:50 --> Language Class Initialized
INFO - 2023-10-25 15:02:50 --> Loader Class Initialized
INFO - 2023-10-25 15:02:50 --> Helper loaded: url_helper
INFO - 2023-10-25 15:02:50 --> Helper loaded: file_helper
INFO - 2023-10-25 15:02:50 --> Helper loaded: html_helper
INFO - 2023-10-25 15:02:50 --> Helper loaded: text_helper
INFO - 2023-10-25 15:02:50 --> Helper loaded: form_helper
INFO - 2023-10-25 15:02:50 --> Helper loaded: lang_helper
INFO - 2023-10-25 15:02:50 --> Helper loaded: security_helper
INFO - 2023-10-25 15:02:50 --> Helper loaded: cookie_helper
INFO - 2023-10-25 15:02:50 --> Database Driver Class Initialized
INFO - 2023-10-25 15:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 15:02:50 --> Parser Class Initialized
INFO - 2023-10-25 15:02:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 15:02:50 --> Pagination Class Initialized
INFO - 2023-10-25 15:02:50 --> Form Validation Class Initialized
INFO - 2023-10-25 15:02:50 --> Controller Class Initialized
INFO - 2023-10-25 15:02:50 --> Model Class Initialized
DEBUG - 2023-10-25 15:02:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 15:02:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:02:50 --> Model Class Initialized
DEBUG - 2023-10-25 15:02:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:02:50 --> Model Class Initialized
INFO - 2023-10-25 15:02:50 --> Final output sent to browser
DEBUG - 2023-10-25 15:02:50 --> Total execution time: 0.0453
ERROR - 2023-10-25 15:03:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 15:03:04 --> Config Class Initialized
INFO - 2023-10-25 15:03:04 --> Hooks Class Initialized
DEBUG - 2023-10-25 15:03:04 --> UTF-8 Support Enabled
INFO - 2023-10-25 15:03:04 --> Utf8 Class Initialized
INFO - 2023-10-25 15:03:04 --> URI Class Initialized
INFO - 2023-10-25 15:03:04 --> Router Class Initialized
INFO - 2023-10-25 15:03:04 --> Output Class Initialized
INFO - 2023-10-25 15:03:04 --> Security Class Initialized
DEBUG - 2023-10-25 15:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 15:03:04 --> Input Class Initialized
INFO - 2023-10-25 15:03:04 --> Language Class Initialized
INFO - 2023-10-25 15:03:04 --> Loader Class Initialized
INFO - 2023-10-25 15:03:04 --> Helper loaded: url_helper
INFO - 2023-10-25 15:03:04 --> Helper loaded: file_helper
INFO - 2023-10-25 15:03:04 --> Helper loaded: html_helper
INFO - 2023-10-25 15:03:04 --> Helper loaded: text_helper
INFO - 2023-10-25 15:03:04 --> Helper loaded: form_helper
INFO - 2023-10-25 15:03:04 --> Helper loaded: lang_helper
INFO - 2023-10-25 15:03:04 --> Helper loaded: security_helper
INFO - 2023-10-25 15:03:04 --> Helper loaded: cookie_helper
INFO - 2023-10-25 15:03:04 --> Database Driver Class Initialized
INFO - 2023-10-25 15:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 15:03:04 --> Parser Class Initialized
INFO - 2023-10-25 15:03:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 15:03:04 --> Pagination Class Initialized
INFO - 2023-10-25 15:03:04 --> Form Validation Class Initialized
INFO - 2023-10-25 15:03:04 --> Controller Class Initialized
INFO - 2023-10-25 15:03:04 --> Model Class Initialized
DEBUG - 2023-10-25 15:03:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 15:03:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:03:04 --> Model Class Initialized
DEBUG - 2023-10-25 15:03:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:03:04 --> Model Class Initialized
DEBUG - 2023-10-25 15:03:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:03:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-25 15:03:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:03:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 15:03:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 15:03:04 --> Model Class Initialized
INFO - 2023-10-25 15:03:04 --> Model Class Initialized
INFO - 2023-10-25 15:03:04 --> Model Class Initialized
INFO - 2023-10-25 15:03:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-25 15:03:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-25 15:03:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 15:03:04 --> Final output sent to browser
DEBUG - 2023-10-25 15:03:04 --> Total execution time: 0.1452
ERROR - 2023-10-25 15:03:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 15:03:11 --> Config Class Initialized
INFO - 2023-10-25 15:03:11 --> Hooks Class Initialized
DEBUG - 2023-10-25 15:03:11 --> UTF-8 Support Enabled
INFO - 2023-10-25 15:03:11 --> Utf8 Class Initialized
INFO - 2023-10-25 15:03:11 --> URI Class Initialized
INFO - 2023-10-25 15:03:11 --> Router Class Initialized
INFO - 2023-10-25 15:03:11 --> Output Class Initialized
INFO - 2023-10-25 15:03:11 --> Security Class Initialized
DEBUG - 2023-10-25 15:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 15:03:11 --> Input Class Initialized
INFO - 2023-10-25 15:03:11 --> Language Class Initialized
INFO - 2023-10-25 15:03:11 --> Loader Class Initialized
INFO - 2023-10-25 15:03:11 --> Helper loaded: url_helper
INFO - 2023-10-25 15:03:11 --> Helper loaded: file_helper
INFO - 2023-10-25 15:03:11 --> Helper loaded: html_helper
INFO - 2023-10-25 15:03:11 --> Helper loaded: text_helper
INFO - 2023-10-25 15:03:11 --> Helper loaded: form_helper
INFO - 2023-10-25 15:03:11 --> Helper loaded: lang_helper
INFO - 2023-10-25 15:03:11 --> Helper loaded: security_helper
INFO - 2023-10-25 15:03:11 --> Helper loaded: cookie_helper
INFO - 2023-10-25 15:03:11 --> Database Driver Class Initialized
INFO - 2023-10-25 15:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 15:03:11 --> Parser Class Initialized
INFO - 2023-10-25 15:03:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 15:03:11 --> Pagination Class Initialized
INFO - 2023-10-25 15:03:11 --> Form Validation Class Initialized
INFO - 2023-10-25 15:03:11 --> Controller Class Initialized
INFO - 2023-10-25 15:03:11 --> Model Class Initialized
DEBUG - 2023-10-25 15:03:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 15:03:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:03:11 --> Model Class Initialized
DEBUG - 2023-10-25 15:03:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:03:11 --> Model Class Initialized
INFO - 2023-10-25 15:03:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-25 15:03:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:03:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 15:03:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 15:03:11 --> Model Class Initialized
INFO - 2023-10-25 15:03:11 --> Model Class Initialized
INFO - 2023-10-25 15:03:11 --> Model Class Initialized
INFO - 2023-10-25 15:03:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-25 15:03:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-25 15:03:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 15:03:11 --> Final output sent to browser
DEBUG - 2023-10-25 15:03:11 --> Total execution time: 0.1388
ERROR - 2023-10-25 15:03:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 15:03:12 --> Config Class Initialized
INFO - 2023-10-25 15:03:12 --> Hooks Class Initialized
DEBUG - 2023-10-25 15:03:12 --> UTF-8 Support Enabled
INFO - 2023-10-25 15:03:12 --> Utf8 Class Initialized
INFO - 2023-10-25 15:03:12 --> URI Class Initialized
INFO - 2023-10-25 15:03:12 --> Router Class Initialized
INFO - 2023-10-25 15:03:12 --> Output Class Initialized
INFO - 2023-10-25 15:03:12 --> Security Class Initialized
DEBUG - 2023-10-25 15:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 15:03:12 --> Input Class Initialized
INFO - 2023-10-25 15:03:12 --> Language Class Initialized
INFO - 2023-10-25 15:03:12 --> Loader Class Initialized
INFO - 2023-10-25 15:03:12 --> Helper loaded: url_helper
INFO - 2023-10-25 15:03:12 --> Helper loaded: file_helper
INFO - 2023-10-25 15:03:12 --> Helper loaded: html_helper
INFO - 2023-10-25 15:03:12 --> Helper loaded: text_helper
INFO - 2023-10-25 15:03:12 --> Helper loaded: form_helper
INFO - 2023-10-25 15:03:12 --> Helper loaded: lang_helper
INFO - 2023-10-25 15:03:12 --> Helper loaded: security_helper
INFO - 2023-10-25 15:03:12 --> Helper loaded: cookie_helper
INFO - 2023-10-25 15:03:12 --> Database Driver Class Initialized
INFO - 2023-10-25 15:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 15:03:12 --> Parser Class Initialized
INFO - 2023-10-25 15:03:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 15:03:12 --> Pagination Class Initialized
INFO - 2023-10-25 15:03:12 --> Form Validation Class Initialized
INFO - 2023-10-25 15:03:12 --> Controller Class Initialized
INFO - 2023-10-25 15:03:12 --> Model Class Initialized
DEBUG - 2023-10-25 15:03:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 15:03:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:03:12 --> Model Class Initialized
DEBUG - 2023-10-25 15:03:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:03:12 --> Model Class Initialized
INFO - 2023-10-25 15:03:12 --> Final output sent to browser
DEBUG - 2023-10-25 15:03:12 --> Total execution time: 0.0427
ERROR - 2023-10-25 15:03:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 15:03:18 --> Config Class Initialized
INFO - 2023-10-25 15:03:18 --> Hooks Class Initialized
DEBUG - 2023-10-25 15:03:18 --> UTF-8 Support Enabled
INFO - 2023-10-25 15:03:18 --> Utf8 Class Initialized
INFO - 2023-10-25 15:03:18 --> URI Class Initialized
INFO - 2023-10-25 15:03:18 --> Router Class Initialized
INFO - 2023-10-25 15:03:18 --> Output Class Initialized
INFO - 2023-10-25 15:03:18 --> Security Class Initialized
DEBUG - 2023-10-25 15:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 15:03:18 --> Input Class Initialized
INFO - 2023-10-25 15:03:18 --> Language Class Initialized
INFO - 2023-10-25 15:03:18 --> Loader Class Initialized
INFO - 2023-10-25 15:03:18 --> Helper loaded: url_helper
INFO - 2023-10-25 15:03:18 --> Helper loaded: file_helper
INFO - 2023-10-25 15:03:18 --> Helper loaded: html_helper
INFO - 2023-10-25 15:03:18 --> Helper loaded: text_helper
INFO - 2023-10-25 15:03:18 --> Helper loaded: form_helper
INFO - 2023-10-25 15:03:18 --> Helper loaded: lang_helper
INFO - 2023-10-25 15:03:18 --> Helper loaded: security_helper
INFO - 2023-10-25 15:03:18 --> Helper loaded: cookie_helper
INFO - 2023-10-25 15:03:18 --> Database Driver Class Initialized
INFO - 2023-10-25 15:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 15:03:18 --> Parser Class Initialized
INFO - 2023-10-25 15:03:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 15:03:18 --> Pagination Class Initialized
INFO - 2023-10-25 15:03:18 --> Form Validation Class Initialized
INFO - 2023-10-25 15:03:18 --> Controller Class Initialized
INFO - 2023-10-25 15:03:18 --> Model Class Initialized
DEBUG - 2023-10-25 15:03:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 15:03:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:03:18 --> Model Class Initialized
DEBUG - 2023-10-25 15:03:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:03:18 --> Model Class Initialized
DEBUG - 2023-10-25 15:03:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:03:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-25 15:03:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:03:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 15:03:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 15:03:18 --> Model Class Initialized
INFO - 2023-10-25 15:03:18 --> Model Class Initialized
INFO - 2023-10-25 15:03:18 --> Model Class Initialized
INFO - 2023-10-25 15:03:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-25 15:03:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-25 15:03:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 15:03:18 --> Final output sent to browser
DEBUG - 2023-10-25 15:03:18 --> Total execution time: 0.1364
ERROR - 2023-10-25 15:03:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 15:03:47 --> Config Class Initialized
INFO - 2023-10-25 15:03:47 --> Hooks Class Initialized
DEBUG - 2023-10-25 15:03:47 --> UTF-8 Support Enabled
INFO - 2023-10-25 15:03:47 --> Utf8 Class Initialized
INFO - 2023-10-25 15:03:47 --> URI Class Initialized
INFO - 2023-10-25 15:03:47 --> Router Class Initialized
INFO - 2023-10-25 15:03:47 --> Output Class Initialized
INFO - 2023-10-25 15:03:47 --> Security Class Initialized
DEBUG - 2023-10-25 15:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 15:03:47 --> Input Class Initialized
INFO - 2023-10-25 15:03:47 --> Language Class Initialized
INFO - 2023-10-25 15:03:47 --> Loader Class Initialized
INFO - 2023-10-25 15:03:47 --> Helper loaded: url_helper
INFO - 2023-10-25 15:03:47 --> Helper loaded: file_helper
INFO - 2023-10-25 15:03:47 --> Helper loaded: html_helper
INFO - 2023-10-25 15:03:47 --> Helper loaded: text_helper
INFO - 2023-10-25 15:03:47 --> Helper loaded: form_helper
INFO - 2023-10-25 15:03:47 --> Helper loaded: lang_helper
INFO - 2023-10-25 15:03:47 --> Helper loaded: security_helper
INFO - 2023-10-25 15:03:47 --> Helper loaded: cookie_helper
INFO - 2023-10-25 15:03:47 --> Database Driver Class Initialized
INFO - 2023-10-25 15:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 15:03:47 --> Parser Class Initialized
INFO - 2023-10-25 15:03:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 15:03:47 --> Pagination Class Initialized
INFO - 2023-10-25 15:03:47 --> Form Validation Class Initialized
INFO - 2023-10-25 15:03:47 --> Controller Class Initialized
INFO - 2023-10-25 15:03:47 --> Model Class Initialized
DEBUG - 2023-10-25 15:03:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 15:03:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:03:47 --> Model Class Initialized
DEBUG - 2023-10-25 15:03:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:03:47 --> Model Class Initialized
INFO - 2023-10-25 15:03:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-25 15:03:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:03:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 15:03:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 15:03:47 --> Model Class Initialized
INFO - 2023-10-25 15:03:47 --> Model Class Initialized
INFO - 2023-10-25 15:03:47 --> Model Class Initialized
INFO - 2023-10-25 15:03:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-25 15:03:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-25 15:03:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 15:03:47 --> Final output sent to browser
DEBUG - 2023-10-25 15:03:47 --> Total execution time: 0.1335
ERROR - 2023-10-25 15:03:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 15:03:48 --> Config Class Initialized
INFO - 2023-10-25 15:03:48 --> Hooks Class Initialized
DEBUG - 2023-10-25 15:03:48 --> UTF-8 Support Enabled
INFO - 2023-10-25 15:03:48 --> Utf8 Class Initialized
INFO - 2023-10-25 15:03:48 --> URI Class Initialized
INFO - 2023-10-25 15:03:48 --> Router Class Initialized
INFO - 2023-10-25 15:03:48 --> Output Class Initialized
INFO - 2023-10-25 15:03:48 --> Security Class Initialized
DEBUG - 2023-10-25 15:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 15:03:48 --> Input Class Initialized
INFO - 2023-10-25 15:03:48 --> Language Class Initialized
INFO - 2023-10-25 15:03:48 --> Loader Class Initialized
INFO - 2023-10-25 15:03:48 --> Helper loaded: url_helper
INFO - 2023-10-25 15:03:48 --> Helper loaded: file_helper
INFO - 2023-10-25 15:03:48 --> Helper loaded: html_helper
INFO - 2023-10-25 15:03:48 --> Helper loaded: text_helper
INFO - 2023-10-25 15:03:48 --> Helper loaded: form_helper
INFO - 2023-10-25 15:03:48 --> Helper loaded: lang_helper
INFO - 2023-10-25 15:03:48 --> Helper loaded: security_helper
INFO - 2023-10-25 15:03:48 --> Helper loaded: cookie_helper
INFO - 2023-10-25 15:03:48 --> Database Driver Class Initialized
INFO - 2023-10-25 15:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 15:03:48 --> Parser Class Initialized
INFO - 2023-10-25 15:03:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 15:03:48 --> Pagination Class Initialized
INFO - 2023-10-25 15:03:48 --> Form Validation Class Initialized
INFO - 2023-10-25 15:03:48 --> Controller Class Initialized
INFO - 2023-10-25 15:03:48 --> Model Class Initialized
DEBUG - 2023-10-25 15:03:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 15:03:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:03:48 --> Model Class Initialized
DEBUG - 2023-10-25 15:03:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:03:48 --> Model Class Initialized
INFO - 2023-10-25 15:03:48 --> Final output sent to browser
DEBUG - 2023-10-25 15:03:48 --> Total execution time: 0.0493
ERROR - 2023-10-25 15:03:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 15:03:51 --> Config Class Initialized
INFO - 2023-10-25 15:03:51 --> Hooks Class Initialized
DEBUG - 2023-10-25 15:03:51 --> UTF-8 Support Enabled
INFO - 2023-10-25 15:03:51 --> Utf8 Class Initialized
INFO - 2023-10-25 15:03:51 --> URI Class Initialized
DEBUG - 2023-10-25 15:03:51 --> No URI present. Default controller set.
INFO - 2023-10-25 15:03:51 --> Router Class Initialized
INFO - 2023-10-25 15:03:51 --> Output Class Initialized
INFO - 2023-10-25 15:03:51 --> Security Class Initialized
DEBUG - 2023-10-25 15:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 15:03:51 --> Input Class Initialized
INFO - 2023-10-25 15:03:51 --> Language Class Initialized
INFO - 2023-10-25 15:03:51 --> Loader Class Initialized
INFO - 2023-10-25 15:03:51 --> Helper loaded: url_helper
INFO - 2023-10-25 15:03:51 --> Helper loaded: file_helper
INFO - 2023-10-25 15:03:51 --> Helper loaded: html_helper
INFO - 2023-10-25 15:03:51 --> Helper loaded: text_helper
INFO - 2023-10-25 15:03:51 --> Helper loaded: form_helper
INFO - 2023-10-25 15:03:51 --> Helper loaded: lang_helper
INFO - 2023-10-25 15:03:51 --> Helper loaded: security_helper
INFO - 2023-10-25 15:03:51 --> Helper loaded: cookie_helper
INFO - 2023-10-25 15:03:51 --> Database Driver Class Initialized
INFO - 2023-10-25 15:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 15:03:51 --> Parser Class Initialized
INFO - 2023-10-25 15:03:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 15:03:51 --> Pagination Class Initialized
INFO - 2023-10-25 15:03:51 --> Form Validation Class Initialized
INFO - 2023-10-25 15:03:51 --> Controller Class Initialized
INFO - 2023-10-25 15:03:51 --> Model Class Initialized
DEBUG - 2023-10-25 15:03:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:03:51 --> Model Class Initialized
DEBUG - 2023-10-25 15:03:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:03:51 --> Model Class Initialized
INFO - 2023-10-25 15:03:51 --> Model Class Initialized
INFO - 2023-10-25 15:03:51 --> Model Class Initialized
INFO - 2023-10-25 15:03:51 --> Model Class Initialized
DEBUG - 2023-10-25 15:03:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 15:03:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:03:51 --> Model Class Initialized
INFO - 2023-10-25 15:03:51 --> Model Class Initialized
INFO - 2023-10-25 15:03:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-25 15:03:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:03:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 15:03:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 15:03:51 --> Model Class Initialized
INFO - 2023-10-25 15:03:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-25 15:03:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-25 15:03:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 15:03:51 --> Final output sent to browser
DEBUG - 2023-10-25 15:03:51 --> Total execution time: 0.2025
ERROR - 2023-10-25 15:04:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 15:04:01 --> Config Class Initialized
INFO - 2023-10-25 15:04:01 --> Hooks Class Initialized
DEBUG - 2023-10-25 15:04:01 --> UTF-8 Support Enabled
INFO - 2023-10-25 15:04:01 --> Utf8 Class Initialized
INFO - 2023-10-25 15:04:01 --> URI Class Initialized
INFO - 2023-10-25 15:04:01 --> Router Class Initialized
INFO - 2023-10-25 15:04:01 --> Output Class Initialized
INFO - 2023-10-25 15:04:01 --> Security Class Initialized
DEBUG - 2023-10-25 15:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 15:04:01 --> Input Class Initialized
INFO - 2023-10-25 15:04:01 --> Language Class Initialized
INFO - 2023-10-25 15:04:01 --> Loader Class Initialized
INFO - 2023-10-25 15:04:01 --> Helper loaded: url_helper
INFO - 2023-10-25 15:04:01 --> Helper loaded: file_helper
INFO - 2023-10-25 15:04:01 --> Helper loaded: html_helper
INFO - 2023-10-25 15:04:01 --> Helper loaded: text_helper
INFO - 2023-10-25 15:04:01 --> Helper loaded: form_helper
INFO - 2023-10-25 15:04:01 --> Helper loaded: lang_helper
INFO - 2023-10-25 15:04:01 --> Helper loaded: security_helper
INFO - 2023-10-25 15:04:01 --> Helper loaded: cookie_helper
INFO - 2023-10-25 15:04:01 --> Database Driver Class Initialized
INFO - 2023-10-25 15:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 15:04:01 --> Parser Class Initialized
INFO - 2023-10-25 15:04:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 15:04:01 --> Pagination Class Initialized
INFO - 2023-10-25 15:04:01 --> Form Validation Class Initialized
INFO - 2023-10-25 15:04:01 --> Controller Class Initialized
INFO - 2023-10-25 15:04:01 --> Model Class Initialized
DEBUG - 2023-10-25 15:04:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 15:04:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:04:01 --> Model Class Initialized
DEBUG - 2023-10-25 15:04:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:04:01 --> Model Class Initialized
INFO - 2023-10-25 15:04:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-25 15:04:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:04:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 15:04:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 15:04:01 --> Model Class Initialized
INFO - 2023-10-25 15:04:01 --> Model Class Initialized
INFO - 2023-10-25 15:04:01 --> Model Class Initialized
INFO - 2023-10-25 15:04:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-25 15:04:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-25 15:04:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 15:04:01 --> Final output sent to browser
DEBUG - 2023-10-25 15:04:01 --> Total execution time: 0.1421
ERROR - 2023-10-25 15:04:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 15:04:03 --> Config Class Initialized
INFO - 2023-10-25 15:04:03 --> Hooks Class Initialized
DEBUG - 2023-10-25 15:04:03 --> UTF-8 Support Enabled
INFO - 2023-10-25 15:04:03 --> Utf8 Class Initialized
INFO - 2023-10-25 15:04:03 --> URI Class Initialized
INFO - 2023-10-25 15:04:03 --> Router Class Initialized
INFO - 2023-10-25 15:04:03 --> Output Class Initialized
INFO - 2023-10-25 15:04:03 --> Security Class Initialized
DEBUG - 2023-10-25 15:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 15:04:03 --> Input Class Initialized
INFO - 2023-10-25 15:04:03 --> Language Class Initialized
INFO - 2023-10-25 15:04:03 --> Loader Class Initialized
INFO - 2023-10-25 15:04:03 --> Helper loaded: url_helper
INFO - 2023-10-25 15:04:03 --> Helper loaded: file_helper
INFO - 2023-10-25 15:04:03 --> Helper loaded: html_helper
INFO - 2023-10-25 15:04:03 --> Helper loaded: text_helper
INFO - 2023-10-25 15:04:03 --> Helper loaded: form_helper
INFO - 2023-10-25 15:04:03 --> Helper loaded: lang_helper
INFO - 2023-10-25 15:04:03 --> Helper loaded: security_helper
INFO - 2023-10-25 15:04:03 --> Helper loaded: cookie_helper
INFO - 2023-10-25 15:04:03 --> Database Driver Class Initialized
INFO - 2023-10-25 15:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 15:04:03 --> Parser Class Initialized
INFO - 2023-10-25 15:04:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 15:04:03 --> Pagination Class Initialized
INFO - 2023-10-25 15:04:03 --> Form Validation Class Initialized
INFO - 2023-10-25 15:04:03 --> Controller Class Initialized
INFO - 2023-10-25 15:04:03 --> Model Class Initialized
DEBUG - 2023-10-25 15:04:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 15:04:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:04:03 --> Model Class Initialized
DEBUG - 2023-10-25 15:04:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:04:03 --> Model Class Initialized
INFO - 2023-10-25 15:04:03 --> Final output sent to browser
DEBUG - 2023-10-25 15:04:03 --> Total execution time: 0.0369
ERROR - 2023-10-25 15:04:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 15:04:13 --> Config Class Initialized
INFO - 2023-10-25 15:04:13 --> Hooks Class Initialized
DEBUG - 2023-10-25 15:04:13 --> UTF-8 Support Enabled
INFO - 2023-10-25 15:04:13 --> Utf8 Class Initialized
INFO - 2023-10-25 15:04:13 --> URI Class Initialized
INFO - 2023-10-25 15:04:13 --> Router Class Initialized
INFO - 2023-10-25 15:04:13 --> Output Class Initialized
INFO - 2023-10-25 15:04:13 --> Security Class Initialized
DEBUG - 2023-10-25 15:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 15:04:13 --> Input Class Initialized
INFO - 2023-10-25 15:04:13 --> Language Class Initialized
INFO - 2023-10-25 15:04:13 --> Loader Class Initialized
INFO - 2023-10-25 15:04:13 --> Helper loaded: url_helper
INFO - 2023-10-25 15:04:13 --> Helper loaded: file_helper
INFO - 2023-10-25 15:04:13 --> Helper loaded: html_helper
INFO - 2023-10-25 15:04:13 --> Helper loaded: text_helper
INFO - 2023-10-25 15:04:13 --> Helper loaded: form_helper
INFO - 2023-10-25 15:04:13 --> Helper loaded: lang_helper
INFO - 2023-10-25 15:04:13 --> Helper loaded: security_helper
INFO - 2023-10-25 15:04:13 --> Helper loaded: cookie_helper
INFO - 2023-10-25 15:04:13 --> Database Driver Class Initialized
INFO - 2023-10-25 15:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 15:04:13 --> Parser Class Initialized
INFO - 2023-10-25 15:04:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 15:04:13 --> Pagination Class Initialized
INFO - 2023-10-25 15:04:13 --> Form Validation Class Initialized
INFO - 2023-10-25 15:04:13 --> Controller Class Initialized
INFO - 2023-10-25 15:04:13 --> Model Class Initialized
DEBUG - 2023-10-25 15:04:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 15:04:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:04:13 --> Model Class Initialized
DEBUG - 2023-10-25 15:04:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:04:13 --> Model Class Initialized
INFO - 2023-10-25 15:04:13 --> Final output sent to browser
DEBUG - 2023-10-25 15:04:13 --> Total execution time: 0.0596
ERROR - 2023-10-25 15:04:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 15:04:15 --> Config Class Initialized
INFO - 2023-10-25 15:04:15 --> Hooks Class Initialized
DEBUG - 2023-10-25 15:04:15 --> UTF-8 Support Enabled
INFO - 2023-10-25 15:04:15 --> Utf8 Class Initialized
INFO - 2023-10-25 15:04:15 --> URI Class Initialized
INFO - 2023-10-25 15:04:15 --> Router Class Initialized
INFO - 2023-10-25 15:04:15 --> Output Class Initialized
INFO - 2023-10-25 15:04:15 --> Security Class Initialized
DEBUG - 2023-10-25 15:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 15:04:15 --> Input Class Initialized
INFO - 2023-10-25 15:04:15 --> Language Class Initialized
INFO - 2023-10-25 15:04:15 --> Loader Class Initialized
INFO - 2023-10-25 15:04:15 --> Helper loaded: url_helper
INFO - 2023-10-25 15:04:15 --> Helper loaded: file_helper
INFO - 2023-10-25 15:04:15 --> Helper loaded: html_helper
INFO - 2023-10-25 15:04:15 --> Helper loaded: text_helper
INFO - 2023-10-25 15:04:15 --> Helper loaded: form_helper
INFO - 2023-10-25 15:04:15 --> Helper loaded: lang_helper
INFO - 2023-10-25 15:04:15 --> Helper loaded: security_helper
INFO - 2023-10-25 15:04:15 --> Helper loaded: cookie_helper
INFO - 2023-10-25 15:04:15 --> Database Driver Class Initialized
INFO - 2023-10-25 15:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 15:04:15 --> Parser Class Initialized
INFO - 2023-10-25 15:04:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 15:04:15 --> Pagination Class Initialized
INFO - 2023-10-25 15:04:15 --> Form Validation Class Initialized
INFO - 2023-10-25 15:04:15 --> Controller Class Initialized
INFO - 2023-10-25 15:04:15 --> Model Class Initialized
DEBUG - 2023-10-25 15:04:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 15:04:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:04:15 --> Model Class Initialized
DEBUG - 2023-10-25 15:04:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 15:04:15 --> Model Class Initialized
INFO - 2023-10-25 15:04:15 --> Final output sent to browser
DEBUG - 2023-10-25 15:04:15 --> Total execution time: 0.0630
ERROR - 2023-10-25 17:04:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 17:04:03 --> Config Class Initialized
INFO - 2023-10-25 17:04:03 --> Hooks Class Initialized
DEBUG - 2023-10-25 17:04:03 --> UTF-8 Support Enabled
INFO - 2023-10-25 17:04:03 --> Utf8 Class Initialized
INFO - 2023-10-25 17:04:03 --> URI Class Initialized
DEBUG - 2023-10-25 17:04:03 --> No URI present. Default controller set.
INFO - 2023-10-25 17:04:03 --> Router Class Initialized
INFO - 2023-10-25 17:04:03 --> Output Class Initialized
INFO - 2023-10-25 17:04:03 --> Security Class Initialized
DEBUG - 2023-10-25 17:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 17:04:03 --> Input Class Initialized
INFO - 2023-10-25 17:04:03 --> Language Class Initialized
INFO - 2023-10-25 17:04:03 --> Loader Class Initialized
INFO - 2023-10-25 17:04:03 --> Helper loaded: url_helper
INFO - 2023-10-25 17:04:03 --> Helper loaded: file_helper
INFO - 2023-10-25 17:04:03 --> Helper loaded: html_helper
INFO - 2023-10-25 17:04:03 --> Helper loaded: text_helper
INFO - 2023-10-25 17:04:03 --> Helper loaded: form_helper
INFO - 2023-10-25 17:04:03 --> Helper loaded: lang_helper
INFO - 2023-10-25 17:04:03 --> Helper loaded: security_helper
INFO - 2023-10-25 17:04:03 --> Helper loaded: cookie_helper
INFO - 2023-10-25 17:04:03 --> Database Driver Class Initialized
INFO - 2023-10-25 17:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 17:04:03 --> Parser Class Initialized
INFO - 2023-10-25 17:04:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 17:04:03 --> Pagination Class Initialized
INFO - 2023-10-25 17:04:03 --> Form Validation Class Initialized
INFO - 2023-10-25 17:04:03 --> Controller Class Initialized
INFO - 2023-10-25 17:04:03 --> Model Class Initialized
DEBUG - 2023-10-25 17:04:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-25 17:04:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 17:04:03 --> Config Class Initialized
INFO - 2023-10-25 17:04:03 --> Hooks Class Initialized
DEBUG - 2023-10-25 17:04:03 --> UTF-8 Support Enabled
INFO - 2023-10-25 17:04:03 --> Utf8 Class Initialized
INFO - 2023-10-25 17:04:03 --> URI Class Initialized
INFO - 2023-10-25 17:04:03 --> Router Class Initialized
INFO - 2023-10-25 17:04:03 --> Output Class Initialized
INFO - 2023-10-25 17:04:03 --> Security Class Initialized
DEBUG - 2023-10-25 17:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 17:04:03 --> Input Class Initialized
INFO - 2023-10-25 17:04:03 --> Language Class Initialized
INFO - 2023-10-25 17:04:03 --> Loader Class Initialized
INFO - 2023-10-25 17:04:03 --> Helper loaded: url_helper
INFO - 2023-10-25 17:04:03 --> Helper loaded: file_helper
INFO - 2023-10-25 17:04:03 --> Helper loaded: html_helper
INFO - 2023-10-25 17:04:03 --> Helper loaded: text_helper
INFO - 2023-10-25 17:04:03 --> Helper loaded: form_helper
INFO - 2023-10-25 17:04:03 --> Helper loaded: lang_helper
INFO - 2023-10-25 17:04:03 --> Helper loaded: security_helper
INFO - 2023-10-25 17:04:03 --> Helper loaded: cookie_helper
INFO - 2023-10-25 17:04:03 --> Database Driver Class Initialized
INFO - 2023-10-25 17:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 17:04:03 --> Parser Class Initialized
INFO - 2023-10-25 17:04:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 17:04:03 --> Pagination Class Initialized
INFO - 2023-10-25 17:04:03 --> Form Validation Class Initialized
INFO - 2023-10-25 17:04:03 --> Controller Class Initialized
INFO - 2023-10-25 17:04:03 --> Model Class Initialized
DEBUG - 2023-10-25 17:04:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 17:04:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-25 17:04:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 17:04:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 17:04:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 17:04:03 --> Model Class Initialized
INFO - 2023-10-25 17:04:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 17:04:03 --> Final output sent to browser
DEBUG - 2023-10-25 17:04:03 --> Total execution time: 0.0315
ERROR - 2023-10-25 17:04:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 17:04:06 --> Config Class Initialized
INFO - 2023-10-25 17:04:06 --> Hooks Class Initialized
DEBUG - 2023-10-25 17:04:06 --> UTF-8 Support Enabled
INFO - 2023-10-25 17:04:06 --> Utf8 Class Initialized
INFO - 2023-10-25 17:04:06 --> URI Class Initialized
INFO - 2023-10-25 17:04:06 --> Router Class Initialized
INFO - 2023-10-25 17:04:06 --> Output Class Initialized
INFO - 2023-10-25 17:04:06 --> Security Class Initialized
DEBUG - 2023-10-25 17:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 17:04:06 --> Input Class Initialized
INFO - 2023-10-25 17:04:06 --> Language Class Initialized
INFO - 2023-10-25 17:04:06 --> Loader Class Initialized
INFO - 2023-10-25 17:04:06 --> Helper loaded: url_helper
INFO - 2023-10-25 17:04:06 --> Helper loaded: file_helper
INFO - 2023-10-25 17:04:06 --> Helper loaded: html_helper
INFO - 2023-10-25 17:04:06 --> Helper loaded: text_helper
INFO - 2023-10-25 17:04:06 --> Helper loaded: form_helper
INFO - 2023-10-25 17:04:06 --> Helper loaded: lang_helper
INFO - 2023-10-25 17:04:06 --> Helper loaded: security_helper
INFO - 2023-10-25 17:04:06 --> Helper loaded: cookie_helper
INFO - 2023-10-25 17:04:06 --> Database Driver Class Initialized
INFO - 2023-10-25 17:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 17:04:06 --> Parser Class Initialized
INFO - 2023-10-25 17:04:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 17:04:06 --> Pagination Class Initialized
INFO - 2023-10-25 17:04:06 --> Form Validation Class Initialized
INFO - 2023-10-25 17:04:06 --> Controller Class Initialized
INFO - 2023-10-25 17:04:06 --> Model Class Initialized
DEBUG - 2023-10-25 17:04:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 17:04:06 --> Model Class Initialized
INFO - 2023-10-25 17:04:06 --> Final output sent to browser
DEBUG - 2023-10-25 17:04:06 --> Total execution time: 0.0201
ERROR - 2023-10-25 17:04:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 17:04:07 --> Config Class Initialized
INFO - 2023-10-25 17:04:07 --> Hooks Class Initialized
DEBUG - 2023-10-25 17:04:07 --> UTF-8 Support Enabled
INFO - 2023-10-25 17:04:07 --> Utf8 Class Initialized
INFO - 2023-10-25 17:04:07 --> URI Class Initialized
DEBUG - 2023-10-25 17:04:07 --> No URI present. Default controller set.
INFO - 2023-10-25 17:04:07 --> Router Class Initialized
INFO - 2023-10-25 17:04:07 --> Output Class Initialized
INFO - 2023-10-25 17:04:07 --> Security Class Initialized
DEBUG - 2023-10-25 17:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 17:04:07 --> Input Class Initialized
INFO - 2023-10-25 17:04:07 --> Language Class Initialized
INFO - 2023-10-25 17:04:07 --> Loader Class Initialized
INFO - 2023-10-25 17:04:07 --> Helper loaded: url_helper
INFO - 2023-10-25 17:04:07 --> Helper loaded: file_helper
INFO - 2023-10-25 17:04:07 --> Helper loaded: html_helper
INFO - 2023-10-25 17:04:07 --> Helper loaded: text_helper
INFO - 2023-10-25 17:04:07 --> Helper loaded: form_helper
INFO - 2023-10-25 17:04:07 --> Helper loaded: lang_helper
INFO - 2023-10-25 17:04:07 --> Helper loaded: security_helper
INFO - 2023-10-25 17:04:07 --> Helper loaded: cookie_helper
INFO - 2023-10-25 17:04:07 --> Database Driver Class Initialized
INFO - 2023-10-25 17:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 17:04:07 --> Parser Class Initialized
INFO - 2023-10-25 17:04:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 17:04:07 --> Pagination Class Initialized
INFO - 2023-10-25 17:04:07 --> Form Validation Class Initialized
INFO - 2023-10-25 17:04:07 --> Controller Class Initialized
INFO - 2023-10-25 17:04:07 --> Model Class Initialized
DEBUG - 2023-10-25 17:04:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 17:04:07 --> Model Class Initialized
DEBUG - 2023-10-25 17:04:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 17:04:07 --> Model Class Initialized
INFO - 2023-10-25 17:04:07 --> Model Class Initialized
INFO - 2023-10-25 17:04:07 --> Model Class Initialized
INFO - 2023-10-25 17:04:07 --> Model Class Initialized
DEBUG - 2023-10-25 17:04:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 17:04:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 17:04:07 --> Model Class Initialized
INFO - 2023-10-25 17:04:07 --> Model Class Initialized
INFO - 2023-10-25 17:04:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-25 17:04:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 17:04:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 17:04:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 17:04:07 --> Model Class Initialized
INFO - 2023-10-25 17:04:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-25 17:04:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-25 17:04:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 17:04:07 --> Final output sent to browser
DEBUG - 2023-10-25 17:04:07 --> Total execution time: 0.3464
ERROR - 2023-10-25 17:04:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 17:04:08 --> Config Class Initialized
INFO - 2023-10-25 17:04:08 --> Hooks Class Initialized
DEBUG - 2023-10-25 17:04:08 --> UTF-8 Support Enabled
INFO - 2023-10-25 17:04:08 --> Utf8 Class Initialized
INFO - 2023-10-25 17:04:08 --> URI Class Initialized
INFO - 2023-10-25 17:04:08 --> Router Class Initialized
INFO - 2023-10-25 17:04:08 --> Output Class Initialized
INFO - 2023-10-25 17:04:08 --> Security Class Initialized
DEBUG - 2023-10-25 17:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 17:04:08 --> Input Class Initialized
INFO - 2023-10-25 17:04:08 --> Language Class Initialized
INFO - 2023-10-25 17:04:08 --> Loader Class Initialized
INFO - 2023-10-25 17:04:08 --> Helper loaded: url_helper
INFO - 2023-10-25 17:04:08 --> Helper loaded: file_helper
INFO - 2023-10-25 17:04:08 --> Helper loaded: html_helper
INFO - 2023-10-25 17:04:08 --> Helper loaded: text_helper
INFO - 2023-10-25 17:04:08 --> Helper loaded: form_helper
INFO - 2023-10-25 17:04:08 --> Helper loaded: lang_helper
INFO - 2023-10-25 17:04:08 --> Helper loaded: security_helper
INFO - 2023-10-25 17:04:08 --> Helper loaded: cookie_helper
INFO - 2023-10-25 17:04:08 --> Database Driver Class Initialized
INFO - 2023-10-25 17:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 17:04:08 --> Parser Class Initialized
INFO - 2023-10-25 17:04:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 17:04:08 --> Pagination Class Initialized
INFO - 2023-10-25 17:04:08 --> Form Validation Class Initialized
INFO - 2023-10-25 17:04:08 --> Controller Class Initialized
DEBUG - 2023-10-25 17:04:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 17:04:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 17:04:08 --> Model Class Initialized
INFO - 2023-10-25 17:04:08 --> Final output sent to browser
DEBUG - 2023-10-25 17:04:08 --> Total execution time: 0.0135
ERROR - 2023-10-25 17:04:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 17:04:28 --> Config Class Initialized
INFO - 2023-10-25 17:04:28 --> Hooks Class Initialized
DEBUG - 2023-10-25 17:04:28 --> UTF-8 Support Enabled
INFO - 2023-10-25 17:04:28 --> Utf8 Class Initialized
INFO - 2023-10-25 17:04:28 --> URI Class Initialized
INFO - 2023-10-25 17:04:28 --> Router Class Initialized
INFO - 2023-10-25 17:04:28 --> Output Class Initialized
INFO - 2023-10-25 17:04:28 --> Security Class Initialized
DEBUG - 2023-10-25 17:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 17:04:28 --> Input Class Initialized
INFO - 2023-10-25 17:04:28 --> Language Class Initialized
INFO - 2023-10-25 17:04:28 --> Loader Class Initialized
INFO - 2023-10-25 17:04:28 --> Helper loaded: url_helper
INFO - 2023-10-25 17:04:28 --> Helper loaded: file_helper
INFO - 2023-10-25 17:04:28 --> Helper loaded: html_helper
INFO - 2023-10-25 17:04:28 --> Helper loaded: text_helper
INFO - 2023-10-25 17:04:28 --> Helper loaded: form_helper
INFO - 2023-10-25 17:04:28 --> Helper loaded: lang_helper
INFO - 2023-10-25 17:04:28 --> Helper loaded: security_helper
INFO - 2023-10-25 17:04:28 --> Helper loaded: cookie_helper
INFO - 2023-10-25 17:04:28 --> Database Driver Class Initialized
INFO - 2023-10-25 17:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 17:04:28 --> Parser Class Initialized
INFO - 2023-10-25 17:04:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 17:04:28 --> Pagination Class Initialized
INFO - 2023-10-25 17:04:28 --> Form Validation Class Initialized
INFO - 2023-10-25 17:04:28 --> Controller Class Initialized
DEBUG - 2023-10-25 17:04:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 17:04:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 17:04:28 --> Model Class Initialized
INFO - 2023-10-25 17:04:28 --> Model Class Initialized
DEBUG - 2023-10-25 17:04:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 17:04:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 17:04:28 --> Model Class Initialized
DEBUG - 2023-10-25 17:04:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 17:04:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gst/list.php
DEBUG - 2023-10-25 17:04:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 17:04:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 17:04:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 17:04:28 --> Model Class Initialized
INFO - 2023-10-25 17:04:28 --> Model Class Initialized
INFO - 2023-10-25 17:04:28 --> Model Class Initialized
INFO - 2023-10-25 17:04:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-25 17:04:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-25 17:04:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 17:04:28 --> Final output sent to browser
DEBUG - 2023-10-25 17:04:28 --> Total execution time: 0.1801
ERROR - 2023-10-25 17:04:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 17:04:58 --> Config Class Initialized
INFO - 2023-10-25 17:04:58 --> Hooks Class Initialized
DEBUG - 2023-10-25 17:04:58 --> UTF-8 Support Enabled
INFO - 2023-10-25 17:04:58 --> Utf8 Class Initialized
INFO - 2023-10-25 17:04:58 --> URI Class Initialized
INFO - 2023-10-25 17:04:58 --> Router Class Initialized
INFO - 2023-10-25 17:04:58 --> Output Class Initialized
INFO - 2023-10-25 17:04:58 --> Security Class Initialized
DEBUG - 2023-10-25 17:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 17:04:58 --> Input Class Initialized
INFO - 2023-10-25 17:04:58 --> Language Class Initialized
INFO - 2023-10-25 17:04:58 --> Loader Class Initialized
INFO - 2023-10-25 17:04:58 --> Helper loaded: url_helper
INFO - 2023-10-25 17:04:58 --> Helper loaded: file_helper
INFO - 2023-10-25 17:04:58 --> Helper loaded: html_helper
INFO - 2023-10-25 17:04:58 --> Helper loaded: text_helper
INFO - 2023-10-25 17:04:58 --> Helper loaded: form_helper
INFO - 2023-10-25 17:04:58 --> Helper loaded: lang_helper
INFO - 2023-10-25 17:04:58 --> Helper loaded: security_helper
INFO - 2023-10-25 17:04:58 --> Helper loaded: cookie_helper
INFO - 2023-10-25 17:04:58 --> Database Driver Class Initialized
INFO - 2023-10-25 17:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 17:04:58 --> Parser Class Initialized
INFO - 2023-10-25 17:04:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 17:04:58 --> Pagination Class Initialized
INFO - 2023-10-25 17:04:58 --> Form Validation Class Initialized
INFO - 2023-10-25 17:04:58 --> Controller Class Initialized
DEBUG - 2023-10-25 17:04:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 17:04:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 17:04:58 --> Model Class Initialized
DEBUG - 2023-10-25 17:04:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 17:04:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 17:04:58 --> Model Class Initialized
DEBUG - 2023-10-25 17:04:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 17:04:58 --> Model Class Initialized
INFO - 2023-10-25 17:04:58 --> Final output sent to browser
DEBUG - 2023-10-25 17:04:58 --> Total execution time: 0.0316
ERROR - 2023-10-25 17:29:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 17:29:49 --> Config Class Initialized
INFO - 2023-10-25 17:29:49 --> Hooks Class Initialized
DEBUG - 2023-10-25 17:29:49 --> UTF-8 Support Enabled
INFO - 2023-10-25 17:29:49 --> Utf8 Class Initialized
INFO - 2023-10-25 17:29:49 --> URI Class Initialized
INFO - 2023-10-25 17:29:49 --> Router Class Initialized
INFO - 2023-10-25 17:29:49 --> Output Class Initialized
INFO - 2023-10-25 17:29:49 --> Security Class Initialized
DEBUG - 2023-10-25 17:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 17:29:49 --> Input Class Initialized
INFO - 2023-10-25 17:29:49 --> Language Class Initialized
INFO - 2023-10-25 17:29:49 --> Loader Class Initialized
INFO - 2023-10-25 17:29:49 --> Helper loaded: url_helper
INFO - 2023-10-25 17:29:49 --> Helper loaded: file_helper
INFO - 2023-10-25 17:29:49 --> Helper loaded: html_helper
INFO - 2023-10-25 17:29:49 --> Helper loaded: text_helper
INFO - 2023-10-25 17:29:49 --> Helper loaded: form_helper
INFO - 2023-10-25 17:29:49 --> Helper loaded: lang_helper
INFO - 2023-10-25 17:29:49 --> Helper loaded: security_helper
INFO - 2023-10-25 17:29:49 --> Helper loaded: cookie_helper
INFO - 2023-10-25 17:29:49 --> Database Driver Class Initialized
INFO - 2023-10-25 17:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 17:29:49 --> Parser Class Initialized
INFO - 2023-10-25 17:29:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 17:29:49 --> Pagination Class Initialized
INFO - 2023-10-25 17:29:49 --> Form Validation Class Initialized
INFO - 2023-10-25 17:29:49 --> Controller Class Initialized
DEBUG - 2023-10-25 17:29:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 17:29:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 17:29:49 --> Model Class Initialized
INFO - 2023-10-25 17:29:49 --> Model Class Initialized
DEBUG - 2023-10-25 17:29:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 17:29:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 17:29:49 --> Model Class Initialized
DEBUG - 2023-10-25 17:29:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 17:29:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/gst/list.php
DEBUG - 2023-10-25 17:29:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-25 17:29:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-25 17:29:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-25 17:29:49 --> Model Class Initialized
INFO - 2023-10-25 17:29:49 --> Model Class Initialized
INFO - 2023-10-25 17:29:49 --> Model Class Initialized
INFO - 2023-10-25 17:29:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-25 17:29:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-25 17:29:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-25 17:29:49 --> Final output sent to browser
DEBUG - 2023-10-25 17:29:49 --> Total execution time: 0.1830
ERROR - 2023-10-25 17:30:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 17:30:05 --> Config Class Initialized
INFO - 2023-10-25 17:30:05 --> Hooks Class Initialized
DEBUG - 2023-10-25 17:30:05 --> UTF-8 Support Enabled
INFO - 2023-10-25 17:30:05 --> Utf8 Class Initialized
INFO - 2023-10-25 17:30:05 --> URI Class Initialized
INFO - 2023-10-25 17:30:05 --> Router Class Initialized
INFO - 2023-10-25 17:30:05 --> Output Class Initialized
INFO - 2023-10-25 17:30:05 --> Security Class Initialized
DEBUG - 2023-10-25 17:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 17:30:05 --> Input Class Initialized
INFO - 2023-10-25 17:30:05 --> Language Class Initialized
INFO - 2023-10-25 17:30:05 --> Loader Class Initialized
INFO - 2023-10-25 17:30:05 --> Helper loaded: url_helper
INFO - 2023-10-25 17:30:05 --> Helper loaded: file_helper
INFO - 2023-10-25 17:30:05 --> Helper loaded: html_helper
INFO - 2023-10-25 17:30:05 --> Helper loaded: text_helper
INFO - 2023-10-25 17:30:05 --> Helper loaded: form_helper
INFO - 2023-10-25 17:30:05 --> Helper loaded: lang_helper
INFO - 2023-10-25 17:30:05 --> Helper loaded: security_helper
INFO - 2023-10-25 17:30:05 --> Helper loaded: cookie_helper
INFO - 2023-10-25 17:30:05 --> Database Driver Class Initialized
INFO - 2023-10-25 17:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-25 17:30:05 --> Parser Class Initialized
INFO - 2023-10-25 17:30:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-25 17:30:05 --> Pagination Class Initialized
INFO - 2023-10-25 17:30:05 --> Form Validation Class Initialized
INFO - 2023-10-25 17:30:05 --> Controller Class Initialized
DEBUG - 2023-10-25 17:30:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 17:30:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 17:30:05 --> Model Class Initialized
DEBUG - 2023-10-25 17:30:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-25 17:30:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 17:30:05 --> Model Class Initialized
DEBUG - 2023-10-25 17:30:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-25 17:30:05 --> Model Class Initialized
INFO - 2023-10-25 17:30:05 --> Final output sent to browser
DEBUG - 2023-10-25 17:30:05 --> Total execution time: 0.0221
ERROR - 2023-10-25 22:32:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-25 22:32:11 --> Config Class Initialized
INFO - 2023-10-25 22:32:11 --> Hooks Class Initialized
DEBUG - 2023-10-25 22:32:11 --> UTF-8 Support Enabled
INFO - 2023-10-25 22:32:11 --> Utf8 Class Initialized
INFO - 2023-10-25 22:32:11 --> URI Class Initialized
INFO - 2023-10-25 22:32:11 --> Router Class Initialized
INFO - 2023-10-25 22:32:11 --> Output Class Initialized
INFO - 2023-10-25 22:32:11 --> Security Class Initialized
DEBUG - 2023-10-25 22:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-25 22:32:11 --> Input Class Initialized
INFO - 2023-10-25 22:32:11 --> Language Class Initialized
ERROR - 2023-10-25 22:32:11 --> 404 Page Not Found: Well-known/assetlinks.json
