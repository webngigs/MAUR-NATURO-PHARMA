<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-06 01:01:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:01:16 --> Config Class Initialized
INFO - 2024-02-06 01:01:16 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:01:16 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:01:16 --> Utf8 Class Initialized
INFO - 2024-02-06 01:01:16 --> URI Class Initialized
DEBUG - 2024-02-06 01:01:16 --> No URI present. Default controller set.
INFO - 2024-02-06 01:01:16 --> Router Class Initialized
INFO - 2024-02-06 01:01:16 --> Output Class Initialized
INFO - 2024-02-06 01:01:16 --> Security Class Initialized
DEBUG - 2024-02-06 01:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:01:16 --> Input Class Initialized
INFO - 2024-02-06 01:01:16 --> Language Class Initialized
INFO - 2024-02-06 01:01:16 --> Loader Class Initialized
INFO - 2024-02-06 01:01:16 --> Helper loaded: url_helper
INFO - 2024-02-06 01:01:16 --> Helper loaded: file_helper
INFO - 2024-02-06 01:01:16 --> Helper loaded: html_helper
INFO - 2024-02-06 01:01:16 --> Helper loaded: text_helper
INFO - 2024-02-06 01:01:16 --> Helper loaded: form_helper
INFO - 2024-02-06 01:01:16 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:01:16 --> Helper loaded: security_helper
INFO - 2024-02-06 01:01:16 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:01:16 --> Database Driver Class Initialized
INFO - 2024-02-06 01:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:01:16 --> Parser Class Initialized
INFO - 2024-02-06 01:01:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:01:16 --> Pagination Class Initialized
INFO - 2024-02-06 01:01:16 --> Form Validation Class Initialized
INFO - 2024-02-06 01:01:16 --> Controller Class Initialized
INFO - 2024-02-06 01:01:16 --> Model Class Initialized
DEBUG - 2024-02-06 01:01:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-06 01:53:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:53:00 --> Config Class Initialized
INFO - 2024-02-06 01:53:00 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:53:00 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:53:00 --> Utf8 Class Initialized
INFO - 2024-02-06 01:53:00 --> URI Class Initialized
DEBUG - 2024-02-06 01:53:00 --> No URI present. Default controller set.
INFO - 2024-02-06 01:53:00 --> Router Class Initialized
INFO - 2024-02-06 01:53:00 --> Output Class Initialized
INFO - 2024-02-06 01:53:00 --> Security Class Initialized
DEBUG - 2024-02-06 01:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:53:00 --> Input Class Initialized
INFO - 2024-02-06 01:53:00 --> Language Class Initialized
INFO - 2024-02-06 01:53:00 --> Loader Class Initialized
INFO - 2024-02-06 01:53:00 --> Helper loaded: url_helper
INFO - 2024-02-06 01:53:00 --> Helper loaded: file_helper
INFO - 2024-02-06 01:53:00 --> Helper loaded: html_helper
INFO - 2024-02-06 01:53:00 --> Helper loaded: text_helper
INFO - 2024-02-06 01:53:00 --> Helper loaded: form_helper
INFO - 2024-02-06 01:53:00 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:53:00 --> Helper loaded: security_helper
INFO - 2024-02-06 01:53:00 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:53:00 --> Database Driver Class Initialized
INFO - 2024-02-06 01:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:53:00 --> Parser Class Initialized
INFO - 2024-02-06 01:53:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:53:00 --> Pagination Class Initialized
INFO - 2024-02-06 01:53:00 --> Form Validation Class Initialized
INFO - 2024-02-06 01:53:00 --> Controller Class Initialized
INFO - 2024-02-06 01:53:00 --> Model Class Initialized
DEBUG - 2024-02-06 01:53:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-06 01:53:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:53:00 --> Config Class Initialized
INFO - 2024-02-06 01:53:00 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:53:00 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:53:00 --> Utf8 Class Initialized
INFO - 2024-02-06 01:53:00 --> URI Class Initialized
INFO - 2024-02-06 01:53:00 --> Router Class Initialized
INFO - 2024-02-06 01:53:00 --> Output Class Initialized
INFO - 2024-02-06 01:53:00 --> Security Class Initialized
DEBUG - 2024-02-06 01:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:53:00 --> Input Class Initialized
INFO - 2024-02-06 01:53:00 --> Language Class Initialized
INFO - 2024-02-06 01:53:00 --> Loader Class Initialized
INFO - 2024-02-06 01:53:00 --> Helper loaded: url_helper
INFO - 2024-02-06 01:53:00 --> Helper loaded: file_helper
INFO - 2024-02-06 01:53:00 --> Helper loaded: html_helper
INFO - 2024-02-06 01:53:00 --> Helper loaded: text_helper
INFO - 2024-02-06 01:53:00 --> Helper loaded: form_helper
INFO - 2024-02-06 01:53:00 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:53:00 --> Helper loaded: security_helper
INFO - 2024-02-06 01:53:00 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:53:00 --> Database Driver Class Initialized
INFO - 2024-02-06 01:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:53:00 --> Parser Class Initialized
INFO - 2024-02-06 01:53:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:53:00 --> Pagination Class Initialized
INFO - 2024-02-06 01:53:00 --> Form Validation Class Initialized
INFO - 2024-02-06 01:53:00 --> Controller Class Initialized
INFO - 2024-02-06 01:53:00 --> Model Class Initialized
DEBUG - 2024-02-06 01:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-06 01:53:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 01:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 01:53:00 --> Model Class Initialized
INFO - 2024-02-06 01:53:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 01:53:00 --> Final output sent to browser
DEBUG - 2024-02-06 01:53:00 --> Total execution time: 0.0342
ERROR - 2024-02-06 01:53:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:53:27 --> Config Class Initialized
INFO - 2024-02-06 01:53:27 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:53:27 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:53:27 --> Utf8 Class Initialized
INFO - 2024-02-06 01:53:27 --> URI Class Initialized
INFO - 2024-02-06 01:53:27 --> Router Class Initialized
INFO - 2024-02-06 01:53:27 --> Output Class Initialized
INFO - 2024-02-06 01:53:27 --> Security Class Initialized
DEBUG - 2024-02-06 01:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:53:27 --> Input Class Initialized
INFO - 2024-02-06 01:53:27 --> Language Class Initialized
INFO - 2024-02-06 01:53:27 --> Loader Class Initialized
INFO - 2024-02-06 01:53:27 --> Helper loaded: url_helper
INFO - 2024-02-06 01:53:27 --> Helper loaded: file_helper
INFO - 2024-02-06 01:53:27 --> Helper loaded: html_helper
INFO - 2024-02-06 01:53:27 --> Helper loaded: text_helper
INFO - 2024-02-06 01:53:27 --> Helper loaded: form_helper
INFO - 2024-02-06 01:53:27 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:53:27 --> Helper loaded: security_helper
INFO - 2024-02-06 01:53:27 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:53:27 --> Database Driver Class Initialized
INFO - 2024-02-06 01:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:53:27 --> Parser Class Initialized
INFO - 2024-02-06 01:53:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:53:27 --> Pagination Class Initialized
INFO - 2024-02-06 01:53:27 --> Form Validation Class Initialized
INFO - 2024-02-06 01:53:27 --> Controller Class Initialized
INFO - 2024-02-06 01:53:27 --> Model Class Initialized
DEBUG - 2024-02-06 01:53:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:53:27 --> Model Class Initialized
INFO - 2024-02-06 01:53:27 --> Final output sent to browser
DEBUG - 2024-02-06 01:53:27 --> Total execution time: 0.0242
ERROR - 2024-02-06 01:53:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:53:27 --> Config Class Initialized
INFO - 2024-02-06 01:53:27 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:53:27 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:53:27 --> Utf8 Class Initialized
INFO - 2024-02-06 01:53:27 --> URI Class Initialized
DEBUG - 2024-02-06 01:53:27 --> No URI present. Default controller set.
INFO - 2024-02-06 01:53:27 --> Router Class Initialized
INFO - 2024-02-06 01:53:27 --> Output Class Initialized
INFO - 2024-02-06 01:53:27 --> Security Class Initialized
DEBUG - 2024-02-06 01:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:53:27 --> Input Class Initialized
INFO - 2024-02-06 01:53:27 --> Language Class Initialized
INFO - 2024-02-06 01:53:27 --> Loader Class Initialized
INFO - 2024-02-06 01:53:27 --> Helper loaded: url_helper
INFO - 2024-02-06 01:53:27 --> Helper loaded: file_helper
INFO - 2024-02-06 01:53:27 --> Helper loaded: html_helper
INFO - 2024-02-06 01:53:27 --> Helper loaded: text_helper
INFO - 2024-02-06 01:53:27 --> Helper loaded: form_helper
INFO - 2024-02-06 01:53:27 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:53:27 --> Helper loaded: security_helper
INFO - 2024-02-06 01:53:27 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:53:27 --> Database Driver Class Initialized
INFO - 2024-02-06 01:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:53:27 --> Parser Class Initialized
INFO - 2024-02-06 01:53:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:53:27 --> Pagination Class Initialized
INFO - 2024-02-06 01:53:27 --> Form Validation Class Initialized
INFO - 2024-02-06 01:53:27 --> Controller Class Initialized
INFO - 2024-02-06 01:53:27 --> Model Class Initialized
DEBUG - 2024-02-06 01:53:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:53:27 --> Model Class Initialized
DEBUG - 2024-02-06 01:53:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:53:27 --> Model Class Initialized
INFO - 2024-02-06 01:53:27 --> Model Class Initialized
INFO - 2024-02-06 01:53:27 --> Model Class Initialized
INFO - 2024-02-06 01:53:27 --> Model Class Initialized
DEBUG - 2024-02-06 01:53:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:53:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:53:27 --> Model Class Initialized
INFO - 2024-02-06 01:53:27 --> Model Class Initialized
INFO - 2024-02-06 01:53:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 01:53:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:53:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 01:53:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 01:53:27 --> Model Class Initialized
INFO - 2024-02-06 01:53:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 01:53:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 01:53:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 01:53:27 --> Final output sent to browser
DEBUG - 2024-02-06 01:53:27 --> Total execution time: 0.2423
ERROR - 2024-02-06 01:53:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:53:34 --> Config Class Initialized
INFO - 2024-02-06 01:53:34 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:53:34 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:53:34 --> Utf8 Class Initialized
INFO - 2024-02-06 01:53:34 --> URI Class Initialized
INFO - 2024-02-06 01:53:34 --> Router Class Initialized
INFO - 2024-02-06 01:53:34 --> Output Class Initialized
INFO - 2024-02-06 01:53:34 --> Security Class Initialized
DEBUG - 2024-02-06 01:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:53:34 --> Input Class Initialized
INFO - 2024-02-06 01:53:34 --> Language Class Initialized
INFO - 2024-02-06 01:53:34 --> Loader Class Initialized
INFO - 2024-02-06 01:53:34 --> Helper loaded: url_helper
INFO - 2024-02-06 01:53:34 --> Helper loaded: file_helper
INFO - 2024-02-06 01:53:34 --> Helper loaded: html_helper
INFO - 2024-02-06 01:53:34 --> Helper loaded: text_helper
INFO - 2024-02-06 01:53:34 --> Helper loaded: form_helper
INFO - 2024-02-06 01:53:34 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:53:34 --> Helper loaded: security_helper
INFO - 2024-02-06 01:53:34 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:53:34 --> Database Driver Class Initialized
INFO - 2024-02-06 01:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:53:34 --> Parser Class Initialized
INFO - 2024-02-06 01:53:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:53:34 --> Pagination Class Initialized
INFO - 2024-02-06 01:53:34 --> Form Validation Class Initialized
INFO - 2024-02-06 01:53:34 --> Controller Class Initialized
INFO - 2024-02-06 01:53:34 --> Model Class Initialized
DEBUG - 2024-02-06 01:53:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:53:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:53:34 --> Model Class Initialized
DEBUG - 2024-02-06 01:53:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:53:34 --> Model Class Initialized
INFO - 2024-02-06 01:53:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-06 01:53:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:53:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 01:53:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 01:53:34 --> Model Class Initialized
INFO - 2024-02-06 01:53:34 --> Model Class Initialized
INFO - 2024-02-06 01:53:34 --> Model Class Initialized
INFO - 2024-02-06 01:53:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 01:53:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 01:53:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 01:53:34 --> Final output sent to browser
DEBUG - 2024-02-06 01:53:34 --> Total execution time: 0.1840
ERROR - 2024-02-06 01:53:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:53:42 --> Config Class Initialized
INFO - 2024-02-06 01:53:42 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:53:42 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:53:42 --> Utf8 Class Initialized
INFO - 2024-02-06 01:53:42 --> URI Class Initialized
INFO - 2024-02-06 01:53:42 --> Router Class Initialized
INFO - 2024-02-06 01:53:42 --> Output Class Initialized
INFO - 2024-02-06 01:53:42 --> Security Class Initialized
DEBUG - 2024-02-06 01:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:53:42 --> Input Class Initialized
INFO - 2024-02-06 01:53:42 --> Language Class Initialized
INFO - 2024-02-06 01:53:42 --> Loader Class Initialized
INFO - 2024-02-06 01:53:42 --> Helper loaded: url_helper
INFO - 2024-02-06 01:53:42 --> Helper loaded: file_helper
INFO - 2024-02-06 01:53:42 --> Helper loaded: html_helper
INFO - 2024-02-06 01:53:42 --> Helper loaded: text_helper
INFO - 2024-02-06 01:53:42 --> Helper loaded: form_helper
INFO - 2024-02-06 01:53:42 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:53:42 --> Helper loaded: security_helper
INFO - 2024-02-06 01:53:42 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:53:42 --> Database Driver Class Initialized
INFO - 2024-02-06 01:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:53:42 --> Parser Class Initialized
INFO - 2024-02-06 01:53:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:53:42 --> Pagination Class Initialized
INFO - 2024-02-06 01:53:42 --> Form Validation Class Initialized
INFO - 2024-02-06 01:53:42 --> Controller Class Initialized
INFO - 2024-02-06 01:53:42 --> Model Class Initialized
DEBUG - 2024-02-06 01:53:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:53:42 --> Final output sent to browser
DEBUG - 2024-02-06 01:53:42 --> Total execution time: 0.0156
ERROR - 2024-02-06 01:53:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:53:43 --> Config Class Initialized
INFO - 2024-02-06 01:53:43 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:53:43 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:53:43 --> Utf8 Class Initialized
INFO - 2024-02-06 01:53:43 --> URI Class Initialized
INFO - 2024-02-06 01:53:43 --> Router Class Initialized
INFO - 2024-02-06 01:53:43 --> Output Class Initialized
INFO - 2024-02-06 01:53:43 --> Security Class Initialized
DEBUG - 2024-02-06 01:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:53:43 --> Input Class Initialized
INFO - 2024-02-06 01:53:43 --> Language Class Initialized
INFO - 2024-02-06 01:53:43 --> Loader Class Initialized
INFO - 2024-02-06 01:53:43 --> Helper loaded: url_helper
INFO - 2024-02-06 01:53:43 --> Helper loaded: file_helper
INFO - 2024-02-06 01:53:43 --> Helper loaded: html_helper
INFO - 2024-02-06 01:53:43 --> Helper loaded: text_helper
INFO - 2024-02-06 01:53:43 --> Helper loaded: form_helper
INFO - 2024-02-06 01:53:43 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:53:43 --> Helper loaded: security_helper
INFO - 2024-02-06 01:53:43 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:53:43 --> Database Driver Class Initialized
INFO - 2024-02-06 01:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:53:43 --> Parser Class Initialized
INFO - 2024-02-06 01:53:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:53:43 --> Pagination Class Initialized
INFO - 2024-02-06 01:53:43 --> Form Validation Class Initialized
INFO - 2024-02-06 01:53:43 --> Controller Class Initialized
INFO - 2024-02-06 01:53:43 --> Model Class Initialized
DEBUG - 2024-02-06 01:53:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:53:43 --> Final output sent to browser
DEBUG - 2024-02-06 01:53:43 --> Total execution time: 0.0189
ERROR - 2024-02-06 01:53:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:53:45 --> Config Class Initialized
INFO - 2024-02-06 01:53:45 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:53:45 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:53:45 --> Utf8 Class Initialized
INFO - 2024-02-06 01:53:45 --> URI Class Initialized
INFO - 2024-02-06 01:53:45 --> Router Class Initialized
INFO - 2024-02-06 01:53:45 --> Output Class Initialized
INFO - 2024-02-06 01:53:45 --> Security Class Initialized
DEBUG - 2024-02-06 01:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:53:45 --> Input Class Initialized
INFO - 2024-02-06 01:53:45 --> Language Class Initialized
INFO - 2024-02-06 01:53:45 --> Loader Class Initialized
INFO - 2024-02-06 01:53:45 --> Helper loaded: url_helper
INFO - 2024-02-06 01:53:45 --> Helper loaded: file_helper
INFO - 2024-02-06 01:53:45 --> Helper loaded: html_helper
INFO - 2024-02-06 01:53:45 --> Helper loaded: text_helper
INFO - 2024-02-06 01:53:45 --> Helper loaded: form_helper
INFO - 2024-02-06 01:53:45 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:53:45 --> Helper loaded: security_helper
INFO - 2024-02-06 01:53:45 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:53:45 --> Database Driver Class Initialized
INFO - 2024-02-06 01:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:53:45 --> Parser Class Initialized
INFO - 2024-02-06 01:53:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:53:45 --> Pagination Class Initialized
INFO - 2024-02-06 01:53:45 --> Form Validation Class Initialized
INFO - 2024-02-06 01:53:45 --> Controller Class Initialized
INFO - 2024-02-06 01:53:45 --> Final output sent to browser
DEBUG - 2024-02-06 01:53:45 --> Total execution time: 0.0147
ERROR - 2024-02-06 01:53:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:53:51 --> Config Class Initialized
INFO - 2024-02-06 01:53:51 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:53:51 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:53:51 --> Utf8 Class Initialized
INFO - 2024-02-06 01:53:51 --> URI Class Initialized
INFO - 2024-02-06 01:53:51 --> Router Class Initialized
INFO - 2024-02-06 01:53:51 --> Output Class Initialized
INFO - 2024-02-06 01:53:51 --> Security Class Initialized
DEBUG - 2024-02-06 01:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:53:51 --> Input Class Initialized
INFO - 2024-02-06 01:53:51 --> Language Class Initialized
INFO - 2024-02-06 01:53:51 --> Loader Class Initialized
INFO - 2024-02-06 01:53:51 --> Helper loaded: url_helper
INFO - 2024-02-06 01:53:51 --> Helper loaded: file_helper
INFO - 2024-02-06 01:53:51 --> Helper loaded: html_helper
INFO - 2024-02-06 01:53:51 --> Helper loaded: text_helper
INFO - 2024-02-06 01:53:51 --> Helper loaded: form_helper
INFO - 2024-02-06 01:53:51 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:53:51 --> Helper loaded: security_helper
INFO - 2024-02-06 01:53:51 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:53:51 --> Database Driver Class Initialized
INFO - 2024-02-06 01:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:53:51 --> Parser Class Initialized
INFO - 2024-02-06 01:53:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:53:51 --> Pagination Class Initialized
INFO - 2024-02-06 01:53:51 --> Form Validation Class Initialized
INFO - 2024-02-06 01:53:51 --> Controller Class Initialized
INFO - 2024-02-06 01:53:51 --> Model Class Initialized
DEBUG - 2024-02-06 01:53:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:53:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:53:51 --> Model Class Initialized
DEBUG - 2024-02-06 01:53:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:53:51 --> Model Class Initialized
INFO - 2024-02-06 01:53:51 --> Final output sent to browser
DEBUG - 2024-02-06 01:53:51 --> Total execution time: 0.0962
ERROR - 2024-02-06 01:54:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:54:10 --> Config Class Initialized
INFO - 2024-02-06 01:54:10 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:54:10 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:54:10 --> Utf8 Class Initialized
INFO - 2024-02-06 01:54:10 --> URI Class Initialized
INFO - 2024-02-06 01:54:10 --> Router Class Initialized
INFO - 2024-02-06 01:54:10 --> Output Class Initialized
INFO - 2024-02-06 01:54:10 --> Security Class Initialized
DEBUG - 2024-02-06 01:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:54:10 --> Input Class Initialized
INFO - 2024-02-06 01:54:10 --> Language Class Initialized
INFO - 2024-02-06 01:54:10 --> Loader Class Initialized
INFO - 2024-02-06 01:54:10 --> Helper loaded: url_helper
INFO - 2024-02-06 01:54:10 --> Helper loaded: file_helper
INFO - 2024-02-06 01:54:10 --> Helper loaded: html_helper
INFO - 2024-02-06 01:54:10 --> Helper loaded: text_helper
INFO - 2024-02-06 01:54:10 --> Helper loaded: form_helper
INFO - 2024-02-06 01:54:10 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:54:10 --> Helper loaded: security_helper
INFO - 2024-02-06 01:54:10 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:54:10 --> Database Driver Class Initialized
INFO - 2024-02-06 01:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:54:10 --> Parser Class Initialized
INFO - 2024-02-06 01:54:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:54:10 --> Pagination Class Initialized
INFO - 2024-02-06 01:54:10 --> Form Validation Class Initialized
INFO - 2024-02-06 01:54:10 --> Controller Class Initialized
INFO - 2024-02-06 01:54:10 --> Model Class Initialized
DEBUG - 2024-02-06 01:54:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:54:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:54:10 --> Model Class Initialized
DEBUG - 2024-02-06 01:54:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:54:10 --> Model Class Initialized
INFO - 2024-02-06 01:54:10 --> Final output sent to browser
DEBUG - 2024-02-06 01:54:10 --> Total execution time: 0.0955
ERROR - 2024-02-06 01:54:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:54:11 --> Config Class Initialized
INFO - 2024-02-06 01:54:11 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:54:11 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:54:11 --> Utf8 Class Initialized
INFO - 2024-02-06 01:54:11 --> URI Class Initialized
INFO - 2024-02-06 01:54:11 --> Router Class Initialized
INFO - 2024-02-06 01:54:11 --> Output Class Initialized
INFO - 2024-02-06 01:54:11 --> Security Class Initialized
DEBUG - 2024-02-06 01:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:54:11 --> Input Class Initialized
INFO - 2024-02-06 01:54:11 --> Language Class Initialized
INFO - 2024-02-06 01:54:11 --> Loader Class Initialized
INFO - 2024-02-06 01:54:11 --> Helper loaded: url_helper
INFO - 2024-02-06 01:54:11 --> Helper loaded: file_helper
INFO - 2024-02-06 01:54:11 --> Helper loaded: html_helper
INFO - 2024-02-06 01:54:11 --> Helper loaded: text_helper
INFO - 2024-02-06 01:54:11 --> Helper loaded: form_helper
INFO - 2024-02-06 01:54:11 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:54:11 --> Helper loaded: security_helper
INFO - 2024-02-06 01:54:11 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:54:11 --> Database Driver Class Initialized
INFO - 2024-02-06 01:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:54:11 --> Parser Class Initialized
INFO - 2024-02-06 01:54:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:54:11 --> Pagination Class Initialized
INFO - 2024-02-06 01:54:11 --> Form Validation Class Initialized
INFO - 2024-02-06 01:54:11 --> Controller Class Initialized
INFO - 2024-02-06 01:54:11 --> Model Class Initialized
DEBUG - 2024-02-06 01:54:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:54:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:54:11 --> Model Class Initialized
DEBUG - 2024-02-06 01:54:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:54:11 --> Model Class Initialized
INFO - 2024-02-06 01:54:11 --> Final output sent to browser
DEBUG - 2024-02-06 01:54:11 --> Total execution time: 0.0925
ERROR - 2024-02-06 01:55:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:55:20 --> Config Class Initialized
INFO - 2024-02-06 01:55:20 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:55:20 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:55:20 --> Utf8 Class Initialized
INFO - 2024-02-06 01:55:20 --> URI Class Initialized
INFO - 2024-02-06 01:55:20 --> Router Class Initialized
INFO - 2024-02-06 01:55:20 --> Output Class Initialized
INFO - 2024-02-06 01:55:20 --> Security Class Initialized
DEBUG - 2024-02-06 01:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:55:20 --> Input Class Initialized
INFO - 2024-02-06 01:55:20 --> Language Class Initialized
INFO - 2024-02-06 01:55:20 --> Loader Class Initialized
INFO - 2024-02-06 01:55:20 --> Helper loaded: url_helper
INFO - 2024-02-06 01:55:20 --> Helper loaded: file_helper
INFO - 2024-02-06 01:55:20 --> Helper loaded: html_helper
INFO - 2024-02-06 01:55:20 --> Helper loaded: text_helper
INFO - 2024-02-06 01:55:20 --> Helper loaded: form_helper
INFO - 2024-02-06 01:55:20 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:55:20 --> Helper loaded: security_helper
INFO - 2024-02-06 01:55:20 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:55:20 --> Database Driver Class Initialized
INFO - 2024-02-06 01:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:55:20 --> Parser Class Initialized
INFO - 2024-02-06 01:55:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:55:20 --> Pagination Class Initialized
INFO - 2024-02-06 01:55:20 --> Form Validation Class Initialized
INFO - 2024-02-06 01:55:20 --> Controller Class Initialized
INFO - 2024-02-06 01:55:20 --> Model Class Initialized
DEBUG - 2024-02-06 01:55:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:55:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:55:20 --> Model Class Initialized
INFO - 2024-02-06 01:55:20 --> Model Class Initialized
INFO - 2024-02-06 01:55:20 --> Final output sent to browser
DEBUG - 2024-02-06 01:55:20 --> Total execution time: 0.0238
ERROR - 2024-02-06 01:55:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:55:23 --> Config Class Initialized
INFO - 2024-02-06 01:55:23 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:55:23 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:55:23 --> Utf8 Class Initialized
INFO - 2024-02-06 01:55:23 --> URI Class Initialized
INFO - 2024-02-06 01:55:23 --> Router Class Initialized
INFO - 2024-02-06 01:55:23 --> Output Class Initialized
INFO - 2024-02-06 01:55:23 --> Security Class Initialized
DEBUG - 2024-02-06 01:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:55:23 --> Input Class Initialized
INFO - 2024-02-06 01:55:23 --> Language Class Initialized
INFO - 2024-02-06 01:55:23 --> Loader Class Initialized
INFO - 2024-02-06 01:55:23 --> Helper loaded: url_helper
INFO - 2024-02-06 01:55:23 --> Helper loaded: file_helper
INFO - 2024-02-06 01:55:23 --> Helper loaded: html_helper
INFO - 2024-02-06 01:55:23 --> Helper loaded: text_helper
INFO - 2024-02-06 01:55:23 --> Helper loaded: form_helper
INFO - 2024-02-06 01:55:23 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:55:23 --> Helper loaded: security_helper
INFO - 2024-02-06 01:55:23 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:55:23 --> Database Driver Class Initialized
INFO - 2024-02-06 01:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:55:23 --> Parser Class Initialized
INFO - 2024-02-06 01:55:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:55:23 --> Pagination Class Initialized
INFO - 2024-02-06 01:55:23 --> Form Validation Class Initialized
INFO - 2024-02-06 01:55:23 --> Controller Class Initialized
INFO - 2024-02-06 01:55:23 --> Model Class Initialized
DEBUG - 2024-02-06 01:55:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:55:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:55:23 --> Model Class Initialized
INFO - 2024-02-06 01:55:23 --> Final output sent to browser
DEBUG - 2024-02-06 01:55:23 --> Total execution time: 0.0177
ERROR - 2024-02-06 01:55:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:55:26 --> Config Class Initialized
INFO - 2024-02-06 01:55:26 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:55:26 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:55:26 --> Utf8 Class Initialized
INFO - 2024-02-06 01:55:26 --> URI Class Initialized
INFO - 2024-02-06 01:55:26 --> Router Class Initialized
INFO - 2024-02-06 01:55:26 --> Output Class Initialized
INFO - 2024-02-06 01:55:26 --> Security Class Initialized
DEBUG - 2024-02-06 01:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:55:26 --> Input Class Initialized
INFO - 2024-02-06 01:55:26 --> Language Class Initialized
INFO - 2024-02-06 01:55:26 --> Loader Class Initialized
INFO - 2024-02-06 01:55:26 --> Helper loaded: url_helper
INFO - 2024-02-06 01:55:26 --> Helper loaded: file_helper
INFO - 2024-02-06 01:55:26 --> Helper loaded: html_helper
INFO - 2024-02-06 01:55:26 --> Helper loaded: text_helper
INFO - 2024-02-06 01:55:26 --> Helper loaded: form_helper
INFO - 2024-02-06 01:55:26 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:55:26 --> Helper loaded: security_helper
INFO - 2024-02-06 01:55:26 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:55:26 --> Database Driver Class Initialized
INFO - 2024-02-06 01:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:55:26 --> Parser Class Initialized
INFO - 2024-02-06 01:55:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:55:26 --> Pagination Class Initialized
INFO - 2024-02-06 01:55:26 --> Form Validation Class Initialized
INFO - 2024-02-06 01:55:26 --> Controller Class Initialized
INFO - 2024-02-06 01:55:26 --> Model Class Initialized
DEBUG - 2024-02-06 01:55:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:55:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:55:26 --> Model Class Initialized
INFO - 2024-02-06 01:55:26 --> Final output sent to browser
DEBUG - 2024-02-06 01:55:26 --> Total execution time: 0.0168
ERROR - 2024-02-06 01:55:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:55:44 --> Config Class Initialized
INFO - 2024-02-06 01:55:44 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:55:44 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:55:44 --> Utf8 Class Initialized
INFO - 2024-02-06 01:55:44 --> URI Class Initialized
INFO - 2024-02-06 01:55:44 --> Router Class Initialized
INFO - 2024-02-06 01:55:44 --> Output Class Initialized
INFO - 2024-02-06 01:55:44 --> Security Class Initialized
DEBUG - 2024-02-06 01:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:55:44 --> Input Class Initialized
INFO - 2024-02-06 01:55:44 --> Language Class Initialized
INFO - 2024-02-06 01:55:44 --> Loader Class Initialized
INFO - 2024-02-06 01:55:44 --> Helper loaded: url_helper
INFO - 2024-02-06 01:55:44 --> Helper loaded: file_helper
INFO - 2024-02-06 01:55:44 --> Helper loaded: html_helper
INFO - 2024-02-06 01:55:44 --> Helper loaded: text_helper
INFO - 2024-02-06 01:55:44 --> Helper loaded: form_helper
INFO - 2024-02-06 01:55:44 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:55:44 --> Helper loaded: security_helper
INFO - 2024-02-06 01:55:44 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:55:44 --> Database Driver Class Initialized
INFO - 2024-02-06 01:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:55:44 --> Parser Class Initialized
INFO - 2024-02-06 01:55:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:55:44 --> Pagination Class Initialized
INFO - 2024-02-06 01:55:44 --> Form Validation Class Initialized
INFO - 2024-02-06 01:55:44 --> Controller Class Initialized
INFO - 2024-02-06 01:55:44 --> Model Class Initialized
DEBUG - 2024-02-06 01:55:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:55:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:55:44 --> Model Class Initialized
INFO - 2024-02-06 01:55:44 --> Final output sent to browser
DEBUG - 2024-02-06 01:55:44 --> Total execution time: 0.0202
ERROR - 2024-02-06 01:56:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:56:13 --> Config Class Initialized
INFO - 2024-02-06 01:56:13 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:56:13 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:56:13 --> Utf8 Class Initialized
INFO - 2024-02-06 01:56:13 --> URI Class Initialized
INFO - 2024-02-06 01:56:13 --> Router Class Initialized
INFO - 2024-02-06 01:56:13 --> Output Class Initialized
INFO - 2024-02-06 01:56:13 --> Security Class Initialized
DEBUG - 2024-02-06 01:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:56:13 --> Input Class Initialized
INFO - 2024-02-06 01:56:13 --> Language Class Initialized
INFO - 2024-02-06 01:56:13 --> Loader Class Initialized
INFO - 2024-02-06 01:56:13 --> Helper loaded: url_helper
INFO - 2024-02-06 01:56:13 --> Helper loaded: file_helper
INFO - 2024-02-06 01:56:13 --> Helper loaded: html_helper
INFO - 2024-02-06 01:56:13 --> Helper loaded: text_helper
INFO - 2024-02-06 01:56:13 --> Helper loaded: form_helper
INFO - 2024-02-06 01:56:13 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:56:13 --> Helper loaded: security_helper
INFO - 2024-02-06 01:56:13 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:56:13 --> Database Driver Class Initialized
INFO - 2024-02-06 01:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:56:13 --> Parser Class Initialized
INFO - 2024-02-06 01:56:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:56:13 --> Pagination Class Initialized
INFO - 2024-02-06 01:56:13 --> Form Validation Class Initialized
INFO - 2024-02-06 01:56:13 --> Controller Class Initialized
INFO - 2024-02-06 01:56:13 --> Model Class Initialized
DEBUG - 2024-02-06 01:56:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:56:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:56:13 --> Model Class Initialized
DEBUG - 2024-02-06 01:56:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:56:13 --> Model Class Initialized
INFO - 2024-02-06 01:56:13 --> Final output sent to browser
DEBUG - 2024-02-06 01:56:13 --> Total execution time: 0.0216
ERROR - 2024-02-06 01:56:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:56:17 --> Config Class Initialized
INFO - 2024-02-06 01:56:17 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:56:17 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:56:17 --> Utf8 Class Initialized
INFO - 2024-02-06 01:56:17 --> URI Class Initialized
INFO - 2024-02-06 01:56:17 --> Router Class Initialized
INFO - 2024-02-06 01:56:17 --> Output Class Initialized
INFO - 2024-02-06 01:56:17 --> Security Class Initialized
DEBUG - 2024-02-06 01:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:56:17 --> Input Class Initialized
INFO - 2024-02-06 01:56:17 --> Language Class Initialized
INFO - 2024-02-06 01:56:17 --> Loader Class Initialized
INFO - 2024-02-06 01:56:17 --> Helper loaded: url_helper
INFO - 2024-02-06 01:56:17 --> Helper loaded: file_helper
INFO - 2024-02-06 01:56:17 --> Helper loaded: html_helper
INFO - 2024-02-06 01:56:17 --> Helper loaded: text_helper
INFO - 2024-02-06 01:56:17 --> Helper loaded: form_helper
INFO - 2024-02-06 01:56:17 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:56:17 --> Helper loaded: security_helper
INFO - 2024-02-06 01:56:17 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:56:17 --> Database Driver Class Initialized
INFO - 2024-02-06 01:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:56:17 --> Parser Class Initialized
INFO - 2024-02-06 01:56:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:56:17 --> Pagination Class Initialized
INFO - 2024-02-06 01:56:17 --> Form Validation Class Initialized
INFO - 2024-02-06 01:56:17 --> Controller Class Initialized
INFO - 2024-02-06 01:56:17 --> Model Class Initialized
DEBUG - 2024-02-06 01:56:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:56:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:56:17 --> Model Class Initialized
DEBUG - 2024-02-06 01:56:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:56:17 --> Model Class Initialized
INFO - 2024-02-06 01:56:17 --> Final output sent to browser
DEBUG - 2024-02-06 01:56:17 --> Total execution time: 0.0180
ERROR - 2024-02-06 01:56:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:56:19 --> Config Class Initialized
INFO - 2024-02-06 01:56:19 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:56:19 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:56:19 --> Utf8 Class Initialized
INFO - 2024-02-06 01:56:19 --> URI Class Initialized
INFO - 2024-02-06 01:56:19 --> Router Class Initialized
INFO - 2024-02-06 01:56:19 --> Output Class Initialized
INFO - 2024-02-06 01:56:19 --> Security Class Initialized
DEBUG - 2024-02-06 01:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:56:19 --> Input Class Initialized
INFO - 2024-02-06 01:56:19 --> Language Class Initialized
INFO - 2024-02-06 01:56:19 --> Loader Class Initialized
INFO - 2024-02-06 01:56:19 --> Helper loaded: url_helper
INFO - 2024-02-06 01:56:19 --> Helper loaded: file_helper
INFO - 2024-02-06 01:56:19 --> Helper loaded: html_helper
INFO - 2024-02-06 01:56:19 --> Helper loaded: text_helper
INFO - 2024-02-06 01:56:19 --> Helper loaded: form_helper
INFO - 2024-02-06 01:56:19 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:56:19 --> Helper loaded: security_helper
INFO - 2024-02-06 01:56:19 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:56:19 --> Database Driver Class Initialized
INFO - 2024-02-06 01:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:56:19 --> Parser Class Initialized
INFO - 2024-02-06 01:56:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:56:19 --> Pagination Class Initialized
INFO - 2024-02-06 01:56:19 --> Form Validation Class Initialized
INFO - 2024-02-06 01:56:19 --> Controller Class Initialized
INFO - 2024-02-06 01:56:19 --> Model Class Initialized
DEBUG - 2024-02-06 01:56:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:56:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:56:19 --> Model Class Initialized
DEBUG - 2024-02-06 01:56:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:56:19 --> Model Class Initialized
INFO - 2024-02-06 01:56:19 --> Final output sent to browser
DEBUG - 2024-02-06 01:56:19 --> Total execution time: 0.0210
ERROR - 2024-02-06 01:56:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:56:22 --> Config Class Initialized
INFO - 2024-02-06 01:56:22 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:56:22 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:56:22 --> Utf8 Class Initialized
INFO - 2024-02-06 01:56:22 --> URI Class Initialized
INFO - 2024-02-06 01:56:22 --> Router Class Initialized
INFO - 2024-02-06 01:56:22 --> Output Class Initialized
INFO - 2024-02-06 01:56:22 --> Security Class Initialized
DEBUG - 2024-02-06 01:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:56:22 --> Input Class Initialized
INFO - 2024-02-06 01:56:22 --> Language Class Initialized
INFO - 2024-02-06 01:56:22 --> Loader Class Initialized
INFO - 2024-02-06 01:56:22 --> Helper loaded: url_helper
INFO - 2024-02-06 01:56:22 --> Helper loaded: file_helper
INFO - 2024-02-06 01:56:22 --> Helper loaded: html_helper
INFO - 2024-02-06 01:56:22 --> Helper loaded: text_helper
INFO - 2024-02-06 01:56:22 --> Helper loaded: form_helper
INFO - 2024-02-06 01:56:22 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:56:22 --> Helper loaded: security_helper
INFO - 2024-02-06 01:56:22 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:56:22 --> Database Driver Class Initialized
INFO - 2024-02-06 01:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:56:22 --> Parser Class Initialized
INFO - 2024-02-06 01:56:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:56:22 --> Pagination Class Initialized
INFO - 2024-02-06 01:56:22 --> Form Validation Class Initialized
INFO - 2024-02-06 01:56:22 --> Controller Class Initialized
INFO - 2024-02-06 01:56:22 --> Model Class Initialized
DEBUG - 2024-02-06 01:56:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:56:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:56:22 --> Model Class Initialized
DEBUG - 2024-02-06 01:56:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:56:22 --> Model Class Initialized
INFO - 2024-02-06 01:56:22 --> Final output sent to browser
DEBUG - 2024-02-06 01:56:22 --> Total execution time: 0.1010
ERROR - 2024-02-06 01:56:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:56:23 --> Config Class Initialized
INFO - 2024-02-06 01:56:23 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:56:23 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:56:23 --> Utf8 Class Initialized
INFO - 2024-02-06 01:56:23 --> URI Class Initialized
INFO - 2024-02-06 01:56:23 --> Router Class Initialized
INFO - 2024-02-06 01:56:23 --> Output Class Initialized
INFO - 2024-02-06 01:56:23 --> Security Class Initialized
DEBUG - 2024-02-06 01:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:56:23 --> Input Class Initialized
INFO - 2024-02-06 01:56:23 --> Language Class Initialized
INFO - 2024-02-06 01:56:23 --> Loader Class Initialized
INFO - 2024-02-06 01:56:23 --> Helper loaded: url_helper
INFO - 2024-02-06 01:56:23 --> Helper loaded: file_helper
INFO - 2024-02-06 01:56:23 --> Helper loaded: html_helper
INFO - 2024-02-06 01:56:23 --> Helper loaded: text_helper
INFO - 2024-02-06 01:56:23 --> Helper loaded: form_helper
INFO - 2024-02-06 01:56:23 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:56:23 --> Helper loaded: security_helper
INFO - 2024-02-06 01:56:23 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:56:24 --> Database Driver Class Initialized
INFO - 2024-02-06 01:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:56:24 --> Parser Class Initialized
INFO - 2024-02-06 01:56:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:56:24 --> Pagination Class Initialized
INFO - 2024-02-06 01:56:24 --> Form Validation Class Initialized
INFO - 2024-02-06 01:56:24 --> Controller Class Initialized
INFO - 2024-02-06 01:56:24 --> Model Class Initialized
DEBUG - 2024-02-06 01:56:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:56:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:56:24 --> Model Class Initialized
DEBUG - 2024-02-06 01:56:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:56:24 --> Model Class Initialized
INFO - 2024-02-06 01:56:24 --> Final output sent to browser
DEBUG - 2024-02-06 01:56:24 --> Total execution time: 0.0925
ERROR - 2024-02-06 01:56:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:56:29 --> Config Class Initialized
INFO - 2024-02-06 01:56:29 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:56:29 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:56:29 --> Utf8 Class Initialized
INFO - 2024-02-06 01:56:29 --> URI Class Initialized
INFO - 2024-02-06 01:56:29 --> Router Class Initialized
INFO - 2024-02-06 01:56:29 --> Output Class Initialized
INFO - 2024-02-06 01:56:29 --> Security Class Initialized
DEBUG - 2024-02-06 01:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:56:29 --> Input Class Initialized
INFO - 2024-02-06 01:56:29 --> Language Class Initialized
INFO - 2024-02-06 01:56:29 --> Loader Class Initialized
INFO - 2024-02-06 01:56:29 --> Helper loaded: url_helper
INFO - 2024-02-06 01:56:29 --> Helper loaded: file_helper
INFO - 2024-02-06 01:56:29 --> Helper loaded: html_helper
INFO - 2024-02-06 01:56:29 --> Helper loaded: text_helper
INFO - 2024-02-06 01:56:29 --> Helper loaded: form_helper
INFO - 2024-02-06 01:56:29 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:56:29 --> Helper loaded: security_helper
INFO - 2024-02-06 01:56:29 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:56:29 --> Database Driver Class Initialized
INFO - 2024-02-06 01:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:56:29 --> Parser Class Initialized
INFO - 2024-02-06 01:56:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:56:29 --> Pagination Class Initialized
INFO - 2024-02-06 01:56:29 --> Form Validation Class Initialized
INFO - 2024-02-06 01:56:29 --> Controller Class Initialized
INFO - 2024-02-06 01:56:29 --> Model Class Initialized
DEBUG - 2024-02-06 01:56:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:56:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:56:29 --> Model Class Initialized
INFO - 2024-02-06 01:56:29 --> Model Class Initialized
INFO - 2024-02-06 01:56:29 --> Final output sent to browser
DEBUG - 2024-02-06 01:56:29 --> Total execution time: 0.0195
ERROR - 2024-02-06 01:56:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:56:32 --> Config Class Initialized
INFO - 2024-02-06 01:56:32 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:56:32 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:56:32 --> Utf8 Class Initialized
INFO - 2024-02-06 01:56:32 --> URI Class Initialized
INFO - 2024-02-06 01:56:32 --> Router Class Initialized
INFO - 2024-02-06 01:56:32 --> Output Class Initialized
INFO - 2024-02-06 01:56:32 --> Security Class Initialized
DEBUG - 2024-02-06 01:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:56:32 --> Input Class Initialized
INFO - 2024-02-06 01:56:32 --> Language Class Initialized
INFO - 2024-02-06 01:56:32 --> Loader Class Initialized
INFO - 2024-02-06 01:56:32 --> Helper loaded: url_helper
INFO - 2024-02-06 01:56:32 --> Helper loaded: file_helper
INFO - 2024-02-06 01:56:32 --> Helper loaded: html_helper
INFO - 2024-02-06 01:56:32 --> Helper loaded: text_helper
INFO - 2024-02-06 01:56:32 --> Helper loaded: form_helper
INFO - 2024-02-06 01:56:32 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:56:32 --> Helper loaded: security_helper
INFO - 2024-02-06 01:56:32 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:56:32 --> Database Driver Class Initialized
INFO - 2024-02-06 01:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:56:32 --> Parser Class Initialized
INFO - 2024-02-06 01:56:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:56:32 --> Pagination Class Initialized
INFO - 2024-02-06 01:56:32 --> Form Validation Class Initialized
INFO - 2024-02-06 01:56:32 --> Controller Class Initialized
INFO - 2024-02-06 01:56:32 --> Model Class Initialized
DEBUG - 2024-02-06 01:56:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:56:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:56:32 --> Model Class Initialized
INFO - 2024-02-06 01:56:32 --> Final output sent to browser
DEBUG - 2024-02-06 01:56:32 --> Total execution time: 0.0153
ERROR - 2024-02-06 01:56:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:56:33 --> Config Class Initialized
INFO - 2024-02-06 01:56:33 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:56:33 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:56:33 --> Utf8 Class Initialized
INFO - 2024-02-06 01:56:33 --> URI Class Initialized
INFO - 2024-02-06 01:56:33 --> Router Class Initialized
INFO - 2024-02-06 01:56:33 --> Output Class Initialized
INFO - 2024-02-06 01:56:33 --> Security Class Initialized
DEBUG - 2024-02-06 01:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:56:33 --> Input Class Initialized
INFO - 2024-02-06 01:56:33 --> Language Class Initialized
INFO - 2024-02-06 01:56:33 --> Loader Class Initialized
INFO - 2024-02-06 01:56:33 --> Helper loaded: url_helper
INFO - 2024-02-06 01:56:33 --> Helper loaded: file_helper
INFO - 2024-02-06 01:56:33 --> Helper loaded: html_helper
INFO - 2024-02-06 01:56:33 --> Helper loaded: text_helper
INFO - 2024-02-06 01:56:33 --> Helper loaded: form_helper
INFO - 2024-02-06 01:56:33 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:56:33 --> Helper loaded: security_helper
INFO - 2024-02-06 01:56:33 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:56:33 --> Database Driver Class Initialized
INFO - 2024-02-06 01:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:56:33 --> Parser Class Initialized
INFO - 2024-02-06 01:56:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:56:33 --> Pagination Class Initialized
INFO - 2024-02-06 01:56:33 --> Form Validation Class Initialized
INFO - 2024-02-06 01:56:33 --> Controller Class Initialized
INFO - 2024-02-06 01:56:33 --> Model Class Initialized
DEBUG - 2024-02-06 01:56:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:56:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:56:33 --> Model Class Initialized
INFO - 2024-02-06 01:56:33 --> Final output sent to browser
DEBUG - 2024-02-06 01:56:33 --> Total execution time: 0.0179
ERROR - 2024-02-06 01:56:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:56:55 --> Config Class Initialized
INFO - 2024-02-06 01:56:55 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:56:55 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:56:55 --> Utf8 Class Initialized
INFO - 2024-02-06 01:56:55 --> URI Class Initialized
INFO - 2024-02-06 01:56:55 --> Router Class Initialized
INFO - 2024-02-06 01:56:55 --> Output Class Initialized
INFO - 2024-02-06 01:56:55 --> Security Class Initialized
DEBUG - 2024-02-06 01:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:56:55 --> Input Class Initialized
INFO - 2024-02-06 01:56:55 --> Language Class Initialized
INFO - 2024-02-06 01:56:55 --> Loader Class Initialized
INFO - 2024-02-06 01:56:55 --> Helper loaded: url_helper
INFO - 2024-02-06 01:56:55 --> Helper loaded: file_helper
INFO - 2024-02-06 01:56:55 --> Helper loaded: html_helper
INFO - 2024-02-06 01:56:55 --> Helper loaded: text_helper
INFO - 2024-02-06 01:56:55 --> Helper loaded: form_helper
INFO - 2024-02-06 01:56:55 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:56:55 --> Helper loaded: security_helper
INFO - 2024-02-06 01:56:55 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:56:55 --> Database Driver Class Initialized
INFO - 2024-02-06 01:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:56:55 --> Parser Class Initialized
INFO - 2024-02-06 01:56:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:56:55 --> Pagination Class Initialized
INFO - 2024-02-06 01:56:55 --> Form Validation Class Initialized
INFO - 2024-02-06 01:56:55 --> Controller Class Initialized
INFO - 2024-02-06 01:56:55 --> Model Class Initialized
DEBUG - 2024-02-06 01:56:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:56:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:56:55 --> Model Class Initialized
DEBUG - 2024-02-06 01:56:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:56:55 --> Model Class Initialized
INFO - 2024-02-06 01:56:55 --> Final output sent to browser
DEBUG - 2024-02-06 01:56:55 --> Total execution time: 0.0943
ERROR - 2024-02-06 01:57:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:57:10 --> Config Class Initialized
INFO - 2024-02-06 01:57:10 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:57:10 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:57:10 --> Utf8 Class Initialized
INFO - 2024-02-06 01:57:10 --> URI Class Initialized
INFO - 2024-02-06 01:57:10 --> Router Class Initialized
INFO - 2024-02-06 01:57:10 --> Output Class Initialized
INFO - 2024-02-06 01:57:10 --> Security Class Initialized
DEBUG - 2024-02-06 01:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:57:10 --> Input Class Initialized
INFO - 2024-02-06 01:57:10 --> Language Class Initialized
INFO - 2024-02-06 01:57:10 --> Loader Class Initialized
INFO - 2024-02-06 01:57:10 --> Helper loaded: url_helper
INFO - 2024-02-06 01:57:10 --> Helper loaded: file_helper
INFO - 2024-02-06 01:57:10 --> Helper loaded: html_helper
INFO - 2024-02-06 01:57:10 --> Helper loaded: text_helper
INFO - 2024-02-06 01:57:10 --> Helper loaded: form_helper
INFO - 2024-02-06 01:57:10 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:57:10 --> Helper loaded: security_helper
INFO - 2024-02-06 01:57:10 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:57:10 --> Database Driver Class Initialized
INFO - 2024-02-06 01:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:57:10 --> Parser Class Initialized
INFO - 2024-02-06 01:57:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:57:10 --> Pagination Class Initialized
INFO - 2024-02-06 01:57:10 --> Form Validation Class Initialized
INFO - 2024-02-06 01:57:10 --> Controller Class Initialized
INFO - 2024-02-06 01:57:10 --> Model Class Initialized
DEBUG - 2024-02-06 01:57:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:57:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:57:10 --> Model Class Initialized
INFO - 2024-02-06 01:57:10 --> Model Class Initialized
INFO - 2024-02-06 01:57:10 --> Final output sent to browser
DEBUG - 2024-02-06 01:57:10 --> Total execution time: 0.0231
ERROR - 2024-02-06 01:57:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:57:15 --> Config Class Initialized
INFO - 2024-02-06 01:57:15 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:57:15 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:57:15 --> Utf8 Class Initialized
INFO - 2024-02-06 01:57:15 --> URI Class Initialized
INFO - 2024-02-06 01:57:15 --> Router Class Initialized
INFO - 2024-02-06 01:57:15 --> Output Class Initialized
INFO - 2024-02-06 01:57:15 --> Security Class Initialized
DEBUG - 2024-02-06 01:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:57:15 --> Input Class Initialized
INFO - 2024-02-06 01:57:15 --> Language Class Initialized
INFO - 2024-02-06 01:57:15 --> Loader Class Initialized
INFO - 2024-02-06 01:57:15 --> Helper loaded: url_helper
INFO - 2024-02-06 01:57:15 --> Helper loaded: file_helper
INFO - 2024-02-06 01:57:15 --> Helper loaded: html_helper
INFO - 2024-02-06 01:57:15 --> Helper loaded: text_helper
INFO - 2024-02-06 01:57:15 --> Helper loaded: form_helper
INFO - 2024-02-06 01:57:15 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:57:15 --> Helper loaded: security_helper
INFO - 2024-02-06 01:57:15 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:57:15 --> Database Driver Class Initialized
INFO - 2024-02-06 01:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:57:15 --> Parser Class Initialized
INFO - 2024-02-06 01:57:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:57:15 --> Pagination Class Initialized
INFO - 2024-02-06 01:57:15 --> Form Validation Class Initialized
INFO - 2024-02-06 01:57:15 --> Controller Class Initialized
INFO - 2024-02-06 01:57:15 --> Model Class Initialized
DEBUG - 2024-02-06 01:57:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:57:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:57:15 --> Model Class Initialized
INFO - 2024-02-06 01:57:15 --> Final output sent to browser
DEBUG - 2024-02-06 01:57:15 --> Total execution time: 0.0181
ERROR - 2024-02-06 01:57:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:57:18 --> Config Class Initialized
INFO - 2024-02-06 01:57:18 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:57:18 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:57:18 --> Utf8 Class Initialized
INFO - 2024-02-06 01:57:18 --> URI Class Initialized
INFO - 2024-02-06 01:57:18 --> Router Class Initialized
INFO - 2024-02-06 01:57:18 --> Output Class Initialized
INFO - 2024-02-06 01:57:18 --> Security Class Initialized
DEBUG - 2024-02-06 01:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:57:18 --> Input Class Initialized
INFO - 2024-02-06 01:57:18 --> Language Class Initialized
INFO - 2024-02-06 01:57:18 --> Loader Class Initialized
INFO - 2024-02-06 01:57:18 --> Helper loaded: url_helper
INFO - 2024-02-06 01:57:18 --> Helper loaded: file_helper
INFO - 2024-02-06 01:57:18 --> Helper loaded: html_helper
INFO - 2024-02-06 01:57:18 --> Helper loaded: text_helper
INFO - 2024-02-06 01:57:18 --> Helper loaded: form_helper
INFO - 2024-02-06 01:57:18 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:57:18 --> Helper loaded: security_helper
INFO - 2024-02-06 01:57:18 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:57:18 --> Database Driver Class Initialized
INFO - 2024-02-06 01:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:57:18 --> Parser Class Initialized
INFO - 2024-02-06 01:57:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:57:18 --> Pagination Class Initialized
INFO - 2024-02-06 01:57:18 --> Form Validation Class Initialized
INFO - 2024-02-06 01:57:18 --> Controller Class Initialized
INFO - 2024-02-06 01:57:18 --> Model Class Initialized
DEBUG - 2024-02-06 01:57:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:57:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:57:18 --> Model Class Initialized
INFO - 2024-02-06 01:57:18 --> Final output sent to browser
DEBUG - 2024-02-06 01:57:18 --> Total execution time: 0.0166
ERROR - 2024-02-06 01:57:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:57:21 --> Config Class Initialized
INFO - 2024-02-06 01:57:21 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:57:21 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:57:21 --> Utf8 Class Initialized
INFO - 2024-02-06 01:57:21 --> URI Class Initialized
INFO - 2024-02-06 01:57:21 --> Router Class Initialized
INFO - 2024-02-06 01:57:21 --> Output Class Initialized
INFO - 2024-02-06 01:57:21 --> Security Class Initialized
DEBUG - 2024-02-06 01:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:57:21 --> Input Class Initialized
INFO - 2024-02-06 01:57:21 --> Language Class Initialized
INFO - 2024-02-06 01:57:21 --> Loader Class Initialized
INFO - 2024-02-06 01:57:21 --> Helper loaded: url_helper
INFO - 2024-02-06 01:57:21 --> Helper loaded: file_helper
INFO - 2024-02-06 01:57:21 --> Helper loaded: html_helper
INFO - 2024-02-06 01:57:21 --> Helper loaded: text_helper
INFO - 2024-02-06 01:57:21 --> Helper loaded: form_helper
INFO - 2024-02-06 01:57:21 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:57:21 --> Helper loaded: security_helper
INFO - 2024-02-06 01:57:21 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:57:21 --> Database Driver Class Initialized
INFO - 2024-02-06 01:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:57:21 --> Parser Class Initialized
INFO - 2024-02-06 01:57:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:57:21 --> Pagination Class Initialized
INFO - 2024-02-06 01:57:21 --> Form Validation Class Initialized
INFO - 2024-02-06 01:57:21 --> Controller Class Initialized
INFO - 2024-02-06 01:57:21 --> Model Class Initialized
DEBUG - 2024-02-06 01:57:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:57:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:57:21 --> Model Class Initialized
INFO - 2024-02-06 01:57:21 --> Final output sent to browser
DEBUG - 2024-02-06 01:57:21 --> Total execution time: 0.0205
ERROR - 2024-02-06 01:57:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:57:53 --> Config Class Initialized
INFO - 2024-02-06 01:57:53 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:57:53 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:57:53 --> Utf8 Class Initialized
INFO - 2024-02-06 01:57:53 --> URI Class Initialized
INFO - 2024-02-06 01:57:53 --> Router Class Initialized
INFO - 2024-02-06 01:57:53 --> Output Class Initialized
INFO - 2024-02-06 01:57:53 --> Security Class Initialized
DEBUG - 2024-02-06 01:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:57:53 --> Input Class Initialized
INFO - 2024-02-06 01:57:53 --> Language Class Initialized
INFO - 2024-02-06 01:57:53 --> Loader Class Initialized
INFO - 2024-02-06 01:57:53 --> Helper loaded: url_helper
INFO - 2024-02-06 01:57:53 --> Helper loaded: file_helper
INFO - 2024-02-06 01:57:53 --> Helper loaded: html_helper
INFO - 2024-02-06 01:57:53 --> Helper loaded: text_helper
INFO - 2024-02-06 01:57:53 --> Helper loaded: form_helper
INFO - 2024-02-06 01:57:53 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:57:53 --> Helper loaded: security_helper
INFO - 2024-02-06 01:57:53 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:57:53 --> Database Driver Class Initialized
INFO - 2024-02-06 01:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:57:53 --> Parser Class Initialized
INFO - 2024-02-06 01:57:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:57:53 --> Pagination Class Initialized
INFO - 2024-02-06 01:57:53 --> Form Validation Class Initialized
INFO - 2024-02-06 01:57:53 --> Controller Class Initialized
INFO - 2024-02-06 01:57:53 --> Model Class Initialized
DEBUG - 2024-02-06 01:57:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:57:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:57:53 --> Model Class Initialized
DEBUG - 2024-02-06 01:57:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:57:53 --> Model Class Initialized
INFO - 2024-02-06 01:57:53 --> Final output sent to browser
DEBUG - 2024-02-06 01:57:53 --> Total execution time: 0.0927
ERROR - 2024-02-06 01:57:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:57:54 --> Config Class Initialized
INFO - 2024-02-06 01:57:54 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:57:54 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:57:54 --> Utf8 Class Initialized
INFO - 2024-02-06 01:57:54 --> URI Class Initialized
INFO - 2024-02-06 01:57:54 --> Router Class Initialized
INFO - 2024-02-06 01:57:54 --> Output Class Initialized
INFO - 2024-02-06 01:57:54 --> Security Class Initialized
DEBUG - 2024-02-06 01:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:57:54 --> Input Class Initialized
INFO - 2024-02-06 01:57:54 --> Language Class Initialized
INFO - 2024-02-06 01:57:54 --> Loader Class Initialized
INFO - 2024-02-06 01:57:54 --> Helper loaded: url_helper
INFO - 2024-02-06 01:57:54 --> Helper loaded: file_helper
INFO - 2024-02-06 01:57:54 --> Helper loaded: html_helper
INFO - 2024-02-06 01:57:54 --> Helper loaded: text_helper
INFO - 2024-02-06 01:57:54 --> Helper loaded: form_helper
INFO - 2024-02-06 01:57:54 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:57:54 --> Helper loaded: security_helper
INFO - 2024-02-06 01:57:54 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:57:54 --> Database Driver Class Initialized
INFO - 2024-02-06 01:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:57:54 --> Parser Class Initialized
INFO - 2024-02-06 01:57:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:57:54 --> Pagination Class Initialized
INFO - 2024-02-06 01:57:54 --> Form Validation Class Initialized
INFO - 2024-02-06 01:57:54 --> Controller Class Initialized
INFO - 2024-02-06 01:57:54 --> Model Class Initialized
DEBUG - 2024-02-06 01:57:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:57:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:57:54 --> Model Class Initialized
DEBUG - 2024-02-06 01:57:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:57:54 --> Model Class Initialized
INFO - 2024-02-06 01:57:54 --> Final output sent to browser
DEBUG - 2024-02-06 01:57:54 --> Total execution time: 0.0888
ERROR - 2024-02-06 01:58:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:58:01 --> Config Class Initialized
INFO - 2024-02-06 01:58:01 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:58:01 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:58:01 --> Utf8 Class Initialized
INFO - 2024-02-06 01:58:01 --> URI Class Initialized
INFO - 2024-02-06 01:58:01 --> Router Class Initialized
INFO - 2024-02-06 01:58:01 --> Output Class Initialized
INFO - 2024-02-06 01:58:01 --> Security Class Initialized
DEBUG - 2024-02-06 01:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:58:01 --> Input Class Initialized
INFO - 2024-02-06 01:58:01 --> Language Class Initialized
INFO - 2024-02-06 01:58:01 --> Loader Class Initialized
INFO - 2024-02-06 01:58:01 --> Helper loaded: url_helper
INFO - 2024-02-06 01:58:01 --> Helper loaded: file_helper
INFO - 2024-02-06 01:58:01 --> Helper loaded: html_helper
INFO - 2024-02-06 01:58:01 --> Helper loaded: text_helper
INFO - 2024-02-06 01:58:01 --> Helper loaded: form_helper
INFO - 2024-02-06 01:58:01 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:58:01 --> Helper loaded: security_helper
INFO - 2024-02-06 01:58:01 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:58:01 --> Database Driver Class Initialized
INFO - 2024-02-06 01:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:58:01 --> Parser Class Initialized
INFO - 2024-02-06 01:58:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:58:01 --> Pagination Class Initialized
INFO - 2024-02-06 01:58:01 --> Form Validation Class Initialized
INFO - 2024-02-06 01:58:01 --> Controller Class Initialized
INFO - 2024-02-06 01:58:01 --> Model Class Initialized
DEBUG - 2024-02-06 01:58:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:58:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:58:01 --> Model Class Initialized
INFO - 2024-02-06 01:58:01 --> Model Class Initialized
INFO - 2024-02-06 01:58:01 --> Final output sent to browser
DEBUG - 2024-02-06 01:58:01 --> Total execution time: 0.0242
ERROR - 2024-02-06 01:58:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:58:06 --> Config Class Initialized
INFO - 2024-02-06 01:58:06 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:58:06 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:58:06 --> Utf8 Class Initialized
INFO - 2024-02-06 01:58:06 --> URI Class Initialized
INFO - 2024-02-06 01:58:06 --> Router Class Initialized
INFO - 2024-02-06 01:58:06 --> Output Class Initialized
INFO - 2024-02-06 01:58:06 --> Security Class Initialized
DEBUG - 2024-02-06 01:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:58:06 --> Input Class Initialized
INFO - 2024-02-06 01:58:06 --> Language Class Initialized
INFO - 2024-02-06 01:58:06 --> Loader Class Initialized
INFO - 2024-02-06 01:58:06 --> Helper loaded: url_helper
INFO - 2024-02-06 01:58:06 --> Helper loaded: file_helper
INFO - 2024-02-06 01:58:06 --> Helper loaded: html_helper
INFO - 2024-02-06 01:58:06 --> Helper loaded: text_helper
INFO - 2024-02-06 01:58:06 --> Helper loaded: form_helper
INFO - 2024-02-06 01:58:06 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:58:06 --> Helper loaded: security_helper
INFO - 2024-02-06 01:58:06 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:58:06 --> Database Driver Class Initialized
INFO - 2024-02-06 01:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:58:06 --> Parser Class Initialized
INFO - 2024-02-06 01:58:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:58:06 --> Pagination Class Initialized
INFO - 2024-02-06 01:58:06 --> Form Validation Class Initialized
INFO - 2024-02-06 01:58:06 --> Controller Class Initialized
INFO - 2024-02-06 01:58:06 --> Model Class Initialized
DEBUG - 2024-02-06 01:58:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:58:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:58:06 --> Model Class Initialized
INFO - 2024-02-06 01:58:06 --> Final output sent to browser
DEBUG - 2024-02-06 01:58:06 --> Total execution time: 0.0186
ERROR - 2024-02-06 01:58:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:58:28 --> Config Class Initialized
INFO - 2024-02-06 01:58:28 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:58:28 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:58:28 --> Utf8 Class Initialized
INFO - 2024-02-06 01:58:28 --> URI Class Initialized
INFO - 2024-02-06 01:58:28 --> Router Class Initialized
INFO - 2024-02-06 01:58:28 --> Output Class Initialized
INFO - 2024-02-06 01:58:28 --> Security Class Initialized
DEBUG - 2024-02-06 01:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:58:28 --> Input Class Initialized
INFO - 2024-02-06 01:58:28 --> Language Class Initialized
INFO - 2024-02-06 01:58:28 --> Loader Class Initialized
INFO - 2024-02-06 01:58:28 --> Helper loaded: url_helper
INFO - 2024-02-06 01:58:28 --> Helper loaded: file_helper
INFO - 2024-02-06 01:58:28 --> Helper loaded: html_helper
INFO - 2024-02-06 01:58:28 --> Helper loaded: text_helper
INFO - 2024-02-06 01:58:28 --> Helper loaded: form_helper
INFO - 2024-02-06 01:58:28 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:58:28 --> Helper loaded: security_helper
INFO - 2024-02-06 01:58:28 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:58:28 --> Database Driver Class Initialized
INFO - 2024-02-06 01:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:58:28 --> Parser Class Initialized
INFO - 2024-02-06 01:58:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:58:28 --> Pagination Class Initialized
INFO - 2024-02-06 01:58:28 --> Form Validation Class Initialized
INFO - 2024-02-06 01:58:28 --> Controller Class Initialized
INFO - 2024-02-06 01:58:28 --> Model Class Initialized
DEBUG - 2024-02-06 01:58:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:58:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:58:28 --> Model Class Initialized
DEBUG - 2024-02-06 01:58:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:58:28 --> Model Class Initialized
INFO - 2024-02-06 01:58:28 --> Final output sent to browser
DEBUG - 2024-02-06 01:58:28 --> Total execution time: 0.1007
ERROR - 2024-02-06 01:59:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:59:00 --> Config Class Initialized
INFO - 2024-02-06 01:59:00 --> Hooks Class Initialized
ERROR - 2024-02-06 01:59:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
DEBUG - 2024-02-06 01:59:00 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:59:00 --> Utf8 Class Initialized
INFO - 2024-02-06 01:59:00 --> Config Class Initialized
INFO - 2024-02-06 01:59:00 --> Hooks Class Initialized
INFO - 2024-02-06 01:59:00 --> URI Class Initialized
INFO - 2024-02-06 01:59:00 --> Router Class Initialized
DEBUG - 2024-02-06 01:59:00 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:59:00 --> Utf8 Class Initialized
INFO - 2024-02-06 01:59:00 --> Output Class Initialized
INFO - 2024-02-06 01:59:00 --> URI Class Initialized
INFO - 2024-02-06 01:59:00 --> Security Class Initialized
INFO - 2024-02-06 01:59:00 --> Router Class Initialized
DEBUG - 2024-02-06 01:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:59:00 --> Input Class Initialized
INFO - 2024-02-06 01:59:00 --> Language Class Initialized
INFO - 2024-02-06 01:59:00 --> Output Class Initialized
INFO - 2024-02-06 01:59:00 --> Security Class Initialized
DEBUG - 2024-02-06 01:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:59:00 --> Input Class Initialized
INFO - 2024-02-06 01:59:00 --> Language Class Initialized
INFO - 2024-02-06 01:59:00 --> Loader Class Initialized
INFO - 2024-02-06 01:59:00 --> Helper loaded: url_helper
INFO - 2024-02-06 01:59:00 --> Helper loaded: file_helper
INFO - 2024-02-06 01:59:00 --> Helper loaded: html_helper
INFO - 2024-02-06 01:59:00 --> Helper loaded: text_helper
INFO - 2024-02-06 01:59:00 --> Loader Class Initialized
INFO - 2024-02-06 01:59:00 --> Helper loaded: url_helper
INFO - 2024-02-06 01:59:00 --> Helper loaded: form_helper
INFO - 2024-02-06 01:59:00 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:59:00 --> Helper loaded: security_helper
INFO - 2024-02-06 01:59:00 --> Helper loaded: file_helper
INFO - 2024-02-06 01:59:00 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:59:00 --> Helper loaded: html_helper
INFO - 2024-02-06 01:59:00 --> Helper loaded: text_helper
INFO - 2024-02-06 01:59:00 --> Helper loaded: form_helper
INFO - 2024-02-06 01:59:00 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:59:00 --> Helper loaded: security_helper
INFO - 2024-02-06 01:59:00 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:59:00 --> Database Driver Class Initialized
INFO - 2024-02-06 01:59:00 --> Database Driver Class Initialized
INFO - 2024-02-06 01:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:59:00 --> Parser Class Initialized
INFO - 2024-02-06 01:59:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:59:00 --> Pagination Class Initialized
INFO - 2024-02-06 01:59:00 --> Form Validation Class Initialized
INFO - 2024-02-06 01:59:00 --> Controller Class Initialized
INFO - 2024-02-06 01:59:00 --> Model Class Initialized
DEBUG - 2024-02-06 01:59:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:59:00 --> Model Class Initialized
DEBUG - 2024-02-06 01:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:59:00 --> Model Class Initialized
INFO - 2024-02-06 01:59:00 --> Final output sent to browser
DEBUG - 2024-02-06 01:59:00 --> Total execution time: 0.0953
INFO - 2024-02-06 01:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:59:00 --> Parser Class Initialized
INFO - 2024-02-06 01:59:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:59:00 --> Pagination Class Initialized
INFO - 2024-02-06 01:59:00 --> Form Validation Class Initialized
INFO - 2024-02-06 01:59:00 --> Controller Class Initialized
INFO - 2024-02-06 01:59:00 --> Model Class Initialized
DEBUG - 2024-02-06 01:59:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:59:00 --> Model Class Initialized
DEBUG - 2024-02-06 01:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:59:00 --> Model Class Initialized
INFO - 2024-02-06 01:59:00 --> Final output sent to browser
DEBUG - 2024-02-06 01:59:00 --> Total execution time: 0.1778
ERROR - 2024-02-06 01:59:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:59:09 --> Config Class Initialized
INFO - 2024-02-06 01:59:09 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:59:09 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:59:09 --> Utf8 Class Initialized
INFO - 2024-02-06 01:59:09 --> URI Class Initialized
INFO - 2024-02-06 01:59:09 --> Router Class Initialized
INFO - 2024-02-06 01:59:09 --> Output Class Initialized
INFO - 2024-02-06 01:59:09 --> Security Class Initialized
DEBUG - 2024-02-06 01:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:59:09 --> Input Class Initialized
INFO - 2024-02-06 01:59:09 --> Language Class Initialized
INFO - 2024-02-06 01:59:09 --> Loader Class Initialized
INFO - 2024-02-06 01:59:09 --> Helper loaded: url_helper
INFO - 2024-02-06 01:59:09 --> Helper loaded: file_helper
INFO - 2024-02-06 01:59:09 --> Helper loaded: html_helper
INFO - 2024-02-06 01:59:09 --> Helper loaded: text_helper
INFO - 2024-02-06 01:59:09 --> Helper loaded: form_helper
INFO - 2024-02-06 01:59:09 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:59:09 --> Helper loaded: security_helper
INFO - 2024-02-06 01:59:09 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:59:09 --> Database Driver Class Initialized
INFO - 2024-02-06 01:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:59:09 --> Parser Class Initialized
INFO - 2024-02-06 01:59:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:59:09 --> Pagination Class Initialized
INFO - 2024-02-06 01:59:09 --> Form Validation Class Initialized
INFO - 2024-02-06 01:59:09 --> Controller Class Initialized
INFO - 2024-02-06 01:59:09 --> Model Class Initialized
DEBUG - 2024-02-06 01:59:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:59:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:59:09 --> Model Class Initialized
DEBUG - 2024-02-06 01:59:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:59:09 --> Model Class Initialized
INFO - 2024-02-06 01:59:09 --> Final output sent to browser
DEBUG - 2024-02-06 01:59:09 --> Total execution time: 0.0187
ERROR - 2024-02-06 01:59:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 01:59:12 --> Config Class Initialized
INFO - 2024-02-06 01:59:12 --> Hooks Class Initialized
DEBUG - 2024-02-06 01:59:12 --> UTF-8 Support Enabled
INFO - 2024-02-06 01:59:12 --> Utf8 Class Initialized
INFO - 2024-02-06 01:59:12 --> URI Class Initialized
INFO - 2024-02-06 01:59:12 --> Router Class Initialized
INFO - 2024-02-06 01:59:12 --> Output Class Initialized
INFO - 2024-02-06 01:59:12 --> Security Class Initialized
DEBUG - 2024-02-06 01:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 01:59:12 --> Input Class Initialized
INFO - 2024-02-06 01:59:12 --> Language Class Initialized
INFO - 2024-02-06 01:59:12 --> Loader Class Initialized
INFO - 2024-02-06 01:59:12 --> Helper loaded: url_helper
INFO - 2024-02-06 01:59:12 --> Helper loaded: file_helper
INFO - 2024-02-06 01:59:12 --> Helper loaded: html_helper
INFO - 2024-02-06 01:59:12 --> Helper loaded: text_helper
INFO - 2024-02-06 01:59:12 --> Helper loaded: form_helper
INFO - 2024-02-06 01:59:12 --> Helper loaded: lang_helper
INFO - 2024-02-06 01:59:12 --> Helper loaded: security_helper
INFO - 2024-02-06 01:59:12 --> Helper loaded: cookie_helper
INFO - 2024-02-06 01:59:12 --> Database Driver Class Initialized
INFO - 2024-02-06 01:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 01:59:12 --> Parser Class Initialized
INFO - 2024-02-06 01:59:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 01:59:12 --> Pagination Class Initialized
INFO - 2024-02-06 01:59:12 --> Form Validation Class Initialized
INFO - 2024-02-06 01:59:12 --> Controller Class Initialized
INFO - 2024-02-06 01:59:12 --> Model Class Initialized
DEBUG - 2024-02-06 01:59:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 01:59:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:59:12 --> Model Class Initialized
DEBUG - 2024-02-06 01:59:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 01:59:12 --> Model Class Initialized
INFO - 2024-02-06 01:59:12 --> Final output sent to browser
DEBUG - 2024-02-06 01:59:12 --> Total execution time: 0.0926
ERROR - 2024-02-06 02:00:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 02:00:43 --> Config Class Initialized
INFO - 2024-02-06 02:00:43 --> Hooks Class Initialized
DEBUG - 2024-02-06 02:00:43 --> UTF-8 Support Enabled
INFO - 2024-02-06 02:00:43 --> Utf8 Class Initialized
INFO - 2024-02-06 02:00:43 --> URI Class Initialized
INFO - 2024-02-06 02:00:43 --> Router Class Initialized
INFO - 2024-02-06 02:00:43 --> Output Class Initialized
INFO - 2024-02-06 02:00:43 --> Security Class Initialized
DEBUG - 2024-02-06 02:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 02:00:43 --> Input Class Initialized
INFO - 2024-02-06 02:00:43 --> Language Class Initialized
INFO - 2024-02-06 02:00:43 --> Loader Class Initialized
INFO - 2024-02-06 02:00:43 --> Helper loaded: url_helper
INFO - 2024-02-06 02:00:43 --> Helper loaded: file_helper
INFO - 2024-02-06 02:00:43 --> Helper loaded: html_helper
INFO - 2024-02-06 02:00:43 --> Helper loaded: text_helper
INFO - 2024-02-06 02:00:43 --> Helper loaded: form_helper
INFO - 2024-02-06 02:00:43 --> Helper loaded: lang_helper
INFO - 2024-02-06 02:00:43 --> Helper loaded: security_helper
INFO - 2024-02-06 02:00:43 --> Helper loaded: cookie_helper
INFO - 2024-02-06 02:00:43 --> Database Driver Class Initialized
INFO - 2024-02-06 02:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 02:00:43 --> Parser Class Initialized
INFO - 2024-02-06 02:00:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 02:00:43 --> Pagination Class Initialized
INFO - 2024-02-06 02:00:43 --> Form Validation Class Initialized
INFO - 2024-02-06 02:00:43 --> Controller Class Initialized
INFO - 2024-02-06 02:00:43 --> Model Class Initialized
DEBUG - 2024-02-06 02:00:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 02:00:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:00:43 --> Model Class Initialized
DEBUG - 2024-02-06 02:00:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:00:43 --> Model Class Initialized
INFO - 2024-02-06 02:00:43 --> Final output sent to browser
DEBUG - 2024-02-06 02:00:43 --> Total execution time: 0.0401
ERROR - 2024-02-06 02:00:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 02:00:45 --> Config Class Initialized
INFO - 2024-02-06 02:00:45 --> Hooks Class Initialized
DEBUG - 2024-02-06 02:00:45 --> UTF-8 Support Enabled
INFO - 2024-02-06 02:00:45 --> Utf8 Class Initialized
INFO - 2024-02-06 02:00:45 --> URI Class Initialized
INFO - 2024-02-06 02:00:45 --> Router Class Initialized
INFO - 2024-02-06 02:00:45 --> Output Class Initialized
INFO - 2024-02-06 02:00:45 --> Security Class Initialized
DEBUG - 2024-02-06 02:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 02:00:45 --> Input Class Initialized
INFO - 2024-02-06 02:00:45 --> Language Class Initialized
INFO - 2024-02-06 02:00:45 --> Loader Class Initialized
INFO - 2024-02-06 02:00:45 --> Helper loaded: url_helper
INFO - 2024-02-06 02:00:45 --> Helper loaded: file_helper
INFO - 2024-02-06 02:00:45 --> Helper loaded: html_helper
INFO - 2024-02-06 02:00:45 --> Helper loaded: text_helper
INFO - 2024-02-06 02:00:45 --> Helper loaded: form_helper
INFO - 2024-02-06 02:00:45 --> Helper loaded: lang_helper
INFO - 2024-02-06 02:00:45 --> Helper loaded: security_helper
INFO - 2024-02-06 02:00:45 --> Helper loaded: cookie_helper
INFO - 2024-02-06 02:00:45 --> Database Driver Class Initialized
INFO - 2024-02-06 02:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 02:00:45 --> Parser Class Initialized
INFO - 2024-02-06 02:00:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 02:00:45 --> Pagination Class Initialized
INFO - 2024-02-06 02:00:45 --> Form Validation Class Initialized
INFO - 2024-02-06 02:00:45 --> Controller Class Initialized
INFO - 2024-02-06 02:00:45 --> Model Class Initialized
DEBUG - 2024-02-06 02:00:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 02:00:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:00:45 --> Model Class Initialized
DEBUG - 2024-02-06 02:00:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:00:45 --> Model Class Initialized
INFO - 2024-02-06 02:00:45 --> Final output sent to browser
DEBUG - 2024-02-06 02:00:45 --> Total execution time: 0.0192
ERROR - 2024-02-06 02:01:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 02:01:01 --> Config Class Initialized
INFO - 2024-02-06 02:01:01 --> Hooks Class Initialized
DEBUG - 2024-02-06 02:01:01 --> UTF-8 Support Enabled
INFO - 2024-02-06 02:01:01 --> Utf8 Class Initialized
INFO - 2024-02-06 02:01:01 --> URI Class Initialized
INFO - 2024-02-06 02:01:01 --> Router Class Initialized
INFO - 2024-02-06 02:01:01 --> Output Class Initialized
INFO - 2024-02-06 02:01:01 --> Security Class Initialized
DEBUG - 2024-02-06 02:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 02:01:01 --> Input Class Initialized
INFO - 2024-02-06 02:01:01 --> Language Class Initialized
INFO - 2024-02-06 02:01:01 --> Loader Class Initialized
INFO - 2024-02-06 02:01:01 --> Helper loaded: url_helper
INFO - 2024-02-06 02:01:01 --> Helper loaded: file_helper
INFO - 2024-02-06 02:01:01 --> Helper loaded: html_helper
INFO - 2024-02-06 02:01:01 --> Helper loaded: text_helper
INFO - 2024-02-06 02:01:01 --> Helper loaded: form_helper
INFO - 2024-02-06 02:01:01 --> Helper loaded: lang_helper
INFO - 2024-02-06 02:01:01 --> Helper loaded: security_helper
INFO - 2024-02-06 02:01:01 --> Helper loaded: cookie_helper
INFO - 2024-02-06 02:01:01 --> Database Driver Class Initialized
INFO - 2024-02-06 02:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 02:01:01 --> Parser Class Initialized
INFO - 2024-02-06 02:01:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 02:01:01 --> Pagination Class Initialized
INFO - 2024-02-06 02:01:01 --> Form Validation Class Initialized
INFO - 2024-02-06 02:01:01 --> Controller Class Initialized
INFO - 2024-02-06 02:01:01 --> Model Class Initialized
DEBUG - 2024-02-06 02:01:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 02:01:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:01:01 --> Model Class Initialized
DEBUG - 2024-02-06 02:01:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:01:01 --> Model Class Initialized
INFO - 2024-02-06 02:01:01 --> Final output sent to browser
DEBUG - 2024-02-06 02:01:01 --> Total execution time: 0.1017
ERROR - 2024-02-06 02:01:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 02:01:09 --> Config Class Initialized
INFO - 2024-02-06 02:01:09 --> Hooks Class Initialized
DEBUG - 2024-02-06 02:01:09 --> UTF-8 Support Enabled
INFO - 2024-02-06 02:01:09 --> Utf8 Class Initialized
INFO - 2024-02-06 02:01:09 --> URI Class Initialized
INFO - 2024-02-06 02:01:09 --> Router Class Initialized
INFO - 2024-02-06 02:01:09 --> Output Class Initialized
INFO - 2024-02-06 02:01:09 --> Security Class Initialized
DEBUG - 2024-02-06 02:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 02:01:09 --> Input Class Initialized
INFO - 2024-02-06 02:01:09 --> Language Class Initialized
INFO - 2024-02-06 02:01:09 --> Loader Class Initialized
INFO - 2024-02-06 02:01:09 --> Helper loaded: url_helper
INFO - 2024-02-06 02:01:09 --> Helper loaded: file_helper
INFO - 2024-02-06 02:01:09 --> Helper loaded: html_helper
INFO - 2024-02-06 02:01:09 --> Helper loaded: text_helper
INFO - 2024-02-06 02:01:09 --> Helper loaded: form_helper
INFO - 2024-02-06 02:01:09 --> Helper loaded: lang_helper
INFO - 2024-02-06 02:01:09 --> Helper loaded: security_helper
INFO - 2024-02-06 02:01:09 --> Helper loaded: cookie_helper
INFO - 2024-02-06 02:01:09 --> Database Driver Class Initialized
INFO - 2024-02-06 02:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 02:01:09 --> Parser Class Initialized
INFO - 2024-02-06 02:01:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 02:01:09 --> Pagination Class Initialized
INFO - 2024-02-06 02:01:09 --> Form Validation Class Initialized
INFO - 2024-02-06 02:01:09 --> Controller Class Initialized
INFO - 2024-02-06 02:01:09 --> Model Class Initialized
DEBUG - 2024-02-06 02:01:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 02:01:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:01:09 --> Model Class Initialized
DEBUG - 2024-02-06 02:01:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:01:09 --> Model Class Initialized
INFO - 2024-02-06 02:01:09 --> Final output sent to browser
DEBUG - 2024-02-06 02:01:09 --> Total execution time: 0.0209
ERROR - 2024-02-06 02:01:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 02:01:13 --> Config Class Initialized
INFO - 2024-02-06 02:01:13 --> Hooks Class Initialized
DEBUG - 2024-02-06 02:01:13 --> UTF-8 Support Enabled
INFO - 2024-02-06 02:01:13 --> Utf8 Class Initialized
INFO - 2024-02-06 02:01:13 --> URI Class Initialized
INFO - 2024-02-06 02:01:13 --> Router Class Initialized
INFO - 2024-02-06 02:01:13 --> Output Class Initialized
INFO - 2024-02-06 02:01:13 --> Security Class Initialized
DEBUG - 2024-02-06 02:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 02:01:13 --> Input Class Initialized
INFO - 2024-02-06 02:01:13 --> Language Class Initialized
INFO - 2024-02-06 02:01:13 --> Loader Class Initialized
INFO - 2024-02-06 02:01:13 --> Helper loaded: url_helper
INFO - 2024-02-06 02:01:13 --> Helper loaded: file_helper
INFO - 2024-02-06 02:01:13 --> Helper loaded: html_helper
INFO - 2024-02-06 02:01:13 --> Helper loaded: text_helper
INFO - 2024-02-06 02:01:13 --> Helper loaded: form_helper
INFO - 2024-02-06 02:01:13 --> Helper loaded: lang_helper
INFO - 2024-02-06 02:01:13 --> Helper loaded: security_helper
INFO - 2024-02-06 02:01:13 --> Helper loaded: cookie_helper
INFO - 2024-02-06 02:01:13 --> Database Driver Class Initialized
INFO - 2024-02-06 02:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 02:01:13 --> Parser Class Initialized
INFO - 2024-02-06 02:01:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 02:01:13 --> Pagination Class Initialized
INFO - 2024-02-06 02:01:13 --> Form Validation Class Initialized
INFO - 2024-02-06 02:01:13 --> Controller Class Initialized
INFO - 2024-02-06 02:01:13 --> Model Class Initialized
DEBUG - 2024-02-06 02:01:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 02:01:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:01:13 --> Model Class Initialized
DEBUG - 2024-02-06 02:01:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:01:13 --> Model Class Initialized
INFO - 2024-02-06 02:01:13 --> Final output sent to browser
DEBUG - 2024-02-06 02:01:13 --> Total execution time: 0.0207
ERROR - 2024-02-06 02:01:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 02:01:20 --> Config Class Initialized
INFO - 2024-02-06 02:01:20 --> Hooks Class Initialized
DEBUG - 2024-02-06 02:01:20 --> UTF-8 Support Enabled
INFO - 2024-02-06 02:01:20 --> Utf8 Class Initialized
INFO - 2024-02-06 02:01:20 --> URI Class Initialized
INFO - 2024-02-06 02:01:20 --> Router Class Initialized
INFO - 2024-02-06 02:01:20 --> Output Class Initialized
INFO - 2024-02-06 02:01:20 --> Security Class Initialized
DEBUG - 2024-02-06 02:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 02:01:20 --> Input Class Initialized
INFO - 2024-02-06 02:01:20 --> Language Class Initialized
INFO - 2024-02-06 02:01:20 --> Loader Class Initialized
INFO - 2024-02-06 02:01:20 --> Helper loaded: url_helper
INFO - 2024-02-06 02:01:20 --> Helper loaded: file_helper
INFO - 2024-02-06 02:01:20 --> Helper loaded: html_helper
INFO - 2024-02-06 02:01:20 --> Helper loaded: text_helper
INFO - 2024-02-06 02:01:20 --> Helper loaded: form_helper
INFO - 2024-02-06 02:01:20 --> Helper loaded: lang_helper
INFO - 2024-02-06 02:01:20 --> Helper loaded: security_helper
INFO - 2024-02-06 02:01:20 --> Helper loaded: cookie_helper
INFO - 2024-02-06 02:01:20 --> Database Driver Class Initialized
INFO - 2024-02-06 02:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 02:01:20 --> Parser Class Initialized
INFO - 2024-02-06 02:01:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 02:01:20 --> Pagination Class Initialized
INFO - 2024-02-06 02:01:20 --> Form Validation Class Initialized
INFO - 2024-02-06 02:01:20 --> Controller Class Initialized
INFO - 2024-02-06 02:01:20 --> Model Class Initialized
DEBUG - 2024-02-06 02:01:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 02:01:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:01:20 --> Model Class Initialized
DEBUG - 2024-02-06 02:01:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:01:20 --> Model Class Initialized
INFO - 2024-02-06 02:01:20 --> Final output sent to browser
DEBUG - 2024-02-06 02:01:20 --> Total execution time: 0.0209
ERROR - 2024-02-06 02:01:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 02:01:22 --> Config Class Initialized
INFO - 2024-02-06 02:01:22 --> Hooks Class Initialized
DEBUG - 2024-02-06 02:01:22 --> UTF-8 Support Enabled
INFO - 2024-02-06 02:01:22 --> Utf8 Class Initialized
INFO - 2024-02-06 02:01:22 --> URI Class Initialized
INFO - 2024-02-06 02:01:22 --> Router Class Initialized
INFO - 2024-02-06 02:01:22 --> Output Class Initialized
INFO - 2024-02-06 02:01:22 --> Security Class Initialized
DEBUG - 2024-02-06 02:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 02:01:22 --> Input Class Initialized
INFO - 2024-02-06 02:01:22 --> Language Class Initialized
INFO - 2024-02-06 02:01:22 --> Loader Class Initialized
INFO - 2024-02-06 02:01:22 --> Helper loaded: url_helper
INFO - 2024-02-06 02:01:22 --> Helper loaded: file_helper
INFO - 2024-02-06 02:01:22 --> Helper loaded: html_helper
INFO - 2024-02-06 02:01:22 --> Helper loaded: text_helper
INFO - 2024-02-06 02:01:22 --> Helper loaded: form_helper
INFO - 2024-02-06 02:01:22 --> Helper loaded: lang_helper
INFO - 2024-02-06 02:01:22 --> Helper loaded: security_helper
INFO - 2024-02-06 02:01:22 --> Helper loaded: cookie_helper
INFO - 2024-02-06 02:01:22 --> Database Driver Class Initialized
INFO - 2024-02-06 02:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 02:01:22 --> Parser Class Initialized
INFO - 2024-02-06 02:01:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 02:01:22 --> Pagination Class Initialized
INFO - 2024-02-06 02:01:22 --> Form Validation Class Initialized
INFO - 2024-02-06 02:01:22 --> Controller Class Initialized
INFO - 2024-02-06 02:01:22 --> Model Class Initialized
DEBUG - 2024-02-06 02:01:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 02:01:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:01:22 --> Model Class Initialized
DEBUG - 2024-02-06 02:01:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:01:22 --> Model Class Initialized
INFO - 2024-02-06 02:01:22 --> Final output sent to browser
DEBUG - 2024-02-06 02:01:22 --> Total execution time: 0.0897
ERROR - 2024-02-06 02:01:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 02:01:25 --> Config Class Initialized
INFO - 2024-02-06 02:01:25 --> Hooks Class Initialized
DEBUG - 2024-02-06 02:01:25 --> UTF-8 Support Enabled
INFO - 2024-02-06 02:01:25 --> Utf8 Class Initialized
INFO - 2024-02-06 02:01:25 --> URI Class Initialized
INFO - 2024-02-06 02:01:25 --> Router Class Initialized
INFO - 2024-02-06 02:01:25 --> Output Class Initialized
INFO - 2024-02-06 02:01:25 --> Security Class Initialized
DEBUG - 2024-02-06 02:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 02:01:25 --> Input Class Initialized
INFO - 2024-02-06 02:01:25 --> Language Class Initialized
INFO - 2024-02-06 02:01:25 --> Loader Class Initialized
INFO - 2024-02-06 02:01:25 --> Helper loaded: url_helper
INFO - 2024-02-06 02:01:25 --> Helper loaded: file_helper
INFO - 2024-02-06 02:01:25 --> Helper loaded: html_helper
INFO - 2024-02-06 02:01:25 --> Helper loaded: text_helper
INFO - 2024-02-06 02:01:25 --> Helper loaded: form_helper
INFO - 2024-02-06 02:01:25 --> Helper loaded: lang_helper
INFO - 2024-02-06 02:01:25 --> Helper loaded: security_helper
INFO - 2024-02-06 02:01:25 --> Helper loaded: cookie_helper
INFO - 2024-02-06 02:01:25 --> Database Driver Class Initialized
INFO - 2024-02-06 02:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 02:01:25 --> Parser Class Initialized
INFO - 2024-02-06 02:01:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 02:01:25 --> Pagination Class Initialized
INFO - 2024-02-06 02:01:25 --> Form Validation Class Initialized
INFO - 2024-02-06 02:01:25 --> Controller Class Initialized
INFO - 2024-02-06 02:01:25 --> Model Class Initialized
DEBUG - 2024-02-06 02:01:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 02:01:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:01:25 --> Model Class Initialized
DEBUG - 2024-02-06 02:01:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:01:25 --> Model Class Initialized
INFO - 2024-02-06 02:01:25 --> Final output sent to browser
DEBUG - 2024-02-06 02:01:25 --> Total execution time: 0.0208
ERROR - 2024-02-06 02:01:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 02:01:28 --> Config Class Initialized
INFO - 2024-02-06 02:01:28 --> Hooks Class Initialized
DEBUG - 2024-02-06 02:01:28 --> UTF-8 Support Enabled
INFO - 2024-02-06 02:01:28 --> Utf8 Class Initialized
INFO - 2024-02-06 02:01:28 --> URI Class Initialized
INFO - 2024-02-06 02:01:28 --> Router Class Initialized
INFO - 2024-02-06 02:01:28 --> Output Class Initialized
INFO - 2024-02-06 02:01:28 --> Security Class Initialized
DEBUG - 2024-02-06 02:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 02:01:28 --> Input Class Initialized
INFO - 2024-02-06 02:01:28 --> Language Class Initialized
INFO - 2024-02-06 02:01:28 --> Loader Class Initialized
INFO - 2024-02-06 02:01:28 --> Helper loaded: url_helper
INFO - 2024-02-06 02:01:28 --> Helper loaded: file_helper
INFO - 2024-02-06 02:01:28 --> Helper loaded: html_helper
INFO - 2024-02-06 02:01:28 --> Helper loaded: text_helper
INFO - 2024-02-06 02:01:28 --> Helper loaded: form_helper
INFO - 2024-02-06 02:01:28 --> Helper loaded: lang_helper
INFO - 2024-02-06 02:01:28 --> Helper loaded: security_helper
INFO - 2024-02-06 02:01:28 --> Helper loaded: cookie_helper
INFO - 2024-02-06 02:01:28 --> Database Driver Class Initialized
INFO - 2024-02-06 02:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 02:01:28 --> Parser Class Initialized
INFO - 2024-02-06 02:01:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 02:01:28 --> Pagination Class Initialized
INFO - 2024-02-06 02:01:28 --> Form Validation Class Initialized
INFO - 2024-02-06 02:01:28 --> Controller Class Initialized
INFO - 2024-02-06 02:01:28 --> Model Class Initialized
DEBUG - 2024-02-06 02:01:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 02:01:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:01:28 --> Model Class Initialized
DEBUG - 2024-02-06 02:01:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:01:28 --> Model Class Initialized
INFO - 2024-02-06 02:01:28 --> Final output sent to browser
DEBUG - 2024-02-06 02:01:28 --> Total execution time: 0.0202
ERROR - 2024-02-06 02:02:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 02:02:30 --> Config Class Initialized
INFO - 2024-02-06 02:02:30 --> Hooks Class Initialized
DEBUG - 2024-02-06 02:02:30 --> UTF-8 Support Enabled
INFO - 2024-02-06 02:02:30 --> Utf8 Class Initialized
INFO - 2024-02-06 02:02:30 --> URI Class Initialized
INFO - 2024-02-06 02:02:30 --> Router Class Initialized
INFO - 2024-02-06 02:02:30 --> Output Class Initialized
INFO - 2024-02-06 02:02:30 --> Security Class Initialized
DEBUG - 2024-02-06 02:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 02:02:30 --> Input Class Initialized
INFO - 2024-02-06 02:02:30 --> Language Class Initialized
INFO - 2024-02-06 02:02:30 --> Loader Class Initialized
INFO - 2024-02-06 02:02:30 --> Helper loaded: url_helper
INFO - 2024-02-06 02:02:30 --> Helper loaded: file_helper
INFO - 2024-02-06 02:02:30 --> Helper loaded: html_helper
INFO - 2024-02-06 02:02:30 --> Helper loaded: text_helper
INFO - 2024-02-06 02:02:30 --> Helper loaded: form_helper
INFO - 2024-02-06 02:02:30 --> Helper loaded: lang_helper
INFO - 2024-02-06 02:02:30 --> Helper loaded: security_helper
INFO - 2024-02-06 02:02:30 --> Helper loaded: cookie_helper
INFO - 2024-02-06 02:02:30 --> Database Driver Class Initialized
INFO - 2024-02-06 02:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 02:02:30 --> Parser Class Initialized
INFO - 2024-02-06 02:02:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 02:02:30 --> Pagination Class Initialized
INFO - 2024-02-06 02:02:30 --> Form Validation Class Initialized
INFO - 2024-02-06 02:02:30 --> Controller Class Initialized
INFO - 2024-02-06 02:02:30 --> Model Class Initialized
DEBUG - 2024-02-06 02:02:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 02:02:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:02:30 --> Model Class Initialized
DEBUG - 2024-02-06 02:02:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:02:30 --> Model Class Initialized
INFO - 2024-02-06 02:02:30 --> Final output sent to browser
DEBUG - 2024-02-06 02:02:30 --> Total execution time: 0.0925
ERROR - 2024-02-06 02:02:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 02:02:40 --> Config Class Initialized
INFO - 2024-02-06 02:02:40 --> Hooks Class Initialized
DEBUG - 2024-02-06 02:02:40 --> UTF-8 Support Enabled
INFO - 2024-02-06 02:02:40 --> Utf8 Class Initialized
INFO - 2024-02-06 02:02:40 --> URI Class Initialized
INFO - 2024-02-06 02:02:40 --> Router Class Initialized
INFO - 2024-02-06 02:02:40 --> Output Class Initialized
INFO - 2024-02-06 02:02:40 --> Security Class Initialized
DEBUG - 2024-02-06 02:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 02:02:40 --> Input Class Initialized
INFO - 2024-02-06 02:02:40 --> Language Class Initialized
INFO - 2024-02-06 02:02:40 --> Loader Class Initialized
INFO - 2024-02-06 02:02:40 --> Helper loaded: url_helper
INFO - 2024-02-06 02:02:40 --> Helper loaded: file_helper
INFO - 2024-02-06 02:02:40 --> Helper loaded: html_helper
INFO - 2024-02-06 02:02:40 --> Helper loaded: text_helper
INFO - 2024-02-06 02:02:40 --> Helper loaded: form_helper
INFO - 2024-02-06 02:02:40 --> Helper loaded: lang_helper
INFO - 2024-02-06 02:02:40 --> Helper loaded: security_helper
INFO - 2024-02-06 02:02:40 --> Helper loaded: cookie_helper
INFO - 2024-02-06 02:02:40 --> Database Driver Class Initialized
INFO - 2024-02-06 02:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 02:02:40 --> Parser Class Initialized
INFO - 2024-02-06 02:02:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 02:02:40 --> Pagination Class Initialized
INFO - 2024-02-06 02:02:40 --> Form Validation Class Initialized
INFO - 2024-02-06 02:02:40 --> Controller Class Initialized
INFO - 2024-02-06 02:02:40 --> Model Class Initialized
DEBUG - 2024-02-06 02:02:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 02:02:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:02:40 --> Model Class Initialized
DEBUG - 2024-02-06 02:02:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:02:40 --> Model Class Initialized
INFO - 2024-02-06 02:02:40 --> Final output sent to browser
DEBUG - 2024-02-06 02:02:40 --> Total execution time: 0.0897
ERROR - 2024-02-06 02:02:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 02:02:45 --> Config Class Initialized
INFO - 2024-02-06 02:02:45 --> Hooks Class Initialized
DEBUG - 2024-02-06 02:02:45 --> UTF-8 Support Enabled
INFO - 2024-02-06 02:02:45 --> Utf8 Class Initialized
INFO - 2024-02-06 02:02:45 --> URI Class Initialized
INFO - 2024-02-06 02:02:45 --> Router Class Initialized
INFO - 2024-02-06 02:02:45 --> Output Class Initialized
INFO - 2024-02-06 02:02:45 --> Security Class Initialized
DEBUG - 2024-02-06 02:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 02:02:45 --> Input Class Initialized
INFO - 2024-02-06 02:02:45 --> Language Class Initialized
INFO - 2024-02-06 02:02:45 --> Loader Class Initialized
INFO - 2024-02-06 02:02:45 --> Helper loaded: url_helper
INFO - 2024-02-06 02:02:45 --> Helper loaded: file_helper
INFO - 2024-02-06 02:02:45 --> Helper loaded: html_helper
INFO - 2024-02-06 02:02:45 --> Helper loaded: text_helper
INFO - 2024-02-06 02:02:45 --> Helper loaded: form_helper
INFO - 2024-02-06 02:02:45 --> Helper loaded: lang_helper
INFO - 2024-02-06 02:02:45 --> Helper loaded: security_helper
INFO - 2024-02-06 02:02:45 --> Helper loaded: cookie_helper
INFO - 2024-02-06 02:02:45 --> Database Driver Class Initialized
INFO - 2024-02-06 02:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 02:02:45 --> Parser Class Initialized
INFO - 2024-02-06 02:02:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 02:02:45 --> Pagination Class Initialized
INFO - 2024-02-06 02:02:45 --> Form Validation Class Initialized
INFO - 2024-02-06 02:02:45 --> Controller Class Initialized
INFO - 2024-02-06 02:02:45 --> Model Class Initialized
DEBUG - 2024-02-06 02:02:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 02:02:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:02:45 --> Model Class Initialized
DEBUG - 2024-02-06 02:02:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:02:45 --> Model Class Initialized
INFO - 2024-02-06 02:02:45 --> Final output sent to browser
DEBUG - 2024-02-06 02:02:45 --> Total execution time: 0.0915
ERROR - 2024-02-06 02:02:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 02:02:51 --> Config Class Initialized
INFO - 2024-02-06 02:02:51 --> Hooks Class Initialized
DEBUG - 2024-02-06 02:02:51 --> UTF-8 Support Enabled
INFO - 2024-02-06 02:02:51 --> Utf8 Class Initialized
INFO - 2024-02-06 02:02:51 --> URI Class Initialized
INFO - 2024-02-06 02:02:51 --> Router Class Initialized
INFO - 2024-02-06 02:02:51 --> Output Class Initialized
INFO - 2024-02-06 02:02:51 --> Security Class Initialized
DEBUG - 2024-02-06 02:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 02:02:51 --> Input Class Initialized
INFO - 2024-02-06 02:02:51 --> Language Class Initialized
INFO - 2024-02-06 02:02:51 --> Loader Class Initialized
INFO - 2024-02-06 02:02:51 --> Helper loaded: url_helper
INFO - 2024-02-06 02:02:51 --> Helper loaded: file_helper
INFO - 2024-02-06 02:02:51 --> Helper loaded: html_helper
INFO - 2024-02-06 02:02:51 --> Helper loaded: text_helper
INFO - 2024-02-06 02:02:51 --> Helper loaded: form_helper
INFO - 2024-02-06 02:02:51 --> Helper loaded: lang_helper
INFO - 2024-02-06 02:02:51 --> Helper loaded: security_helper
INFO - 2024-02-06 02:02:51 --> Helper loaded: cookie_helper
INFO - 2024-02-06 02:02:51 --> Database Driver Class Initialized
INFO - 2024-02-06 02:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 02:02:51 --> Parser Class Initialized
INFO - 2024-02-06 02:02:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 02:02:51 --> Pagination Class Initialized
INFO - 2024-02-06 02:02:51 --> Form Validation Class Initialized
INFO - 2024-02-06 02:02:51 --> Controller Class Initialized
INFO - 2024-02-06 02:02:51 --> Model Class Initialized
DEBUG - 2024-02-06 02:02:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 02:02:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:02:51 --> Model Class Initialized
DEBUG - 2024-02-06 02:02:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:02:51 --> Model Class Initialized
INFO - 2024-02-06 02:02:51 --> Final output sent to browser
DEBUG - 2024-02-06 02:02:51 --> Total execution time: 0.0208
ERROR - 2024-02-06 02:02:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 02:02:53 --> Config Class Initialized
INFO - 2024-02-06 02:02:53 --> Hooks Class Initialized
DEBUG - 2024-02-06 02:02:53 --> UTF-8 Support Enabled
INFO - 2024-02-06 02:02:53 --> Utf8 Class Initialized
INFO - 2024-02-06 02:02:53 --> URI Class Initialized
INFO - 2024-02-06 02:02:53 --> Router Class Initialized
INFO - 2024-02-06 02:02:53 --> Output Class Initialized
INFO - 2024-02-06 02:02:53 --> Security Class Initialized
DEBUG - 2024-02-06 02:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 02:02:53 --> Input Class Initialized
INFO - 2024-02-06 02:02:53 --> Language Class Initialized
INFO - 2024-02-06 02:02:53 --> Loader Class Initialized
INFO - 2024-02-06 02:02:53 --> Helper loaded: url_helper
INFO - 2024-02-06 02:02:53 --> Helper loaded: file_helper
INFO - 2024-02-06 02:02:53 --> Helper loaded: html_helper
INFO - 2024-02-06 02:02:53 --> Helper loaded: text_helper
INFO - 2024-02-06 02:02:53 --> Helper loaded: form_helper
INFO - 2024-02-06 02:02:53 --> Helper loaded: lang_helper
INFO - 2024-02-06 02:02:53 --> Helper loaded: security_helper
INFO - 2024-02-06 02:02:53 --> Helper loaded: cookie_helper
INFO - 2024-02-06 02:02:53 --> Database Driver Class Initialized
INFO - 2024-02-06 02:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 02:02:53 --> Parser Class Initialized
INFO - 2024-02-06 02:02:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 02:02:53 --> Pagination Class Initialized
INFO - 2024-02-06 02:02:53 --> Form Validation Class Initialized
INFO - 2024-02-06 02:02:53 --> Controller Class Initialized
INFO - 2024-02-06 02:02:53 --> Model Class Initialized
DEBUG - 2024-02-06 02:02:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 02:02:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:02:53 --> Model Class Initialized
INFO - 2024-02-06 02:02:53 --> Model Class Initialized
INFO - 2024-02-06 02:02:53 --> Final output sent to browser
DEBUG - 2024-02-06 02:02:53 --> Total execution time: 0.0197
ERROR - 2024-02-06 02:02:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 02:02:56 --> Config Class Initialized
INFO - 2024-02-06 02:02:56 --> Hooks Class Initialized
DEBUG - 2024-02-06 02:02:56 --> UTF-8 Support Enabled
INFO - 2024-02-06 02:02:56 --> Utf8 Class Initialized
INFO - 2024-02-06 02:02:56 --> URI Class Initialized
INFO - 2024-02-06 02:02:56 --> Router Class Initialized
INFO - 2024-02-06 02:02:56 --> Output Class Initialized
INFO - 2024-02-06 02:02:56 --> Security Class Initialized
DEBUG - 2024-02-06 02:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 02:02:56 --> Input Class Initialized
INFO - 2024-02-06 02:02:56 --> Language Class Initialized
INFO - 2024-02-06 02:02:56 --> Loader Class Initialized
INFO - 2024-02-06 02:02:56 --> Helper loaded: url_helper
INFO - 2024-02-06 02:02:56 --> Helper loaded: file_helper
INFO - 2024-02-06 02:02:56 --> Helper loaded: html_helper
INFO - 2024-02-06 02:02:56 --> Helper loaded: text_helper
INFO - 2024-02-06 02:02:56 --> Helper loaded: form_helper
INFO - 2024-02-06 02:02:56 --> Helper loaded: lang_helper
INFO - 2024-02-06 02:02:56 --> Helper loaded: security_helper
INFO - 2024-02-06 02:02:56 --> Helper loaded: cookie_helper
INFO - 2024-02-06 02:02:56 --> Database Driver Class Initialized
INFO - 2024-02-06 02:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 02:02:56 --> Parser Class Initialized
INFO - 2024-02-06 02:02:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 02:02:56 --> Pagination Class Initialized
INFO - 2024-02-06 02:02:56 --> Form Validation Class Initialized
INFO - 2024-02-06 02:02:56 --> Controller Class Initialized
INFO - 2024-02-06 02:02:56 --> Model Class Initialized
DEBUG - 2024-02-06 02:02:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 02:02:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:02:56 --> Model Class Initialized
INFO - 2024-02-06 02:02:56 --> Final output sent to browser
DEBUG - 2024-02-06 02:02:56 --> Total execution time: 0.0176
ERROR - 2024-02-06 02:03:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 02:03:14 --> Config Class Initialized
INFO - 2024-02-06 02:03:14 --> Hooks Class Initialized
DEBUG - 2024-02-06 02:03:14 --> UTF-8 Support Enabled
INFO - 2024-02-06 02:03:14 --> Utf8 Class Initialized
INFO - 2024-02-06 02:03:14 --> URI Class Initialized
INFO - 2024-02-06 02:03:14 --> Router Class Initialized
INFO - 2024-02-06 02:03:14 --> Output Class Initialized
INFO - 2024-02-06 02:03:14 --> Security Class Initialized
DEBUG - 2024-02-06 02:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 02:03:14 --> Input Class Initialized
INFO - 2024-02-06 02:03:14 --> Language Class Initialized
INFO - 2024-02-06 02:03:14 --> Loader Class Initialized
INFO - 2024-02-06 02:03:14 --> Helper loaded: url_helper
INFO - 2024-02-06 02:03:14 --> Helper loaded: file_helper
INFO - 2024-02-06 02:03:14 --> Helper loaded: html_helper
INFO - 2024-02-06 02:03:14 --> Helper loaded: text_helper
INFO - 2024-02-06 02:03:14 --> Helper loaded: form_helper
INFO - 2024-02-06 02:03:14 --> Helper loaded: lang_helper
INFO - 2024-02-06 02:03:14 --> Helper loaded: security_helper
INFO - 2024-02-06 02:03:14 --> Helper loaded: cookie_helper
INFO - 2024-02-06 02:03:14 --> Database Driver Class Initialized
INFO - 2024-02-06 02:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 02:03:14 --> Parser Class Initialized
INFO - 2024-02-06 02:03:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 02:03:14 --> Pagination Class Initialized
INFO - 2024-02-06 02:03:14 --> Form Validation Class Initialized
INFO - 2024-02-06 02:03:14 --> Controller Class Initialized
INFO - 2024-02-06 02:03:14 --> Model Class Initialized
DEBUG - 2024-02-06 02:03:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 02:03:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:03:14 --> Model Class Initialized
DEBUG - 2024-02-06 02:03:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:03:14 --> Model Class Initialized
INFO - 2024-02-06 02:03:14 --> Email Class Initialized
DEBUG - 2024-02-06 02:03:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:03:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 02:03:14 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-02-06 02:03:14 --> Language file loaded: language/english/email_lang.php
INFO - 2024-02-06 02:03:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-02-06 02:03:14 --> Final output sent to browser
DEBUG - 2024-02-06 02:03:14 --> Total execution time: 0.5291
ERROR - 2024-02-06 02:03:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 02:03:20 --> Config Class Initialized
INFO - 2024-02-06 02:03:20 --> Hooks Class Initialized
DEBUG - 2024-02-06 02:03:20 --> UTF-8 Support Enabled
INFO - 2024-02-06 02:03:20 --> Utf8 Class Initialized
INFO - 2024-02-06 02:03:20 --> URI Class Initialized
DEBUG - 2024-02-06 02:03:20 --> No URI present. Default controller set.
INFO - 2024-02-06 02:03:20 --> Router Class Initialized
INFO - 2024-02-06 02:03:20 --> Output Class Initialized
INFO - 2024-02-06 02:03:20 --> Security Class Initialized
DEBUG - 2024-02-06 02:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 02:03:20 --> Input Class Initialized
INFO - 2024-02-06 02:03:20 --> Language Class Initialized
INFO - 2024-02-06 02:03:20 --> Loader Class Initialized
INFO - 2024-02-06 02:03:20 --> Helper loaded: url_helper
INFO - 2024-02-06 02:03:20 --> Helper loaded: file_helper
INFO - 2024-02-06 02:03:20 --> Helper loaded: html_helper
INFO - 2024-02-06 02:03:20 --> Helper loaded: text_helper
INFO - 2024-02-06 02:03:20 --> Helper loaded: form_helper
INFO - 2024-02-06 02:03:20 --> Helper loaded: lang_helper
INFO - 2024-02-06 02:03:20 --> Helper loaded: security_helper
INFO - 2024-02-06 02:03:20 --> Helper loaded: cookie_helper
INFO - 2024-02-06 02:03:20 --> Database Driver Class Initialized
INFO - 2024-02-06 02:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 02:03:20 --> Parser Class Initialized
INFO - 2024-02-06 02:03:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 02:03:20 --> Pagination Class Initialized
INFO - 2024-02-06 02:03:20 --> Form Validation Class Initialized
INFO - 2024-02-06 02:03:20 --> Controller Class Initialized
INFO - 2024-02-06 02:03:20 --> Model Class Initialized
DEBUG - 2024-02-06 02:03:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:03:20 --> Model Class Initialized
DEBUG - 2024-02-06 02:03:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:03:20 --> Model Class Initialized
INFO - 2024-02-06 02:03:20 --> Model Class Initialized
INFO - 2024-02-06 02:03:20 --> Model Class Initialized
INFO - 2024-02-06 02:03:20 --> Model Class Initialized
DEBUG - 2024-02-06 02:03:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 02:03:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:03:20 --> Model Class Initialized
INFO - 2024-02-06 02:03:20 --> Model Class Initialized
INFO - 2024-02-06 02:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 02:03:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 02:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 02:03:20 --> Model Class Initialized
INFO - 2024-02-06 02:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 02:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 02:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 02:03:20 --> Final output sent to browser
DEBUG - 2024-02-06 02:03:20 --> Total execution time: 0.2318
ERROR - 2024-02-06 02:03:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 02:03:20 --> Config Class Initialized
INFO - 2024-02-06 02:03:20 --> Hooks Class Initialized
DEBUG - 2024-02-06 02:03:20 --> UTF-8 Support Enabled
INFO - 2024-02-06 02:03:20 --> Utf8 Class Initialized
INFO - 2024-02-06 02:03:20 --> URI Class Initialized
INFO - 2024-02-06 02:03:20 --> Router Class Initialized
INFO - 2024-02-06 02:03:20 --> Output Class Initialized
INFO - 2024-02-06 02:03:20 --> Security Class Initialized
DEBUG - 2024-02-06 02:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 02:03:20 --> Input Class Initialized
INFO - 2024-02-06 02:03:20 --> Language Class Initialized
INFO - 2024-02-06 02:03:20 --> Loader Class Initialized
INFO - 2024-02-06 02:03:20 --> Helper loaded: url_helper
INFO - 2024-02-06 02:03:20 --> Helper loaded: file_helper
INFO - 2024-02-06 02:03:20 --> Helper loaded: html_helper
INFO - 2024-02-06 02:03:20 --> Helper loaded: text_helper
INFO - 2024-02-06 02:03:20 --> Helper loaded: form_helper
INFO - 2024-02-06 02:03:20 --> Helper loaded: lang_helper
INFO - 2024-02-06 02:03:20 --> Helper loaded: security_helper
INFO - 2024-02-06 02:03:20 --> Helper loaded: cookie_helper
INFO - 2024-02-06 02:03:20 --> Database Driver Class Initialized
INFO - 2024-02-06 02:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 02:03:20 --> Parser Class Initialized
INFO - 2024-02-06 02:03:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 02:03:20 --> Pagination Class Initialized
INFO - 2024-02-06 02:03:20 --> Form Validation Class Initialized
INFO - 2024-02-06 02:03:20 --> Controller Class Initialized
INFO - 2024-02-06 02:03:20 --> Model Class Initialized
DEBUG - 2024-02-06 02:03:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-06 02:03:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 02:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 02:03:20 --> Model Class Initialized
INFO - 2024-02-06 02:03:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 02:03:20 --> Final output sent to browser
DEBUG - 2024-02-06 02:03:20 --> Total execution time: 0.0332
ERROR - 2024-02-06 02:03:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 02:03:21 --> Config Class Initialized
INFO - 2024-02-06 02:03:21 --> Hooks Class Initialized
DEBUG - 2024-02-06 02:03:21 --> UTF-8 Support Enabled
INFO - 2024-02-06 02:03:21 --> Utf8 Class Initialized
INFO - 2024-02-06 02:03:21 --> URI Class Initialized
INFO - 2024-02-06 02:03:21 --> Router Class Initialized
INFO - 2024-02-06 02:03:21 --> Output Class Initialized
INFO - 2024-02-06 02:03:21 --> Security Class Initialized
DEBUG - 2024-02-06 02:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 02:03:21 --> Input Class Initialized
INFO - 2024-02-06 02:03:21 --> Language Class Initialized
INFO - 2024-02-06 02:03:21 --> Loader Class Initialized
INFO - 2024-02-06 02:03:21 --> Helper loaded: url_helper
INFO - 2024-02-06 02:03:21 --> Helper loaded: file_helper
INFO - 2024-02-06 02:03:21 --> Helper loaded: html_helper
INFO - 2024-02-06 02:03:21 --> Helper loaded: text_helper
INFO - 2024-02-06 02:03:21 --> Helper loaded: form_helper
INFO - 2024-02-06 02:03:21 --> Helper loaded: lang_helper
INFO - 2024-02-06 02:03:21 --> Helper loaded: security_helper
INFO - 2024-02-06 02:03:21 --> Helper loaded: cookie_helper
INFO - 2024-02-06 02:03:21 --> Database Driver Class Initialized
INFO - 2024-02-06 02:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 02:03:21 --> Parser Class Initialized
INFO - 2024-02-06 02:03:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 02:03:21 --> Pagination Class Initialized
INFO - 2024-02-06 02:03:21 --> Form Validation Class Initialized
INFO - 2024-02-06 02:03:21 --> Controller Class Initialized
INFO - 2024-02-06 02:03:21 --> Model Class Initialized
DEBUG - 2024-02-06 02:03:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:03:21 --> Model Class Initialized
DEBUG - 2024-02-06 02:03:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:03:21 --> Model Class Initialized
INFO - 2024-02-06 02:03:21 --> Model Class Initialized
INFO - 2024-02-06 02:03:21 --> Model Class Initialized
INFO - 2024-02-06 02:03:21 --> Model Class Initialized
DEBUG - 2024-02-06 02:03:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 02:03:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:03:21 --> Model Class Initialized
INFO - 2024-02-06 02:03:21 --> Model Class Initialized
INFO - 2024-02-06 02:03:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 02:03:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 02:03:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 02:03:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 02:03:21 --> Model Class Initialized
INFO - 2024-02-06 02:03:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 02:03:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 02:03:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 02:03:21 --> Final output sent to browser
DEBUG - 2024-02-06 02:03:21 --> Total execution time: 0.2507
ERROR - 2024-02-06 02:07:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 02:07:20 --> Config Class Initialized
INFO - 2024-02-06 02:07:20 --> Hooks Class Initialized
DEBUG - 2024-02-06 02:07:20 --> UTF-8 Support Enabled
INFO - 2024-02-06 02:07:20 --> Utf8 Class Initialized
INFO - 2024-02-06 02:07:20 --> URI Class Initialized
INFO - 2024-02-06 02:07:20 --> Router Class Initialized
INFO - 2024-02-06 02:07:20 --> Output Class Initialized
INFO - 2024-02-06 02:07:20 --> Security Class Initialized
DEBUG - 2024-02-06 02:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 02:07:20 --> Input Class Initialized
INFO - 2024-02-06 02:07:20 --> Language Class Initialized
ERROR - 2024-02-06 02:07:20 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-02-06 04:50:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 04:50:15 --> Config Class Initialized
INFO - 2024-02-06 04:50:15 --> Hooks Class Initialized
DEBUG - 2024-02-06 04:50:15 --> UTF-8 Support Enabled
INFO - 2024-02-06 04:50:15 --> Utf8 Class Initialized
INFO - 2024-02-06 04:50:15 --> URI Class Initialized
DEBUG - 2024-02-06 04:50:15 --> No URI present. Default controller set.
INFO - 2024-02-06 04:50:15 --> Router Class Initialized
INFO - 2024-02-06 04:50:15 --> Output Class Initialized
INFO - 2024-02-06 04:50:15 --> Security Class Initialized
DEBUG - 2024-02-06 04:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 04:50:15 --> Input Class Initialized
INFO - 2024-02-06 04:50:15 --> Language Class Initialized
INFO - 2024-02-06 04:50:15 --> Loader Class Initialized
INFO - 2024-02-06 04:50:15 --> Helper loaded: url_helper
INFO - 2024-02-06 04:50:15 --> Helper loaded: file_helper
INFO - 2024-02-06 04:50:15 --> Helper loaded: html_helper
INFO - 2024-02-06 04:50:15 --> Helper loaded: text_helper
INFO - 2024-02-06 04:50:15 --> Helper loaded: form_helper
INFO - 2024-02-06 04:50:15 --> Helper loaded: lang_helper
INFO - 2024-02-06 04:50:15 --> Helper loaded: security_helper
INFO - 2024-02-06 04:50:15 --> Helper loaded: cookie_helper
INFO - 2024-02-06 04:50:15 --> Database Driver Class Initialized
INFO - 2024-02-06 04:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 04:50:15 --> Parser Class Initialized
INFO - 2024-02-06 04:50:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 04:50:15 --> Pagination Class Initialized
INFO - 2024-02-06 04:50:15 --> Form Validation Class Initialized
INFO - 2024-02-06 04:50:15 --> Controller Class Initialized
INFO - 2024-02-06 04:50:15 --> Model Class Initialized
DEBUG - 2024-02-06 04:50:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-06 04:50:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 04:50:15 --> Config Class Initialized
INFO - 2024-02-06 04:50:15 --> Hooks Class Initialized
DEBUG - 2024-02-06 04:50:15 --> UTF-8 Support Enabled
INFO - 2024-02-06 04:50:15 --> Utf8 Class Initialized
INFO - 2024-02-06 04:50:15 --> URI Class Initialized
INFO - 2024-02-06 04:50:15 --> Router Class Initialized
INFO - 2024-02-06 04:50:15 --> Output Class Initialized
INFO - 2024-02-06 04:50:15 --> Security Class Initialized
DEBUG - 2024-02-06 04:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 04:50:15 --> Input Class Initialized
INFO - 2024-02-06 04:50:15 --> Language Class Initialized
INFO - 2024-02-06 04:50:15 --> Loader Class Initialized
INFO - 2024-02-06 04:50:15 --> Helper loaded: url_helper
INFO - 2024-02-06 04:50:15 --> Helper loaded: file_helper
INFO - 2024-02-06 04:50:15 --> Helper loaded: html_helper
INFO - 2024-02-06 04:50:15 --> Helper loaded: text_helper
INFO - 2024-02-06 04:50:15 --> Helper loaded: form_helper
INFO - 2024-02-06 04:50:15 --> Helper loaded: lang_helper
INFO - 2024-02-06 04:50:15 --> Helper loaded: security_helper
INFO - 2024-02-06 04:50:15 --> Helper loaded: cookie_helper
INFO - 2024-02-06 04:50:15 --> Database Driver Class Initialized
INFO - 2024-02-06 04:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 04:50:15 --> Parser Class Initialized
INFO - 2024-02-06 04:50:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 04:50:15 --> Pagination Class Initialized
INFO - 2024-02-06 04:50:15 --> Form Validation Class Initialized
INFO - 2024-02-06 04:50:15 --> Controller Class Initialized
INFO - 2024-02-06 04:50:15 --> Model Class Initialized
DEBUG - 2024-02-06 04:50:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 04:50:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-06 04:50:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 04:50:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 04:50:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 04:50:15 --> Model Class Initialized
INFO - 2024-02-06 04:50:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 04:50:15 --> Final output sent to browser
DEBUG - 2024-02-06 04:50:15 --> Total execution time: 0.0384
ERROR - 2024-02-06 05:38:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 05:38:49 --> Config Class Initialized
INFO - 2024-02-06 05:38:49 --> Hooks Class Initialized
DEBUG - 2024-02-06 05:38:49 --> UTF-8 Support Enabled
INFO - 2024-02-06 05:38:49 --> Utf8 Class Initialized
INFO - 2024-02-06 05:38:49 --> URI Class Initialized
DEBUG - 2024-02-06 05:38:49 --> No URI present. Default controller set.
INFO - 2024-02-06 05:38:49 --> Router Class Initialized
INFO - 2024-02-06 05:38:49 --> Output Class Initialized
INFO - 2024-02-06 05:38:49 --> Security Class Initialized
DEBUG - 2024-02-06 05:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 05:38:49 --> Input Class Initialized
INFO - 2024-02-06 05:38:49 --> Language Class Initialized
INFO - 2024-02-06 05:38:49 --> Loader Class Initialized
INFO - 2024-02-06 05:38:49 --> Helper loaded: url_helper
INFO - 2024-02-06 05:38:49 --> Helper loaded: file_helper
INFO - 2024-02-06 05:38:49 --> Helper loaded: html_helper
INFO - 2024-02-06 05:38:49 --> Helper loaded: text_helper
INFO - 2024-02-06 05:38:49 --> Helper loaded: form_helper
INFO - 2024-02-06 05:38:49 --> Helper loaded: lang_helper
INFO - 2024-02-06 05:38:49 --> Helper loaded: security_helper
INFO - 2024-02-06 05:38:49 --> Helper loaded: cookie_helper
INFO - 2024-02-06 05:38:49 --> Database Driver Class Initialized
INFO - 2024-02-06 05:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 05:38:49 --> Parser Class Initialized
INFO - 2024-02-06 05:38:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 05:38:49 --> Pagination Class Initialized
INFO - 2024-02-06 05:38:49 --> Form Validation Class Initialized
INFO - 2024-02-06 05:38:49 --> Controller Class Initialized
INFO - 2024-02-06 05:38:49 --> Model Class Initialized
DEBUG - 2024-02-06 05:38:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-06 05:38:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 05:38:49 --> Config Class Initialized
INFO - 2024-02-06 05:38:49 --> Hooks Class Initialized
DEBUG - 2024-02-06 05:38:49 --> UTF-8 Support Enabled
INFO - 2024-02-06 05:38:49 --> Utf8 Class Initialized
INFO - 2024-02-06 05:38:49 --> URI Class Initialized
INFO - 2024-02-06 05:38:49 --> Router Class Initialized
INFO - 2024-02-06 05:38:49 --> Output Class Initialized
INFO - 2024-02-06 05:38:49 --> Security Class Initialized
DEBUG - 2024-02-06 05:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 05:38:49 --> Input Class Initialized
INFO - 2024-02-06 05:38:49 --> Language Class Initialized
INFO - 2024-02-06 05:38:49 --> Loader Class Initialized
INFO - 2024-02-06 05:38:49 --> Helper loaded: url_helper
INFO - 2024-02-06 05:38:49 --> Helper loaded: file_helper
INFO - 2024-02-06 05:38:49 --> Helper loaded: html_helper
INFO - 2024-02-06 05:38:49 --> Helper loaded: text_helper
INFO - 2024-02-06 05:38:49 --> Helper loaded: form_helper
INFO - 2024-02-06 05:38:49 --> Helper loaded: lang_helper
INFO - 2024-02-06 05:38:49 --> Helper loaded: security_helper
INFO - 2024-02-06 05:38:49 --> Helper loaded: cookie_helper
INFO - 2024-02-06 05:38:49 --> Database Driver Class Initialized
INFO - 2024-02-06 05:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 05:38:49 --> Parser Class Initialized
INFO - 2024-02-06 05:38:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 05:38:49 --> Pagination Class Initialized
INFO - 2024-02-06 05:38:49 --> Form Validation Class Initialized
INFO - 2024-02-06 05:38:49 --> Controller Class Initialized
INFO - 2024-02-06 05:38:49 --> Model Class Initialized
DEBUG - 2024-02-06 05:38:49 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 05:38:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-06 05:38:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 05:38:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 05:38:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 05:38:49 --> Model Class Initialized
INFO - 2024-02-06 05:38:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 05:38:49 --> Final output sent to browser
DEBUG - 2024-02-06 05:38:49 --> Total execution time: 0.0413
ERROR - 2024-02-06 05:39:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 05:39:06 --> Config Class Initialized
INFO - 2024-02-06 05:39:06 --> Hooks Class Initialized
DEBUG - 2024-02-06 05:39:06 --> UTF-8 Support Enabled
INFO - 2024-02-06 05:39:06 --> Utf8 Class Initialized
INFO - 2024-02-06 05:39:06 --> URI Class Initialized
INFO - 2024-02-06 05:39:06 --> Router Class Initialized
INFO - 2024-02-06 05:39:06 --> Output Class Initialized
INFO - 2024-02-06 05:39:06 --> Security Class Initialized
DEBUG - 2024-02-06 05:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 05:39:06 --> Input Class Initialized
INFO - 2024-02-06 05:39:06 --> Language Class Initialized
INFO - 2024-02-06 05:39:06 --> Loader Class Initialized
INFO - 2024-02-06 05:39:06 --> Helper loaded: url_helper
INFO - 2024-02-06 05:39:06 --> Helper loaded: file_helper
INFO - 2024-02-06 05:39:06 --> Helper loaded: html_helper
INFO - 2024-02-06 05:39:06 --> Helper loaded: text_helper
INFO - 2024-02-06 05:39:06 --> Helper loaded: form_helper
INFO - 2024-02-06 05:39:06 --> Helper loaded: lang_helper
INFO - 2024-02-06 05:39:06 --> Helper loaded: security_helper
INFO - 2024-02-06 05:39:06 --> Helper loaded: cookie_helper
INFO - 2024-02-06 05:39:06 --> Database Driver Class Initialized
INFO - 2024-02-06 05:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 05:39:06 --> Parser Class Initialized
INFO - 2024-02-06 05:39:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 05:39:06 --> Pagination Class Initialized
INFO - 2024-02-06 05:39:06 --> Form Validation Class Initialized
INFO - 2024-02-06 05:39:06 --> Controller Class Initialized
INFO - 2024-02-06 05:39:06 --> Model Class Initialized
DEBUG - 2024-02-06 05:39:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 05:39:06 --> Model Class Initialized
INFO - 2024-02-06 05:39:06 --> Final output sent to browser
DEBUG - 2024-02-06 05:39:06 --> Total execution time: 0.0190
ERROR - 2024-02-06 05:39:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 05:39:06 --> Config Class Initialized
INFO - 2024-02-06 05:39:06 --> Hooks Class Initialized
DEBUG - 2024-02-06 05:39:06 --> UTF-8 Support Enabled
INFO - 2024-02-06 05:39:06 --> Utf8 Class Initialized
INFO - 2024-02-06 05:39:06 --> URI Class Initialized
DEBUG - 2024-02-06 05:39:06 --> No URI present. Default controller set.
INFO - 2024-02-06 05:39:06 --> Router Class Initialized
INFO - 2024-02-06 05:39:06 --> Output Class Initialized
INFO - 2024-02-06 05:39:06 --> Security Class Initialized
DEBUG - 2024-02-06 05:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 05:39:06 --> Input Class Initialized
INFO - 2024-02-06 05:39:06 --> Language Class Initialized
INFO - 2024-02-06 05:39:06 --> Loader Class Initialized
INFO - 2024-02-06 05:39:06 --> Helper loaded: url_helper
INFO - 2024-02-06 05:39:06 --> Helper loaded: file_helper
INFO - 2024-02-06 05:39:06 --> Helper loaded: html_helper
INFO - 2024-02-06 05:39:06 --> Helper loaded: text_helper
INFO - 2024-02-06 05:39:06 --> Helper loaded: form_helper
INFO - 2024-02-06 05:39:06 --> Helper loaded: lang_helper
INFO - 2024-02-06 05:39:06 --> Helper loaded: security_helper
INFO - 2024-02-06 05:39:06 --> Helper loaded: cookie_helper
INFO - 2024-02-06 05:39:06 --> Database Driver Class Initialized
INFO - 2024-02-06 05:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 05:39:06 --> Parser Class Initialized
INFO - 2024-02-06 05:39:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 05:39:06 --> Pagination Class Initialized
INFO - 2024-02-06 05:39:06 --> Form Validation Class Initialized
INFO - 2024-02-06 05:39:06 --> Controller Class Initialized
INFO - 2024-02-06 05:39:06 --> Model Class Initialized
DEBUG - 2024-02-06 05:39:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 05:39:06 --> Model Class Initialized
DEBUG - 2024-02-06 05:39:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 05:39:06 --> Model Class Initialized
INFO - 2024-02-06 05:39:06 --> Model Class Initialized
INFO - 2024-02-06 05:39:06 --> Model Class Initialized
INFO - 2024-02-06 05:39:06 --> Model Class Initialized
DEBUG - 2024-02-06 05:39:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 05:39:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 05:39:06 --> Model Class Initialized
INFO - 2024-02-06 05:39:06 --> Model Class Initialized
INFO - 2024-02-06 05:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 05:39:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 05:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 05:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 05:39:06 --> Model Class Initialized
INFO - 2024-02-06 05:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 05:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 05:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 05:39:06 --> Final output sent to browser
DEBUG - 2024-02-06 05:39:06 --> Total execution time: 0.4103
ERROR - 2024-02-06 05:39:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 05:39:08 --> Config Class Initialized
INFO - 2024-02-06 05:39:08 --> Hooks Class Initialized
DEBUG - 2024-02-06 05:39:08 --> UTF-8 Support Enabled
INFO - 2024-02-06 05:39:08 --> Utf8 Class Initialized
INFO - 2024-02-06 05:39:08 --> URI Class Initialized
INFO - 2024-02-06 05:39:08 --> Router Class Initialized
INFO - 2024-02-06 05:39:08 --> Output Class Initialized
INFO - 2024-02-06 05:39:08 --> Security Class Initialized
DEBUG - 2024-02-06 05:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 05:39:08 --> Input Class Initialized
INFO - 2024-02-06 05:39:08 --> Language Class Initialized
INFO - 2024-02-06 05:39:08 --> Loader Class Initialized
INFO - 2024-02-06 05:39:08 --> Helper loaded: url_helper
INFO - 2024-02-06 05:39:08 --> Helper loaded: file_helper
INFO - 2024-02-06 05:39:08 --> Helper loaded: html_helper
INFO - 2024-02-06 05:39:08 --> Helper loaded: text_helper
INFO - 2024-02-06 05:39:08 --> Helper loaded: form_helper
INFO - 2024-02-06 05:39:08 --> Helper loaded: lang_helper
INFO - 2024-02-06 05:39:08 --> Helper loaded: security_helper
INFO - 2024-02-06 05:39:08 --> Helper loaded: cookie_helper
INFO - 2024-02-06 05:39:08 --> Database Driver Class Initialized
INFO - 2024-02-06 05:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 05:39:08 --> Parser Class Initialized
INFO - 2024-02-06 05:39:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 05:39:08 --> Pagination Class Initialized
INFO - 2024-02-06 05:39:08 --> Form Validation Class Initialized
INFO - 2024-02-06 05:39:08 --> Controller Class Initialized
DEBUG - 2024-02-06 05:39:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 05:39:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 05:39:08 --> Model Class Initialized
INFO - 2024-02-06 05:39:08 --> Final output sent to browser
DEBUG - 2024-02-06 05:39:08 --> Total execution time: 0.0168
ERROR - 2024-02-06 05:39:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 05:39:30 --> Config Class Initialized
INFO - 2024-02-06 05:39:30 --> Hooks Class Initialized
DEBUG - 2024-02-06 05:39:30 --> UTF-8 Support Enabled
INFO - 2024-02-06 05:39:30 --> Utf8 Class Initialized
INFO - 2024-02-06 05:39:30 --> URI Class Initialized
INFO - 2024-02-06 05:39:30 --> Router Class Initialized
INFO - 2024-02-06 05:39:30 --> Output Class Initialized
INFO - 2024-02-06 05:39:30 --> Security Class Initialized
DEBUG - 2024-02-06 05:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 05:39:30 --> Input Class Initialized
INFO - 2024-02-06 05:39:30 --> Language Class Initialized
INFO - 2024-02-06 05:39:30 --> Loader Class Initialized
INFO - 2024-02-06 05:39:30 --> Helper loaded: url_helper
INFO - 2024-02-06 05:39:30 --> Helper loaded: file_helper
INFO - 2024-02-06 05:39:30 --> Helper loaded: html_helper
INFO - 2024-02-06 05:39:30 --> Helper loaded: text_helper
INFO - 2024-02-06 05:39:30 --> Helper loaded: form_helper
INFO - 2024-02-06 05:39:30 --> Helper loaded: lang_helper
INFO - 2024-02-06 05:39:30 --> Helper loaded: security_helper
INFO - 2024-02-06 05:39:30 --> Helper loaded: cookie_helper
INFO - 2024-02-06 05:39:30 --> Database Driver Class Initialized
INFO - 2024-02-06 05:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 05:39:30 --> Parser Class Initialized
INFO - 2024-02-06 05:39:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 05:39:30 --> Pagination Class Initialized
INFO - 2024-02-06 05:39:30 --> Form Validation Class Initialized
INFO - 2024-02-06 05:39:30 --> Controller Class Initialized
INFO - 2024-02-06 05:39:30 --> Model Class Initialized
DEBUG - 2024-02-06 05:39:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 05:39:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 05:39:30 --> Model Class Initialized
DEBUG - 2024-02-06 05:39:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 05:39:30 --> Model Class Initialized
INFO - 2024-02-06 05:39:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-06 05:39:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 05:39:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 05:39:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 05:39:30 --> Model Class Initialized
INFO - 2024-02-06 05:39:30 --> Model Class Initialized
INFO - 2024-02-06 05:39:30 --> Model Class Initialized
INFO - 2024-02-06 05:39:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 05:39:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 05:39:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 05:39:30 --> Final output sent to browser
DEBUG - 2024-02-06 05:39:30 --> Total execution time: 0.2148
ERROR - 2024-02-06 05:39:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 05:39:31 --> Config Class Initialized
INFO - 2024-02-06 05:39:31 --> Hooks Class Initialized
DEBUG - 2024-02-06 05:39:31 --> UTF-8 Support Enabled
INFO - 2024-02-06 05:39:31 --> Utf8 Class Initialized
INFO - 2024-02-06 05:39:31 --> URI Class Initialized
INFO - 2024-02-06 05:39:31 --> Router Class Initialized
INFO - 2024-02-06 05:39:31 --> Output Class Initialized
INFO - 2024-02-06 05:39:31 --> Security Class Initialized
DEBUG - 2024-02-06 05:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 05:39:31 --> Input Class Initialized
INFO - 2024-02-06 05:39:31 --> Language Class Initialized
INFO - 2024-02-06 05:39:31 --> Loader Class Initialized
INFO - 2024-02-06 05:39:31 --> Helper loaded: url_helper
INFO - 2024-02-06 05:39:31 --> Helper loaded: file_helper
INFO - 2024-02-06 05:39:31 --> Helper loaded: html_helper
INFO - 2024-02-06 05:39:31 --> Helper loaded: text_helper
INFO - 2024-02-06 05:39:31 --> Helper loaded: form_helper
INFO - 2024-02-06 05:39:31 --> Helper loaded: lang_helper
INFO - 2024-02-06 05:39:31 --> Helper loaded: security_helper
INFO - 2024-02-06 05:39:31 --> Helper loaded: cookie_helper
INFO - 2024-02-06 05:39:31 --> Database Driver Class Initialized
INFO - 2024-02-06 05:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 05:39:31 --> Parser Class Initialized
INFO - 2024-02-06 05:39:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 05:39:31 --> Pagination Class Initialized
INFO - 2024-02-06 05:39:31 --> Form Validation Class Initialized
INFO - 2024-02-06 05:39:31 --> Controller Class Initialized
INFO - 2024-02-06 05:39:31 --> Model Class Initialized
DEBUG - 2024-02-06 05:39:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 05:39:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 05:39:31 --> Model Class Initialized
DEBUG - 2024-02-06 05:39:31 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 05:39:31 --> Model Class Initialized
INFO - 2024-02-06 05:39:31 --> Final output sent to browser
DEBUG - 2024-02-06 05:39:31 --> Total execution time: 0.0590
ERROR - 2024-02-06 06:58:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 06:58:42 --> Config Class Initialized
INFO - 2024-02-06 06:58:42 --> Hooks Class Initialized
DEBUG - 2024-02-06 06:58:42 --> UTF-8 Support Enabled
INFO - 2024-02-06 06:58:42 --> Utf8 Class Initialized
INFO - 2024-02-06 06:58:42 --> URI Class Initialized
DEBUG - 2024-02-06 06:58:42 --> No URI present. Default controller set.
INFO - 2024-02-06 06:58:42 --> Router Class Initialized
INFO - 2024-02-06 06:58:42 --> Output Class Initialized
INFO - 2024-02-06 06:58:42 --> Security Class Initialized
DEBUG - 2024-02-06 06:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 06:58:42 --> Input Class Initialized
INFO - 2024-02-06 06:58:42 --> Language Class Initialized
INFO - 2024-02-06 06:58:42 --> Loader Class Initialized
INFO - 2024-02-06 06:58:42 --> Helper loaded: url_helper
INFO - 2024-02-06 06:58:42 --> Helper loaded: file_helper
INFO - 2024-02-06 06:58:42 --> Helper loaded: html_helper
INFO - 2024-02-06 06:58:42 --> Helper loaded: text_helper
INFO - 2024-02-06 06:58:42 --> Helper loaded: form_helper
INFO - 2024-02-06 06:58:42 --> Helper loaded: lang_helper
INFO - 2024-02-06 06:58:42 --> Helper loaded: security_helper
INFO - 2024-02-06 06:58:42 --> Helper loaded: cookie_helper
INFO - 2024-02-06 06:58:42 --> Database Driver Class Initialized
INFO - 2024-02-06 06:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 06:58:42 --> Parser Class Initialized
INFO - 2024-02-06 06:58:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 06:58:42 --> Pagination Class Initialized
INFO - 2024-02-06 06:58:42 --> Form Validation Class Initialized
INFO - 2024-02-06 06:58:42 --> Controller Class Initialized
INFO - 2024-02-06 06:58:42 --> Model Class Initialized
DEBUG - 2024-02-06 06:58:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-06 06:58:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 06:58:43 --> Config Class Initialized
INFO - 2024-02-06 06:58:43 --> Hooks Class Initialized
DEBUG - 2024-02-06 06:58:43 --> UTF-8 Support Enabled
INFO - 2024-02-06 06:58:43 --> Utf8 Class Initialized
INFO - 2024-02-06 06:58:43 --> URI Class Initialized
INFO - 2024-02-06 06:58:43 --> Router Class Initialized
INFO - 2024-02-06 06:58:43 --> Output Class Initialized
INFO - 2024-02-06 06:58:43 --> Security Class Initialized
DEBUG - 2024-02-06 06:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 06:58:43 --> Input Class Initialized
INFO - 2024-02-06 06:58:43 --> Language Class Initialized
INFO - 2024-02-06 06:58:43 --> Loader Class Initialized
INFO - 2024-02-06 06:58:43 --> Helper loaded: url_helper
INFO - 2024-02-06 06:58:43 --> Helper loaded: file_helper
INFO - 2024-02-06 06:58:43 --> Helper loaded: html_helper
INFO - 2024-02-06 06:58:43 --> Helper loaded: text_helper
INFO - 2024-02-06 06:58:43 --> Helper loaded: form_helper
INFO - 2024-02-06 06:58:43 --> Helper loaded: lang_helper
INFO - 2024-02-06 06:58:43 --> Helper loaded: security_helper
INFO - 2024-02-06 06:58:43 --> Helper loaded: cookie_helper
INFO - 2024-02-06 06:58:43 --> Database Driver Class Initialized
INFO - 2024-02-06 06:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 06:58:43 --> Parser Class Initialized
INFO - 2024-02-06 06:58:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 06:58:43 --> Pagination Class Initialized
INFO - 2024-02-06 06:58:43 --> Form Validation Class Initialized
INFO - 2024-02-06 06:58:43 --> Controller Class Initialized
INFO - 2024-02-06 06:58:43 --> Model Class Initialized
DEBUG - 2024-02-06 06:58:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 06:58:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-06 06:58:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 06:58:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 06:58:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 06:58:43 --> Model Class Initialized
INFO - 2024-02-06 06:58:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 06:58:43 --> Final output sent to browser
DEBUG - 2024-02-06 06:58:43 --> Total execution time: 0.0345
ERROR - 2024-02-06 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 06:59:10 --> Config Class Initialized
INFO - 2024-02-06 06:59:10 --> Hooks Class Initialized
DEBUG - 2024-02-06 06:59:10 --> UTF-8 Support Enabled
INFO - 2024-02-06 06:59:10 --> Utf8 Class Initialized
INFO - 2024-02-06 06:59:10 --> URI Class Initialized
INFO - 2024-02-06 06:59:10 --> Router Class Initialized
INFO - 2024-02-06 06:59:10 --> Output Class Initialized
INFO - 2024-02-06 06:59:10 --> Security Class Initialized
DEBUG - 2024-02-06 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 06:59:10 --> Input Class Initialized
INFO - 2024-02-06 06:59:10 --> Language Class Initialized
INFO - 2024-02-06 06:59:10 --> Loader Class Initialized
INFO - 2024-02-06 06:59:10 --> Helper loaded: url_helper
INFO - 2024-02-06 06:59:10 --> Helper loaded: file_helper
INFO - 2024-02-06 06:59:10 --> Helper loaded: html_helper
INFO - 2024-02-06 06:59:10 --> Helper loaded: text_helper
INFO - 2024-02-06 06:59:10 --> Helper loaded: form_helper
INFO - 2024-02-06 06:59:10 --> Helper loaded: lang_helper
INFO - 2024-02-06 06:59:10 --> Helper loaded: security_helper
INFO - 2024-02-06 06:59:10 --> Helper loaded: cookie_helper
INFO - 2024-02-06 06:59:10 --> Database Driver Class Initialized
INFO - 2024-02-06 06:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 06:59:10 --> Parser Class Initialized
INFO - 2024-02-06 06:59:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 06:59:10 --> Pagination Class Initialized
INFO - 2024-02-06 06:59:10 --> Form Validation Class Initialized
INFO - 2024-02-06 06:59:10 --> Controller Class Initialized
INFO - 2024-02-06 06:59:10 --> Model Class Initialized
DEBUG - 2024-02-06 06:59:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 06:59:10 --> Model Class Initialized
INFO - 2024-02-06 06:59:10 --> Final output sent to browser
DEBUG - 2024-02-06 06:59:10 --> Total execution time: 0.0215
ERROR - 2024-02-06 06:59:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 06:59:10 --> Config Class Initialized
INFO - 2024-02-06 06:59:10 --> Hooks Class Initialized
DEBUG - 2024-02-06 06:59:10 --> UTF-8 Support Enabled
INFO - 2024-02-06 06:59:10 --> Utf8 Class Initialized
INFO - 2024-02-06 06:59:10 --> URI Class Initialized
DEBUG - 2024-02-06 06:59:10 --> No URI present. Default controller set.
INFO - 2024-02-06 06:59:10 --> Router Class Initialized
INFO - 2024-02-06 06:59:10 --> Output Class Initialized
INFO - 2024-02-06 06:59:10 --> Security Class Initialized
DEBUG - 2024-02-06 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 06:59:10 --> Input Class Initialized
INFO - 2024-02-06 06:59:10 --> Language Class Initialized
INFO - 2024-02-06 06:59:10 --> Loader Class Initialized
INFO - 2024-02-06 06:59:10 --> Helper loaded: url_helper
INFO - 2024-02-06 06:59:10 --> Helper loaded: file_helper
INFO - 2024-02-06 06:59:10 --> Helper loaded: html_helper
INFO - 2024-02-06 06:59:10 --> Helper loaded: text_helper
INFO - 2024-02-06 06:59:10 --> Helper loaded: form_helper
INFO - 2024-02-06 06:59:10 --> Helper loaded: lang_helper
INFO - 2024-02-06 06:59:10 --> Helper loaded: security_helper
INFO - 2024-02-06 06:59:10 --> Helper loaded: cookie_helper
INFO - 2024-02-06 06:59:10 --> Database Driver Class Initialized
INFO - 2024-02-06 06:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 06:59:10 --> Parser Class Initialized
INFO - 2024-02-06 06:59:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 06:59:10 --> Pagination Class Initialized
INFO - 2024-02-06 06:59:10 --> Form Validation Class Initialized
INFO - 2024-02-06 06:59:10 --> Controller Class Initialized
INFO - 2024-02-06 06:59:10 --> Model Class Initialized
DEBUG - 2024-02-06 06:59:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 06:59:10 --> Model Class Initialized
DEBUG - 2024-02-06 06:59:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 06:59:10 --> Model Class Initialized
INFO - 2024-02-06 06:59:10 --> Model Class Initialized
INFO - 2024-02-06 06:59:10 --> Model Class Initialized
INFO - 2024-02-06 06:59:10 --> Model Class Initialized
DEBUG - 2024-02-06 06:59:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 06:59:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 06:59:10 --> Model Class Initialized
INFO - 2024-02-06 06:59:10 --> Model Class Initialized
INFO - 2024-02-06 06:59:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 06:59:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 06:59:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 06:59:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 06:59:11 --> Model Class Initialized
INFO - 2024-02-06 06:59:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 06:59:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 06:59:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 06:59:11 --> Final output sent to browser
DEBUG - 2024-02-06 06:59:11 --> Total execution time: 0.2172
ERROR - 2024-02-06 07:00:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 07:00:30 --> Config Class Initialized
INFO - 2024-02-06 07:00:30 --> Hooks Class Initialized
DEBUG - 2024-02-06 07:00:30 --> UTF-8 Support Enabled
INFO - 2024-02-06 07:00:30 --> Utf8 Class Initialized
INFO - 2024-02-06 07:00:30 --> URI Class Initialized
INFO - 2024-02-06 07:00:30 --> Router Class Initialized
INFO - 2024-02-06 07:00:30 --> Output Class Initialized
INFO - 2024-02-06 07:00:30 --> Security Class Initialized
DEBUG - 2024-02-06 07:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 07:00:30 --> Input Class Initialized
INFO - 2024-02-06 07:00:30 --> Language Class Initialized
INFO - 2024-02-06 07:00:30 --> Loader Class Initialized
INFO - 2024-02-06 07:00:30 --> Helper loaded: url_helper
INFO - 2024-02-06 07:00:30 --> Helper loaded: file_helper
INFO - 2024-02-06 07:00:30 --> Helper loaded: html_helper
INFO - 2024-02-06 07:00:30 --> Helper loaded: text_helper
INFO - 2024-02-06 07:00:30 --> Helper loaded: form_helper
INFO - 2024-02-06 07:00:30 --> Helper loaded: lang_helper
INFO - 2024-02-06 07:00:30 --> Helper loaded: security_helper
INFO - 2024-02-06 07:00:30 --> Helper loaded: cookie_helper
INFO - 2024-02-06 07:00:30 --> Database Driver Class Initialized
INFO - 2024-02-06 07:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 07:00:30 --> Parser Class Initialized
INFO - 2024-02-06 07:00:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 07:00:30 --> Pagination Class Initialized
INFO - 2024-02-06 07:00:30 --> Form Validation Class Initialized
INFO - 2024-02-06 07:00:30 --> Controller Class Initialized
INFO - 2024-02-06 07:00:30 --> Model Class Initialized
DEBUG - 2024-02-06 07:00:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 07:00:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:00:30 --> Model Class Initialized
DEBUG - 2024-02-06 07:00:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:00:30 --> Model Class Initialized
INFO - 2024-02-06 07:00:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-06 07:00:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:00:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 07:00:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 07:00:30 --> Model Class Initialized
INFO - 2024-02-06 07:00:30 --> Model Class Initialized
INFO - 2024-02-06 07:00:30 --> Model Class Initialized
INFO - 2024-02-06 07:00:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 07:00:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 07:00:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 07:00:30 --> Final output sent to browser
DEBUG - 2024-02-06 07:00:30 --> Total execution time: 0.1940
ERROR - 2024-02-06 07:00:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 07:00:35 --> Config Class Initialized
INFO - 2024-02-06 07:00:35 --> Hooks Class Initialized
DEBUG - 2024-02-06 07:00:35 --> UTF-8 Support Enabled
INFO - 2024-02-06 07:00:35 --> Utf8 Class Initialized
INFO - 2024-02-06 07:00:35 --> URI Class Initialized
DEBUG - 2024-02-06 07:00:35 --> No URI present. Default controller set.
INFO - 2024-02-06 07:00:35 --> Router Class Initialized
INFO - 2024-02-06 07:00:35 --> Output Class Initialized
INFO - 2024-02-06 07:00:35 --> Security Class Initialized
DEBUG - 2024-02-06 07:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 07:00:35 --> Input Class Initialized
INFO - 2024-02-06 07:00:35 --> Language Class Initialized
INFO - 2024-02-06 07:00:35 --> Loader Class Initialized
INFO - 2024-02-06 07:00:35 --> Helper loaded: url_helper
INFO - 2024-02-06 07:00:35 --> Helper loaded: file_helper
INFO - 2024-02-06 07:00:35 --> Helper loaded: html_helper
INFO - 2024-02-06 07:00:35 --> Helper loaded: text_helper
INFO - 2024-02-06 07:00:35 --> Helper loaded: form_helper
INFO - 2024-02-06 07:00:35 --> Helper loaded: lang_helper
INFO - 2024-02-06 07:00:35 --> Helper loaded: security_helper
INFO - 2024-02-06 07:00:35 --> Helper loaded: cookie_helper
INFO - 2024-02-06 07:00:35 --> Database Driver Class Initialized
INFO - 2024-02-06 07:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 07:00:35 --> Parser Class Initialized
INFO - 2024-02-06 07:00:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 07:00:35 --> Pagination Class Initialized
INFO - 2024-02-06 07:00:35 --> Form Validation Class Initialized
INFO - 2024-02-06 07:00:35 --> Controller Class Initialized
INFO - 2024-02-06 07:00:35 --> Model Class Initialized
DEBUG - 2024-02-06 07:00:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:00:35 --> Model Class Initialized
DEBUG - 2024-02-06 07:00:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:00:35 --> Model Class Initialized
INFO - 2024-02-06 07:00:35 --> Model Class Initialized
INFO - 2024-02-06 07:00:35 --> Model Class Initialized
INFO - 2024-02-06 07:00:35 --> Model Class Initialized
DEBUG - 2024-02-06 07:00:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 07:00:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:00:35 --> Model Class Initialized
INFO - 2024-02-06 07:00:35 --> Model Class Initialized
INFO - 2024-02-06 07:00:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 07:00:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:00:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 07:00:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 07:00:36 --> Model Class Initialized
INFO - 2024-02-06 07:00:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 07:00:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 07:00:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 07:00:36 --> Final output sent to browser
DEBUG - 2024-02-06 07:00:36 --> Total execution time: 0.2096
ERROR - 2024-02-06 07:00:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 07:00:37 --> Config Class Initialized
INFO - 2024-02-06 07:00:37 --> Hooks Class Initialized
DEBUG - 2024-02-06 07:00:37 --> UTF-8 Support Enabled
INFO - 2024-02-06 07:00:37 --> Utf8 Class Initialized
INFO - 2024-02-06 07:00:37 --> URI Class Initialized
INFO - 2024-02-06 07:00:37 --> Router Class Initialized
INFO - 2024-02-06 07:00:37 --> Output Class Initialized
INFO - 2024-02-06 07:00:37 --> Security Class Initialized
DEBUG - 2024-02-06 07:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 07:00:37 --> Input Class Initialized
INFO - 2024-02-06 07:00:37 --> Language Class Initialized
INFO - 2024-02-06 07:00:37 --> Loader Class Initialized
INFO - 2024-02-06 07:00:37 --> Helper loaded: url_helper
INFO - 2024-02-06 07:00:37 --> Helper loaded: file_helper
INFO - 2024-02-06 07:00:37 --> Helper loaded: html_helper
INFO - 2024-02-06 07:00:37 --> Helper loaded: text_helper
INFO - 2024-02-06 07:00:37 --> Helper loaded: form_helper
INFO - 2024-02-06 07:00:37 --> Helper loaded: lang_helper
INFO - 2024-02-06 07:00:37 --> Helper loaded: security_helper
INFO - 2024-02-06 07:00:37 --> Helper loaded: cookie_helper
INFO - 2024-02-06 07:00:37 --> Database Driver Class Initialized
INFO - 2024-02-06 07:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 07:00:37 --> Parser Class Initialized
INFO - 2024-02-06 07:00:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 07:00:37 --> Pagination Class Initialized
INFO - 2024-02-06 07:00:37 --> Form Validation Class Initialized
INFO - 2024-02-06 07:00:37 --> Controller Class Initialized
INFO - 2024-02-06 07:00:37 --> Model Class Initialized
DEBUG - 2024-02-06 07:00:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:00:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-06 07:00:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:00:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 07:00:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 07:00:37 --> Model Class Initialized
INFO - 2024-02-06 07:00:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 07:00:37 --> Final output sent to browser
DEBUG - 2024-02-06 07:00:37 --> Total execution time: 0.0294
ERROR - 2024-02-06 07:00:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 07:00:46 --> Config Class Initialized
INFO - 2024-02-06 07:00:46 --> Hooks Class Initialized
DEBUG - 2024-02-06 07:00:46 --> UTF-8 Support Enabled
INFO - 2024-02-06 07:00:46 --> Utf8 Class Initialized
INFO - 2024-02-06 07:00:46 --> URI Class Initialized
INFO - 2024-02-06 07:00:46 --> Router Class Initialized
INFO - 2024-02-06 07:00:46 --> Output Class Initialized
INFO - 2024-02-06 07:00:46 --> Security Class Initialized
DEBUG - 2024-02-06 07:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 07:00:46 --> Input Class Initialized
INFO - 2024-02-06 07:00:46 --> Language Class Initialized
INFO - 2024-02-06 07:00:46 --> Loader Class Initialized
INFO - 2024-02-06 07:00:46 --> Helper loaded: url_helper
INFO - 2024-02-06 07:00:46 --> Helper loaded: file_helper
INFO - 2024-02-06 07:00:46 --> Helper loaded: html_helper
INFO - 2024-02-06 07:00:46 --> Helper loaded: text_helper
INFO - 2024-02-06 07:00:46 --> Helper loaded: form_helper
INFO - 2024-02-06 07:00:46 --> Helper loaded: lang_helper
INFO - 2024-02-06 07:00:46 --> Helper loaded: security_helper
INFO - 2024-02-06 07:00:46 --> Helper loaded: cookie_helper
INFO - 2024-02-06 07:00:46 --> Database Driver Class Initialized
INFO - 2024-02-06 07:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 07:00:46 --> Parser Class Initialized
INFO - 2024-02-06 07:00:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 07:00:46 --> Pagination Class Initialized
INFO - 2024-02-06 07:00:46 --> Form Validation Class Initialized
INFO - 2024-02-06 07:00:46 --> Controller Class Initialized
INFO - 2024-02-06 07:00:46 --> Model Class Initialized
DEBUG - 2024-02-06 07:00:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:00:46 --> Model Class Initialized
DEBUG - 2024-02-06 07:00:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:00:46 --> Model Class Initialized
INFO - 2024-02-06 07:00:46 --> Model Class Initialized
INFO - 2024-02-06 07:00:46 --> Model Class Initialized
INFO - 2024-02-06 07:00:46 --> Model Class Initialized
DEBUG - 2024-02-06 07:00:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 07:00:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:00:46 --> Model Class Initialized
INFO - 2024-02-06 07:00:46 --> Model Class Initialized
INFO - 2024-02-06 07:00:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 07:00:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:00:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 07:00:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 07:00:46 --> Model Class Initialized
ERROR - 2024-02-06 07:00:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 07:00:46 --> Config Class Initialized
INFO - 2024-02-06 07:00:46 --> Hooks Class Initialized
DEBUG - 2024-02-06 07:00:46 --> UTF-8 Support Enabled
INFO - 2024-02-06 07:00:46 --> Utf8 Class Initialized
INFO - 2024-02-06 07:00:46 --> URI Class Initialized
INFO - 2024-02-06 07:00:46 --> Router Class Initialized
INFO - 2024-02-06 07:00:46 --> Output Class Initialized
INFO - 2024-02-06 07:00:46 --> Security Class Initialized
DEBUG - 2024-02-06 07:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 07:00:46 --> Input Class Initialized
INFO - 2024-02-06 07:00:46 --> Language Class Initialized
INFO - 2024-02-06 07:00:46 --> Loader Class Initialized
INFO - 2024-02-06 07:00:46 --> Helper loaded: url_helper
INFO - 2024-02-06 07:00:46 --> Helper loaded: file_helper
INFO - 2024-02-06 07:00:46 --> Helper loaded: html_helper
INFO - 2024-02-06 07:00:46 --> Helper loaded: text_helper
INFO - 2024-02-06 07:00:46 --> Helper loaded: form_helper
INFO - 2024-02-06 07:00:46 --> Helper loaded: lang_helper
INFO - 2024-02-06 07:00:46 --> Helper loaded: security_helper
INFO - 2024-02-06 07:00:46 --> Helper loaded: cookie_helper
INFO - 2024-02-06 07:00:46 --> Database Driver Class Initialized
INFO - 2024-02-06 07:00:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 07:00:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 07:00:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 07:00:46 --> Final output sent to browser
DEBUG - 2024-02-06 07:00:46 --> Total execution time: 0.2055
INFO - 2024-02-06 07:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 07:00:46 --> Parser Class Initialized
INFO - 2024-02-06 07:00:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 07:00:46 --> Pagination Class Initialized
INFO - 2024-02-06 07:00:46 --> Form Validation Class Initialized
INFO - 2024-02-06 07:00:46 --> Controller Class Initialized
INFO - 2024-02-06 07:00:46 --> Model Class Initialized
DEBUG - 2024-02-06 07:00:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 07:00:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:00:46 --> Model Class Initialized
DEBUG - 2024-02-06 07:00:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:00:46 --> Model Class Initialized
INFO - 2024-02-06 07:00:46 --> Final output sent to browser
DEBUG - 2024-02-06 07:00:46 --> Total execution time: 0.0677
ERROR - 2024-02-06 07:01:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 07:01:38 --> Config Class Initialized
INFO - 2024-02-06 07:01:38 --> Hooks Class Initialized
DEBUG - 2024-02-06 07:01:38 --> UTF-8 Support Enabled
INFO - 2024-02-06 07:01:38 --> Utf8 Class Initialized
INFO - 2024-02-06 07:01:38 --> URI Class Initialized
INFO - 2024-02-06 07:01:38 --> Router Class Initialized
INFO - 2024-02-06 07:01:38 --> Output Class Initialized
INFO - 2024-02-06 07:01:38 --> Security Class Initialized
DEBUG - 2024-02-06 07:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 07:01:38 --> Input Class Initialized
INFO - 2024-02-06 07:01:38 --> Language Class Initialized
INFO - 2024-02-06 07:01:38 --> Loader Class Initialized
INFO - 2024-02-06 07:01:38 --> Helper loaded: url_helper
INFO - 2024-02-06 07:01:38 --> Helper loaded: file_helper
INFO - 2024-02-06 07:01:38 --> Helper loaded: html_helper
INFO - 2024-02-06 07:01:38 --> Helper loaded: text_helper
INFO - 2024-02-06 07:01:38 --> Helper loaded: form_helper
INFO - 2024-02-06 07:01:38 --> Helper loaded: lang_helper
INFO - 2024-02-06 07:01:38 --> Helper loaded: security_helper
INFO - 2024-02-06 07:01:38 --> Helper loaded: cookie_helper
INFO - 2024-02-06 07:01:38 --> Database Driver Class Initialized
INFO - 2024-02-06 07:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 07:01:38 --> Parser Class Initialized
INFO - 2024-02-06 07:01:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 07:01:38 --> Pagination Class Initialized
INFO - 2024-02-06 07:01:38 --> Form Validation Class Initialized
INFO - 2024-02-06 07:01:38 --> Controller Class Initialized
INFO - 2024-02-06 07:01:38 --> Model Class Initialized
INFO - 2024-02-06 07:01:38 --> Model Class Initialized
INFO - 2024-02-06 07:01:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2024-02-06 07:01:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:01:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 07:01:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 07:01:38 --> Model Class Initialized
INFO - 2024-02-06 07:01:38 --> Model Class Initialized
INFO - 2024-02-06 07:01:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 07:01:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 07:01:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 07:01:38 --> Final output sent to browser
DEBUG - 2024-02-06 07:01:38 --> Total execution time: 0.1908
ERROR - 2024-02-06 07:01:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 07:01:45 --> Config Class Initialized
INFO - 2024-02-06 07:01:45 --> Hooks Class Initialized
DEBUG - 2024-02-06 07:01:45 --> UTF-8 Support Enabled
INFO - 2024-02-06 07:01:45 --> Utf8 Class Initialized
INFO - 2024-02-06 07:01:45 --> URI Class Initialized
INFO - 2024-02-06 07:01:45 --> Router Class Initialized
INFO - 2024-02-06 07:01:45 --> Output Class Initialized
INFO - 2024-02-06 07:01:45 --> Security Class Initialized
DEBUG - 2024-02-06 07:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 07:01:45 --> Input Class Initialized
INFO - 2024-02-06 07:01:45 --> Language Class Initialized
INFO - 2024-02-06 07:01:45 --> Loader Class Initialized
INFO - 2024-02-06 07:01:45 --> Helper loaded: url_helper
INFO - 2024-02-06 07:01:45 --> Helper loaded: file_helper
INFO - 2024-02-06 07:01:45 --> Helper loaded: html_helper
INFO - 2024-02-06 07:01:45 --> Helper loaded: text_helper
INFO - 2024-02-06 07:01:45 --> Helper loaded: form_helper
INFO - 2024-02-06 07:01:45 --> Helper loaded: lang_helper
INFO - 2024-02-06 07:01:45 --> Helper loaded: security_helper
INFO - 2024-02-06 07:01:45 --> Helper loaded: cookie_helper
INFO - 2024-02-06 07:01:45 --> Database Driver Class Initialized
INFO - 2024-02-06 07:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 07:01:45 --> Parser Class Initialized
INFO - 2024-02-06 07:01:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 07:01:45 --> Pagination Class Initialized
INFO - 2024-02-06 07:01:45 --> Form Validation Class Initialized
INFO - 2024-02-06 07:01:45 --> Controller Class Initialized
INFO - 2024-02-06 07:01:45 --> Model Class Initialized
INFO - 2024-02-06 07:01:45 --> Model Class Initialized
INFO - 2024-02-06 07:01:45 --> Final output sent to browser
DEBUG - 2024-02-06 07:01:45 --> Total execution time: 0.1830
ERROR - 2024-02-06 07:01:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 07:01:48 --> Config Class Initialized
INFO - 2024-02-06 07:01:48 --> Hooks Class Initialized
DEBUG - 2024-02-06 07:01:48 --> UTF-8 Support Enabled
INFO - 2024-02-06 07:01:48 --> Utf8 Class Initialized
INFO - 2024-02-06 07:01:48 --> URI Class Initialized
DEBUG - 2024-02-06 07:01:48 --> No URI present. Default controller set.
INFO - 2024-02-06 07:01:48 --> Router Class Initialized
INFO - 2024-02-06 07:01:48 --> Output Class Initialized
INFO - 2024-02-06 07:01:48 --> Security Class Initialized
DEBUG - 2024-02-06 07:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 07:01:48 --> Input Class Initialized
INFO - 2024-02-06 07:01:48 --> Language Class Initialized
INFO - 2024-02-06 07:01:48 --> Loader Class Initialized
INFO - 2024-02-06 07:01:48 --> Helper loaded: url_helper
INFO - 2024-02-06 07:01:48 --> Helper loaded: file_helper
INFO - 2024-02-06 07:01:48 --> Helper loaded: html_helper
INFO - 2024-02-06 07:01:48 --> Helper loaded: text_helper
INFO - 2024-02-06 07:01:48 --> Helper loaded: form_helper
INFO - 2024-02-06 07:01:48 --> Helper loaded: lang_helper
INFO - 2024-02-06 07:01:48 --> Helper loaded: security_helper
INFO - 2024-02-06 07:01:48 --> Helper loaded: cookie_helper
INFO - 2024-02-06 07:01:48 --> Database Driver Class Initialized
INFO - 2024-02-06 07:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 07:01:48 --> Parser Class Initialized
INFO - 2024-02-06 07:01:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 07:01:48 --> Pagination Class Initialized
INFO - 2024-02-06 07:01:48 --> Form Validation Class Initialized
INFO - 2024-02-06 07:01:48 --> Controller Class Initialized
INFO - 2024-02-06 07:01:48 --> Model Class Initialized
DEBUG - 2024-02-06 07:01:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-06 07:01:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 07:01:48 --> Config Class Initialized
INFO - 2024-02-06 07:01:48 --> Hooks Class Initialized
DEBUG - 2024-02-06 07:01:48 --> UTF-8 Support Enabled
INFO - 2024-02-06 07:01:48 --> Utf8 Class Initialized
INFO - 2024-02-06 07:01:48 --> URI Class Initialized
INFO - 2024-02-06 07:01:48 --> Router Class Initialized
INFO - 2024-02-06 07:01:48 --> Output Class Initialized
INFO - 2024-02-06 07:01:48 --> Security Class Initialized
DEBUG - 2024-02-06 07:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 07:01:48 --> Input Class Initialized
INFO - 2024-02-06 07:01:48 --> Language Class Initialized
INFO - 2024-02-06 07:01:48 --> Loader Class Initialized
INFO - 2024-02-06 07:01:48 --> Helper loaded: url_helper
INFO - 2024-02-06 07:01:48 --> Helper loaded: file_helper
INFO - 2024-02-06 07:01:48 --> Helper loaded: html_helper
INFO - 2024-02-06 07:01:48 --> Helper loaded: text_helper
INFO - 2024-02-06 07:01:48 --> Helper loaded: form_helper
INFO - 2024-02-06 07:01:48 --> Helper loaded: lang_helper
INFO - 2024-02-06 07:01:48 --> Helper loaded: security_helper
INFO - 2024-02-06 07:01:48 --> Helper loaded: cookie_helper
INFO - 2024-02-06 07:01:48 --> Database Driver Class Initialized
INFO - 2024-02-06 07:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 07:01:48 --> Parser Class Initialized
INFO - 2024-02-06 07:01:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 07:01:48 --> Pagination Class Initialized
INFO - 2024-02-06 07:01:48 --> Form Validation Class Initialized
INFO - 2024-02-06 07:01:48 --> Controller Class Initialized
INFO - 2024-02-06 07:01:48 --> Model Class Initialized
DEBUG - 2024-02-06 07:01:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:01:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-06 07:01:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:01:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 07:01:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 07:01:48 --> Model Class Initialized
INFO - 2024-02-06 07:01:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 07:01:48 --> Final output sent to browser
DEBUG - 2024-02-06 07:01:48 --> Total execution time: 0.0298
ERROR - 2024-02-06 07:01:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 07:01:51 --> Config Class Initialized
INFO - 2024-02-06 07:01:51 --> Hooks Class Initialized
DEBUG - 2024-02-06 07:01:51 --> UTF-8 Support Enabled
INFO - 2024-02-06 07:01:51 --> Utf8 Class Initialized
INFO - 2024-02-06 07:01:51 --> URI Class Initialized
INFO - 2024-02-06 07:01:51 --> Router Class Initialized
INFO - 2024-02-06 07:01:51 --> Output Class Initialized
INFO - 2024-02-06 07:01:51 --> Security Class Initialized
DEBUG - 2024-02-06 07:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 07:01:51 --> Input Class Initialized
INFO - 2024-02-06 07:01:51 --> Language Class Initialized
INFO - 2024-02-06 07:01:51 --> Loader Class Initialized
INFO - 2024-02-06 07:01:51 --> Helper loaded: url_helper
INFO - 2024-02-06 07:01:51 --> Helper loaded: file_helper
INFO - 2024-02-06 07:01:51 --> Helper loaded: html_helper
INFO - 2024-02-06 07:01:51 --> Helper loaded: text_helper
INFO - 2024-02-06 07:01:51 --> Helper loaded: form_helper
INFO - 2024-02-06 07:01:51 --> Helper loaded: lang_helper
INFO - 2024-02-06 07:01:51 --> Helper loaded: security_helper
INFO - 2024-02-06 07:01:51 --> Helper loaded: cookie_helper
INFO - 2024-02-06 07:01:51 --> Database Driver Class Initialized
INFO - 2024-02-06 07:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 07:01:51 --> Parser Class Initialized
INFO - 2024-02-06 07:01:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 07:01:51 --> Pagination Class Initialized
INFO - 2024-02-06 07:01:51 --> Form Validation Class Initialized
INFO - 2024-02-06 07:01:51 --> Controller Class Initialized
INFO - 2024-02-06 07:01:51 --> Model Class Initialized
INFO - 2024-02-06 07:01:51 --> Model Class Initialized
INFO - 2024-02-06 07:01:52 --> Final output sent to browser
DEBUG - 2024-02-06 07:01:52 --> Total execution time: 0.1856
ERROR - 2024-02-06 07:01:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 07:01:56 --> Config Class Initialized
INFO - 2024-02-06 07:01:56 --> Hooks Class Initialized
DEBUG - 2024-02-06 07:01:56 --> UTF-8 Support Enabled
INFO - 2024-02-06 07:01:56 --> Utf8 Class Initialized
INFO - 2024-02-06 07:01:56 --> URI Class Initialized
INFO - 2024-02-06 07:01:56 --> Router Class Initialized
INFO - 2024-02-06 07:01:56 --> Output Class Initialized
INFO - 2024-02-06 07:01:56 --> Security Class Initialized
DEBUG - 2024-02-06 07:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 07:01:56 --> Input Class Initialized
INFO - 2024-02-06 07:01:56 --> Language Class Initialized
INFO - 2024-02-06 07:01:56 --> Loader Class Initialized
INFO - 2024-02-06 07:01:56 --> Helper loaded: url_helper
INFO - 2024-02-06 07:01:56 --> Helper loaded: file_helper
INFO - 2024-02-06 07:01:56 --> Helper loaded: html_helper
INFO - 2024-02-06 07:01:56 --> Helper loaded: text_helper
INFO - 2024-02-06 07:01:56 --> Helper loaded: form_helper
INFO - 2024-02-06 07:01:56 --> Helper loaded: lang_helper
INFO - 2024-02-06 07:01:56 --> Helper loaded: security_helper
INFO - 2024-02-06 07:01:56 --> Helper loaded: cookie_helper
INFO - 2024-02-06 07:01:56 --> Database Driver Class Initialized
INFO - 2024-02-06 07:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 07:01:56 --> Parser Class Initialized
INFO - 2024-02-06 07:01:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 07:01:56 --> Pagination Class Initialized
INFO - 2024-02-06 07:01:56 --> Form Validation Class Initialized
INFO - 2024-02-06 07:01:56 --> Controller Class Initialized
INFO - 2024-02-06 07:01:56 --> Model Class Initialized
DEBUG - 2024-02-06 07:01:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:01:56 --> Model Class Initialized
INFO - 2024-02-06 07:01:56 --> Final output sent to browser
DEBUG - 2024-02-06 07:01:56 --> Total execution time: 0.0158
ERROR - 2024-02-06 07:01:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 07:01:56 --> Config Class Initialized
INFO - 2024-02-06 07:01:56 --> Hooks Class Initialized
DEBUG - 2024-02-06 07:01:56 --> UTF-8 Support Enabled
INFO - 2024-02-06 07:01:56 --> Utf8 Class Initialized
INFO - 2024-02-06 07:01:56 --> URI Class Initialized
DEBUG - 2024-02-06 07:01:56 --> No URI present. Default controller set.
INFO - 2024-02-06 07:01:56 --> Router Class Initialized
INFO - 2024-02-06 07:01:56 --> Output Class Initialized
INFO - 2024-02-06 07:01:56 --> Security Class Initialized
DEBUG - 2024-02-06 07:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 07:01:56 --> Input Class Initialized
INFO - 2024-02-06 07:01:56 --> Language Class Initialized
INFO - 2024-02-06 07:01:56 --> Loader Class Initialized
INFO - 2024-02-06 07:01:56 --> Helper loaded: url_helper
INFO - 2024-02-06 07:01:56 --> Helper loaded: file_helper
INFO - 2024-02-06 07:01:56 --> Helper loaded: html_helper
INFO - 2024-02-06 07:01:56 --> Helper loaded: text_helper
INFO - 2024-02-06 07:01:56 --> Helper loaded: form_helper
INFO - 2024-02-06 07:01:56 --> Helper loaded: lang_helper
INFO - 2024-02-06 07:01:56 --> Helper loaded: security_helper
INFO - 2024-02-06 07:01:56 --> Helper loaded: cookie_helper
INFO - 2024-02-06 07:01:56 --> Database Driver Class Initialized
INFO - 2024-02-06 07:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 07:01:56 --> Parser Class Initialized
INFO - 2024-02-06 07:01:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 07:01:56 --> Pagination Class Initialized
INFO - 2024-02-06 07:01:56 --> Form Validation Class Initialized
INFO - 2024-02-06 07:01:56 --> Controller Class Initialized
INFO - 2024-02-06 07:01:56 --> Model Class Initialized
DEBUG - 2024-02-06 07:01:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:01:56 --> Model Class Initialized
DEBUG - 2024-02-06 07:01:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:01:56 --> Model Class Initialized
INFO - 2024-02-06 07:01:56 --> Model Class Initialized
INFO - 2024-02-06 07:01:56 --> Model Class Initialized
INFO - 2024-02-06 07:01:56 --> Model Class Initialized
DEBUG - 2024-02-06 07:01:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 07:01:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:01:56 --> Model Class Initialized
INFO - 2024-02-06 07:01:56 --> Model Class Initialized
INFO - 2024-02-06 07:01:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 07:01:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:01:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 07:01:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 07:01:56 --> Model Class Initialized
INFO - 2024-02-06 07:01:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 07:01:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 07:01:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 07:01:56 --> Final output sent to browser
DEBUG - 2024-02-06 07:01:56 --> Total execution time: 0.2108
ERROR - 2024-02-06 07:02:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 07:02:10 --> Config Class Initialized
INFO - 2024-02-06 07:02:10 --> Hooks Class Initialized
DEBUG - 2024-02-06 07:02:10 --> UTF-8 Support Enabled
INFO - 2024-02-06 07:02:10 --> Utf8 Class Initialized
INFO - 2024-02-06 07:02:10 --> URI Class Initialized
DEBUG - 2024-02-06 07:02:10 --> No URI present. Default controller set.
INFO - 2024-02-06 07:02:10 --> Router Class Initialized
INFO - 2024-02-06 07:02:10 --> Output Class Initialized
INFO - 2024-02-06 07:02:10 --> Security Class Initialized
DEBUG - 2024-02-06 07:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 07:02:10 --> Input Class Initialized
INFO - 2024-02-06 07:02:10 --> Language Class Initialized
INFO - 2024-02-06 07:02:10 --> Loader Class Initialized
INFO - 2024-02-06 07:02:10 --> Helper loaded: url_helper
INFO - 2024-02-06 07:02:10 --> Helper loaded: file_helper
INFO - 2024-02-06 07:02:10 --> Helper loaded: html_helper
INFO - 2024-02-06 07:02:10 --> Helper loaded: text_helper
INFO - 2024-02-06 07:02:10 --> Helper loaded: form_helper
INFO - 2024-02-06 07:02:10 --> Helper loaded: lang_helper
INFO - 2024-02-06 07:02:10 --> Helper loaded: security_helper
INFO - 2024-02-06 07:02:10 --> Helper loaded: cookie_helper
INFO - 2024-02-06 07:02:10 --> Database Driver Class Initialized
INFO - 2024-02-06 07:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 07:02:10 --> Parser Class Initialized
INFO - 2024-02-06 07:02:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 07:02:10 --> Pagination Class Initialized
INFO - 2024-02-06 07:02:10 --> Form Validation Class Initialized
INFO - 2024-02-06 07:02:10 --> Controller Class Initialized
INFO - 2024-02-06 07:02:10 --> Model Class Initialized
DEBUG - 2024-02-06 07:02:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:02:10 --> Model Class Initialized
DEBUG - 2024-02-06 07:02:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:02:10 --> Model Class Initialized
INFO - 2024-02-06 07:02:10 --> Model Class Initialized
INFO - 2024-02-06 07:02:10 --> Model Class Initialized
INFO - 2024-02-06 07:02:10 --> Model Class Initialized
DEBUG - 2024-02-06 07:02:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 07:02:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:02:10 --> Model Class Initialized
INFO - 2024-02-06 07:02:10 --> Model Class Initialized
INFO - 2024-02-06 07:02:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 07:02:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:02:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 07:02:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 07:02:10 --> Model Class Initialized
INFO - 2024-02-06 07:02:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 07:02:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 07:02:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 07:02:10 --> Final output sent to browser
DEBUG - 2024-02-06 07:02:10 --> Total execution time: 0.2132
ERROR - 2024-02-06 07:02:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 07:02:29 --> Config Class Initialized
INFO - 2024-02-06 07:02:29 --> Hooks Class Initialized
DEBUG - 2024-02-06 07:02:29 --> UTF-8 Support Enabled
INFO - 2024-02-06 07:02:29 --> Utf8 Class Initialized
INFO - 2024-02-06 07:02:29 --> URI Class Initialized
INFO - 2024-02-06 07:02:29 --> Router Class Initialized
INFO - 2024-02-06 07:02:29 --> Output Class Initialized
INFO - 2024-02-06 07:02:29 --> Security Class Initialized
DEBUG - 2024-02-06 07:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 07:02:29 --> Input Class Initialized
INFO - 2024-02-06 07:02:29 --> Language Class Initialized
INFO - 2024-02-06 07:02:29 --> Loader Class Initialized
INFO - 2024-02-06 07:02:29 --> Helper loaded: url_helper
INFO - 2024-02-06 07:02:29 --> Helper loaded: file_helper
INFO - 2024-02-06 07:02:29 --> Helper loaded: html_helper
INFO - 2024-02-06 07:02:29 --> Helper loaded: text_helper
INFO - 2024-02-06 07:02:29 --> Helper loaded: form_helper
INFO - 2024-02-06 07:02:29 --> Helper loaded: lang_helper
INFO - 2024-02-06 07:02:29 --> Helper loaded: security_helper
INFO - 2024-02-06 07:02:29 --> Helper loaded: cookie_helper
INFO - 2024-02-06 07:02:29 --> Database Driver Class Initialized
INFO - 2024-02-06 07:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 07:02:29 --> Parser Class Initialized
INFO - 2024-02-06 07:02:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 07:02:29 --> Pagination Class Initialized
INFO - 2024-02-06 07:02:29 --> Form Validation Class Initialized
INFO - 2024-02-06 07:02:29 --> Controller Class Initialized
INFO - 2024-02-06 07:02:29 --> Model Class Initialized
INFO - 2024-02-06 07:02:29 --> Model Class Initialized
INFO - 2024-02-06 07:02:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2024-02-06 07:02:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 07:02:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 07:02:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 07:02:29 --> Model Class Initialized
INFO - 2024-02-06 07:02:29 --> Model Class Initialized
INFO - 2024-02-06 07:02:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 07:02:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 07:02:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 07:02:29 --> Final output sent to browser
DEBUG - 2024-02-06 07:02:29 --> Total execution time: 0.1809
ERROR - 2024-02-06 07:02:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 07:02:52 --> Config Class Initialized
INFO - 2024-02-06 07:02:52 --> Hooks Class Initialized
DEBUG - 2024-02-06 07:02:52 --> UTF-8 Support Enabled
INFO - 2024-02-06 07:02:52 --> Utf8 Class Initialized
INFO - 2024-02-06 07:02:52 --> URI Class Initialized
INFO - 2024-02-06 07:02:52 --> Router Class Initialized
INFO - 2024-02-06 07:02:52 --> Output Class Initialized
INFO - 2024-02-06 07:02:52 --> Security Class Initialized
DEBUG - 2024-02-06 07:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 07:02:52 --> Input Class Initialized
INFO - 2024-02-06 07:02:52 --> Language Class Initialized
INFO - 2024-02-06 07:02:52 --> Loader Class Initialized
INFO - 2024-02-06 07:02:52 --> Helper loaded: url_helper
INFO - 2024-02-06 07:02:52 --> Helper loaded: file_helper
INFO - 2024-02-06 07:02:52 --> Helper loaded: html_helper
INFO - 2024-02-06 07:02:52 --> Helper loaded: text_helper
INFO - 2024-02-06 07:02:52 --> Helper loaded: form_helper
INFO - 2024-02-06 07:02:52 --> Helper loaded: lang_helper
INFO - 2024-02-06 07:02:52 --> Helper loaded: security_helper
INFO - 2024-02-06 07:02:52 --> Helper loaded: cookie_helper
INFO - 2024-02-06 07:02:52 --> Database Driver Class Initialized
INFO - 2024-02-06 07:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 07:02:52 --> Parser Class Initialized
INFO - 2024-02-06 07:02:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 07:02:52 --> Pagination Class Initialized
INFO - 2024-02-06 07:02:52 --> Form Validation Class Initialized
INFO - 2024-02-06 07:02:52 --> Controller Class Initialized
INFO - 2024-02-06 07:02:52 --> Model Class Initialized
INFO - 2024-02-06 07:02:52 --> Model Class Initialized
INFO - 2024-02-06 07:02:52 --> Final output sent to browser
DEBUG - 2024-02-06 07:02:52 --> Total execution time: 0.1875
ERROR - 2024-02-06 08:27:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 08:27:55 --> Config Class Initialized
INFO - 2024-02-06 08:27:55 --> Hooks Class Initialized
DEBUG - 2024-02-06 08:27:55 --> UTF-8 Support Enabled
INFO - 2024-02-06 08:27:55 --> Utf8 Class Initialized
INFO - 2024-02-06 08:27:55 --> URI Class Initialized
DEBUG - 2024-02-06 08:27:55 --> No URI present. Default controller set.
INFO - 2024-02-06 08:27:55 --> Router Class Initialized
INFO - 2024-02-06 08:27:55 --> Output Class Initialized
INFO - 2024-02-06 08:27:55 --> Security Class Initialized
DEBUG - 2024-02-06 08:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 08:27:55 --> Input Class Initialized
INFO - 2024-02-06 08:27:55 --> Language Class Initialized
INFO - 2024-02-06 08:27:55 --> Loader Class Initialized
INFO - 2024-02-06 08:27:55 --> Helper loaded: url_helper
INFO - 2024-02-06 08:27:55 --> Helper loaded: file_helper
INFO - 2024-02-06 08:27:55 --> Helper loaded: html_helper
INFO - 2024-02-06 08:27:55 --> Helper loaded: text_helper
INFO - 2024-02-06 08:27:55 --> Helper loaded: form_helper
INFO - 2024-02-06 08:27:55 --> Helper loaded: lang_helper
INFO - 2024-02-06 08:27:55 --> Helper loaded: security_helper
INFO - 2024-02-06 08:27:55 --> Helper loaded: cookie_helper
INFO - 2024-02-06 08:27:55 --> Database Driver Class Initialized
INFO - 2024-02-06 08:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 08:27:55 --> Parser Class Initialized
INFO - 2024-02-06 08:27:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 08:27:55 --> Pagination Class Initialized
INFO - 2024-02-06 08:27:55 --> Form Validation Class Initialized
INFO - 2024-02-06 08:27:55 --> Controller Class Initialized
INFO - 2024-02-06 08:27:55 --> Model Class Initialized
DEBUG - 2024-02-06 08:27:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-06 08:27:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 08:27:56 --> Config Class Initialized
INFO - 2024-02-06 08:27:56 --> Hooks Class Initialized
DEBUG - 2024-02-06 08:27:56 --> UTF-8 Support Enabled
INFO - 2024-02-06 08:27:56 --> Utf8 Class Initialized
INFO - 2024-02-06 08:27:56 --> URI Class Initialized
INFO - 2024-02-06 08:27:56 --> Router Class Initialized
INFO - 2024-02-06 08:27:56 --> Output Class Initialized
INFO - 2024-02-06 08:27:56 --> Security Class Initialized
DEBUG - 2024-02-06 08:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 08:27:56 --> Input Class Initialized
INFO - 2024-02-06 08:27:56 --> Language Class Initialized
INFO - 2024-02-06 08:27:56 --> Loader Class Initialized
INFO - 2024-02-06 08:27:56 --> Helper loaded: url_helper
INFO - 2024-02-06 08:27:56 --> Helper loaded: file_helper
INFO - 2024-02-06 08:27:56 --> Helper loaded: html_helper
INFO - 2024-02-06 08:27:56 --> Helper loaded: text_helper
INFO - 2024-02-06 08:27:56 --> Helper loaded: form_helper
INFO - 2024-02-06 08:27:56 --> Helper loaded: lang_helper
INFO - 2024-02-06 08:27:56 --> Helper loaded: security_helper
INFO - 2024-02-06 08:27:56 --> Helper loaded: cookie_helper
INFO - 2024-02-06 08:27:56 --> Database Driver Class Initialized
INFO - 2024-02-06 08:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 08:27:56 --> Parser Class Initialized
INFO - 2024-02-06 08:27:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 08:27:56 --> Pagination Class Initialized
INFO - 2024-02-06 08:27:56 --> Form Validation Class Initialized
INFO - 2024-02-06 08:27:56 --> Controller Class Initialized
INFO - 2024-02-06 08:27:56 --> Model Class Initialized
DEBUG - 2024-02-06 08:27:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:27:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-06 08:27:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:27:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 08:27:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 08:27:56 --> Model Class Initialized
INFO - 2024-02-06 08:27:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 08:27:56 --> Final output sent to browser
DEBUG - 2024-02-06 08:27:56 --> Total execution time: 0.0338
ERROR - 2024-02-06 08:31:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 08:31:36 --> Config Class Initialized
INFO - 2024-02-06 08:31:36 --> Hooks Class Initialized
DEBUG - 2024-02-06 08:31:36 --> UTF-8 Support Enabled
INFO - 2024-02-06 08:31:36 --> Utf8 Class Initialized
INFO - 2024-02-06 08:31:36 --> URI Class Initialized
INFO - 2024-02-06 08:31:36 --> Router Class Initialized
INFO - 2024-02-06 08:31:36 --> Output Class Initialized
INFO - 2024-02-06 08:31:36 --> Security Class Initialized
DEBUG - 2024-02-06 08:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 08:31:36 --> Input Class Initialized
INFO - 2024-02-06 08:31:36 --> Language Class Initialized
INFO - 2024-02-06 08:31:36 --> Loader Class Initialized
INFO - 2024-02-06 08:31:36 --> Helper loaded: url_helper
INFO - 2024-02-06 08:31:36 --> Helper loaded: file_helper
INFO - 2024-02-06 08:31:36 --> Helper loaded: html_helper
INFO - 2024-02-06 08:31:36 --> Helper loaded: text_helper
INFO - 2024-02-06 08:31:36 --> Helper loaded: form_helper
INFO - 2024-02-06 08:31:36 --> Helper loaded: lang_helper
INFO - 2024-02-06 08:31:36 --> Helper loaded: security_helper
INFO - 2024-02-06 08:31:36 --> Helper loaded: cookie_helper
INFO - 2024-02-06 08:31:36 --> Database Driver Class Initialized
INFO - 2024-02-06 08:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 08:31:36 --> Parser Class Initialized
INFO - 2024-02-06 08:31:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 08:31:36 --> Pagination Class Initialized
INFO - 2024-02-06 08:31:36 --> Form Validation Class Initialized
INFO - 2024-02-06 08:31:36 --> Controller Class Initialized
INFO - 2024-02-06 08:31:36 --> Model Class Initialized
DEBUG - 2024-02-06 08:31:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:31:36 --> Model Class Initialized
INFO - 2024-02-06 08:31:36 --> Final output sent to browser
DEBUG - 2024-02-06 08:31:36 --> Total execution time: 0.0283
ERROR - 2024-02-06 08:31:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 08:31:36 --> Config Class Initialized
INFO - 2024-02-06 08:31:36 --> Hooks Class Initialized
DEBUG - 2024-02-06 08:31:36 --> UTF-8 Support Enabled
INFO - 2024-02-06 08:31:36 --> Utf8 Class Initialized
INFO - 2024-02-06 08:31:36 --> URI Class Initialized
DEBUG - 2024-02-06 08:31:36 --> No URI present. Default controller set.
INFO - 2024-02-06 08:31:36 --> Router Class Initialized
INFO - 2024-02-06 08:31:36 --> Output Class Initialized
INFO - 2024-02-06 08:31:36 --> Security Class Initialized
DEBUG - 2024-02-06 08:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 08:31:36 --> Input Class Initialized
INFO - 2024-02-06 08:31:36 --> Language Class Initialized
INFO - 2024-02-06 08:31:36 --> Loader Class Initialized
INFO - 2024-02-06 08:31:36 --> Helper loaded: url_helper
INFO - 2024-02-06 08:31:36 --> Helper loaded: file_helper
INFO - 2024-02-06 08:31:36 --> Helper loaded: html_helper
INFO - 2024-02-06 08:31:36 --> Helper loaded: text_helper
INFO - 2024-02-06 08:31:36 --> Helper loaded: form_helper
INFO - 2024-02-06 08:31:36 --> Helper loaded: lang_helper
INFO - 2024-02-06 08:31:36 --> Helper loaded: security_helper
INFO - 2024-02-06 08:31:36 --> Helper loaded: cookie_helper
INFO - 2024-02-06 08:31:36 --> Database Driver Class Initialized
INFO - 2024-02-06 08:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 08:31:36 --> Parser Class Initialized
INFO - 2024-02-06 08:31:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 08:31:36 --> Pagination Class Initialized
INFO - 2024-02-06 08:31:36 --> Form Validation Class Initialized
INFO - 2024-02-06 08:31:36 --> Controller Class Initialized
INFO - 2024-02-06 08:31:36 --> Model Class Initialized
DEBUG - 2024-02-06 08:31:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:31:36 --> Model Class Initialized
DEBUG - 2024-02-06 08:31:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:31:36 --> Model Class Initialized
INFO - 2024-02-06 08:31:36 --> Model Class Initialized
INFO - 2024-02-06 08:31:36 --> Model Class Initialized
INFO - 2024-02-06 08:31:36 --> Model Class Initialized
DEBUG - 2024-02-06 08:31:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 08:31:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:31:36 --> Model Class Initialized
INFO - 2024-02-06 08:31:36 --> Model Class Initialized
INFO - 2024-02-06 08:31:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 08:31:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:31:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 08:31:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 08:31:36 --> Model Class Initialized
INFO - 2024-02-06 08:31:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 08:31:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 08:31:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 08:31:36 --> Final output sent to browser
DEBUG - 2024-02-06 08:31:36 --> Total execution time: 0.3391
ERROR - 2024-02-06 08:31:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 08:31:45 --> Config Class Initialized
INFO - 2024-02-06 08:31:45 --> Hooks Class Initialized
DEBUG - 2024-02-06 08:31:45 --> UTF-8 Support Enabled
INFO - 2024-02-06 08:31:45 --> Utf8 Class Initialized
INFO - 2024-02-06 08:31:45 --> URI Class Initialized
INFO - 2024-02-06 08:31:45 --> Router Class Initialized
INFO - 2024-02-06 08:31:45 --> Output Class Initialized
INFO - 2024-02-06 08:31:45 --> Security Class Initialized
DEBUG - 2024-02-06 08:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 08:31:45 --> Input Class Initialized
INFO - 2024-02-06 08:31:45 --> Language Class Initialized
INFO - 2024-02-06 08:31:45 --> Loader Class Initialized
INFO - 2024-02-06 08:31:45 --> Helper loaded: url_helper
INFO - 2024-02-06 08:31:45 --> Helper loaded: file_helper
INFO - 2024-02-06 08:31:45 --> Helper loaded: html_helper
INFO - 2024-02-06 08:31:45 --> Helper loaded: text_helper
INFO - 2024-02-06 08:31:45 --> Helper loaded: form_helper
INFO - 2024-02-06 08:31:45 --> Helper loaded: lang_helper
INFO - 2024-02-06 08:31:45 --> Helper loaded: security_helper
INFO - 2024-02-06 08:31:45 --> Helper loaded: cookie_helper
INFO - 2024-02-06 08:31:45 --> Database Driver Class Initialized
INFO - 2024-02-06 08:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 08:31:45 --> Parser Class Initialized
INFO - 2024-02-06 08:31:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 08:31:45 --> Pagination Class Initialized
INFO - 2024-02-06 08:31:45 --> Form Validation Class Initialized
INFO - 2024-02-06 08:31:45 --> Controller Class Initialized
DEBUG - 2024-02-06 08:31:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 08:31:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:31:45 --> Model Class Initialized
DEBUG - 2024-02-06 08:31:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:31:45 --> Model Class Initialized
INFO - 2024-02-06 08:31:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-02-06 08:31:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:31:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 08:31:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 08:31:45 --> Model Class Initialized
INFO - 2024-02-06 08:31:45 --> Model Class Initialized
INFO - 2024-02-06 08:31:45 --> Model Class Initialized
INFO - 2024-02-06 08:31:45 --> Model Class Initialized
INFO - 2024-02-06 08:31:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 08:31:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 08:31:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 08:31:45 --> Final output sent to browser
DEBUG - 2024-02-06 08:31:45 --> Total execution time: 0.1835
ERROR - 2024-02-06 08:38:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 08:38:14 --> Config Class Initialized
INFO - 2024-02-06 08:38:14 --> Hooks Class Initialized
DEBUG - 2024-02-06 08:38:14 --> UTF-8 Support Enabled
INFO - 2024-02-06 08:38:14 --> Utf8 Class Initialized
INFO - 2024-02-06 08:38:14 --> URI Class Initialized
INFO - 2024-02-06 08:38:14 --> Router Class Initialized
INFO - 2024-02-06 08:38:14 --> Output Class Initialized
INFO - 2024-02-06 08:38:14 --> Security Class Initialized
DEBUG - 2024-02-06 08:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 08:38:14 --> Input Class Initialized
INFO - 2024-02-06 08:38:14 --> Language Class Initialized
INFO - 2024-02-06 08:38:14 --> Loader Class Initialized
INFO - 2024-02-06 08:38:14 --> Helper loaded: url_helper
INFO - 2024-02-06 08:38:14 --> Helper loaded: file_helper
INFO - 2024-02-06 08:38:14 --> Helper loaded: html_helper
INFO - 2024-02-06 08:38:14 --> Helper loaded: text_helper
INFO - 2024-02-06 08:38:14 --> Helper loaded: form_helper
INFO - 2024-02-06 08:38:14 --> Helper loaded: lang_helper
INFO - 2024-02-06 08:38:14 --> Helper loaded: security_helper
INFO - 2024-02-06 08:38:14 --> Helper loaded: cookie_helper
INFO - 2024-02-06 08:38:14 --> Database Driver Class Initialized
INFO - 2024-02-06 08:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 08:38:14 --> Parser Class Initialized
INFO - 2024-02-06 08:38:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 08:38:14 --> Pagination Class Initialized
INFO - 2024-02-06 08:38:14 --> Form Validation Class Initialized
INFO - 2024-02-06 08:38:14 --> Controller Class Initialized
DEBUG - 2024-02-06 08:38:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 08:38:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:38:14 --> Model Class Initialized
DEBUG - 2024-02-06 08:38:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:38:14 --> Model Class Initialized
DEBUG - 2024-02-06 08:38:14 --> Auth class already loaded. Second attempt ignored.
ERROR - 2024-02-06 08:38:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 08:38:14 --> Config Class Initialized
INFO - 2024-02-06 08:38:14 --> Hooks Class Initialized
DEBUG - 2024-02-06 08:38:14 --> UTF-8 Support Enabled
INFO - 2024-02-06 08:38:14 --> Utf8 Class Initialized
INFO - 2024-02-06 08:38:14 --> URI Class Initialized
INFO - 2024-02-06 08:38:14 --> Router Class Initialized
INFO - 2024-02-06 08:38:14 --> Output Class Initialized
INFO - 2024-02-06 08:38:14 --> Security Class Initialized
DEBUG - 2024-02-06 08:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 08:38:14 --> Input Class Initialized
INFO - 2024-02-06 08:38:14 --> Language Class Initialized
INFO - 2024-02-06 08:38:14 --> Loader Class Initialized
INFO - 2024-02-06 08:38:14 --> Helper loaded: url_helper
INFO - 2024-02-06 08:38:14 --> Helper loaded: file_helper
INFO - 2024-02-06 08:38:14 --> Helper loaded: html_helper
INFO - 2024-02-06 08:38:14 --> Helper loaded: text_helper
INFO - 2024-02-06 08:38:14 --> Helper loaded: form_helper
INFO - 2024-02-06 08:38:14 --> Helper loaded: lang_helper
INFO - 2024-02-06 08:38:14 --> Helper loaded: security_helper
INFO - 2024-02-06 08:38:14 --> Helper loaded: cookie_helper
INFO - 2024-02-06 08:38:14 --> Database Driver Class Initialized
INFO - 2024-02-06 08:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 08:38:14 --> Parser Class Initialized
INFO - 2024-02-06 08:38:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 08:38:14 --> Pagination Class Initialized
INFO - 2024-02-06 08:38:14 --> Form Validation Class Initialized
INFO - 2024-02-06 08:38:14 --> Controller Class Initialized
DEBUG - 2024-02-06 08:38:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 08:38:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:38:14 --> Model Class Initialized
DEBUG - 2024-02-06 08:38:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:38:14 --> Model Class Initialized
INFO - 2024-02-06 08:38:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-02-06 08:38:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:38:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 08:38:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 08:38:14 --> Model Class Initialized
INFO - 2024-02-06 08:38:14 --> Model Class Initialized
INFO - 2024-02-06 08:38:14 --> Model Class Initialized
INFO - 2024-02-06 08:38:14 --> Model Class Initialized
INFO - 2024-02-06 08:38:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 08:38:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 08:38:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 08:38:14 --> Final output sent to browser
DEBUG - 2024-02-06 08:38:14 --> Total execution time: 0.1643
ERROR - 2024-02-06 08:38:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 08:38:41 --> Config Class Initialized
INFO - 2024-02-06 08:38:41 --> Hooks Class Initialized
DEBUG - 2024-02-06 08:38:41 --> UTF-8 Support Enabled
INFO - 2024-02-06 08:38:41 --> Utf8 Class Initialized
INFO - 2024-02-06 08:38:41 --> URI Class Initialized
INFO - 2024-02-06 08:38:41 --> Router Class Initialized
INFO - 2024-02-06 08:38:41 --> Output Class Initialized
INFO - 2024-02-06 08:38:41 --> Security Class Initialized
DEBUG - 2024-02-06 08:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 08:38:41 --> Input Class Initialized
INFO - 2024-02-06 08:38:41 --> Language Class Initialized
INFO - 2024-02-06 08:38:41 --> Loader Class Initialized
INFO - 2024-02-06 08:38:41 --> Helper loaded: url_helper
INFO - 2024-02-06 08:38:41 --> Helper loaded: file_helper
INFO - 2024-02-06 08:38:41 --> Helper loaded: html_helper
INFO - 2024-02-06 08:38:41 --> Helper loaded: text_helper
INFO - 2024-02-06 08:38:41 --> Helper loaded: form_helper
INFO - 2024-02-06 08:38:41 --> Helper loaded: lang_helper
INFO - 2024-02-06 08:38:41 --> Helper loaded: security_helper
INFO - 2024-02-06 08:38:41 --> Helper loaded: cookie_helper
INFO - 2024-02-06 08:38:41 --> Database Driver Class Initialized
INFO - 2024-02-06 08:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 08:38:41 --> Parser Class Initialized
INFO - 2024-02-06 08:38:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 08:38:41 --> Pagination Class Initialized
INFO - 2024-02-06 08:38:41 --> Form Validation Class Initialized
INFO - 2024-02-06 08:38:41 --> Controller Class Initialized
DEBUG - 2024-02-06 08:38:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 08:38:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:38:41 --> Model Class Initialized
DEBUG - 2024-02-06 08:38:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:38:41 --> Model Class Initialized
INFO - 2024-02-06 08:38:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-02-06 08:38:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:38:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 08:38:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 08:38:41 --> Model Class Initialized
INFO - 2024-02-06 08:38:41 --> Model Class Initialized
INFO - 2024-02-06 08:38:41 --> Model Class Initialized
INFO - 2024-02-06 08:38:41 --> Model Class Initialized
INFO - 2024-02-06 08:38:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 08:38:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 08:38:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 08:38:41 --> Final output sent to browser
DEBUG - 2024-02-06 08:38:41 --> Total execution time: 0.1829
ERROR - 2024-02-06 08:38:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 08:38:42 --> Config Class Initialized
INFO - 2024-02-06 08:38:42 --> Hooks Class Initialized
DEBUG - 2024-02-06 08:38:42 --> UTF-8 Support Enabled
INFO - 2024-02-06 08:38:42 --> Utf8 Class Initialized
INFO - 2024-02-06 08:38:42 --> URI Class Initialized
DEBUG - 2024-02-06 08:38:42 --> No URI present. Default controller set.
INFO - 2024-02-06 08:38:42 --> Router Class Initialized
INFO - 2024-02-06 08:38:42 --> Output Class Initialized
INFO - 2024-02-06 08:38:42 --> Security Class Initialized
DEBUG - 2024-02-06 08:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 08:38:42 --> Input Class Initialized
INFO - 2024-02-06 08:38:42 --> Language Class Initialized
INFO - 2024-02-06 08:38:42 --> Loader Class Initialized
INFO - 2024-02-06 08:38:42 --> Helper loaded: url_helper
INFO - 2024-02-06 08:38:42 --> Helper loaded: file_helper
INFO - 2024-02-06 08:38:42 --> Helper loaded: html_helper
INFO - 2024-02-06 08:38:42 --> Helper loaded: text_helper
INFO - 2024-02-06 08:38:42 --> Helper loaded: form_helper
INFO - 2024-02-06 08:38:42 --> Helper loaded: lang_helper
INFO - 2024-02-06 08:38:42 --> Helper loaded: security_helper
INFO - 2024-02-06 08:38:42 --> Helper loaded: cookie_helper
INFO - 2024-02-06 08:38:42 --> Database Driver Class Initialized
INFO - 2024-02-06 08:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 08:38:42 --> Parser Class Initialized
INFO - 2024-02-06 08:38:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 08:38:42 --> Pagination Class Initialized
INFO - 2024-02-06 08:38:42 --> Form Validation Class Initialized
INFO - 2024-02-06 08:38:42 --> Controller Class Initialized
INFO - 2024-02-06 08:38:42 --> Model Class Initialized
DEBUG - 2024-02-06 08:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:38:42 --> Model Class Initialized
DEBUG - 2024-02-06 08:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:38:42 --> Model Class Initialized
INFO - 2024-02-06 08:38:42 --> Model Class Initialized
INFO - 2024-02-06 08:38:42 --> Model Class Initialized
INFO - 2024-02-06 08:38:42 --> Model Class Initialized
DEBUG - 2024-02-06 08:38:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 08:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:38:42 --> Model Class Initialized
INFO - 2024-02-06 08:38:42 --> Model Class Initialized
INFO - 2024-02-06 08:38:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 08:38:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:38:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 08:38:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 08:38:42 --> Model Class Initialized
INFO - 2024-02-06 08:38:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 08:38:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 08:38:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 08:38:42 --> Final output sent to browser
DEBUG - 2024-02-06 08:38:42 --> Total execution time: 0.2202
ERROR - 2024-02-06 08:38:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 08:38:54 --> Config Class Initialized
INFO - 2024-02-06 08:38:54 --> Hooks Class Initialized
DEBUG - 2024-02-06 08:38:54 --> UTF-8 Support Enabled
INFO - 2024-02-06 08:38:54 --> Utf8 Class Initialized
INFO - 2024-02-06 08:38:54 --> URI Class Initialized
INFO - 2024-02-06 08:38:54 --> Router Class Initialized
INFO - 2024-02-06 08:38:54 --> Output Class Initialized
INFO - 2024-02-06 08:38:54 --> Security Class Initialized
DEBUG - 2024-02-06 08:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 08:38:54 --> Input Class Initialized
INFO - 2024-02-06 08:38:54 --> Language Class Initialized
INFO - 2024-02-06 08:38:54 --> Loader Class Initialized
INFO - 2024-02-06 08:38:54 --> Helper loaded: url_helper
INFO - 2024-02-06 08:38:54 --> Helper loaded: file_helper
INFO - 2024-02-06 08:38:54 --> Helper loaded: html_helper
INFO - 2024-02-06 08:38:54 --> Helper loaded: text_helper
INFO - 2024-02-06 08:38:54 --> Helper loaded: form_helper
INFO - 2024-02-06 08:38:54 --> Helper loaded: lang_helper
INFO - 2024-02-06 08:38:54 --> Helper loaded: security_helper
INFO - 2024-02-06 08:38:54 --> Helper loaded: cookie_helper
INFO - 2024-02-06 08:38:54 --> Database Driver Class Initialized
INFO - 2024-02-06 08:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 08:38:54 --> Parser Class Initialized
INFO - 2024-02-06 08:38:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 08:38:54 --> Pagination Class Initialized
INFO - 2024-02-06 08:38:54 --> Form Validation Class Initialized
INFO - 2024-02-06 08:38:54 --> Controller Class Initialized
INFO - 2024-02-06 08:38:54 --> Model Class Initialized
DEBUG - 2024-02-06 08:38:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:38:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-06 08:38:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:38:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 08:38:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 08:38:54 --> Model Class Initialized
INFO - 2024-02-06 08:38:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 08:38:54 --> Final output sent to browser
DEBUG - 2024-02-06 08:38:54 --> Total execution time: 0.0278
ERROR - 2024-02-06 08:38:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 08:38:55 --> Config Class Initialized
INFO - 2024-02-06 08:38:55 --> Hooks Class Initialized
DEBUG - 2024-02-06 08:38:55 --> UTF-8 Support Enabled
INFO - 2024-02-06 08:38:55 --> Utf8 Class Initialized
INFO - 2024-02-06 08:38:55 --> URI Class Initialized
INFO - 2024-02-06 08:38:55 --> Router Class Initialized
INFO - 2024-02-06 08:38:55 --> Output Class Initialized
INFO - 2024-02-06 08:38:55 --> Security Class Initialized
DEBUG - 2024-02-06 08:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 08:38:55 --> Input Class Initialized
INFO - 2024-02-06 08:38:55 --> Language Class Initialized
INFO - 2024-02-06 08:38:55 --> Loader Class Initialized
INFO - 2024-02-06 08:38:55 --> Helper loaded: url_helper
INFO - 2024-02-06 08:38:55 --> Helper loaded: file_helper
INFO - 2024-02-06 08:38:55 --> Helper loaded: html_helper
INFO - 2024-02-06 08:38:55 --> Helper loaded: text_helper
INFO - 2024-02-06 08:38:55 --> Helper loaded: form_helper
INFO - 2024-02-06 08:38:55 --> Helper loaded: lang_helper
INFO - 2024-02-06 08:38:55 --> Helper loaded: security_helper
INFO - 2024-02-06 08:38:55 --> Helper loaded: cookie_helper
INFO - 2024-02-06 08:38:55 --> Database Driver Class Initialized
INFO - 2024-02-06 08:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 08:38:55 --> Parser Class Initialized
INFO - 2024-02-06 08:38:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 08:38:55 --> Pagination Class Initialized
INFO - 2024-02-06 08:38:55 --> Form Validation Class Initialized
INFO - 2024-02-06 08:38:55 --> Controller Class Initialized
INFO - 2024-02-06 08:38:55 --> Model Class Initialized
DEBUG - 2024-02-06 08:38:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:38:55 --> Model Class Initialized
DEBUG - 2024-02-06 08:38:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:38:55 --> Model Class Initialized
INFO - 2024-02-06 08:38:55 --> Model Class Initialized
INFO - 2024-02-06 08:38:55 --> Model Class Initialized
INFO - 2024-02-06 08:38:55 --> Model Class Initialized
DEBUG - 2024-02-06 08:38:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 08:38:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:38:55 --> Model Class Initialized
INFO - 2024-02-06 08:38:55 --> Model Class Initialized
INFO - 2024-02-06 08:38:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 08:38:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:38:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 08:38:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 08:38:55 --> Model Class Initialized
INFO - 2024-02-06 08:38:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 08:38:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 08:38:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 08:38:55 --> Final output sent to browser
DEBUG - 2024-02-06 08:38:55 --> Total execution time: 0.2256
ERROR - 2024-02-06 08:54:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 08:54:50 --> Config Class Initialized
INFO - 2024-02-06 08:54:50 --> Hooks Class Initialized
DEBUG - 2024-02-06 08:54:50 --> UTF-8 Support Enabled
INFO - 2024-02-06 08:54:50 --> Utf8 Class Initialized
INFO - 2024-02-06 08:54:50 --> URI Class Initialized
DEBUG - 2024-02-06 08:54:50 --> No URI present. Default controller set.
INFO - 2024-02-06 08:54:50 --> Router Class Initialized
INFO - 2024-02-06 08:54:50 --> Output Class Initialized
INFO - 2024-02-06 08:54:50 --> Security Class Initialized
DEBUG - 2024-02-06 08:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 08:54:50 --> Input Class Initialized
INFO - 2024-02-06 08:54:50 --> Language Class Initialized
INFO - 2024-02-06 08:54:50 --> Loader Class Initialized
INFO - 2024-02-06 08:54:50 --> Helper loaded: url_helper
INFO - 2024-02-06 08:54:50 --> Helper loaded: file_helper
INFO - 2024-02-06 08:54:50 --> Helper loaded: html_helper
INFO - 2024-02-06 08:54:50 --> Helper loaded: text_helper
INFO - 2024-02-06 08:54:50 --> Helper loaded: form_helper
INFO - 2024-02-06 08:54:50 --> Helper loaded: lang_helper
INFO - 2024-02-06 08:54:50 --> Helper loaded: security_helper
INFO - 2024-02-06 08:54:50 --> Helper loaded: cookie_helper
INFO - 2024-02-06 08:54:50 --> Database Driver Class Initialized
INFO - 2024-02-06 08:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 08:54:50 --> Parser Class Initialized
INFO - 2024-02-06 08:54:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 08:54:50 --> Pagination Class Initialized
INFO - 2024-02-06 08:54:50 --> Form Validation Class Initialized
INFO - 2024-02-06 08:54:50 --> Controller Class Initialized
INFO - 2024-02-06 08:54:50 --> Model Class Initialized
DEBUG - 2024-02-06 08:54:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:54:50 --> Model Class Initialized
DEBUG - 2024-02-06 08:54:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:54:50 --> Model Class Initialized
INFO - 2024-02-06 08:54:50 --> Model Class Initialized
INFO - 2024-02-06 08:54:50 --> Model Class Initialized
INFO - 2024-02-06 08:54:50 --> Model Class Initialized
DEBUG - 2024-02-06 08:54:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 08:54:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:54:50 --> Model Class Initialized
INFO - 2024-02-06 08:54:50 --> Model Class Initialized
INFO - 2024-02-06 08:54:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 08:54:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:54:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 08:54:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 08:54:50 --> Model Class Initialized
INFO - 2024-02-06 08:54:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 08:54:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 08:54:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 08:54:50 --> Final output sent to browser
DEBUG - 2024-02-06 08:54:50 --> Total execution time: 0.2236
ERROR - 2024-02-06 08:54:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 08:54:56 --> Config Class Initialized
INFO - 2024-02-06 08:54:56 --> Hooks Class Initialized
DEBUG - 2024-02-06 08:54:56 --> UTF-8 Support Enabled
INFO - 2024-02-06 08:54:56 --> Utf8 Class Initialized
INFO - 2024-02-06 08:54:56 --> URI Class Initialized
INFO - 2024-02-06 08:54:56 --> Router Class Initialized
INFO - 2024-02-06 08:54:56 --> Output Class Initialized
INFO - 2024-02-06 08:54:56 --> Security Class Initialized
DEBUG - 2024-02-06 08:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 08:54:56 --> Input Class Initialized
INFO - 2024-02-06 08:54:56 --> Language Class Initialized
INFO - 2024-02-06 08:54:56 --> Loader Class Initialized
INFO - 2024-02-06 08:54:56 --> Helper loaded: url_helper
INFO - 2024-02-06 08:54:56 --> Helper loaded: file_helper
INFO - 2024-02-06 08:54:56 --> Helper loaded: html_helper
INFO - 2024-02-06 08:54:56 --> Helper loaded: text_helper
INFO - 2024-02-06 08:54:56 --> Helper loaded: form_helper
INFO - 2024-02-06 08:54:56 --> Helper loaded: lang_helper
INFO - 2024-02-06 08:54:56 --> Helper loaded: security_helper
INFO - 2024-02-06 08:54:56 --> Helper loaded: cookie_helper
INFO - 2024-02-06 08:54:56 --> Database Driver Class Initialized
INFO - 2024-02-06 08:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 08:54:56 --> Parser Class Initialized
INFO - 2024-02-06 08:54:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 08:54:56 --> Pagination Class Initialized
INFO - 2024-02-06 08:54:56 --> Form Validation Class Initialized
INFO - 2024-02-06 08:54:56 --> Controller Class Initialized
DEBUG - 2024-02-06 08:54:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 08:54:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:54:56 --> Model Class Initialized
DEBUG - 2024-02-06 08:54:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:54:56 --> Model Class Initialized
INFO - 2024-02-06 08:54:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-02-06 08:54:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 08:54:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 08:54:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 08:54:56 --> Model Class Initialized
INFO - 2024-02-06 08:54:56 --> Model Class Initialized
INFO - 2024-02-06 08:54:56 --> Model Class Initialized
INFO - 2024-02-06 08:54:56 --> Model Class Initialized
INFO - 2024-02-06 08:54:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 08:54:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 08:54:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 08:54:56 --> Final output sent to browser
DEBUG - 2024-02-06 08:54:56 --> Total execution time: 0.1664
ERROR - 2024-02-06 09:00:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 09:00:24 --> Config Class Initialized
INFO - 2024-02-06 09:00:24 --> Hooks Class Initialized
DEBUG - 2024-02-06 09:00:24 --> UTF-8 Support Enabled
INFO - 2024-02-06 09:00:24 --> Utf8 Class Initialized
INFO - 2024-02-06 09:00:24 --> URI Class Initialized
INFO - 2024-02-06 09:00:24 --> Router Class Initialized
INFO - 2024-02-06 09:00:24 --> Output Class Initialized
INFO - 2024-02-06 09:00:24 --> Security Class Initialized
DEBUG - 2024-02-06 09:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 09:00:24 --> Input Class Initialized
INFO - 2024-02-06 09:00:24 --> Language Class Initialized
INFO - 2024-02-06 09:00:24 --> Loader Class Initialized
INFO - 2024-02-06 09:00:24 --> Helper loaded: url_helper
INFO - 2024-02-06 09:00:24 --> Helper loaded: file_helper
INFO - 2024-02-06 09:00:24 --> Helper loaded: html_helper
INFO - 2024-02-06 09:00:24 --> Helper loaded: text_helper
INFO - 2024-02-06 09:00:24 --> Helper loaded: form_helper
INFO - 2024-02-06 09:00:24 --> Helper loaded: lang_helper
INFO - 2024-02-06 09:00:24 --> Helper loaded: security_helper
INFO - 2024-02-06 09:00:24 --> Helper loaded: cookie_helper
INFO - 2024-02-06 09:00:24 --> Database Driver Class Initialized
INFO - 2024-02-06 09:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 09:00:24 --> Parser Class Initialized
INFO - 2024-02-06 09:00:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 09:00:24 --> Pagination Class Initialized
INFO - 2024-02-06 09:00:24 --> Form Validation Class Initialized
INFO - 2024-02-06 09:00:24 --> Controller Class Initialized
DEBUG - 2024-02-06 09:00:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 09:00:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 09:00:24 --> Model Class Initialized
DEBUG - 2024-02-06 09:00:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 09:00:24 --> Model Class Initialized
DEBUG - 2024-02-06 09:00:24 --> Auth class already loaded. Second attempt ignored.
ERROR - 2024-02-06 09:00:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 09:00:24 --> Config Class Initialized
INFO - 2024-02-06 09:00:24 --> Hooks Class Initialized
DEBUG - 2024-02-06 09:00:24 --> UTF-8 Support Enabled
INFO - 2024-02-06 09:00:24 --> Utf8 Class Initialized
INFO - 2024-02-06 09:00:24 --> URI Class Initialized
INFO - 2024-02-06 09:00:24 --> Router Class Initialized
INFO - 2024-02-06 09:00:24 --> Output Class Initialized
INFO - 2024-02-06 09:00:24 --> Security Class Initialized
DEBUG - 2024-02-06 09:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 09:00:24 --> Input Class Initialized
INFO - 2024-02-06 09:00:24 --> Language Class Initialized
INFO - 2024-02-06 09:00:24 --> Loader Class Initialized
INFO - 2024-02-06 09:00:24 --> Helper loaded: url_helper
INFO - 2024-02-06 09:00:24 --> Helper loaded: file_helper
INFO - 2024-02-06 09:00:24 --> Helper loaded: html_helper
INFO - 2024-02-06 09:00:24 --> Helper loaded: text_helper
INFO - 2024-02-06 09:00:24 --> Helper loaded: form_helper
INFO - 2024-02-06 09:00:24 --> Helper loaded: lang_helper
INFO - 2024-02-06 09:00:24 --> Helper loaded: security_helper
INFO - 2024-02-06 09:00:24 --> Helper loaded: cookie_helper
INFO - 2024-02-06 09:00:24 --> Database Driver Class Initialized
INFO - 2024-02-06 09:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 09:00:24 --> Parser Class Initialized
INFO - 2024-02-06 09:00:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 09:00:24 --> Pagination Class Initialized
INFO - 2024-02-06 09:00:24 --> Form Validation Class Initialized
INFO - 2024-02-06 09:00:24 --> Controller Class Initialized
DEBUG - 2024-02-06 09:00:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 09:00:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 09:00:24 --> Model Class Initialized
DEBUG - 2024-02-06 09:00:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 09:00:24 --> Model Class Initialized
INFO - 2024-02-06 09:00:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-02-06 09:00:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 09:00:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 09:00:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 09:00:24 --> Model Class Initialized
INFO - 2024-02-06 09:00:24 --> Model Class Initialized
INFO - 2024-02-06 09:00:24 --> Model Class Initialized
INFO - 2024-02-06 09:00:24 --> Model Class Initialized
INFO - 2024-02-06 09:00:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 09:00:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 09:00:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 09:00:25 --> Final output sent to browser
DEBUG - 2024-02-06 09:00:25 --> Total execution time: 0.1754
ERROR - 2024-02-06 09:00:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 09:00:29 --> Config Class Initialized
INFO - 2024-02-06 09:00:29 --> Hooks Class Initialized
DEBUG - 2024-02-06 09:00:29 --> UTF-8 Support Enabled
INFO - 2024-02-06 09:00:29 --> Utf8 Class Initialized
INFO - 2024-02-06 09:00:29 --> URI Class Initialized
INFO - 2024-02-06 09:00:29 --> Router Class Initialized
INFO - 2024-02-06 09:00:29 --> Output Class Initialized
INFO - 2024-02-06 09:00:29 --> Security Class Initialized
DEBUG - 2024-02-06 09:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 09:00:29 --> Input Class Initialized
INFO - 2024-02-06 09:00:29 --> Language Class Initialized
INFO - 2024-02-06 09:00:29 --> Loader Class Initialized
INFO - 2024-02-06 09:00:29 --> Helper loaded: url_helper
INFO - 2024-02-06 09:00:29 --> Helper loaded: file_helper
INFO - 2024-02-06 09:00:29 --> Helper loaded: html_helper
INFO - 2024-02-06 09:00:29 --> Helper loaded: text_helper
INFO - 2024-02-06 09:00:29 --> Helper loaded: form_helper
INFO - 2024-02-06 09:00:29 --> Helper loaded: lang_helper
INFO - 2024-02-06 09:00:29 --> Helper loaded: security_helper
INFO - 2024-02-06 09:00:29 --> Helper loaded: cookie_helper
INFO - 2024-02-06 09:00:29 --> Database Driver Class Initialized
INFO - 2024-02-06 09:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 09:00:29 --> Parser Class Initialized
INFO - 2024-02-06 09:00:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 09:00:29 --> Pagination Class Initialized
INFO - 2024-02-06 09:00:29 --> Form Validation Class Initialized
INFO - 2024-02-06 09:00:29 --> Controller Class Initialized
DEBUG - 2024-02-06 09:00:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 09:00:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 09:00:29 --> Model Class Initialized
DEBUG - 2024-02-06 09:00:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 09:00:29 --> Model Class Initialized
INFO - 2024-02-06 09:00:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2024-02-06 09:00:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 09:00:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 09:00:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 09:00:29 --> Model Class Initialized
INFO - 2024-02-06 09:00:29 --> Model Class Initialized
INFO - 2024-02-06 09:00:29 --> Model Class Initialized
INFO - 2024-02-06 09:00:29 --> Model Class Initialized
INFO - 2024-02-06 09:00:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 09:00:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 09:00:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 09:00:29 --> Final output sent to browser
DEBUG - 2024-02-06 09:00:29 --> Total execution time: 0.1735
ERROR - 2024-02-06 09:00:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 09:00:32 --> Config Class Initialized
INFO - 2024-02-06 09:00:32 --> Hooks Class Initialized
DEBUG - 2024-02-06 09:00:32 --> UTF-8 Support Enabled
INFO - 2024-02-06 09:00:32 --> Utf8 Class Initialized
INFO - 2024-02-06 09:00:32 --> URI Class Initialized
DEBUG - 2024-02-06 09:00:32 --> No URI present. Default controller set.
INFO - 2024-02-06 09:00:32 --> Router Class Initialized
INFO - 2024-02-06 09:00:32 --> Output Class Initialized
INFO - 2024-02-06 09:00:32 --> Security Class Initialized
DEBUG - 2024-02-06 09:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 09:00:32 --> Input Class Initialized
INFO - 2024-02-06 09:00:32 --> Language Class Initialized
INFO - 2024-02-06 09:00:32 --> Loader Class Initialized
INFO - 2024-02-06 09:00:32 --> Helper loaded: url_helper
INFO - 2024-02-06 09:00:32 --> Helper loaded: file_helper
INFO - 2024-02-06 09:00:32 --> Helper loaded: html_helper
INFO - 2024-02-06 09:00:32 --> Helper loaded: text_helper
INFO - 2024-02-06 09:00:32 --> Helper loaded: form_helper
INFO - 2024-02-06 09:00:32 --> Helper loaded: lang_helper
INFO - 2024-02-06 09:00:32 --> Helper loaded: security_helper
INFO - 2024-02-06 09:00:32 --> Helper loaded: cookie_helper
INFO - 2024-02-06 09:00:32 --> Database Driver Class Initialized
INFO - 2024-02-06 09:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 09:00:32 --> Parser Class Initialized
INFO - 2024-02-06 09:00:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 09:00:32 --> Pagination Class Initialized
INFO - 2024-02-06 09:00:32 --> Form Validation Class Initialized
INFO - 2024-02-06 09:00:32 --> Controller Class Initialized
INFO - 2024-02-06 09:00:32 --> Model Class Initialized
DEBUG - 2024-02-06 09:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 09:00:32 --> Model Class Initialized
DEBUG - 2024-02-06 09:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 09:00:32 --> Model Class Initialized
INFO - 2024-02-06 09:00:32 --> Model Class Initialized
INFO - 2024-02-06 09:00:32 --> Model Class Initialized
INFO - 2024-02-06 09:00:32 --> Model Class Initialized
DEBUG - 2024-02-06 09:00:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 09:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 09:00:32 --> Model Class Initialized
INFO - 2024-02-06 09:00:32 --> Model Class Initialized
INFO - 2024-02-06 09:00:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 09:00:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 09:00:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 09:00:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 09:00:32 --> Model Class Initialized
INFO - 2024-02-06 09:00:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 09:00:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 09:00:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 09:00:32 --> Final output sent to browser
DEBUG - 2024-02-06 09:00:32 --> Total execution time: 0.2387
ERROR - 2024-02-06 12:06:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 12:06:24 --> Config Class Initialized
INFO - 2024-02-06 12:06:24 --> Hooks Class Initialized
DEBUG - 2024-02-06 12:06:24 --> UTF-8 Support Enabled
INFO - 2024-02-06 12:06:24 --> Utf8 Class Initialized
INFO - 2024-02-06 12:06:24 --> URI Class Initialized
DEBUG - 2024-02-06 12:06:24 --> No URI present. Default controller set.
INFO - 2024-02-06 12:06:24 --> Router Class Initialized
INFO - 2024-02-06 12:06:24 --> Output Class Initialized
INFO - 2024-02-06 12:06:24 --> Security Class Initialized
DEBUG - 2024-02-06 12:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 12:06:24 --> Input Class Initialized
INFO - 2024-02-06 12:06:24 --> Language Class Initialized
INFO - 2024-02-06 12:06:24 --> Loader Class Initialized
INFO - 2024-02-06 12:06:24 --> Helper loaded: url_helper
INFO - 2024-02-06 12:06:24 --> Helper loaded: file_helper
INFO - 2024-02-06 12:06:24 --> Helper loaded: html_helper
INFO - 2024-02-06 12:06:24 --> Helper loaded: text_helper
INFO - 2024-02-06 12:06:24 --> Helper loaded: form_helper
INFO - 2024-02-06 12:06:24 --> Helper loaded: lang_helper
INFO - 2024-02-06 12:06:24 --> Helper loaded: security_helper
INFO - 2024-02-06 12:06:24 --> Helper loaded: cookie_helper
INFO - 2024-02-06 12:06:24 --> Database Driver Class Initialized
INFO - 2024-02-06 12:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 12:06:24 --> Parser Class Initialized
INFO - 2024-02-06 12:06:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 12:06:24 --> Pagination Class Initialized
INFO - 2024-02-06 12:06:24 --> Form Validation Class Initialized
INFO - 2024-02-06 12:06:24 --> Controller Class Initialized
INFO - 2024-02-06 12:06:24 --> Model Class Initialized
DEBUG - 2024-02-06 12:06:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-06 12:06:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 12:06:24 --> Config Class Initialized
INFO - 2024-02-06 12:06:24 --> Hooks Class Initialized
DEBUG - 2024-02-06 12:06:24 --> UTF-8 Support Enabled
INFO - 2024-02-06 12:06:24 --> Utf8 Class Initialized
INFO - 2024-02-06 12:06:24 --> URI Class Initialized
INFO - 2024-02-06 12:06:24 --> Router Class Initialized
INFO - 2024-02-06 12:06:24 --> Output Class Initialized
INFO - 2024-02-06 12:06:24 --> Security Class Initialized
DEBUG - 2024-02-06 12:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 12:06:24 --> Input Class Initialized
INFO - 2024-02-06 12:06:24 --> Language Class Initialized
INFO - 2024-02-06 12:06:24 --> Loader Class Initialized
INFO - 2024-02-06 12:06:24 --> Helper loaded: url_helper
INFO - 2024-02-06 12:06:24 --> Helper loaded: file_helper
INFO - 2024-02-06 12:06:24 --> Helper loaded: html_helper
INFO - 2024-02-06 12:06:24 --> Helper loaded: text_helper
INFO - 2024-02-06 12:06:24 --> Helper loaded: form_helper
INFO - 2024-02-06 12:06:24 --> Helper loaded: lang_helper
INFO - 2024-02-06 12:06:24 --> Helper loaded: security_helper
INFO - 2024-02-06 12:06:24 --> Helper loaded: cookie_helper
INFO - 2024-02-06 12:06:24 --> Database Driver Class Initialized
INFO - 2024-02-06 12:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 12:06:24 --> Parser Class Initialized
INFO - 2024-02-06 12:06:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 12:06:24 --> Pagination Class Initialized
INFO - 2024-02-06 12:06:24 --> Form Validation Class Initialized
INFO - 2024-02-06 12:06:24 --> Controller Class Initialized
INFO - 2024-02-06 12:06:24 --> Model Class Initialized
DEBUG - 2024-02-06 12:06:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 12:06:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-06 12:06:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 12:06:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 12:06:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 12:06:24 --> Model Class Initialized
INFO - 2024-02-06 12:06:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 12:06:24 --> Final output sent to browser
DEBUG - 2024-02-06 12:06:24 --> Total execution time: 0.0338
ERROR - 2024-02-06 13:20:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:20:19 --> Config Class Initialized
INFO - 2024-02-06 13:20:19 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:20:19 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:20:19 --> Utf8 Class Initialized
INFO - 2024-02-06 13:20:19 --> URI Class Initialized
DEBUG - 2024-02-06 13:20:19 --> No URI present. Default controller set.
INFO - 2024-02-06 13:20:19 --> Router Class Initialized
INFO - 2024-02-06 13:20:19 --> Output Class Initialized
INFO - 2024-02-06 13:20:19 --> Security Class Initialized
DEBUG - 2024-02-06 13:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:20:19 --> Input Class Initialized
INFO - 2024-02-06 13:20:19 --> Language Class Initialized
INFO - 2024-02-06 13:20:19 --> Loader Class Initialized
INFO - 2024-02-06 13:20:19 --> Helper loaded: url_helper
INFO - 2024-02-06 13:20:19 --> Helper loaded: file_helper
INFO - 2024-02-06 13:20:19 --> Helper loaded: html_helper
INFO - 2024-02-06 13:20:19 --> Helper loaded: text_helper
INFO - 2024-02-06 13:20:19 --> Helper loaded: form_helper
INFO - 2024-02-06 13:20:19 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:20:19 --> Helper loaded: security_helper
INFO - 2024-02-06 13:20:19 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:20:19 --> Database Driver Class Initialized
INFO - 2024-02-06 13:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:20:19 --> Parser Class Initialized
INFO - 2024-02-06 13:20:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:20:19 --> Pagination Class Initialized
INFO - 2024-02-06 13:20:19 --> Form Validation Class Initialized
INFO - 2024-02-06 13:20:19 --> Controller Class Initialized
INFO - 2024-02-06 13:20:19 --> Model Class Initialized
DEBUG - 2024-02-06 13:20:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-06 13:20:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:20:19 --> Config Class Initialized
INFO - 2024-02-06 13:20:19 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:20:19 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:20:19 --> Utf8 Class Initialized
INFO - 2024-02-06 13:20:19 --> URI Class Initialized
INFO - 2024-02-06 13:20:19 --> Router Class Initialized
INFO - 2024-02-06 13:20:19 --> Output Class Initialized
INFO - 2024-02-06 13:20:19 --> Security Class Initialized
DEBUG - 2024-02-06 13:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:20:19 --> Input Class Initialized
INFO - 2024-02-06 13:20:19 --> Language Class Initialized
INFO - 2024-02-06 13:20:19 --> Loader Class Initialized
INFO - 2024-02-06 13:20:19 --> Helper loaded: url_helper
INFO - 2024-02-06 13:20:19 --> Helper loaded: file_helper
INFO - 2024-02-06 13:20:19 --> Helper loaded: html_helper
INFO - 2024-02-06 13:20:19 --> Helper loaded: text_helper
INFO - 2024-02-06 13:20:19 --> Helper loaded: form_helper
INFO - 2024-02-06 13:20:19 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:20:19 --> Helper loaded: security_helper
INFO - 2024-02-06 13:20:19 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:20:19 --> Database Driver Class Initialized
INFO - 2024-02-06 13:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:20:19 --> Parser Class Initialized
INFO - 2024-02-06 13:20:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:20:19 --> Pagination Class Initialized
INFO - 2024-02-06 13:20:19 --> Form Validation Class Initialized
INFO - 2024-02-06 13:20:19 --> Controller Class Initialized
INFO - 2024-02-06 13:20:19 --> Model Class Initialized
DEBUG - 2024-02-06 13:20:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:20:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-06 13:20:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:20:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 13:20:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 13:20:19 --> Model Class Initialized
INFO - 2024-02-06 13:20:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 13:20:19 --> Final output sent to browser
DEBUG - 2024-02-06 13:20:19 --> Total execution time: 0.0342
ERROR - 2024-02-06 13:20:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:20:28 --> Config Class Initialized
INFO - 2024-02-06 13:20:28 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:20:28 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:20:28 --> Utf8 Class Initialized
INFO - 2024-02-06 13:20:28 --> URI Class Initialized
INFO - 2024-02-06 13:20:28 --> Router Class Initialized
INFO - 2024-02-06 13:20:28 --> Output Class Initialized
INFO - 2024-02-06 13:20:28 --> Security Class Initialized
DEBUG - 2024-02-06 13:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:20:28 --> Input Class Initialized
INFO - 2024-02-06 13:20:28 --> Language Class Initialized
INFO - 2024-02-06 13:20:28 --> Loader Class Initialized
INFO - 2024-02-06 13:20:28 --> Helper loaded: url_helper
INFO - 2024-02-06 13:20:28 --> Helper loaded: file_helper
INFO - 2024-02-06 13:20:28 --> Helper loaded: html_helper
INFO - 2024-02-06 13:20:28 --> Helper loaded: text_helper
INFO - 2024-02-06 13:20:28 --> Helper loaded: form_helper
INFO - 2024-02-06 13:20:28 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:20:28 --> Helper loaded: security_helper
INFO - 2024-02-06 13:20:28 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:20:28 --> Database Driver Class Initialized
INFO - 2024-02-06 13:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:20:28 --> Parser Class Initialized
INFO - 2024-02-06 13:20:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:20:28 --> Pagination Class Initialized
INFO - 2024-02-06 13:20:28 --> Form Validation Class Initialized
INFO - 2024-02-06 13:20:28 --> Controller Class Initialized
INFO - 2024-02-06 13:20:28 --> Model Class Initialized
DEBUG - 2024-02-06 13:20:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:20:28 --> Model Class Initialized
INFO - 2024-02-06 13:20:28 --> Final output sent to browser
DEBUG - 2024-02-06 13:20:28 --> Total execution time: 0.0183
ERROR - 2024-02-06 13:20:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:20:28 --> Config Class Initialized
INFO - 2024-02-06 13:20:28 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:20:28 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:20:28 --> Utf8 Class Initialized
INFO - 2024-02-06 13:20:28 --> URI Class Initialized
DEBUG - 2024-02-06 13:20:28 --> No URI present. Default controller set.
INFO - 2024-02-06 13:20:28 --> Router Class Initialized
INFO - 2024-02-06 13:20:28 --> Output Class Initialized
INFO - 2024-02-06 13:20:28 --> Security Class Initialized
DEBUG - 2024-02-06 13:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:20:28 --> Input Class Initialized
INFO - 2024-02-06 13:20:28 --> Language Class Initialized
INFO - 2024-02-06 13:20:28 --> Loader Class Initialized
INFO - 2024-02-06 13:20:28 --> Helper loaded: url_helper
INFO - 2024-02-06 13:20:28 --> Helper loaded: file_helper
INFO - 2024-02-06 13:20:28 --> Helper loaded: html_helper
INFO - 2024-02-06 13:20:28 --> Helper loaded: text_helper
INFO - 2024-02-06 13:20:28 --> Helper loaded: form_helper
INFO - 2024-02-06 13:20:28 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:20:28 --> Helper loaded: security_helper
INFO - 2024-02-06 13:20:28 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:20:28 --> Database Driver Class Initialized
INFO - 2024-02-06 13:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:20:28 --> Parser Class Initialized
INFO - 2024-02-06 13:20:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:20:28 --> Pagination Class Initialized
INFO - 2024-02-06 13:20:28 --> Form Validation Class Initialized
INFO - 2024-02-06 13:20:28 --> Controller Class Initialized
INFO - 2024-02-06 13:20:28 --> Model Class Initialized
DEBUG - 2024-02-06 13:20:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:20:28 --> Model Class Initialized
DEBUG - 2024-02-06 13:20:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:20:28 --> Model Class Initialized
INFO - 2024-02-06 13:20:28 --> Model Class Initialized
INFO - 2024-02-06 13:20:28 --> Model Class Initialized
INFO - 2024-02-06 13:20:28 --> Model Class Initialized
DEBUG - 2024-02-06 13:20:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:20:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:20:28 --> Model Class Initialized
INFO - 2024-02-06 13:20:28 --> Model Class Initialized
INFO - 2024-02-06 13:20:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 13:20:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:20:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 13:20:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 13:20:28 --> Model Class Initialized
INFO - 2024-02-06 13:20:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 13:20:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 13:20:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 13:20:28 --> Final output sent to browser
DEBUG - 2024-02-06 13:20:28 --> Total execution time: 0.4204
ERROR - 2024-02-06 13:20:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:20:34 --> Config Class Initialized
INFO - 2024-02-06 13:20:34 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:20:34 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:20:34 --> Utf8 Class Initialized
INFO - 2024-02-06 13:20:34 --> URI Class Initialized
INFO - 2024-02-06 13:20:34 --> Router Class Initialized
INFO - 2024-02-06 13:20:34 --> Output Class Initialized
INFO - 2024-02-06 13:20:34 --> Security Class Initialized
DEBUG - 2024-02-06 13:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:20:34 --> Input Class Initialized
INFO - 2024-02-06 13:20:34 --> Language Class Initialized
INFO - 2024-02-06 13:20:34 --> Loader Class Initialized
INFO - 2024-02-06 13:20:34 --> Helper loaded: url_helper
INFO - 2024-02-06 13:20:34 --> Helper loaded: file_helper
INFO - 2024-02-06 13:20:34 --> Helper loaded: html_helper
INFO - 2024-02-06 13:20:34 --> Helper loaded: text_helper
INFO - 2024-02-06 13:20:34 --> Helper loaded: form_helper
INFO - 2024-02-06 13:20:34 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:20:34 --> Helper loaded: security_helper
INFO - 2024-02-06 13:20:34 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:20:34 --> Database Driver Class Initialized
INFO - 2024-02-06 13:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:20:34 --> Parser Class Initialized
INFO - 2024-02-06 13:20:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:20:34 --> Pagination Class Initialized
INFO - 2024-02-06 13:20:34 --> Form Validation Class Initialized
INFO - 2024-02-06 13:20:34 --> Controller Class Initialized
DEBUG - 2024-02-06 13:20:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:20:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:20:34 --> Model Class Initialized
INFO - 2024-02-06 13:20:34 --> Final output sent to browser
DEBUG - 2024-02-06 13:20:34 --> Total execution time: 0.0136
ERROR - 2024-02-06 13:20:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:20:44 --> Config Class Initialized
INFO - 2024-02-06 13:20:44 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:20:44 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:20:44 --> Utf8 Class Initialized
INFO - 2024-02-06 13:20:44 --> URI Class Initialized
INFO - 2024-02-06 13:20:44 --> Router Class Initialized
INFO - 2024-02-06 13:20:44 --> Output Class Initialized
INFO - 2024-02-06 13:20:44 --> Security Class Initialized
DEBUG - 2024-02-06 13:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:20:44 --> Input Class Initialized
INFO - 2024-02-06 13:20:44 --> Language Class Initialized
INFO - 2024-02-06 13:20:44 --> Loader Class Initialized
INFO - 2024-02-06 13:20:44 --> Helper loaded: url_helper
INFO - 2024-02-06 13:20:44 --> Helper loaded: file_helper
INFO - 2024-02-06 13:20:44 --> Helper loaded: html_helper
INFO - 2024-02-06 13:20:44 --> Helper loaded: text_helper
INFO - 2024-02-06 13:20:44 --> Helper loaded: form_helper
INFO - 2024-02-06 13:20:44 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:20:44 --> Helper loaded: security_helper
INFO - 2024-02-06 13:20:44 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:20:44 --> Database Driver Class Initialized
INFO - 2024-02-06 13:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:20:44 --> Parser Class Initialized
INFO - 2024-02-06 13:20:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:20:44 --> Pagination Class Initialized
INFO - 2024-02-06 13:20:44 --> Form Validation Class Initialized
INFO - 2024-02-06 13:20:44 --> Controller Class Initialized
DEBUG - 2024-02-06 13:20:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:20:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:20:44 --> Model Class Initialized
DEBUG - 2024-02-06 13:20:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:20:44 --> Model Class Initialized
DEBUG - 2024-02-06 13:20:44 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:20:44 --> Model Class Initialized
INFO - 2024-02-06 13:20:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-06 13:20:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:20:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 13:20:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 13:20:44 --> Model Class Initialized
INFO - 2024-02-06 13:20:44 --> Model Class Initialized
INFO - 2024-02-06 13:20:44 --> Model Class Initialized
INFO - 2024-02-06 13:20:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 13:20:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 13:20:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 13:20:44 --> Final output sent to browser
DEBUG - 2024-02-06 13:20:44 --> Total execution time: 0.2113
ERROR - 2024-02-06 13:20:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:20:47 --> Config Class Initialized
INFO - 2024-02-06 13:20:47 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:20:47 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:20:47 --> Utf8 Class Initialized
INFO - 2024-02-06 13:20:47 --> URI Class Initialized
INFO - 2024-02-06 13:20:47 --> Router Class Initialized
INFO - 2024-02-06 13:20:47 --> Output Class Initialized
INFO - 2024-02-06 13:20:47 --> Security Class Initialized
DEBUG - 2024-02-06 13:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:20:47 --> Input Class Initialized
INFO - 2024-02-06 13:20:47 --> Language Class Initialized
INFO - 2024-02-06 13:20:47 --> Loader Class Initialized
INFO - 2024-02-06 13:20:47 --> Helper loaded: url_helper
INFO - 2024-02-06 13:20:47 --> Helper loaded: file_helper
INFO - 2024-02-06 13:20:47 --> Helper loaded: html_helper
INFO - 2024-02-06 13:20:47 --> Helper loaded: text_helper
INFO - 2024-02-06 13:20:47 --> Helper loaded: form_helper
INFO - 2024-02-06 13:20:47 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:20:47 --> Helper loaded: security_helper
INFO - 2024-02-06 13:20:47 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:20:47 --> Database Driver Class Initialized
INFO - 2024-02-06 13:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:20:47 --> Parser Class Initialized
INFO - 2024-02-06 13:20:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:20:47 --> Pagination Class Initialized
INFO - 2024-02-06 13:20:47 --> Form Validation Class Initialized
INFO - 2024-02-06 13:20:47 --> Controller Class Initialized
DEBUG - 2024-02-06 13:20:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:20:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:20:47 --> Model Class Initialized
DEBUG - 2024-02-06 13:20:47 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:20:47 --> Model Class Initialized
INFO - 2024-02-06 13:20:47 --> Final output sent to browser
DEBUG - 2024-02-06 13:20:47 --> Total execution time: 0.0332
ERROR - 2024-02-06 13:21:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:21:16 --> Config Class Initialized
INFO - 2024-02-06 13:21:16 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:21:16 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:21:16 --> Utf8 Class Initialized
INFO - 2024-02-06 13:21:16 --> URI Class Initialized
INFO - 2024-02-06 13:21:16 --> Router Class Initialized
INFO - 2024-02-06 13:21:16 --> Output Class Initialized
INFO - 2024-02-06 13:21:16 --> Security Class Initialized
DEBUG - 2024-02-06 13:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:21:16 --> Input Class Initialized
INFO - 2024-02-06 13:21:16 --> Language Class Initialized
INFO - 2024-02-06 13:21:16 --> Loader Class Initialized
INFO - 2024-02-06 13:21:16 --> Helper loaded: url_helper
INFO - 2024-02-06 13:21:16 --> Helper loaded: file_helper
INFO - 2024-02-06 13:21:16 --> Helper loaded: html_helper
INFO - 2024-02-06 13:21:16 --> Helper loaded: text_helper
INFO - 2024-02-06 13:21:16 --> Helper loaded: form_helper
INFO - 2024-02-06 13:21:16 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:21:16 --> Helper loaded: security_helper
INFO - 2024-02-06 13:21:16 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:21:16 --> Database Driver Class Initialized
INFO - 2024-02-06 13:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:21:16 --> Parser Class Initialized
INFO - 2024-02-06 13:21:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:21:16 --> Pagination Class Initialized
INFO - 2024-02-06 13:21:16 --> Form Validation Class Initialized
INFO - 2024-02-06 13:21:16 --> Controller Class Initialized
DEBUG - 2024-02-06 13:21:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:21:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:16 --> Model Class Initialized
DEBUG - 2024-02-06 13:21:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:16 --> Model Class Initialized
INFO - 2024-02-06 13:21:16 --> Final output sent to browser
DEBUG - 2024-02-06 13:21:16 --> Total execution time: 0.1946
ERROR - 2024-02-06 13:21:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:21:30 --> Config Class Initialized
INFO - 2024-02-06 13:21:30 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:21:30 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:21:30 --> Utf8 Class Initialized
INFO - 2024-02-06 13:21:30 --> URI Class Initialized
INFO - 2024-02-06 13:21:30 --> Router Class Initialized
INFO - 2024-02-06 13:21:30 --> Output Class Initialized
INFO - 2024-02-06 13:21:30 --> Security Class Initialized
DEBUG - 2024-02-06 13:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:21:30 --> Input Class Initialized
INFO - 2024-02-06 13:21:30 --> Language Class Initialized
INFO - 2024-02-06 13:21:30 --> Loader Class Initialized
INFO - 2024-02-06 13:21:30 --> Helper loaded: url_helper
INFO - 2024-02-06 13:21:30 --> Helper loaded: file_helper
INFO - 2024-02-06 13:21:30 --> Helper loaded: html_helper
INFO - 2024-02-06 13:21:30 --> Helper loaded: text_helper
INFO - 2024-02-06 13:21:30 --> Helper loaded: form_helper
INFO - 2024-02-06 13:21:30 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:21:30 --> Helper loaded: security_helper
INFO - 2024-02-06 13:21:30 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:21:30 --> Database Driver Class Initialized
INFO - 2024-02-06 13:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:21:30 --> Parser Class Initialized
INFO - 2024-02-06 13:21:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:21:30 --> Pagination Class Initialized
INFO - 2024-02-06 13:21:30 --> Form Validation Class Initialized
INFO - 2024-02-06 13:21:30 --> Controller Class Initialized
DEBUG - 2024-02-06 13:21:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:21:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:30 --> Model Class Initialized
DEBUG - 2024-02-06 13:21:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:30 --> Model Class Initialized
INFO - 2024-02-06 13:21:30 --> Final output sent to browser
DEBUG - 2024-02-06 13:21:30 --> Total execution time: 0.2134
ERROR - 2024-02-06 13:21:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:21:33 --> Config Class Initialized
INFO - 2024-02-06 13:21:33 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:21:33 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:21:33 --> Utf8 Class Initialized
INFO - 2024-02-06 13:21:33 --> URI Class Initialized
INFO - 2024-02-06 13:21:33 --> Router Class Initialized
INFO - 2024-02-06 13:21:33 --> Output Class Initialized
INFO - 2024-02-06 13:21:33 --> Security Class Initialized
DEBUG - 2024-02-06 13:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:21:33 --> Input Class Initialized
INFO - 2024-02-06 13:21:33 --> Language Class Initialized
INFO - 2024-02-06 13:21:33 --> Loader Class Initialized
INFO - 2024-02-06 13:21:33 --> Helper loaded: url_helper
INFO - 2024-02-06 13:21:33 --> Helper loaded: file_helper
INFO - 2024-02-06 13:21:33 --> Helper loaded: html_helper
INFO - 2024-02-06 13:21:33 --> Helper loaded: text_helper
INFO - 2024-02-06 13:21:33 --> Helper loaded: form_helper
INFO - 2024-02-06 13:21:33 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:21:33 --> Helper loaded: security_helper
INFO - 2024-02-06 13:21:33 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:21:33 --> Database Driver Class Initialized
INFO - 2024-02-06 13:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:21:33 --> Parser Class Initialized
INFO - 2024-02-06 13:21:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:21:33 --> Pagination Class Initialized
INFO - 2024-02-06 13:21:33 --> Form Validation Class Initialized
INFO - 2024-02-06 13:21:33 --> Controller Class Initialized
DEBUG - 2024-02-06 13:21:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:21:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:33 --> Model Class Initialized
DEBUG - 2024-02-06 13:21:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:33 --> Model Class Initialized
INFO - 2024-02-06 13:21:33 --> Final output sent to browser
DEBUG - 2024-02-06 13:21:33 --> Total execution time: 0.0703
ERROR - 2024-02-06 13:21:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:21:33 --> Config Class Initialized
INFO - 2024-02-06 13:21:33 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:21:33 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:21:33 --> Utf8 Class Initialized
INFO - 2024-02-06 13:21:33 --> URI Class Initialized
INFO - 2024-02-06 13:21:33 --> Router Class Initialized
INFO - 2024-02-06 13:21:33 --> Output Class Initialized
INFO - 2024-02-06 13:21:33 --> Security Class Initialized
DEBUG - 2024-02-06 13:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:21:33 --> Input Class Initialized
INFO - 2024-02-06 13:21:33 --> Language Class Initialized
INFO - 2024-02-06 13:21:33 --> Loader Class Initialized
INFO - 2024-02-06 13:21:33 --> Helper loaded: url_helper
INFO - 2024-02-06 13:21:33 --> Helper loaded: file_helper
INFO - 2024-02-06 13:21:33 --> Helper loaded: html_helper
INFO - 2024-02-06 13:21:33 --> Helper loaded: text_helper
INFO - 2024-02-06 13:21:33 --> Helper loaded: form_helper
INFO - 2024-02-06 13:21:33 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:21:33 --> Helper loaded: security_helper
INFO - 2024-02-06 13:21:33 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:21:33 --> Database Driver Class Initialized
INFO - 2024-02-06 13:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:21:33 --> Parser Class Initialized
INFO - 2024-02-06 13:21:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:21:33 --> Pagination Class Initialized
INFO - 2024-02-06 13:21:33 --> Form Validation Class Initialized
INFO - 2024-02-06 13:21:33 --> Controller Class Initialized
DEBUG - 2024-02-06 13:21:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:21:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:33 --> Model Class Initialized
DEBUG - 2024-02-06 13:21:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:33 --> Model Class Initialized
INFO - 2024-02-06 13:21:33 --> Final output sent to browser
DEBUG - 2024-02-06 13:21:33 --> Total execution time: 0.0662
ERROR - 2024-02-06 13:21:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:21:35 --> Config Class Initialized
INFO - 2024-02-06 13:21:35 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:21:35 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:21:35 --> Utf8 Class Initialized
INFO - 2024-02-06 13:21:35 --> URI Class Initialized
INFO - 2024-02-06 13:21:35 --> Router Class Initialized
INFO - 2024-02-06 13:21:35 --> Output Class Initialized
INFO - 2024-02-06 13:21:35 --> Security Class Initialized
DEBUG - 2024-02-06 13:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:21:35 --> Input Class Initialized
INFO - 2024-02-06 13:21:35 --> Language Class Initialized
INFO - 2024-02-06 13:21:35 --> Loader Class Initialized
INFO - 2024-02-06 13:21:35 --> Helper loaded: url_helper
INFO - 2024-02-06 13:21:35 --> Helper loaded: file_helper
INFO - 2024-02-06 13:21:35 --> Helper loaded: html_helper
INFO - 2024-02-06 13:21:35 --> Helper loaded: text_helper
INFO - 2024-02-06 13:21:35 --> Helper loaded: form_helper
INFO - 2024-02-06 13:21:35 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:21:35 --> Helper loaded: security_helper
INFO - 2024-02-06 13:21:35 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:21:35 --> Database Driver Class Initialized
INFO - 2024-02-06 13:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:21:35 --> Parser Class Initialized
INFO - 2024-02-06 13:21:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:21:35 --> Pagination Class Initialized
INFO - 2024-02-06 13:21:35 --> Form Validation Class Initialized
INFO - 2024-02-06 13:21:35 --> Controller Class Initialized
DEBUG - 2024-02-06 13:21:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:21:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:35 --> Model Class Initialized
DEBUG - 2024-02-06 13:21:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:35 --> Model Class Initialized
INFO - 2024-02-06 13:21:35 --> Final output sent to browser
DEBUG - 2024-02-06 13:21:35 --> Total execution time: 0.0702
ERROR - 2024-02-06 13:21:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:21:36 --> Config Class Initialized
INFO - 2024-02-06 13:21:36 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:21:36 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:21:36 --> Utf8 Class Initialized
INFO - 2024-02-06 13:21:36 --> URI Class Initialized
INFO - 2024-02-06 13:21:36 --> Router Class Initialized
INFO - 2024-02-06 13:21:36 --> Output Class Initialized
INFO - 2024-02-06 13:21:36 --> Security Class Initialized
DEBUG - 2024-02-06 13:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:21:36 --> Input Class Initialized
INFO - 2024-02-06 13:21:36 --> Language Class Initialized
INFO - 2024-02-06 13:21:36 --> Loader Class Initialized
INFO - 2024-02-06 13:21:36 --> Helper loaded: url_helper
INFO - 2024-02-06 13:21:36 --> Helper loaded: file_helper
INFO - 2024-02-06 13:21:36 --> Helper loaded: html_helper
INFO - 2024-02-06 13:21:36 --> Helper loaded: text_helper
INFO - 2024-02-06 13:21:36 --> Helper loaded: form_helper
INFO - 2024-02-06 13:21:36 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:21:36 --> Helper loaded: security_helper
INFO - 2024-02-06 13:21:36 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:21:36 --> Database Driver Class Initialized
INFO - 2024-02-06 13:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:21:36 --> Parser Class Initialized
INFO - 2024-02-06 13:21:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:21:36 --> Pagination Class Initialized
INFO - 2024-02-06 13:21:36 --> Form Validation Class Initialized
INFO - 2024-02-06 13:21:36 --> Controller Class Initialized
DEBUG - 2024-02-06 13:21:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:21:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:36 --> Model Class Initialized
DEBUG - 2024-02-06 13:21:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:36 --> Model Class Initialized
INFO - 2024-02-06 13:21:36 --> Final output sent to browser
DEBUG - 2024-02-06 13:21:36 --> Total execution time: 0.2150
ERROR - 2024-02-06 13:21:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:21:37 --> Config Class Initialized
INFO - 2024-02-06 13:21:37 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:21:37 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:21:37 --> Utf8 Class Initialized
INFO - 2024-02-06 13:21:37 --> URI Class Initialized
INFO - 2024-02-06 13:21:37 --> Router Class Initialized
INFO - 2024-02-06 13:21:37 --> Output Class Initialized
INFO - 2024-02-06 13:21:37 --> Security Class Initialized
DEBUG - 2024-02-06 13:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:21:37 --> Input Class Initialized
INFO - 2024-02-06 13:21:37 --> Language Class Initialized
INFO - 2024-02-06 13:21:37 --> Loader Class Initialized
INFO - 2024-02-06 13:21:37 --> Helper loaded: url_helper
INFO - 2024-02-06 13:21:37 --> Helper loaded: file_helper
INFO - 2024-02-06 13:21:37 --> Helper loaded: html_helper
INFO - 2024-02-06 13:21:37 --> Helper loaded: text_helper
INFO - 2024-02-06 13:21:37 --> Helper loaded: form_helper
INFO - 2024-02-06 13:21:37 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:21:37 --> Helper loaded: security_helper
INFO - 2024-02-06 13:21:37 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:21:37 --> Database Driver Class Initialized
INFO - 2024-02-06 13:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:21:37 --> Parser Class Initialized
INFO - 2024-02-06 13:21:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:21:37 --> Pagination Class Initialized
INFO - 2024-02-06 13:21:37 --> Form Validation Class Initialized
INFO - 2024-02-06 13:21:37 --> Controller Class Initialized
DEBUG - 2024-02-06 13:21:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:21:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:37 --> Model Class Initialized
DEBUG - 2024-02-06 13:21:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:37 --> Model Class Initialized
INFO - 2024-02-06 13:21:37 --> Final output sent to browser
DEBUG - 2024-02-06 13:21:37 --> Total execution time: 0.2355
ERROR - 2024-02-06 13:21:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:21:41 --> Config Class Initialized
INFO - 2024-02-06 13:21:41 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:21:41 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:21:41 --> Utf8 Class Initialized
INFO - 2024-02-06 13:21:41 --> URI Class Initialized
INFO - 2024-02-06 13:21:41 --> Router Class Initialized
INFO - 2024-02-06 13:21:41 --> Output Class Initialized
INFO - 2024-02-06 13:21:41 --> Security Class Initialized
DEBUG - 2024-02-06 13:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:21:41 --> Input Class Initialized
INFO - 2024-02-06 13:21:41 --> Language Class Initialized
INFO - 2024-02-06 13:21:41 --> Loader Class Initialized
INFO - 2024-02-06 13:21:41 --> Helper loaded: url_helper
INFO - 2024-02-06 13:21:41 --> Helper loaded: file_helper
INFO - 2024-02-06 13:21:41 --> Helper loaded: html_helper
INFO - 2024-02-06 13:21:41 --> Helper loaded: text_helper
INFO - 2024-02-06 13:21:41 --> Helper loaded: form_helper
INFO - 2024-02-06 13:21:41 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:21:41 --> Helper loaded: security_helper
INFO - 2024-02-06 13:21:41 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:21:41 --> Database Driver Class Initialized
INFO - 2024-02-06 13:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:21:41 --> Parser Class Initialized
INFO - 2024-02-06 13:21:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:21:41 --> Pagination Class Initialized
INFO - 2024-02-06 13:21:41 --> Form Validation Class Initialized
INFO - 2024-02-06 13:21:41 --> Controller Class Initialized
DEBUG - 2024-02-06 13:21:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:21:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:41 --> Model Class Initialized
DEBUG - 2024-02-06 13:21:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:41 --> Model Class Initialized
INFO - 2024-02-06 13:21:41 --> Final output sent to browser
DEBUG - 2024-02-06 13:21:41 --> Total execution time: 0.2401
ERROR - 2024-02-06 13:21:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:21:45 --> Config Class Initialized
INFO - 2024-02-06 13:21:45 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:21:45 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:21:45 --> Utf8 Class Initialized
INFO - 2024-02-06 13:21:45 --> URI Class Initialized
INFO - 2024-02-06 13:21:45 --> Router Class Initialized
INFO - 2024-02-06 13:21:45 --> Output Class Initialized
INFO - 2024-02-06 13:21:45 --> Security Class Initialized
DEBUG - 2024-02-06 13:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:21:45 --> Input Class Initialized
INFO - 2024-02-06 13:21:45 --> Language Class Initialized
INFO - 2024-02-06 13:21:45 --> Loader Class Initialized
INFO - 2024-02-06 13:21:45 --> Helper loaded: url_helper
INFO - 2024-02-06 13:21:45 --> Helper loaded: file_helper
INFO - 2024-02-06 13:21:45 --> Helper loaded: html_helper
INFO - 2024-02-06 13:21:45 --> Helper loaded: text_helper
INFO - 2024-02-06 13:21:45 --> Helper loaded: form_helper
INFO - 2024-02-06 13:21:45 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:21:45 --> Helper loaded: security_helper
INFO - 2024-02-06 13:21:45 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:21:45 --> Database Driver Class Initialized
INFO - 2024-02-06 13:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:21:45 --> Parser Class Initialized
INFO - 2024-02-06 13:21:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:21:45 --> Pagination Class Initialized
INFO - 2024-02-06 13:21:45 --> Form Validation Class Initialized
INFO - 2024-02-06 13:21:45 --> Controller Class Initialized
DEBUG - 2024-02-06 13:21:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:21:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:45 --> Model Class Initialized
DEBUG - 2024-02-06 13:21:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:45 --> Model Class Initialized
INFO - 2024-02-06 13:21:46 --> Final output sent to browser
DEBUG - 2024-02-06 13:21:46 --> Total execution time: 0.1848
ERROR - 2024-02-06 13:21:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:21:50 --> Config Class Initialized
INFO - 2024-02-06 13:21:50 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:21:50 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:21:50 --> Utf8 Class Initialized
INFO - 2024-02-06 13:21:50 --> URI Class Initialized
INFO - 2024-02-06 13:21:50 --> Router Class Initialized
INFO - 2024-02-06 13:21:50 --> Output Class Initialized
INFO - 2024-02-06 13:21:50 --> Security Class Initialized
DEBUG - 2024-02-06 13:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:21:50 --> Input Class Initialized
INFO - 2024-02-06 13:21:50 --> Language Class Initialized
INFO - 2024-02-06 13:21:50 --> Loader Class Initialized
INFO - 2024-02-06 13:21:50 --> Helper loaded: url_helper
INFO - 2024-02-06 13:21:50 --> Helper loaded: file_helper
INFO - 2024-02-06 13:21:50 --> Helper loaded: html_helper
INFO - 2024-02-06 13:21:50 --> Helper loaded: text_helper
INFO - 2024-02-06 13:21:50 --> Helper loaded: form_helper
INFO - 2024-02-06 13:21:50 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:21:50 --> Helper loaded: security_helper
INFO - 2024-02-06 13:21:50 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:21:50 --> Database Driver Class Initialized
INFO - 2024-02-06 13:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:21:50 --> Parser Class Initialized
INFO - 2024-02-06 13:21:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:21:50 --> Pagination Class Initialized
INFO - 2024-02-06 13:21:50 --> Form Validation Class Initialized
INFO - 2024-02-06 13:21:50 --> Controller Class Initialized
DEBUG - 2024-02-06 13:21:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:21:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:50 --> Model Class Initialized
DEBUG - 2024-02-06 13:21:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:50 --> Model Class Initialized
INFO - 2024-02-06 13:21:50 --> Final output sent to browser
DEBUG - 2024-02-06 13:21:50 --> Total execution time: 0.0209
ERROR - 2024-02-06 13:21:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:21:51 --> Config Class Initialized
INFO - 2024-02-06 13:21:51 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:21:51 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:21:51 --> Utf8 Class Initialized
INFO - 2024-02-06 13:21:51 --> URI Class Initialized
INFO - 2024-02-06 13:21:51 --> Router Class Initialized
INFO - 2024-02-06 13:21:51 --> Output Class Initialized
INFO - 2024-02-06 13:21:51 --> Security Class Initialized
DEBUG - 2024-02-06 13:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:21:51 --> Input Class Initialized
INFO - 2024-02-06 13:21:51 --> Language Class Initialized
INFO - 2024-02-06 13:21:51 --> Loader Class Initialized
INFO - 2024-02-06 13:21:51 --> Helper loaded: url_helper
INFO - 2024-02-06 13:21:51 --> Helper loaded: file_helper
INFO - 2024-02-06 13:21:51 --> Helper loaded: html_helper
INFO - 2024-02-06 13:21:51 --> Helper loaded: text_helper
INFO - 2024-02-06 13:21:51 --> Helper loaded: form_helper
INFO - 2024-02-06 13:21:51 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:21:51 --> Helper loaded: security_helper
INFO - 2024-02-06 13:21:51 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:21:51 --> Database Driver Class Initialized
INFO - 2024-02-06 13:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:21:51 --> Parser Class Initialized
INFO - 2024-02-06 13:21:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:21:51 --> Pagination Class Initialized
INFO - 2024-02-06 13:21:51 --> Form Validation Class Initialized
INFO - 2024-02-06 13:21:51 --> Controller Class Initialized
DEBUG - 2024-02-06 13:21:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:21:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:51 --> Model Class Initialized
DEBUG - 2024-02-06 13:21:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:51 --> Model Class Initialized
INFO - 2024-02-06 13:21:51 --> Final output sent to browser
DEBUG - 2024-02-06 13:21:51 --> Total execution time: 0.0214
ERROR - 2024-02-06 13:21:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:21:53 --> Config Class Initialized
INFO - 2024-02-06 13:21:53 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:21:53 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:21:53 --> Utf8 Class Initialized
INFO - 2024-02-06 13:21:53 --> URI Class Initialized
INFO - 2024-02-06 13:21:53 --> Router Class Initialized
INFO - 2024-02-06 13:21:53 --> Output Class Initialized
INFO - 2024-02-06 13:21:53 --> Security Class Initialized
DEBUG - 2024-02-06 13:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:21:53 --> Input Class Initialized
INFO - 2024-02-06 13:21:53 --> Language Class Initialized
INFO - 2024-02-06 13:21:53 --> Loader Class Initialized
INFO - 2024-02-06 13:21:53 --> Helper loaded: url_helper
INFO - 2024-02-06 13:21:53 --> Helper loaded: file_helper
INFO - 2024-02-06 13:21:53 --> Helper loaded: html_helper
INFO - 2024-02-06 13:21:53 --> Helper loaded: text_helper
INFO - 2024-02-06 13:21:53 --> Helper loaded: form_helper
INFO - 2024-02-06 13:21:53 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:21:53 --> Helper loaded: security_helper
INFO - 2024-02-06 13:21:53 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:21:53 --> Database Driver Class Initialized
INFO - 2024-02-06 13:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:21:53 --> Parser Class Initialized
INFO - 2024-02-06 13:21:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:21:53 --> Pagination Class Initialized
INFO - 2024-02-06 13:21:53 --> Form Validation Class Initialized
INFO - 2024-02-06 13:21:53 --> Controller Class Initialized
DEBUG - 2024-02-06 13:21:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:21:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:53 --> Model Class Initialized
DEBUG - 2024-02-06 13:21:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:53 --> Model Class Initialized
INFO - 2024-02-06 13:21:53 --> Final output sent to browser
DEBUG - 2024-02-06 13:21:53 --> Total execution time: 0.0210
ERROR - 2024-02-06 13:21:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:21:54 --> Config Class Initialized
INFO - 2024-02-06 13:21:54 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:21:54 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:21:54 --> Utf8 Class Initialized
INFO - 2024-02-06 13:21:54 --> URI Class Initialized
INFO - 2024-02-06 13:21:54 --> Router Class Initialized
INFO - 2024-02-06 13:21:54 --> Output Class Initialized
INFO - 2024-02-06 13:21:54 --> Security Class Initialized
DEBUG - 2024-02-06 13:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:21:54 --> Input Class Initialized
INFO - 2024-02-06 13:21:54 --> Language Class Initialized
INFO - 2024-02-06 13:21:54 --> Loader Class Initialized
INFO - 2024-02-06 13:21:54 --> Helper loaded: url_helper
INFO - 2024-02-06 13:21:54 --> Helper loaded: file_helper
INFO - 2024-02-06 13:21:54 --> Helper loaded: html_helper
INFO - 2024-02-06 13:21:54 --> Helper loaded: text_helper
INFO - 2024-02-06 13:21:54 --> Helper loaded: form_helper
INFO - 2024-02-06 13:21:54 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:21:54 --> Helper loaded: security_helper
INFO - 2024-02-06 13:21:54 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:21:54 --> Database Driver Class Initialized
INFO - 2024-02-06 13:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:21:54 --> Parser Class Initialized
INFO - 2024-02-06 13:21:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:21:54 --> Pagination Class Initialized
INFO - 2024-02-06 13:21:54 --> Form Validation Class Initialized
INFO - 2024-02-06 13:21:54 --> Controller Class Initialized
DEBUG - 2024-02-06 13:21:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:21:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:54 --> Model Class Initialized
DEBUG - 2024-02-06 13:21:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:54 --> Model Class Initialized
INFO - 2024-02-06 13:21:54 --> Final output sent to browser
DEBUG - 2024-02-06 13:21:54 --> Total execution time: 0.1753
ERROR - 2024-02-06 13:21:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:21:54 --> Config Class Initialized
INFO - 2024-02-06 13:21:54 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:21:54 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:21:54 --> Utf8 Class Initialized
INFO - 2024-02-06 13:21:54 --> URI Class Initialized
INFO - 2024-02-06 13:21:54 --> Router Class Initialized
INFO - 2024-02-06 13:21:54 --> Output Class Initialized
INFO - 2024-02-06 13:21:54 --> Security Class Initialized
DEBUG - 2024-02-06 13:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:21:54 --> Input Class Initialized
INFO - 2024-02-06 13:21:54 --> Language Class Initialized
INFO - 2024-02-06 13:21:54 --> Loader Class Initialized
INFO - 2024-02-06 13:21:54 --> Helper loaded: url_helper
INFO - 2024-02-06 13:21:54 --> Helper loaded: file_helper
INFO - 2024-02-06 13:21:54 --> Helper loaded: html_helper
INFO - 2024-02-06 13:21:54 --> Helper loaded: text_helper
INFO - 2024-02-06 13:21:54 --> Helper loaded: form_helper
INFO - 2024-02-06 13:21:54 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:21:54 --> Helper loaded: security_helper
INFO - 2024-02-06 13:21:54 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:21:54 --> Database Driver Class Initialized
INFO - 2024-02-06 13:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:21:54 --> Parser Class Initialized
INFO - 2024-02-06 13:21:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:21:54 --> Pagination Class Initialized
INFO - 2024-02-06 13:21:54 --> Form Validation Class Initialized
INFO - 2024-02-06 13:21:54 --> Controller Class Initialized
DEBUG - 2024-02-06 13:21:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:21:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:54 --> Model Class Initialized
DEBUG - 2024-02-06 13:21:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:54 --> Model Class Initialized
INFO - 2024-02-06 13:21:54 --> Final output sent to browser
DEBUG - 2024-02-06 13:21:54 --> Total execution time: 0.2015
ERROR - 2024-02-06 13:21:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:21:55 --> Config Class Initialized
INFO - 2024-02-06 13:21:55 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:21:55 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:21:55 --> Utf8 Class Initialized
INFO - 2024-02-06 13:21:55 --> URI Class Initialized
INFO - 2024-02-06 13:21:55 --> Router Class Initialized
INFO - 2024-02-06 13:21:55 --> Output Class Initialized
INFO - 2024-02-06 13:21:55 --> Security Class Initialized
DEBUG - 2024-02-06 13:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:21:55 --> Input Class Initialized
INFO - 2024-02-06 13:21:55 --> Language Class Initialized
INFO - 2024-02-06 13:21:55 --> Loader Class Initialized
INFO - 2024-02-06 13:21:55 --> Helper loaded: url_helper
INFO - 2024-02-06 13:21:55 --> Helper loaded: file_helper
INFO - 2024-02-06 13:21:55 --> Helper loaded: html_helper
INFO - 2024-02-06 13:21:55 --> Helper loaded: text_helper
INFO - 2024-02-06 13:21:55 --> Helper loaded: form_helper
INFO - 2024-02-06 13:21:55 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:21:55 --> Helper loaded: security_helper
INFO - 2024-02-06 13:21:55 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:21:55 --> Database Driver Class Initialized
INFO - 2024-02-06 13:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:21:55 --> Parser Class Initialized
INFO - 2024-02-06 13:21:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:21:55 --> Pagination Class Initialized
INFO - 2024-02-06 13:21:55 --> Form Validation Class Initialized
INFO - 2024-02-06 13:21:55 --> Controller Class Initialized
DEBUG - 2024-02-06 13:21:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:21:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:55 --> Model Class Initialized
DEBUG - 2024-02-06 13:21:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:55 --> Model Class Initialized
INFO - 2024-02-06 13:21:55 --> Final output sent to browser
DEBUG - 2024-02-06 13:21:55 --> Total execution time: 0.2178
ERROR - 2024-02-06 13:21:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:21:58 --> Config Class Initialized
INFO - 2024-02-06 13:21:58 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:21:58 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:21:58 --> Utf8 Class Initialized
INFO - 2024-02-06 13:21:58 --> URI Class Initialized
INFO - 2024-02-06 13:21:58 --> Router Class Initialized
INFO - 2024-02-06 13:21:58 --> Output Class Initialized
INFO - 2024-02-06 13:21:58 --> Security Class Initialized
DEBUG - 2024-02-06 13:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:21:58 --> Input Class Initialized
INFO - 2024-02-06 13:21:58 --> Language Class Initialized
INFO - 2024-02-06 13:21:58 --> Loader Class Initialized
INFO - 2024-02-06 13:21:58 --> Helper loaded: url_helper
INFO - 2024-02-06 13:21:58 --> Helper loaded: file_helper
INFO - 2024-02-06 13:21:58 --> Helper loaded: html_helper
INFO - 2024-02-06 13:21:58 --> Helper loaded: text_helper
INFO - 2024-02-06 13:21:58 --> Helper loaded: form_helper
INFO - 2024-02-06 13:21:58 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:21:58 --> Helper loaded: security_helper
INFO - 2024-02-06 13:21:58 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:21:58 --> Database Driver Class Initialized
INFO - 2024-02-06 13:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:21:58 --> Parser Class Initialized
INFO - 2024-02-06 13:21:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:21:58 --> Pagination Class Initialized
INFO - 2024-02-06 13:21:58 --> Form Validation Class Initialized
INFO - 2024-02-06 13:21:58 --> Controller Class Initialized
DEBUG - 2024-02-06 13:21:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:21:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:58 --> Model Class Initialized
DEBUG - 2024-02-06 13:21:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:58 --> Model Class Initialized
INFO - 2024-02-06 13:21:58 --> Final output sent to browser
DEBUG - 2024-02-06 13:21:58 --> Total execution time: 0.2122
ERROR - 2024-02-06 13:21:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:21:58 --> Config Class Initialized
INFO - 2024-02-06 13:21:58 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:21:58 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:21:58 --> Utf8 Class Initialized
INFO - 2024-02-06 13:21:58 --> URI Class Initialized
INFO - 2024-02-06 13:21:58 --> Router Class Initialized
INFO - 2024-02-06 13:21:58 --> Output Class Initialized
INFO - 2024-02-06 13:21:58 --> Security Class Initialized
DEBUG - 2024-02-06 13:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:21:58 --> Input Class Initialized
INFO - 2024-02-06 13:21:58 --> Language Class Initialized
INFO - 2024-02-06 13:21:58 --> Loader Class Initialized
INFO - 2024-02-06 13:21:58 --> Helper loaded: url_helper
INFO - 2024-02-06 13:21:58 --> Helper loaded: file_helper
INFO - 2024-02-06 13:21:58 --> Helper loaded: html_helper
INFO - 2024-02-06 13:21:58 --> Helper loaded: text_helper
INFO - 2024-02-06 13:21:58 --> Helper loaded: form_helper
INFO - 2024-02-06 13:21:58 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:21:58 --> Helper loaded: security_helper
INFO - 2024-02-06 13:21:58 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:21:58 --> Database Driver Class Initialized
INFO - 2024-02-06 13:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:21:58 --> Parser Class Initialized
INFO - 2024-02-06 13:21:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:21:58 --> Pagination Class Initialized
INFO - 2024-02-06 13:21:58 --> Form Validation Class Initialized
INFO - 2024-02-06 13:21:58 --> Controller Class Initialized
DEBUG - 2024-02-06 13:21:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:21:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:58 --> Model Class Initialized
DEBUG - 2024-02-06 13:21:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:58 --> Model Class Initialized
INFO - 2024-02-06 13:21:58 --> Final output sent to browser
DEBUG - 2024-02-06 13:21:58 --> Total execution time: 0.2052
ERROR - 2024-02-06 13:21:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:21:59 --> Config Class Initialized
INFO - 2024-02-06 13:21:59 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:21:59 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:21:59 --> Utf8 Class Initialized
INFO - 2024-02-06 13:21:59 --> URI Class Initialized
INFO - 2024-02-06 13:21:59 --> Router Class Initialized
INFO - 2024-02-06 13:21:59 --> Output Class Initialized
INFO - 2024-02-06 13:21:59 --> Security Class Initialized
DEBUG - 2024-02-06 13:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:21:59 --> Input Class Initialized
INFO - 2024-02-06 13:21:59 --> Language Class Initialized
INFO - 2024-02-06 13:21:59 --> Loader Class Initialized
INFO - 2024-02-06 13:21:59 --> Helper loaded: url_helper
INFO - 2024-02-06 13:21:59 --> Helper loaded: file_helper
INFO - 2024-02-06 13:21:59 --> Helper loaded: html_helper
INFO - 2024-02-06 13:21:59 --> Helper loaded: text_helper
INFO - 2024-02-06 13:21:59 --> Helper loaded: form_helper
INFO - 2024-02-06 13:21:59 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:21:59 --> Helper loaded: security_helper
INFO - 2024-02-06 13:21:59 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:21:59 --> Database Driver Class Initialized
INFO - 2024-02-06 13:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:21:59 --> Parser Class Initialized
INFO - 2024-02-06 13:21:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:21:59 --> Pagination Class Initialized
INFO - 2024-02-06 13:21:59 --> Form Validation Class Initialized
INFO - 2024-02-06 13:21:59 --> Controller Class Initialized
DEBUG - 2024-02-06 13:21:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:21:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:59 --> Model Class Initialized
DEBUG - 2024-02-06 13:21:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:21:59 --> Model Class Initialized
INFO - 2024-02-06 13:21:59 --> Final output sent to browser
DEBUG - 2024-02-06 13:21:59 --> Total execution time: 0.0242
ERROR - 2024-02-06 13:22:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:22:03 --> Config Class Initialized
INFO - 2024-02-06 13:22:03 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:22:03 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:22:03 --> Utf8 Class Initialized
INFO - 2024-02-06 13:22:03 --> URI Class Initialized
INFO - 2024-02-06 13:22:03 --> Router Class Initialized
INFO - 2024-02-06 13:22:03 --> Output Class Initialized
INFO - 2024-02-06 13:22:03 --> Security Class Initialized
DEBUG - 2024-02-06 13:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:22:03 --> Input Class Initialized
INFO - 2024-02-06 13:22:03 --> Language Class Initialized
INFO - 2024-02-06 13:22:03 --> Loader Class Initialized
INFO - 2024-02-06 13:22:03 --> Helper loaded: url_helper
INFO - 2024-02-06 13:22:03 --> Helper loaded: file_helper
INFO - 2024-02-06 13:22:03 --> Helper loaded: html_helper
INFO - 2024-02-06 13:22:03 --> Helper loaded: text_helper
INFO - 2024-02-06 13:22:03 --> Helper loaded: form_helper
INFO - 2024-02-06 13:22:03 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:22:03 --> Helper loaded: security_helper
INFO - 2024-02-06 13:22:03 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:22:03 --> Database Driver Class Initialized
INFO - 2024-02-06 13:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:22:03 --> Parser Class Initialized
INFO - 2024-02-06 13:22:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:22:03 --> Pagination Class Initialized
INFO - 2024-02-06 13:22:03 --> Form Validation Class Initialized
INFO - 2024-02-06 13:22:03 --> Controller Class Initialized
DEBUG - 2024-02-06 13:22:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:22:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:22:03 --> Model Class Initialized
DEBUG - 2024-02-06 13:22:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:22:03 --> Model Class Initialized
INFO - 2024-02-06 13:22:03 --> Final output sent to browser
DEBUG - 2024-02-06 13:22:03 --> Total execution time: 0.0170
ERROR - 2024-02-06 13:22:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:22:05 --> Config Class Initialized
INFO - 2024-02-06 13:22:05 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:22:05 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:22:05 --> Utf8 Class Initialized
INFO - 2024-02-06 13:22:05 --> URI Class Initialized
INFO - 2024-02-06 13:22:05 --> Router Class Initialized
INFO - 2024-02-06 13:22:05 --> Output Class Initialized
INFO - 2024-02-06 13:22:05 --> Security Class Initialized
DEBUG - 2024-02-06 13:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:22:05 --> Input Class Initialized
INFO - 2024-02-06 13:22:05 --> Language Class Initialized
INFO - 2024-02-06 13:22:05 --> Loader Class Initialized
INFO - 2024-02-06 13:22:05 --> Helper loaded: url_helper
INFO - 2024-02-06 13:22:05 --> Helper loaded: file_helper
INFO - 2024-02-06 13:22:05 --> Helper loaded: html_helper
INFO - 2024-02-06 13:22:05 --> Helper loaded: text_helper
INFO - 2024-02-06 13:22:05 --> Helper loaded: form_helper
INFO - 2024-02-06 13:22:05 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:22:05 --> Helper loaded: security_helper
INFO - 2024-02-06 13:22:05 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:22:05 --> Database Driver Class Initialized
INFO - 2024-02-06 13:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:22:05 --> Parser Class Initialized
INFO - 2024-02-06 13:22:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:22:05 --> Pagination Class Initialized
INFO - 2024-02-06 13:22:05 --> Form Validation Class Initialized
INFO - 2024-02-06 13:22:05 --> Controller Class Initialized
DEBUG - 2024-02-06 13:22:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:22:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:22:05 --> Model Class Initialized
DEBUG - 2024-02-06 13:22:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:22:05 --> Model Class Initialized
INFO - 2024-02-06 13:22:06 --> Final output sent to browser
DEBUG - 2024-02-06 13:22:06 --> Total execution time: 0.1933
ERROR - 2024-02-06 13:22:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:22:06 --> Config Class Initialized
INFO - 2024-02-06 13:22:06 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:22:06 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:22:06 --> Utf8 Class Initialized
INFO - 2024-02-06 13:22:06 --> URI Class Initialized
INFO - 2024-02-06 13:22:06 --> Router Class Initialized
INFO - 2024-02-06 13:22:06 --> Output Class Initialized
INFO - 2024-02-06 13:22:06 --> Security Class Initialized
DEBUG - 2024-02-06 13:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:22:06 --> Input Class Initialized
INFO - 2024-02-06 13:22:06 --> Language Class Initialized
INFO - 2024-02-06 13:22:06 --> Loader Class Initialized
INFO - 2024-02-06 13:22:06 --> Helper loaded: url_helper
INFO - 2024-02-06 13:22:06 --> Helper loaded: file_helper
INFO - 2024-02-06 13:22:06 --> Helper loaded: html_helper
INFO - 2024-02-06 13:22:06 --> Helper loaded: text_helper
INFO - 2024-02-06 13:22:06 --> Helper loaded: form_helper
INFO - 2024-02-06 13:22:06 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:22:06 --> Helper loaded: security_helper
INFO - 2024-02-06 13:22:06 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:22:06 --> Database Driver Class Initialized
INFO - 2024-02-06 13:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:22:06 --> Parser Class Initialized
INFO - 2024-02-06 13:22:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:22:06 --> Pagination Class Initialized
INFO - 2024-02-06 13:22:06 --> Form Validation Class Initialized
INFO - 2024-02-06 13:22:06 --> Controller Class Initialized
DEBUG - 2024-02-06 13:22:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:22:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:22:06 --> Model Class Initialized
DEBUG - 2024-02-06 13:22:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:22:06 --> Model Class Initialized
INFO - 2024-02-06 13:22:06 --> Final output sent to browser
DEBUG - 2024-02-06 13:22:06 --> Total execution time: 0.2177
ERROR - 2024-02-06 13:22:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:22:06 --> Config Class Initialized
INFO - 2024-02-06 13:22:06 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:22:06 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:22:06 --> Utf8 Class Initialized
INFO - 2024-02-06 13:22:06 --> URI Class Initialized
INFO - 2024-02-06 13:22:06 --> Router Class Initialized
INFO - 2024-02-06 13:22:06 --> Output Class Initialized
INFO - 2024-02-06 13:22:06 --> Security Class Initialized
DEBUG - 2024-02-06 13:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:22:06 --> Input Class Initialized
INFO - 2024-02-06 13:22:06 --> Language Class Initialized
INFO - 2024-02-06 13:22:06 --> Loader Class Initialized
INFO - 2024-02-06 13:22:06 --> Helper loaded: url_helper
INFO - 2024-02-06 13:22:06 --> Helper loaded: file_helper
INFO - 2024-02-06 13:22:06 --> Helper loaded: html_helper
INFO - 2024-02-06 13:22:06 --> Helper loaded: text_helper
INFO - 2024-02-06 13:22:06 --> Helper loaded: form_helper
INFO - 2024-02-06 13:22:06 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:22:06 --> Helper loaded: security_helper
INFO - 2024-02-06 13:22:06 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:22:06 --> Database Driver Class Initialized
INFO - 2024-02-06 13:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:22:06 --> Parser Class Initialized
INFO - 2024-02-06 13:22:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:22:06 --> Pagination Class Initialized
INFO - 2024-02-06 13:22:06 --> Form Validation Class Initialized
INFO - 2024-02-06 13:22:06 --> Controller Class Initialized
DEBUG - 2024-02-06 13:22:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:22:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:22:06 --> Model Class Initialized
DEBUG - 2024-02-06 13:22:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:22:06 --> Model Class Initialized
INFO - 2024-02-06 13:22:07 --> Final output sent to browser
DEBUG - 2024-02-06 13:22:07 --> Total execution time: 0.2160
ERROR - 2024-02-06 13:22:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:22:09 --> Config Class Initialized
INFO - 2024-02-06 13:22:09 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:22:09 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:22:09 --> Utf8 Class Initialized
INFO - 2024-02-06 13:22:09 --> URI Class Initialized
INFO - 2024-02-06 13:22:09 --> Router Class Initialized
INFO - 2024-02-06 13:22:09 --> Output Class Initialized
INFO - 2024-02-06 13:22:09 --> Security Class Initialized
DEBUG - 2024-02-06 13:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:22:09 --> Input Class Initialized
INFO - 2024-02-06 13:22:09 --> Language Class Initialized
INFO - 2024-02-06 13:22:09 --> Loader Class Initialized
INFO - 2024-02-06 13:22:09 --> Helper loaded: url_helper
INFO - 2024-02-06 13:22:09 --> Helper loaded: file_helper
INFO - 2024-02-06 13:22:09 --> Helper loaded: html_helper
INFO - 2024-02-06 13:22:09 --> Helper loaded: text_helper
INFO - 2024-02-06 13:22:09 --> Helper loaded: form_helper
INFO - 2024-02-06 13:22:09 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:22:09 --> Helper loaded: security_helper
INFO - 2024-02-06 13:22:09 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:22:09 --> Database Driver Class Initialized
INFO - 2024-02-06 13:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:22:09 --> Parser Class Initialized
INFO - 2024-02-06 13:22:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:22:09 --> Pagination Class Initialized
INFO - 2024-02-06 13:22:09 --> Form Validation Class Initialized
INFO - 2024-02-06 13:22:09 --> Controller Class Initialized
DEBUG - 2024-02-06 13:22:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:22:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:22:09 --> Model Class Initialized
DEBUG - 2024-02-06 13:22:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:22:09 --> Model Class Initialized
INFO - 2024-02-06 13:22:09 --> Final output sent to browser
DEBUG - 2024-02-06 13:22:09 --> Total execution time: 0.1720
ERROR - 2024-02-06 13:22:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:22:09 --> Config Class Initialized
INFO - 2024-02-06 13:22:09 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:22:09 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:22:09 --> Utf8 Class Initialized
INFO - 2024-02-06 13:22:09 --> URI Class Initialized
INFO - 2024-02-06 13:22:09 --> Router Class Initialized
INFO - 2024-02-06 13:22:09 --> Output Class Initialized
INFO - 2024-02-06 13:22:09 --> Security Class Initialized
DEBUG - 2024-02-06 13:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:22:09 --> Input Class Initialized
INFO - 2024-02-06 13:22:09 --> Language Class Initialized
INFO - 2024-02-06 13:22:09 --> Loader Class Initialized
INFO - 2024-02-06 13:22:09 --> Helper loaded: url_helper
INFO - 2024-02-06 13:22:09 --> Helper loaded: file_helper
INFO - 2024-02-06 13:22:09 --> Helper loaded: html_helper
INFO - 2024-02-06 13:22:09 --> Helper loaded: text_helper
INFO - 2024-02-06 13:22:09 --> Helper loaded: form_helper
INFO - 2024-02-06 13:22:09 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:22:09 --> Helper loaded: security_helper
INFO - 2024-02-06 13:22:09 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:22:09 --> Database Driver Class Initialized
INFO - 2024-02-06 13:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:22:09 --> Parser Class Initialized
INFO - 2024-02-06 13:22:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:22:09 --> Pagination Class Initialized
INFO - 2024-02-06 13:22:09 --> Form Validation Class Initialized
INFO - 2024-02-06 13:22:09 --> Controller Class Initialized
DEBUG - 2024-02-06 13:22:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:22:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:22:09 --> Model Class Initialized
DEBUG - 2024-02-06 13:22:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:22:09 --> Model Class Initialized
INFO - 2024-02-06 13:22:09 --> Final output sent to browser
DEBUG - 2024-02-06 13:22:09 --> Total execution time: 0.0744
ERROR - 2024-02-06 13:22:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:22:10 --> Config Class Initialized
INFO - 2024-02-06 13:22:10 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:22:10 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:22:10 --> Utf8 Class Initialized
INFO - 2024-02-06 13:22:10 --> URI Class Initialized
INFO - 2024-02-06 13:22:10 --> Router Class Initialized
INFO - 2024-02-06 13:22:10 --> Output Class Initialized
INFO - 2024-02-06 13:22:10 --> Security Class Initialized
DEBUG - 2024-02-06 13:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:22:10 --> Input Class Initialized
INFO - 2024-02-06 13:22:10 --> Language Class Initialized
INFO - 2024-02-06 13:22:10 --> Loader Class Initialized
INFO - 2024-02-06 13:22:10 --> Helper loaded: url_helper
INFO - 2024-02-06 13:22:10 --> Helper loaded: file_helper
INFO - 2024-02-06 13:22:10 --> Helper loaded: html_helper
INFO - 2024-02-06 13:22:10 --> Helper loaded: text_helper
INFO - 2024-02-06 13:22:10 --> Helper loaded: form_helper
INFO - 2024-02-06 13:22:10 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:22:10 --> Helper loaded: security_helper
INFO - 2024-02-06 13:22:10 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:22:10 --> Database Driver Class Initialized
INFO - 2024-02-06 13:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:22:10 --> Parser Class Initialized
INFO - 2024-02-06 13:22:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:22:10 --> Pagination Class Initialized
INFO - 2024-02-06 13:22:10 --> Form Validation Class Initialized
INFO - 2024-02-06 13:22:10 --> Controller Class Initialized
DEBUG - 2024-02-06 13:22:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:22:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:22:10 --> Model Class Initialized
DEBUG - 2024-02-06 13:22:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:22:10 --> Model Class Initialized
INFO - 2024-02-06 13:22:10 --> Final output sent to browser
DEBUG - 2024-02-06 13:22:10 --> Total execution time: 0.0174
ERROR - 2024-02-06 13:22:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:22:12 --> Config Class Initialized
INFO - 2024-02-06 13:22:12 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:22:12 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:22:12 --> Utf8 Class Initialized
INFO - 2024-02-06 13:22:12 --> URI Class Initialized
INFO - 2024-02-06 13:22:12 --> Router Class Initialized
INFO - 2024-02-06 13:22:12 --> Output Class Initialized
INFO - 2024-02-06 13:22:12 --> Security Class Initialized
DEBUG - 2024-02-06 13:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:22:12 --> Input Class Initialized
INFO - 2024-02-06 13:22:12 --> Language Class Initialized
INFO - 2024-02-06 13:22:12 --> Loader Class Initialized
INFO - 2024-02-06 13:22:12 --> Helper loaded: url_helper
INFO - 2024-02-06 13:22:12 --> Helper loaded: file_helper
INFO - 2024-02-06 13:22:12 --> Helper loaded: html_helper
INFO - 2024-02-06 13:22:12 --> Helper loaded: text_helper
INFO - 2024-02-06 13:22:12 --> Helper loaded: form_helper
INFO - 2024-02-06 13:22:12 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:22:12 --> Helper loaded: security_helper
INFO - 2024-02-06 13:22:12 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:22:12 --> Database Driver Class Initialized
INFO - 2024-02-06 13:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:22:12 --> Parser Class Initialized
INFO - 2024-02-06 13:22:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:22:12 --> Pagination Class Initialized
INFO - 2024-02-06 13:22:12 --> Form Validation Class Initialized
INFO - 2024-02-06 13:22:12 --> Controller Class Initialized
DEBUG - 2024-02-06 13:22:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:22:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:22:12 --> Model Class Initialized
DEBUG - 2024-02-06 13:22:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:22:12 --> Model Class Initialized
INFO - 2024-02-06 13:22:12 --> Final output sent to browser
DEBUG - 2024-02-06 13:22:12 --> Total execution time: 0.0610
ERROR - 2024-02-06 13:22:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:22:13 --> Config Class Initialized
INFO - 2024-02-06 13:22:13 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:22:13 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:22:13 --> Utf8 Class Initialized
INFO - 2024-02-06 13:22:13 --> URI Class Initialized
INFO - 2024-02-06 13:22:13 --> Router Class Initialized
INFO - 2024-02-06 13:22:13 --> Output Class Initialized
INFO - 2024-02-06 13:22:13 --> Security Class Initialized
DEBUG - 2024-02-06 13:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:22:13 --> Input Class Initialized
INFO - 2024-02-06 13:22:13 --> Language Class Initialized
INFO - 2024-02-06 13:22:13 --> Loader Class Initialized
INFO - 2024-02-06 13:22:13 --> Helper loaded: url_helper
INFO - 2024-02-06 13:22:13 --> Helper loaded: file_helper
INFO - 2024-02-06 13:22:13 --> Helper loaded: html_helper
INFO - 2024-02-06 13:22:13 --> Helper loaded: text_helper
INFO - 2024-02-06 13:22:13 --> Helper loaded: form_helper
INFO - 2024-02-06 13:22:13 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:22:13 --> Helper loaded: security_helper
INFO - 2024-02-06 13:22:13 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:22:13 --> Database Driver Class Initialized
INFO - 2024-02-06 13:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:22:13 --> Parser Class Initialized
INFO - 2024-02-06 13:22:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:22:13 --> Pagination Class Initialized
INFO - 2024-02-06 13:22:13 --> Form Validation Class Initialized
INFO - 2024-02-06 13:22:13 --> Controller Class Initialized
DEBUG - 2024-02-06 13:22:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:22:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:22:13 --> Model Class Initialized
DEBUG - 2024-02-06 13:22:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:22:13 --> Model Class Initialized
INFO - 2024-02-06 13:22:13 --> Final output sent to browser
DEBUG - 2024-02-06 13:22:13 --> Total execution time: 0.0999
ERROR - 2024-02-06 13:22:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:22:15 --> Config Class Initialized
INFO - 2024-02-06 13:22:15 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:22:15 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:22:15 --> Utf8 Class Initialized
INFO - 2024-02-06 13:22:15 --> URI Class Initialized
INFO - 2024-02-06 13:22:15 --> Router Class Initialized
INFO - 2024-02-06 13:22:15 --> Output Class Initialized
INFO - 2024-02-06 13:22:15 --> Security Class Initialized
DEBUG - 2024-02-06 13:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:22:15 --> Input Class Initialized
INFO - 2024-02-06 13:22:15 --> Language Class Initialized
INFO - 2024-02-06 13:22:15 --> Loader Class Initialized
INFO - 2024-02-06 13:22:15 --> Helper loaded: url_helper
INFO - 2024-02-06 13:22:15 --> Helper loaded: file_helper
INFO - 2024-02-06 13:22:15 --> Helper loaded: html_helper
INFO - 2024-02-06 13:22:15 --> Helper loaded: text_helper
INFO - 2024-02-06 13:22:15 --> Helper loaded: form_helper
INFO - 2024-02-06 13:22:15 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:22:15 --> Helper loaded: security_helper
INFO - 2024-02-06 13:22:15 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:22:15 --> Database Driver Class Initialized
INFO - 2024-02-06 13:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:22:15 --> Parser Class Initialized
INFO - 2024-02-06 13:22:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:22:15 --> Pagination Class Initialized
INFO - 2024-02-06 13:22:15 --> Form Validation Class Initialized
INFO - 2024-02-06 13:22:15 --> Controller Class Initialized
DEBUG - 2024-02-06 13:22:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:22:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:22:15 --> Model Class Initialized
DEBUG - 2024-02-06 13:22:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:22:15 --> Model Class Initialized
INFO - 2024-02-06 13:22:15 --> Final output sent to browser
DEBUG - 2024-02-06 13:22:15 --> Total execution time: 0.1731
ERROR - 2024-02-06 13:22:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:22:33 --> Config Class Initialized
INFO - 2024-02-06 13:22:33 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:22:33 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:22:33 --> Utf8 Class Initialized
INFO - 2024-02-06 13:22:33 --> URI Class Initialized
INFO - 2024-02-06 13:22:33 --> Router Class Initialized
INFO - 2024-02-06 13:22:33 --> Output Class Initialized
INFO - 2024-02-06 13:22:33 --> Security Class Initialized
DEBUG - 2024-02-06 13:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:22:33 --> Input Class Initialized
INFO - 2024-02-06 13:22:33 --> Language Class Initialized
INFO - 2024-02-06 13:22:33 --> Loader Class Initialized
INFO - 2024-02-06 13:22:33 --> Helper loaded: url_helper
INFO - 2024-02-06 13:22:33 --> Helper loaded: file_helper
INFO - 2024-02-06 13:22:33 --> Helper loaded: html_helper
INFO - 2024-02-06 13:22:33 --> Helper loaded: text_helper
INFO - 2024-02-06 13:22:33 --> Helper loaded: form_helper
INFO - 2024-02-06 13:22:33 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:22:33 --> Helper loaded: security_helper
INFO - 2024-02-06 13:22:33 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:22:33 --> Database Driver Class Initialized
INFO - 2024-02-06 13:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:22:33 --> Parser Class Initialized
INFO - 2024-02-06 13:22:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:22:33 --> Pagination Class Initialized
INFO - 2024-02-06 13:22:33 --> Form Validation Class Initialized
INFO - 2024-02-06 13:22:33 --> Controller Class Initialized
DEBUG - 2024-02-06 13:22:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:22:33 --> Model Class Initialized
DEBUG - 2024-02-06 13:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:22:33 --> Model Class Initialized
INFO - 2024-02-06 13:22:33 --> Final output sent to browser
DEBUG - 2024-02-06 13:22:33 --> Total execution time: 0.0312
ERROR - 2024-02-06 13:23:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:23:00 --> Config Class Initialized
INFO - 2024-02-06 13:23:00 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:23:00 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:23:00 --> Utf8 Class Initialized
INFO - 2024-02-06 13:23:00 --> URI Class Initialized
INFO - 2024-02-06 13:23:00 --> Router Class Initialized
INFO - 2024-02-06 13:23:00 --> Output Class Initialized
INFO - 2024-02-06 13:23:00 --> Security Class Initialized
DEBUG - 2024-02-06 13:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:23:00 --> Input Class Initialized
INFO - 2024-02-06 13:23:00 --> Language Class Initialized
INFO - 2024-02-06 13:23:00 --> Loader Class Initialized
INFO - 2024-02-06 13:23:00 --> Helper loaded: url_helper
INFO - 2024-02-06 13:23:00 --> Helper loaded: file_helper
INFO - 2024-02-06 13:23:00 --> Helper loaded: html_helper
INFO - 2024-02-06 13:23:00 --> Helper loaded: text_helper
INFO - 2024-02-06 13:23:00 --> Helper loaded: form_helper
INFO - 2024-02-06 13:23:00 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:23:00 --> Helper loaded: security_helper
INFO - 2024-02-06 13:23:00 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:23:00 --> Database Driver Class Initialized
INFO - 2024-02-06 13:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:23:00 --> Parser Class Initialized
INFO - 2024-02-06 13:23:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:23:00 --> Pagination Class Initialized
INFO - 2024-02-06 13:23:00 --> Form Validation Class Initialized
INFO - 2024-02-06 13:23:00 --> Controller Class Initialized
DEBUG - 2024-02-06 13:23:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:23:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:23:00 --> Model Class Initialized
DEBUG - 2024-02-06 13:23:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:23:00 --> Model Class Initialized
DEBUG - 2024-02-06 13:23:00 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:23:00 --> Model Class Initialized
INFO - 2024-02-06 13:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-06 13:23:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 13:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 13:23:00 --> Model Class Initialized
INFO - 2024-02-06 13:23:00 --> Model Class Initialized
INFO - 2024-02-06 13:23:00 --> Model Class Initialized
INFO - 2024-02-06 13:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 13:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 13:23:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 13:23:00 --> Final output sent to browser
DEBUG - 2024-02-06 13:23:00 --> Total execution time: 0.2157
ERROR - 2024-02-06 13:23:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:23:02 --> Config Class Initialized
INFO - 2024-02-06 13:23:02 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:23:02 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:23:02 --> Utf8 Class Initialized
INFO - 2024-02-06 13:23:02 --> URI Class Initialized
INFO - 2024-02-06 13:23:02 --> Router Class Initialized
INFO - 2024-02-06 13:23:02 --> Output Class Initialized
INFO - 2024-02-06 13:23:02 --> Security Class Initialized
DEBUG - 2024-02-06 13:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:23:02 --> Input Class Initialized
INFO - 2024-02-06 13:23:02 --> Language Class Initialized
INFO - 2024-02-06 13:23:02 --> Loader Class Initialized
INFO - 2024-02-06 13:23:02 --> Helper loaded: url_helper
INFO - 2024-02-06 13:23:02 --> Helper loaded: file_helper
INFO - 2024-02-06 13:23:02 --> Helper loaded: html_helper
INFO - 2024-02-06 13:23:02 --> Helper loaded: text_helper
INFO - 2024-02-06 13:23:02 --> Helper loaded: form_helper
INFO - 2024-02-06 13:23:02 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:23:02 --> Helper loaded: security_helper
INFO - 2024-02-06 13:23:02 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:23:02 --> Database Driver Class Initialized
INFO - 2024-02-06 13:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:23:02 --> Parser Class Initialized
INFO - 2024-02-06 13:23:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:23:02 --> Pagination Class Initialized
INFO - 2024-02-06 13:23:02 --> Form Validation Class Initialized
INFO - 2024-02-06 13:23:02 --> Controller Class Initialized
DEBUG - 2024-02-06 13:23:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:23:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:23:02 --> Model Class Initialized
DEBUG - 2024-02-06 13:23:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:23:02 --> Model Class Initialized
INFO - 2024-02-06 13:23:02 --> Final output sent to browser
DEBUG - 2024-02-06 13:23:02 --> Total execution time: 0.0306
ERROR - 2024-02-06 13:23:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:23:10 --> Config Class Initialized
INFO - 2024-02-06 13:23:10 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:23:10 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:23:10 --> Utf8 Class Initialized
INFO - 2024-02-06 13:23:10 --> URI Class Initialized
INFO - 2024-02-06 13:23:10 --> Router Class Initialized
INFO - 2024-02-06 13:23:10 --> Output Class Initialized
INFO - 2024-02-06 13:23:10 --> Security Class Initialized
DEBUG - 2024-02-06 13:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:23:10 --> Input Class Initialized
INFO - 2024-02-06 13:23:10 --> Language Class Initialized
INFO - 2024-02-06 13:23:10 --> Loader Class Initialized
INFO - 2024-02-06 13:23:10 --> Helper loaded: url_helper
INFO - 2024-02-06 13:23:10 --> Helper loaded: file_helper
INFO - 2024-02-06 13:23:10 --> Helper loaded: html_helper
INFO - 2024-02-06 13:23:10 --> Helper loaded: text_helper
INFO - 2024-02-06 13:23:10 --> Helper loaded: form_helper
INFO - 2024-02-06 13:23:10 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:23:10 --> Helper loaded: security_helper
INFO - 2024-02-06 13:23:10 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:23:10 --> Database Driver Class Initialized
INFO - 2024-02-06 13:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:23:10 --> Parser Class Initialized
INFO - 2024-02-06 13:23:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:23:10 --> Pagination Class Initialized
INFO - 2024-02-06 13:23:10 --> Form Validation Class Initialized
INFO - 2024-02-06 13:23:10 --> Controller Class Initialized
DEBUG - 2024-02-06 13:23:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:23:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:23:10 --> Model Class Initialized
DEBUG - 2024-02-06 13:23:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:23:10 --> Model Class Initialized
INFO - 2024-02-06 13:23:10 --> Final output sent to browser
DEBUG - 2024-02-06 13:23:10 --> Total execution time: 0.1986
ERROR - 2024-02-06 13:23:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:23:14 --> Config Class Initialized
INFO - 2024-02-06 13:23:14 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:23:14 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:23:14 --> Utf8 Class Initialized
INFO - 2024-02-06 13:23:14 --> URI Class Initialized
INFO - 2024-02-06 13:23:14 --> Router Class Initialized
INFO - 2024-02-06 13:23:14 --> Output Class Initialized
INFO - 2024-02-06 13:23:14 --> Security Class Initialized
DEBUG - 2024-02-06 13:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:23:14 --> Input Class Initialized
INFO - 2024-02-06 13:23:14 --> Language Class Initialized
INFO - 2024-02-06 13:23:14 --> Loader Class Initialized
INFO - 2024-02-06 13:23:14 --> Helper loaded: url_helper
INFO - 2024-02-06 13:23:14 --> Helper loaded: file_helper
INFO - 2024-02-06 13:23:14 --> Helper loaded: html_helper
INFO - 2024-02-06 13:23:14 --> Helper loaded: text_helper
INFO - 2024-02-06 13:23:14 --> Helper loaded: form_helper
INFO - 2024-02-06 13:23:14 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:23:14 --> Helper loaded: security_helper
INFO - 2024-02-06 13:23:14 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:23:14 --> Database Driver Class Initialized
INFO - 2024-02-06 13:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:23:14 --> Parser Class Initialized
INFO - 2024-02-06 13:23:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:23:14 --> Pagination Class Initialized
INFO - 2024-02-06 13:23:14 --> Form Validation Class Initialized
INFO - 2024-02-06 13:23:14 --> Controller Class Initialized
DEBUG - 2024-02-06 13:23:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:23:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:23:14 --> Model Class Initialized
DEBUG - 2024-02-06 13:23:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:23:14 --> Model Class Initialized
INFO - 2024-02-06 13:23:14 --> Final output sent to browser
DEBUG - 2024-02-06 13:23:14 --> Total execution time: 0.1578
ERROR - 2024-02-06 13:23:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:23:16 --> Config Class Initialized
INFO - 2024-02-06 13:23:16 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:23:16 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:23:16 --> Utf8 Class Initialized
INFO - 2024-02-06 13:23:16 --> URI Class Initialized
INFO - 2024-02-06 13:23:16 --> Router Class Initialized
INFO - 2024-02-06 13:23:16 --> Output Class Initialized
INFO - 2024-02-06 13:23:16 --> Security Class Initialized
DEBUG - 2024-02-06 13:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:23:16 --> Input Class Initialized
INFO - 2024-02-06 13:23:16 --> Language Class Initialized
INFO - 2024-02-06 13:23:16 --> Loader Class Initialized
INFO - 2024-02-06 13:23:16 --> Helper loaded: url_helper
INFO - 2024-02-06 13:23:16 --> Helper loaded: file_helper
INFO - 2024-02-06 13:23:16 --> Helper loaded: html_helper
INFO - 2024-02-06 13:23:16 --> Helper loaded: text_helper
INFO - 2024-02-06 13:23:16 --> Helper loaded: form_helper
INFO - 2024-02-06 13:23:16 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:23:16 --> Helper loaded: security_helper
INFO - 2024-02-06 13:23:16 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:23:16 --> Database Driver Class Initialized
INFO - 2024-02-06 13:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:23:16 --> Parser Class Initialized
INFO - 2024-02-06 13:23:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:23:16 --> Pagination Class Initialized
INFO - 2024-02-06 13:23:16 --> Form Validation Class Initialized
INFO - 2024-02-06 13:23:16 --> Controller Class Initialized
DEBUG - 2024-02-06 13:23:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:23:16 --> Model Class Initialized
DEBUG - 2024-02-06 13:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:23:16 --> Model Class Initialized
INFO - 2024-02-06 13:23:16 --> Final output sent to browser
DEBUG - 2024-02-06 13:23:16 --> Total execution time: 0.1133
ERROR - 2024-02-06 13:23:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:23:17 --> Config Class Initialized
INFO - 2024-02-06 13:23:17 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:23:17 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:23:17 --> Utf8 Class Initialized
INFO - 2024-02-06 13:23:17 --> URI Class Initialized
INFO - 2024-02-06 13:23:17 --> Router Class Initialized
INFO - 2024-02-06 13:23:17 --> Output Class Initialized
INFO - 2024-02-06 13:23:17 --> Security Class Initialized
DEBUG - 2024-02-06 13:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:23:17 --> Input Class Initialized
INFO - 2024-02-06 13:23:17 --> Language Class Initialized
INFO - 2024-02-06 13:23:17 --> Loader Class Initialized
INFO - 2024-02-06 13:23:17 --> Helper loaded: url_helper
INFO - 2024-02-06 13:23:17 --> Helper loaded: file_helper
INFO - 2024-02-06 13:23:17 --> Helper loaded: html_helper
INFO - 2024-02-06 13:23:17 --> Helper loaded: text_helper
INFO - 2024-02-06 13:23:17 --> Helper loaded: form_helper
INFO - 2024-02-06 13:23:17 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:23:17 --> Helper loaded: security_helper
INFO - 2024-02-06 13:23:17 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:23:17 --> Database Driver Class Initialized
INFO - 2024-02-06 13:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:23:17 --> Parser Class Initialized
INFO - 2024-02-06 13:23:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:23:17 --> Pagination Class Initialized
INFO - 2024-02-06 13:23:17 --> Form Validation Class Initialized
INFO - 2024-02-06 13:23:17 --> Controller Class Initialized
DEBUG - 2024-02-06 13:23:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:23:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:23:18 --> Model Class Initialized
DEBUG - 2024-02-06 13:23:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:23:18 --> Model Class Initialized
INFO - 2024-02-06 13:23:18 --> Final output sent to browser
DEBUG - 2024-02-06 13:23:18 --> Total execution time: 0.0628
ERROR - 2024-02-06 13:23:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:23:24 --> Config Class Initialized
INFO - 2024-02-06 13:23:24 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:23:24 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:23:24 --> Utf8 Class Initialized
INFO - 2024-02-06 13:23:24 --> URI Class Initialized
INFO - 2024-02-06 13:23:24 --> Router Class Initialized
INFO - 2024-02-06 13:23:24 --> Output Class Initialized
INFO - 2024-02-06 13:23:24 --> Security Class Initialized
DEBUG - 2024-02-06 13:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:23:24 --> Input Class Initialized
INFO - 2024-02-06 13:23:24 --> Language Class Initialized
INFO - 2024-02-06 13:23:24 --> Loader Class Initialized
INFO - 2024-02-06 13:23:24 --> Helper loaded: url_helper
INFO - 2024-02-06 13:23:24 --> Helper loaded: file_helper
INFO - 2024-02-06 13:23:24 --> Helper loaded: html_helper
INFO - 2024-02-06 13:23:24 --> Helper loaded: text_helper
INFO - 2024-02-06 13:23:24 --> Helper loaded: form_helper
INFO - 2024-02-06 13:23:24 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:23:24 --> Helper loaded: security_helper
INFO - 2024-02-06 13:23:24 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:23:24 --> Database Driver Class Initialized
INFO - 2024-02-06 13:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:23:24 --> Parser Class Initialized
INFO - 2024-02-06 13:23:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:23:24 --> Pagination Class Initialized
INFO - 2024-02-06 13:23:24 --> Form Validation Class Initialized
INFO - 2024-02-06 13:23:24 --> Controller Class Initialized
DEBUG - 2024-02-06 13:23:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:23:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:23:24 --> Model Class Initialized
DEBUG - 2024-02-06 13:23:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:23:24 --> Model Class Initialized
INFO - 2024-02-06 13:23:24 --> Final output sent to browser
DEBUG - 2024-02-06 13:23:24 --> Total execution time: 0.0164
ERROR - 2024-02-06 13:23:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:23:30 --> Config Class Initialized
INFO - 2024-02-06 13:23:30 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:23:30 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:23:30 --> Utf8 Class Initialized
INFO - 2024-02-06 13:23:30 --> URI Class Initialized
DEBUG - 2024-02-06 13:23:30 --> No URI present. Default controller set.
INFO - 2024-02-06 13:23:30 --> Router Class Initialized
INFO - 2024-02-06 13:23:30 --> Output Class Initialized
INFO - 2024-02-06 13:23:30 --> Security Class Initialized
DEBUG - 2024-02-06 13:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:23:30 --> Input Class Initialized
INFO - 2024-02-06 13:23:30 --> Language Class Initialized
INFO - 2024-02-06 13:23:30 --> Loader Class Initialized
INFO - 2024-02-06 13:23:30 --> Helper loaded: url_helper
INFO - 2024-02-06 13:23:30 --> Helper loaded: file_helper
INFO - 2024-02-06 13:23:30 --> Helper loaded: html_helper
INFO - 2024-02-06 13:23:30 --> Helper loaded: text_helper
INFO - 2024-02-06 13:23:30 --> Helper loaded: form_helper
INFO - 2024-02-06 13:23:30 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:23:30 --> Helper loaded: security_helper
INFO - 2024-02-06 13:23:30 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:23:30 --> Database Driver Class Initialized
INFO - 2024-02-06 13:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:23:30 --> Parser Class Initialized
INFO - 2024-02-06 13:23:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:23:30 --> Pagination Class Initialized
INFO - 2024-02-06 13:23:30 --> Form Validation Class Initialized
INFO - 2024-02-06 13:23:30 --> Controller Class Initialized
INFO - 2024-02-06 13:23:30 --> Model Class Initialized
DEBUG - 2024-02-06 13:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:23:30 --> Model Class Initialized
DEBUG - 2024-02-06 13:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:23:30 --> Model Class Initialized
INFO - 2024-02-06 13:23:30 --> Model Class Initialized
INFO - 2024-02-06 13:23:30 --> Model Class Initialized
INFO - 2024-02-06 13:23:30 --> Model Class Initialized
DEBUG - 2024-02-06 13:23:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:23:30 --> Model Class Initialized
INFO - 2024-02-06 13:23:30 --> Model Class Initialized
INFO - 2024-02-06 13:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 13:23:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 13:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 13:23:30 --> Model Class Initialized
INFO - 2024-02-06 13:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 13:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 13:23:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 13:23:30 --> Final output sent to browser
DEBUG - 2024-02-06 13:23:30 --> Total execution time: 0.4005
ERROR - 2024-02-06 13:24:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:24:03 --> Config Class Initialized
INFO - 2024-02-06 13:24:03 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:24:03 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:24:03 --> Utf8 Class Initialized
INFO - 2024-02-06 13:24:03 --> URI Class Initialized
DEBUG - 2024-02-06 13:24:03 --> No URI present. Default controller set.
INFO - 2024-02-06 13:24:03 --> Router Class Initialized
INFO - 2024-02-06 13:24:03 --> Output Class Initialized
INFO - 2024-02-06 13:24:03 --> Security Class Initialized
DEBUG - 2024-02-06 13:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:24:03 --> Input Class Initialized
INFO - 2024-02-06 13:24:03 --> Language Class Initialized
INFO - 2024-02-06 13:24:03 --> Loader Class Initialized
INFO - 2024-02-06 13:24:03 --> Helper loaded: url_helper
INFO - 2024-02-06 13:24:03 --> Helper loaded: file_helper
INFO - 2024-02-06 13:24:03 --> Helper loaded: html_helper
INFO - 2024-02-06 13:24:03 --> Helper loaded: text_helper
INFO - 2024-02-06 13:24:03 --> Helper loaded: form_helper
INFO - 2024-02-06 13:24:03 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:24:03 --> Helper loaded: security_helper
INFO - 2024-02-06 13:24:03 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:24:03 --> Database Driver Class Initialized
INFO - 2024-02-06 13:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:24:03 --> Parser Class Initialized
INFO - 2024-02-06 13:24:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:24:03 --> Pagination Class Initialized
INFO - 2024-02-06 13:24:03 --> Form Validation Class Initialized
INFO - 2024-02-06 13:24:03 --> Controller Class Initialized
INFO - 2024-02-06 13:24:03 --> Model Class Initialized
DEBUG - 2024-02-06 13:24:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:24:03 --> Model Class Initialized
DEBUG - 2024-02-06 13:24:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:24:03 --> Model Class Initialized
INFO - 2024-02-06 13:24:03 --> Model Class Initialized
INFO - 2024-02-06 13:24:03 --> Model Class Initialized
INFO - 2024-02-06 13:24:03 --> Model Class Initialized
DEBUG - 2024-02-06 13:24:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:24:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:24:03 --> Model Class Initialized
INFO - 2024-02-06 13:24:03 --> Model Class Initialized
INFO - 2024-02-06 13:24:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 13:24:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:24:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 13:24:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 13:24:04 --> Model Class Initialized
INFO - 2024-02-06 13:24:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 13:24:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 13:24:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 13:24:04 --> Final output sent to browser
DEBUG - 2024-02-06 13:24:04 --> Total execution time: 0.4377
ERROR - 2024-02-06 13:24:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:24:12 --> Config Class Initialized
INFO - 2024-02-06 13:24:12 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:24:12 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:24:12 --> Utf8 Class Initialized
INFO - 2024-02-06 13:24:12 --> URI Class Initialized
INFO - 2024-02-06 13:24:12 --> Router Class Initialized
INFO - 2024-02-06 13:24:12 --> Output Class Initialized
INFO - 2024-02-06 13:24:12 --> Security Class Initialized
DEBUG - 2024-02-06 13:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:24:12 --> Input Class Initialized
INFO - 2024-02-06 13:24:12 --> Language Class Initialized
INFO - 2024-02-06 13:24:12 --> Loader Class Initialized
INFO - 2024-02-06 13:24:12 --> Helper loaded: url_helper
INFO - 2024-02-06 13:24:12 --> Helper loaded: file_helper
INFO - 2024-02-06 13:24:12 --> Helper loaded: html_helper
INFO - 2024-02-06 13:24:12 --> Helper loaded: text_helper
INFO - 2024-02-06 13:24:12 --> Helper loaded: form_helper
INFO - 2024-02-06 13:24:12 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:24:12 --> Helper loaded: security_helper
INFO - 2024-02-06 13:24:12 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:24:12 --> Database Driver Class Initialized
INFO - 2024-02-06 13:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:24:12 --> Parser Class Initialized
INFO - 2024-02-06 13:24:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:24:12 --> Pagination Class Initialized
INFO - 2024-02-06 13:24:12 --> Form Validation Class Initialized
INFO - 2024-02-06 13:24:12 --> Controller Class Initialized
INFO - 2024-02-06 13:24:12 --> Model Class Initialized
DEBUG - 2024-02-06 13:24:12 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:24:12 --> Final output sent to browser
DEBUG - 2024-02-06 13:24:12 --> Total execution time: 0.0132
ERROR - 2024-02-06 13:24:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:24:13 --> Config Class Initialized
INFO - 2024-02-06 13:24:13 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:24:13 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:24:13 --> Utf8 Class Initialized
INFO - 2024-02-06 13:24:13 --> URI Class Initialized
INFO - 2024-02-06 13:24:13 --> Router Class Initialized
INFO - 2024-02-06 13:24:13 --> Output Class Initialized
INFO - 2024-02-06 13:24:13 --> Security Class Initialized
DEBUG - 2024-02-06 13:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:24:13 --> Input Class Initialized
INFO - 2024-02-06 13:24:13 --> Language Class Initialized
INFO - 2024-02-06 13:24:13 --> Loader Class Initialized
INFO - 2024-02-06 13:24:13 --> Helper loaded: url_helper
INFO - 2024-02-06 13:24:13 --> Helper loaded: file_helper
INFO - 2024-02-06 13:24:13 --> Helper loaded: html_helper
INFO - 2024-02-06 13:24:13 --> Helper loaded: text_helper
INFO - 2024-02-06 13:24:13 --> Helper loaded: form_helper
INFO - 2024-02-06 13:24:13 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:24:13 --> Helper loaded: security_helper
INFO - 2024-02-06 13:24:13 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:24:13 --> Database Driver Class Initialized
INFO - 2024-02-06 13:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:24:13 --> Parser Class Initialized
INFO - 2024-02-06 13:24:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:24:13 --> Pagination Class Initialized
INFO - 2024-02-06 13:24:13 --> Form Validation Class Initialized
INFO - 2024-02-06 13:24:13 --> Controller Class Initialized
INFO - 2024-02-06 13:24:13 --> Model Class Initialized
DEBUG - 2024-02-06 13:24:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:24:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-06 13:24:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:24:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 13:24:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 13:24:13 --> Model Class Initialized
INFO - 2024-02-06 13:24:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 13:24:13 --> Final output sent to browser
DEBUG - 2024-02-06 13:24:13 --> Total execution time: 0.0287
ERROR - 2024-02-06 13:24:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:24:20 --> Config Class Initialized
INFO - 2024-02-06 13:24:20 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:24:20 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:24:20 --> Utf8 Class Initialized
INFO - 2024-02-06 13:24:20 --> URI Class Initialized
INFO - 2024-02-06 13:24:20 --> Router Class Initialized
INFO - 2024-02-06 13:24:20 --> Output Class Initialized
INFO - 2024-02-06 13:24:20 --> Security Class Initialized
DEBUG - 2024-02-06 13:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:24:20 --> Input Class Initialized
INFO - 2024-02-06 13:24:20 --> Language Class Initialized
INFO - 2024-02-06 13:24:20 --> Loader Class Initialized
INFO - 2024-02-06 13:24:20 --> Helper loaded: url_helper
INFO - 2024-02-06 13:24:20 --> Helper loaded: file_helper
INFO - 2024-02-06 13:24:20 --> Helper loaded: html_helper
INFO - 2024-02-06 13:24:20 --> Helper loaded: text_helper
INFO - 2024-02-06 13:24:20 --> Helper loaded: form_helper
INFO - 2024-02-06 13:24:20 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:24:20 --> Helper loaded: security_helper
INFO - 2024-02-06 13:24:20 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:24:20 --> Database Driver Class Initialized
INFO - 2024-02-06 13:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:24:20 --> Parser Class Initialized
INFO - 2024-02-06 13:24:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:24:20 --> Pagination Class Initialized
INFO - 2024-02-06 13:24:20 --> Form Validation Class Initialized
INFO - 2024-02-06 13:24:20 --> Controller Class Initialized
INFO - 2024-02-06 13:24:20 --> Model Class Initialized
DEBUG - 2024-02-06 13:24:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:24:20 --> Model Class Initialized
INFO - 2024-02-06 13:24:20 --> Final output sent to browser
DEBUG - 2024-02-06 13:24:20 --> Total execution time: 0.0172
ERROR - 2024-02-06 13:24:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:24:21 --> Config Class Initialized
INFO - 2024-02-06 13:24:21 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:24:21 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:24:21 --> Utf8 Class Initialized
INFO - 2024-02-06 13:24:21 --> URI Class Initialized
DEBUG - 2024-02-06 13:24:21 --> No URI present. Default controller set.
INFO - 2024-02-06 13:24:21 --> Router Class Initialized
INFO - 2024-02-06 13:24:21 --> Output Class Initialized
INFO - 2024-02-06 13:24:21 --> Security Class Initialized
DEBUG - 2024-02-06 13:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:24:21 --> Input Class Initialized
INFO - 2024-02-06 13:24:21 --> Language Class Initialized
INFO - 2024-02-06 13:24:21 --> Loader Class Initialized
INFO - 2024-02-06 13:24:21 --> Helper loaded: url_helper
INFO - 2024-02-06 13:24:21 --> Helper loaded: file_helper
INFO - 2024-02-06 13:24:21 --> Helper loaded: html_helper
INFO - 2024-02-06 13:24:21 --> Helper loaded: text_helper
INFO - 2024-02-06 13:24:21 --> Helper loaded: form_helper
INFO - 2024-02-06 13:24:21 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:24:21 --> Helper loaded: security_helper
INFO - 2024-02-06 13:24:21 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:24:21 --> Database Driver Class Initialized
INFO - 2024-02-06 13:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:24:21 --> Parser Class Initialized
INFO - 2024-02-06 13:24:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:24:21 --> Pagination Class Initialized
INFO - 2024-02-06 13:24:21 --> Form Validation Class Initialized
INFO - 2024-02-06 13:24:21 --> Controller Class Initialized
INFO - 2024-02-06 13:24:21 --> Model Class Initialized
DEBUG - 2024-02-06 13:24:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:24:21 --> Model Class Initialized
DEBUG - 2024-02-06 13:24:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:24:21 --> Model Class Initialized
INFO - 2024-02-06 13:24:21 --> Model Class Initialized
INFO - 2024-02-06 13:24:21 --> Model Class Initialized
INFO - 2024-02-06 13:24:21 --> Model Class Initialized
DEBUG - 2024-02-06 13:24:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:24:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:24:21 --> Model Class Initialized
INFO - 2024-02-06 13:24:21 --> Model Class Initialized
INFO - 2024-02-06 13:24:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 13:24:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:24:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 13:24:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 13:24:21 --> Model Class Initialized
INFO - 2024-02-06 13:24:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 13:24:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 13:24:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 13:24:21 --> Final output sent to browser
DEBUG - 2024-02-06 13:24:21 --> Total execution time: 0.2283
ERROR - 2024-02-06 13:39:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:39:37 --> Config Class Initialized
INFO - 2024-02-06 13:39:37 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:39:37 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:39:37 --> Utf8 Class Initialized
INFO - 2024-02-06 13:39:37 --> URI Class Initialized
DEBUG - 2024-02-06 13:39:37 --> No URI present. Default controller set.
INFO - 2024-02-06 13:39:37 --> Router Class Initialized
INFO - 2024-02-06 13:39:37 --> Output Class Initialized
INFO - 2024-02-06 13:39:37 --> Security Class Initialized
DEBUG - 2024-02-06 13:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:39:37 --> Input Class Initialized
INFO - 2024-02-06 13:39:37 --> Language Class Initialized
INFO - 2024-02-06 13:39:37 --> Loader Class Initialized
INFO - 2024-02-06 13:39:37 --> Helper loaded: url_helper
INFO - 2024-02-06 13:39:37 --> Helper loaded: file_helper
INFO - 2024-02-06 13:39:37 --> Helper loaded: html_helper
INFO - 2024-02-06 13:39:37 --> Helper loaded: text_helper
INFO - 2024-02-06 13:39:37 --> Helper loaded: form_helper
INFO - 2024-02-06 13:39:37 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:39:37 --> Helper loaded: security_helper
INFO - 2024-02-06 13:39:37 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:39:37 --> Database Driver Class Initialized
INFO - 2024-02-06 13:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:39:37 --> Parser Class Initialized
INFO - 2024-02-06 13:39:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:39:37 --> Pagination Class Initialized
INFO - 2024-02-06 13:39:37 --> Form Validation Class Initialized
INFO - 2024-02-06 13:39:37 --> Controller Class Initialized
INFO - 2024-02-06 13:39:37 --> Model Class Initialized
DEBUG - 2024-02-06 13:39:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-06 13:39:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:39:38 --> Config Class Initialized
INFO - 2024-02-06 13:39:38 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:39:38 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:39:38 --> Utf8 Class Initialized
INFO - 2024-02-06 13:39:38 --> URI Class Initialized
INFO - 2024-02-06 13:39:38 --> Router Class Initialized
INFO - 2024-02-06 13:39:38 --> Output Class Initialized
INFO - 2024-02-06 13:39:38 --> Security Class Initialized
DEBUG - 2024-02-06 13:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:39:38 --> Input Class Initialized
INFO - 2024-02-06 13:39:38 --> Language Class Initialized
INFO - 2024-02-06 13:39:38 --> Loader Class Initialized
INFO - 2024-02-06 13:39:38 --> Helper loaded: url_helper
INFO - 2024-02-06 13:39:38 --> Helper loaded: file_helper
INFO - 2024-02-06 13:39:38 --> Helper loaded: html_helper
INFO - 2024-02-06 13:39:38 --> Helper loaded: text_helper
INFO - 2024-02-06 13:39:38 --> Helper loaded: form_helper
INFO - 2024-02-06 13:39:38 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:39:38 --> Helper loaded: security_helper
INFO - 2024-02-06 13:39:38 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:39:38 --> Database Driver Class Initialized
INFO - 2024-02-06 13:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:39:38 --> Parser Class Initialized
INFO - 2024-02-06 13:39:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:39:38 --> Pagination Class Initialized
INFO - 2024-02-06 13:39:38 --> Form Validation Class Initialized
INFO - 2024-02-06 13:39:38 --> Controller Class Initialized
INFO - 2024-02-06 13:39:38 --> Model Class Initialized
DEBUG - 2024-02-06 13:39:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:39:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-06 13:39:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:39:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 13:39:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 13:39:38 --> Model Class Initialized
INFO - 2024-02-06 13:39:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 13:39:38 --> Final output sent to browser
DEBUG - 2024-02-06 13:39:38 --> Total execution time: 0.0306
ERROR - 2024-02-06 13:41:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:41:07 --> Config Class Initialized
INFO - 2024-02-06 13:41:07 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:41:07 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:41:07 --> Utf8 Class Initialized
INFO - 2024-02-06 13:41:07 --> URI Class Initialized
INFO - 2024-02-06 13:41:07 --> Router Class Initialized
INFO - 2024-02-06 13:41:07 --> Output Class Initialized
INFO - 2024-02-06 13:41:07 --> Security Class Initialized
DEBUG - 2024-02-06 13:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:41:07 --> Input Class Initialized
INFO - 2024-02-06 13:41:07 --> Language Class Initialized
INFO - 2024-02-06 13:41:07 --> Loader Class Initialized
INFO - 2024-02-06 13:41:07 --> Helper loaded: url_helper
INFO - 2024-02-06 13:41:07 --> Helper loaded: file_helper
INFO - 2024-02-06 13:41:07 --> Helper loaded: html_helper
INFO - 2024-02-06 13:41:07 --> Helper loaded: text_helper
INFO - 2024-02-06 13:41:07 --> Helper loaded: form_helper
INFO - 2024-02-06 13:41:07 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:41:07 --> Helper loaded: security_helper
INFO - 2024-02-06 13:41:07 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:41:07 --> Database Driver Class Initialized
INFO - 2024-02-06 13:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:41:07 --> Parser Class Initialized
INFO - 2024-02-06 13:41:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:41:07 --> Pagination Class Initialized
INFO - 2024-02-06 13:41:07 --> Form Validation Class Initialized
INFO - 2024-02-06 13:41:07 --> Controller Class Initialized
INFO - 2024-02-06 13:41:07 --> Model Class Initialized
DEBUG - 2024-02-06 13:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:41:07 --> Model Class Initialized
INFO - 2024-02-06 13:41:07 --> Final output sent to browser
DEBUG - 2024-02-06 13:41:07 --> Total execution time: 0.0195
ERROR - 2024-02-06 13:41:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:41:07 --> Config Class Initialized
INFO - 2024-02-06 13:41:07 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:41:07 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:41:07 --> Utf8 Class Initialized
INFO - 2024-02-06 13:41:07 --> URI Class Initialized
DEBUG - 2024-02-06 13:41:07 --> No URI present. Default controller set.
INFO - 2024-02-06 13:41:07 --> Router Class Initialized
INFO - 2024-02-06 13:41:07 --> Output Class Initialized
INFO - 2024-02-06 13:41:07 --> Security Class Initialized
DEBUG - 2024-02-06 13:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:41:07 --> Input Class Initialized
INFO - 2024-02-06 13:41:07 --> Language Class Initialized
INFO - 2024-02-06 13:41:07 --> Loader Class Initialized
INFO - 2024-02-06 13:41:07 --> Helper loaded: url_helper
INFO - 2024-02-06 13:41:07 --> Helper loaded: file_helper
INFO - 2024-02-06 13:41:07 --> Helper loaded: html_helper
INFO - 2024-02-06 13:41:07 --> Helper loaded: text_helper
INFO - 2024-02-06 13:41:07 --> Helper loaded: form_helper
INFO - 2024-02-06 13:41:07 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:41:07 --> Helper loaded: security_helper
INFO - 2024-02-06 13:41:07 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:41:07 --> Database Driver Class Initialized
INFO - 2024-02-06 13:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:41:07 --> Parser Class Initialized
INFO - 2024-02-06 13:41:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:41:07 --> Pagination Class Initialized
INFO - 2024-02-06 13:41:07 --> Form Validation Class Initialized
INFO - 2024-02-06 13:41:07 --> Controller Class Initialized
INFO - 2024-02-06 13:41:07 --> Model Class Initialized
DEBUG - 2024-02-06 13:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:41:07 --> Model Class Initialized
DEBUG - 2024-02-06 13:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:41:07 --> Model Class Initialized
INFO - 2024-02-06 13:41:07 --> Model Class Initialized
INFO - 2024-02-06 13:41:07 --> Model Class Initialized
INFO - 2024-02-06 13:41:07 --> Model Class Initialized
DEBUG - 2024-02-06 13:41:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:41:07 --> Model Class Initialized
INFO - 2024-02-06 13:41:07 --> Model Class Initialized
INFO - 2024-02-06 13:41:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 13:41:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:41:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 13:41:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 13:41:07 --> Model Class Initialized
INFO - 2024-02-06 13:41:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 13:41:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 13:41:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 13:41:07 --> Final output sent to browser
DEBUG - 2024-02-06 13:41:07 --> Total execution time: 0.2316
ERROR - 2024-02-06 13:41:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:41:16 --> Config Class Initialized
INFO - 2024-02-06 13:41:16 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:41:16 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:41:16 --> Utf8 Class Initialized
INFO - 2024-02-06 13:41:16 --> URI Class Initialized
INFO - 2024-02-06 13:41:16 --> Router Class Initialized
INFO - 2024-02-06 13:41:16 --> Output Class Initialized
INFO - 2024-02-06 13:41:16 --> Security Class Initialized
DEBUG - 2024-02-06 13:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:41:16 --> Input Class Initialized
INFO - 2024-02-06 13:41:16 --> Language Class Initialized
INFO - 2024-02-06 13:41:16 --> Loader Class Initialized
INFO - 2024-02-06 13:41:16 --> Helper loaded: url_helper
INFO - 2024-02-06 13:41:16 --> Helper loaded: file_helper
INFO - 2024-02-06 13:41:16 --> Helper loaded: html_helper
INFO - 2024-02-06 13:41:16 --> Helper loaded: text_helper
INFO - 2024-02-06 13:41:16 --> Helper loaded: form_helper
INFO - 2024-02-06 13:41:16 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:41:16 --> Helper loaded: security_helper
INFO - 2024-02-06 13:41:16 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:41:16 --> Database Driver Class Initialized
INFO - 2024-02-06 13:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:41:16 --> Parser Class Initialized
INFO - 2024-02-06 13:41:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:41:16 --> Pagination Class Initialized
INFO - 2024-02-06 13:41:16 --> Form Validation Class Initialized
INFO - 2024-02-06 13:41:16 --> Controller Class Initialized
INFO - 2024-02-06 13:41:16 --> Model Class Initialized
DEBUG - 2024-02-06 13:41:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:41:16 --> Model Class Initialized
DEBUG - 2024-02-06 13:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:41:16 --> Model Class Initialized
INFO - 2024-02-06 13:41:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-06 13:41:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:41:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 13:41:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 13:41:16 --> Model Class Initialized
INFO - 2024-02-06 13:41:16 --> Model Class Initialized
INFO - 2024-02-06 13:41:16 --> Model Class Initialized
INFO - 2024-02-06 13:41:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 13:41:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 13:41:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 13:41:16 --> Final output sent to browser
DEBUG - 2024-02-06 13:41:16 --> Total execution time: 0.1574
ERROR - 2024-02-06 13:41:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:41:17 --> Config Class Initialized
INFO - 2024-02-06 13:41:17 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:41:17 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:41:17 --> Utf8 Class Initialized
INFO - 2024-02-06 13:41:17 --> URI Class Initialized
INFO - 2024-02-06 13:41:17 --> Router Class Initialized
INFO - 2024-02-06 13:41:17 --> Output Class Initialized
INFO - 2024-02-06 13:41:17 --> Security Class Initialized
DEBUG - 2024-02-06 13:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:41:17 --> Input Class Initialized
INFO - 2024-02-06 13:41:17 --> Language Class Initialized
INFO - 2024-02-06 13:41:17 --> Loader Class Initialized
INFO - 2024-02-06 13:41:17 --> Helper loaded: url_helper
INFO - 2024-02-06 13:41:17 --> Helper loaded: file_helper
INFO - 2024-02-06 13:41:17 --> Helper loaded: html_helper
INFO - 2024-02-06 13:41:17 --> Helper loaded: text_helper
INFO - 2024-02-06 13:41:17 --> Helper loaded: form_helper
INFO - 2024-02-06 13:41:17 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:41:17 --> Helper loaded: security_helper
INFO - 2024-02-06 13:41:17 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:41:17 --> Database Driver Class Initialized
INFO - 2024-02-06 13:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:41:17 --> Parser Class Initialized
INFO - 2024-02-06 13:41:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:41:17 --> Pagination Class Initialized
INFO - 2024-02-06 13:41:17 --> Form Validation Class Initialized
INFO - 2024-02-06 13:41:17 --> Controller Class Initialized
INFO - 2024-02-06 13:41:17 --> Model Class Initialized
DEBUG - 2024-02-06 13:41:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:41:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:41:17 --> Model Class Initialized
DEBUG - 2024-02-06 13:41:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:41:17 --> Model Class Initialized
INFO - 2024-02-06 13:41:17 --> Final output sent to browser
DEBUG - 2024-02-06 13:41:17 --> Total execution time: 0.0409
ERROR - 2024-02-06 13:41:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:41:21 --> Config Class Initialized
INFO - 2024-02-06 13:41:21 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:41:21 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:41:21 --> Utf8 Class Initialized
INFO - 2024-02-06 13:41:21 --> URI Class Initialized
INFO - 2024-02-06 13:41:21 --> Router Class Initialized
INFO - 2024-02-06 13:41:21 --> Output Class Initialized
INFO - 2024-02-06 13:41:21 --> Security Class Initialized
DEBUG - 2024-02-06 13:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:41:21 --> Input Class Initialized
INFO - 2024-02-06 13:41:21 --> Language Class Initialized
INFO - 2024-02-06 13:41:21 --> Loader Class Initialized
INFO - 2024-02-06 13:41:21 --> Helper loaded: url_helper
INFO - 2024-02-06 13:41:21 --> Helper loaded: file_helper
INFO - 2024-02-06 13:41:21 --> Helper loaded: html_helper
INFO - 2024-02-06 13:41:21 --> Helper loaded: text_helper
INFO - 2024-02-06 13:41:21 --> Helper loaded: form_helper
INFO - 2024-02-06 13:41:21 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:41:21 --> Helper loaded: security_helper
INFO - 2024-02-06 13:41:21 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:41:21 --> Database Driver Class Initialized
INFO - 2024-02-06 13:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:41:21 --> Parser Class Initialized
INFO - 2024-02-06 13:41:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:41:21 --> Pagination Class Initialized
INFO - 2024-02-06 13:41:21 --> Form Validation Class Initialized
INFO - 2024-02-06 13:41:21 --> Controller Class Initialized
INFO - 2024-02-06 13:41:21 --> Model Class Initialized
DEBUG - 2024-02-06 13:41:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:41:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:41:21 --> Model Class Initialized
DEBUG - 2024-02-06 13:41:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:41:21 --> Model Class Initialized
INFO - 2024-02-06 13:41:21 --> Final output sent to browser
DEBUG - 2024-02-06 13:41:21 --> Total execution time: 0.1212
ERROR - 2024-02-06 13:41:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:41:28 --> Config Class Initialized
INFO - 2024-02-06 13:41:28 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:41:28 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:41:28 --> Utf8 Class Initialized
INFO - 2024-02-06 13:41:28 --> URI Class Initialized
DEBUG - 2024-02-06 13:41:28 --> No URI present. Default controller set.
INFO - 2024-02-06 13:41:28 --> Router Class Initialized
INFO - 2024-02-06 13:41:28 --> Output Class Initialized
INFO - 2024-02-06 13:41:28 --> Security Class Initialized
DEBUG - 2024-02-06 13:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:41:28 --> Input Class Initialized
INFO - 2024-02-06 13:41:28 --> Language Class Initialized
INFO - 2024-02-06 13:41:28 --> Loader Class Initialized
INFO - 2024-02-06 13:41:28 --> Helper loaded: url_helper
INFO - 2024-02-06 13:41:28 --> Helper loaded: file_helper
INFO - 2024-02-06 13:41:28 --> Helper loaded: html_helper
INFO - 2024-02-06 13:41:28 --> Helper loaded: text_helper
INFO - 2024-02-06 13:41:28 --> Helper loaded: form_helper
INFO - 2024-02-06 13:41:28 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:41:28 --> Helper loaded: security_helper
INFO - 2024-02-06 13:41:28 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:41:28 --> Database Driver Class Initialized
INFO - 2024-02-06 13:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:41:28 --> Parser Class Initialized
INFO - 2024-02-06 13:41:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:41:28 --> Pagination Class Initialized
INFO - 2024-02-06 13:41:28 --> Form Validation Class Initialized
INFO - 2024-02-06 13:41:28 --> Controller Class Initialized
INFO - 2024-02-06 13:41:28 --> Model Class Initialized
DEBUG - 2024-02-06 13:41:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:41:28 --> Model Class Initialized
DEBUG - 2024-02-06 13:41:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:41:28 --> Model Class Initialized
INFO - 2024-02-06 13:41:28 --> Model Class Initialized
INFO - 2024-02-06 13:41:28 --> Model Class Initialized
INFO - 2024-02-06 13:41:28 --> Model Class Initialized
DEBUG - 2024-02-06 13:41:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:41:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:41:28 --> Model Class Initialized
INFO - 2024-02-06 13:41:28 --> Model Class Initialized
INFO - 2024-02-06 13:41:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 13:41:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:41:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 13:41:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 13:41:28 --> Model Class Initialized
INFO - 2024-02-06 13:41:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 13:41:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 13:41:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 13:41:29 --> Final output sent to browser
DEBUG - 2024-02-06 13:41:29 --> Total execution time: 0.2316
ERROR - 2024-02-06 13:41:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:41:37 --> Config Class Initialized
INFO - 2024-02-06 13:41:37 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:41:37 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:41:37 --> Utf8 Class Initialized
INFO - 2024-02-06 13:41:37 --> URI Class Initialized
INFO - 2024-02-06 13:41:37 --> Router Class Initialized
INFO - 2024-02-06 13:41:37 --> Output Class Initialized
INFO - 2024-02-06 13:41:37 --> Security Class Initialized
DEBUG - 2024-02-06 13:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:41:37 --> Input Class Initialized
INFO - 2024-02-06 13:41:37 --> Language Class Initialized
INFO - 2024-02-06 13:41:37 --> Loader Class Initialized
INFO - 2024-02-06 13:41:37 --> Helper loaded: url_helper
INFO - 2024-02-06 13:41:37 --> Helper loaded: file_helper
INFO - 2024-02-06 13:41:37 --> Helper loaded: html_helper
INFO - 2024-02-06 13:41:37 --> Helper loaded: text_helper
INFO - 2024-02-06 13:41:37 --> Helper loaded: form_helper
INFO - 2024-02-06 13:41:37 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:41:37 --> Helper loaded: security_helper
INFO - 2024-02-06 13:41:37 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:41:37 --> Database Driver Class Initialized
INFO - 2024-02-06 13:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:41:37 --> Parser Class Initialized
INFO - 2024-02-06 13:41:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:41:37 --> Pagination Class Initialized
INFO - 2024-02-06 13:41:37 --> Form Validation Class Initialized
INFO - 2024-02-06 13:41:37 --> Controller Class Initialized
INFO - 2024-02-06 13:41:37 --> Model Class Initialized
DEBUG - 2024-02-06 13:41:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:41:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:41:37 --> Model Class Initialized
DEBUG - 2024-02-06 13:41:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:41:37 --> Model Class Initialized
INFO - 2024-02-06 13:41:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-06 13:41:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:41:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 13:41:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 13:41:37 --> Model Class Initialized
INFO - 2024-02-06 13:41:37 --> Model Class Initialized
INFO - 2024-02-06 13:41:37 --> Model Class Initialized
INFO - 2024-02-06 13:41:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 13:41:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 13:41:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 13:41:37 --> Final output sent to browser
DEBUG - 2024-02-06 13:41:37 --> Total execution time: 0.1886
ERROR - 2024-02-06 13:41:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:41:48 --> Config Class Initialized
INFO - 2024-02-06 13:41:48 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:41:48 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:41:48 --> Utf8 Class Initialized
INFO - 2024-02-06 13:41:48 --> URI Class Initialized
INFO - 2024-02-06 13:41:48 --> Router Class Initialized
INFO - 2024-02-06 13:41:48 --> Output Class Initialized
INFO - 2024-02-06 13:41:48 --> Security Class Initialized
DEBUG - 2024-02-06 13:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:41:48 --> Input Class Initialized
INFO - 2024-02-06 13:41:48 --> Language Class Initialized
INFO - 2024-02-06 13:41:48 --> Loader Class Initialized
INFO - 2024-02-06 13:41:48 --> Helper loaded: url_helper
INFO - 2024-02-06 13:41:48 --> Helper loaded: file_helper
INFO - 2024-02-06 13:41:48 --> Helper loaded: html_helper
INFO - 2024-02-06 13:41:48 --> Helper loaded: text_helper
INFO - 2024-02-06 13:41:48 --> Helper loaded: form_helper
INFO - 2024-02-06 13:41:48 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:41:48 --> Helper loaded: security_helper
INFO - 2024-02-06 13:41:48 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:41:48 --> Database Driver Class Initialized
INFO - 2024-02-06 13:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:41:48 --> Parser Class Initialized
INFO - 2024-02-06 13:41:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:41:48 --> Pagination Class Initialized
INFO - 2024-02-06 13:41:48 --> Form Validation Class Initialized
INFO - 2024-02-06 13:41:48 --> Controller Class Initialized
INFO - 2024-02-06 13:41:48 --> Model Class Initialized
DEBUG - 2024-02-06 13:41:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:41:48 --> Final output sent to browser
DEBUG - 2024-02-06 13:41:48 --> Total execution time: 0.0195
ERROR - 2024-02-06 13:41:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:41:54 --> Config Class Initialized
INFO - 2024-02-06 13:41:54 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:41:54 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:41:54 --> Utf8 Class Initialized
INFO - 2024-02-06 13:41:54 --> URI Class Initialized
INFO - 2024-02-06 13:41:54 --> Router Class Initialized
INFO - 2024-02-06 13:41:54 --> Output Class Initialized
INFO - 2024-02-06 13:41:54 --> Security Class Initialized
DEBUG - 2024-02-06 13:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:41:54 --> Input Class Initialized
INFO - 2024-02-06 13:41:54 --> Language Class Initialized
INFO - 2024-02-06 13:41:54 --> Loader Class Initialized
INFO - 2024-02-06 13:41:54 --> Helper loaded: url_helper
INFO - 2024-02-06 13:41:54 --> Helper loaded: file_helper
INFO - 2024-02-06 13:41:54 --> Helper loaded: html_helper
INFO - 2024-02-06 13:41:54 --> Helper loaded: text_helper
INFO - 2024-02-06 13:41:54 --> Helper loaded: form_helper
INFO - 2024-02-06 13:41:54 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:41:54 --> Helper loaded: security_helper
INFO - 2024-02-06 13:41:54 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:41:54 --> Database Driver Class Initialized
INFO - 2024-02-06 13:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:41:54 --> Parser Class Initialized
INFO - 2024-02-06 13:41:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:41:54 --> Pagination Class Initialized
INFO - 2024-02-06 13:41:54 --> Form Validation Class Initialized
INFO - 2024-02-06 13:41:54 --> Controller Class Initialized
INFO - 2024-02-06 13:41:54 --> Model Class Initialized
DEBUG - 2024-02-06 13:41:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-06 13:41:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-06 13:41:54 --> Final output sent to browser
DEBUG - 2024-02-06 13:41:54 --> Total execution time: 0.0153
ERROR - 2024-02-06 13:41:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:41:58 --> Config Class Initialized
INFO - 2024-02-06 13:41:58 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:41:58 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:41:58 --> Utf8 Class Initialized
INFO - 2024-02-06 13:41:58 --> URI Class Initialized
INFO - 2024-02-06 13:41:58 --> Router Class Initialized
INFO - 2024-02-06 13:41:58 --> Output Class Initialized
INFO - 2024-02-06 13:41:58 --> Security Class Initialized
DEBUG - 2024-02-06 13:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:41:58 --> Input Class Initialized
INFO - 2024-02-06 13:41:58 --> Language Class Initialized
INFO - 2024-02-06 13:41:58 --> Loader Class Initialized
INFO - 2024-02-06 13:41:58 --> Helper loaded: url_helper
INFO - 2024-02-06 13:41:58 --> Helper loaded: file_helper
INFO - 2024-02-06 13:41:58 --> Helper loaded: html_helper
INFO - 2024-02-06 13:41:58 --> Helper loaded: text_helper
INFO - 2024-02-06 13:41:58 --> Helper loaded: form_helper
INFO - 2024-02-06 13:41:58 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:41:58 --> Helper loaded: security_helper
INFO - 2024-02-06 13:41:58 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:41:58 --> Database Driver Class Initialized
INFO - 2024-02-06 13:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:41:58 --> Parser Class Initialized
INFO - 2024-02-06 13:41:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:41:58 --> Pagination Class Initialized
INFO - 2024-02-06 13:41:58 --> Form Validation Class Initialized
INFO - 2024-02-06 13:41:58 --> Controller Class Initialized
INFO - 2024-02-06 13:41:58 --> Model Class Initialized
DEBUG - 2024-02-06 13:41:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:41:58 --> Final output sent to browser
DEBUG - 2024-02-06 13:41:58 --> Total execution time: 0.0147
ERROR - 2024-02-06 13:42:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:42:00 --> Config Class Initialized
INFO - 2024-02-06 13:42:00 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:42:00 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:42:00 --> Utf8 Class Initialized
INFO - 2024-02-06 13:42:00 --> URI Class Initialized
INFO - 2024-02-06 13:42:00 --> Router Class Initialized
INFO - 2024-02-06 13:42:00 --> Output Class Initialized
INFO - 2024-02-06 13:42:00 --> Security Class Initialized
DEBUG - 2024-02-06 13:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:42:00 --> Input Class Initialized
INFO - 2024-02-06 13:42:00 --> Language Class Initialized
INFO - 2024-02-06 13:42:00 --> Loader Class Initialized
INFO - 2024-02-06 13:42:00 --> Helper loaded: url_helper
INFO - 2024-02-06 13:42:00 --> Helper loaded: file_helper
INFO - 2024-02-06 13:42:00 --> Helper loaded: html_helper
INFO - 2024-02-06 13:42:00 --> Helper loaded: text_helper
INFO - 2024-02-06 13:42:00 --> Helper loaded: form_helper
INFO - 2024-02-06 13:42:00 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:42:00 --> Helper loaded: security_helper
INFO - 2024-02-06 13:42:00 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:42:00 --> Database Driver Class Initialized
INFO - 2024-02-06 13:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:42:00 --> Parser Class Initialized
INFO - 2024-02-06 13:42:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:42:00 --> Pagination Class Initialized
INFO - 2024-02-06 13:42:00 --> Form Validation Class Initialized
INFO - 2024-02-06 13:42:00 --> Controller Class Initialized
INFO - 2024-02-06 13:42:00 --> Model Class Initialized
DEBUG - 2024-02-06 13:42:00 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:42:00 --> Final output sent to browser
DEBUG - 2024-02-06 13:42:00 --> Total execution time: 0.0190
ERROR - 2024-02-06 13:42:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:42:10 --> Config Class Initialized
INFO - 2024-02-06 13:42:10 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:42:10 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:42:10 --> Utf8 Class Initialized
INFO - 2024-02-06 13:42:10 --> URI Class Initialized
INFO - 2024-02-06 13:42:10 --> Router Class Initialized
INFO - 2024-02-06 13:42:10 --> Output Class Initialized
INFO - 2024-02-06 13:42:10 --> Security Class Initialized
DEBUG - 2024-02-06 13:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:42:10 --> Input Class Initialized
INFO - 2024-02-06 13:42:10 --> Language Class Initialized
INFO - 2024-02-06 13:42:10 --> Loader Class Initialized
INFO - 2024-02-06 13:42:10 --> Helper loaded: url_helper
INFO - 2024-02-06 13:42:10 --> Helper loaded: file_helper
INFO - 2024-02-06 13:42:10 --> Helper loaded: html_helper
INFO - 2024-02-06 13:42:10 --> Helper loaded: text_helper
INFO - 2024-02-06 13:42:10 --> Helper loaded: form_helper
INFO - 2024-02-06 13:42:10 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:42:10 --> Helper loaded: security_helper
INFO - 2024-02-06 13:42:10 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:42:10 --> Database Driver Class Initialized
INFO - 2024-02-06 13:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:42:10 --> Parser Class Initialized
INFO - 2024-02-06 13:42:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:42:10 --> Pagination Class Initialized
INFO - 2024-02-06 13:42:10 --> Form Validation Class Initialized
INFO - 2024-02-06 13:42:10 --> Controller Class Initialized
INFO - 2024-02-06 13:42:10 --> Model Class Initialized
DEBUG - 2024-02-06 13:42:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:42:10 --> Final output sent to browser
DEBUG - 2024-02-06 13:42:10 --> Total execution time: 0.0153
ERROR - 2024-02-06 13:42:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:42:10 --> Config Class Initialized
INFO - 2024-02-06 13:42:10 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:42:10 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:42:10 --> Utf8 Class Initialized
INFO - 2024-02-06 13:42:10 --> URI Class Initialized
INFO - 2024-02-06 13:42:10 --> Router Class Initialized
INFO - 2024-02-06 13:42:10 --> Output Class Initialized
INFO - 2024-02-06 13:42:10 --> Security Class Initialized
DEBUG - 2024-02-06 13:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:42:10 --> Input Class Initialized
INFO - 2024-02-06 13:42:10 --> Language Class Initialized
INFO - 2024-02-06 13:42:10 --> Loader Class Initialized
INFO - 2024-02-06 13:42:10 --> Helper loaded: url_helper
INFO - 2024-02-06 13:42:10 --> Helper loaded: file_helper
INFO - 2024-02-06 13:42:10 --> Helper loaded: html_helper
INFO - 2024-02-06 13:42:10 --> Helper loaded: text_helper
INFO - 2024-02-06 13:42:10 --> Helper loaded: form_helper
INFO - 2024-02-06 13:42:10 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:42:10 --> Helper loaded: security_helper
INFO - 2024-02-06 13:42:10 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:42:10 --> Database Driver Class Initialized
INFO - 2024-02-06 13:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:42:10 --> Parser Class Initialized
INFO - 2024-02-06 13:42:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:42:10 --> Pagination Class Initialized
INFO - 2024-02-06 13:42:10 --> Form Validation Class Initialized
INFO - 2024-02-06 13:42:10 --> Controller Class Initialized
INFO - 2024-02-06 13:42:10 --> Model Class Initialized
DEBUG - 2024-02-06 13:42:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:42:10 --> Final output sent to browser
DEBUG - 2024-02-06 13:42:10 --> Total execution time: 0.0195
ERROR - 2024-02-06 13:42:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:42:11 --> Config Class Initialized
INFO - 2024-02-06 13:42:11 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:42:11 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:42:11 --> Utf8 Class Initialized
INFO - 2024-02-06 13:42:11 --> URI Class Initialized
INFO - 2024-02-06 13:42:11 --> Router Class Initialized
INFO - 2024-02-06 13:42:11 --> Output Class Initialized
INFO - 2024-02-06 13:42:11 --> Security Class Initialized
DEBUG - 2024-02-06 13:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:42:11 --> Input Class Initialized
INFO - 2024-02-06 13:42:11 --> Language Class Initialized
INFO - 2024-02-06 13:42:11 --> Loader Class Initialized
INFO - 2024-02-06 13:42:11 --> Helper loaded: url_helper
INFO - 2024-02-06 13:42:11 --> Helper loaded: file_helper
INFO - 2024-02-06 13:42:11 --> Helper loaded: html_helper
INFO - 2024-02-06 13:42:11 --> Helper loaded: text_helper
INFO - 2024-02-06 13:42:11 --> Helper loaded: form_helper
INFO - 2024-02-06 13:42:11 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:42:11 --> Helper loaded: security_helper
INFO - 2024-02-06 13:42:11 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:42:11 --> Database Driver Class Initialized
INFO - 2024-02-06 13:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:42:11 --> Parser Class Initialized
INFO - 2024-02-06 13:42:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:42:11 --> Pagination Class Initialized
INFO - 2024-02-06 13:42:11 --> Form Validation Class Initialized
INFO - 2024-02-06 13:42:11 --> Controller Class Initialized
INFO - 2024-02-06 13:42:11 --> Model Class Initialized
DEBUG - 2024-02-06 13:42:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:42:11 --> Final output sent to browser
DEBUG - 2024-02-06 13:42:11 --> Total execution time: 0.0193
ERROR - 2024-02-06 13:42:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:42:33 --> Config Class Initialized
INFO - 2024-02-06 13:42:33 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:42:33 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:42:33 --> Utf8 Class Initialized
INFO - 2024-02-06 13:42:33 --> URI Class Initialized
DEBUG - 2024-02-06 13:42:33 --> No URI present. Default controller set.
INFO - 2024-02-06 13:42:33 --> Router Class Initialized
INFO - 2024-02-06 13:42:33 --> Output Class Initialized
INFO - 2024-02-06 13:42:33 --> Security Class Initialized
DEBUG - 2024-02-06 13:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:42:33 --> Input Class Initialized
INFO - 2024-02-06 13:42:33 --> Language Class Initialized
INFO - 2024-02-06 13:42:33 --> Loader Class Initialized
INFO - 2024-02-06 13:42:33 --> Helper loaded: url_helper
INFO - 2024-02-06 13:42:33 --> Helper loaded: file_helper
INFO - 2024-02-06 13:42:33 --> Helper loaded: html_helper
INFO - 2024-02-06 13:42:33 --> Helper loaded: text_helper
INFO - 2024-02-06 13:42:33 --> Helper loaded: form_helper
INFO - 2024-02-06 13:42:33 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:42:33 --> Helper loaded: security_helper
INFO - 2024-02-06 13:42:33 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:42:33 --> Database Driver Class Initialized
INFO - 2024-02-06 13:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:42:33 --> Parser Class Initialized
INFO - 2024-02-06 13:42:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:42:33 --> Pagination Class Initialized
INFO - 2024-02-06 13:42:33 --> Form Validation Class Initialized
INFO - 2024-02-06 13:42:33 --> Controller Class Initialized
INFO - 2024-02-06 13:42:33 --> Model Class Initialized
DEBUG - 2024-02-06 13:42:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:42:33 --> Model Class Initialized
DEBUG - 2024-02-06 13:42:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:42:33 --> Model Class Initialized
INFO - 2024-02-06 13:42:33 --> Model Class Initialized
INFO - 2024-02-06 13:42:33 --> Model Class Initialized
INFO - 2024-02-06 13:42:33 --> Model Class Initialized
DEBUG - 2024-02-06 13:42:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:42:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:42:33 --> Model Class Initialized
INFO - 2024-02-06 13:42:33 --> Model Class Initialized
INFO - 2024-02-06 13:42:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 13:42:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:42:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 13:42:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 13:42:34 --> Model Class Initialized
INFO - 2024-02-06 13:42:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 13:42:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 13:42:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 13:42:34 --> Final output sent to browser
DEBUG - 2024-02-06 13:42:34 --> Total execution time: 0.2373
ERROR - 2024-02-06 13:42:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:42:45 --> Config Class Initialized
INFO - 2024-02-06 13:42:45 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:42:45 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:42:45 --> Utf8 Class Initialized
INFO - 2024-02-06 13:42:45 --> URI Class Initialized
INFO - 2024-02-06 13:42:45 --> Router Class Initialized
INFO - 2024-02-06 13:42:45 --> Output Class Initialized
INFO - 2024-02-06 13:42:45 --> Security Class Initialized
DEBUG - 2024-02-06 13:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:42:45 --> Input Class Initialized
INFO - 2024-02-06 13:42:45 --> Language Class Initialized
INFO - 2024-02-06 13:42:45 --> Loader Class Initialized
INFO - 2024-02-06 13:42:45 --> Helper loaded: url_helper
INFO - 2024-02-06 13:42:45 --> Helper loaded: file_helper
INFO - 2024-02-06 13:42:45 --> Helper loaded: html_helper
INFO - 2024-02-06 13:42:45 --> Helper loaded: text_helper
INFO - 2024-02-06 13:42:45 --> Helper loaded: form_helper
INFO - 2024-02-06 13:42:45 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:42:45 --> Helper loaded: security_helper
INFO - 2024-02-06 13:42:45 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:42:45 --> Database Driver Class Initialized
INFO - 2024-02-06 13:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:42:45 --> Parser Class Initialized
INFO - 2024-02-06 13:42:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:42:45 --> Pagination Class Initialized
INFO - 2024-02-06 13:42:45 --> Form Validation Class Initialized
INFO - 2024-02-06 13:42:45 --> Controller Class Initialized
DEBUG - 2024-02-06 13:42:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:42:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:42:45 --> Model Class Initialized
DEBUG - 2024-02-06 13:42:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:42:45 --> Model Class Initialized
DEBUG - 2024-02-06 13:42:45 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:42:45 --> Model Class Initialized
INFO - 2024-02-06 13:42:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-06 13:42:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:42:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 13:42:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 13:42:45 --> Model Class Initialized
INFO - 2024-02-06 13:42:45 --> Model Class Initialized
INFO - 2024-02-06 13:42:45 --> Model Class Initialized
INFO - 2024-02-06 13:42:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 13:42:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 13:42:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 13:42:45 --> Final output sent to browser
DEBUG - 2024-02-06 13:42:45 --> Total execution time: 0.1647
ERROR - 2024-02-06 13:42:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:42:46 --> Config Class Initialized
INFO - 2024-02-06 13:42:46 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:42:46 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:42:46 --> Utf8 Class Initialized
INFO - 2024-02-06 13:42:46 --> URI Class Initialized
INFO - 2024-02-06 13:42:46 --> Router Class Initialized
INFO - 2024-02-06 13:42:46 --> Output Class Initialized
INFO - 2024-02-06 13:42:46 --> Security Class Initialized
DEBUG - 2024-02-06 13:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:42:46 --> Input Class Initialized
INFO - 2024-02-06 13:42:46 --> Language Class Initialized
INFO - 2024-02-06 13:42:46 --> Loader Class Initialized
INFO - 2024-02-06 13:42:46 --> Helper loaded: url_helper
INFO - 2024-02-06 13:42:46 --> Helper loaded: file_helper
INFO - 2024-02-06 13:42:46 --> Helper loaded: html_helper
INFO - 2024-02-06 13:42:46 --> Helper loaded: text_helper
INFO - 2024-02-06 13:42:46 --> Helper loaded: form_helper
INFO - 2024-02-06 13:42:46 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:42:46 --> Helper loaded: security_helper
INFO - 2024-02-06 13:42:46 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:42:46 --> Database Driver Class Initialized
INFO - 2024-02-06 13:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:42:46 --> Parser Class Initialized
INFO - 2024-02-06 13:42:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:42:46 --> Pagination Class Initialized
INFO - 2024-02-06 13:42:46 --> Form Validation Class Initialized
INFO - 2024-02-06 13:42:46 --> Controller Class Initialized
DEBUG - 2024-02-06 13:42:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:42:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:42:46 --> Model Class Initialized
DEBUG - 2024-02-06 13:42:46 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:42:46 --> Model Class Initialized
INFO - 2024-02-06 13:42:46 --> Final output sent to browser
DEBUG - 2024-02-06 13:42:46 --> Total execution time: 0.0266
ERROR - 2024-02-06 13:42:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:42:51 --> Config Class Initialized
INFO - 2024-02-06 13:42:51 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:42:51 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:42:51 --> Utf8 Class Initialized
INFO - 2024-02-06 13:42:51 --> URI Class Initialized
INFO - 2024-02-06 13:42:51 --> Router Class Initialized
INFO - 2024-02-06 13:42:51 --> Output Class Initialized
INFO - 2024-02-06 13:42:51 --> Security Class Initialized
DEBUG - 2024-02-06 13:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:42:51 --> Input Class Initialized
INFO - 2024-02-06 13:42:51 --> Language Class Initialized
INFO - 2024-02-06 13:42:51 --> Loader Class Initialized
INFO - 2024-02-06 13:42:51 --> Helper loaded: url_helper
INFO - 2024-02-06 13:42:51 --> Helper loaded: file_helper
INFO - 2024-02-06 13:42:51 --> Helper loaded: html_helper
INFO - 2024-02-06 13:42:51 --> Helper loaded: text_helper
INFO - 2024-02-06 13:42:51 --> Helper loaded: form_helper
INFO - 2024-02-06 13:42:51 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:42:51 --> Helper loaded: security_helper
INFO - 2024-02-06 13:42:51 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:42:51 --> Database Driver Class Initialized
INFO - 2024-02-06 13:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:42:51 --> Parser Class Initialized
INFO - 2024-02-06 13:42:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:42:51 --> Pagination Class Initialized
INFO - 2024-02-06 13:42:51 --> Form Validation Class Initialized
INFO - 2024-02-06 13:42:51 --> Controller Class Initialized
DEBUG - 2024-02-06 13:42:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:42:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:42:51 --> Model Class Initialized
DEBUG - 2024-02-06 13:42:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:42:51 --> Model Class Initialized
INFO - 2024-02-06 13:42:51 --> Final output sent to browser
DEBUG - 2024-02-06 13:42:51 --> Total execution time: 0.0263
ERROR - 2024-02-06 13:44:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:44:18 --> Config Class Initialized
INFO - 2024-02-06 13:44:18 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:44:18 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:44:18 --> Utf8 Class Initialized
INFO - 2024-02-06 13:44:18 --> URI Class Initialized
DEBUG - 2024-02-06 13:44:18 --> No URI present. Default controller set.
INFO - 2024-02-06 13:44:18 --> Router Class Initialized
INFO - 2024-02-06 13:44:18 --> Output Class Initialized
INFO - 2024-02-06 13:44:18 --> Security Class Initialized
DEBUG - 2024-02-06 13:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:44:18 --> Input Class Initialized
INFO - 2024-02-06 13:44:18 --> Language Class Initialized
INFO - 2024-02-06 13:44:18 --> Loader Class Initialized
INFO - 2024-02-06 13:44:18 --> Helper loaded: url_helper
INFO - 2024-02-06 13:44:18 --> Helper loaded: file_helper
INFO - 2024-02-06 13:44:18 --> Helper loaded: html_helper
INFO - 2024-02-06 13:44:18 --> Helper loaded: text_helper
INFO - 2024-02-06 13:44:18 --> Helper loaded: form_helper
INFO - 2024-02-06 13:44:18 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:44:18 --> Helper loaded: security_helper
INFO - 2024-02-06 13:44:18 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:44:18 --> Database Driver Class Initialized
INFO - 2024-02-06 13:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:44:18 --> Parser Class Initialized
INFO - 2024-02-06 13:44:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:44:18 --> Pagination Class Initialized
INFO - 2024-02-06 13:44:18 --> Form Validation Class Initialized
INFO - 2024-02-06 13:44:18 --> Controller Class Initialized
INFO - 2024-02-06 13:44:18 --> Model Class Initialized
DEBUG - 2024-02-06 13:44:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:44:18 --> Model Class Initialized
DEBUG - 2024-02-06 13:44:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:44:18 --> Model Class Initialized
INFO - 2024-02-06 13:44:18 --> Model Class Initialized
INFO - 2024-02-06 13:44:18 --> Model Class Initialized
INFO - 2024-02-06 13:44:18 --> Model Class Initialized
DEBUG - 2024-02-06 13:44:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:44:18 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:44:18 --> Model Class Initialized
INFO - 2024-02-06 13:44:18 --> Model Class Initialized
INFO - 2024-02-06 13:44:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 13:44:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:44:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 13:44:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 13:44:18 --> Model Class Initialized
INFO - 2024-02-06 13:44:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 13:44:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 13:44:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 13:44:18 --> Final output sent to browser
DEBUG - 2024-02-06 13:44:18 --> Total execution time: 0.2406
ERROR - 2024-02-06 13:44:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:44:24 --> Config Class Initialized
INFO - 2024-02-06 13:44:24 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:44:24 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:44:24 --> Utf8 Class Initialized
INFO - 2024-02-06 13:44:24 --> URI Class Initialized
INFO - 2024-02-06 13:44:24 --> Router Class Initialized
INFO - 2024-02-06 13:44:24 --> Output Class Initialized
INFO - 2024-02-06 13:44:24 --> Security Class Initialized
DEBUG - 2024-02-06 13:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:44:24 --> Input Class Initialized
INFO - 2024-02-06 13:44:24 --> Language Class Initialized
INFO - 2024-02-06 13:44:24 --> Loader Class Initialized
INFO - 2024-02-06 13:44:24 --> Helper loaded: url_helper
INFO - 2024-02-06 13:44:24 --> Helper loaded: file_helper
INFO - 2024-02-06 13:44:24 --> Helper loaded: html_helper
INFO - 2024-02-06 13:44:24 --> Helper loaded: text_helper
INFO - 2024-02-06 13:44:24 --> Helper loaded: form_helper
INFO - 2024-02-06 13:44:24 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:44:24 --> Helper loaded: security_helper
INFO - 2024-02-06 13:44:24 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:44:24 --> Database Driver Class Initialized
INFO - 2024-02-06 13:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:44:24 --> Parser Class Initialized
INFO - 2024-02-06 13:44:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:44:24 --> Pagination Class Initialized
INFO - 2024-02-06 13:44:24 --> Form Validation Class Initialized
INFO - 2024-02-06 13:44:24 --> Controller Class Initialized
INFO - 2024-02-06 13:44:24 --> Model Class Initialized
DEBUG - 2024-02-06 13:44:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:44:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:44:24 --> Model Class Initialized
DEBUG - 2024-02-06 13:44:24 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:44:24 --> Model Class Initialized
INFO - 2024-02-06 13:44:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-06 13:44:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:44:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 13:44:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 13:44:24 --> Model Class Initialized
INFO - 2024-02-06 13:44:24 --> Model Class Initialized
INFO - 2024-02-06 13:44:24 --> Model Class Initialized
INFO - 2024-02-06 13:44:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 13:44:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 13:44:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 13:44:24 --> Final output sent to browser
DEBUG - 2024-02-06 13:44:24 --> Total execution time: 0.1941
ERROR - 2024-02-06 13:44:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:44:29 --> Config Class Initialized
INFO - 2024-02-06 13:44:29 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:44:29 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:44:29 --> Utf8 Class Initialized
INFO - 2024-02-06 13:44:29 --> URI Class Initialized
INFO - 2024-02-06 13:44:29 --> Router Class Initialized
INFO - 2024-02-06 13:44:29 --> Output Class Initialized
INFO - 2024-02-06 13:44:29 --> Security Class Initialized
DEBUG - 2024-02-06 13:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:44:29 --> Input Class Initialized
INFO - 2024-02-06 13:44:29 --> Language Class Initialized
INFO - 2024-02-06 13:44:29 --> Loader Class Initialized
INFO - 2024-02-06 13:44:29 --> Helper loaded: url_helper
INFO - 2024-02-06 13:44:29 --> Helper loaded: file_helper
INFO - 2024-02-06 13:44:29 --> Helper loaded: html_helper
INFO - 2024-02-06 13:44:29 --> Helper loaded: text_helper
INFO - 2024-02-06 13:44:29 --> Helper loaded: form_helper
INFO - 2024-02-06 13:44:29 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:44:29 --> Helper loaded: security_helper
INFO - 2024-02-06 13:44:29 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:44:29 --> Database Driver Class Initialized
INFO - 2024-02-06 13:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:44:29 --> Parser Class Initialized
INFO - 2024-02-06 13:44:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:44:29 --> Pagination Class Initialized
INFO - 2024-02-06 13:44:29 --> Form Validation Class Initialized
INFO - 2024-02-06 13:44:29 --> Controller Class Initialized
INFO - 2024-02-06 13:44:29 --> Model Class Initialized
DEBUG - 2024-02-06 13:44:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:44:29 --> Final output sent to browser
DEBUG - 2024-02-06 13:44:29 --> Total execution time: 0.0161
ERROR - 2024-02-06 13:44:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:44:35 --> Config Class Initialized
INFO - 2024-02-06 13:44:35 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:44:35 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:44:35 --> Utf8 Class Initialized
INFO - 2024-02-06 13:44:35 --> URI Class Initialized
INFO - 2024-02-06 13:44:35 --> Router Class Initialized
INFO - 2024-02-06 13:44:35 --> Output Class Initialized
INFO - 2024-02-06 13:44:35 --> Security Class Initialized
DEBUG - 2024-02-06 13:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:44:35 --> Input Class Initialized
INFO - 2024-02-06 13:44:35 --> Language Class Initialized
INFO - 2024-02-06 13:44:35 --> Loader Class Initialized
INFO - 2024-02-06 13:44:35 --> Helper loaded: url_helper
INFO - 2024-02-06 13:44:35 --> Helper loaded: file_helper
INFO - 2024-02-06 13:44:35 --> Helper loaded: html_helper
INFO - 2024-02-06 13:44:35 --> Helper loaded: text_helper
INFO - 2024-02-06 13:44:35 --> Helper loaded: form_helper
INFO - 2024-02-06 13:44:35 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:44:35 --> Helper loaded: security_helper
INFO - 2024-02-06 13:44:35 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:44:35 --> Database Driver Class Initialized
INFO - 2024-02-06 13:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:44:35 --> Parser Class Initialized
INFO - 2024-02-06 13:44:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:44:35 --> Pagination Class Initialized
INFO - 2024-02-06 13:44:35 --> Form Validation Class Initialized
INFO - 2024-02-06 13:44:35 --> Controller Class Initialized
INFO - 2024-02-06 13:44:35 --> Model Class Initialized
DEBUG - 2024-02-06 13:44:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:44:35 --> Final output sent to browser
DEBUG - 2024-02-06 13:44:35 --> Total execution time: 0.0182
ERROR - 2024-02-06 13:44:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:44:38 --> Config Class Initialized
INFO - 2024-02-06 13:44:38 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:44:38 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:44:38 --> Utf8 Class Initialized
INFO - 2024-02-06 13:44:38 --> URI Class Initialized
INFO - 2024-02-06 13:44:38 --> Router Class Initialized
INFO - 2024-02-06 13:44:38 --> Output Class Initialized
INFO - 2024-02-06 13:44:38 --> Security Class Initialized
DEBUG - 2024-02-06 13:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:44:38 --> Input Class Initialized
INFO - 2024-02-06 13:44:38 --> Language Class Initialized
INFO - 2024-02-06 13:44:38 --> Loader Class Initialized
INFO - 2024-02-06 13:44:38 --> Helper loaded: url_helper
INFO - 2024-02-06 13:44:38 --> Helper loaded: file_helper
INFO - 2024-02-06 13:44:38 --> Helper loaded: html_helper
INFO - 2024-02-06 13:44:38 --> Helper loaded: text_helper
INFO - 2024-02-06 13:44:38 --> Helper loaded: form_helper
INFO - 2024-02-06 13:44:38 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:44:38 --> Helper loaded: security_helper
INFO - 2024-02-06 13:44:38 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:44:38 --> Database Driver Class Initialized
INFO - 2024-02-06 13:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:44:38 --> Parser Class Initialized
INFO - 2024-02-06 13:44:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:44:38 --> Pagination Class Initialized
INFO - 2024-02-06 13:44:38 --> Form Validation Class Initialized
INFO - 2024-02-06 13:44:38 --> Controller Class Initialized
INFO - 2024-02-06 13:44:38 --> Model Class Initialized
DEBUG - 2024-02-06 13:44:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-06 13:44:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-06 13:44:38 --> Final output sent to browser
DEBUG - 2024-02-06 13:44:38 --> Total execution time: 0.0199
ERROR - 2024-02-06 13:44:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:44:41 --> Config Class Initialized
INFO - 2024-02-06 13:44:41 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:44:41 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:44:41 --> Utf8 Class Initialized
INFO - 2024-02-06 13:44:41 --> URI Class Initialized
INFO - 2024-02-06 13:44:41 --> Router Class Initialized
INFO - 2024-02-06 13:44:41 --> Output Class Initialized
INFO - 2024-02-06 13:44:41 --> Security Class Initialized
DEBUG - 2024-02-06 13:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:44:41 --> Input Class Initialized
INFO - 2024-02-06 13:44:41 --> Language Class Initialized
INFO - 2024-02-06 13:44:41 --> Loader Class Initialized
INFO - 2024-02-06 13:44:41 --> Helper loaded: url_helper
INFO - 2024-02-06 13:44:41 --> Helper loaded: file_helper
INFO - 2024-02-06 13:44:41 --> Helper loaded: html_helper
INFO - 2024-02-06 13:44:41 --> Helper loaded: text_helper
INFO - 2024-02-06 13:44:41 --> Helper loaded: form_helper
INFO - 2024-02-06 13:44:41 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:44:41 --> Helper loaded: security_helper
INFO - 2024-02-06 13:44:41 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:44:41 --> Database Driver Class Initialized
INFO - 2024-02-06 13:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:44:41 --> Parser Class Initialized
INFO - 2024-02-06 13:44:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:44:41 --> Pagination Class Initialized
INFO - 2024-02-06 13:44:41 --> Form Validation Class Initialized
INFO - 2024-02-06 13:44:41 --> Controller Class Initialized
INFO - 2024-02-06 13:44:41 --> Model Class Initialized
DEBUG - 2024-02-06 13:44:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-06 13:44:41 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-06 13:44:41 --> Final output sent to browser
DEBUG - 2024-02-06 13:44:41 --> Total execution time: 0.0160
ERROR - 2024-02-06 13:44:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:44:44 --> Config Class Initialized
INFO - 2024-02-06 13:44:44 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:44:44 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:44:44 --> Utf8 Class Initialized
INFO - 2024-02-06 13:44:44 --> URI Class Initialized
INFO - 2024-02-06 13:44:44 --> Router Class Initialized
INFO - 2024-02-06 13:44:44 --> Output Class Initialized
INFO - 2024-02-06 13:44:44 --> Security Class Initialized
DEBUG - 2024-02-06 13:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:44:44 --> Input Class Initialized
INFO - 2024-02-06 13:44:44 --> Language Class Initialized
INFO - 2024-02-06 13:44:44 --> Loader Class Initialized
INFO - 2024-02-06 13:44:44 --> Helper loaded: url_helper
INFO - 2024-02-06 13:44:44 --> Helper loaded: file_helper
INFO - 2024-02-06 13:44:44 --> Helper loaded: html_helper
INFO - 2024-02-06 13:44:44 --> Helper loaded: text_helper
INFO - 2024-02-06 13:44:44 --> Helper loaded: form_helper
INFO - 2024-02-06 13:44:44 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:44:44 --> Helper loaded: security_helper
INFO - 2024-02-06 13:44:44 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:44:44 --> Database Driver Class Initialized
INFO - 2024-02-06 13:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:44:44 --> Parser Class Initialized
INFO - 2024-02-06 13:44:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:44:44 --> Pagination Class Initialized
INFO - 2024-02-06 13:44:44 --> Form Validation Class Initialized
INFO - 2024-02-06 13:44:44 --> Controller Class Initialized
INFO - 2024-02-06 13:44:44 --> Model Class Initialized
DEBUG - 2024-02-06 13:44:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:44:44 --> Final output sent to browser
DEBUG - 2024-02-06 13:44:44 --> Total execution time: 0.0160
ERROR - 2024-02-06 13:44:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:44:47 --> Config Class Initialized
INFO - 2024-02-06 13:44:47 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:44:47 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:44:47 --> Utf8 Class Initialized
INFO - 2024-02-06 13:44:47 --> URI Class Initialized
INFO - 2024-02-06 13:44:47 --> Router Class Initialized
INFO - 2024-02-06 13:44:47 --> Output Class Initialized
INFO - 2024-02-06 13:44:47 --> Security Class Initialized
DEBUG - 2024-02-06 13:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:44:47 --> Input Class Initialized
INFO - 2024-02-06 13:44:47 --> Language Class Initialized
INFO - 2024-02-06 13:44:47 --> Loader Class Initialized
INFO - 2024-02-06 13:44:47 --> Helper loaded: url_helper
INFO - 2024-02-06 13:44:47 --> Helper loaded: file_helper
INFO - 2024-02-06 13:44:47 --> Helper loaded: html_helper
INFO - 2024-02-06 13:44:47 --> Helper loaded: text_helper
INFO - 2024-02-06 13:44:47 --> Helper loaded: form_helper
INFO - 2024-02-06 13:44:47 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:44:47 --> Helper loaded: security_helper
INFO - 2024-02-06 13:44:47 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:44:47 --> Database Driver Class Initialized
INFO - 2024-02-06 13:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:44:47 --> Parser Class Initialized
INFO - 2024-02-06 13:44:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:44:47 --> Pagination Class Initialized
INFO - 2024-02-06 13:44:47 --> Form Validation Class Initialized
INFO - 2024-02-06 13:44:47 --> Controller Class Initialized
INFO - 2024-02-06 13:44:47 --> Final output sent to browser
DEBUG - 2024-02-06 13:44:47 --> Total execution time: 0.0136
ERROR - 2024-02-06 13:44:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:44:57 --> Config Class Initialized
INFO - 2024-02-06 13:44:57 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:44:57 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:44:57 --> Utf8 Class Initialized
INFO - 2024-02-06 13:44:57 --> URI Class Initialized
INFO - 2024-02-06 13:44:57 --> Router Class Initialized
INFO - 2024-02-06 13:44:57 --> Output Class Initialized
INFO - 2024-02-06 13:44:57 --> Security Class Initialized
DEBUG - 2024-02-06 13:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:44:57 --> Input Class Initialized
INFO - 2024-02-06 13:44:57 --> Language Class Initialized
INFO - 2024-02-06 13:44:57 --> Loader Class Initialized
INFO - 2024-02-06 13:44:57 --> Helper loaded: url_helper
INFO - 2024-02-06 13:44:57 --> Helper loaded: file_helper
INFO - 2024-02-06 13:44:57 --> Helper loaded: html_helper
INFO - 2024-02-06 13:44:57 --> Helper loaded: text_helper
INFO - 2024-02-06 13:44:57 --> Helper loaded: form_helper
INFO - 2024-02-06 13:44:57 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:44:57 --> Helper loaded: security_helper
INFO - 2024-02-06 13:44:57 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:44:57 --> Database Driver Class Initialized
INFO - 2024-02-06 13:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:44:57 --> Parser Class Initialized
INFO - 2024-02-06 13:44:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:44:57 --> Pagination Class Initialized
INFO - 2024-02-06 13:44:57 --> Form Validation Class Initialized
INFO - 2024-02-06 13:44:57 --> Controller Class Initialized
INFO - 2024-02-06 13:44:57 --> Model Class Initialized
DEBUG - 2024-02-06 13:44:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:44:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:44:57 --> Model Class Initialized
DEBUG - 2024-02-06 13:44:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:44:57 --> Model Class Initialized
INFO - 2024-02-06 13:44:58 --> Final output sent to browser
DEBUG - 2024-02-06 13:44:58 --> Total execution time: 0.0961
ERROR - 2024-02-06 13:45:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:45:01 --> Config Class Initialized
INFO - 2024-02-06 13:45:01 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:45:01 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:45:01 --> Utf8 Class Initialized
INFO - 2024-02-06 13:45:01 --> URI Class Initialized
INFO - 2024-02-06 13:45:01 --> Router Class Initialized
INFO - 2024-02-06 13:45:01 --> Output Class Initialized
INFO - 2024-02-06 13:45:01 --> Security Class Initialized
DEBUG - 2024-02-06 13:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:45:01 --> Input Class Initialized
INFO - 2024-02-06 13:45:01 --> Language Class Initialized
INFO - 2024-02-06 13:45:01 --> Loader Class Initialized
INFO - 2024-02-06 13:45:01 --> Helper loaded: url_helper
INFO - 2024-02-06 13:45:01 --> Helper loaded: file_helper
INFO - 2024-02-06 13:45:01 --> Helper loaded: html_helper
INFO - 2024-02-06 13:45:01 --> Helper loaded: text_helper
INFO - 2024-02-06 13:45:01 --> Helper loaded: form_helper
INFO - 2024-02-06 13:45:01 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:45:01 --> Helper loaded: security_helper
INFO - 2024-02-06 13:45:01 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:45:01 --> Database Driver Class Initialized
INFO - 2024-02-06 13:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:45:01 --> Parser Class Initialized
INFO - 2024-02-06 13:45:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:45:01 --> Pagination Class Initialized
INFO - 2024-02-06 13:45:01 --> Form Validation Class Initialized
INFO - 2024-02-06 13:45:01 --> Controller Class Initialized
INFO - 2024-02-06 13:45:01 --> Model Class Initialized
DEBUG - 2024-02-06 13:45:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:45:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:45:01 --> Model Class Initialized
DEBUG - 2024-02-06 13:45:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:45:01 --> Model Class Initialized
INFO - 2024-02-06 13:45:01 --> Final output sent to browser
DEBUG - 2024-02-06 13:45:01 --> Total execution time: 0.0888
ERROR - 2024-02-06 13:45:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:45:08 --> Config Class Initialized
INFO - 2024-02-06 13:45:08 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:45:08 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:45:08 --> Utf8 Class Initialized
INFO - 2024-02-06 13:45:08 --> URI Class Initialized
INFO - 2024-02-06 13:45:08 --> Router Class Initialized
INFO - 2024-02-06 13:45:08 --> Output Class Initialized
INFO - 2024-02-06 13:45:08 --> Security Class Initialized
DEBUG - 2024-02-06 13:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:45:08 --> Input Class Initialized
INFO - 2024-02-06 13:45:08 --> Language Class Initialized
INFO - 2024-02-06 13:45:08 --> Loader Class Initialized
INFO - 2024-02-06 13:45:08 --> Helper loaded: url_helper
INFO - 2024-02-06 13:45:08 --> Helper loaded: file_helper
INFO - 2024-02-06 13:45:08 --> Helper loaded: html_helper
INFO - 2024-02-06 13:45:08 --> Helper loaded: text_helper
INFO - 2024-02-06 13:45:08 --> Helper loaded: form_helper
INFO - 2024-02-06 13:45:08 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:45:08 --> Helper loaded: security_helper
INFO - 2024-02-06 13:45:08 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:45:08 --> Database Driver Class Initialized
INFO - 2024-02-06 13:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:45:08 --> Parser Class Initialized
INFO - 2024-02-06 13:45:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:45:08 --> Pagination Class Initialized
INFO - 2024-02-06 13:45:08 --> Form Validation Class Initialized
INFO - 2024-02-06 13:45:08 --> Controller Class Initialized
INFO - 2024-02-06 13:45:08 --> Model Class Initialized
DEBUG - 2024-02-06 13:45:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:45:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:45:08 --> Model Class Initialized
INFO - 2024-02-06 13:45:08 --> Model Class Initialized
INFO - 2024-02-06 13:45:08 --> Final output sent to browser
DEBUG - 2024-02-06 13:45:08 --> Total execution time: 0.0207
ERROR - 2024-02-06 13:45:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:45:11 --> Config Class Initialized
INFO - 2024-02-06 13:45:11 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:45:11 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:45:11 --> Utf8 Class Initialized
INFO - 2024-02-06 13:45:11 --> URI Class Initialized
INFO - 2024-02-06 13:45:11 --> Router Class Initialized
INFO - 2024-02-06 13:45:11 --> Output Class Initialized
INFO - 2024-02-06 13:45:11 --> Security Class Initialized
DEBUG - 2024-02-06 13:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:45:11 --> Input Class Initialized
INFO - 2024-02-06 13:45:11 --> Language Class Initialized
INFO - 2024-02-06 13:45:11 --> Loader Class Initialized
INFO - 2024-02-06 13:45:11 --> Helper loaded: url_helper
INFO - 2024-02-06 13:45:11 --> Helper loaded: file_helper
INFO - 2024-02-06 13:45:11 --> Helper loaded: html_helper
INFO - 2024-02-06 13:45:11 --> Helper loaded: text_helper
INFO - 2024-02-06 13:45:11 --> Helper loaded: form_helper
INFO - 2024-02-06 13:45:11 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:45:11 --> Helper loaded: security_helper
INFO - 2024-02-06 13:45:11 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:45:11 --> Database Driver Class Initialized
INFO - 2024-02-06 13:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:45:11 --> Parser Class Initialized
INFO - 2024-02-06 13:45:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:45:11 --> Pagination Class Initialized
INFO - 2024-02-06 13:45:11 --> Form Validation Class Initialized
INFO - 2024-02-06 13:45:11 --> Controller Class Initialized
INFO - 2024-02-06 13:45:11 --> Model Class Initialized
DEBUG - 2024-02-06 13:45:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:45:11 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:45:11 --> Model Class Initialized
INFO - 2024-02-06 13:45:11 --> Final output sent to browser
DEBUG - 2024-02-06 13:45:11 --> Total execution time: 0.0160
ERROR - 2024-02-06 13:45:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:45:13 --> Config Class Initialized
INFO - 2024-02-06 13:45:13 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:45:13 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:45:13 --> Utf8 Class Initialized
INFO - 2024-02-06 13:45:13 --> URI Class Initialized
INFO - 2024-02-06 13:45:13 --> Router Class Initialized
INFO - 2024-02-06 13:45:13 --> Output Class Initialized
INFO - 2024-02-06 13:45:13 --> Security Class Initialized
DEBUG - 2024-02-06 13:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:45:13 --> Input Class Initialized
INFO - 2024-02-06 13:45:13 --> Language Class Initialized
INFO - 2024-02-06 13:45:13 --> Loader Class Initialized
INFO - 2024-02-06 13:45:13 --> Helper loaded: url_helper
INFO - 2024-02-06 13:45:13 --> Helper loaded: file_helper
INFO - 2024-02-06 13:45:13 --> Helper loaded: html_helper
INFO - 2024-02-06 13:45:13 --> Helper loaded: text_helper
INFO - 2024-02-06 13:45:13 --> Helper loaded: form_helper
INFO - 2024-02-06 13:45:13 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:45:13 --> Helper loaded: security_helper
INFO - 2024-02-06 13:45:13 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:45:13 --> Database Driver Class Initialized
INFO - 2024-02-06 13:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:45:13 --> Parser Class Initialized
INFO - 2024-02-06 13:45:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:45:13 --> Pagination Class Initialized
INFO - 2024-02-06 13:45:13 --> Form Validation Class Initialized
INFO - 2024-02-06 13:45:13 --> Controller Class Initialized
INFO - 2024-02-06 13:45:13 --> Model Class Initialized
DEBUG - 2024-02-06 13:45:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:45:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:45:13 --> Model Class Initialized
INFO - 2024-02-06 13:45:13 --> Final output sent to browser
DEBUG - 2024-02-06 13:45:13 --> Total execution time: 0.0165
ERROR - 2024-02-06 13:45:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:45:36 --> Config Class Initialized
INFO - 2024-02-06 13:45:36 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:45:36 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:45:36 --> Utf8 Class Initialized
INFO - 2024-02-06 13:45:36 --> URI Class Initialized
INFO - 2024-02-06 13:45:36 --> Router Class Initialized
INFO - 2024-02-06 13:45:36 --> Output Class Initialized
INFO - 2024-02-06 13:45:36 --> Security Class Initialized
DEBUG - 2024-02-06 13:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:45:36 --> Input Class Initialized
INFO - 2024-02-06 13:45:36 --> Language Class Initialized
INFO - 2024-02-06 13:45:36 --> Loader Class Initialized
INFO - 2024-02-06 13:45:36 --> Helper loaded: url_helper
INFO - 2024-02-06 13:45:36 --> Helper loaded: file_helper
INFO - 2024-02-06 13:45:36 --> Helper loaded: html_helper
INFO - 2024-02-06 13:45:36 --> Helper loaded: text_helper
INFO - 2024-02-06 13:45:36 --> Helper loaded: form_helper
INFO - 2024-02-06 13:45:36 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:45:36 --> Helper loaded: security_helper
INFO - 2024-02-06 13:45:36 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:45:36 --> Database Driver Class Initialized
INFO - 2024-02-06 13:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:45:36 --> Parser Class Initialized
INFO - 2024-02-06 13:45:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:45:36 --> Pagination Class Initialized
INFO - 2024-02-06 13:45:36 --> Form Validation Class Initialized
INFO - 2024-02-06 13:45:36 --> Controller Class Initialized
INFO - 2024-02-06 13:45:36 --> Model Class Initialized
DEBUG - 2024-02-06 13:45:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:45:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:45:36 --> Model Class Initialized
DEBUG - 2024-02-06 13:45:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:45:36 --> Model Class Initialized
INFO - 2024-02-06 13:45:36 --> Final output sent to browser
DEBUG - 2024-02-06 13:45:36 --> Total execution time: 0.0930
ERROR - 2024-02-06 13:45:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:45:51 --> Config Class Initialized
INFO - 2024-02-06 13:45:51 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:45:51 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:45:51 --> Utf8 Class Initialized
INFO - 2024-02-06 13:45:51 --> URI Class Initialized
INFO - 2024-02-06 13:45:51 --> Router Class Initialized
INFO - 2024-02-06 13:45:51 --> Output Class Initialized
INFO - 2024-02-06 13:45:51 --> Security Class Initialized
DEBUG - 2024-02-06 13:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:45:51 --> Input Class Initialized
INFO - 2024-02-06 13:45:51 --> Language Class Initialized
INFO - 2024-02-06 13:45:51 --> Loader Class Initialized
INFO - 2024-02-06 13:45:51 --> Helper loaded: url_helper
INFO - 2024-02-06 13:45:51 --> Helper loaded: file_helper
INFO - 2024-02-06 13:45:51 --> Helper loaded: html_helper
INFO - 2024-02-06 13:45:51 --> Helper loaded: text_helper
INFO - 2024-02-06 13:45:51 --> Helper loaded: form_helper
INFO - 2024-02-06 13:45:51 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:45:51 --> Helper loaded: security_helper
INFO - 2024-02-06 13:45:51 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:45:51 --> Database Driver Class Initialized
INFO - 2024-02-06 13:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:45:51 --> Parser Class Initialized
INFO - 2024-02-06 13:45:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:45:51 --> Pagination Class Initialized
INFO - 2024-02-06 13:45:51 --> Form Validation Class Initialized
INFO - 2024-02-06 13:45:51 --> Controller Class Initialized
INFO - 2024-02-06 13:45:51 --> Model Class Initialized
DEBUG - 2024-02-06 13:45:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:45:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:45:51 --> Model Class Initialized
INFO - 2024-02-06 13:45:51 --> Model Class Initialized
INFO - 2024-02-06 13:45:51 --> Final output sent to browser
DEBUG - 2024-02-06 13:45:51 --> Total execution time: 0.0232
ERROR - 2024-02-06 13:45:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:45:56 --> Config Class Initialized
INFO - 2024-02-06 13:45:56 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:45:56 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:45:56 --> Utf8 Class Initialized
INFO - 2024-02-06 13:45:56 --> URI Class Initialized
INFO - 2024-02-06 13:45:56 --> Router Class Initialized
INFO - 2024-02-06 13:45:56 --> Output Class Initialized
INFO - 2024-02-06 13:45:56 --> Security Class Initialized
DEBUG - 2024-02-06 13:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:45:56 --> Input Class Initialized
INFO - 2024-02-06 13:45:56 --> Language Class Initialized
INFO - 2024-02-06 13:45:56 --> Loader Class Initialized
INFO - 2024-02-06 13:45:56 --> Helper loaded: url_helper
INFO - 2024-02-06 13:45:56 --> Helper loaded: file_helper
INFO - 2024-02-06 13:45:56 --> Helper loaded: html_helper
INFO - 2024-02-06 13:45:56 --> Helper loaded: text_helper
INFO - 2024-02-06 13:45:56 --> Helper loaded: form_helper
INFO - 2024-02-06 13:45:56 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:45:56 --> Helper loaded: security_helper
INFO - 2024-02-06 13:45:56 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:45:56 --> Database Driver Class Initialized
INFO - 2024-02-06 13:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:45:56 --> Parser Class Initialized
INFO - 2024-02-06 13:45:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:45:56 --> Pagination Class Initialized
INFO - 2024-02-06 13:45:56 --> Form Validation Class Initialized
INFO - 2024-02-06 13:45:56 --> Controller Class Initialized
INFO - 2024-02-06 13:45:56 --> Model Class Initialized
DEBUG - 2024-02-06 13:45:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:45:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:45:56 --> Model Class Initialized
INFO - 2024-02-06 13:45:56 --> Final output sent to browser
DEBUG - 2024-02-06 13:45:56 --> Total execution time: 0.0169
ERROR - 2024-02-06 13:46:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:46:27 --> Config Class Initialized
INFO - 2024-02-06 13:46:27 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:46:27 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:46:27 --> Utf8 Class Initialized
INFO - 2024-02-06 13:46:28 --> URI Class Initialized
INFO - 2024-02-06 13:46:28 --> Router Class Initialized
INFO - 2024-02-06 13:46:28 --> Output Class Initialized
INFO - 2024-02-06 13:46:28 --> Security Class Initialized
DEBUG - 2024-02-06 13:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:46:28 --> Input Class Initialized
INFO - 2024-02-06 13:46:28 --> Language Class Initialized
INFO - 2024-02-06 13:46:28 --> Loader Class Initialized
INFO - 2024-02-06 13:46:28 --> Helper loaded: url_helper
INFO - 2024-02-06 13:46:28 --> Helper loaded: file_helper
INFO - 2024-02-06 13:46:28 --> Helper loaded: html_helper
INFO - 2024-02-06 13:46:28 --> Helper loaded: text_helper
INFO - 2024-02-06 13:46:28 --> Helper loaded: form_helper
INFO - 2024-02-06 13:46:28 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:46:28 --> Helper loaded: security_helper
INFO - 2024-02-06 13:46:28 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:46:28 --> Database Driver Class Initialized
INFO - 2024-02-06 13:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:46:28 --> Parser Class Initialized
INFO - 2024-02-06 13:46:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:46:28 --> Pagination Class Initialized
INFO - 2024-02-06 13:46:28 --> Form Validation Class Initialized
INFO - 2024-02-06 13:46:28 --> Controller Class Initialized
INFO - 2024-02-06 13:46:28 --> Model Class Initialized
DEBUG - 2024-02-06 13:46:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:46:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:46:28 --> Model Class Initialized
INFO - 2024-02-06 13:46:28 --> Final output sent to browser
DEBUG - 2024-02-06 13:46:28 --> Total execution time: 0.0193
ERROR - 2024-02-06 13:46:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:46:30 --> Config Class Initialized
INFO - 2024-02-06 13:46:30 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:46:30 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:46:30 --> Utf8 Class Initialized
INFO - 2024-02-06 13:46:30 --> URI Class Initialized
INFO - 2024-02-06 13:46:30 --> Router Class Initialized
INFO - 2024-02-06 13:46:30 --> Output Class Initialized
INFO - 2024-02-06 13:46:30 --> Security Class Initialized
DEBUG - 2024-02-06 13:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:46:30 --> Input Class Initialized
INFO - 2024-02-06 13:46:30 --> Language Class Initialized
INFO - 2024-02-06 13:46:30 --> Loader Class Initialized
INFO - 2024-02-06 13:46:30 --> Helper loaded: url_helper
INFO - 2024-02-06 13:46:30 --> Helper loaded: file_helper
INFO - 2024-02-06 13:46:30 --> Helper loaded: html_helper
INFO - 2024-02-06 13:46:30 --> Helper loaded: text_helper
INFO - 2024-02-06 13:46:30 --> Helper loaded: form_helper
INFO - 2024-02-06 13:46:30 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:46:30 --> Helper loaded: security_helper
INFO - 2024-02-06 13:46:30 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:46:30 --> Database Driver Class Initialized
INFO - 2024-02-06 13:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:46:30 --> Parser Class Initialized
INFO - 2024-02-06 13:46:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:46:30 --> Pagination Class Initialized
INFO - 2024-02-06 13:46:30 --> Form Validation Class Initialized
INFO - 2024-02-06 13:46:30 --> Controller Class Initialized
INFO - 2024-02-06 13:46:30 --> Model Class Initialized
DEBUG - 2024-02-06 13:46:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:46:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:46:30 --> Model Class Initialized
INFO - 2024-02-06 13:46:30 --> Final output sent to browser
DEBUG - 2024-02-06 13:46:30 --> Total execution time: 0.0191
ERROR - 2024-02-06 13:46:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:46:43 --> Config Class Initialized
INFO - 2024-02-06 13:46:43 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:46:43 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:46:43 --> Utf8 Class Initialized
INFO - 2024-02-06 13:46:43 --> URI Class Initialized
INFO - 2024-02-06 13:46:43 --> Router Class Initialized
INFO - 2024-02-06 13:46:43 --> Output Class Initialized
INFO - 2024-02-06 13:46:43 --> Security Class Initialized
DEBUG - 2024-02-06 13:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:46:43 --> Input Class Initialized
INFO - 2024-02-06 13:46:43 --> Language Class Initialized
INFO - 2024-02-06 13:46:43 --> Loader Class Initialized
INFO - 2024-02-06 13:46:43 --> Helper loaded: url_helper
INFO - 2024-02-06 13:46:43 --> Helper loaded: file_helper
INFO - 2024-02-06 13:46:43 --> Helper loaded: html_helper
INFO - 2024-02-06 13:46:43 --> Helper loaded: text_helper
INFO - 2024-02-06 13:46:43 --> Helper loaded: form_helper
INFO - 2024-02-06 13:46:43 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:46:43 --> Helper loaded: security_helper
INFO - 2024-02-06 13:46:43 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:46:43 --> Database Driver Class Initialized
INFO - 2024-02-06 13:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:46:43 --> Parser Class Initialized
INFO - 2024-02-06 13:46:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:46:43 --> Pagination Class Initialized
INFO - 2024-02-06 13:46:43 --> Form Validation Class Initialized
INFO - 2024-02-06 13:46:43 --> Controller Class Initialized
INFO - 2024-02-06 13:46:43 --> Model Class Initialized
DEBUG - 2024-02-06 13:46:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:46:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:46:43 --> Model Class Initialized
DEBUG - 2024-02-06 13:46:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:46:43 --> Model Class Initialized
INFO - 2024-02-06 13:46:43 --> Email Class Initialized
DEBUG - 2024-02-06 13:46:43 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:46:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-02-06 13:46:43 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-02-06 13:46:43 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-02-06 13:46:43 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:46:44 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-02-06 13:46:44 --> Language file loaded: language/english/email_lang.php
INFO - 2024-02-06 13:46:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-02-06 13:46:44 --> Final output sent to browser
DEBUG - 2024-02-06 13:46:44 --> Total execution time: 0.3886
ERROR - 2024-02-06 13:46:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:46:51 --> Config Class Initialized
INFO - 2024-02-06 13:46:51 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:46:51 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:46:51 --> Utf8 Class Initialized
INFO - 2024-02-06 13:46:51 --> URI Class Initialized
DEBUG - 2024-02-06 13:46:51 --> No URI present. Default controller set.
INFO - 2024-02-06 13:46:51 --> Router Class Initialized
INFO - 2024-02-06 13:46:51 --> Output Class Initialized
INFO - 2024-02-06 13:46:51 --> Security Class Initialized
DEBUG - 2024-02-06 13:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:46:51 --> Input Class Initialized
INFO - 2024-02-06 13:46:51 --> Language Class Initialized
INFO - 2024-02-06 13:46:51 --> Loader Class Initialized
INFO - 2024-02-06 13:46:51 --> Helper loaded: url_helper
INFO - 2024-02-06 13:46:51 --> Helper loaded: file_helper
INFO - 2024-02-06 13:46:51 --> Helper loaded: html_helper
INFO - 2024-02-06 13:46:51 --> Helper loaded: text_helper
INFO - 2024-02-06 13:46:51 --> Helper loaded: form_helper
INFO - 2024-02-06 13:46:51 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:46:51 --> Helper loaded: security_helper
INFO - 2024-02-06 13:46:51 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:46:51 --> Database Driver Class Initialized
INFO - 2024-02-06 13:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:46:51 --> Parser Class Initialized
INFO - 2024-02-06 13:46:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:46:51 --> Pagination Class Initialized
INFO - 2024-02-06 13:46:51 --> Form Validation Class Initialized
INFO - 2024-02-06 13:46:51 --> Controller Class Initialized
INFO - 2024-02-06 13:46:51 --> Model Class Initialized
DEBUG - 2024-02-06 13:46:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:46:51 --> Model Class Initialized
DEBUG - 2024-02-06 13:46:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:46:51 --> Model Class Initialized
INFO - 2024-02-06 13:46:51 --> Model Class Initialized
INFO - 2024-02-06 13:46:51 --> Model Class Initialized
INFO - 2024-02-06 13:46:51 --> Model Class Initialized
DEBUG - 2024-02-06 13:46:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:46:51 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:46:51 --> Model Class Initialized
INFO - 2024-02-06 13:46:51 --> Model Class Initialized
INFO - 2024-02-06 13:46:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 13:46:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:46:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 13:46:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 13:46:51 --> Model Class Initialized
INFO - 2024-02-06 13:46:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 13:46:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 13:46:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 13:46:51 --> Final output sent to browser
DEBUG - 2024-02-06 13:46:51 --> Total execution time: 0.2465
ERROR - 2024-02-06 13:46:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:46:59 --> Config Class Initialized
INFO - 2024-02-06 13:46:59 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:46:59 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:46:59 --> Utf8 Class Initialized
INFO - 2024-02-06 13:46:59 --> URI Class Initialized
INFO - 2024-02-06 13:46:59 --> Router Class Initialized
INFO - 2024-02-06 13:46:59 --> Output Class Initialized
INFO - 2024-02-06 13:46:59 --> Security Class Initialized
DEBUG - 2024-02-06 13:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:46:59 --> Input Class Initialized
INFO - 2024-02-06 13:46:59 --> Language Class Initialized
INFO - 2024-02-06 13:46:59 --> Loader Class Initialized
INFO - 2024-02-06 13:46:59 --> Helper loaded: url_helper
INFO - 2024-02-06 13:46:59 --> Helper loaded: file_helper
INFO - 2024-02-06 13:46:59 --> Helper loaded: html_helper
INFO - 2024-02-06 13:46:59 --> Helper loaded: text_helper
INFO - 2024-02-06 13:46:59 --> Helper loaded: form_helper
INFO - 2024-02-06 13:46:59 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:46:59 --> Helper loaded: security_helper
INFO - 2024-02-06 13:46:59 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:46:59 --> Database Driver Class Initialized
INFO - 2024-02-06 13:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:46:59 --> Parser Class Initialized
INFO - 2024-02-06 13:46:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:46:59 --> Pagination Class Initialized
INFO - 2024-02-06 13:46:59 --> Form Validation Class Initialized
INFO - 2024-02-06 13:46:59 --> Controller Class Initialized
INFO - 2024-02-06 13:46:59 --> Model Class Initialized
DEBUG - 2024-02-06 13:46:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:46:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:46:59 --> Model Class Initialized
DEBUG - 2024-02-06 13:46:59 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:46:59 --> Model Class Initialized
INFO - 2024-02-06 13:46:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-06 13:46:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:46:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 13:46:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 13:46:59 --> Model Class Initialized
INFO - 2024-02-06 13:46:59 --> Model Class Initialized
INFO - 2024-02-06 13:46:59 --> Model Class Initialized
INFO - 2024-02-06 13:46:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 13:46:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 13:46:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 13:46:59 --> Final output sent to browser
DEBUG - 2024-02-06 13:46:59 --> Total execution time: 0.1818
ERROR - 2024-02-06 13:47:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:47:08 --> Config Class Initialized
INFO - 2024-02-06 13:47:08 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:47:08 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:47:08 --> Utf8 Class Initialized
INFO - 2024-02-06 13:47:08 --> URI Class Initialized
INFO - 2024-02-06 13:47:08 --> Router Class Initialized
INFO - 2024-02-06 13:47:08 --> Output Class Initialized
INFO - 2024-02-06 13:47:08 --> Security Class Initialized
DEBUG - 2024-02-06 13:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:47:08 --> Input Class Initialized
INFO - 2024-02-06 13:47:08 --> Language Class Initialized
INFO - 2024-02-06 13:47:08 --> Loader Class Initialized
INFO - 2024-02-06 13:47:08 --> Helper loaded: url_helper
INFO - 2024-02-06 13:47:08 --> Helper loaded: file_helper
INFO - 2024-02-06 13:47:08 --> Helper loaded: html_helper
INFO - 2024-02-06 13:47:08 --> Helper loaded: text_helper
INFO - 2024-02-06 13:47:08 --> Helper loaded: form_helper
INFO - 2024-02-06 13:47:08 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:47:08 --> Helper loaded: security_helper
INFO - 2024-02-06 13:47:08 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:47:08 --> Database Driver Class Initialized
INFO - 2024-02-06 13:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:47:08 --> Parser Class Initialized
INFO - 2024-02-06 13:47:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:47:08 --> Pagination Class Initialized
INFO - 2024-02-06 13:47:08 --> Form Validation Class Initialized
INFO - 2024-02-06 13:47:08 --> Controller Class Initialized
INFO - 2024-02-06 13:47:08 --> Model Class Initialized
DEBUG - 2024-02-06 13:47:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:47:08 --> Final output sent to browser
DEBUG - 2024-02-06 13:47:08 --> Total execution time: 0.0158
ERROR - 2024-02-06 13:47:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:47:09 --> Config Class Initialized
INFO - 2024-02-06 13:47:09 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:47:09 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:47:09 --> Utf8 Class Initialized
INFO - 2024-02-06 13:47:09 --> URI Class Initialized
INFO - 2024-02-06 13:47:09 --> Router Class Initialized
INFO - 2024-02-06 13:47:09 --> Output Class Initialized
INFO - 2024-02-06 13:47:09 --> Security Class Initialized
DEBUG - 2024-02-06 13:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:47:09 --> Input Class Initialized
INFO - 2024-02-06 13:47:09 --> Language Class Initialized
INFO - 2024-02-06 13:47:09 --> Loader Class Initialized
INFO - 2024-02-06 13:47:09 --> Helper loaded: url_helper
INFO - 2024-02-06 13:47:09 --> Helper loaded: file_helper
INFO - 2024-02-06 13:47:09 --> Helper loaded: html_helper
INFO - 2024-02-06 13:47:09 --> Helper loaded: text_helper
INFO - 2024-02-06 13:47:09 --> Helper loaded: form_helper
INFO - 2024-02-06 13:47:09 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:47:09 --> Helper loaded: security_helper
INFO - 2024-02-06 13:47:09 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:47:09 --> Database Driver Class Initialized
INFO - 2024-02-06 13:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:47:09 --> Parser Class Initialized
INFO - 2024-02-06 13:47:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:47:09 --> Pagination Class Initialized
INFO - 2024-02-06 13:47:09 --> Form Validation Class Initialized
INFO - 2024-02-06 13:47:09 --> Controller Class Initialized
INFO - 2024-02-06 13:47:09 --> Model Class Initialized
DEBUG - 2024-02-06 13:47:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:47:09 --> Final output sent to browser
DEBUG - 2024-02-06 13:47:09 --> Total execution time: 0.0170
ERROR - 2024-02-06 13:47:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:47:20 --> Config Class Initialized
INFO - 2024-02-06 13:47:20 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:47:20 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:47:20 --> Utf8 Class Initialized
INFO - 2024-02-06 13:47:20 --> URI Class Initialized
INFO - 2024-02-06 13:47:20 --> Router Class Initialized
INFO - 2024-02-06 13:47:20 --> Output Class Initialized
INFO - 2024-02-06 13:47:20 --> Security Class Initialized
DEBUG - 2024-02-06 13:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:47:20 --> Input Class Initialized
INFO - 2024-02-06 13:47:20 --> Language Class Initialized
INFO - 2024-02-06 13:47:20 --> Loader Class Initialized
INFO - 2024-02-06 13:47:20 --> Helper loaded: url_helper
INFO - 2024-02-06 13:47:20 --> Helper loaded: file_helper
INFO - 2024-02-06 13:47:20 --> Helper loaded: html_helper
INFO - 2024-02-06 13:47:20 --> Helper loaded: text_helper
INFO - 2024-02-06 13:47:20 --> Helper loaded: form_helper
INFO - 2024-02-06 13:47:20 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:47:20 --> Helper loaded: security_helper
INFO - 2024-02-06 13:47:20 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:47:20 --> Database Driver Class Initialized
INFO - 2024-02-06 13:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:47:20 --> Parser Class Initialized
INFO - 2024-02-06 13:47:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:47:20 --> Pagination Class Initialized
INFO - 2024-02-06 13:47:20 --> Form Validation Class Initialized
INFO - 2024-02-06 13:47:20 --> Controller Class Initialized
INFO - 2024-02-06 13:47:20 --> Final output sent to browser
DEBUG - 2024-02-06 13:47:20 --> Total execution time: 0.0139
ERROR - 2024-02-06 13:47:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:47:30 --> Config Class Initialized
INFO - 2024-02-06 13:47:30 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:47:30 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:47:30 --> Utf8 Class Initialized
INFO - 2024-02-06 13:47:30 --> URI Class Initialized
INFO - 2024-02-06 13:47:30 --> Router Class Initialized
INFO - 2024-02-06 13:47:30 --> Output Class Initialized
INFO - 2024-02-06 13:47:30 --> Security Class Initialized
DEBUG - 2024-02-06 13:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:47:30 --> Input Class Initialized
INFO - 2024-02-06 13:47:30 --> Language Class Initialized
INFO - 2024-02-06 13:47:30 --> Loader Class Initialized
INFO - 2024-02-06 13:47:30 --> Helper loaded: url_helper
INFO - 2024-02-06 13:47:30 --> Helper loaded: file_helper
INFO - 2024-02-06 13:47:30 --> Helper loaded: html_helper
INFO - 2024-02-06 13:47:30 --> Helper loaded: text_helper
INFO - 2024-02-06 13:47:30 --> Helper loaded: form_helper
INFO - 2024-02-06 13:47:30 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:47:30 --> Helper loaded: security_helper
INFO - 2024-02-06 13:47:30 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:47:30 --> Database Driver Class Initialized
INFO - 2024-02-06 13:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:47:30 --> Parser Class Initialized
INFO - 2024-02-06 13:47:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:47:30 --> Pagination Class Initialized
INFO - 2024-02-06 13:47:30 --> Form Validation Class Initialized
INFO - 2024-02-06 13:47:30 --> Controller Class Initialized
INFO - 2024-02-06 13:47:30 --> Model Class Initialized
DEBUG - 2024-02-06 13:47:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:47:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:47:30 --> Model Class Initialized
DEBUG - 2024-02-06 13:47:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:47:30 --> Model Class Initialized
INFO - 2024-02-06 13:47:30 --> Final output sent to browser
DEBUG - 2024-02-06 13:47:30 --> Total execution time: 0.0922
ERROR - 2024-02-06 13:47:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:47:38 --> Config Class Initialized
INFO - 2024-02-06 13:47:38 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:47:38 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:47:38 --> Utf8 Class Initialized
INFO - 2024-02-06 13:47:38 --> URI Class Initialized
INFO - 2024-02-06 13:47:38 --> Router Class Initialized
INFO - 2024-02-06 13:47:38 --> Output Class Initialized
INFO - 2024-02-06 13:47:38 --> Security Class Initialized
DEBUG - 2024-02-06 13:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:47:38 --> Input Class Initialized
INFO - 2024-02-06 13:47:38 --> Language Class Initialized
INFO - 2024-02-06 13:47:38 --> Loader Class Initialized
INFO - 2024-02-06 13:47:38 --> Helper loaded: url_helper
INFO - 2024-02-06 13:47:38 --> Helper loaded: file_helper
INFO - 2024-02-06 13:47:38 --> Helper loaded: html_helper
INFO - 2024-02-06 13:47:38 --> Helper loaded: text_helper
INFO - 2024-02-06 13:47:38 --> Helper loaded: form_helper
INFO - 2024-02-06 13:47:38 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:47:38 --> Helper loaded: security_helper
INFO - 2024-02-06 13:47:38 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:47:38 --> Database Driver Class Initialized
INFO - 2024-02-06 13:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:47:38 --> Parser Class Initialized
INFO - 2024-02-06 13:47:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:47:38 --> Pagination Class Initialized
INFO - 2024-02-06 13:47:38 --> Form Validation Class Initialized
INFO - 2024-02-06 13:47:38 --> Controller Class Initialized
INFO - 2024-02-06 13:47:38 --> Model Class Initialized
DEBUG - 2024-02-06 13:47:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:47:38 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:47:38 --> Model Class Initialized
INFO - 2024-02-06 13:47:38 --> Model Class Initialized
INFO - 2024-02-06 13:47:38 --> Final output sent to browser
DEBUG - 2024-02-06 13:47:38 --> Total execution time: 0.0281
ERROR - 2024-02-06 13:47:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:47:41 --> Config Class Initialized
INFO - 2024-02-06 13:47:41 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:47:41 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:47:41 --> Utf8 Class Initialized
INFO - 2024-02-06 13:47:41 --> URI Class Initialized
INFO - 2024-02-06 13:47:41 --> Router Class Initialized
INFO - 2024-02-06 13:47:41 --> Output Class Initialized
INFO - 2024-02-06 13:47:41 --> Security Class Initialized
DEBUG - 2024-02-06 13:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:47:41 --> Input Class Initialized
INFO - 2024-02-06 13:47:41 --> Language Class Initialized
INFO - 2024-02-06 13:47:41 --> Loader Class Initialized
INFO - 2024-02-06 13:47:41 --> Helper loaded: url_helper
INFO - 2024-02-06 13:47:41 --> Helper loaded: file_helper
INFO - 2024-02-06 13:47:41 --> Helper loaded: html_helper
INFO - 2024-02-06 13:47:41 --> Helper loaded: text_helper
INFO - 2024-02-06 13:47:41 --> Helper loaded: form_helper
INFO - 2024-02-06 13:47:41 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:47:41 --> Helper loaded: security_helper
INFO - 2024-02-06 13:47:41 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:47:41 --> Database Driver Class Initialized
INFO - 2024-02-06 13:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:47:41 --> Parser Class Initialized
INFO - 2024-02-06 13:47:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:47:41 --> Pagination Class Initialized
INFO - 2024-02-06 13:47:41 --> Form Validation Class Initialized
INFO - 2024-02-06 13:47:41 --> Controller Class Initialized
INFO - 2024-02-06 13:47:41 --> Model Class Initialized
DEBUG - 2024-02-06 13:47:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:47:41 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:47:41 --> Model Class Initialized
INFO - 2024-02-06 13:47:41 --> Final output sent to browser
DEBUG - 2024-02-06 13:47:41 --> Total execution time: 0.0177
ERROR - 2024-02-06 13:48:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:48:03 --> Config Class Initialized
INFO - 2024-02-06 13:48:03 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:48:03 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:48:03 --> Utf8 Class Initialized
INFO - 2024-02-06 13:48:03 --> URI Class Initialized
INFO - 2024-02-06 13:48:03 --> Router Class Initialized
INFO - 2024-02-06 13:48:03 --> Output Class Initialized
INFO - 2024-02-06 13:48:03 --> Security Class Initialized
DEBUG - 2024-02-06 13:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:48:03 --> Input Class Initialized
INFO - 2024-02-06 13:48:03 --> Language Class Initialized
INFO - 2024-02-06 13:48:03 --> Loader Class Initialized
INFO - 2024-02-06 13:48:03 --> Helper loaded: url_helper
INFO - 2024-02-06 13:48:03 --> Helper loaded: file_helper
INFO - 2024-02-06 13:48:03 --> Helper loaded: html_helper
INFO - 2024-02-06 13:48:03 --> Helper loaded: text_helper
INFO - 2024-02-06 13:48:03 --> Helper loaded: form_helper
INFO - 2024-02-06 13:48:03 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:48:03 --> Helper loaded: security_helper
INFO - 2024-02-06 13:48:03 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:48:03 --> Database Driver Class Initialized
INFO - 2024-02-06 13:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:48:03 --> Parser Class Initialized
INFO - 2024-02-06 13:48:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:48:03 --> Pagination Class Initialized
INFO - 2024-02-06 13:48:03 --> Form Validation Class Initialized
INFO - 2024-02-06 13:48:03 --> Controller Class Initialized
INFO - 2024-02-06 13:48:03 --> Model Class Initialized
DEBUG - 2024-02-06 13:48:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:48:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:48:03 --> Model Class Initialized
DEBUG - 2024-02-06 13:48:03 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:48:03 --> Model Class Initialized
INFO - 2024-02-06 13:48:03 --> Final output sent to browser
DEBUG - 2024-02-06 13:48:03 --> Total execution time: 0.0951
ERROR - 2024-02-06 13:48:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:48:08 --> Config Class Initialized
INFO - 2024-02-06 13:48:08 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:48:08 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:48:08 --> Utf8 Class Initialized
INFO - 2024-02-06 13:48:08 --> URI Class Initialized
INFO - 2024-02-06 13:48:08 --> Router Class Initialized
INFO - 2024-02-06 13:48:08 --> Output Class Initialized
INFO - 2024-02-06 13:48:08 --> Security Class Initialized
DEBUG - 2024-02-06 13:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:48:08 --> Input Class Initialized
INFO - 2024-02-06 13:48:08 --> Language Class Initialized
INFO - 2024-02-06 13:48:08 --> Loader Class Initialized
INFO - 2024-02-06 13:48:08 --> Helper loaded: url_helper
INFO - 2024-02-06 13:48:08 --> Helper loaded: file_helper
INFO - 2024-02-06 13:48:08 --> Helper loaded: html_helper
INFO - 2024-02-06 13:48:08 --> Helper loaded: text_helper
INFO - 2024-02-06 13:48:08 --> Helper loaded: form_helper
INFO - 2024-02-06 13:48:08 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:48:08 --> Helper loaded: security_helper
INFO - 2024-02-06 13:48:08 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:48:08 --> Database Driver Class Initialized
INFO - 2024-02-06 13:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:48:08 --> Parser Class Initialized
INFO - 2024-02-06 13:48:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:48:08 --> Pagination Class Initialized
INFO - 2024-02-06 13:48:08 --> Form Validation Class Initialized
INFO - 2024-02-06 13:48:08 --> Controller Class Initialized
INFO - 2024-02-06 13:48:08 --> Model Class Initialized
DEBUG - 2024-02-06 13:48:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:48:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:48:08 --> Model Class Initialized
INFO - 2024-02-06 13:48:08 --> Model Class Initialized
INFO - 2024-02-06 13:48:08 --> Final output sent to browser
DEBUG - 2024-02-06 13:48:08 --> Total execution time: 0.0207
ERROR - 2024-02-06 13:48:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:48:13 --> Config Class Initialized
INFO - 2024-02-06 13:48:13 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:48:13 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:48:13 --> Utf8 Class Initialized
INFO - 2024-02-06 13:48:13 --> URI Class Initialized
INFO - 2024-02-06 13:48:13 --> Router Class Initialized
INFO - 2024-02-06 13:48:13 --> Output Class Initialized
INFO - 2024-02-06 13:48:13 --> Security Class Initialized
DEBUG - 2024-02-06 13:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:48:13 --> Input Class Initialized
INFO - 2024-02-06 13:48:13 --> Language Class Initialized
INFO - 2024-02-06 13:48:13 --> Loader Class Initialized
INFO - 2024-02-06 13:48:13 --> Helper loaded: url_helper
INFO - 2024-02-06 13:48:13 --> Helper loaded: file_helper
INFO - 2024-02-06 13:48:13 --> Helper loaded: html_helper
INFO - 2024-02-06 13:48:13 --> Helper loaded: text_helper
INFO - 2024-02-06 13:48:13 --> Helper loaded: form_helper
INFO - 2024-02-06 13:48:13 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:48:13 --> Helper loaded: security_helper
INFO - 2024-02-06 13:48:13 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:48:13 --> Database Driver Class Initialized
INFO - 2024-02-06 13:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:48:13 --> Parser Class Initialized
INFO - 2024-02-06 13:48:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:48:13 --> Pagination Class Initialized
INFO - 2024-02-06 13:48:13 --> Form Validation Class Initialized
INFO - 2024-02-06 13:48:13 --> Controller Class Initialized
INFO - 2024-02-06 13:48:13 --> Model Class Initialized
DEBUG - 2024-02-06 13:48:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:48:13 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:48:13 --> Model Class Initialized
INFO - 2024-02-06 13:48:13 --> Final output sent to browser
DEBUG - 2024-02-06 13:48:13 --> Total execution time: 0.0190
ERROR - 2024-02-06 13:48:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:48:42 --> Config Class Initialized
INFO - 2024-02-06 13:48:42 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:48:42 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:48:42 --> Utf8 Class Initialized
INFO - 2024-02-06 13:48:42 --> URI Class Initialized
INFO - 2024-02-06 13:48:42 --> Router Class Initialized
INFO - 2024-02-06 13:48:42 --> Output Class Initialized
INFO - 2024-02-06 13:48:42 --> Security Class Initialized
DEBUG - 2024-02-06 13:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:48:42 --> Input Class Initialized
INFO - 2024-02-06 13:48:42 --> Language Class Initialized
INFO - 2024-02-06 13:48:42 --> Loader Class Initialized
INFO - 2024-02-06 13:48:42 --> Helper loaded: url_helper
INFO - 2024-02-06 13:48:42 --> Helper loaded: file_helper
INFO - 2024-02-06 13:48:42 --> Helper loaded: html_helper
INFO - 2024-02-06 13:48:42 --> Helper loaded: text_helper
INFO - 2024-02-06 13:48:42 --> Helper loaded: form_helper
INFO - 2024-02-06 13:48:42 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:48:42 --> Helper loaded: security_helper
INFO - 2024-02-06 13:48:42 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:48:42 --> Database Driver Class Initialized
INFO - 2024-02-06 13:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:48:42 --> Parser Class Initialized
INFO - 2024-02-06 13:48:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:48:42 --> Pagination Class Initialized
INFO - 2024-02-06 13:48:42 --> Form Validation Class Initialized
INFO - 2024-02-06 13:48:42 --> Controller Class Initialized
INFO - 2024-02-06 13:48:42 --> Model Class Initialized
DEBUG - 2024-02-06 13:48:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:48:42 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:48:42 --> Model Class Initialized
INFO - 2024-02-06 13:48:42 --> Final output sent to browser
DEBUG - 2024-02-06 13:48:42 --> Total execution time: 0.0196
ERROR - 2024-02-06 13:48:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:48:56 --> Config Class Initialized
INFO - 2024-02-06 13:48:56 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:48:56 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:48:56 --> Utf8 Class Initialized
INFO - 2024-02-06 13:48:56 --> URI Class Initialized
INFO - 2024-02-06 13:48:56 --> Router Class Initialized
INFO - 2024-02-06 13:48:56 --> Output Class Initialized
INFO - 2024-02-06 13:48:56 --> Security Class Initialized
DEBUG - 2024-02-06 13:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:48:56 --> Input Class Initialized
INFO - 2024-02-06 13:48:56 --> Language Class Initialized
INFO - 2024-02-06 13:48:56 --> Loader Class Initialized
INFO - 2024-02-06 13:48:56 --> Helper loaded: url_helper
INFO - 2024-02-06 13:48:56 --> Helper loaded: file_helper
INFO - 2024-02-06 13:48:56 --> Helper loaded: html_helper
INFO - 2024-02-06 13:48:56 --> Helper loaded: text_helper
INFO - 2024-02-06 13:48:56 --> Helper loaded: form_helper
INFO - 2024-02-06 13:48:56 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:48:56 --> Helper loaded: security_helper
INFO - 2024-02-06 13:48:56 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:48:56 --> Database Driver Class Initialized
INFO - 2024-02-06 13:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:48:56 --> Parser Class Initialized
INFO - 2024-02-06 13:48:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:48:56 --> Pagination Class Initialized
INFO - 2024-02-06 13:48:56 --> Form Validation Class Initialized
INFO - 2024-02-06 13:48:56 --> Controller Class Initialized
INFO - 2024-02-06 13:48:56 --> Model Class Initialized
DEBUG - 2024-02-06 13:48:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:48:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:48:56 --> Model Class Initialized
INFO - 2024-02-06 13:48:56 --> Final output sent to browser
DEBUG - 2024-02-06 13:48:56 --> Total execution time: 0.0197
ERROR - 2024-02-06 13:49:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:49:23 --> Config Class Initialized
INFO - 2024-02-06 13:49:23 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:49:23 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:49:23 --> Utf8 Class Initialized
INFO - 2024-02-06 13:49:23 --> URI Class Initialized
INFO - 2024-02-06 13:49:23 --> Router Class Initialized
INFO - 2024-02-06 13:49:23 --> Output Class Initialized
INFO - 2024-02-06 13:49:23 --> Security Class Initialized
DEBUG - 2024-02-06 13:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:49:23 --> Input Class Initialized
INFO - 2024-02-06 13:49:23 --> Language Class Initialized
INFO - 2024-02-06 13:49:23 --> Loader Class Initialized
INFO - 2024-02-06 13:49:23 --> Helper loaded: url_helper
INFO - 2024-02-06 13:49:23 --> Helper loaded: file_helper
INFO - 2024-02-06 13:49:23 --> Helper loaded: html_helper
INFO - 2024-02-06 13:49:23 --> Helper loaded: text_helper
INFO - 2024-02-06 13:49:23 --> Helper loaded: form_helper
INFO - 2024-02-06 13:49:23 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:49:23 --> Helper loaded: security_helper
INFO - 2024-02-06 13:49:23 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:49:23 --> Database Driver Class Initialized
INFO - 2024-02-06 13:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:49:23 --> Parser Class Initialized
INFO - 2024-02-06 13:49:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:49:23 --> Pagination Class Initialized
INFO - 2024-02-06 13:49:23 --> Form Validation Class Initialized
INFO - 2024-02-06 13:49:23 --> Controller Class Initialized
INFO - 2024-02-06 13:49:23 --> Model Class Initialized
DEBUG - 2024-02-06 13:49:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:49:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:49:23 --> Model Class Initialized
DEBUG - 2024-02-06 13:49:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:49:23 --> Model Class Initialized
INFO - 2024-02-06 13:49:23 --> Final output sent to browser
DEBUG - 2024-02-06 13:49:23 --> Total execution time: 0.0206
ERROR - 2024-02-06 13:49:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:49:26 --> Config Class Initialized
INFO - 2024-02-06 13:49:26 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:49:26 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:49:26 --> Utf8 Class Initialized
INFO - 2024-02-06 13:49:26 --> URI Class Initialized
INFO - 2024-02-06 13:49:26 --> Router Class Initialized
INFO - 2024-02-06 13:49:26 --> Output Class Initialized
INFO - 2024-02-06 13:49:26 --> Security Class Initialized
DEBUG - 2024-02-06 13:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:49:26 --> Input Class Initialized
INFO - 2024-02-06 13:49:26 --> Language Class Initialized
INFO - 2024-02-06 13:49:26 --> Loader Class Initialized
INFO - 2024-02-06 13:49:26 --> Helper loaded: url_helper
INFO - 2024-02-06 13:49:26 --> Helper loaded: file_helper
INFO - 2024-02-06 13:49:26 --> Helper loaded: html_helper
INFO - 2024-02-06 13:49:26 --> Helper loaded: text_helper
INFO - 2024-02-06 13:49:26 --> Helper loaded: form_helper
INFO - 2024-02-06 13:49:26 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:49:26 --> Helper loaded: security_helper
INFO - 2024-02-06 13:49:26 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:49:26 --> Database Driver Class Initialized
INFO - 2024-02-06 13:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:49:26 --> Parser Class Initialized
INFO - 2024-02-06 13:49:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:49:26 --> Pagination Class Initialized
INFO - 2024-02-06 13:49:26 --> Form Validation Class Initialized
INFO - 2024-02-06 13:49:26 --> Controller Class Initialized
INFO - 2024-02-06 13:49:26 --> Model Class Initialized
DEBUG - 2024-02-06 13:49:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:49:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:49:26 --> Model Class Initialized
DEBUG - 2024-02-06 13:49:26 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:49:26 --> Model Class Initialized
INFO - 2024-02-06 13:49:26 --> Final output sent to browser
DEBUG - 2024-02-06 13:49:26 --> Total execution time: 0.0193
ERROR - 2024-02-06 13:49:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:49:33 --> Config Class Initialized
INFO - 2024-02-06 13:49:33 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:49:33 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:49:33 --> Utf8 Class Initialized
INFO - 2024-02-06 13:49:33 --> URI Class Initialized
INFO - 2024-02-06 13:49:33 --> Router Class Initialized
INFO - 2024-02-06 13:49:33 --> Output Class Initialized
INFO - 2024-02-06 13:49:33 --> Security Class Initialized
DEBUG - 2024-02-06 13:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:49:33 --> Input Class Initialized
INFO - 2024-02-06 13:49:33 --> Language Class Initialized
INFO - 2024-02-06 13:49:33 --> Loader Class Initialized
INFO - 2024-02-06 13:49:33 --> Helper loaded: url_helper
INFO - 2024-02-06 13:49:33 --> Helper loaded: file_helper
INFO - 2024-02-06 13:49:33 --> Helper loaded: html_helper
INFO - 2024-02-06 13:49:33 --> Helper loaded: text_helper
INFO - 2024-02-06 13:49:33 --> Helper loaded: form_helper
INFO - 2024-02-06 13:49:33 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:49:33 --> Helper loaded: security_helper
INFO - 2024-02-06 13:49:33 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:49:33 --> Database Driver Class Initialized
INFO - 2024-02-06 13:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:49:33 --> Parser Class Initialized
INFO - 2024-02-06 13:49:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:49:33 --> Pagination Class Initialized
INFO - 2024-02-06 13:49:33 --> Form Validation Class Initialized
INFO - 2024-02-06 13:49:33 --> Controller Class Initialized
INFO - 2024-02-06 13:49:33 --> Model Class Initialized
DEBUG - 2024-02-06 13:49:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:49:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:49:33 --> Model Class Initialized
INFO - 2024-02-06 13:49:33 --> Final output sent to browser
DEBUG - 2024-02-06 13:49:33 --> Total execution time: 0.0210
ERROR - 2024-02-06 13:49:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:49:36 --> Config Class Initialized
INFO - 2024-02-06 13:49:36 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:49:36 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:49:36 --> Utf8 Class Initialized
INFO - 2024-02-06 13:49:36 --> URI Class Initialized
INFO - 2024-02-06 13:49:36 --> Router Class Initialized
INFO - 2024-02-06 13:49:36 --> Output Class Initialized
INFO - 2024-02-06 13:49:36 --> Security Class Initialized
DEBUG - 2024-02-06 13:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:49:36 --> Input Class Initialized
INFO - 2024-02-06 13:49:36 --> Language Class Initialized
INFO - 2024-02-06 13:49:36 --> Loader Class Initialized
INFO - 2024-02-06 13:49:36 --> Helper loaded: url_helper
INFO - 2024-02-06 13:49:36 --> Helper loaded: file_helper
INFO - 2024-02-06 13:49:36 --> Helper loaded: html_helper
INFO - 2024-02-06 13:49:36 --> Helper loaded: text_helper
INFO - 2024-02-06 13:49:36 --> Helper loaded: form_helper
INFO - 2024-02-06 13:49:36 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:49:36 --> Helper loaded: security_helper
INFO - 2024-02-06 13:49:36 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:49:36 --> Database Driver Class Initialized
INFO - 2024-02-06 13:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:49:36 --> Parser Class Initialized
INFO - 2024-02-06 13:49:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:49:36 --> Pagination Class Initialized
INFO - 2024-02-06 13:49:36 --> Form Validation Class Initialized
INFO - 2024-02-06 13:49:36 --> Controller Class Initialized
INFO - 2024-02-06 13:49:36 --> Model Class Initialized
DEBUG - 2024-02-06 13:49:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:49:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:49:36 --> Model Class Initialized
INFO - 2024-02-06 13:49:36 --> Final output sent to browser
DEBUG - 2024-02-06 13:49:36 --> Total execution time: 0.0165
ERROR - 2024-02-06 13:49:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:49:39 --> Config Class Initialized
INFO - 2024-02-06 13:49:39 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:49:39 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:49:39 --> Utf8 Class Initialized
INFO - 2024-02-06 13:49:39 --> URI Class Initialized
DEBUG - 2024-02-06 13:49:39 --> No URI present. Default controller set.
INFO - 2024-02-06 13:49:39 --> Router Class Initialized
INFO - 2024-02-06 13:49:39 --> Output Class Initialized
INFO - 2024-02-06 13:49:39 --> Security Class Initialized
DEBUG - 2024-02-06 13:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:49:39 --> Input Class Initialized
INFO - 2024-02-06 13:49:39 --> Language Class Initialized
INFO - 2024-02-06 13:49:39 --> Loader Class Initialized
INFO - 2024-02-06 13:49:39 --> Helper loaded: url_helper
INFO - 2024-02-06 13:49:39 --> Helper loaded: file_helper
INFO - 2024-02-06 13:49:39 --> Helper loaded: html_helper
INFO - 2024-02-06 13:49:39 --> Helper loaded: text_helper
INFO - 2024-02-06 13:49:39 --> Helper loaded: form_helper
INFO - 2024-02-06 13:49:39 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:49:39 --> Helper loaded: security_helper
INFO - 2024-02-06 13:49:39 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:49:39 --> Database Driver Class Initialized
INFO - 2024-02-06 13:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:49:39 --> Parser Class Initialized
INFO - 2024-02-06 13:49:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:49:39 --> Pagination Class Initialized
INFO - 2024-02-06 13:49:39 --> Form Validation Class Initialized
INFO - 2024-02-06 13:49:39 --> Controller Class Initialized
INFO - 2024-02-06 13:49:39 --> Model Class Initialized
DEBUG - 2024-02-06 13:49:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:49:39 --> Model Class Initialized
DEBUG - 2024-02-06 13:49:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:49:39 --> Model Class Initialized
INFO - 2024-02-06 13:49:39 --> Model Class Initialized
INFO - 2024-02-06 13:49:39 --> Model Class Initialized
INFO - 2024-02-06 13:49:39 --> Model Class Initialized
DEBUG - 2024-02-06 13:49:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:49:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:49:39 --> Model Class Initialized
INFO - 2024-02-06 13:49:39 --> Model Class Initialized
INFO - 2024-02-06 13:49:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 13:49:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:49:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 13:49:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 13:49:39 --> Model Class Initialized
INFO - 2024-02-06 13:49:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 13:49:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 13:49:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 13:49:39 --> Final output sent to browser
DEBUG - 2024-02-06 13:49:39 --> Total execution time: 0.2380
ERROR - 2024-02-06 13:49:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:49:40 --> Config Class Initialized
INFO - 2024-02-06 13:49:40 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:49:40 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:49:40 --> Utf8 Class Initialized
INFO - 2024-02-06 13:49:40 --> URI Class Initialized
INFO - 2024-02-06 13:49:40 --> Router Class Initialized
INFO - 2024-02-06 13:49:40 --> Output Class Initialized
INFO - 2024-02-06 13:49:40 --> Security Class Initialized
DEBUG - 2024-02-06 13:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:49:40 --> Input Class Initialized
INFO - 2024-02-06 13:49:40 --> Language Class Initialized
INFO - 2024-02-06 13:49:40 --> Loader Class Initialized
INFO - 2024-02-06 13:49:40 --> Helper loaded: url_helper
INFO - 2024-02-06 13:49:40 --> Helper loaded: file_helper
INFO - 2024-02-06 13:49:40 --> Helper loaded: html_helper
INFO - 2024-02-06 13:49:40 --> Helper loaded: text_helper
INFO - 2024-02-06 13:49:40 --> Helper loaded: form_helper
INFO - 2024-02-06 13:49:40 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:49:40 --> Helper loaded: security_helper
INFO - 2024-02-06 13:49:40 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:49:40 --> Database Driver Class Initialized
INFO - 2024-02-06 13:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:49:40 --> Parser Class Initialized
INFO - 2024-02-06 13:49:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:49:40 --> Pagination Class Initialized
INFO - 2024-02-06 13:49:40 --> Form Validation Class Initialized
INFO - 2024-02-06 13:49:40 --> Controller Class Initialized
INFO - 2024-02-06 13:49:40 --> Model Class Initialized
DEBUG - 2024-02-06 13:49:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-06 13:49:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 13:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 13:49:40 --> Model Class Initialized
INFO - 2024-02-06 13:49:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 13:49:40 --> Final output sent to browser
DEBUG - 2024-02-06 13:49:40 --> Total execution time: 0.0382
ERROR - 2024-02-06 13:49:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:49:40 --> Config Class Initialized
INFO - 2024-02-06 13:49:40 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:49:40 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:49:40 --> Utf8 Class Initialized
INFO - 2024-02-06 13:49:40 --> URI Class Initialized
INFO - 2024-02-06 13:49:40 --> Router Class Initialized
INFO - 2024-02-06 13:49:40 --> Output Class Initialized
INFO - 2024-02-06 13:49:40 --> Security Class Initialized
DEBUG - 2024-02-06 13:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:49:40 --> Input Class Initialized
INFO - 2024-02-06 13:49:40 --> Language Class Initialized
INFO - 2024-02-06 13:49:40 --> Loader Class Initialized
INFO - 2024-02-06 13:49:40 --> Helper loaded: url_helper
INFO - 2024-02-06 13:49:40 --> Helper loaded: file_helper
INFO - 2024-02-06 13:49:40 --> Helper loaded: html_helper
INFO - 2024-02-06 13:49:40 --> Helper loaded: text_helper
INFO - 2024-02-06 13:49:40 --> Helper loaded: form_helper
INFO - 2024-02-06 13:49:40 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:49:40 --> Helper loaded: security_helper
INFO - 2024-02-06 13:49:40 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:49:40 --> Database Driver Class Initialized
INFO - 2024-02-06 13:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:49:40 --> Parser Class Initialized
INFO - 2024-02-06 13:49:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:49:40 --> Pagination Class Initialized
INFO - 2024-02-06 13:49:40 --> Form Validation Class Initialized
INFO - 2024-02-06 13:49:40 --> Controller Class Initialized
INFO - 2024-02-06 13:49:40 --> Model Class Initialized
DEBUG - 2024-02-06 13:49:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:49:40 --> Model Class Initialized
DEBUG - 2024-02-06 13:49:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:49:40 --> Model Class Initialized
INFO - 2024-02-06 13:49:40 --> Model Class Initialized
INFO - 2024-02-06 13:49:40 --> Model Class Initialized
INFO - 2024-02-06 13:49:40 --> Model Class Initialized
DEBUG - 2024-02-06 13:49:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:49:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:49:40 --> Model Class Initialized
INFO - 2024-02-06 13:49:40 --> Model Class Initialized
INFO - 2024-02-06 13:49:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 13:49:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:49:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 13:49:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 13:49:41 --> Model Class Initialized
INFO - 2024-02-06 13:49:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 13:49:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 13:49:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 13:49:41 --> Final output sent to browser
DEBUG - 2024-02-06 13:49:41 --> Total execution time: 0.2328
ERROR - 2024-02-06 13:49:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:49:48 --> Config Class Initialized
INFO - 2024-02-06 13:49:48 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:49:48 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:49:48 --> Utf8 Class Initialized
INFO - 2024-02-06 13:49:48 --> URI Class Initialized
DEBUG - 2024-02-06 13:49:48 --> No URI present. Default controller set.
INFO - 2024-02-06 13:49:48 --> Router Class Initialized
INFO - 2024-02-06 13:49:48 --> Output Class Initialized
INFO - 2024-02-06 13:49:48 --> Security Class Initialized
DEBUG - 2024-02-06 13:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:49:48 --> Input Class Initialized
INFO - 2024-02-06 13:49:48 --> Language Class Initialized
INFO - 2024-02-06 13:49:48 --> Loader Class Initialized
INFO - 2024-02-06 13:49:48 --> Helper loaded: url_helper
INFO - 2024-02-06 13:49:48 --> Helper loaded: file_helper
INFO - 2024-02-06 13:49:48 --> Helper loaded: html_helper
INFO - 2024-02-06 13:49:48 --> Helper loaded: text_helper
INFO - 2024-02-06 13:49:48 --> Helper loaded: form_helper
INFO - 2024-02-06 13:49:48 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:49:48 --> Helper loaded: security_helper
INFO - 2024-02-06 13:49:48 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:49:48 --> Database Driver Class Initialized
INFO - 2024-02-06 13:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:49:48 --> Parser Class Initialized
INFO - 2024-02-06 13:49:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:49:48 --> Pagination Class Initialized
INFO - 2024-02-06 13:49:48 --> Form Validation Class Initialized
INFO - 2024-02-06 13:49:48 --> Controller Class Initialized
INFO - 2024-02-06 13:49:48 --> Model Class Initialized
DEBUG - 2024-02-06 13:49:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:49:48 --> Model Class Initialized
DEBUG - 2024-02-06 13:49:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:49:48 --> Model Class Initialized
INFO - 2024-02-06 13:49:48 --> Model Class Initialized
INFO - 2024-02-06 13:49:48 --> Model Class Initialized
INFO - 2024-02-06 13:49:48 --> Model Class Initialized
DEBUG - 2024-02-06 13:49:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:49:48 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:49:48 --> Model Class Initialized
INFO - 2024-02-06 13:49:48 --> Model Class Initialized
INFO - 2024-02-06 13:49:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 13:49:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:49:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 13:49:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 13:49:48 --> Model Class Initialized
INFO - 2024-02-06 13:49:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 13:49:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 13:49:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 13:49:48 --> Final output sent to browser
DEBUG - 2024-02-06 13:49:48 --> Total execution time: 0.2362
ERROR - 2024-02-06 13:49:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:49:57 --> Config Class Initialized
INFO - 2024-02-06 13:49:57 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:49:57 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:49:57 --> Utf8 Class Initialized
INFO - 2024-02-06 13:49:57 --> URI Class Initialized
INFO - 2024-02-06 13:49:57 --> Router Class Initialized
INFO - 2024-02-06 13:49:57 --> Output Class Initialized
INFO - 2024-02-06 13:49:57 --> Security Class Initialized
DEBUG - 2024-02-06 13:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:49:57 --> Input Class Initialized
INFO - 2024-02-06 13:49:57 --> Language Class Initialized
INFO - 2024-02-06 13:49:57 --> Loader Class Initialized
INFO - 2024-02-06 13:49:57 --> Helper loaded: url_helper
INFO - 2024-02-06 13:49:57 --> Helper loaded: file_helper
INFO - 2024-02-06 13:49:57 --> Helper loaded: html_helper
INFO - 2024-02-06 13:49:57 --> Helper loaded: text_helper
INFO - 2024-02-06 13:49:57 --> Helper loaded: form_helper
INFO - 2024-02-06 13:49:57 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:49:57 --> Helper loaded: security_helper
INFO - 2024-02-06 13:49:57 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:49:57 --> Database Driver Class Initialized
INFO - 2024-02-06 13:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:49:57 --> Parser Class Initialized
INFO - 2024-02-06 13:49:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:49:57 --> Pagination Class Initialized
INFO - 2024-02-06 13:49:57 --> Form Validation Class Initialized
INFO - 2024-02-06 13:49:57 --> Controller Class Initialized
INFO - 2024-02-06 13:49:57 --> Model Class Initialized
DEBUG - 2024-02-06 13:49:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:49:57 --> Model Class Initialized
DEBUG - 2024-02-06 13:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:49:57 --> Model Class Initialized
INFO - 2024-02-06 13:49:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2024-02-06 13:49:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:49:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 13:49:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 13:49:57 --> Model Class Initialized
INFO - 2024-02-06 13:49:57 --> Model Class Initialized
INFO - 2024-02-06 13:49:57 --> Model Class Initialized
INFO - 2024-02-06 13:49:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 13:49:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 13:49:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 13:49:57 --> Final output sent to browser
DEBUG - 2024-02-06 13:49:57 --> Total execution time: 0.1828
ERROR - 2024-02-06 13:50:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:50:14 --> Config Class Initialized
INFO - 2024-02-06 13:50:14 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:50:14 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:50:14 --> Utf8 Class Initialized
INFO - 2024-02-06 13:50:14 --> URI Class Initialized
INFO - 2024-02-06 13:50:14 --> Router Class Initialized
INFO - 2024-02-06 13:50:14 --> Output Class Initialized
INFO - 2024-02-06 13:50:14 --> Security Class Initialized
DEBUG - 2024-02-06 13:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:50:14 --> Input Class Initialized
INFO - 2024-02-06 13:50:14 --> Language Class Initialized
INFO - 2024-02-06 13:50:14 --> Loader Class Initialized
INFO - 2024-02-06 13:50:14 --> Helper loaded: url_helper
INFO - 2024-02-06 13:50:14 --> Helper loaded: file_helper
INFO - 2024-02-06 13:50:14 --> Helper loaded: html_helper
INFO - 2024-02-06 13:50:14 --> Helper loaded: text_helper
INFO - 2024-02-06 13:50:14 --> Helper loaded: form_helper
INFO - 2024-02-06 13:50:14 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:50:14 --> Helper loaded: security_helper
INFO - 2024-02-06 13:50:14 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:50:14 --> Database Driver Class Initialized
INFO - 2024-02-06 13:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:50:14 --> Parser Class Initialized
INFO - 2024-02-06 13:50:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:50:14 --> Pagination Class Initialized
INFO - 2024-02-06 13:50:14 --> Form Validation Class Initialized
INFO - 2024-02-06 13:50:14 --> Controller Class Initialized
INFO - 2024-02-06 13:50:14 --> Model Class Initialized
DEBUG - 2024-02-06 13:50:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:50:14 --> Final output sent to browser
DEBUG - 2024-02-06 13:50:14 --> Total execution time: 0.0182
ERROR - 2024-02-06 13:50:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:50:14 --> Config Class Initialized
INFO - 2024-02-06 13:50:14 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:50:14 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:50:14 --> Utf8 Class Initialized
INFO - 2024-02-06 13:50:14 --> URI Class Initialized
INFO - 2024-02-06 13:50:14 --> Router Class Initialized
INFO - 2024-02-06 13:50:14 --> Output Class Initialized
INFO - 2024-02-06 13:50:14 --> Security Class Initialized
DEBUG - 2024-02-06 13:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:50:14 --> Input Class Initialized
INFO - 2024-02-06 13:50:14 --> Language Class Initialized
INFO - 2024-02-06 13:50:14 --> Loader Class Initialized
INFO - 2024-02-06 13:50:14 --> Helper loaded: url_helper
INFO - 2024-02-06 13:50:14 --> Helper loaded: file_helper
INFO - 2024-02-06 13:50:14 --> Helper loaded: html_helper
INFO - 2024-02-06 13:50:14 --> Helper loaded: text_helper
INFO - 2024-02-06 13:50:14 --> Helper loaded: form_helper
INFO - 2024-02-06 13:50:14 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:50:14 --> Helper loaded: security_helper
INFO - 2024-02-06 13:50:14 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:50:14 --> Database Driver Class Initialized
INFO - 2024-02-06 13:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:50:14 --> Parser Class Initialized
INFO - 2024-02-06 13:50:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:50:14 --> Pagination Class Initialized
INFO - 2024-02-06 13:50:14 --> Form Validation Class Initialized
INFO - 2024-02-06 13:50:14 --> Controller Class Initialized
INFO - 2024-02-06 13:50:14 --> Model Class Initialized
DEBUG - 2024-02-06 13:50:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-06 13:50:14 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2024-02-06 13:50:14 --> Final output sent to browser
DEBUG - 2024-02-06 13:50:14 --> Total execution time: 0.0151
ERROR - 2024-02-06 13:50:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:50:17 --> Config Class Initialized
INFO - 2024-02-06 13:50:17 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:50:17 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:50:17 --> Utf8 Class Initialized
INFO - 2024-02-06 13:50:17 --> URI Class Initialized
INFO - 2024-02-06 13:50:17 --> Router Class Initialized
INFO - 2024-02-06 13:50:17 --> Output Class Initialized
INFO - 2024-02-06 13:50:17 --> Security Class Initialized
DEBUG - 2024-02-06 13:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:50:17 --> Input Class Initialized
INFO - 2024-02-06 13:50:17 --> Language Class Initialized
INFO - 2024-02-06 13:50:17 --> Loader Class Initialized
INFO - 2024-02-06 13:50:17 --> Helper loaded: url_helper
INFO - 2024-02-06 13:50:17 --> Helper loaded: file_helper
INFO - 2024-02-06 13:50:17 --> Helper loaded: html_helper
INFO - 2024-02-06 13:50:17 --> Helper loaded: text_helper
INFO - 2024-02-06 13:50:17 --> Helper loaded: form_helper
INFO - 2024-02-06 13:50:17 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:50:17 --> Helper loaded: security_helper
INFO - 2024-02-06 13:50:17 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:50:17 --> Database Driver Class Initialized
INFO - 2024-02-06 13:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:50:17 --> Parser Class Initialized
INFO - 2024-02-06 13:50:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:50:17 --> Pagination Class Initialized
INFO - 2024-02-06 13:50:17 --> Form Validation Class Initialized
INFO - 2024-02-06 13:50:17 --> Controller Class Initialized
INFO - 2024-02-06 13:50:17 --> Model Class Initialized
DEBUG - 2024-02-06 13:50:17 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:50:17 --> Final output sent to browser
DEBUG - 2024-02-06 13:50:17 --> Total execution time: 0.0170
ERROR - 2024-02-06 13:50:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:50:25 --> Config Class Initialized
INFO - 2024-02-06 13:50:25 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:50:25 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:50:25 --> Utf8 Class Initialized
INFO - 2024-02-06 13:50:25 --> URI Class Initialized
INFO - 2024-02-06 13:50:25 --> Router Class Initialized
INFO - 2024-02-06 13:50:25 --> Output Class Initialized
INFO - 2024-02-06 13:50:25 --> Security Class Initialized
DEBUG - 2024-02-06 13:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:50:25 --> Input Class Initialized
INFO - 2024-02-06 13:50:25 --> Language Class Initialized
INFO - 2024-02-06 13:50:25 --> Loader Class Initialized
INFO - 2024-02-06 13:50:25 --> Helper loaded: url_helper
INFO - 2024-02-06 13:50:25 --> Helper loaded: file_helper
INFO - 2024-02-06 13:50:25 --> Helper loaded: html_helper
INFO - 2024-02-06 13:50:25 --> Helper loaded: text_helper
INFO - 2024-02-06 13:50:25 --> Helper loaded: form_helper
INFO - 2024-02-06 13:50:25 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:50:25 --> Helper loaded: security_helper
INFO - 2024-02-06 13:50:25 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:50:25 --> Database Driver Class Initialized
INFO - 2024-02-06 13:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:50:25 --> Parser Class Initialized
INFO - 2024-02-06 13:50:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:50:25 --> Pagination Class Initialized
INFO - 2024-02-06 13:50:25 --> Form Validation Class Initialized
INFO - 2024-02-06 13:50:25 --> Controller Class Initialized
INFO - 2024-02-06 13:50:25 --> Final output sent to browser
DEBUG - 2024-02-06 13:50:25 --> Total execution time: 0.0178
ERROR - 2024-02-06 13:50:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:50:29 --> Config Class Initialized
INFO - 2024-02-06 13:50:29 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:50:29 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:50:29 --> Utf8 Class Initialized
INFO - 2024-02-06 13:50:29 --> URI Class Initialized
INFO - 2024-02-06 13:50:29 --> Router Class Initialized
INFO - 2024-02-06 13:50:29 --> Output Class Initialized
INFO - 2024-02-06 13:50:29 --> Security Class Initialized
DEBUG - 2024-02-06 13:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:50:29 --> Input Class Initialized
INFO - 2024-02-06 13:50:29 --> Language Class Initialized
INFO - 2024-02-06 13:50:29 --> Loader Class Initialized
INFO - 2024-02-06 13:50:29 --> Helper loaded: url_helper
INFO - 2024-02-06 13:50:29 --> Helper loaded: file_helper
INFO - 2024-02-06 13:50:29 --> Helper loaded: html_helper
INFO - 2024-02-06 13:50:29 --> Helper loaded: text_helper
INFO - 2024-02-06 13:50:29 --> Helper loaded: form_helper
INFO - 2024-02-06 13:50:29 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:50:29 --> Helper loaded: security_helper
INFO - 2024-02-06 13:50:29 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:50:29 --> Database Driver Class Initialized
INFO - 2024-02-06 13:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:50:29 --> Parser Class Initialized
INFO - 2024-02-06 13:50:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:50:29 --> Pagination Class Initialized
INFO - 2024-02-06 13:50:29 --> Form Validation Class Initialized
INFO - 2024-02-06 13:50:29 --> Controller Class Initialized
INFO - 2024-02-06 13:50:29 --> Model Class Initialized
DEBUG - 2024-02-06 13:50:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:50:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:50:29 --> Model Class Initialized
DEBUG - 2024-02-06 13:50:29 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:50:29 --> Model Class Initialized
INFO - 2024-02-06 13:50:29 --> Final output sent to browser
DEBUG - 2024-02-06 13:50:29 --> Total execution time: 0.0925
ERROR - 2024-02-06 13:50:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:50:35 --> Config Class Initialized
INFO - 2024-02-06 13:50:35 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:50:35 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:50:35 --> Utf8 Class Initialized
INFO - 2024-02-06 13:50:35 --> URI Class Initialized
INFO - 2024-02-06 13:50:35 --> Router Class Initialized
INFO - 2024-02-06 13:50:35 --> Output Class Initialized
INFO - 2024-02-06 13:50:35 --> Security Class Initialized
DEBUG - 2024-02-06 13:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:50:35 --> Input Class Initialized
INFO - 2024-02-06 13:50:35 --> Language Class Initialized
INFO - 2024-02-06 13:50:35 --> Loader Class Initialized
INFO - 2024-02-06 13:50:35 --> Helper loaded: url_helper
INFO - 2024-02-06 13:50:35 --> Helper loaded: file_helper
INFO - 2024-02-06 13:50:35 --> Helper loaded: html_helper
INFO - 2024-02-06 13:50:35 --> Helper loaded: text_helper
INFO - 2024-02-06 13:50:35 --> Helper loaded: form_helper
INFO - 2024-02-06 13:50:35 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:50:35 --> Helper loaded: security_helper
INFO - 2024-02-06 13:50:35 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:50:35 --> Database Driver Class Initialized
INFO - 2024-02-06 13:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:50:35 --> Parser Class Initialized
INFO - 2024-02-06 13:50:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:50:35 --> Pagination Class Initialized
INFO - 2024-02-06 13:50:35 --> Form Validation Class Initialized
INFO - 2024-02-06 13:50:35 --> Controller Class Initialized
INFO - 2024-02-06 13:50:35 --> Model Class Initialized
DEBUG - 2024-02-06 13:50:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:50:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:50:35 --> Model Class Initialized
INFO - 2024-02-06 13:50:35 --> Model Class Initialized
INFO - 2024-02-06 13:50:35 --> Final output sent to browser
DEBUG - 2024-02-06 13:50:35 --> Total execution time: 0.0185
ERROR - 2024-02-06 13:50:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:50:39 --> Config Class Initialized
INFO - 2024-02-06 13:50:39 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:50:39 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:50:39 --> Utf8 Class Initialized
INFO - 2024-02-06 13:50:39 --> URI Class Initialized
INFO - 2024-02-06 13:50:39 --> Router Class Initialized
INFO - 2024-02-06 13:50:39 --> Output Class Initialized
INFO - 2024-02-06 13:50:39 --> Security Class Initialized
DEBUG - 2024-02-06 13:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:50:39 --> Input Class Initialized
INFO - 2024-02-06 13:50:39 --> Language Class Initialized
INFO - 2024-02-06 13:50:39 --> Loader Class Initialized
INFO - 2024-02-06 13:50:39 --> Helper loaded: url_helper
INFO - 2024-02-06 13:50:39 --> Helper loaded: file_helper
INFO - 2024-02-06 13:50:39 --> Helper loaded: html_helper
INFO - 2024-02-06 13:50:39 --> Helper loaded: text_helper
INFO - 2024-02-06 13:50:39 --> Helper loaded: form_helper
INFO - 2024-02-06 13:50:39 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:50:39 --> Helper loaded: security_helper
INFO - 2024-02-06 13:50:39 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:50:39 --> Database Driver Class Initialized
INFO - 2024-02-06 13:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:50:39 --> Parser Class Initialized
INFO - 2024-02-06 13:50:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:50:39 --> Pagination Class Initialized
INFO - 2024-02-06 13:50:39 --> Form Validation Class Initialized
INFO - 2024-02-06 13:50:39 --> Controller Class Initialized
INFO - 2024-02-06 13:50:39 --> Model Class Initialized
DEBUG - 2024-02-06 13:50:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:50:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:50:39 --> Model Class Initialized
INFO - 2024-02-06 13:50:39 --> Final output sent to browser
DEBUG - 2024-02-06 13:50:39 --> Total execution time: 0.0164
ERROR - 2024-02-06 13:50:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:50:53 --> Config Class Initialized
INFO - 2024-02-06 13:50:53 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:50:53 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:50:53 --> Utf8 Class Initialized
INFO - 2024-02-06 13:50:53 --> URI Class Initialized
INFO - 2024-02-06 13:50:53 --> Router Class Initialized
INFO - 2024-02-06 13:50:53 --> Output Class Initialized
INFO - 2024-02-06 13:50:53 --> Security Class Initialized
DEBUG - 2024-02-06 13:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:50:53 --> Input Class Initialized
INFO - 2024-02-06 13:50:53 --> Language Class Initialized
INFO - 2024-02-06 13:50:53 --> Loader Class Initialized
INFO - 2024-02-06 13:50:53 --> Helper loaded: url_helper
INFO - 2024-02-06 13:50:53 --> Helper loaded: file_helper
INFO - 2024-02-06 13:50:53 --> Helper loaded: html_helper
INFO - 2024-02-06 13:50:53 --> Helper loaded: text_helper
INFO - 2024-02-06 13:50:53 --> Helper loaded: form_helper
INFO - 2024-02-06 13:50:53 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:50:53 --> Helper loaded: security_helper
INFO - 2024-02-06 13:50:53 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:50:53 --> Database Driver Class Initialized
INFO - 2024-02-06 13:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:50:53 --> Parser Class Initialized
INFO - 2024-02-06 13:50:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:50:53 --> Pagination Class Initialized
INFO - 2024-02-06 13:50:53 --> Form Validation Class Initialized
INFO - 2024-02-06 13:50:53 --> Controller Class Initialized
INFO - 2024-02-06 13:50:53 --> Model Class Initialized
DEBUG - 2024-02-06 13:50:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:50:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:50:53 --> Model Class Initialized
DEBUG - 2024-02-06 13:50:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:50:53 --> Model Class Initialized
INFO - 2024-02-06 13:50:53 --> Email Class Initialized
DEBUG - 2024-02-06 13:50:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:50:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2024-02-06 13:50:54 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2024-02-06 13:50:54 --> Language file loaded: language/english/email_lang.php
INFO - 2024-02-06 13:50:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2024-02-06 13:50:54 --> Final output sent to browser
DEBUG - 2024-02-06 13:50:54 --> Total execution time: 0.3629
ERROR - 2024-02-06 13:50:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 13:50:56 --> Config Class Initialized
INFO - 2024-02-06 13:50:56 --> Hooks Class Initialized
DEBUG - 2024-02-06 13:50:56 --> UTF-8 Support Enabled
INFO - 2024-02-06 13:50:56 --> Utf8 Class Initialized
INFO - 2024-02-06 13:50:56 --> URI Class Initialized
DEBUG - 2024-02-06 13:50:56 --> No URI present. Default controller set.
INFO - 2024-02-06 13:50:56 --> Router Class Initialized
INFO - 2024-02-06 13:50:56 --> Output Class Initialized
INFO - 2024-02-06 13:50:56 --> Security Class Initialized
DEBUG - 2024-02-06 13:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 13:50:56 --> Input Class Initialized
INFO - 2024-02-06 13:50:56 --> Language Class Initialized
INFO - 2024-02-06 13:50:56 --> Loader Class Initialized
INFO - 2024-02-06 13:50:56 --> Helper loaded: url_helper
INFO - 2024-02-06 13:50:56 --> Helper loaded: file_helper
INFO - 2024-02-06 13:50:56 --> Helper loaded: html_helper
INFO - 2024-02-06 13:50:56 --> Helper loaded: text_helper
INFO - 2024-02-06 13:50:56 --> Helper loaded: form_helper
INFO - 2024-02-06 13:50:56 --> Helper loaded: lang_helper
INFO - 2024-02-06 13:50:56 --> Helper loaded: security_helper
INFO - 2024-02-06 13:50:56 --> Helper loaded: cookie_helper
INFO - 2024-02-06 13:50:56 --> Database Driver Class Initialized
INFO - 2024-02-06 13:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 13:50:56 --> Parser Class Initialized
INFO - 2024-02-06 13:50:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 13:50:56 --> Pagination Class Initialized
INFO - 2024-02-06 13:50:56 --> Form Validation Class Initialized
INFO - 2024-02-06 13:50:56 --> Controller Class Initialized
INFO - 2024-02-06 13:50:56 --> Model Class Initialized
DEBUG - 2024-02-06 13:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:50:56 --> Model Class Initialized
DEBUG - 2024-02-06 13:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:50:56 --> Model Class Initialized
INFO - 2024-02-06 13:50:56 --> Model Class Initialized
INFO - 2024-02-06 13:50:56 --> Model Class Initialized
INFO - 2024-02-06 13:50:56 --> Model Class Initialized
DEBUG - 2024-02-06 13:50:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 13:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:50:56 --> Model Class Initialized
INFO - 2024-02-06 13:50:56 --> Model Class Initialized
INFO - 2024-02-06 13:50:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 13:50:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 13:50:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 13:50:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 13:50:56 --> Model Class Initialized
INFO - 2024-02-06 13:50:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 13:50:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 13:50:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 13:50:56 --> Final output sent to browser
DEBUG - 2024-02-06 13:50:56 --> Total execution time: 0.2384
ERROR - 2024-02-06 14:07:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 14:07:26 --> Config Class Initialized
INFO - 2024-02-06 14:07:26 --> Hooks Class Initialized
DEBUG - 2024-02-06 14:07:26 --> UTF-8 Support Enabled
INFO - 2024-02-06 14:07:26 --> Utf8 Class Initialized
INFO - 2024-02-06 14:07:26 --> URI Class Initialized
INFO - 2024-02-06 14:07:26 --> Router Class Initialized
INFO - 2024-02-06 14:07:26 --> Output Class Initialized
INFO - 2024-02-06 14:07:26 --> Security Class Initialized
DEBUG - 2024-02-06 14:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 14:07:26 --> Input Class Initialized
INFO - 2024-02-06 14:07:26 --> Language Class Initialized
ERROR - 2024-02-06 14:07:26 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2024-02-06 15:50:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:50:27 --> Config Class Initialized
INFO - 2024-02-06 15:50:27 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:50:27 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:50:27 --> Utf8 Class Initialized
INFO - 2024-02-06 15:50:27 --> URI Class Initialized
DEBUG - 2024-02-06 15:50:27 --> No URI present. Default controller set.
INFO - 2024-02-06 15:50:27 --> Router Class Initialized
INFO - 2024-02-06 15:50:27 --> Output Class Initialized
INFO - 2024-02-06 15:50:27 --> Security Class Initialized
DEBUG - 2024-02-06 15:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:50:27 --> Input Class Initialized
INFO - 2024-02-06 15:50:27 --> Language Class Initialized
INFO - 2024-02-06 15:50:27 --> Loader Class Initialized
INFO - 2024-02-06 15:50:27 --> Helper loaded: url_helper
INFO - 2024-02-06 15:50:27 --> Helper loaded: file_helper
INFO - 2024-02-06 15:50:27 --> Helper loaded: html_helper
INFO - 2024-02-06 15:50:27 --> Helper loaded: text_helper
INFO - 2024-02-06 15:50:27 --> Helper loaded: form_helper
INFO - 2024-02-06 15:50:27 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:50:27 --> Helper loaded: security_helper
INFO - 2024-02-06 15:50:27 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:50:27 --> Database Driver Class Initialized
INFO - 2024-02-06 15:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:50:27 --> Parser Class Initialized
INFO - 2024-02-06 15:50:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:50:27 --> Pagination Class Initialized
INFO - 2024-02-06 15:50:27 --> Form Validation Class Initialized
INFO - 2024-02-06 15:50:27 --> Controller Class Initialized
INFO - 2024-02-06 15:50:27 --> Model Class Initialized
DEBUG - 2024-02-06 15:50:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2024-02-06 15:50:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:50:27 --> Config Class Initialized
INFO - 2024-02-06 15:50:27 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:50:27 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:50:27 --> Utf8 Class Initialized
INFO - 2024-02-06 15:50:27 --> URI Class Initialized
INFO - 2024-02-06 15:50:27 --> Router Class Initialized
INFO - 2024-02-06 15:50:27 --> Output Class Initialized
INFO - 2024-02-06 15:50:27 --> Security Class Initialized
DEBUG - 2024-02-06 15:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:50:27 --> Input Class Initialized
INFO - 2024-02-06 15:50:27 --> Language Class Initialized
INFO - 2024-02-06 15:50:27 --> Loader Class Initialized
INFO - 2024-02-06 15:50:27 --> Helper loaded: url_helper
INFO - 2024-02-06 15:50:27 --> Helper loaded: file_helper
INFO - 2024-02-06 15:50:27 --> Helper loaded: html_helper
INFO - 2024-02-06 15:50:27 --> Helper loaded: text_helper
INFO - 2024-02-06 15:50:27 --> Helper loaded: form_helper
INFO - 2024-02-06 15:50:27 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:50:27 --> Helper loaded: security_helper
INFO - 2024-02-06 15:50:27 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:50:27 --> Database Driver Class Initialized
INFO - 2024-02-06 15:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:50:27 --> Parser Class Initialized
INFO - 2024-02-06 15:50:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:50:27 --> Pagination Class Initialized
INFO - 2024-02-06 15:50:27 --> Form Validation Class Initialized
INFO - 2024-02-06 15:50:27 --> Controller Class Initialized
INFO - 2024-02-06 15:50:27 --> Model Class Initialized
DEBUG - 2024-02-06 15:50:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:50:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2024-02-06 15:50:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:50:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:50:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:50:27 --> Model Class Initialized
INFO - 2024-02-06 15:50:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:50:27 --> Final output sent to browser
DEBUG - 2024-02-06 15:50:27 --> Total execution time: 0.0353
ERROR - 2024-02-06 15:50:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:50:35 --> Config Class Initialized
INFO - 2024-02-06 15:50:35 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:50:35 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:50:35 --> Utf8 Class Initialized
INFO - 2024-02-06 15:50:35 --> URI Class Initialized
INFO - 2024-02-06 15:50:35 --> Router Class Initialized
INFO - 2024-02-06 15:50:35 --> Output Class Initialized
INFO - 2024-02-06 15:50:35 --> Security Class Initialized
DEBUG - 2024-02-06 15:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:50:35 --> Input Class Initialized
INFO - 2024-02-06 15:50:35 --> Language Class Initialized
INFO - 2024-02-06 15:50:35 --> Loader Class Initialized
INFO - 2024-02-06 15:50:35 --> Helper loaded: url_helper
INFO - 2024-02-06 15:50:35 --> Helper loaded: file_helper
INFO - 2024-02-06 15:50:35 --> Helper loaded: html_helper
INFO - 2024-02-06 15:50:35 --> Helper loaded: text_helper
INFO - 2024-02-06 15:50:35 --> Helper loaded: form_helper
INFO - 2024-02-06 15:50:35 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:50:35 --> Helper loaded: security_helper
INFO - 2024-02-06 15:50:35 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:50:35 --> Database Driver Class Initialized
INFO - 2024-02-06 15:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:50:35 --> Parser Class Initialized
INFO - 2024-02-06 15:50:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:50:35 --> Pagination Class Initialized
INFO - 2024-02-06 15:50:35 --> Form Validation Class Initialized
INFO - 2024-02-06 15:50:35 --> Controller Class Initialized
INFO - 2024-02-06 15:50:35 --> Model Class Initialized
DEBUG - 2024-02-06 15:50:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:50:35 --> Model Class Initialized
INFO - 2024-02-06 15:50:35 --> Final output sent to browser
DEBUG - 2024-02-06 15:50:35 --> Total execution time: 0.0192
ERROR - 2024-02-06 15:50:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:50:36 --> Config Class Initialized
INFO - 2024-02-06 15:50:36 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:50:36 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:50:36 --> Utf8 Class Initialized
INFO - 2024-02-06 15:50:36 --> URI Class Initialized
DEBUG - 2024-02-06 15:50:36 --> No URI present. Default controller set.
INFO - 2024-02-06 15:50:36 --> Router Class Initialized
INFO - 2024-02-06 15:50:36 --> Output Class Initialized
INFO - 2024-02-06 15:50:36 --> Security Class Initialized
DEBUG - 2024-02-06 15:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:50:36 --> Input Class Initialized
INFO - 2024-02-06 15:50:36 --> Language Class Initialized
INFO - 2024-02-06 15:50:36 --> Loader Class Initialized
INFO - 2024-02-06 15:50:36 --> Helper loaded: url_helper
INFO - 2024-02-06 15:50:36 --> Helper loaded: file_helper
INFO - 2024-02-06 15:50:36 --> Helper loaded: html_helper
INFO - 2024-02-06 15:50:36 --> Helper loaded: text_helper
INFO - 2024-02-06 15:50:36 --> Helper loaded: form_helper
INFO - 2024-02-06 15:50:36 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:50:36 --> Helper loaded: security_helper
INFO - 2024-02-06 15:50:36 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:50:36 --> Database Driver Class Initialized
INFO - 2024-02-06 15:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:50:36 --> Parser Class Initialized
INFO - 2024-02-06 15:50:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:50:36 --> Pagination Class Initialized
INFO - 2024-02-06 15:50:36 --> Form Validation Class Initialized
INFO - 2024-02-06 15:50:36 --> Controller Class Initialized
INFO - 2024-02-06 15:50:36 --> Model Class Initialized
DEBUG - 2024-02-06 15:50:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:50:36 --> Model Class Initialized
DEBUG - 2024-02-06 15:50:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:50:36 --> Model Class Initialized
INFO - 2024-02-06 15:50:36 --> Model Class Initialized
INFO - 2024-02-06 15:50:36 --> Model Class Initialized
INFO - 2024-02-06 15:50:36 --> Model Class Initialized
DEBUG - 2024-02-06 15:50:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:50:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:50:36 --> Model Class Initialized
INFO - 2024-02-06 15:50:36 --> Model Class Initialized
INFO - 2024-02-06 15:50:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 15:50:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:50:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:50:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:50:36 --> Model Class Initialized
INFO - 2024-02-06 15:50:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:50:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:50:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:50:36 --> Final output sent to browser
DEBUG - 2024-02-06 15:50:36 --> Total execution time: 0.2206
ERROR - 2024-02-06 15:50:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:50:56 --> Config Class Initialized
INFO - 2024-02-06 15:50:56 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:50:56 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:50:56 --> Utf8 Class Initialized
INFO - 2024-02-06 15:50:56 --> URI Class Initialized
INFO - 2024-02-06 15:50:56 --> Router Class Initialized
INFO - 2024-02-06 15:50:56 --> Output Class Initialized
INFO - 2024-02-06 15:50:56 --> Security Class Initialized
DEBUG - 2024-02-06 15:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:50:56 --> Input Class Initialized
INFO - 2024-02-06 15:50:56 --> Language Class Initialized
INFO - 2024-02-06 15:50:56 --> Loader Class Initialized
INFO - 2024-02-06 15:50:56 --> Helper loaded: url_helper
INFO - 2024-02-06 15:50:56 --> Helper loaded: file_helper
INFO - 2024-02-06 15:50:56 --> Helper loaded: html_helper
INFO - 2024-02-06 15:50:56 --> Helper loaded: text_helper
INFO - 2024-02-06 15:50:56 --> Helper loaded: form_helper
INFO - 2024-02-06 15:50:56 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:50:56 --> Helper loaded: security_helper
INFO - 2024-02-06 15:50:56 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:50:56 --> Database Driver Class Initialized
INFO - 2024-02-06 15:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:50:56 --> Parser Class Initialized
INFO - 2024-02-06 15:50:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:50:56 --> Pagination Class Initialized
INFO - 2024-02-06 15:50:56 --> Form Validation Class Initialized
INFO - 2024-02-06 15:50:56 --> Controller Class Initialized
DEBUG - 2024-02-06 15:50:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:50:56 --> Model Class Initialized
DEBUG - 2024-02-06 15:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:50:56 --> Model Class Initialized
DEBUG - 2024-02-06 15:50:56 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:50:56 --> Model Class Initialized
INFO - 2024-02-06 15:50:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-06 15:50:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:50:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:50:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:50:56 --> Model Class Initialized
INFO - 2024-02-06 15:50:56 --> Model Class Initialized
INFO - 2024-02-06 15:50:56 --> Model Class Initialized
INFO - 2024-02-06 15:50:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:50:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:50:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:50:56 --> Final output sent to browser
DEBUG - 2024-02-06 15:50:56 --> Total execution time: 0.1451
ERROR - 2024-02-06 15:50:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:50:58 --> Config Class Initialized
INFO - 2024-02-06 15:50:58 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:50:58 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:50:58 --> Utf8 Class Initialized
INFO - 2024-02-06 15:50:58 --> URI Class Initialized
INFO - 2024-02-06 15:50:58 --> Router Class Initialized
INFO - 2024-02-06 15:50:58 --> Output Class Initialized
INFO - 2024-02-06 15:50:58 --> Security Class Initialized
DEBUG - 2024-02-06 15:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:50:58 --> Input Class Initialized
INFO - 2024-02-06 15:50:58 --> Language Class Initialized
INFO - 2024-02-06 15:50:58 --> Loader Class Initialized
INFO - 2024-02-06 15:50:58 --> Helper loaded: url_helper
INFO - 2024-02-06 15:50:58 --> Helper loaded: file_helper
INFO - 2024-02-06 15:50:58 --> Helper loaded: html_helper
INFO - 2024-02-06 15:50:58 --> Helper loaded: text_helper
INFO - 2024-02-06 15:50:58 --> Helper loaded: form_helper
INFO - 2024-02-06 15:50:58 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:50:58 --> Helper loaded: security_helper
INFO - 2024-02-06 15:50:58 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:50:58 --> Database Driver Class Initialized
INFO - 2024-02-06 15:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:50:58 --> Parser Class Initialized
INFO - 2024-02-06 15:50:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:50:58 --> Pagination Class Initialized
INFO - 2024-02-06 15:50:58 --> Form Validation Class Initialized
INFO - 2024-02-06 15:50:58 --> Controller Class Initialized
DEBUG - 2024-02-06 15:50:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:50:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:50:58 --> Model Class Initialized
DEBUG - 2024-02-06 15:50:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:50:58 --> Model Class Initialized
INFO - 2024-02-06 15:50:58 --> Final output sent to browser
DEBUG - 2024-02-06 15:50:58 --> Total execution time: 0.0274
ERROR - 2024-02-06 15:51:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:51:01 --> Config Class Initialized
INFO - 2024-02-06 15:51:01 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:51:01 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:51:01 --> Utf8 Class Initialized
INFO - 2024-02-06 15:51:01 --> URI Class Initialized
INFO - 2024-02-06 15:51:01 --> Router Class Initialized
INFO - 2024-02-06 15:51:01 --> Output Class Initialized
INFO - 2024-02-06 15:51:01 --> Security Class Initialized
DEBUG - 2024-02-06 15:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:51:01 --> Input Class Initialized
INFO - 2024-02-06 15:51:01 --> Language Class Initialized
INFO - 2024-02-06 15:51:01 --> Loader Class Initialized
INFO - 2024-02-06 15:51:01 --> Helper loaded: url_helper
INFO - 2024-02-06 15:51:01 --> Helper loaded: file_helper
INFO - 2024-02-06 15:51:01 --> Helper loaded: html_helper
INFO - 2024-02-06 15:51:01 --> Helper loaded: text_helper
INFO - 2024-02-06 15:51:01 --> Helper loaded: form_helper
INFO - 2024-02-06 15:51:01 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:51:01 --> Helper loaded: security_helper
INFO - 2024-02-06 15:51:01 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:51:01 --> Database Driver Class Initialized
INFO - 2024-02-06 15:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:51:01 --> Parser Class Initialized
INFO - 2024-02-06 15:51:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:51:01 --> Pagination Class Initialized
INFO - 2024-02-06 15:51:01 --> Form Validation Class Initialized
INFO - 2024-02-06 15:51:01 --> Controller Class Initialized
DEBUG - 2024-02-06 15:51:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:01 --> Model Class Initialized
DEBUG - 2024-02-06 15:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:01 --> Model Class Initialized
INFO - 2024-02-06 15:51:01 --> Final output sent to browser
DEBUG - 2024-02-06 15:51:01 --> Total execution time: 0.0267
ERROR - 2024-02-06 15:51:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:51:08 --> Config Class Initialized
INFO - 2024-02-06 15:51:08 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:51:08 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:51:08 --> Utf8 Class Initialized
INFO - 2024-02-06 15:51:08 --> URI Class Initialized
INFO - 2024-02-06 15:51:08 --> Router Class Initialized
INFO - 2024-02-06 15:51:08 --> Output Class Initialized
INFO - 2024-02-06 15:51:08 --> Security Class Initialized
DEBUG - 2024-02-06 15:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:51:08 --> Input Class Initialized
INFO - 2024-02-06 15:51:08 --> Language Class Initialized
INFO - 2024-02-06 15:51:08 --> Loader Class Initialized
INFO - 2024-02-06 15:51:08 --> Helper loaded: url_helper
INFO - 2024-02-06 15:51:08 --> Helper loaded: file_helper
INFO - 2024-02-06 15:51:08 --> Helper loaded: html_helper
INFO - 2024-02-06 15:51:08 --> Helper loaded: text_helper
INFO - 2024-02-06 15:51:08 --> Helper loaded: form_helper
INFO - 2024-02-06 15:51:08 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:51:08 --> Helper loaded: security_helper
INFO - 2024-02-06 15:51:08 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:51:08 --> Database Driver Class Initialized
INFO - 2024-02-06 15:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:51:08 --> Parser Class Initialized
INFO - 2024-02-06 15:51:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:51:08 --> Pagination Class Initialized
INFO - 2024-02-06 15:51:08 --> Form Validation Class Initialized
INFO - 2024-02-06 15:51:08 --> Controller Class Initialized
INFO - 2024-02-06 15:51:08 --> Model Class Initialized
DEBUG - 2024-02-06 15:51:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:08 --> Model Class Initialized
DEBUG - 2024-02-06 15:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:08 --> Model Class Initialized
INFO - 2024-02-06 15:51:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-06 15:51:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:51:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:51:08 --> Model Class Initialized
INFO - 2024-02-06 15:51:08 --> Model Class Initialized
INFO - 2024-02-06 15:51:08 --> Model Class Initialized
INFO - 2024-02-06 15:51:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:51:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:51:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:51:08 --> Final output sent to browser
DEBUG - 2024-02-06 15:51:08 --> Total execution time: 0.1519
ERROR - 2024-02-06 15:51:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:51:09 --> Config Class Initialized
INFO - 2024-02-06 15:51:09 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:51:09 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:51:09 --> Utf8 Class Initialized
INFO - 2024-02-06 15:51:09 --> URI Class Initialized
INFO - 2024-02-06 15:51:09 --> Router Class Initialized
INFO - 2024-02-06 15:51:09 --> Output Class Initialized
INFO - 2024-02-06 15:51:09 --> Security Class Initialized
DEBUG - 2024-02-06 15:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:51:09 --> Input Class Initialized
INFO - 2024-02-06 15:51:09 --> Language Class Initialized
INFO - 2024-02-06 15:51:09 --> Loader Class Initialized
INFO - 2024-02-06 15:51:09 --> Helper loaded: url_helper
INFO - 2024-02-06 15:51:09 --> Helper loaded: file_helper
INFO - 2024-02-06 15:51:09 --> Helper loaded: html_helper
INFO - 2024-02-06 15:51:09 --> Helper loaded: text_helper
INFO - 2024-02-06 15:51:09 --> Helper loaded: form_helper
INFO - 2024-02-06 15:51:09 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:51:09 --> Helper loaded: security_helper
INFO - 2024-02-06 15:51:09 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:51:09 --> Database Driver Class Initialized
INFO - 2024-02-06 15:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:51:09 --> Parser Class Initialized
INFO - 2024-02-06 15:51:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:51:09 --> Pagination Class Initialized
INFO - 2024-02-06 15:51:09 --> Form Validation Class Initialized
INFO - 2024-02-06 15:51:09 --> Controller Class Initialized
INFO - 2024-02-06 15:51:09 --> Model Class Initialized
DEBUG - 2024-02-06 15:51:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:51:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:09 --> Model Class Initialized
DEBUG - 2024-02-06 15:51:09 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:09 --> Model Class Initialized
INFO - 2024-02-06 15:51:09 --> Final output sent to browser
DEBUG - 2024-02-06 15:51:09 --> Total execution time: 0.0457
ERROR - 2024-02-06 15:51:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:51:15 --> Config Class Initialized
INFO - 2024-02-06 15:51:15 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:51:15 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:51:15 --> Utf8 Class Initialized
INFO - 2024-02-06 15:51:15 --> URI Class Initialized
INFO - 2024-02-06 15:51:15 --> Router Class Initialized
INFO - 2024-02-06 15:51:15 --> Output Class Initialized
INFO - 2024-02-06 15:51:15 --> Security Class Initialized
DEBUG - 2024-02-06 15:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:51:15 --> Input Class Initialized
INFO - 2024-02-06 15:51:15 --> Language Class Initialized
INFO - 2024-02-06 15:51:15 --> Loader Class Initialized
INFO - 2024-02-06 15:51:15 --> Helper loaded: url_helper
INFO - 2024-02-06 15:51:15 --> Helper loaded: file_helper
INFO - 2024-02-06 15:51:15 --> Helper loaded: html_helper
INFO - 2024-02-06 15:51:15 --> Helper loaded: text_helper
INFO - 2024-02-06 15:51:15 --> Helper loaded: form_helper
INFO - 2024-02-06 15:51:15 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:51:15 --> Helper loaded: security_helper
INFO - 2024-02-06 15:51:15 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:51:15 --> Database Driver Class Initialized
INFO - 2024-02-06 15:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:51:15 --> Parser Class Initialized
INFO - 2024-02-06 15:51:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:51:15 --> Pagination Class Initialized
INFO - 2024-02-06 15:51:15 --> Form Validation Class Initialized
INFO - 2024-02-06 15:51:15 --> Controller Class Initialized
INFO - 2024-02-06 15:51:15 --> Model Class Initialized
DEBUG - 2024-02-06 15:51:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:51:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:15 --> Model Class Initialized
DEBUG - 2024-02-06 15:51:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:15 --> Model Class Initialized
DEBUG - 2024-02-06 15:51:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-02-06 15:51:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:51:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:51:15 --> Model Class Initialized
INFO - 2024-02-06 15:51:15 --> Model Class Initialized
INFO - 2024-02-06 15:51:15 --> Model Class Initialized
INFO - 2024-02-06 15:51:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:51:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:51:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:51:15 --> Final output sent to browser
DEBUG - 2024-02-06 15:51:15 --> Total execution time: 0.1631
ERROR - 2024-02-06 15:51:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:51:20 --> Config Class Initialized
INFO - 2024-02-06 15:51:20 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:51:20 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:51:20 --> Utf8 Class Initialized
INFO - 2024-02-06 15:51:20 --> URI Class Initialized
INFO - 2024-02-06 15:51:20 --> Router Class Initialized
INFO - 2024-02-06 15:51:20 --> Output Class Initialized
INFO - 2024-02-06 15:51:20 --> Security Class Initialized
DEBUG - 2024-02-06 15:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:51:20 --> Input Class Initialized
INFO - 2024-02-06 15:51:20 --> Language Class Initialized
INFO - 2024-02-06 15:51:20 --> Loader Class Initialized
INFO - 2024-02-06 15:51:20 --> Helper loaded: url_helper
INFO - 2024-02-06 15:51:20 --> Helper loaded: file_helper
INFO - 2024-02-06 15:51:20 --> Helper loaded: html_helper
INFO - 2024-02-06 15:51:20 --> Helper loaded: text_helper
INFO - 2024-02-06 15:51:20 --> Helper loaded: form_helper
INFO - 2024-02-06 15:51:20 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:51:20 --> Helper loaded: security_helper
INFO - 2024-02-06 15:51:20 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:51:20 --> Database Driver Class Initialized
INFO - 2024-02-06 15:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:51:20 --> Parser Class Initialized
INFO - 2024-02-06 15:51:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:51:20 --> Pagination Class Initialized
INFO - 2024-02-06 15:51:20 --> Form Validation Class Initialized
INFO - 2024-02-06 15:51:20 --> Controller Class Initialized
INFO - 2024-02-06 15:51:20 --> Model Class Initialized
DEBUG - 2024-02-06 15:51:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:51:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:20 --> Model Class Initialized
DEBUG - 2024-02-06 15:51:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:20 --> Model Class Initialized
INFO - 2024-02-06 15:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-06 15:51:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:51:20 --> Model Class Initialized
INFO - 2024-02-06 15:51:20 --> Model Class Initialized
INFO - 2024-02-06 15:51:20 --> Model Class Initialized
INFO - 2024-02-06 15:51:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:51:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:51:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:51:21 --> Final output sent to browser
DEBUG - 2024-02-06 15:51:21 --> Total execution time: 0.1438
ERROR - 2024-02-06 15:51:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:51:21 --> Config Class Initialized
INFO - 2024-02-06 15:51:21 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:51:21 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:51:21 --> Utf8 Class Initialized
INFO - 2024-02-06 15:51:21 --> URI Class Initialized
INFO - 2024-02-06 15:51:21 --> Router Class Initialized
INFO - 2024-02-06 15:51:21 --> Output Class Initialized
INFO - 2024-02-06 15:51:21 --> Security Class Initialized
DEBUG - 2024-02-06 15:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:51:21 --> Input Class Initialized
INFO - 2024-02-06 15:51:21 --> Language Class Initialized
INFO - 2024-02-06 15:51:21 --> Loader Class Initialized
INFO - 2024-02-06 15:51:21 --> Helper loaded: url_helper
INFO - 2024-02-06 15:51:21 --> Helper loaded: file_helper
INFO - 2024-02-06 15:51:21 --> Helper loaded: html_helper
INFO - 2024-02-06 15:51:21 --> Helper loaded: text_helper
INFO - 2024-02-06 15:51:21 --> Helper loaded: form_helper
INFO - 2024-02-06 15:51:21 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:51:21 --> Helper loaded: security_helper
INFO - 2024-02-06 15:51:21 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:51:21 --> Database Driver Class Initialized
INFO - 2024-02-06 15:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:51:21 --> Parser Class Initialized
INFO - 2024-02-06 15:51:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:51:21 --> Pagination Class Initialized
INFO - 2024-02-06 15:51:21 --> Form Validation Class Initialized
INFO - 2024-02-06 15:51:21 --> Controller Class Initialized
INFO - 2024-02-06 15:51:21 --> Model Class Initialized
DEBUG - 2024-02-06 15:51:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:51:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:21 --> Model Class Initialized
DEBUG - 2024-02-06 15:51:21 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:21 --> Model Class Initialized
INFO - 2024-02-06 15:51:21 --> Final output sent to browser
DEBUG - 2024-02-06 15:51:21 --> Total execution time: 0.0398
ERROR - 2024-02-06 15:51:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:51:27 --> Config Class Initialized
INFO - 2024-02-06 15:51:27 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:51:27 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:51:27 --> Utf8 Class Initialized
INFO - 2024-02-06 15:51:27 --> URI Class Initialized
INFO - 2024-02-06 15:51:27 --> Router Class Initialized
INFO - 2024-02-06 15:51:27 --> Output Class Initialized
INFO - 2024-02-06 15:51:27 --> Security Class Initialized
DEBUG - 2024-02-06 15:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:51:27 --> Input Class Initialized
INFO - 2024-02-06 15:51:27 --> Language Class Initialized
INFO - 2024-02-06 15:51:27 --> Loader Class Initialized
INFO - 2024-02-06 15:51:27 --> Helper loaded: url_helper
INFO - 2024-02-06 15:51:27 --> Helper loaded: file_helper
INFO - 2024-02-06 15:51:27 --> Helper loaded: html_helper
INFO - 2024-02-06 15:51:27 --> Helper loaded: text_helper
INFO - 2024-02-06 15:51:27 --> Helper loaded: form_helper
INFO - 2024-02-06 15:51:27 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:51:27 --> Helper loaded: security_helper
INFO - 2024-02-06 15:51:27 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:51:27 --> Database Driver Class Initialized
INFO - 2024-02-06 15:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:51:27 --> Parser Class Initialized
INFO - 2024-02-06 15:51:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:51:27 --> Pagination Class Initialized
INFO - 2024-02-06 15:51:27 --> Form Validation Class Initialized
INFO - 2024-02-06 15:51:27 --> Controller Class Initialized
INFO - 2024-02-06 15:51:27 --> Model Class Initialized
DEBUG - 2024-02-06 15:51:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:51:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:27 --> Model Class Initialized
DEBUG - 2024-02-06 15:51:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:27 --> Model Class Initialized
DEBUG - 2024-02-06 15:51:27 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-02-06 15:51:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:51:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:51:27 --> Model Class Initialized
INFO - 2024-02-06 15:51:27 --> Model Class Initialized
INFO - 2024-02-06 15:51:27 --> Model Class Initialized
INFO - 2024-02-06 15:51:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:51:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:51:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:51:27 --> Final output sent to browser
DEBUG - 2024-02-06 15:51:27 --> Total execution time: 0.1529
ERROR - 2024-02-06 15:51:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:51:34 --> Config Class Initialized
INFO - 2024-02-06 15:51:34 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:51:34 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:51:34 --> Utf8 Class Initialized
INFO - 2024-02-06 15:51:34 --> URI Class Initialized
INFO - 2024-02-06 15:51:34 --> Router Class Initialized
INFO - 2024-02-06 15:51:34 --> Output Class Initialized
INFO - 2024-02-06 15:51:34 --> Security Class Initialized
DEBUG - 2024-02-06 15:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:51:34 --> Input Class Initialized
INFO - 2024-02-06 15:51:34 --> Language Class Initialized
INFO - 2024-02-06 15:51:34 --> Loader Class Initialized
INFO - 2024-02-06 15:51:34 --> Helper loaded: url_helper
INFO - 2024-02-06 15:51:34 --> Helper loaded: file_helper
INFO - 2024-02-06 15:51:34 --> Helper loaded: html_helper
INFO - 2024-02-06 15:51:34 --> Helper loaded: text_helper
INFO - 2024-02-06 15:51:34 --> Helper loaded: form_helper
INFO - 2024-02-06 15:51:34 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:51:34 --> Helper loaded: security_helper
INFO - 2024-02-06 15:51:34 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:51:34 --> Database Driver Class Initialized
INFO - 2024-02-06 15:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:51:34 --> Parser Class Initialized
INFO - 2024-02-06 15:51:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:51:34 --> Pagination Class Initialized
INFO - 2024-02-06 15:51:34 --> Form Validation Class Initialized
INFO - 2024-02-06 15:51:34 --> Controller Class Initialized
INFO - 2024-02-06 15:51:34 --> Model Class Initialized
DEBUG - 2024-02-06 15:51:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:51:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:34 --> Model Class Initialized
DEBUG - 2024-02-06 15:51:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:34 --> Model Class Initialized
INFO - 2024-02-06 15:51:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-06 15:51:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:51:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:51:34 --> Model Class Initialized
INFO - 2024-02-06 15:51:34 --> Model Class Initialized
INFO - 2024-02-06 15:51:34 --> Model Class Initialized
INFO - 2024-02-06 15:51:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:51:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:51:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:51:34 --> Final output sent to browser
DEBUG - 2024-02-06 15:51:34 --> Total execution time: 0.1424
ERROR - 2024-02-06 15:51:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:51:35 --> Config Class Initialized
INFO - 2024-02-06 15:51:35 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:51:35 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:51:35 --> Utf8 Class Initialized
INFO - 2024-02-06 15:51:35 --> URI Class Initialized
INFO - 2024-02-06 15:51:35 --> Router Class Initialized
INFO - 2024-02-06 15:51:35 --> Output Class Initialized
INFO - 2024-02-06 15:51:35 --> Security Class Initialized
DEBUG - 2024-02-06 15:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:51:35 --> Input Class Initialized
INFO - 2024-02-06 15:51:35 --> Language Class Initialized
INFO - 2024-02-06 15:51:35 --> Loader Class Initialized
INFO - 2024-02-06 15:51:35 --> Helper loaded: url_helper
INFO - 2024-02-06 15:51:35 --> Helper loaded: file_helper
INFO - 2024-02-06 15:51:35 --> Helper loaded: html_helper
INFO - 2024-02-06 15:51:35 --> Helper loaded: text_helper
INFO - 2024-02-06 15:51:35 --> Helper loaded: form_helper
INFO - 2024-02-06 15:51:35 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:51:35 --> Helper loaded: security_helper
INFO - 2024-02-06 15:51:35 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:51:35 --> Database Driver Class Initialized
INFO - 2024-02-06 15:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:51:35 --> Parser Class Initialized
INFO - 2024-02-06 15:51:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:51:35 --> Pagination Class Initialized
INFO - 2024-02-06 15:51:35 --> Form Validation Class Initialized
INFO - 2024-02-06 15:51:35 --> Controller Class Initialized
INFO - 2024-02-06 15:51:35 --> Model Class Initialized
DEBUG - 2024-02-06 15:51:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:51:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:35 --> Model Class Initialized
DEBUG - 2024-02-06 15:51:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:35 --> Model Class Initialized
INFO - 2024-02-06 15:51:35 --> Final output sent to browser
DEBUG - 2024-02-06 15:51:35 --> Total execution time: 0.0383
ERROR - 2024-02-06 15:51:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:51:44 --> Config Class Initialized
INFO - 2024-02-06 15:51:44 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:51:44 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:51:44 --> Utf8 Class Initialized
INFO - 2024-02-06 15:51:44 --> URI Class Initialized
INFO - 2024-02-06 15:51:44 --> Router Class Initialized
INFO - 2024-02-06 15:51:44 --> Output Class Initialized
INFO - 2024-02-06 15:51:44 --> Security Class Initialized
DEBUG - 2024-02-06 15:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:51:44 --> Input Class Initialized
INFO - 2024-02-06 15:51:44 --> Language Class Initialized
INFO - 2024-02-06 15:51:44 --> Loader Class Initialized
INFO - 2024-02-06 15:51:44 --> Helper loaded: url_helper
INFO - 2024-02-06 15:51:44 --> Helper loaded: file_helper
INFO - 2024-02-06 15:51:44 --> Helper loaded: html_helper
INFO - 2024-02-06 15:51:44 --> Helper loaded: text_helper
INFO - 2024-02-06 15:51:44 --> Helper loaded: form_helper
INFO - 2024-02-06 15:51:44 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:51:44 --> Helper loaded: security_helper
INFO - 2024-02-06 15:51:44 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:51:44 --> Database Driver Class Initialized
INFO - 2024-02-06 15:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:51:44 --> Parser Class Initialized
INFO - 2024-02-06 15:51:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:51:44 --> Pagination Class Initialized
INFO - 2024-02-06 15:51:44 --> Form Validation Class Initialized
INFO - 2024-02-06 15:51:44 --> Controller Class Initialized
INFO - 2024-02-06 15:51:44 --> Model Class Initialized
DEBUG - 2024-02-06 15:51:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:51:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:44 --> Model Class Initialized
DEBUG - 2024-02-06 15:51:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:44 --> Model Class Initialized
DEBUG - 2024-02-06 15:51:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-02-06 15:51:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:51:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:51:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:51:44 --> Model Class Initialized
INFO - 2024-02-06 15:51:44 --> Model Class Initialized
INFO - 2024-02-06 15:51:44 --> Model Class Initialized
INFO - 2024-02-06 15:51:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:51:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:51:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:51:44 --> Final output sent to browser
DEBUG - 2024-02-06 15:51:44 --> Total execution time: 0.1504
ERROR - 2024-02-06 15:52:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:52:15 --> Config Class Initialized
INFO - 2024-02-06 15:52:15 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:52:15 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:52:15 --> Utf8 Class Initialized
INFO - 2024-02-06 15:52:15 --> URI Class Initialized
INFO - 2024-02-06 15:52:15 --> Router Class Initialized
INFO - 2024-02-06 15:52:15 --> Output Class Initialized
INFO - 2024-02-06 15:52:15 --> Security Class Initialized
DEBUG - 2024-02-06 15:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:52:15 --> Input Class Initialized
INFO - 2024-02-06 15:52:15 --> Language Class Initialized
INFO - 2024-02-06 15:52:15 --> Loader Class Initialized
INFO - 2024-02-06 15:52:15 --> Helper loaded: url_helper
INFO - 2024-02-06 15:52:15 --> Helper loaded: file_helper
INFO - 2024-02-06 15:52:15 --> Helper loaded: html_helper
INFO - 2024-02-06 15:52:15 --> Helper loaded: text_helper
INFO - 2024-02-06 15:52:15 --> Helper loaded: form_helper
INFO - 2024-02-06 15:52:15 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:52:15 --> Helper loaded: security_helper
INFO - 2024-02-06 15:52:15 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:52:15 --> Database Driver Class Initialized
INFO - 2024-02-06 15:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:52:15 --> Parser Class Initialized
INFO - 2024-02-06 15:52:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:52:15 --> Pagination Class Initialized
INFO - 2024-02-06 15:52:15 --> Form Validation Class Initialized
INFO - 2024-02-06 15:52:15 --> Controller Class Initialized
INFO - 2024-02-06 15:52:15 --> Model Class Initialized
DEBUG - 2024-02-06 15:52:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:52:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:52:15 --> Model Class Initialized
DEBUG - 2024-02-06 15:52:15 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:52:15 --> Model Class Initialized
INFO - 2024-02-06 15:52:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-06 15:52:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:52:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:52:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:52:15 --> Model Class Initialized
INFO - 2024-02-06 15:52:15 --> Model Class Initialized
INFO - 2024-02-06 15:52:15 --> Model Class Initialized
INFO - 2024-02-06 15:52:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:52:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:52:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:52:15 --> Final output sent to browser
DEBUG - 2024-02-06 15:52:15 --> Total execution time: 0.1552
ERROR - 2024-02-06 15:52:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:52:16 --> Config Class Initialized
INFO - 2024-02-06 15:52:16 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:52:16 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:52:16 --> Utf8 Class Initialized
INFO - 2024-02-06 15:52:16 --> URI Class Initialized
INFO - 2024-02-06 15:52:16 --> Router Class Initialized
INFO - 2024-02-06 15:52:16 --> Output Class Initialized
INFO - 2024-02-06 15:52:16 --> Security Class Initialized
DEBUG - 2024-02-06 15:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:52:16 --> Input Class Initialized
INFO - 2024-02-06 15:52:16 --> Language Class Initialized
INFO - 2024-02-06 15:52:16 --> Loader Class Initialized
INFO - 2024-02-06 15:52:16 --> Helper loaded: url_helper
INFO - 2024-02-06 15:52:16 --> Helper loaded: file_helper
INFO - 2024-02-06 15:52:16 --> Helper loaded: html_helper
INFO - 2024-02-06 15:52:16 --> Helper loaded: text_helper
INFO - 2024-02-06 15:52:16 --> Helper loaded: form_helper
INFO - 2024-02-06 15:52:16 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:52:16 --> Helper loaded: security_helper
INFO - 2024-02-06 15:52:16 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:52:16 --> Database Driver Class Initialized
INFO - 2024-02-06 15:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:52:16 --> Parser Class Initialized
INFO - 2024-02-06 15:52:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:52:16 --> Pagination Class Initialized
INFO - 2024-02-06 15:52:16 --> Form Validation Class Initialized
INFO - 2024-02-06 15:52:16 --> Controller Class Initialized
INFO - 2024-02-06 15:52:16 --> Model Class Initialized
DEBUG - 2024-02-06 15:52:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:52:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:52:16 --> Model Class Initialized
DEBUG - 2024-02-06 15:52:16 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:52:16 --> Model Class Initialized
INFO - 2024-02-06 15:52:16 --> Final output sent to browser
DEBUG - 2024-02-06 15:52:16 --> Total execution time: 0.0388
ERROR - 2024-02-06 15:52:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:52:28 --> Config Class Initialized
INFO - 2024-02-06 15:52:28 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:52:28 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:52:28 --> Utf8 Class Initialized
INFO - 2024-02-06 15:52:28 --> URI Class Initialized
DEBUG - 2024-02-06 15:52:28 --> No URI present. Default controller set.
INFO - 2024-02-06 15:52:28 --> Router Class Initialized
INFO - 2024-02-06 15:52:28 --> Output Class Initialized
INFO - 2024-02-06 15:52:28 --> Security Class Initialized
DEBUG - 2024-02-06 15:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:52:28 --> Input Class Initialized
INFO - 2024-02-06 15:52:28 --> Language Class Initialized
INFO - 2024-02-06 15:52:28 --> Loader Class Initialized
INFO - 2024-02-06 15:52:28 --> Helper loaded: url_helper
INFO - 2024-02-06 15:52:28 --> Helper loaded: file_helper
INFO - 2024-02-06 15:52:28 --> Helper loaded: html_helper
INFO - 2024-02-06 15:52:28 --> Helper loaded: text_helper
INFO - 2024-02-06 15:52:28 --> Helper loaded: form_helper
INFO - 2024-02-06 15:52:28 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:52:28 --> Helper loaded: security_helper
INFO - 2024-02-06 15:52:28 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:52:28 --> Database Driver Class Initialized
INFO - 2024-02-06 15:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:52:28 --> Parser Class Initialized
INFO - 2024-02-06 15:52:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:52:28 --> Pagination Class Initialized
INFO - 2024-02-06 15:52:28 --> Form Validation Class Initialized
INFO - 2024-02-06 15:52:28 --> Controller Class Initialized
INFO - 2024-02-06 15:52:28 --> Model Class Initialized
DEBUG - 2024-02-06 15:52:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:52:28 --> Model Class Initialized
DEBUG - 2024-02-06 15:52:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:52:28 --> Model Class Initialized
INFO - 2024-02-06 15:52:28 --> Model Class Initialized
INFO - 2024-02-06 15:52:28 --> Model Class Initialized
INFO - 2024-02-06 15:52:28 --> Model Class Initialized
DEBUG - 2024-02-06 15:52:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:52:28 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:52:28 --> Model Class Initialized
INFO - 2024-02-06 15:52:28 --> Model Class Initialized
INFO - 2024-02-06 15:52:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 15:52:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:52:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:52:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:52:28 --> Model Class Initialized
INFO - 2024-02-06 15:52:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:52:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:52:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:52:28 --> Final output sent to browser
DEBUG - 2024-02-06 15:52:28 --> Total execution time: 0.2397
ERROR - 2024-02-06 15:52:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:52:34 --> Config Class Initialized
INFO - 2024-02-06 15:52:34 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:52:34 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:52:34 --> Utf8 Class Initialized
INFO - 2024-02-06 15:52:34 --> URI Class Initialized
INFO - 2024-02-06 15:52:34 --> Router Class Initialized
INFO - 2024-02-06 15:52:34 --> Output Class Initialized
INFO - 2024-02-06 15:52:34 --> Security Class Initialized
DEBUG - 2024-02-06 15:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:52:34 --> Input Class Initialized
INFO - 2024-02-06 15:52:34 --> Language Class Initialized
INFO - 2024-02-06 15:52:34 --> Loader Class Initialized
INFO - 2024-02-06 15:52:34 --> Helper loaded: url_helper
INFO - 2024-02-06 15:52:34 --> Helper loaded: file_helper
INFO - 2024-02-06 15:52:34 --> Helper loaded: html_helper
INFO - 2024-02-06 15:52:34 --> Helper loaded: text_helper
INFO - 2024-02-06 15:52:34 --> Helper loaded: form_helper
INFO - 2024-02-06 15:52:34 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:52:34 --> Helper loaded: security_helper
INFO - 2024-02-06 15:52:34 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:52:34 --> Database Driver Class Initialized
INFO - 2024-02-06 15:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:52:34 --> Parser Class Initialized
INFO - 2024-02-06 15:52:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:52:34 --> Pagination Class Initialized
INFO - 2024-02-06 15:52:34 --> Form Validation Class Initialized
INFO - 2024-02-06 15:52:34 --> Controller Class Initialized
INFO - 2024-02-06 15:52:34 --> Model Class Initialized
DEBUG - 2024-02-06 15:52:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:52:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:52:34 --> Model Class Initialized
DEBUG - 2024-02-06 15:52:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:52:34 --> Model Class Initialized
INFO - 2024-02-06 15:52:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-06 15:52:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:52:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:52:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:52:34 --> Model Class Initialized
INFO - 2024-02-06 15:52:34 --> Model Class Initialized
INFO - 2024-02-06 15:52:34 --> Model Class Initialized
INFO - 2024-02-06 15:52:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:52:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:52:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:52:34 --> Final output sent to browser
DEBUG - 2024-02-06 15:52:34 --> Total execution time: 0.1550
ERROR - 2024-02-06 15:52:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:52:35 --> Config Class Initialized
INFO - 2024-02-06 15:52:35 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:52:35 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:52:35 --> Utf8 Class Initialized
INFO - 2024-02-06 15:52:35 --> URI Class Initialized
INFO - 2024-02-06 15:52:35 --> Router Class Initialized
INFO - 2024-02-06 15:52:35 --> Output Class Initialized
INFO - 2024-02-06 15:52:35 --> Security Class Initialized
DEBUG - 2024-02-06 15:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:52:35 --> Input Class Initialized
INFO - 2024-02-06 15:52:35 --> Language Class Initialized
INFO - 2024-02-06 15:52:35 --> Loader Class Initialized
INFO - 2024-02-06 15:52:35 --> Helper loaded: url_helper
INFO - 2024-02-06 15:52:35 --> Helper loaded: file_helper
INFO - 2024-02-06 15:52:35 --> Helper loaded: html_helper
INFO - 2024-02-06 15:52:35 --> Helper loaded: text_helper
INFO - 2024-02-06 15:52:35 --> Helper loaded: form_helper
INFO - 2024-02-06 15:52:35 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:52:35 --> Helper loaded: security_helper
INFO - 2024-02-06 15:52:35 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:52:35 --> Database Driver Class Initialized
INFO - 2024-02-06 15:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:52:35 --> Parser Class Initialized
INFO - 2024-02-06 15:52:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:52:35 --> Pagination Class Initialized
INFO - 2024-02-06 15:52:35 --> Form Validation Class Initialized
INFO - 2024-02-06 15:52:35 --> Controller Class Initialized
INFO - 2024-02-06 15:52:35 --> Model Class Initialized
DEBUG - 2024-02-06 15:52:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:52:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:52:35 --> Model Class Initialized
DEBUG - 2024-02-06 15:52:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:52:35 --> Model Class Initialized
INFO - 2024-02-06 15:52:35 --> Final output sent to browser
DEBUG - 2024-02-06 15:52:35 --> Total execution time: 0.0401
ERROR - 2024-02-06 15:52:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:52:37 --> Config Class Initialized
INFO - 2024-02-06 15:52:37 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:52:37 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:52:37 --> Utf8 Class Initialized
INFO - 2024-02-06 15:52:37 --> URI Class Initialized
INFO - 2024-02-06 15:52:37 --> Router Class Initialized
INFO - 2024-02-06 15:52:37 --> Output Class Initialized
INFO - 2024-02-06 15:52:37 --> Security Class Initialized
DEBUG - 2024-02-06 15:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:52:37 --> Input Class Initialized
INFO - 2024-02-06 15:52:37 --> Language Class Initialized
INFO - 2024-02-06 15:52:37 --> Loader Class Initialized
INFO - 2024-02-06 15:52:37 --> Helper loaded: url_helper
INFO - 2024-02-06 15:52:37 --> Helper loaded: file_helper
INFO - 2024-02-06 15:52:37 --> Helper loaded: html_helper
INFO - 2024-02-06 15:52:37 --> Helper loaded: text_helper
INFO - 2024-02-06 15:52:37 --> Helper loaded: form_helper
INFO - 2024-02-06 15:52:37 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:52:37 --> Helper loaded: security_helper
INFO - 2024-02-06 15:52:37 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:52:37 --> Database Driver Class Initialized
INFO - 2024-02-06 15:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:52:37 --> Parser Class Initialized
INFO - 2024-02-06 15:52:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:52:37 --> Pagination Class Initialized
INFO - 2024-02-06 15:52:37 --> Form Validation Class Initialized
INFO - 2024-02-06 15:52:37 --> Controller Class Initialized
INFO - 2024-02-06 15:52:37 --> Model Class Initialized
DEBUG - 2024-02-06 15:52:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:52:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:52:37 --> Model Class Initialized
DEBUG - 2024-02-06 15:52:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:52:37 --> Model Class Initialized
DEBUG - 2024-02-06 15:52:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:52:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2024-02-06 15:52:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:52:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:52:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:52:37 --> Model Class Initialized
INFO - 2024-02-06 15:52:37 --> Model Class Initialized
INFO - 2024-02-06 15:52:37 --> Model Class Initialized
INFO - 2024-02-06 15:52:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:52:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:52:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:52:37 --> Final output sent to browser
DEBUG - 2024-02-06 15:52:37 --> Total execution time: 0.1613
ERROR - 2024-02-06 15:52:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:52:54 --> Config Class Initialized
INFO - 2024-02-06 15:52:54 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:52:54 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:52:54 --> Utf8 Class Initialized
INFO - 2024-02-06 15:52:54 --> URI Class Initialized
INFO - 2024-02-06 15:52:54 --> Router Class Initialized
INFO - 2024-02-06 15:52:54 --> Output Class Initialized
INFO - 2024-02-06 15:52:54 --> Security Class Initialized
DEBUG - 2024-02-06 15:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:52:54 --> Input Class Initialized
INFO - 2024-02-06 15:52:54 --> Language Class Initialized
INFO - 2024-02-06 15:52:54 --> Loader Class Initialized
INFO - 2024-02-06 15:52:54 --> Helper loaded: url_helper
INFO - 2024-02-06 15:52:54 --> Helper loaded: file_helper
INFO - 2024-02-06 15:52:54 --> Helper loaded: html_helper
INFO - 2024-02-06 15:52:54 --> Helper loaded: text_helper
INFO - 2024-02-06 15:52:54 --> Helper loaded: form_helper
INFO - 2024-02-06 15:52:54 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:52:54 --> Helper loaded: security_helper
INFO - 2024-02-06 15:52:54 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:52:54 --> Database Driver Class Initialized
INFO - 2024-02-06 15:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:52:54 --> Parser Class Initialized
INFO - 2024-02-06 15:52:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:52:54 --> Pagination Class Initialized
INFO - 2024-02-06 15:52:54 --> Form Validation Class Initialized
INFO - 2024-02-06 15:52:54 --> Controller Class Initialized
INFO - 2024-02-06 15:52:54 --> Model Class Initialized
DEBUG - 2024-02-06 15:52:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:52:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:52:54 --> Model Class Initialized
INFO - 2024-02-06 15:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2024-02-06 15:52:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:52:54 --> Model Class Initialized
INFO - 2024-02-06 15:52:54 --> Model Class Initialized
INFO - 2024-02-06 15:52:54 --> Model Class Initialized
INFO - 2024-02-06 15:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:52:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:52:54 --> Final output sent to browser
DEBUG - 2024-02-06 15:52:54 --> Total execution time: 0.1388
ERROR - 2024-02-06 15:52:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:52:55 --> Config Class Initialized
INFO - 2024-02-06 15:52:55 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:52:55 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:52:55 --> Utf8 Class Initialized
INFO - 2024-02-06 15:52:55 --> URI Class Initialized
INFO - 2024-02-06 15:52:55 --> Router Class Initialized
INFO - 2024-02-06 15:52:55 --> Output Class Initialized
INFO - 2024-02-06 15:52:55 --> Security Class Initialized
DEBUG - 2024-02-06 15:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:52:55 --> Input Class Initialized
INFO - 2024-02-06 15:52:55 --> Language Class Initialized
INFO - 2024-02-06 15:52:55 --> Loader Class Initialized
INFO - 2024-02-06 15:52:55 --> Helper loaded: url_helper
INFO - 2024-02-06 15:52:55 --> Helper loaded: file_helper
INFO - 2024-02-06 15:52:55 --> Helper loaded: html_helper
INFO - 2024-02-06 15:52:55 --> Helper loaded: text_helper
INFO - 2024-02-06 15:52:55 --> Helper loaded: form_helper
INFO - 2024-02-06 15:52:55 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:52:55 --> Helper loaded: security_helper
INFO - 2024-02-06 15:52:55 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:52:55 --> Database Driver Class Initialized
INFO - 2024-02-06 15:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:52:55 --> Parser Class Initialized
INFO - 2024-02-06 15:52:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:52:55 --> Pagination Class Initialized
INFO - 2024-02-06 15:52:55 --> Form Validation Class Initialized
INFO - 2024-02-06 15:52:55 --> Controller Class Initialized
INFO - 2024-02-06 15:52:55 --> Model Class Initialized
DEBUG - 2024-02-06 15:52:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:52:55 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:52:55 --> Model Class Initialized
INFO - 2024-02-06 15:52:55 --> Final output sent to browser
DEBUG - 2024-02-06 15:52:55 --> Total execution time: 0.0532
ERROR - 2024-02-06 15:53:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:53:04 --> Config Class Initialized
INFO - 2024-02-06 15:53:04 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:53:04 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:53:04 --> Utf8 Class Initialized
INFO - 2024-02-06 15:53:04 --> URI Class Initialized
INFO - 2024-02-06 15:53:04 --> Router Class Initialized
INFO - 2024-02-06 15:53:04 --> Output Class Initialized
INFO - 2024-02-06 15:53:04 --> Security Class Initialized
DEBUG - 2024-02-06 15:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:53:04 --> Input Class Initialized
INFO - 2024-02-06 15:53:04 --> Language Class Initialized
INFO - 2024-02-06 15:53:04 --> Loader Class Initialized
INFO - 2024-02-06 15:53:04 --> Helper loaded: url_helper
INFO - 2024-02-06 15:53:04 --> Helper loaded: file_helper
INFO - 2024-02-06 15:53:04 --> Helper loaded: html_helper
INFO - 2024-02-06 15:53:04 --> Helper loaded: text_helper
INFO - 2024-02-06 15:53:04 --> Helper loaded: form_helper
INFO - 2024-02-06 15:53:04 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:53:04 --> Helper loaded: security_helper
INFO - 2024-02-06 15:53:04 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:53:04 --> Database Driver Class Initialized
INFO - 2024-02-06 15:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:53:04 --> Parser Class Initialized
INFO - 2024-02-06 15:53:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:53:04 --> Pagination Class Initialized
INFO - 2024-02-06 15:53:04 --> Form Validation Class Initialized
INFO - 2024-02-06 15:53:04 --> Controller Class Initialized
INFO - 2024-02-06 15:53:04 --> Model Class Initialized
DEBUG - 2024-02-06 15:53:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:53:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:04 --> Model Class Initialized
INFO - 2024-02-06 15:53:04 --> Final output sent to browser
DEBUG - 2024-02-06 15:53:04 --> Total execution time: 0.0518
ERROR - 2024-02-06 15:53:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:53:10 --> Config Class Initialized
INFO - 2024-02-06 15:53:10 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:53:10 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:53:10 --> Utf8 Class Initialized
INFO - 2024-02-06 15:53:10 --> URI Class Initialized
DEBUG - 2024-02-06 15:53:10 --> No URI present. Default controller set.
INFO - 2024-02-06 15:53:10 --> Router Class Initialized
INFO - 2024-02-06 15:53:10 --> Output Class Initialized
INFO - 2024-02-06 15:53:10 --> Security Class Initialized
DEBUG - 2024-02-06 15:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:53:10 --> Input Class Initialized
INFO - 2024-02-06 15:53:10 --> Language Class Initialized
INFO - 2024-02-06 15:53:10 --> Loader Class Initialized
INFO - 2024-02-06 15:53:10 --> Helper loaded: url_helper
INFO - 2024-02-06 15:53:10 --> Helper loaded: file_helper
INFO - 2024-02-06 15:53:10 --> Helper loaded: html_helper
INFO - 2024-02-06 15:53:10 --> Helper loaded: text_helper
INFO - 2024-02-06 15:53:10 --> Helper loaded: form_helper
INFO - 2024-02-06 15:53:10 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:53:10 --> Helper loaded: security_helper
INFO - 2024-02-06 15:53:10 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:53:10 --> Database Driver Class Initialized
INFO - 2024-02-06 15:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:53:10 --> Parser Class Initialized
INFO - 2024-02-06 15:53:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:53:10 --> Pagination Class Initialized
INFO - 2024-02-06 15:53:10 --> Form Validation Class Initialized
INFO - 2024-02-06 15:53:10 --> Controller Class Initialized
INFO - 2024-02-06 15:53:10 --> Model Class Initialized
DEBUG - 2024-02-06 15:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:10 --> Model Class Initialized
DEBUG - 2024-02-06 15:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:10 --> Model Class Initialized
INFO - 2024-02-06 15:53:10 --> Model Class Initialized
INFO - 2024-02-06 15:53:10 --> Model Class Initialized
INFO - 2024-02-06 15:53:10 --> Model Class Initialized
DEBUG - 2024-02-06 15:53:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:10 --> Model Class Initialized
INFO - 2024-02-06 15:53:10 --> Model Class Initialized
INFO - 2024-02-06 15:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 15:53:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:53:10 --> Model Class Initialized
INFO - 2024-02-06 15:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:53:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:53:10 --> Final output sent to browser
DEBUG - 2024-02-06 15:53:10 --> Total execution time: 0.2287
ERROR - 2024-02-06 15:53:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:53:19 --> Config Class Initialized
INFO - 2024-02-06 15:53:19 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:53:19 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:53:19 --> Utf8 Class Initialized
INFO - 2024-02-06 15:53:19 --> URI Class Initialized
INFO - 2024-02-06 15:53:19 --> Router Class Initialized
INFO - 2024-02-06 15:53:19 --> Output Class Initialized
INFO - 2024-02-06 15:53:19 --> Security Class Initialized
DEBUG - 2024-02-06 15:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:53:19 --> Input Class Initialized
INFO - 2024-02-06 15:53:19 --> Language Class Initialized
INFO - 2024-02-06 15:53:19 --> Loader Class Initialized
INFO - 2024-02-06 15:53:19 --> Helper loaded: url_helper
INFO - 2024-02-06 15:53:19 --> Helper loaded: file_helper
INFO - 2024-02-06 15:53:19 --> Helper loaded: html_helper
INFO - 2024-02-06 15:53:19 --> Helper loaded: text_helper
INFO - 2024-02-06 15:53:19 --> Helper loaded: form_helper
INFO - 2024-02-06 15:53:19 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:53:19 --> Helper loaded: security_helper
INFO - 2024-02-06 15:53:19 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:53:19 --> Database Driver Class Initialized
INFO - 2024-02-06 15:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:53:19 --> Parser Class Initialized
INFO - 2024-02-06 15:53:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:53:19 --> Pagination Class Initialized
INFO - 2024-02-06 15:53:19 --> Form Validation Class Initialized
INFO - 2024-02-06 15:53:19 --> Controller Class Initialized
INFO - 2024-02-06 15:53:19 --> Model Class Initialized
DEBUG - 2024-02-06 15:53:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:53:19 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:19 --> Model Class Initialized
INFO - 2024-02-06 15:53:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2024-02-06 15:53:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:53:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:53:19 --> Model Class Initialized
INFO - 2024-02-06 15:53:19 --> Model Class Initialized
INFO - 2024-02-06 15:53:19 --> Model Class Initialized
INFO - 2024-02-06 15:53:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:53:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:53:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:53:19 --> Final output sent to browser
DEBUG - 2024-02-06 15:53:19 --> Total execution time: 0.1606
ERROR - 2024-02-06 15:53:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:53:20 --> Config Class Initialized
INFO - 2024-02-06 15:53:20 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:53:20 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:53:20 --> Utf8 Class Initialized
INFO - 2024-02-06 15:53:20 --> URI Class Initialized
INFO - 2024-02-06 15:53:20 --> Router Class Initialized
INFO - 2024-02-06 15:53:20 --> Output Class Initialized
INFO - 2024-02-06 15:53:20 --> Security Class Initialized
DEBUG - 2024-02-06 15:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:53:20 --> Input Class Initialized
INFO - 2024-02-06 15:53:20 --> Language Class Initialized
INFO - 2024-02-06 15:53:20 --> Loader Class Initialized
INFO - 2024-02-06 15:53:20 --> Helper loaded: url_helper
INFO - 2024-02-06 15:53:20 --> Helper loaded: file_helper
INFO - 2024-02-06 15:53:20 --> Helper loaded: html_helper
INFO - 2024-02-06 15:53:20 --> Helper loaded: text_helper
INFO - 2024-02-06 15:53:20 --> Helper loaded: form_helper
INFO - 2024-02-06 15:53:20 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:53:20 --> Helper loaded: security_helper
INFO - 2024-02-06 15:53:20 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:53:20 --> Database Driver Class Initialized
INFO - 2024-02-06 15:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:53:20 --> Parser Class Initialized
INFO - 2024-02-06 15:53:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:53:20 --> Pagination Class Initialized
INFO - 2024-02-06 15:53:20 --> Form Validation Class Initialized
INFO - 2024-02-06 15:53:20 --> Controller Class Initialized
INFO - 2024-02-06 15:53:20 --> Model Class Initialized
DEBUG - 2024-02-06 15:53:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:53:20 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:20 --> Model Class Initialized
INFO - 2024-02-06 15:53:20 --> Final output sent to browser
DEBUG - 2024-02-06 15:53:20 --> Total execution time: 0.0316
ERROR - 2024-02-06 15:53:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:53:22 --> Config Class Initialized
INFO - 2024-02-06 15:53:22 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:53:22 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:53:22 --> Utf8 Class Initialized
INFO - 2024-02-06 15:53:22 --> URI Class Initialized
DEBUG - 2024-02-06 15:53:22 --> No URI present. Default controller set.
INFO - 2024-02-06 15:53:22 --> Router Class Initialized
INFO - 2024-02-06 15:53:22 --> Output Class Initialized
INFO - 2024-02-06 15:53:22 --> Security Class Initialized
DEBUG - 2024-02-06 15:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:53:22 --> Input Class Initialized
INFO - 2024-02-06 15:53:22 --> Language Class Initialized
INFO - 2024-02-06 15:53:22 --> Loader Class Initialized
INFO - 2024-02-06 15:53:22 --> Helper loaded: url_helper
INFO - 2024-02-06 15:53:22 --> Helper loaded: file_helper
INFO - 2024-02-06 15:53:22 --> Helper loaded: html_helper
INFO - 2024-02-06 15:53:22 --> Helper loaded: text_helper
INFO - 2024-02-06 15:53:22 --> Helper loaded: form_helper
INFO - 2024-02-06 15:53:22 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:53:22 --> Helper loaded: security_helper
INFO - 2024-02-06 15:53:22 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:53:22 --> Database Driver Class Initialized
INFO - 2024-02-06 15:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:53:22 --> Parser Class Initialized
INFO - 2024-02-06 15:53:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:53:22 --> Pagination Class Initialized
INFO - 2024-02-06 15:53:22 --> Form Validation Class Initialized
INFO - 2024-02-06 15:53:22 --> Controller Class Initialized
INFO - 2024-02-06 15:53:22 --> Model Class Initialized
DEBUG - 2024-02-06 15:53:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:22 --> Model Class Initialized
DEBUG - 2024-02-06 15:53:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:22 --> Model Class Initialized
INFO - 2024-02-06 15:53:22 --> Model Class Initialized
INFO - 2024-02-06 15:53:22 --> Model Class Initialized
INFO - 2024-02-06 15:53:22 --> Model Class Initialized
DEBUG - 2024-02-06 15:53:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:53:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:22 --> Model Class Initialized
INFO - 2024-02-06 15:53:22 --> Model Class Initialized
INFO - 2024-02-06 15:53:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 15:53:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:53:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:53:22 --> Model Class Initialized
INFO - 2024-02-06 15:53:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:53:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:53:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:53:22 --> Final output sent to browser
DEBUG - 2024-02-06 15:53:22 --> Total execution time: 0.2248
ERROR - 2024-02-06 15:53:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:53:30 --> Config Class Initialized
INFO - 2024-02-06 15:53:30 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:53:30 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:53:30 --> Utf8 Class Initialized
INFO - 2024-02-06 15:53:30 --> URI Class Initialized
INFO - 2024-02-06 15:53:30 --> Router Class Initialized
INFO - 2024-02-06 15:53:30 --> Output Class Initialized
INFO - 2024-02-06 15:53:30 --> Security Class Initialized
DEBUG - 2024-02-06 15:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:53:30 --> Input Class Initialized
INFO - 2024-02-06 15:53:30 --> Language Class Initialized
INFO - 2024-02-06 15:53:30 --> Loader Class Initialized
INFO - 2024-02-06 15:53:30 --> Helper loaded: url_helper
INFO - 2024-02-06 15:53:30 --> Helper loaded: file_helper
INFO - 2024-02-06 15:53:30 --> Helper loaded: html_helper
INFO - 2024-02-06 15:53:30 --> Helper loaded: text_helper
INFO - 2024-02-06 15:53:30 --> Helper loaded: form_helper
INFO - 2024-02-06 15:53:30 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:53:30 --> Helper loaded: security_helper
INFO - 2024-02-06 15:53:30 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:53:30 --> Database Driver Class Initialized
INFO - 2024-02-06 15:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:53:30 --> Parser Class Initialized
INFO - 2024-02-06 15:53:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:53:30 --> Pagination Class Initialized
INFO - 2024-02-06 15:53:30 --> Form Validation Class Initialized
INFO - 2024-02-06 15:53:30 --> Controller Class Initialized
INFO - 2024-02-06 15:53:30 --> Model Class Initialized
DEBUG - 2024-02-06 15:53:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:53:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:30 --> Model Class Initialized
DEBUG - 2024-02-06 15:53:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:30 --> Model Class Initialized
INFO - 2024-02-06 15:53:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-06 15:53:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:53:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:53:30 --> Model Class Initialized
INFO - 2024-02-06 15:53:30 --> Model Class Initialized
INFO - 2024-02-06 15:53:30 --> Model Class Initialized
INFO - 2024-02-06 15:53:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:53:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:53:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:53:30 --> Final output sent to browser
DEBUG - 2024-02-06 15:53:30 --> Total execution time: 0.1639
ERROR - 2024-02-06 15:53:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:53:30 --> Config Class Initialized
INFO - 2024-02-06 15:53:30 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:53:30 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:53:30 --> Utf8 Class Initialized
INFO - 2024-02-06 15:53:30 --> URI Class Initialized
INFO - 2024-02-06 15:53:30 --> Router Class Initialized
INFO - 2024-02-06 15:53:30 --> Output Class Initialized
INFO - 2024-02-06 15:53:30 --> Security Class Initialized
DEBUG - 2024-02-06 15:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:53:30 --> Input Class Initialized
INFO - 2024-02-06 15:53:30 --> Language Class Initialized
INFO - 2024-02-06 15:53:30 --> Loader Class Initialized
INFO - 2024-02-06 15:53:30 --> Helper loaded: url_helper
INFO - 2024-02-06 15:53:30 --> Helper loaded: file_helper
INFO - 2024-02-06 15:53:30 --> Helper loaded: html_helper
INFO - 2024-02-06 15:53:30 --> Helper loaded: text_helper
INFO - 2024-02-06 15:53:30 --> Helper loaded: form_helper
INFO - 2024-02-06 15:53:30 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:53:30 --> Helper loaded: security_helper
INFO - 2024-02-06 15:53:30 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:53:30 --> Database Driver Class Initialized
INFO - 2024-02-06 15:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:53:30 --> Parser Class Initialized
INFO - 2024-02-06 15:53:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:53:30 --> Pagination Class Initialized
INFO - 2024-02-06 15:53:30 --> Form Validation Class Initialized
INFO - 2024-02-06 15:53:30 --> Controller Class Initialized
INFO - 2024-02-06 15:53:30 --> Model Class Initialized
DEBUG - 2024-02-06 15:53:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:53:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:30 --> Model Class Initialized
DEBUG - 2024-02-06 15:53:30 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:30 --> Model Class Initialized
INFO - 2024-02-06 15:53:30 --> Final output sent to browser
DEBUG - 2024-02-06 15:53:30 --> Total execution time: 0.0503
ERROR - 2024-02-06 15:53:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:53:34 --> Config Class Initialized
INFO - 2024-02-06 15:53:34 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:53:34 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:53:34 --> Utf8 Class Initialized
INFO - 2024-02-06 15:53:34 --> URI Class Initialized
INFO - 2024-02-06 15:53:34 --> Router Class Initialized
INFO - 2024-02-06 15:53:34 --> Output Class Initialized
INFO - 2024-02-06 15:53:34 --> Security Class Initialized
DEBUG - 2024-02-06 15:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:53:34 --> Input Class Initialized
INFO - 2024-02-06 15:53:34 --> Language Class Initialized
INFO - 2024-02-06 15:53:34 --> Loader Class Initialized
INFO - 2024-02-06 15:53:34 --> Helper loaded: url_helper
INFO - 2024-02-06 15:53:34 --> Helper loaded: file_helper
INFO - 2024-02-06 15:53:34 --> Helper loaded: html_helper
INFO - 2024-02-06 15:53:34 --> Helper loaded: text_helper
INFO - 2024-02-06 15:53:34 --> Helper loaded: form_helper
INFO - 2024-02-06 15:53:34 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:53:34 --> Helper loaded: security_helper
INFO - 2024-02-06 15:53:34 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:53:34 --> Database Driver Class Initialized
INFO - 2024-02-06 15:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:53:34 --> Parser Class Initialized
INFO - 2024-02-06 15:53:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:53:34 --> Pagination Class Initialized
INFO - 2024-02-06 15:53:34 --> Form Validation Class Initialized
INFO - 2024-02-06 15:53:34 --> Controller Class Initialized
INFO - 2024-02-06 15:53:34 --> Model Class Initialized
DEBUG - 2024-02-06 15:53:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:53:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:34 --> Model Class Initialized
DEBUG - 2024-02-06 15:53:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:34 --> Model Class Initialized
INFO - 2024-02-06 15:53:34 --> Final output sent to browser
DEBUG - 2024-02-06 15:53:34 --> Total execution time: 0.1357
ERROR - 2024-02-06 15:53:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:53:45 --> Config Class Initialized
INFO - 2024-02-06 15:53:45 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:53:45 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:53:45 --> Utf8 Class Initialized
INFO - 2024-02-06 15:53:45 --> URI Class Initialized
DEBUG - 2024-02-06 15:53:45 --> No URI present. Default controller set.
INFO - 2024-02-06 15:53:45 --> Router Class Initialized
INFO - 2024-02-06 15:53:45 --> Output Class Initialized
INFO - 2024-02-06 15:53:45 --> Security Class Initialized
DEBUG - 2024-02-06 15:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:53:45 --> Input Class Initialized
INFO - 2024-02-06 15:53:45 --> Language Class Initialized
INFO - 2024-02-06 15:53:45 --> Loader Class Initialized
INFO - 2024-02-06 15:53:45 --> Helper loaded: url_helper
INFO - 2024-02-06 15:53:45 --> Helper loaded: file_helper
INFO - 2024-02-06 15:53:45 --> Helper loaded: html_helper
INFO - 2024-02-06 15:53:45 --> Helper loaded: text_helper
INFO - 2024-02-06 15:53:45 --> Helper loaded: form_helper
INFO - 2024-02-06 15:53:45 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:53:45 --> Helper loaded: security_helper
INFO - 2024-02-06 15:53:45 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:53:45 --> Database Driver Class Initialized
INFO - 2024-02-06 15:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:53:45 --> Parser Class Initialized
INFO - 2024-02-06 15:53:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:53:45 --> Pagination Class Initialized
INFO - 2024-02-06 15:53:45 --> Form Validation Class Initialized
INFO - 2024-02-06 15:53:45 --> Controller Class Initialized
INFO - 2024-02-06 15:53:45 --> Model Class Initialized
DEBUG - 2024-02-06 15:53:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:45 --> Model Class Initialized
DEBUG - 2024-02-06 15:53:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:45 --> Model Class Initialized
INFO - 2024-02-06 15:53:45 --> Model Class Initialized
INFO - 2024-02-06 15:53:45 --> Model Class Initialized
INFO - 2024-02-06 15:53:45 --> Model Class Initialized
DEBUG - 2024-02-06 15:53:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:53:45 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:45 --> Model Class Initialized
INFO - 2024-02-06 15:53:45 --> Model Class Initialized
INFO - 2024-02-06 15:53:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 15:53:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:53:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:53:45 --> Model Class Initialized
INFO - 2024-02-06 15:53:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:53:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:53:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:53:45 --> Final output sent to browser
DEBUG - 2024-02-06 15:53:45 --> Total execution time: 0.2179
ERROR - 2024-02-06 15:53:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:53:53 --> Config Class Initialized
INFO - 2024-02-06 15:53:53 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:53:53 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:53:53 --> Utf8 Class Initialized
INFO - 2024-02-06 15:53:53 --> URI Class Initialized
INFO - 2024-02-06 15:53:53 --> Router Class Initialized
INFO - 2024-02-06 15:53:53 --> Output Class Initialized
INFO - 2024-02-06 15:53:53 --> Security Class Initialized
DEBUG - 2024-02-06 15:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:53:53 --> Input Class Initialized
INFO - 2024-02-06 15:53:53 --> Language Class Initialized
INFO - 2024-02-06 15:53:53 --> Loader Class Initialized
INFO - 2024-02-06 15:53:53 --> Helper loaded: url_helper
INFO - 2024-02-06 15:53:53 --> Helper loaded: file_helper
INFO - 2024-02-06 15:53:53 --> Helper loaded: html_helper
INFO - 2024-02-06 15:53:53 --> Helper loaded: text_helper
INFO - 2024-02-06 15:53:53 --> Helper loaded: form_helper
INFO - 2024-02-06 15:53:53 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:53:53 --> Helper loaded: security_helper
INFO - 2024-02-06 15:53:53 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:53:53 --> Database Driver Class Initialized
INFO - 2024-02-06 15:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:53:53 --> Parser Class Initialized
INFO - 2024-02-06 15:53:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:53:53 --> Pagination Class Initialized
INFO - 2024-02-06 15:53:53 --> Form Validation Class Initialized
INFO - 2024-02-06 15:53:53 --> Controller Class Initialized
DEBUG - 2024-02-06 15:53:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:53:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:53 --> Model Class Initialized
DEBUG - 2024-02-06 15:53:53 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:53 --> Model Class Initialized
DEBUG - 2024-02-06 15:53:53 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:53 --> Model Class Initialized
INFO - 2024-02-06 15:53:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-06 15:53:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:53:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:53:53 --> Model Class Initialized
INFO - 2024-02-06 15:53:53 --> Model Class Initialized
INFO - 2024-02-06 15:53:53 --> Model Class Initialized
INFO - 2024-02-06 15:53:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:53:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:53:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:53:53 --> Final output sent to browser
DEBUG - 2024-02-06 15:53:53 --> Total execution time: 0.1381
ERROR - 2024-02-06 15:53:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:53:54 --> Config Class Initialized
INFO - 2024-02-06 15:53:54 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:53:54 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:53:54 --> Utf8 Class Initialized
INFO - 2024-02-06 15:53:54 --> URI Class Initialized
INFO - 2024-02-06 15:53:54 --> Router Class Initialized
INFO - 2024-02-06 15:53:54 --> Output Class Initialized
INFO - 2024-02-06 15:53:54 --> Security Class Initialized
DEBUG - 2024-02-06 15:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:53:54 --> Input Class Initialized
INFO - 2024-02-06 15:53:54 --> Language Class Initialized
INFO - 2024-02-06 15:53:54 --> Loader Class Initialized
INFO - 2024-02-06 15:53:54 --> Helper loaded: url_helper
INFO - 2024-02-06 15:53:54 --> Helper loaded: file_helper
INFO - 2024-02-06 15:53:54 --> Helper loaded: html_helper
INFO - 2024-02-06 15:53:54 --> Helper loaded: text_helper
INFO - 2024-02-06 15:53:54 --> Helper loaded: form_helper
INFO - 2024-02-06 15:53:54 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:53:54 --> Helper loaded: security_helper
INFO - 2024-02-06 15:53:54 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:53:54 --> Database Driver Class Initialized
INFO - 2024-02-06 15:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:53:54 --> Parser Class Initialized
INFO - 2024-02-06 15:53:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:53:54 --> Pagination Class Initialized
INFO - 2024-02-06 15:53:54 --> Form Validation Class Initialized
INFO - 2024-02-06 15:53:54 --> Controller Class Initialized
DEBUG - 2024-02-06 15:53:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:53:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:54 --> Model Class Initialized
DEBUG - 2024-02-06 15:53:54 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:54 --> Model Class Initialized
INFO - 2024-02-06 15:53:54 --> Final output sent to browser
DEBUG - 2024-02-06 15:53:54 --> Total execution time: 0.0209
ERROR - 2024-02-06 15:53:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:53:56 --> Config Class Initialized
INFO - 2024-02-06 15:53:56 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:53:56 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:53:56 --> Utf8 Class Initialized
INFO - 2024-02-06 15:53:56 --> URI Class Initialized
DEBUG - 2024-02-06 15:53:56 --> No URI present. Default controller set.
INFO - 2024-02-06 15:53:56 --> Router Class Initialized
INFO - 2024-02-06 15:53:56 --> Output Class Initialized
INFO - 2024-02-06 15:53:56 --> Security Class Initialized
DEBUG - 2024-02-06 15:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:53:56 --> Input Class Initialized
INFO - 2024-02-06 15:53:56 --> Language Class Initialized
INFO - 2024-02-06 15:53:56 --> Loader Class Initialized
INFO - 2024-02-06 15:53:56 --> Helper loaded: url_helper
INFO - 2024-02-06 15:53:56 --> Helper loaded: file_helper
INFO - 2024-02-06 15:53:56 --> Helper loaded: html_helper
INFO - 2024-02-06 15:53:56 --> Helper loaded: text_helper
INFO - 2024-02-06 15:53:56 --> Helper loaded: form_helper
INFO - 2024-02-06 15:53:56 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:53:56 --> Helper loaded: security_helper
INFO - 2024-02-06 15:53:56 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:53:56 --> Database Driver Class Initialized
INFO - 2024-02-06 15:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:53:56 --> Parser Class Initialized
INFO - 2024-02-06 15:53:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:53:56 --> Pagination Class Initialized
INFO - 2024-02-06 15:53:56 --> Form Validation Class Initialized
INFO - 2024-02-06 15:53:56 --> Controller Class Initialized
INFO - 2024-02-06 15:53:56 --> Model Class Initialized
DEBUG - 2024-02-06 15:53:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:56 --> Model Class Initialized
DEBUG - 2024-02-06 15:53:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:56 --> Model Class Initialized
INFO - 2024-02-06 15:53:56 --> Model Class Initialized
INFO - 2024-02-06 15:53:56 --> Model Class Initialized
INFO - 2024-02-06 15:53:56 --> Model Class Initialized
DEBUG - 2024-02-06 15:53:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:53:56 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:56 --> Model Class Initialized
INFO - 2024-02-06 15:53:56 --> Model Class Initialized
INFO - 2024-02-06 15:53:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 15:53:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:53:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:53:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:53:56 --> Model Class Initialized
INFO - 2024-02-06 15:53:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:53:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:53:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:53:56 --> Final output sent to browser
DEBUG - 2024-02-06 15:53:56 --> Total execution time: 0.2231
ERROR - 2024-02-06 15:54:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:54:06 --> Config Class Initialized
INFO - 2024-02-06 15:54:06 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:54:06 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:54:06 --> Utf8 Class Initialized
INFO - 2024-02-06 15:54:06 --> URI Class Initialized
INFO - 2024-02-06 15:54:06 --> Router Class Initialized
INFO - 2024-02-06 15:54:06 --> Output Class Initialized
INFO - 2024-02-06 15:54:06 --> Security Class Initialized
DEBUG - 2024-02-06 15:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:54:06 --> Input Class Initialized
INFO - 2024-02-06 15:54:06 --> Language Class Initialized
INFO - 2024-02-06 15:54:06 --> Loader Class Initialized
INFO - 2024-02-06 15:54:06 --> Helper loaded: url_helper
INFO - 2024-02-06 15:54:06 --> Helper loaded: file_helper
INFO - 2024-02-06 15:54:06 --> Helper loaded: html_helper
INFO - 2024-02-06 15:54:06 --> Helper loaded: text_helper
INFO - 2024-02-06 15:54:06 --> Helper loaded: form_helper
INFO - 2024-02-06 15:54:06 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:54:06 --> Helper loaded: security_helper
INFO - 2024-02-06 15:54:06 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:54:06 --> Database Driver Class Initialized
INFO - 2024-02-06 15:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:54:06 --> Parser Class Initialized
INFO - 2024-02-06 15:54:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:54:06 --> Pagination Class Initialized
INFO - 2024-02-06 15:54:06 --> Form Validation Class Initialized
INFO - 2024-02-06 15:54:06 --> Controller Class Initialized
INFO - 2024-02-06 15:54:06 --> Model Class Initialized
DEBUG - 2024-02-06 15:54:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:54:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:54:06 --> Model Class Initialized
DEBUG - 2024-02-06 15:54:06 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:54:06 --> Model Class Initialized
INFO - 2024-02-06 15:54:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-06 15:54:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:54:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:54:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:54:06 --> Model Class Initialized
INFO - 2024-02-06 15:54:06 --> Model Class Initialized
INFO - 2024-02-06 15:54:06 --> Model Class Initialized
INFO - 2024-02-06 15:54:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:54:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:54:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:54:06 --> Final output sent to browser
DEBUG - 2024-02-06 15:54:06 --> Total execution time: 0.1616
ERROR - 2024-02-06 15:54:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:54:07 --> Config Class Initialized
INFO - 2024-02-06 15:54:07 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:54:07 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:54:07 --> Utf8 Class Initialized
INFO - 2024-02-06 15:54:07 --> URI Class Initialized
INFO - 2024-02-06 15:54:07 --> Router Class Initialized
INFO - 2024-02-06 15:54:07 --> Output Class Initialized
INFO - 2024-02-06 15:54:07 --> Security Class Initialized
DEBUG - 2024-02-06 15:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:54:07 --> Input Class Initialized
INFO - 2024-02-06 15:54:07 --> Language Class Initialized
INFO - 2024-02-06 15:54:07 --> Loader Class Initialized
INFO - 2024-02-06 15:54:07 --> Helper loaded: url_helper
INFO - 2024-02-06 15:54:07 --> Helper loaded: file_helper
INFO - 2024-02-06 15:54:07 --> Helper loaded: html_helper
INFO - 2024-02-06 15:54:07 --> Helper loaded: text_helper
INFO - 2024-02-06 15:54:07 --> Helper loaded: form_helper
INFO - 2024-02-06 15:54:07 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:54:07 --> Helper loaded: security_helper
INFO - 2024-02-06 15:54:07 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:54:07 --> Database Driver Class Initialized
INFO - 2024-02-06 15:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:54:07 --> Parser Class Initialized
INFO - 2024-02-06 15:54:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:54:07 --> Pagination Class Initialized
INFO - 2024-02-06 15:54:07 --> Form Validation Class Initialized
INFO - 2024-02-06 15:54:07 --> Controller Class Initialized
INFO - 2024-02-06 15:54:07 --> Model Class Initialized
DEBUG - 2024-02-06 15:54:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:54:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:54:07 --> Model Class Initialized
DEBUG - 2024-02-06 15:54:07 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:54:07 --> Model Class Initialized
INFO - 2024-02-06 15:54:07 --> Final output sent to browser
DEBUG - 2024-02-06 15:54:07 --> Total execution time: 0.0462
ERROR - 2024-02-06 15:54:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:54:10 --> Config Class Initialized
INFO - 2024-02-06 15:54:10 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:54:10 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:54:10 --> Utf8 Class Initialized
INFO - 2024-02-06 15:54:10 --> URI Class Initialized
INFO - 2024-02-06 15:54:10 --> Router Class Initialized
INFO - 2024-02-06 15:54:10 --> Output Class Initialized
INFO - 2024-02-06 15:54:10 --> Security Class Initialized
DEBUG - 2024-02-06 15:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:54:10 --> Input Class Initialized
INFO - 2024-02-06 15:54:10 --> Language Class Initialized
INFO - 2024-02-06 15:54:10 --> Loader Class Initialized
INFO - 2024-02-06 15:54:10 --> Helper loaded: url_helper
INFO - 2024-02-06 15:54:10 --> Helper loaded: file_helper
INFO - 2024-02-06 15:54:10 --> Helper loaded: html_helper
INFO - 2024-02-06 15:54:10 --> Helper loaded: text_helper
INFO - 2024-02-06 15:54:10 --> Helper loaded: form_helper
INFO - 2024-02-06 15:54:10 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:54:10 --> Helper loaded: security_helper
INFO - 2024-02-06 15:54:10 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:54:10 --> Database Driver Class Initialized
INFO - 2024-02-06 15:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:54:10 --> Parser Class Initialized
INFO - 2024-02-06 15:54:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:54:10 --> Pagination Class Initialized
INFO - 2024-02-06 15:54:10 --> Form Validation Class Initialized
INFO - 2024-02-06 15:54:10 --> Controller Class Initialized
INFO - 2024-02-06 15:54:10 --> Model Class Initialized
DEBUG - 2024-02-06 15:54:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:54:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:54:10 --> Model Class Initialized
DEBUG - 2024-02-06 15:54:10 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:54:10 --> Model Class Initialized
INFO - 2024-02-06 15:54:10 --> Final output sent to browser
DEBUG - 2024-02-06 15:54:10 --> Total execution time: 0.1267
ERROR - 2024-02-06 15:54:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:54:14 --> Config Class Initialized
INFO - 2024-02-06 15:54:14 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:54:14 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:54:14 --> Utf8 Class Initialized
INFO - 2024-02-06 15:54:14 --> URI Class Initialized
DEBUG - 2024-02-06 15:54:14 --> No URI present. Default controller set.
INFO - 2024-02-06 15:54:14 --> Router Class Initialized
INFO - 2024-02-06 15:54:14 --> Output Class Initialized
INFO - 2024-02-06 15:54:14 --> Security Class Initialized
DEBUG - 2024-02-06 15:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:54:14 --> Input Class Initialized
INFO - 2024-02-06 15:54:14 --> Language Class Initialized
INFO - 2024-02-06 15:54:14 --> Loader Class Initialized
INFO - 2024-02-06 15:54:14 --> Helper loaded: url_helper
INFO - 2024-02-06 15:54:14 --> Helper loaded: file_helper
INFO - 2024-02-06 15:54:14 --> Helper loaded: html_helper
INFO - 2024-02-06 15:54:14 --> Helper loaded: text_helper
INFO - 2024-02-06 15:54:14 --> Helper loaded: form_helper
INFO - 2024-02-06 15:54:14 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:54:14 --> Helper loaded: security_helper
INFO - 2024-02-06 15:54:14 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:54:14 --> Database Driver Class Initialized
INFO - 2024-02-06 15:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:54:14 --> Parser Class Initialized
INFO - 2024-02-06 15:54:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:54:14 --> Pagination Class Initialized
INFO - 2024-02-06 15:54:14 --> Form Validation Class Initialized
INFO - 2024-02-06 15:54:14 --> Controller Class Initialized
INFO - 2024-02-06 15:54:14 --> Model Class Initialized
DEBUG - 2024-02-06 15:54:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:54:14 --> Model Class Initialized
DEBUG - 2024-02-06 15:54:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:54:14 --> Model Class Initialized
INFO - 2024-02-06 15:54:14 --> Model Class Initialized
INFO - 2024-02-06 15:54:14 --> Model Class Initialized
INFO - 2024-02-06 15:54:14 --> Model Class Initialized
DEBUG - 2024-02-06 15:54:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:54:14 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:54:14 --> Model Class Initialized
INFO - 2024-02-06 15:54:14 --> Model Class Initialized
INFO - 2024-02-06 15:54:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 15:54:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:54:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:54:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:54:14 --> Model Class Initialized
INFO - 2024-02-06 15:54:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:54:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:54:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:54:14 --> Final output sent to browser
DEBUG - 2024-02-06 15:54:14 --> Total execution time: 0.2227
ERROR - 2024-02-06 15:54:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:54:34 --> Config Class Initialized
INFO - 2024-02-06 15:54:34 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:54:34 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:54:34 --> Utf8 Class Initialized
INFO - 2024-02-06 15:54:34 --> URI Class Initialized
INFO - 2024-02-06 15:54:34 --> Router Class Initialized
INFO - 2024-02-06 15:54:34 --> Output Class Initialized
INFO - 2024-02-06 15:54:34 --> Security Class Initialized
DEBUG - 2024-02-06 15:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:54:34 --> Input Class Initialized
INFO - 2024-02-06 15:54:34 --> Language Class Initialized
INFO - 2024-02-06 15:54:34 --> Loader Class Initialized
INFO - 2024-02-06 15:54:34 --> Helper loaded: url_helper
INFO - 2024-02-06 15:54:34 --> Helper loaded: file_helper
INFO - 2024-02-06 15:54:34 --> Helper loaded: html_helper
INFO - 2024-02-06 15:54:34 --> Helper loaded: text_helper
INFO - 2024-02-06 15:54:34 --> Helper loaded: form_helper
INFO - 2024-02-06 15:54:34 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:54:34 --> Helper loaded: security_helper
INFO - 2024-02-06 15:54:34 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:54:34 --> Database Driver Class Initialized
INFO - 2024-02-06 15:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:54:34 --> Parser Class Initialized
INFO - 2024-02-06 15:54:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:54:34 --> Pagination Class Initialized
INFO - 2024-02-06 15:54:34 --> Form Validation Class Initialized
INFO - 2024-02-06 15:54:34 --> Controller Class Initialized
DEBUG - 2024-02-06 15:54:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:54:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:54:34 --> Model Class Initialized
DEBUG - 2024-02-06 15:54:34 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:54:34 --> Model Class Initialized
DEBUG - 2024-02-06 15:54:34 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:54:34 --> Model Class Initialized
INFO - 2024-02-06 15:54:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-06 15:54:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:54:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:54:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:54:34 --> Model Class Initialized
INFO - 2024-02-06 15:54:34 --> Model Class Initialized
INFO - 2024-02-06 15:54:34 --> Model Class Initialized
INFO - 2024-02-06 15:54:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:54:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:54:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:54:34 --> Final output sent to browser
DEBUG - 2024-02-06 15:54:34 --> Total execution time: 0.1455
ERROR - 2024-02-06 15:54:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:54:35 --> Config Class Initialized
INFO - 2024-02-06 15:54:35 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:54:35 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:54:35 --> Utf8 Class Initialized
INFO - 2024-02-06 15:54:35 --> URI Class Initialized
INFO - 2024-02-06 15:54:35 --> Router Class Initialized
INFO - 2024-02-06 15:54:35 --> Output Class Initialized
INFO - 2024-02-06 15:54:35 --> Security Class Initialized
DEBUG - 2024-02-06 15:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:54:35 --> Input Class Initialized
INFO - 2024-02-06 15:54:35 --> Language Class Initialized
INFO - 2024-02-06 15:54:35 --> Loader Class Initialized
INFO - 2024-02-06 15:54:35 --> Helper loaded: url_helper
INFO - 2024-02-06 15:54:35 --> Helper loaded: file_helper
INFO - 2024-02-06 15:54:35 --> Helper loaded: html_helper
INFO - 2024-02-06 15:54:35 --> Helper loaded: text_helper
INFO - 2024-02-06 15:54:35 --> Helper loaded: form_helper
INFO - 2024-02-06 15:54:35 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:54:35 --> Helper loaded: security_helper
INFO - 2024-02-06 15:54:35 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:54:35 --> Database Driver Class Initialized
INFO - 2024-02-06 15:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:54:35 --> Parser Class Initialized
INFO - 2024-02-06 15:54:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:54:35 --> Pagination Class Initialized
INFO - 2024-02-06 15:54:35 --> Form Validation Class Initialized
INFO - 2024-02-06 15:54:35 --> Controller Class Initialized
DEBUG - 2024-02-06 15:54:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:54:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:54:35 --> Model Class Initialized
DEBUG - 2024-02-06 15:54:35 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:54:35 --> Model Class Initialized
INFO - 2024-02-06 15:54:35 --> Final output sent to browser
DEBUG - 2024-02-06 15:54:35 --> Total execution time: 0.0210
ERROR - 2024-02-06 15:54:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:54:39 --> Config Class Initialized
INFO - 2024-02-06 15:54:39 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:54:39 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:54:39 --> Utf8 Class Initialized
INFO - 2024-02-06 15:54:39 --> URI Class Initialized
INFO - 2024-02-06 15:54:39 --> Router Class Initialized
INFO - 2024-02-06 15:54:39 --> Output Class Initialized
INFO - 2024-02-06 15:54:39 --> Security Class Initialized
DEBUG - 2024-02-06 15:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:54:39 --> Input Class Initialized
INFO - 2024-02-06 15:54:39 --> Language Class Initialized
INFO - 2024-02-06 15:54:39 --> Loader Class Initialized
INFO - 2024-02-06 15:54:39 --> Helper loaded: url_helper
INFO - 2024-02-06 15:54:39 --> Helper loaded: file_helper
INFO - 2024-02-06 15:54:39 --> Helper loaded: html_helper
INFO - 2024-02-06 15:54:39 --> Helper loaded: text_helper
INFO - 2024-02-06 15:54:39 --> Helper loaded: form_helper
INFO - 2024-02-06 15:54:39 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:54:39 --> Helper loaded: security_helper
INFO - 2024-02-06 15:54:39 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:54:39 --> Database Driver Class Initialized
INFO - 2024-02-06 15:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:54:39 --> Parser Class Initialized
INFO - 2024-02-06 15:54:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:54:39 --> Pagination Class Initialized
INFO - 2024-02-06 15:54:39 --> Form Validation Class Initialized
INFO - 2024-02-06 15:54:39 --> Controller Class Initialized
DEBUG - 2024-02-06 15:54:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:54:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:54:39 --> Model Class Initialized
DEBUG - 2024-02-06 15:54:39 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:54:39 --> Model Class Initialized
INFO - 2024-02-06 15:54:39 --> Final output sent to browser
DEBUG - 2024-02-06 15:54:39 --> Total execution time: 0.0288
ERROR - 2024-02-06 15:54:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:54:58 --> Config Class Initialized
INFO - 2024-02-06 15:54:58 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:54:58 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:54:58 --> Utf8 Class Initialized
INFO - 2024-02-06 15:54:58 --> URI Class Initialized
DEBUG - 2024-02-06 15:54:58 --> No URI present. Default controller set.
INFO - 2024-02-06 15:54:58 --> Router Class Initialized
INFO - 2024-02-06 15:54:58 --> Output Class Initialized
INFO - 2024-02-06 15:54:58 --> Security Class Initialized
DEBUG - 2024-02-06 15:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:54:58 --> Input Class Initialized
INFO - 2024-02-06 15:54:58 --> Language Class Initialized
INFO - 2024-02-06 15:54:58 --> Loader Class Initialized
INFO - 2024-02-06 15:54:58 --> Helper loaded: url_helper
INFO - 2024-02-06 15:54:58 --> Helper loaded: file_helper
INFO - 2024-02-06 15:54:58 --> Helper loaded: html_helper
INFO - 2024-02-06 15:54:58 --> Helper loaded: text_helper
INFO - 2024-02-06 15:54:58 --> Helper loaded: form_helper
INFO - 2024-02-06 15:54:58 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:54:58 --> Helper loaded: security_helper
INFO - 2024-02-06 15:54:58 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:54:58 --> Database Driver Class Initialized
INFO - 2024-02-06 15:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:54:58 --> Parser Class Initialized
INFO - 2024-02-06 15:54:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:54:58 --> Pagination Class Initialized
INFO - 2024-02-06 15:54:58 --> Form Validation Class Initialized
INFO - 2024-02-06 15:54:58 --> Controller Class Initialized
INFO - 2024-02-06 15:54:58 --> Model Class Initialized
DEBUG - 2024-02-06 15:54:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:54:58 --> Model Class Initialized
DEBUG - 2024-02-06 15:54:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:54:58 --> Model Class Initialized
INFO - 2024-02-06 15:54:58 --> Model Class Initialized
INFO - 2024-02-06 15:54:58 --> Model Class Initialized
INFO - 2024-02-06 15:54:58 --> Model Class Initialized
DEBUG - 2024-02-06 15:54:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:54:58 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:54:58 --> Model Class Initialized
INFO - 2024-02-06 15:54:58 --> Model Class Initialized
INFO - 2024-02-06 15:54:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 15:54:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:54:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:54:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:54:58 --> Model Class Initialized
INFO - 2024-02-06 15:54:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:54:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:54:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:54:58 --> Final output sent to browser
DEBUG - 2024-02-06 15:54:58 --> Total execution time: 0.2159
ERROR - 2024-02-06 15:55:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:55:01 --> Config Class Initialized
INFO - 2024-02-06 15:55:01 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:55:01 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:55:01 --> Utf8 Class Initialized
INFO - 2024-02-06 15:55:01 --> URI Class Initialized
INFO - 2024-02-06 15:55:01 --> Router Class Initialized
INFO - 2024-02-06 15:55:01 --> Output Class Initialized
INFO - 2024-02-06 15:55:01 --> Security Class Initialized
DEBUG - 2024-02-06 15:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:55:01 --> Input Class Initialized
INFO - 2024-02-06 15:55:01 --> Language Class Initialized
INFO - 2024-02-06 15:55:01 --> Loader Class Initialized
INFO - 2024-02-06 15:55:01 --> Helper loaded: url_helper
INFO - 2024-02-06 15:55:01 --> Helper loaded: file_helper
INFO - 2024-02-06 15:55:01 --> Helper loaded: html_helper
INFO - 2024-02-06 15:55:01 --> Helper loaded: text_helper
INFO - 2024-02-06 15:55:01 --> Helper loaded: form_helper
INFO - 2024-02-06 15:55:01 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:55:01 --> Helper loaded: security_helper
INFO - 2024-02-06 15:55:01 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:55:01 --> Database Driver Class Initialized
INFO - 2024-02-06 15:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:55:01 --> Parser Class Initialized
INFO - 2024-02-06 15:55:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:55:01 --> Pagination Class Initialized
INFO - 2024-02-06 15:55:02 --> Form Validation Class Initialized
INFO - 2024-02-06 15:55:02 --> Controller Class Initialized
DEBUG - 2024-02-06 15:55:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:55:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:55:02 --> Model Class Initialized
DEBUG - 2024-02-06 15:55:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:55:02 --> Model Class Initialized
DEBUG - 2024-02-06 15:55:02 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:55:02 --> Model Class Initialized
INFO - 2024-02-06 15:55:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-06 15:55:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:55:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:55:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:55:02 --> Model Class Initialized
INFO - 2024-02-06 15:55:02 --> Model Class Initialized
INFO - 2024-02-06 15:55:02 --> Model Class Initialized
INFO - 2024-02-06 15:55:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:55:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:55:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:55:02 --> Final output sent to browser
DEBUG - 2024-02-06 15:55:02 --> Total execution time: 0.1758
ERROR - 2024-02-06 15:55:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:55:02 --> Config Class Initialized
INFO - 2024-02-06 15:55:02 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:55:02 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:55:02 --> Utf8 Class Initialized
INFO - 2024-02-06 15:55:02 --> URI Class Initialized
INFO - 2024-02-06 15:55:02 --> Router Class Initialized
INFO - 2024-02-06 15:55:02 --> Output Class Initialized
INFO - 2024-02-06 15:55:02 --> Security Class Initialized
DEBUG - 2024-02-06 15:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:55:02 --> Input Class Initialized
INFO - 2024-02-06 15:55:02 --> Language Class Initialized
INFO - 2024-02-06 15:55:02 --> Loader Class Initialized
INFO - 2024-02-06 15:55:02 --> Helper loaded: url_helper
INFO - 2024-02-06 15:55:02 --> Helper loaded: file_helper
INFO - 2024-02-06 15:55:02 --> Helper loaded: html_helper
INFO - 2024-02-06 15:55:02 --> Helper loaded: text_helper
INFO - 2024-02-06 15:55:02 --> Helper loaded: form_helper
INFO - 2024-02-06 15:55:02 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:55:02 --> Helper loaded: security_helper
INFO - 2024-02-06 15:55:02 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:55:02 --> Database Driver Class Initialized
INFO - 2024-02-06 15:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:55:02 --> Parser Class Initialized
INFO - 2024-02-06 15:55:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:55:02 --> Pagination Class Initialized
INFO - 2024-02-06 15:55:02 --> Form Validation Class Initialized
INFO - 2024-02-06 15:55:02 --> Controller Class Initialized
DEBUG - 2024-02-06 15:55:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:55:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:55:02 --> Model Class Initialized
DEBUG - 2024-02-06 15:55:02 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:55:02 --> Model Class Initialized
INFO - 2024-02-06 15:55:02 --> Final output sent to browser
DEBUG - 2024-02-06 15:55:02 --> Total execution time: 0.0241
ERROR - 2024-02-06 15:55:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:55:05 --> Config Class Initialized
INFO - 2024-02-06 15:55:05 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:55:05 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:55:05 --> Utf8 Class Initialized
INFO - 2024-02-06 15:55:05 --> URI Class Initialized
INFO - 2024-02-06 15:55:05 --> Router Class Initialized
INFO - 2024-02-06 15:55:05 --> Output Class Initialized
INFO - 2024-02-06 15:55:05 --> Security Class Initialized
DEBUG - 2024-02-06 15:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:55:05 --> Input Class Initialized
INFO - 2024-02-06 15:55:05 --> Language Class Initialized
INFO - 2024-02-06 15:55:05 --> Loader Class Initialized
INFO - 2024-02-06 15:55:05 --> Helper loaded: url_helper
INFO - 2024-02-06 15:55:05 --> Helper loaded: file_helper
INFO - 2024-02-06 15:55:05 --> Helper loaded: html_helper
INFO - 2024-02-06 15:55:05 --> Helper loaded: text_helper
INFO - 2024-02-06 15:55:05 --> Helper loaded: form_helper
INFO - 2024-02-06 15:55:05 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:55:05 --> Helper loaded: security_helper
INFO - 2024-02-06 15:55:05 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:55:05 --> Database Driver Class Initialized
INFO - 2024-02-06 15:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:55:05 --> Parser Class Initialized
INFO - 2024-02-06 15:55:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:55:05 --> Pagination Class Initialized
INFO - 2024-02-06 15:55:05 --> Form Validation Class Initialized
INFO - 2024-02-06 15:55:05 --> Controller Class Initialized
DEBUG - 2024-02-06 15:55:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:55:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:55:05 --> Model Class Initialized
DEBUG - 2024-02-06 15:55:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:55:05 --> Model Class Initialized
INFO - 2024-02-06 15:55:06 --> Final output sent to browser
DEBUG - 2024-02-06 15:55:06 --> Total execution time: 0.0381
ERROR - 2024-02-06 15:55:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:55:22 --> Config Class Initialized
INFO - 2024-02-06 15:55:22 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:55:22 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:55:22 --> Utf8 Class Initialized
INFO - 2024-02-06 15:55:22 --> URI Class Initialized
DEBUG - 2024-02-06 15:55:22 --> No URI present. Default controller set.
INFO - 2024-02-06 15:55:22 --> Router Class Initialized
INFO - 2024-02-06 15:55:22 --> Output Class Initialized
INFO - 2024-02-06 15:55:22 --> Security Class Initialized
DEBUG - 2024-02-06 15:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:55:22 --> Input Class Initialized
INFO - 2024-02-06 15:55:22 --> Language Class Initialized
INFO - 2024-02-06 15:55:22 --> Loader Class Initialized
INFO - 2024-02-06 15:55:22 --> Helper loaded: url_helper
INFO - 2024-02-06 15:55:22 --> Helper loaded: file_helper
INFO - 2024-02-06 15:55:22 --> Helper loaded: html_helper
INFO - 2024-02-06 15:55:22 --> Helper loaded: text_helper
INFO - 2024-02-06 15:55:22 --> Helper loaded: form_helper
INFO - 2024-02-06 15:55:22 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:55:22 --> Helper loaded: security_helper
INFO - 2024-02-06 15:55:22 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:55:22 --> Database Driver Class Initialized
INFO - 2024-02-06 15:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:55:22 --> Parser Class Initialized
INFO - 2024-02-06 15:55:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:55:22 --> Pagination Class Initialized
INFO - 2024-02-06 15:55:22 --> Form Validation Class Initialized
INFO - 2024-02-06 15:55:22 --> Controller Class Initialized
INFO - 2024-02-06 15:55:22 --> Model Class Initialized
DEBUG - 2024-02-06 15:55:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:55:22 --> Model Class Initialized
DEBUG - 2024-02-06 15:55:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:55:22 --> Model Class Initialized
INFO - 2024-02-06 15:55:22 --> Model Class Initialized
INFO - 2024-02-06 15:55:22 --> Model Class Initialized
INFO - 2024-02-06 15:55:22 --> Model Class Initialized
DEBUG - 2024-02-06 15:55:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:55:22 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:55:22 --> Model Class Initialized
INFO - 2024-02-06 15:55:22 --> Model Class Initialized
INFO - 2024-02-06 15:55:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 15:55:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:55:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:55:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:55:22 --> Model Class Initialized
INFO - 2024-02-06 15:55:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:55:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:55:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:55:22 --> Final output sent to browser
DEBUG - 2024-02-06 15:55:22 --> Total execution time: 0.2252
ERROR - 2024-02-06 15:55:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:55:36 --> Config Class Initialized
INFO - 2024-02-06 15:55:36 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:55:36 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:55:36 --> Utf8 Class Initialized
INFO - 2024-02-06 15:55:36 --> URI Class Initialized
INFO - 2024-02-06 15:55:36 --> Router Class Initialized
INFO - 2024-02-06 15:55:36 --> Output Class Initialized
INFO - 2024-02-06 15:55:36 --> Security Class Initialized
DEBUG - 2024-02-06 15:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:55:36 --> Input Class Initialized
INFO - 2024-02-06 15:55:36 --> Language Class Initialized
INFO - 2024-02-06 15:55:36 --> Loader Class Initialized
INFO - 2024-02-06 15:55:36 --> Helper loaded: url_helper
INFO - 2024-02-06 15:55:36 --> Helper loaded: file_helper
INFO - 2024-02-06 15:55:36 --> Helper loaded: html_helper
INFO - 2024-02-06 15:55:36 --> Helper loaded: text_helper
INFO - 2024-02-06 15:55:36 --> Helper loaded: form_helper
INFO - 2024-02-06 15:55:36 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:55:36 --> Helper loaded: security_helper
INFO - 2024-02-06 15:55:36 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:55:36 --> Database Driver Class Initialized
INFO - 2024-02-06 15:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:55:36 --> Parser Class Initialized
INFO - 2024-02-06 15:55:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:55:36 --> Pagination Class Initialized
INFO - 2024-02-06 15:55:36 --> Form Validation Class Initialized
INFO - 2024-02-06 15:55:36 --> Controller Class Initialized
DEBUG - 2024-02-06 15:55:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:55:36 --> Model Class Initialized
DEBUG - 2024-02-06 15:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:55:36 --> Model Class Initialized
DEBUG - 2024-02-06 15:55:36 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:55:36 --> Model Class Initialized
INFO - 2024-02-06 15:55:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2024-02-06 15:55:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:55:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:55:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:55:36 --> Model Class Initialized
INFO - 2024-02-06 15:55:36 --> Model Class Initialized
INFO - 2024-02-06 15:55:36 --> Model Class Initialized
INFO - 2024-02-06 15:55:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:55:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:55:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:55:36 --> Final output sent to browser
DEBUG - 2024-02-06 15:55:36 --> Total execution time: 0.1426
ERROR - 2024-02-06 15:55:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:55:37 --> Config Class Initialized
INFO - 2024-02-06 15:55:37 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:55:37 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:55:37 --> Utf8 Class Initialized
INFO - 2024-02-06 15:55:37 --> URI Class Initialized
INFO - 2024-02-06 15:55:37 --> Router Class Initialized
INFO - 2024-02-06 15:55:37 --> Output Class Initialized
INFO - 2024-02-06 15:55:37 --> Security Class Initialized
DEBUG - 2024-02-06 15:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:55:37 --> Input Class Initialized
INFO - 2024-02-06 15:55:37 --> Language Class Initialized
INFO - 2024-02-06 15:55:37 --> Loader Class Initialized
INFO - 2024-02-06 15:55:37 --> Helper loaded: url_helper
INFO - 2024-02-06 15:55:37 --> Helper loaded: file_helper
INFO - 2024-02-06 15:55:37 --> Helper loaded: html_helper
INFO - 2024-02-06 15:55:37 --> Helper loaded: text_helper
INFO - 2024-02-06 15:55:37 --> Helper loaded: form_helper
INFO - 2024-02-06 15:55:37 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:55:37 --> Helper loaded: security_helper
INFO - 2024-02-06 15:55:37 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:55:37 --> Database Driver Class Initialized
INFO - 2024-02-06 15:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:55:37 --> Parser Class Initialized
INFO - 2024-02-06 15:55:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:55:37 --> Pagination Class Initialized
INFO - 2024-02-06 15:55:37 --> Form Validation Class Initialized
INFO - 2024-02-06 15:55:37 --> Controller Class Initialized
DEBUG - 2024-02-06 15:55:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:55:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:55:37 --> Model Class Initialized
DEBUG - 2024-02-06 15:55:37 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:55:37 --> Model Class Initialized
INFO - 2024-02-06 15:55:37 --> Final output sent to browser
DEBUG - 2024-02-06 15:55:37 --> Total execution time: 0.0209
ERROR - 2024-02-06 15:55:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:55:40 --> Config Class Initialized
INFO - 2024-02-06 15:55:40 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:55:40 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:55:40 --> Utf8 Class Initialized
INFO - 2024-02-06 15:55:40 --> URI Class Initialized
INFO - 2024-02-06 15:55:40 --> Router Class Initialized
INFO - 2024-02-06 15:55:40 --> Output Class Initialized
INFO - 2024-02-06 15:55:40 --> Security Class Initialized
DEBUG - 2024-02-06 15:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:55:40 --> Input Class Initialized
INFO - 2024-02-06 15:55:40 --> Language Class Initialized
INFO - 2024-02-06 15:55:40 --> Loader Class Initialized
INFO - 2024-02-06 15:55:40 --> Helper loaded: url_helper
INFO - 2024-02-06 15:55:40 --> Helper loaded: file_helper
INFO - 2024-02-06 15:55:40 --> Helper loaded: html_helper
INFO - 2024-02-06 15:55:40 --> Helper loaded: text_helper
INFO - 2024-02-06 15:55:40 --> Helper loaded: form_helper
INFO - 2024-02-06 15:55:40 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:55:40 --> Helper loaded: security_helper
INFO - 2024-02-06 15:55:40 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:55:40 --> Database Driver Class Initialized
INFO - 2024-02-06 15:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:55:40 --> Parser Class Initialized
INFO - 2024-02-06 15:55:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:55:40 --> Pagination Class Initialized
INFO - 2024-02-06 15:55:40 --> Form Validation Class Initialized
INFO - 2024-02-06 15:55:40 --> Controller Class Initialized
DEBUG - 2024-02-06 15:55:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:55:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:55:40 --> Model Class Initialized
DEBUG - 2024-02-06 15:55:40 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:55:40 --> Model Class Initialized
INFO - 2024-02-06 15:55:40 --> Final output sent to browser
DEBUG - 2024-02-06 15:55:40 --> Total execution time: 0.0263
ERROR - 2024-02-06 15:55:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:55:44 --> Config Class Initialized
INFO - 2024-02-06 15:55:44 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:55:44 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:55:44 --> Utf8 Class Initialized
INFO - 2024-02-06 15:55:44 --> URI Class Initialized
DEBUG - 2024-02-06 15:55:44 --> No URI present. Default controller set.
INFO - 2024-02-06 15:55:44 --> Router Class Initialized
INFO - 2024-02-06 15:55:44 --> Output Class Initialized
INFO - 2024-02-06 15:55:44 --> Security Class Initialized
DEBUG - 2024-02-06 15:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:55:44 --> Input Class Initialized
INFO - 2024-02-06 15:55:44 --> Language Class Initialized
INFO - 2024-02-06 15:55:44 --> Loader Class Initialized
INFO - 2024-02-06 15:55:44 --> Helper loaded: url_helper
INFO - 2024-02-06 15:55:44 --> Helper loaded: file_helper
INFO - 2024-02-06 15:55:44 --> Helper loaded: html_helper
INFO - 2024-02-06 15:55:44 --> Helper loaded: text_helper
INFO - 2024-02-06 15:55:44 --> Helper loaded: form_helper
INFO - 2024-02-06 15:55:44 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:55:44 --> Helper loaded: security_helper
INFO - 2024-02-06 15:55:44 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:55:44 --> Database Driver Class Initialized
INFO - 2024-02-06 15:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:55:44 --> Parser Class Initialized
INFO - 2024-02-06 15:55:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:55:44 --> Pagination Class Initialized
INFO - 2024-02-06 15:55:44 --> Form Validation Class Initialized
INFO - 2024-02-06 15:55:44 --> Controller Class Initialized
INFO - 2024-02-06 15:55:44 --> Model Class Initialized
DEBUG - 2024-02-06 15:55:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:55:44 --> Model Class Initialized
DEBUG - 2024-02-06 15:55:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:55:44 --> Model Class Initialized
INFO - 2024-02-06 15:55:44 --> Model Class Initialized
INFO - 2024-02-06 15:55:44 --> Model Class Initialized
INFO - 2024-02-06 15:55:44 --> Model Class Initialized
DEBUG - 2024-02-06 15:55:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:55:44 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:55:44 --> Model Class Initialized
INFO - 2024-02-06 15:55:44 --> Model Class Initialized
INFO - 2024-02-06 15:55:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 15:55:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:55:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:55:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:55:44 --> Model Class Initialized
INFO - 2024-02-06 15:55:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:55:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:55:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:55:44 --> Final output sent to browser
DEBUG - 2024-02-06 15:55:44 --> Total execution time: 0.2274
ERROR - 2024-02-06 15:56:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:56:04 --> Config Class Initialized
INFO - 2024-02-06 15:56:04 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:56:04 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:56:04 --> Utf8 Class Initialized
INFO - 2024-02-06 15:56:04 --> URI Class Initialized
DEBUG - 2024-02-06 15:56:04 --> No URI present. Default controller set.
INFO - 2024-02-06 15:56:04 --> Router Class Initialized
INFO - 2024-02-06 15:56:04 --> Output Class Initialized
INFO - 2024-02-06 15:56:04 --> Security Class Initialized
DEBUG - 2024-02-06 15:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:56:04 --> Input Class Initialized
INFO - 2024-02-06 15:56:04 --> Language Class Initialized
INFO - 2024-02-06 15:56:04 --> Loader Class Initialized
INFO - 2024-02-06 15:56:04 --> Helper loaded: url_helper
INFO - 2024-02-06 15:56:04 --> Helper loaded: file_helper
INFO - 2024-02-06 15:56:04 --> Helper loaded: html_helper
INFO - 2024-02-06 15:56:04 --> Helper loaded: text_helper
INFO - 2024-02-06 15:56:04 --> Helper loaded: form_helper
INFO - 2024-02-06 15:56:04 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:56:04 --> Helper loaded: security_helper
INFO - 2024-02-06 15:56:04 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:56:04 --> Database Driver Class Initialized
INFO - 2024-02-06 15:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:56:04 --> Parser Class Initialized
INFO - 2024-02-06 15:56:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:56:04 --> Pagination Class Initialized
INFO - 2024-02-06 15:56:04 --> Form Validation Class Initialized
INFO - 2024-02-06 15:56:04 --> Controller Class Initialized
INFO - 2024-02-06 15:56:04 --> Model Class Initialized
DEBUG - 2024-02-06 15:56:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:56:04 --> Model Class Initialized
DEBUG - 2024-02-06 15:56:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:56:04 --> Model Class Initialized
INFO - 2024-02-06 15:56:04 --> Model Class Initialized
INFO - 2024-02-06 15:56:04 --> Model Class Initialized
INFO - 2024-02-06 15:56:04 --> Model Class Initialized
DEBUG - 2024-02-06 15:56:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:56:04 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:56:04 --> Model Class Initialized
INFO - 2024-02-06 15:56:04 --> Model Class Initialized
INFO - 2024-02-06 15:56:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 15:56:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:56:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:56:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:56:04 --> Model Class Initialized
INFO - 2024-02-06 15:56:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:56:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:56:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:56:04 --> Final output sent to browser
DEBUG - 2024-02-06 15:56:04 --> Total execution time: 0.2387
ERROR - 2024-02-06 15:56:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:56:25 --> Config Class Initialized
INFO - 2024-02-06 15:56:25 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:56:25 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:56:25 --> Utf8 Class Initialized
INFO - 2024-02-06 15:56:25 --> URI Class Initialized
DEBUG - 2024-02-06 15:56:25 --> No URI present. Default controller set.
INFO - 2024-02-06 15:56:25 --> Router Class Initialized
INFO - 2024-02-06 15:56:25 --> Output Class Initialized
INFO - 2024-02-06 15:56:25 --> Security Class Initialized
DEBUG - 2024-02-06 15:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:56:25 --> Input Class Initialized
INFO - 2024-02-06 15:56:25 --> Language Class Initialized
INFO - 2024-02-06 15:56:25 --> Loader Class Initialized
INFO - 2024-02-06 15:56:25 --> Helper loaded: url_helper
INFO - 2024-02-06 15:56:25 --> Helper loaded: file_helper
INFO - 2024-02-06 15:56:25 --> Helper loaded: html_helper
INFO - 2024-02-06 15:56:25 --> Helper loaded: text_helper
INFO - 2024-02-06 15:56:25 --> Helper loaded: form_helper
INFO - 2024-02-06 15:56:25 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:56:25 --> Helper loaded: security_helper
INFO - 2024-02-06 15:56:25 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:56:25 --> Database Driver Class Initialized
INFO - 2024-02-06 15:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:56:25 --> Parser Class Initialized
INFO - 2024-02-06 15:56:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:56:25 --> Pagination Class Initialized
INFO - 2024-02-06 15:56:25 --> Form Validation Class Initialized
INFO - 2024-02-06 15:56:25 --> Controller Class Initialized
INFO - 2024-02-06 15:56:25 --> Model Class Initialized
DEBUG - 2024-02-06 15:56:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:56:25 --> Model Class Initialized
DEBUG - 2024-02-06 15:56:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:56:25 --> Model Class Initialized
INFO - 2024-02-06 15:56:25 --> Model Class Initialized
INFO - 2024-02-06 15:56:25 --> Model Class Initialized
INFO - 2024-02-06 15:56:25 --> Model Class Initialized
DEBUG - 2024-02-06 15:56:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:56:25 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:56:25 --> Model Class Initialized
INFO - 2024-02-06 15:56:25 --> Model Class Initialized
INFO - 2024-02-06 15:56:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 15:56:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:56:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:56:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:56:25 --> Model Class Initialized
INFO - 2024-02-06 15:56:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:56:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:56:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:56:25 --> Final output sent to browser
DEBUG - 2024-02-06 15:56:25 --> Total execution time: 0.2193
ERROR - 2024-02-06 15:56:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:56:49 --> Config Class Initialized
INFO - 2024-02-06 15:56:49 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:56:49 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:56:49 --> Utf8 Class Initialized
INFO - 2024-02-06 15:56:49 --> URI Class Initialized
DEBUG - 2024-02-06 15:56:49 --> No URI present. Default controller set.
INFO - 2024-02-06 15:56:49 --> Router Class Initialized
INFO - 2024-02-06 15:56:49 --> Output Class Initialized
INFO - 2024-02-06 15:56:49 --> Security Class Initialized
DEBUG - 2024-02-06 15:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:56:49 --> Input Class Initialized
INFO - 2024-02-06 15:56:49 --> Language Class Initialized
INFO - 2024-02-06 15:56:49 --> Loader Class Initialized
INFO - 2024-02-06 15:56:49 --> Helper loaded: url_helper
INFO - 2024-02-06 15:56:49 --> Helper loaded: file_helper
INFO - 2024-02-06 15:56:49 --> Helper loaded: html_helper
INFO - 2024-02-06 15:56:49 --> Helper loaded: text_helper
INFO - 2024-02-06 15:56:50 --> Helper loaded: form_helper
INFO - 2024-02-06 15:56:50 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:56:50 --> Helper loaded: security_helper
INFO - 2024-02-06 15:56:50 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:56:50 --> Database Driver Class Initialized
INFO - 2024-02-06 15:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:56:50 --> Parser Class Initialized
INFO - 2024-02-06 15:56:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:56:50 --> Pagination Class Initialized
INFO - 2024-02-06 15:56:50 --> Form Validation Class Initialized
INFO - 2024-02-06 15:56:50 --> Controller Class Initialized
INFO - 2024-02-06 15:56:50 --> Model Class Initialized
DEBUG - 2024-02-06 15:56:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:56:50 --> Model Class Initialized
DEBUG - 2024-02-06 15:56:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:56:50 --> Model Class Initialized
INFO - 2024-02-06 15:56:50 --> Model Class Initialized
INFO - 2024-02-06 15:56:50 --> Model Class Initialized
INFO - 2024-02-06 15:56:50 --> Model Class Initialized
DEBUG - 2024-02-06 15:56:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:56:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:56:50 --> Model Class Initialized
INFO - 2024-02-06 15:56:50 --> Model Class Initialized
INFO - 2024-02-06 15:56:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 15:56:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:56:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:56:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:56:50 --> Model Class Initialized
INFO - 2024-02-06 15:56:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:56:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:56:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:56:50 --> Final output sent to browser
DEBUG - 2024-02-06 15:56:50 --> Total execution time: 0.2186
ERROR - 2024-02-06 15:57:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:57:23 --> Config Class Initialized
INFO - 2024-02-06 15:57:23 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:57:23 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:57:23 --> Utf8 Class Initialized
INFO - 2024-02-06 15:57:23 --> URI Class Initialized
DEBUG - 2024-02-06 15:57:23 --> No URI present. Default controller set.
INFO - 2024-02-06 15:57:23 --> Router Class Initialized
INFO - 2024-02-06 15:57:23 --> Output Class Initialized
INFO - 2024-02-06 15:57:23 --> Security Class Initialized
DEBUG - 2024-02-06 15:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:57:23 --> Input Class Initialized
INFO - 2024-02-06 15:57:23 --> Language Class Initialized
INFO - 2024-02-06 15:57:23 --> Loader Class Initialized
INFO - 2024-02-06 15:57:23 --> Helper loaded: url_helper
INFO - 2024-02-06 15:57:23 --> Helper loaded: file_helper
INFO - 2024-02-06 15:57:23 --> Helper loaded: html_helper
INFO - 2024-02-06 15:57:23 --> Helper loaded: text_helper
INFO - 2024-02-06 15:57:23 --> Helper loaded: form_helper
INFO - 2024-02-06 15:57:23 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:57:23 --> Helper loaded: security_helper
INFO - 2024-02-06 15:57:23 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:57:23 --> Database Driver Class Initialized
INFO - 2024-02-06 15:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:57:23 --> Parser Class Initialized
INFO - 2024-02-06 15:57:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:57:23 --> Pagination Class Initialized
INFO - 2024-02-06 15:57:23 --> Form Validation Class Initialized
INFO - 2024-02-06 15:57:23 --> Controller Class Initialized
INFO - 2024-02-06 15:57:23 --> Model Class Initialized
DEBUG - 2024-02-06 15:57:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:57:23 --> Model Class Initialized
DEBUG - 2024-02-06 15:57:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:57:23 --> Model Class Initialized
INFO - 2024-02-06 15:57:23 --> Model Class Initialized
INFO - 2024-02-06 15:57:23 --> Model Class Initialized
INFO - 2024-02-06 15:57:23 --> Model Class Initialized
DEBUG - 2024-02-06 15:57:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:57:23 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:57:23 --> Model Class Initialized
INFO - 2024-02-06 15:57:23 --> Model Class Initialized
INFO - 2024-02-06 15:57:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 15:57:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:57:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:57:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:57:23 --> Model Class Initialized
INFO - 2024-02-06 15:57:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:57:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:57:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:57:23 --> Final output sent to browser
DEBUG - 2024-02-06 15:57:23 --> Total execution time: 0.2283
ERROR - 2024-02-06 15:57:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:57:32 --> Config Class Initialized
INFO - 2024-02-06 15:57:32 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:57:32 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:57:32 --> Utf8 Class Initialized
INFO - 2024-02-06 15:57:32 --> URI Class Initialized
INFO - 2024-02-06 15:57:32 --> Router Class Initialized
INFO - 2024-02-06 15:57:32 --> Output Class Initialized
INFO - 2024-02-06 15:57:32 --> Security Class Initialized
DEBUG - 2024-02-06 15:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:57:32 --> Input Class Initialized
INFO - 2024-02-06 15:57:32 --> Language Class Initialized
INFO - 2024-02-06 15:57:32 --> Loader Class Initialized
INFO - 2024-02-06 15:57:32 --> Helper loaded: url_helper
INFO - 2024-02-06 15:57:32 --> Helper loaded: file_helper
INFO - 2024-02-06 15:57:32 --> Helper loaded: html_helper
INFO - 2024-02-06 15:57:32 --> Helper loaded: text_helper
INFO - 2024-02-06 15:57:32 --> Helper loaded: form_helper
INFO - 2024-02-06 15:57:32 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:57:32 --> Helper loaded: security_helper
INFO - 2024-02-06 15:57:32 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:57:32 --> Database Driver Class Initialized
INFO - 2024-02-06 15:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:57:32 --> Parser Class Initialized
INFO - 2024-02-06 15:57:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:57:32 --> Pagination Class Initialized
INFO - 2024-02-06 15:57:32 --> Form Validation Class Initialized
INFO - 2024-02-06 15:57:32 --> Controller Class Initialized
INFO - 2024-02-06 15:57:32 --> Model Class Initialized
DEBUG - 2024-02-06 15:57:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:57:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:57:32 --> Model Class Initialized
DEBUG - 2024-02-06 15:57:32 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:57:32 --> Model Class Initialized
INFO - 2024-02-06 15:57:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2024-02-06 15:57:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:57:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:57:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:57:32 --> Model Class Initialized
INFO - 2024-02-06 15:57:32 --> Model Class Initialized
INFO - 2024-02-06 15:57:32 --> Model Class Initialized
INFO - 2024-02-06 15:57:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:57:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:57:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:57:32 --> Final output sent to browser
DEBUG - 2024-02-06 15:57:32 --> Total execution time: 0.1694
ERROR - 2024-02-06 15:57:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:57:33 --> Config Class Initialized
INFO - 2024-02-06 15:57:33 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:57:33 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:57:33 --> Utf8 Class Initialized
INFO - 2024-02-06 15:57:33 --> URI Class Initialized
INFO - 2024-02-06 15:57:33 --> Router Class Initialized
INFO - 2024-02-06 15:57:33 --> Output Class Initialized
INFO - 2024-02-06 15:57:33 --> Security Class Initialized
DEBUG - 2024-02-06 15:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:57:33 --> Input Class Initialized
INFO - 2024-02-06 15:57:33 --> Language Class Initialized
INFO - 2024-02-06 15:57:33 --> Loader Class Initialized
INFO - 2024-02-06 15:57:33 --> Helper loaded: url_helper
INFO - 2024-02-06 15:57:33 --> Helper loaded: file_helper
INFO - 2024-02-06 15:57:33 --> Helper loaded: html_helper
INFO - 2024-02-06 15:57:33 --> Helper loaded: text_helper
INFO - 2024-02-06 15:57:33 --> Helper loaded: form_helper
INFO - 2024-02-06 15:57:33 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:57:33 --> Helper loaded: security_helper
INFO - 2024-02-06 15:57:33 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:57:33 --> Database Driver Class Initialized
INFO - 2024-02-06 15:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:57:33 --> Parser Class Initialized
INFO - 2024-02-06 15:57:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:57:33 --> Pagination Class Initialized
INFO - 2024-02-06 15:57:33 --> Form Validation Class Initialized
INFO - 2024-02-06 15:57:33 --> Controller Class Initialized
INFO - 2024-02-06 15:57:33 --> Model Class Initialized
DEBUG - 2024-02-06 15:57:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:57:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:57:33 --> Model Class Initialized
DEBUG - 2024-02-06 15:57:33 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:57:33 --> Model Class Initialized
INFO - 2024-02-06 15:57:33 --> Final output sent to browser
DEBUG - 2024-02-06 15:57:33 --> Total execution time: 0.0393
ERROR - 2024-02-06 15:57:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:57:36 --> Config Class Initialized
INFO - 2024-02-06 15:57:36 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:57:36 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:57:36 --> Utf8 Class Initialized
INFO - 2024-02-06 15:57:36 --> URI Class Initialized
INFO - 2024-02-06 15:57:36 --> Router Class Initialized
INFO - 2024-02-06 15:57:36 --> Output Class Initialized
INFO - 2024-02-06 15:57:36 --> Security Class Initialized
DEBUG - 2024-02-06 15:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:57:36 --> Input Class Initialized
INFO - 2024-02-06 15:57:36 --> Language Class Initialized
INFO - 2024-02-06 15:57:36 --> Loader Class Initialized
INFO - 2024-02-06 15:57:36 --> Helper loaded: url_helper
INFO - 2024-02-06 15:57:36 --> Helper loaded: file_helper
INFO - 2024-02-06 15:57:36 --> Helper loaded: html_helper
INFO - 2024-02-06 15:57:36 --> Helper loaded: text_helper
INFO - 2024-02-06 15:57:36 --> Helper loaded: form_helper
INFO - 2024-02-06 15:57:36 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:57:36 --> Helper loaded: security_helper
INFO - 2024-02-06 15:57:36 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:57:36 --> Database Driver Class Initialized
INFO - 2024-02-06 15:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:57:36 --> Parser Class Initialized
INFO - 2024-02-06 15:57:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:57:36 --> Pagination Class Initialized
INFO - 2024-02-06 15:57:36 --> Form Validation Class Initialized
INFO - 2024-02-06 15:57:36 --> Controller Class Initialized
INFO - 2024-02-06 15:57:36 --> Model Class Initialized
DEBUG - 2024-02-06 15:57:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:57:36 --> Model Class Initialized
DEBUG - 2024-02-06 15:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:57:36 --> Model Class Initialized
INFO - 2024-02-06 15:57:36 --> Final output sent to browser
DEBUG - 2024-02-06 15:57:36 --> Total execution time: 0.1293
ERROR - 2024-02-06 15:58:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:58:50 --> Config Class Initialized
INFO - 2024-02-06 15:58:50 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:58:50 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:58:50 --> Utf8 Class Initialized
INFO - 2024-02-06 15:58:50 --> URI Class Initialized
DEBUG - 2024-02-06 15:58:50 --> No URI present. Default controller set.
INFO - 2024-02-06 15:58:50 --> Router Class Initialized
INFO - 2024-02-06 15:58:50 --> Output Class Initialized
INFO - 2024-02-06 15:58:50 --> Security Class Initialized
DEBUG - 2024-02-06 15:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:58:50 --> Input Class Initialized
INFO - 2024-02-06 15:58:50 --> Language Class Initialized
INFO - 2024-02-06 15:58:50 --> Loader Class Initialized
INFO - 2024-02-06 15:58:50 --> Helper loaded: url_helper
INFO - 2024-02-06 15:58:50 --> Helper loaded: file_helper
INFO - 2024-02-06 15:58:50 --> Helper loaded: html_helper
INFO - 2024-02-06 15:58:50 --> Helper loaded: text_helper
INFO - 2024-02-06 15:58:50 --> Helper loaded: form_helper
INFO - 2024-02-06 15:58:50 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:58:50 --> Helper loaded: security_helper
INFO - 2024-02-06 15:58:50 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:58:50 --> Database Driver Class Initialized
INFO - 2024-02-06 15:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:58:50 --> Parser Class Initialized
INFO - 2024-02-06 15:58:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:58:50 --> Pagination Class Initialized
INFO - 2024-02-06 15:58:50 --> Form Validation Class Initialized
INFO - 2024-02-06 15:58:50 --> Controller Class Initialized
INFO - 2024-02-06 15:58:50 --> Model Class Initialized
DEBUG - 2024-02-06 15:58:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:58:50 --> Model Class Initialized
DEBUG - 2024-02-06 15:58:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:58:50 --> Model Class Initialized
INFO - 2024-02-06 15:58:50 --> Model Class Initialized
INFO - 2024-02-06 15:58:50 --> Model Class Initialized
INFO - 2024-02-06 15:58:50 --> Model Class Initialized
DEBUG - 2024-02-06 15:58:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:58:50 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:58:50 --> Model Class Initialized
INFO - 2024-02-06 15:58:50 --> Model Class Initialized
INFO - 2024-02-06 15:58:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 15:58:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:58:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:58:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:58:50 --> Model Class Initialized
INFO - 2024-02-06 15:58:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:58:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:58:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:58:50 --> Final output sent to browser
DEBUG - 2024-02-06 15:58:50 --> Total execution time: 0.2235
ERROR - 2024-02-06 15:59:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 15:59:05 --> Config Class Initialized
INFO - 2024-02-06 15:59:05 --> Hooks Class Initialized
DEBUG - 2024-02-06 15:59:05 --> UTF-8 Support Enabled
INFO - 2024-02-06 15:59:05 --> Utf8 Class Initialized
INFO - 2024-02-06 15:59:05 --> URI Class Initialized
DEBUG - 2024-02-06 15:59:05 --> No URI present. Default controller set.
INFO - 2024-02-06 15:59:05 --> Router Class Initialized
INFO - 2024-02-06 15:59:05 --> Output Class Initialized
INFO - 2024-02-06 15:59:05 --> Security Class Initialized
DEBUG - 2024-02-06 15:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 15:59:05 --> Input Class Initialized
INFO - 2024-02-06 15:59:05 --> Language Class Initialized
INFO - 2024-02-06 15:59:05 --> Loader Class Initialized
INFO - 2024-02-06 15:59:05 --> Helper loaded: url_helper
INFO - 2024-02-06 15:59:05 --> Helper loaded: file_helper
INFO - 2024-02-06 15:59:05 --> Helper loaded: html_helper
INFO - 2024-02-06 15:59:05 --> Helper loaded: text_helper
INFO - 2024-02-06 15:59:05 --> Helper loaded: form_helper
INFO - 2024-02-06 15:59:05 --> Helper loaded: lang_helper
INFO - 2024-02-06 15:59:05 --> Helper loaded: security_helper
INFO - 2024-02-06 15:59:05 --> Helper loaded: cookie_helper
INFO - 2024-02-06 15:59:05 --> Database Driver Class Initialized
INFO - 2024-02-06 15:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 15:59:05 --> Parser Class Initialized
INFO - 2024-02-06 15:59:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 15:59:05 --> Pagination Class Initialized
INFO - 2024-02-06 15:59:05 --> Form Validation Class Initialized
INFO - 2024-02-06 15:59:05 --> Controller Class Initialized
INFO - 2024-02-06 15:59:05 --> Model Class Initialized
DEBUG - 2024-02-06 15:59:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:59:05 --> Model Class Initialized
DEBUG - 2024-02-06 15:59:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:59:05 --> Model Class Initialized
INFO - 2024-02-06 15:59:05 --> Model Class Initialized
INFO - 2024-02-06 15:59:05 --> Model Class Initialized
INFO - 2024-02-06 15:59:05 --> Model Class Initialized
DEBUG - 2024-02-06 15:59:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2024-02-06 15:59:05 --> Session class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:59:05 --> Model Class Initialized
INFO - 2024-02-06 15:59:05 --> Model Class Initialized
INFO - 2024-02-06 15:59:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2024-02-06 15:59:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2024-02-06 15:59:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2024-02-06 15:59:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2024-02-06 15:59:05 --> Model Class Initialized
INFO - 2024-02-06 15:59:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2024-02-06 15:59:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2024-02-06 15:59:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2024-02-06 15:59:06 --> Final output sent to browser
DEBUG - 2024-02-06 15:59:06 --> Total execution time: 0.2224
ERROR - 2024-02-06 17:50:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2024-02-06 17:50:10 --> Config Class Initialized
INFO - 2024-02-06 17:50:10 --> Hooks Class Initialized
DEBUG - 2024-02-06 17:50:10 --> UTF-8 Support Enabled
INFO - 2024-02-06 17:50:10 --> Utf8 Class Initialized
INFO - 2024-02-06 17:50:10 --> URI Class Initialized
DEBUG - 2024-02-06 17:50:10 --> No URI present. Default controller set.
INFO - 2024-02-06 17:50:10 --> Router Class Initialized
INFO - 2024-02-06 17:50:10 --> Output Class Initialized
INFO - 2024-02-06 17:50:10 --> Security Class Initialized
DEBUG - 2024-02-06 17:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 17:50:10 --> Input Class Initialized
INFO - 2024-02-06 17:50:10 --> Language Class Initialized
INFO - 2024-02-06 17:50:10 --> Loader Class Initialized
INFO - 2024-02-06 17:50:10 --> Helper loaded: url_helper
INFO - 2024-02-06 17:50:10 --> Helper loaded: file_helper
INFO - 2024-02-06 17:50:10 --> Helper loaded: html_helper
INFO - 2024-02-06 17:50:10 --> Helper loaded: text_helper
INFO - 2024-02-06 17:50:10 --> Helper loaded: form_helper
INFO - 2024-02-06 17:50:10 --> Helper loaded: lang_helper
INFO - 2024-02-06 17:50:10 --> Helper loaded: security_helper
INFO - 2024-02-06 17:50:10 --> Helper loaded: cookie_helper
INFO - 2024-02-06 17:50:10 --> Database Driver Class Initialized
INFO - 2024-02-06 17:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 17:50:10 --> Parser Class Initialized
INFO - 2024-02-06 17:50:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-02-06 17:50:10 --> Pagination Class Initialized
INFO - 2024-02-06 17:50:10 --> Form Validation Class Initialized
INFO - 2024-02-06 17:50:10 --> Controller Class Initialized
INFO - 2024-02-06 17:50:10 --> Model Class Initialized
DEBUG - 2024-02-06 17:50:10 --> Session class already loaded. Second attempt ignored.
