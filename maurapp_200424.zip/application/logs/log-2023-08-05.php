<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-05 01:01:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 01:01:45 --> Config Class Initialized
INFO - 2023-08-05 01:01:45 --> Hooks Class Initialized
DEBUG - 2023-08-05 01:01:45 --> UTF-8 Support Enabled
INFO - 2023-08-05 01:01:45 --> Utf8 Class Initialized
INFO - 2023-08-05 01:01:45 --> URI Class Initialized
DEBUG - 2023-08-05 01:01:45 --> No URI present. Default controller set.
INFO - 2023-08-05 01:01:45 --> Router Class Initialized
INFO - 2023-08-05 01:01:45 --> Output Class Initialized
INFO - 2023-08-05 01:01:45 --> Security Class Initialized
DEBUG - 2023-08-05 01:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 01:01:45 --> Input Class Initialized
INFO - 2023-08-05 01:01:45 --> Language Class Initialized
INFO - 2023-08-05 01:01:45 --> Loader Class Initialized
INFO - 2023-08-05 01:01:45 --> Helper loaded: url_helper
INFO - 2023-08-05 01:01:45 --> Helper loaded: file_helper
INFO - 2023-08-05 01:01:45 --> Helper loaded: html_helper
INFO - 2023-08-05 01:01:45 --> Helper loaded: text_helper
INFO - 2023-08-05 01:01:45 --> Helper loaded: form_helper
INFO - 2023-08-05 01:01:45 --> Helper loaded: lang_helper
INFO - 2023-08-05 01:01:45 --> Helper loaded: security_helper
INFO - 2023-08-05 01:01:45 --> Helper loaded: cookie_helper
INFO - 2023-08-05 01:01:45 --> Database Driver Class Initialized
INFO - 2023-08-05 01:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 01:01:45 --> Parser Class Initialized
INFO - 2023-08-05 01:01:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 01:01:45 --> Pagination Class Initialized
INFO - 2023-08-05 01:01:45 --> Form Validation Class Initialized
INFO - 2023-08-05 01:01:45 --> Controller Class Initialized
INFO - 2023-08-05 01:01:45 --> Model Class Initialized
DEBUG - 2023-08-05 01:01:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-05 06:02:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 06:02:08 --> Config Class Initialized
INFO - 2023-08-05 06:02:08 --> Hooks Class Initialized
DEBUG - 2023-08-05 06:02:08 --> UTF-8 Support Enabled
INFO - 2023-08-05 06:02:08 --> Utf8 Class Initialized
INFO - 2023-08-05 06:02:08 --> URI Class Initialized
DEBUG - 2023-08-05 06:02:08 --> No URI present. Default controller set.
INFO - 2023-08-05 06:02:08 --> Router Class Initialized
INFO - 2023-08-05 06:02:08 --> Output Class Initialized
INFO - 2023-08-05 06:02:08 --> Security Class Initialized
DEBUG - 2023-08-05 06:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 06:02:08 --> Input Class Initialized
INFO - 2023-08-05 06:02:08 --> Language Class Initialized
INFO - 2023-08-05 06:02:08 --> Loader Class Initialized
INFO - 2023-08-05 06:02:08 --> Helper loaded: url_helper
INFO - 2023-08-05 06:02:08 --> Helper loaded: file_helper
INFO - 2023-08-05 06:02:08 --> Helper loaded: html_helper
INFO - 2023-08-05 06:02:08 --> Helper loaded: text_helper
INFO - 2023-08-05 06:02:08 --> Helper loaded: form_helper
INFO - 2023-08-05 06:02:08 --> Helper loaded: lang_helper
INFO - 2023-08-05 06:02:08 --> Helper loaded: security_helper
INFO - 2023-08-05 06:02:08 --> Helper loaded: cookie_helper
INFO - 2023-08-05 06:02:08 --> Database Driver Class Initialized
INFO - 2023-08-05 06:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 06:02:08 --> Parser Class Initialized
INFO - 2023-08-05 06:02:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 06:02:08 --> Pagination Class Initialized
INFO - 2023-08-05 06:02:08 --> Form Validation Class Initialized
INFO - 2023-08-05 06:02:08 --> Controller Class Initialized
INFO - 2023-08-05 06:02:08 --> Model Class Initialized
DEBUG - 2023-08-05 06:02:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-05 06:02:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 06:02:25 --> Config Class Initialized
INFO - 2023-08-05 06:02:25 --> Hooks Class Initialized
DEBUG - 2023-08-05 06:02:25 --> UTF-8 Support Enabled
INFO - 2023-08-05 06:02:25 --> Utf8 Class Initialized
INFO - 2023-08-05 06:02:25 --> URI Class Initialized
INFO - 2023-08-05 06:02:25 --> Router Class Initialized
INFO - 2023-08-05 06:02:25 --> Output Class Initialized
INFO - 2023-08-05 06:02:25 --> Security Class Initialized
DEBUG - 2023-08-05 06:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 06:02:25 --> Input Class Initialized
INFO - 2023-08-05 06:02:25 --> Language Class Initialized
INFO - 2023-08-05 06:02:25 --> Loader Class Initialized
INFO - 2023-08-05 06:02:25 --> Helper loaded: url_helper
INFO - 2023-08-05 06:02:25 --> Helper loaded: file_helper
INFO - 2023-08-05 06:02:25 --> Helper loaded: html_helper
INFO - 2023-08-05 06:02:25 --> Helper loaded: text_helper
INFO - 2023-08-05 06:02:25 --> Helper loaded: form_helper
INFO - 2023-08-05 06:02:25 --> Helper loaded: lang_helper
INFO - 2023-08-05 06:02:25 --> Helper loaded: security_helper
INFO - 2023-08-05 06:02:25 --> Helper loaded: cookie_helper
INFO - 2023-08-05 06:02:25 --> Database Driver Class Initialized
INFO - 2023-08-05 06:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 06:02:25 --> Parser Class Initialized
INFO - 2023-08-05 06:02:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 06:02:25 --> Pagination Class Initialized
INFO - 2023-08-05 06:02:25 --> Form Validation Class Initialized
INFO - 2023-08-05 06:02:25 --> Controller Class Initialized
INFO - 2023-08-05 06:02:25 --> Model Class Initialized
DEBUG - 2023-08-05 06:02:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:02:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-05 06:02:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:02:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 06:02:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 06:02:25 --> Model Class Initialized
INFO - 2023-08-05 06:02:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 06:02:25 --> Final output sent to browser
DEBUG - 2023-08-05 06:02:25 --> Total execution time: 0.0398
ERROR - 2023-08-05 06:02:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 06:02:45 --> Config Class Initialized
INFO - 2023-08-05 06:02:45 --> Hooks Class Initialized
DEBUG - 2023-08-05 06:02:45 --> UTF-8 Support Enabled
INFO - 2023-08-05 06:02:45 --> Utf8 Class Initialized
INFO - 2023-08-05 06:02:45 --> URI Class Initialized
DEBUG - 2023-08-05 06:02:45 --> No URI present. Default controller set.
INFO - 2023-08-05 06:02:45 --> Router Class Initialized
INFO - 2023-08-05 06:02:45 --> Output Class Initialized
INFO - 2023-08-05 06:02:45 --> Security Class Initialized
DEBUG - 2023-08-05 06:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 06:02:45 --> Input Class Initialized
INFO - 2023-08-05 06:02:45 --> Language Class Initialized
INFO - 2023-08-05 06:02:45 --> Loader Class Initialized
INFO - 2023-08-05 06:02:45 --> Helper loaded: url_helper
INFO - 2023-08-05 06:02:45 --> Helper loaded: file_helper
INFO - 2023-08-05 06:02:45 --> Helper loaded: html_helper
INFO - 2023-08-05 06:02:45 --> Helper loaded: text_helper
INFO - 2023-08-05 06:02:45 --> Helper loaded: form_helper
INFO - 2023-08-05 06:02:45 --> Helper loaded: lang_helper
INFO - 2023-08-05 06:02:45 --> Helper loaded: security_helper
INFO - 2023-08-05 06:02:45 --> Helper loaded: cookie_helper
INFO - 2023-08-05 06:02:45 --> Database Driver Class Initialized
INFO - 2023-08-05 06:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 06:02:45 --> Parser Class Initialized
INFO - 2023-08-05 06:02:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 06:02:45 --> Pagination Class Initialized
INFO - 2023-08-05 06:02:45 --> Form Validation Class Initialized
INFO - 2023-08-05 06:02:45 --> Controller Class Initialized
INFO - 2023-08-05 06:02:45 --> Model Class Initialized
DEBUG - 2023-08-05 06:02:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-05 06:02:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 06:02:52 --> Config Class Initialized
INFO - 2023-08-05 06:02:52 --> Hooks Class Initialized
DEBUG - 2023-08-05 06:02:52 --> UTF-8 Support Enabled
INFO - 2023-08-05 06:02:52 --> Utf8 Class Initialized
INFO - 2023-08-05 06:02:52 --> URI Class Initialized
INFO - 2023-08-05 06:02:52 --> Router Class Initialized
INFO - 2023-08-05 06:02:52 --> Output Class Initialized
INFO - 2023-08-05 06:02:52 --> Security Class Initialized
DEBUG - 2023-08-05 06:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 06:02:52 --> Input Class Initialized
INFO - 2023-08-05 06:02:52 --> Language Class Initialized
INFO - 2023-08-05 06:02:52 --> Loader Class Initialized
INFO - 2023-08-05 06:02:52 --> Helper loaded: url_helper
INFO - 2023-08-05 06:02:52 --> Helper loaded: file_helper
INFO - 2023-08-05 06:02:52 --> Helper loaded: html_helper
INFO - 2023-08-05 06:02:52 --> Helper loaded: text_helper
INFO - 2023-08-05 06:02:52 --> Helper loaded: form_helper
INFO - 2023-08-05 06:02:52 --> Helper loaded: lang_helper
INFO - 2023-08-05 06:02:52 --> Helper loaded: security_helper
INFO - 2023-08-05 06:02:52 --> Helper loaded: cookie_helper
INFO - 2023-08-05 06:02:52 --> Database Driver Class Initialized
INFO - 2023-08-05 06:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 06:02:52 --> Parser Class Initialized
INFO - 2023-08-05 06:02:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 06:02:52 --> Pagination Class Initialized
INFO - 2023-08-05 06:02:52 --> Form Validation Class Initialized
INFO - 2023-08-05 06:02:52 --> Controller Class Initialized
INFO - 2023-08-05 06:02:52 --> Model Class Initialized
DEBUG - 2023-08-05 06:02:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:02:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-05 06:02:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:02:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 06:02:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 06:02:52 --> Model Class Initialized
INFO - 2023-08-05 06:02:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 06:02:52 --> Final output sent to browser
DEBUG - 2023-08-05 06:02:52 --> Total execution time: 0.0317
ERROR - 2023-08-05 06:03:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 06:03:23 --> Config Class Initialized
INFO - 2023-08-05 06:03:23 --> Hooks Class Initialized
DEBUG - 2023-08-05 06:03:23 --> UTF-8 Support Enabled
INFO - 2023-08-05 06:03:23 --> Utf8 Class Initialized
INFO - 2023-08-05 06:03:23 --> URI Class Initialized
INFO - 2023-08-05 06:03:23 --> Router Class Initialized
INFO - 2023-08-05 06:03:23 --> Output Class Initialized
INFO - 2023-08-05 06:03:23 --> Security Class Initialized
DEBUG - 2023-08-05 06:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 06:03:23 --> Input Class Initialized
INFO - 2023-08-05 06:03:23 --> Language Class Initialized
INFO - 2023-08-05 06:03:23 --> Loader Class Initialized
INFO - 2023-08-05 06:03:23 --> Helper loaded: url_helper
INFO - 2023-08-05 06:03:23 --> Helper loaded: file_helper
INFO - 2023-08-05 06:03:23 --> Helper loaded: html_helper
INFO - 2023-08-05 06:03:23 --> Helper loaded: text_helper
INFO - 2023-08-05 06:03:23 --> Helper loaded: form_helper
INFO - 2023-08-05 06:03:23 --> Helper loaded: lang_helper
INFO - 2023-08-05 06:03:23 --> Helper loaded: security_helper
INFO - 2023-08-05 06:03:23 --> Helper loaded: cookie_helper
INFO - 2023-08-05 06:03:23 --> Database Driver Class Initialized
INFO - 2023-08-05 06:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 06:03:23 --> Parser Class Initialized
INFO - 2023-08-05 06:03:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 06:03:23 --> Pagination Class Initialized
INFO - 2023-08-05 06:03:23 --> Form Validation Class Initialized
INFO - 2023-08-05 06:03:23 --> Controller Class Initialized
INFO - 2023-08-05 06:03:23 --> Model Class Initialized
DEBUG - 2023-08-05 06:03:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:03:23 --> Model Class Initialized
INFO - 2023-08-05 06:03:23 --> Final output sent to browser
DEBUG - 2023-08-05 06:03:23 --> Total execution time: 0.0224
ERROR - 2023-08-05 06:03:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 06:03:23 --> Config Class Initialized
INFO - 2023-08-05 06:03:23 --> Hooks Class Initialized
DEBUG - 2023-08-05 06:03:23 --> UTF-8 Support Enabled
INFO - 2023-08-05 06:03:23 --> Utf8 Class Initialized
INFO - 2023-08-05 06:03:23 --> URI Class Initialized
DEBUG - 2023-08-05 06:03:23 --> No URI present. Default controller set.
INFO - 2023-08-05 06:03:23 --> Router Class Initialized
INFO - 2023-08-05 06:03:23 --> Output Class Initialized
INFO - 2023-08-05 06:03:23 --> Security Class Initialized
DEBUG - 2023-08-05 06:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 06:03:23 --> Input Class Initialized
INFO - 2023-08-05 06:03:23 --> Language Class Initialized
INFO - 2023-08-05 06:03:23 --> Loader Class Initialized
INFO - 2023-08-05 06:03:23 --> Helper loaded: url_helper
INFO - 2023-08-05 06:03:23 --> Helper loaded: file_helper
INFO - 2023-08-05 06:03:23 --> Helper loaded: html_helper
INFO - 2023-08-05 06:03:23 --> Helper loaded: text_helper
INFO - 2023-08-05 06:03:23 --> Helper loaded: form_helper
INFO - 2023-08-05 06:03:23 --> Helper loaded: lang_helper
INFO - 2023-08-05 06:03:23 --> Helper loaded: security_helper
INFO - 2023-08-05 06:03:23 --> Helper loaded: cookie_helper
INFO - 2023-08-05 06:03:23 --> Database Driver Class Initialized
INFO - 2023-08-05 06:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 06:03:23 --> Parser Class Initialized
INFO - 2023-08-05 06:03:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 06:03:23 --> Pagination Class Initialized
INFO - 2023-08-05 06:03:23 --> Form Validation Class Initialized
INFO - 2023-08-05 06:03:23 --> Controller Class Initialized
INFO - 2023-08-05 06:03:23 --> Model Class Initialized
DEBUG - 2023-08-05 06:03:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:03:23 --> Model Class Initialized
DEBUG - 2023-08-05 06:03:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:03:23 --> Model Class Initialized
INFO - 2023-08-05 06:03:23 --> Model Class Initialized
INFO - 2023-08-05 06:03:23 --> Model Class Initialized
INFO - 2023-08-05 06:03:23 --> Model Class Initialized
DEBUG - 2023-08-05 06:03:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 06:03:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:03:23 --> Model Class Initialized
INFO - 2023-08-05 06:03:23 --> Model Class Initialized
INFO - 2023-08-05 06:03:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 06:03:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:03:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 06:03:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 06:03:23 --> Model Class Initialized
INFO - 2023-08-05 06:03:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 06:03:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 06:03:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 06:03:23 --> Final output sent to browser
DEBUG - 2023-08-05 06:03:23 --> Total execution time: 0.0807
ERROR - 2023-08-05 06:03:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 06:03:37 --> Config Class Initialized
INFO - 2023-08-05 06:03:37 --> Hooks Class Initialized
DEBUG - 2023-08-05 06:03:37 --> UTF-8 Support Enabled
INFO - 2023-08-05 06:03:37 --> Utf8 Class Initialized
INFO - 2023-08-05 06:03:37 --> URI Class Initialized
INFO - 2023-08-05 06:03:37 --> Router Class Initialized
INFO - 2023-08-05 06:03:37 --> Output Class Initialized
INFO - 2023-08-05 06:03:37 --> Security Class Initialized
DEBUG - 2023-08-05 06:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 06:03:37 --> Input Class Initialized
INFO - 2023-08-05 06:03:37 --> Language Class Initialized
INFO - 2023-08-05 06:03:37 --> Loader Class Initialized
INFO - 2023-08-05 06:03:37 --> Helper loaded: url_helper
INFO - 2023-08-05 06:03:37 --> Helper loaded: file_helper
INFO - 2023-08-05 06:03:37 --> Helper loaded: html_helper
INFO - 2023-08-05 06:03:37 --> Helper loaded: text_helper
INFO - 2023-08-05 06:03:37 --> Helper loaded: form_helper
INFO - 2023-08-05 06:03:37 --> Helper loaded: lang_helper
INFO - 2023-08-05 06:03:37 --> Helper loaded: security_helper
INFO - 2023-08-05 06:03:37 --> Helper loaded: cookie_helper
INFO - 2023-08-05 06:03:37 --> Database Driver Class Initialized
INFO - 2023-08-05 06:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 06:03:37 --> Parser Class Initialized
INFO - 2023-08-05 06:03:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 06:03:37 --> Pagination Class Initialized
INFO - 2023-08-05 06:03:37 --> Form Validation Class Initialized
INFO - 2023-08-05 06:03:37 --> Controller Class Initialized
INFO - 2023-08-05 06:03:37 --> Model Class Initialized
DEBUG - 2023-08-05 06:03:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 06:03:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:03:37 --> Model Class Initialized
DEBUG - 2023-08-05 06:03:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:03:37 --> Model Class Initialized
INFO - 2023-08-05 06:03:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 06:03:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:03:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 06:03:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 06:03:37 --> Model Class Initialized
INFO - 2023-08-05 06:03:37 --> Model Class Initialized
INFO - 2023-08-05 06:03:37 --> Model Class Initialized
INFO - 2023-08-05 06:03:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 06:03:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 06:03:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 06:03:37 --> Final output sent to browser
DEBUG - 2023-08-05 06:03:37 --> Total execution time: 0.0716
ERROR - 2023-08-05 06:03:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 06:03:38 --> Config Class Initialized
INFO - 2023-08-05 06:03:38 --> Hooks Class Initialized
DEBUG - 2023-08-05 06:03:38 --> UTF-8 Support Enabled
INFO - 2023-08-05 06:03:38 --> Utf8 Class Initialized
INFO - 2023-08-05 06:03:38 --> URI Class Initialized
INFO - 2023-08-05 06:03:38 --> Router Class Initialized
INFO - 2023-08-05 06:03:38 --> Output Class Initialized
INFO - 2023-08-05 06:03:38 --> Security Class Initialized
DEBUG - 2023-08-05 06:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 06:03:38 --> Input Class Initialized
INFO - 2023-08-05 06:03:38 --> Language Class Initialized
INFO - 2023-08-05 06:03:38 --> Loader Class Initialized
INFO - 2023-08-05 06:03:38 --> Helper loaded: url_helper
INFO - 2023-08-05 06:03:38 --> Helper loaded: file_helper
INFO - 2023-08-05 06:03:38 --> Helper loaded: html_helper
INFO - 2023-08-05 06:03:38 --> Helper loaded: text_helper
INFO - 2023-08-05 06:03:38 --> Helper loaded: form_helper
INFO - 2023-08-05 06:03:38 --> Helper loaded: lang_helper
INFO - 2023-08-05 06:03:38 --> Helper loaded: security_helper
INFO - 2023-08-05 06:03:38 --> Helper loaded: cookie_helper
INFO - 2023-08-05 06:03:38 --> Database Driver Class Initialized
INFO - 2023-08-05 06:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 06:03:38 --> Parser Class Initialized
INFO - 2023-08-05 06:03:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 06:03:38 --> Pagination Class Initialized
INFO - 2023-08-05 06:03:38 --> Form Validation Class Initialized
INFO - 2023-08-05 06:03:38 --> Controller Class Initialized
INFO - 2023-08-05 06:03:38 --> Model Class Initialized
DEBUG - 2023-08-05 06:03:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 06:03:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:03:38 --> Model Class Initialized
DEBUG - 2023-08-05 06:03:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:03:38 --> Model Class Initialized
INFO - 2023-08-05 06:03:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 06:03:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:03:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 06:03:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 06:03:38 --> Model Class Initialized
INFO - 2023-08-05 06:03:38 --> Model Class Initialized
INFO - 2023-08-05 06:03:38 --> Model Class Initialized
INFO - 2023-08-05 06:03:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 06:03:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 06:03:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 06:03:38 --> Final output sent to browser
DEBUG - 2023-08-05 06:03:38 --> Total execution time: 0.0690
ERROR - 2023-08-05 06:03:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 06:03:39 --> Config Class Initialized
INFO - 2023-08-05 06:03:39 --> Hooks Class Initialized
DEBUG - 2023-08-05 06:03:39 --> UTF-8 Support Enabled
INFO - 2023-08-05 06:03:39 --> Utf8 Class Initialized
INFO - 2023-08-05 06:03:39 --> URI Class Initialized
INFO - 2023-08-05 06:03:39 --> Router Class Initialized
INFO - 2023-08-05 06:03:39 --> Output Class Initialized
INFO - 2023-08-05 06:03:39 --> Security Class Initialized
DEBUG - 2023-08-05 06:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 06:03:39 --> Input Class Initialized
INFO - 2023-08-05 06:03:39 --> Language Class Initialized
INFO - 2023-08-05 06:03:39 --> Loader Class Initialized
INFO - 2023-08-05 06:03:39 --> Helper loaded: url_helper
INFO - 2023-08-05 06:03:39 --> Helper loaded: file_helper
INFO - 2023-08-05 06:03:39 --> Helper loaded: html_helper
INFO - 2023-08-05 06:03:39 --> Helper loaded: text_helper
INFO - 2023-08-05 06:03:39 --> Helper loaded: form_helper
INFO - 2023-08-05 06:03:39 --> Helper loaded: lang_helper
INFO - 2023-08-05 06:03:39 --> Helper loaded: security_helper
INFO - 2023-08-05 06:03:39 --> Helper loaded: cookie_helper
INFO - 2023-08-05 06:03:39 --> Database Driver Class Initialized
INFO - 2023-08-05 06:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 06:03:39 --> Parser Class Initialized
INFO - 2023-08-05 06:03:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 06:03:39 --> Pagination Class Initialized
INFO - 2023-08-05 06:03:39 --> Form Validation Class Initialized
INFO - 2023-08-05 06:03:39 --> Controller Class Initialized
INFO - 2023-08-05 06:03:39 --> Model Class Initialized
DEBUG - 2023-08-05 06:03:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 06:03:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:03:39 --> Model Class Initialized
DEBUG - 2023-08-05 06:03:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:03:39 --> Model Class Initialized
INFO - 2023-08-05 06:03:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 06:03:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:03:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 06:03:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 06:03:39 --> Model Class Initialized
INFO - 2023-08-05 06:03:39 --> Model Class Initialized
INFO - 2023-08-05 06:03:39 --> Model Class Initialized
INFO - 2023-08-05 06:03:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 06:03:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 06:03:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 06:03:39 --> Final output sent to browser
DEBUG - 2023-08-05 06:03:39 --> Total execution time: 0.0684
ERROR - 2023-08-05 06:03:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 06:03:39 --> Config Class Initialized
INFO - 2023-08-05 06:03:39 --> Hooks Class Initialized
DEBUG - 2023-08-05 06:03:39 --> UTF-8 Support Enabled
INFO - 2023-08-05 06:03:39 --> Utf8 Class Initialized
INFO - 2023-08-05 06:03:39 --> URI Class Initialized
INFO - 2023-08-05 06:03:39 --> Router Class Initialized
INFO - 2023-08-05 06:03:39 --> Output Class Initialized
INFO - 2023-08-05 06:03:39 --> Security Class Initialized
DEBUG - 2023-08-05 06:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 06:03:39 --> Input Class Initialized
INFO - 2023-08-05 06:03:39 --> Language Class Initialized
INFO - 2023-08-05 06:03:39 --> Loader Class Initialized
INFO - 2023-08-05 06:03:39 --> Helper loaded: url_helper
INFO - 2023-08-05 06:03:39 --> Helper loaded: file_helper
INFO - 2023-08-05 06:03:39 --> Helper loaded: html_helper
INFO - 2023-08-05 06:03:39 --> Helper loaded: text_helper
INFO - 2023-08-05 06:03:39 --> Helper loaded: form_helper
INFO - 2023-08-05 06:03:39 --> Helper loaded: lang_helper
INFO - 2023-08-05 06:03:39 --> Helper loaded: security_helper
INFO - 2023-08-05 06:03:39 --> Helper loaded: cookie_helper
INFO - 2023-08-05 06:03:39 --> Database Driver Class Initialized
INFO - 2023-08-05 06:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 06:03:39 --> Parser Class Initialized
INFO - 2023-08-05 06:03:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 06:03:39 --> Pagination Class Initialized
INFO - 2023-08-05 06:03:39 --> Form Validation Class Initialized
INFO - 2023-08-05 06:03:39 --> Controller Class Initialized
INFO - 2023-08-05 06:03:39 --> Model Class Initialized
DEBUG - 2023-08-05 06:03:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 06:03:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:03:39 --> Model Class Initialized
DEBUG - 2023-08-05 06:03:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:03:39 --> Model Class Initialized
INFO - 2023-08-05 06:03:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 06:03:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:03:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 06:03:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 06:03:39 --> Model Class Initialized
INFO - 2023-08-05 06:03:39 --> Model Class Initialized
INFO - 2023-08-05 06:03:39 --> Model Class Initialized
INFO - 2023-08-05 06:03:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 06:03:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 06:03:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 06:03:39 --> Final output sent to browser
DEBUG - 2023-08-05 06:03:39 --> Total execution time: 0.0717
ERROR - 2023-08-05 06:03:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 06:03:42 --> Config Class Initialized
INFO - 2023-08-05 06:03:42 --> Hooks Class Initialized
DEBUG - 2023-08-05 06:03:42 --> UTF-8 Support Enabled
INFO - 2023-08-05 06:03:42 --> Utf8 Class Initialized
INFO - 2023-08-05 06:03:42 --> URI Class Initialized
INFO - 2023-08-05 06:03:42 --> Router Class Initialized
INFO - 2023-08-05 06:03:42 --> Output Class Initialized
INFO - 2023-08-05 06:03:42 --> Security Class Initialized
DEBUG - 2023-08-05 06:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 06:03:42 --> Input Class Initialized
INFO - 2023-08-05 06:03:42 --> Language Class Initialized
INFO - 2023-08-05 06:03:42 --> Loader Class Initialized
INFO - 2023-08-05 06:03:42 --> Helper loaded: url_helper
INFO - 2023-08-05 06:03:42 --> Helper loaded: file_helper
INFO - 2023-08-05 06:03:42 --> Helper loaded: html_helper
INFO - 2023-08-05 06:03:42 --> Helper loaded: text_helper
INFO - 2023-08-05 06:03:42 --> Helper loaded: form_helper
INFO - 2023-08-05 06:03:42 --> Helper loaded: lang_helper
INFO - 2023-08-05 06:03:42 --> Helper loaded: security_helper
INFO - 2023-08-05 06:03:42 --> Helper loaded: cookie_helper
INFO - 2023-08-05 06:03:42 --> Database Driver Class Initialized
INFO - 2023-08-05 06:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 06:03:42 --> Parser Class Initialized
INFO - 2023-08-05 06:03:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 06:03:42 --> Pagination Class Initialized
INFO - 2023-08-05 06:03:42 --> Form Validation Class Initialized
INFO - 2023-08-05 06:03:42 --> Controller Class Initialized
INFO - 2023-08-05 06:03:42 --> Model Class Initialized
DEBUG - 2023-08-05 06:03:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 06:03:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:03:42 --> Model Class Initialized
DEBUG - 2023-08-05 06:03:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:03:42 --> Model Class Initialized
INFO - 2023-08-05 06:03:42 --> Final output sent to browser
DEBUG - 2023-08-05 06:03:42 --> Total execution time: 0.0224
ERROR - 2023-08-05 06:03:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 06:03:55 --> Config Class Initialized
INFO - 2023-08-05 06:03:55 --> Hooks Class Initialized
DEBUG - 2023-08-05 06:03:55 --> UTF-8 Support Enabled
INFO - 2023-08-05 06:03:55 --> Utf8 Class Initialized
INFO - 2023-08-05 06:03:55 --> URI Class Initialized
INFO - 2023-08-05 06:03:55 --> Router Class Initialized
INFO - 2023-08-05 06:03:55 --> Output Class Initialized
INFO - 2023-08-05 06:03:55 --> Security Class Initialized
DEBUG - 2023-08-05 06:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 06:03:55 --> Input Class Initialized
INFO - 2023-08-05 06:03:55 --> Language Class Initialized
INFO - 2023-08-05 06:03:55 --> Loader Class Initialized
INFO - 2023-08-05 06:03:55 --> Helper loaded: url_helper
INFO - 2023-08-05 06:03:55 --> Helper loaded: file_helper
INFO - 2023-08-05 06:03:55 --> Helper loaded: html_helper
INFO - 2023-08-05 06:03:55 --> Helper loaded: text_helper
INFO - 2023-08-05 06:03:55 --> Helper loaded: form_helper
INFO - 2023-08-05 06:03:55 --> Helper loaded: lang_helper
INFO - 2023-08-05 06:03:55 --> Helper loaded: security_helper
INFO - 2023-08-05 06:03:55 --> Helper loaded: cookie_helper
INFO - 2023-08-05 06:03:55 --> Database Driver Class Initialized
INFO - 2023-08-05 06:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 06:03:55 --> Parser Class Initialized
INFO - 2023-08-05 06:03:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 06:03:55 --> Pagination Class Initialized
INFO - 2023-08-05 06:03:55 --> Form Validation Class Initialized
INFO - 2023-08-05 06:03:55 --> Controller Class Initialized
INFO - 2023-08-05 06:03:55 --> Model Class Initialized
INFO - 2023-08-05 06:03:55 --> Model Class Initialized
INFO - 2023-08-05 06:03:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-08-05 06:03:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:03:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 06:03:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 06:03:55 --> Model Class Initialized
INFO - 2023-08-05 06:03:55 --> Model Class Initialized
INFO - 2023-08-05 06:03:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 06:03:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 06:03:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 06:03:55 --> Final output sent to browser
DEBUG - 2023-08-05 06:03:55 --> Total execution time: 0.0653
ERROR - 2023-08-05 06:03:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 06:03:58 --> Config Class Initialized
INFO - 2023-08-05 06:03:58 --> Hooks Class Initialized
DEBUG - 2023-08-05 06:03:58 --> UTF-8 Support Enabled
INFO - 2023-08-05 06:03:58 --> Utf8 Class Initialized
INFO - 2023-08-05 06:03:58 --> URI Class Initialized
INFO - 2023-08-05 06:03:58 --> Router Class Initialized
INFO - 2023-08-05 06:03:58 --> Output Class Initialized
INFO - 2023-08-05 06:03:58 --> Security Class Initialized
DEBUG - 2023-08-05 06:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 06:03:58 --> Input Class Initialized
INFO - 2023-08-05 06:03:58 --> Language Class Initialized
INFO - 2023-08-05 06:03:58 --> Loader Class Initialized
INFO - 2023-08-05 06:03:58 --> Helper loaded: url_helper
INFO - 2023-08-05 06:03:58 --> Helper loaded: file_helper
INFO - 2023-08-05 06:03:58 --> Helper loaded: html_helper
INFO - 2023-08-05 06:03:58 --> Helper loaded: text_helper
INFO - 2023-08-05 06:03:58 --> Helper loaded: form_helper
INFO - 2023-08-05 06:03:58 --> Helper loaded: lang_helper
INFO - 2023-08-05 06:03:58 --> Helper loaded: security_helper
INFO - 2023-08-05 06:03:58 --> Helper loaded: cookie_helper
INFO - 2023-08-05 06:03:58 --> Database Driver Class Initialized
INFO - 2023-08-05 06:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 06:03:58 --> Parser Class Initialized
INFO - 2023-08-05 06:03:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 06:03:58 --> Pagination Class Initialized
INFO - 2023-08-05 06:03:58 --> Form Validation Class Initialized
INFO - 2023-08-05 06:03:58 --> Controller Class Initialized
INFO - 2023-08-05 06:03:58 --> Model Class Initialized
INFO - 2023-08-05 06:03:58 --> Model Class Initialized
INFO - 2023-08-05 06:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-08-05 06:03:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 06:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 06:03:58 --> Model Class Initialized
INFO - 2023-08-05 06:03:58 --> Model Class Initialized
INFO - 2023-08-05 06:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 06:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 06:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 06:03:58 --> Final output sent to browser
DEBUG - 2023-08-05 06:03:58 --> Total execution time: 0.0626
ERROR - 2023-08-05 06:03:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 06:03:58 --> Config Class Initialized
INFO - 2023-08-05 06:03:58 --> Hooks Class Initialized
DEBUG - 2023-08-05 06:03:58 --> UTF-8 Support Enabled
INFO - 2023-08-05 06:03:58 --> Utf8 Class Initialized
INFO - 2023-08-05 06:03:58 --> URI Class Initialized
INFO - 2023-08-05 06:03:58 --> Router Class Initialized
INFO - 2023-08-05 06:03:58 --> Output Class Initialized
INFO - 2023-08-05 06:03:58 --> Security Class Initialized
DEBUG - 2023-08-05 06:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 06:03:58 --> Input Class Initialized
INFO - 2023-08-05 06:03:58 --> Language Class Initialized
INFO - 2023-08-05 06:03:58 --> Loader Class Initialized
INFO - 2023-08-05 06:03:58 --> Helper loaded: url_helper
INFO - 2023-08-05 06:03:58 --> Helper loaded: file_helper
INFO - 2023-08-05 06:03:58 --> Helper loaded: html_helper
INFO - 2023-08-05 06:03:58 --> Helper loaded: text_helper
INFO - 2023-08-05 06:03:58 --> Helper loaded: form_helper
INFO - 2023-08-05 06:03:58 --> Helper loaded: lang_helper
INFO - 2023-08-05 06:03:58 --> Helper loaded: security_helper
INFO - 2023-08-05 06:03:58 --> Helper loaded: cookie_helper
INFO - 2023-08-05 06:03:58 --> Database Driver Class Initialized
INFO - 2023-08-05 06:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 06:03:58 --> Parser Class Initialized
INFO - 2023-08-05 06:03:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 06:03:58 --> Pagination Class Initialized
INFO - 2023-08-05 06:03:58 --> Form Validation Class Initialized
INFO - 2023-08-05 06:03:58 --> Controller Class Initialized
INFO - 2023-08-05 06:03:58 --> Model Class Initialized
INFO - 2023-08-05 06:03:58 --> Model Class Initialized
INFO - 2023-08-05 06:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-08-05 06:03:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 06:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 06:03:58 --> Model Class Initialized
INFO - 2023-08-05 06:03:58 --> Model Class Initialized
INFO - 2023-08-05 06:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 06:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 06:03:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 06:03:58 --> Final output sent to browser
DEBUG - 2023-08-05 06:03:58 --> Total execution time: 0.0608
ERROR - 2023-08-05 06:03:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 06:03:59 --> Config Class Initialized
INFO - 2023-08-05 06:03:59 --> Hooks Class Initialized
DEBUG - 2023-08-05 06:03:59 --> UTF-8 Support Enabled
INFO - 2023-08-05 06:03:59 --> Utf8 Class Initialized
INFO - 2023-08-05 06:03:59 --> URI Class Initialized
INFO - 2023-08-05 06:03:59 --> Router Class Initialized
INFO - 2023-08-05 06:03:59 --> Output Class Initialized
INFO - 2023-08-05 06:03:59 --> Security Class Initialized
DEBUG - 2023-08-05 06:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 06:03:59 --> Input Class Initialized
INFO - 2023-08-05 06:03:59 --> Language Class Initialized
INFO - 2023-08-05 06:03:59 --> Loader Class Initialized
INFO - 2023-08-05 06:03:59 --> Helper loaded: url_helper
INFO - 2023-08-05 06:03:59 --> Helper loaded: file_helper
INFO - 2023-08-05 06:03:59 --> Helper loaded: html_helper
INFO - 2023-08-05 06:03:59 --> Helper loaded: text_helper
INFO - 2023-08-05 06:03:59 --> Helper loaded: form_helper
INFO - 2023-08-05 06:03:59 --> Helper loaded: lang_helper
INFO - 2023-08-05 06:03:59 --> Helper loaded: security_helper
INFO - 2023-08-05 06:03:59 --> Helper loaded: cookie_helper
INFO - 2023-08-05 06:03:59 --> Database Driver Class Initialized
INFO - 2023-08-05 06:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 06:03:59 --> Parser Class Initialized
INFO - 2023-08-05 06:03:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 06:03:59 --> Pagination Class Initialized
INFO - 2023-08-05 06:03:59 --> Form Validation Class Initialized
INFO - 2023-08-05 06:03:59 --> Controller Class Initialized
INFO - 2023-08-05 06:03:59 --> Model Class Initialized
INFO - 2023-08-05 06:03:59 --> Model Class Initialized
INFO - 2023-08-05 06:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-08-05 06:03:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 06:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 06:03:59 --> Model Class Initialized
INFO - 2023-08-05 06:03:59 --> Model Class Initialized
INFO - 2023-08-05 06:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 06:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 06:03:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 06:03:59 --> Final output sent to browser
DEBUG - 2023-08-05 06:03:59 --> Total execution time: 0.0653
ERROR - 2023-08-05 06:04:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 06:04:02 --> Config Class Initialized
INFO - 2023-08-05 06:04:02 --> Hooks Class Initialized
DEBUG - 2023-08-05 06:04:02 --> UTF-8 Support Enabled
INFO - 2023-08-05 06:04:02 --> Utf8 Class Initialized
INFO - 2023-08-05 06:04:02 --> URI Class Initialized
INFO - 2023-08-05 06:04:02 --> Router Class Initialized
INFO - 2023-08-05 06:04:02 --> Output Class Initialized
INFO - 2023-08-05 06:04:02 --> Security Class Initialized
DEBUG - 2023-08-05 06:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 06:04:02 --> Input Class Initialized
INFO - 2023-08-05 06:04:02 --> Language Class Initialized
INFO - 2023-08-05 06:04:02 --> Loader Class Initialized
INFO - 2023-08-05 06:04:02 --> Helper loaded: url_helper
INFO - 2023-08-05 06:04:02 --> Helper loaded: file_helper
INFO - 2023-08-05 06:04:02 --> Helper loaded: html_helper
INFO - 2023-08-05 06:04:02 --> Helper loaded: text_helper
INFO - 2023-08-05 06:04:02 --> Helper loaded: form_helper
INFO - 2023-08-05 06:04:02 --> Helper loaded: lang_helper
INFO - 2023-08-05 06:04:02 --> Helper loaded: security_helper
INFO - 2023-08-05 06:04:02 --> Helper loaded: cookie_helper
INFO - 2023-08-05 06:04:02 --> Database Driver Class Initialized
INFO - 2023-08-05 06:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 06:04:02 --> Parser Class Initialized
INFO - 2023-08-05 06:04:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 06:04:02 --> Pagination Class Initialized
INFO - 2023-08-05 06:04:02 --> Form Validation Class Initialized
INFO - 2023-08-05 06:04:02 --> Controller Class Initialized
INFO - 2023-08-05 06:04:02 --> Model Class Initialized
INFO - 2023-08-05 06:04:02 --> Model Class Initialized
INFO - 2023-08-05 06:04:02 --> Final output sent to browser
DEBUG - 2023-08-05 06:04:02 --> Total execution time: 0.0382
ERROR - 2023-08-05 06:04:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 06:04:02 --> Config Class Initialized
INFO - 2023-08-05 06:04:02 --> Hooks Class Initialized
DEBUG - 2023-08-05 06:04:02 --> UTF-8 Support Enabled
INFO - 2023-08-05 06:04:02 --> Utf8 Class Initialized
INFO - 2023-08-05 06:04:02 --> URI Class Initialized
INFO - 2023-08-05 06:04:02 --> Router Class Initialized
INFO - 2023-08-05 06:04:02 --> Output Class Initialized
INFO - 2023-08-05 06:04:02 --> Security Class Initialized
DEBUG - 2023-08-05 06:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 06:04:02 --> Input Class Initialized
INFO - 2023-08-05 06:04:02 --> Language Class Initialized
INFO - 2023-08-05 06:04:02 --> Loader Class Initialized
INFO - 2023-08-05 06:04:02 --> Helper loaded: url_helper
INFO - 2023-08-05 06:04:02 --> Helper loaded: file_helper
INFO - 2023-08-05 06:04:02 --> Helper loaded: html_helper
INFO - 2023-08-05 06:04:02 --> Helper loaded: text_helper
INFO - 2023-08-05 06:04:02 --> Helper loaded: form_helper
INFO - 2023-08-05 06:04:02 --> Helper loaded: lang_helper
INFO - 2023-08-05 06:04:02 --> Helper loaded: security_helper
INFO - 2023-08-05 06:04:02 --> Helper loaded: cookie_helper
INFO - 2023-08-05 06:04:02 --> Database Driver Class Initialized
INFO - 2023-08-05 06:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 06:04:02 --> Parser Class Initialized
INFO - 2023-08-05 06:04:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 06:04:02 --> Pagination Class Initialized
INFO - 2023-08-05 06:04:02 --> Form Validation Class Initialized
INFO - 2023-08-05 06:04:02 --> Controller Class Initialized
INFO - 2023-08-05 06:04:02 --> Model Class Initialized
DEBUG - 2023-08-05 06:04:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 06:04:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:04:02 --> Model Class Initialized
DEBUG - 2023-08-05 06:04:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:04:02 --> Model Class Initialized
INFO - 2023-08-05 06:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 06:04:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 06:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 06:04:02 --> Model Class Initialized
INFO - 2023-08-05 06:04:02 --> Model Class Initialized
INFO - 2023-08-05 06:04:02 --> Model Class Initialized
INFO - 2023-08-05 06:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 06:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 06:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 06:04:02 --> Final output sent to browser
DEBUG - 2023-08-05 06:04:02 --> Total execution time: 0.0915
ERROR - 2023-08-05 06:04:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 06:04:05 --> Config Class Initialized
INFO - 2023-08-05 06:04:05 --> Hooks Class Initialized
DEBUG - 2023-08-05 06:04:05 --> UTF-8 Support Enabled
INFO - 2023-08-05 06:04:05 --> Utf8 Class Initialized
INFO - 2023-08-05 06:04:05 --> URI Class Initialized
INFO - 2023-08-05 06:04:05 --> Router Class Initialized
INFO - 2023-08-05 06:04:05 --> Output Class Initialized
INFO - 2023-08-05 06:04:05 --> Security Class Initialized
DEBUG - 2023-08-05 06:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 06:04:05 --> Input Class Initialized
INFO - 2023-08-05 06:04:05 --> Language Class Initialized
INFO - 2023-08-05 06:04:05 --> Loader Class Initialized
INFO - 2023-08-05 06:04:05 --> Helper loaded: url_helper
INFO - 2023-08-05 06:04:05 --> Helper loaded: file_helper
INFO - 2023-08-05 06:04:05 --> Helper loaded: html_helper
INFO - 2023-08-05 06:04:05 --> Helper loaded: text_helper
INFO - 2023-08-05 06:04:05 --> Helper loaded: form_helper
INFO - 2023-08-05 06:04:05 --> Helper loaded: lang_helper
INFO - 2023-08-05 06:04:05 --> Helper loaded: security_helper
INFO - 2023-08-05 06:04:05 --> Helper loaded: cookie_helper
INFO - 2023-08-05 06:04:05 --> Database Driver Class Initialized
INFO - 2023-08-05 06:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 06:04:05 --> Parser Class Initialized
INFO - 2023-08-05 06:04:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 06:04:05 --> Pagination Class Initialized
INFO - 2023-08-05 06:04:05 --> Form Validation Class Initialized
INFO - 2023-08-05 06:04:05 --> Controller Class Initialized
INFO - 2023-08-05 06:04:05 --> Model Class Initialized
DEBUG - 2023-08-05 06:04:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 06:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:04:05 --> Model Class Initialized
DEBUG - 2023-08-05 06:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:04:05 --> Model Class Initialized
INFO - 2023-08-05 06:04:05 --> Final output sent to browser
DEBUG - 2023-08-05 06:04:05 --> Total execution time: 0.0226
ERROR - 2023-08-05 06:04:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 06:04:05 --> Config Class Initialized
INFO - 2023-08-05 06:04:05 --> Hooks Class Initialized
DEBUG - 2023-08-05 06:04:05 --> UTF-8 Support Enabled
INFO - 2023-08-05 06:04:05 --> Utf8 Class Initialized
INFO - 2023-08-05 06:04:05 --> URI Class Initialized
DEBUG - 2023-08-05 06:04:05 --> No URI present. Default controller set.
INFO - 2023-08-05 06:04:05 --> Router Class Initialized
INFO - 2023-08-05 06:04:05 --> Output Class Initialized
INFO - 2023-08-05 06:04:05 --> Security Class Initialized
DEBUG - 2023-08-05 06:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 06:04:05 --> Input Class Initialized
INFO - 2023-08-05 06:04:05 --> Language Class Initialized
INFO - 2023-08-05 06:04:05 --> Loader Class Initialized
INFO - 2023-08-05 06:04:05 --> Helper loaded: url_helper
INFO - 2023-08-05 06:04:05 --> Helper loaded: file_helper
INFO - 2023-08-05 06:04:05 --> Helper loaded: html_helper
INFO - 2023-08-05 06:04:05 --> Helper loaded: text_helper
INFO - 2023-08-05 06:04:05 --> Helper loaded: form_helper
INFO - 2023-08-05 06:04:05 --> Helper loaded: lang_helper
INFO - 2023-08-05 06:04:05 --> Helper loaded: security_helper
INFO - 2023-08-05 06:04:05 --> Helper loaded: cookie_helper
INFO - 2023-08-05 06:04:05 --> Database Driver Class Initialized
INFO - 2023-08-05 06:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 06:04:05 --> Parser Class Initialized
INFO - 2023-08-05 06:04:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 06:04:05 --> Pagination Class Initialized
INFO - 2023-08-05 06:04:05 --> Form Validation Class Initialized
INFO - 2023-08-05 06:04:05 --> Controller Class Initialized
INFO - 2023-08-05 06:04:05 --> Model Class Initialized
DEBUG - 2023-08-05 06:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:04:05 --> Model Class Initialized
DEBUG - 2023-08-05 06:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:04:05 --> Model Class Initialized
INFO - 2023-08-05 06:04:05 --> Model Class Initialized
INFO - 2023-08-05 06:04:05 --> Model Class Initialized
INFO - 2023-08-05 06:04:05 --> Model Class Initialized
DEBUG - 2023-08-05 06:04:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 06:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:04:05 --> Model Class Initialized
INFO - 2023-08-05 06:04:05 --> Model Class Initialized
INFO - 2023-08-05 06:04:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 06:04:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:04:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 06:04:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 06:04:05 --> Model Class Initialized
INFO - 2023-08-05 06:04:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 06:04:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 06:04:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 06:04:05 --> Final output sent to browser
DEBUG - 2023-08-05 06:04:05 --> Total execution time: 0.0881
ERROR - 2023-08-05 06:04:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 06:04:08 --> Config Class Initialized
INFO - 2023-08-05 06:04:08 --> Hooks Class Initialized
DEBUG - 2023-08-05 06:04:08 --> UTF-8 Support Enabled
INFO - 2023-08-05 06:04:08 --> Utf8 Class Initialized
INFO - 2023-08-05 06:04:08 --> URI Class Initialized
INFO - 2023-08-05 06:04:08 --> Router Class Initialized
INFO - 2023-08-05 06:04:08 --> Output Class Initialized
INFO - 2023-08-05 06:04:08 --> Security Class Initialized
DEBUG - 2023-08-05 06:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 06:04:08 --> Input Class Initialized
INFO - 2023-08-05 06:04:08 --> Language Class Initialized
INFO - 2023-08-05 06:04:08 --> Loader Class Initialized
INFO - 2023-08-05 06:04:08 --> Helper loaded: url_helper
INFO - 2023-08-05 06:04:08 --> Helper loaded: file_helper
INFO - 2023-08-05 06:04:08 --> Helper loaded: html_helper
INFO - 2023-08-05 06:04:08 --> Helper loaded: text_helper
INFO - 2023-08-05 06:04:08 --> Helper loaded: form_helper
INFO - 2023-08-05 06:04:08 --> Helper loaded: lang_helper
INFO - 2023-08-05 06:04:08 --> Helper loaded: security_helper
INFO - 2023-08-05 06:04:08 --> Helper loaded: cookie_helper
INFO - 2023-08-05 06:04:08 --> Database Driver Class Initialized
INFO - 2023-08-05 06:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 06:04:08 --> Parser Class Initialized
INFO - 2023-08-05 06:04:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 06:04:08 --> Pagination Class Initialized
INFO - 2023-08-05 06:04:08 --> Form Validation Class Initialized
INFO - 2023-08-05 06:04:08 --> Controller Class Initialized
INFO - 2023-08-05 06:04:08 --> Model Class Initialized
DEBUG - 2023-08-05 06:04:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:04:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-05 06:04:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:04:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 06:04:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 06:04:08 --> Model Class Initialized
INFO - 2023-08-05 06:04:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 06:04:08 --> Final output sent to browser
DEBUG - 2023-08-05 06:04:08 --> Total execution time: 0.0308
ERROR - 2023-08-05 06:04:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 06:04:09 --> Config Class Initialized
INFO - 2023-08-05 06:04:09 --> Hooks Class Initialized
DEBUG - 2023-08-05 06:04:09 --> UTF-8 Support Enabled
INFO - 2023-08-05 06:04:09 --> Utf8 Class Initialized
INFO - 2023-08-05 06:04:09 --> URI Class Initialized
INFO - 2023-08-05 06:04:09 --> Router Class Initialized
INFO - 2023-08-05 06:04:09 --> Output Class Initialized
INFO - 2023-08-05 06:04:09 --> Security Class Initialized
DEBUG - 2023-08-05 06:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 06:04:09 --> Input Class Initialized
INFO - 2023-08-05 06:04:09 --> Language Class Initialized
INFO - 2023-08-05 06:04:09 --> Loader Class Initialized
INFO - 2023-08-05 06:04:09 --> Helper loaded: url_helper
INFO - 2023-08-05 06:04:09 --> Helper loaded: file_helper
INFO - 2023-08-05 06:04:09 --> Helper loaded: html_helper
INFO - 2023-08-05 06:04:09 --> Helper loaded: text_helper
INFO - 2023-08-05 06:04:09 --> Helper loaded: form_helper
INFO - 2023-08-05 06:04:09 --> Helper loaded: lang_helper
INFO - 2023-08-05 06:04:09 --> Helper loaded: security_helper
INFO - 2023-08-05 06:04:09 --> Helper loaded: cookie_helper
INFO - 2023-08-05 06:04:09 --> Database Driver Class Initialized
INFO - 2023-08-05 06:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 06:04:09 --> Parser Class Initialized
INFO - 2023-08-05 06:04:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 06:04:09 --> Pagination Class Initialized
INFO - 2023-08-05 06:04:09 --> Form Validation Class Initialized
INFO - 2023-08-05 06:04:09 --> Controller Class Initialized
INFO - 2023-08-05 06:04:09 --> Model Class Initialized
DEBUG - 2023-08-05 06:04:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:04:09 --> Model Class Initialized
DEBUG - 2023-08-05 06:04:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:04:09 --> Model Class Initialized
INFO - 2023-08-05 06:04:09 --> Model Class Initialized
INFO - 2023-08-05 06:04:09 --> Model Class Initialized
INFO - 2023-08-05 06:04:09 --> Model Class Initialized
DEBUG - 2023-08-05 06:04:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 06:04:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:04:09 --> Model Class Initialized
INFO - 2023-08-05 06:04:09 --> Model Class Initialized
INFO - 2023-08-05 06:04:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 06:04:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 06:04:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 06:04:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 06:04:09 --> Model Class Initialized
INFO - 2023-08-05 06:04:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 06:04:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 06:04:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 06:04:09 --> Final output sent to browser
DEBUG - 2023-08-05 06:04:09 --> Total execution time: 0.0839
ERROR - 2023-08-05 10:39:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 10:39:06 --> Config Class Initialized
INFO - 2023-08-05 10:39:06 --> Hooks Class Initialized
DEBUG - 2023-08-05 10:39:06 --> UTF-8 Support Enabled
INFO - 2023-08-05 10:39:06 --> Utf8 Class Initialized
INFO - 2023-08-05 10:39:06 --> URI Class Initialized
DEBUG - 2023-08-05 10:39:06 --> No URI present. Default controller set.
INFO - 2023-08-05 10:39:06 --> Router Class Initialized
INFO - 2023-08-05 10:39:06 --> Output Class Initialized
INFO - 2023-08-05 10:39:06 --> Security Class Initialized
DEBUG - 2023-08-05 10:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 10:39:06 --> Input Class Initialized
INFO - 2023-08-05 10:39:06 --> Language Class Initialized
INFO - 2023-08-05 10:39:06 --> Loader Class Initialized
INFO - 2023-08-05 10:39:06 --> Helper loaded: url_helper
INFO - 2023-08-05 10:39:06 --> Helper loaded: file_helper
INFO - 2023-08-05 10:39:06 --> Helper loaded: html_helper
INFO - 2023-08-05 10:39:06 --> Helper loaded: text_helper
INFO - 2023-08-05 10:39:06 --> Helper loaded: form_helper
INFO - 2023-08-05 10:39:06 --> Helper loaded: lang_helper
INFO - 2023-08-05 10:39:06 --> Helper loaded: security_helper
INFO - 2023-08-05 10:39:06 --> Helper loaded: cookie_helper
INFO - 2023-08-05 10:39:06 --> Database Driver Class Initialized
INFO - 2023-08-05 10:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 10:39:06 --> Parser Class Initialized
INFO - 2023-08-05 10:39:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 10:39:06 --> Pagination Class Initialized
INFO - 2023-08-05 10:39:06 --> Form Validation Class Initialized
INFO - 2023-08-05 10:39:06 --> Controller Class Initialized
INFO - 2023-08-05 10:39:06 --> Model Class Initialized
DEBUG - 2023-08-05 10:39:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-05 10:39:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 10:39:07 --> Config Class Initialized
INFO - 2023-08-05 10:39:07 --> Hooks Class Initialized
DEBUG - 2023-08-05 10:39:07 --> UTF-8 Support Enabled
INFO - 2023-08-05 10:39:07 --> Utf8 Class Initialized
INFO - 2023-08-05 10:39:07 --> URI Class Initialized
INFO - 2023-08-05 10:39:07 --> Router Class Initialized
INFO - 2023-08-05 10:39:07 --> Output Class Initialized
INFO - 2023-08-05 10:39:07 --> Security Class Initialized
DEBUG - 2023-08-05 10:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 10:39:07 --> Input Class Initialized
INFO - 2023-08-05 10:39:07 --> Language Class Initialized
INFO - 2023-08-05 10:39:07 --> Loader Class Initialized
INFO - 2023-08-05 10:39:07 --> Helper loaded: url_helper
INFO - 2023-08-05 10:39:07 --> Helper loaded: file_helper
INFO - 2023-08-05 10:39:07 --> Helper loaded: html_helper
INFO - 2023-08-05 10:39:07 --> Helper loaded: text_helper
INFO - 2023-08-05 10:39:07 --> Helper loaded: form_helper
INFO - 2023-08-05 10:39:07 --> Helper loaded: lang_helper
INFO - 2023-08-05 10:39:07 --> Helper loaded: security_helper
INFO - 2023-08-05 10:39:07 --> Helper loaded: cookie_helper
INFO - 2023-08-05 10:39:07 --> Database Driver Class Initialized
INFO - 2023-08-05 10:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 10:39:07 --> Parser Class Initialized
INFO - 2023-08-05 10:39:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 10:39:07 --> Pagination Class Initialized
INFO - 2023-08-05 10:39:07 --> Form Validation Class Initialized
INFO - 2023-08-05 10:39:07 --> Controller Class Initialized
INFO - 2023-08-05 10:39:07 --> Model Class Initialized
DEBUG - 2023-08-05 10:39:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 10:39:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-05 10:39:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 10:39:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 10:39:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 10:39:07 --> Model Class Initialized
INFO - 2023-08-05 10:39:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 10:39:07 --> Final output sent to browser
DEBUG - 2023-08-05 10:39:07 --> Total execution time: 0.0338
ERROR - 2023-08-05 12:39:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:39:43 --> Config Class Initialized
INFO - 2023-08-05 12:39:43 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:39:43 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:39:43 --> Utf8 Class Initialized
INFO - 2023-08-05 12:39:43 --> URI Class Initialized
DEBUG - 2023-08-05 12:39:43 --> No URI present. Default controller set.
INFO - 2023-08-05 12:39:43 --> Router Class Initialized
INFO - 2023-08-05 12:39:43 --> Output Class Initialized
INFO - 2023-08-05 12:39:43 --> Security Class Initialized
DEBUG - 2023-08-05 12:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:39:43 --> Input Class Initialized
INFO - 2023-08-05 12:39:43 --> Language Class Initialized
INFO - 2023-08-05 12:39:43 --> Loader Class Initialized
INFO - 2023-08-05 12:39:43 --> Helper loaded: url_helper
INFO - 2023-08-05 12:39:43 --> Helper loaded: file_helper
INFO - 2023-08-05 12:39:43 --> Helper loaded: html_helper
INFO - 2023-08-05 12:39:43 --> Helper loaded: text_helper
INFO - 2023-08-05 12:39:43 --> Helper loaded: form_helper
INFO - 2023-08-05 12:39:43 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:39:43 --> Helper loaded: security_helper
INFO - 2023-08-05 12:39:43 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:39:43 --> Database Driver Class Initialized
INFO - 2023-08-05 12:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:39:43 --> Parser Class Initialized
INFO - 2023-08-05 12:39:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:39:43 --> Pagination Class Initialized
INFO - 2023-08-05 12:39:43 --> Form Validation Class Initialized
INFO - 2023-08-05 12:39:43 --> Controller Class Initialized
INFO - 2023-08-05 12:39:43 --> Model Class Initialized
DEBUG - 2023-08-05 12:39:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-05 12:39:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:39:43 --> Config Class Initialized
INFO - 2023-08-05 12:39:43 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:39:43 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:39:43 --> Utf8 Class Initialized
INFO - 2023-08-05 12:39:43 --> URI Class Initialized
INFO - 2023-08-05 12:39:43 --> Router Class Initialized
INFO - 2023-08-05 12:39:43 --> Output Class Initialized
INFO - 2023-08-05 12:39:43 --> Security Class Initialized
DEBUG - 2023-08-05 12:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:39:43 --> Input Class Initialized
INFO - 2023-08-05 12:39:43 --> Language Class Initialized
INFO - 2023-08-05 12:39:43 --> Loader Class Initialized
INFO - 2023-08-05 12:39:43 --> Helper loaded: url_helper
INFO - 2023-08-05 12:39:43 --> Helper loaded: file_helper
INFO - 2023-08-05 12:39:43 --> Helper loaded: html_helper
INFO - 2023-08-05 12:39:43 --> Helper loaded: text_helper
INFO - 2023-08-05 12:39:43 --> Helper loaded: form_helper
INFO - 2023-08-05 12:39:43 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:39:43 --> Helper loaded: security_helper
INFO - 2023-08-05 12:39:43 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:39:43 --> Database Driver Class Initialized
INFO - 2023-08-05 12:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:39:43 --> Parser Class Initialized
INFO - 2023-08-05 12:39:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:39:43 --> Pagination Class Initialized
INFO - 2023-08-05 12:39:43 --> Form Validation Class Initialized
INFO - 2023-08-05 12:39:43 --> Controller Class Initialized
INFO - 2023-08-05 12:39:43 --> Model Class Initialized
DEBUG - 2023-08-05 12:39:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:39:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-05 12:39:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:39:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 12:39:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 12:39:43 --> Model Class Initialized
INFO - 2023-08-05 12:39:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 12:39:43 --> Final output sent to browser
DEBUG - 2023-08-05 12:39:43 --> Total execution time: 0.0366
ERROR - 2023-08-05 12:39:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:39:47 --> Config Class Initialized
INFO - 2023-08-05 12:39:47 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:39:47 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:39:47 --> Utf8 Class Initialized
INFO - 2023-08-05 12:39:47 --> URI Class Initialized
INFO - 2023-08-05 12:39:47 --> Router Class Initialized
INFO - 2023-08-05 12:39:47 --> Output Class Initialized
INFO - 2023-08-05 12:39:47 --> Security Class Initialized
DEBUG - 2023-08-05 12:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:39:47 --> Input Class Initialized
INFO - 2023-08-05 12:39:47 --> Language Class Initialized
INFO - 2023-08-05 12:39:47 --> Loader Class Initialized
INFO - 2023-08-05 12:39:47 --> Helper loaded: url_helper
INFO - 2023-08-05 12:39:47 --> Helper loaded: file_helper
INFO - 2023-08-05 12:39:47 --> Helper loaded: html_helper
INFO - 2023-08-05 12:39:47 --> Helper loaded: text_helper
INFO - 2023-08-05 12:39:47 --> Helper loaded: form_helper
INFO - 2023-08-05 12:39:47 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:39:47 --> Helper loaded: security_helper
INFO - 2023-08-05 12:39:47 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:39:47 --> Database Driver Class Initialized
INFO - 2023-08-05 12:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:39:47 --> Parser Class Initialized
INFO - 2023-08-05 12:39:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:39:47 --> Pagination Class Initialized
INFO - 2023-08-05 12:39:47 --> Form Validation Class Initialized
INFO - 2023-08-05 12:39:47 --> Controller Class Initialized
INFO - 2023-08-05 12:39:47 --> Model Class Initialized
DEBUG - 2023-08-05 12:39:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:39:47 --> Model Class Initialized
INFO - 2023-08-05 12:39:47 --> Final output sent to browser
DEBUG - 2023-08-05 12:39:47 --> Total execution time: 0.0197
ERROR - 2023-08-05 12:39:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:39:47 --> Config Class Initialized
INFO - 2023-08-05 12:39:47 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:39:47 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:39:47 --> Utf8 Class Initialized
INFO - 2023-08-05 12:39:47 --> URI Class Initialized
DEBUG - 2023-08-05 12:39:47 --> No URI present. Default controller set.
INFO - 2023-08-05 12:39:47 --> Router Class Initialized
INFO - 2023-08-05 12:39:47 --> Output Class Initialized
INFO - 2023-08-05 12:39:47 --> Security Class Initialized
DEBUG - 2023-08-05 12:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:39:47 --> Input Class Initialized
INFO - 2023-08-05 12:39:47 --> Language Class Initialized
INFO - 2023-08-05 12:39:47 --> Loader Class Initialized
INFO - 2023-08-05 12:39:47 --> Helper loaded: url_helper
INFO - 2023-08-05 12:39:47 --> Helper loaded: file_helper
INFO - 2023-08-05 12:39:47 --> Helper loaded: html_helper
INFO - 2023-08-05 12:39:47 --> Helper loaded: text_helper
INFO - 2023-08-05 12:39:47 --> Helper loaded: form_helper
INFO - 2023-08-05 12:39:47 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:39:47 --> Helper loaded: security_helper
INFO - 2023-08-05 12:39:47 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:39:47 --> Database Driver Class Initialized
INFO - 2023-08-05 12:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:39:47 --> Parser Class Initialized
INFO - 2023-08-05 12:39:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:39:47 --> Pagination Class Initialized
INFO - 2023-08-05 12:39:47 --> Form Validation Class Initialized
INFO - 2023-08-05 12:39:47 --> Controller Class Initialized
INFO - 2023-08-05 12:39:47 --> Model Class Initialized
DEBUG - 2023-08-05 12:39:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:39:47 --> Model Class Initialized
DEBUG - 2023-08-05 12:39:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:39:47 --> Model Class Initialized
INFO - 2023-08-05 12:39:47 --> Model Class Initialized
INFO - 2023-08-05 12:39:47 --> Model Class Initialized
INFO - 2023-08-05 12:39:47 --> Model Class Initialized
DEBUG - 2023-08-05 12:39:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 12:39:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:39:47 --> Model Class Initialized
INFO - 2023-08-05 12:39:47 --> Model Class Initialized
INFO - 2023-08-05 12:39:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 12:39:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:39:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 12:39:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 12:39:47 --> Model Class Initialized
INFO - 2023-08-05 12:39:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 12:39:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 12:39:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 12:39:47 --> Final output sent to browser
DEBUG - 2023-08-05 12:39:47 --> Total execution time: 0.2042
ERROR - 2023-08-05 12:39:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:39:49 --> Config Class Initialized
INFO - 2023-08-05 12:39:49 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:39:49 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:39:49 --> Utf8 Class Initialized
INFO - 2023-08-05 12:39:49 --> URI Class Initialized
INFO - 2023-08-05 12:39:49 --> Router Class Initialized
INFO - 2023-08-05 12:39:49 --> Output Class Initialized
INFO - 2023-08-05 12:39:49 --> Security Class Initialized
DEBUG - 2023-08-05 12:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:39:49 --> Input Class Initialized
INFO - 2023-08-05 12:39:49 --> Language Class Initialized
INFO - 2023-08-05 12:39:49 --> Loader Class Initialized
INFO - 2023-08-05 12:39:49 --> Helper loaded: url_helper
INFO - 2023-08-05 12:39:49 --> Helper loaded: file_helper
INFO - 2023-08-05 12:39:49 --> Helper loaded: html_helper
INFO - 2023-08-05 12:39:49 --> Helper loaded: text_helper
INFO - 2023-08-05 12:39:49 --> Helper loaded: form_helper
INFO - 2023-08-05 12:39:49 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:39:49 --> Helper loaded: security_helper
INFO - 2023-08-05 12:39:49 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:39:49 --> Database Driver Class Initialized
INFO - 2023-08-05 12:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:39:49 --> Parser Class Initialized
INFO - 2023-08-05 12:39:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:39:49 --> Pagination Class Initialized
INFO - 2023-08-05 12:39:49 --> Form Validation Class Initialized
INFO - 2023-08-05 12:39:49 --> Controller Class Initialized
DEBUG - 2023-08-05 12:39:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 12:39:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:39:49 --> Model Class Initialized
INFO - 2023-08-05 12:39:49 --> Final output sent to browser
DEBUG - 2023-08-05 12:39:49 --> Total execution time: 0.0139
ERROR - 2023-08-05 12:40:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:40:17 --> Config Class Initialized
INFO - 2023-08-05 12:40:17 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:40:17 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:40:17 --> Utf8 Class Initialized
INFO - 2023-08-05 12:40:17 --> URI Class Initialized
INFO - 2023-08-05 12:40:17 --> Router Class Initialized
INFO - 2023-08-05 12:40:17 --> Output Class Initialized
INFO - 2023-08-05 12:40:17 --> Security Class Initialized
DEBUG - 2023-08-05 12:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:40:17 --> Input Class Initialized
INFO - 2023-08-05 12:40:17 --> Language Class Initialized
INFO - 2023-08-05 12:40:17 --> Loader Class Initialized
INFO - 2023-08-05 12:40:17 --> Helper loaded: url_helper
INFO - 2023-08-05 12:40:17 --> Helper loaded: file_helper
INFO - 2023-08-05 12:40:17 --> Helper loaded: html_helper
INFO - 2023-08-05 12:40:17 --> Helper loaded: text_helper
INFO - 2023-08-05 12:40:17 --> Helper loaded: form_helper
INFO - 2023-08-05 12:40:17 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:40:17 --> Helper loaded: security_helper
INFO - 2023-08-05 12:40:17 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:40:17 --> Database Driver Class Initialized
INFO - 2023-08-05 12:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:40:17 --> Parser Class Initialized
INFO - 2023-08-05 12:40:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:40:17 --> Pagination Class Initialized
INFO - 2023-08-05 12:40:17 --> Form Validation Class Initialized
INFO - 2023-08-05 12:40:17 --> Controller Class Initialized
INFO - 2023-08-05 12:40:17 --> Model Class Initialized
DEBUG - 2023-08-05 12:40:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 12:40:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:40:17 --> Model Class Initialized
DEBUG - 2023-08-05 12:40:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:40:17 --> Model Class Initialized
INFO - 2023-08-05 12:40:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 12:40:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:40:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 12:40:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 12:40:17 --> Model Class Initialized
INFO - 2023-08-05 12:40:17 --> Model Class Initialized
INFO - 2023-08-05 12:40:17 --> Model Class Initialized
INFO - 2023-08-05 12:40:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 12:40:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 12:40:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 12:40:17 --> Final output sent to browser
DEBUG - 2023-08-05 12:40:17 --> Total execution time: 0.1523
ERROR - 2023-08-05 12:40:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:40:18 --> Config Class Initialized
INFO - 2023-08-05 12:40:18 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:40:18 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:40:18 --> Utf8 Class Initialized
INFO - 2023-08-05 12:40:18 --> URI Class Initialized
INFO - 2023-08-05 12:40:18 --> Router Class Initialized
INFO - 2023-08-05 12:40:18 --> Output Class Initialized
INFO - 2023-08-05 12:40:18 --> Security Class Initialized
DEBUG - 2023-08-05 12:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:40:18 --> Input Class Initialized
INFO - 2023-08-05 12:40:18 --> Language Class Initialized
INFO - 2023-08-05 12:40:18 --> Loader Class Initialized
INFO - 2023-08-05 12:40:18 --> Helper loaded: url_helper
INFO - 2023-08-05 12:40:18 --> Helper loaded: file_helper
INFO - 2023-08-05 12:40:18 --> Helper loaded: html_helper
INFO - 2023-08-05 12:40:18 --> Helper loaded: text_helper
INFO - 2023-08-05 12:40:18 --> Helper loaded: form_helper
INFO - 2023-08-05 12:40:18 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:40:18 --> Helper loaded: security_helper
INFO - 2023-08-05 12:40:18 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:40:18 --> Database Driver Class Initialized
INFO - 2023-08-05 12:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:40:18 --> Parser Class Initialized
INFO - 2023-08-05 12:40:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:40:18 --> Pagination Class Initialized
INFO - 2023-08-05 12:40:18 --> Form Validation Class Initialized
INFO - 2023-08-05 12:40:18 --> Controller Class Initialized
INFO - 2023-08-05 12:40:18 --> Model Class Initialized
DEBUG - 2023-08-05 12:40:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 12:40:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:40:18 --> Model Class Initialized
DEBUG - 2023-08-05 12:40:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:40:18 --> Model Class Initialized
INFO - 2023-08-05 12:40:18 --> Final output sent to browser
DEBUG - 2023-08-05 12:40:18 --> Total execution time: 0.0625
ERROR - 2023-08-05 12:40:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:40:29 --> Config Class Initialized
INFO - 2023-08-05 12:40:29 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:40:29 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:40:29 --> Utf8 Class Initialized
INFO - 2023-08-05 12:40:29 --> URI Class Initialized
INFO - 2023-08-05 12:40:29 --> Router Class Initialized
INFO - 2023-08-05 12:40:29 --> Output Class Initialized
INFO - 2023-08-05 12:40:29 --> Security Class Initialized
DEBUG - 2023-08-05 12:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:40:29 --> Input Class Initialized
INFO - 2023-08-05 12:40:29 --> Language Class Initialized
INFO - 2023-08-05 12:40:29 --> Loader Class Initialized
INFO - 2023-08-05 12:40:29 --> Helper loaded: url_helper
INFO - 2023-08-05 12:40:29 --> Helper loaded: file_helper
INFO - 2023-08-05 12:40:29 --> Helper loaded: html_helper
INFO - 2023-08-05 12:40:29 --> Helper loaded: text_helper
INFO - 2023-08-05 12:40:29 --> Helper loaded: form_helper
INFO - 2023-08-05 12:40:29 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:40:29 --> Helper loaded: security_helper
INFO - 2023-08-05 12:40:29 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:40:29 --> Database Driver Class Initialized
INFO - 2023-08-05 12:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:40:29 --> Parser Class Initialized
INFO - 2023-08-05 12:40:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:40:29 --> Pagination Class Initialized
INFO - 2023-08-05 12:40:29 --> Form Validation Class Initialized
INFO - 2023-08-05 12:40:29 --> Controller Class Initialized
INFO - 2023-08-05 12:40:29 --> Model Class Initialized
DEBUG - 2023-08-05 12:40:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 12:40:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:40:29 --> Model Class Initialized
DEBUG - 2023-08-05 12:40:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:40:29 --> Model Class Initialized
INFO - 2023-08-05 12:40:30 --> Final output sent to browser
DEBUG - 2023-08-05 12:40:30 --> Total execution time: 0.4535
ERROR - 2023-08-05 12:40:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:40:38 --> Config Class Initialized
INFO - 2023-08-05 12:40:38 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:40:38 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:40:38 --> Utf8 Class Initialized
INFO - 2023-08-05 12:40:38 --> URI Class Initialized
INFO - 2023-08-05 12:40:38 --> Router Class Initialized
INFO - 2023-08-05 12:40:38 --> Output Class Initialized
INFO - 2023-08-05 12:40:38 --> Security Class Initialized
DEBUG - 2023-08-05 12:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:40:38 --> Input Class Initialized
INFO - 2023-08-05 12:40:38 --> Language Class Initialized
INFO - 2023-08-05 12:40:38 --> Loader Class Initialized
INFO - 2023-08-05 12:40:38 --> Helper loaded: url_helper
INFO - 2023-08-05 12:40:38 --> Helper loaded: file_helper
INFO - 2023-08-05 12:40:38 --> Helper loaded: html_helper
INFO - 2023-08-05 12:40:38 --> Helper loaded: text_helper
INFO - 2023-08-05 12:40:38 --> Helper loaded: form_helper
INFO - 2023-08-05 12:40:38 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:40:38 --> Helper loaded: security_helper
INFO - 2023-08-05 12:40:38 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:40:38 --> Database Driver Class Initialized
INFO - 2023-08-05 12:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:40:38 --> Parser Class Initialized
INFO - 2023-08-05 12:40:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:40:38 --> Pagination Class Initialized
INFO - 2023-08-05 12:40:38 --> Form Validation Class Initialized
INFO - 2023-08-05 12:40:38 --> Controller Class Initialized
DEBUG - 2023-08-05 12:40:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 12:40:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:40:38 --> Model Class Initialized
DEBUG - 2023-08-05 12:40:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:40:38 --> Model Class Initialized
DEBUG - 2023-08-05 12:40:38 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:40:38 --> Model Class Initialized
INFO - 2023-08-05 12:40:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-08-05 12:40:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:40:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 12:40:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 12:40:38 --> Model Class Initialized
INFO - 2023-08-05 12:40:38 --> Model Class Initialized
INFO - 2023-08-05 12:40:38 --> Model Class Initialized
INFO - 2023-08-05 12:40:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 12:40:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 12:40:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 12:40:38 --> Final output sent to browser
DEBUG - 2023-08-05 12:40:38 --> Total execution time: 0.1442
ERROR - 2023-08-05 12:40:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:40:39 --> Config Class Initialized
INFO - 2023-08-05 12:40:39 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:40:39 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:40:39 --> Utf8 Class Initialized
INFO - 2023-08-05 12:40:39 --> URI Class Initialized
INFO - 2023-08-05 12:40:39 --> Router Class Initialized
INFO - 2023-08-05 12:40:39 --> Output Class Initialized
INFO - 2023-08-05 12:40:39 --> Security Class Initialized
DEBUG - 2023-08-05 12:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:40:39 --> Input Class Initialized
INFO - 2023-08-05 12:40:39 --> Language Class Initialized
INFO - 2023-08-05 12:40:39 --> Loader Class Initialized
INFO - 2023-08-05 12:40:39 --> Helper loaded: url_helper
INFO - 2023-08-05 12:40:39 --> Helper loaded: file_helper
INFO - 2023-08-05 12:40:39 --> Helper loaded: html_helper
INFO - 2023-08-05 12:40:39 --> Helper loaded: text_helper
INFO - 2023-08-05 12:40:39 --> Helper loaded: form_helper
INFO - 2023-08-05 12:40:39 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:40:39 --> Helper loaded: security_helper
INFO - 2023-08-05 12:40:39 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:40:39 --> Database Driver Class Initialized
INFO - 2023-08-05 12:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:40:39 --> Parser Class Initialized
INFO - 2023-08-05 12:40:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:40:39 --> Pagination Class Initialized
INFO - 2023-08-05 12:40:39 --> Form Validation Class Initialized
INFO - 2023-08-05 12:40:39 --> Controller Class Initialized
DEBUG - 2023-08-05 12:40:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 12:40:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:40:39 --> Model Class Initialized
DEBUG - 2023-08-05 12:40:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:40:39 --> Model Class Initialized
INFO - 2023-08-05 12:40:39 --> Final output sent to browser
DEBUG - 2023-08-05 12:40:39 --> Total execution time: 0.0335
ERROR - 2023-08-05 12:40:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:40:43 --> Config Class Initialized
INFO - 2023-08-05 12:40:43 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:40:43 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:40:43 --> Utf8 Class Initialized
INFO - 2023-08-05 12:40:43 --> URI Class Initialized
INFO - 2023-08-05 12:40:43 --> Router Class Initialized
INFO - 2023-08-05 12:40:43 --> Output Class Initialized
INFO - 2023-08-05 12:40:43 --> Security Class Initialized
DEBUG - 2023-08-05 12:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:40:43 --> Input Class Initialized
INFO - 2023-08-05 12:40:43 --> Language Class Initialized
INFO - 2023-08-05 12:40:43 --> Loader Class Initialized
INFO - 2023-08-05 12:40:43 --> Helper loaded: url_helper
INFO - 2023-08-05 12:40:43 --> Helper loaded: file_helper
INFO - 2023-08-05 12:40:43 --> Helper loaded: html_helper
INFO - 2023-08-05 12:40:43 --> Helper loaded: text_helper
INFO - 2023-08-05 12:40:43 --> Helper loaded: form_helper
INFO - 2023-08-05 12:40:43 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:40:43 --> Helper loaded: security_helper
INFO - 2023-08-05 12:40:43 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:40:43 --> Database Driver Class Initialized
INFO - 2023-08-05 12:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:40:43 --> Parser Class Initialized
INFO - 2023-08-05 12:40:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:40:43 --> Pagination Class Initialized
INFO - 2023-08-05 12:40:43 --> Form Validation Class Initialized
INFO - 2023-08-05 12:40:43 --> Controller Class Initialized
DEBUG - 2023-08-05 12:40:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 12:40:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:40:43 --> Model Class Initialized
DEBUG - 2023-08-05 12:40:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:40:43 --> Model Class Initialized
INFO - 2023-08-05 12:40:43 --> Final output sent to browser
DEBUG - 2023-08-05 12:40:43 --> Total execution time: 0.1550
ERROR - 2023-08-05 12:40:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:40:53 --> Config Class Initialized
INFO - 2023-08-05 12:40:53 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:40:53 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:40:53 --> Utf8 Class Initialized
INFO - 2023-08-05 12:40:53 --> URI Class Initialized
DEBUG - 2023-08-05 12:40:53 --> No URI present. Default controller set.
INFO - 2023-08-05 12:40:53 --> Router Class Initialized
INFO - 2023-08-05 12:40:53 --> Output Class Initialized
INFO - 2023-08-05 12:40:53 --> Security Class Initialized
DEBUG - 2023-08-05 12:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:40:53 --> Input Class Initialized
INFO - 2023-08-05 12:40:53 --> Language Class Initialized
INFO - 2023-08-05 12:40:53 --> Loader Class Initialized
INFO - 2023-08-05 12:40:53 --> Helper loaded: url_helper
INFO - 2023-08-05 12:40:53 --> Helper loaded: file_helper
INFO - 2023-08-05 12:40:53 --> Helper loaded: html_helper
INFO - 2023-08-05 12:40:53 --> Helper loaded: text_helper
INFO - 2023-08-05 12:40:53 --> Helper loaded: form_helper
INFO - 2023-08-05 12:40:53 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:40:53 --> Helper loaded: security_helper
INFO - 2023-08-05 12:40:53 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:40:53 --> Database Driver Class Initialized
INFO - 2023-08-05 12:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:40:53 --> Parser Class Initialized
INFO - 2023-08-05 12:40:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:40:53 --> Pagination Class Initialized
INFO - 2023-08-05 12:40:53 --> Form Validation Class Initialized
INFO - 2023-08-05 12:40:53 --> Controller Class Initialized
INFO - 2023-08-05 12:40:53 --> Model Class Initialized
DEBUG - 2023-08-05 12:40:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-05 12:40:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:40:53 --> Config Class Initialized
INFO - 2023-08-05 12:40:53 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:40:53 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:40:53 --> Utf8 Class Initialized
INFO - 2023-08-05 12:40:53 --> URI Class Initialized
INFO - 2023-08-05 12:40:53 --> Router Class Initialized
INFO - 2023-08-05 12:40:53 --> Output Class Initialized
INFO - 2023-08-05 12:40:53 --> Security Class Initialized
DEBUG - 2023-08-05 12:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:40:53 --> Input Class Initialized
INFO - 2023-08-05 12:40:53 --> Language Class Initialized
INFO - 2023-08-05 12:40:53 --> Loader Class Initialized
INFO - 2023-08-05 12:40:53 --> Helper loaded: url_helper
INFO - 2023-08-05 12:40:53 --> Helper loaded: file_helper
INFO - 2023-08-05 12:40:53 --> Helper loaded: html_helper
INFO - 2023-08-05 12:40:53 --> Helper loaded: text_helper
INFO - 2023-08-05 12:40:53 --> Helper loaded: form_helper
INFO - 2023-08-05 12:40:53 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:40:53 --> Helper loaded: security_helper
INFO - 2023-08-05 12:40:53 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:40:53 --> Database Driver Class Initialized
INFO - 2023-08-05 12:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:40:53 --> Parser Class Initialized
INFO - 2023-08-05 12:40:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:40:53 --> Pagination Class Initialized
INFO - 2023-08-05 12:40:53 --> Form Validation Class Initialized
INFO - 2023-08-05 12:40:53 --> Controller Class Initialized
INFO - 2023-08-05 12:40:53 --> Model Class Initialized
DEBUG - 2023-08-05 12:40:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:40:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-05 12:40:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:40:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 12:40:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 12:40:53 --> Model Class Initialized
INFO - 2023-08-05 12:40:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 12:40:53 --> Final output sent to browser
DEBUG - 2023-08-05 12:40:53 --> Total execution time: 0.0314
ERROR - 2023-08-05 12:40:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:40:57 --> Config Class Initialized
INFO - 2023-08-05 12:40:57 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:40:57 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:40:57 --> Utf8 Class Initialized
INFO - 2023-08-05 12:40:57 --> URI Class Initialized
INFO - 2023-08-05 12:40:57 --> Router Class Initialized
INFO - 2023-08-05 12:40:57 --> Output Class Initialized
INFO - 2023-08-05 12:40:57 --> Security Class Initialized
DEBUG - 2023-08-05 12:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:40:57 --> Input Class Initialized
INFO - 2023-08-05 12:40:57 --> Language Class Initialized
INFO - 2023-08-05 12:40:57 --> Loader Class Initialized
INFO - 2023-08-05 12:40:57 --> Helper loaded: url_helper
INFO - 2023-08-05 12:40:57 --> Helper loaded: file_helper
INFO - 2023-08-05 12:40:57 --> Helper loaded: html_helper
INFO - 2023-08-05 12:40:57 --> Helper loaded: text_helper
INFO - 2023-08-05 12:40:57 --> Helper loaded: form_helper
INFO - 2023-08-05 12:40:57 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:40:57 --> Helper loaded: security_helper
INFO - 2023-08-05 12:40:57 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:40:57 --> Database Driver Class Initialized
INFO - 2023-08-05 12:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:40:57 --> Parser Class Initialized
INFO - 2023-08-05 12:40:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:40:57 --> Pagination Class Initialized
INFO - 2023-08-05 12:40:57 --> Form Validation Class Initialized
INFO - 2023-08-05 12:40:57 --> Controller Class Initialized
INFO - 2023-08-05 12:40:57 --> Model Class Initialized
DEBUG - 2023-08-05 12:40:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:40:57 --> Model Class Initialized
INFO - 2023-08-05 12:40:57 --> Final output sent to browser
DEBUG - 2023-08-05 12:40:57 --> Total execution time: 0.0173
ERROR - 2023-08-05 12:40:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:40:57 --> Config Class Initialized
INFO - 2023-08-05 12:40:57 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:40:57 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:40:57 --> Utf8 Class Initialized
INFO - 2023-08-05 12:40:57 --> URI Class Initialized
DEBUG - 2023-08-05 12:40:57 --> No URI present. Default controller set.
INFO - 2023-08-05 12:40:57 --> Router Class Initialized
INFO - 2023-08-05 12:40:57 --> Output Class Initialized
INFO - 2023-08-05 12:40:57 --> Security Class Initialized
DEBUG - 2023-08-05 12:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:40:57 --> Input Class Initialized
INFO - 2023-08-05 12:40:57 --> Language Class Initialized
INFO - 2023-08-05 12:40:57 --> Loader Class Initialized
INFO - 2023-08-05 12:40:57 --> Helper loaded: url_helper
INFO - 2023-08-05 12:40:57 --> Helper loaded: file_helper
INFO - 2023-08-05 12:40:57 --> Helper loaded: html_helper
INFO - 2023-08-05 12:40:57 --> Helper loaded: text_helper
INFO - 2023-08-05 12:40:57 --> Helper loaded: form_helper
INFO - 2023-08-05 12:40:57 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:40:57 --> Helper loaded: security_helper
INFO - 2023-08-05 12:40:57 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:40:57 --> Database Driver Class Initialized
INFO - 2023-08-05 12:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:40:57 --> Parser Class Initialized
INFO - 2023-08-05 12:40:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:40:57 --> Pagination Class Initialized
INFO - 2023-08-05 12:40:57 --> Form Validation Class Initialized
INFO - 2023-08-05 12:40:57 --> Controller Class Initialized
INFO - 2023-08-05 12:40:57 --> Model Class Initialized
DEBUG - 2023-08-05 12:40:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:40:57 --> Model Class Initialized
DEBUG - 2023-08-05 12:40:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:40:57 --> Model Class Initialized
INFO - 2023-08-05 12:40:57 --> Model Class Initialized
INFO - 2023-08-05 12:40:57 --> Model Class Initialized
INFO - 2023-08-05 12:40:57 --> Model Class Initialized
DEBUG - 2023-08-05 12:40:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 12:40:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:40:57 --> Model Class Initialized
INFO - 2023-08-05 12:40:57 --> Model Class Initialized
INFO - 2023-08-05 12:40:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 12:40:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:40:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 12:40:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 12:40:58 --> Model Class Initialized
INFO - 2023-08-05 12:40:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 12:40:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 12:40:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 12:40:58 --> Final output sent to browser
DEBUG - 2023-08-05 12:40:58 --> Total execution time: 0.0958
ERROR - 2023-08-05 12:41:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:41:05 --> Config Class Initialized
INFO - 2023-08-05 12:41:05 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:41:05 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:41:05 --> Utf8 Class Initialized
INFO - 2023-08-05 12:41:05 --> URI Class Initialized
INFO - 2023-08-05 12:41:05 --> Router Class Initialized
INFO - 2023-08-05 12:41:05 --> Output Class Initialized
INFO - 2023-08-05 12:41:05 --> Security Class Initialized
DEBUG - 2023-08-05 12:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:41:05 --> Input Class Initialized
INFO - 2023-08-05 12:41:05 --> Language Class Initialized
INFO - 2023-08-05 12:41:05 --> Loader Class Initialized
INFO - 2023-08-05 12:41:05 --> Helper loaded: url_helper
INFO - 2023-08-05 12:41:05 --> Helper loaded: file_helper
INFO - 2023-08-05 12:41:05 --> Helper loaded: html_helper
INFO - 2023-08-05 12:41:05 --> Helper loaded: text_helper
INFO - 2023-08-05 12:41:05 --> Helper loaded: form_helper
INFO - 2023-08-05 12:41:05 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:41:05 --> Helper loaded: security_helper
INFO - 2023-08-05 12:41:05 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:41:05 --> Database Driver Class Initialized
INFO - 2023-08-05 12:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:41:05 --> Parser Class Initialized
INFO - 2023-08-05 12:41:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:41:05 --> Pagination Class Initialized
INFO - 2023-08-05 12:41:05 --> Form Validation Class Initialized
INFO - 2023-08-05 12:41:05 --> Controller Class Initialized
INFO - 2023-08-05 12:41:05 --> Model Class Initialized
DEBUG - 2023-08-05 12:41:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 12:41:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:41:05 --> Model Class Initialized
DEBUG - 2023-08-05 12:41:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:41:05 --> Model Class Initialized
INFO - 2023-08-05 12:41:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 12:41:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:41:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 12:41:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 12:41:05 --> Model Class Initialized
INFO - 2023-08-05 12:41:05 --> Model Class Initialized
INFO - 2023-08-05 12:41:05 --> Model Class Initialized
INFO - 2023-08-05 12:41:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 12:41:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 12:41:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 12:41:06 --> Final output sent to browser
DEBUG - 2023-08-05 12:41:06 --> Total execution time: 0.0893
ERROR - 2023-08-05 12:41:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:41:06 --> Config Class Initialized
INFO - 2023-08-05 12:41:06 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:41:06 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:41:06 --> Utf8 Class Initialized
INFO - 2023-08-05 12:41:06 --> URI Class Initialized
INFO - 2023-08-05 12:41:06 --> Router Class Initialized
INFO - 2023-08-05 12:41:06 --> Output Class Initialized
INFO - 2023-08-05 12:41:06 --> Security Class Initialized
DEBUG - 2023-08-05 12:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:41:06 --> Input Class Initialized
INFO - 2023-08-05 12:41:06 --> Language Class Initialized
INFO - 2023-08-05 12:41:06 --> Loader Class Initialized
INFO - 2023-08-05 12:41:06 --> Helper loaded: url_helper
INFO - 2023-08-05 12:41:06 --> Helper loaded: file_helper
INFO - 2023-08-05 12:41:06 --> Helper loaded: html_helper
INFO - 2023-08-05 12:41:06 --> Helper loaded: text_helper
INFO - 2023-08-05 12:41:06 --> Helper loaded: form_helper
INFO - 2023-08-05 12:41:06 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:41:06 --> Helper loaded: security_helper
INFO - 2023-08-05 12:41:06 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:41:06 --> Database Driver Class Initialized
INFO - 2023-08-05 12:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:41:06 --> Parser Class Initialized
INFO - 2023-08-05 12:41:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:41:06 --> Pagination Class Initialized
INFO - 2023-08-05 12:41:06 --> Form Validation Class Initialized
INFO - 2023-08-05 12:41:06 --> Controller Class Initialized
INFO - 2023-08-05 12:41:06 --> Model Class Initialized
DEBUG - 2023-08-05 12:41:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 12:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:41:06 --> Model Class Initialized
DEBUG - 2023-08-05 12:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:41:06 --> Model Class Initialized
INFO - 2023-08-05 12:41:06 --> Final output sent to browser
DEBUG - 2023-08-05 12:41:06 --> Total execution time: 0.0414
ERROR - 2023-08-05 12:41:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:41:13 --> Config Class Initialized
INFO - 2023-08-05 12:41:13 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:41:13 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:41:13 --> Utf8 Class Initialized
INFO - 2023-08-05 12:41:13 --> URI Class Initialized
INFO - 2023-08-05 12:41:13 --> Router Class Initialized
INFO - 2023-08-05 12:41:13 --> Output Class Initialized
INFO - 2023-08-05 12:41:13 --> Security Class Initialized
DEBUG - 2023-08-05 12:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:41:13 --> Input Class Initialized
INFO - 2023-08-05 12:41:13 --> Language Class Initialized
INFO - 2023-08-05 12:41:13 --> Loader Class Initialized
INFO - 2023-08-05 12:41:13 --> Helper loaded: url_helper
INFO - 2023-08-05 12:41:13 --> Helper loaded: file_helper
INFO - 2023-08-05 12:41:13 --> Helper loaded: html_helper
INFO - 2023-08-05 12:41:13 --> Helper loaded: text_helper
INFO - 2023-08-05 12:41:13 --> Helper loaded: form_helper
INFO - 2023-08-05 12:41:13 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:41:13 --> Helper loaded: security_helper
INFO - 2023-08-05 12:41:13 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:41:13 --> Database Driver Class Initialized
INFO - 2023-08-05 12:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:41:13 --> Parser Class Initialized
INFO - 2023-08-05 12:41:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:41:13 --> Pagination Class Initialized
INFO - 2023-08-05 12:41:13 --> Form Validation Class Initialized
INFO - 2023-08-05 12:41:13 --> Controller Class Initialized
INFO - 2023-08-05 12:41:13 --> Model Class Initialized
DEBUG - 2023-08-05 12:41:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 12:41:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:41:13 --> Model Class Initialized
DEBUG - 2023-08-05 12:41:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:41:13 --> Model Class Initialized
INFO - 2023-08-05 12:41:13 --> Final output sent to browser
DEBUG - 2023-08-05 12:41:13 --> Total execution time: 0.1527
ERROR - 2023-08-05 12:41:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:41:19 --> Config Class Initialized
INFO - 2023-08-05 12:41:19 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:41:19 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:41:19 --> Utf8 Class Initialized
INFO - 2023-08-05 12:41:19 --> URI Class Initialized
INFO - 2023-08-05 12:41:19 --> Router Class Initialized
INFO - 2023-08-05 12:41:19 --> Output Class Initialized
INFO - 2023-08-05 12:41:19 --> Security Class Initialized
DEBUG - 2023-08-05 12:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:41:19 --> Input Class Initialized
INFO - 2023-08-05 12:41:19 --> Language Class Initialized
INFO - 2023-08-05 12:41:19 --> Loader Class Initialized
INFO - 2023-08-05 12:41:19 --> Helper loaded: url_helper
INFO - 2023-08-05 12:41:19 --> Helper loaded: file_helper
INFO - 2023-08-05 12:41:19 --> Helper loaded: html_helper
INFO - 2023-08-05 12:41:19 --> Helper loaded: text_helper
INFO - 2023-08-05 12:41:19 --> Helper loaded: form_helper
INFO - 2023-08-05 12:41:19 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:41:19 --> Helper loaded: security_helper
INFO - 2023-08-05 12:41:19 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:41:19 --> Database Driver Class Initialized
INFO - 2023-08-05 12:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:41:19 --> Parser Class Initialized
INFO - 2023-08-05 12:41:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:41:19 --> Pagination Class Initialized
INFO - 2023-08-05 12:41:19 --> Form Validation Class Initialized
INFO - 2023-08-05 12:41:19 --> Controller Class Initialized
INFO - 2023-08-05 12:41:19 --> Model Class Initialized
DEBUG - 2023-08-05 12:41:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 12:41:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:41:19 --> Model Class Initialized
DEBUG - 2023-08-05 12:41:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:41:19 --> Model Class Initialized
DEBUG - 2023-08-05 12:41:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:41:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-05 12:41:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:41:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 12:41:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 12:41:19 --> Model Class Initialized
INFO - 2023-08-05 12:41:19 --> Model Class Initialized
INFO - 2023-08-05 12:41:19 --> Model Class Initialized
INFO - 2023-08-05 12:41:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 12:41:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 12:41:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 12:41:20 --> Final output sent to browser
DEBUG - 2023-08-05 12:41:20 --> Total execution time: 0.0830
ERROR - 2023-08-05 12:41:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:41:26 --> Config Class Initialized
INFO - 2023-08-05 12:41:26 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:41:26 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:41:26 --> Utf8 Class Initialized
INFO - 2023-08-05 12:41:26 --> URI Class Initialized
INFO - 2023-08-05 12:41:26 --> Router Class Initialized
INFO - 2023-08-05 12:41:26 --> Output Class Initialized
INFO - 2023-08-05 12:41:26 --> Security Class Initialized
DEBUG - 2023-08-05 12:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:41:26 --> Input Class Initialized
INFO - 2023-08-05 12:41:26 --> Language Class Initialized
INFO - 2023-08-05 12:41:26 --> Loader Class Initialized
INFO - 2023-08-05 12:41:26 --> Helper loaded: url_helper
INFO - 2023-08-05 12:41:26 --> Helper loaded: file_helper
INFO - 2023-08-05 12:41:26 --> Helper loaded: html_helper
INFO - 2023-08-05 12:41:26 --> Helper loaded: text_helper
INFO - 2023-08-05 12:41:26 --> Helper loaded: form_helper
INFO - 2023-08-05 12:41:26 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:41:26 --> Helper loaded: security_helper
INFO - 2023-08-05 12:41:26 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:41:26 --> Database Driver Class Initialized
INFO - 2023-08-05 12:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:41:26 --> Parser Class Initialized
INFO - 2023-08-05 12:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:41:26 --> Pagination Class Initialized
INFO - 2023-08-05 12:41:26 --> Form Validation Class Initialized
INFO - 2023-08-05 12:41:26 --> Controller Class Initialized
INFO - 2023-08-05 12:41:26 --> Model Class Initialized
DEBUG - 2023-08-05 12:41:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 12:41:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:41:26 --> Model Class Initialized
DEBUG - 2023-08-05 12:41:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:41:26 --> Model Class Initialized
INFO - 2023-08-05 12:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 12:41:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 12:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 12:41:26 --> Model Class Initialized
INFO - 2023-08-05 12:41:26 --> Model Class Initialized
INFO - 2023-08-05 12:41:26 --> Model Class Initialized
INFO - 2023-08-05 12:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 12:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 12:41:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 12:41:26 --> Final output sent to browser
DEBUG - 2023-08-05 12:41:26 --> Total execution time: 0.0818
ERROR - 2023-08-05 12:41:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:41:26 --> Config Class Initialized
INFO - 2023-08-05 12:41:26 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:41:26 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:41:26 --> Utf8 Class Initialized
INFO - 2023-08-05 12:41:26 --> URI Class Initialized
INFO - 2023-08-05 12:41:26 --> Router Class Initialized
INFO - 2023-08-05 12:41:26 --> Output Class Initialized
INFO - 2023-08-05 12:41:26 --> Security Class Initialized
DEBUG - 2023-08-05 12:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:41:26 --> Input Class Initialized
INFO - 2023-08-05 12:41:26 --> Language Class Initialized
INFO - 2023-08-05 12:41:26 --> Loader Class Initialized
INFO - 2023-08-05 12:41:26 --> Helper loaded: url_helper
INFO - 2023-08-05 12:41:26 --> Helper loaded: file_helper
INFO - 2023-08-05 12:41:26 --> Helper loaded: html_helper
INFO - 2023-08-05 12:41:26 --> Helper loaded: text_helper
INFO - 2023-08-05 12:41:26 --> Helper loaded: form_helper
INFO - 2023-08-05 12:41:26 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:41:26 --> Helper loaded: security_helper
INFO - 2023-08-05 12:41:26 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:41:26 --> Database Driver Class Initialized
INFO - 2023-08-05 12:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:41:26 --> Parser Class Initialized
INFO - 2023-08-05 12:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:41:26 --> Pagination Class Initialized
INFO - 2023-08-05 12:41:26 --> Form Validation Class Initialized
INFO - 2023-08-05 12:41:26 --> Controller Class Initialized
INFO - 2023-08-05 12:41:26 --> Model Class Initialized
DEBUG - 2023-08-05 12:41:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 12:41:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:41:26 --> Model Class Initialized
DEBUG - 2023-08-05 12:41:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:41:26 --> Model Class Initialized
INFO - 2023-08-05 12:41:26 --> Final output sent to browser
DEBUG - 2023-08-05 12:41:26 --> Total execution time: 0.0488
ERROR - 2023-08-05 12:41:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:41:50 --> Config Class Initialized
INFO - 2023-08-05 12:41:50 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:41:50 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:41:50 --> Utf8 Class Initialized
INFO - 2023-08-05 12:41:50 --> URI Class Initialized
INFO - 2023-08-05 12:41:50 --> Router Class Initialized
INFO - 2023-08-05 12:41:50 --> Output Class Initialized
INFO - 2023-08-05 12:41:50 --> Security Class Initialized
DEBUG - 2023-08-05 12:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:41:50 --> Input Class Initialized
INFO - 2023-08-05 12:41:50 --> Language Class Initialized
INFO - 2023-08-05 12:41:50 --> Loader Class Initialized
INFO - 2023-08-05 12:41:50 --> Helper loaded: url_helper
INFO - 2023-08-05 12:41:50 --> Helper loaded: file_helper
INFO - 2023-08-05 12:41:50 --> Helper loaded: html_helper
INFO - 2023-08-05 12:41:50 --> Helper loaded: text_helper
INFO - 2023-08-05 12:41:50 --> Helper loaded: form_helper
INFO - 2023-08-05 12:41:50 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:41:50 --> Helper loaded: security_helper
INFO - 2023-08-05 12:41:50 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:41:50 --> Database Driver Class Initialized
INFO - 2023-08-05 12:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:41:50 --> Parser Class Initialized
INFO - 2023-08-05 12:41:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:41:50 --> Pagination Class Initialized
INFO - 2023-08-05 12:41:50 --> Form Validation Class Initialized
INFO - 2023-08-05 12:41:50 --> Controller Class Initialized
INFO - 2023-08-05 12:41:50 --> Model Class Initialized
DEBUG - 2023-08-05 12:41:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 12:41:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:41:50 --> Model Class Initialized
DEBUG - 2023-08-05 12:41:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:41:50 --> Model Class Initialized
DEBUG - 2023-08-05 12:41:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:41:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-05 12:41:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:41:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 12:41:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 12:41:50 --> Model Class Initialized
INFO - 2023-08-05 12:41:50 --> Model Class Initialized
INFO - 2023-08-05 12:41:50 --> Model Class Initialized
INFO - 2023-08-05 12:41:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 12:41:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 12:41:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 12:41:50 --> Final output sent to browser
DEBUG - 2023-08-05 12:41:50 --> Total execution time: 0.0865
ERROR - 2023-08-05 12:42:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:42:31 --> Config Class Initialized
INFO - 2023-08-05 12:42:31 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:42:31 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:42:31 --> Utf8 Class Initialized
INFO - 2023-08-05 12:42:31 --> URI Class Initialized
DEBUG - 2023-08-05 12:42:31 --> No URI present. Default controller set.
INFO - 2023-08-05 12:42:31 --> Router Class Initialized
INFO - 2023-08-05 12:42:31 --> Output Class Initialized
INFO - 2023-08-05 12:42:31 --> Security Class Initialized
DEBUG - 2023-08-05 12:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:42:31 --> Input Class Initialized
INFO - 2023-08-05 12:42:31 --> Language Class Initialized
INFO - 2023-08-05 12:42:31 --> Loader Class Initialized
INFO - 2023-08-05 12:42:31 --> Helper loaded: url_helper
INFO - 2023-08-05 12:42:31 --> Helper loaded: file_helper
INFO - 2023-08-05 12:42:31 --> Helper loaded: html_helper
INFO - 2023-08-05 12:42:31 --> Helper loaded: text_helper
INFO - 2023-08-05 12:42:31 --> Helper loaded: form_helper
INFO - 2023-08-05 12:42:31 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:42:31 --> Helper loaded: security_helper
INFO - 2023-08-05 12:42:31 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:42:31 --> Database Driver Class Initialized
INFO - 2023-08-05 12:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:42:31 --> Parser Class Initialized
INFO - 2023-08-05 12:42:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:42:31 --> Pagination Class Initialized
INFO - 2023-08-05 12:42:31 --> Form Validation Class Initialized
INFO - 2023-08-05 12:42:31 --> Controller Class Initialized
INFO - 2023-08-05 12:42:31 --> Model Class Initialized
DEBUG - 2023-08-05 12:42:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:42:31 --> Model Class Initialized
DEBUG - 2023-08-05 12:42:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:42:31 --> Model Class Initialized
INFO - 2023-08-05 12:42:31 --> Model Class Initialized
INFO - 2023-08-05 12:42:31 --> Model Class Initialized
INFO - 2023-08-05 12:42:31 --> Model Class Initialized
DEBUG - 2023-08-05 12:42:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 12:42:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:42:31 --> Model Class Initialized
INFO - 2023-08-05 12:42:31 --> Model Class Initialized
INFO - 2023-08-05 12:42:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 12:42:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:42:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 12:42:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 12:42:31 --> Model Class Initialized
INFO - 2023-08-05 12:42:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 12:42:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 12:42:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 12:42:31 --> Final output sent to browser
DEBUG - 2023-08-05 12:42:31 --> Total execution time: 0.2082
ERROR - 2023-08-05 12:59:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:59:32 --> Config Class Initialized
INFO - 2023-08-05 12:59:32 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:59:32 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:59:32 --> Utf8 Class Initialized
INFO - 2023-08-05 12:59:32 --> URI Class Initialized
DEBUG - 2023-08-05 12:59:32 --> No URI present. Default controller set.
INFO - 2023-08-05 12:59:32 --> Router Class Initialized
INFO - 2023-08-05 12:59:32 --> Output Class Initialized
INFO - 2023-08-05 12:59:32 --> Security Class Initialized
DEBUG - 2023-08-05 12:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:59:32 --> Input Class Initialized
INFO - 2023-08-05 12:59:32 --> Language Class Initialized
INFO - 2023-08-05 12:59:32 --> Loader Class Initialized
INFO - 2023-08-05 12:59:32 --> Helper loaded: url_helper
INFO - 2023-08-05 12:59:32 --> Helper loaded: file_helper
INFO - 2023-08-05 12:59:32 --> Helper loaded: html_helper
INFO - 2023-08-05 12:59:32 --> Helper loaded: text_helper
INFO - 2023-08-05 12:59:32 --> Helper loaded: form_helper
INFO - 2023-08-05 12:59:32 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:59:32 --> Helper loaded: security_helper
INFO - 2023-08-05 12:59:32 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:59:32 --> Database Driver Class Initialized
INFO - 2023-08-05 12:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:59:32 --> Parser Class Initialized
INFO - 2023-08-05 12:59:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:59:32 --> Pagination Class Initialized
INFO - 2023-08-05 12:59:32 --> Form Validation Class Initialized
INFO - 2023-08-05 12:59:32 --> Controller Class Initialized
INFO - 2023-08-05 12:59:32 --> Model Class Initialized
DEBUG - 2023-08-05 12:59:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:59:32 --> Model Class Initialized
DEBUG - 2023-08-05 12:59:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:59:32 --> Model Class Initialized
INFO - 2023-08-05 12:59:32 --> Model Class Initialized
INFO - 2023-08-05 12:59:32 --> Model Class Initialized
INFO - 2023-08-05 12:59:32 --> Model Class Initialized
DEBUG - 2023-08-05 12:59:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 12:59:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:59:32 --> Model Class Initialized
INFO - 2023-08-05 12:59:32 --> Model Class Initialized
INFO - 2023-08-05 12:59:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 12:59:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:59:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 12:59:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 12:59:32 --> Model Class Initialized
INFO - 2023-08-05 12:59:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 12:59:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 12:59:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 12:59:32 --> Final output sent to browser
DEBUG - 2023-08-05 12:59:32 --> Total execution time: 0.0923
ERROR - 2023-08-05 12:59:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:59:32 --> Config Class Initialized
INFO - 2023-08-05 12:59:32 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:59:32 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:59:32 --> Utf8 Class Initialized
INFO - 2023-08-05 12:59:32 --> URI Class Initialized
DEBUG - 2023-08-05 12:59:32 --> No URI present. Default controller set.
INFO - 2023-08-05 12:59:32 --> Router Class Initialized
INFO - 2023-08-05 12:59:32 --> Output Class Initialized
INFO - 2023-08-05 12:59:32 --> Security Class Initialized
DEBUG - 2023-08-05 12:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:59:32 --> Input Class Initialized
INFO - 2023-08-05 12:59:32 --> Language Class Initialized
INFO - 2023-08-05 12:59:32 --> Loader Class Initialized
INFO - 2023-08-05 12:59:32 --> Helper loaded: url_helper
INFO - 2023-08-05 12:59:32 --> Helper loaded: file_helper
INFO - 2023-08-05 12:59:32 --> Helper loaded: html_helper
INFO - 2023-08-05 12:59:32 --> Helper loaded: text_helper
INFO - 2023-08-05 12:59:32 --> Helper loaded: form_helper
INFO - 2023-08-05 12:59:32 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:59:32 --> Helper loaded: security_helper
INFO - 2023-08-05 12:59:32 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:59:32 --> Database Driver Class Initialized
INFO - 2023-08-05 12:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:59:32 --> Parser Class Initialized
INFO - 2023-08-05 12:59:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:59:32 --> Pagination Class Initialized
INFO - 2023-08-05 12:59:32 --> Form Validation Class Initialized
INFO - 2023-08-05 12:59:32 --> Controller Class Initialized
INFO - 2023-08-05 12:59:32 --> Model Class Initialized
DEBUG - 2023-08-05 12:59:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:59:32 --> Model Class Initialized
DEBUG - 2023-08-05 12:59:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:59:32 --> Model Class Initialized
INFO - 2023-08-05 12:59:32 --> Model Class Initialized
INFO - 2023-08-05 12:59:32 --> Model Class Initialized
INFO - 2023-08-05 12:59:32 --> Model Class Initialized
DEBUG - 2023-08-05 12:59:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 12:59:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:59:32 --> Model Class Initialized
INFO - 2023-08-05 12:59:32 --> Model Class Initialized
INFO - 2023-08-05 12:59:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 12:59:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:59:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 12:59:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 12:59:32 --> Model Class Initialized
INFO - 2023-08-05 12:59:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 12:59:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 12:59:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 12:59:32 --> Final output sent to browser
DEBUG - 2023-08-05 12:59:32 --> Total execution time: 0.0891
ERROR - 2023-08-05 12:59:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:59:42 --> Config Class Initialized
INFO - 2023-08-05 12:59:42 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:59:42 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:59:42 --> Utf8 Class Initialized
INFO - 2023-08-05 12:59:42 --> URI Class Initialized
INFO - 2023-08-05 12:59:42 --> Router Class Initialized
INFO - 2023-08-05 12:59:42 --> Output Class Initialized
INFO - 2023-08-05 12:59:42 --> Security Class Initialized
DEBUG - 2023-08-05 12:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:59:42 --> Input Class Initialized
INFO - 2023-08-05 12:59:42 --> Language Class Initialized
INFO - 2023-08-05 12:59:42 --> Loader Class Initialized
INFO - 2023-08-05 12:59:42 --> Helper loaded: url_helper
INFO - 2023-08-05 12:59:42 --> Helper loaded: file_helper
INFO - 2023-08-05 12:59:42 --> Helper loaded: html_helper
INFO - 2023-08-05 12:59:42 --> Helper loaded: text_helper
INFO - 2023-08-05 12:59:42 --> Helper loaded: form_helper
INFO - 2023-08-05 12:59:42 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:59:42 --> Helper loaded: security_helper
INFO - 2023-08-05 12:59:42 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:59:42 --> Database Driver Class Initialized
INFO - 2023-08-05 12:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:59:42 --> Parser Class Initialized
INFO - 2023-08-05 12:59:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:59:42 --> Pagination Class Initialized
INFO - 2023-08-05 12:59:42 --> Form Validation Class Initialized
INFO - 2023-08-05 12:59:42 --> Controller Class Initialized
INFO - 2023-08-05 12:59:42 --> Model Class Initialized
DEBUG - 2023-08-05 12:59:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 12:59:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:59:42 --> Model Class Initialized
DEBUG - 2023-08-05 12:59:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:59:42 --> Model Class Initialized
INFO - 2023-08-05 12:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 12:59:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 12:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 12:59:42 --> Model Class Initialized
INFO - 2023-08-05 12:59:42 --> Model Class Initialized
INFO - 2023-08-05 12:59:42 --> Model Class Initialized
INFO - 2023-08-05 12:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 12:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 12:59:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 12:59:42 --> Final output sent to browser
DEBUG - 2023-08-05 12:59:42 --> Total execution time: 0.0812
ERROR - 2023-08-05 12:59:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:59:43 --> Config Class Initialized
INFO - 2023-08-05 12:59:43 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:59:43 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:59:43 --> Utf8 Class Initialized
INFO - 2023-08-05 12:59:43 --> URI Class Initialized
INFO - 2023-08-05 12:59:43 --> Router Class Initialized
INFO - 2023-08-05 12:59:43 --> Output Class Initialized
INFO - 2023-08-05 12:59:43 --> Security Class Initialized
DEBUG - 2023-08-05 12:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:59:43 --> Input Class Initialized
INFO - 2023-08-05 12:59:43 --> Language Class Initialized
INFO - 2023-08-05 12:59:43 --> Loader Class Initialized
INFO - 2023-08-05 12:59:43 --> Helper loaded: url_helper
INFO - 2023-08-05 12:59:43 --> Helper loaded: file_helper
INFO - 2023-08-05 12:59:43 --> Helper loaded: html_helper
INFO - 2023-08-05 12:59:43 --> Helper loaded: text_helper
INFO - 2023-08-05 12:59:43 --> Helper loaded: form_helper
INFO - 2023-08-05 12:59:43 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:59:43 --> Helper loaded: security_helper
INFO - 2023-08-05 12:59:43 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:59:43 --> Database Driver Class Initialized
INFO - 2023-08-05 12:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:59:43 --> Parser Class Initialized
INFO - 2023-08-05 12:59:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:59:43 --> Pagination Class Initialized
INFO - 2023-08-05 12:59:43 --> Form Validation Class Initialized
INFO - 2023-08-05 12:59:43 --> Controller Class Initialized
INFO - 2023-08-05 12:59:43 --> Model Class Initialized
DEBUG - 2023-08-05 12:59:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 12:59:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:59:43 --> Model Class Initialized
DEBUG - 2023-08-05 12:59:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:59:43 --> Model Class Initialized
INFO - 2023-08-05 12:59:43 --> Final output sent to browser
DEBUG - 2023-08-05 12:59:43 --> Total execution time: 0.0398
ERROR - 2023-08-05 12:59:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 12:59:46 --> Config Class Initialized
INFO - 2023-08-05 12:59:46 --> Hooks Class Initialized
DEBUG - 2023-08-05 12:59:46 --> UTF-8 Support Enabled
INFO - 2023-08-05 12:59:46 --> Utf8 Class Initialized
INFO - 2023-08-05 12:59:46 --> URI Class Initialized
INFO - 2023-08-05 12:59:46 --> Router Class Initialized
INFO - 2023-08-05 12:59:46 --> Output Class Initialized
INFO - 2023-08-05 12:59:46 --> Security Class Initialized
DEBUG - 2023-08-05 12:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 12:59:46 --> Input Class Initialized
INFO - 2023-08-05 12:59:46 --> Language Class Initialized
INFO - 2023-08-05 12:59:46 --> Loader Class Initialized
INFO - 2023-08-05 12:59:46 --> Helper loaded: url_helper
INFO - 2023-08-05 12:59:46 --> Helper loaded: file_helper
INFO - 2023-08-05 12:59:46 --> Helper loaded: html_helper
INFO - 2023-08-05 12:59:46 --> Helper loaded: text_helper
INFO - 2023-08-05 12:59:46 --> Helper loaded: form_helper
INFO - 2023-08-05 12:59:46 --> Helper loaded: lang_helper
INFO - 2023-08-05 12:59:46 --> Helper loaded: security_helper
INFO - 2023-08-05 12:59:46 --> Helper loaded: cookie_helper
INFO - 2023-08-05 12:59:46 --> Database Driver Class Initialized
INFO - 2023-08-05 12:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 12:59:46 --> Parser Class Initialized
INFO - 2023-08-05 12:59:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 12:59:46 --> Pagination Class Initialized
INFO - 2023-08-05 12:59:46 --> Form Validation Class Initialized
INFO - 2023-08-05 12:59:46 --> Controller Class Initialized
INFO - 2023-08-05 12:59:46 --> Model Class Initialized
DEBUG - 2023-08-05 12:59:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 12:59:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:59:46 --> Model Class Initialized
DEBUG - 2023-08-05 12:59:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 12:59:46 --> Model Class Initialized
INFO - 2023-08-05 12:59:46 --> Final output sent to browser
DEBUG - 2023-08-05 12:59:46 --> Total execution time: 0.1739
ERROR - 2023-08-05 13:00:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:00:36 --> Config Class Initialized
INFO - 2023-08-05 13:00:36 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:00:36 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:00:36 --> Utf8 Class Initialized
INFO - 2023-08-05 13:00:36 --> URI Class Initialized
INFO - 2023-08-05 13:00:36 --> Router Class Initialized
INFO - 2023-08-05 13:00:36 --> Output Class Initialized
INFO - 2023-08-05 13:00:36 --> Security Class Initialized
DEBUG - 2023-08-05 13:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:00:36 --> Input Class Initialized
INFO - 2023-08-05 13:00:36 --> Language Class Initialized
INFO - 2023-08-05 13:00:36 --> Loader Class Initialized
INFO - 2023-08-05 13:00:36 --> Helper loaded: url_helper
INFO - 2023-08-05 13:00:36 --> Helper loaded: file_helper
INFO - 2023-08-05 13:00:36 --> Helper loaded: html_helper
INFO - 2023-08-05 13:00:36 --> Helper loaded: text_helper
INFO - 2023-08-05 13:00:36 --> Helper loaded: form_helper
INFO - 2023-08-05 13:00:36 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:00:36 --> Helper loaded: security_helper
INFO - 2023-08-05 13:00:36 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:00:36 --> Database Driver Class Initialized
INFO - 2023-08-05 13:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:00:36 --> Parser Class Initialized
INFO - 2023-08-05 13:00:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:00:36 --> Pagination Class Initialized
INFO - 2023-08-05 13:00:36 --> Form Validation Class Initialized
INFO - 2023-08-05 13:00:36 --> Controller Class Initialized
INFO - 2023-08-05 13:00:36 --> Model Class Initialized
DEBUG - 2023-08-05 13:00:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:00:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:00:36 --> Model Class Initialized
DEBUG - 2023-08-05 13:00:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:00:36 --> Model Class Initialized
INFO - 2023-08-05 13:00:37 --> Final output sent to browser
DEBUG - 2023-08-05 13:00:37 --> Total execution time: 0.1856
ERROR - 2023-08-05 13:00:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:00:49 --> Config Class Initialized
INFO - 2023-08-05 13:00:49 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:00:49 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:00:49 --> Utf8 Class Initialized
INFO - 2023-08-05 13:00:49 --> URI Class Initialized
DEBUG - 2023-08-05 13:00:49 --> No URI present. Default controller set.
INFO - 2023-08-05 13:00:49 --> Router Class Initialized
INFO - 2023-08-05 13:00:49 --> Output Class Initialized
INFO - 2023-08-05 13:00:49 --> Security Class Initialized
DEBUG - 2023-08-05 13:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:00:49 --> Input Class Initialized
INFO - 2023-08-05 13:00:49 --> Language Class Initialized
INFO - 2023-08-05 13:00:49 --> Loader Class Initialized
INFO - 2023-08-05 13:00:49 --> Helper loaded: url_helper
INFO - 2023-08-05 13:00:49 --> Helper loaded: file_helper
INFO - 2023-08-05 13:00:49 --> Helper loaded: html_helper
INFO - 2023-08-05 13:00:49 --> Helper loaded: text_helper
INFO - 2023-08-05 13:00:49 --> Helper loaded: form_helper
INFO - 2023-08-05 13:00:49 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:00:49 --> Helper loaded: security_helper
INFO - 2023-08-05 13:00:49 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:00:49 --> Database Driver Class Initialized
INFO - 2023-08-05 13:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:00:49 --> Parser Class Initialized
INFO - 2023-08-05 13:00:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:00:49 --> Pagination Class Initialized
INFO - 2023-08-05 13:00:49 --> Form Validation Class Initialized
INFO - 2023-08-05 13:00:49 --> Controller Class Initialized
INFO - 2023-08-05 13:00:49 --> Model Class Initialized
DEBUG - 2023-08-05 13:00:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:00:49 --> Model Class Initialized
DEBUG - 2023-08-05 13:00:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:00:49 --> Model Class Initialized
INFO - 2023-08-05 13:00:49 --> Model Class Initialized
INFO - 2023-08-05 13:00:49 --> Model Class Initialized
INFO - 2023-08-05 13:00:49 --> Model Class Initialized
DEBUG - 2023-08-05 13:00:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:00:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:00:49 --> Model Class Initialized
INFO - 2023-08-05 13:00:49 --> Model Class Initialized
INFO - 2023-08-05 13:00:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 13:00:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:00:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:00:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:00:49 --> Model Class Initialized
INFO - 2023-08-05 13:00:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:00:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:00:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:00:49 --> Final output sent to browser
DEBUG - 2023-08-05 13:00:49 --> Total execution time: 0.0975
ERROR - 2023-08-05 13:00:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:00:56 --> Config Class Initialized
INFO - 2023-08-05 13:00:56 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:00:56 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:00:56 --> Utf8 Class Initialized
INFO - 2023-08-05 13:00:56 --> URI Class Initialized
INFO - 2023-08-05 13:00:56 --> Router Class Initialized
INFO - 2023-08-05 13:00:56 --> Output Class Initialized
INFO - 2023-08-05 13:00:56 --> Security Class Initialized
DEBUG - 2023-08-05 13:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:00:56 --> Input Class Initialized
INFO - 2023-08-05 13:00:56 --> Language Class Initialized
INFO - 2023-08-05 13:00:56 --> Loader Class Initialized
INFO - 2023-08-05 13:00:56 --> Helper loaded: url_helper
INFO - 2023-08-05 13:00:56 --> Helper loaded: file_helper
INFO - 2023-08-05 13:00:56 --> Helper loaded: html_helper
INFO - 2023-08-05 13:00:56 --> Helper loaded: text_helper
INFO - 2023-08-05 13:00:56 --> Helper loaded: form_helper
INFO - 2023-08-05 13:00:56 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:00:56 --> Helper loaded: security_helper
INFO - 2023-08-05 13:00:56 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:00:56 --> Database Driver Class Initialized
INFO - 2023-08-05 13:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:00:56 --> Parser Class Initialized
INFO - 2023-08-05 13:00:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:00:56 --> Pagination Class Initialized
INFO - 2023-08-05 13:00:56 --> Form Validation Class Initialized
INFO - 2023-08-05 13:00:56 --> Controller Class Initialized
INFO - 2023-08-05 13:00:56 --> Model Class Initialized
DEBUG - 2023-08-05 13:00:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:00:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:00:56 --> Model Class Initialized
DEBUG - 2023-08-05 13:00:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:00:56 --> Model Class Initialized
INFO - 2023-08-05 13:00:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 13:00:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:00:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:00:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:00:56 --> Model Class Initialized
INFO - 2023-08-05 13:00:56 --> Model Class Initialized
INFO - 2023-08-05 13:00:56 --> Model Class Initialized
INFO - 2023-08-05 13:00:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:00:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:00:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:00:56 --> Final output sent to browser
DEBUG - 2023-08-05 13:00:56 --> Total execution time: 0.0847
ERROR - 2023-08-05 13:00:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:00:56 --> Config Class Initialized
INFO - 2023-08-05 13:00:56 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:00:57 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:00:57 --> Utf8 Class Initialized
INFO - 2023-08-05 13:00:57 --> URI Class Initialized
INFO - 2023-08-05 13:00:57 --> Router Class Initialized
INFO - 2023-08-05 13:00:57 --> Output Class Initialized
INFO - 2023-08-05 13:00:57 --> Security Class Initialized
DEBUG - 2023-08-05 13:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:00:57 --> Input Class Initialized
INFO - 2023-08-05 13:00:57 --> Language Class Initialized
INFO - 2023-08-05 13:00:57 --> Loader Class Initialized
INFO - 2023-08-05 13:00:57 --> Helper loaded: url_helper
INFO - 2023-08-05 13:00:57 --> Helper loaded: file_helper
INFO - 2023-08-05 13:00:57 --> Helper loaded: html_helper
INFO - 2023-08-05 13:00:57 --> Helper loaded: text_helper
INFO - 2023-08-05 13:00:57 --> Helper loaded: form_helper
INFO - 2023-08-05 13:00:57 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:00:57 --> Helper loaded: security_helper
INFO - 2023-08-05 13:00:57 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:00:57 --> Database Driver Class Initialized
INFO - 2023-08-05 13:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:00:57 --> Parser Class Initialized
INFO - 2023-08-05 13:00:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:00:57 --> Pagination Class Initialized
INFO - 2023-08-05 13:00:57 --> Form Validation Class Initialized
INFO - 2023-08-05 13:00:57 --> Controller Class Initialized
INFO - 2023-08-05 13:00:57 --> Model Class Initialized
DEBUG - 2023-08-05 13:00:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:00:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:00:57 --> Model Class Initialized
DEBUG - 2023-08-05 13:00:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:00:57 --> Model Class Initialized
INFO - 2023-08-05 13:00:57 --> Final output sent to browser
DEBUG - 2023-08-05 13:00:57 --> Total execution time: 0.0414
ERROR - 2023-08-05 13:01:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:01:00 --> Config Class Initialized
INFO - 2023-08-05 13:01:00 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:01:00 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:01:00 --> Utf8 Class Initialized
INFO - 2023-08-05 13:01:00 --> URI Class Initialized
INFO - 2023-08-05 13:01:00 --> Router Class Initialized
INFO - 2023-08-05 13:01:00 --> Output Class Initialized
INFO - 2023-08-05 13:01:00 --> Security Class Initialized
DEBUG - 2023-08-05 13:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:01:00 --> Input Class Initialized
INFO - 2023-08-05 13:01:00 --> Language Class Initialized
INFO - 2023-08-05 13:01:00 --> Loader Class Initialized
INFO - 2023-08-05 13:01:00 --> Helper loaded: url_helper
INFO - 2023-08-05 13:01:00 --> Helper loaded: file_helper
INFO - 2023-08-05 13:01:00 --> Helper loaded: html_helper
INFO - 2023-08-05 13:01:00 --> Helper loaded: text_helper
INFO - 2023-08-05 13:01:00 --> Helper loaded: form_helper
INFO - 2023-08-05 13:01:00 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:01:00 --> Helper loaded: security_helper
INFO - 2023-08-05 13:01:00 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:01:00 --> Database Driver Class Initialized
INFO - 2023-08-05 13:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:01:00 --> Parser Class Initialized
INFO - 2023-08-05 13:01:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:01:00 --> Pagination Class Initialized
INFO - 2023-08-05 13:01:00 --> Form Validation Class Initialized
INFO - 2023-08-05 13:01:00 --> Controller Class Initialized
INFO - 2023-08-05 13:01:00 --> Model Class Initialized
DEBUG - 2023-08-05 13:01:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:01:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:01:00 --> Model Class Initialized
DEBUG - 2023-08-05 13:01:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:01:00 --> Model Class Initialized
INFO - 2023-08-05 13:01:00 --> Final output sent to browser
DEBUG - 2023-08-05 13:01:00 --> Total execution time: 0.1650
ERROR - 2023-08-05 13:01:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:01:33 --> Config Class Initialized
INFO - 2023-08-05 13:01:33 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:01:33 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:01:33 --> Utf8 Class Initialized
INFO - 2023-08-05 13:01:33 --> URI Class Initialized
DEBUG - 2023-08-05 13:01:33 --> No URI present. Default controller set.
INFO - 2023-08-05 13:01:33 --> Router Class Initialized
INFO - 2023-08-05 13:01:33 --> Output Class Initialized
INFO - 2023-08-05 13:01:33 --> Security Class Initialized
DEBUG - 2023-08-05 13:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:01:33 --> Input Class Initialized
INFO - 2023-08-05 13:01:33 --> Language Class Initialized
INFO - 2023-08-05 13:01:33 --> Loader Class Initialized
INFO - 2023-08-05 13:01:33 --> Helper loaded: url_helper
INFO - 2023-08-05 13:01:33 --> Helper loaded: file_helper
INFO - 2023-08-05 13:01:33 --> Helper loaded: html_helper
INFO - 2023-08-05 13:01:33 --> Helper loaded: text_helper
INFO - 2023-08-05 13:01:33 --> Helper loaded: form_helper
INFO - 2023-08-05 13:01:33 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:01:33 --> Helper loaded: security_helper
INFO - 2023-08-05 13:01:33 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:01:33 --> Database Driver Class Initialized
INFO - 2023-08-05 13:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:01:33 --> Parser Class Initialized
INFO - 2023-08-05 13:01:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:01:33 --> Pagination Class Initialized
INFO - 2023-08-05 13:01:33 --> Form Validation Class Initialized
INFO - 2023-08-05 13:01:33 --> Controller Class Initialized
INFO - 2023-08-05 13:01:33 --> Model Class Initialized
DEBUG - 2023-08-05 13:01:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:01:33 --> Model Class Initialized
DEBUG - 2023-08-05 13:01:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:01:33 --> Model Class Initialized
INFO - 2023-08-05 13:01:33 --> Model Class Initialized
INFO - 2023-08-05 13:01:33 --> Model Class Initialized
INFO - 2023-08-05 13:01:33 --> Model Class Initialized
DEBUG - 2023-08-05 13:01:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:01:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:01:33 --> Model Class Initialized
INFO - 2023-08-05 13:01:33 --> Model Class Initialized
INFO - 2023-08-05 13:01:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 13:01:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:01:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:01:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:01:34 --> Model Class Initialized
INFO - 2023-08-05 13:01:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:01:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:01:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:01:34 --> Final output sent to browser
DEBUG - 2023-08-05 13:01:34 --> Total execution time: 0.0901
ERROR - 2023-08-05 13:01:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:01:52 --> Config Class Initialized
INFO - 2023-08-05 13:01:52 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:01:52 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:01:52 --> Utf8 Class Initialized
INFO - 2023-08-05 13:01:52 --> URI Class Initialized
DEBUG - 2023-08-05 13:01:52 --> No URI present. Default controller set.
INFO - 2023-08-05 13:01:52 --> Router Class Initialized
INFO - 2023-08-05 13:01:52 --> Output Class Initialized
INFO - 2023-08-05 13:01:52 --> Security Class Initialized
DEBUG - 2023-08-05 13:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:01:52 --> Input Class Initialized
INFO - 2023-08-05 13:01:52 --> Language Class Initialized
INFO - 2023-08-05 13:01:52 --> Loader Class Initialized
INFO - 2023-08-05 13:01:52 --> Helper loaded: url_helper
INFO - 2023-08-05 13:01:52 --> Helper loaded: file_helper
INFO - 2023-08-05 13:01:52 --> Helper loaded: html_helper
INFO - 2023-08-05 13:01:52 --> Helper loaded: text_helper
INFO - 2023-08-05 13:01:52 --> Helper loaded: form_helper
INFO - 2023-08-05 13:01:52 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:01:52 --> Helper loaded: security_helper
INFO - 2023-08-05 13:01:52 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:01:52 --> Database Driver Class Initialized
INFO - 2023-08-05 13:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:01:52 --> Parser Class Initialized
INFO - 2023-08-05 13:01:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:01:52 --> Pagination Class Initialized
INFO - 2023-08-05 13:01:52 --> Form Validation Class Initialized
INFO - 2023-08-05 13:01:52 --> Controller Class Initialized
INFO - 2023-08-05 13:01:52 --> Model Class Initialized
DEBUG - 2023-08-05 13:01:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-05 13:01:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:01:53 --> Config Class Initialized
INFO - 2023-08-05 13:01:53 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:01:53 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:01:53 --> Utf8 Class Initialized
INFO - 2023-08-05 13:01:53 --> URI Class Initialized
INFO - 2023-08-05 13:01:53 --> Router Class Initialized
INFO - 2023-08-05 13:01:53 --> Output Class Initialized
INFO - 2023-08-05 13:01:53 --> Security Class Initialized
DEBUG - 2023-08-05 13:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:01:53 --> Input Class Initialized
INFO - 2023-08-05 13:01:53 --> Language Class Initialized
INFO - 2023-08-05 13:01:53 --> Loader Class Initialized
INFO - 2023-08-05 13:01:53 --> Helper loaded: url_helper
INFO - 2023-08-05 13:01:53 --> Helper loaded: file_helper
INFO - 2023-08-05 13:01:53 --> Helper loaded: html_helper
INFO - 2023-08-05 13:01:53 --> Helper loaded: text_helper
INFO - 2023-08-05 13:01:53 --> Helper loaded: form_helper
INFO - 2023-08-05 13:01:53 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:01:53 --> Helper loaded: security_helper
INFO - 2023-08-05 13:01:53 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:01:53 --> Database Driver Class Initialized
INFO - 2023-08-05 13:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:01:53 --> Parser Class Initialized
INFO - 2023-08-05 13:01:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:01:53 --> Pagination Class Initialized
INFO - 2023-08-05 13:01:53 --> Form Validation Class Initialized
INFO - 2023-08-05 13:01:53 --> Controller Class Initialized
INFO - 2023-08-05 13:01:53 --> Model Class Initialized
DEBUG - 2023-08-05 13:01:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:01:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-05 13:01:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:01:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:01:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:01:53 --> Model Class Initialized
INFO - 2023-08-05 13:01:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:01:53 --> Final output sent to browser
DEBUG - 2023-08-05 13:01:53 --> Total execution time: 0.0331
ERROR - 2023-08-05 13:02:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:02:14 --> Config Class Initialized
INFO - 2023-08-05 13:02:14 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:02:14 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:02:14 --> Utf8 Class Initialized
INFO - 2023-08-05 13:02:14 --> URI Class Initialized
INFO - 2023-08-05 13:02:14 --> Router Class Initialized
INFO - 2023-08-05 13:02:14 --> Output Class Initialized
INFO - 2023-08-05 13:02:14 --> Security Class Initialized
DEBUG - 2023-08-05 13:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:02:14 --> Input Class Initialized
INFO - 2023-08-05 13:02:14 --> Language Class Initialized
INFO - 2023-08-05 13:02:14 --> Loader Class Initialized
INFO - 2023-08-05 13:02:14 --> Helper loaded: url_helper
INFO - 2023-08-05 13:02:14 --> Helper loaded: file_helper
INFO - 2023-08-05 13:02:14 --> Helper loaded: html_helper
INFO - 2023-08-05 13:02:14 --> Helper loaded: text_helper
INFO - 2023-08-05 13:02:14 --> Helper loaded: form_helper
INFO - 2023-08-05 13:02:14 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:02:14 --> Helper loaded: security_helper
INFO - 2023-08-05 13:02:14 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:02:14 --> Database Driver Class Initialized
INFO - 2023-08-05 13:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:02:14 --> Parser Class Initialized
INFO - 2023-08-05 13:02:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:02:14 --> Pagination Class Initialized
INFO - 2023-08-05 13:02:14 --> Form Validation Class Initialized
INFO - 2023-08-05 13:02:14 --> Controller Class Initialized
INFO - 2023-08-05 13:02:14 --> Model Class Initialized
DEBUG - 2023-08-05 13:02:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:02:14 --> Model Class Initialized
INFO - 2023-08-05 13:02:14 --> Final output sent to browser
DEBUG - 2023-08-05 13:02:14 --> Total execution time: 0.0194
ERROR - 2023-08-05 13:02:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:02:15 --> Config Class Initialized
INFO - 2023-08-05 13:02:15 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:02:15 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:02:15 --> Utf8 Class Initialized
INFO - 2023-08-05 13:02:15 --> URI Class Initialized
INFO - 2023-08-05 13:02:15 --> Router Class Initialized
INFO - 2023-08-05 13:02:15 --> Output Class Initialized
INFO - 2023-08-05 13:02:15 --> Security Class Initialized
DEBUG - 2023-08-05 13:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:02:15 --> Input Class Initialized
INFO - 2023-08-05 13:02:15 --> Language Class Initialized
INFO - 2023-08-05 13:02:15 --> Loader Class Initialized
INFO - 2023-08-05 13:02:15 --> Helper loaded: url_helper
INFO - 2023-08-05 13:02:15 --> Helper loaded: file_helper
INFO - 2023-08-05 13:02:15 --> Helper loaded: html_helper
INFO - 2023-08-05 13:02:15 --> Helper loaded: text_helper
INFO - 2023-08-05 13:02:15 --> Helper loaded: form_helper
INFO - 2023-08-05 13:02:15 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:02:15 --> Helper loaded: security_helper
INFO - 2023-08-05 13:02:15 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:02:15 --> Database Driver Class Initialized
INFO - 2023-08-05 13:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:02:15 --> Parser Class Initialized
INFO - 2023-08-05 13:02:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:02:15 --> Pagination Class Initialized
INFO - 2023-08-05 13:02:15 --> Form Validation Class Initialized
INFO - 2023-08-05 13:02:15 --> Controller Class Initialized
INFO - 2023-08-05 13:02:15 --> Model Class Initialized
DEBUG - 2023-08-05 13:02:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:02:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-05 13:02:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:02:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:02:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:02:15 --> Model Class Initialized
INFO - 2023-08-05 13:02:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:02:15 --> Final output sent to browser
DEBUG - 2023-08-05 13:02:15 --> Total execution time: 0.0383
ERROR - 2023-08-05 13:02:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:02:26 --> Config Class Initialized
INFO - 2023-08-05 13:02:26 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:02:26 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:02:26 --> Utf8 Class Initialized
INFO - 2023-08-05 13:02:26 --> URI Class Initialized
INFO - 2023-08-05 13:02:26 --> Router Class Initialized
INFO - 2023-08-05 13:02:26 --> Output Class Initialized
INFO - 2023-08-05 13:02:26 --> Security Class Initialized
DEBUG - 2023-08-05 13:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:02:26 --> Input Class Initialized
INFO - 2023-08-05 13:02:26 --> Language Class Initialized
INFO - 2023-08-05 13:02:26 --> Loader Class Initialized
INFO - 2023-08-05 13:02:26 --> Helper loaded: url_helper
INFO - 2023-08-05 13:02:26 --> Helper loaded: file_helper
INFO - 2023-08-05 13:02:26 --> Helper loaded: html_helper
INFO - 2023-08-05 13:02:26 --> Helper loaded: text_helper
INFO - 2023-08-05 13:02:26 --> Helper loaded: form_helper
INFO - 2023-08-05 13:02:26 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:02:26 --> Helper loaded: security_helper
INFO - 2023-08-05 13:02:26 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:02:26 --> Database Driver Class Initialized
INFO - 2023-08-05 13:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:02:26 --> Parser Class Initialized
INFO - 2023-08-05 13:02:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:02:26 --> Pagination Class Initialized
INFO - 2023-08-05 13:02:26 --> Form Validation Class Initialized
INFO - 2023-08-05 13:02:26 --> Controller Class Initialized
INFO - 2023-08-05 13:02:26 --> Model Class Initialized
DEBUG - 2023-08-05 13:02:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:02:26 --> Model Class Initialized
INFO - 2023-08-05 13:02:26 --> Final output sent to browser
DEBUG - 2023-08-05 13:02:26 --> Total execution time: 0.0207
ERROR - 2023-08-05 13:02:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:02:26 --> Config Class Initialized
INFO - 2023-08-05 13:02:26 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:02:26 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:02:26 --> Utf8 Class Initialized
INFO - 2023-08-05 13:02:26 --> URI Class Initialized
INFO - 2023-08-05 13:02:26 --> Router Class Initialized
INFO - 2023-08-05 13:02:26 --> Output Class Initialized
INFO - 2023-08-05 13:02:26 --> Security Class Initialized
DEBUG - 2023-08-05 13:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:02:26 --> Input Class Initialized
INFO - 2023-08-05 13:02:26 --> Language Class Initialized
INFO - 2023-08-05 13:02:26 --> Loader Class Initialized
INFO - 2023-08-05 13:02:26 --> Helper loaded: url_helper
INFO - 2023-08-05 13:02:26 --> Helper loaded: file_helper
INFO - 2023-08-05 13:02:26 --> Helper loaded: html_helper
INFO - 2023-08-05 13:02:26 --> Helper loaded: text_helper
INFO - 2023-08-05 13:02:26 --> Helper loaded: form_helper
INFO - 2023-08-05 13:02:26 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:02:26 --> Helper loaded: security_helper
INFO - 2023-08-05 13:02:26 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:02:26 --> Database Driver Class Initialized
INFO - 2023-08-05 13:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:02:26 --> Parser Class Initialized
INFO - 2023-08-05 13:02:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:02:26 --> Pagination Class Initialized
INFO - 2023-08-05 13:02:26 --> Form Validation Class Initialized
INFO - 2023-08-05 13:02:26 --> Controller Class Initialized
INFO - 2023-08-05 13:02:26 --> Model Class Initialized
DEBUG - 2023-08-05 13:02:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:02:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-05 13:02:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:02:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:02:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:02:26 --> Model Class Initialized
INFO - 2023-08-05 13:02:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:02:26 --> Final output sent to browser
DEBUG - 2023-08-05 13:02:26 --> Total execution time: 0.0297
ERROR - 2023-08-05 13:02:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:02:41 --> Config Class Initialized
INFO - 2023-08-05 13:02:41 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:02:41 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:02:41 --> Utf8 Class Initialized
INFO - 2023-08-05 13:02:41 --> URI Class Initialized
INFO - 2023-08-05 13:02:41 --> Router Class Initialized
INFO - 2023-08-05 13:02:41 --> Output Class Initialized
INFO - 2023-08-05 13:02:41 --> Security Class Initialized
DEBUG - 2023-08-05 13:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:02:41 --> Input Class Initialized
INFO - 2023-08-05 13:02:41 --> Language Class Initialized
INFO - 2023-08-05 13:02:41 --> Loader Class Initialized
INFO - 2023-08-05 13:02:41 --> Helper loaded: url_helper
INFO - 2023-08-05 13:02:41 --> Helper loaded: file_helper
INFO - 2023-08-05 13:02:41 --> Helper loaded: html_helper
INFO - 2023-08-05 13:02:41 --> Helper loaded: text_helper
INFO - 2023-08-05 13:02:41 --> Helper loaded: form_helper
INFO - 2023-08-05 13:02:41 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:02:41 --> Helper loaded: security_helper
INFO - 2023-08-05 13:02:41 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:02:41 --> Database Driver Class Initialized
INFO - 2023-08-05 13:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:02:41 --> Parser Class Initialized
INFO - 2023-08-05 13:02:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:02:41 --> Pagination Class Initialized
INFO - 2023-08-05 13:02:41 --> Form Validation Class Initialized
INFO - 2023-08-05 13:02:41 --> Controller Class Initialized
INFO - 2023-08-05 13:02:41 --> Model Class Initialized
DEBUG - 2023-08-05 13:02:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:02:41 --> Model Class Initialized
INFO - 2023-08-05 13:02:41 --> Final output sent to browser
DEBUG - 2023-08-05 13:02:41 --> Total execution time: 0.0193
ERROR - 2023-08-05 13:02:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:02:41 --> Config Class Initialized
INFO - 2023-08-05 13:02:41 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:02:41 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:02:41 --> Utf8 Class Initialized
INFO - 2023-08-05 13:02:41 --> URI Class Initialized
INFO - 2023-08-05 13:02:41 --> Router Class Initialized
INFO - 2023-08-05 13:02:41 --> Output Class Initialized
INFO - 2023-08-05 13:02:41 --> Security Class Initialized
DEBUG - 2023-08-05 13:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:02:41 --> Input Class Initialized
INFO - 2023-08-05 13:02:41 --> Language Class Initialized
INFO - 2023-08-05 13:02:41 --> Loader Class Initialized
INFO - 2023-08-05 13:02:41 --> Helper loaded: url_helper
INFO - 2023-08-05 13:02:41 --> Helper loaded: file_helper
INFO - 2023-08-05 13:02:41 --> Helper loaded: html_helper
INFO - 2023-08-05 13:02:41 --> Helper loaded: text_helper
INFO - 2023-08-05 13:02:41 --> Helper loaded: form_helper
INFO - 2023-08-05 13:02:41 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:02:41 --> Helper loaded: security_helper
INFO - 2023-08-05 13:02:41 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:02:41 --> Database Driver Class Initialized
INFO - 2023-08-05 13:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:02:41 --> Parser Class Initialized
INFO - 2023-08-05 13:02:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:02:41 --> Pagination Class Initialized
INFO - 2023-08-05 13:02:41 --> Form Validation Class Initialized
INFO - 2023-08-05 13:02:41 --> Controller Class Initialized
INFO - 2023-08-05 13:02:41 --> Model Class Initialized
DEBUG - 2023-08-05 13:02:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:02:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-05 13:02:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:02:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:02:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:02:41 --> Model Class Initialized
INFO - 2023-08-05 13:02:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:02:41 --> Final output sent to browser
DEBUG - 2023-08-05 13:02:41 --> Total execution time: 0.0297
ERROR - 2023-08-05 13:02:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:02:51 --> Config Class Initialized
INFO - 2023-08-05 13:02:51 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:02:51 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:02:51 --> Utf8 Class Initialized
INFO - 2023-08-05 13:02:51 --> URI Class Initialized
INFO - 2023-08-05 13:02:51 --> Router Class Initialized
INFO - 2023-08-05 13:02:51 --> Output Class Initialized
INFO - 2023-08-05 13:02:51 --> Security Class Initialized
DEBUG - 2023-08-05 13:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:02:51 --> Input Class Initialized
INFO - 2023-08-05 13:02:51 --> Language Class Initialized
INFO - 2023-08-05 13:02:51 --> Loader Class Initialized
INFO - 2023-08-05 13:02:51 --> Helper loaded: url_helper
INFO - 2023-08-05 13:02:51 --> Helper loaded: file_helper
INFO - 2023-08-05 13:02:51 --> Helper loaded: html_helper
INFO - 2023-08-05 13:02:51 --> Helper loaded: text_helper
INFO - 2023-08-05 13:02:51 --> Helper loaded: form_helper
INFO - 2023-08-05 13:02:51 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:02:51 --> Helper loaded: security_helper
INFO - 2023-08-05 13:02:51 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:02:51 --> Database Driver Class Initialized
INFO - 2023-08-05 13:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:02:51 --> Parser Class Initialized
INFO - 2023-08-05 13:02:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:02:51 --> Pagination Class Initialized
INFO - 2023-08-05 13:02:51 --> Form Validation Class Initialized
INFO - 2023-08-05 13:02:51 --> Controller Class Initialized
INFO - 2023-08-05 13:02:51 --> Model Class Initialized
DEBUG - 2023-08-05 13:02:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:02:51 --> Final output sent to browser
DEBUG - 2023-08-05 13:02:51 --> Total execution time: 0.0169
ERROR - 2023-08-05 13:02:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:02:51 --> Config Class Initialized
INFO - 2023-08-05 13:02:51 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:02:51 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:02:51 --> Utf8 Class Initialized
INFO - 2023-08-05 13:02:51 --> URI Class Initialized
INFO - 2023-08-05 13:02:51 --> Router Class Initialized
INFO - 2023-08-05 13:02:51 --> Output Class Initialized
INFO - 2023-08-05 13:02:51 --> Security Class Initialized
DEBUG - 2023-08-05 13:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:02:51 --> Input Class Initialized
INFO - 2023-08-05 13:02:51 --> Language Class Initialized
INFO - 2023-08-05 13:02:51 --> Loader Class Initialized
INFO - 2023-08-05 13:02:51 --> Helper loaded: url_helper
INFO - 2023-08-05 13:02:51 --> Helper loaded: file_helper
INFO - 2023-08-05 13:02:51 --> Helper loaded: html_helper
INFO - 2023-08-05 13:02:51 --> Helper loaded: text_helper
INFO - 2023-08-05 13:02:51 --> Helper loaded: form_helper
INFO - 2023-08-05 13:02:51 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:02:51 --> Helper loaded: security_helper
INFO - 2023-08-05 13:02:51 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:02:51 --> Database Driver Class Initialized
INFO - 2023-08-05 13:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:02:51 --> Parser Class Initialized
INFO - 2023-08-05 13:02:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:02:51 --> Pagination Class Initialized
INFO - 2023-08-05 13:02:51 --> Form Validation Class Initialized
INFO - 2023-08-05 13:02:51 --> Controller Class Initialized
INFO - 2023-08-05 13:02:51 --> Model Class Initialized
DEBUG - 2023-08-05 13:02:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:02:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-05 13:02:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:02:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:02:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:02:51 --> Model Class Initialized
INFO - 2023-08-05 13:02:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:02:51 --> Final output sent to browser
DEBUG - 2023-08-05 13:02:51 --> Total execution time: 0.0308
ERROR - 2023-08-05 13:03:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:03:01 --> Config Class Initialized
INFO - 2023-08-05 13:03:01 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:03:01 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:03:01 --> Utf8 Class Initialized
INFO - 2023-08-05 13:03:01 --> URI Class Initialized
INFO - 2023-08-05 13:03:01 --> Router Class Initialized
INFO - 2023-08-05 13:03:01 --> Output Class Initialized
INFO - 2023-08-05 13:03:01 --> Security Class Initialized
DEBUG - 2023-08-05 13:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:03:01 --> Input Class Initialized
INFO - 2023-08-05 13:03:01 --> Language Class Initialized
INFO - 2023-08-05 13:03:01 --> Loader Class Initialized
INFO - 2023-08-05 13:03:01 --> Helper loaded: url_helper
INFO - 2023-08-05 13:03:01 --> Helper loaded: file_helper
INFO - 2023-08-05 13:03:01 --> Helper loaded: html_helper
INFO - 2023-08-05 13:03:01 --> Helper loaded: text_helper
INFO - 2023-08-05 13:03:01 --> Helper loaded: form_helper
INFO - 2023-08-05 13:03:01 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:03:01 --> Helper loaded: security_helper
INFO - 2023-08-05 13:03:01 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:03:01 --> Database Driver Class Initialized
INFO - 2023-08-05 13:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:03:01 --> Parser Class Initialized
INFO - 2023-08-05 13:03:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:03:01 --> Pagination Class Initialized
INFO - 2023-08-05 13:03:01 --> Form Validation Class Initialized
INFO - 2023-08-05 13:03:01 --> Controller Class Initialized
INFO - 2023-08-05 13:03:01 --> Model Class Initialized
DEBUG - 2023-08-05 13:03:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:01 --> Model Class Initialized
INFO - 2023-08-05 13:03:01 --> Final output sent to browser
DEBUG - 2023-08-05 13:03:01 --> Total execution time: 0.0200
ERROR - 2023-08-05 13:03:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:03:01 --> Config Class Initialized
INFO - 2023-08-05 13:03:01 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:03:01 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:03:01 --> Utf8 Class Initialized
INFO - 2023-08-05 13:03:01 --> URI Class Initialized
INFO - 2023-08-05 13:03:01 --> Router Class Initialized
INFO - 2023-08-05 13:03:01 --> Output Class Initialized
INFO - 2023-08-05 13:03:01 --> Security Class Initialized
DEBUG - 2023-08-05 13:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:03:01 --> Input Class Initialized
INFO - 2023-08-05 13:03:01 --> Language Class Initialized
INFO - 2023-08-05 13:03:01 --> Loader Class Initialized
INFO - 2023-08-05 13:03:01 --> Helper loaded: url_helper
INFO - 2023-08-05 13:03:01 --> Helper loaded: file_helper
INFO - 2023-08-05 13:03:01 --> Helper loaded: html_helper
INFO - 2023-08-05 13:03:01 --> Helper loaded: text_helper
INFO - 2023-08-05 13:03:01 --> Helper loaded: form_helper
INFO - 2023-08-05 13:03:01 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:03:01 --> Helper loaded: security_helper
INFO - 2023-08-05 13:03:01 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:03:01 --> Database Driver Class Initialized
INFO - 2023-08-05 13:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:03:01 --> Parser Class Initialized
INFO - 2023-08-05 13:03:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:03:01 --> Pagination Class Initialized
INFO - 2023-08-05 13:03:01 --> Form Validation Class Initialized
INFO - 2023-08-05 13:03:01 --> Controller Class Initialized
INFO - 2023-08-05 13:03:01 --> Model Class Initialized
DEBUG - 2023-08-05 13:03:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-05 13:03:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:03:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:03:01 --> Model Class Initialized
INFO - 2023-08-05 13:03:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:03:01 --> Final output sent to browser
DEBUG - 2023-08-05 13:03:01 --> Total execution time: 0.0306
ERROR - 2023-08-05 13:03:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:03:13 --> Config Class Initialized
INFO - 2023-08-05 13:03:13 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:03:13 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:03:13 --> Utf8 Class Initialized
INFO - 2023-08-05 13:03:13 --> URI Class Initialized
INFO - 2023-08-05 13:03:13 --> Router Class Initialized
INFO - 2023-08-05 13:03:13 --> Output Class Initialized
INFO - 2023-08-05 13:03:13 --> Security Class Initialized
DEBUG - 2023-08-05 13:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:03:13 --> Input Class Initialized
INFO - 2023-08-05 13:03:13 --> Language Class Initialized
INFO - 2023-08-05 13:03:13 --> Loader Class Initialized
INFO - 2023-08-05 13:03:13 --> Helper loaded: url_helper
INFO - 2023-08-05 13:03:13 --> Helper loaded: file_helper
INFO - 2023-08-05 13:03:13 --> Helper loaded: html_helper
INFO - 2023-08-05 13:03:13 --> Helper loaded: text_helper
INFO - 2023-08-05 13:03:13 --> Helper loaded: form_helper
INFO - 2023-08-05 13:03:13 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:03:13 --> Helper loaded: security_helper
INFO - 2023-08-05 13:03:13 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:03:13 --> Database Driver Class Initialized
INFO - 2023-08-05 13:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:03:13 --> Parser Class Initialized
INFO - 2023-08-05 13:03:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:03:13 --> Pagination Class Initialized
INFO - 2023-08-05 13:03:13 --> Form Validation Class Initialized
INFO - 2023-08-05 13:03:13 --> Controller Class Initialized
INFO - 2023-08-05 13:03:13 --> Model Class Initialized
DEBUG - 2023-08-05 13:03:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:13 --> Model Class Initialized
INFO - 2023-08-05 13:03:13 --> Final output sent to browser
DEBUG - 2023-08-05 13:03:13 --> Total execution time: 0.0186
ERROR - 2023-08-05 13:03:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:03:13 --> Config Class Initialized
INFO - 2023-08-05 13:03:13 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:03:13 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:03:13 --> Utf8 Class Initialized
INFO - 2023-08-05 13:03:13 --> URI Class Initialized
DEBUG - 2023-08-05 13:03:13 --> No URI present. Default controller set.
INFO - 2023-08-05 13:03:13 --> Router Class Initialized
INFO - 2023-08-05 13:03:13 --> Output Class Initialized
INFO - 2023-08-05 13:03:13 --> Security Class Initialized
DEBUG - 2023-08-05 13:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:03:13 --> Input Class Initialized
INFO - 2023-08-05 13:03:13 --> Language Class Initialized
INFO - 2023-08-05 13:03:13 --> Loader Class Initialized
INFO - 2023-08-05 13:03:13 --> Helper loaded: url_helper
INFO - 2023-08-05 13:03:13 --> Helper loaded: file_helper
INFO - 2023-08-05 13:03:13 --> Helper loaded: html_helper
INFO - 2023-08-05 13:03:13 --> Helper loaded: text_helper
INFO - 2023-08-05 13:03:13 --> Helper loaded: form_helper
INFO - 2023-08-05 13:03:13 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:03:13 --> Helper loaded: security_helper
INFO - 2023-08-05 13:03:13 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:03:13 --> Database Driver Class Initialized
INFO - 2023-08-05 13:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:03:13 --> Parser Class Initialized
INFO - 2023-08-05 13:03:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:03:13 --> Pagination Class Initialized
INFO - 2023-08-05 13:03:13 --> Form Validation Class Initialized
INFO - 2023-08-05 13:03:13 --> Controller Class Initialized
INFO - 2023-08-05 13:03:13 --> Model Class Initialized
DEBUG - 2023-08-05 13:03:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:13 --> Model Class Initialized
DEBUG - 2023-08-05 13:03:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:13 --> Model Class Initialized
INFO - 2023-08-05 13:03:13 --> Model Class Initialized
INFO - 2023-08-05 13:03:13 --> Model Class Initialized
INFO - 2023-08-05 13:03:13 --> Model Class Initialized
DEBUG - 2023-08-05 13:03:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:03:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:13 --> Model Class Initialized
INFO - 2023-08-05 13:03:13 --> Model Class Initialized
INFO - 2023-08-05 13:03:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 13:03:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:03:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:03:13 --> Model Class Initialized
INFO - 2023-08-05 13:03:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:03:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:03:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:03:13 --> Final output sent to browser
DEBUG - 2023-08-05 13:03:13 --> Total execution time: 0.0891
ERROR - 2023-08-05 13:03:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:03:14 --> Config Class Initialized
INFO - 2023-08-05 13:03:14 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:03:14 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:03:14 --> Utf8 Class Initialized
INFO - 2023-08-05 13:03:14 --> URI Class Initialized
INFO - 2023-08-05 13:03:14 --> Router Class Initialized
INFO - 2023-08-05 13:03:14 --> Output Class Initialized
INFO - 2023-08-05 13:03:14 --> Security Class Initialized
DEBUG - 2023-08-05 13:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:03:14 --> Input Class Initialized
INFO - 2023-08-05 13:03:14 --> Language Class Initialized
INFO - 2023-08-05 13:03:14 --> Loader Class Initialized
INFO - 2023-08-05 13:03:14 --> Helper loaded: url_helper
INFO - 2023-08-05 13:03:14 --> Helper loaded: file_helper
INFO - 2023-08-05 13:03:14 --> Helper loaded: html_helper
INFO - 2023-08-05 13:03:14 --> Helper loaded: text_helper
INFO - 2023-08-05 13:03:14 --> Helper loaded: form_helper
INFO - 2023-08-05 13:03:14 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:03:14 --> Helper loaded: security_helper
INFO - 2023-08-05 13:03:14 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:03:14 --> Database Driver Class Initialized
INFO - 2023-08-05 13:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:03:14 --> Parser Class Initialized
INFO - 2023-08-05 13:03:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:03:14 --> Pagination Class Initialized
INFO - 2023-08-05 13:03:14 --> Form Validation Class Initialized
INFO - 2023-08-05 13:03:14 --> Controller Class Initialized
INFO - 2023-08-05 13:03:14 --> Model Class Initialized
DEBUG - 2023-08-05 13:03:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:14 --> Model Class Initialized
INFO - 2023-08-05 13:03:14 --> Final output sent to browser
DEBUG - 2023-08-05 13:03:14 --> Total execution time: 0.0158
ERROR - 2023-08-05 13:03:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:03:15 --> Config Class Initialized
INFO - 2023-08-05 13:03:15 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:03:15 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:03:15 --> Utf8 Class Initialized
INFO - 2023-08-05 13:03:15 --> URI Class Initialized
INFO - 2023-08-05 13:03:15 --> Router Class Initialized
INFO - 2023-08-05 13:03:15 --> Output Class Initialized
INFO - 2023-08-05 13:03:15 --> Security Class Initialized
DEBUG - 2023-08-05 13:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:03:15 --> Input Class Initialized
INFO - 2023-08-05 13:03:15 --> Language Class Initialized
INFO - 2023-08-05 13:03:15 --> Loader Class Initialized
INFO - 2023-08-05 13:03:15 --> Helper loaded: url_helper
INFO - 2023-08-05 13:03:15 --> Helper loaded: file_helper
INFO - 2023-08-05 13:03:15 --> Helper loaded: html_helper
INFO - 2023-08-05 13:03:15 --> Helper loaded: text_helper
INFO - 2023-08-05 13:03:15 --> Helper loaded: form_helper
INFO - 2023-08-05 13:03:15 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:03:15 --> Helper loaded: security_helper
INFO - 2023-08-05 13:03:15 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:03:15 --> Database Driver Class Initialized
INFO - 2023-08-05 13:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:03:15 --> Parser Class Initialized
INFO - 2023-08-05 13:03:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:03:15 --> Pagination Class Initialized
INFO - 2023-08-05 13:03:15 --> Form Validation Class Initialized
INFO - 2023-08-05 13:03:15 --> Controller Class Initialized
INFO - 2023-08-05 13:03:15 --> Model Class Initialized
DEBUG - 2023-08-05 13:03:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-05 13:03:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:03:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:03:15 --> Model Class Initialized
INFO - 2023-08-05 13:03:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:03:15 --> Final output sent to browser
DEBUG - 2023-08-05 13:03:15 --> Total execution time: 0.0328
ERROR - 2023-08-05 13:03:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:03:26 --> Config Class Initialized
INFO - 2023-08-05 13:03:26 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:03:26 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:03:26 --> Utf8 Class Initialized
INFO - 2023-08-05 13:03:26 --> URI Class Initialized
INFO - 2023-08-05 13:03:26 --> Router Class Initialized
INFO - 2023-08-05 13:03:26 --> Output Class Initialized
INFO - 2023-08-05 13:03:26 --> Security Class Initialized
DEBUG - 2023-08-05 13:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:03:26 --> Input Class Initialized
INFO - 2023-08-05 13:03:26 --> Language Class Initialized
INFO - 2023-08-05 13:03:26 --> Loader Class Initialized
INFO - 2023-08-05 13:03:26 --> Helper loaded: url_helper
INFO - 2023-08-05 13:03:26 --> Helper loaded: file_helper
INFO - 2023-08-05 13:03:26 --> Helper loaded: html_helper
INFO - 2023-08-05 13:03:26 --> Helper loaded: text_helper
INFO - 2023-08-05 13:03:26 --> Helper loaded: form_helper
INFO - 2023-08-05 13:03:26 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:03:26 --> Helper loaded: security_helper
INFO - 2023-08-05 13:03:26 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:03:26 --> Database Driver Class Initialized
INFO - 2023-08-05 13:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:03:26 --> Parser Class Initialized
INFO - 2023-08-05 13:03:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:03:26 --> Pagination Class Initialized
INFO - 2023-08-05 13:03:26 --> Form Validation Class Initialized
INFO - 2023-08-05 13:03:26 --> Controller Class Initialized
INFO - 2023-08-05 13:03:26 --> Model Class Initialized
DEBUG - 2023-08-05 13:03:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:03:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:26 --> Model Class Initialized
DEBUG - 2023-08-05 13:03:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:26 --> Model Class Initialized
INFO - 2023-08-05 13:03:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 13:03:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:03:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:03:26 --> Model Class Initialized
INFO - 2023-08-05 13:03:26 --> Model Class Initialized
INFO - 2023-08-05 13:03:26 --> Model Class Initialized
INFO - 2023-08-05 13:03:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:03:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:03:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:03:26 --> Final output sent to browser
DEBUG - 2023-08-05 13:03:26 --> Total execution time: 0.0800
ERROR - 2023-08-05 13:03:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:03:27 --> Config Class Initialized
INFO - 2023-08-05 13:03:27 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:03:27 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:03:27 --> Utf8 Class Initialized
INFO - 2023-08-05 13:03:27 --> URI Class Initialized
INFO - 2023-08-05 13:03:27 --> Router Class Initialized
INFO - 2023-08-05 13:03:27 --> Output Class Initialized
INFO - 2023-08-05 13:03:27 --> Security Class Initialized
DEBUG - 2023-08-05 13:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:03:27 --> Input Class Initialized
INFO - 2023-08-05 13:03:27 --> Language Class Initialized
INFO - 2023-08-05 13:03:27 --> Loader Class Initialized
INFO - 2023-08-05 13:03:27 --> Helper loaded: url_helper
INFO - 2023-08-05 13:03:27 --> Helper loaded: file_helper
INFO - 2023-08-05 13:03:27 --> Helper loaded: html_helper
INFO - 2023-08-05 13:03:27 --> Helper loaded: text_helper
INFO - 2023-08-05 13:03:27 --> Helper loaded: form_helper
INFO - 2023-08-05 13:03:27 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:03:27 --> Helper loaded: security_helper
INFO - 2023-08-05 13:03:27 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:03:27 --> Database Driver Class Initialized
INFO - 2023-08-05 13:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:03:27 --> Parser Class Initialized
INFO - 2023-08-05 13:03:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:03:27 --> Pagination Class Initialized
INFO - 2023-08-05 13:03:27 --> Form Validation Class Initialized
INFO - 2023-08-05 13:03:27 --> Controller Class Initialized
INFO - 2023-08-05 13:03:27 --> Model Class Initialized
DEBUG - 2023-08-05 13:03:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:03:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:27 --> Model Class Initialized
DEBUG - 2023-08-05 13:03:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:27 --> Model Class Initialized
INFO - 2023-08-05 13:03:27 --> Final output sent to browser
DEBUG - 2023-08-05 13:03:27 --> Total execution time: 0.0382
ERROR - 2023-08-05 13:03:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:03:30 --> Config Class Initialized
INFO - 2023-08-05 13:03:30 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:03:30 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:03:30 --> Utf8 Class Initialized
INFO - 2023-08-05 13:03:30 --> URI Class Initialized
INFO - 2023-08-05 13:03:30 --> Router Class Initialized
INFO - 2023-08-05 13:03:30 --> Output Class Initialized
INFO - 2023-08-05 13:03:30 --> Security Class Initialized
DEBUG - 2023-08-05 13:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:03:30 --> Input Class Initialized
INFO - 2023-08-05 13:03:30 --> Language Class Initialized
INFO - 2023-08-05 13:03:30 --> Loader Class Initialized
INFO - 2023-08-05 13:03:30 --> Helper loaded: url_helper
INFO - 2023-08-05 13:03:30 --> Helper loaded: file_helper
INFO - 2023-08-05 13:03:30 --> Helper loaded: html_helper
INFO - 2023-08-05 13:03:30 --> Helper loaded: text_helper
INFO - 2023-08-05 13:03:30 --> Helper loaded: form_helper
INFO - 2023-08-05 13:03:30 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:03:30 --> Helper loaded: security_helper
INFO - 2023-08-05 13:03:30 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:03:30 --> Database Driver Class Initialized
INFO - 2023-08-05 13:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:03:30 --> Parser Class Initialized
INFO - 2023-08-05 13:03:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:03:30 --> Pagination Class Initialized
INFO - 2023-08-05 13:03:30 --> Form Validation Class Initialized
INFO - 2023-08-05 13:03:30 --> Controller Class Initialized
INFO - 2023-08-05 13:03:30 --> Model Class Initialized
DEBUG - 2023-08-05 13:03:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:03:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:30 --> Model Class Initialized
DEBUG - 2023-08-05 13:03:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:30 --> Model Class Initialized
INFO - 2023-08-05 13:03:30 --> Final output sent to browser
DEBUG - 2023-08-05 13:03:30 --> Total execution time: 0.0782
ERROR - 2023-08-05 13:03:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:03:34 --> Config Class Initialized
INFO - 2023-08-05 13:03:34 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:03:34 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:03:34 --> Utf8 Class Initialized
INFO - 2023-08-05 13:03:34 --> URI Class Initialized
INFO - 2023-08-05 13:03:34 --> Router Class Initialized
INFO - 2023-08-05 13:03:34 --> Output Class Initialized
INFO - 2023-08-05 13:03:34 --> Security Class Initialized
DEBUG - 2023-08-05 13:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:03:34 --> Input Class Initialized
INFO - 2023-08-05 13:03:34 --> Language Class Initialized
INFO - 2023-08-05 13:03:34 --> Loader Class Initialized
INFO - 2023-08-05 13:03:34 --> Helper loaded: url_helper
INFO - 2023-08-05 13:03:34 --> Helper loaded: file_helper
INFO - 2023-08-05 13:03:34 --> Helper loaded: html_helper
INFO - 2023-08-05 13:03:34 --> Helper loaded: text_helper
INFO - 2023-08-05 13:03:34 --> Helper loaded: form_helper
INFO - 2023-08-05 13:03:34 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:03:34 --> Helper loaded: security_helper
INFO - 2023-08-05 13:03:34 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:03:34 --> Database Driver Class Initialized
INFO - 2023-08-05 13:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:03:34 --> Parser Class Initialized
INFO - 2023-08-05 13:03:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:03:34 --> Pagination Class Initialized
INFO - 2023-08-05 13:03:34 --> Form Validation Class Initialized
INFO - 2023-08-05 13:03:34 --> Controller Class Initialized
INFO - 2023-08-05 13:03:34 --> Model Class Initialized
DEBUG - 2023-08-05 13:03:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:34 --> Model Class Initialized
INFO - 2023-08-05 13:03:34 --> Final output sent to browser
DEBUG - 2023-08-05 13:03:34 --> Total execution time: 0.0164
ERROR - 2023-08-05 13:03:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:03:34 --> Config Class Initialized
INFO - 2023-08-05 13:03:34 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:03:34 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:03:34 --> Utf8 Class Initialized
INFO - 2023-08-05 13:03:34 --> URI Class Initialized
DEBUG - 2023-08-05 13:03:34 --> No URI present. Default controller set.
INFO - 2023-08-05 13:03:34 --> Router Class Initialized
INFO - 2023-08-05 13:03:34 --> Output Class Initialized
INFO - 2023-08-05 13:03:34 --> Security Class Initialized
DEBUG - 2023-08-05 13:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:03:34 --> Input Class Initialized
INFO - 2023-08-05 13:03:34 --> Language Class Initialized
INFO - 2023-08-05 13:03:34 --> Loader Class Initialized
INFO - 2023-08-05 13:03:34 --> Helper loaded: url_helper
INFO - 2023-08-05 13:03:34 --> Helper loaded: file_helper
INFO - 2023-08-05 13:03:34 --> Helper loaded: html_helper
INFO - 2023-08-05 13:03:34 --> Helper loaded: text_helper
INFO - 2023-08-05 13:03:34 --> Helper loaded: form_helper
INFO - 2023-08-05 13:03:34 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:03:34 --> Helper loaded: security_helper
INFO - 2023-08-05 13:03:34 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:03:34 --> Database Driver Class Initialized
INFO - 2023-08-05 13:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:03:34 --> Parser Class Initialized
INFO - 2023-08-05 13:03:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:03:34 --> Pagination Class Initialized
INFO - 2023-08-05 13:03:34 --> Form Validation Class Initialized
INFO - 2023-08-05 13:03:34 --> Controller Class Initialized
INFO - 2023-08-05 13:03:34 --> Model Class Initialized
DEBUG - 2023-08-05 13:03:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:34 --> Model Class Initialized
DEBUG - 2023-08-05 13:03:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:34 --> Model Class Initialized
INFO - 2023-08-05 13:03:34 --> Model Class Initialized
INFO - 2023-08-05 13:03:34 --> Model Class Initialized
INFO - 2023-08-05 13:03:34 --> Model Class Initialized
DEBUG - 2023-08-05 13:03:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:03:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:34 --> Model Class Initialized
INFO - 2023-08-05 13:03:34 --> Model Class Initialized
INFO - 2023-08-05 13:03:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 13:03:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:03:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:03:34 --> Model Class Initialized
INFO - 2023-08-05 13:03:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:03:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:03:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:03:34 --> Final output sent to browser
DEBUG - 2023-08-05 13:03:34 --> Total execution time: 0.0771
ERROR - 2023-08-05 13:03:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:03:53 --> Config Class Initialized
INFO - 2023-08-05 13:03:53 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:03:53 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:03:53 --> Utf8 Class Initialized
INFO - 2023-08-05 13:03:53 --> URI Class Initialized
INFO - 2023-08-05 13:03:53 --> Router Class Initialized
INFO - 2023-08-05 13:03:53 --> Output Class Initialized
INFO - 2023-08-05 13:03:53 --> Security Class Initialized
DEBUG - 2023-08-05 13:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:03:53 --> Input Class Initialized
INFO - 2023-08-05 13:03:53 --> Language Class Initialized
INFO - 2023-08-05 13:03:53 --> Loader Class Initialized
INFO - 2023-08-05 13:03:53 --> Helper loaded: url_helper
INFO - 2023-08-05 13:03:53 --> Helper loaded: file_helper
INFO - 2023-08-05 13:03:53 --> Helper loaded: html_helper
INFO - 2023-08-05 13:03:53 --> Helper loaded: text_helper
INFO - 2023-08-05 13:03:53 --> Helper loaded: form_helper
INFO - 2023-08-05 13:03:53 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:03:53 --> Helper loaded: security_helper
INFO - 2023-08-05 13:03:53 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:03:53 --> Database Driver Class Initialized
INFO - 2023-08-05 13:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:03:53 --> Parser Class Initialized
INFO - 2023-08-05 13:03:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:03:53 --> Pagination Class Initialized
INFO - 2023-08-05 13:03:53 --> Form Validation Class Initialized
INFO - 2023-08-05 13:03:53 --> Controller Class Initialized
INFO - 2023-08-05 13:03:53 --> Model Class Initialized
DEBUG - 2023-08-05 13:03:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:03:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:53 --> Model Class Initialized
DEBUG - 2023-08-05 13:03:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:53 --> Model Class Initialized
INFO - 2023-08-05 13:03:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 13:03:53 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:03:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:03:53 --> Model Class Initialized
INFO - 2023-08-05 13:03:53 --> Model Class Initialized
INFO - 2023-08-05 13:03:53 --> Model Class Initialized
INFO - 2023-08-05 13:03:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:03:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:03:53 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:03:53 --> Final output sent to browser
DEBUG - 2023-08-05 13:03:53 --> Total execution time: 0.0765
ERROR - 2023-08-05 13:03:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:03:54 --> Config Class Initialized
INFO - 2023-08-05 13:03:54 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:03:54 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:03:54 --> Utf8 Class Initialized
INFO - 2023-08-05 13:03:54 --> URI Class Initialized
INFO - 2023-08-05 13:03:54 --> Router Class Initialized
INFO - 2023-08-05 13:03:54 --> Output Class Initialized
INFO - 2023-08-05 13:03:54 --> Security Class Initialized
DEBUG - 2023-08-05 13:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:03:54 --> Input Class Initialized
INFO - 2023-08-05 13:03:54 --> Language Class Initialized
INFO - 2023-08-05 13:03:54 --> Loader Class Initialized
INFO - 2023-08-05 13:03:54 --> Helper loaded: url_helper
INFO - 2023-08-05 13:03:54 --> Helper loaded: file_helper
INFO - 2023-08-05 13:03:54 --> Helper loaded: html_helper
INFO - 2023-08-05 13:03:54 --> Helper loaded: text_helper
INFO - 2023-08-05 13:03:54 --> Helper loaded: form_helper
INFO - 2023-08-05 13:03:54 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:03:54 --> Helper loaded: security_helper
INFO - 2023-08-05 13:03:54 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:03:54 --> Database Driver Class Initialized
INFO - 2023-08-05 13:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:03:54 --> Parser Class Initialized
INFO - 2023-08-05 13:03:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:03:54 --> Pagination Class Initialized
INFO - 2023-08-05 13:03:54 --> Form Validation Class Initialized
INFO - 2023-08-05 13:03:54 --> Controller Class Initialized
INFO - 2023-08-05 13:03:54 --> Model Class Initialized
DEBUG - 2023-08-05 13:03:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:03:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:54 --> Model Class Initialized
DEBUG - 2023-08-05 13:03:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:03:54 --> Model Class Initialized
INFO - 2023-08-05 13:03:54 --> Final output sent to browser
DEBUG - 2023-08-05 13:03:54 --> Total execution time: 0.0284
ERROR - 2023-08-05 13:04:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:04:18 --> Config Class Initialized
INFO - 2023-08-05 13:04:18 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:04:18 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:04:18 --> Utf8 Class Initialized
INFO - 2023-08-05 13:04:18 --> URI Class Initialized
DEBUG - 2023-08-05 13:04:18 --> No URI present. Default controller set.
INFO - 2023-08-05 13:04:18 --> Router Class Initialized
INFO - 2023-08-05 13:04:18 --> Output Class Initialized
INFO - 2023-08-05 13:04:18 --> Security Class Initialized
DEBUG - 2023-08-05 13:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:04:18 --> Input Class Initialized
INFO - 2023-08-05 13:04:18 --> Language Class Initialized
INFO - 2023-08-05 13:04:18 --> Loader Class Initialized
INFO - 2023-08-05 13:04:18 --> Helper loaded: url_helper
INFO - 2023-08-05 13:04:18 --> Helper loaded: file_helper
INFO - 2023-08-05 13:04:18 --> Helper loaded: html_helper
INFO - 2023-08-05 13:04:18 --> Helper loaded: text_helper
INFO - 2023-08-05 13:04:18 --> Helper loaded: form_helper
INFO - 2023-08-05 13:04:18 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:04:18 --> Helper loaded: security_helper
INFO - 2023-08-05 13:04:18 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:04:18 --> Database Driver Class Initialized
INFO - 2023-08-05 13:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:04:18 --> Parser Class Initialized
INFO - 2023-08-05 13:04:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:04:18 --> Pagination Class Initialized
INFO - 2023-08-05 13:04:18 --> Form Validation Class Initialized
INFO - 2023-08-05 13:04:18 --> Controller Class Initialized
INFO - 2023-08-05 13:04:18 --> Model Class Initialized
DEBUG - 2023-08-05 13:04:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:04:18 --> Model Class Initialized
DEBUG - 2023-08-05 13:04:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:04:18 --> Model Class Initialized
INFO - 2023-08-05 13:04:18 --> Model Class Initialized
INFO - 2023-08-05 13:04:18 --> Model Class Initialized
INFO - 2023-08-05 13:04:18 --> Model Class Initialized
DEBUG - 2023-08-05 13:04:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:04:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:04:18 --> Model Class Initialized
INFO - 2023-08-05 13:04:18 --> Model Class Initialized
INFO - 2023-08-05 13:04:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 13:04:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:04:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:04:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:04:19 --> Model Class Initialized
INFO - 2023-08-05 13:04:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:04:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:04:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:04:19 --> Final output sent to browser
DEBUG - 2023-08-05 13:04:19 --> Total execution time: 0.1035
ERROR - 2023-08-05 13:04:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:04:23 --> Config Class Initialized
INFO - 2023-08-05 13:04:23 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:04:23 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:04:23 --> Utf8 Class Initialized
INFO - 2023-08-05 13:04:23 --> URI Class Initialized
INFO - 2023-08-05 13:04:23 --> Router Class Initialized
INFO - 2023-08-05 13:04:23 --> Output Class Initialized
INFO - 2023-08-05 13:04:23 --> Security Class Initialized
DEBUG - 2023-08-05 13:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:04:23 --> Input Class Initialized
INFO - 2023-08-05 13:04:23 --> Language Class Initialized
INFO - 2023-08-05 13:04:23 --> Loader Class Initialized
INFO - 2023-08-05 13:04:23 --> Helper loaded: url_helper
INFO - 2023-08-05 13:04:23 --> Helper loaded: file_helper
INFO - 2023-08-05 13:04:23 --> Helper loaded: html_helper
INFO - 2023-08-05 13:04:23 --> Helper loaded: text_helper
INFO - 2023-08-05 13:04:23 --> Helper loaded: form_helper
INFO - 2023-08-05 13:04:23 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:04:23 --> Helper loaded: security_helper
INFO - 2023-08-05 13:04:23 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:04:23 --> Database Driver Class Initialized
INFO - 2023-08-05 13:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:04:23 --> Parser Class Initialized
INFO - 2023-08-05 13:04:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:04:23 --> Pagination Class Initialized
INFO - 2023-08-05 13:04:23 --> Form Validation Class Initialized
INFO - 2023-08-05 13:04:23 --> Controller Class Initialized
INFO - 2023-08-05 13:04:23 --> Model Class Initialized
DEBUG - 2023-08-05 13:04:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:04:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:04:23 --> Model Class Initialized
DEBUG - 2023-08-05 13:04:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:04:23 --> Model Class Initialized
DEBUG - 2023-08-05 13:04:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:04:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-05 13:04:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:04:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:04:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:04:23 --> Model Class Initialized
INFO - 2023-08-05 13:04:23 --> Model Class Initialized
INFO - 2023-08-05 13:04:23 --> Model Class Initialized
INFO - 2023-08-05 13:04:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:04:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:04:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:04:23 --> Final output sent to browser
DEBUG - 2023-08-05 13:04:23 --> Total execution time: 0.0889
ERROR - 2023-08-05 13:04:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:04:27 --> Config Class Initialized
INFO - 2023-08-05 13:04:27 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:04:27 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:04:27 --> Utf8 Class Initialized
INFO - 2023-08-05 13:04:27 --> URI Class Initialized
INFO - 2023-08-05 13:04:27 --> Router Class Initialized
INFO - 2023-08-05 13:04:27 --> Output Class Initialized
INFO - 2023-08-05 13:04:27 --> Security Class Initialized
DEBUG - 2023-08-05 13:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:04:27 --> Input Class Initialized
INFO - 2023-08-05 13:04:27 --> Language Class Initialized
INFO - 2023-08-05 13:04:27 --> Loader Class Initialized
INFO - 2023-08-05 13:04:27 --> Helper loaded: url_helper
INFO - 2023-08-05 13:04:27 --> Helper loaded: file_helper
INFO - 2023-08-05 13:04:27 --> Helper loaded: html_helper
INFO - 2023-08-05 13:04:27 --> Helper loaded: text_helper
INFO - 2023-08-05 13:04:27 --> Helper loaded: form_helper
INFO - 2023-08-05 13:04:27 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:04:27 --> Helper loaded: security_helper
INFO - 2023-08-05 13:04:27 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:04:27 --> Database Driver Class Initialized
INFO - 2023-08-05 13:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:04:27 --> Parser Class Initialized
INFO - 2023-08-05 13:04:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:04:27 --> Pagination Class Initialized
INFO - 2023-08-05 13:04:27 --> Form Validation Class Initialized
INFO - 2023-08-05 13:04:27 --> Controller Class Initialized
DEBUG - 2023-08-05 13:04:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:04:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:04:27 --> Model Class Initialized
DEBUG - 2023-08-05 13:04:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:04:27 --> Model Class Initialized
DEBUG - 2023-08-05 13:04:27 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:04:27 --> Model Class Initialized
INFO - 2023-08-05 13:04:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-08-05 13:04:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:04:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:04:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:04:27 --> Model Class Initialized
INFO - 2023-08-05 13:04:27 --> Model Class Initialized
INFO - 2023-08-05 13:04:27 --> Model Class Initialized
INFO - 2023-08-05 13:04:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:04:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:04:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:04:27 --> Final output sent to browser
DEBUG - 2023-08-05 13:04:27 --> Total execution time: 0.0744
ERROR - 2023-08-05 13:04:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:04:27 --> Config Class Initialized
INFO - 2023-08-05 13:04:27 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:04:27 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:04:27 --> Utf8 Class Initialized
INFO - 2023-08-05 13:04:27 --> URI Class Initialized
INFO - 2023-08-05 13:04:27 --> Router Class Initialized
INFO - 2023-08-05 13:04:27 --> Output Class Initialized
INFO - 2023-08-05 13:04:27 --> Security Class Initialized
DEBUG - 2023-08-05 13:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:04:27 --> Input Class Initialized
INFO - 2023-08-05 13:04:27 --> Language Class Initialized
INFO - 2023-08-05 13:04:27 --> Loader Class Initialized
INFO - 2023-08-05 13:04:27 --> Helper loaded: url_helper
INFO - 2023-08-05 13:04:27 --> Helper loaded: file_helper
INFO - 2023-08-05 13:04:27 --> Helper loaded: html_helper
INFO - 2023-08-05 13:04:27 --> Helper loaded: text_helper
INFO - 2023-08-05 13:04:27 --> Helper loaded: form_helper
INFO - 2023-08-05 13:04:27 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:04:27 --> Helper loaded: security_helper
INFO - 2023-08-05 13:04:27 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:04:27 --> Database Driver Class Initialized
INFO - 2023-08-05 13:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:04:27 --> Parser Class Initialized
INFO - 2023-08-05 13:04:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:04:27 --> Pagination Class Initialized
INFO - 2023-08-05 13:04:27 --> Form Validation Class Initialized
INFO - 2023-08-05 13:04:27 --> Controller Class Initialized
DEBUG - 2023-08-05 13:04:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:04:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:04:27 --> Model Class Initialized
DEBUG - 2023-08-05 13:04:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:04:27 --> Model Class Initialized
INFO - 2023-08-05 13:04:28 --> Final output sent to browser
DEBUG - 2023-08-05 13:04:28 --> Total execution time: 0.0204
ERROR - 2023-08-05 13:04:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:04:33 --> Config Class Initialized
INFO - 2023-08-05 13:04:33 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:04:33 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:04:33 --> Utf8 Class Initialized
INFO - 2023-08-05 13:04:33 --> URI Class Initialized
INFO - 2023-08-05 13:04:33 --> Router Class Initialized
INFO - 2023-08-05 13:04:33 --> Output Class Initialized
INFO - 2023-08-05 13:04:33 --> Security Class Initialized
DEBUG - 2023-08-05 13:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:04:33 --> Input Class Initialized
INFO - 2023-08-05 13:04:33 --> Language Class Initialized
INFO - 2023-08-05 13:04:33 --> Loader Class Initialized
INFO - 2023-08-05 13:04:33 --> Helper loaded: url_helper
INFO - 2023-08-05 13:04:33 --> Helper loaded: file_helper
INFO - 2023-08-05 13:04:33 --> Helper loaded: html_helper
INFO - 2023-08-05 13:04:33 --> Helper loaded: text_helper
INFO - 2023-08-05 13:04:33 --> Helper loaded: form_helper
INFO - 2023-08-05 13:04:33 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:04:33 --> Helper loaded: security_helper
INFO - 2023-08-05 13:04:33 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:04:33 --> Database Driver Class Initialized
INFO - 2023-08-05 13:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:04:33 --> Parser Class Initialized
INFO - 2023-08-05 13:04:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:04:33 --> Pagination Class Initialized
INFO - 2023-08-05 13:04:33 --> Form Validation Class Initialized
INFO - 2023-08-05 13:04:33 --> Controller Class Initialized
DEBUG - 2023-08-05 13:04:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:04:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:04:33 --> Model Class Initialized
DEBUG - 2023-08-05 13:04:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:04:33 --> Model Class Initialized
INFO - 2023-08-05 13:04:33 --> Final output sent to browser
DEBUG - 2023-08-05 13:04:33 --> Total execution time: 0.0241
ERROR - 2023-08-05 13:05:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:05:26 --> Config Class Initialized
INFO - 2023-08-05 13:05:26 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:05:26 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:05:26 --> Utf8 Class Initialized
INFO - 2023-08-05 13:05:26 --> URI Class Initialized
INFO - 2023-08-05 13:05:26 --> Router Class Initialized
INFO - 2023-08-05 13:05:26 --> Output Class Initialized
INFO - 2023-08-05 13:05:26 --> Security Class Initialized
DEBUG - 2023-08-05 13:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:05:26 --> Input Class Initialized
INFO - 2023-08-05 13:05:26 --> Language Class Initialized
INFO - 2023-08-05 13:05:26 --> Loader Class Initialized
INFO - 2023-08-05 13:05:26 --> Helper loaded: url_helper
INFO - 2023-08-05 13:05:26 --> Helper loaded: file_helper
INFO - 2023-08-05 13:05:26 --> Helper loaded: html_helper
INFO - 2023-08-05 13:05:26 --> Helper loaded: text_helper
INFO - 2023-08-05 13:05:26 --> Helper loaded: form_helper
INFO - 2023-08-05 13:05:26 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:05:26 --> Helper loaded: security_helper
INFO - 2023-08-05 13:05:26 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:05:26 --> Database Driver Class Initialized
INFO - 2023-08-05 13:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:05:26 --> Parser Class Initialized
INFO - 2023-08-05 13:05:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:05:26 --> Pagination Class Initialized
INFO - 2023-08-05 13:05:26 --> Form Validation Class Initialized
INFO - 2023-08-05 13:05:26 --> Controller Class Initialized
INFO - 2023-08-05 13:05:26 --> Model Class Initialized
DEBUG - 2023-08-05 13:05:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:05:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:05:26 --> Model Class Initialized
DEBUG - 2023-08-05 13:05:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:05:26 --> Model Class Initialized
INFO - 2023-08-05 13:05:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 13:05:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:05:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:05:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:05:26 --> Model Class Initialized
INFO - 2023-08-05 13:05:26 --> Model Class Initialized
INFO - 2023-08-05 13:05:26 --> Model Class Initialized
INFO - 2023-08-05 13:05:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:05:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:05:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:05:26 --> Final output sent to browser
DEBUG - 2023-08-05 13:05:26 --> Total execution time: 0.0761
ERROR - 2023-08-05 13:05:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:05:27 --> Config Class Initialized
INFO - 2023-08-05 13:05:27 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:05:27 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:05:27 --> Utf8 Class Initialized
INFO - 2023-08-05 13:05:27 --> URI Class Initialized
INFO - 2023-08-05 13:05:27 --> Router Class Initialized
INFO - 2023-08-05 13:05:27 --> Output Class Initialized
INFO - 2023-08-05 13:05:27 --> Security Class Initialized
DEBUG - 2023-08-05 13:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:05:27 --> Input Class Initialized
INFO - 2023-08-05 13:05:27 --> Language Class Initialized
INFO - 2023-08-05 13:05:27 --> Loader Class Initialized
INFO - 2023-08-05 13:05:27 --> Helper loaded: url_helper
INFO - 2023-08-05 13:05:27 --> Helper loaded: file_helper
INFO - 2023-08-05 13:05:27 --> Helper loaded: html_helper
INFO - 2023-08-05 13:05:27 --> Helper loaded: text_helper
INFO - 2023-08-05 13:05:27 --> Helper loaded: form_helper
INFO - 2023-08-05 13:05:27 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:05:27 --> Helper loaded: security_helper
INFO - 2023-08-05 13:05:27 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:05:27 --> Database Driver Class Initialized
INFO - 2023-08-05 13:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:05:27 --> Parser Class Initialized
INFO - 2023-08-05 13:05:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:05:27 --> Pagination Class Initialized
INFO - 2023-08-05 13:05:27 --> Form Validation Class Initialized
INFO - 2023-08-05 13:05:27 --> Controller Class Initialized
INFO - 2023-08-05 13:05:27 --> Model Class Initialized
DEBUG - 2023-08-05 13:05:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:05:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:05:27 --> Model Class Initialized
DEBUG - 2023-08-05 13:05:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:05:27 --> Model Class Initialized
INFO - 2023-08-05 13:05:27 --> Final output sent to browser
DEBUG - 2023-08-05 13:05:27 --> Total execution time: 0.0264
ERROR - 2023-08-05 13:05:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:05:35 --> Config Class Initialized
INFO - 2023-08-05 13:05:35 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:05:35 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:05:35 --> Utf8 Class Initialized
INFO - 2023-08-05 13:05:35 --> URI Class Initialized
DEBUG - 2023-08-05 13:05:35 --> No URI present. Default controller set.
INFO - 2023-08-05 13:05:35 --> Router Class Initialized
INFO - 2023-08-05 13:05:35 --> Output Class Initialized
INFO - 2023-08-05 13:05:35 --> Security Class Initialized
DEBUG - 2023-08-05 13:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:05:35 --> Input Class Initialized
INFO - 2023-08-05 13:05:35 --> Language Class Initialized
INFO - 2023-08-05 13:05:35 --> Loader Class Initialized
INFO - 2023-08-05 13:05:35 --> Helper loaded: url_helper
INFO - 2023-08-05 13:05:35 --> Helper loaded: file_helper
INFO - 2023-08-05 13:05:35 --> Helper loaded: html_helper
INFO - 2023-08-05 13:05:35 --> Helper loaded: text_helper
INFO - 2023-08-05 13:05:35 --> Helper loaded: form_helper
INFO - 2023-08-05 13:05:35 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:05:35 --> Helper loaded: security_helper
INFO - 2023-08-05 13:05:35 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:05:35 --> Database Driver Class Initialized
INFO - 2023-08-05 13:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:05:35 --> Parser Class Initialized
INFO - 2023-08-05 13:05:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:05:35 --> Pagination Class Initialized
INFO - 2023-08-05 13:05:35 --> Form Validation Class Initialized
INFO - 2023-08-05 13:05:35 --> Controller Class Initialized
INFO - 2023-08-05 13:05:35 --> Model Class Initialized
DEBUG - 2023-08-05 13:05:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:05:35 --> Model Class Initialized
DEBUG - 2023-08-05 13:05:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:05:35 --> Model Class Initialized
INFO - 2023-08-05 13:05:35 --> Model Class Initialized
INFO - 2023-08-05 13:05:35 --> Model Class Initialized
INFO - 2023-08-05 13:05:35 --> Model Class Initialized
DEBUG - 2023-08-05 13:05:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:05:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:05:35 --> Model Class Initialized
INFO - 2023-08-05 13:05:35 --> Model Class Initialized
INFO - 2023-08-05 13:05:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 13:05:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:05:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:05:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:05:35 --> Model Class Initialized
INFO - 2023-08-05 13:05:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:05:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:05:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:05:35 --> Final output sent to browser
DEBUG - 2023-08-05 13:05:35 --> Total execution time: 0.0771
ERROR - 2023-08-05 13:06:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:06:08 --> Config Class Initialized
INFO - 2023-08-05 13:06:08 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:06:08 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:06:08 --> Utf8 Class Initialized
INFO - 2023-08-05 13:06:08 --> URI Class Initialized
INFO - 2023-08-05 13:06:08 --> Router Class Initialized
INFO - 2023-08-05 13:06:08 --> Output Class Initialized
INFO - 2023-08-05 13:06:08 --> Security Class Initialized
DEBUG - 2023-08-05 13:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:06:08 --> Input Class Initialized
INFO - 2023-08-05 13:06:08 --> Language Class Initialized
INFO - 2023-08-05 13:06:08 --> Loader Class Initialized
INFO - 2023-08-05 13:06:08 --> Helper loaded: url_helper
INFO - 2023-08-05 13:06:08 --> Helper loaded: file_helper
INFO - 2023-08-05 13:06:08 --> Helper loaded: html_helper
INFO - 2023-08-05 13:06:08 --> Helper loaded: text_helper
INFO - 2023-08-05 13:06:08 --> Helper loaded: form_helper
INFO - 2023-08-05 13:06:08 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:06:08 --> Helper loaded: security_helper
INFO - 2023-08-05 13:06:08 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:06:08 --> Database Driver Class Initialized
INFO - 2023-08-05 13:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:06:08 --> Parser Class Initialized
INFO - 2023-08-05 13:06:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:06:08 --> Pagination Class Initialized
INFO - 2023-08-05 13:06:08 --> Form Validation Class Initialized
INFO - 2023-08-05 13:06:08 --> Controller Class Initialized
INFO - 2023-08-05 13:06:08 --> Model Class Initialized
DEBUG - 2023-08-05 13:06:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:06:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-05 13:06:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:06:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:06:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:06:08 --> Model Class Initialized
INFO - 2023-08-05 13:06:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:06:08 --> Final output sent to browser
DEBUG - 2023-08-05 13:06:08 --> Total execution time: 0.0328
ERROR - 2023-08-05 13:06:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:06:08 --> Config Class Initialized
INFO - 2023-08-05 13:06:08 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:06:08 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:06:08 --> Utf8 Class Initialized
INFO - 2023-08-05 13:06:08 --> URI Class Initialized
INFO - 2023-08-05 13:06:08 --> Router Class Initialized
INFO - 2023-08-05 13:06:08 --> Output Class Initialized
INFO - 2023-08-05 13:06:08 --> Security Class Initialized
DEBUG - 2023-08-05 13:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:06:08 --> Input Class Initialized
INFO - 2023-08-05 13:06:08 --> Language Class Initialized
INFO - 2023-08-05 13:06:08 --> Loader Class Initialized
INFO - 2023-08-05 13:06:08 --> Helper loaded: url_helper
INFO - 2023-08-05 13:06:08 --> Helper loaded: file_helper
INFO - 2023-08-05 13:06:08 --> Helper loaded: html_helper
INFO - 2023-08-05 13:06:08 --> Helper loaded: text_helper
INFO - 2023-08-05 13:06:08 --> Helper loaded: form_helper
INFO - 2023-08-05 13:06:08 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:06:08 --> Helper loaded: security_helper
INFO - 2023-08-05 13:06:08 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:06:08 --> Database Driver Class Initialized
INFO - 2023-08-05 13:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:06:08 --> Parser Class Initialized
INFO - 2023-08-05 13:06:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:06:08 --> Pagination Class Initialized
INFO - 2023-08-05 13:06:08 --> Form Validation Class Initialized
INFO - 2023-08-05 13:06:08 --> Controller Class Initialized
INFO - 2023-08-05 13:06:08 --> Model Class Initialized
DEBUG - 2023-08-05 13:06:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:06:08 --> Model Class Initialized
DEBUG - 2023-08-05 13:06:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:06:08 --> Model Class Initialized
INFO - 2023-08-05 13:06:08 --> Model Class Initialized
INFO - 2023-08-05 13:06:08 --> Model Class Initialized
INFO - 2023-08-05 13:06:08 --> Model Class Initialized
DEBUG - 2023-08-05 13:06:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:06:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:06:08 --> Model Class Initialized
INFO - 2023-08-05 13:06:08 --> Model Class Initialized
INFO - 2023-08-05 13:06:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 13:06:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:06:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:06:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:06:08 --> Model Class Initialized
INFO - 2023-08-05 13:06:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:06:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:06:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:06:08 --> Final output sent to browser
DEBUG - 2023-08-05 13:06:08 --> Total execution time: 0.0885
ERROR - 2023-08-05 13:06:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:06:29 --> Config Class Initialized
INFO - 2023-08-05 13:06:29 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:06:29 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:06:29 --> Utf8 Class Initialized
INFO - 2023-08-05 13:06:29 --> URI Class Initialized
INFO - 2023-08-05 13:06:29 --> Router Class Initialized
INFO - 2023-08-05 13:06:29 --> Output Class Initialized
INFO - 2023-08-05 13:06:29 --> Security Class Initialized
DEBUG - 2023-08-05 13:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:06:29 --> Input Class Initialized
INFO - 2023-08-05 13:06:29 --> Language Class Initialized
INFO - 2023-08-05 13:06:29 --> Loader Class Initialized
INFO - 2023-08-05 13:06:29 --> Helper loaded: url_helper
INFO - 2023-08-05 13:06:29 --> Helper loaded: file_helper
INFO - 2023-08-05 13:06:29 --> Helper loaded: html_helper
INFO - 2023-08-05 13:06:29 --> Helper loaded: text_helper
INFO - 2023-08-05 13:06:29 --> Helper loaded: form_helper
INFO - 2023-08-05 13:06:29 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:06:29 --> Helper loaded: security_helper
INFO - 2023-08-05 13:06:29 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:06:29 --> Database Driver Class Initialized
INFO - 2023-08-05 13:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:06:29 --> Parser Class Initialized
INFO - 2023-08-05 13:06:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:06:29 --> Pagination Class Initialized
INFO - 2023-08-05 13:06:29 --> Form Validation Class Initialized
INFO - 2023-08-05 13:06:29 --> Controller Class Initialized
INFO - 2023-08-05 13:06:29 --> Model Class Initialized
DEBUG - 2023-08-05 13:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-05 13:06:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:06:29 --> Model Class Initialized
INFO - 2023-08-05 13:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:06:29 --> Final output sent to browser
DEBUG - 2023-08-05 13:06:29 --> Total execution time: 0.0314
ERROR - 2023-08-05 13:06:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:06:29 --> Config Class Initialized
INFO - 2023-08-05 13:06:29 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:06:29 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:06:29 --> Utf8 Class Initialized
INFO - 2023-08-05 13:06:29 --> URI Class Initialized
INFO - 2023-08-05 13:06:29 --> Router Class Initialized
INFO - 2023-08-05 13:06:29 --> Output Class Initialized
INFO - 2023-08-05 13:06:29 --> Security Class Initialized
DEBUG - 2023-08-05 13:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:06:29 --> Input Class Initialized
INFO - 2023-08-05 13:06:29 --> Language Class Initialized
INFO - 2023-08-05 13:06:29 --> Loader Class Initialized
INFO - 2023-08-05 13:06:29 --> Helper loaded: url_helper
INFO - 2023-08-05 13:06:29 --> Helper loaded: file_helper
INFO - 2023-08-05 13:06:29 --> Helper loaded: html_helper
INFO - 2023-08-05 13:06:29 --> Helper loaded: text_helper
INFO - 2023-08-05 13:06:29 --> Helper loaded: form_helper
INFO - 2023-08-05 13:06:29 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:06:29 --> Helper loaded: security_helper
INFO - 2023-08-05 13:06:29 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:06:29 --> Database Driver Class Initialized
INFO - 2023-08-05 13:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:06:29 --> Parser Class Initialized
INFO - 2023-08-05 13:06:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:06:29 --> Pagination Class Initialized
INFO - 2023-08-05 13:06:29 --> Form Validation Class Initialized
INFO - 2023-08-05 13:06:29 --> Controller Class Initialized
INFO - 2023-08-05 13:06:29 --> Model Class Initialized
DEBUG - 2023-08-05 13:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:06:29 --> Model Class Initialized
DEBUG - 2023-08-05 13:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:06:29 --> Model Class Initialized
INFO - 2023-08-05 13:06:29 --> Model Class Initialized
INFO - 2023-08-05 13:06:29 --> Model Class Initialized
INFO - 2023-08-05 13:06:29 --> Model Class Initialized
DEBUG - 2023-08-05 13:06:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:06:29 --> Model Class Initialized
INFO - 2023-08-05 13:06:29 --> Model Class Initialized
INFO - 2023-08-05 13:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 13:06:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:06:29 --> Model Class Initialized
INFO - 2023-08-05 13:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:06:29 --> Final output sent to browser
DEBUG - 2023-08-05 13:06:29 --> Total execution time: 0.0860
ERROR - 2023-08-05 13:06:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:06:48 --> Config Class Initialized
INFO - 2023-08-05 13:06:48 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:06:48 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:06:48 --> Utf8 Class Initialized
INFO - 2023-08-05 13:06:48 --> URI Class Initialized
INFO - 2023-08-05 13:06:48 --> Router Class Initialized
INFO - 2023-08-05 13:06:48 --> Output Class Initialized
INFO - 2023-08-05 13:06:48 --> Security Class Initialized
DEBUG - 2023-08-05 13:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:06:48 --> Input Class Initialized
INFO - 2023-08-05 13:06:48 --> Language Class Initialized
INFO - 2023-08-05 13:06:48 --> Loader Class Initialized
INFO - 2023-08-05 13:06:48 --> Helper loaded: url_helper
INFO - 2023-08-05 13:06:48 --> Helper loaded: file_helper
INFO - 2023-08-05 13:06:48 --> Helper loaded: html_helper
INFO - 2023-08-05 13:06:48 --> Helper loaded: text_helper
INFO - 2023-08-05 13:06:48 --> Helper loaded: form_helper
INFO - 2023-08-05 13:06:48 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:06:48 --> Helper loaded: security_helper
INFO - 2023-08-05 13:06:48 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:06:48 --> Database Driver Class Initialized
INFO - 2023-08-05 13:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:06:48 --> Parser Class Initialized
INFO - 2023-08-05 13:06:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:06:48 --> Pagination Class Initialized
INFO - 2023-08-05 13:06:48 --> Form Validation Class Initialized
INFO - 2023-08-05 13:06:48 --> Controller Class Initialized
INFO - 2023-08-05 13:06:48 --> Model Class Initialized
DEBUG - 2023-08-05 13:06:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:06:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:06:48 --> Model Class Initialized
DEBUG - 2023-08-05 13:06:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:06:48 --> Model Class Initialized
INFO - 2023-08-05 13:06:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 13:06:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:06:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:06:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:06:48 --> Model Class Initialized
INFO - 2023-08-05 13:06:48 --> Model Class Initialized
INFO - 2023-08-05 13:06:48 --> Model Class Initialized
INFO - 2023-08-05 13:06:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:06:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:06:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:06:48 --> Final output sent to browser
DEBUG - 2023-08-05 13:06:48 --> Total execution time: 0.0723
ERROR - 2023-08-05 13:06:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:06:48 --> Config Class Initialized
INFO - 2023-08-05 13:06:48 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:06:48 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:06:48 --> Utf8 Class Initialized
INFO - 2023-08-05 13:06:48 --> URI Class Initialized
INFO - 2023-08-05 13:06:48 --> Router Class Initialized
INFO - 2023-08-05 13:06:48 --> Output Class Initialized
INFO - 2023-08-05 13:06:48 --> Security Class Initialized
DEBUG - 2023-08-05 13:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:06:48 --> Input Class Initialized
INFO - 2023-08-05 13:06:48 --> Language Class Initialized
INFO - 2023-08-05 13:06:48 --> Loader Class Initialized
INFO - 2023-08-05 13:06:48 --> Helper loaded: url_helper
INFO - 2023-08-05 13:06:48 --> Helper loaded: file_helper
INFO - 2023-08-05 13:06:48 --> Helper loaded: html_helper
INFO - 2023-08-05 13:06:48 --> Helper loaded: text_helper
INFO - 2023-08-05 13:06:48 --> Helper loaded: form_helper
INFO - 2023-08-05 13:06:48 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:06:48 --> Helper loaded: security_helper
INFO - 2023-08-05 13:06:48 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:06:48 --> Database Driver Class Initialized
INFO - 2023-08-05 13:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:06:48 --> Parser Class Initialized
INFO - 2023-08-05 13:06:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:06:48 --> Pagination Class Initialized
INFO - 2023-08-05 13:06:48 --> Form Validation Class Initialized
INFO - 2023-08-05 13:06:48 --> Controller Class Initialized
INFO - 2023-08-05 13:06:48 --> Model Class Initialized
DEBUG - 2023-08-05 13:06:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:06:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:06:48 --> Model Class Initialized
DEBUG - 2023-08-05 13:06:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:06:48 --> Model Class Initialized
INFO - 2023-08-05 13:06:48 --> Final output sent to browser
DEBUG - 2023-08-05 13:06:48 --> Total execution time: 0.0270
ERROR - 2023-08-05 13:06:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:06:54 --> Config Class Initialized
INFO - 2023-08-05 13:06:54 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:06:54 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:06:54 --> Utf8 Class Initialized
INFO - 2023-08-05 13:06:54 --> URI Class Initialized
INFO - 2023-08-05 13:06:54 --> Router Class Initialized
INFO - 2023-08-05 13:06:54 --> Output Class Initialized
INFO - 2023-08-05 13:06:54 --> Security Class Initialized
DEBUG - 2023-08-05 13:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:06:54 --> Input Class Initialized
INFO - 2023-08-05 13:06:54 --> Language Class Initialized
INFO - 2023-08-05 13:06:54 --> Loader Class Initialized
INFO - 2023-08-05 13:06:54 --> Helper loaded: url_helper
INFO - 2023-08-05 13:06:54 --> Helper loaded: file_helper
INFO - 2023-08-05 13:06:54 --> Helper loaded: html_helper
INFO - 2023-08-05 13:06:54 --> Helper loaded: text_helper
INFO - 2023-08-05 13:06:54 --> Helper loaded: form_helper
INFO - 2023-08-05 13:06:54 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:06:54 --> Helper loaded: security_helper
INFO - 2023-08-05 13:06:54 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:06:54 --> Database Driver Class Initialized
INFO - 2023-08-05 13:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:06:54 --> Parser Class Initialized
INFO - 2023-08-05 13:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:06:54 --> Pagination Class Initialized
INFO - 2023-08-05 13:06:54 --> Form Validation Class Initialized
INFO - 2023-08-05 13:06:54 --> Controller Class Initialized
INFO - 2023-08-05 13:06:54 --> Model Class Initialized
DEBUG - 2023-08-05 13:06:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:06:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:06:54 --> Model Class Initialized
DEBUG - 2023-08-05 13:06:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:06:54 --> Model Class Initialized
INFO - 2023-08-05 13:06:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 13:06:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:06:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:06:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:06:55 --> Model Class Initialized
INFO - 2023-08-05 13:06:55 --> Model Class Initialized
INFO - 2023-08-05 13:06:55 --> Model Class Initialized
INFO - 2023-08-05 13:06:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:06:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:06:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:06:55 --> Final output sent to browser
DEBUG - 2023-08-05 13:06:55 --> Total execution time: 0.0666
ERROR - 2023-08-05 13:06:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:06:55 --> Config Class Initialized
INFO - 2023-08-05 13:06:55 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:06:55 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:06:55 --> Utf8 Class Initialized
INFO - 2023-08-05 13:06:55 --> URI Class Initialized
INFO - 2023-08-05 13:06:55 --> Router Class Initialized
INFO - 2023-08-05 13:06:55 --> Output Class Initialized
INFO - 2023-08-05 13:06:55 --> Security Class Initialized
DEBUG - 2023-08-05 13:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:06:55 --> Input Class Initialized
INFO - 2023-08-05 13:06:55 --> Language Class Initialized
INFO - 2023-08-05 13:06:55 --> Loader Class Initialized
INFO - 2023-08-05 13:06:55 --> Helper loaded: url_helper
INFO - 2023-08-05 13:06:55 --> Helper loaded: file_helper
INFO - 2023-08-05 13:06:55 --> Helper loaded: html_helper
INFO - 2023-08-05 13:06:55 --> Helper loaded: text_helper
INFO - 2023-08-05 13:06:55 --> Helper loaded: form_helper
INFO - 2023-08-05 13:06:55 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:06:55 --> Helper loaded: security_helper
INFO - 2023-08-05 13:06:55 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:06:55 --> Database Driver Class Initialized
INFO - 2023-08-05 13:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:06:55 --> Parser Class Initialized
INFO - 2023-08-05 13:06:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:06:55 --> Pagination Class Initialized
INFO - 2023-08-05 13:06:55 --> Form Validation Class Initialized
INFO - 2023-08-05 13:06:55 --> Controller Class Initialized
INFO - 2023-08-05 13:06:55 --> Model Class Initialized
DEBUG - 2023-08-05 13:06:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:06:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:06:55 --> Model Class Initialized
DEBUG - 2023-08-05 13:06:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:06:55 --> Model Class Initialized
INFO - 2023-08-05 13:06:55 --> Final output sent to browser
DEBUG - 2023-08-05 13:06:55 --> Total execution time: 0.0246
ERROR - 2023-08-05 13:07:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:07:51 --> Config Class Initialized
INFO - 2023-08-05 13:07:51 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:07:51 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:07:51 --> Utf8 Class Initialized
INFO - 2023-08-05 13:07:51 --> URI Class Initialized
INFO - 2023-08-05 13:07:51 --> Router Class Initialized
INFO - 2023-08-05 13:07:51 --> Output Class Initialized
INFO - 2023-08-05 13:07:51 --> Security Class Initialized
DEBUG - 2023-08-05 13:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:07:51 --> Input Class Initialized
INFO - 2023-08-05 13:07:51 --> Language Class Initialized
INFO - 2023-08-05 13:07:51 --> Loader Class Initialized
INFO - 2023-08-05 13:07:51 --> Helper loaded: url_helper
INFO - 2023-08-05 13:07:51 --> Helper loaded: file_helper
INFO - 2023-08-05 13:07:51 --> Helper loaded: html_helper
INFO - 2023-08-05 13:07:51 --> Helper loaded: text_helper
INFO - 2023-08-05 13:07:51 --> Helper loaded: form_helper
INFO - 2023-08-05 13:07:51 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:07:51 --> Helper loaded: security_helper
INFO - 2023-08-05 13:07:51 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:07:51 --> Database Driver Class Initialized
INFO - 2023-08-05 13:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:07:51 --> Parser Class Initialized
INFO - 2023-08-05 13:07:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:07:51 --> Pagination Class Initialized
INFO - 2023-08-05 13:07:51 --> Form Validation Class Initialized
INFO - 2023-08-05 13:07:51 --> Controller Class Initialized
INFO - 2023-08-05 13:07:51 --> Model Class Initialized
DEBUG - 2023-08-05 13:07:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:07:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:07:51 --> Model Class Initialized
DEBUG - 2023-08-05 13:07:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:07:51 --> Model Class Initialized
INFO - 2023-08-05 13:07:51 --> Final output sent to browser
DEBUG - 2023-08-05 13:07:51 --> Total execution time: 0.0300
ERROR - 2023-08-05 13:08:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:08:16 --> Config Class Initialized
INFO - 2023-08-05 13:08:16 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:08:16 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:08:16 --> Utf8 Class Initialized
INFO - 2023-08-05 13:08:16 --> URI Class Initialized
INFO - 2023-08-05 13:08:16 --> Router Class Initialized
INFO - 2023-08-05 13:08:16 --> Output Class Initialized
INFO - 2023-08-05 13:08:16 --> Security Class Initialized
DEBUG - 2023-08-05 13:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:08:16 --> Input Class Initialized
INFO - 2023-08-05 13:08:16 --> Language Class Initialized
INFO - 2023-08-05 13:08:16 --> Loader Class Initialized
INFO - 2023-08-05 13:08:16 --> Helper loaded: url_helper
INFO - 2023-08-05 13:08:16 --> Helper loaded: file_helper
INFO - 2023-08-05 13:08:16 --> Helper loaded: html_helper
INFO - 2023-08-05 13:08:16 --> Helper loaded: text_helper
INFO - 2023-08-05 13:08:16 --> Helper loaded: form_helper
INFO - 2023-08-05 13:08:16 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:08:16 --> Helper loaded: security_helper
INFO - 2023-08-05 13:08:16 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:08:16 --> Database Driver Class Initialized
INFO - 2023-08-05 13:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:08:16 --> Parser Class Initialized
INFO - 2023-08-05 13:08:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:08:16 --> Pagination Class Initialized
INFO - 2023-08-05 13:08:16 --> Form Validation Class Initialized
INFO - 2023-08-05 13:08:16 --> Controller Class Initialized
INFO - 2023-08-05 13:08:16 --> Model Class Initialized
DEBUG - 2023-08-05 13:08:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:08:16 --> Model Class Initialized
DEBUG - 2023-08-05 13:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:08:16 --> Model Class Initialized
DEBUG - 2023-08-05 13:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:08:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-05 13:08:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:08:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:08:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:08:16 --> Model Class Initialized
INFO - 2023-08-05 13:08:16 --> Model Class Initialized
INFO - 2023-08-05 13:08:16 --> Model Class Initialized
INFO - 2023-08-05 13:08:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:08:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:08:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:08:16 --> Final output sent to browser
DEBUG - 2023-08-05 13:08:16 --> Total execution time: 0.0894
ERROR - 2023-08-05 13:18:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:18:30 --> Config Class Initialized
INFO - 2023-08-05 13:18:30 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:18:30 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:18:30 --> Utf8 Class Initialized
INFO - 2023-08-05 13:18:30 --> URI Class Initialized
DEBUG - 2023-08-05 13:18:30 --> No URI present. Default controller set.
INFO - 2023-08-05 13:18:30 --> Router Class Initialized
INFO - 2023-08-05 13:18:30 --> Output Class Initialized
INFO - 2023-08-05 13:18:30 --> Security Class Initialized
DEBUG - 2023-08-05 13:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:18:30 --> Input Class Initialized
INFO - 2023-08-05 13:18:30 --> Language Class Initialized
INFO - 2023-08-05 13:18:30 --> Loader Class Initialized
INFO - 2023-08-05 13:18:30 --> Helper loaded: url_helper
INFO - 2023-08-05 13:18:30 --> Helper loaded: file_helper
INFO - 2023-08-05 13:18:30 --> Helper loaded: html_helper
INFO - 2023-08-05 13:18:30 --> Helper loaded: text_helper
INFO - 2023-08-05 13:18:30 --> Helper loaded: form_helper
INFO - 2023-08-05 13:18:30 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:18:30 --> Helper loaded: security_helper
INFO - 2023-08-05 13:18:30 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:18:30 --> Database Driver Class Initialized
INFO - 2023-08-05 13:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:18:30 --> Parser Class Initialized
INFO - 2023-08-05 13:18:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:18:30 --> Pagination Class Initialized
INFO - 2023-08-05 13:18:30 --> Form Validation Class Initialized
INFO - 2023-08-05 13:18:30 --> Controller Class Initialized
INFO - 2023-08-05 13:18:30 --> Model Class Initialized
DEBUG - 2023-08-05 13:18:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-05 13:18:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:18:30 --> Config Class Initialized
INFO - 2023-08-05 13:18:30 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:18:30 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:18:30 --> Utf8 Class Initialized
INFO - 2023-08-05 13:18:30 --> URI Class Initialized
INFO - 2023-08-05 13:18:30 --> Router Class Initialized
INFO - 2023-08-05 13:18:30 --> Output Class Initialized
INFO - 2023-08-05 13:18:30 --> Security Class Initialized
DEBUG - 2023-08-05 13:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:18:30 --> Input Class Initialized
INFO - 2023-08-05 13:18:30 --> Language Class Initialized
INFO - 2023-08-05 13:18:30 --> Loader Class Initialized
INFO - 2023-08-05 13:18:30 --> Helper loaded: url_helper
INFO - 2023-08-05 13:18:30 --> Helper loaded: file_helper
INFO - 2023-08-05 13:18:30 --> Helper loaded: html_helper
INFO - 2023-08-05 13:18:30 --> Helper loaded: text_helper
INFO - 2023-08-05 13:18:30 --> Helper loaded: form_helper
INFO - 2023-08-05 13:18:30 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:18:30 --> Helper loaded: security_helper
INFO - 2023-08-05 13:18:30 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:18:30 --> Database Driver Class Initialized
INFO - 2023-08-05 13:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:18:30 --> Parser Class Initialized
INFO - 2023-08-05 13:18:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:18:30 --> Pagination Class Initialized
INFO - 2023-08-05 13:18:30 --> Form Validation Class Initialized
INFO - 2023-08-05 13:18:30 --> Controller Class Initialized
INFO - 2023-08-05 13:18:30 --> Model Class Initialized
DEBUG - 2023-08-05 13:18:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:18:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-05 13:18:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:18:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:18:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:18:30 --> Model Class Initialized
INFO - 2023-08-05 13:18:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:18:30 --> Final output sent to browser
DEBUG - 2023-08-05 13:18:30 --> Total execution time: 0.0339
ERROR - 2023-08-05 13:18:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:18:58 --> Config Class Initialized
INFO - 2023-08-05 13:18:58 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:18:58 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:18:58 --> Utf8 Class Initialized
INFO - 2023-08-05 13:18:58 --> URI Class Initialized
INFO - 2023-08-05 13:18:58 --> Router Class Initialized
INFO - 2023-08-05 13:18:58 --> Output Class Initialized
INFO - 2023-08-05 13:18:58 --> Security Class Initialized
DEBUG - 2023-08-05 13:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:18:58 --> Input Class Initialized
INFO - 2023-08-05 13:18:58 --> Language Class Initialized
INFO - 2023-08-05 13:18:58 --> Loader Class Initialized
INFO - 2023-08-05 13:18:58 --> Helper loaded: url_helper
INFO - 2023-08-05 13:18:58 --> Helper loaded: file_helper
INFO - 2023-08-05 13:18:58 --> Helper loaded: html_helper
INFO - 2023-08-05 13:18:58 --> Helper loaded: text_helper
INFO - 2023-08-05 13:18:58 --> Helper loaded: form_helper
INFO - 2023-08-05 13:18:58 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:18:58 --> Helper loaded: security_helper
INFO - 2023-08-05 13:18:58 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:18:58 --> Database Driver Class Initialized
INFO - 2023-08-05 13:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:18:58 --> Parser Class Initialized
INFO - 2023-08-05 13:18:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:18:58 --> Pagination Class Initialized
INFO - 2023-08-05 13:18:58 --> Form Validation Class Initialized
INFO - 2023-08-05 13:18:58 --> Controller Class Initialized
INFO - 2023-08-05 13:18:58 --> Model Class Initialized
DEBUG - 2023-08-05 13:18:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:18:58 --> Model Class Initialized
INFO - 2023-08-05 13:18:58 --> Final output sent to browser
DEBUG - 2023-08-05 13:18:58 --> Total execution time: 0.0194
ERROR - 2023-08-05 13:18:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:18:59 --> Config Class Initialized
INFO - 2023-08-05 13:18:59 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:18:59 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:18:59 --> Utf8 Class Initialized
INFO - 2023-08-05 13:18:59 --> URI Class Initialized
DEBUG - 2023-08-05 13:18:59 --> No URI present. Default controller set.
INFO - 2023-08-05 13:18:59 --> Router Class Initialized
INFO - 2023-08-05 13:18:59 --> Output Class Initialized
INFO - 2023-08-05 13:18:59 --> Security Class Initialized
DEBUG - 2023-08-05 13:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:18:59 --> Input Class Initialized
INFO - 2023-08-05 13:18:59 --> Language Class Initialized
INFO - 2023-08-05 13:18:59 --> Loader Class Initialized
INFO - 2023-08-05 13:18:59 --> Helper loaded: url_helper
INFO - 2023-08-05 13:18:59 --> Helper loaded: file_helper
INFO - 2023-08-05 13:18:59 --> Helper loaded: html_helper
INFO - 2023-08-05 13:18:59 --> Helper loaded: text_helper
INFO - 2023-08-05 13:18:59 --> Helper loaded: form_helper
INFO - 2023-08-05 13:18:59 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:18:59 --> Helper loaded: security_helper
INFO - 2023-08-05 13:18:59 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:18:59 --> Database Driver Class Initialized
INFO - 2023-08-05 13:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:18:59 --> Parser Class Initialized
INFO - 2023-08-05 13:18:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:18:59 --> Pagination Class Initialized
INFO - 2023-08-05 13:18:59 --> Form Validation Class Initialized
INFO - 2023-08-05 13:18:59 --> Controller Class Initialized
INFO - 2023-08-05 13:18:59 --> Model Class Initialized
DEBUG - 2023-08-05 13:18:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:18:59 --> Model Class Initialized
DEBUG - 2023-08-05 13:18:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:18:59 --> Model Class Initialized
INFO - 2023-08-05 13:18:59 --> Model Class Initialized
INFO - 2023-08-05 13:18:59 --> Model Class Initialized
INFO - 2023-08-05 13:18:59 --> Model Class Initialized
DEBUG - 2023-08-05 13:18:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:18:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:18:59 --> Model Class Initialized
INFO - 2023-08-05 13:18:59 --> Model Class Initialized
INFO - 2023-08-05 13:18:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 13:18:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:18:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:18:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:18:59 --> Model Class Initialized
INFO - 2023-08-05 13:18:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:18:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:18:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:18:59 --> Final output sent to browser
DEBUG - 2023-08-05 13:18:59 --> Total execution time: 0.0972
ERROR - 2023-08-05 13:19:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:19:11 --> Config Class Initialized
INFO - 2023-08-05 13:19:11 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:19:11 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:19:11 --> Utf8 Class Initialized
INFO - 2023-08-05 13:19:11 --> URI Class Initialized
INFO - 2023-08-05 13:19:11 --> Router Class Initialized
INFO - 2023-08-05 13:19:11 --> Output Class Initialized
INFO - 2023-08-05 13:19:11 --> Security Class Initialized
DEBUG - 2023-08-05 13:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:19:11 --> Input Class Initialized
INFO - 2023-08-05 13:19:11 --> Language Class Initialized
INFO - 2023-08-05 13:19:11 --> Loader Class Initialized
INFO - 2023-08-05 13:19:11 --> Helper loaded: url_helper
INFO - 2023-08-05 13:19:11 --> Helper loaded: file_helper
INFO - 2023-08-05 13:19:11 --> Helper loaded: html_helper
INFO - 2023-08-05 13:19:11 --> Helper loaded: text_helper
INFO - 2023-08-05 13:19:11 --> Helper loaded: form_helper
INFO - 2023-08-05 13:19:11 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:19:11 --> Helper loaded: security_helper
INFO - 2023-08-05 13:19:11 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:19:11 --> Database Driver Class Initialized
INFO - 2023-08-05 13:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:19:11 --> Parser Class Initialized
INFO - 2023-08-05 13:19:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:19:11 --> Pagination Class Initialized
INFO - 2023-08-05 13:19:11 --> Form Validation Class Initialized
INFO - 2023-08-05 13:19:11 --> Controller Class Initialized
DEBUG - 2023-08-05 13:19:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:19:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:19:11 --> Model Class Initialized
DEBUG - 2023-08-05 13:19:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:19:11 --> Model Class Initialized
INFO - 2023-08-05 13:19:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2023-08-05 13:19:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:19:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:19:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:19:11 --> Model Class Initialized
INFO - 2023-08-05 13:19:11 --> Model Class Initialized
INFO - 2023-08-05 13:19:11 --> Model Class Initialized
INFO - 2023-08-05 13:19:11 --> Model Class Initialized
INFO - 2023-08-05 13:19:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:19:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:19:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:19:11 --> Final output sent to browser
DEBUG - 2023-08-05 13:19:11 --> Total execution time: 0.1132
ERROR - 2023-08-05 13:22:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:22:09 --> Config Class Initialized
INFO - 2023-08-05 13:22:09 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:22:09 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:22:09 --> Utf8 Class Initialized
INFO - 2023-08-05 13:22:09 --> URI Class Initialized
INFO - 2023-08-05 13:22:09 --> Router Class Initialized
INFO - 2023-08-05 13:22:09 --> Output Class Initialized
INFO - 2023-08-05 13:22:09 --> Security Class Initialized
DEBUG - 2023-08-05 13:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:22:09 --> Input Class Initialized
INFO - 2023-08-05 13:22:09 --> Language Class Initialized
INFO - 2023-08-05 13:22:09 --> Loader Class Initialized
INFO - 2023-08-05 13:22:09 --> Helper loaded: url_helper
INFO - 2023-08-05 13:22:09 --> Helper loaded: file_helper
INFO - 2023-08-05 13:22:09 --> Helper loaded: html_helper
INFO - 2023-08-05 13:22:09 --> Helper loaded: text_helper
INFO - 2023-08-05 13:22:09 --> Helper loaded: form_helper
INFO - 2023-08-05 13:22:09 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:22:09 --> Helper loaded: security_helper
INFO - 2023-08-05 13:22:09 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:22:09 --> Database Driver Class Initialized
INFO - 2023-08-05 13:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:22:09 --> Parser Class Initialized
INFO - 2023-08-05 13:22:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:22:09 --> Pagination Class Initialized
INFO - 2023-08-05 13:22:09 --> Form Validation Class Initialized
INFO - 2023-08-05 13:22:09 --> Controller Class Initialized
DEBUG - 2023-08-05 13:22:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:22:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:22:09 --> Model Class Initialized
DEBUG - 2023-08-05 13:22:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:22:09 --> Model Class Initialized
DEBUG - 2023-08-05 13:22:09 --> Auth class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:22:09 --> Final output sent to browser
DEBUG - 2023-08-05 13:22:09 --> Total execution time: 0.0244
ERROR - 2023-08-05 13:22:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:22:16 --> Config Class Initialized
INFO - 2023-08-05 13:22:16 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:22:16 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:22:16 --> Utf8 Class Initialized
INFO - 2023-08-05 13:22:16 --> URI Class Initialized
INFO - 2023-08-05 13:22:16 --> Router Class Initialized
INFO - 2023-08-05 13:22:16 --> Output Class Initialized
INFO - 2023-08-05 13:22:16 --> Security Class Initialized
DEBUG - 2023-08-05 13:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:22:16 --> Input Class Initialized
INFO - 2023-08-05 13:22:16 --> Language Class Initialized
INFO - 2023-08-05 13:22:16 --> Loader Class Initialized
INFO - 2023-08-05 13:22:16 --> Helper loaded: url_helper
INFO - 2023-08-05 13:22:16 --> Helper loaded: file_helper
INFO - 2023-08-05 13:22:16 --> Helper loaded: html_helper
INFO - 2023-08-05 13:22:16 --> Helper loaded: text_helper
INFO - 2023-08-05 13:22:16 --> Helper loaded: form_helper
INFO - 2023-08-05 13:22:16 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:22:16 --> Helper loaded: security_helper
INFO - 2023-08-05 13:22:16 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:22:16 --> Database Driver Class Initialized
INFO - 2023-08-05 13:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:22:16 --> Parser Class Initialized
INFO - 2023-08-05 13:22:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:22:16 --> Pagination Class Initialized
INFO - 2023-08-05 13:22:16 --> Form Validation Class Initialized
INFO - 2023-08-05 13:22:16 --> Controller Class Initialized
DEBUG - 2023-08-05 13:22:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:22:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:22:16 --> Model Class Initialized
DEBUG - 2023-08-05 13:22:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:22:16 --> Model Class Initialized
INFO - 2023-08-05 13:22:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2023-08-05 13:22:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:22:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:22:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:22:16 --> Model Class Initialized
INFO - 2023-08-05 13:22:16 --> Model Class Initialized
INFO - 2023-08-05 13:22:16 --> Model Class Initialized
INFO - 2023-08-05 13:22:16 --> Model Class Initialized
INFO - 2023-08-05 13:22:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:22:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:22:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:22:16 --> Final output sent to browser
DEBUG - 2023-08-05 13:22:16 --> Total execution time: 0.1023
ERROR - 2023-08-05 13:22:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:22:23 --> Config Class Initialized
INFO - 2023-08-05 13:22:23 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:22:23 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:22:23 --> Utf8 Class Initialized
INFO - 2023-08-05 13:22:23 --> URI Class Initialized
DEBUG - 2023-08-05 13:22:23 --> No URI present. Default controller set.
INFO - 2023-08-05 13:22:23 --> Router Class Initialized
INFO - 2023-08-05 13:22:23 --> Output Class Initialized
INFO - 2023-08-05 13:22:23 --> Security Class Initialized
DEBUG - 2023-08-05 13:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:22:23 --> Input Class Initialized
INFO - 2023-08-05 13:22:23 --> Language Class Initialized
INFO - 2023-08-05 13:22:23 --> Loader Class Initialized
INFO - 2023-08-05 13:22:23 --> Helper loaded: url_helper
INFO - 2023-08-05 13:22:23 --> Helper loaded: file_helper
INFO - 2023-08-05 13:22:23 --> Helper loaded: html_helper
INFO - 2023-08-05 13:22:23 --> Helper loaded: text_helper
INFO - 2023-08-05 13:22:23 --> Helper loaded: form_helper
INFO - 2023-08-05 13:22:23 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:22:23 --> Helper loaded: security_helper
INFO - 2023-08-05 13:22:23 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:22:23 --> Database Driver Class Initialized
INFO - 2023-08-05 13:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:22:23 --> Parser Class Initialized
INFO - 2023-08-05 13:22:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:22:23 --> Pagination Class Initialized
INFO - 2023-08-05 13:22:23 --> Form Validation Class Initialized
INFO - 2023-08-05 13:22:23 --> Controller Class Initialized
INFO - 2023-08-05 13:22:23 --> Model Class Initialized
DEBUG - 2023-08-05 13:22:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:22:23 --> Model Class Initialized
DEBUG - 2023-08-05 13:22:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:22:23 --> Model Class Initialized
INFO - 2023-08-05 13:22:23 --> Model Class Initialized
INFO - 2023-08-05 13:22:23 --> Model Class Initialized
INFO - 2023-08-05 13:22:23 --> Model Class Initialized
DEBUG - 2023-08-05 13:22:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:22:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:22:23 --> Model Class Initialized
INFO - 2023-08-05 13:22:23 --> Model Class Initialized
INFO - 2023-08-05 13:22:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 13:22:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:22:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:22:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:22:23 --> Model Class Initialized
INFO - 2023-08-05 13:22:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:22:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:22:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:22:23 --> Final output sent to browser
DEBUG - 2023-08-05 13:22:23 --> Total execution time: 0.0840
ERROR - 2023-08-05 13:22:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:22:50 --> Config Class Initialized
INFO - 2023-08-05 13:22:50 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:22:50 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:22:50 --> Utf8 Class Initialized
INFO - 2023-08-05 13:22:50 --> URI Class Initialized
INFO - 2023-08-05 13:22:50 --> Router Class Initialized
INFO - 2023-08-05 13:22:50 --> Output Class Initialized
INFO - 2023-08-05 13:22:50 --> Security Class Initialized
DEBUG - 2023-08-05 13:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:22:50 --> Input Class Initialized
INFO - 2023-08-05 13:22:50 --> Language Class Initialized
INFO - 2023-08-05 13:22:50 --> Loader Class Initialized
INFO - 2023-08-05 13:22:50 --> Helper loaded: url_helper
INFO - 2023-08-05 13:22:50 --> Helper loaded: file_helper
INFO - 2023-08-05 13:22:50 --> Helper loaded: html_helper
INFO - 2023-08-05 13:22:50 --> Helper loaded: text_helper
INFO - 2023-08-05 13:22:50 --> Helper loaded: form_helper
INFO - 2023-08-05 13:22:50 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:22:50 --> Helper loaded: security_helper
INFO - 2023-08-05 13:22:50 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:22:50 --> Database Driver Class Initialized
INFO - 2023-08-05 13:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:22:50 --> Parser Class Initialized
INFO - 2023-08-05 13:22:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:22:50 --> Pagination Class Initialized
INFO - 2023-08-05 13:22:50 --> Form Validation Class Initialized
INFO - 2023-08-05 13:22:50 --> Controller Class Initialized
INFO - 2023-08-05 13:22:50 --> Model Class Initialized
DEBUG - 2023-08-05 13:22:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:22:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:22:50 --> Model Class Initialized
DEBUG - 2023-08-05 13:22:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:22:50 --> Model Class Initialized
INFO - 2023-08-05 13:22:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-08-05 13:22:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:22:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:22:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:22:50 --> Model Class Initialized
INFO - 2023-08-05 13:22:50 --> Model Class Initialized
INFO - 2023-08-05 13:22:50 --> Model Class Initialized
INFO - 2023-08-05 13:22:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:22:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:22:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:22:50 --> Final output sent to browser
DEBUG - 2023-08-05 13:22:50 --> Total execution time: 0.1170
ERROR - 2023-08-05 13:23:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:23:49 --> Config Class Initialized
INFO - 2023-08-05 13:23:49 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:23:49 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:23:49 --> Utf8 Class Initialized
INFO - 2023-08-05 13:23:49 --> URI Class Initialized
INFO - 2023-08-05 13:23:49 --> Router Class Initialized
INFO - 2023-08-05 13:23:49 --> Output Class Initialized
INFO - 2023-08-05 13:23:49 --> Security Class Initialized
DEBUG - 2023-08-05 13:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:23:49 --> Input Class Initialized
INFO - 2023-08-05 13:23:49 --> Language Class Initialized
INFO - 2023-08-05 13:23:49 --> Loader Class Initialized
INFO - 2023-08-05 13:23:49 --> Helper loaded: url_helper
INFO - 2023-08-05 13:23:49 --> Helper loaded: file_helper
INFO - 2023-08-05 13:23:49 --> Helper loaded: html_helper
INFO - 2023-08-05 13:23:49 --> Helper loaded: text_helper
INFO - 2023-08-05 13:23:49 --> Helper loaded: form_helper
INFO - 2023-08-05 13:23:49 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:23:49 --> Helper loaded: security_helper
INFO - 2023-08-05 13:23:49 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:23:49 --> Database Driver Class Initialized
INFO - 2023-08-05 13:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:23:49 --> Parser Class Initialized
INFO - 2023-08-05 13:23:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:23:49 --> Pagination Class Initialized
INFO - 2023-08-05 13:23:49 --> Form Validation Class Initialized
INFO - 2023-08-05 13:23:49 --> Controller Class Initialized
INFO - 2023-08-05 13:23:49 --> Model Class Initialized
DEBUG - 2023-08-05 13:23:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-05 13:23:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-08-05 13:23:49 --> Final output sent to browser
DEBUG - 2023-08-05 13:23:49 --> Total execution time: 0.0194
ERROR - 2023-08-05 13:23:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:23:52 --> Config Class Initialized
INFO - 2023-08-05 13:23:52 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:23:52 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:23:52 --> Utf8 Class Initialized
INFO - 2023-08-05 13:23:52 --> URI Class Initialized
INFO - 2023-08-05 13:23:52 --> Router Class Initialized
INFO - 2023-08-05 13:23:52 --> Output Class Initialized
INFO - 2023-08-05 13:23:52 --> Security Class Initialized
DEBUG - 2023-08-05 13:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:23:52 --> Input Class Initialized
INFO - 2023-08-05 13:23:52 --> Language Class Initialized
INFO - 2023-08-05 13:23:52 --> Loader Class Initialized
INFO - 2023-08-05 13:23:52 --> Helper loaded: url_helper
INFO - 2023-08-05 13:23:52 --> Helper loaded: file_helper
INFO - 2023-08-05 13:23:52 --> Helper loaded: html_helper
INFO - 2023-08-05 13:23:52 --> Helper loaded: text_helper
INFO - 2023-08-05 13:23:52 --> Helper loaded: form_helper
INFO - 2023-08-05 13:23:52 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:23:52 --> Helper loaded: security_helper
INFO - 2023-08-05 13:23:52 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:23:52 --> Database Driver Class Initialized
INFO - 2023-08-05 13:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:23:52 --> Parser Class Initialized
INFO - 2023-08-05 13:23:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:23:52 --> Pagination Class Initialized
INFO - 2023-08-05 13:23:52 --> Form Validation Class Initialized
INFO - 2023-08-05 13:23:52 --> Controller Class Initialized
INFO - 2023-08-05 13:23:52 --> Model Class Initialized
DEBUG - 2023-08-05 13:23:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:23:52 --> Final output sent to browser
DEBUG - 2023-08-05 13:23:52 --> Total execution time: 0.0159
ERROR - 2023-08-05 13:23:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:23:52 --> Config Class Initialized
INFO - 2023-08-05 13:23:52 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:23:52 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:23:52 --> Utf8 Class Initialized
INFO - 2023-08-05 13:23:52 --> URI Class Initialized
INFO - 2023-08-05 13:23:52 --> Router Class Initialized
INFO - 2023-08-05 13:23:52 --> Output Class Initialized
INFO - 2023-08-05 13:23:52 --> Security Class Initialized
DEBUG - 2023-08-05 13:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:23:52 --> Input Class Initialized
INFO - 2023-08-05 13:23:52 --> Language Class Initialized
INFO - 2023-08-05 13:23:52 --> Loader Class Initialized
INFO - 2023-08-05 13:23:52 --> Helper loaded: url_helper
INFO - 2023-08-05 13:23:52 --> Helper loaded: file_helper
INFO - 2023-08-05 13:23:52 --> Helper loaded: html_helper
INFO - 2023-08-05 13:23:52 --> Helper loaded: text_helper
INFO - 2023-08-05 13:23:52 --> Helper loaded: form_helper
INFO - 2023-08-05 13:23:52 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:23:52 --> Helper loaded: security_helper
INFO - 2023-08-05 13:23:52 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:23:52 --> Database Driver Class Initialized
INFO - 2023-08-05 13:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:23:52 --> Parser Class Initialized
INFO - 2023-08-05 13:23:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:23:52 --> Pagination Class Initialized
INFO - 2023-08-05 13:23:52 --> Form Validation Class Initialized
INFO - 2023-08-05 13:23:52 --> Controller Class Initialized
INFO - 2023-08-05 13:23:52 --> Model Class Initialized
DEBUG - 2023-08-05 13:23:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:23:52 --> Final output sent to browser
DEBUG - 2023-08-05 13:23:52 --> Total execution time: 0.0154
ERROR - 2023-08-05 13:23:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:23:53 --> Config Class Initialized
INFO - 2023-08-05 13:23:53 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:23:53 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:23:53 --> Utf8 Class Initialized
INFO - 2023-08-05 13:23:53 --> URI Class Initialized
INFO - 2023-08-05 13:23:53 --> Router Class Initialized
INFO - 2023-08-05 13:23:53 --> Output Class Initialized
INFO - 2023-08-05 13:23:53 --> Security Class Initialized
DEBUG - 2023-08-05 13:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:23:53 --> Input Class Initialized
INFO - 2023-08-05 13:23:53 --> Language Class Initialized
INFO - 2023-08-05 13:23:53 --> Loader Class Initialized
INFO - 2023-08-05 13:23:53 --> Helper loaded: url_helper
INFO - 2023-08-05 13:23:53 --> Helper loaded: file_helper
INFO - 2023-08-05 13:23:53 --> Helper loaded: html_helper
INFO - 2023-08-05 13:23:53 --> Helper loaded: text_helper
INFO - 2023-08-05 13:23:53 --> Helper loaded: form_helper
INFO - 2023-08-05 13:23:53 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:23:53 --> Helper loaded: security_helper
INFO - 2023-08-05 13:23:53 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:23:53 --> Database Driver Class Initialized
INFO - 2023-08-05 13:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:23:53 --> Parser Class Initialized
INFO - 2023-08-05 13:23:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:23:53 --> Pagination Class Initialized
INFO - 2023-08-05 13:23:53 --> Form Validation Class Initialized
INFO - 2023-08-05 13:23:53 --> Controller Class Initialized
INFO - 2023-08-05 13:23:53 --> Model Class Initialized
DEBUG - 2023-08-05 13:23:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:23:53 --> Final output sent to browser
DEBUG - 2023-08-05 13:23:53 --> Total execution time: 0.0161
ERROR - 2023-08-05 13:23:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:23:53 --> Config Class Initialized
INFO - 2023-08-05 13:23:53 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:23:53 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:23:53 --> Utf8 Class Initialized
INFO - 2023-08-05 13:23:53 --> URI Class Initialized
INFO - 2023-08-05 13:23:53 --> Router Class Initialized
INFO - 2023-08-05 13:23:53 --> Output Class Initialized
INFO - 2023-08-05 13:23:53 --> Security Class Initialized
DEBUG - 2023-08-05 13:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:23:53 --> Input Class Initialized
INFO - 2023-08-05 13:23:53 --> Language Class Initialized
INFO - 2023-08-05 13:23:53 --> Loader Class Initialized
INFO - 2023-08-05 13:23:53 --> Helper loaded: url_helper
INFO - 2023-08-05 13:23:53 --> Helper loaded: file_helper
INFO - 2023-08-05 13:23:53 --> Helper loaded: html_helper
INFO - 2023-08-05 13:23:53 --> Helper loaded: text_helper
INFO - 2023-08-05 13:23:53 --> Helper loaded: form_helper
INFO - 2023-08-05 13:23:53 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:23:53 --> Helper loaded: security_helper
INFO - 2023-08-05 13:23:53 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:23:53 --> Database Driver Class Initialized
INFO - 2023-08-05 13:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:23:53 --> Parser Class Initialized
INFO - 2023-08-05 13:23:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:23:53 --> Pagination Class Initialized
INFO - 2023-08-05 13:23:53 --> Form Validation Class Initialized
INFO - 2023-08-05 13:23:53 --> Controller Class Initialized
INFO - 2023-08-05 13:23:53 --> Model Class Initialized
DEBUG - 2023-08-05 13:23:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-05 13:23:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-08-05 13:23:53 --> Final output sent to browser
DEBUG - 2023-08-05 13:23:53 --> Total execution time: 0.0159
ERROR - 2023-08-05 13:23:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:23:55 --> Config Class Initialized
INFO - 2023-08-05 13:23:55 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:23:55 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:23:55 --> Utf8 Class Initialized
INFO - 2023-08-05 13:23:55 --> URI Class Initialized
INFO - 2023-08-05 13:23:55 --> Router Class Initialized
INFO - 2023-08-05 13:23:55 --> Output Class Initialized
INFO - 2023-08-05 13:23:55 --> Security Class Initialized
DEBUG - 2023-08-05 13:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:23:55 --> Input Class Initialized
INFO - 2023-08-05 13:23:55 --> Language Class Initialized
INFO - 2023-08-05 13:23:55 --> Loader Class Initialized
INFO - 2023-08-05 13:23:55 --> Helper loaded: url_helper
INFO - 2023-08-05 13:23:55 --> Helper loaded: file_helper
INFO - 2023-08-05 13:23:55 --> Helper loaded: html_helper
INFO - 2023-08-05 13:23:55 --> Helper loaded: text_helper
INFO - 2023-08-05 13:23:55 --> Helper loaded: form_helper
INFO - 2023-08-05 13:23:55 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:23:55 --> Helper loaded: security_helper
INFO - 2023-08-05 13:23:55 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:23:55 --> Database Driver Class Initialized
INFO - 2023-08-05 13:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:23:55 --> Parser Class Initialized
INFO - 2023-08-05 13:23:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:23:55 --> Pagination Class Initialized
INFO - 2023-08-05 13:23:55 --> Form Validation Class Initialized
INFO - 2023-08-05 13:23:55 --> Controller Class Initialized
INFO - 2023-08-05 13:23:55 --> Model Class Initialized
DEBUG - 2023-08-05 13:23:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-05 13:23:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-08-05 13:23:55 --> Final output sent to browser
DEBUG - 2023-08-05 13:23:55 --> Total execution time: 0.0157
ERROR - 2023-08-05 13:23:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:23:55 --> Config Class Initialized
INFO - 2023-08-05 13:23:55 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:23:55 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:23:55 --> Utf8 Class Initialized
INFO - 2023-08-05 13:23:55 --> URI Class Initialized
INFO - 2023-08-05 13:23:55 --> Router Class Initialized
INFO - 2023-08-05 13:23:55 --> Output Class Initialized
INFO - 2023-08-05 13:23:55 --> Security Class Initialized
DEBUG - 2023-08-05 13:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:23:55 --> Input Class Initialized
INFO - 2023-08-05 13:23:55 --> Language Class Initialized
INFO - 2023-08-05 13:23:55 --> Loader Class Initialized
INFO - 2023-08-05 13:23:55 --> Helper loaded: url_helper
INFO - 2023-08-05 13:23:55 --> Helper loaded: file_helper
INFO - 2023-08-05 13:23:55 --> Helper loaded: html_helper
INFO - 2023-08-05 13:23:55 --> Helper loaded: text_helper
INFO - 2023-08-05 13:23:55 --> Helper loaded: form_helper
INFO - 2023-08-05 13:23:55 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:23:55 --> Helper loaded: security_helper
INFO - 2023-08-05 13:23:55 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:23:55 --> Database Driver Class Initialized
INFO - 2023-08-05 13:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:23:55 --> Parser Class Initialized
INFO - 2023-08-05 13:23:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:23:55 --> Pagination Class Initialized
INFO - 2023-08-05 13:23:55 --> Form Validation Class Initialized
INFO - 2023-08-05 13:23:55 --> Controller Class Initialized
INFO - 2023-08-05 13:23:55 --> Model Class Initialized
DEBUG - 2023-08-05 13:23:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-05 13:23:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-08-05 13:23:55 --> Final output sent to browser
DEBUG - 2023-08-05 13:23:55 --> Total execution time: 0.0159
ERROR - 2023-08-05 13:23:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:23:58 --> Config Class Initialized
INFO - 2023-08-05 13:23:58 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:23:58 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:23:58 --> Utf8 Class Initialized
INFO - 2023-08-05 13:23:58 --> URI Class Initialized
INFO - 2023-08-05 13:23:58 --> Router Class Initialized
INFO - 2023-08-05 13:23:58 --> Output Class Initialized
INFO - 2023-08-05 13:23:58 --> Security Class Initialized
DEBUG - 2023-08-05 13:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:23:58 --> Input Class Initialized
INFO - 2023-08-05 13:23:58 --> Language Class Initialized
INFO - 2023-08-05 13:23:58 --> Loader Class Initialized
INFO - 2023-08-05 13:23:58 --> Helper loaded: url_helper
INFO - 2023-08-05 13:23:58 --> Helper loaded: file_helper
INFO - 2023-08-05 13:23:58 --> Helper loaded: html_helper
INFO - 2023-08-05 13:23:58 --> Helper loaded: text_helper
INFO - 2023-08-05 13:23:58 --> Helper loaded: form_helper
INFO - 2023-08-05 13:23:58 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:23:58 --> Helper loaded: security_helper
INFO - 2023-08-05 13:23:58 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:23:58 --> Database Driver Class Initialized
INFO - 2023-08-05 13:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:23:58 --> Parser Class Initialized
INFO - 2023-08-05 13:23:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:23:58 --> Pagination Class Initialized
INFO - 2023-08-05 13:23:58 --> Form Validation Class Initialized
INFO - 2023-08-05 13:23:58 --> Controller Class Initialized
INFO - 2023-08-05 13:23:58 --> Model Class Initialized
DEBUG - 2023-08-05 13:23:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-05 13:23:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-08-05 13:23:58 --> Final output sent to browser
DEBUG - 2023-08-05 13:23:58 --> Total execution time: 0.0165
ERROR - 2023-08-05 13:23:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:23:58 --> Config Class Initialized
INFO - 2023-08-05 13:23:58 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:23:58 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:23:58 --> Utf8 Class Initialized
INFO - 2023-08-05 13:23:58 --> URI Class Initialized
INFO - 2023-08-05 13:23:58 --> Router Class Initialized
INFO - 2023-08-05 13:23:58 --> Output Class Initialized
INFO - 2023-08-05 13:23:58 --> Security Class Initialized
DEBUG - 2023-08-05 13:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:23:58 --> Input Class Initialized
INFO - 2023-08-05 13:23:58 --> Language Class Initialized
INFO - 2023-08-05 13:23:58 --> Loader Class Initialized
INFO - 2023-08-05 13:23:58 --> Helper loaded: url_helper
INFO - 2023-08-05 13:23:58 --> Helper loaded: file_helper
INFO - 2023-08-05 13:23:58 --> Helper loaded: html_helper
INFO - 2023-08-05 13:23:58 --> Helper loaded: text_helper
INFO - 2023-08-05 13:23:58 --> Helper loaded: form_helper
INFO - 2023-08-05 13:23:58 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:23:58 --> Helper loaded: security_helper
INFO - 2023-08-05 13:23:58 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:23:58 --> Database Driver Class Initialized
INFO - 2023-08-05 13:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:23:58 --> Parser Class Initialized
INFO - 2023-08-05 13:23:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:23:58 --> Pagination Class Initialized
INFO - 2023-08-05 13:23:58 --> Form Validation Class Initialized
INFO - 2023-08-05 13:23:58 --> Controller Class Initialized
INFO - 2023-08-05 13:23:58 --> Model Class Initialized
DEBUG - 2023-08-05 13:23:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-05 13:23:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-08-05 13:23:58 --> Final output sent to browser
DEBUG - 2023-08-05 13:23:58 --> Total execution time: 0.0160
ERROR - 2023-08-05 13:24:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:24:00 --> Config Class Initialized
INFO - 2023-08-05 13:24:00 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:24:00 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:24:00 --> Utf8 Class Initialized
INFO - 2023-08-05 13:24:00 --> URI Class Initialized
INFO - 2023-08-05 13:24:00 --> Router Class Initialized
INFO - 2023-08-05 13:24:00 --> Output Class Initialized
INFO - 2023-08-05 13:24:00 --> Security Class Initialized
DEBUG - 2023-08-05 13:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:24:00 --> Input Class Initialized
INFO - 2023-08-05 13:24:00 --> Language Class Initialized
INFO - 2023-08-05 13:24:00 --> Loader Class Initialized
INFO - 2023-08-05 13:24:00 --> Helper loaded: url_helper
INFO - 2023-08-05 13:24:00 --> Helper loaded: file_helper
INFO - 2023-08-05 13:24:00 --> Helper loaded: html_helper
INFO - 2023-08-05 13:24:00 --> Helper loaded: text_helper
INFO - 2023-08-05 13:24:00 --> Helper loaded: form_helper
INFO - 2023-08-05 13:24:00 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:24:00 --> Helper loaded: security_helper
INFO - 2023-08-05 13:24:00 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:24:00 --> Database Driver Class Initialized
INFO - 2023-08-05 13:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:24:00 --> Parser Class Initialized
INFO - 2023-08-05 13:24:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:24:00 --> Pagination Class Initialized
INFO - 2023-08-05 13:24:00 --> Form Validation Class Initialized
INFO - 2023-08-05 13:24:00 --> Controller Class Initialized
INFO - 2023-08-05 13:24:00 --> Model Class Initialized
DEBUG - 2023-08-05 13:24:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:24:00 --> Final output sent to browser
DEBUG - 2023-08-05 13:24:00 --> Total execution time: 0.0173
ERROR - 2023-08-05 13:24:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:24:02 --> Config Class Initialized
INFO - 2023-08-05 13:24:02 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:24:02 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:24:02 --> Utf8 Class Initialized
INFO - 2023-08-05 13:24:02 --> URI Class Initialized
INFO - 2023-08-05 13:24:02 --> Router Class Initialized
INFO - 2023-08-05 13:24:02 --> Output Class Initialized
INFO - 2023-08-05 13:24:02 --> Security Class Initialized
DEBUG - 2023-08-05 13:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:24:02 --> Input Class Initialized
INFO - 2023-08-05 13:24:02 --> Language Class Initialized
INFO - 2023-08-05 13:24:02 --> Loader Class Initialized
INFO - 2023-08-05 13:24:02 --> Helper loaded: url_helper
INFO - 2023-08-05 13:24:02 --> Helper loaded: file_helper
INFO - 2023-08-05 13:24:02 --> Helper loaded: html_helper
INFO - 2023-08-05 13:24:02 --> Helper loaded: text_helper
INFO - 2023-08-05 13:24:02 --> Helper loaded: form_helper
INFO - 2023-08-05 13:24:02 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:24:02 --> Helper loaded: security_helper
INFO - 2023-08-05 13:24:02 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:24:02 --> Database Driver Class Initialized
INFO - 2023-08-05 13:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:24:02 --> Parser Class Initialized
INFO - 2023-08-05 13:24:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:24:02 --> Pagination Class Initialized
INFO - 2023-08-05 13:24:02 --> Form Validation Class Initialized
INFO - 2023-08-05 13:24:02 --> Controller Class Initialized
INFO - 2023-08-05 13:24:02 --> Model Class Initialized
DEBUG - 2023-08-05 13:24:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:24:02 --> Final output sent to browser
DEBUG - 2023-08-05 13:24:02 --> Total execution time: 0.0159
ERROR - 2023-08-05 13:24:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:24:03 --> Config Class Initialized
INFO - 2023-08-05 13:24:03 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:24:03 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:24:03 --> Utf8 Class Initialized
INFO - 2023-08-05 13:24:03 --> URI Class Initialized
INFO - 2023-08-05 13:24:03 --> Router Class Initialized
INFO - 2023-08-05 13:24:03 --> Output Class Initialized
INFO - 2023-08-05 13:24:03 --> Security Class Initialized
DEBUG - 2023-08-05 13:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:24:03 --> Input Class Initialized
INFO - 2023-08-05 13:24:03 --> Language Class Initialized
INFO - 2023-08-05 13:24:03 --> Loader Class Initialized
INFO - 2023-08-05 13:24:03 --> Helper loaded: url_helper
INFO - 2023-08-05 13:24:03 --> Helper loaded: file_helper
INFO - 2023-08-05 13:24:03 --> Helper loaded: html_helper
INFO - 2023-08-05 13:24:03 --> Helper loaded: text_helper
INFO - 2023-08-05 13:24:03 --> Helper loaded: form_helper
INFO - 2023-08-05 13:24:03 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:24:03 --> Helper loaded: security_helper
INFO - 2023-08-05 13:24:03 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:24:03 --> Database Driver Class Initialized
INFO - 2023-08-05 13:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:24:03 --> Parser Class Initialized
INFO - 2023-08-05 13:24:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:24:03 --> Pagination Class Initialized
INFO - 2023-08-05 13:24:03 --> Form Validation Class Initialized
INFO - 2023-08-05 13:24:03 --> Controller Class Initialized
INFO - 2023-08-05 13:24:03 --> Model Class Initialized
DEBUG - 2023-08-05 13:24:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:24:03 --> Final output sent to browser
DEBUG - 2023-08-05 13:24:03 --> Total execution time: 0.0158
ERROR - 2023-08-05 13:24:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:24:05 --> Config Class Initialized
INFO - 2023-08-05 13:24:05 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:24:05 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:24:05 --> Utf8 Class Initialized
INFO - 2023-08-05 13:24:05 --> URI Class Initialized
INFO - 2023-08-05 13:24:05 --> Router Class Initialized
INFO - 2023-08-05 13:24:05 --> Output Class Initialized
INFO - 2023-08-05 13:24:05 --> Security Class Initialized
DEBUG - 2023-08-05 13:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:24:05 --> Input Class Initialized
INFO - 2023-08-05 13:24:05 --> Language Class Initialized
INFO - 2023-08-05 13:24:05 --> Loader Class Initialized
INFO - 2023-08-05 13:24:05 --> Helper loaded: url_helper
INFO - 2023-08-05 13:24:05 --> Helper loaded: file_helper
INFO - 2023-08-05 13:24:05 --> Helper loaded: html_helper
INFO - 2023-08-05 13:24:05 --> Helper loaded: text_helper
INFO - 2023-08-05 13:24:05 --> Helper loaded: form_helper
INFO - 2023-08-05 13:24:05 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:24:05 --> Helper loaded: security_helper
INFO - 2023-08-05 13:24:05 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:24:05 --> Database Driver Class Initialized
INFO - 2023-08-05 13:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:24:05 --> Parser Class Initialized
INFO - 2023-08-05 13:24:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:24:05 --> Pagination Class Initialized
INFO - 2023-08-05 13:24:05 --> Form Validation Class Initialized
INFO - 2023-08-05 13:24:05 --> Controller Class Initialized
INFO - 2023-08-05 13:24:05 --> Final output sent to browser
DEBUG - 2023-08-05 13:24:05 --> Total execution time: 0.0140
ERROR - 2023-08-05 13:24:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:24:09 --> Config Class Initialized
INFO - 2023-08-05 13:24:09 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:24:09 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:24:09 --> Utf8 Class Initialized
INFO - 2023-08-05 13:24:09 --> URI Class Initialized
INFO - 2023-08-05 13:24:09 --> Router Class Initialized
INFO - 2023-08-05 13:24:09 --> Output Class Initialized
INFO - 2023-08-05 13:24:09 --> Security Class Initialized
DEBUG - 2023-08-05 13:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:24:09 --> Input Class Initialized
INFO - 2023-08-05 13:24:09 --> Language Class Initialized
INFO - 2023-08-05 13:24:09 --> Loader Class Initialized
INFO - 2023-08-05 13:24:09 --> Helper loaded: url_helper
INFO - 2023-08-05 13:24:09 --> Helper loaded: file_helper
INFO - 2023-08-05 13:24:09 --> Helper loaded: html_helper
INFO - 2023-08-05 13:24:09 --> Helper loaded: text_helper
INFO - 2023-08-05 13:24:09 --> Helper loaded: form_helper
INFO - 2023-08-05 13:24:09 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:24:09 --> Helper loaded: security_helper
INFO - 2023-08-05 13:24:09 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:24:09 --> Database Driver Class Initialized
INFO - 2023-08-05 13:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:24:09 --> Parser Class Initialized
INFO - 2023-08-05 13:24:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:24:09 --> Pagination Class Initialized
INFO - 2023-08-05 13:24:09 --> Form Validation Class Initialized
INFO - 2023-08-05 13:24:09 --> Controller Class Initialized
INFO - 2023-08-05 13:24:09 --> Model Class Initialized
DEBUG - 2023-08-05 13:24:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:24:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:24:09 --> Model Class Initialized
DEBUG - 2023-08-05 13:24:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:24:09 --> Model Class Initialized
INFO - 2023-08-05 13:24:09 --> Final output sent to browser
DEBUG - 2023-08-05 13:24:09 --> Total execution time: 0.0583
ERROR - 2023-08-05 13:24:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:24:09 --> Config Class Initialized
INFO - 2023-08-05 13:24:09 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:24:09 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:24:09 --> Utf8 Class Initialized
INFO - 2023-08-05 13:24:09 --> URI Class Initialized
INFO - 2023-08-05 13:24:09 --> Router Class Initialized
INFO - 2023-08-05 13:24:09 --> Output Class Initialized
INFO - 2023-08-05 13:24:09 --> Security Class Initialized
DEBUG - 2023-08-05 13:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:24:09 --> Input Class Initialized
INFO - 2023-08-05 13:24:09 --> Language Class Initialized
INFO - 2023-08-05 13:24:09 --> Loader Class Initialized
INFO - 2023-08-05 13:24:09 --> Helper loaded: url_helper
INFO - 2023-08-05 13:24:09 --> Helper loaded: file_helper
INFO - 2023-08-05 13:24:09 --> Helper loaded: html_helper
INFO - 2023-08-05 13:24:09 --> Helper loaded: text_helper
INFO - 2023-08-05 13:24:09 --> Helper loaded: form_helper
INFO - 2023-08-05 13:24:09 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:24:09 --> Helper loaded: security_helper
INFO - 2023-08-05 13:24:09 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:24:09 --> Database Driver Class Initialized
INFO - 2023-08-05 13:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:24:09 --> Parser Class Initialized
INFO - 2023-08-05 13:24:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:24:09 --> Pagination Class Initialized
INFO - 2023-08-05 13:24:09 --> Form Validation Class Initialized
INFO - 2023-08-05 13:24:09 --> Controller Class Initialized
INFO - 2023-08-05 13:24:09 --> Model Class Initialized
DEBUG - 2023-08-05 13:24:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:24:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:24:09 --> Model Class Initialized
DEBUG - 2023-08-05 13:24:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:24:09 --> Model Class Initialized
INFO - 2023-08-05 13:24:09 --> Final output sent to browser
DEBUG - 2023-08-05 13:24:09 --> Total execution time: 0.0547
ERROR - 2023-08-05 13:24:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:24:10 --> Config Class Initialized
INFO - 2023-08-05 13:24:10 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:24:10 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:24:10 --> Utf8 Class Initialized
INFO - 2023-08-05 13:24:10 --> URI Class Initialized
INFO - 2023-08-05 13:24:10 --> Router Class Initialized
INFO - 2023-08-05 13:24:10 --> Output Class Initialized
INFO - 2023-08-05 13:24:10 --> Security Class Initialized
DEBUG - 2023-08-05 13:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:24:10 --> Input Class Initialized
INFO - 2023-08-05 13:24:10 --> Language Class Initialized
INFO - 2023-08-05 13:24:10 --> Loader Class Initialized
INFO - 2023-08-05 13:24:10 --> Helper loaded: url_helper
INFO - 2023-08-05 13:24:10 --> Helper loaded: file_helper
INFO - 2023-08-05 13:24:10 --> Helper loaded: html_helper
INFO - 2023-08-05 13:24:10 --> Helper loaded: text_helper
INFO - 2023-08-05 13:24:10 --> Helper loaded: form_helper
INFO - 2023-08-05 13:24:10 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:24:10 --> Helper loaded: security_helper
INFO - 2023-08-05 13:24:10 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:24:10 --> Database Driver Class Initialized
INFO - 2023-08-05 13:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:24:10 --> Parser Class Initialized
INFO - 2023-08-05 13:24:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:24:10 --> Pagination Class Initialized
INFO - 2023-08-05 13:24:10 --> Form Validation Class Initialized
INFO - 2023-08-05 13:24:10 --> Controller Class Initialized
INFO - 2023-08-05 13:24:10 --> Model Class Initialized
DEBUG - 2023-08-05 13:24:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:24:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:24:10 --> Model Class Initialized
DEBUG - 2023-08-05 13:24:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:24:10 --> Model Class Initialized
INFO - 2023-08-05 13:24:10 --> Final output sent to browser
DEBUG - 2023-08-05 13:24:10 --> Total execution time: 0.0204
ERROR - 2023-08-05 13:24:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:24:12 --> Config Class Initialized
INFO - 2023-08-05 13:24:12 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:24:12 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:24:12 --> Utf8 Class Initialized
INFO - 2023-08-05 13:24:12 --> URI Class Initialized
INFO - 2023-08-05 13:24:12 --> Router Class Initialized
INFO - 2023-08-05 13:24:12 --> Output Class Initialized
INFO - 2023-08-05 13:24:12 --> Security Class Initialized
DEBUG - 2023-08-05 13:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:24:12 --> Input Class Initialized
INFO - 2023-08-05 13:24:12 --> Language Class Initialized
INFO - 2023-08-05 13:24:12 --> Loader Class Initialized
INFO - 2023-08-05 13:24:12 --> Helper loaded: url_helper
INFO - 2023-08-05 13:24:12 --> Helper loaded: file_helper
INFO - 2023-08-05 13:24:12 --> Helper loaded: html_helper
INFO - 2023-08-05 13:24:12 --> Helper loaded: text_helper
INFO - 2023-08-05 13:24:12 --> Helper loaded: form_helper
INFO - 2023-08-05 13:24:12 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:24:12 --> Helper loaded: security_helper
INFO - 2023-08-05 13:24:12 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:24:12 --> Database Driver Class Initialized
INFO - 2023-08-05 13:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:24:12 --> Parser Class Initialized
INFO - 2023-08-05 13:24:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:24:12 --> Pagination Class Initialized
INFO - 2023-08-05 13:24:12 --> Form Validation Class Initialized
INFO - 2023-08-05 13:24:12 --> Controller Class Initialized
INFO - 2023-08-05 13:24:12 --> Model Class Initialized
DEBUG - 2023-08-05 13:24:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:24:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:24:12 --> Model Class Initialized
INFO - 2023-08-05 13:24:12 --> Model Class Initialized
INFO - 2023-08-05 13:24:12 --> Final output sent to browser
DEBUG - 2023-08-05 13:24:12 --> Total execution time: 0.0225
ERROR - 2023-08-05 13:24:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:24:14 --> Config Class Initialized
INFO - 2023-08-05 13:24:14 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:24:14 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:24:14 --> Utf8 Class Initialized
INFO - 2023-08-05 13:24:14 --> URI Class Initialized
INFO - 2023-08-05 13:24:14 --> Router Class Initialized
INFO - 2023-08-05 13:24:14 --> Output Class Initialized
INFO - 2023-08-05 13:24:14 --> Security Class Initialized
DEBUG - 2023-08-05 13:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:24:14 --> Input Class Initialized
INFO - 2023-08-05 13:24:14 --> Language Class Initialized
INFO - 2023-08-05 13:24:14 --> Loader Class Initialized
INFO - 2023-08-05 13:24:14 --> Helper loaded: url_helper
INFO - 2023-08-05 13:24:14 --> Helper loaded: file_helper
INFO - 2023-08-05 13:24:14 --> Helper loaded: html_helper
INFO - 2023-08-05 13:24:14 --> Helper loaded: text_helper
INFO - 2023-08-05 13:24:14 --> Helper loaded: form_helper
INFO - 2023-08-05 13:24:14 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:24:14 --> Helper loaded: security_helper
INFO - 2023-08-05 13:24:14 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:24:14 --> Database Driver Class Initialized
INFO - 2023-08-05 13:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:24:14 --> Parser Class Initialized
INFO - 2023-08-05 13:24:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:24:14 --> Pagination Class Initialized
INFO - 2023-08-05 13:24:14 --> Form Validation Class Initialized
INFO - 2023-08-05 13:24:14 --> Controller Class Initialized
INFO - 2023-08-05 13:24:14 --> Model Class Initialized
DEBUG - 2023-08-05 13:24:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:24:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:24:14 --> Model Class Initialized
INFO - 2023-08-05 13:24:14 --> Final output sent to browser
DEBUG - 2023-08-05 13:24:14 --> Total execution time: 0.0172
ERROR - 2023-08-05 13:25:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:25:00 --> Config Class Initialized
INFO - 2023-08-05 13:25:00 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:25:00 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:25:00 --> Utf8 Class Initialized
INFO - 2023-08-05 13:25:00 --> URI Class Initialized
INFO - 2023-08-05 13:25:00 --> Router Class Initialized
INFO - 2023-08-05 13:25:00 --> Output Class Initialized
INFO - 2023-08-05 13:25:00 --> Security Class Initialized
DEBUG - 2023-08-05 13:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:25:00 --> Input Class Initialized
INFO - 2023-08-05 13:25:00 --> Language Class Initialized
INFO - 2023-08-05 13:25:00 --> Loader Class Initialized
INFO - 2023-08-05 13:25:00 --> Helper loaded: url_helper
INFO - 2023-08-05 13:25:00 --> Helper loaded: file_helper
INFO - 2023-08-05 13:25:00 --> Helper loaded: html_helper
INFO - 2023-08-05 13:25:00 --> Helper loaded: text_helper
INFO - 2023-08-05 13:25:00 --> Helper loaded: form_helper
INFO - 2023-08-05 13:25:00 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:25:00 --> Helper loaded: security_helper
INFO - 2023-08-05 13:25:00 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:25:00 --> Database Driver Class Initialized
INFO - 2023-08-05 13:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:25:00 --> Parser Class Initialized
INFO - 2023-08-05 13:25:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:25:00 --> Pagination Class Initialized
INFO - 2023-08-05 13:25:00 --> Form Validation Class Initialized
INFO - 2023-08-05 13:25:00 --> Controller Class Initialized
INFO - 2023-08-05 13:25:00 --> Model Class Initialized
DEBUG - 2023-08-05 13:25:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:25:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:25:00 --> Model Class Initialized
DEBUG - 2023-08-05 13:25:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:25:00 --> Model Class Initialized
INFO - 2023-08-05 13:25:00 --> Email Class Initialized
DEBUG - 2023-08-05 13:25:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:25:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-08-05 13:25:00 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-08-05 13:25:00 --> Language file loaded: language/english/email_lang.php
INFO - 2023-08-05 13:25:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2023-08-05 13:25:01 --> Final output sent to browser
DEBUG - 2023-08-05 13:25:01 --> Total execution time: 0.5093
ERROR - 2023-08-05 13:25:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:25:03 --> Config Class Initialized
INFO - 2023-08-05 13:25:03 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:25:03 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:25:03 --> Utf8 Class Initialized
INFO - 2023-08-05 13:25:03 --> URI Class Initialized
INFO - 2023-08-05 13:25:03 --> Router Class Initialized
INFO - 2023-08-05 13:25:03 --> Output Class Initialized
INFO - 2023-08-05 13:25:03 --> Security Class Initialized
DEBUG - 2023-08-05 13:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:25:03 --> Input Class Initialized
INFO - 2023-08-05 13:25:03 --> Language Class Initialized
INFO - 2023-08-05 13:25:03 --> Loader Class Initialized
INFO - 2023-08-05 13:25:03 --> Helper loaded: url_helper
INFO - 2023-08-05 13:25:03 --> Helper loaded: file_helper
INFO - 2023-08-05 13:25:03 --> Helper loaded: html_helper
INFO - 2023-08-05 13:25:03 --> Helper loaded: text_helper
INFO - 2023-08-05 13:25:03 --> Helper loaded: form_helper
INFO - 2023-08-05 13:25:03 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:25:03 --> Helper loaded: security_helper
INFO - 2023-08-05 13:25:03 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:25:03 --> Database Driver Class Initialized
INFO - 2023-08-05 13:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:25:03 --> Parser Class Initialized
INFO - 2023-08-05 13:25:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:25:03 --> Pagination Class Initialized
INFO - 2023-08-05 13:25:03 --> Form Validation Class Initialized
INFO - 2023-08-05 13:25:03 --> Controller Class Initialized
INFO - 2023-08-05 13:25:03 --> Model Class Initialized
DEBUG - 2023-08-05 13:25:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:25:03 --> Model Class Initialized
DEBUG - 2023-08-05 13:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:25:03 --> Model Class Initialized
INFO - 2023-08-05 13:25:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_manual.php
DEBUG - 2023-08-05 13:25:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:25:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:25:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:25:03 --> Model Class Initialized
INFO - 2023-08-05 13:25:03 --> Model Class Initialized
INFO - 2023-08-05 13:25:03 --> Model Class Initialized
INFO - 2023-08-05 13:25:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:25:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:25:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:25:03 --> Final output sent to browser
DEBUG - 2023-08-05 13:25:03 --> Total execution time: 0.0859
ERROR - 2023-08-05 13:27:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:27:39 --> Config Class Initialized
INFO - 2023-08-05 13:27:39 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:27:39 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:27:39 --> Utf8 Class Initialized
INFO - 2023-08-05 13:27:39 --> URI Class Initialized
INFO - 2023-08-05 13:27:39 --> Router Class Initialized
INFO - 2023-08-05 13:27:39 --> Output Class Initialized
INFO - 2023-08-05 13:27:39 --> Security Class Initialized
DEBUG - 2023-08-05 13:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:27:39 --> Input Class Initialized
INFO - 2023-08-05 13:27:39 --> Language Class Initialized
INFO - 2023-08-05 13:27:39 --> Loader Class Initialized
INFO - 2023-08-05 13:27:39 --> Helper loaded: url_helper
INFO - 2023-08-05 13:27:39 --> Helper loaded: file_helper
INFO - 2023-08-05 13:27:39 --> Helper loaded: html_helper
INFO - 2023-08-05 13:27:39 --> Helper loaded: text_helper
INFO - 2023-08-05 13:27:39 --> Helper loaded: form_helper
INFO - 2023-08-05 13:27:39 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:27:39 --> Helper loaded: security_helper
INFO - 2023-08-05 13:27:39 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:27:39 --> Database Driver Class Initialized
INFO - 2023-08-05 13:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:27:39 --> Parser Class Initialized
INFO - 2023-08-05 13:27:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:27:39 --> Pagination Class Initialized
INFO - 2023-08-05 13:27:39 --> Form Validation Class Initialized
INFO - 2023-08-05 13:27:39 --> Controller Class Initialized
DEBUG - 2023-08-05 13:27:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:27:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:27:39 --> Model Class Initialized
DEBUG - 2023-08-05 13:27:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:27:39 --> Model Class Initialized
INFO - 2023-08-05 13:27:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2023-08-05 13:27:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:27:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:27:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:27:39 --> Model Class Initialized
INFO - 2023-08-05 13:27:39 --> Model Class Initialized
INFO - 2023-08-05 13:27:39 --> Model Class Initialized
INFO - 2023-08-05 13:27:39 --> Model Class Initialized
INFO - 2023-08-05 13:27:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:27:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:27:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:27:39 --> Final output sent to browser
DEBUG - 2023-08-05 13:27:39 --> Total execution time: 0.1024
ERROR - 2023-08-05 13:30:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:30:43 --> Config Class Initialized
INFO - 2023-08-05 13:30:43 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:30:43 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:30:43 --> Utf8 Class Initialized
INFO - 2023-08-05 13:30:43 --> URI Class Initialized
DEBUG - 2023-08-05 13:30:43 --> No URI present. Default controller set.
INFO - 2023-08-05 13:30:43 --> Router Class Initialized
INFO - 2023-08-05 13:30:43 --> Output Class Initialized
INFO - 2023-08-05 13:30:43 --> Security Class Initialized
DEBUG - 2023-08-05 13:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:30:43 --> Input Class Initialized
INFO - 2023-08-05 13:30:43 --> Language Class Initialized
INFO - 2023-08-05 13:30:43 --> Loader Class Initialized
INFO - 2023-08-05 13:30:43 --> Helper loaded: url_helper
INFO - 2023-08-05 13:30:43 --> Helper loaded: file_helper
INFO - 2023-08-05 13:30:43 --> Helper loaded: html_helper
INFO - 2023-08-05 13:30:43 --> Helper loaded: text_helper
INFO - 2023-08-05 13:30:43 --> Helper loaded: form_helper
INFO - 2023-08-05 13:30:43 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:30:43 --> Helper loaded: security_helper
INFO - 2023-08-05 13:30:43 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:30:43 --> Database Driver Class Initialized
INFO - 2023-08-05 13:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:30:43 --> Parser Class Initialized
INFO - 2023-08-05 13:30:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:30:43 --> Pagination Class Initialized
INFO - 2023-08-05 13:30:43 --> Form Validation Class Initialized
INFO - 2023-08-05 13:30:43 --> Controller Class Initialized
INFO - 2023-08-05 13:30:43 --> Model Class Initialized
DEBUG - 2023-08-05 13:30:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:30:43 --> Model Class Initialized
DEBUG - 2023-08-05 13:30:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:30:43 --> Model Class Initialized
INFO - 2023-08-05 13:30:43 --> Model Class Initialized
INFO - 2023-08-05 13:30:43 --> Model Class Initialized
INFO - 2023-08-05 13:30:43 --> Model Class Initialized
DEBUG - 2023-08-05 13:30:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:30:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:30:43 --> Model Class Initialized
INFO - 2023-08-05 13:30:43 --> Model Class Initialized
INFO - 2023-08-05 13:30:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 13:30:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:30:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:30:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:30:43 --> Model Class Initialized
INFO - 2023-08-05 13:30:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:30:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:30:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:30:43 --> Final output sent to browser
DEBUG - 2023-08-05 13:30:43 --> Total execution time: 0.0916
ERROR - 2023-08-05 13:30:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:30:58 --> Config Class Initialized
INFO - 2023-08-05 13:30:58 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:30:58 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:30:58 --> Utf8 Class Initialized
INFO - 2023-08-05 13:30:58 --> URI Class Initialized
INFO - 2023-08-05 13:30:58 --> Router Class Initialized
INFO - 2023-08-05 13:30:58 --> Output Class Initialized
INFO - 2023-08-05 13:30:58 --> Security Class Initialized
DEBUG - 2023-08-05 13:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:30:58 --> Input Class Initialized
INFO - 2023-08-05 13:30:58 --> Language Class Initialized
INFO - 2023-08-05 13:30:58 --> Loader Class Initialized
INFO - 2023-08-05 13:30:58 --> Helper loaded: url_helper
INFO - 2023-08-05 13:30:58 --> Helper loaded: file_helper
INFO - 2023-08-05 13:30:58 --> Helper loaded: html_helper
INFO - 2023-08-05 13:30:58 --> Helper loaded: text_helper
INFO - 2023-08-05 13:30:58 --> Helper loaded: form_helper
INFO - 2023-08-05 13:30:58 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:30:58 --> Helper loaded: security_helper
INFO - 2023-08-05 13:30:58 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:30:58 --> Database Driver Class Initialized
INFO - 2023-08-05 13:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:30:58 --> Parser Class Initialized
INFO - 2023-08-05 13:30:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:30:58 --> Pagination Class Initialized
INFO - 2023-08-05 13:30:58 --> Form Validation Class Initialized
INFO - 2023-08-05 13:30:58 --> Controller Class Initialized
DEBUG - 2023-08-05 13:30:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:30:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:30:58 --> Model Class Initialized
DEBUG - 2023-08-05 13:30:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:30:58 --> Model Class Initialized
INFO - 2023-08-05 13:30:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/add_customer_form.php
DEBUG - 2023-08-05 13:30:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:30:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:30:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:30:58 --> Model Class Initialized
INFO - 2023-08-05 13:30:58 --> Model Class Initialized
INFO - 2023-08-05 13:30:58 --> Model Class Initialized
INFO - 2023-08-05 13:30:58 --> Model Class Initialized
INFO - 2023-08-05 13:30:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:30:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:30:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:30:58 --> Final output sent to browser
DEBUG - 2023-08-05 13:30:58 --> Total execution time: 0.0954
ERROR - 2023-08-05 13:48:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:48:47 --> Config Class Initialized
INFO - 2023-08-05 13:48:47 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:48:47 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:48:47 --> Utf8 Class Initialized
INFO - 2023-08-05 13:48:47 --> URI Class Initialized
INFO - 2023-08-05 13:48:47 --> Router Class Initialized
INFO - 2023-08-05 13:48:47 --> Output Class Initialized
INFO - 2023-08-05 13:48:47 --> Security Class Initialized
DEBUG - 2023-08-05 13:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:48:47 --> Input Class Initialized
INFO - 2023-08-05 13:48:47 --> Language Class Initialized
INFO - 2023-08-05 13:48:47 --> Loader Class Initialized
INFO - 2023-08-05 13:48:47 --> Helper loaded: url_helper
INFO - 2023-08-05 13:48:47 --> Helper loaded: file_helper
INFO - 2023-08-05 13:48:47 --> Helper loaded: html_helper
INFO - 2023-08-05 13:48:47 --> Helper loaded: text_helper
INFO - 2023-08-05 13:48:47 --> Helper loaded: form_helper
INFO - 2023-08-05 13:48:47 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:48:47 --> Helper loaded: security_helper
INFO - 2023-08-05 13:48:47 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:48:47 --> Database Driver Class Initialized
INFO - 2023-08-05 13:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:48:47 --> Parser Class Initialized
INFO - 2023-08-05 13:48:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:48:47 --> Pagination Class Initialized
INFO - 2023-08-05 13:48:47 --> Form Validation Class Initialized
INFO - 2023-08-05 13:48:47 --> Controller Class Initialized
INFO - 2023-08-05 13:48:47 --> Model Class Initialized
DEBUG - 2023-08-05 13:48:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:48:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:48:47 --> Model Class Initialized
DEBUG - 2023-08-05 13:48:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:48:47 --> Model Class Initialized
INFO - 2023-08-05 13:48:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 13:48:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:48:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:48:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:48:47 --> Model Class Initialized
INFO - 2023-08-05 13:48:47 --> Model Class Initialized
INFO - 2023-08-05 13:48:47 --> Model Class Initialized
INFO - 2023-08-05 13:48:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:48:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:48:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:48:47 --> Final output sent to browser
DEBUG - 2023-08-05 13:48:47 --> Total execution time: 0.0722
ERROR - 2023-08-05 13:48:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:48:54 --> Config Class Initialized
INFO - 2023-08-05 13:48:54 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:48:54 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:48:54 --> Utf8 Class Initialized
INFO - 2023-08-05 13:48:54 --> URI Class Initialized
INFO - 2023-08-05 13:48:54 --> Router Class Initialized
INFO - 2023-08-05 13:48:54 --> Output Class Initialized
INFO - 2023-08-05 13:48:54 --> Security Class Initialized
DEBUG - 2023-08-05 13:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:48:54 --> Input Class Initialized
INFO - 2023-08-05 13:48:54 --> Language Class Initialized
INFO - 2023-08-05 13:48:54 --> Loader Class Initialized
INFO - 2023-08-05 13:48:54 --> Helper loaded: url_helper
INFO - 2023-08-05 13:48:54 --> Helper loaded: file_helper
INFO - 2023-08-05 13:48:54 --> Helper loaded: html_helper
INFO - 2023-08-05 13:48:54 --> Helper loaded: text_helper
INFO - 2023-08-05 13:48:54 --> Helper loaded: form_helper
INFO - 2023-08-05 13:48:54 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:48:54 --> Helper loaded: security_helper
INFO - 2023-08-05 13:48:54 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:48:54 --> Database Driver Class Initialized
INFO - 2023-08-05 13:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:48:54 --> Parser Class Initialized
INFO - 2023-08-05 13:48:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:48:54 --> Pagination Class Initialized
INFO - 2023-08-05 13:48:54 --> Form Validation Class Initialized
INFO - 2023-08-05 13:48:54 --> Controller Class Initialized
INFO - 2023-08-05 13:48:54 --> Model Class Initialized
DEBUG - 2023-08-05 13:48:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:48:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:48:54 --> Model Class Initialized
DEBUG - 2023-08-05 13:48:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:48:54 --> Model Class Initialized
INFO - 2023-08-05 13:48:54 --> Final output sent to browser
DEBUG - 2023-08-05 13:48:54 --> Total execution time: 0.0264
ERROR - 2023-08-05 13:49:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:49:07 --> Config Class Initialized
INFO - 2023-08-05 13:49:07 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:49:07 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:49:07 --> Utf8 Class Initialized
INFO - 2023-08-05 13:49:07 --> URI Class Initialized
INFO - 2023-08-05 13:49:07 --> Router Class Initialized
INFO - 2023-08-05 13:49:07 --> Output Class Initialized
INFO - 2023-08-05 13:49:07 --> Security Class Initialized
DEBUG - 2023-08-05 13:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:49:07 --> Input Class Initialized
INFO - 2023-08-05 13:49:07 --> Language Class Initialized
INFO - 2023-08-05 13:49:07 --> Loader Class Initialized
INFO - 2023-08-05 13:49:07 --> Helper loaded: url_helper
INFO - 2023-08-05 13:49:07 --> Helper loaded: file_helper
INFO - 2023-08-05 13:49:07 --> Helper loaded: html_helper
INFO - 2023-08-05 13:49:07 --> Helper loaded: text_helper
INFO - 2023-08-05 13:49:07 --> Helper loaded: form_helper
INFO - 2023-08-05 13:49:07 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:49:07 --> Helper loaded: security_helper
INFO - 2023-08-05 13:49:07 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:49:07 --> Database Driver Class Initialized
INFO - 2023-08-05 13:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:49:07 --> Parser Class Initialized
INFO - 2023-08-05 13:49:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:49:07 --> Pagination Class Initialized
INFO - 2023-08-05 13:49:07 --> Form Validation Class Initialized
INFO - 2023-08-05 13:49:07 --> Controller Class Initialized
INFO - 2023-08-05 13:49:07 --> Model Class Initialized
DEBUG - 2023-08-05 13:49:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:49:07 --> Model Class Initialized
DEBUG - 2023-08-05 13:49:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:49:07 --> Model Class Initialized
INFO - 2023-08-05 13:49:07 --> Model Class Initialized
INFO - 2023-08-05 13:49:07 --> Model Class Initialized
INFO - 2023-08-05 13:49:07 --> Model Class Initialized
DEBUG - 2023-08-05 13:49:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:49:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:49:07 --> Model Class Initialized
INFO - 2023-08-05 13:49:07 --> Model Class Initialized
INFO - 2023-08-05 13:49:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 13:49:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:49:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:49:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:49:07 --> Model Class Initialized
INFO - 2023-08-05 13:49:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:49:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:49:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:49:07 --> Final output sent to browser
DEBUG - 2023-08-05 13:49:07 --> Total execution time: 0.0754
ERROR - 2023-08-05 13:49:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:49:58 --> Config Class Initialized
INFO - 2023-08-05 13:49:58 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:49:58 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:49:58 --> Utf8 Class Initialized
INFO - 2023-08-05 13:49:58 --> URI Class Initialized
INFO - 2023-08-05 13:49:58 --> Router Class Initialized
INFO - 2023-08-05 13:49:58 --> Output Class Initialized
INFO - 2023-08-05 13:49:58 --> Security Class Initialized
DEBUG - 2023-08-05 13:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:49:58 --> Input Class Initialized
INFO - 2023-08-05 13:49:58 --> Language Class Initialized
INFO - 2023-08-05 13:49:58 --> Loader Class Initialized
INFO - 2023-08-05 13:49:58 --> Helper loaded: url_helper
INFO - 2023-08-05 13:49:58 --> Helper loaded: file_helper
INFO - 2023-08-05 13:49:58 --> Helper loaded: html_helper
INFO - 2023-08-05 13:49:58 --> Helper loaded: text_helper
INFO - 2023-08-05 13:49:58 --> Helper loaded: form_helper
INFO - 2023-08-05 13:49:58 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:49:58 --> Helper loaded: security_helper
INFO - 2023-08-05 13:49:58 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:49:58 --> Database Driver Class Initialized
INFO - 2023-08-05 13:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:49:58 --> Parser Class Initialized
INFO - 2023-08-05 13:49:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:49:58 --> Pagination Class Initialized
INFO - 2023-08-05 13:49:58 --> Form Validation Class Initialized
INFO - 2023-08-05 13:49:58 --> Controller Class Initialized
INFO - 2023-08-05 13:49:58 --> Model Class Initialized
DEBUG - 2023-08-05 13:49:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:49:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-05 13:49:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:49:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:49:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:49:58 --> Model Class Initialized
INFO - 2023-08-05 13:49:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:49:58 --> Final output sent to browser
DEBUG - 2023-08-05 13:49:58 --> Total execution time: 0.0316
ERROR - 2023-08-05 13:49:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:49:59 --> Config Class Initialized
INFO - 2023-08-05 13:49:59 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:49:59 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:49:59 --> Utf8 Class Initialized
INFO - 2023-08-05 13:49:59 --> URI Class Initialized
INFO - 2023-08-05 13:49:59 --> Router Class Initialized
INFO - 2023-08-05 13:49:59 --> Output Class Initialized
INFO - 2023-08-05 13:49:59 --> Security Class Initialized
DEBUG - 2023-08-05 13:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:49:59 --> Input Class Initialized
INFO - 2023-08-05 13:49:59 --> Language Class Initialized
INFO - 2023-08-05 13:49:59 --> Loader Class Initialized
INFO - 2023-08-05 13:49:59 --> Helper loaded: url_helper
INFO - 2023-08-05 13:49:59 --> Helper loaded: file_helper
INFO - 2023-08-05 13:49:59 --> Helper loaded: html_helper
INFO - 2023-08-05 13:49:59 --> Helper loaded: text_helper
INFO - 2023-08-05 13:49:59 --> Helper loaded: form_helper
INFO - 2023-08-05 13:49:59 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:49:59 --> Helper loaded: security_helper
INFO - 2023-08-05 13:49:59 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:49:59 --> Database Driver Class Initialized
INFO - 2023-08-05 13:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:49:59 --> Parser Class Initialized
INFO - 2023-08-05 13:49:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:49:59 --> Pagination Class Initialized
INFO - 2023-08-05 13:49:59 --> Form Validation Class Initialized
INFO - 2023-08-05 13:49:59 --> Controller Class Initialized
INFO - 2023-08-05 13:49:59 --> Model Class Initialized
DEBUG - 2023-08-05 13:49:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:49:59 --> Model Class Initialized
DEBUG - 2023-08-05 13:49:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:49:59 --> Model Class Initialized
INFO - 2023-08-05 13:49:59 --> Model Class Initialized
INFO - 2023-08-05 13:49:59 --> Model Class Initialized
INFO - 2023-08-05 13:49:59 --> Model Class Initialized
DEBUG - 2023-08-05 13:49:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:49:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:49:59 --> Model Class Initialized
INFO - 2023-08-05 13:49:59 --> Model Class Initialized
INFO - 2023-08-05 13:49:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 13:49:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:49:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:49:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:49:59 --> Model Class Initialized
INFO - 2023-08-05 13:49:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:49:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:49:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:49:59 --> Final output sent to browser
DEBUG - 2023-08-05 13:49:59 --> Total execution time: 0.0759
ERROR - 2023-08-05 13:50:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:50:06 --> Config Class Initialized
INFO - 2023-08-05 13:50:06 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:50:06 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:50:06 --> Utf8 Class Initialized
INFO - 2023-08-05 13:50:06 --> URI Class Initialized
INFO - 2023-08-05 13:50:06 --> Router Class Initialized
INFO - 2023-08-05 13:50:06 --> Output Class Initialized
INFO - 2023-08-05 13:50:06 --> Security Class Initialized
DEBUG - 2023-08-05 13:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:50:06 --> Input Class Initialized
INFO - 2023-08-05 13:50:06 --> Language Class Initialized
INFO - 2023-08-05 13:50:06 --> Loader Class Initialized
INFO - 2023-08-05 13:50:06 --> Helper loaded: url_helper
INFO - 2023-08-05 13:50:06 --> Helper loaded: file_helper
INFO - 2023-08-05 13:50:06 --> Helper loaded: html_helper
INFO - 2023-08-05 13:50:06 --> Helper loaded: text_helper
INFO - 2023-08-05 13:50:06 --> Helper loaded: form_helper
INFO - 2023-08-05 13:50:06 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:50:06 --> Helper loaded: security_helper
INFO - 2023-08-05 13:50:06 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:50:06 --> Database Driver Class Initialized
INFO - 2023-08-05 13:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:50:06 --> Parser Class Initialized
INFO - 2023-08-05 13:50:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:50:06 --> Pagination Class Initialized
INFO - 2023-08-05 13:50:06 --> Form Validation Class Initialized
INFO - 2023-08-05 13:50:06 --> Controller Class Initialized
INFO - 2023-08-05 13:50:06 --> Model Class Initialized
INFO - 2023-08-05 13:50:06 --> Model Class Initialized
INFO - 2023-08-05 13:50:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-08-05 13:50:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:50:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:50:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:50:06 --> Model Class Initialized
INFO - 2023-08-05 13:50:06 --> Model Class Initialized
INFO - 2023-08-05 13:50:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:50:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:50:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:50:06 --> Final output sent to browser
DEBUG - 2023-08-05 13:50:06 --> Total execution time: 0.0598
ERROR - 2023-08-05 13:50:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:50:07 --> Config Class Initialized
INFO - 2023-08-05 13:50:07 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:50:07 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:50:07 --> Utf8 Class Initialized
INFO - 2023-08-05 13:50:07 --> URI Class Initialized
INFO - 2023-08-05 13:50:07 --> Router Class Initialized
INFO - 2023-08-05 13:50:07 --> Output Class Initialized
INFO - 2023-08-05 13:50:07 --> Security Class Initialized
DEBUG - 2023-08-05 13:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:50:07 --> Input Class Initialized
INFO - 2023-08-05 13:50:07 --> Language Class Initialized
INFO - 2023-08-05 13:50:07 --> Loader Class Initialized
INFO - 2023-08-05 13:50:07 --> Helper loaded: url_helper
INFO - 2023-08-05 13:50:07 --> Helper loaded: file_helper
INFO - 2023-08-05 13:50:07 --> Helper loaded: html_helper
INFO - 2023-08-05 13:50:07 --> Helper loaded: text_helper
INFO - 2023-08-05 13:50:07 --> Helper loaded: form_helper
INFO - 2023-08-05 13:50:07 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:50:07 --> Helper loaded: security_helper
INFO - 2023-08-05 13:50:07 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:50:07 --> Database Driver Class Initialized
INFO - 2023-08-05 13:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:50:07 --> Parser Class Initialized
INFO - 2023-08-05 13:50:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:50:07 --> Pagination Class Initialized
INFO - 2023-08-05 13:50:07 --> Form Validation Class Initialized
INFO - 2023-08-05 13:50:07 --> Controller Class Initialized
INFO - 2023-08-05 13:50:07 --> Model Class Initialized
INFO - 2023-08-05 13:50:07 --> Model Class Initialized
INFO - 2023-08-05 13:50:07 --> Final output sent to browser
DEBUG - 2023-08-05 13:50:07 --> Total execution time: 0.0226
ERROR - 2023-08-05 13:50:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:50:56 --> Config Class Initialized
INFO - 2023-08-05 13:50:56 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:50:56 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:50:56 --> Utf8 Class Initialized
INFO - 2023-08-05 13:50:56 --> URI Class Initialized
INFO - 2023-08-05 13:50:56 --> Router Class Initialized
INFO - 2023-08-05 13:50:56 --> Output Class Initialized
INFO - 2023-08-05 13:50:56 --> Security Class Initialized
DEBUG - 2023-08-05 13:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:50:56 --> Input Class Initialized
INFO - 2023-08-05 13:50:56 --> Language Class Initialized
INFO - 2023-08-05 13:50:56 --> Loader Class Initialized
INFO - 2023-08-05 13:50:56 --> Helper loaded: url_helper
INFO - 2023-08-05 13:50:56 --> Helper loaded: file_helper
INFO - 2023-08-05 13:50:56 --> Helper loaded: html_helper
INFO - 2023-08-05 13:50:56 --> Helper loaded: text_helper
INFO - 2023-08-05 13:50:56 --> Helper loaded: form_helper
INFO - 2023-08-05 13:50:56 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:50:56 --> Helper loaded: security_helper
INFO - 2023-08-05 13:50:56 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:50:56 --> Database Driver Class Initialized
INFO - 2023-08-05 13:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:50:56 --> Parser Class Initialized
INFO - 2023-08-05 13:50:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:50:56 --> Pagination Class Initialized
INFO - 2023-08-05 13:50:56 --> Form Validation Class Initialized
INFO - 2023-08-05 13:50:56 --> Controller Class Initialized
INFO - 2023-08-05 13:50:56 --> Model Class Initialized
DEBUG - 2023-08-05 13:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:50:56 --> Model Class Initialized
DEBUG - 2023-08-05 13:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:50:56 --> Model Class Initialized
INFO - 2023-08-05 13:50:56 --> Model Class Initialized
INFO - 2023-08-05 13:50:56 --> Model Class Initialized
INFO - 2023-08-05 13:50:56 --> Model Class Initialized
DEBUG - 2023-08-05 13:50:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:50:56 --> Model Class Initialized
INFO - 2023-08-05 13:50:56 --> Model Class Initialized
INFO - 2023-08-05 13:50:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 13:50:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:50:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:50:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:50:56 --> Model Class Initialized
INFO - 2023-08-05 13:50:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:50:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:50:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:50:56 --> Final output sent to browser
DEBUG - 2023-08-05 13:50:56 --> Total execution time: 0.0816
ERROR - 2023-08-05 13:51:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:51:05 --> Config Class Initialized
INFO - 2023-08-05 13:51:05 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:51:05 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:51:05 --> Utf8 Class Initialized
INFO - 2023-08-05 13:51:05 --> URI Class Initialized
INFO - 2023-08-05 13:51:05 --> Router Class Initialized
INFO - 2023-08-05 13:51:05 --> Output Class Initialized
INFO - 2023-08-05 13:51:05 --> Security Class Initialized
DEBUG - 2023-08-05 13:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:51:05 --> Input Class Initialized
INFO - 2023-08-05 13:51:05 --> Language Class Initialized
INFO - 2023-08-05 13:51:05 --> Loader Class Initialized
INFO - 2023-08-05 13:51:05 --> Helper loaded: url_helper
INFO - 2023-08-05 13:51:05 --> Helper loaded: file_helper
INFO - 2023-08-05 13:51:05 --> Helper loaded: html_helper
INFO - 2023-08-05 13:51:05 --> Helper loaded: text_helper
INFO - 2023-08-05 13:51:05 --> Helper loaded: form_helper
INFO - 2023-08-05 13:51:05 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:51:05 --> Helper loaded: security_helper
INFO - 2023-08-05 13:51:05 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:51:05 --> Database Driver Class Initialized
INFO - 2023-08-05 13:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:51:05 --> Parser Class Initialized
INFO - 2023-08-05 13:51:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:51:05 --> Pagination Class Initialized
INFO - 2023-08-05 13:51:05 --> Form Validation Class Initialized
INFO - 2023-08-05 13:51:05 --> Controller Class Initialized
INFO - 2023-08-05 13:51:05 --> Model Class Initialized
DEBUG - 2023-08-05 13:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-05 13:51:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:51:05 --> Model Class Initialized
INFO - 2023-08-05 13:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:51:05 --> Final output sent to browser
DEBUG - 2023-08-05 13:51:05 --> Total execution time: 0.0332
ERROR - 2023-08-05 13:51:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:51:05 --> Config Class Initialized
INFO - 2023-08-05 13:51:05 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:51:05 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:51:05 --> Utf8 Class Initialized
INFO - 2023-08-05 13:51:05 --> URI Class Initialized
INFO - 2023-08-05 13:51:05 --> Router Class Initialized
INFO - 2023-08-05 13:51:05 --> Output Class Initialized
INFO - 2023-08-05 13:51:05 --> Security Class Initialized
DEBUG - 2023-08-05 13:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:51:05 --> Input Class Initialized
INFO - 2023-08-05 13:51:05 --> Language Class Initialized
INFO - 2023-08-05 13:51:05 --> Loader Class Initialized
INFO - 2023-08-05 13:51:05 --> Helper loaded: url_helper
INFO - 2023-08-05 13:51:05 --> Helper loaded: file_helper
INFO - 2023-08-05 13:51:05 --> Helper loaded: html_helper
INFO - 2023-08-05 13:51:05 --> Helper loaded: text_helper
INFO - 2023-08-05 13:51:05 --> Helper loaded: form_helper
INFO - 2023-08-05 13:51:05 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:51:05 --> Helper loaded: security_helper
INFO - 2023-08-05 13:51:05 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:51:05 --> Database Driver Class Initialized
INFO - 2023-08-05 13:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:51:05 --> Parser Class Initialized
INFO - 2023-08-05 13:51:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:51:05 --> Pagination Class Initialized
INFO - 2023-08-05 13:51:05 --> Form Validation Class Initialized
INFO - 2023-08-05 13:51:05 --> Controller Class Initialized
INFO - 2023-08-05 13:51:05 --> Model Class Initialized
DEBUG - 2023-08-05 13:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:51:05 --> Model Class Initialized
DEBUG - 2023-08-05 13:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:51:05 --> Model Class Initialized
INFO - 2023-08-05 13:51:05 --> Model Class Initialized
INFO - 2023-08-05 13:51:05 --> Model Class Initialized
INFO - 2023-08-05 13:51:05 --> Model Class Initialized
DEBUG - 2023-08-05 13:51:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:51:05 --> Model Class Initialized
INFO - 2023-08-05 13:51:05 --> Model Class Initialized
INFO - 2023-08-05 13:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 13:51:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:51:05 --> Model Class Initialized
INFO - 2023-08-05 13:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:51:05 --> Final output sent to browser
DEBUG - 2023-08-05 13:51:05 --> Total execution time: 0.0843
ERROR - 2023-08-05 13:51:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:51:21 --> Config Class Initialized
INFO - 2023-08-05 13:51:21 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:51:21 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:51:21 --> Utf8 Class Initialized
INFO - 2023-08-05 13:51:21 --> URI Class Initialized
INFO - 2023-08-05 13:51:21 --> Router Class Initialized
INFO - 2023-08-05 13:51:21 --> Output Class Initialized
INFO - 2023-08-05 13:51:21 --> Security Class Initialized
DEBUG - 2023-08-05 13:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:51:21 --> Input Class Initialized
INFO - 2023-08-05 13:51:21 --> Language Class Initialized
INFO - 2023-08-05 13:51:21 --> Loader Class Initialized
INFO - 2023-08-05 13:51:21 --> Helper loaded: url_helper
INFO - 2023-08-05 13:51:21 --> Helper loaded: file_helper
INFO - 2023-08-05 13:51:21 --> Helper loaded: html_helper
INFO - 2023-08-05 13:51:21 --> Helper loaded: text_helper
INFO - 2023-08-05 13:51:21 --> Helper loaded: form_helper
INFO - 2023-08-05 13:51:21 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:51:21 --> Helper loaded: security_helper
INFO - 2023-08-05 13:51:21 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:51:21 --> Database Driver Class Initialized
INFO - 2023-08-05 13:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:51:21 --> Parser Class Initialized
INFO - 2023-08-05 13:51:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:51:21 --> Pagination Class Initialized
INFO - 2023-08-05 13:51:21 --> Form Validation Class Initialized
INFO - 2023-08-05 13:51:21 --> Controller Class Initialized
INFO - 2023-08-05 13:51:21 --> Model Class Initialized
DEBUG - 2023-08-05 13:51:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:51:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:51:21 --> Model Class Initialized
DEBUG - 2023-08-05 13:51:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:51:21 --> Model Class Initialized
INFO - 2023-08-05 13:51:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 13:51:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:51:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:51:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:51:21 --> Model Class Initialized
INFO - 2023-08-05 13:51:21 --> Model Class Initialized
INFO - 2023-08-05 13:51:21 --> Model Class Initialized
INFO - 2023-08-05 13:51:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:51:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:51:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:51:21 --> Final output sent to browser
DEBUG - 2023-08-05 13:51:21 --> Total execution time: 0.0689
ERROR - 2023-08-05 13:51:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:51:21 --> Config Class Initialized
INFO - 2023-08-05 13:51:21 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:51:21 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:51:21 --> Utf8 Class Initialized
INFO - 2023-08-05 13:51:21 --> URI Class Initialized
INFO - 2023-08-05 13:51:21 --> Router Class Initialized
INFO - 2023-08-05 13:51:21 --> Output Class Initialized
INFO - 2023-08-05 13:51:21 --> Security Class Initialized
DEBUG - 2023-08-05 13:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:51:21 --> Input Class Initialized
INFO - 2023-08-05 13:51:21 --> Language Class Initialized
INFO - 2023-08-05 13:51:21 --> Loader Class Initialized
INFO - 2023-08-05 13:51:21 --> Helper loaded: url_helper
INFO - 2023-08-05 13:51:21 --> Helper loaded: file_helper
INFO - 2023-08-05 13:51:21 --> Helper loaded: html_helper
INFO - 2023-08-05 13:51:21 --> Helper loaded: text_helper
INFO - 2023-08-05 13:51:21 --> Helper loaded: form_helper
INFO - 2023-08-05 13:51:21 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:51:21 --> Helper loaded: security_helper
INFO - 2023-08-05 13:51:21 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:51:21 --> Database Driver Class Initialized
INFO - 2023-08-05 13:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:51:22 --> Parser Class Initialized
INFO - 2023-08-05 13:51:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:51:22 --> Pagination Class Initialized
INFO - 2023-08-05 13:51:22 --> Form Validation Class Initialized
INFO - 2023-08-05 13:51:22 --> Controller Class Initialized
INFO - 2023-08-05 13:51:22 --> Model Class Initialized
DEBUG - 2023-08-05 13:51:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:51:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:51:22 --> Model Class Initialized
DEBUG - 2023-08-05 13:51:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:51:22 --> Model Class Initialized
INFO - 2023-08-05 13:51:22 --> Final output sent to browser
DEBUG - 2023-08-05 13:51:22 --> Total execution time: 0.0269
ERROR - 2023-08-05 13:51:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:51:30 --> Config Class Initialized
INFO - 2023-08-05 13:51:30 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:51:30 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:51:30 --> Utf8 Class Initialized
INFO - 2023-08-05 13:51:30 --> URI Class Initialized
INFO - 2023-08-05 13:51:30 --> Router Class Initialized
INFO - 2023-08-05 13:51:30 --> Output Class Initialized
INFO - 2023-08-05 13:51:30 --> Security Class Initialized
DEBUG - 2023-08-05 13:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:51:30 --> Input Class Initialized
INFO - 2023-08-05 13:51:30 --> Language Class Initialized
INFO - 2023-08-05 13:51:30 --> Loader Class Initialized
INFO - 2023-08-05 13:51:30 --> Helper loaded: url_helper
INFO - 2023-08-05 13:51:30 --> Helper loaded: file_helper
INFO - 2023-08-05 13:51:30 --> Helper loaded: html_helper
INFO - 2023-08-05 13:51:30 --> Helper loaded: text_helper
INFO - 2023-08-05 13:51:30 --> Helper loaded: form_helper
INFO - 2023-08-05 13:51:30 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:51:30 --> Helper loaded: security_helper
INFO - 2023-08-05 13:51:30 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:51:30 --> Database Driver Class Initialized
INFO - 2023-08-05 13:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:51:30 --> Parser Class Initialized
INFO - 2023-08-05 13:51:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:51:30 --> Pagination Class Initialized
INFO - 2023-08-05 13:51:30 --> Form Validation Class Initialized
INFO - 2023-08-05 13:51:30 --> Controller Class Initialized
INFO - 2023-08-05 13:51:30 --> Model Class Initialized
DEBUG - 2023-08-05 13:51:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:51:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:51:30 --> Model Class Initialized
DEBUG - 2023-08-05 13:51:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:51:30 --> Model Class Initialized
DEBUG - 2023-08-05 13:51:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:51:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-05 13:51:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:51:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:51:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:51:30 --> Model Class Initialized
INFO - 2023-08-05 13:51:30 --> Model Class Initialized
INFO - 2023-08-05 13:51:30 --> Model Class Initialized
INFO - 2023-08-05 13:51:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:51:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:51:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:51:30 --> Final output sent to browser
DEBUG - 2023-08-05 13:51:30 --> Total execution time: 0.0769
ERROR - 2023-08-05 13:51:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:51:52 --> Config Class Initialized
INFO - 2023-08-05 13:51:52 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:51:52 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:51:52 --> Utf8 Class Initialized
INFO - 2023-08-05 13:51:52 --> URI Class Initialized
INFO - 2023-08-05 13:51:52 --> Router Class Initialized
INFO - 2023-08-05 13:51:52 --> Output Class Initialized
INFO - 2023-08-05 13:51:52 --> Security Class Initialized
DEBUG - 2023-08-05 13:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:51:52 --> Input Class Initialized
INFO - 2023-08-05 13:51:52 --> Language Class Initialized
INFO - 2023-08-05 13:51:52 --> Loader Class Initialized
INFO - 2023-08-05 13:51:52 --> Helper loaded: url_helper
INFO - 2023-08-05 13:51:52 --> Helper loaded: file_helper
INFO - 2023-08-05 13:51:52 --> Helper loaded: html_helper
INFO - 2023-08-05 13:51:52 --> Helper loaded: text_helper
INFO - 2023-08-05 13:51:52 --> Helper loaded: form_helper
INFO - 2023-08-05 13:51:52 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:51:52 --> Helper loaded: security_helper
INFO - 2023-08-05 13:51:52 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:51:52 --> Database Driver Class Initialized
INFO - 2023-08-05 13:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:51:52 --> Parser Class Initialized
INFO - 2023-08-05 13:51:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:51:52 --> Pagination Class Initialized
INFO - 2023-08-05 13:51:52 --> Form Validation Class Initialized
INFO - 2023-08-05 13:51:52 --> Controller Class Initialized
INFO - 2023-08-05 13:51:52 --> Model Class Initialized
DEBUG - 2023-08-05 13:51:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:51:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:51:52 --> Model Class Initialized
DEBUG - 2023-08-05 13:51:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:51:52 --> Model Class Initialized
INFO - 2023-08-05 13:51:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 13:51:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:51:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:51:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:51:52 --> Model Class Initialized
INFO - 2023-08-05 13:51:52 --> Model Class Initialized
INFO - 2023-08-05 13:51:52 --> Model Class Initialized
INFO - 2023-08-05 13:51:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:51:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:51:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:51:52 --> Final output sent to browser
DEBUG - 2023-08-05 13:51:52 --> Total execution time: 0.0712
ERROR - 2023-08-05 13:51:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:51:53 --> Config Class Initialized
INFO - 2023-08-05 13:51:53 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:51:53 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:51:53 --> Utf8 Class Initialized
INFO - 2023-08-05 13:51:53 --> URI Class Initialized
INFO - 2023-08-05 13:51:53 --> Router Class Initialized
INFO - 2023-08-05 13:51:53 --> Output Class Initialized
INFO - 2023-08-05 13:51:53 --> Security Class Initialized
DEBUG - 2023-08-05 13:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:51:53 --> Input Class Initialized
INFO - 2023-08-05 13:51:53 --> Language Class Initialized
INFO - 2023-08-05 13:51:53 --> Loader Class Initialized
INFO - 2023-08-05 13:51:53 --> Helper loaded: url_helper
INFO - 2023-08-05 13:51:53 --> Helper loaded: file_helper
INFO - 2023-08-05 13:51:53 --> Helper loaded: html_helper
INFO - 2023-08-05 13:51:53 --> Helper loaded: text_helper
INFO - 2023-08-05 13:51:53 --> Helper loaded: form_helper
INFO - 2023-08-05 13:51:53 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:51:53 --> Helper loaded: security_helper
INFO - 2023-08-05 13:51:53 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:51:53 --> Database Driver Class Initialized
INFO - 2023-08-05 13:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:51:53 --> Parser Class Initialized
INFO - 2023-08-05 13:51:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:51:53 --> Pagination Class Initialized
INFO - 2023-08-05 13:51:53 --> Form Validation Class Initialized
INFO - 2023-08-05 13:51:53 --> Controller Class Initialized
INFO - 2023-08-05 13:51:53 --> Model Class Initialized
DEBUG - 2023-08-05 13:51:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:51:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:51:53 --> Model Class Initialized
DEBUG - 2023-08-05 13:51:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:51:53 --> Model Class Initialized
INFO - 2023-08-05 13:51:53 --> Final output sent to browser
DEBUG - 2023-08-05 13:51:53 --> Total execution time: 0.0250
ERROR - 2023-08-05 13:51:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:51:57 --> Config Class Initialized
INFO - 2023-08-05 13:51:57 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:51:57 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:51:57 --> Utf8 Class Initialized
INFO - 2023-08-05 13:51:57 --> URI Class Initialized
INFO - 2023-08-05 13:51:57 --> Router Class Initialized
INFO - 2023-08-05 13:51:57 --> Output Class Initialized
INFO - 2023-08-05 13:51:57 --> Security Class Initialized
DEBUG - 2023-08-05 13:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:51:57 --> Input Class Initialized
INFO - 2023-08-05 13:51:57 --> Language Class Initialized
INFO - 2023-08-05 13:51:57 --> Loader Class Initialized
INFO - 2023-08-05 13:51:57 --> Helper loaded: url_helper
INFO - 2023-08-05 13:51:57 --> Helper loaded: file_helper
INFO - 2023-08-05 13:51:57 --> Helper loaded: html_helper
INFO - 2023-08-05 13:51:57 --> Helper loaded: text_helper
INFO - 2023-08-05 13:51:57 --> Helper loaded: form_helper
INFO - 2023-08-05 13:51:57 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:51:57 --> Helper loaded: security_helper
INFO - 2023-08-05 13:51:57 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:51:57 --> Database Driver Class Initialized
INFO - 2023-08-05 13:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:51:57 --> Parser Class Initialized
INFO - 2023-08-05 13:51:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:51:57 --> Pagination Class Initialized
INFO - 2023-08-05 13:51:57 --> Form Validation Class Initialized
INFO - 2023-08-05 13:51:57 --> Controller Class Initialized
INFO - 2023-08-05 13:51:57 --> Model Class Initialized
DEBUG - 2023-08-05 13:51:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:51:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:51:57 --> Model Class Initialized
DEBUG - 2023-08-05 13:51:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:51:57 --> Model Class Initialized
DEBUG - 2023-08-05 13:51:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:51:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-05 13:51:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:51:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:51:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:51:57 --> Model Class Initialized
INFO - 2023-08-05 13:51:57 --> Model Class Initialized
INFO - 2023-08-05 13:51:57 --> Model Class Initialized
INFO - 2023-08-05 13:51:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:51:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:51:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:51:57 --> Final output sent to browser
DEBUG - 2023-08-05 13:51:57 --> Total execution time: 0.0679
ERROR - 2023-08-05 13:52:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:52:07 --> Config Class Initialized
INFO - 2023-08-05 13:52:07 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:52:07 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:52:07 --> Utf8 Class Initialized
INFO - 2023-08-05 13:52:07 --> URI Class Initialized
INFO - 2023-08-05 13:52:07 --> Router Class Initialized
INFO - 2023-08-05 13:52:07 --> Output Class Initialized
INFO - 2023-08-05 13:52:07 --> Security Class Initialized
DEBUG - 2023-08-05 13:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:52:07 --> Input Class Initialized
INFO - 2023-08-05 13:52:07 --> Language Class Initialized
INFO - 2023-08-05 13:52:07 --> Loader Class Initialized
INFO - 2023-08-05 13:52:07 --> Helper loaded: url_helper
INFO - 2023-08-05 13:52:07 --> Helper loaded: file_helper
INFO - 2023-08-05 13:52:07 --> Helper loaded: html_helper
INFO - 2023-08-05 13:52:07 --> Helper loaded: text_helper
INFO - 2023-08-05 13:52:07 --> Helper loaded: form_helper
INFO - 2023-08-05 13:52:07 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:52:07 --> Helper loaded: security_helper
INFO - 2023-08-05 13:52:07 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:52:07 --> Database Driver Class Initialized
INFO - 2023-08-05 13:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:52:07 --> Parser Class Initialized
INFO - 2023-08-05 13:52:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:52:07 --> Pagination Class Initialized
INFO - 2023-08-05 13:52:07 --> Form Validation Class Initialized
INFO - 2023-08-05 13:52:07 --> Controller Class Initialized
INFO - 2023-08-05 13:52:07 --> Model Class Initialized
DEBUG - 2023-08-05 13:52:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:52:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:52:07 --> Model Class Initialized
DEBUG - 2023-08-05 13:52:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:52:07 --> Model Class Initialized
INFO - 2023-08-05 13:52:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 13:52:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:52:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:52:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:52:07 --> Model Class Initialized
INFO - 2023-08-05 13:52:07 --> Model Class Initialized
INFO - 2023-08-05 13:52:07 --> Model Class Initialized
INFO - 2023-08-05 13:52:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:52:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:52:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:52:07 --> Final output sent to browser
DEBUG - 2023-08-05 13:52:07 --> Total execution time: 0.0652
ERROR - 2023-08-05 13:52:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:52:08 --> Config Class Initialized
INFO - 2023-08-05 13:52:08 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:52:08 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:52:08 --> Utf8 Class Initialized
INFO - 2023-08-05 13:52:08 --> URI Class Initialized
INFO - 2023-08-05 13:52:08 --> Router Class Initialized
INFO - 2023-08-05 13:52:08 --> Output Class Initialized
INFO - 2023-08-05 13:52:08 --> Security Class Initialized
DEBUG - 2023-08-05 13:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:52:08 --> Input Class Initialized
INFO - 2023-08-05 13:52:08 --> Language Class Initialized
INFO - 2023-08-05 13:52:08 --> Loader Class Initialized
INFO - 2023-08-05 13:52:08 --> Helper loaded: url_helper
INFO - 2023-08-05 13:52:08 --> Helper loaded: file_helper
INFO - 2023-08-05 13:52:08 --> Helper loaded: html_helper
INFO - 2023-08-05 13:52:08 --> Helper loaded: text_helper
INFO - 2023-08-05 13:52:08 --> Helper loaded: form_helper
INFO - 2023-08-05 13:52:08 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:52:08 --> Helper loaded: security_helper
INFO - 2023-08-05 13:52:08 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:52:08 --> Database Driver Class Initialized
INFO - 2023-08-05 13:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:52:08 --> Parser Class Initialized
INFO - 2023-08-05 13:52:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:52:08 --> Pagination Class Initialized
INFO - 2023-08-05 13:52:08 --> Form Validation Class Initialized
INFO - 2023-08-05 13:52:08 --> Controller Class Initialized
INFO - 2023-08-05 13:52:08 --> Model Class Initialized
DEBUG - 2023-08-05 13:52:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:52:08 --> Model Class Initialized
DEBUG - 2023-08-05 13:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:52:08 --> Model Class Initialized
INFO - 2023-08-05 13:52:08 --> Final output sent to browser
DEBUG - 2023-08-05 13:52:08 --> Total execution time: 0.0264
ERROR - 2023-08-05 13:52:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:52:12 --> Config Class Initialized
INFO - 2023-08-05 13:52:12 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:52:12 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:52:12 --> Utf8 Class Initialized
INFO - 2023-08-05 13:52:12 --> URI Class Initialized
INFO - 2023-08-05 13:52:12 --> Router Class Initialized
INFO - 2023-08-05 13:52:12 --> Output Class Initialized
INFO - 2023-08-05 13:52:12 --> Security Class Initialized
DEBUG - 2023-08-05 13:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:52:12 --> Input Class Initialized
INFO - 2023-08-05 13:52:12 --> Language Class Initialized
INFO - 2023-08-05 13:52:12 --> Loader Class Initialized
INFO - 2023-08-05 13:52:12 --> Helper loaded: url_helper
INFO - 2023-08-05 13:52:12 --> Helper loaded: file_helper
INFO - 2023-08-05 13:52:12 --> Helper loaded: html_helper
INFO - 2023-08-05 13:52:12 --> Helper loaded: text_helper
INFO - 2023-08-05 13:52:12 --> Helper loaded: form_helper
INFO - 2023-08-05 13:52:12 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:52:12 --> Helper loaded: security_helper
INFO - 2023-08-05 13:52:12 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:52:12 --> Database Driver Class Initialized
INFO - 2023-08-05 13:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:52:12 --> Parser Class Initialized
INFO - 2023-08-05 13:52:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:52:12 --> Pagination Class Initialized
INFO - 2023-08-05 13:52:12 --> Form Validation Class Initialized
INFO - 2023-08-05 13:52:12 --> Controller Class Initialized
INFO - 2023-08-05 13:52:12 --> Model Class Initialized
DEBUG - 2023-08-05 13:52:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:52:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:52:12 --> Model Class Initialized
DEBUG - 2023-08-05 13:52:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:52:12 --> Model Class Initialized
DEBUG - 2023-08-05 13:52:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:52:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-05 13:52:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:52:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:52:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:52:12 --> Model Class Initialized
INFO - 2023-08-05 13:52:12 --> Model Class Initialized
INFO - 2023-08-05 13:52:12 --> Model Class Initialized
INFO - 2023-08-05 13:52:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:52:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:52:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:52:12 --> Final output sent to browser
DEBUG - 2023-08-05 13:52:12 --> Total execution time: 0.0667
ERROR - 2023-08-05 13:53:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:53:34 --> Config Class Initialized
INFO - 2023-08-05 13:53:34 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:53:34 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:53:34 --> Utf8 Class Initialized
INFO - 2023-08-05 13:53:34 --> URI Class Initialized
INFO - 2023-08-05 13:53:34 --> Router Class Initialized
INFO - 2023-08-05 13:53:34 --> Output Class Initialized
INFO - 2023-08-05 13:53:34 --> Security Class Initialized
DEBUG - 2023-08-05 13:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:53:34 --> Input Class Initialized
INFO - 2023-08-05 13:53:34 --> Language Class Initialized
INFO - 2023-08-05 13:53:34 --> Loader Class Initialized
INFO - 2023-08-05 13:53:34 --> Helper loaded: url_helper
INFO - 2023-08-05 13:53:34 --> Helper loaded: file_helper
INFO - 2023-08-05 13:53:34 --> Helper loaded: html_helper
INFO - 2023-08-05 13:53:34 --> Helper loaded: text_helper
INFO - 2023-08-05 13:53:34 --> Helper loaded: form_helper
INFO - 2023-08-05 13:53:34 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:53:34 --> Helper loaded: security_helper
INFO - 2023-08-05 13:53:34 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:53:34 --> Database Driver Class Initialized
INFO - 2023-08-05 13:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:53:34 --> Parser Class Initialized
INFO - 2023-08-05 13:53:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:53:34 --> Pagination Class Initialized
INFO - 2023-08-05 13:53:34 --> Form Validation Class Initialized
INFO - 2023-08-05 13:53:34 --> Controller Class Initialized
INFO - 2023-08-05 13:53:34 --> Model Class Initialized
DEBUG - 2023-08-05 13:53:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:53:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:53:34 --> Model Class Initialized
DEBUG - 2023-08-05 13:53:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:53:34 --> Model Class Initialized
INFO - 2023-08-05 13:53:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 13:53:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:53:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:53:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:53:34 --> Model Class Initialized
INFO - 2023-08-05 13:53:34 --> Model Class Initialized
INFO - 2023-08-05 13:53:34 --> Model Class Initialized
INFO - 2023-08-05 13:53:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:53:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:53:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:53:34 --> Final output sent to browser
DEBUG - 2023-08-05 13:53:34 --> Total execution time: 0.0655
ERROR - 2023-08-05 13:53:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:53:35 --> Config Class Initialized
INFO - 2023-08-05 13:53:35 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:53:35 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:53:35 --> Utf8 Class Initialized
INFO - 2023-08-05 13:53:35 --> URI Class Initialized
INFO - 2023-08-05 13:53:35 --> Router Class Initialized
INFO - 2023-08-05 13:53:35 --> Output Class Initialized
INFO - 2023-08-05 13:53:35 --> Security Class Initialized
DEBUG - 2023-08-05 13:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:53:35 --> Input Class Initialized
INFO - 2023-08-05 13:53:35 --> Language Class Initialized
INFO - 2023-08-05 13:53:35 --> Loader Class Initialized
INFO - 2023-08-05 13:53:35 --> Helper loaded: url_helper
INFO - 2023-08-05 13:53:35 --> Helper loaded: file_helper
INFO - 2023-08-05 13:53:35 --> Helper loaded: html_helper
INFO - 2023-08-05 13:53:35 --> Helper loaded: text_helper
INFO - 2023-08-05 13:53:35 --> Helper loaded: form_helper
INFO - 2023-08-05 13:53:35 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:53:35 --> Helper loaded: security_helper
INFO - 2023-08-05 13:53:35 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:53:35 --> Database Driver Class Initialized
INFO - 2023-08-05 13:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:53:35 --> Parser Class Initialized
INFO - 2023-08-05 13:53:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:53:35 --> Pagination Class Initialized
INFO - 2023-08-05 13:53:35 --> Form Validation Class Initialized
INFO - 2023-08-05 13:53:35 --> Controller Class Initialized
INFO - 2023-08-05 13:53:35 --> Model Class Initialized
DEBUG - 2023-08-05 13:53:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:53:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:53:35 --> Model Class Initialized
DEBUG - 2023-08-05 13:53:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:53:35 --> Model Class Initialized
INFO - 2023-08-05 13:53:35 --> Final output sent to browser
DEBUG - 2023-08-05 13:53:35 --> Total execution time: 0.0258
ERROR - 2023-08-05 13:54:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:54:25 --> Config Class Initialized
INFO - 2023-08-05 13:54:25 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:54:25 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:54:25 --> Utf8 Class Initialized
INFO - 2023-08-05 13:54:25 --> URI Class Initialized
INFO - 2023-08-05 13:54:25 --> Router Class Initialized
INFO - 2023-08-05 13:54:25 --> Output Class Initialized
INFO - 2023-08-05 13:54:25 --> Security Class Initialized
DEBUG - 2023-08-05 13:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:54:25 --> Input Class Initialized
INFO - 2023-08-05 13:54:25 --> Language Class Initialized
INFO - 2023-08-05 13:54:25 --> Loader Class Initialized
INFO - 2023-08-05 13:54:25 --> Helper loaded: url_helper
INFO - 2023-08-05 13:54:25 --> Helper loaded: file_helper
INFO - 2023-08-05 13:54:25 --> Helper loaded: html_helper
INFO - 2023-08-05 13:54:25 --> Helper loaded: text_helper
INFO - 2023-08-05 13:54:25 --> Helper loaded: form_helper
INFO - 2023-08-05 13:54:25 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:54:25 --> Helper loaded: security_helper
INFO - 2023-08-05 13:54:25 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:54:25 --> Database Driver Class Initialized
INFO - 2023-08-05 13:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:54:25 --> Parser Class Initialized
INFO - 2023-08-05 13:54:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:54:25 --> Pagination Class Initialized
INFO - 2023-08-05 13:54:25 --> Form Validation Class Initialized
INFO - 2023-08-05 13:54:25 --> Controller Class Initialized
INFO - 2023-08-05 13:54:25 --> Model Class Initialized
DEBUG - 2023-08-05 13:54:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:54:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:54:25 --> Model Class Initialized
DEBUG - 2023-08-05 13:54:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:54:25 --> Model Class Initialized
INFO - 2023-08-05 13:54:25 --> Final output sent to browser
DEBUG - 2023-08-05 13:54:25 --> Total execution time: 0.0289
ERROR - 2023-08-05 13:54:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:54:38 --> Config Class Initialized
INFO - 2023-08-05 13:54:38 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:54:38 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:54:38 --> Utf8 Class Initialized
INFO - 2023-08-05 13:54:38 --> URI Class Initialized
INFO - 2023-08-05 13:54:38 --> Router Class Initialized
INFO - 2023-08-05 13:54:38 --> Output Class Initialized
INFO - 2023-08-05 13:54:38 --> Security Class Initialized
DEBUG - 2023-08-05 13:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:54:38 --> Input Class Initialized
INFO - 2023-08-05 13:54:38 --> Language Class Initialized
INFO - 2023-08-05 13:54:38 --> Loader Class Initialized
INFO - 2023-08-05 13:54:38 --> Helper loaded: url_helper
INFO - 2023-08-05 13:54:38 --> Helper loaded: file_helper
INFO - 2023-08-05 13:54:38 --> Helper loaded: html_helper
INFO - 2023-08-05 13:54:38 --> Helper loaded: text_helper
INFO - 2023-08-05 13:54:38 --> Helper loaded: form_helper
INFO - 2023-08-05 13:54:38 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:54:38 --> Helper loaded: security_helper
INFO - 2023-08-05 13:54:38 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:54:38 --> Database Driver Class Initialized
INFO - 2023-08-05 13:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:54:38 --> Parser Class Initialized
INFO - 2023-08-05 13:54:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:54:38 --> Pagination Class Initialized
INFO - 2023-08-05 13:54:38 --> Form Validation Class Initialized
INFO - 2023-08-05 13:54:38 --> Controller Class Initialized
DEBUG - 2023-08-05 13:54:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:54:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:54:38 --> Model Class Initialized
DEBUG - 2023-08-05 13:54:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:54:38 --> Model Class Initialized
DEBUG - 2023-08-05 13:54:38 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:54:38 --> Model Class Initialized
INFO - 2023-08-05 13:54:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-08-05 13:54:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:54:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:54:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:54:38 --> Model Class Initialized
INFO - 2023-08-05 13:54:38 --> Model Class Initialized
INFO - 2023-08-05 13:54:38 --> Model Class Initialized
INFO - 2023-08-05 13:54:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:54:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:54:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:54:38 --> Final output sent to browser
DEBUG - 2023-08-05 13:54:38 --> Total execution time: 0.0727
ERROR - 2023-08-05 13:54:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:54:39 --> Config Class Initialized
INFO - 2023-08-05 13:54:39 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:54:39 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:54:39 --> Utf8 Class Initialized
INFO - 2023-08-05 13:54:39 --> URI Class Initialized
INFO - 2023-08-05 13:54:39 --> Router Class Initialized
INFO - 2023-08-05 13:54:39 --> Output Class Initialized
INFO - 2023-08-05 13:54:39 --> Security Class Initialized
DEBUG - 2023-08-05 13:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:54:39 --> Input Class Initialized
INFO - 2023-08-05 13:54:39 --> Language Class Initialized
INFO - 2023-08-05 13:54:39 --> Loader Class Initialized
INFO - 2023-08-05 13:54:39 --> Helper loaded: url_helper
INFO - 2023-08-05 13:54:39 --> Helper loaded: file_helper
INFO - 2023-08-05 13:54:39 --> Helper loaded: html_helper
INFO - 2023-08-05 13:54:39 --> Helper loaded: text_helper
INFO - 2023-08-05 13:54:39 --> Helper loaded: form_helper
INFO - 2023-08-05 13:54:39 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:54:39 --> Helper loaded: security_helper
INFO - 2023-08-05 13:54:39 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:54:39 --> Database Driver Class Initialized
INFO - 2023-08-05 13:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:54:39 --> Parser Class Initialized
INFO - 2023-08-05 13:54:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:54:39 --> Pagination Class Initialized
INFO - 2023-08-05 13:54:39 --> Form Validation Class Initialized
INFO - 2023-08-05 13:54:39 --> Controller Class Initialized
DEBUG - 2023-08-05 13:54:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:54:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:54:39 --> Model Class Initialized
DEBUG - 2023-08-05 13:54:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:54:39 --> Model Class Initialized
INFO - 2023-08-05 13:54:39 --> Final output sent to browser
DEBUG - 2023-08-05 13:54:39 --> Total execution time: 0.0245
ERROR - 2023-08-05 13:54:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:54:42 --> Config Class Initialized
INFO - 2023-08-05 13:54:42 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:54:42 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:54:42 --> Utf8 Class Initialized
INFO - 2023-08-05 13:54:42 --> URI Class Initialized
DEBUG - 2023-08-05 13:54:42 --> No URI present. Default controller set.
INFO - 2023-08-05 13:54:42 --> Router Class Initialized
INFO - 2023-08-05 13:54:42 --> Output Class Initialized
INFO - 2023-08-05 13:54:42 --> Security Class Initialized
DEBUG - 2023-08-05 13:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:54:42 --> Input Class Initialized
INFO - 2023-08-05 13:54:42 --> Language Class Initialized
INFO - 2023-08-05 13:54:42 --> Loader Class Initialized
INFO - 2023-08-05 13:54:42 --> Helper loaded: url_helper
INFO - 2023-08-05 13:54:42 --> Helper loaded: file_helper
INFO - 2023-08-05 13:54:42 --> Helper loaded: html_helper
INFO - 2023-08-05 13:54:42 --> Helper loaded: text_helper
INFO - 2023-08-05 13:54:42 --> Helper loaded: form_helper
INFO - 2023-08-05 13:54:42 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:54:42 --> Helper loaded: security_helper
INFO - 2023-08-05 13:54:42 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:54:42 --> Database Driver Class Initialized
INFO - 2023-08-05 13:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:54:42 --> Parser Class Initialized
INFO - 2023-08-05 13:54:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:54:42 --> Pagination Class Initialized
INFO - 2023-08-05 13:54:42 --> Form Validation Class Initialized
INFO - 2023-08-05 13:54:42 --> Controller Class Initialized
INFO - 2023-08-05 13:54:42 --> Model Class Initialized
DEBUG - 2023-08-05 13:54:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:54:42 --> Model Class Initialized
DEBUG - 2023-08-05 13:54:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:54:42 --> Model Class Initialized
INFO - 2023-08-05 13:54:42 --> Model Class Initialized
INFO - 2023-08-05 13:54:42 --> Model Class Initialized
INFO - 2023-08-05 13:54:42 --> Model Class Initialized
DEBUG - 2023-08-05 13:54:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:54:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:54:42 --> Model Class Initialized
INFO - 2023-08-05 13:54:42 --> Model Class Initialized
INFO - 2023-08-05 13:54:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 13:54:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:54:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:54:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:54:42 --> Model Class Initialized
INFO - 2023-08-05 13:54:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:54:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:54:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:54:42 --> Final output sent to browser
DEBUG - 2023-08-05 13:54:42 --> Total execution time: 0.0901
ERROR - 2023-08-05 13:54:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:54:45 --> Config Class Initialized
INFO - 2023-08-05 13:54:45 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:54:45 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:54:45 --> Utf8 Class Initialized
INFO - 2023-08-05 13:54:45 --> URI Class Initialized
INFO - 2023-08-05 13:54:45 --> Router Class Initialized
INFO - 2023-08-05 13:54:45 --> Output Class Initialized
INFO - 2023-08-05 13:54:45 --> Security Class Initialized
DEBUG - 2023-08-05 13:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:54:45 --> Input Class Initialized
INFO - 2023-08-05 13:54:45 --> Language Class Initialized
INFO - 2023-08-05 13:54:45 --> Loader Class Initialized
INFO - 2023-08-05 13:54:45 --> Helper loaded: url_helper
INFO - 2023-08-05 13:54:45 --> Helper loaded: file_helper
INFO - 2023-08-05 13:54:45 --> Helper loaded: html_helper
INFO - 2023-08-05 13:54:45 --> Helper loaded: text_helper
INFO - 2023-08-05 13:54:45 --> Helper loaded: form_helper
INFO - 2023-08-05 13:54:45 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:54:45 --> Helper loaded: security_helper
INFO - 2023-08-05 13:54:45 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:54:45 --> Database Driver Class Initialized
INFO - 2023-08-05 13:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:54:45 --> Parser Class Initialized
INFO - 2023-08-05 13:54:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:54:45 --> Pagination Class Initialized
INFO - 2023-08-05 13:54:45 --> Form Validation Class Initialized
INFO - 2023-08-05 13:54:45 --> Controller Class Initialized
DEBUG - 2023-08-05 13:54:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:54:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:54:45 --> Model Class Initialized
DEBUG - 2023-08-05 13:54:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:54:45 --> Model Class Initialized
INFO - 2023-08-05 13:54:45 --> Final output sent to browser
DEBUG - 2023-08-05 13:54:45 --> Total execution time: 0.0251
ERROR - 2023-08-05 13:54:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:54:59 --> Config Class Initialized
INFO - 2023-08-05 13:54:59 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:54:59 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:54:59 --> Utf8 Class Initialized
INFO - 2023-08-05 13:54:59 --> URI Class Initialized
INFO - 2023-08-05 13:54:59 --> Router Class Initialized
INFO - 2023-08-05 13:54:59 --> Output Class Initialized
INFO - 2023-08-05 13:54:59 --> Security Class Initialized
DEBUG - 2023-08-05 13:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:54:59 --> Input Class Initialized
INFO - 2023-08-05 13:54:59 --> Language Class Initialized
INFO - 2023-08-05 13:54:59 --> Loader Class Initialized
INFO - 2023-08-05 13:54:59 --> Helper loaded: url_helper
INFO - 2023-08-05 13:54:59 --> Helper loaded: file_helper
INFO - 2023-08-05 13:54:59 --> Helper loaded: html_helper
INFO - 2023-08-05 13:54:59 --> Helper loaded: text_helper
INFO - 2023-08-05 13:54:59 --> Helper loaded: form_helper
INFO - 2023-08-05 13:54:59 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:54:59 --> Helper loaded: security_helper
INFO - 2023-08-05 13:54:59 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:54:59 --> Database Driver Class Initialized
INFO - 2023-08-05 13:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:54:59 --> Parser Class Initialized
INFO - 2023-08-05 13:54:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:54:59 --> Pagination Class Initialized
INFO - 2023-08-05 13:54:59 --> Form Validation Class Initialized
INFO - 2023-08-05 13:54:59 --> Controller Class Initialized
INFO - 2023-08-05 13:54:59 --> Model Class Initialized
DEBUG - 2023-08-05 13:54:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:54:59 --> Model Class Initialized
DEBUG - 2023-08-05 13:54:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:54:59 --> Model Class Initialized
INFO - 2023-08-05 13:54:59 --> Model Class Initialized
INFO - 2023-08-05 13:54:59 --> Model Class Initialized
INFO - 2023-08-05 13:54:59 --> Model Class Initialized
DEBUG - 2023-08-05 13:54:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:54:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:54:59 --> Model Class Initialized
INFO - 2023-08-05 13:54:59 --> Model Class Initialized
INFO - 2023-08-05 13:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 13:54:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:54:59 --> Model Class Initialized
INFO - 2023-08-05 13:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:54:59 --> Final output sent to browser
DEBUG - 2023-08-05 13:54:59 --> Total execution time: 0.0805
ERROR - 2023-08-05 13:54:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:54:59 --> Config Class Initialized
INFO - 2023-08-05 13:54:59 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:54:59 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:54:59 --> Utf8 Class Initialized
INFO - 2023-08-05 13:54:59 --> URI Class Initialized
INFO - 2023-08-05 13:54:59 --> Router Class Initialized
INFO - 2023-08-05 13:54:59 --> Output Class Initialized
INFO - 2023-08-05 13:54:59 --> Security Class Initialized
DEBUG - 2023-08-05 13:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:54:59 --> Input Class Initialized
INFO - 2023-08-05 13:54:59 --> Language Class Initialized
INFO - 2023-08-05 13:54:59 --> Loader Class Initialized
INFO - 2023-08-05 13:54:59 --> Helper loaded: url_helper
INFO - 2023-08-05 13:54:59 --> Helper loaded: file_helper
INFO - 2023-08-05 13:54:59 --> Helper loaded: html_helper
INFO - 2023-08-05 13:54:59 --> Helper loaded: text_helper
INFO - 2023-08-05 13:54:59 --> Helper loaded: form_helper
INFO - 2023-08-05 13:54:59 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:54:59 --> Helper loaded: security_helper
INFO - 2023-08-05 13:54:59 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:54:59 --> Database Driver Class Initialized
INFO - 2023-08-05 13:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:54:59 --> Parser Class Initialized
INFO - 2023-08-05 13:54:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:54:59 --> Pagination Class Initialized
INFO - 2023-08-05 13:54:59 --> Form Validation Class Initialized
INFO - 2023-08-05 13:54:59 --> Controller Class Initialized
INFO - 2023-08-05 13:54:59 --> Model Class Initialized
DEBUG - 2023-08-05 13:54:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-05 13:54:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:54:59 --> Model Class Initialized
INFO - 2023-08-05 13:54:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:54:59 --> Final output sent to browser
DEBUG - 2023-08-05 13:54:59 --> Total execution time: 0.0306
ERROR - 2023-08-05 13:55:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:55:00 --> Config Class Initialized
INFO - 2023-08-05 13:55:00 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:55:00 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:55:00 --> Utf8 Class Initialized
INFO - 2023-08-05 13:55:00 --> URI Class Initialized
INFO - 2023-08-05 13:55:00 --> Router Class Initialized
INFO - 2023-08-05 13:55:00 --> Output Class Initialized
INFO - 2023-08-05 13:55:00 --> Security Class Initialized
DEBUG - 2023-08-05 13:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:55:00 --> Input Class Initialized
INFO - 2023-08-05 13:55:00 --> Language Class Initialized
INFO - 2023-08-05 13:55:00 --> Loader Class Initialized
INFO - 2023-08-05 13:55:00 --> Helper loaded: url_helper
INFO - 2023-08-05 13:55:00 --> Helper loaded: file_helper
INFO - 2023-08-05 13:55:00 --> Helper loaded: html_helper
INFO - 2023-08-05 13:55:00 --> Helper loaded: text_helper
INFO - 2023-08-05 13:55:00 --> Helper loaded: form_helper
INFO - 2023-08-05 13:55:00 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:55:00 --> Helper loaded: security_helper
INFO - 2023-08-05 13:55:00 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:55:00 --> Database Driver Class Initialized
INFO - 2023-08-05 13:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:55:00 --> Parser Class Initialized
INFO - 2023-08-05 13:55:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:55:00 --> Pagination Class Initialized
INFO - 2023-08-05 13:55:00 --> Form Validation Class Initialized
INFO - 2023-08-05 13:55:00 --> Controller Class Initialized
INFO - 2023-08-05 13:55:00 --> Model Class Initialized
DEBUG - 2023-08-05 13:55:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:00 --> Model Class Initialized
DEBUG - 2023-08-05 13:55:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:00 --> Model Class Initialized
INFO - 2023-08-05 13:55:00 --> Model Class Initialized
INFO - 2023-08-05 13:55:00 --> Model Class Initialized
INFO - 2023-08-05 13:55:00 --> Model Class Initialized
DEBUG - 2023-08-05 13:55:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:55:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:00 --> Model Class Initialized
INFO - 2023-08-05 13:55:00 --> Model Class Initialized
INFO - 2023-08-05 13:55:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 13:55:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:55:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:55:00 --> Model Class Initialized
INFO - 2023-08-05 13:55:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:55:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:55:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:55:00 --> Final output sent to browser
DEBUG - 2023-08-05 13:55:00 --> Total execution time: 0.0767
ERROR - 2023-08-05 13:55:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:55:03 --> Config Class Initialized
INFO - 2023-08-05 13:55:03 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:55:03 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:55:03 --> Utf8 Class Initialized
INFO - 2023-08-05 13:55:03 --> URI Class Initialized
INFO - 2023-08-05 13:55:03 --> Router Class Initialized
INFO - 2023-08-05 13:55:03 --> Output Class Initialized
INFO - 2023-08-05 13:55:03 --> Security Class Initialized
DEBUG - 2023-08-05 13:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:55:03 --> Input Class Initialized
INFO - 2023-08-05 13:55:03 --> Language Class Initialized
INFO - 2023-08-05 13:55:03 --> Loader Class Initialized
INFO - 2023-08-05 13:55:03 --> Helper loaded: url_helper
INFO - 2023-08-05 13:55:03 --> Helper loaded: file_helper
INFO - 2023-08-05 13:55:03 --> Helper loaded: html_helper
INFO - 2023-08-05 13:55:03 --> Helper loaded: text_helper
INFO - 2023-08-05 13:55:03 --> Helper loaded: form_helper
INFO - 2023-08-05 13:55:03 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:55:03 --> Helper loaded: security_helper
INFO - 2023-08-05 13:55:03 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:55:03 --> Database Driver Class Initialized
INFO - 2023-08-05 13:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:55:03 --> Parser Class Initialized
INFO - 2023-08-05 13:55:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:55:03 --> Pagination Class Initialized
INFO - 2023-08-05 13:55:03 --> Form Validation Class Initialized
INFO - 2023-08-05 13:55:03 --> Controller Class Initialized
INFO - 2023-08-05 13:55:03 --> Model Class Initialized
DEBUG - 2023-08-05 13:55:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:55:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:03 --> Model Class Initialized
DEBUG - 2023-08-05 13:55:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:03 --> Model Class Initialized
INFO - 2023-08-05 13:55:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-08-05 13:55:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:55:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:55:04 --> Model Class Initialized
INFO - 2023-08-05 13:55:04 --> Model Class Initialized
INFO - 2023-08-05 13:55:04 --> Model Class Initialized
INFO - 2023-08-05 13:55:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:55:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:55:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:55:04 --> Final output sent to browser
DEBUG - 2023-08-05 13:55:04 --> Total execution time: 0.0817
ERROR - 2023-08-05 13:55:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:55:04 --> Config Class Initialized
INFO - 2023-08-05 13:55:04 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:55:04 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:55:04 --> Utf8 Class Initialized
INFO - 2023-08-05 13:55:04 --> URI Class Initialized
INFO - 2023-08-05 13:55:04 --> Router Class Initialized
INFO - 2023-08-05 13:55:04 --> Output Class Initialized
INFO - 2023-08-05 13:55:04 --> Security Class Initialized
DEBUG - 2023-08-05 13:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:55:04 --> Input Class Initialized
INFO - 2023-08-05 13:55:04 --> Language Class Initialized
INFO - 2023-08-05 13:55:04 --> Loader Class Initialized
INFO - 2023-08-05 13:55:04 --> Helper loaded: url_helper
INFO - 2023-08-05 13:55:04 --> Helper loaded: file_helper
INFO - 2023-08-05 13:55:04 --> Helper loaded: html_helper
INFO - 2023-08-05 13:55:04 --> Helper loaded: text_helper
INFO - 2023-08-05 13:55:04 --> Helper loaded: form_helper
INFO - 2023-08-05 13:55:04 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:55:04 --> Helper loaded: security_helper
INFO - 2023-08-05 13:55:04 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:55:04 --> Database Driver Class Initialized
INFO - 2023-08-05 13:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:55:04 --> Parser Class Initialized
INFO - 2023-08-05 13:55:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:55:04 --> Pagination Class Initialized
INFO - 2023-08-05 13:55:04 --> Form Validation Class Initialized
INFO - 2023-08-05 13:55:04 --> Controller Class Initialized
INFO - 2023-08-05 13:55:04 --> Model Class Initialized
DEBUG - 2023-08-05 13:55:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:04 --> Model Class Initialized
DEBUG - 2023-08-05 13:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:04 --> Model Class Initialized
INFO - 2023-08-05 13:55:04 --> Final output sent to browser
DEBUG - 2023-08-05 13:55:04 --> Total execution time: 0.0247
ERROR - 2023-08-05 13:55:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:55:09 --> Config Class Initialized
INFO - 2023-08-05 13:55:09 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:55:09 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:55:09 --> Utf8 Class Initialized
INFO - 2023-08-05 13:55:09 --> URI Class Initialized
DEBUG - 2023-08-05 13:55:09 --> No URI present. Default controller set.
INFO - 2023-08-05 13:55:09 --> Router Class Initialized
INFO - 2023-08-05 13:55:09 --> Output Class Initialized
INFO - 2023-08-05 13:55:09 --> Security Class Initialized
DEBUG - 2023-08-05 13:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:55:09 --> Input Class Initialized
INFO - 2023-08-05 13:55:09 --> Language Class Initialized
INFO - 2023-08-05 13:55:09 --> Loader Class Initialized
INFO - 2023-08-05 13:55:09 --> Helper loaded: url_helper
INFO - 2023-08-05 13:55:09 --> Helper loaded: file_helper
INFO - 2023-08-05 13:55:09 --> Helper loaded: html_helper
INFO - 2023-08-05 13:55:09 --> Helper loaded: text_helper
INFO - 2023-08-05 13:55:09 --> Helper loaded: form_helper
INFO - 2023-08-05 13:55:09 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:55:09 --> Helper loaded: security_helper
INFO - 2023-08-05 13:55:09 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:55:09 --> Database Driver Class Initialized
INFO - 2023-08-05 13:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:55:09 --> Parser Class Initialized
INFO - 2023-08-05 13:55:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:55:09 --> Pagination Class Initialized
INFO - 2023-08-05 13:55:09 --> Form Validation Class Initialized
INFO - 2023-08-05 13:55:09 --> Controller Class Initialized
INFO - 2023-08-05 13:55:09 --> Model Class Initialized
DEBUG - 2023-08-05 13:55:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:09 --> Model Class Initialized
DEBUG - 2023-08-05 13:55:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:09 --> Model Class Initialized
INFO - 2023-08-05 13:55:09 --> Model Class Initialized
INFO - 2023-08-05 13:55:09 --> Model Class Initialized
INFO - 2023-08-05 13:55:09 --> Model Class Initialized
DEBUG - 2023-08-05 13:55:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:55:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:09 --> Model Class Initialized
INFO - 2023-08-05 13:55:09 --> Model Class Initialized
INFO - 2023-08-05 13:55:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 13:55:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:55:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:55:09 --> Model Class Initialized
INFO - 2023-08-05 13:55:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:55:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:55:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:55:09 --> Final output sent to browser
DEBUG - 2023-08-05 13:55:09 --> Total execution time: 0.0820
ERROR - 2023-08-05 13:55:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:55:14 --> Config Class Initialized
INFO - 2023-08-05 13:55:14 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:55:14 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:55:14 --> Utf8 Class Initialized
INFO - 2023-08-05 13:55:14 --> URI Class Initialized
INFO - 2023-08-05 13:55:14 --> Router Class Initialized
INFO - 2023-08-05 13:55:14 --> Output Class Initialized
INFO - 2023-08-05 13:55:14 --> Security Class Initialized
DEBUG - 2023-08-05 13:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:55:14 --> Input Class Initialized
INFO - 2023-08-05 13:55:14 --> Language Class Initialized
INFO - 2023-08-05 13:55:14 --> Loader Class Initialized
INFO - 2023-08-05 13:55:14 --> Helper loaded: url_helper
INFO - 2023-08-05 13:55:14 --> Helper loaded: file_helper
INFO - 2023-08-05 13:55:14 --> Helper loaded: html_helper
INFO - 2023-08-05 13:55:14 --> Helper loaded: text_helper
INFO - 2023-08-05 13:55:14 --> Helper loaded: form_helper
INFO - 2023-08-05 13:55:14 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:55:14 --> Helper loaded: security_helper
INFO - 2023-08-05 13:55:14 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:55:14 --> Database Driver Class Initialized
INFO - 2023-08-05 13:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:55:14 --> Parser Class Initialized
INFO - 2023-08-05 13:55:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:55:14 --> Pagination Class Initialized
INFO - 2023-08-05 13:55:14 --> Form Validation Class Initialized
INFO - 2023-08-05 13:55:14 --> Controller Class Initialized
INFO - 2023-08-05 13:55:14 --> Model Class Initialized
INFO - 2023-08-05 13:55:14 --> Model Class Initialized
INFO - 2023-08-05 13:55:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-08-05 13:55:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:55:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:55:14 --> Model Class Initialized
INFO - 2023-08-05 13:55:14 --> Model Class Initialized
INFO - 2023-08-05 13:55:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:55:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:55:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:55:14 --> Final output sent to browser
DEBUG - 2023-08-05 13:55:14 --> Total execution time: 0.0628
ERROR - 2023-08-05 13:55:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:55:14 --> Config Class Initialized
INFO - 2023-08-05 13:55:14 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:55:14 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:55:14 --> Utf8 Class Initialized
INFO - 2023-08-05 13:55:14 --> URI Class Initialized
INFO - 2023-08-05 13:55:14 --> Router Class Initialized
INFO - 2023-08-05 13:55:14 --> Output Class Initialized
INFO - 2023-08-05 13:55:14 --> Security Class Initialized
DEBUG - 2023-08-05 13:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:55:14 --> Input Class Initialized
INFO - 2023-08-05 13:55:14 --> Language Class Initialized
INFO - 2023-08-05 13:55:14 --> Loader Class Initialized
INFO - 2023-08-05 13:55:14 --> Helper loaded: url_helper
INFO - 2023-08-05 13:55:14 --> Helper loaded: file_helper
INFO - 2023-08-05 13:55:14 --> Helper loaded: html_helper
INFO - 2023-08-05 13:55:14 --> Helper loaded: text_helper
INFO - 2023-08-05 13:55:14 --> Helper loaded: form_helper
INFO - 2023-08-05 13:55:14 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:55:14 --> Helper loaded: security_helper
INFO - 2023-08-05 13:55:14 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:55:14 --> Database Driver Class Initialized
INFO - 2023-08-05 13:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:55:14 --> Parser Class Initialized
INFO - 2023-08-05 13:55:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:55:14 --> Pagination Class Initialized
INFO - 2023-08-05 13:55:14 --> Form Validation Class Initialized
INFO - 2023-08-05 13:55:14 --> Controller Class Initialized
INFO - 2023-08-05 13:55:14 --> Model Class Initialized
INFO - 2023-08-05 13:55:14 --> Model Class Initialized
INFO - 2023-08-05 13:55:14 --> Final output sent to browser
DEBUG - 2023-08-05 13:55:14 --> Total execution time: 0.0253
ERROR - 2023-08-05 13:55:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:55:17 --> Config Class Initialized
INFO - 2023-08-05 13:55:17 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:55:17 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:55:17 --> Utf8 Class Initialized
INFO - 2023-08-05 13:55:17 --> URI Class Initialized
INFO - 2023-08-05 13:55:17 --> Router Class Initialized
INFO - 2023-08-05 13:55:17 --> Output Class Initialized
INFO - 2023-08-05 13:55:17 --> Security Class Initialized
DEBUG - 2023-08-05 13:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:55:17 --> Input Class Initialized
INFO - 2023-08-05 13:55:17 --> Language Class Initialized
INFO - 2023-08-05 13:55:17 --> Loader Class Initialized
INFO - 2023-08-05 13:55:17 --> Helper loaded: url_helper
INFO - 2023-08-05 13:55:17 --> Helper loaded: file_helper
INFO - 2023-08-05 13:55:17 --> Helper loaded: html_helper
INFO - 2023-08-05 13:55:17 --> Helper loaded: text_helper
INFO - 2023-08-05 13:55:17 --> Helper loaded: form_helper
INFO - 2023-08-05 13:55:17 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:55:17 --> Helper loaded: security_helper
INFO - 2023-08-05 13:55:17 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:55:17 --> Database Driver Class Initialized
INFO - 2023-08-05 13:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:55:17 --> Parser Class Initialized
INFO - 2023-08-05 13:55:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:55:17 --> Pagination Class Initialized
INFO - 2023-08-05 13:55:17 --> Form Validation Class Initialized
INFO - 2023-08-05 13:55:17 --> Controller Class Initialized
INFO - 2023-08-05 13:55:17 --> Model Class Initialized
INFO - 2023-08-05 13:55:17 --> Model Class Initialized
INFO - 2023-08-05 13:55:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-08-05 13:55:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:55:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:55:17 --> Model Class Initialized
INFO - 2023-08-05 13:55:17 --> Model Class Initialized
INFO - 2023-08-05 13:55:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:55:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:55:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:55:17 --> Final output sent to browser
DEBUG - 2023-08-05 13:55:17 --> Total execution time: 0.0597
ERROR - 2023-08-05 13:55:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:55:17 --> Config Class Initialized
INFO - 2023-08-05 13:55:17 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:55:17 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:55:17 --> Utf8 Class Initialized
INFO - 2023-08-05 13:55:17 --> URI Class Initialized
INFO - 2023-08-05 13:55:17 --> Router Class Initialized
INFO - 2023-08-05 13:55:17 --> Output Class Initialized
INFO - 2023-08-05 13:55:17 --> Security Class Initialized
DEBUG - 2023-08-05 13:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:55:17 --> Input Class Initialized
INFO - 2023-08-05 13:55:17 --> Language Class Initialized
INFO - 2023-08-05 13:55:17 --> Loader Class Initialized
INFO - 2023-08-05 13:55:17 --> Helper loaded: url_helper
INFO - 2023-08-05 13:55:17 --> Helper loaded: file_helper
INFO - 2023-08-05 13:55:17 --> Helper loaded: html_helper
INFO - 2023-08-05 13:55:17 --> Helper loaded: text_helper
INFO - 2023-08-05 13:55:17 --> Helper loaded: form_helper
INFO - 2023-08-05 13:55:17 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:55:17 --> Helper loaded: security_helper
INFO - 2023-08-05 13:55:17 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:55:17 --> Database Driver Class Initialized
INFO - 2023-08-05 13:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:55:17 --> Parser Class Initialized
INFO - 2023-08-05 13:55:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:55:17 --> Pagination Class Initialized
INFO - 2023-08-05 13:55:17 --> Form Validation Class Initialized
INFO - 2023-08-05 13:55:17 --> Controller Class Initialized
INFO - 2023-08-05 13:55:17 --> Model Class Initialized
INFO - 2023-08-05 13:55:17 --> Model Class Initialized
INFO - 2023-08-05 13:55:17 --> Final output sent to browser
DEBUG - 2023-08-05 13:55:17 --> Total execution time: 0.0222
ERROR - 2023-08-05 13:55:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:55:21 --> Config Class Initialized
INFO - 2023-08-05 13:55:21 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:55:21 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:55:21 --> Utf8 Class Initialized
INFO - 2023-08-05 13:55:21 --> URI Class Initialized
INFO - 2023-08-05 13:55:21 --> Router Class Initialized
INFO - 2023-08-05 13:55:21 --> Output Class Initialized
INFO - 2023-08-05 13:55:21 --> Security Class Initialized
DEBUG - 2023-08-05 13:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:55:21 --> Input Class Initialized
INFO - 2023-08-05 13:55:21 --> Language Class Initialized
INFO - 2023-08-05 13:55:21 --> Loader Class Initialized
INFO - 2023-08-05 13:55:21 --> Helper loaded: url_helper
INFO - 2023-08-05 13:55:21 --> Helper loaded: file_helper
INFO - 2023-08-05 13:55:21 --> Helper loaded: html_helper
INFO - 2023-08-05 13:55:21 --> Helper loaded: text_helper
INFO - 2023-08-05 13:55:21 --> Helper loaded: form_helper
INFO - 2023-08-05 13:55:21 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:55:21 --> Helper loaded: security_helper
INFO - 2023-08-05 13:55:21 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:55:21 --> Database Driver Class Initialized
INFO - 2023-08-05 13:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:55:21 --> Parser Class Initialized
INFO - 2023-08-05 13:55:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:55:21 --> Pagination Class Initialized
INFO - 2023-08-05 13:55:21 --> Form Validation Class Initialized
INFO - 2023-08-05 13:55:21 --> Controller Class Initialized
INFO - 2023-08-05 13:55:21 --> Model Class Initialized
INFO - 2023-08-05 13:55:21 --> Model Class Initialized
INFO - 2023-08-05 13:55:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-08-05 13:55:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:55:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:55:21 --> Model Class Initialized
INFO - 2023-08-05 13:55:21 --> Model Class Initialized
INFO - 2023-08-05 13:55:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:55:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:55:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:55:21 --> Final output sent to browser
DEBUG - 2023-08-05 13:55:21 --> Total execution time: 0.0654
ERROR - 2023-08-05 13:55:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:55:22 --> Config Class Initialized
INFO - 2023-08-05 13:55:22 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:55:22 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:55:22 --> Utf8 Class Initialized
INFO - 2023-08-05 13:55:22 --> URI Class Initialized
INFO - 2023-08-05 13:55:22 --> Router Class Initialized
INFO - 2023-08-05 13:55:22 --> Output Class Initialized
INFO - 2023-08-05 13:55:22 --> Security Class Initialized
DEBUG - 2023-08-05 13:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:55:22 --> Input Class Initialized
INFO - 2023-08-05 13:55:22 --> Language Class Initialized
INFO - 2023-08-05 13:55:22 --> Loader Class Initialized
INFO - 2023-08-05 13:55:22 --> Helper loaded: url_helper
INFO - 2023-08-05 13:55:22 --> Helper loaded: file_helper
INFO - 2023-08-05 13:55:22 --> Helper loaded: html_helper
INFO - 2023-08-05 13:55:22 --> Helper loaded: text_helper
INFO - 2023-08-05 13:55:22 --> Helper loaded: form_helper
INFO - 2023-08-05 13:55:22 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:55:22 --> Helper loaded: security_helper
INFO - 2023-08-05 13:55:22 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:55:22 --> Database Driver Class Initialized
INFO - 2023-08-05 13:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:55:22 --> Parser Class Initialized
INFO - 2023-08-05 13:55:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:55:22 --> Pagination Class Initialized
INFO - 2023-08-05 13:55:22 --> Form Validation Class Initialized
INFO - 2023-08-05 13:55:22 --> Controller Class Initialized
INFO - 2023-08-05 13:55:22 --> Model Class Initialized
INFO - 2023-08-05 13:55:22 --> Model Class Initialized
INFO - 2023-08-05 13:55:22 --> Final output sent to browser
DEBUG - 2023-08-05 13:55:22 --> Total execution time: 0.0373
ERROR - 2023-08-05 13:55:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:55:26 --> Config Class Initialized
INFO - 2023-08-05 13:55:26 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:55:26 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:55:26 --> Utf8 Class Initialized
INFO - 2023-08-05 13:55:26 --> URI Class Initialized
INFO - 2023-08-05 13:55:26 --> Router Class Initialized
INFO - 2023-08-05 13:55:26 --> Output Class Initialized
INFO - 2023-08-05 13:55:26 --> Security Class Initialized
DEBUG - 2023-08-05 13:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:55:26 --> Input Class Initialized
INFO - 2023-08-05 13:55:26 --> Language Class Initialized
INFO - 2023-08-05 13:55:26 --> Loader Class Initialized
INFO - 2023-08-05 13:55:26 --> Helper loaded: url_helper
INFO - 2023-08-05 13:55:26 --> Helper loaded: file_helper
INFO - 2023-08-05 13:55:26 --> Helper loaded: html_helper
INFO - 2023-08-05 13:55:26 --> Helper loaded: text_helper
INFO - 2023-08-05 13:55:26 --> Helper loaded: form_helper
INFO - 2023-08-05 13:55:26 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:55:26 --> Helper loaded: security_helper
INFO - 2023-08-05 13:55:26 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:55:26 --> Database Driver Class Initialized
INFO - 2023-08-05 13:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:55:26 --> Parser Class Initialized
INFO - 2023-08-05 13:55:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:55:26 --> Pagination Class Initialized
INFO - 2023-08-05 13:55:26 --> Form Validation Class Initialized
INFO - 2023-08-05 13:55:26 --> Controller Class Initialized
DEBUG - 2023-08-05 13:55:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:55:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:26 --> Model Class Initialized
DEBUG - 2023-08-05 13:55:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:26 --> Model Class Initialized
INFO - 2023-08-05 13:55:26 --> Final output sent to browser
DEBUG - 2023-08-05 13:55:26 --> Total execution time: 0.0181
ERROR - 2023-08-05 13:55:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:55:40 --> Config Class Initialized
INFO - 2023-08-05 13:55:40 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:55:40 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:55:40 --> Utf8 Class Initialized
INFO - 2023-08-05 13:55:40 --> URI Class Initialized
INFO - 2023-08-05 13:55:40 --> Router Class Initialized
INFO - 2023-08-05 13:55:40 --> Output Class Initialized
INFO - 2023-08-05 13:55:40 --> Security Class Initialized
DEBUG - 2023-08-05 13:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:55:40 --> Input Class Initialized
INFO - 2023-08-05 13:55:40 --> Language Class Initialized
INFO - 2023-08-05 13:55:40 --> Loader Class Initialized
INFO - 2023-08-05 13:55:40 --> Helper loaded: url_helper
INFO - 2023-08-05 13:55:40 --> Helper loaded: file_helper
INFO - 2023-08-05 13:55:40 --> Helper loaded: html_helper
INFO - 2023-08-05 13:55:40 --> Helper loaded: text_helper
INFO - 2023-08-05 13:55:40 --> Helper loaded: form_helper
INFO - 2023-08-05 13:55:40 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:55:40 --> Helper loaded: security_helper
INFO - 2023-08-05 13:55:40 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:55:40 --> Database Driver Class Initialized
INFO - 2023-08-05 13:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:55:40 --> Parser Class Initialized
INFO - 2023-08-05 13:55:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:55:40 --> Pagination Class Initialized
INFO - 2023-08-05 13:55:40 --> Form Validation Class Initialized
INFO - 2023-08-05 13:55:40 --> Controller Class Initialized
INFO - 2023-08-05 13:55:40 --> Model Class Initialized
INFO - 2023-08-05 13:55:40 --> Model Class Initialized
INFO - 2023-08-05 13:55:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-08-05 13:55:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:55:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:55:40 --> Model Class Initialized
INFO - 2023-08-05 13:55:40 --> Model Class Initialized
INFO - 2023-08-05 13:55:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:55:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:55:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:55:40 --> Final output sent to browser
DEBUG - 2023-08-05 13:55:40 --> Total execution time: 0.0646
ERROR - 2023-08-05 13:55:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:55:41 --> Config Class Initialized
INFO - 2023-08-05 13:55:41 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:55:41 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:55:41 --> Utf8 Class Initialized
INFO - 2023-08-05 13:55:41 --> URI Class Initialized
INFO - 2023-08-05 13:55:41 --> Router Class Initialized
INFO - 2023-08-05 13:55:41 --> Output Class Initialized
INFO - 2023-08-05 13:55:41 --> Security Class Initialized
DEBUG - 2023-08-05 13:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:55:41 --> Input Class Initialized
INFO - 2023-08-05 13:55:41 --> Language Class Initialized
INFO - 2023-08-05 13:55:41 --> Loader Class Initialized
INFO - 2023-08-05 13:55:41 --> Helper loaded: url_helper
INFO - 2023-08-05 13:55:41 --> Helper loaded: file_helper
INFO - 2023-08-05 13:55:41 --> Helper loaded: html_helper
INFO - 2023-08-05 13:55:41 --> Helper loaded: text_helper
INFO - 2023-08-05 13:55:41 --> Helper loaded: form_helper
INFO - 2023-08-05 13:55:41 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:55:41 --> Helper loaded: security_helper
INFO - 2023-08-05 13:55:41 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:55:41 --> Database Driver Class Initialized
INFO - 2023-08-05 13:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:55:41 --> Parser Class Initialized
INFO - 2023-08-05 13:55:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:55:41 --> Pagination Class Initialized
INFO - 2023-08-05 13:55:41 --> Form Validation Class Initialized
INFO - 2023-08-05 13:55:41 --> Controller Class Initialized
INFO - 2023-08-05 13:55:41 --> Model Class Initialized
INFO - 2023-08-05 13:55:41 --> Model Class Initialized
INFO - 2023-08-05 13:55:41 --> Final output sent to browser
DEBUG - 2023-08-05 13:55:41 --> Total execution time: 0.0225
ERROR - 2023-08-05 13:55:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:55:43 --> Config Class Initialized
INFO - 2023-08-05 13:55:43 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:55:43 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:55:43 --> Utf8 Class Initialized
INFO - 2023-08-05 13:55:43 --> URI Class Initialized
INFO - 2023-08-05 13:55:43 --> Router Class Initialized
INFO - 2023-08-05 13:55:43 --> Output Class Initialized
INFO - 2023-08-05 13:55:43 --> Security Class Initialized
DEBUG - 2023-08-05 13:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:55:43 --> Input Class Initialized
INFO - 2023-08-05 13:55:43 --> Language Class Initialized
INFO - 2023-08-05 13:55:43 --> Loader Class Initialized
INFO - 2023-08-05 13:55:43 --> Helper loaded: url_helper
INFO - 2023-08-05 13:55:43 --> Helper loaded: file_helper
INFO - 2023-08-05 13:55:43 --> Helper loaded: html_helper
INFO - 2023-08-05 13:55:43 --> Helper loaded: text_helper
INFO - 2023-08-05 13:55:43 --> Helper loaded: form_helper
INFO - 2023-08-05 13:55:43 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:55:43 --> Helper loaded: security_helper
INFO - 2023-08-05 13:55:43 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:55:43 --> Database Driver Class Initialized
INFO - 2023-08-05 13:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:55:43 --> Parser Class Initialized
INFO - 2023-08-05 13:55:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:55:43 --> Pagination Class Initialized
INFO - 2023-08-05 13:55:43 --> Form Validation Class Initialized
INFO - 2023-08-05 13:55:43 --> Controller Class Initialized
INFO - 2023-08-05 13:55:43 --> Model Class Initialized
DEBUG - 2023-08-05 13:55:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:43 --> Model Class Initialized
DEBUG - 2023-08-05 13:55:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:43 --> Model Class Initialized
INFO - 2023-08-05 13:55:43 --> Model Class Initialized
INFO - 2023-08-05 13:55:43 --> Model Class Initialized
INFO - 2023-08-05 13:55:43 --> Model Class Initialized
DEBUG - 2023-08-05 13:55:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:55:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:43 --> Model Class Initialized
INFO - 2023-08-05 13:55:43 --> Model Class Initialized
INFO - 2023-08-05 13:55:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 13:55:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:55:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:55:43 --> Model Class Initialized
INFO - 2023-08-05 13:55:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:55:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:55:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:55:43 --> Final output sent to browser
DEBUG - 2023-08-05 13:55:43 --> Total execution time: 0.0731
ERROR - 2023-08-05 13:55:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:55:55 --> Config Class Initialized
INFO - 2023-08-05 13:55:55 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:55:55 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:55:55 --> Utf8 Class Initialized
INFO - 2023-08-05 13:55:55 --> URI Class Initialized
INFO - 2023-08-05 13:55:55 --> Router Class Initialized
INFO - 2023-08-05 13:55:55 --> Output Class Initialized
INFO - 2023-08-05 13:55:55 --> Security Class Initialized
DEBUG - 2023-08-05 13:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:55:55 --> Input Class Initialized
INFO - 2023-08-05 13:55:55 --> Language Class Initialized
INFO - 2023-08-05 13:55:55 --> Loader Class Initialized
INFO - 2023-08-05 13:55:55 --> Helper loaded: url_helper
INFO - 2023-08-05 13:55:55 --> Helper loaded: file_helper
INFO - 2023-08-05 13:55:55 --> Helper loaded: html_helper
INFO - 2023-08-05 13:55:55 --> Helper loaded: text_helper
INFO - 2023-08-05 13:55:55 --> Helper loaded: form_helper
INFO - 2023-08-05 13:55:55 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:55:55 --> Helper loaded: security_helper
INFO - 2023-08-05 13:55:55 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:55:55 --> Database Driver Class Initialized
INFO - 2023-08-05 13:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:55:55 --> Parser Class Initialized
INFO - 2023-08-05 13:55:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:55:55 --> Pagination Class Initialized
INFO - 2023-08-05 13:55:55 --> Form Validation Class Initialized
INFO - 2023-08-05 13:55:55 --> Controller Class Initialized
INFO - 2023-08-05 13:55:55 --> Model Class Initialized
DEBUG - 2023-08-05 13:55:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-05 13:55:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:55:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:55:55 --> Model Class Initialized
INFO - 2023-08-05 13:55:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:55:55 --> Final output sent to browser
DEBUG - 2023-08-05 13:55:55 --> Total execution time: 0.0330
ERROR - 2023-08-05 13:55:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:55:55 --> Config Class Initialized
INFO - 2023-08-05 13:55:55 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:55:55 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:55:55 --> Utf8 Class Initialized
INFO - 2023-08-05 13:55:55 --> URI Class Initialized
INFO - 2023-08-05 13:55:55 --> Router Class Initialized
INFO - 2023-08-05 13:55:55 --> Output Class Initialized
INFO - 2023-08-05 13:55:55 --> Security Class Initialized
DEBUG - 2023-08-05 13:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:55:55 --> Input Class Initialized
INFO - 2023-08-05 13:55:55 --> Language Class Initialized
INFO - 2023-08-05 13:55:55 --> Loader Class Initialized
INFO - 2023-08-05 13:55:55 --> Helper loaded: url_helper
INFO - 2023-08-05 13:55:55 --> Helper loaded: file_helper
INFO - 2023-08-05 13:55:55 --> Helper loaded: html_helper
INFO - 2023-08-05 13:55:55 --> Helper loaded: text_helper
INFO - 2023-08-05 13:55:55 --> Helper loaded: form_helper
INFO - 2023-08-05 13:55:55 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:55:55 --> Helper loaded: security_helper
INFO - 2023-08-05 13:55:55 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:55:55 --> Database Driver Class Initialized
INFO - 2023-08-05 13:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:55:55 --> Parser Class Initialized
INFO - 2023-08-05 13:55:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:55:55 --> Pagination Class Initialized
INFO - 2023-08-05 13:55:55 --> Form Validation Class Initialized
INFO - 2023-08-05 13:55:55 --> Controller Class Initialized
INFO - 2023-08-05 13:55:55 --> Model Class Initialized
DEBUG - 2023-08-05 13:55:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:55 --> Model Class Initialized
DEBUG - 2023-08-05 13:55:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:55 --> Model Class Initialized
INFO - 2023-08-05 13:55:55 --> Model Class Initialized
INFO - 2023-08-05 13:55:55 --> Model Class Initialized
INFO - 2023-08-05 13:55:55 --> Model Class Initialized
DEBUG - 2023-08-05 13:55:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:55:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:55 --> Model Class Initialized
INFO - 2023-08-05 13:55:55 --> Model Class Initialized
INFO - 2023-08-05 13:55:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 13:55:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:55:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:55:55 --> Model Class Initialized
INFO - 2023-08-05 13:55:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:55:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:55:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:55:55 --> Final output sent to browser
DEBUG - 2023-08-05 13:55:55 --> Total execution time: 0.0788
ERROR - 2023-08-05 13:55:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:55:59 --> Config Class Initialized
INFO - 2023-08-05 13:55:59 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:55:59 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:55:59 --> Utf8 Class Initialized
INFO - 2023-08-05 13:55:59 --> URI Class Initialized
DEBUG - 2023-08-05 13:55:59 --> No URI present. Default controller set.
INFO - 2023-08-05 13:55:59 --> Router Class Initialized
INFO - 2023-08-05 13:55:59 --> Output Class Initialized
INFO - 2023-08-05 13:55:59 --> Security Class Initialized
DEBUG - 2023-08-05 13:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:55:59 --> Input Class Initialized
INFO - 2023-08-05 13:55:59 --> Language Class Initialized
INFO - 2023-08-05 13:55:59 --> Loader Class Initialized
INFO - 2023-08-05 13:55:59 --> Helper loaded: url_helper
INFO - 2023-08-05 13:55:59 --> Helper loaded: file_helper
INFO - 2023-08-05 13:55:59 --> Helper loaded: html_helper
INFO - 2023-08-05 13:55:59 --> Helper loaded: text_helper
INFO - 2023-08-05 13:55:59 --> Helper loaded: form_helper
INFO - 2023-08-05 13:55:59 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:55:59 --> Helper loaded: security_helper
INFO - 2023-08-05 13:55:59 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:55:59 --> Database Driver Class Initialized
INFO - 2023-08-05 13:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:55:59 --> Parser Class Initialized
INFO - 2023-08-05 13:55:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:55:59 --> Pagination Class Initialized
INFO - 2023-08-05 13:55:59 --> Form Validation Class Initialized
INFO - 2023-08-05 13:55:59 --> Controller Class Initialized
INFO - 2023-08-05 13:55:59 --> Model Class Initialized
DEBUG - 2023-08-05 13:55:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:59 --> Model Class Initialized
DEBUG - 2023-08-05 13:55:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:59 --> Model Class Initialized
INFO - 2023-08-05 13:55:59 --> Model Class Initialized
INFO - 2023-08-05 13:55:59 --> Model Class Initialized
INFO - 2023-08-05 13:55:59 --> Model Class Initialized
DEBUG - 2023-08-05 13:55:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:55:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:59 --> Model Class Initialized
INFO - 2023-08-05 13:55:59 --> Model Class Initialized
INFO - 2023-08-05 13:55:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 13:55:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:55:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:55:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:55:59 --> Model Class Initialized
INFO - 2023-08-05 13:55:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:55:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:55:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:55:59 --> Final output sent to browser
DEBUG - 2023-08-05 13:55:59 --> Total execution time: 0.0758
ERROR - 2023-08-05 13:56:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:56:02 --> Config Class Initialized
INFO - 2023-08-05 13:56:02 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:56:02 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:56:02 --> Utf8 Class Initialized
INFO - 2023-08-05 13:56:02 --> URI Class Initialized
INFO - 2023-08-05 13:56:02 --> Router Class Initialized
INFO - 2023-08-05 13:56:02 --> Output Class Initialized
INFO - 2023-08-05 13:56:02 --> Security Class Initialized
DEBUG - 2023-08-05 13:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:56:02 --> Input Class Initialized
INFO - 2023-08-05 13:56:02 --> Language Class Initialized
INFO - 2023-08-05 13:56:02 --> Loader Class Initialized
INFO - 2023-08-05 13:56:02 --> Helper loaded: url_helper
INFO - 2023-08-05 13:56:02 --> Helper loaded: file_helper
INFO - 2023-08-05 13:56:02 --> Helper loaded: html_helper
INFO - 2023-08-05 13:56:02 --> Helper loaded: text_helper
INFO - 2023-08-05 13:56:02 --> Helper loaded: form_helper
INFO - 2023-08-05 13:56:02 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:56:02 --> Helper loaded: security_helper
INFO - 2023-08-05 13:56:02 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:56:02 --> Database Driver Class Initialized
INFO - 2023-08-05 13:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:56:02 --> Parser Class Initialized
INFO - 2023-08-05 13:56:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:56:02 --> Pagination Class Initialized
INFO - 2023-08-05 13:56:02 --> Form Validation Class Initialized
INFO - 2023-08-05 13:56:02 --> Controller Class Initialized
INFO - 2023-08-05 13:56:02 --> Model Class Initialized
DEBUG - 2023-08-05 13:56:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:56:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:56:02 --> Model Class Initialized
DEBUG - 2023-08-05 13:56:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:56:02 --> Model Class Initialized
INFO - 2023-08-05 13:56:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 13:56:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:56:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:56:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:56:02 --> Model Class Initialized
INFO - 2023-08-05 13:56:02 --> Model Class Initialized
INFO - 2023-08-05 13:56:02 --> Model Class Initialized
INFO - 2023-08-05 13:56:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:56:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:56:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:56:02 --> Final output sent to browser
DEBUG - 2023-08-05 13:56:02 --> Total execution time: 0.0800
ERROR - 2023-08-05 13:56:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:56:05 --> Config Class Initialized
INFO - 2023-08-05 13:56:05 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:56:05 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:56:05 --> Utf8 Class Initialized
INFO - 2023-08-05 13:56:05 --> URI Class Initialized
INFO - 2023-08-05 13:56:05 --> Router Class Initialized
INFO - 2023-08-05 13:56:05 --> Output Class Initialized
INFO - 2023-08-05 13:56:05 --> Security Class Initialized
DEBUG - 2023-08-05 13:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:56:05 --> Input Class Initialized
INFO - 2023-08-05 13:56:05 --> Language Class Initialized
INFO - 2023-08-05 13:56:05 --> Loader Class Initialized
INFO - 2023-08-05 13:56:05 --> Helper loaded: url_helper
INFO - 2023-08-05 13:56:05 --> Helper loaded: file_helper
INFO - 2023-08-05 13:56:05 --> Helper loaded: html_helper
INFO - 2023-08-05 13:56:05 --> Helper loaded: text_helper
INFO - 2023-08-05 13:56:05 --> Helper loaded: form_helper
INFO - 2023-08-05 13:56:05 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:56:05 --> Helper loaded: security_helper
INFO - 2023-08-05 13:56:05 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:56:05 --> Database Driver Class Initialized
INFO - 2023-08-05 13:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:56:05 --> Parser Class Initialized
INFO - 2023-08-05 13:56:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:56:05 --> Pagination Class Initialized
INFO - 2023-08-05 13:56:05 --> Form Validation Class Initialized
INFO - 2023-08-05 13:56:05 --> Controller Class Initialized
INFO - 2023-08-05 13:56:05 --> Model Class Initialized
DEBUG - 2023-08-05 13:56:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:56:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:56:05 --> Model Class Initialized
DEBUG - 2023-08-05 13:56:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:56:05 --> Model Class Initialized
INFO - 2023-08-05 13:56:05 --> Final output sent to browser
DEBUG - 2023-08-05 13:56:05 --> Total execution time: 0.0410
ERROR - 2023-08-05 13:56:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:56:08 --> Config Class Initialized
INFO - 2023-08-05 13:56:08 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:56:08 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:56:08 --> Utf8 Class Initialized
INFO - 2023-08-05 13:56:08 --> URI Class Initialized
INFO - 2023-08-05 13:56:08 --> Router Class Initialized
INFO - 2023-08-05 13:56:08 --> Output Class Initialized
INFO - 2023-08-05 13:56:08 --> Security Class Initialized
DEBUG - 2023-08-05 13:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:56:08 --> Input Class Initialized
INFO - 2023-08-05 13:56:08 --> Language Class Initialized
INFO - 2023-08-05 13:56:08 --> Loader Class Initialized
INFO - 2023-08-05 13:56:08 --> Helper loaded: url_helper
INFO - 2023-08-05 13:56:08 --> Helper loaded: file_helper
INFO - 2023-08-05 13:56:08 --> Helper loaded: html_helper
INFO - 2023-08-05 13:56:08 --> Helper loaded: text_helper
INFO - 2023-08-05 13:56:08 --> Helper loaded: form_helper
INFO - 2023-08-05 13:56:08 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:56:08 --> Helper loaded: security_helper
INFO - 2023-08-05 13:56:08 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:56:08 --> Database Driver Class Initialized
INFO - 2023-08-05 13:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:56:08 --> Parser Class Initialized
INFO - 2023-08-05 13:56:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:56:08 --> Pagination Class Initialized
INFO - 2023-08-05 13:56:08 --> Form Validation Class Initialized
INFO - 2023-08-05 13:56:08 --> Controller Class Initialized
INFO - 2023-08-05 13:56:08 --> Model Class Initialized
DEBUG - 2023-08-05 13:56:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:56:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:56:08 --> Model Class Initialized
DEBUG - 2023-08-05 13:56:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:56:08 --> Model Class Initialized
DEBUG - 2023-08-05 13:56:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:56:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-05 13:56:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:56:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:56:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:56:08 --> Model Class Initialized
INFO - 2023-08-05 13:56:08 --> Model Class Initialized
INFO - 2023-08-05 13:56:08 --> Model Class Initialized
INFO - 2023-08-05 13:56:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:56:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:56:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:56:08 --> Final output sent to browser
DEBUG - 2023-08-05 13:56:08 --> Total execution time: 0.0869
ERROR - 2023-08-05 13:56:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:56:20 --> Config Class Initialized
INFO - 2023-08-05 13:56:20 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:56:20 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:56:20 --> Utf8 Class Initialized
INFO - 2023-08-05 13:56:20 --> URI Class Initialized
INFO - 2023-08-05 13:56:20 --> Router Class Initialized
INFO - 2023-08-05 13:56:20 --> Output Class Initialized
INFO - 2023-08-05 13:56:20 --> Security Class Initialized
DEBUG - 2023-08-05 13:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:56:20 --> Input Class Initialized
INFO - 2023-08-05 13:56:20 --> Language Class Initialized
INFO - 2023-08-05 13:56:20 --> Loader Class Initialized
INFO - 2023-08-05 13:56:20 --> Helper loaded: url_helper
INFO - 2023-08-05 13:56:20 --> Helper loaded: file_helper
INFO - 2023-08-05 13:56:20 --> Helper loaded: html_helper
INFO - 2023-08-05 13:56:20 --> Helper loaded: text_helper
INFO - 2023-08-05 13:56:20 --> Helper loaded: form_helper
INFO - 2023-08-05 13:56:20 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:56:20 --> Helper loaded: security_helper
INFO - 2023-08-05 13:56:20 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:56:20 --> Database Driver Class Initialized
INFO - 2023-08-05 13:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:56:20 --> Parser Class Initialized
INFO - 2023-08-05 13:56:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:56:20 --> Pagination Class Initialized
INFO - 2023-08-05 13:56:20 --> Form Validation Class Initialized
INFO - 2023-08-05 13:56:20 --> Controller Class Initialized
INFO - 2023-08-05 13:56:20 --> Model Class Initialized
DEBUG - 2023-08-05 13:56:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:56:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:56:20 --> Model Class Initialized
DEBUG - 2023-08-05 13:56:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:56:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-08-05 13:56:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:56:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:56:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:56:20 --> Model Class Initialized
INFO - 2023-08-05 13:56:20 --> Model Class Initialized
INFO - 2023-08-05 13:56:20 --> Model Class Initialized
INFO - 2023-08-05 13:56:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:56:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:56:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:56:20 --> Final output sent to browser
DEBUG - 2023-08-05 13:56:20 --> Total execution time: 0.0696
ERROR - 2023-08-05 13:56:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:56:42 --> Config Class Initialized
INFO - 2023-08-05 13:56:42 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:56:42 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:56:42 --> Utf8 Class Initialized
INFO - 2023-08-05 13:56:42 --> URI Class Initialized
DEBUG - 2023-08-05 13:56:42 --> No URI present. Default controller set.
INFO - 2023-08-05 13:56:42 --> Router Class Initialized
INFO - 2023-08-05 13:56:42 --> Output Class Initialized
INFO - 2023-08-05 13:56:42 --> Security Class Initialized
DEBUG - 2023-08-05 13:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:56:42 --> Input Class Initialized
INFO - 2023-08-05 13:56:42 --> Language Class Initialized
INFO - 2023-08-05 13:56:42 --> Loader Class Initialized
INFO - 2023-08-05 13:56:42 --> Helper loaded: url_helper
INFO - 2023-08-05 13:56:42 --> Helper loaded: file_helper
INFO - 2023-08-05 13:56:42 --> Helper loaded: html_helper
INFO - 2023-08-05 13:56:42 --> Helper loaded: text_helper
INFO - 2023-08-05 13:56:42 --> Helper loaded: form_helper
INFO - 2023-08-05 13:56:42 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:56:42 --> Helper loaded: security_helper
INFO - 2023-08-05 13:56:42 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:56:42 --> Database Driver Class Initialized
INFO - 2023-08-05 13:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:56:42 --> Parser Class Initialized
INFO - 2023-08-05 13:56:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:56:42 --> Pagination Class Initialized
INFO - 2023-08-05 13:56:42 --> Form Validation Class Initialized
INFO - 2023-08-05 13:56:42 --> Controller Class Initialized
INFO - 2023-08-05 13:56:42 --> Model Class Initialized
DEBUG - 2023-08-05 13:56:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:56:42 --> Model Class Initialized
DEBUG - 2023-08-05 13:56:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:56:42 --> Model Class Initialized
INFO - 2023-08-05 13:56:42 --> Model Class Initialized
INFO - 2023-08-05 13:56:42 --> Model Class Initialized
INFO - 2023-08-05 13:56:42 --> Model Class Initialized
DEBUG - 2023-08-05 13:56:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:56:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:56:42 --> Model Class Initialized
INFO - 2023-08-05 13:56:42 --> Model Class Initialized
INFO - 2023-08-05 13:56:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 13:56:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:56:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:56:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:56:42 --> Model Class Initialized
INFO - 2023-08-05 13:56:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:56:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:56:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:56:42 --> Final output sent to browser
DEBUG - 2023-08-05 13:56:42 --> Total execution time: 0.0764
ERROR - 2023-08-05 13:56:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:56:44 --> Config Class Initialized
INFO - 2023-08-05 13:56:44 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:56:44 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:56:44 --> Utf8 Class Initialized
INFO - 2023-08-05 13:56:44 --> URI Class Initialized
DEBUG - 2023-08-05 13:56:44 --> No URI present. Default controller set.
INFO - 2023-08-05 13:56:44 --> Router Class Initialized
INFO - 2023-08-05 13:56:44 --> Output Class Initialized
INFO - 2023-08-05 13:56:44 --> Security Class Initialized
DEBUG - 2023-08-05 13:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:56:44 --> Input Class Initialized
INFO - 2023-08-05 13:56:44 --> Language Class Initialized
INFO - 2023-08-05 13:56:44 --> Loader Class Initialized
INFO - 2023-08-05 13:56:44 --> Helper loaded: url_helper
INFO - 2023-08-05 13:56:44 --> Helper loaded: file_helper
INFO - 2023-08-05 13:56:44 --> Helper loaded: html_helper
INFO - 2023-08-05 13:56:44 --> Helper loaded: text_helper
INFO - 2023-08-05 13:56:44 --> Helper loaded: form_helper
INFO - 2023-08-05 13:56:44 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:56:44 --> Helper loaded: security_helper
INFO - 2023-08-05 13:56:44 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:56:44 --> Database Driver Class Initialized
INFO - 2023-08-05 13:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:56:44 --> Parser Class Initialized
INFO - 2023-08-05 13:56:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:56:44 --> Pagination Class Initialized
INFO - 2023-08-05 13:56:44 --> Form Validation Class Initialized
INFO - 2023-08-05 13:56:44 --> Controller Class Initialized
INFO - 2023-08-05 13:56:44 --> Model Class Initialized
DEBUG - 2023-08-05 13:56:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:56:44 --> Model Class Initialized
DEBUG - 2023-08-05 13:56:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:56:44 --> Model Class Initialized
INFO - 2023-08-05 13:56:44 --> Model Class Initialized
INFO - 2023-08-05 13:56:44 --> Model Class Initialized
INFO - 2023-08-05 13:56:44 --> Model Class Initialized
DEBUG - 2023-08-05 13:56:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:56:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:56:44 --> Model Class Initialized
INFO - 2023-08-05 13:56:44 --> Model Class Initialized
INFO - 2023-08-05 13:56:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 13:56:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:56:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:56:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:56:44 --> Model Class Initialized
INFO - 2023-08-05 13:56:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:56:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:56:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:56:44 --> Final output sent to browser
DEBUG - 2023-08-05 13:56:44 --> Total execution time: 0.0856
ERROR - 2023-08-05 13:56:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:56:55 --> Config Class Initialized
INFO - 2023-08-05 13:56:55 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:56:55 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:56:55 --> Utf8 Class Initialized
INFO - 2023-08-05 13:56:55 --> URI Class Initialized
INFO - 2023-08-05 13:56:55 --> Router Class Initialized
INFO - 2023-08-05 13:56:55 --> Output Class Initialized
INFO - 2023-08-05 13:56:55 --> Security Class Initialized
DEBUG - 2023-08-05 13:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:56:55 --> Input Class Initialized
INFO - 2023-08-05 13:56:55 --> Language Class Initialized
INFO - 2023-08-05 13:56:55 --> Loader Class Initialized
INFO - 2023-08-05 13:56:55 --> Helper loaded: url_helper
INFO - 2023-08-05 13:56:55 --> Helper loaded: file_helper
INFO - 2023-08-05 13:56:55 --> Helper loaded: html_helper
INFO - 2023-08-05 13:56:55 --> Helper loaded: text_helper
INFO - 2023-08-05 13:56:55 --> Helper loaded: form_helper
INFO - 2023-08-05 13:56:55 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:56:55 --> Helper loaded: security_helper
INFO - 2023-08-05 13:56:55 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:56:55 --> Database Driver Class Initialized
INFO - 2023-08-05 13:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:56:55 --> Parser Class Initialized
INFO - 2023-08-05 13:56:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:56:55 --> Pagination Class Initialized
INFO - 2023-08-05 13:56:55 --> Form Validation Class Initialized
INFO - 2023-08-05 13:56:55 --> Controller Class Initialized
INFO - 2023-08-05 13:56:55 --> Model Class Initialized
DEBUG - 2023-08-05 13:56:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:56:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:56:55 --> Model Class Initialized
DEBUG - 2023-08-05 13:56:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:56:55 --> Model Class Initialized
INFO - 2023-08-05 13:56:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 13:56:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:56:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:56:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:56:55 --> Model Class Initialized
INFO - 2023-08-05 13:56:55 --> Model Class Initialized
INFO - 2023-08-05 13:56:55 --> Model Class Initialized
INFO - 2023-08-05 13:56:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:56:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:56:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:56:56 --> Final output sent to browser
DEBUG - 2023-08-05 13:56:56 --> Total execution time: 0.0725
ERROR - 2023-08-05 13:56:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:56:56 --> Config Class Initialized
INFO - 2023-08-05 13:56:56 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:56:56 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:56:56 --> Utf8 Class Initialized
INFO - 2023-08-05 13:56:56 --> URI Class Initialized
INFO - 2023-08-05 13:56:56 --> Router Class Initialized
INFO - 2023-08-05 13:56:56 --> Output Class Initialized
INFO - 2023-08-05 13:56:56 --> Security Class Initialized
DEBUG - 2023-08-05 13:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:56:56 --> Input Class Initialized
INFO - 2023-08-05 13:56:56 --> Language Class Initialized
INFO - 2023-08-05 13:56:56 --> Loader Class Initialized
INFO - 2023-08-05 13:56:56 --> Helper loaded: url_helper
INFO - 2023-08-05 13:56:56 --> Helper loaded: file_helper
INFO - 2023-08-05 13:56:56 --> Helper loaded: html_helper
INFO - 2023-08-05 13:56:56 --> Helper loaded: text_helper
INFO - 2023-08-05 13:56:56 --> Helper loaded: form_helper
INFO - 2023-08-05 13:56:56 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:56:56 --> Helper loaded: security_helper
INFO - 2023-08-05 13:56:56 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:56:56 --> Database Driver Class Initialized
INFO - 2023-08-05 13:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:56:56 --> Parser Class Initialized
INFO - 2023-08-05 13:56:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:56:56 --> Pagination Class Initialized
INFO - 2023-08-05 13:56:56 --> Form Validation Class Initialized
INFO - 2023-08-05 13:56:56 --> Controller Class Initialized
INFO - 2023-08-05 13:56:56 --> Model Class Initialized
DEBUG - 2023-08-05 13:56:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:56:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:56:56 --> Model Class Initialized
DEBUG - 2023-08-05 13:56:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:56:56 --> Model Class Initialized
INFO - 2023-08-05 13:56:56 --> Final output sent to browser
DEBUG - 2023-08-05 13:56:56 --> Total execution time: 0.0403
ERROR - 2023-08-05 13:57:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:57:05 --> Config Class Initialized
INFO - 2023-08-05 13:57:05 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:57:05 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:57:05 --> Utf8 Class Initialized
INFO - 2023-08-05 13:57:05 --> URI Class Initialized
INFO - 2023-08-05 13:57:05 --> Router Class Initialized
INFO - 2023-08-05 13:57:05 --> Output Class Initialized
INFO - 2023-08-05 13:57:05 --> Security Class Initialized
DEBUG - 2023-08-05 13:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:57:05 --> Input Class Initialized
INFO - 2023-08-05 13:57:05 --> Language Class Initialized
INFO - 2023-08-05 13:57:05 --> Loader Class Initialized
INFO - 2023-08-05 13:57:05 --> Helper loaded: url_helper
INFO - 2023-08-05 13:57:05 --> Helper loaded: file_helper
INFO - 2023-08-05 13:57:05 --> Helper loaded: html_helper
INFO - 2023-08-05 13:57:05 --> Helper loaded: text_helper
INFO - 2023-08-05 13:57:05 --> Helper loaded: form_helper
INFO - 2023-08-05 13:57:05 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:57:05 --> Helper loaded: security_helper
INFO - 2023-08-05 13:57:05 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:57:05 --> Database Driver Class Initialized
INFO - 2023-08-05 13:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:57:05 --> Parser Class Initialized
INFO - 2023-08-05 13:57:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:57:05 --> Pagination Class Initialized
INFO - 2023-08-05 13:57:05 --> Form Validation Class Initialized
INFO - 2023-08-05 13:57:05 --> Controller Class Initialized
INFO - 2023-08-05 13:57:05 --> Model Class Initialized
DEBUG - 2023-08-05 13:57:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:57:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:57:05 --> Model Class Initialized
DEBUG - 2023-08-05 13:57:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:57:05 --> Model Class Initialized
DEBUG - 2023-08-05 13:57:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:57:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-05 13:57:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:57:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:57:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:57:05 --> Model Class Initialized
INFO - 2023-08-05 13:57:05 --> Model Class Initialized
INFO - 2023-08-05 13:57:05 --> Model Class Initialized
INFO - 2023-08-05 13:57:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:57:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:57:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:57:05 --> Final output sent to browser
DEBUG - 2023-08-05 13:57:05 --> Total execution time: 0.0785
ERROR - 2023-08-05 13:57:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:57:52 --> Config Class Initialized
INFO - 2023-08-05 13:57:52 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:57:52 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:57:52 --> Utf8 Class Initialized
INFO - 2023-08-05 13:57:52 --> URI Class Initialized
DEBUG - 2023-08-05 13:57:52 --> No URI present. Default controller set.
INFO - 2023-08-05 13:57:52 --> Router Class Initialized
INFO - 2023-08-05 13:57:52 --> Output Class Initialized
INFO - 2023-08-05 13:57:52 --> Security Class Initialized
DEBUG - 2023-08-05 13:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:57:52 --> Input Class Initialized
INFO - 2023-08-05 13:57:52 --> Language Class Initialized
INFO - 2023-08-05 13:57:52 --> Loader Class Initialized
INFO - 2023-08-05 13:57:52 --> Helper loaded: url_helper
INFO - 2023-08-05 13:57:52 --> Helper loaded: file_helper
INFO - 2023-08-05 13:57:52 --> Helper loaded: html_helper
INFO - 2023-08-05 13:57:52 --> Helper loaded: text_helper
INFO - 2023-08-05 13:57:52 --> Helper loaded: form_helper
INFO - 2023-08-05 13:57:52 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:57:52 --> Helper loaded: security_helper
INFO - 2023-08-05 13:57:52 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:57:52 --> Database Driver Class Initialized
INFO - 2023-08-05 13:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:57:52 --> Parser Class Initialized
INFO - 2023-08-05 13:57:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:57:52 --> Pagination Class Initialized
INFO - 2023-08-05 13:57:52 --> Form Validation Class Initialized
INFO - 2023-08-05 13:57:52 --> Controller Class Initialized
INFO - 2023-08-05 13:57:52 --> Model Class Initialized
DEBUG - 2023-08-05 13:57:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:57:52 --> Model Class Initialized
DEBUG - 2023-08-05 13:57:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:57:52 --> Model Class Initialized
INFO - 2023-08-05 13:57:52 --> Model Class Initialized
INFO - 2023-08-05 13:57:52 --> Model Class Initialized
INFO - 2023-08-05 13:57:52 --> Model Class Initialized
DEBUG - 2023-08-05 13:57:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:57:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:57:52 --> Model Class Initialized
INFO - 2023-08-05 13:57:52 --> Model Class Initialized
INFO - 2023-08-05 13:57:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 13:57:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:57:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:57:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:57:52 --> Model Class Initialized
INFO - 2023-08-05 13:57:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:57:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:57:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:57:52 --> Final output sent to browser
DEBUG - 2023-08-05 13:57:52 --> Total execution time: 0.0964
ERROR - 2023-08-05 13:58:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:58:08 --> Config Class Initialized
INFO - 2023-08-05 13:58:08 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:58:08 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:58:08 --> Utf8 Class Initialized
INFO - 2023-08-05 13:58:08 --> URI Class Initialized
DEBUG - 2023-08-05 13:58:08 --> No URI present. Default controller set.
INFO - 2023-08-05 13:58:08 --> Router Class Initialized
INFO - 2023-08-05 13:58:08 --> Output Class Initialized
INFO - 2023-08-05 13:58:08 --> Security Class Initialized
DEBUG - 2023-08-05 13:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:58:08 --> Input Class Initialized
INFO - 2023-08-05 13:58:08 --> Language Class Initialized
INFO - 2023-08-05 13:58:08 --> Loader Class Initialized
INFO - 2023-08-05 13:58:08 --> Helper loaded: url_helper
INFO - 2023-08-05 13:58:08 --> Helper loaded: file_helper
INFO - 2023-08-05 13:58:08 --> Helper loaded: html_helper
INFO - 2023-08-05 13:58:08 --> Helper loaded: text_helper
INFO - 2023-08-05 13:58:08 --> Helper loaded: form_helper
INFO - 2023-08-05 13:58:08 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:58:08 --> Helper loaded: security_helper
INFO - 2023-08-05 13:58:08 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:58:08 --> Database Driver Class Initialized
INFO - 2023-08-05 13:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:58:08 --> Parser Class Initialized
INFO - 2023-08-05 13:58:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:58:08 --> Pagination Class Initialized
INFO - 2023-08-05 13:58:08 --> Form Validation Class Initialized
INFO - 2023-08-05 13:58:08 --> Controller Class Initialized
INFO - 2023-08-05 13:58:08 --> Model Class Initialized
DEBUG - 2023-08-05 13:58:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:58:08 --> Model Class Initialized
DEBUG - 2023-08-05 13:58:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:58:08 --> Model Class Initialized
INFO - 2023-08-05 13:58:08 --> Model Class Initialized
INFO - 2023-08-05 13:58:08 --> Model Class Initialized
INFO - 2023-08-05 13:58:08 --> Model Class Initialized
DEBUG - 2023-08-05 13:58:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:58:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:58:08 --> Model Class Initialized
INFO - 2023-08-05 13:58:08 --> Model Class Initialized
INFO - 2023-08-05 13:58:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 13:58:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:58:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:58:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:58:08 --> Model Class Initialized
INFO - 2023-08-05 13:58:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:58:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:58:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:58:08 --> Final output sent to browser
DEBUG - 2023-08-05 13:58:08 --> Total execution time: 0.2077
ERROR - 2023-08-05 13:58:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:58:15 --> Config Class Initialized
INFO - 2023-08-05 13:58:15 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:58:15 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:58:15 --> Utf8 Class Initialized
INFO - 2023-08-05 13:58:15 --> URI Class Initialized
INFO - 2023-08-05 13:58:15 --> Router Class Initialized
INFO - 2023-08-05 13:58:15 --> Output Class Initialized
INFO - 2023-08-05 13:58:15 --> Security Class Initialized
DEBUG - 2023-08-05 13:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:58:15 --> Input Class Initialized
INFO - 2023-08-05 13:58:15 --> Language Class Initialized
INFO - 2023-08-05 13:58:15 --> Loader Class Initialized
INFO - 2023-08-05 13:58:15 --> Helper loaded: url_helper
INFO - 2023-08-05 13:58:15 --> Helper loaded: file_helper
INFO - 2023-08-05 13:58:15 --> Helper loaded: html_helper
INFO - 2023-08-05 13:58:15 --> Helper loaded: text_helper
INFO - 2023-08-05 13:58:15 --> Helper loaded: form_helper
INFO - 2023-08-05 13:58:15 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:58:15 --> Helper loaded: security_helper
INFO - 2023-08-05 13:58:15 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:58:15 --> Database Driver Class Initialized
INFO - 2023-08-05 13:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:58:15 --> Parser Class Initialized
INFO - 2023-08-05 13:58:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:58:15 --> Pagination Class Initialized
INFO - 2023-08-05 13:58:15 --> Form Validation Class Initialized
INFO - 2023-08-05 13:58:15 --> Controller Class Initialized
INFO - 2023-08-05 13:58:15 --> Model Class Initialized
DEBUG - 2023-08-05 13:58:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:58:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:58:15 --> Model Class Initialized
DEBUG - 2023-08-05 13:58:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:58:15 --> Model Class Initialized
INFO - 2023-08-05 13:58:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-08-05 13:58:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:58:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:58:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:58:15 --> Model Class Initialized
INFO - 2023-08-05 13:58:15 --> Model Class Initialized
INFO - 2023-08-05 13:58:15 --> Model Class Initialized
INFO - 2023-08-05 13:58:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:58:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:58:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:58:15 --> Final output sent to browser
DEBUG - 2023-08-05 13:58:15 --> Total execution time: 0.1617
ERROR - 2023-08-05 13:58:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:58:16 --> Config Class Initialized
INFO - 2023-08-05 13:58:16 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:58:16 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:58:16 --> Utf8 Class Initialized
INFO - 2023-08-05 13:58:16 --> URI Class Initialized
INFO - 2023-08-05 13:58:16 --> Router Class Initialized
INFO - 2023-08-05 13:58:16 --> Output Class Initialized
INFO - 2023-08-05 13:58:16 --> Security Class Initialized
DEBUG - 2023-08-05 13:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:58:16 --> Input Class Initialized
INFO - 2023-08-05 13:58:16 --> Language Class Initialized
INFO - 2023-08-05 13:58:16 --> Loader Class Initialized
INFO - 2023-08-05 13:58:16 --> Helper loaded: url_helper
INFO - 2023-08-05 13:58:16 --> Helper loaded: file_helper
INFO - 2023-08-05 13:58:16 --> Helper loaded: html_helper
INFO - 2023-08-05 13:58:16 --> Helper loaded: text_helper
INFO - 2023-08-05 13:58:16 --> Helper loaded: form_helper
INFO - 2023-08-05 13:58:16 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:58:16 --> Helper loaded: security_helper
INFO - 2023-08-05 13:58:16 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:58:16 --> Database Driver Class Initialized
INFO - 2023-08-05 13:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:58:16 --> Parser Class Initialized
INFO - 2023-08-05 13:58:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:58:16 --> Pagination Class Initialized
INFO - 2023-08-05 13:58:16 --> Form Validation Class Initialized
INFO - 2023-08-05 13:58:16 --> Controller Class Initialized
INFO - 2023-08-05 13:58:16 --> Model Class Initialized
DEBUG - 2023-08-05 13:58:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:58:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:58:16 --> Model Class Initialized
DEBUG - 2023-08-05 13:58:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:58:16 --> Model Class Initialized
INFO - 2023-08-05 13:58:16 --> Final output sent to browser
DEBUG - 2023-08-05 13:58:16 --> Total execution time: 0.0557
ERROR - 2023-08-05 13:58:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:58:22 --> Config Class Initialized
INFO - 2023-08-05 13:58:22 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:58:22 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:58:22 --> Utf8 Class Initialized
INFO - 2023-08-05 13:58:22 --> URI Class Initialized
INFO - 2023-08-05 13:58:22 --> Router Class Initialized
INFO - 2023-08-05 13:58:22 --> Output Class Initialized
INFO - 2023-08-05 13:58:22 --> Security Class Initialized
DEBUG - 2023-08-05 13:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:58:22 --> Input Class Initialized
INFO - 2023-08-05 13:58:22 --> Language Class Initialized
INFO - 2023-08-05 13:58:22 --> Loader Class Initialized
INFO - 2023-08-05 13:58:22 --> Helper loaded: url_helper
INFO - 2023-08-05 13:58:22 --> Helper loaded: file_helper
INFO - 2023-08-05 13:58:22 --> Helper loaded: html_helper
INFO - 2023-08-05 13:58:22 --> Helper loaded: text_helper
INFO - 2023-08-05 13:58:22 --> Helper loaded: form_helper
INFO - 2023-08-05 13:58:22 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:58:22 --> Helper loaded: security_helper
INFO - 2023-08-05 13:58:22 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:58:22 --> Database Driver Class Initialized
INFO - 2023-08-05 13:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:58:22 --> Parser Class Initialized
INFO - 2023-08-05 13:58:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:58:22 --> Pagination Class Initialized
INFO - 2023-08-05 13:58:22 --> Form Validation Class Initialized
INFO - 2023-08-05 13:58:22 --> Controller Class Initialized
DEBUG - 2023-08-05 13:58:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:58:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:58:22 --> Model Class Initialized
DEBUG - 2023-08-05 13:58:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:58:22 --> Model Class Initialized
DEBUG - 2023-08-05 13:58:22 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:58:22 --> Model Class Initialized
INFO - 2023-08-05 13:58:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-08-05 13:58:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:58:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:58:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:58:22 --> Model Class Initialized
INFO - 2023-08-05 13:58:22 --> Model Class Initialized
INFO - 2023-08-05 13:58:22 --> Model Class Initialized
INFO - 2023-08-05 13:58:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:58:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:58:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:58:22 --> Final output sent to browser
DEBUG - 2023-08-05 13:58:22 --> Total execution time: 0.1505
ERROR - 2023-08-05 13:58:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:58:22 --> Config Class Initialized
INFO - 2023-08-05 13:58:22 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:58:22 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:58:22 --> Utf8 Class Initialized
INFO - 2023-08-05 13:58:22 --> URI Class Initialized
INFO - 2023-08-05 13:58:22 --> Router Class Initialized
INFO - 2023-08-05 13:58:22 --> Output Class Initialized
INFO - 2023-08-05 13:58:22 --> Security Class Initialized
DEBUG - 2023-08-05 13:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:58:22 --> Input Class Initialized
INFO - 2023-08-05 13:58:22 --> Language Class Initialized
INFO - 2023-08-05 13:58:22 --> Loader Class Initialized
INFO - 2023-08-05 13:58:22 --> Helper loaded: url_helper
INFO - 2023-08-05 13:58:22 --> Helper loaded: file_helper
INFO - 2023-08-05 13:58:22 --> Helper loaded: html_helper
INFO - 2023-08-05 13:58:22 --> Helper loaded: text_helper
INFO - 2023-08-05 13:58:22 --> Helper loaded: form_helper
INFO - 2023-08-05 13:58:22 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:58:22 --> Helper loaded: security_helper
INFO - 2023-08-05 13:58:22 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:58:22 --> Database Driver Class Initialized
INFO - 2023-08-05 13:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:58:22 --> Parser Class Initialized
INFO - 2023-08-05 13:58:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:58:22 --> Pagination Class Initialized
INFO - 2023-08-05 13:58:22 --> Form Validation Class Initialized
INFO - 2023-08-05 13:58:22 --> Controller Class Initialized
DEBUG - 2023-08-05 13:58:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:58:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:58:22 --> Model Class Initialized
DEBUG - 2023-08-05 13:58:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:58:22 --> Model Class Initialized
INFO - 2023-08-05 13:58:22 --> Final output sent to browser
DEBUG - 2023-08-05 13:58:22 --> Total execution time: 0.0341
ERROR - 2023-08-05 13:58:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:58:27 --> Config Class Initialized
INFO - 2023-08-05 13:58:27 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:58:27 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:58:27 --> Utf8 Class Initialized
INFO - 2023-08-05 13:58:27 --> URI Class Initialized
INFO - 2023-08-05 13:58:27 --> Router Class Initialized
INFO - 2023-08-05 13:58:27 --> Output Class Initialized
INFO - 2023-08-05 13:58:27 --> Security Class Initialized
DEBUG - 2023-08-05 13:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:58:27 --> Input Class Initialized
INFO - 2023-08-05 13:58:27 --> Language Class Initialized
INFO - 2023-08-05 13:58:27 --> Loader Class Initialized
INFO - 2023-08-05 13:58:27 --> Helper loaded: url_helper
INFO - 2023-08-05 13:58:27 --> Helper loaded: file_helper
INFO - 2023-08-05 13:58:27 --> Helper loaded: html_helper
INFO - 2023-08-05 13:58:27 --> Helper loaded: text_helper
INFO - 2023-08-05 13:58:27 --> Helper loaded: form_helper
INFO - 2023-08-05 13:58:27 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:58:27 --> Helper loaded: security_helper
INFO - 2023-08-05 13:58:27 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:58:27 --> Database Driver Class Initialized
INFO - 2023-08-05 13:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:58:27 --> Parser Class Initialized
INFO - 2023-08-05 13:58:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:58:27 --> Pagination Class Initialized
INFO - 2023-08-05 13:58:27 --> Form Validation Class Initialized
INFO - 2023-08-05 13:58:27 --> Controller Class Initialized
DEBUG - 2023-08-05 13:58:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:58:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:58:27 --> Model Class Initialized
DEBUG - 2023-08-05 13:58:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:58:27 --> Model Class Initialized
INFO - 2023-08-05 13:58:27 --> Final output sent to browser
DEBUG - 2023-08-05 13:58:27 --> Total execution time: 0.1248
ERROR - 2023-08-05 13:58:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:58:56 --> Config Class Initialized
INFO - 2023-08-05 13:58:56 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:58:56 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:58:56 --> Utf8 Class Initialized
INFO - 2023-08-05 13:58:56 --> URI Class Initialized
INFO - 2023-08-05 13:58:56 --> Router Class Initialized
INFO - 2023-08-05 13:58:56 --> Output Class Initialized
INFO - 2023-08-05 13:58:56 --> Security Class Initialized
DEBUG - 2023-08-05 13:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:58:56 --> Input Class Initialized
INFO - 2023-08-05 13:58:56 --> Language Class Initialized
INFO - 2023-08-05 13:58:56 --> Loader Class Initialized
INFO - 2023-08-05 13:58:56 --> Helper loaded: url_helper
INFO - 2023-08-05 13:58:56 --> Helper loaded: file_helper
INFO - 2023-08-05 13:58:56 --> Helper loaded: html_helper
INFO - 2023-08-05 13:58:56 --> Helper loaded: text_helper
INFO - 2023-08-05 13:58:56 --> Helper loaded: form_helper
INFO - 2023-08-05 13:58:56 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:58:56 --> Helper loaded: security_helper
INFO - 2023-08-05 13:58:56 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:58:56 --> Database Driver Class Initialized
INFO - 2023-08-05 13:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:58:56 --> Parser Class Initialized
INFO - 2023-08-05 13:58:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:58:56 --> Pagination Class Initialized
INFO - 2023-08-05 13:58:56 --> Form Validation Class Initialized
INFO - 2023-08-05 13:58:56 --> Controller Class Initialized
DEBUG - 2023-08-05 13:58:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:58:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:58:56 --> Model Class Initialized
DEBUG - 2023-08-05 13:58:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:58:56 --> Model Class Initialized
INFO - 2023-08-05 13:58:56 --> Final output sent to browser
DEBUG - 2023-08-05 13:58:56 --> Total execution time: 0.0384
ERROR - 2023-08-05 13:59:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:59:33 --> Config Class Initialized
INFO - 2023-08-05 13:59:33 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:59:33 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:59:33 --> Utf8 Class Initialized
INFO - 2023-08-05 13:59:33 --> URI Class Initialized
INFO - 2023-08-05 13:59:33 --> Router Class Initialized
INFO - 2023-08-05 13:59:33 --> Output Class Initialized
INFO - 2023-08-05 13:59:33 --> Security Class Initialized
DEBUG - 2023-08-05 13:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:59:33 --> Input Class Initialized
INFO - 2023-08-05 13:59:33 --> Language Class Initialized
INFO - 2023-08-05 13:59:33 --> Loader Class Initialized
INFO - 2023-08-05 13:59:33 --> Helper loaded: url_helper
INFO - 2023-08-05 13:59:33 --> Helper loaded: file_helper
INFO - 2023-08-05 13:59:33 --> Helper loaded: html_helper
INFO - 2023-08-05 13:59:33 --> Helper loaded: text_helper
INFO - 2023-08-05 13:59:33 --> Helper loaded: form_helper
INFO - 2023-08-05 13:59:33 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:59:33 --> Helper loaded: security_helper
INFO - 2023-08-05 13:59:33 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:59:33 --> Database Driver Class Initialized
INFO - 2023-08-05 13:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:59:33 --> Parser Class Initialized
INFO - 2023-08-05 13:59:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:59:33 --> Pagination Class Initialized
INFO - 2023-08-05 13:59:33 --> Form Validation Class Initialized
INFO - 2023-08-05 13:59:33 --> Controller Class Initialized
DEBUG - 2023-08-05 13:59:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:59:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:59:33 --> Model Class Initialized
DEBUG - 2023-08-05 13:59:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:59:33 --> Model Class Initialized
DEBUG - 2023-08-05 13:59:33 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:59:33 --> Model Class Initialized
INFO - 2023-08-05 13:59:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-08-05 13:59:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:59:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:59:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:59:33 --> Model Class Initialized
INFO - 2023-08-05 13:59:33 --> Model Class Initialized
INFO - 2023-08-05 13:59:33 --> Model Class Initialized
INFO - 2023-08-05 13:59:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:59:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:59:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:59:33 --> Final output sent to browser
DEBUG - 2023-08-05 13:59:33 --> Total execution time: 0.0741
ERROR - 2023-08-05 13:59:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:59:34 --> Config Class Initialized
INFO - 2023-08-05 13:59:34 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:59:34 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:59:34 --> Utf8 Class Initialized
INFO - 2023-08-05 13:59:34 --> URI Class Initialized
INFO - 2023-08-05 13:59:34 --> Router Class Initialized
INFO - 2023-08-05 13:59:34 --> Output Class Initialized
INFO - 2023-08-05 13:59:34 --> Security Class Initialized
DEBUG - 2023-08-05 13:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:59:34 --> Input Class Initialized
INFO - 2023-08-05 13:59:34 --> Language Class Initialized
INFO - 2023-08-05 13:59:34 --> Loader Class Initialized
INFO - 2023-08-05 13:59:34 --> Helper loaded: url_helper
INFO - 2023-08-05 13:59:34 --> Helper loaded: file_helper
INFO - 2023-08-05 13:59:34 --> Helper loaded: html_helper
INFO - 2023-08-05 13:59:34 --> Helper loaded: text_helper
INFO - 2023-08-05 13:59:34 --> Helper loaded: form_helper
INFO - 2023-08-05 13:59:34 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:59:34 --> Helper loaded: security_helper
INFO - 2023-08-05 13:59:34 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:59:34 --> Database Driver Class Initialized
INFO - 2023-08-05 13:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:59:34 --> Parser Class Initialized
INFO - 2023-08-05 13:59:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:59:34 --> Pagination Class Initialized
INFO - 2023-08-05 13:59:34 --> Form Validation Class Initialized
INFO - 2023-08-05 13:59:34 --> Controller Class Initialized
DEBUG - 2023-08-05 13:59:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:59:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:59:34 --> Model Class Initialized
DEBUG - 2023-08-05 13:59:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:59:34 --> Model Class Initialized
INFO - 2023-08-05 13:59:34 --> Final output sent to browser
DEBUG - 2023-08-05 13:59:34 --> Total execution time: 0.0200
ERROR - 2023-08-05 13:59:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:59:54 --> Config Class Initialized
INFO - 2023-08-05 13:59:54 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:59:54 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:59:54 --> Utf8 Class Initialized
INFO - 2023-08-05 13:59:54 --> URI Class Initialized
INFO - 2023-08-05 13:59:54 --> Router Class Initialized
INFO - 2023-08-05 13:59:54 --> Output Class Initialized
INFO - 2023-08-05 13:59:54 --> Security Class Initialized
DEBUG - 2023-08-05 13:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:59:54 --> Input Class Initialized
INFO - 2023-08-05 13:59:54 --> Language Class Initialized
INFO - 2023-08-05 13:59:54 --> Loader Class Initialized
INFO - 2023-08-05 13:59:54 --> Helper loaded: url_helper
INFO - 2023-08-05 13:59:54 --> Helper loaded: file_helper
INFO - 2023-08-05 13:59:54 --> Helper loaded: html_helper
INFO - 2023-08-05 13:59:54 --> Helper loaded: text_helper
INFO - 2023-08-05 13:59:54 --> Helper loaded: form_helper
INFO - 2023-08-05 13:59:54 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:59:54 --> Helper loaded: security_helper
INFO - 2023-08-05 13:59:54 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:59:54 --> Database Driver Class Initialized
INFO - 2023-08-05 13:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:59:54 --> Parser Class Initialized
INFO - 2023-08-05 13:59:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:59:54 --> Pagination Class Initialized
INFO - 2023-08-05 13:59:54 --> Form Validation Class Initialized
INFO - 2023-08-05 13:59:54 --> Controller Class Initialized
INFO - 2023-08-05 13:59:54 --> Model Class Initialized
DEBUG - 2023-08-05 13:59:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:59:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:59:54 --> Model Class Initialized
DEBUG - 2023-08-05 13:59:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:59:54 --> Model Class Initialized
INFO - 2023-08-05 13:59:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 13:59:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:59:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 13:59:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 13:59:54 --> Model Class Initialized
INFO - 2023-08-05 13:59:54 --> Model Class Initialized
INFO - 2023-08-05 13:59:54 --> Model Class Initialized
INFO - 2023-08-05 13:59:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 13:59:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 13:59:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 13:59:54 --> Final output sent to browser
DEBUG - 2023-08-05 13:59:54 --> Total execution time: 0.0778
ERROR - 2023-08-05 13:59:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 13:59:54 --> Config Class Initialized
INFO - 2023-08-05 13:59:54 --> Hooks Class Initialized
DEBUG - 2023-08-05 13:59:54 --> UTF-8 Support Enabled
INFO - 2023-08-05 13:59:54 --> Utf8 Class Initialized
INFO - 2023-08-05 13:59:54 --> URI Class Initialized
INFO - 2023-08-05 13:59:54 --> Router Class Initialized
INFO - 2023-08-05 13:59:54 --> Output Class Initialized
INFO - 2023-08-05 13:59:54 --> Security Class Initialized
DEBUG - 2023-08-05 13:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 13:59:54 --> Input Class Initialized
INFO - 2023-08-05 13:59:54 --> Language Class Initialized
INFO - 2023-08-05 13:59:54 --> Loader Class Initialized
INFO - 2023-08-05 13:59:54 --> Helper loaded: url_helper
INFO - 2023-08-05 13:59:54 --> Helper loaded: file_helper
INFO - 2023-08-05 13:59:54 --> Helper loaded: html_helper
INFO - 2023-08-05 13:59:54 --> Helper loaded: text_helper
INFO - 2023-08-05 13:59:54 --> Helper loaded: form_helper
INFO - 2023-08-05 13:59:54 --> Helper loaded: lang_helper
INFO - 2023-08-05 13:59:54 --> Helper loaded: security_helper
INFO - 2023-08-05 13:59:54 --> Helper loaded: cookie_helper
INFO - 2023-08-05 13:59:54 --> Database Driver Class Initialized
INFO - 2023-08-05 13:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 13:59:54 --> Parser Class Initialized
INFO - 2023-08-05 13:59:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 13:59:54 --> Pagination Class Initialized
INFO - 2023-08-05 13:59:54 --> Form Validation Class Initialized
INFO - 2023-08-05 13:59:54 --> Controller Class Initialized
INFO - 2023-08-05 13:59:54 --> Model Class Initialized
DEBUG - 2023-08-05 13:59:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 13:59:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:59:54 --> Model Class Initialized
DEBUG - 2023-08-05 13:59:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 13:59:54 --> Model Class Initialized
INFO - 2023-08-05 13:59:54 --> Final output sent to browser
DEBUG - 2023-08-05 13:59:54 --> Total execution time: 0.0392
ERROR - 2023-08-05 14:00:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:00:04 --> Config Class Initialized
INFO - 2023-08-05 14:00:04 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:00:04 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:00:04 --> Utf8 Class Initialized
INFO - 2023-08-05 14:00:04 --> URI Class Initialized
INFO - 2023-08-05 14:00:04 --> Router Class Initialized
INFO - 2023-08-05 14:00:04 --> Output Class Initialized
INFO - 2023-08-05 14:00:04 --> Security Class Initialized
DEBUG - 2023-08-05 14:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:00:04 --> Input Class Initialized
INFO - 2023-08-05 14:00:04 --> Language Class Initialized
INFO - 2023-08-05 14:00:04 --> Loader Class Initialized
INFO - 2023-08-05 14:00:04 --> Helper loaded: url_helper
INFO - 2023-08-05 14:00:04 --> Helper loaded: file_helper
INFO - 2023-08-05 14:00:04 --> Helper loaded: html_helper
INFO - 2023-08-05 14:00:04 --> Helper loaded: text_helper
INFO - 2023-08-05 14:00:04 --> Helper loaded: form_helper
INFO - 2023-08-05 14:00:04 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:00:04 --> Helper loaded: security_helper
INFO - 2023-08-05 14:00:04 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:00:04 --> Database Driver Class Initialized
INFO - 2023-08-05 14:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:00:04 --> Parser Class Initialized
INFO - 2023-08-05 14:00:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:00:04 --> Pagination Class Initialized
INFO - 2023-08-05 14:00:04 --> Form Validation Class Initialized
INFO - 2023-08-05 14:00:04 --> Controller Class Initialized
INFO - 2023-08-05 14:00:04 --> Model Class Initialized
DEBUG - 2023-08-05 14:00:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:00:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:00:04 --> Model Class Initialized
DEBUG - 2023-08-05 14:00:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:00:04 --> Model Class Initialized
INFO - 2023-08-05 14:00:04 --> Final output sent to browser
DEBUG - 2023-08-05 14:00:04 --> Total execution time: 0.0950
ERROR - 2023-08-05 14:00:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:00:19 --> Config Class Initialized
INFO - 2023-08-05 14:00:19 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:00:19 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:00:19 --> Utf8 Class Initialized
INFO - 2023-08-05 14:00:19 --> URI Class Initialized
INFO - 2023-08-05 14:00:19 --> Router Class Initialized
INFO - 2023-08-05 14:00:19 --> Output Class Initialized
INFO - 2023-08-05 14:00:19 --> Security Class Initialized
DEBUG - 2023-08-05 14:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:00:19 --> Input Class Initialized
INFO - 2023-08-05 14:00:19 --> Language Class Initialized
INFO - 2023-08-05 14:00:19 --> Loader Class Initialized
INFO - 2023-08-05 14:00:19 --> Helper loaded: url_helper
INFO - 2023-08-05 14:00:19 --> Helper loaded: file_helper
INFO - 2023-08-05 14:00:19 --> Helper loaded: html_helper
INFO - 2023-08-05 14:00:19 --> Helper loaded: text_helper
INFO - 2023-08-05 14:00:19 --> Helper loaded: form_helper
INFO - 2023-08-05 14:00:19 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:00:19 --> Helper loaded: security_helper
INFO - 2023-08-05 14:00:19 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:00:19 --> Database Driver Class Initialized
INFO - 2023-08-05 14:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:00:19 --> Parser Class Initialized
INFO - 2023-08-05 14:00:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:00:19 --> Pagination Class Initialized
INFO - 2023-08-05 14:00:19 --> Form Validation Class Initialized
INFO - 2023-08-05 14:00:19 --> Controller Class Initialized
DEBUG - 2023-08-05 14:00:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:00:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:00:19 --> Model Class Initialized
DEBUG - 2023-08-05 14:00:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:00:19 --> Model Class Initialized
DEBUG - 2023-08-05 14:00:19 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:00:19 --> Model Class Initialized
INFO - 2023-08-05 14:00:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-08-05 14:00:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:00:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:00:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:00:19 --> Model Class Initialized
INFO - 2023-08-05 14:00:19 --> Model Class Initialized
INFO - 2023-08-05 14:00:19 --> Model Class Initialized
INFO - 2023-08-05 14:00:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 14:00:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 14:00:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:00:19 --> Final output sent to browser
DEBUG - 2023-08-05 14:00:19 --> Total execution time: 0.0752
ERROR - 2023-08-05 14:00:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:00:19 --> Config Class Initialized
INFO - 2023-08-05 14:00:19 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:00:19 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:00:19 --> Utf8 Class Initialized
INFO - 2023-08-05 14:00:19 --> URI Class Initialized
INFO - 2023-08-05 14:00:19 --> Router Class Initialized
INFO - 2023-08-05 14:00:19 --> Output Class Initialized
INFO - 2023-08-05 14:00:19 --> Security Class Initialized
DEBUG - 2023-08-05 14:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:00:19 --> Input Class Initialized
INFO - 2023-08-05 14:00:19 --> Language Class Initialized
INFO - 2023-08-05 14:00:19 --> Loader Class Initialized
INFO - 2023-08-05 14:00:19 --> Helper loaded: url_helper
INFO - 2023-08-05 14:00:19 --> Helper loaded: file_helper
INFO - 2023-08-05 14:00:19 --> Helper loaded: html_helper
INFO - 2023-08-05 14:00:19 --> Helper loaded: text_helper
INFO - 2023-08-05 14:00:19 --> Helper loaded: form_helper
INFO - 2023-08-05 14:00:19 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:00:19 --> Helper loaded: security_helper
INFO - 2023-08-05 14:00:19 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:00:19 --> Database Driver Class Initialized
INFO - 2023-08-05 14:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:00:19 --> Parser Class Initialized
INFO - 2023-08-05 14:00:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:00:19 --> Pagination Class Initialized
INFO - 2023-08-05 14:00:19 --> Form Validation Class Initialized
INFO - 2023-08-05 14:00:19 --> Controller Class Initialized
DEBUG - 2023-08-05 14:00:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:00:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:00:19 --> Model Class Initialized
DEBUG - 2023-08-05 14:00:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:00:19 --> Model Class Initialized
INFO - 2023-08-05 14:00:19 --> Final output sent to browser
DEBUG - 2023-08-05 14:00:19 --> Total execution time: 0.0224
ERROR - 2023-08-05 14:00:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:00:27 --> Config Class Initialized
INFO - 2023-08-05 14:00:27 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:00:27 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:00:27 --> Utf8 Class Initialized
INFO - 2023-08-05 14:00:27 --> URI Class Initialized
INFO - 2023-08-05 14:00:27 --> Router Class Initialized
INFO - 2023-08-05 14:00:27 --> Output Class Initialized
INFO - 2023-08-05 14:00:27 --> Security Class Initialized
DEBUG - 2023-08-05 14:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:00:27 --> Input Class Initialized
INFO - 2023-08-05 14:00:27 --> Language Class Initialized
INFO - 2023-08-05 14:00:27 --> Loader Class Initialized
INFO - 2023-08-05 14:00:27 --> Helper loaded: url_helper
INFO - 2023-08-05 14:00:27 --> Helper loaded: file_helper
INFO - 2023-08-05 14:00:27 --> Helper loaded: html_helper
INFO - 2023-08-05 14:00:27 --> Helper loaded: text_helper
INFO - 2023-08-05 14:00:27 --> Helper loaded: form_helper
INFO - 2023-08-05 14:00:27 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:00:27 --> Helper loaded: security_helper
INFO - 2023-08-05 14:00:27 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:00:27 --> Database Driver Class Initialized
INFO - 2023-08-05 14:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:00:27 --> Parser Class Initialized
INFO - 2023-08-05 14:00:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:00:27 --> Pagination Class Initialized
INFO - 2023-08-05 14:00:27 --> Form Validation Class Initialized
INFO - 2023-08-05 14:00:27 --> Controller Class Initialized
DEBUG - 2023-08-05 14:00:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:00:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:00:27 --> Model Class Initialized
DEBUG - 2023-08-05 14:00:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:00:27 --> Model Class Initialized
INFO - 2023-08-05 14:00:27 --> Final output sent to browser
DEBUG - 2023-08-05 14:00:27 --> Total execution time: 0.0254
ERROR - 2023-08-05 14:01:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:01:01 --> Config Class Initialized
INFO - 2023-08-05 14:01:01 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:01:01 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:01:01 --> Utf8 Class Initialized
INFO - 2023-08-05 14:01:01 --> URI Class Initialized
INFO - 2023-08-05 14:01:01 --> Router Class Initialized
INFO - 2023-08-05 14:01:01 --> Output Class Initialized
INFO - 2023-08-05 14:01:01 --> Security Class Initialized
DEBUG - 2023-08-05 14:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:01:01 --> Input Class Initialized
INFO - 2023-08-05 14:01:01 --> Language Class Initialized
INFO - 2023-08-05 14:01:01 --> Loader Class Initialized
INFO - 2023-08-05 14:01:01 --> Helper loaded: url_helper
INFO - 2023-08-05 14:01:01 --> Helper loaded: file_helper
INFO - 2023-08-05 14:01:01 --> Helper loaded: html_helper
INFO - 2023-08-05 14:01:01 --> Helper loaded: text_helper
INFO - 2023-08-05 14:01:01 --> Helper loaded: form_helper
INFO - 2023-08-05 14:01:01 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:01:01 --> Helper loaded: security_helper
INFO - 2023-08-05 14:01:01 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:01:01 --> Database Driver Class Initialized
INFO - 2023-08-05 14:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:01:01 --> Parser Class Initialized
INFO - 2023-08-05 14:01:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:01:01 --> Pagination Class Initialized
INFO - 2023-08-05 14:01:01 --> Form Validation Class Initialized
INFO - 2023-08-05 14:01:01 --> Controller Class Initialized
DEBUG - 2023-08-05 14:01:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:01:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:01:01 --> Model Class Initialized
DEBUG - 2023-08-05 14:01:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:01:01 --> Model Class Initialized
DEBUG - 2023-08-05 14:01:01 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:01:01 --> Model Class Initialized
INFO - 2023-08-05 14:01:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-08-05 14:01:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:01:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:01:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:01:01 --> Model Class Initialized
INFO - 2023-08-05 14:01:01 --> Model Class Initialized
INFO - 2023-08-05 14:01:01 --> Model Class Initialized
INFO - 2023-08-05 14:01:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 14:01:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 14:01:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:01:01 --> Final output sent to browser
DEBUG - 2023-08-05 14:01:01 --> Total execution time: 0.1354
ERROR - 2023-08-05 14:01:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:01:02 --> Config Class Initialized
INFO - 2023-08-05 14:01:02 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:01:02 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:01:02 --> Utf8 Class Initialized
INFO - 2023-08-05 14:01:02 --> URI Class Initialized
INFO - 2023-08-05 14:01:02 --> Router Class Initialized
INFO - 2023-08-05 14:01:02 --> Output Class Initialized
INFO - 2023-08-05 14:01:02 --> Security Class Initialized
DEBUG - 2023-08-05 14:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:01:02 --> Input Class Initialized
INFO - 2023-08-05 14:01:02 --> Language Class Initialized
INFO - 2023-08-05 14:01:02 --> Loader Class Initialized
INFO - 2023-08-05 14:01:02 --> Helper loaded: url_helper
INFO - 2023-08-05 14:01:02 --> Helper loaded: file_helper
INFO - 2023-08-05 14:01:02 --> Helper loaded: html_helper
INFO - 2023-08-05 14:01:02 --> Helper loaded: text_helper
INFO - 2023-08-05 14:01:02 --> Helper loaded: form_helper
INFO - 2023-08-05 14:01:02 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:01:02 --> Helper loaded: security_helper
INFO - 2023-08-05 14:01:02 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:01:02 --> Database Driver Class Initialized
INFO - 2023-08-05 14:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:01:02 --> Parser Class Initialized
INFO - 2023-08-05 14:01:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:01:02 --> Pagination Class Initialized
INFO - 2023-08-05 14:01:02 --> Form Validation Class Initialized
INFO - 2023-08-05 14:01:02 --> Controller Class Initialized
DEBUG - 2023-08-05 14:01:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:01:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:01:02 --> Model Class Initialized
DEBUG - 2023-08-05 14:01:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:01:02 --> Model Class Initialized
INFO - 2023-08-05 14:01:02 --> Final output sent to browser
DEBUG - 2023-08-05 14:01:02 --> Total execution time: 0.0298
ERROR - 2023-08-05 14:01:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:01:05 --> Config Class Initialized
INFO - 2023-08-05 14:01:05 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:01:05 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:01:05 --> Utf8 Class Initialized
INFO - 2023-08-05 14:01:05 --> URI Class Initialized
INFO - 2023-08-05 14:01:05 --> Router Class Initialized
INFO - 2023-08-05 14:01:05 --> Output Class Initialized
INFO - 2023-08-05 14:01:05 --> Security Class Initialized
DEBUG - 2023-08-05 14:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:01:05 --> Input Class Initialized
INFO - 2023-08-05 14:01:05 --> Language Class Initialized
INFO - 2023-08-05 14:01:05 --> Loader Class Initialized
INFO - 2023-08-05 14:01:05 --> Helper loaded: url_helper
INFO - 2023-08-05 14:01:05 --> Helper loaded: file_helper
INFO - 2023-08-05 14:01:05 --> Helper loaded: html_helper
INFO - 2023-08-05 14:01:05 --> Helper loaded: text_helper
INFO - 2023-08-05 14:01:05 --> Helper loaded: form_helper
INFO - 2023-08-05 14:01:05 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:01:05 --> Helper loaded: security_helper
INFO - 2023-08-05 14:01:05 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:01:05 --> Database Driver Class Initialized
INFO - 2023-08-05 14:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:01:05 --> Parser Class Initialized
INFO - 2023-08-05 14:01:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:01:05 --> Pagination Class Initialized
INFO - 2023-08-05 14:01:05 --> Form Validation Class Initialized
INFO - 2023-08-05 14:01:05 --> Controller Class Initialized
DEBUG - 2023-08-05 14:01:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:01:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:01:05 --> Model Class Initialized
DEBUG - 2023-08-05 14:01:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:01:05 --> Model Class Initialized
INFO - 2023-08-05 14:01:05 --> Final output sent to browser
DEBUG - 2023-08-05 14:01:05 --> Total execution time: 0.1310
ERROR - 2023-08-05 14:01:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:01:17 --> Config Class Initialized
INFO - 2023-08-05 14:01:17 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:01:17 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:01:17 --> Utf8 Class Initialized
INFO - 2023-08-05 14:01:17 --> URI Class Initialized
DEBUG - 2023-08-05 14:01:17 --> No URI present. Default controller set.
INFO - 2023-08-05 14:01:17 --> Router Class Initialized
INFO - 2023-08-05 14:01:17 --> Output Class Initialized
INFO - 2023-08-05 14:01:17 --> Security Class Initialized
DEBUG - 2023-08-05 14:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:01:17 --> Input Class Initialized
INFO - 2023-08-05 14:01:17 --> Language Class Initialized
INFO - 2023-08-05 14:01:17 --> Loader Class Initialized
INFO - 2023-08-05 14:01:17 --> Helper loaded: url_helper
INFO - 2023-08-05 14:01:17 --> Helper loaded: file_helper
INFO - 2023-08-05 14:01:17 --> Helper loaded: html_helper
INFO - 2023-08-05 14:01:17 --> Helper loaded: text_helper
INFO - 2023-08-05 14:01:17 --> Helper loaded: form_helper
INFO - 2023-08-05 14:01:17 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:01:17 --> Helper loaded: security_helper
INFO - 2023-08-05 14:01:17 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:01:17 --> Database Driver Class Initialized
INFO - 2023-08-05 14:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:01:17 --> Parser Class Initialized
INFO - 2023-08-05 14:01:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:01:17 --> Pagination Class Initialized
INFO - 2023-08-05 14:01:17 --> Form Validation Class Initialized
INFO - 2023-08-05 14:01:17 --> Controller Class Initialized
INFO - 2023-08-05 14:01:17 --> Model Class Initialized
DEBUG - 2023-08-05 14:01:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-05 14:01:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:01:21 --> Config Class Initialized
INFO - 2023-08-05 14:01:21 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:01:21 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:01:21 --> Utf8 Class Initialized
INFO - 2023-08-05 14:01:21 --> URI Class Initialized
INFO - 2023-08-05 14:01:21 --> Router Class Initialized
INFO - 2023-08-05 14:01:21 --> Output Class Initialized
INFO - 2023-08-05 14:01:21 --> Security Class Initialized
DEBUG - 2023-08-05 14:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:01:21 --> Input Class Initialized
INFO - 2023-08-05 14:01:21 --> Language Class Initialized
INFO - 2023-08-05 14:01:21 --> Loader Class Initialized
INFO - 2023-08-05 14:01:21 --> Helper loaded: url_helper
INFO - 2023-08-05 14:01:21 --> Helper loaded: file_helper
INFO - 2023-08-05 14:01:21 --> Helper loaded: html_helper
INFO - 2023-08-05 14:01:21 --> Helper loaded: text_helper
INFO - 2023-08-05 14:01:21 --> Helper loaded: form_helper
INFO - 2023-08-05 14:01:21 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:01:21 --> Helper loaded: security_helper
INFO - 2023-08-05 14:01:21 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:01:21 --> Database Driver Class Initialized
INFO - 2023-08-05 14:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:01:21 --> Parser Class Initialized
INFO - 2023-08-05 14:01:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:01:21 --> Pagination Class Initialized
INFO - 2023-08-05 14:01:21 --> Form Validation Class Initialized
INFO - 2023-08-05 14:01:21 --> Controller Class Initialized
DEBUG - 2023-08-05 14:01:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:01:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:01:21 --> Model Class Initialized
DEBUG - 2023-08-05 14:01:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:01:21 --> Model Class Initialized
INFO - 2023-08-05 14:01:21 --> Final output sent to browser
DEBUG - 2023-08-05 14:01:21 --> Total execution time: 0.0176
ERROR - 2023-08-05 14:01:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:01:23 --> Config Class Initialized
INFO - 2023-08-05 14:01:23 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:01:23 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:01:23 --> Utf8 Class Initialized
INFO - 2023-08-05 14:01:23 --> URI Class Initialized
INFO - 2023-08-05 14:01:23 --> Router Class Initialized
INFO - 2023-08-05 14:01:23 --> Output Class Initialized
INFO - 2023-08-05 14:01:23 --> Security Class Initialized
DEBUG - 2023-08-05 14:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:01:23 --> Input Class Initialized
INFO - 2023-08-05 14:01:23 --> Language Class Initialized
INFO - 2023-08-05 14:01:23 --> Loader Class Initialized
INFO - 2023-08-05 14:01:23 --> Helper loaded: url_helper
INFO - 2023-08-05 14:01:23 --> Helper loaded: file_helper
INFO - 2023-08-05 14:01:23 --> Helper loaded: html_helper
INFO - 2023-08-05 14:01:23 --> Helper loaded: text_helper
INFO - 2023-08-05 14:01:23 --> Helper loaded: form_helper
INFO - 2023-08-05 14:01:23 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:01:23 --> Helper loaded: security_helper
INFO - 2023-08-05 14:01:23 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:01:23 --> Database Driver Class Initialized
INFO - 2023-08-05 14:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:01:23 --> Parser Class Initialized
INFO - 2023-08-05 14:01:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:01:23 --> Pagination Class Initialized
INFO - 2023-08-05 14:01:23 --> Form Validation Class Initialized
INFO - 2023-08-05 14:01:23 --> Controller Class Initialized
DEBUG - 2023-08-05 14:01:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:01:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:01:23 --> Model Class Initialized
DEBUG - 2023-08-05 14:01:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:01:23 --> Model Class Initialized
DEBUG - 2023-08-05 14:01:23 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:01:23 --> Model Class Initialized
INFO - 2023-08-05 14:01:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-08-05 14:01:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:01:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:01:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:01:23 --> Model Class Initialized
INFO - 2023-08-05 14:01:23 --> Model Class Initialized
INFO - 2023-08-05 14:01:23 --> Model Class Initialized
INFO - 2023-08-05 14:01:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 14:01:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 14:01:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:01:23 --> Final output sent to browser
DEBUG - 2023-08-05 14:01:23 --> Total execution time: 0.1486
ERROR - 2023-08-05 14:01:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:01:23 --> Config Class Initialized
INFO - 2023-08-05 14:01:23 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:01:23 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:01:23 --> Utf8 Class Initialized
INFO - 2023-08-05 14:01:23 --> URI Class Initialized
INFO - 2023-08-05 14:01:23 --> Router Class Initialized
INFO - 2023-08-05 14:01:23 --> Output Class Initialized
INFO - 2023-08-05 14:01:23 --> Security Class Initialized
DEBUG - 2023-08-05 14:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:01:23 --> Input Class Initialized
INFO - 2023-08-05 14:01:23 --> Language Class Initialized
INFO - 2023-08-05 14:01:23 --> Loader Class Initialized
INFO - 2023-08-05 14:01:23 --> Helper loaded: url_helper
INFO - 2023-08-05 14:01:23 --> Helper loaded: file_helper
INFO - 2023-08-05 14:01:23 --> Helper loaded: html_helper
INFO - 2023-08-05 14:01:23 --> Helper loaded: text_helper
INFO - 2023-08-05 14:01:23 --> Helper loaded: form_helper
INFO - 2023-08-05 14:01:23 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:01:23 --> Helper loaded: security_helper
INFO - 2023-08-05 14:01:23 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:01:23 --> Database Driver Class Initialized
INFO - 2023-08-05 14:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:01:23 --> Parser Class Initialized
INFO - 2023-08-05 14:01:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:01:23 --> Pagination Class Initialized
INFO - 2023-08-05 14:01:23 --> Form Validation Class Initialized
INFO - 2023-08-05 14:01:23 --> Controller Class Initialized
DEBUG - 2023-08-05 14:01:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:01:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:01:23 --> Model Class Initialized
DEBUG - 2023-08-05 14:01:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:01:23 --> Model Class Initialized
INFO - 2023-08-05 14:01:23 --> Final output sent to browser
DEBUG - 2023-08-05 14:01:23 --> Total execution time: 0.0331
ERROR - 2023-08-05 14:01:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:01:36 --> Config Class Initialized
INFO - 2023-08-05 14:01:36 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:01:36 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:01:36 --> Utf8 Class Initialized
INFO - 2023-08-05 14:01:36 --> URI Class Initialized
INFO - 2023-08-05 14:01:36 --> Router Class Initialized
INFO - 2023-08-05 14:01:36 --> Output Class Initialized
INFO - 2023-08-05 14:01:36 --> Security Class Initialized
DEBUG - 2023-08-05 14:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:01:36 --> Input Class Initialized
INFO - 2023-08-05 14:01:36 --> Language Class Initialized
INFO - 2023-08-05 14:01:36 --> Loader Class Initialized
INFO - 2023-08-05 14:01:36 --> Helper loaded: url_helper
INFO - 2023-08-05 14:01:36 --> Helper loaded: file_helper
INFO - 2023-08-05 14:01:36 --> Helper loaded: html_helper
INFO - 2023-08-05 14:01:36 --> Helper loaded: text_helper
INFO - 2023-08-05 14:01:36 --> Helper loaded: form_helper
INFO - 2023-08-05 14:01:36 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:01:36 --> Helper loaded: security_helper
INFO - 2023-08-05 14:01:36 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:01:36 --> Database Driver Class Initialized
INFO - 2023-08-05 14:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:01:36 --> Parser Class Initialized
INFO - 2023-08-05 14:01:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:01:36 --> Pagination Class Initialized
INFO - 2023-08-05 14:01:36 --> Form Validation Class Initialized
INFO - 2023-08-05 14:01:36 --> Controller Class Initialized
INFO - 2023-08-05 14:01:36 --> Model Class Initialized
DEBUG - 2023-08-05 14:01:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:01:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:01:36 --> Model Class Initialized
DEBUG - 2023-08-05 14:01:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:01:36 --> Model Class Initialized
INFO - 2023-08-05 14:01:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 14:01:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:01:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:01:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:01:36 --> Model Class Initialized
INFO - 2023-08-05 14:01:36 --> Model Class Initialized
INFO - 2023-08-05 14:01:36 --> Model Class Initialized
INFO - 2023-08-05 14:01:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 14:01:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 14:01:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:01:37 --> Final output sent to browser
DEBUG - 2023-08-05 14:01:37 --> Total execution time: 0.1561
ERROR - 2023-08-05 14:01:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:01:37 --> Config Class Initialized
INFO - 2023-08-05 14:01:37 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:01:37 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:01:37 --> Utf8 Class Initialized
INFO - 2023-08-05 14:01:37 --> URI Class Initialized
INFO - 2023-08-05 14:01:37 --> Router Class Initialized
INFO - 2023-08-05 14:01:37 --> Output Class Initialized
INFO - 2023-08-05 14:01:37 --> Security Class Initialized
DEBUG - 2023-08-05 14:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:01:37 --> Input Class Initialized
INFO - 2023-08-05 14:01:37 --> Language Class Initialized
INFO - 2023-08-05 14:01:37 --> Loader Class Initialized
INFO - 2023-08-05 14:01:37 --> Helper loaded: url_helper
INFO - 2023-08-05 14:01:37 --> Helper loaded: file_helper
INFO - 2023-08-05 14:01:37 --> Helper loaded: html_helper
INFO - 2023-08-05 14:01:37 --> Helper loaded: text_helper
INFO - 2023-08-05 14:01:37 --> Helper loaded: form_helper
INFO - 2023-08-05 14:01:37 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:01:37 --> Helper loaded: security_helper
INFO - 2023-08-05 14:01:37 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:01:37 --> Database Driver Class Initialized
INFO - 2023-08-05 14:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:01:37 --> Parser Class Initialized
INFO - 2023-08-05 14:01:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:01:37 --> Pagination Class Initialized
INFO - 2023-08-05 14:01:37 --> Form Validation Class Initialized
INFO - 2023-08-05 14:01:37 --> Controller Class Initialized
INFO - 2023-08-05 14:01:37 --> Model Class Initialized
DEBUG - 2023-08-05 14:01:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:01:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:01:37 --> Model Class Initialized
DEBUG - 2023-08-05 14:01:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:01:37 --> Model Class Initialized
INFO - 2023-08-05 14:01:37 --> Final output sent to browser
DEBUG - 2023-08-05 14:01:37 --> Total execution time: 0.0597
ERROR - 2023-08-05 14:01:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:01:41 --> Config Class Initialized
INFO - 2023-08-05 14:01:41 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:01:41 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:01:41 --> Utf8 Class Initialized
INFO - 2023-08-05 14:01:41 --> URI Class Initialized
INFO - 2023-08-05 14:01:41 --> Router Class Initialized
INFO - 2023-08-05 14:01:41 --> Output Class Initialized
INFO - 2023-08-05 14:01:41 --> Security Class Initialized
DEBUG - 2023-08-05 14:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:01:41 --> Input Class Initialized
INFO - 2023-08-05 14:01:41 --> Language Class Initialized
INFO - 2023-08-05 14:01:41 --> Loader Class Initialized
INFO - 2023-08-05 14:01:41 --> Helper loaded: url_helper
INFO - 2023-08-05 14:01:41 --> Helper loaded: file_helper
INFO - 2023-08-05 14:01:41 --> Helper loaded: html_helper
INFO - 2023-08-05 14:01:41 --> Helper loaded: text_helper
INFO - 2023-08-05 14:01:41 --> Helper loaded: form_helper
INFO - 2023-08-05 14:01:41 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:01:41 --> Helper loaded: security_helper
INFO - 2023-08-05 14:01:41 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:01:41 --> Database Driver Class Initialized
INFO - 2023-08-05 14:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:01:41 --> Parser Class Initialized
INFO - 2023-08-05 14:01:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:01:41 --> Pagination Class Initialized
INFO - 2023-08-05 14:01:41 --> Form Validation Class Initialized
INFO - 2023-08-05 14:01:41 --> Controller Class Initialized
INFO - 2023-08-05 14:01:41 --> Model Class Initialized
DEBUG - 2023-08-05 14:01:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:01:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:01:41 --> Model Class Initialized
DEBUG - 2023-08-05 14:01:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:01:41 --> Model Class Initialized
DEBUG - 2023-08-05 14:01:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:01:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-05 14:01:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:01:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:01:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:01:41 --> Model Class Initialized
INFO - 2023-08-05 14:01:41 --> Model Class Initialized
INFO - 2023-08-05 14:01:41 --> Model Class Initialized
INFO - 2023-08-05 14:01:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 14:01:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 14:01:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:01:41 --> Final output sent to browser
DEBUG - 2023-08-05 14:01:41 --> Total execution time: 0.1465
ERROR - 2023-08-05 14:04:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:04:02 --> Config Class Initialized
INFO - 2023-08-05 14:04:02 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:04:02 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:04:02 --> Utf8 Class Initialized
INFO - 2023-08-05 14:04:02 --> URI Class Initialized
INFO - 2023-08-05 14:04:02 --> Router Class Initialized
INFO - 2023-08-05 14:04:02 --> Output Class Initialized
INFO - 2023-08-05 14:04:02 --> Security Class Initialized
DEBUG - 2023-08-05 14:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:04:02 --> Input Class Initialized
INFO - 2023-08-05 14:04:02 --> Language Class Initialized
INFO - 2023-08-05 14:04:02 --> Loader Class Initialized
INFO - 2023-08-05 14:04:02 --> Helper loaded: url_helper
INFO - 2023-08-05 14:04:02 --> Helper loaded: file_helper
INFO - 2023-08-05 14:04:02 --> Helper loaded: html_helper
INFO - 2023-08-05 14:04:02 --> Helper loaded: text_helper
INFO - 2023-08-05 14:04:02 --> Helper loaded: form_helper
INFO - 2023-08-05 14:04:02 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:04:02 --> Helper loaded: security_helper
INFO - 2023-08-05 14:04:02 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:04:02 --> Database Driver Class Initialized
INFO - 2023-08-05 14:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:04:02 --> Parser Class Initialized
INFO - 2023-08-05 14:04:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:04:02 --> Pagination Class Initialized
INFO - 2023-08-05 14:04:02 --> Form Validation Class Initialized
INFO - 2023-08-05 14:04:02 --> Controller Class Initialized
INFO - 2023-08-05 14:04:02 --> Model Class Initialized
DEBUG - 2023-08-05 14:04:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:04:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:04:02 --> Model Class Initialized
DEBUG - 2023-08-05 14:04:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:04:02 --> Model Class Initialized
INFO - 2023-08-05 14:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 14:04:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:04:02 --> Model Class Initialized
INFO - 2023-08-05 14:04:02 --> Model Class Initialized
INFO - 2023-08-05 14:04:02 --> Model Class Initialized
INFO - 2023-08-05 14:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 14:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 14:04:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:04:02 --> Final output sent to browser
DEBUG - 2023-08-05 14:04:02 --> Total execution time: 0.1377
ERROR - 2023-08-05 14:04:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:04:03 --> Config Class Initialized
INFO - 2023-08-05 14:04:03 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:04:03 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:04:03 --> Utf8 Class Initialized
INFO - 2023-08-05 14:04:03 --> URI Class Initialized
INFO - 2023-08-05 14:04:03 --> Router Class Initialized
INFO - 2023-08-05 14:04:03 --> Output Class Initialized
INFO - 2023-08-05 14:04:03 --> Security Class Initialized
DEBUG - 2023-08-05 14:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:04:03 --> Input Class Initialized
INFO - 2023-08-05 14:04:03 --> Language Class Initialized
INFO - 2023-08-05 14:04:03 --> Loader Class Initialized
INFO - 2023-08-05 14:04:03 --> Helper loaded: url_helper
INFO - 2023-08-05 14:04:03 --> Helper loaded: file_helper
INFO - 2023-08-05 14:04:03 --> Helper loaded: html_helper
INFO - 2023-08-05 14:04:03 --> Helper loaded: text_helper
INFO - 2023-08-05 14:04:03 --> Helper loaded: form_helper
INFO - 2023-08-05 14:04:03 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:04:03 --> Helper loaded: security_helper
INFO - 2023-08-05 14:04:03 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:04:03 --> Database Driver Class Initialized
INFO - 2023-08-05 14:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:04:03 --> Parser Class Initialized
INFO - 2023-08-05 14:04:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:04:03 --> Pagination Class Initialized
INFO - 2023-08-05 14:04:03 --> Form Validation Class Initialized
INFO - 2023-08-05 14:04:03 --> Controller Class Initialized
INFO - 2023-08-05 14:04:03 --> Model Class Initialized
DEBUG - 2023-08-05 14:04:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:04:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:04:03 --> Model Class Initialized
DEBUG - 2023-08-05 14:04:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:04:03 --> Model Class Initialized
INFO - 2023-08-05 14:04:03 --> Final output sent to browser
DEBUG - 2023-08-05 14:04:03 --> Total execution time: 0.0528
ERROR - 2023-08-05 14:04:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:04:31 --> Config Class Initialized
INFO - 2023-08-05 14:04:31 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:04:31 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:04:31 --> Utf8 Class Initialized
INFO - 2023-08-05 14:04:31 --> URI Class Initialized
INFO - 2023-08-05 14:04:31 --> Router Class Initialized
INFO - 2023-08-05 14:04:31 --> Output Class Initialized
INFO - 2023-08-05 14:04:31 --> Security Class Initialized
DEBUG - 2023-08-05 14:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:04:31 --> Input Class Initialized
INFO - 2023-08-05 14:04:31 --> Language Class Initialized
INFO - 2023-08-05 14:04:31 --> Loader Class Initialized
INFO - 2023-08-05 14:04:31 --> Helper loaded: url_helper
INFO - 2023-08-05 14:04:31 --> Helper loaded: file_helper
INFO - 2023-08-05 14:04:31 --> Helper loaded: html_helper
INFO - 2023-08-05 14:04:31 --> Helper loaded: text_helper
INFO - 2023-08-05 14:04:31 --> Helper loaded: form_helper
INFO - 2023-08-05 14:04:31 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:04:31 --> Helper loaded: security_helper
INFO - 2023-08-05 14:04:31 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:04:31 --> Database Driver Class Initialized
INFO - 2023-08-05 14:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:04:31 --> Parser Class Initialized
INFO - 2023-08-05 14:04:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:04:31 --> Pagination Class Initialized
INFO - 2023-08-05 14:04:31 --> Form Validation Class Initialized
INFO - 2023-08-05 14:04:31 --> Controller Class Initialized
ERROR - 2023-08-05 14:04:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:04:32 --> Config Class Initialized
INFO - 2023-08-05 14:04:32 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:04:32 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:04:32 --> Utf8 Class Initialized
INFO - 2023-08-05 14:04:32 --> URI Class Initialized
INFO - 2023-08-05 14:04:32 --> Router Class Initialized
INFO - 2023-08-05 14:04:32 --> Output Class Initialized
INFO - 2023-08-05 14:04:32 --> Security Class Initialized
DEBUG - 2023-08-05 14:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:04:32 --> Input Class Initialized
INFO - 2023-08-05 14:04:32 --> Language Class Initialized
INFO - 2023-08-05 14:04:32 --> Loader Class Initialized
INFO - 2023-08-05 14:04:32 --> Helper loaded: url_helper
INFO - 2023-08-05 14:04:32 --> Helper loaded: file_helper
INFO - 2023-08-05 14:04:32 --> Helper loaded: html_helper
INFO - 2023-08-05 14:04:32 --> Helper loaded: text_helper
INFO - 2023-08-05 14:04:32 --> Helper loaded: form_helper
INFO - 2023-08-05 14:04:32 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:04:32 --> Helper loaded: security_helper
INFO - 2023-08-05 14:04:32 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:04:32 --> Database Driver Class Initialized
INFO - 2023-08-05 14:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:04:32 --> Parser Class Initialized
INFO - 2023-08-05 14:04:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:04:32 --> Pagination Class Initialized
INFO - 2023-08-05 14:04:32 --> Form Validation Class Initialized
INFO - 2023-08-05 14:04:32 --> Controller Class Initialized
ERROR - 2023-08-05 14:04:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:04:32 --> Config Class Initialized
INFO - 2023-08-05 14:04:32 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:04:32 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:04:32 --> Utf8 Class Initialized
INFO - 2023-08-05 14:04:32 --> URI Class Initialized
INFO - 2023-08-05 14:04:32 --> Router Class Initialized
INFO - 2023-08-05 14:04:32 --> Output Class Initialized
INFO - 2023-08-05 14:04:32 --> Security Class Initialized
DEBUG - 2023-08-05 14:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:04:32 --> Input Class Initialized
INFO - 2023-08-05 14:04:32 --> Language Class Initialized
INFO - 2023-08-05 14:04:32 --> Loader Class Initialized
INFO - 2023-08-05 14:04:32 --> Helper loaded: url_helper
INFO - 2023-08-05 14:04:32 --> Helper loaded: file_helper
INFO - 2023-08-05 14:04:32 --> Helper loaded: html_helper
INFO - 2023-08-05 14:04:32 --> Helper loaded: text_helper
INFO - 2023-08-05 14:04:32 --> Helper loaded: form_helper
INFO - 2023-08-05 14:04:32 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:04:32 --> Helper loaded: security_helper
INFO - 2023-08-05 14:04:32 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:04:32 --> Database Driver Class Initialized
INFO - 2023-08-05 14:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:04:32 --> Parser Class Initialized
INFO - 2023-08-05 14:04:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:04:32 --> Pagination Class Initialized
INFO - 2023-08-05 14:04:32 --> Form Validation Class Initialized
INFO - 2023-08-05 14:04:32 --> Controller Class Initialized
ERROR - 2023-08-05 14:04:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:04:32 --> Config Class Initialized
INFO - 2023-08-05 14:04:32 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:04:32 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:04:32 --> Utf8 Class Initialized
INFO - 2023-08-05 14:04:32 --> URI Class Initialized
INFO - 2023-08-05 14:04:32 --> Router Class Initialized
INFO - 2023-08-05 14:04:32 --> Output Class Initialized
INFO - 2023-08-05 14:04:32 --> Security Class Initialized
DEBUG - 2023-08-05 14:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:04:32 --> Input Class Initialized
INFO - 2023-08-05 14:04:32 --> Language Class Initialized
INFO - 2023-08-05 14:04:32 --> Loader Class Initialized
INFO - 2023-08-05 14:04:32 --> Helper loaded: url_helper
INFO - 2023-08-05 14:04:32 --> Helper loaded: file_helper
INFO - 2023-08-05 14:04:32 --> Helper loaded: html_helper
INFO - 2023-08-05 14:04:32 --> Helper loaded: text_helper
INFO - 2023-08-05 14:04:32 --> Helper loaded: form_helper
INFO - 2023-08-05 14:04:32 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:04:32 --> Helper loaded: security_helper
INFO - 2023-08-05 14:04:32 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:04:32 --> Database Driver Class Initialized
INFO - 2023-08-05 14:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:04:32 --> Parser Class Initialized
INFO - 2023-08-05 14:04:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:04:32 --> Pagination Class Initialized
INFO - 2023-08-05 14:04:32 --> Form Validation Class Initialized
INFO - 2023-08-05 14:04:32 --> Controller Class Initialized
ERROR - 2023-08-05 14:04:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:04:45 --> Config Class Initialized
INFO - 2023-08-05 14:04:45 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:04:45 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:04:45 --> Utf8 Class Initialized
INFO - 2023-08-05 14:04:45 --> URI Class Initialized
INFO - 2023-08-05 14:04:45 --> Router Class Initialized
INFO - 2023-08-05 14:04:45 --> Output Class Initialized
INFO - 2023-08-05 14:04:45 --> Security Class Initialized
DEBUG - 2023-08-05 14:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:04:45 --> Input Class Initialized
INFO - 2023-08-05 14:04:45 --> Language Class Initialized
INFO - 2023-08-05 14:04:45 --> Loader Class Initialized
INFO - 2023-08-05 14:04:45 --> Helper loaded: url_helper
INFO - 2023-08-05 14:04:45 --> Helper loaded: file_helper
INFO - 2023-08-05 14:04:45 --> Helper loaded: html_helper
INFO - 2023-08-05 14:04:45 --> Helper loaded: text_helper
INFO - 2023-08-05 14:04:45 --> Helper loaded: form_helper
INFO - 2023-08-05 14:04:45 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:04:45 --> Helper loaded: security_helper
INFO - 2023-08-05 14:04:45 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:04:45 --> Database Driver Class Initialized
INFO - 2023-08-05 14:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:04:45 --> Parser Class Initialized
INFO - 2023-08-05 14:04:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:04:45 --> Pagination Class Initialized
INFO - 2023-08-05 14:04:45 --> Form Validation Class Initialized
INFO - 2023-08-05 14:04:45 --> Controller Class Initialized
ERROR - 2023-08-05 14:06:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:06:14 --> Config Class Initialized
INFO - 2023-08-05 14:06:14 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:06:14 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:06:14 --> Utf8 Class Initialized
INFO - 2023-08-05 14:06:14 --> URI Class Initialized
INFO - 2023-08-05 14:06:14 --> Router Class Initialized
INFO - 2023-08-05 14:06:14 --> Output Class Initialized
INFO - 2023-08-05 14:06:14 --> Security Class Initialized
DEBUG - 2023-08-05 14:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:06:14 --> Input Class Initialized
INFO - 2023-08-05 14:06:14 --> Language Class Initialized
INFO - 2023-08-05 14:06:14 --> Loader Class Initialized
INFO - 2023-08-05 14:06:14 --> Helper loaded: url_helper
INFO - 2023-08-05 14:06:14 --> Helper loaded: file_helper
INFO - 2023-08-05 14:06:14 --> Helper loaded: html_helper
INFO - 2023-08-05 14:06:14 --> Helper loaded: text_helper
INFO - 2023-08-05 14:06:14 --> Helper loaded: form_helper
INFO - 2023-08-05 14:06:14 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:06:14 --> Helper loaded: security_helper
INFO - 2023-08-05 14:06:14 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:06:14 --> Database Driver Class Initialized
INFO - 2023-08-05 14:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:06:14 --> Parser Class Initialized
INFO - 2023-08-05 14:06:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:06:14 --> Pagination Class Initialized
INFO - 2023-08-05 14:06:14 --> Form Validation Class Initialized
INFO - 2023-08-05 14:06:14 --> Controller Class Initialized
INFO - 2023-08-05 14:06:14 --> Model Class Initialized
DEBUG - 2023-08-05 14:06:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:06:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:06:14 --> Model Class Initialized
DEBUG - 2023-08-05 14:06:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:06:14 --> Model Class Initialized
INFO - 2023-08-05 14:06:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 14:06:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:06:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:06:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:06:14 --> Model Class Initialized
INFO - 2023-08-05 14:06:14 --> Model Class Initialized
INFO - 2023-08-05 14:06:14 --> Model Class Initialized
INFO - 2023-08-05 14:06:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 14:06:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 14:06:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:06:14 --> Final output sent to browser
DEBUG - 2023-08-05 14:06:14 --> Total execution time: 0.0903
ERROR - 2023-08-05 14:06:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:06:15 --> Config Class Initialized
INFO - 2023-08-05 14:06:15 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:06:15 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:06:15 --> Utf8 Class Initialized
INFO - 2023-08-05 14:06:15 --> URI Class Initialized
INFO - 2023-08-05 14:06:15 --> Router Class Initialized
INFO - 2023-08-05 14:06:15 --> Output Class Initialized
INFO - 2023-08-05 14:06:15 --> Security Class Initialized
DEBUG - 2023-08-05 14:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:06:15 --> Input Class Initialized
INFO - 2023-08-05 14:06:15 --> Language Class Initialized
INFO - 2023-08-05 14:06:15 --> Loader Class Initialized
INFO - 2023-08-05 14:06:15 --> Helper loaded: url_helper
INFO - 2023-08-05 14:06:15 --> Helper loaded: file_helper
INFO - 2023-08-05 14:06:15 --> Helper loaded: html_helper
INFO - 2023-08-05 14:06:15 --> Helper loaded: text_helper
INFO - 2023-08-05 14:06:15 --> Helper loaded: form_helper
INFO - 2023-08-05 14:06:15 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:06:15 --> Helper loaded: security_helper
INFO - 2023-08-05 14:06:15 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:06:15 --> Database Driver Class Initialized
INFO - 2023-08-05 14:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:06:15 --> Parser Class Initialized
INFO - 2023-08-05 14:06:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:06:15 --> Pagination Class Initialized
INFO - 2023-08-05 14:06:15 --> Form Validation Class Initialized
INFO - 2023-08-05 14:06:15 --> Controller Class Initialized
INFO - 2023-08-05 14:06:15 --> Model Class Initialized
DEBUG - 2023-08-05 14:06:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:06:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:06:15 --> Model Class Initialized
DEBUG - 2023-08-05 14:06:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:06:15 --> Model Class Initialized
INFO - 2023-08-05 14:06:15 --> Final output sent to browser
DEBUG - 2023-08-05 14:06:15 --> Total execution time: 0.0393
ERROR - 2023-08-05 14:06:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:06:20 --> Config Class Initialized
INFO - 2023-08-05 14:06:20 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:06:20 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:06:20 --> Utf8 Class Initialized
INFO - 2023-08-05 14:06:20 --> URI Class Initialized
INFO - 2023-08-05 14:06:20 --> Router Class Initialized
INFO - 2023-08-05 14:06:20 --> Output Class Initialized
INFO - 2023-08-05 14:06:20 --> Security Class Initialized
DEBUG - 2023-08-05 14:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:06:21 --> Input Class Initialized
INFO - 2023-08-05 14:06:21 --> Language Class Initialized
INFO - 2023-08-05 14:06:21 --> Loader Class Initialized
INFO - 2023-08-05 14:06:21 --> Helper loaded: url_helper
INFO - 2023-08-05 14:06:21 --> Helper loaded: file_helper
INFO - 2023-08-05 14:06:21 --> Helper loaded: html_helper
INFO - 2023-08-05 14:06:21 --> Helper loaded: text_helper
INFO - 2023-08-05 14:06:21 --> Helper loaded: form_helper
INFO - 2023-08-05 14:06:21 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:06:21 --> Helper loaded: security_helper
INFO - 2023-08-05 14:06:21 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:06:21 --> Database Driver Class Initialized
INFO - 2023-08-05 14:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:06:21 --> Parser Class Initialized
INFO - 2023-08-05 14:06:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:06:21 --> Pagination Class Initialized
INFO - 2023-08-05 14:06:21 --> Form Validation Class Initialized
INFO - 2023-08-05 14:06:21 --> Controller Class Initialized
DEBUG - 2023-08-05 14:06:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:06:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:06:21 --> Model Class Initialized
DEBUG - 2023-08-05 14:06:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:06:21 --> Model Class Initialized
INFO - 2023-08-05 14:06:21 --> Final output sent to browser
DEBUG - 2023-08-05 14:06:21 --> Total execution time: 0.0268
ERROR - 2023-08-05 14:06:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:06:25 --> Config Class Initialized
INFO - 2023-08-05 14:06:25 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:06:25 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:06:25 --> Utf8 Class Initialized
INFO - 2023-08-05 14:06:25 --> URI Class Initialized
INFO - 2023-08-05 14:06:25 --> Router Class Initialized
INFO - 2023-08-05 14:06:25 --> Output Class Initialized
INFO - 2023-08-05 14:06:25 --> Security Class Initialized
DEBUG - 2023-08-05 14:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:06:25 --> Input Class Initialized
INFO - 2023-08-05 14:06:25 --> Language Class Initialized
INFO - 2023-08-05 14:06:25 --> Loader Class Initialized
INFO - 2023-08-05 14:06:25 --> Helper loaded: url_helper
INFO - 2023-08-05 14:06:25 --> Helper loaded: file_helper
INFO - 2023-08-05 14:06:25 --> Helper loaded: html_helper
INFO - 2023-08-05 14:06:25 --> Helper loaded: text_helper
INFO - 2023-08-05 14:06:25 --> Helper loaded: form_helper
INFO - 2023-08-05 14:06:25 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:06:25 --> Helper loaded: security_helper
INFO - 2023-08-05 14:06:25 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:06:25 --> Database Driver Class Initialized
INFO - 2023-08-05 14:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:06:25 --> Parser Class Initialized
INFO - 2023-08-05 14:06:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:06:25 --> Pagination Class Initialized
INFO - 2023-08-05 14:06:25 --> Form Validation Class Initialized
INFO - 2023-08-05 14:06:25 --> Controller Class Initialized
DEBUG - 2023-08-05 14:06:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:06:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:06:25 --> Model Class Initialized
DEBUG - 2023-08-05 14:06:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:06:25 --> Model Class Initialized
INFO - 2023-08-05 14:06:25 --> Final output sent to browser
DEBUG - 2023-08-05 14:06:25 --> Total execution time: 0.0254
ERROR - 2023-08-05 14:06:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:06:29 --> Config Class Initialized
INFO - 2023-08-05 14:06:29 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:06:29 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:06:29 --> Utf8 Class Initialized
INFO - 2023-08-05 14:06:29 --> URI Class Initialized
DEBUG - 2023-08-05 14:06:29 --> No URI present. Default controller set.
INFO - 2023-08-05 14:06:29 --> Router Class Initialized
INFO - 2023-08-05 14:06:29 --> Output Class Initialized
INFO - 2023-08-05 14:06:29 --> Security Class Initialized
DEBUG - 2023-08-05 14:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:06:29 --> Input Class Initialized
INFO - 2023-08-05 14:06:29 --> Language Class Initialized
INFO - 2023-08-05 14:06:29 --> Loader Class Initialized
INFO - 2023-08-05 14:06:29 --> Helper loaded: url_helper
INFO - 2023-08-05 14:06:29 --> Helper loaded: file_helper
INFO - 2023-08-05 14:06:29 --> Helper loaded: html_helper
INFO - 2023-08-05 14:06:29 --> Helper loaded: text_helper
INFO - 2023-08-05 14:06:29 --> Helper loaded: form_helper
INFO - 2023-08-05 14:06:29 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:06:29 --> Helper loaded: security_helper
INFO - 2023-08-05 14:06:29 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:06:29 --> Database Driver Class Initialized
INFO - 2023-08-05 14:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:06:29 --> Parser Class Initialized
INFO - 2023-08-05 14:06:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:06:29 --> Pagination Class Initialized
INFO - 2023-08-05 14:06:29 --> Form Validation Class Initialized
INFO - 2023-08-05 14:06:29 --> Controller Class Initialized
INFO - 2023-08-05 14:06:29 --> Model Class Initialized
DEBUG - 2023-08-05 14:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:06:29 --> Model Class Initialized
DEBUG - 2023-08-05 14:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:06:29 --> Model Class Initialized
INFO - 2023-08-05 14:06:29 --> Model Class Initialized
INFO - 2023-08-05 14:06:29 --> Model Class Initialized
INFO - 2023-08-05 14:06:29 --> Model Class Initialized
DEBUG - 2023-08-05 14:06:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:06:29 --> Model Class Initialized
INFO - 2023-08-05 14:06:29 --> Model Class Initialized
INFO - 2023-08-05 14:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 14:06:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:06:29 --> Model Class Initialized
INFO - 2023-08-05 14:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 14:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 14:06:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:06:29 --> Final output sent to browser
DEBUG - 2023-08-05 14:06:29 --> Total execution time: 0.0863
ERROR - 2023-08-05 14:06:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:06:30 --> Config Class Initialized
INFO - 2023-08-05 14:06:30 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:06:30 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:06:30 --> Utf8 Class Initialized
INFO - 2023-08-05 14:06:30 --> URI Class Initialized
DEBUG - 2023-08-05 14:06:30 --> No URI present. Default controller set.
INFO - 2023-08-05 14:06:30 --> Router Class Initialized
INFO - 2023-08-05 14:06:30 --> Output Class Initialized
INFO - 2023-08-05 14:06:30 --> Security Class Initialized
DEBUG - 2023-08-05 14:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:06:30 --> Input Class Initialized
INFO - 2023-08-05 14:06:30 --> Language Class Initialized
INFO - 2023-08-05 14:06:30 --> Loader Class Initialized
INFO - 2023-08-05 14:06:30 --> Helper loaded: url_helper
INFO - 2023-08-05 14:06:30 --> Helper loaded: file_helper
INFO - 2023-08-05 14:06:30 --> Helper loaded: html_helper
INFO - 2023-08-05 14:06:30 --> Helper loaded: text_helper
INFO - 2023-08-05 14:06:30 --> Helper loaded: form_helper
INFO - 2023-08-05 14:06:30 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:06:30 --> Helper loaded: security_helper
INFO - 2023-08-05 14:06:30 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:06:30 --> Database Driver Class Initialized
INFO - 2023-08-05 14:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:06:30 --> Parser Class Initialized
INFO - 2023-08-05 14:06:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:06:30 --> Pagination Class Initialized
INFO - 2023-08-05 14:06:30 --> Form Validation Class Initialized
INFO - 2023-08-05 14:06:30 --> Controller Class Initialized
INFO - 2023-08-05 14:06:30 --> Model Class Initialized
DEBUG - 2023-08-05 14:06:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:06:30 --> Model Class Initialized
DEBUG - 2023-08-05 14:06:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:06:30 --> Model Class Initialized
INFO - 2023-08-05 14:06:30 --> Model Class Initialized
INFO - 2023-08-05 14:06:30 --> Model Class Initialized
INFO - 2023-08-05 14:06:30 --> Model Class Initialized
DEBUG - 2023-08-05 14:06:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:06:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:06:30 --> Model Class Initialized
INFO - 2023-08-05 14:06:30 --> Model Class Initialized
INFO - 2023-08-05 14:06:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 14:06:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:06:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:06:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:06:30 --> Model Class Initialized
INFO - 2023-08-05 14:06:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 14:06:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 14:06:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:06:30 --> Final output sent to browser
DEBUG - 2023-08-05 14:06:30 --> Total execution time: 0.0789
ERROR - 2023-08-05 14:06:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:06:46 --> Config Class Initialized
INFO - 2023-08-05 14:06:46 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:06:46 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:06:46 --> Utf8 Class Initialized
INFO - 2023-08-05 14:06:46 --> URI Class Initialized
INFO - 2023-08-05 14:06:46 --> Router Class Initialized
INFO - 2023-08-05 14:06:46 --> Output Class Initialized
INFO - 2023-08-05 14:06:46 --> Security Class Initialized
DEBUG - 2023-08-05 14:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:06:46 --> Input Class Initialized
INFO - 2023-08-05 14:06:46 --> Language Class Initialized
INFO - 2023-08-05 14:06:46 --> Loader Class Initialized
INFO - 2023-08-05 14:06:46 --> Helper loaded: url_helper
INFO - 2023-08-05 14:06:46 --> Helper loaded: file_helper
INFO - 2023-08-05 14:06:46 --> Helper loaded: html_helper
INFO - 2023-08-05 14:06:46 --> Helper loaded: text_helper
INFO - 2023-08-05 14:06:46 --> Helper loaded: form_helper
INFO - 2023-08-05 14:06:46 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:06:46 --> Helper loaded: security_helper
INFO - 2023-08-05 14:06:46 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:06:46 --> Database Driver Class Initialized
INFO - 2023-08-05 14:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:06:46 --> Parser Class Initialized
INFO - 2023-08-05 14:06:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:06:46 --> Pagination Class Initialized
INFO - 2023-08-05 14:06:46 --> Form Validation Class Initialized
INFO - 2023-08-05 14:06:46 --> Controller Class Initialized
INFO - 2023-08-05 14:06:46 --> Model Class Initialized
DEBUG - 2023-08-05 14:06:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-05 14:06:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:06:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-05 14:06:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:06:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:06:46 --> Config Class Initialized
INFO - 2023-08-05 14:06:46 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:06:46 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:06:46 --> Utf8 Class Initialized
INFO - 2023-08-05 14:06:46 --> URI Class Initialized
INFO - 2023-08-05 14:06:46 --> Router Class Initialized
INFO - 2023-08-05 14:06:46 --> Output Class Initialized
INFO - 2023-08-05 14:06:46 --> Security Class Initialized
INFO - 2023-08-05 14:06:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
DEBUG - 2023-08-05 14:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:06:46 --> Input Class Initialized
INFO - 2023-08-05 14:06:46 --> Language Class Initialized
INFO - 2023-08-05 14:06:46 --> Model Class Initialized
INFO - 2023-08-05 14:06:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:06:46 --> Final output sent to browser
INFO - 2023-08-05 14:06:46 --> Loader Class Initialized
DEBUG - 2023-08-05 14:06:46 --> Total execution time: 0.0339
INFO - 2023-08-05 14:06:46 --> Helper loaded: url_helper
INFO - 2023-08-05 14:06:46 --> Helper loaded: file_helper
INFO - 2023-08-05 14:06:46 --> Helper loaded: html_helper
INFO - 2023-08-05 14:06:46 --> Helper loaded: text_helper
INFO - 2023-08-05 14:06:46 --> Helper loaded: form_helper
INFO - 2023-08-05 14:06:46 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:06:46 --> Helper loaded: security_helper
INFO - 2023-08-05 14:06:46 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:06:46 --> Database Driver Class Initialized
INFO - 2023-08-05 14:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:06:46 --> Parser Class Initialized
INFO - 2023-08-05 14:06:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:06:46 --> Pagination Class Initialized
INFO - 2023-08-05 14:06:46 --> Form Validation Class Initialized
INFO - 2023-08-05 14:06:46 --> Controller Class Initialized
INFO - 2023-08-05 14:06:46 --> Model Class Initialized
DEBUG - 2023-08-05 14:06:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-05 14:06:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:06:46 --> Config Class Initialized
INFO - 2023-08-05 14:06:46 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:06:46 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:06:46 --> Utf8 Class Initialized
INFO - 2023-08-05 14:06:46 --> URI Class Initialized
INFO - 2023-08-05 14:06:46 --> Router Class Initialized
INFO - 2023-08-05 14:06:46 --> Output Class Initialized
INFO - 2023-08-05 14:06:46 --> Security Class Initialized
DEBUG - 2023-08-05 14:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:06:46 --> Input Class Initialized
INFO - 2023-08-05 14:06:46 --> Language Class Initialized
INFO - 2023-08-05 14:06:46 --> Loader Class Initialized
INFO - 2023-08-05 14:06:46 --> Helper loaded: url_helper
INFO - 2023-08-05 14:06:46 --> Helper loaded: file_helper
INFO - 2023-08-05 14:06:46 --> Helper loaded: html_helper
INFO - 2023-08-05 14:06:46 --> Helper loaded: text_helper
INFO - 2023-08-05 14:06:46 --> Helper loaded: form_helper
INFO - 2023-08-05 14:06:46 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:06:46 --> Helper loaded: security_helper
INFO - 2023-08-05 14:06:46 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:06:46 --> Database Driver Class Initialized
INFO - 2023-08-05 14:06:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-05 14:06:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:06:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:06:46 --> Parser Class Initialized
INFO - 2023-08-05 14:06:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:06:46 --> Pagination Class Initialized
INFO - 2023-08-05 14:06:46 --> Form Validation Class Initialized
INFO - 2023-08-05 14:06:46 --> Controller Class Initialized
INFO - 2023-08-05 14:06:46 --> Model Class Initialized
DEBUG - 2023-08-05 14:06:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:06:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:06:46 --> Model Class Initialized
INFO - 2023-08-05 14:06:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:06:46 --> Final output sent to browser
DEBUG - 2023-08-05 14:06:46 --> Total execution time: 0.0319
INFO - 2023-08-05 14:06:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-05 14:06:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:06:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:06:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:06:46 --> Model Class Initialized
INFO - 2023-08-05 14:06:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:06:46 --> Final output sent to browser
DEBUG - 2023-08-05 14:06:46 --> Total execution time: 0.0306
ERROR - 2023-08-05 14:06:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:06:47 --> Config Class Initialized
INFO - 2023-08-05 14:06:47 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:06:47 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:06:47 --> Utf8 Class Initialized
INFO - 2023-08-05 14:06:47 --> URI Class Initialized
INFO - 2023-08-05 14:06:47 --> Router Class Initialized
INFO - 2023-08-05 14:06:47 --> Output Class Initialized
INFO - 2023-08-05 14:06:47 --> Security Class Initialized
DEBUG - 2023-08-05 14:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:06:47 --> Input Class Initialized
INFO - 2023-08-05 14:06:47 --> Language Class Initialized
INFO - 2023-08-05 14:06:47 --> Loader Class Initialized
INFO - 2023-08-05 14:06:47 --> Helper loaded: url_helper
INFO - 2023-08-05 14:06:47 --> Helper loaded: file_helper
INFO - 2023-08-05 14:06:47 --> Helper loaded: html_helper
INFO - 2023-08-05 14:06:47 --> Helper loaded: text_helper
INFO - 2023-08-05 14:06:47 --> Helper loaded: form_helper
INFO - 2023-08-05 14:06:47 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:06:47 --> Helper loaded: security_helper
INFO - 2023-08-05 14:06:47 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:06:47 --> Database Driver Class Initialized
INFO - 2023-08-05 14:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:06:47 --> Parser Class Initialized
INFO - 2023-08-05 14:06:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:06:47 --> Pagination Class Initialized
INFO - 2023-08-05 14:06:47 --> Form Validation Class Initialized
INFO - 2023-08-05 14:06:47 --> Controller Class Initialized
INFO - 2023-08-05 14:06:47 --> Model Class Initialized
DEBUG - 2023-08-05 14:06:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:06:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-05 14:06:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:06:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:06:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:06:47 --> Model Class Initialized
INFO - 2023-08-05 14:06:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:06:47 --> Final output sent to browser
DEBUG - 2023-08-05 14:06:47 --> Total execution time: 0.0292
ERROR - 2023-08-05 14:06:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:06:48 --> Config Class Initialized
INFO - 2023-08-05 14:06:48 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:06:48 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:06:48 --> Utf8 Class Initialized
INFO - 2023-08-05 14:06:48 --> URI Class Initialized
INFO - 2023-08-05 14:06:48 --> Router Class Initialized
INFO - 2023-08-05 14:06:48 --> Output Class Initialized
INFO - 2023-08-05 14:06:48 --> Security Class Initialized
DEBUG - 2023-08-05 14:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:06:48 --> Input Class Initialized
INFO - 2023-08-05 14:06:48 --> Language Class Initialized
INFO - 2023-08-05 14:06:48 --> Loader Class Initialized
INFO - 2023-08-05 14:06:48 --> Helper loaded: url_helper
INFO - 2023-08-05 14:06:48 --> Helper loaded: file_helper
INFO - 2023-08-05 14:06:48 --> Helper loaded: html_helper
INFO - 2023-08-05 14:06:48 --> Helper loaded: text_helper
INFO - 2023-08-05 14:06:48 --> Helper loaded: form_helper
INFO - 2023-08-05 14:06:48 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:06:48 --> Helper loaded: security_helper
INFO - 2023-08-05 14:06:48 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:06:48 --> Database Driver Class Initialized
INFO - 2023-08-05 14:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:06:48 --> Parser Class Initialized
INFO - 2023-08-05 14:06:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:06:48 --> Pagination Class Initialized
INFO - 2023-08-05 14:06:48 --> Form Validation Class Initialized
INFO - 2023-08-05 14:06:48 --> Controller Class Initialized
INFO - 2023-08-05 14:06:48 --> Model Class Initialized
DEBUG - 2023-08-05 14:06:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:06:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-05 14:06:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:06:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:06:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:06:48 --> Model Class Initialized
INFO - 2023-08-05 14:06:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:06:48 --> Final output sent to browser
DEBUG - 2023-08-05 14:06:48 --> Total execution time: 0.0287
ERROR - 2023-08-05 14:07:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:07:15 --> Config Class Initialized
INFO - 2023-08-05 14:07:15 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:07:15 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:07:15 --> Utf8 Class Initialized
INFO - 2023-08-05 14:07:15 --> URI Class Initialized
INFO - 2023-08-05 14:07:15 --> Router Class Initialized
INFO - 2023-08-05 14:07:15 --> Output Class Initialized
INFO - 2023-08-05 14:07:15 --> Security Class Initialized
DEBUG - 2023-08-05 14:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:07:15 --> Input Class Initialized
INFO - 2023-08-05 14:07:15 --> Language Class Initialized
INFO - 2023-08-05 14:07:15 --> Loader Class Initialized
INFO - 2023-08-05 14:07:15 --> Helper loaded: url_helper
INFO - 2023-08-05 14:07:15 --> Helper loaded: file_helper
INFO - 2023-08-05 14:07:15 --> Helper loaded: html_helper
INFO - 2023-08-05 14:07:15 --> Helper loaded: text_helper
INFO - 2023-08-05 14:07:15 --> Helper loaded: form_helper
INFO - 2023-08-05 14:07:15 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:07:15 --> Helper loaded: security_helper
INFO - 2023-08-05 14:07:15 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:07:15 --> Database Driver Class Initialized
INFO - 2023-08-05 14:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:07:15 --> Parser Class Initialized
INFO - 2023-08-05 14:07:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:07:15 --> Pagination Class Initialized
INFO - 2023-08-05 14:07:15 --> Form Validation Class Initialized
INFO - 2023-08-05 14:07:15 --> Controller Class Initialized
DEBUG - 2023-08-05 14:07:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:07:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:07:15 --> Model Class Initialized
DEBUG - 2023-08-05 14:07:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:07:15 --> Model Class Initialized
DEBUG - 2023-08-05 14:07:15 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:07:15 --> Model Class Initialized
INFO - 2023-08-05 14:07:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-08-05 14:07:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:07:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:07:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:07:15 --> Model Class Initialized
INFO - 2023-08-05 14:07:15 --> Model Class Initialized
INFO - 2023-08-05 14:07:15 --> Model Class Initialized
INFO - 2023-08-05 14:07:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 14:07:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 14:07:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:07:15 --> Final output sent to browser
DEBUG - 2023-08-05 14:07:15 --> Total execution time: 0.1290
ERROR - 2023-08-05 14:07:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:07:15 --> Config Class Initialized
INFO - 2023-08-05 14:07:15 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:07:15 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:07:15 --> Utf8 Class Initialized
INFO - 2023-08-05 14:07:15 --> URI Class Initialized
INFO - 2023-08-05 14:07:15 --> Router Class Initialized
INFO - 2023-08-05 14:07:15 --> Output Class Initialized
INFO - 2023-08-05 14:07:15 --> Security Class Initialized
DEBUG - 2023-08-05 14:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:07:15 --> Input Class Initialized
INFO - 2023-08-05 14:07:15 --> Language Class Initialized
INFO - 2023-08-05 14:07:15 --> Loader Class Initialized
INFO - 2023-08-05 14:07:15 --> Helper loaded: url_helper
INFO - 2023-08-05 14:07:15 --> Helper loaded: file_helper
INFO - 2023-08-05 14:07:15 --> Helper loaded: html_helper
INFO - 2023-08-05 14:07:15 --> Helper loaded: text_helper
INFO - 2023-08-05 14:07:15 --> Helper loaded: form_helper
INFO - 2023-08-05 14:07:15 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:07:15 --> Helper loaded: security_helper
INFO - 2023-08-05 14:07:15 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:07:15 --> Database Driver Class Initialized
INFO - 2023-08-05 14:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:07:15 --> Parser Class Initialized
INFO - 2023-08-05 14:07:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:07:15 --> Pagination Class Initialized
INFO - 2023-08-05 14:07:15 --> Form Validation Class Initialized
INFO - 2023-08-05 14:07:15 --> Controller Class Initialized
DEBUG - 2023-08-05 14:07:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:07:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:07:15 --> Model Class Initialized
DEBUG - 2023-08-05 14:07:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:07:15 --> Model Class Initialized
INFO - 2023-08-05 14:07:15 --> Final output sent to browser
DEBUG - 2023-08-05 14:07:15 --> Total execution time: 0.0299
ERROR - 2023-08-05 14:07:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:07:21 --> Config Class Initialized
INFO - 2023-08-05 14:07:21 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:07:21 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:07:21 --> Utf8 Class Initialized
INFO - 2023-08-05 14:07:21 --> URI Class Initialized
INFO - 2023-08-05 14:07:21 --> Router Class Initialized
INFO - 2023-08-05 14:07:21 --> Output Class Initialized
INFO - 2023-08-05 14:07:21 --> Security Class Initialized
DEBUG - 2023-08-05 14:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:07:21 --> Input Class Initialized
INFO - 2023-08-05 14:07:21 --> Language Class Initialized
INFO - 2023-08-05 14:07:21 --> Loader Class Initialized
INFO - 2023-08-05 14:07:21 --> Helper loaded: url_helper
INFO - 2023-08-05 14:07:21 --> Helper loaded: file_helper
INFO - 2023-08-05 14:07:21 --> Helper loaded: html_helper
INFO - 2023-08-05 14:07:21 --> Helper loaded: text_helper
INFO - 2023-08-05 14:07:21 --> Helper loaded: form_helper
INFO - 2023-08-05 14:07:21 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:07:21 --> Helper loaded: security_helper
INFO - 2023-08-05 14:07:21 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:07:21 --> Database Driver Class Initialized
INFO - 2023-08-05 14:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:07:21 --> Parser Class Initialized
INFO - 2023-08-05 14:07:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:07:21 --> Pagination Class Initialized
INFO - 2023-08-05 14:07:21 --> Form Validation Class Initialized
INFO - 2023-08-05 14:07:21 --> Controller Class Initialized
DEBUG - 2023-08-05 14:07:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:07:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:07:21 --> Model Class Initialized
DEBUG - 2023-08-05 14:07:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:07:21 --> Model Class Initialized
INFO - 2023-08-05 14:07:21 --> Final output sent to browser
DEBUG - 2023-08-05 14:07:21 --> Total execution time: 0.1273
ERROR - 2023-08-05 14:07:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:07:33 --> Config Class Initialized
INFO - 2023-08-05 14:07:33 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:07:33 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:07:33 --> Utf8 Class Initialized
INFO - 2023-08-05 14:07:33 --> URI Class Initialized
INFO - 2023-08-05 14:07:33 --> Router Class Initialized
INFO - 2023-08-05 14:07:33 --> Output Class Initialized
INFO - 2023-08-05 14:07:33 --> Security Class Initialized
DEBUG - 2023-08-05 14:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:07:33 --> Input Class Initialized
INFO - 2023-08-05 14:07:33 --> Language Class Initialized
INFO - 2023-08-05 14:07:33 --> Loader Class Initialized
INFO - 2023-08-05 14:07:33 --> Helper loaded: url_helper
INFO - 2023-08-05 14:07:33 --> Helper loaded: file_helper
INFO - 2023-08-05 14:07:33 --> Helper loaded: html_helper
INFO - 2023-08-05 14:07:33 --> Helper loaded: text_helper
INFO - 2023-08-05 14:07:33 --> Helper loaded: form_helper
INFO - 2023-08-05 14:07:33 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:07:33 --> Helper loaded: security_helper
INFO - 2023-08-05 14:07:33 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:07:33 --> Database Driver Class Initialized
INFO - 2023-08-05 14:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:07:33 --> Parser Class Initialized
INFO - 2023-08-05 14:07:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:07:33 --> Pagination Class Initialized
INFO - 2023-08-05 14:07:33 --> Form Validation Class Initialized
INFO - 2023-08-05 14:07:33 --> Controller Class Initialized
DEBUG - 2023-08-05 14:07:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:07:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:07:33 --> Model Class Initialized
DEBUG - 2023-08-05 14:07:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:07:33 --> Model Class Initialized
INFO - 2023-08-05 14:07:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-08-05 14:07:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:07:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:07:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:07:33 --> Model Class Initialized
INFO - 2023-08-05 14:07:33 --> Model Class Initialized
INFO - 2023-08-05 14:07:33 --> Model Class Initialized
INFO - 2023-08-05 14:07:33 --> Model Class Initialized
INFO - 2023-08-05 14:07:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 14:07:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 14:07:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:07:33 --> Final output sent to browser
DEBUG - 2023-08-05 14:07:33 --> Total execution time: 0.1342
ERROR - 2023-08-05 14:07:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:07:42 --> Config Class Initialized
INFO - 2023-08-05 14:07:42 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:07:42 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:07:42 --> Utf8 Class Initialized
INFO - 2023-08-05 14:07:42 --> URI Class Initialized
INFO - 2023-08-05 14:07:42 --> Router Class Initialized
INFO - 2023-08-05 14:07:42 --> Output Class Initialized
INFO - 2023-08-05 14:07:42 --> Security Class Initialized
DEBUG - 2023-08-05 14:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:07:42 --> Input Class Initialized
INFO - 2023-08-05 14:07:42 --> Language Class Initialized
INFO - 2023-08-05 14:07:42 --> Loader Class Initialized
INFO - 2023-08-05 14:07:42 --> Helper loaded: url_helper
INFO - 2023-08-05 14:07:42 --> Helper loaded: file_helper
INFO - 2023-08-05 14:07:42 --> Helper loaded: html_helper
INFO - 2023-08-05 14:07:42 --> Helper loaded: text_helper
INFO - 2023-08-05 14:07:42 --> Helper loaded: form_helper
INFO - 2023-08-05 14:07:42 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:07:42 --> Helper loaded: security_helper
INFO - 2023-08-05 14:07:42 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:07:42 --> Database Driver Class Initialized
INFO - 2023-08-05 14:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:07:42 --> Parser Class Initialized
INFO - 2023-08-05 14:07:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:07:42 --> Pagination Class Initialized
INFO - 2023-08-05 14:07:42 --> Form Validation Class Initialized
INFO - 2023-08-05 14:07:42 --> Controller Class Initialized
DEBUG - 2023-08-05 14:07:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:07:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:07:42 --> Model Class Initialized
DEBUG - 2023-08-05 14:07:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:07:42 --> Model Class Initialized
DEBUG - 2023-08-05 14:07:42 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:07:42 --> Model Class Initialized
INFO - 2023-08-05 14:07:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-08-05 14:07:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:07:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:07:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:07:42 --> Model Class Initialized
INFO - 2023-08-05 14:07:42 --> Model Class Initialized
INFO - 2023-08-05 14:07:42 --> Model Class Initialized
INFO - 2023-08-05 14:07:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 14:07:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 14:07:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:07:42 --> Final output sent to browser
DEBUG - 2023-08-05 14:07:42 --> Total execution time: 0.1253
ERROR - 2023-08-05 14:07:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:07:43 --> Config Class Initialized
INFO - 2023-08-05 14:07:43 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:07:43 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:07:43 --> Utf8 Class Initialized
INFO - 2023-08-05 14:07:43 --> URI Class Initialized
INFO - 2023-08-05 14:07:43 --> Router Class Initialized
INFO - 2023-08-05 14:07:43 --> Output Class Initialized
INFO - 2023-08-05 14:07:43 --> Security Class Initialized
DEBUG - 2023-08-05 14:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:07:43 --> Input Class Initialized
INFO - 2023-08-05 14:07:43 --> Language Class Initialized
INFO - 2023-08-05 14:07:43 --> Loader Class Initialized
INFO - 2023-08-05 14:07:43 --> Helper loaded: url_helper
INFO - 2023-08-05 14:07:43 --> Helper loaded: file_helper
INFO - 2023-08-05 14:07:43 --> Helper loaded: html_helper
INFO - 2023-08-05 14:07:43 --> Helper loaded: text_helper
INFO - 2023-08-05 14:07:43 --> Helper loaded: form_helper
INFO - 2023-08-05 14:07:43 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:07:43 --> Helper loaded: security_helper
INFO - 2023-08-05 14:07:43 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:07:43 --> Database Driver Class Initialized
INFO - 2023-08-05 14:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:07:43 --> Parser Class Initialized
INFO - 2023-08-05 14:07:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:07:43 --> Pagination Class Initialized
INFO - 2023-08-05 14:07:43 --> Form Validation Class Initialized
INFO - 2023-08-05 14:07:43 --> Controller Class Initialized
DEBUG - 2023-08-05 14:07:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:07:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:07:43 --> Model Class Initialized
DEBUG - 2023-08-05 14:07:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:07:43 --> Model Class Initialized
INFO - 2023-08-05 14:07:43 --> Final output sent to browser
DEBUG - 2023-08-05 14:07:43 --> Total execution time: 0.0322
ERROR - 2023-08-05 14:07:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:07:50 --> Config Class Initialized
INFO - 2023-08-05 14:07:50 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:07:50 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:07:50 --> Utf8 Class Initialized
INFO - 2023-08-05 14:07:50 --> URI Class Initialized
INFO - 2023-08-05 14:07:50 --> Router Class Initialized
INFO - 2023-08-05 14:07:50 --> Output Class Initialized
INFO - 2023-08-05 14:07:50 --> Security Class Initialized
DEBUG - 2023-08-05 14:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:07:50 --> Input Class Initialized
INFO - 2023-08-05 14:07:50 --> Language Class Initialized
INFO - 2023-08-05 14:07:50 --> Loader Class Initialized
INFO - 2023-08-05 14:07:50 --> Helper loaded: url_helper
INFO - 2023-08-05 14:07:50 --> Helper loaded: file_helper
INFO - 2023-08-05 14:07:50 --> Helper loaded: html_helper
INFO - 2023-08-05 14:07:50 --> Helper loaded: text_helper
INFO - 2023-08-05 14:07:50 --> Helper loaded: form_helper
INFO - 2023-08-05 14:07:50 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:07:50 --> Helper loaded: security_helper
INFO - 2023-08-05 14:07:50 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:07:50 --> Database Driver Class Initialized
INFO - 2023-08-05 14:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:07:50 --> Parser Class Initialized
INFO - 2023-08-05 14:07:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:07:50 --> Pagination Class Initialized
INFO - 2023-08-05 14:07:50 --> Form Validation Class Initialized
INFO - 2023-08-05 14:07:50 --> Controller Class Initialized
DEBUG - 2023-08-05 14:07:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:07:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:07:50 --> Model Class Initialized
DEBUG - 2023-08-05 14:07:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:07:50 --> Model Class Initialized
INFO - 2023-08-05 14:07:50 --> Final output sent to browser
DEBUG - 2023-08-05 14:07:50 --> Total execution time: 0.1348
ERROR - 2023-08-05 14:07:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:07:57 --> Config Class Initialized
INFO - 2023-08-05 14:07:57 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:07:57 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:07:57 --> Utf8 Class Initialized
INFO - 2023-08-05 14:07:57 --> URI Class Initialized
INFO - 2023-08-05 14:07:57 --> Router Class Initialized
INFO - 2023-08-05 14:07:57 --> Output Class Initialized
INFO - 2023-08-05 14:07:57 --> Security Class Initialized
DEBUG - 2023-08-05 14:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:07:57 --> Input Class Initialized
INFO - 2023-08-05 14:07:57 --> Language Class Initialized
INFO - 2023-08-05 14:07:57 --> Loader Class Initialized
INFO - 2023-08-05 14:07:57 --> Helper loaded: url_helper
INFO - 2023-08-05 14:07:57 --> Helper loaded: file_helper
INFO - 2023-08-05 14:07:57 --> Helper loaded: html_helper
INFO - 2023-08-05 14:07:57 --> Helper loaded: text_helper
INFO - 2023-08-05 14:07:57 --> Helper loaded: form_helper
INFO - 2023-08-05 14:07:57 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:07:57 --> Helper loaded: security_helper
INFO - 2023-08-05 14:07:57 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:07:57 --> Database Driver Class Initialized
INFO - 2023-08-05 14:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:07:57 --> Parser Class Initialized
INFO - 2023-08-05 14:07:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:07:57 --> Pagination Class Initialized
INFO - 2023-08-05 14:07:57 --> Form Validation Class Initialized
INFO - 2023-08-05 14:07:57 --> Controller Class Initialized
DEBUG - 2023-08-05 14:07:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:07:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:07:57 --> Model Class Initialized
DEBUG - 2023-08-05 14:07:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:07:57 --> Model Class Initialized
INFO - 2023-08-05 14:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/edit_customer_form.php
DEBUG - 2023-08-05 14:07:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:07:57 --> Model Class Initialized
INFO - 2023-08-05 14:07:57 --> Model Class Initialized
INFO - 2023-08-05 14:07:57 --> Model Class Initialized
INFO - 2023-08-05 14:07:57 --> Model Class Initialized
INFO - 2023-08-05 14:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 14:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 14:07:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:07:57 --> Final output sent to browser
DEBUG - 2023-08-05 14:07:57 --> Total execution time: 0.1523
ERROR - 2023-08-05 14:08:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:08:09 --> Config Class Initialized
INFO - 2023-08-05 14:08:09 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:08:09 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:08:09 --> Utf8 Class Initialized
INFO - 2023-08-05 14:08:09 --> URI Class Initialized
INFO - 2023-08-05 14:08:09 --> Router Class Initialized
INFO - 2023-08-05 14:08:09 --> Output Class Initialized
INFO - 2023-08-05 14:08:09 --> Security Class Initialized
DEBUG - 2023-08-05 14:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:08:09 --> Input Class Initialized
INFO - 2023-08-05 14:08:09 --> Language Class Initialized
INFO - 2023-08-05 14:08:09 --> Loader Class Initialized
INFO - 2023-08-05 14:08:09 --> Helper loaded: url_helper
INFO - 2023-08-05 14:08:09 --> Helper loaded: file_helper
INFO - 2023-08-05 14:08:09 --> Helper loaded: html_helper
INFO - 2023-08-05 14:08:09 --> Helper loaded: text_helper
INFO - 2023-08-05 14:08:09 --> Helper loaded: form_helper
INFO - 2023-08-05 14:08:09 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:08:09 --> Helper loaded: security_helper
INFO - 2023-08-05 14:08:09 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:08:09 --> Database Driver Class Initialized
INFO - 2023-08-05 14:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:08:09 --> Parser Class Initialized
INFO - 2023-08-05 14:08:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:08:09 --> Pagination Class Initialized
INFO - 2023-08-05 14:08:09 --> Form Validation Class Initialized
INFO - 2023-08-05 14:08:09 --> Controller Class Initialized
DEBUG - 2023-08-05 14:08:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:08:09 --> Model Class Initialized
DEBUG - 2023-08-05 14:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:08:09 --> Model Class Initialized
ERROR - 2023-08-05 14:08:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:08:09 --> Config Class Initialized
INFO - 2023-08-05 14:08:09 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:08:09 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:08:09 --> Utf8 Class Initialized
INFO - 2023-08-05 14:08:09 --> URI Class Initialized
INFO - 2023-08-05 14:08:09 --> Router Class Initialized
INFO - 2023-08-05 14:08:09 --> Output Class Initialized
INFO - 2023-08-05 14:08:09 --> Security Class Initialized
DEBUG - 2023-08-05 14:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:08:09 --> Input Class Initialized
INFO - 2023-08-05 14:08:09 --> Language Class Initialized
INFO - 2023-08-05 14:08:09 --> Loader Class Initialized
INFO - 2023-08-05 14:08:09 --> Helper loaded: url_helper
INFO - 2023-08-05 14:08:09 --> Helper loaded: file_helper
INFO - 2023-08-05 14:08:09 --> Helper loaded: html_helper
INFO - 2023-08-05 14:08:09 --> Helper loaded: text_helper
INFO - 2023-08-05 14:08:09 --> Helper loaded: form_helper
INFO - 2023-08-05 14:08:09 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:08:09 --> Helper loaded: security_helper
INFO - 2023-08-05 14:08:09 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:08:09 --> Database Driver Class Initialized
INFO - 2023-08-05 14:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:08:09 --> Parser Class Initialized
INFO - 2023-08-05 14:08:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:08:09 --> Pagination Class Initialized
INFO - 2023-08-05 14:08:09 --> Form Validation Class Initialized
INFO - 2023-08-05 14:08:09 --> Controller Class Initialized
DEBUG - 2023-08-05 14:08:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:08:09 --> Model Class Initialized
DEBUG - 2023-08-05 14:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:08:09 --> Model Class Initialized
DEBUG - 2023-08-05 14:08:09 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:08:09 --> Model Class Initialized
INFO - 2023-08-05 14:08:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-08-05 14:08:09 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:08:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:08:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:08:09 --> Model Class Initialized
INFO - 2023-08-05 14:08:09 --> Model Class Initialized
INFO - 2023-08-05 14:08:09 --> Model Class Initialized
INFO - 2023-08-05 14:08:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 14:08:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 14:08:09 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:08:09 --> Final output sent to browser
DEBUG - 2023-08-05 14:08:09 --> Total execution time: 0.1451
ERROR - 2023-08-05 14:08:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:08:10 --> Config Class Initialized
INFO - 2023-08-05 14:08:10 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:08:10 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:08:10 --> Utf8 Class Initialized
INFO - 2023-08-05 14:08:10 --> URI Class Initialized
INFO - 2023-08-05 14:08:10 --> Router Class Initialized
INFO - 2023-08-05 14:08:10 --> Output Class Initialized
INFO - 2023-08-05 14:08:10 --> Security Class Initialized
DEBUG - 2023-08-05 14:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:08:10 --> Input Class Initialized
INFO - 2023-08-05 14:08:10 --> Language Class Initialized
INFO - 2023-08-05 14:08:10 --> Loader Class Initialized
INFO - 2023-08-05 14:08:10 --> Helper loaded: url_helper
INFO - 2023-08-05 14:08:10 --> Helper loaded: file_helper
INFO - 2023-08-05 14:08:10 --> Helper loaded: html_helper
INFO - 2023-08-05 14:08:10 --> Helper loaded: text_helper
INFO - 2023-08-05 14:08:10 --> Helper loaded: form_helper
INFO - 2023-08-05 14:08:10 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:08:10 --> Helper loaded: security_helper
INFO - 2023-08-05 14:08:10 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:08:10 --> Database Driver Class Initialized
INFO - 2023-08-05 14:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:08:10 --> Parser Class Initialized
INFO - 2023-08-05 14:08:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:08:10 --> Pagination Class Initialized
INFO - 2023-08-05 14:08:10 --> Form Validation Class Initialized
INFO - 2023-08-05 14:08:10 --> Controller Class Initialized
DEBUG - 2023-08-05 14:08:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:08:10 --> Model Class Initialized
DEBUG - 2023-08-05 14:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:08:10 --> Model Class Initialized
INFO - 2023-08-05 14:08:10 --> Final output sent to browser
DEBUG - 2023-08-05 14:08:10 --> Total execution time: 0.0325
ERROR - 2023-08-05 14:08:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:08:13 --> Config Class Initialized
INFO - 2023-08-05 14:08:13 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:08:13 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:08:13 --> Utf8 Class Initialized
INFO - 2023-08-05 14:08:13 --> URI Class Initialized
INFO - 2023-08-05 14:08:13 --> Router Class Initialized
INFO - 2023-08-05 14:08:13 --> Output Class Initialized
INFO - 2023-08-05 14:08:13 --> Security Class Initialized
DEBUG - 2023-08-05 14:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:08:13 --> Input Class Initialized
INFO - 2023-08-05 14:08:13 --> Language Class Initialized
INFO - 2023-08-05 14:08:13 --> Loader Class Initialized
INFO - 2023-08-05 14:08:13 --> Helper loaded: url_helper
INFO - 2023-08-05 14:08:13 --> Helper loaded: file_helper
INFO - 2023-08-05 14:08:13 --> Helper loaded: html_helper
INFO - 2023-08-05 14:08:13 --> Helper loaded: text_helper
INFO - 2023-08-05 14:08:13 --> Helper loaded: form_helper
INFO - 2023-08-05 14:08:13 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:08:13 --> Helper loaded: security_helper
INFO - 2023-08-05 14:08:13 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:08:13 --> Database Driver Class Initialized
INFO - 2023-08-05 14:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:08:13 --> Parser Class Initialized
INFO - 2023-08-05 14:08:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:08:13 --> Pagination Class Initialized
INFO - 2023-08-05 14:08:13 --> Form Validation Class Initialized
INFO - 2023-08-05 14:08:13 --> Controller Class Initialized
DEBUG - 2023-08-05 14:08:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:08:13 --> Model Class Initialized
DEBUG - 2023-08-05 14:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:08:13 --> Model Class Initialized
INFO - 2023-08-05 14:08:14 --> Final output sent to browser
DEBUG - 2023-08-05 14:08:14 --> Total execution time: 0.1452
ERROR - 2023-08-05 14:08:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:08:24 --> Config Class Initialized
INFO - 2023-08-05 14:08:24 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:08:24 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:08:24 --> Utf8 Class Initialized
INFO - 2023-08-05 14:08:24 --> URI Class Initialized
INFO - 2023-08-05 14:08:24 --> Router Class Initialized
INFO - 2023-08-05 14:08:24 --> Output Class Initialized
INFO - 2023-08-05 14:08:24 --> Security Class Initialized
DEBUG - 2023-08-05 14:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:08:24 --> Input Class Initialized
INFO - 2023-08-05 14:08:24 --> Language Class Initialized
INFO - 2023-08-05 14:08:24 --> Loader Class Initialized
INFO - 2023-08-05 14:08:24 --> Helper loaded: url_helper
INFO - 2023-08-05 14:08:24 --> Helper loaded: file_helper
INFO - 2023-08-05 14:08:24 --> Helper loaded: html_helper
INFO - 2023-08-05 14:08:24 --> Helper loaded: text_helper
INFO - 2023-08-05 14:08:24 --> Helper loaded: form_helper
INFO - 2023-08-05 14:08:24 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:08:24 --> Helper loaded: security_helper
INFO - 2023-08-05 14:08:24 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:08:24 --> Database Driver Class Initialized
INFO - 2023-08-05 14:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:08:24 --> Parser Class Initialized
INFO - 2023-08-05 14:08:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:08:24 --> Pagination Class Initialized
INFO - 2023-08-05 14:08:24 --> Form Validation Class Initialized
INFO - 2023-08-05 14:08:24 --> Controller Class Initialized
DEBUG - 2023-08-05 14:08:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:08:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:08:24 --> Model Class Initialized
DEBUG - 2023-08-05 14:08:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:08:24 --> Model Class Initialized
INFO - 2023-08-05 14:08:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer_change_password_form.php
DEBUG - 2023-08-05 14:08:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:08:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:08:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:08:24 --> Model Class Initialized
INFO - 2023-08-05 14:08:24 --> Model Class Initialized
INFO - 2023-08-05 14:08:24 --> Model Class Initialized
INFO - 2023-08-05 14:08:24 --> Model Class Initialized
INFO - 2023-08-05 14:08:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 14:08:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 14:08:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:08:24 --> Final output sent to browser
DEBUG - 2023-08-05 14:08:24 --> Total execution time: 0.1303
ERROR - 2023-08-05 14:08:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:08:30 --> Config Class Initialized
INFO - 2023-08-05 14:08:30 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:08:30 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:08:30 --> Utf8 Class Initialized
INFO - 2023-08-05 14:08:30 --> URI Class Initialized
INFO - 2023-08-05 14:08:30 --> Router Class Initialized
INFO - 2023-08-05 14:08:30 --> Output Class Initialized
INFO - 2023-08-05 14:08:30 --> Security Class Initialized
DEBUG - 2023-08-05 14:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:08:30 --> Input Class Initialized
INFO - 2023-08-05 14:08:30 --> Language Class Initialized
INFO - 2023-08-05 14:08:30 --> Loader Class Initialized
INFO - 2023-08-05 14:08:30 --> Helper loaded: url_helper
INFO - 2023-08-05 14:08:30 --> Helper loaded: file_helper
INFO - 2023-08-05 14:08:30 --> Helper loaded: html_helper
INFO - 2023-08-05 14:08:30 --> Helper loaded: text_helper
INFO - 2023-08-05 14:08:30 --> Helper loaded: form_helper
INFO - 2023-08-05 14:08:30 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:08:30 --> Helper loaded: security_helper
INFO - 2023-08-05 14:08:30 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:08:30 --> Database Driver Class Initialized
INFO - 2023-08-05 14:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:08:30 --> Parser Class Initialized
INFO - 2023-08-05 14:08:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:08:30 --> Pagination Class Initialized
INFO - 2023-08-05 14:08:30 --> Form Validation Class Initialized
INFO - 2023-08-05 14:08:30 --> Controller Class Initialized
DEBUG - 2023-08-05 14:08:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:08:30 --> Model Class Initialized
DEBUG - 2023-08-05 14:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:08:30 --> Model Class Initialized
ERROR - 2023-08-05 14:08:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:08:31 --> Config Class Initialized
INFO - 2023-08-05 14:08:31 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:08:31 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:08:31 --> Utf8 Class Initialized
INFO - 2023-08-05 14:08:31 --> URI Class Initialized
INFO - 2023-08-05 14:08:31 --> Router Class Initialized
INFO - 2023-08-05 14:08:31 --> Output Class Initialized
INFO - 2023-08-05 14:08:31 --> Security Class Initialized
DEBUG - 2023-08-05 14:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:08:31 --> Input Class Initialized
INFO - 2023-08-05 14:08:31 --> Language Class Initialized
INFO - 2023-08-05 14:08:31 --> Loader Class Initialized
INFO - 2023-08-05 14:08:31 --> Helper loaded: url_helper
INFO - 2023-08-05 14:08:31 --> Helper loaded: file_helper
INFO - 2023-08-05 14:08:31 --> Helper loaded: html_helper
INFO - 2023-08-05 14:08:31 --> Helper loaded: text_helper
INFO - 2023-08-05 14:08:31 --> Helper loaded: form_helper
INFO - 2023-08-05 14:08:31 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:08:31 --> Helper loaded: security_helper
INFO - 2023-08-05 14:08:31 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:08:31 --> Database Driver Class Initialized
INFO - 2023-08-05 14:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:08:31 --> Parser Class Initialized
INFO - 2023-08-05 14:08:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:08:31 --> Pagination Class Initialized
INFO - 2023-08-05 14:08:31 --> Form Validation Class Initialized
INFO - 2023-08-05 14:08:31 --> Controller Class Initialized
DEBUG - 2023-08-05 14:08:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:08:31 --> Model Class Initialized
DEBUG - 2023-08-05 14:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:08:31 --> Model Class Initialized
DEBUG - 2023-08-05 14:08:31 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:08:31 --> Model Class Initialized
INFO - 2023-08-05 14:08:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-08-05 14:08:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:08:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:08:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:08:31 --> Model Class Initialized
INFO - 2023-08-05 14:08:31 --> Model Class Initialized
INFO - 2023-08-05 14:08:31 --> Model Class Initialized
INFO - 2023-08-05 14:08:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 14:08:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 14:08:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:08:31 --> Final output sent to browser
DEBUG - 2023-08-05 14:08:31 --> Total execution time: 0.1669
ERROR - 2023-08-05 14:08:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:08:31 --> Config Class Initialized
INFO - 2023-08-05 14:08:31 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:08:31 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:08:31 --> Utf8 Class Initialized
INFO - 2023-08-05 14:08:31 --> URI Class Initialized
INFO - 2023-08-05 14:08:31 --> Router Class Initialized
INFO - 2023-08-05 14:08:31 --> Output Class Initialized
INFO - 2023-08-05 14:08:31 --> Security Class Initialized
DEBUG - 2023-08-05 14:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:08:31 --> Input Class Initialized
INFO - 2023-08-05 14:08:31 --> Language Class Initialized
INFO - 2023-08-05 14:08:31 --> Loader Class Initialized
INFO - 2023-08-05 14:08:31 --> Helper loaded: url_helper
INFO - 2023-08-05 14:08:31 --> Helper loaded: file_helper
INFO - 2023-08-05 14:08:31 --> Helper loaded: html_helper
INFO - 2023-08-05 14:08:31 --> Helper loaded: text_helper
INFO - 2023-08-05 14:08:31 --> Helper loaded: form_helper
INFO - 2023-08-05 14:08:31 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:08:31 --> Helper loaded: security_helper
INFO - 2023-08-05 14:08:31 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:08:31 --> Database Driver Class Initialized
INFO - 2023-08-05 14:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:08:31 --> Parser Class Initialized
INFO - 2023-08-05 14:08:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:08:31 --> Pagination Class Initialized
INFO - 2023-08-05 14:08:31 --> Form Validation Class Initialized
INFO - 2023-08-05 14:08:31 --> Controller Class Initialized
DEBUG - 2023-08-05 14:08:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:08:31 --> Model Class Initialized
DEBUG - 2023-08-05 14:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:08:31 --> Model Class Initialized
INFO - 2023-08-05 14:08:31 --> Final output sent to browser
DEBUG - 2023-08-05 14:08:31 --> Total execution time: 0.0307
ERROR - 2023-08-05 14:08:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:08:47 --> Config Class Initialized
INFO - 2023-08-05 14:08:47 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:08:47 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:08:47 --> Utf8 Class Initialized
INFO - 2023-08-05 14:08:47 --> URI Class Initialized
INFO - 2023-08-05 14:08:47 --> Router Class Initialized
INFO - 2023-08-05 14:08:47 --> Output Class Initialized
INFO - 2023-08-05 14:08:47 --> Security Class Initialized
DEBUG - 2023-08-05 14:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:08:47 --> Input Class Initialized
INFO - 2023-08-05 14:08:47 --> Language Class Initialized
INFO - 2023-08-05 14:08:47 --> Loader Class Initialized
INFO - 2023-08-05 14:08:47 --> Helper loaded: url_helper
INFO - 2023-08-05 14:08:47 --> Helper loaded: file_helper
INFO - 2023-08-05 14:08:47 --> Helper loaded: html_helper
INFO - 2023-08-05 14:08:47 --> Helper loaded: text_helper
INFO - 2023-08-05 14:08:47 --> Helper loaded: form_helper
INFO - 2023-08-05 14:08:47 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:08:47 --> Helper loaded: security_helper
INFO - 2023-08-05 14:08:47 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:08:47 --> Database Driver Class Initialized
INFO - 2023-08-05 14:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:08:47 --> Parser Class Initialized
INFO - 2023-08-05 14:08:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:08:47 --> Pagination Class Initialized
INFO - 2023-08-05 14:08:47 --> Form Validation Class Initialized
INFO - 2023-08-05 14:08:47 --> Controller Class Initialized
DEBUG - 2023-08-05 14:08:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:08:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:08:47 --> Model Class Initialized
DEBUG - 2023-08-05 14:08:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:08:47 --> Model Class Initialized
INFO - 2023-08-05 14:08:47 --> Final output sent to browser
DEBUG - 2023-08-05 14:08:47 --> Total execution time: 0.1251
ERROR - 2023-08-05 14:09:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:09:05 --> Config Class Initialized
INFO - 2023-08-05 14:09:05 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:09:05 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:09:05 --> Utf8 Class Initialized
INFO - 2023-08-05 14:09:05 --> URI Class Initialized
INFO - 2023-08-05 14:09:05 --> Router Class Initialized
INFO - 2023-08-05 14:09:05 --> Output Class Initialized
INFO - 2023-08-05 14:09:05 --> Security Class Initialized
DEBUG - 2023-08-05 14:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:09:05 --> Input Class Initialized
INFO - 2023-08-05 14:09:05 --> Language Class Initialized
INFO - 2023-08-05 14:09:05 --> Loader Class Initialized
INFO - 2023-08-05 14:09:05 --> Helper loaded: url_helper
INFO - 2023-08-05 14:09:05 --> Helper loaded: file_helper
INFO - 2023-08-05 14:09:05 --> Helper loaded: html_helper
INFO - 2023-08-05 14:09:05 --> Helper loaded: text_helper
INFO - 2023-08-05 14:09:05 --> Helper loaded: form_helper
INFO - 2023-08-05 14:09:05 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:09:05 --> Helper loaded: security_helper
INFO - 2023-08-05 14:09:05 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:09:05 --> Database Driver Class Initialized
INFO - 2023-08-05 14:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:09:05 --> Parser Class Initialized
INFO - 2023-08-05 14:09:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:09:05 --> Pagination Class Initialized
INFO - 2023-08-05 14:09:06 --> Form Validation Class Initialized
INFO - 2023-08-05 14:09:06 --> Controller Class Initialized
DEBUG - 2023-08-05 14:09:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:09:06 --> Model Class Initialized
DEBUG - 2023-08-05 14:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:09:06 --> Model Class Initialized
INFO - 2023-08-05 14:09:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/view_customer.php
DEBUG - 2023-08-05 14:09:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:09:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:09:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:09:06 --> Model Class Initialized
INFO - 2023-08-05 14:09:06 --> Model Class Initialized
INFO - 2023-08-05 14:09:06 --> Model Class Initialized
INFO - 2023-08-05 14:09:06 --> Model Class Initialized
INFO - 2023-08-05 14:09:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 14:09:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 14:09:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:09:06 --> Final output sent to browser
DEBUG - 2023-08-05 14:09:06 --> Total execution time: 0.1323
ERROR - 2023-08-05 14:09:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:09:18 --> Config Class Initialized
INFO - 2023-08-05 14:09:18 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:09:18 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:09:18 --> Utf8 Class Initialized
INFO - 2023-08-05 14:09:18 --> URI Class Initialized
DEBUG - 2023-08-05 14:09:18 --> No URI present. Default controller set.
INFO - 2023-08-05 14:09:18 --> Router Class Initialized
INFO - 2023-08-05 14:09:18 --> Output Class Initialized
INFO - 2023-08-05 14:09:18 --> Security Class Initialized
DEBUG - 2023-08-05 14:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:09:18 --> Input Class Initialized
INFO - 2023-08-05 14:09:18 --> Language Class Initialized
INFO - 2023-08-05 14:09:18 --> Loader Class Initialized
INFO - 2023-08-05 14:09:18 --> Helper loaded: url_helper
INFO - 2023-08-05 14:09:18 --> Helper loaded: file_helper
INFO - 2023-08-05 14:09:18 --> Helper loaded: html_helper
INFO - 2023-08-05 14:09:18 --> Helper loaded: text_helper
INFO - 2023-08-05 14:09:18 --> Helper loaded: form_helper
INFO - 2023-08-05 14:09:18 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:09:18 --> Helper loaded: security_helper
INFO - 2023-08-05 14:09:18 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:09:18 --> Database Driver Class Initialized
INFO - 2023-08-05 14:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:09:18 --> Parser Class Initialized
INFO - 2023-08-05 14:09:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:09:18 --> Pagination Class Initialized
INFO - 2023-08-05 14:09:18 --> Form Validation Class Initialized
INFO - 2023-08-05 14:09:18 --> Controller Class Initialized
INFO - 2023-08-05 14:09:18 --> Model Class Initialized
DEBUG - 2023-08-05 14:09:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-05 14:09:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:09:19 --> Config Class Initialized
INFO - 2023-08-05 14:09:19 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:09:19 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:09:19 --> Utf8 Class Initialized
INFO - 2023-08-05 14:09:19 --> URI Class Initialized
INFO - 2023-08-05 14:09:19 --> Router Class Initialized
INFO - 2023-08-05 14:09:19 --> Output Class Initialized
INFO - 2023-08-05 14:09:19 --> Security Class Initialized
DEBUG - 2023-08-05 14:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:09:19 --> Input Class Initialized
INFO - 2023-08-05 14:09:19 --> Language Class Initialized
INFO - 2023-08-05 14:09:19 --> Loader Class Initialized
INFO - 2023-08-05 14:09:19 --> Helper loaded: url_helper
INFO - 2023-08-05 14:09:19 --> Helper loaded: file_helper
INFO - 2023-08-05 14:09:19 --> Helper loaded: html_helper
INFO - 2023-08-05 14:09:19 --> Helper loaded: text_helper
INFO - 2023-08-05 14:09:19 --> Helper loaded: form_helper
INFO - 2023-08-05 14:09:19 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:09:19 --> Helper loaded: security_helper
INFO - 2023-08-05 14:09:19 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:09:19 --> Database Driver Class Initialized
INFO - 2023-08-05 14:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:09:19 --> Parser Class Initialized
INFO - 2023-08-05 14:09:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:09:19 --> Pagination Class Initialized
INFO - 2023-08-05 14:09:19 --> Form Validation Class Initialized
INFO - 2023-08-05 14:09:19 --> Controller Class Initialized
INFO - 2023-08-05 14:09:19 --> Model Class Initialized
DEBUG - 2023-08-05 14:09:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:09:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-05 14:09:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:09:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:09:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:09:19 --> Model Class Initialized
INFO - 2023-08-05 14:09:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:09:19 --> Final output sent to browser
DEBUG - 2023-08-05 14:09:19 --> Total execution time: 0.0319
ERROR - 2023-08-05 14:09:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:09:30 --> Config Class Initialized
INFO - 2023-08-05 14:09:30 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:09:30 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:09:30 --> Utf8 Class Initialized
INFO - 2023-08-05 14:09:30 --> URI Class Initialized
INFO - 2023-08-05 14:09:30 --> Router Class Initialized
INFO - 2023-08-05 14:09:30 --> Output Class Initialized
INFO - 2023-08-05 14:09:30 --> Security Class Initialized
DEBUG - 2023-08-05 14:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:09:30 --> Input Class Initialized
INFO - 2023-08-05 14:09:30 --> Language Class Initialized
INFO - 2023-08-05 14:09:30 --> Loader Class Initialized
INFO - 2023-08-05 14:09:30 --> Helper loaded: url_helper
INFO - 2023-08-05 14:09:30 --> Helper loaded: file_helper
INFO - 2023-08-05 14:09:30 --> Helper loaded: html_helper
INFO - 2023-08-05 14:09:30 --> Helper loaded: text_helper
INFO - 2023-08-05 14:09:30 --> Helper loaded: form_helper
INFO - 2023-08-05 14:09:30 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:09:30 --> Helper loaded: security_helper
INFO - 2023-08-05 14:09:30 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:09:30 --> Database Driver Class Initialized
INFO - 2023-08-05 14:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:09:30 --> Parser Class Initialized
INFO - 2023-08-05 14:09:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:09:30 --> Pagination Class Initialized
INFO - 2023-08-05 14:09:30 --> Form Validation Class Initialized
INFO - 2023-08-05 14:09:30 --> Controller Class Initialized
INFO - 2023-08-05 14:09:30 --> Model Class Initialized
DEBUG - 2023-08-05 14:09:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:09:30 --> Model Class Initialized
INFO - 2023-08-05 14:09:30 --> Final output sent to browser
DEBUG - 2023-08-05 14:09:30 --> Total execution time: 0.0181
ERROR - 2023-08-05 14:09:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:09:30 --> Config Class Initialized
INFO - 2023-08-05 14:09:30 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:09:30 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:09:30 --> Utf8 Class Initialized
INFO - 2023-08-05 14:09:30 --> URI Class Initialized
DEBUG - 2023-08-05 14:09:30 --> No URI present. Default controller set.
INFO - 2023-08-05 14:09:30 --> Router Class Initialized
INFO - 2023-08-05 14:09:30 --> Output Class Initialized
INFO - 2023-08-05 14:09:30 --> Security Class Initialized
DEBUG - 2023-08-05 14:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:09:30 --> Input Class Initialized
INFO - 2023-08-05 14:09:30 --> Language Class Initialized
INFO - 2023-08-05 14:09:30 --> Loader Class Initialized
INFO - 2023-08-05 14:09:30 --> Helper loaded: url_helper
INFO - 2023-08-05 14:09:30 --> Helper loaded: file_helper
INFO - 2023-08-05 14:09:30 --> Helper loaded: html_helper
INFO - 2023-08-05 14:09:30 --> Helper loaded: text_helper
INFO - 2023-08-05 14:09:30 --> Helper loaded: form_helper
INFO - 2023-08-05 14:09:30 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:09:30 --> Helper loaded: security_helper
INFO - 2023-08-05 14:09:30 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:09:30 --> Database Driver Class Initialized
INFO - 2023-08-05 14:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:09:30 --> Parser Class Initialized
INFO - 2023-08-05 14:09:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:09:30 --> Pagination Class Initialized
INFO - 2023-08-05 14:09:30 --> Form Validation Class Initialized
INFO - 2023-08-05 14:09:30 --> Controller Class Initialized
INFO - 2023-08-05 14:09:30 --> Model Class Initialized
DEBUG - 2023-08-05 14:09:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:09:30 --> Model Class Initialized
DEBUG - 2023-08-05 14:09:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:09:30 --> Model Class Initialized
INFO - 2023-08-05 14:09:30 --> Model Class Initialized
INFO - 2023-08-05 14:09:30 --> Model Class Initialized
INFO - 2023-08-05 14:09:30 --> Model Class Initialized
DEBUG - 2023-08-05 14:09:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:09:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:09:30 --> Model Class Initialized
INFO - 2023-08-05 14:09:30 --> Model Class Initialized
INFO - 2023-08-05 14:09:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 14:09:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:09:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:09:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:09:30 --> Model Class Initialized
INFO - 2023-08-05 14:09:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 14:09:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 14:09:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:09:30 --> Final output sent to browser
DEBUG - 2023-08-05 14:09:30 --> Total execution time: 0.0820
ERROR - 2023-08-05 14:09:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:09:44 --> Config Class Initialized
INFO - 2023-08-05 14:09:44 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:09:44 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:09:44 --> Utf8 Class Initialized
INFO - 2023-08-05 14:09:44 --> URI Class Initialized
INFO - 2023-08-05 14:09:44 --> Router Class Initialized
INFO - 2023-08-05 14:09:44 --> Output Class Initialized
INFO - 2023-08-05 14:09:44 --> Security Class Initialized
DEBUG - 2023-08-05 14:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:09:44 --> Input Class Initialized
INFO - 2023-08-05 14:09:44 --> Language Class Initialized
INFO - 2023-08-05 14:09:44 --> Loader Class Initialized
INFO - 2023-08-05 14:09:44 --> Helper loaded: url_helper
INFO - 2023-08-05 14:09:44 --> Helper loaded: file_helper
INFO - 2023-08-05 14:09:44 --> Helper loaded: html_helper
INFO - 2023-08-05 14:09:44 --> Helper loaded: text_helper
INFO - 2023-08-05 14:09:44 --> Helper loaded: form_helper
INFO - 2023-08-05 14:09:44 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:09:44 --> Helper loaded: security_helper
INFO - 2023-08-05 14:09:44 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:09:44 --> Database Driver Class Initialized
INFO - 2023-08-05 14:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:09:44 --> Parser Class Initialized
INFO - 2023-08-05 14:09:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:09:44 --> Pagination Class Initialized
INFO - 2023-08-05 14:09:44 --> Form Validation Class Initialized
INFO - 2023-08-05 14:09:44 --> Controller Class Initialized
INFO - 2023-08-05 14:09:44 --> Model Class Initialized
DEBUG - 2023-08-05 14:09:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:09:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:09:44 --> Model Class Initialized
DEBUG - 2023-08-05 14:09:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:09:44 --> Model Class Initialized
INFO - 2023-08-05 14:09:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 14:09:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:09:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:09:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:09:44 --> Model Class Initialized
INFO - 2023-08-05 14:09:44 --> Model Class Initialized
INFO - 2023-08-05 14:09:44 --> Model Class Initialized
INFO - 2023-08-05 14:09:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 14:09:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 14:09:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:09:44 --> Final output sent to browser
DEBUG - 2023-08-05 14:09:44 --> Total execution time: 0.0687
ERROR - 2023-08-05 14:09:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:09:45 --> Config Class Initialized
INFO - 2023-08-05 14:09:45 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:09:45 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:09:45 --> Utf8 Class Initialized
INFO - 2023-08-05 14:09:45 --> URI Class Initialized
INFO - 2023-08-05 14:09:45 --> Router Class Initialized
INFO - 2023-08-05 14:09:45 --> Output Class Initialized
INFO - 2023-08-05 14:09:45 --> Security Class Initialized
DEBUG - 2023-08-05 14:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:09:45 --> Input Class Initialized
INFO - 2023-08-05 14:09:45 --> Language Class Initialized
INFO - 2023-08-05 14:09:45 --> Loader Class Initialized
INFO - 2023-08-05 14:09:45 --> Helper loaded: url_helper
INFO - 2023-08-05 14:09:45 --> Helper loaded: file_helper
INFO - 2023-08-05 14:09:45 --> Helper loaded: html_helper
INFO - 2023-08-05 14:09:45 --> Helper loaded: text_helper
INFO - 2023-08-05 14:09:45 --> Helper loaded: form_helper
INFO - 2023-08-05 14:09:45 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:09:45 --> Helper loaded: security_helper
INFO - 2023-08-05 14:09:45 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:09:45 --> Database Driver Class Initialized
INFO - 2023-08-05 14:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:09:45 --> Parser Class Initialized
INFO - 2023-08-05 14:09:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:09:45 --> Pagination Class Initialized
INFO - 2023-08-05 14:09:45 --> Form Validation Class Initialized
INFO - 2023-08-05 14:09:45 --> Controller Class Initialized
INFO - 2023-08-05 14:09:45 --> Model Class Initialized
DEBUG - 2023-08-05 14:09:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:09:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:09:45 --> Model Class Initialized
DEBUG - 2023-08-05 14:09:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:09:45 --> Model Class Initialized
INFO - 2023-08-05 14:09:45 --> Final output sent to browser
DEBUG - 2023-08-05 14:09:45 --> Total execution time: 0.0233
ERROR - 2023-08-05 14:09:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:09:48 --> Config Class Initialized
INFO - 2023-08-05 14:09:48 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:09:48 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:09:48 --> Utf8 Class Initialized
INFO - 2023-08-05 14:09:48 --> URI Class Initialized
INFO - 2023-08-05 14:09:48 --> Router Class Initialized
INFO - 2023-08-05 14:09:48 --> Output Class Initialized
INFO - 2023-08-05 14:09:48 --> Security Class Initialized
DEBUG - 2023-08-05 14:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:09:48 --> Input Class Initialized
INFO - 2023-08-05 14:09:48 --> Language Class Initialized
INFO - 2023-08-05 14:09:48 --> Loader Class Initialized
INFO - 2023-08-05 14:09:48 --> Helper loaded: url_helper
INFO - 2023-08-05 14:09:48 --> Helper loaded: file_helper
INFO - 2023-08-05 14:09:48 --> Helper loaded: html_helper
INFO - 2023-08-05 14:09:48 --> Helper loaded: text_helper
INFO - 2023-08-05 14:09:48 --> Helper loaded: form_helper
INFO - 2023-08-05 14:09:48 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:09:48 --> Helper loaded: security_helper
INFO - 2023-08-05 14:09:48 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:09:48 --> Database Driver Class Initialized
INFO - 2023-08-05 14:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:09:48 --> Parser Class Initialized
INFO - 2023-08-05 14:09:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:09:48 --> Pagination Class Initialized
INFO - 2023-08-05 14:09:48 --> Form Validation Class Initialized
INFO - 2023-08-05 14:09:48 --> Controller Class Initialized
INFO - 2023-08-05 14:09:48 --> Model Class Initialized
DEBUG - 2023-08-05 14:09:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:09:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:09:48 --> Model Class Initialized
DEBUG - 2023-08-05 14:09:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:09:48 --> Model Class Initialized
DEBUG - 2023-08-05 14:09:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:09:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-05 14:09:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:09:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:09:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:09:48 --> Model Class Initialized
INFO - 2023-08-05 14:09:48 --> Model Class Initialized
INFO - 2023-08-05 14:09:48 --> Model Class Initialized
INFO - 2023-08-05 14:09:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 14:09:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 14:09:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:09:48 --> Final output sent to browser
DEBUG - 2023-08-05 14:09:48 --> Total execution time: 0.0690
ERROR - 2023-08-05 14:10:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:10:25 --> Config Class Initialized
INFO - 2023-08-05 14:10:25 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:10:25 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:10:25 --> Utf8 Class Initialized
INFO - 2023-08-05 14:10:25 --> URI Class Initialized
DEBUG - 2023-08-05 14:10:25 --> No URI present. Default controller set.
INFO - 2023-08-05 14:10:25 --> Router Class Initialized
INFO - 2023-08-05 14:10:25 --> Output Class Initialized
INFO - 2023-08-05 14:10:25 --> Security Class Initialized
DEBUG - 2023-08-05 14:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:10:25 --> Input Class Initialized
INFO - 2023-08-05 14:10:25 --> Language Class Initialized
INFO - 2023-08-05 14:10:25 --> Loader Class Initialized
INFO - 2023-08-05 14:10:25 --> Helper loaded: url_helper
INFO - 2023-08-05 14:10:25 --> Helper loaded: file_helper
INFO - 2023-08-05 14:10:25 --> Helper loaded: html_helper
INFO - 2023-08-05 14:10:25 --> Helper loaded: text_helper
INFO - 2023-08-05 14:10:25 --> Helper loaded: form_helper
INFO - 2023-08-05 14:10:25 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:10:25 --> Helper loaded: security_helper
INFO - 2023-08-05 14:10:25 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:10:25 --> Database Driver Class Initialized
INFO - 2023-08-05 14:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:10:25 --> Parser Class Initialized
INFO - 2023-08-05 14:10:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:10:25 --> Pagination Class Initialized
INFO - 2023-08-05 14:10:25 --> Form Validation Class Initialized
INFO - 2023-08-05 14:10:25 --> Controller Class Initialized
INFO - 2023-08-05 14:10:25 --> Model Class Initialized
DEBUG - 2023-08-05 14:10:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:10:25 --> Model Class Initialized
DEBUG - 2023-08-05 14:10:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:10:25 --> Model Class Initialized
INFO - 2023-08-05 14:10:25 --> Model Class Initialized
INFO - 2023-08-05 14:10:25 --> Model Class Initialized
INFO - 2023-08-05 14:10:25 --> Model Class Initialized
DEBUG - 2023-08-05 14:10:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:10:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:10:25 --> Model Class Initialized
INFO - 2023-08-05 14:10:25 --> Model Class Initialized
INFO - 2023-08-05 14:10:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 14:10:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:10:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:10:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:10:25 --> Model Class Initialized
INFO - 2023-08-05 14:10:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 14:10:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 14:10:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:10:25 --> Final output sent to browser
DEBUG - 2023-08-05 14:10:25 --> Total execution time: 0.1726
ERROR - 2023-08-05 14:10:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:10:28 --> Config Class Initialized
INFO - 2023-08-05 14:10:28 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:10:28 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:10:28 --> Utf8 Class Initialized
INFO - 2023-08-05 14:10:28 --> URI Class Initialized
INFO - 2023-08-05 14:10:28 --> Router Class Initialized
INFO - 2023-08-05 14:10:28 --> Output Class Initialized
INFO - 2023-08-05 14:10:28 --> Security Class Initialized
DEBUG - 2023-08-05 14:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:10:28 --> Input Class Initialized
INFO - 2023-08-05 14:10:28 --> Language Class Initialized
INFO - 2023-08-05 14:10:28 --> Loader Class Initialized
INFO - 2023-08-05 14:10:28 --> Helper loaded: url_helper
INFO - 2023-08-05 14:10:28 --> Helper loaded: file_helper
INFO - 2023-08-05 14:10:28 --> Helper loaded: html_helper
INFO - 2023-08-05 14:10:28 --> Helper loaded: text_helper
INFO - 2023-08-05 14:10:28 --> Helper loaded: form_helper
INFO - 2023-08-05 14:10:28 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:10:28 --> Helper loaded: security_helper
INFO - 2023-08-05 14:10:28 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:10:28 --> Database Driver Class Initialized
INFO - 2023-08-05 14:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:10:28 --> Parser Class Initialized
INFO - 2023-08-05 14:10:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:10:28 --> Pagination Class Initialized
INFO - 2023-08-05 14:10:28 --> Form Validation Class Initialized
INFO - 2023-08-05 14:10:28 --> Controller Class Initialized
INFO - 2023-08-05 14:10:28 --> Model Class Initialized
DEBUG - 2023-08-05 14:10:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:10:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:10:28 --> Model Class Initialized
DEBUG - 2023-08-05 14:10:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:10:28 --> Model Class Initialized
INFO - 2023-08-05 14:10:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 14:10:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:10:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:10:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:10:28 --> Model Class Initialized
INFO - 2023-08-05 14:10:28 --> Model Class Initialized
INFO - 2023-08-05 14:10:28 --> Model Class Initialized
INFO - 2023-08-05 14:10:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 14:10:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 14:10:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:10:28 --> Final output sent to browser
DEBUG - 2023-08-05 14:10:28 --> Total execution time: 0.1273
ERROR - 2023-08-05 14:10:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:10:29 --> Config Class Initialized
INFO - 2023-08-05 14:10:29 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:10:29 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:10:29 --> Utf8 Class Initialized
INFO - 2023-08-05 14:10:29 --> URI Class Initialized
INFO - 2023-08-05 14:10:29 --> Router Class Initialized
INFO - 2023-08-05 14:10:29 --> Output Class Initialized
INFO - 2023-08-05 14:10:29 --> Security Class Initialized
DEBUG - 2023-08-05 14:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:10:29 --> Input Class Initialized
INFO - 2023-08-05 14:10:29 --> Language Class Initialized
INFO - 2023-08-05 14:10:29 --> Loader Class Initialized
INFO - 2023-08-05 14:10:29 --> Helper loaded: url_helper
INFO - 2023-08-05 14:10:29 --> Helper loaded: file_helper
INFO - 2023-08-05 14:10:29 --> Helper loaded: html_helper
INFO - 2023-08-05 14:10:29 --> Helper loaded: text_helper
INFO - 2023-08-05 14:10:29 --> Helper loaded: form_helper
INFO - 2023-08-05 14:10:29 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:10:29 --> Helper loaded: security_helper
INFO - 2023-08-05 14:10:29 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:10:29 --> Database Driver Class Initialized
INFO - 2023-08-05 14:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:10:29 --> Parser Class Initialized
INFO - 2023-08-05 14:10:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:10:29 --> Pagination Class Initialized
INFO - 2023-08-05 14:10:29 --> Form Validation Class Initialized
INFO - 2023-08-05 14:10:29 --> Controller Class Initialized
INFO - 2023-08-05 14:10:29 --> Model Class Initialized
DEBUG - 2023-08-05 14:10:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:10:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:10:29 --> Model Class Initialized
DEBUG - 2023-08-05 14:10:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:10:29 --> Model Class Initialized
INFO - 2023-08-05 14:10:29 --> Final output sent to browser
DEBUG - 2023-08-05 14:10:29 --> Total execution time: 0.0517
ERROR - 2023-08-05 14:10:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:10:33 --> Config Class Initialized
INFO - 2023-08-05 14:10:33 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:10:33 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:10:33 --> Utf8 Class Initialized
INFO - 2023-08-05 14:10:33 --> URI Class Initialized
INFO - 2023-08-05 14:10:33 --> Router Class Initialized
INFO - 2023-08-05 14:10:33 --> Output Class Initialized
INFO - 2023-08-05 14:10:33 --> Security Class Initialized
DEBUG - 2023-08-05 14:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:10:33 --> Input Class Initialized
INFO - 2023-08-05 14:10:33 --> Language Class Initialized
INFO - 2023-08-05 14:10:33 --> Loader Class Initialized
INFO - 2023-08-05 14:10:33 --> Helper loaded: url_helper
INFO - 2023-08-05 14:10:33 --> Helper loaded: file_helper
INFO - 2023-08-05 14:10:33 --> Helper loaded: html_helper
INFO - 2023-08-05 14:10:33 --> Helper loaded: text_helper
INFO - 2023-08-05 14:10:33 --> Helper loaded: form_helper
INFO - 2023-08-05 14:10:33 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:10:33 --> Helper loaded: security_helper
INFO - 2023-08-05 14:10:33 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:10:33 --> Database Driver Class Initialized
INFO - 2023-08-05 14:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:10:33 --> Parser Class Initialized
INFO - 2023-08-05 14:10:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:10:33 --> Pagination Class Initialized
INFO - 2023-08-05 14:10:33 --> Form Validation Class Initialized
INFO - 2023-08-05 14:10:33 --> Controller Class Initialized
INFO - 2023-08-05 14:10:33 --> Model Class Initialized
DEBUG - 2023-08-05 14:10:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:10:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:10:33 --> Model Class Initialized
DEBUG - 2023-08-05 14:10:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:10:33 --> Model Class Initialized
INFO - 2023-08-05 14:10:33 --> Final output sent to browser
DEBUG - 2023-08-05 14:10:33 --> Total execution time: 0.4269
ERROR - 2023-08-05 14:10:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:10:47 --> Config Class Initialized
INFO - 2023-08-05 14:10:47 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:10:47 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:10:47 --> Utf8 Class Initialized
INFO - 2023-08-05 14:10:47 --> URI Class Initialized
DEBUG - 2023-08-05 14:10:47 --> No URI present. Default controller set.
INFO - 2023-08-05 14:10:47 --> Router Class Initialized
INFO - 2023-08-05 14:10:47 --> Output Class Initialized
INFO - 2023-08-05 14:10:47 --> Security Class Initialized
DEBUG - 2023-08-05 14:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:10:47 --> Input Class Initialized
INFO - 2023-08-05 14:10:47 --> Language Class Initialized
INFO - 2023-08-05 14:10:47 --> Loader Class Initialized
INFO - 2023-08-05 14:10:47 --> Helper loaded: url_helper
INFO - 2023-08-05 14:10:47 --> Helper loaded: file_helper
INFO - 2023-08-05 14:10:47 --> Helper loaded: html_helper
INFO - 2023-08-05 14:10:47 --> Helper loaded: text_helper
INFO - 2023-08-05 14:10:47 --> Helper loaded: form_helper
INFO - 2023-08-05 14:10:47 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:10:47 --> Helper loaded: security_helper
INFO - 2023-08-05 14:10:47 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:10:47 --> Database Driver Class Initialized
INFO - 2023-08-05 14:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:10:47 --> Parser Class Initialized
INFO - 2023-08-05 14:10:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:10:47 --> Pagination Class Initialized
INFO - 2023-08-05 14:10:47 --> Form Validation Class Initialized
INFO - 2023-08-05 14:10:47 --> Controller Class Initialized
INFO - 2023-08-05 14:10:47 --> Model Class Initialized
DEBUG - 2023-08-05 14:10:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:10:47 --> Model Class Initialized
DEBUG - 2023-08-05 14:10:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:10:47 --> Model Class Initialized
INFO - 2023-08-05 14:10:47 --> Model Class Initialized
INFO - 2023-08-05 14:10:47 --> Model Class Initialized
INFO - 2023-08-05 14:10:47 --> Model Class Initialized
DEBUG - 2023-08-05 14:10:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:10:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:10:47 --> Model Class Initialized
INFO - 2023-08-05 14:10:47 --> Model Class Initialized
INFO - 2023-08-05 14:10:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 14:10:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:10:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:10:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:10:47 --> Model Class Initialized
INFO - 2023-08-05 14:10:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 14:10:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 14:10:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:10:47 --> Final output sent to browser
DEBUG - 2023-08-05 14:10:47 --> Total execution time: 0.1881
ERROR - 2023-08-05 14:11:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:11:10 --> Config Class Initialized
INFO - 2023-08-05 14:11:10 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:11:10 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:11:10 --> Utf8 Class Initialized
INFO - 2023-08-05 14:11:10 --> URI Class Initialized
INFO - 2023-08-05 14:11:10 --> Router Class Initialized
INFO - 2023-08-05 14:11:10 --> Output Class Initialized
INFO - 2023-08-05 14:11:10 --> Security Class Initialized
DEBUG - 2023-08-05 14:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:11:10 --> Input Class Initialized
INFO - 2023-08-05 14:11:10 --> Language Class Initialized
INFO - 2023-08-05 14:11:10 --> Loader Class Initialized
INFO - 2023-08-05 14:11:10 --> Helper loaded: url_helper
INFO - 2023-08-05 14:11:10 --> Helper loaded: file_helper
INFO - 2023-08-05 14:11:10 --> Helper loaded: html_helper
INFO - 2023-08-05 14:11:10 --> Helper loaded: text_helper
INFO - 2023-08-05 14:11:10 --> Helper loaded: form_helper
INFO - 2023-08-05 14:11:10 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:11:10 --> Helper loaded: security_helper
INFO - 2023-08-05 14:11:10 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:11:10 --> Database Driver Class Initialized
INFO - 2023-08-05 14:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:11:10 --> Parser Class Initialized
INFO - 2023-08-05 14:11:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:11:10 --> Pagination Class Initialized
INFO - 2023-08-05 14:11:10 --> Form Validation Class Initialized
INFO - 2023-08-05 14:11:10 --> Controller Class Initialized
INFO - 2023-08-05 14:11:10 --> Model Class Initialized
DEBUG - 2023-08-05 14:11:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:11:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:11:10 --> Model Class Initialized
DEBUG - 2023-08-05 14:11:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:11:10 --> Model Class Initialized
INFO - 2023-08-05 14:11:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 14:11:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:11:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:11:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:11:11 --> Model Class Initialized
INFO - 2023-08-05 14:11:11 --> Model Class Initialized
INFO - 2023-08-05 14:11:11 --> Model Class Initialized
INFO - 2023-08-05 14:11:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 14:11:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 14:11:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:11:11 --> Final output sent to browser
DEBUG - 2023-08-05 14:11:11 --> Total execution time: 0.1664
ERROR - 2023-08-05 14:11:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:11:11 --> Config Class Initialized
INFO - 2023-08-05 14:11:11 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:11:11 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:11:11 --> Utf8 Class Initialized
INFO - 2023-08-05 14:11:11 --> URI Class Initialized
INFO - 2023-08-05 14:11:11 --> Router Class Initialized
INFO - 2023-08-05 14:11:11 --> Output Class Initialized
INFO - 2023-08-05 14:11:11 --> Security Class Initialized
DEBUG - 2023-08-05 14:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:11:11 --> Input Class Initialized
INFO - 2023-08-05 14:11:11 --> Language Class Initialized
INFO - 2023-08-05 14:11:11 --> Loader Class Initialized
INFO - 2023-08-05 14:11:11 --> Helper loaded: url_helper
INFO - 2023-08-05 14:11:11 --> Helper loaded: file_helper
INFO - 2023-08-05 14:11:11 --> Helper loaded: html_helper
INFO - 2023-08-05 14:11:11 --> Helper loaded: text_helper
INFO - 2023-08-05 14:11:11 --> Helper loaded: form_helper
INFO - 2023-08-05 14:11:11 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:11:11 --> Helper loaded: security_helper
INFO - 2023-08-05 14:11:11 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:11:11 --> Database Driver Class Initialized
INFO - 2023-08-05 14:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:11:11 --> Parser Class Initialized
INFO - 2023-08-05 14:11:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:11:11 --> Pagination Class Initialized
INFO - 2023-08-05 14:11:11 --> Form Validation Class Initialized
INFO - 2023-08-05 14:11:11 --> Controller Class Initialized
INFO - 2023-08-05 14:11:11 --> Model Class Initialized
DEBUG - 2023-08-05 14:11:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:11:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:11:11 --> Model Class Initialized
DEBUG - 2023-08-05 14:11:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:11:11 --> Model Class Initialized
INFO - 2023-08-05 14:11:11 --> Final output sent to browser
DEBUG - 2023-08-05 14:11:11 --> Total execution time: 0.0626
ERROR - 2023-08-05 14:11:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:11:15 --> Config Class Initialized
INFO - 2023-08-05 14:11:15 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:11:15 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:11:15 --> Utf8 Class Initialized
INFO - 2023-08-05 14:11:15 --> URI Class Initialized
INFO - 2023-08-05 14:11:15 --> Router Class Initialized
INFO - 2023-08-05 14:11:15 --> Output Class Initialized
INFO - 2023-08-05 14:11:15 --> Security Class Initialized
DEBUG - 2023-08-05 14:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:11:15 --> Input Class Initialized
INFO - 2023-08-05 14:11:15 --> Language Class Initialized
INFO - 2023-08-05 14:11:15 --> Loader Class Initialized
INFO - 2023-08-05 14:11:15 --> Helper loaded: url_helper
INFO - 2023-08-05 14:11:15 --> Helper loaded: file_helper
INFO - 2023-08-05 14:11:15 --> Helper loaded: html_helper
INFO - 2023-08-05 14:11:15 --> Helper loaded: text_helper
INFO - 2023-08-05 14:11:15 --> Helper loaded: form_helper
INFO - 2023-08-05 14:11:15 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:11:15 --> Helper loaded: security_helper
INFO - 2023-08-05 14:11:15 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:11:15 --> Database Driver Class Initialized
INFO - 2023-08-05 14:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:11:15 --> Parser Class Initialized
INFO - 2023-08-05 14:11:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:11:15 --> Pagination Class Initialized
INFO - 2023-08-05 14:11:15 --> Form Validation Class Initialized
INFO - 2023-08-05 14:11:15 --> Controller Class Initialized
INFO - 2023-08-05 14:11:15 --> Model Class Initialized
DEBUG - 2023-08-05 14:11:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:11:15 --> Model Class Initialized
DEBUG - 2023-08-05 14:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:11:15 --> Model Class Initialized
INFO - 2023-08-05 14:11:15 --> Final output sent to browser
DEBUG - 2023-08-05 14:11:15 --> Total execution time: 0.4551
ERROR - 2023-08-05 14:11:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:11:23 --> Config Class Initialized
INFO - 2023-08-05 14:11:23 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:11:23 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:11:23 --> Utf8 Class Initialized
INFO - 2023-08-05 14:11:23 --> URI Class Initialized
DEBUG - 2023-08-05 14:11:23 --> No URI present. Default controller set.
INFO - 2023-08-05 14:11:23 --> Router Class Initialized
INFO - 2023-08-05 14:11:23 --> Output Class Initialized
INFO - 2023-08-05 14:11:23 --> Security Class Initialized
DEBUG - 2023-08-05 14:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:11:23 --> Input Class Initialized
INFO - 2023-08-05 14:11:23 --> Language Class Initialized
INFO - 2023-08-05 14:11:23 --> Loader Class Initialized
INFO - 2023-08-05 14:11:23 --> Helper loaded: url_helper
INFO - 2023-08-05 14:11:23 --> Helper loaded: file_helper
INFO - 2023-08-05 14:11:23 --> Helper loaded: html_helper
INFO - 2023-08-05 14:11:23 --> Helper loaded: text_helper
INFO - 2023-08-05 14:11:23 --> Helper loaded: form_helper
INFO - 2023-08-05 14:11:23 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:11:23 --> Helper loaded: security_helper
INFO - 2023-08-05 14:11:23 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:11:23 --> Database Driver Class Initialized
INFO - 2023-08-05 14:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:11:23 --> Parser Class Initialized
INFO - 2023-08-05 14:11:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:11:23 --> Pagination Class Initialized
INFO - 2023-08-05 14:11:23 --> Form Validation Class Initialized
INFO - 2023-08-05 14:11:23 --> Controller Class Initialized
INFO - 2023-08-05 14:11:23 --> Model Class Initialized
DEBUG - 2023-08-05 14:11:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:11:23 --> Model Class Initialized
DEBUG - 2023-08-05 14:11:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:11:23 --> Model Class Initialized
INFO - 2023-08-05 14:11:23 --> Model Class Initialized
INFO - 2023-08-05 14:11:23 --> Model Class Initialized
INFO - 2023-08-05 14:11:23 --> Model Class Initialized
DEBUG - 2023-08-05 14:11:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:11:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:11:23 --> Model Class Initialized
INFO - 2023-08-05 14:11:23 --> Model Class Initialized
INFO - 2023-08-05 14:11:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 14:11:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:11:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:11:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:11:23 --> Model Class Initialized
INFO - 2023-08-05 14:11:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 14:11:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 14:11:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:11:23 --> Final output sent to browser
DEBUG - 2023-08-05 14:11:23 --> Total execution time: 0.1674
ERROR - 2023-08-05 14:11:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:11:52 --> Config Class Initialized
INFO - 2023-08-05 14:11:52 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:11:52 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:11:52 --> Utf8 Class Initialized
INFO - 2023-08-05 14:11:52 --> URI Class Initialized
INFO - 2023-08-05 14:11:52 --> Router Class Initialized
INFO - 2023-08-05 14:11:52 --> Output Class Initialized
INFO - 2023-08-05 14:11:52 --> Security Class Initialized
DEBUG - 2023-08-05 14:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:11:52 --> Input Class Initialized
INFO - 2023-08-05 14:11:52 --> Language Class Initialized
INFO - 2023-08-05 14:11:52 --> Loader Class Initialized
INFO - 2023-08-05 14:11:52 --> Helper loaded: url_helper
INFO - 2023-08-05 14:11:52 --> Helper loaded: file_helper
INFO - 2023-08-05 14:11:52 --> Helper loaded: html_helper
INFO - 2023-08-05 14:11:52 --> Helper loaded: text_helper
INFO - 2023-08-05 14:11:52 --> Helper loaded: form_helper
INFO - 2023-08-05 14:11:52 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:11:52 --> Helper loaded: security_helper
INFO - 2023-08-05 14:11:52 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:11:52 --> Database Driver Class Initialized
INFO - 2023-08-05 14:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:11:52 --> Parser Class Initialized
INFO - 2023-08-05 14:11:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:11:52 --> Pagination Class Initialized
INFO - 2023-08-05 14:11:52 --> Form Validation Class Initialized
INFO - 2023-08-05 14:11:52 --> Controller Class Initialized
INFO - 2023-08-05 14:11:52 --> Model Class Initialized
DEBUG - 2023-08-05 14:11:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:11:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:11:52 --> Model Class Initialized
DEBUG - 2023-08-05 14:11:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:11:52 --> Model Class Initialized
INFO - 2023-08-05 14:11:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 14:11:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:11:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:11:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:11:52 --> Model Class Initialized
INFO - 2023-08-05 14:11:52 --> Model Class Initialized
INFO - 2023-08-05 14:11:52 --> Model Class Initialized
INFO - 2023-08-05 14:11:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 14:11:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 14:11:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:11:52 --> Final output sent to browser
DEBUG - 2023-08-05 14:11:52 --> Total execution time: 0.1518
ERROR - 2023-08-05 14:11:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:11:52 --> Config Class Initialized
INFO - 2023-08-05 14:11:52 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:11:52 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:11:52 --> Utf8 Class Initialized
INFO - 2023-08-05 14:11:52 --> URI Class Initialized
INFO - 2023-08-05 14:11:52 --> Router Class Initialized
INFO - 2023-08-05 14:11:52 --> Output Class Initialized
INFO - 2023-08-05 14:11:52 --> Security Class Initialized
DEBUG - 2023-08-05 14:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:11:52 --> Input Class Initialized
INFO - 2023-08-05 14:11:52 --> Language Class Initialized
INFO - 2023-08-05 14:11:52 --> Loader Class Initialized
INFO - 2023-08-05 14:11:52 --> Helper loaded: url_helper
INFO - 2023-08-05 14:11:52 --> Helper loaded: file_helper
INFO - 2023-08-05 14:11:52 --> Helper loaded: html_helper
INFO - 2023-08-05 14:11:52 --> Helper loaded: text_helper
INFO - 2023-08-05 14:11:52 --> Helper loaded: form_helper
INFO - 2023-08-05 14:11:52 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:11:52 --> Helper loaded: security_helper
INFO - 2023-08-05 14:11:52 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:11:52 --> Database Driver Class Initialized
INFO - 2023-08-05 14:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:11:52 --> Parser Class Initialized
INFO - 2023-08-05 14:11:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:11:52 --> Pagination Class Initialized
INFO - 2023-08-05 14:11:52 --> Form Validation Class Initialized
INFO - 2023-08-05 14:11:52 --> Controller Class Initialized
INFO - 2023-08-05 14:11:52 --> Model Class Initialized
DEBUG - 2023-08-05 14:11:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:11:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:11:52 --> Model Class Initialized
DEBUG - 2023-08-05 14:11:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:11:52 --> Model Class Initialized
INFO - 2023-08-05 14:11:52 --> Final output sent to browser
DEBUG - 2023-08-05 14:11:52 --> Total execution time: 0.0549
ERROR - 2023-08-05 14:11:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:11:56 --> Config Class Initialized
INFO - 2023-08-05 14:11:56 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:11:56 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:11:56 --> Utf8 Class Initialized
INFO - 2023-08-05 14:11:56 --> URI Class Initialized
INFO - 2023-08-05 14:11:56 --> Router Class Initialized
INFO - 2023-08-05 14:11:56 --> Output Class Initialized
INFO - 2023-08-05 14:11:56 --> Security Class Initialized
DEBUG - 2023-08-05 14:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:11:56 --> Input Class Initialized
INFO - 2023-08-05 14:11:56 --> Language Class Initialized
INFO - 2023-08-05 14:11:56 --> Loader Class Initialized
INFO - 2023-08-05 14:11:56 --> Helper loaded: url_helper
INFO - 2023-08-05 14:11:56 --> Helper loaded: file_helper
INFO - 2023-08-05 14:11:56 --> Helper loaded: html_helper
INFO - 2023-08-05 14:11:56 --> Helper loaded: text_helper
INFO - 2023-08-05 14:11:56 --> Helper loaded: form_helper
INFO - 2023-08-05 14:11:56 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:11:56 --> Helper loaded: security_helper
INFO - 2023-08-05 14:11:56 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:11:56 --> Database Driver Class Initialized
INFO - 2023-08-05 14:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:11:56 --> Parser Class Initialized
INFO - 2023-08-05 14:11:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:11:56 --> Pagination Class Initialized
INFO - 2023-08-05 14:11:56 --> Form Validation Class Initialized
INFO - 2023-08-05 14:11:56 --> Controller Class Initialized
INFO - 2023-08-05 14:11:56 --> Model Class Initialized
DEBUG - 2023-08-05 14:11:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:11:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:11:56 --> Model Class Initialized
DEBUG - 2023-08-05 14:11:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:11:56 --> Model Class Initialized
INFO - 2023-08-05 14:11:56 --> Final output sent to browser
DEBUG - 2023-08-05 14:11:56 --> Total execution time: 0.4407
ERROR - 2023-08-05 14:15:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 14:15:58 --> Config Class Initialized
INFO - 2023-08-05 14:15:58 --> Hooks Class Initialized
DEBUG - 2023-08-05 14:15:58 --> UTF-8 Support Enabled
INFO - 2023-08-05 14:15:58 --> Utf8 Class Initialized
INFO - 2023-08-05 14:15:58 --> URI Class Initialized
DEBUG - 2023-08-05 14:15:58 --> No URI present. Default controller set.
INFO - 2023-08-05 14:15:58 --> Router Class Initialized
INFO - 2023-08-05 14:15:58 --> Output Class Initialized
INFO - 2023-08-05 14:15:58 --> Security Class Initialized
DEBUG - 2023-08-05 14:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 14:15:58 --> Input Class Initialized
INFO - 2023-08-05 14:15:58 --> Language Class Initialized
INFO - 2023-08-05 14:15:58 --> Loader Class Initialized
INFO - 2023-08-05 14:15:58 --> Helper loaded: url_helper
INFO - 2023-08-05 14:15:58 --> Helper loaded: file_helper
INFO - 2023-08-05 14:15:58 --> Helper loaded: html_helper
INFO - 2023-08-05 14:15:58 --> Helper loaded: text_helper
INFO - 2023-08-05 14:15:58 --> Helper loaded: form_helper
INFO - 2023-08-05 14:15:58 --> Helper loaded: lang_helper
INFO - 2023-08-05 14:15:58 --> Helper loaded: security_helper
INFO - 2023-08-05 14:15:58 --> Helper loaded: cookie_helper
INFO - 2023-08-05 14:15:58 --> Database Driver Class Initialized
INFO - 2023-08-05 14:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 14:15:58 --> Parser Class Initialized
INFO - 2023-08-05 14:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 14:15:58 --> Pagination Class Initialized
INFO - 2023-08-05 14:15:58 --> Form Validation Class Initialized
INFO - 2023-08-05 14:15:58 --> Controller Class Initialized
INFO - 2023-08-05 14:15:58 --> Model Class Initialized
DEBUG - 2023-08-05 14:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:15:58 --> Model Class Initialized
DEBUG - 2023-08-05 14:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:15:58 --> Model Class Initialized
INFO - 2023-08-05 14:15:58 --> Model Class Initialized
INFO - 2023-08-05 14:15:58 --> Model Class Initialized
INFO - 2023-08-05 14:15:58 --> Model Class Initialized
DEBUG - 2023-08-05 14:15:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 14:15:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:15:58 --> Model Class Initialized
INFO - 2023-08-05 14:15:58 --> Model Class Initialized
INFO - 2023-08-05 14:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 14:15:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 14:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 14:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 14:15:58 --> Model Class Initialized
INFO - 2023-08-05 14:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 14:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 14:15:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 14:15:58 --> Final output sent to browser
DEBUG - 2023-08-05 14:15:58 --> Total execution time: 0.0938
ERROR - 2023-08-05 15:41:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 15:41:41 --> Config Class Initialized
INFO - 2023-08-05 15:41:41 --> Hooks Class Initialized
DEBUG - 2023-08-05 15:41:41 --> UTF-8 Support Enabled
INFO - 2023-08-05 15:41:41 --> Utf8 Class Initialized
INFO - 2023-08-05 15:41:41 --> URI Class Initialized
INFO - 2023-08-05 15:41:41 --> Router Class Initialized
INFO - 2023-08-05 15:41:41 --> Output Class Initialized
INFO - 2023-08-05 15:41:41 --> Security Class Initialized
DEBUG - 2023-08-05 15:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 15:41:41 --> Input Class Initialized
INFO - 2023-08-05 15:41:41 --> Language Class Initialized
INFO - 2023-08-05 15:41:41 --> Loader Class Initialized
INFO - 2023-08-05 15:41:41 --> Helper loaded: url_helper
INFO - 2023-08-05 15:41:41 --> Helper loaded: file_helper
INFO - 2023-08-05 15:41:41 --> Helper loaded: html_helper
INFO - 2023-08-05 15:41:41 --> Helper loaded: text_helper
INFO - 2023-08-05 15:41:41 --> Helper loaded: form_helper
INFO - 2023-08-05 15:41:41 --> Helper loaded: lang_helper
INFO - 2023-08-05 15:41:41 --> Helper loaded: security_helper
INFO - 2023-08-05 15:41:41 --> Helper loaded: cookie_helper
INFO - 2023-08-05 15:41:41 --> Database Driver Class Initialized
INFO - 2023-08-05 15:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 15:41:41 --> Parser Class Initialized
INFO - 2023-08-05 15:41:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 15:41:41 --> Pagination Class Initialized
INFO - 2023-08-05 15:41:41 --> Form Validation Class Initialized
INFO - 2023-08-05 15:41:41 --> Controller Class Initialized
INFO - 2023-08-05 15:41:41 --> Model Class Initialized
DEBUG - 2023-08-05 15:41:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 15:41:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 15:41:41 --> Model Class Initialized
DEBUG - 2023-08-05 15:41:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 15:41:41 --> Model Class Initialized
DEBUG - 2023-08-05 15:41:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 15:41:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-08-05 15:41:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 15:41:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 15:41:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 15:41:41 --> Model Class Initialized
INFO - 2023-08-05 15:41:41 --> Model Class Initialized
INFO - 2023-08-05 15:41:41 --> Model Class Initialized
INFO - 2023-08-05 15:41:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 15:41:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 15:41:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 15:41:41 --> Final output sent to browser
DEBUG - 2023-08-05 15:41:41 --> Total execution time: 0.1524
ERROR - 2023-08-05 15:41:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 15:41:46 --> Config Class Initialized
INFO - 2023-08-05 15:41:46 --> Hooks Class Initialized
DEBUG - 2023-08-05 15:41:46 --> UTF-8 Support Enabled
INFO - 2023-08-05 15:41:46 --> Utf8 Class Initialized
INFO - 2023-08-05 15:41:46 --> URI Class Initialized
INFO - 2023-08-05 15:41:46 --> Router Class Initialized
INFO - 2023-08-05 15:41:46 --> Output Class Initialized
INFO - 2023-08-05 15:41:46 --> Security Class Initialized
DEBUG - 2023-08-05 15:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 15:41:46 --> Input Class Initialized
INFO - 2023-08-05 15:41:46 --> Language Class Initialized
INFO - 2023-08-05 15:41:46 --> Loader Class Initialized
INFO - 2023-08-05 15:41:46 --> Helper loaded: url_helper
INFO - 2023-08-05 15:41:46 --> Helper loaded: file_helper
INFO - 2023-08-05 15:41:46 --> Helper loaded: html_helper
INFO - 2023-08-05 15:41:46 --> Helper loaded: text_helper
INFO - 2023-08-05 15:41:46 --> Helper loaded: form_helper
INFO - 2023-08-05 15:41:46 --> Helper loaded: lang_helper
INFO - 2023-08-05 15:41:46 --> Helper loaded: security_helper
INFO - 2023-08-05 15:41:46 --> Helper loaded: cookie_helper
INFO - 2023-08-05 15:41:46 --> Database Driver Class Initialized
INFO - 2023-08-05 15:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 15:41:46 --> Parser Class Initialized
INFO - 2023-08-05 15:41:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 15:41:46 --> Pagination Class Initialized
INFO - 2023-08-05 15:41:46 --> Form Validation Class Initialized
INFO - 2023-08-05 15:41:46 --> Controller Class Initialized
INFO - 2023-08-05 15:41:46 --> Model Class Initialized
DEBUG - 2023-08-05 15:41:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 15:41:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 15:41:46 --> Model Class Initialized
DEBUG - 2023-08-05 15:41:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 15:41:46 --> Model Class Initialized
INFO - 2023-08-05 15:41:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 15:41:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 15:41:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 15:41:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 15:41:46 --> Model Class Initialized
INFO - 2023-08-05 15:41:46 --> Model Class Initialized
INFO - 2023-08-05 15:41:46 --> Model Class Initialized
INFO - 2023-08-05 15:41:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 15:41:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 15:41:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 15:41:46 --> Final output sent to browser
DEBUG - 2023-08-05 15:41:46 --> Total execution time: 0.1384
ERROR - 2023-08-05 15:41:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 15:41:47 --> Config Class Initialized
INFO - 2023-08-05 15:41:47 --> Hooks Class Initialized
DEBUG - 2023-08-05 15:41:47 --> UTF-8 Support Enabled
INFO - 2023-08-05 15:41:47 --> Utf8 Class Initialized
INFO - 2023-08-05 15:41:47 --> URI Class Initialized
INFO - 2023-08-05 15:41:47 --> Router Class Initialized
INFO - 2023-08-05 15:41:47 --> Output Class Initialized
INFO - 2023-08-05 15:41:47 --> Security Class Initialized
DEBUG - 2023-08-05 15:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 15:41:47 --> Input Class Initialized
INFO - 2023-08-05 15:41:47 --> Language Class Initialized
INFO - 2023-08-05 15:41:47 --> Loader Class Initialized
INFO - 2023-08-05 15:41:47 --> Helper loaded: url_helper
INFO - 2023-08-05 15:41:47 --> Helper loaded: file_helper
INFO - 2023-08-05 15:41:47 --> Helper loaded: html_helper
INFO - 2023-08-05 15:41:47 --> Helper loaded: text_helper
INFO - 2023-08-05 15:41:47 --> Helper loaded: form_helper
INFO - 2023-08-05 15:41:47 --> Helper loaded: lang_helper
INFO - 2023-08-05 15:41:47 --> Helper loaded: security_helper
INFO - 2023-08-05 15:41:47 --> Helper loaded: cookie_helper
INFO - 2023-08-05 15:41:47 --> Database Driver Class Initialized
INFO - 2023-08-05 15:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 15:41:47 --> Parser Class Initialized
INFO - 2023-08-05 15:41:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 15:41:47 --> Pagination Class Initialized
INFO - 2023-08-05 15:41:47 --> Form Validation Class Initialized
INFO - 2023-08-05 15:41:47 --> Controller Class Initialized
INFO - 2023-08-05 15:41:47 --> Model Class Initialized
DEBUG - 2023-08-05 15:41:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 15:41:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 15:41:47 --> Model Class Initialized
DEBUG - 2023-08-05 15:41:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 15:41:47 --> Model Class Initialized
INFO - 2023-08-05 15:41:47 --> Final output sent to browser
DEBUG - 2023-08-05 15:41:47 --> Total execution time: 0.0545
ERROR - 2023-08-05 15:41:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 15:41:51 --> Config Class Initialized
INFO - 2023-08-05 15:41:51 --> Hooks Class Initialized
DEBUG - 2023-08-05 15:41:51 --> UTF-8 Support Enabled
INFO - 2023-08-05 15:41:51 --> Utf8 Class Initialized
INFO - 2023-08-05 15:41:51 --> URI Class Initialized
INFO - 2023-08-05 15:41:51 --> Router Class Initialized
INFO - 2023-08-05 15:41:51 --> Output Class Initialized
INFO - 2023-08-05 15:41:51 --> Security Class Initialized
DEBUG - 2023-08-05 15:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 15:41:51 --> Input Class Initialized
INFO - 2023-08-05 15:41:51 --> Language Class Initialized
INFO - 2023-08-05 15:41:51 --> Loader Class Initialized
INFO - 2023-08-05 15:41:51 --> Helper loaded: url_helper
INFO - 2023-08-05 15:41:51 --> Helper loaded: file_helper
INFO - 2023-08-05 15:41:51 --> Helper loaded: html_helper
INFO - 2023-08-05 15:41:51 --> Helper loaded: text_helper
INFO - 2023-08-05 15:41:51 --> Helper loaded: form_helper
INFO - 2023-08-05 15:41:51 --> Helper loaded: lang_helper
INFO - 2023-08-05 15:41:51 --> Helper loaded: security_helper
INFO - 2023-08-05 15:41:51 --> Helper loaded: cookie_helper
INFO - 2023-08-05 15:41:51 --> Database Driver Class Initialized
INFO - 2023-08-05 15:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 15:41:51 --> Parser Class Initialized
INFO - 2023-08-05 15:41:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 15:41:51 --> Pagination Class Initialized
INFO - 2023-08-05 15:41:51 --> Form Validation Class Initialized
INFO - 2023-08-05 15:41:51 --> Controller Class Initialized
INFO - 2023-08-05 15:41:51 --> Model Class Initialized
DEBUG - 2023-08-05 15:41:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 15:41:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 15:41:51 --> Model Class Initialized
DEBUG - 2023-08-05 15:41:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 15:41:51 --> Model Class Initialized
INFO - 2023-08-05 15:41:51 --> Final output sent to browser
DEBUG - 2023-08-05 15:41:51 --> Total execution time: 0.3979
ERROR - 2023-08-05 15:42:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 15:42:05 --> Config Class Initialized
INFO - 2023-08-05 15:42:05 --> Hooks Class Initialized
DEBUG - 2023-08-05 15:42:05 --> UTF-8 Support Enabled
INFO - 2023-08-05 15:42:05 --> Utf8 Class Initialized
INFO - 2023-08-05 15:42:05 --> URI Class Initialized
DEBUG - 2023-08-05 15:42:05 --> No URI present. Default controller set.
INFO - 2023-08-05 15:42:05 --> Router Class Initialized
INFO - 2023-08-05 15:42:05 --> Output Class Initialized
INFO - 2023-08-05 15:42:05 --> Security Class Initialized
DEBUG - 2023-08-05 15:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 15:42:05 --> Input Class Initialized
INFO - 2023-08-05 15:42:05 --> Language Class Initialized
INFO - 2023-08-05 15:42:05 --> Loader Class Initialized
INFO - 2023-08-05 15:42:05 --> Helper loaded: url_helper
INFO - 2023-08-05 15:42:05 --> Helper loaded: file_helper
INFO - 2023-08-05 15:42:05 --> Helper loaded: html_helper
INFO - 2023-08-05 15:42:05 --> Helper loaded: text_helper
INFO - 2023-08-05 15:42:05 --> Helper loaded: form_helper
INFO - 2023-08-05 15:42:05 --> Helper loaded: lang_helper
INFO - 2023-08-05 15:42:05 --> Helper loaded: security_helper
INFO - 2023-08-05 15:42:05 --> Helper loaded: cookie_helper
INFO - 2023-08-05 15:42:05 --> Database Driver Class Initialized
INFO - 2023-08-05 15:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 15:42:05 --> Parser Class Initialized
INFO - 2023-08-05 15:42:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 15:42:05 --> Pagination Class Initialized
INFO - 2023-08-05 15:42:05 --> Form Validation Class Initialized
INFO - 2023-08-05 15:42:05 --> Controller Class Initialized
INFO - 2023-08-05 15:42:05 --> Model Class Initialized
DEBUG - 2023-08-05 15:42:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 15:42:05 --> Model Class Initialized
DEBUG - 2023-08-05 15:42:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 15:42:05 --> Model Class Initialized
INFO - 2023-08-05 15:42:05 --> Model Class Initialized
INFO - 2023-08-05 15:42:05 --> Model Class Initialized
INFO - 2023-08-05 15:42:05 --> Model Class Initialized
DEBUG - 2023-08-05 15:42:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 15:42:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 15:42:05 --> Model Class Initialized
INFO - 2023-08-05 15:42:05 --> Model Class Initialized
INFO - 2023-08-05 15:42:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 15:42:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 15:42:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 15:42:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 15:42:05 --> Model Class Initialized
INFO - 2023-08-05 15:42:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 15:42:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 15:42:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 15:42:05 --> Final output sent to browser
DEBUG - 2023-08-05 15:42:05 --> Total execution time: 0.1774
ERROR - 2023-08-05 15:55:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 15:55:46 --> Config Class Initialized
INFO - 2023-08-05 15:55:46 --> Hooks Class Initialized
DEBUG - 2023-08-05 15:55:46 --> UTF-8 Support Enabled
INFO - 2023-08-05 15:55:46 --> Utf8 Class Initialized
INFO - 2023-08-05 15:55:46 --> URI Class Initialized
DEBUG - 2023-08-05 15:55:46 --> No URI present. Default controller set.
INFO - 2023-08-05 15:55:46 --> Router Class Initialized
INFO - 2023-08-05 15:55:46 --> Output Class Initialized
INFO - 2023-08-05 15:55:46 --> Security Class Initialized
DEBUG - 2023-08-05 15:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 15:55:46 --> Input Class Initialized
INFO - 2023-08-05 15:55:46 --> Language Class Initialized
INFO - 2023-08-05 15:55:46 --> Loader Class Initialized
INFO - 2023-08-05 15:55:46 --> Helper loaded: url_helper
INFO - 2023-08-05 15:55:46 --> Helper loaded: file_helper
INFO - 2023-08-05 15:55:46 --> Helper loaded: html_helper
INFO - 2023-08-05 15:55:46 --> Helper loaded: text_helper
INFO - 2023-08-05 15:55:46 --> Helper loaded: form_helper
INFO - 2023-08-05 15:55:46 --> Helper loaded: lang_helper
INFO - 2023-08-05 15:55:46 --> Helper loaded: security_helper
INFO - 2023-08-05 15:55:46 --> Helper loaded: cookie_helper
INFO - 2023-08-05 15:55:46 --> Database Driver Class Initialized
INFO - 2023-08-05 15:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 15:55:46 --> Parser Class Initialized
INFO - 2023-08-05 15:55:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 15:55:46 --> Pagination Class Initialized
INFO - 2023-08-05 15:55:46 --> Form Validation Class Initialized
INFO - 2023-08-05 15:55:46 --> Controller Class Initialized
INFO - 2023-08-05 15:55:46 --> Model Class Initialized
DEBUG - 2023-08-05 15:55:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 15:55:46 --> Model Class Initialized
DEBUG - 2023-08-05 15:55:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 15:55:46 --> Model Class Initialized
INFO - 2023-08-05 15:55:46 --> Model Class Initialized
INFO - 2023-08-05 15:55:46 --> Model Class Initialized
INFO - 2023-08-05 15:55:46 --> Model Class Initialized
DEBUG - 2023-08-05 15:55:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 15:55:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 15:55:46 --> Model Class Initialized
INFO - 2023-08-05 15:55:46 --> Model Class Initialized
INFO - 2023-08-05 15:55:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-05 15:55:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 15:55:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 15:55:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 15:55:46 --> Model Class Initialized
INFO - 2023-08-05 15:55:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 15:55:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 15:55:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 15:55:46 --> Final output sent to browser
DEBUG - 2023-08-05 15:55:46 --> Total execution time: 0.0872
ERROR - 2023-08-05 16:03:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 16:03:07 --> Config Class Initialized
INFO - 2023-08-05 16:03:07 --> Hooks Class Initialized
DEBUG - 2023-08-05 16:03:07 --> UTF-8 Support Enabled
INFO - 2023-08-05 16:03:07 --> Utf8 Class Initialized
INFO - 2023-08-05 16:03:07 --> URI Class Initialized
INFO - 2023-08-05 16:03:07 --> Router Class Initialized
INFO - 2023-08-05 16:03:07 --> Output Class Initialized
INFO - 2023-08-05 16:03:07 --> Security Class Initialized
DEBUG - 2023-08-05 16:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 16:03:07 --> Input Class Initialized
INFO - 2023-08-05 16:03:07 --> Language Class Initialized
INFO - 2023-08-05 16:03:07 --> Loader Class Initialized
INFO - 2023-08-05 16:03:07 --> Helper loaded: url_helper
INFO - 2023-08-05 16:03:07 --> Helper loaded: file_helper
INFO - 2023-08-05 16:03:07 --> Helper loaded: html_helper
INFO - 2023-08-05 16:03:07 --> Helper loaded: text_helper
INFO - 2023-08-05 16:03:07 --> Helper loaded: form_helper
INFO - 2023-08-05 16:03:07 --> Helper loaded: lang_helper
INFO - 2023-08-05 16:03:07 --> Helper loaded: security_helper
INFO - 2023-08-05 16:03:07 --> Helper loaded: cookie_helper
INFO - 2023-08-05 16:03:07 --> Database Driver Class Initialized
INFO - 2023-08-05 16:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 16:03:07 --> Parser Class Initialized
INFO - 2023-08-05 16:03:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 16:03:07 --> Pagination Class Initialized
INFO - 2023-08-05 16:03:07 --> Form Validation Class Initialized
INFO - 2023-08-05 16:03:07 --> Controller Class Initialized
INFO - 2023-08-05 16:03:07 --> Model Class Initialized
DEBUG - 2023-08-05 16:03:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 16:03:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 16:03:07 --> Model Class Initialized
DEBUG - 2023-08-05 16:03:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 16:03:07 --> Model Class Initialized
INFO - 2023-08-05 16:03:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-05 16:03:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-05 16:03:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-05 16:03:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-05 16:03:07 --> Model Class Initialized
INFO - 2023-08-05 16:03:07 --> Model Class Initialized
INFO - 2023-08-05 16:03:07 --> Model Class Initialized
INFO - 2023-08-05 16:03:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-05 16:03:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-05 16:03:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-05 16:03:07 --> Final output sent to browser
DEBUG - 2023-08-05 16:03:07 --> Total execution time: 0.0824
ERROR - 2023-08-05 16:03:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-05 16:03:08 --> Config Class Initialized
INFO - 2023-08-05 16:03:08 --> Hooks Class Initialized
DEBUG - 2023-08-05 16:03:08 --> UTF-8 Support Enabled
INFO - 2023-08-05 16:03:08 --> Utf8 Class Initialized
INFO - 2023-08-05 16:03:08 --> URI Class Initialized
INFO - 2023-08-05 16:03:08 --> Router Class Initialized
INFO - 2023-08-05 16:03:08 --> Output Class Initialized
INFO - 2023-08-05 16:03:08 --> Security Class Initialized
DEBUG - 2023-08-05 16:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-05 16:03:08 --> Input Class Initialized
INFO - 2023-08-05 16:03:08 --> Language Class Initialized
INFO - 2023-08-05 16:03:08 --> Loader Class Initialized
INFO - 2023-08-05 16:03:08 --> Helper loaded: url_helper
INFO - 2023-08-05 16:03:08 --> Helper loaded: file_helper
INFO - 2023-08-05 16:03:08 --> Helper loaded: html_helper
INFO - 2023-08-05 16:03:08 --> Helper loaded: text_helper
INFO - 2023-08-05 16:03:08 --> Helper loaded: form_helper
INFO - 2023-08-05 16:03:08 --> Helper loaded: lang_helper
INFO - 2023-08-05 16:03:08 --> Helper loaded: security_helper
INFO - 2023-08-05 16:03:08 --> Helper loaded: cookie_helper
INFO - 2023-08-05 16:03:08 --> Database Driver Class Initialized
INFO - 2023-08-05 16:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-05 16:03:08 --> Parser Class Initialized
INFO - 2023-08-05 16:03:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-05 16:03:08 --> Pagination Class Initialized
INFO - 2023-08-05 16:03:08 --> Form Validation Class Initialized
INFO - 2023-08-05 16:03:08 --> Controller Class Initialized
INFO - 2023-08-05 16:03:08 --> Model Class Initialized
DEBUG - 2023-08-05 16:03:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-05 16:03:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 16:03:08 --> Model Class Initialized
DEBUG - 2023-08-05 16:03:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-05 16:03:08 --> Model Class Initialized
INFO - 2023-08-05 16:03:08 --> Final output sent to browser
DEBUG - 2023-08-05 16:03:08 --> Total execution time: 0.0367
