<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-20 03:03:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 03:03:14 --> Config Class Initialized
INFO - 2023-05-20 03:03:14 --> Hooks Class Initialized
DEBUG - 2023-05-20 03:03:14 --> UTF-8 Support Enabled
INFO - 2023-05-20 03:03:14 --> Utf8 Class Initialized
INFO - 2023-05-20 03:03:14 --> URI Class Initialized
INFO - 2023-05-20 03:03:14 --> Router Class Initialized
INFO - 2023-05-20 03:03:14 --> Output Class Initialized
INFO - 2023-05-20 03:03:14 --> Security Class Initialized
DEBUG - 2023-05-20 03:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 03:03:14 --> Input Class Initialized
INFO - 2023-05-20 03:03:14 --> Language Class Initialized
INFO - 2023-05-20 03:03:14 --> Loader Class Initialized
INFO - 2023-05-20 03:03:14 --> Helper loaded: url_helper
INFO - 2023-05-20 03:03:14 --> Helper loaded: file_helper
INFO - 2023-05-20 03:03:14 --> Helper loaded: html_helper
INFO - 2023-05-20 03:03:14 --> Helper loaded: text_helper
INFO - 2023-05-20 03:03:14 --> Helper loaded: form_helper
INFO - 2023-05-20 03:03:14 --> Helper loaded: lang_helper
INFO - 2023-05-20 03:03:14 --> Helper loaded: security_helper
INFO - 2023-05-20 03:03:14 --> Helper loaded: cookie_helper
INFO - 2023-05-20 03:03:14 --> Database Driver Class Initialized
INFO - 2023-05-20 03:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 03:03:14 --> Parser Class Initialized
INFO - 2023-05-20 03:03:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 03:03:14 --> Pagination Class Initialized
INFO - 2023-05-20 03:03:14 --> Form Validation Class Initialized
INFO - 2023-05-20 03:03:14 --> Controller Class Initialized
ERROR - 2023-05-20 03:03:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 03:03:14 --> Config Class Initialized
INFO - 2023-05-20 03:03:14 --> Hooks Class Initialized
DEBUG - 2023-05-20 03:03:14 --> UTF-8 Support Enabled
INFO - 2023-05-20 03:03:14 --> Utf8 Class Initialized
INFO - 2023-05-20 03:03:14 --> URI Class Initialized
INFO - 2023-05-20 03:03:14 --> Router Class Initialized
INFO - 2023-05-20 03:03:14 --> Output Class Initialized
INFO - 2023-05-20 03:03:14 --> Security Class Initialized
DEBUG - 2023-05-20 03:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 03:03:14 --> Input Class Initialized
INFO - 2023-05-20 03:03:14 --> Language Class Initialized
INFO - 2023-05-20 03:03:14 --> Loader Class Initialized
INFO - 2023-05-20 03:03:14 --> Helper loaded: url_helper
INFO - 2023-05-20 03:03:14 --> Helper loaded: file_helper
INFO - 2023-05-20 03:03:14 --> Helper loaded: html_helper
INFO - 2023-05-20 03:03:14 --> Helper loaded: text_helper
INFO - 2023-05-20 03:03:14 --> Helper loaded: form_helper
INFO - 2023-05-20 03:03:14 --> Helper loaded: lang_helper
INFO - 2023-05-20 03:03:14 --> Helper loaded: security_helper
INFO - 2023-05-20 03:03:14 --> Helper loaded: cookie_helper
INFO - 2023-05-20 03:03:14 --> Database Driver Class Initialized
INFO - 2023-05-20 03:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 03:03:14 --> Parser Class Initialized
INFO - 2023-05-20 03:03:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 03:03:14 --> Pagination Class Initialized
INFO - 2023-05-20 03:03:14 --> Form Validation Class Initialized
INFO - 2023-05-20 03:03:14 --> Controller Class Initialized
INFO - 2023-05-20 03:03:14 --> Model Class Initialized
DEBUG - 2023-05-20 03:03:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:03:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-20 03:03:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:03:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 03:03:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 03:03:14 --> Model Class Initialized
INFO - 2023-05-20 03:03:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 03:03:14 --> Final output sent to browser
DEBUG - 2023-05-20 03:03:14 --> Total execution time: 0.0307
ERROR - 2023-05-20 03:03:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 03:03:23 --> Config Class Initialized
INFO - 2023-05-20 03:03:23 --> Hooks Class Initialized
DEBUG - 2023-05-20 03:03:23 --> UTF-8 Support Enabled
INFO - 2023-05-20 03:03:23 --> Utf8 Class Initialized
INFO - 2023-05-20 03:03:23 --> URI Class Initialized
INFO - 2023-05-20 03:03:23 --> Router Class Initialized
INFO - 2023-05-20 03:03:23 --> Output Class Initialized
INFO - 2023-05-20 03:03:23 --> Security Class Initialized
DEBUG - 2023-05-20 03:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 03:03:23 --> Input Class Initialized
INFO - 2023-05-20 03:03:23 --> Language Class Initialized
INFO - 2023-05-20 03:03:23 --> Loader Class Initialized
INFO - 2023-05-20 03:03:23 --> Helper loaded: url_helper
INFO - 2023-05-20 03:03:23 --> Helper loaded: file_helper
INFO - 2023-05-20 03:03:23 --> Helper loaded: html_helper
INFO - 2023-05-20 03:03:23 --> Helper loaded: text_helper
INFO - 2023-05-20 03:03:23 --> Helper loaded: form_helper
INFO - 2023-05-20 03:03:23 --> Helper loaded: lang_helper
INFO - 2023-05-20 03:03:23 --> Helper loaded: security_helper
INFO - 2023-05-20 03:03:23 --> Helper loaded: cookie_helper
INFO - 2023-05-20 03:03:23 --> Database Driver Class Initialized
INFO - 2023-05-20 03:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 03:03:23 --> Parser Class Initialized
INFO - 2023-05-20 03:03:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 03:03:23 --> Pagination Class Initialized
INFO - 2023-05-20 03:03:23 --> Form Validation Class Initialized
INFO - 2023-05-20 03:03:23 --> Controller Class Initialized
INFO - 2023-05-20 03:03:23 --> Model Class Initialized
DEBUG - 2023-05-20 03:03:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:03:23 --> Model Class Initialized
INFO - 2023-05-20 03:03:23 --> Final output sent to browser
DEBUG - 2023-05-20 03:03:23 --> Total execution time: 0.0181
ERROR - 2023-05-20 03:03:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 03:03:23 --> Config Class Initialized
INFO - 2023-05-20 03:03:23 --> Hooks Class Initialized
DEBUG - 2023-05-20 03:03:23 --> UTF-8 Support Enabled
INFO - 2023-05-20 03:03:23 --> Utf8 Class Initialized
INFO - 2023-05-20 03:03:23 --> URI Class Initialized
DEBUG - 2023-05-20 03:03:23 --> No URI present. Default controller set.
INFO - 2023-05-20 03:03:23 --> Router Class Initialized
INFO - 2023-05-20 03:03:23 --> Output Class Initialized
INFO - 2023-05-20 03:03:23 --> Security Class Initialized
DEBUG - 2023-05-20 03:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 03:03:23 --> Input Class Initialized
INFO - 2023-05-20 03:03:23 --> Language Class Initialized
INFO - 2023-05-20 03:03:23 --> Loader Class Initialized
INFO - 2023-05-20 03:03:23 --> Helper loaded: url_helper
INFO - 2023-05-20 03:03:23 --> Helper loaded: file_helper
INFO - 2023-05-20 03:03:23 --> Helper loaded: html_helper
INFO - 2023-05-20 03:03:23 --> Helper loaded: text_helper
INFO - 2023-05-20 03:03:23 --> Helper loaded: form_helper
INFO - 2023-05-20 03:03:23 --> Helper loaded: lang_helper
INFO - 2023-05-20 03:03:23 --> Helper loaded: security_helper
INFO - 2023-05-20 03:03:23 --> Helper loaded: cookie_helper
INFO - 2023-05-20 03:03:23 --> Database Driver Class Initialized
INFO - 2023-05-20 03:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 03:03:23 --> Parser Class Initialized
INFO - 2023-05-20 03:03:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 03:03:23 --> Pagination Class Initialized
INFO - 2023-05-20 03:03:23 --> Form Validation Class Initialized
INFO - 2023-05-20 03:03:23 --> Controller Class Initialized
INFO - 2023-05-20 03:03:23 --> Model Class Initialized
DEBUG - 2023-05-20 03:03:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:03:23 --> Model Class Initialized
DEBUG - 2023-05-20 03:03:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:03:23 --> Model Class Initialized
INFO - 2023-05-20 03:03:23 --> Model Class Initialized
INFO - 2023-05-20 03:03:23 --> Model Class Initialized
INFO - 2023-05-20 03:03:23 --> Model Class Initialized
DEBUG - 2023-05-20 03:03:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 03:03:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:03:23 --> Model Class Initialized
INFO - 2023-05-20 03:03:23 --> Model Class Initialized
INFO - 2023-05-20 03:03:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 03:03:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:03:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 03:03:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 03:03:23 --> Model Class Initialized
INFO - 2023-05-20 03:03:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 03:03:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 03:03:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 03:03:24 --> Final output sent to browser
DEBUG - 2023-05-20 03:03:24 --> Total execution time: 0.0758
ERROR - 2023-05-20 03:03:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 03:03:32 --> Config Class Initialized
INFO - 2023-05-20 03:03:32 --> Hooks Class Initialized
DEBUG - 2023-05-20 03:03:32 --> UTF-8 Support Enabled
INFO - 2023-05-20 03:03:32 --> Utf8 Class Initialized
INFO - 2023-05-20 03:03:32 --> URI Class Initialized
INFO - 2023-05-20 03:03:32 --> Router Class Initialized
INFO - 2023-05-20 03:03:32 --> Output Class Initialized
INFO - 2023-05-20 03:03:32 --> Security Class Initialized
DEBUG - 2023-05-20 03:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 03:03:32 --> Input Class Initialized
INFO - 2023-05-20 03:03:32 --> Language Class Initialized
INFO - 2023-05-20 03:03:32 --> Loader Class Initialized
INFO - 2023-05-20 03:03:32 --> Helper loaded: url_helper
INFO - 2023-05-20 03:03:32 --> Helper loaded: file_helper
INFO - 2023-05-20 03:03:32 --> Helper loaded: html_helper
INFO - 2023-05-20 03:03:32 --> Helper loaded: text_helper
INFO - 2023-05-20 03:03:32 --> Helper loaded: form_helper
INFO - 2023-05-20 03:03:32 --> Helper loaded: lang_helper
INFO - 2023-05-20 03:03:32 --> Helper loaded: security_helper
INFO - 2023-05-20 03:03:32 --> Helper loaded: cookie_helper
INFO - 2023-05-20 03:03:32 --> Database Driver Class Initialized
INFO - 2023-05-20 03:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 03:03:32 --> Parser Class Initialized
INFO - 2023-05-20 03:03:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 03:03:32 --> Pagination Class Initialized
INFO - 2023-05-20 03:03:32 --> Form Validation Class Initialized
INFO - 2023-05-20 03:03:32 --> Controller Class Initialized
DEBUG - 2023-05-20 03:03:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 03:03:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:03:32 --> Model Class Initialized
DEBUG - 2023-05-20 03:03:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:03:32 --> Model Class Initialized
DEBUG - 2023-05-20 03:03:32 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:03:32 --> Model Class Initialized
INFO - 2023-05-20 03:03:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-05-20 03:03:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:03:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 03:03:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 03:03:32 --> Model Class Initialized
INFO - 2023-05-20 03:03:32 --> Model Class Initialized
INFO - 2023-05-20 03:03:32 --> Model Class Initialized
INFO - 2023-05-20 03:03:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 03:03:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 03:03:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 03:03:32 --> Final output sent to browser
DEBUG - 2023-05-20 03:03:32 --> Total execution time: 0.0642
ERROR - 2023-05-20 03:03:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 03:03:33 --> Config Class Initialized
INFO - 2023-05-20 03:03:33 --> Hooks Class Initialized
DEBUG - 2023-05-20 03:03:33 --> UTF-8 Support Enabled
INFO - 2023-05-20 03:03:33 --> Utf8 Class Initialized
INFO - 2023-05-20 03:03:33 --> URI Class Initialized
INFO - 2023-05-20 03:03:33 --> Router Class Initialized
INFO - 2023-05-20 03:03:33 --> Output Class Initialized
INFO - 2023-05-20 03:03:33 --> Security Class Initialized
DEBUG - 2023-05-20 03:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 03:03:33 --> Input Class Initialized
INFO - 2023-05-20 03:03:33 --> Language Class Initialized
INFO - 2023-05-20 03:03:33 --> Loader Class Initialized
INFO - 2023-05-20 03:03:33 --> Helper loaded: url_helper
INFO - 2023-05-20 03:03:33 --> Helper loaded: file_helper
INFO - 2023-05-20 03:03:33 --> Helper loaded: html_helper
INFO - 2023-05-20 03:03:33 --> Helper loaded: text_helper
INFO - 2023-05-20 03:03:33 --> Helper loaded: form_helper
INFO - 2023-05-20 03:03:33 --> Helper loaded: lang_helper
INFO - 2023-05-20 03:03:33 --> Helper loaded: security_helper
INFO - 2023-05-20 03:03:33 --> Helper loaded: cookie_helper
INFO - 2023-05-20 03:03:33 --> Database Driver Class Initialized
INFO - 2023-05-20 03:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 03:03:33 --> Parser Class Initialized
INFO - 2023-05-20 03:03:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 03:03:33 --> Pagination Class Initialized
INFO - 2023-05-20 03:03:33 --> Form Validation Class Initialized
INFO - 2023-05-20 03:03:33 --> Controller Class Initialized
DEBUG - 2023-05-20 03:03:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 03:03:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:03:33 --> Model Class Initialized
DEBUG - 2023-05-20 03:03:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:03:33 --> Model Class Initialized
INFO - 2023-05-20 03:03:33 --> Final output sent to browser
DEBUG - 2023-05-20 03:03:33 --> Total execution time: 0.0212
ERROR - 2023-05-20 03:03:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 03:03:50 --> Config Class Initialized
INFO - 2023-05-20 03:03:50 --> Hooks Class Initialized
DEBUG - 2023-05-20 03:03:50 --> UTF-8 Support Enabled
INFO - 2023-05-20 03:03:50 --> Utf8 Class Initialized
INFO - 2023-05-20 03:03:50 --> URI Class Initialized
INFO - 2023-05-20 03:03:50 --> Router Class Initialized
INFO - 2023-05-20 03:03:50 --> Output Class Initialized
INFO - 2023-05-20 03:03:50 --> Security Class Initialized
DEBUG - 2023-05-20 03:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 03:03:50 --> Input Class Initialized
INFO - 2023-05-20 03:03:50 --> Language Class Initialized
INFO - 2023-05-20 03:03:50 --> Loader Class Initialized
INFO - 2023-05-20 03:03:50 --> Helper loaded: url_helper
INFO - 2023-05-20 03:03:50 --> Helper loaded: file_helper
INFO - 2023-05-20 03:03:50 --> Helper loaded: html_helper
INFO - 2023-05-20 03:03:50 --> Helper loaded: text_helper
INFO - 2023-05-20 03:03:50 --> Helper loaded: form_helper
INFO - 2023-05-20 03:03:50 --> Helper loaded: lang_helper
INFO - 2023-05-20 03:03:50 --> Helper loaded: security_helper
INFO - 2023-05-20 03:03:50 --> Helper loaded: cookie_helper
INFO - 2023-05-20 03:03:50 --> Database Driver Class Initialized
INFO - 2023-05-20 03:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 03:03:50 --> Parser Class Initialized
INFO - 2023-05-20 03:03:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 03:03:50 --> Pagination Class Initialized
INFO - 2023-05-20 03:03:50 --> Form Validation Class Initialized
INFO - 2023-05-20 03:03:50 --> Controller Class Initialized
INFO - 2023-05-20 03:03:50 --> Model Class Initialized
DEBUG - 2023-05-20 03:03:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 03:03:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:03:50 --> Model Class Initialized
INFO - 2023-05-20 03:03:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-20 03:03:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:03:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 03:03:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 03:03:50 --> Model Class Initialized
INFO - 2023-05-20 03:03:50 --> Model Class Initialized
INFO - 2023-05-20 03:03:50 --> Model Class Initialized
INFO - 2023-05-20 03:03:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 03:03:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 03:03:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 03:03:50 --> Final output sent to browser
DEBUG - 2023-05-20 03:03:50 --> Total execution time: 0.0639
ERROR - 2023-05-20 03:03:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 03:03:50 --> Config Class Initialized
INFO - 2023-05-20 03:03:50 --> Hooks Class Initialized
DEBUG - 2023-05-20 03:03:50 --> UTF-8 Support Enabled
INFO - 2023-05-20 03:03:50 --> Utf8 Class Initialized
INFO - 2023-05-20 03:03:50 --> URI Class Initialized
INFO - 2023-05-20 03:03:50 --> Router Class Initialized
INFO - 2023-05-20 03:03:50 --> Output Class Initialized
INFO - 2023-05-20 03:03:50 --> Security Class Initialized
DEBUG - 2023-05-20 03:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 03:03:50 --> Input Class Initialized
INFO - 2023-05-20 03:03:50 --> Language Class Initialized
INFO - 2023-05-20 03:03:50 --> Loader Class Initialized
INFO - 2023-05-20 03:03:50 --> Helper loaded: url_helper
INFO - 2023-05-20 03:03:50 --> Helper loaded: file_helper
INFO - 2023-05-20 03:03:50 --> Helper loaded: html_helper
INFO - 2023-05-20 03:03:50 --> Helper loaded: text_helper
INFO - 2023-05-20 03:03:50 --> Helper loaded: form_helper
INFO - 2023-05-20 03:03:50 --> Helper loaded: lang_helper
INFO - 2023-05-20 03:03:50 --> Helper loaded: security_helper
INFO - 2023-05-20 03:03:50 --> Helper loaded: cookie_helper
INFO - 2023-05-20 03:03:50 --> Database Driver Class Initialized
INFO - 2023-05-20 03:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 03:03:50 --> Parser Class Initialized
INFO - 2023-05-20 03:03:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 03:03:50 --> Pagination Class Initialized
INFO - 2023-05-20 03:03:50 --> Form Validation Class Initialized
INFO - 2023-05-20 03:03:50 --> Controller Class Initialized
INFO - 2023-05-20 03:03:50 --> Model Class Initialized
DEBUG - 2023-05-20 03:03:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 03:03:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:03:50 --> Model Class Initialized
INFO - 2023-05-20 03:03:50 --> Final output sent to browser
DEBUG - 2023-05-20 03:03:50 --> Total execution time: 0.0202
ERROR - 2023-05-20 03:04:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 03:04:01 --> Config Class Initialized
INFO - 2023-05-20 03:04:01 --> Hooks Class Initialized
DEBUG - 2023-05-20 03:04:01 --> UTF-8 Support Enabled
INFO - 2023-05-20 03:04:01 --> Utf8 Class Initialized
INFO - 2023-05-20 03:04:01 --> URI Class Initialized
INFO - 2023-05-20 03:04:01 --> Router Class Initialized
INFO - 2023-05-20 03:04:01 --> Output Class Initialized
INFO - 2023-05-20 03:04:01 --> Security Class Initialized
DEBUG - 2023-05-20 03:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 03:04:01 --> Input Class Initialized
INFO - 2023-05-20 03:04:01 --> Language Class Initialized
INFO - 2023-05-20 03:04:01 --> Loader Class Initialized
INFO - 2023-05-20 03:04:01 --> Helper loaded: url_helper
INFO - 2023-05-20 03:04:01 --> Helper loaded: file_helper
INFO - 2023-05-20 03:04:01 --> Helper loaded: html_helper
INFO - 2023-05-20 03:04:01 --> Helper loaded: text_helper
INFO - 2023-05-20 03:04:01 --> Helper loaded: form_helper
INFO - 2023-05-20 03:04:01 --> Helper loaded: lang_helper
INFO - 2023-05-20 03:04:01 --> Helper loaded: security_helper
INFO - 2023-05-20 03:04:01 --> Helper loaded: cookie_helper
INFO - 2023-05-20 03:04:01 --> Database Driver Class Initialized
INFO - 2023-05-20 03:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 03:04:01 --> Parser Class Initialized
INFO - 2023-05-20 03:04:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 03:04:01 --> Pagination Class Initialized
INFO - 2023-05-20 03:04:01 --> Form Validation Class Initialized
INFO - 2023-05-20 03:04:01 --> Controller Class Initialized
INFO - 2023-05-20 03:04:01 --> Model Class Initialized
DEBUG - 2023-05-20 03:04:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 03:04:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:04:01 --> Model Class Initialized
INFO - 2023-05-20 03:04:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-05-20 03:04:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:04:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 03:04:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 03:04:01 --> Model Class Initialized
INFO - 2023-05-20 03:04:01 --> Model Class Initialized
INFO - 2023-05-20 03:04:01 --> Model Class Initialized
INFO - 2023-05-20 03:04:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 03:04:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 03:04:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 03:04:01 --> Final output sent to browser
DEBUG - 2023-05-20 03:04:01 --> Total execution time: 0.0684
ERROR - 2023-05-20 03:04:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 03:04:01 --> Config Class Initialized
INFO - 2023-05-20 03:04:01 --> Hooks Class Initialized
DEBUG - 2023-05-20 03:04:01 --> UTF-8 Support Enabled
INFO - 2023-05-20 03:04:01 --> Utf8 Class Initialized
INFO - 2023-05-20 03:04:01 --> URI Class Initialized
INFO - 2023-05-20 03:04:01 --> Router Class Initialized
INFO - 2023-05-20 03:04:01 --> Output Class Initialized
INFO - 2023-05-20 03:04:01 --> Security Class Initialized
DEBUG - 2023-05-20 03:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 03:04:01 --> Input Class Initialized
INFO - 2023-05-20 03:04:01 --> Language Class Initialized
INFO - 2023-05-20 03:04:01 --> Loader Class Initialized
INFO - 2023-05-20 03:04:01 --> Helper loaded: url_helper
INFO - 2023-05-20 03:04:01 --> Helper loaded: file_helper
INFO - 2023-05-20 03:04:01 --> Helper loaded: html_helper
INFO - 2023-05-20 03:04:01 --> Helper loaded: text_helper
INFO - 2023-05-20 03:04:01 --> Helper loaded: form_helper
INFO - 2023-05-20 03:04:01 --> Helper loaded: lang_helper
INFO - 2023-05-20 03:04:01 --> Helper loaded: security_helper
INFO - 2023-05-20 03:04:01 --> Helper loaded: cookie_helper
INFO - 2023-05-20 03:04:01 --> Database Driver Class Initialized
INFO - 2023-05-20 03:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 03:04:01 --> Parser Class Initialized
INFO - 2023-05-20 03:04:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 03:04:01 --> Pagination Class Initialized
INFO - 2023-05-20 03:04:01 --> Form Validation Class Initialized
INFO - 2023-05-20 03:04:01 --> Controller Class Initialized
INFO - 2023-05-20 03:04:01 --> Model Class Initialized
DEBUG - 2023-05-20 03:04:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 03:04:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:04:01 --> Model Class Initialized
INFO - 2023-05-20 03:04:01 --> Final output sent to browser
DEBUG - 2023-05-20 03:04:01 --> Total execution time: 0.0173
ERROR - 2023-05-20 03:04:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 03:04:18 --> Config Class Initialized
INFO - 2023-05-20 03:04:18 --> Hooks Class Initialized
DEBUG - 2023-05-20 03:04:18 --> UTF-8 Support Enabled
INFO - 2023-05-20 03:04:18 --> Utf8 Class Initialized
INFO - 2023-05-20 03:04:18 --> URI Class Initialized
INFO - 2023-05-20 03:04:18 --> Router Class Initialized
INFO - 2023-05-20 03:04:18 --> Output Class Initialized
INFO - 2023-05-20 03:04:18 --> Security Class Initialized
DEBUG - 2023-05-20 03:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 03:04:18 --> Input Class Initialized
INFO - 2023-05-20 03:04:18 --> Language Class Initialized
INFO - 2023-05-20 03:04:18 --> Loader Class Initialized
INFO - 2023-05-20 03:04:18 --> Helper loaded: url_helper
INFO - 2023-05-20 03:04:18 --> Helper loaded: file_helper
INFO - 2023-05-20 03:04:18 --> Helper loaded: html_helper
INFO - 2023-05-20 03:04:18 --> Helper loaded: text_helper
INFO - 2023-05-20 03:04:18 --> Helper loaded: form_helper
INFO - 2023-05-20 03:04:18 --> Helper loaded: lang_helper
INFO - 2023-05-20 03:04:18 --> Helper loaded: security_helper
INFO - 2023-05-20 03:04:18 --> Helper loaded: cookie_helper
INFO - 2023-05-20 03:04:18 --> Database Driver Class Initialized
INFO - 2023-05-20 03:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 03:04:18 --> Parser Class Initialized
INFO - 2023-05-20 03:04:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 03:04:18 --> Pagination Class Initialized
INFO - 2023-05-20 03:04:18 --> Form Validation Class Initialized
INFO - 2023-05-20 03:04:18 --> Controller Class Initialized
INFO - 2023-05-20 03:04:18 --> Model Class Initialized
DEBUG - 2023-05-20 03:04:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 03:04:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:04:18 --> Model Class Initialized
ERROR - 2023-05-20 03:04:18 --> Query error: Unknown column 'mr_name' in 'order clause' - Invalid query: SELECT `a`.*
FROM `demandrequests` `a`
WHERE `a`.`mr_id` = '37'
AND `a`.`request_by` = 'customer'
ORDER BY `mr_name` ASC
 LIMIT 10
ERROR - 2023-05-20 03:04:18 --> Severity: error --> Exception: Call to a member function result() on bool /home/powera7m/app.maurnaturo.com/application/models/Demandrequests.php 540
ERROR - 2023-05-20 03:04:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 03:04:28 --> Config Class Initialized
INFO - 2023-05-20 03:04:28 --> Hooks Class Initialized
DEBUG - 2023-05-20 03:04:28 --> UTF-8 Support Enabled
INFO - 2023-05-20 03:04:28 --> Utf8 Class Initialized
INFO - 2023-05-20 03:04:28 --> URI Class Initialized
INFO - 2023-05-20 03:04:28 --> Router Class Initialized
INFO - 2023-05-20 03:04:28 --> Output Class Initialized
INFO - 2023-05-20 03:04:28 --> Security Class Initialized
DEBUG - 2023-05-20 03:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 03:04:28 --> Input Class Initialized
INFO - 2023-05-20 03:04:28 --> Language Class Initialized
INFO - 2023-05-20 03:04:28 --> Loader Class Initialized
INFO - 2023-05-20 03:04:28 --> Helper loaded: url_helper
INFO - 2023-05-20 03:04:28 --> Helper loaded: file_helper
INFO - 2023-05-20 03:04:28 --> Helper loaded: html_helper
INFO - 2023-05-20 03:04:28 --> Helper loaded: text_helper
INFO - 2023-05-20 03:04:28 --> Helper loaded: form_helper
INFO - 2023-05-20 03:04:28 --> Helper loaded: lang_helper
INFO - 2023-05-20 03:04:28 --> Helper loaded: security_helper
INFO - 2023-05-20 03:04:28 --> Helper loaded: cookie_helper
INFO - 2023-05-20 03:04:28 --> Database Driver Class Initialized
INFO - 2023-05-20 03:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 03:04:28 --> Parser Class Initialized
INFO - 2023-05-20 03:04:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 03:04:28 --> Pagination Class Initialized
INFO - 2023-05-20 03:04:28 --> Form Validation Class Initialized
INFO - 2023-05-20 03:04:28 --> Controller Class Initialized
INFO - 2023-05-20 03:04:28 --> Model Class Initialized
DEBUG - 2023-05-20 03:04:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 03:04:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:04:28 --> Model Class Initialized
DEBUG - 2023-05-20 03:04:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:04:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-05-20 03:04:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:04:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 03:04:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 03:04:28 --> Model Class Initialized
INFO - 2023-05-20 03:04:28 --> Model Class Initialized
INFO - 2023-05-20 03:04:28 --> Model Class Initialized
INFO - 2023-05-20 03:04:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 03:04:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 03:04:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 03:04:28 --> Final output sent to browser
DEBUG - 2023-05-20 03:04:28 --> Total execution time: 0.0640
ERROR - 2023-05-20 03:04:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 03:04:34 --> Config Class Initialized
INFO - 2023-05-20 03:04:34 --> Hooks Class Initialized
DEBUG - 2023-05-20 03:04:34 --> UTF-8 Support Enabled
INFO - 2023-05-20 03:04:34 --> Utf8 Class Initialized
INFO - 2023-05-20 03:04:34 --> URI Class Initialized
INFO - 2023-05-20 03:04:34 --> Router Class Initialized
INFO - 2023-05-20 03:04:34 --> Output Class Initialized
INFO - 2023-05-20 03:04:34 --> Security Class Initialized
DEBUG - 2023-05-20 03:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 03:04:34 --> Input Class Initialized
INFO - 2023-05-20 03:04:34 --> Language Class Initialized
INFO - 2023-05-20 03:04:34 --> Loader Class Initialized
INFO - 2023-05-20 03:04:34 --> Helper loaded: url_helper
INFO - 2023-05-20 03:04:34 --> Helper loaded: file_helper
INFO - 2023-05-20 03:04:34 --> Helper loaded: html_helper
INFO - 2023-05-20 03:04:34 --> Helper loaded: text_helper
INFO - 2023-05-20 03:04:34 --> Helper loaded: form_helper
INFO - 2023-05-20 03:04:34 --> Helper loaded: lang_helper
INFO - 2023-05-20 03:04:34 --> Helper loaded: security_helper
INFO - 2023-05-20 03:04:34 --> Helper loaded: cookie_helper
INFO - 2023-05-20 03:04:34 --> Database Driver Class Initialized
INFO - 2023-05-20 03:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 03:04:34 --> Parser Class Initialized
INFO - 2023-05-20 03:04:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 03:04:34 --> Pagination Class Initialized
INFO - 2023-05-20 03:04:34 --> Form Validation Class Initialized
INFO - 2023-05-20 03:04:34 --> Controller Class Initialized
INFO - 2023-05-20 03:04:34 --> Model Class Initialized
DEBUG - 2023-05-20 03:04:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 03:04:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:04:34 --> Model Class Initialized
INFO - 2023-05-20 03:04:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-05-20 03:04:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:04:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 03:04:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 03:04:34 --> Model Class Initialized
INFO - 2023-05-20 03:04:34 --> Model Class Initialized
INFO - 2023-05-20 03:04:34 --> Model Class Initialized
INFO - 2023-05-20 03:04:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 03:04:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 03:04:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 03:04:34 --> Final output sent to browser
DEBUG - 2023-05-20 03:04:34 --> Total execution time: 0.0626
ERROR - 2023-05-20 03:04:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 03:04:35 --> Config Class Initialized
INFO - 2023-05-20 03:04:35 --> Hooks Class Initialized
DEBUG - 2023-05-20 03:04:35 --> UTF-8 Support Enabled
INFO - 2023-05-20 03:04:35 --> Utf8 Class Initialized
INFO - 2023-05-20 03:04:35 --> URI Class Initialized
INFO - 2023-05-20 03:04:35 --> Router Class Initialized
INFO - 2023-05-20 03:04:35 --> Output Class Initialized
INFO - 2023-05-20 03:04:35 --> Security Class Initialized
DEBUG - 2023-05-20 03:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 03:04:35 --> Input Class Initialized
INFO - 2023-05-20 03:04:35 --> Language Class Initialized
INFO - 2023-05-20 03:04:35 --> Loader Class Initialized
INFO - 2023-05-20 03:04:35 --> Helper loaded: url_helper
INFO - 2023-05-20 03:04:35 --> Helper loaded: file_helper
INFO - 2023-05-20 03:04:35 --> Helper loaded: html_helper
INFO - 2023-05-20 03:04:35 --> Helper loaded: text_helper
INFO - 2023-05-20 03:04:35 --> Helper loaded: form_helper
INFO - 2023-05-20 03:04:35 --> Helper loaded: lang_helper
INFO - 2023-05-20 03:04:35 --> Helper loaded: security_helper
INFO - 2023-05-20 03:04:35 --> Helper loaded: cookie_helper
INFO - 2023-05-20 03:04:35 --> Database Driver Class Initialized
INFO - 2023-05-20 03:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 03:04:35 --> Parser Class Initialized
INFO - 2023-05-20 03:04:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 03:04:35 --> Pagination Class Initialized
INFO - 2023-05-20 03:04:35 --> Form Validation Class Initialized
INFO - 2023-05-20 03:04:35 --> Controller Class Initialized
INFO - 2023-05-20 03:04:35 --> Model Class Initialized
DEBUG - 2023-05-20 03:04:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 03:04:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:04:35 --> Model Class Initialized
INFO - 2023-05-20 03:04:35 --> Final output sent to browser
DEBUG - 2023-05-20 03:04:35 --> Total execution time: 0.0182
ERROR - 2023-05-20 03:04:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 03:04:46 --> Config Class Initialized
INFO - 2023-05-20 03:04:46 --> Hooks Class Initialized
DEBUG - 2023-05-20 03:04:46 --> UTF-8 Support Enabled
INFO - 2023-05-20 03:04:46 --> Utf8 Class Initialized
INFO - 2023-05-20 03:04:46 --> URI Class Initialized
INFO - 2023-05-20 03:04:46 --> Router Class Initialized
INFO - 2023-05-20 03:04:46 --> Output Class Initialized
INFO - 2023-05-20 03:04:46 --> Security Class Initialized
DEBUG - 2023-05-20 03:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 03:04:46 --> Input Class Initialized
INFO - 2023-05-20 03:04:46 --> Language Class Initialized
INFO - 2023-05-20 03:04:46 --> Loader Class Initialized
INFO - 2023-05-20 03:04:46 --> Helper loaded: url_helper
INFO - 2023-05-20 03:04:46 --> Helper loaded: file_helper
INFO - 2023-05-20 03:04:46 --> Helper loaded: html_helper
INFO - 2023-05-20 03:04:46 --> Helper loaded: text_helper
INFO - 2023-05-20 03:04:46 --> Helper loaded: form_helper
INFO - 2023-05-20 03:04:46 --> Helper loaded: lang_helper
INFO - 2023-05-20 03:04:46 --> Helper loaded: security_helper
INFO - 2023-05-20 03:04:46 --> Helper loaded: cookie_helper
INFO - 2023-05-20 03:04:46 --> Database Driver Class Initialized
INFO - 2023-05-20 03:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 03:04:46 --> Parser Class Initialized
INFO - 2023-05-20 03:04:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 03:04:46 --> Pagination Class Initialized
INFO - 2023-05-20 03:04:46 --> Form Validation Class Initialized
INFO - 2023-05-20 03:04:46 --> Controller Class Initialized
INFO - 2023-05-20 03:04:46 --> Model Class Initialized
INFO - 2023-05-20 03:04:46 --> Model Class Initialized
INFO - 2023-05-20 03:04:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-05-20 03:04:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:04:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 03:04:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 03:04:46 --> Model Class Initialized
INFO - 2023-05-20 03:04:46 --> Model Class Initialized
INFO - 2023-05-20 03:04:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 03:04:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 03:04:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 03:04:46 --> Final output sent to browser
DEBUG - 2023-05-20 03:04:46 --> Total execution time: 0.0633
ERROR - 2023-05-20 03:04:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 03:04:47 --> Config Class Initialized
INFO - 2023-05-20 03:04:47 --> Hooks Class Initialized
DEBUG - 2023-05-20 03:04:47 --> UTF-8 Support Enabled
INFO - 2023-05-20 03:04:47 --> Utf8 Class Initialized
INFO - 2023-05-20 03:04:47 --> URI Class Initialized
INFO - 2023-05-20 03:04:47 --> Router Class Initialized
INFO - 2023-05-20 03:04:47 --> Output Class Initialized
INFO - 2023-05-20 03:04:47 --> Security Class Initialized
DEBUG - 2023-05-20 03:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 03:04:47 --> Input Class Initialized
INFO - 2023-05-20 03:04:47 --> Language Class Initialized
INFO - 2023-05-20 03:04:47 --> Loader Class Initialized
INFO - 2023-05-20 03:04:47 --> Helper loaded: url_helper
INFO - 2023-05-20 03:04:47 --> Helper loaded: file_helper
INFO - 2023-05-20 03:04:47 --> Helper loaded: html_helper
INFO - 2023-05-20 03:04:47 --> Helper loaded: text_helper
INFO - 2023-05-20 03:04:47 --> Helper loaded: form_helper
INFO - 2023-05-20 03:04:47 --> Helper loaded: lang_helper
INFO - 2023-05-20 03:04:47 --> Helper loaded: security_helper
INFO - 2023-05-20 03:04:47 --> Helper loaded: cookie_helper
INFO - 2023-05-20 03:04:47 --> Database Driver Class Initialized
INFO - 2023-05-20 03:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 03:04:47 --> Parser Class Initialized
INFO - 2023-05-20 03:04:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 03:04:47 --> Pagination Class Initialized
INFO - 2023-05-20 03:04:47 --> Form Validation Class Initialized
INFO - 2023-05-20 03:04:47 --> Controller Class Initialized
INFO - 2023-05-20 03:04:47 --> Model Class Initialized
INFO - 2023-05-20 03:04:47 --> Model Class Initialized
INFO - 2023-05-20 03:04:47 --> Final output sent to browser
DEBUG - 2023-05-20 03:04:47 --> Total execution time: 0.0262
ERROR - 2023-05-20 03:05:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 03:05:02 --> Config Class Initialized
INFO - 2023-05-20 03:05:02 --> Hooks Class Initialized
DEBUG - 2023-05-20 03:05:02 --> UTF-8 Support Enabled
INFO - 2023-05-20 03:05:02 --> Utf8 Class Initialized
INFO - 2023-05-20 03:05:02 --> URI Class Initialized
DEBUG - 2023-05-20 03:05:02 --> No URI present. Default controller set.
INFO - 2023-05-20 03:05:02 --> Router Class Initialized
INFO - 2023-05-20 03:05:02 --> Output Class Initialized
INFO - 2023-05-20 03:05:02 --> Security Class Initialized
DEBUG - 2023-05-20 03:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 03:05:02 --> Input Class Initialized
INFO - 2023-05-20 03:05:02 --> Language Class Initialized
INFO - 2023-05-20 03:05:02 --> Loader Class Initialized
INFO - 2023-05-20 03:05:02 --> Helper loaded: url_helper
INFO - 2023-05-20 03:05:02 --> Helper loaded: file_helper
INFO - 2023-05-20 03:05:02 --> Helper loaded: html_helper
INFO - 2023-05-20 03:05:02 --> Helper loaded: text_helper
INFO - 2023-05-20 03:05:02 --> Helper loaded: form_helper
INFO - 2023-05-20 03:05:02 --> Helper loaded: lang_helper
INFO - 2023-05-20 03:05:02 --> Helper loaded: security_helper
INFO - 2023-05-20 03:05:02 --> Helper loaded: cookie_helper
INFO - 2023-05-20 03:05:02 --> Database Driver Class Initialized
INFO - 2023-05-20 03:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 03:05:02 --> Parser Class Initialized
INFO - 2023-05-20 03:05:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 03:05:02 --> Pagination Class Initialized
INFO - 2023-05-20 03:05:02 --> Form Validation Class Initialized
INFO - 2023-05-20 03:05:02 --> Controller Class Initialized
INFO - 2023-05-20 03:05:02 --> Model Class Initialized
DEBUG - 2023-05-20 03:05:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:05:02 --> Model Class Initialized
DEBUG - 2023-05-20 03:05:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:05:02 --> Model Class Initialized
INFO - 2023-05-20 03:05:02 --> Model Class Initialized
INFO - 2023-05-20 03:05:02 --> Model Class Initialized
INFO - 2023-05-20 03:05:02 --> Model Class Initialized
DEBUG - 2023-05-20 03:05:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 03:05:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:05:02 --> Model Class Initialized
INFO - 2023-05-20 03:05:02 --> Model Class Initialized
INFO - 2023-05-20 03:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 03:05:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 03:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 03:05:02 --> Model Class Initialized
INFO - 2023-05-20 03:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 03:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 03:05:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 03:05:02 --> Final output sent to browser
DEBUG - 2023-05-20 03:05:02 --> Total execution time: 0.0768
ERROR - 2023-05-20 03:05:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 03:05:16 --> Config Class Initialized
INFO - 2023-05-20 03:05:16 --> Hooks Class Initialized
DEBUG - 2023-05-20 03:05:16 --> UTF-8 Support Enabled
INFO - 2023-05-20 03:05:16 --> Utf8 Class Initialized
INFO - 2023-05-20 03:05:16 --> URI Class Initialized
INFO - 2023-05-20 03:05:16 --> Router Class Initialized
INFO - 2023-05-20 03:05:16 --> Output Class Initialized
INFO - 2023-05-20 03:05:16 --> Security Class Initialized
DEBUG - 2023-05-20 03:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 03:05:16 --> Input Class Initialized
INFO - 2023-05-20 03:05:16 --> Language Class Initialized
INFO - 2023-05-20 03:05:16 --> Loader Class Initialized
INFO - 2023-05-20 03:05:16 --> Helper loaded: url_helper
INFO - 2023-05-20 03:05:16 --> Helper loaded: file_helper
INFO - 2023-05-20 03:05:16 --> Helper loaded: html_helper
INFO - 2023-05-20 03:05:16 --> Helper loaded: text_helper
INFO - 2023-05-20 03:05:16 --> Helper loaded: form_helper
INFO - 2023-05-20 03:05:16 --> Helper loaded: lang_helper
INFO - 2023-05-20 03:05:16 --> Helper loaded: security_helper
INFO - 2023-05-20 03:05:16 --> Helper loaded: cookie_helper
INFO - 2023-05-20 03:05:16 --> Database Driver Class Initialized
INFO - 2023-05-20 03:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 03:05:16 --> Parser Class Initialized
INFO - 2023-05-20 03:05:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 03:05:16 --> Pagination Class Initialized
INFO - 2023-05-20 03:05:16 --> Form Validation Class Initialized
INFO - 2023-05-20 03:05:16 --> Controller Class Initialized
INFO - 2023-05-20 03:05:16 --> Model Class Initialized
DEBUG - 2023-05-20 03:05:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 03:05:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:05:16 --> Model Class Initialized
DEBUG - 2023-05-20 03:05:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:05:16 --> Model Class Initialized
INFO - 2023-05-20 03:05:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-05-20 03:05:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:05:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 03:05:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 03:05:16 --> Model Class Initialized
INFO - 2023-05-20 03:05:16 --> Model Class Initialized
INFO - 2023-05-20 03:05:16 --> Model Class Initialized
INFO - 2023-05-20 03:05:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 03:05:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 03:05:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 03:05:16 --> Final output sent to browser
DEBUG - 2023-05-20 03:05:16 --> Total execution time: 0.0687
ERROR - 2023-05-20 03:05:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 03:05:17 --> Config Class Initialized
INFO - 2023-05-20 03:05:17 --> Hooks Class Initialized
DEBUG - 2023-05-20 03:05:17 --> UTF-8 Support Enabled
INFO - 2023-05-20 03:05:17 --> Utf8 Class Initialized
INFO - 2023-05-20 03:05:17 --> URI Class Initialized
INFO - 2023-05-20 03:05:17 --> Router Class Initialized
INFO - 2023-05-20 03:05:17 --> Output Class Initialized
INFO - 2023-05-20 03:05:17 --> Security Class Initialized
DEBUG - 2023-05-20 03:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 03:05:17 --> Input Class Initialized
INFO - 2023-05-20 03:05:17 --> Language Class Initialized
INFO - 2023-05-20 03:05:17 --> Loader Class Initialized
INFO - 2023-05-20 03:05:17 --> Helper loaded: url_helper
INFO - 2023-05-20 03:05:17 --> Helper loaded: file_helper
INFO - 2023-05-20 03:05:17 --> Helper loaded: html_helper
INFO - 2023-05-20 03:05:17 --> Helper loaded: text_helper
INFO - 2023-05-20 03:05:17 --> Helper loaded: form_helper
INFO - 2023-05-20 03:05:17 --> Helper loaded: lang_helper
INFO - 2023-05-20 03:05:17 --> Helper loaded: security_helper
INFO - 2023-05-20 03:05:17 --> Helper loaded: cookie_helper
INFO - 2023-05-20 03:05:17 --> Database Driver Class Initialized
INFO - 2023-05-20 03:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 03:05:17 --> Parser Class Initialized
INFO - 2023-05-20 03:05:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 03:05:17 --> Pagination Class Initialized
INFO - 2023-05-20 03:05:17 --> Form Validation Class Initialized
INFO - 2023-05-20 03:05:17 --> Controller Class Initialized
INFO - 2023-05-20 03:05:17 --> Model Class Initialized
DEBUG - 2023-05-20 03:05:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 03:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:05:17 --> Model Class Initialized
DEBUG - 2023-05-20 03:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:05:17 --> Model Class Initialized
INFO - 2023-05-20 03:05:17 --> Final output sent to browser
DEBUG - 2023-05-20 03:05:17 --> Total execution time: 0.0426
ERROR - 2023-05-20 03:05:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 03:05:28 --> Config Class Initialized
INFO - 2023-05-20 03:05:28 --> Hooks Class Initialized
DEBUG - 2023-05-20 03:05:28 --> UTF-8 Support Enabled
INFO - 2023-05-20 03:05:28 --> Utf8 Class Initialized
INFO - 2023-05-20 03:05:28 --> URI Class Initialized
INFO - 2023-05-20 03:05:28 --> Router Class Initialized
INFO - 2023-05-20 03:05:28 --> Output Class Initialized
INFO - 2023-05-20 03:05:28 --> Security Class Initialized
DEBUG - 2023-05-20 03:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 03:05:28 --> Input Class Initialized
INFO - 2023-05-20 03:05:28 --> Language Class Initialized
INFO - 2023-05-20 03:05:28 --> Loader Class Initialized
INFO - 2023-05-20 03:05:28 --> Helper loaded: url_helper
INFO - 2023-05-20 03:05:28 --> Helper loaded: file_helper
INFO - 2023-05-20 03:05:28 --> Helper loaded: html_helper
INFO - 2023-05-20 03:05:28 --> Helper loaded: text_helper
INFO - 2023-05-20 03:05:28 --> Helper loaded: form_helper
INFO - 2023-05-20 03:05:28 --> Helper loaded: lang_helper
INFO - 2023-05-20 03:05:28 --> Helper loaded: security_helper
INFO - 2023-05-20 03:05:28 --> Helper loaded: cookie_helper
INFO - 2023-05-20 03:05:28 --> Database Driver Class Initialized
INFO - 2023-05-20 03:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 03:05:28 --> Parser Class Initialized
INFO - 2023-05-20 03:05:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 03:05:28 --> Pagination Class Initialized
INFO - 2023-05-20 03:05:28 --> Form Validation Class Initialized
INFO - 2023-05-20 03:05:28 --> Controller Class Initialized
INFO - 2023-05-20 03:05:28 --> Model Class Initialized
DEBUG - 2023-05-20 03:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-20 03:05:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 03:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 03:05:28 --> Model Class Initialized
INFO - 2023-05-20 03:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 03:05:28 --> Final output sent to browser
DEBUG - 2023-05-20 03:05:28 --> Total execution time: 0.0313
ERROR - 2023-05-20 03:05:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 03:05:28 --> Config Class Initialized
INFO - 2023-05-20 03:05:28 --> Hooks Class Initialized
DEBUG - 2023-05-20 03:05:28 --> UTF-8 Support Enabled
INFO - 2023-05-20 03:05:28 --> Utf8 Class Initialized
INFO - 2023-05-20 03:05:28 --> URI Class Initialized
INFO - 2023-05-20 03:05:28 --> Router Class Initialized
INFO - 2023-05-20 03:05:28 --> Output Class Initialized
INFO - 2023-05-20 03:05:28 --> Security Class Initialized
DEBUG - 2023-05-20 03:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 03:05:28 --> Input Class Initialized
INFO - 2023-05-20 03:05:28 --> Language Class Initialized
INFO - 2023-05-20 03:05:28 --> Loader Class Initialized
INFO - 2023-05-20 03:05:28 --> Helper loaded: url_helper
INFO - 2023-05-20 03:05:28 --> Helper loaded: file_helper
INFO - 2023-05-20 03:05:28 --> Helper loaded: html_helper
INFO - 2023-05-20 03:05:28 --> Helper loaded: text_helper
INFO - 2023-05-20 03:05:28 --> Helper loaded: form_helper
INFO - 2023-05-20 03:05:28 --> Helper loaded: lang_helper
INFO - 2023-05-20 03:05:28 --> Helper loaded: security_helper
INFO - 2023-05-20 03:05:28 --> Helper loaded: cookie_helper
INFO - 2023-05-20 03:05:28 --> Database Driver Class Initialized
INFO - 2023-05-20 03:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 03:05:28 --> Parser Class Initialized
INFO - 2023-05-20 03:05:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 03:05:28 --> Pagination Class Initialized
INFO - 2023-05-20 03:05:28 --> Form Validation Class Initialized
INFO - 2023-05-20 03:05:28 --> Controller Class Initialized
INFO - 2023-05-20 03:05:28 --> Model Class Initialized
DEBUG - 2023-05-20 03:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:05:28 --> Model Class Initialized
DEBUG - 2023-05-20 03:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:05:28 --> Model Class Initialized
INFO - 2023-05-20 03:05:28 --> Model Class Initialized
INFO - 2023-05-20 03:05:28 --> Model Class Initialized
INFO - 2023-05-20 03:05:28 --> Model Class Initialized
DEBUG - 2023-05-20 03:05:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 03:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:05:28 --> Model Class Initialized
INFO - 2023-05-20 03:05:28 --> Model Class Initialized
INFO - 2023-05-20 03:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 03:05:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 03:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 03:05:28 --> Model Class Initialized
INFO - 2023-05-20 03:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 03:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 03:05:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 03:05:28 --> Final output sent to browser
DEBUG - 2023-05-20 03:05:28 --> Total execution time: 0.0689
ERROR - 2023-05-20 03:44:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 03:44:48 --> Config Class Initialized
INFO - 2023-05-20 03:44:48 --> Hooks Class Initialized
DEBUG - 2023-05-20 03:44:48 --> UTF-8 Support Enabled
INFO - 2023-05-20 03:44:48 --> Utf8 Class Initialized
INFO - 2023-05-20 03:44:48 --> URI Class Initialized
DEBUG - 2023-05-20 03:44:48 --> No URI present. Default controller set.
INFO - 2023-05-20 03:44:48 --> Router Class Initialized
INFO - 2023-05-20 03:44:48 --> Output Class Initialized
INFO - 2023-05-20 03:44:48 --> Security Class Initialized
DEBUG - 2023-05-20 03:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 03:44:48 --> Input Class Initialized
INFO - 2023-05-20 03:44:48 --> Language Class Initialized
INFO - 2023-05-20 03:44:48 --> Loader Class Initialized
INFO - 2023-05-20 03:44:48 --> Helper loaded: url_helper
INFO - 2023-05-20 03:44:48 --> Helper loaded: file_helper
INFO - 2023-05-20 03:44:48 --> Helper loaded: html_helper
INFO - 2023-05-20 03:44:48 --> Helper loaded: text_helper
INFO - 2023-05-20 03:44:48 --> Helper loaded: form_helper
INFO - 2023-05-20 03:44:48 --> Helper loaded: lang_helper
INFO - 2023-05-20 03:44:48 --> Helper loaded: security_helper
INFO - 2023-05-20 03:44:48 --> Helper loaded: cookie_helper
INFO - 2023-05-20 03:44:48 --> Database Driver Class Initialized
INFO - 2023-05-20 03:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 03:44:48 --> Parser Class Initialized
INFO - 2023-05-20 03:44:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 03:44:48 --> Pagination Class Initialized
INFO - 2023-05-20 03:44:48 --> Form Validation Class Initialized
INFO - 2023-05-20 03:44:48 --> Controller Class Initialized
INFO - 2023-05-20 03:44:48 --> Model Class Initialized
DEBUG - 2023-05-20 03:44:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-20 03:44:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 03:44:48 --> Config Class Initialized
INFO - 2023-05-20 03:44:48 --> Hooks Class Initialized
DEBUG - 2023-05-20 03:44:48 --> UTF-8 Support Enabled
INFO - 2023-05-20 03:44:48 --> Utf8 Class Initialized
INFO - 2023-05-20 03:44:48 --> URI Class Initialized
INFO - 2023-05-20 03:44:48 --> Router Class Initialized
INFO - 2023-05-20 03:44:48 --> Output Class Initialized
INFO - 2023-05-20 03:44:48 --> Security Class Initialized
DEBUG - 2023-05-20 03:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 03:44:48 --> Input Class Initialized
INFO - 2023-05-20 03:44:48 --> Language Class Initialized
INFO - 2023-05-20 03:44:48 --> Loader Class Initialized
INFO - 2023-05-20 03:44:48 --> Helper loaded: url_helper
INFO - 2023-05-20 03:44:48 --> Helper loaded: file_helper
INFO - 2023-05-20 03:44:48 --> Helper loaded: html_helper
INFO - 2023-05-20 03:44:48 --> Helper loaded: text_helper
INFO - 2023-05-20 03:44:48 --> Helper loaded: form_helper
INFO - 2023-05-20 03:44:48 --> Helper loaded: lang_helper
INFO - 2023-05-20 03:44:48 --> Helper loaded: security_helper
INFO - 2023-05-20 03:44:48 --> Helper loaded: cookie_helper
INFO - 2023-05-20 03:44:48 --> Database Driver Class Initialized
INFO - 2023-05-20 03:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 03:44:48 --> Parser Class Initialized
INFO - 2023-05-20 03:44:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 03:44:48 --> Pagination Class Initialized
INFO - 2023-05-20 03:44:48 --> Form Validation Class Initialized
INFO - 2023-05-20 03:44:48 --> Controller Class Initialized
INFO - 2023-05-20 03:44:48 --> Model Class Initialized
DEBUG - 2023-05-20 03:44:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:44:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-20 03:44:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:44:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 03:44:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 03:44:48 --> Model Class Initialized
INFO - 2023-05-20 03:44:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 03:44:48 --> Final output sent to browser
DEBUG - 2023-05-20 03:44:48 --> Total execution time: 0.0309
ERROR - 2023-05-20 03:44:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 03:44:55 --> Config Class Initialized
INFO - 2023-05-20 03:44:55 --> Hooks Class Initialized
DEBUG - 2023-05-20 03:44:55 --> UTF-8 Support Enabled
INFO - 2023-05-20 03:44:55 --> Utf8 Class Initialized
INFO - 2023-05-20 03:44:55 --> URI Class Initialized
INFO - 2023-05-20 03:44:55 --> Router Class Initialized
INFO - 2023-05-20 03:44:55 --> Output Class Initialized
INFO - 2023-05-20 03:44:55 --> Security Class Initialized
DEBUG - 2023-05-20 03:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 03:44:55 --> Input Class Initialized
INFO - 2023-05-20 03:44:55 --> Language Class Initialized
INFO - 2023-05-20 03:44:55 --> Loader Class Initialized
INFO - 2023-05-20 03:44:55 --> Helper loaded: url_helper
INFO - 2023-05-20 03:44:55 --> Helper loaded: file_helper
INFO - 2023-05-20 03:44:55 --> Helper loaded: html_helper
INFO - 2023-05-20 03:44:55 --> Helper loaded: text_helper
INFO - 2023-05-20 03:44:55 --> Helper loaded: form_helper
INFO - 2023-05-20 03:44:55 --> Helper loaded: lang_helper
INFO - 2023-05-20 03:44:55 --> Helper loaded: security_helper
INFO - 2023-05-20 03:44:55 --> Helper loaded: cookie_helper
INFO - 2023-05-20 03:44:55 --> Database Driver Class Initialized
INFO - 2023-05-20 03:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 03:44:55 --> Parser Class Initialized
INFO - 2023-05-20 03:44:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 03:44:55 --> Pagination Class Initialized
INFO - 2023-05-20 03:44:55 --> Form Validation Class Initialized
INFO - 2023-05-20 03:44:55 --> Controller Class Initialized
INFO - 2023-05-20 03:44:55 --> Model Class Initialized
DEBUG - 2023-05-20 03:44:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:44:55 --> Model Class Initialized
INFO - 2023-05-20 03:44:55 --> Final output sent to browser
DEBUG - 2023-05-20 03:44:55 --> Total execution time: 0.0182
ERROR - 2023-05-20 03:44:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 03:44:55 --> Config Class Initialized
INFO - 2023-05-20 03:44:55 --> Hooks Class Initialized
DEBUG - 2023-05-20 03:44:55 --> UTF-8 Support Enabled
INFO - 2023-05-20 03:44:55 --> Utf8 Class Initialized
INFO - 2023-05-20 03:44:55 --> URI Class Initialized
DEBUG - 2023-05-20 03:44:55 --> No URI present. Default controller set.
INFO - 2023-05-20 03:44:55 --> Router Class Initialized
INFO - 2023-05-20 03:44:55 --> Output Class Initialized
INFO - 2023-05-20 03:44:55 --> Security Class Initialized
DEBUG - 2023-05-20 03:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 03:44:55 --> Input Class Initialized
INFO - 2023-05-20 03:44:55 --> Language Class Initialized
INFO - 2023-05-20 03:44:55 --> Loader Class Initialized
INFO - 2023-05-20 03:44:55 --> Helper loaded: url_helper
INFO - 2023-05-20 03:44:55 --> Helper loaded: file_helper
INFO - 2023-05-20 03:44:55 --> Helper loaded: html_helper
INFO - 2023-05-20 03:44:55 --> Helper loaded: text_helper
INFO - 2023-05-20 03:44:55 --> Helper loaded: form_helper
INFO - 2023-05-20 03:44:55 --> Helper loaded: lang_helper
INFO - 2023-05-20 03:44:55 --> Helper loaded: security_helper
INFO - 2023-05-20 03:44:55 --> Helper loaded: cookie_helper
INFO - 2023-05-20 03:44:55 --> Database Driver Class Initialized
INFO - 2023-05-20 03:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 03:44:55 --> Parser Class Initialized
INFO - 2023-05-20 03:44:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 03:44:55 --> Pagination Class Initialized
INFO - 2023-05-20 03:44:55 --> Form Validation Class Initialized
INFO - 2023-05-20 03:44:55 --> Controller Class Initialized
INFO - 2023-05-20 03:44:55 --> Model Class Initialized
DEBUG - 2023-05-20 03:44:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:44:55 --> Model Class Initialized
DEBUG - 2023-05-20 03:44:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:44:55 --> Model Class Initialized
INFO - 2023-05-20 03:44:55 --> Model Class Initialized
INFO - 2023-05-20 03:44:55 --> Model Class Initialized
INFO - 2023-05-20 03:44:55 --> Model Class Initialized
DEBUG - 2023-05-20 03:44:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 03:44:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:44:55 --> Model Class Initialized
INFO - 2023-05-20 03:44:55 --> Model Class Initialized
INFO - 2023-05-20 03:44:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 03:44:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:44:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 03:44:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 03:44:55 --> Model Class Initialized
INFO - 2023-05-20 03:44:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 03:44:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 03:44:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 03:44:55 --> Final output sent to browser
DEBUG - 2023-05-20 03:44:55 --> Total execution time: 0.0742
ERROR - 2023-05-20 03:44:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 03:44:58 --> Config Class Initialized
INFO - 2023-05-20 03:44:58 --> Hooks Class Initialized
DEBUG - 2023-05-20 03:44:58 --> UTF-8 Support Enabled
INFO - 2023-05-20 03:44:58 --> Utf8 Class Initialized
INFO - 2023-05-20 03:44:58 --> URI Class Initialized
INFO - 2023-05-20 03:44:58 --> Router Class Initialized
INFO - 2023-05-20 03:44:58 --> Output Class Initialized
INFO - 2023-05-20 03:44:58 --> Security Class Initialized
DEBUG - 2023-05-20 03:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 03:44:58 --> Input Class Initialized
INFO - 2023-05-20 03:44:58 --> Language Class Initialized
INFO - 2023-05-20 03:44:58 --> Loader Class Initialized
INFO - 2023-05-20 03:44:58 --> Helper loaded: url_helper
INFO - 2023-05-20 03:44:58 --> Helper loaded: file_helper
INFO - 2023-05-20 03:44:58 --> Helper loaded: html_helper
INFO - 2023-05-20 03:44:58 --> Helper loaded: text_helper
INFO - 2023-05-20 03:44:58 --> Helper loaded: form_helper
INFO - 2023-05-20 03:44:58 --> Helper loaded: lang_helper
INFO - 2023-05-20 03:44:58 --> Helper loaded: security_helper
INFO - 2023-05-20 03:44:58 --> Helper loaded: cookie_helper
INFO - 2023-05-20 03:44:58 --> Database Driver Class Initialized
INFO - 2023-05-20 03:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 03:44:58 --> Parser Class Initialized
INFO - 2023-05-20 03:44:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 03:44:58 --> Pagination Class Initialized
INFO - 2023-05-20 03:44:58 --> Form Validation Class Initialized
INFO - 2023-05-20 03:44:58 --> Controller Class Initialized
INFO - 2023-05-20 03:44:58 --> Model Class Initialized
INFO - 2023-05-20 03:44:58 --> Model Class Initialized
INFO - 2023-05-20 03:44:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-05-20 03:44:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 03:44:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 03:44:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 03:44:58 --> Model Class Initialized
INFO - 2023-05-20 03:44:58 --> Model Class Initialized
INFO - 2023-05-20 03:44:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 03:44:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 03:44:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 03:44:58 --> Final output sent to browser
DEBUG - 2023-05-20 03:44:58 --> Total execution time: 0.0584
ERROR - 2023-05-20 03:44:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 03:44:58 --> Config Class Initialized
INFO - 2023-05-20 03:44:58 --> Hooks Class Initialized
DEBUG - 2023-05-20 03:44:58 --> UTF-8 Support Enabled
INFO - 2023-05-20 03:44:58 --> Utf8 Class Initialized
INFO - 2023-05-20 03:44:58 --> URI Class Initialized
INFO - 2023-05-20 03:44:58 --> Router Class Initialized
INFO - 2023-05-20 03:44:58 --> Output Class Initialized
INFO - 2023-05-20 03:44:58 --> Security Class Initialized
DEBUG - 2023-05-20 03:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 03:44:58 --> Input Class Initialized
INFO - 2023-05-20 03:44:58 --> Language Class Initialized
INFO - 2023-05-20 03:44:58 --> Loader Class Initialized
INFO - 2023-05-20 03:44:58 --> Helper loaded: url_helper
INFO - 2023-05-20 03:44:58 --> Helper loaded: file_helper
INFO - 2023-05-20 03:44:58 --> Helper loaded: html_helper
INFO - 2023-05-20 03:44:58 --> Helper loaded: text_helper
INFO - 2023-05-20 03:44:58 --> Helper loaded: form_helper
INFO - 2023-05-20 03:44:58 --> Helper loaded: lang_helper
INFO - 2023-05-20 03:44:58 --> Helper loaded: security_helper
INFO - 2023-05-20 03:44:58 --> Helper loaded: cookie_helper
INFO - 2023-05-20 03:44:58 --> Database Driver Class Initialized
INFO - 2023-05-20 03:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 03:44:58 --> Parser Class Initialized
INFO - 2023-05-20 03:44:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 03:44:58 --> Pagination Class Initialized
INFO - 2023-05-20 03:44:58 --> Form Validation Class Initialized
INFO - 2023-05-20 03:44:58 --> Controller Class Initialized
INFO - 2023-05-20 03:44:58 --> Model Class Initialized
INFO - 2023-05-20 03:44:58 --> Model Class Initialized
INFO - 2023-05-20 03:44:58 --> Final output sent to browser
DEBUG - 2023-05-20 03:44:58 --> Total execution time: 0.0175
ERROR - 2023-05-20 04:32:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:32:42 --> Config Class Initialized
INFO - 2023-05-20 04:32:42 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:32:42 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:32:42 --> Utf8 Class Initialized
INFO - 2023-05-20 04:32:42 --> URI Class Initialized
DEBUG - 2023-05-20 04:32:42 --> No URI present. Default controller set.
INFO - 2023-05-20 04:32:42 --> Router Class Initialized
INFO - 2023-05-20 04:32:42 --> Output Class Initialized
INFO - 2023-05-20 04:32:42 --> Security Class Initialized
DEBUG - 2023-05-20 04:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:32:42 --> Input Class Initialized
INFO - 2023-05-20 04:32:42 --> Language Class Initialized
INFO - 2023-05-20 04:32:42 --> Loader Class Initialized
INFO - 2023-05-20 04:32:42 --> Helper loaded: url_helper
INFO - 2023-05-20 04:32:42 --> Helper loaded: file_helper
INFO - 2023-05-20 04:32:42 --> Helper loaded: html_helper
INFO - 2023-05-20 04:32:42 --> Helper loaded: text_helper
INFO - 2023-05-20 04:32:42 --> Helper loaded: form_helper
INFO - 2023-05-20 04:32:42 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:32:42 --> Helper loaded: security_helper
INFO - 2023-05-20 04:32:42 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:32:42 --> Database Driver Class Initialized
INFO - 2023-05-20 04:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:32:42 --> Parser Class Initialized
INFO - 2023-05-20 04:32:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:32:42 --> Pagination Class Initialized
INFO - 2023-05-20 04:32:42 --> Form Validation Class Initialized
INFO - 2023-05-20 04:32:42 --> Controller Class Initialized
INFO - 2023-05-20 04:32:42 --> Model Class Initialized
DEBUG - 2023-05-20 04:32:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-20 04:47:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:47:07 --> Config Class Initialized
INFO - 2023-05-20 04:47:07 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:47:07 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:47:07 --> Utf8 Class Initialized
INFO - 2023-05-20 04:47:07 --> URI Class Initialized
DEBUG - 2023-05-20 04:47:07 --> No URI present. Default controller set.
INFO - 2023-05-20 04:47:07 --> Router Class Initialized
INFO - 2023-05-20 04:47:07 --> Output Class Initialized
INFO - 2023-05-20 04:47:07 --> Security Class Initialized
DEBUG - 2023-05-20 04:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:47:07 --> Input Class Initialized
INFO - 2023-05-20 04:47:07 --> Language Class Initialized
INFO - 2023-05-20 04:47:07 --> Loader Class Initialized
INFO - 2023-05-20 04:47:07 --> Helper loaded: url_helper
INFO - 2023-05-20 04:47:07 --> Helper loaded: file_helper
INFO - 2023-05-20 04:47:07 --> Helper loaded: html_helper
INFO - 2023-05-20 04:47:07 --> Helper loaded: text_helper
INFO - 2023-05-20 04:47:07 --> Helper loaded: form_helper
INFO - 2023-05-20 04:47:07 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:47:07 --> Helper loaded: security_helper
INFO - 2023-05-20 04:47:07 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:47:07 --> Database Driver Class Initialized
INFO - 2023-05-20 04:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:47:07 --> Parser Class Initialized
INFO - 2023-05-20 04:47:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:47:07 --> Pagination Class Initialized
INFO - 2023-05-20 04:47:07 --> Form Validation Class Initialized
INFO - 2023-05-20 04:47:07 --> Controller Class Initialized
INFO - 2023-05-20 04:47:07 --> Model Class Initialized
DEBUG - 2023-05-20 04:47:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-20 04:47:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:47:07 --> Config Class Initialized
INFO - 2023-05-20 04:47:07 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:47:07 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:47:07 --> Utf8 Class Initialized
INFO - 2023-05-20 04:47:07 --> URI Class Initialized
INFO - 2023-05-20 04:47:07 --> Router Class Initialized
INFO - 2023-05-20 04:47:07 --> Output Class Initialized
INFO - 2023-05-20 04:47:07 --> Security Class Initialized
DEBUG - 2023-05-20 04:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:47:07 --> Input Class Initialized
INFO - 2023-05-20 04:47:07 --> Language Class Initialized
INFO - 2023-05-20 04:47:07 --> Loader Class Initialized
INFO - 2023-05-20 04:47:07 --> Helper loaded: url_helper
INFO - 2023-05-20 04:47:07 --> Helper loaded: file_helper
INFO - 2023-05-20 04:47:07 --> Helper loaded: html_helper
INFO - 2023-05-20 04:47:07 --> Helper loaded: text_helper
INFO - 2023-05-20 04:47:07 --> Helper loaded: form_helper
INFO - 2023-05-20 04:47:07 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:47:07 --> Helper loaded: security_helper
INFO - 2023-05-20 04:47:07 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:47:07 --> Database Driver Class Initialized
INFO - 2023-05-20 04:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:47:07 --> Parser Class Initialized
INFO - 2023-05-20 04:47:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:47:07 --> Pagination Class Initialized
INFO - 2023-05-20 04:47:07 --> Form Validation Class Initialized
INFO - 2023-05-20 04:47:07 --> Controller Class Initialized
INFO - 2023-05-20 04:47:07 --> Model Class Initialized
DEBUG - 2023-05-20 04:47:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:47:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-20 04:47:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:47:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 04:47:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 04:47:07 --> Model Class Initialized
INFO - 2023-05-20 04:47:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 04:47:07 --> Final output sent to browser
DEBUG - 2023-05-20 04:47:07 --> Total execution time: 0.0335
ERROR - 2023-05-20 04:47:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:47:11 --> Config Class Initialized
INFO - 2023-05-20 04:47:11 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:47:11 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:47:11 --> Utf8 Class Initialized
INFO - 2023-05-20 04:47:11 --> URI Class Initialized
INFO - 2023-05-20 04:47:11 --> Router Class Initialized
INFO - 2023-05-20 04:47:11 --> Output Class Initialized
INFO - 2023-05-20 04:47:11 --> Security Class Initialized
DEBUG - 2023-05-20 04:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:47:11 --> Input Class Initialized
INFO - 2023-05-20 04:47:11 --> Language Class Initialized
INFO - 2023-05-20 04:47:11 --> Loader Class Initialized
INFO - 2023-05-20 04:47:11 --> Helper loaded: url_helper
INFO - 2023-05-20 04:47:11 --> Helper loaded: file_helper
INFO - 2023-05-20 04:47:11 --> Helper loaded: html_helper
INFO - 2023-05-20 04:47:11 --> Helper loaded: text_helper
INFO - 2023-05-20 04:47:11 --> Helper loaded: form_helper
INFO - 2023-05-20 04:47:11 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:47:11 --> Helper loaded: security_helper
INFO - 2023-05-20 04:47:11 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:47:11 --> Database Driver Class Initialized
INFO - 2023-05-20 04:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:47:11 --> Parser Class Initialized
INFO - 2023-05-20 04:47:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:47:11 --> Pagination Class Initialized
INFO - 2023-05-20 04:47:11 --> Form Validation Class Initialized
INFO - 2023-05-20 04:47:11 --> Controller Class Initialized
INFO - 2023-05-20 04:47:11 --> Model Class Initialized
DEBUG - 2023-05-20 04:47:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:47:11 --> Model Class Initialized
INFO - 2023-05-20 04:47:11 --> Final output sent to browser
DEBUG - 2023-05-20 04:47:11 --> Total execution time: 0.0216
ERROR - 2023-05-20 04:47:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:47:11 --> Config Class Initialized
INFO - 2023-05-20 04:47:11 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:47:11 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:47:11 --> Utf8 Class Initialized
INFO - 2023-05-20 04:47:11 --> URI Class Initialized
DEBUG - 2023-05-20 04:47:11 --> No URI present. Default controller set.
INFO - 2023-05-20 04:47:11 --> Router Class Initialized
INFO - 2023-05-20 04:47:11 --> Output Class Initialized
INFO - 2023-05-20 04:47:11 --> Security Class Initialized
DEBUG - 2023-05-20 04:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:47:11 --> Input Class Initialized
INFO - 2023-05-20 04:47:11 --> Language Class Initialized
INFO - 2023-05-20 04:47:11 --> Loader Class Initialized
INFO - 2023-05-20 04:47:11 --> Helper loaded: url_helper
INFO - 2023-05-20 04:47:11 --> Helper loaded: file_helper
INFO - 2023-05-20 04:47:11 --> Helper loaded: html_helper
INFO - 2023-05-20 04:47:11 --> Helper loaded: text_helper
INFO - 2023-05-20 04:47:11 --> Helper loaded: form_helper
INFO - 2023-05-20 04:47:11 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:47:11 --> Helper loaded: security_helper
INFO - 2023-05-20 04:47:11 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:47:11 --> Database Driver Class Initialized
INFO - 2023-05-20 04:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:47:11 --> Parser Class Initialized
INFO - 2023-05-20 04:47:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:47:11 --> Pagination Class Initialized
INFO - 2023-05-20 04:47:11 --> Form Validation Class Initialized
INFO - 2023-05-20 04:47:11 --> Controller Class Initialized
INFO - 2023-05-20 04:47:11 --> Model Class Initialized
DEBUG - 2023-05-20 04:47:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:47:11 --> Model Class Initialized
DEBUG - 2023-05-20 04:47:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:47:11 --> Model Class Initialized
INFO - 2023-05-20 04:47:11 --> Model Class Initialized
INFO - 2023-05-20 04:47:11 --> Model Class Initialized
INFO - 2023-05-20 04:47:11 --> Model Class Initialized
DEBUG - 2023-05-20 04:47:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:47:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:47:11 --> Model Class Initialized
INFO - 2023-05-20 04:47:11 --> Model Class Initialized
INFO - 2023-05-20 04:47:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 04:47:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:47:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 04:47:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 04:47:11 --> Model Class Initialized
INFO - 2023-05-20 04:47:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 04:47:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 04:47:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 04:47:11 --> Final output sent to browser
DEBUG - 2023-05-20 04:47:11 --> Total execution time: 0.1972
ERROR - 2023-05-20 04:47:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:47:12 --> Config Class Initialized
INFO - 2023-05-20 04:47:12 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:47:12 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:47:12 --> Utf8 Class Initialized
INFO - 2023-05-20 04:47:12 --> URI Class Initialized
INFO - 2023-05-20 04:47:12 --> Router Class Initialized
INFO - 2023-05-20 04:47:12 --> Output Class Initialized
INFO - 2023-05-20 04:47:12 --> Security Class Initialized
DEBUG - 2023-05-20 04:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:47:12 --> Input Class Initialized
INFO - 2023-05-20 04:47:12 --> Language Class Initialized
INFO - 2023-05-20 04:47:12 --> Loader Class Initialized
INFO - 2023-05-20 04:47:12 --> Helper loaded: url_helper
INFO - 2023-05-20 04:47:12 --> Helper loaded: file_helper
INFO - 2023-05-20 04:47:12 --> Helper loaded: html_helper
INFO - 2023-05-20 04:47:12 --> Helper loaded: text_helper
INFO - 2023-05-20 04:47:12 --> Helper loaded: form_helper
INFO - 2023-05-20 04:47:12 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:47:12 --> Helper loaded: security_helper
INFO - 2023-05-20 04:47:12 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:47:12 --> Database Driver Class Initialized
INFO - 2023-05-20 04:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:47:12 --> Parser Class Initialized
INFO - 2023-05-20 04:47:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:47:12 --> Pagination Class Initialized
INFO - 2023-05-20 04:47:12 --> Form Validation Class Initialized
INFO - 2023-05-20 04:47:12 --> Controller Class Initialized
DEBUG - 2023-05-20 04:47:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:47:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:47:12 --> Model Class Initialized
INFO - 2023-05-20 04:47:12 --> Final output sent to browser
DEBUG - 2023-05-20 04:47:12 --> Total execution time: 0.0136
ERROR - 2023-05-20 04:47:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:47:36 --> Config Class Initialized
INFO - 2023-05-20 04:47:36 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:47:36 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:47:36 --> Utf8 Class Initialized
INFO - 2023-05-20 04:47:36 --> URI Class Initialized
DEBUG - 2023-05-20 04:47:36 --> No URI present. Default controller set.
INFO - 2023-05-20 04:47:36 --> Router Class Initialized
INFO - 2023-05-20 04:47:36 --> Output Class Initialized
INFO - 2023-05-20 04:47:36 --> Security Class Initialized
DEBUG - 2023-05-20 04:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:47:36 --> Input Class Initialized
INFO - 2023-05-20 04:47:36 --> Language Class Initialized
INFO - 2023-05-20 04:47:36 --> Loader Class Initialized
INFO - 2023-05-20 04:47:36 --> Helper loaded: url_helper
INFO - 2023-05-20 04:47:36 --> Helper loaded: file_helper
INFO - 2023-05-20 04:47:36 --> Helper loaded: html_helper
INFO - 2023-05-20 04:47:36 --> Helper loaded: text_helper
INFO - 2023-05-20 04:47:36 --> Helper loaded: form_helper
INFO - 2023-05-20 04:47:36 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:47:36 --> Helper loaded: security_helper
INFO - 2023-05-20 04:47:36 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:47:36 --> Database Driver Class Initialized
INFO - 2023-05-20 04:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:47:36 --> Parser Class Initialized
INFO - 2023-05-20 04:47:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:47:36 --> Pagination Class Initialized
INFO - 2023-05-20 04:47:36 --> Form Validation Class Initialized
INFO - 2023-05-20 04:47:36 --> Controller Class Initialized
INFO - 2023-05-20 04:47:36 --> Model Class Initialized
DEBUG - 2023-05-20 04:47:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-20 04:47:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:47:36 --> Config Class Initialized
INFO - 2023-05-20 04:47:36 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:47:36 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:47:36 --> Utf8 Class Initialized
INFO - 2023-05-20 04:47:36 --> URI Class Initialized
INFO - 2023-05-20 04:47:36 --> Router Class Initialized
INFO - 2023-05-20 04:47:36 --> Output Class Initialized
INFO - 2023-05-20 04:47:36 --> Security Class Initialized
DEBUG - 2023-05-20 04:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:47:36 --> Input Class Initialized
INFO - 2023-05-20 04:47:36 --> Language Class Initialized
INFO - 2023-05-20 04:47:36 --> Loader Class Initialized
INFO - 2023-05-20 04:47:36 --> Helper loaded: url_helper
INFO - 2023-05-20 04:47:36 --> Helper loaded: file_helper
INFO - 2023-05-20 04:47:36 --> Helper loaded: html_helper
INFO - 2023-05-20 04:47:36 --> Helper loaded: text_helper
INFO - 2023-05-20 04:47:36 --> Helper loaded: form_helper
INFO - 2023-05-20 04:47:36 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:47:36 --> Helper loaded: security_helper
INFO - 2023-05-20 04:47:36 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:47:36 --> Database Driver Class Initialized
INFO - 2023-05-20 04:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:47:36 --> Parser Class Initialized
INFO - 2023-05-20 04:47:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:47:36 --> Pagination Class Initialized
INFO - 2023-05-20 04:47:36 --> Form Validation Class Initialized
INFO - 2023-05-20 04:47:36 --> Controller Class Initialized
INFO - 2023-05-20 04:47:36 --> Model Class Initialized
DEBUG - 2023-05-20 04:47:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:47:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-20 04:47:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:47:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 04:47:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 04:47:36 --> Model Class Initialized
INFO - 2023-05-20 04:47:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 04:47:36 --> Final output sent to browser
DEBUG - 2023-05-20 04:47:36 --> Total execution time: 0.0364
ERROR - 2023-05-20 04:47:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:47:54 --> Config Class Initialized
INFO - 2023-05-20 04:47:54 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:47:54 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:47:54 --> Utf8 Class Initialized
INFO - 2023-05-20 04:47:54 --> URI Class Initialized
INFO - 2023-05-20 04:47:54 --> Router Class Initialized
INFO - 2023-05-20 04:47:54 --> Output Class Initialized
INFO - 2023-05-20 04:47:54 --> Security Class Initialized
DEBUG - 2023-05-20 04:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:47:54 --> Input Class Initialized
INFO - 2023-05-20 04:47:54 --> Language Class Initialized
INFO - 2023-05-20 04:47:54 --> Loader Class Initialized
INFO - 2023-05-20 04:47:54 --> Helper loaded: url_helper
INFO - 2023-05-20 04:47:54 --> Helper loaded: file_helper
INFO - 2023-05-20 04:47:54 --> Helper loaded: html_helper
INFO - 2023-05-20 04:47:54 --> Helper loaded: text_helper
INFO - 2023-05-20 04:47:54 --> Helper loaded: form_helper
INFO - 2023-05-20 04:47:54 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:47:54 --> Helper loaded: security_helper
INFO - 2023-05-20 04:47:54 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:47:54 --> Database Driver Class Initialized
INFO - 2023-05-20 04:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:47:54 --> Parser Class Initialized
INFO - 2023-05-20 04:47:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:47:54 --> Pagination Class Initialized
INFO - 2023-05-20 04:47:54 --> Form Validation Class Initialized
INFO - 2023-05-20 04:47:54 --> Controller Class Initialized
INFO - 2023-05-20 04:47:54 --> Model Class Initialized
DEBUG - 2023-05-20 04:47:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:47:54 --> Model Class Initialized
INFO - 2023-05-20 04:47:54 --> Final output sent to browser
DEBUG - 2023-05-20 04:47:54 --> Total execution time: 0.0203
ERROR - 2023-05-20 04:47:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:47:55 --> Config Class Initialized
INFO - 2023-05-20 04:47:55 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:47:55 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:47:55 --> Utf8 Class Initialized
INFO - 2023-05-20 04:47:55 --> URI Class Initialized
DEBUG - 2023-05-20 04:47:55 --> No URI present. Default controller set.
INFO - 2023-05-20 04:47:55 --> Router Class Initialized
INFO - 2023-05-20 04:47:55 --> Output Class Initialized
INFO - 2023-05-20 04:47:55 --> Security Class Initialized
DEBUG - 2023-05-20 04:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:47:55 --> Input Class Initialized
INFO - 2023-05-20 04:47:55 --> Language Class Initialized
INFO - 2023-05-20 04:47:55 --> Loader Class Initialized
INFO - 2023-05-20 04:47:55 --> Helper loaded: url_helper
INFO - 2023-05-20 04:47:55 --> Helper loaded: file_helper
INFO - 2023-05-20 04:47:55 --> Helper loaded: html_helper
INFO - 2023-05-20 04:47:55 --> Helper loaded: text_helper
INFO - 2023-05-20 04:47:55 --> Helper loaded: form_helper
INFO - 2023-05-20 04:47:55 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:47:55 --> Helper loaded: security_helper
INFO - 2023-05-20 04:47:55 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:47:55 --> Database Driver Class Initialized
INFO - 2023-05-20 04:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:47:55 --> Parser Class Initialized
INFO - 2023-05-20 04:47:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:47:55 --> Pagination Class Initialized
INFO - 2023-05-20 04:47:55 --> Form Validation Class Initialized
INFO - 2023-05-20 04:47:55 --> Controller Class Initialized
INFO - 2023-05-20 04:47:55 --> Model Class Initialized
DEBUG - 2023-05-20 04:47:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:47:55 --> Model Class Initialized
DEBUG - 2023-05-20 04:47:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:47:55 --> Model Class Initialized
INFO - 2023-05-20 04:47:55 --> Model Class Initialized
INFO - 2023-05-20 04:47:55 --> Model Class Initialized
INFO - 2023-05-20 04:47:55 --> Model Class Initialized
DEBUG - 2023-05-20 04:47:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:47:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:47:55 --> Model Class Initialized
INFO - 2023-05-20 04:47:55 --> Model Class Initialized
INFO - 2023-05-20 04:47:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 04:47:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:47:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 04:47:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 04:47:55 --> Model Class Initialized
INFO - 2023-05-20 04:47:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 04:47:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 04:47:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 04:47:55 --> Final output sent to browser
DEBUG - 2023-05-20 04:47:55 --> Total execution time: 0.0841
ERROR - 2023-05-20 04:48:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:48:00 --> Config Class Initialized
INFO - 2023-05-20 04:48:00 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:48:00 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:48:00 --> Utf8 Class Initialized
INFO - 2023-05-20 04:48:00 --> URI Class Initialized
INFO - 2023-05-20 04:48:00 --> Router Class Initialized
INFO - 2023-05-20 04:48:00 --> Output Class Initialized
INFO - 2023-05-20 04:48:00 --> Security Class Initialized
DEBUG - 2023-05-20 04:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:48:00 --> Input Class Initialized
INFO - 2023-05-20 04:48:00 --> Language Class Initialized
INFO - 2023-05-20 04:48:00 --> Loader Class Initialized
INFO - 2023-05-20 04:48:00 --> Helper loaded: url_helper
INFO - 2023-05-20 04:48:00 --> Helper loaded: file_helper
INFO - 2023-05-20 04:48:00 --> Helper loaded: html_helper
INFO - 2023-05-20 04:48:00 --> Helper loaded: text_helper
INFO - 2023-05-20 04:48:00 --> Helper loaded: form_helper
INFO - 2023-05-20 04:48:00 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:48:00 --> Helper loaded: security_helper
INFO - 2023-05-20 04:48:00 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:48:00 --> Database Driver Class Initialized
INFO - 2023-05-20 04:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:48:00 --> Parser Class Initialized
INFO - 2023-05-20 04:48:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:48:00 --> Pagination Class Initialized
INFO - 2023-05-20 04:48:00 --> Form Validation Class Initialized
INFO - 2023-05-20 04:48:00 --> Controller Class Initialized
INFO - 2023-05-20 04:48:00 --> Model Class Initialized
DEBUG - 2023-05-20 04:48:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:48:00 --> Final output sent to browser
DEBUG - 2023-05-20 04:48:00 --> Total execution time: 0.0159
ERROR - 2023-05-20 04:48:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:48:01 --> Config Class Initialized
INFO - 2023-05-20 04:48:01 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:48:01 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:48:01 --> Utf8 Class Initialized
INFO - 2023-05-20 04:48:01 --> URI Class Initialized
INFO - 2023-05-20 04:48:01 --> Router Class Initialized
INFO - 2023-05-20 04:48:01 --> Output Class Initialized
INFO - 2023-05-20 04:48:01 --> Security Class Initialized
DEBUG - 2023-05-20 04:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:48:01 --> Input Class Initialized
INFO - 2023-05-20 04:48:01 --> Language Class Initialized
INFO - 2023-05-20 04:48:01 --> Loader Class Initialized
INFO - 2023-05-20 04:48:01 --> Helper loaded: url_helper
INFO - 2023-05-20 04:48:01 --> Helper loaded: file_helper
INFO - 2023-05-20 04:48:01 --> Helper loaded: html_helper
INFO - 2023-05-20 04:48:01 --> Helper loaded: text_helper
INFO - 2023-05-20 04:48:01 --> Helper loaded: form_helper
INFO - 2023-05-20 04:48:01 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:48:01 --> Helper loaded: security_helper
INFO - 2023-05-20 04:48:01 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:48:01 --> Database Driver Class Initialized
INFO - 2023-05-20 04:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:48:01 --> Parser Class Initialized
INFO - 2023-05-20 04:48:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:48:01 --> Pagination Class Initialized
INFO - 2023-05-20 04:48:01 --> Form Validation Class Initialized
INFO - 2023-05-20 04:48:01 --> Controller Class Initialized
INFO - 2023-05-20 04:48:01 --> Model Class Initialized
DEBUG - 2023-05-20 04:48:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:48:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-20 04:48:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:48:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 04:48:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 04:48:01 --> Model Class Initialized
INFO - 2023-05-20 04:48:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 04:48:01 --> Final output sent to browser
DEBUG - 2023-05-20 04:48:01 --> Total execution time: 0.0281
ERROR - 2023-05-20 04:48:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:48:06 --> Config Class Initialized
INFO - 2023-05-20 04:48:06 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:48:06 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:48:06 --> Utf8 Class Initialized
INFO - 2023-05-20 04:48:06 --> URI Class Initialized
INFO - 2023-05-20 04:48:06 --> Router Class Initialized
INFO - 2023-05-20 04:48:06 --> Output Class Initialized
INFO - 2023-05-20 04:48:06 --> Security Class Initialized
DEBUG - 2023-05-20 04:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:48:06 --> Input Class Initialized
INFO - 2023-05-20 04:48:06 --> Language Class Initialized
INFO - 2023-05-20 04:48:06 --> Loader Class Initialized
INFO - 2023-05-20 04:48:06 --> Helper loaded: url_helper
INFO - 2023-05-20 04:48:06 --> Helper loaded: file_helper
INFO - 2023-05-20 04:48:06 --> Helper loaded: html_helper
INFO - 2023-05-20 04:48:06 --> Helper loaded: text_helper
INFO - 2023-05-20 04:48:06 --> Helper loaded: form_helper
INFO - 2023-05-20 04:48:06 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:48:06 --> Helper loaded: security_helper
INFO - 2023-05-20 04:48:06 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:48:06 --> Database Driver Class Initialized
INFO - 2023-05-20 04:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:48:06 --> Parser Class Initialized
INFO - 2023-05-20 04:48:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:48:06 --> Pagination Class Initialized
INFO - 2023-05-20 04:48:06 --> Form Validation Class Initialized
INFO - 2023-05-20 04:48:06 --> Controller Class Initialized
INFO - 2023-05-20 04:48:06 --> Model Class Initialized
DEBUG - 2023-05-20 04:48:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:48:06 --> Model Class Initialized
INFO - 2023-05-20 04:48:06 --> Final output sent to browser
DEBUG - 2023-05-20 04:48:06 --> Total execution time: 0.0157
ERROR - 2023-05-20 04:48:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:48:07 --> Config Class Initialized
INFO - 2023-05-20 04:48:07 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:48:07 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:48:07 --> Utf8 Class Initialized
INFO - 2023-05-20 04:48:07 --> URI Class Initialized
DEBUG - 2023-05-20 04:48:07 --> No URI present. Default controller set.
INFO - 2023-05-20 04:48:07 --> Router Class Initialized
INFO - 2023-05-20 04:48:07 --> Output Class Initialized
INFO - 2023-05-20 04:48:07 --> Security Class Initialized
DEBUG - 2023-05-20 04:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:48:07 --> Input Class Initialized
INFO - 2023-05-20 04:48:07 --> Language Class Initialized
INFO - 2023-05-20 04:48:07 --> Loader Class Initialized
INFO - 2023-05-20 04:48:07 --> Helper loaded: url_helper
INFO - 2023-05-20 04:48:07 --> Helper loaded: file_helper
INFO - 2023-05-20 04:48:07 --> Helper loaded: html_helper
INFO - 2023-05-20 04:48:07 --> Helper loaded: text_helper
INFO - 2023-05-20 04:48:07 --> Helper loaded: form_helper
INFO - 2023-05-20 04:48:07 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:48:07 --> Helper loaded: security_helper
INFO - 2023-05-20 04:48:07 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:48:07 --> Database Driver Class Initialized
INFO - 2023-05-20 04:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:48:07 --> Parser Class Initialized
INFO - 2023-05-20 04:48:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:48:07 --> Pagination Class Initialized
INFO - 2023-05-20 04:48:07 --> Form Validation Class Initialized
INFO - 2023-05-20 04:48:07 --> Controller Class Initialized
INFO - 2023-05-20 04:48:07 --> Model Class Initialized
DEBUG - 2023-05-20 04:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:48:07 --> Model Class Initialized
DEBUG - 2023-05-20 04:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:48:07 --> Model Class Initialized
INFO - 2023-05-20 04:48:07 --> Model Class Initialized
INFO - 2023-05-20 04:48:07 --> Model Class Initialized
INFO - 2023-05-20 04:48:07 --> Model Class Initialized
DEBUG - 2023-05-20 04:48:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:48:07 --> Model Class Initialized
INFO - 2023-05-20 04:48:07 --> Model Class Initialized
INFO - 2023-05-20 04:48:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 04:48:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:48:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 04:48:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 04:48:07 --> Model Class Initialized
INFO - 2023-05-20 04:48:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 04:48:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 04:48:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 04:48:07 --> Final output sent to browser
DEBUG - 2023-05-20 04:48:07 --> Total execution time: 0.0843
ERROR - 2023-05-20 04:48:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:48:54 --> Config Class Initialized
INFO - 2023-05-20 04:48:54 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:48:54 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:48:54 --> Utf8 Class Initialized
INFO - 2023-05-20 04:48:54 --> URI Class Initialized
INFO - 2023-05-20 04:48:54 --> Router Class Initialized
INFO - 2023-05-20 04:48:54 --> Output Class Initialized
INFO - 2023-05-20 04:48:54 --> Security Class Initialized
DEBUG - 2023-05-20 04:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:48:54 --> Input Class Initialized
INFO - 2023-05-20 04:48:54 --> Language Class Initialized
INFO - 2023-05-20 04:48:54 --> Loader Class Initialized
INFO - 2023-05-20 04:48:54 --> Helper loaded: url_helper
INFO - 2023-05-20 04:48:54 --> Helper loaded: file_helper
INFO - 2023-05-20 04:48:54 --> Helper loaded: html_helper
INFO - 2023-05-20 04:48:54 --> Helper loaded: text_helper
INFO - 2023-05-20 04:48:54 --> Helper loaded: form_helper
INFO - 2023-05-20 04:48:54 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:48:54 --> Helper loaded: security_helper
INFO - 2023-05-20 04:48:54 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:48:54 --> Database Driver Class Initialized
INFO - 2023-05-20 04:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:48:54 --> Parser Class Initialized
INFO - 2023-05-20 04:48:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:48:54 --> Pagination Class Initialized
INFO - 2023-05-20 04:48:54 --> Form Validation Class Initialized
INFO - 2023-05-20 04:48:54 --> Controller Class Initialized
INFO - 2023-05-20 04:48:54 --> Model Class Initialized
DEBUG - 2023-05-20 04:48:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:48:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:48:54 --> Model Class Initialized
DEBUG - 2023-05-20 04:48:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:48:54 --> Model Class Initialized
INFO - 2023-05-20 04:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-20 04:48:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 04:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 04:48:54 --> Model Class Initialized
INFO - 2023-05-20 04:48:54 --> Model Class Initialized
INFO - 2023-05-20 04:48:54 --> Model Class Initialized
INFO - 2023-05-20 04:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 04:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 04:48:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 04:48:54 --> Final output sent to browser
DEBUG - 2023-05-20 04:48:54 --> Total execution time: 0.0743
ERROR - 2023-05-20 04:48:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:48:55 --> Config Class Initialized
INFO - 2023-05-20 04:48:55 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:48:55 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:48:55 --> Utf8 Class Initialized
INFO - 2023-05-20 04:48:55 --> URI Class Initialized
INFO - 2023-05-20 04:48:55 --> Router Class Initialized
INFO - 2023-05-20 04:48:55 --> Output Class Initialized
INFO - 2023-05-20 04:48:55 --> Security Class Initialized
DEBUG - 2023-05-20 04:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:48:55 --> Input Class Initialized
INFO - 2023-05-20 04:48:55 --> Language Class Initialized
INFO - 2023-05-20 04:48:55 --> Loader Class Initialized
INFO - 2023-05-20 04:48:55 --> Helper loaded: url_helper
INFO - 2023-05-20 04:48:55 --> Helper loaded: file_helper
INFO - 2023-05-20 04:48:55 --> Helper loaded: html_helper
INFO - 2023-05-20 04:48:55 --> Helper loaded: text_helper
INFO - 2023-05-20 04:48:55 --> Helper loaded: form_helper
INFO - 2023-05-20 04:48:55 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:48:55 --> Helper loaded: security_helper
INFO - 2023-05-20 04:48:55 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:48:55 --> Database Driver Class Initialized
INFO - 2023-05-20 04:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:48:55 --> Parser Class Initialized
INFO - 2023-05-20 04:48:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:48:55 --> Pagination Class Initialized
INFO - 2023-05-20 04:48:55 --> Form Validation Class Initialized
INFO - 2023-05-20 04:48:55 --> Controller Class Initialized
INFO - 2023-05-20 04:48:55 --> Model Class Initialized
DEBUG - 2023-05-20 04:48:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:48:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:48:55 --> Model Class Initialized
DEBUG - 2023-05-20 04:48:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:48:55 --> Model Class Initialized
INFO - 2023-05-20 04:48:55 --> Final output sent to browser
DEBUG - 2023-05-20 04:48:55 --> Total execution time: 0.0430
ERROR - 2023-05-20 04:48:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:48:57 --> Config Class Initialized
INFO - 2023-05-20 04:48:57 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:48:57 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:48:57 --> Utf8 Class Initialized
INFO - 2023-05-20 04:48:57 --> URI Class Initialized
DEBUG - 2023-05-20 04:48:57 --> No URI present. Default controller set.
INFO - 2023-05-20 04:48:57 --> Router Class Initialized
INFO - 2023-05-20 04:48:57 --> Output Class Initialized
INFO - 2023-05-20 04:48:57 --> Security Class Initialized
DEBUG - 2023-05-20 04:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:48:57 --> Input Class Initialized
INFO - 2023-05-20 04:48:57 --> Language Class Initialized
INFO - 2023-05-20 04:48:57 --> Loader Class Initialized
INFO - 2023-05-20 04:48:57 --> Helper loaded: url_helper
INFO - 2023-05-20 04:48:57 --> Helper loaded: file_helper
INFO - 2023-05-20 04:48:57 --> Helper loaded: html_helper
INFO - 2023-05-20 04:48:57 --> Helper loaded: text_helper
INFO - 2023-05-20 04:48:57 --> Helper loaded: form_helper
INFO - 2023-05-20 04:48:57 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:48:57 --> Helper loaded: security_helper
INFO - 2023-05-20 04:48:57 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:48:57 --> Database Driver Class Initialized
INFO - 2023-05-20 04:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:48:57 --> Parser Class Initialized
INFO - 2023-05-20 04:48:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:48:57 --> Pagination Class Initialized
INFO - 2023-05-20 04:48:57 --> Form Validation Class Initialized
INFO - 2023-05-20 04:48:57 --> Controller Class Initialized
INFO - 2023-05-20 04:48:57 --> Model Class Initialized
DEBUG - 2023-05-20 04:48:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:48:57 --> Model Class Initialized
DEBUG - 2023-05-20 04:48:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:48:57 --> Model Class Initialized
INFO - 2023-05-20 04:48:57 --> Model Class Initialized
INFO - 2023-05-20 04:48:57 --> Model Class Initialized
INFO - 2023-05-20 04:48:57 --> Model Class Initialized
DEBUG - 2023-05-20 04:48:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:48:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:48:57 --> Model Class Initialized
INFO - 2023-05-20 04:48:57 --> Model Class Initialized
INFO - 2023-05-20 04:48:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 04:48:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:48:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 04:48:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 04:48:57 --> Model Class Initialized
INFO - 2023-05-20 04:48:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 04:48:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 04:48:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 04:48:58 --> Final output sent to browser
DEBUG - 2023-05-20 04:48:58 --> Total execution time: 0.0809
ERROR - 2023-05-20 04:49:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:49:05 --> Config Class Initialized
INFO - 2023-05-20 04:49:05 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:49:05 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:49:05 --> Utf8 Class Initialized
INFO - 2023-05-20 04:49:05 --> URI Class Initialized
INFO - 2023-05-20 04:49:05 --> Router Class Initialized
INFO - 2023-05-20 04:49:05 --> Output Class Initialized
INFO - 2023-05-20 04:49:05 --> Security Class Initialized
DEBUG - 2023-05-20 04:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:49:05 --> Input Class Initialized
INFO - 2023-05-20 04:49:05 --> Language Class Initialized
INFO - 2023-05-20 04:49:05 --> Loader Class Initialized
INFO - 2023-05-20 04:49:05 --> Helper loaded: url_helper
INFO - 2023-05-20 04:49:05 --> Helper loaded: file_helper
INFO - 2023-05-20 04:49:05 --> Helper loaded: html_helper
INFO - 2023-05-20 04:49:05 --> Helper loaded: text_helper
INFO - 2023-05-20 04:49:05 --> Helper loaded: form_helper
INFO - 2023-05-20 04:49:05 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:49:05 --> Helper loaded: security_helper
INFO - 2023-05-20 04:49:05 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:49:05 --> Database Driver Class Initialized
INFO - 2023-05-20 04:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:49:05 --> Parser Class Initialized
INFO - 2023-05-20 04:49:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:49:05 --> Pagination Class Initialized
INFO - 2023-05-20 04:49:05 --> Form Validation Class Initialized
INFO - 2023-05-20 04:49:05 --> Controller Class Initialized
INFO - 2023-05-20 04:49:05 --> Model Class Initialized
DEBUG - 2023-05-20 04:49:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:49:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:49:05 --> Model Class Initialized
DEBUG - 2023-05-20 04:49:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:49:05 --> Model Class Initialized
INFO - 2023-05-20 04:49:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-20 04:49:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:49:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 04:49:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 04:49:06 --> Model Class Initialized
INFO - 2023-05-20 04:49:06 --> Model Class Initialized
INFO - 2023-05-20 04:49:06 --> Model Class Initialized
INFO - 2023-05-20 04:49:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 04:49:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 04:49:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 04:49:06 --> Final output sent to browser
DEBUG - 2023-05-20 04:49:06 --> Total execution time: 0.0786
ERROR - 2023-05-20 04:49:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:49:06 --> Config Class Initialized
INFO - 2023-05-20 04:49:06 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:49:06 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:49:06 --> Utf8 Class Initialized
INFO - 2023-05-20 04:49:06 --> URI Class Initialized
INFO - 2023-05-20 04:49:06 --> Router Class Initialized
INFO - 2023-05-20 04:49:06 --> Output Class Initialized
INFO - 2023-05-20 04:49:06 --> Security Class Initialized
DEBUG - 2023-05-20 04:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:49:06 --> Input Class Initialized
INFO - 2023-05-20 04:49:06 --> Language Class Initialized
INFO - 2023-05-20 04:49:06 --> Loader Class Initialized
INFO - 2023-05-20 04:49:06 --> Helper loaded: url_helper
INFO - 2023-05-20 04:49:06 --> Helper loaded: file_helper
INFO - 2023-05-20 04:49:06 --> Helper loaded: html_helper
INFO - 2023-05-20 04:49:06 --> Helper loaded: text_helper
INFO - 2023-05-20 04:49:06 --> Helper loaded: form_helper
INFO - 2023-05-20 04:49:06 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:49:06 --> Helper loaded: security_helper
INFO - 2023-05-20 04:49:06 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:49:06 --> Database Driver Class Initialized
INFO - 2023-05-20 04:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:49:06 --> Parser Class Initialized
INFO - 2023-05-20 04:49:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:49:06 --> Pagination Class Initialized
INFO - 2023-05-20 04:49:06 --> Form Validation Class Initialized
INFO - 2023-05-20 04:49:06 --> Controller Class Initialized
INFO - 2023-05-20 04:49:06 --> Model Class Initialized
DEBUG - 2023-05-20 04:49:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:49:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:49:06 --> Model Class Initialized
DEBUG - 2023-05-20 04:49:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:49:06 --> Model Class Initialized
INFO - 2023-05-20 04:49:06 --> Final output sent to browser
DEBUG - 2023-05-20 04:49:06 --> Total execution time: 0.0403
ERROR - 2023-05-20 04:49:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:49:14 --> Config Class Initialized
INFO - 2023-05-20 04:49:14 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:49:14 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:49:14 --> Utf8 Class Initialized
INFO - 2023-05-20 04:49:14 --> URI Class Initialized
INFO - 2023-05-20 04:49:14 --> Router Class Initialized
INFO - 2023-05-20 04:49:14 --> Output Class Initialized
INFO - 2023-05-20 04:49:14 --> Security Class Initialized
DEBUG - 2023-05-20 04:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:49:14 --> Input Class Initialized
INFO - 2023-05-20 04:49:14 --> Language Class Initialized
INFO - 2023-05-20 04:49:14 --> Loader Class Initialized
INFO - 2023-05-20 04:49:14 --> Helper loaded: url_helper
INFO - 2023-05-20 04:49:14 --> Helper loaded: file_helper
INFO - 2023-05-20 04:49:14 --> Helper loaded: html_helper
INFO - 2023-05-20 04:49:14 --> Helper loaded: text_helper
INFO - 2023-05-20 04:49:14 --> Helper loaded: form_helper
INFO - 2023-05-20 04:49:14 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:49:14 --> Helper loaded: security_helper
INFO - 2023-05-20 04:49:14 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:49:14 --> Database Driver Class Initialized
INFO - 2023-05-20 04:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:49:14 --> Parser Class Initialized
INFO - 2023-05-20 04:49:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:49:14 --> Pagination Class Initialized
INFO - 2023-05-20 04:49:14 --> Form Validation Class Initialized
INFO - 2023-05-20 04:49:14 --> Controller Class Initialized
INFO - 2023-05-20 04:49:14 --> Model Class Initialized
DEBUG - 2023-05-20 04:49:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:49:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:49:14 --> Model Class Initialized
DEBUG - 2023-05-20 04:49:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:49:14 --> Model Class Initialized
INFO - 2023-05-20 04:49:14 --> Final output sent to browser
DEBUG - 2023-05-20 04:49:14 --> Total execution time: 0.0773
ERROR - 2023-05-20 04:49:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:49:24 --> Config Class Initialized
INFO - 2023-05-20 04:49:24 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:49:24 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:49:24 --> Utf8 Class Initialized
INFO - 2023-05-20 04:49:24 --> URI Class Initialized
INFO - 2023-05-20 04:49:24 --> Router Class Initialized
INFO - 2023-05-20 04:49:24 --> Output Class Initialized
INFO - 2023-05-20 04:49:24 --> Security Class Initialized
DEBUG - 2023-05-20 04:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:49:24 --> Input Class Initialized
INFO - 2023-05-20 04:49:24 --> Language Class Initialized
INFO - 2023-05-20 04:49:24 --> Loader Class Initialized
INFO - 2023-05-20 04:49:24 --> Helper loaded: url_helper
INFO - 2023-05-20 04:49:24 --> Helper loaded: file_helper
INFO - 2023-05-20 04:49:24 --> Helper loaded: html_helper
INFO - 2023-05-20 04:49:24 --> Helper loaded: text_helper
INFO - 2023-05-20 04:49:24 --> Helper loaded: form_helper
INFO - 2023-05-20 04:49:24 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:49:24 --> Helper loaded: security_helper
INFO - 2023-05-20 04:49:24 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:49:24 --> Database Driver Class Initialized
INFO - 2023-05-20 04:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:49:24 --> Parser Class Initialized
INFO - 2023-05-20 04:49:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:49:24 --> Pagination Class Initialized
INFO - 2023-05-20 04:49:24 --> Form Validation Class Initialized
INFO - 2023-05-20 04:49:24 --> Controller Class Initialized
INFO - 2023-05-20 04:49:24 --> Model Class Initialized
DEBUG - 2023-05-20 04:49:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:49:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:49:24 --> Model Class Initialized
DEBUG - 2023-05-20 04:49:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:49:24 --> Model Class Initialized
INFO - 2023-05-20 04:49:24 --> Final output sent to browser
DEBUG - 2023-05-20 04:49:24 --> Total execution time: 0.0448
ERROR - 2023-05-20 04:49:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:49:28 --> Config Class Initialized
INFO - 2023-05-20 04:49:28 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:49:28 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:49:28 --> Utf8 Class Initialized
INFO - 2023-05-20 04:49:28 --> URI Class Initialized
INFO - 2023-05-20 04:49:28 --> Router Class Initialized
INFO - 2023-05-20 04:49:28 --> Output Class Initialized
INFO - 2023-05-20 04:49:28 --> Security Class Initialized
DEBUG - 2023-05-20 04:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:49:28 --> Input Class Initialized
INFO - 2023-05-20 04:49:28 --> Language Class Initialized
INFO - 2023-05-20 04:49:28 --> Loader Class Initialized
INFO - 2023-05-20 04:49:28 --> Helper loaded: url_helper
INFO - 2023-05-20 04:49:28 --> Helper loaded: file_helper
INFO - 2023-05-20 04:49:28 --> Helper loaded: html_helper
INFO - 2023-05-20 04:49:28 --> Helper loaded: text_helper
INFO - 2023-05-20 04:49:28 --> Helper loaded: form_helper
INFO - 2023-05-20 04:49:28 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:49:28 --> Helper loaded: security_helper
INFO - 2023-05-20 04:49:28 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:49:28 --> Database Driver Class Initialized
INFO - 2023-05-20 04:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:49:28 --> Parser Class Initialized
INFO - 2023-05-20 04:49:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:49:28 --> Pagination Class Initialized
INFO - 2023-05-20 04:49:28 --> Form Validation Class Initialized
INFO - 2023-05-20 04:49:28 --> Controller Class Initialized
INFO - 2023-05-20 04:49:28 --> Model Class Initialized
DEBUG - 2023-05-20 04:49:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:49:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:49:28 --> Model Class Initialized
DEBUG - 2023-05-20 04:49:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:49:28 --> Model Class Initialized
INFO - 2023-05-20 04:49:28 --> Final output sent to browser
DEBUG - 2023-05-20 04:49:28 --> Total execution time: 0.0460
ERROR - 2023-05-20 04:49:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:49:29 --> Config Class Initialized
INFO - 2023-05-20 04:49:29 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:49:29 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:49:29 --> Utf8 Class Initialized
INFO - 2023-05-20 04:49:29 --> URI Class Initialized
INFO - 2023-05-20 04:49:29 --> Router Class Initialized
INFO - 2023-05-20 04:49:29 --> Output Class Initialized
INFO - 2023-05-20 04:49:29 --> Security Class Initialized
DEBUG - 2023-05-20 04:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:49:29 --> Input Class Initialized
INFO - 2023-05-20 04:49:29 --> Language Class Initialized
INFO - 2023-05-20 04:49:29 --> Loader Class Initialized
INFO - 2023-05-20 04:49:29 --> Helper loaded: url_helper
INFO - 2023-05-20 04:49:29 --> Helper loaded: file_helper
INFO - 2023-05-20 04:49:29 --> Helper loaded: html_helper
INFO - 2023-05-20 04:49:29 --> Helper loaded: text_helper
INFO - 2023-05-20 04:49:29 --> Helper loaded: form_helper
INFO - 2023-05-20 04:49:29 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:49:29 --> Helper loaded: security_helper
INFO - 2023-05-20 04:49:29 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:49:29 --> Database Driver Class Initialized
INFO - 2023-05-20 04:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:49:29 --> Parser Class Initialized
INFO - 2023-05-20 04:49:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:49:29 --> Pagination Class Initialized
INFO - 2023-05-20 04:49:29 --> Form Validation Class Initialized
INFO - 2023-05-20 04:49:29 --> Controller Class Initialized
INFO - 2023-05-20 04:49:29 --> Model Class Initialized
DEBUG - 2023-05-20 04:49:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:49:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:49:29 --> Model Class Initialized
DEBUG - 2023-05-20 04:49:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:49:29 --> Model Class Initialized
INFO - 2023-05-20 04:49:29 --> Final output sent to browser
DEBUG - 2023-05-20 04:49:29 --> Total execution time: 0.0608
ERROR - 2023-05-20 04:49:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:49:29 --> Config Class Initialized
INFO - 2023-05-20 04:49:29 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:49:29 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:49:29 --> Utf8 Class Initialized
INFO - 2023-05-20 04:49:29 --> URI Class Initialized
INFO - 2023-05-20 04:49:29 --> Router Class Initialized
INFO - 2023-05-20 04:49:29 --> Output Class Initialized
INFO - 2023-05-20 04:49:29 --> Security Class Initialized
DEBUG - 2023-05-20 04:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:49:29 --> Input Class Initialized
INFO - 2023-05-20 04:49:29 --> Language Class Initialized
INFO - 2023-05-20 04:49:29 --> Loader Class Initialized
INFO - 2023-05-20 04:49:29 --> Helper loaded: url_helper
INFO - 2023-05-20 04:49:29 --> Helper loaded: file_helper
INFO - 2023-05-20 04:49:29 --> Helper loaded: html_helper
INFO - 2023-05-20 04:49:29 --> Helper loaded: text_helper
INFO - 2023-05-20 04:49:29 --> Helper loaded: form_helper
INFO - 2023-05-20 04:49:29 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:49:29 --> Helper loaded: security_helper
INFO - 2023-05-20 04:49:29 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:49:29 --> Database Driver Class Initialized
INFO - 2023-05-20 04:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:49:29 --> Parser Class Initialized
INFO - 2023-05-20 04:49:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:49:29 --> Pagination Class Initialized
INFO - 2023-05-20 04:49:29 --> Form Validation Class Initialized
INFO - 2023-05-20 04:49:29 --> Controller Class Initialized
INFO - 2023-05-20 04:49:29 --> Model Class Initialized
DEBUG - 2023-05-20 04:49:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:49:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:49:29 --> Model Class Initialized
DEBUG - 2023-05-20 04:49:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:49:29 --> Model Class Initialized
INFO - 2023-05-20 04:49:29 --> Final output sent to browser
DEBUG - 2023-05-20 04:49:29 --> Total execution time: 0.0502
ERROR - 2023-05-20 04:49:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:49:58 --> Config Class Initialized
INFO - 2023-05-20 04:49:58 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:49:58 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:49:58 --> Utf8 Class Initialized
INFO - 2023-05-20 04:49:58 --> URI Class Initialized
INFO - 2023-05-20 04:49:58 --> Router Class Initialized
INFO - 2023-05-20 04:49:58 --> Output Class Initialized
INFO - 2023-05-20 04:49:58 --> Security Class Initialized
DEBUG - 2023-05-20 04:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:49:58 --> Input Class Initialized
INFO - 2023-05-20 04:49:58 --> Language Class Initialized
INFO - 2023-05-20 04:49:58 --> Loader Class Initialized
INFO - 2023-05-20 04:49:58 --> Helper loaded: url_helper
INFO - 2023-05-20 04:49:58 --> Helper loaded: file_helper
INFO - 2023-05-20 04:49:58 --> Helper loaded: html_helper
INFO - 2023-05-20 04:49:58 --> Helper loaded: text_helper
INFO - 2023-05-20 04:49:58 --> Helper loaded: form_helper
INFO - 2023-05-20 04:49:58 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:49:58 --> Helper loaded: security_helper
INFO - 2023-05-20 04:49:58 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:49:58 --> Database Driver Class Initialized
INFO - 2023-05-20 04:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:49:58 --> Parser Class Initialized
INFO - 2023-05-20 04:49:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:49:58 --> Pagination Class Initialized
INFO - 2023-05-20 04:49:58 --> Form Validation Class Initialized
INFO - 2023-05-20 04:49:58 --> Controller Class Initialized
INFO - 2023-05-20 04:49:58 --> Model Class Initialized
DEBUG - 2023-05-20 04:49:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:49:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:49:58 --> Model Class Initialized
DEBUG - 2023-05-20 04:49:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:49:58 --> Model Class Initialized
INFO - 2023-05-20 04:49:58 --> Final output sent to browser
DEBUG - 2023-05-20 04:49:58 --> Total execution time: 0.0558
ERROR - 2023-05-20 04:50:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:50:37 --> Config Class Initialized
INFO - 2023-05-20 04:50:37 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:50:37 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:50:37 --> Utf8 Class Initialized
INFO - 2023-05-20 04:50:37 --> URI Class Initialized
INFO - 2023-05-20 04:50:37 --> Router Class Initialized
INFO - 2023-05-20 04:50:37 --> Output Class Initialized
INFO - 2023-05-20 04:50:37 --> Security Class Initialized
DEBUG - 2023-05-20 04:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:50:37 --> Input Class Initialized
INFO - 2023-05-20 04:50:37 --> Language Class Initialized
INFO - 2023-05-20 04:50:37 --> Loader Class Initialized
INFO - 2023-05-20 04:50:37 --> Helper loaded: url_helper
INFO - 2023-05-20 04:50:37 --> Helper loaded: file_helper
INFO - 2023-05-20 04:50:37 --> Helper loaded: html_helper
INFO - 2023-05-20 04:50:37 --> Helper loaded: text_helper
INFO - 2023-05-20 04:50:37 --> Helper loaded: form_helper
INFO - 2023-05-20 04:50:37 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:50:37 --> Helper loaded: security_helper
INFO - 2023-05-20 04:50:37 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:50:37 --> Database Driver Class Initialized
INFO - 2023-05-20 04:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:50:37 --> Parser Class Initialized
INFO - 2023-05-20 04:50:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:50:37 --> Pagination Class Initialized
INFO - 2023-05-20 04:50:37 --> Form Validation Class Initialized
INFO - 2023-05-20 04:50:37 --> Controller Class Initialized
INFO - 2023-05-20 04:50:37 --> Model Class Initialized
DEBUG - 2023-05-20 04:50:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:50:37 --> Final output sent to browser
DEBUG - 2023-05-20 04:50:37 --> Total execution time: 0.0151
ERROR - 2023-05-20 04:50:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:50:37 --> Config Class Initialized
INFO - 2023-05-20 04:50:37 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:50:37 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:50:37 --> Utf8 Class Initialized
INFO - 2023-05-20 04:50:37 --> URI Class Initialized
INFO - 2023-05-20 04:50:37 --> Router Class Initialized
INFO - 2023-05-20 04:50:37 --> Output Class Initialized
INFO - 2023-05-20 04:50:37 --> Security Class Initialized
DEBUG - 2023-05-20 04:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:50:37 --> Input Class Initialized
INFO - 2023-05-20 04:50:37 --> Language Class Initialized
INFO - 2023-05-20 04:50:37 --> Loader Class Initialized
INFO - 2023-05-20 04:50:37 --> Helper loaded: url_helper
INFO - 2023-05-20 04:50:37 --> Helper loaded: file_helper
INFO - 2023-05-20 04:50:37 --> Helper loaded: html_helper
INFO - 2023-05-20 04:50:37 --> Helper loaded: text_helper
INFO - 2023-05-20 04:50:37 --> Helper loaded: form_helper
INFO - 2023-05-20 04:50:37 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:50:37 --> Helper loaded: security_helper
INFO - 2023-05-20 04:50:37 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:50:37 --> Database Driver Class Initialized
INFO - 2023-05-20 04:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:50:37 --> Parser Class Initialized
INFO - 2023-05-20 04:50:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:50:37 --> Pagination Class Initialized
INFO - 2023-05-20 04:50:37 --> Form Validation Class Initialized
INFO - 2023-05-20 04:50:37 --> Controller Class Initialized
INFO - 2023-05-20 04:50:37 --> Model Class Initialized
DEBUG - 2023-05-20 04:50:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:50:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-20 04:50:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:50:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 04:50:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 04:50:37 --> Model Class Initialized
INFO - 2023-05-20 04:50:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 04:50:37 --> Final output sent to browser
DEBUG - 2023-05-20 04:50:37 --> Total execution time: 0.0318
ERROR - 2023-05-20 04:50:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:50:43 --> Config Class Initialized
INFO - 2023-05-20 04:50:43 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:50:43 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:50:43 --> Utf8 Class Initialized
INFO - 2023-05-20 04:50:43 --> URI Class Initialized
INFO - 2023-05-20 04:50:43 --> Router Class Initialized
INFO - 2023-05-20 04:50:43 --> Output Class Initialized
INFO - 2023-05-20 04:50:43 --> Security Class Initialized
DEBUG - 2023-05-20 04:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:50:43 --> Input Class Initialized
INFO - 2023-05-20 04:50:43 --> Language Class Initialized
INFO - 2023-05-20 04:50:43 --> Loader Class Initialized
INFO - 2023-05-20 04:50:43 --> Helper loaded: url_helper
INFO - 2023-05-20 04:50:43 --> Helper loaded: file_helper
INFO - 2023-05-20 04:50:43 --> Helper loaded: html_helper
INFO - 2023-05-20 04:50:43 --> Helper loaded: text_helper
INFO - 2023-05-20 04:50:43 --> Helper loaded: form_helper
INFO - 2023-05-20 04:50:43 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:50:43 --> Helper loaded: security_helper
INFO - 2023-05-20 04:50:43 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:50:43 --> Database Driver Class Initialized
INFO - 2023-05-20 04:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:50:43 --> Parser Class Initialized
INFO - 2023-05-20 04:50:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:50:43 --> Pagination Class Initialized
INFO - 2023-05-20 04:50:43 --> Form Validation Class Initialized
INFO - 2023-05-20 04:50:43 --> Controller Class Initialized
INFO - 2023-05-20 04:50:43 --> Model Class Initialized
DEBUG - 2023-05-20 04:50:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:50:43 --> Model Class Initialized
INFO - 2023-05-20 04:50:43 --> Final output sent to browser
DEBUG - 2023-05-20 04:50:43 --> Total execution time: 0.0185
ERROR - 2023-05-20 04:50:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:50:44 --> Config Class Initialized
INFO - 2023-05-20 04:50:44 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:50:44 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:50:44 --> Utf8 Class Initialized
INFO - 2023-05-20 04:50:44 --> URI Class Initialized
DEBUG - 2023-05-20 04:50:44 --> No URI present. Default controller set.
INFO - 2023-05-20 04:50:44 --> Router Class Initialized
INFO - 2023-05-20 04:50:44 --> Output Class Initialized
INFO - 2023-05-20 04:50:44 --> Security Class Initialized
DEBUG - 2023-05-20 04:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:50:44 --> Input Class Initialized
INFO - 2023-05-20 04:50:44 --> Language Class Initialized
INFO - 2023-05-20 04:50:44 --> Loader Class Initialized
INFO - 2023-05-20 04:50:44 --> Helper loaded: url_helper
INFO - 2023-05-20 04:50:44 --> Helper loaded: file_helper
INFO - 2023-05-20 04:50:44 --> Helper loaded: html_helper
INFO - 2023-05-20 04:50:44 --> Helper loaded: text_helper
INFO - 2023-05-20 04:50:44 --> Helper loaded: form_helper
INFO - 2023-05-20 04:50:44 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:50:44 --> Helper loaded: security_helper
INFO - 2023-05-20 04:50:44 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:50:44 --> Database Driver Class Initialized
INFO - 2023-05-20 04:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:50:44 --> Parser Class Initialized
INFO - 2023-05-20 04:50:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:50:44 --> Pagination Class Initialized
INFO - 2023-05-20 04:50:44 --> Form Validation Class Initialized
INFO - 2023-05-20 04:50:44 --> Controller Class Initialized
INFO - 2023-05-20 04:50:44 --> Model Class Initialized
DEBUG - 2023-05-20 04:50:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:50:44 --> Model Class Initialized
DEBUG - 2023-05-20 04:50:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:50:44 --> Model Class Initialized
INFO - 2023-05-20 04:50:44 --> Model Class Initialized
INFO - 2023-05-20 04:50:44 --> Model Class Initialized
INFO - 2023-05-20 04:50:44 --> Model Class Initialized
DEBUG - 2023-05-20 04:50:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:50:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:50:44 --> Model Class Initialized
INFO - 2023-05-20 04:50:44 --> Model Class Initialized
INFO - 2023-05-20 04:50:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 04:50:44 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:50:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 04:50:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 04:50:44 --> Model Class Initialized
INFO - 2023-05-20 04:50:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 04:50:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 04:50:44 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 04:50:44 --> Final output sent to browser
DEBUG - 2023-05-20 04:50:44 --> Total execution time: 0.0868
ERROR - 2023-05-20 04:50:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:50:50 --> Config Class Initialized
INFO - 2023-05-20 04:50:50 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:50:50 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:50:50 --> Utf8 Class Initialized
INFO - 2023-05-20 04:50:50 --> URI Class Initialized
INFO - 2023-05-20 04:50:50 --> Router Class Initialized
INFO - 2023-05-20 04:50:50 --> Output Class Initialized
INFO - 2023-05-20 04:50:50 --> Security Class Initialized
DEBUG - 2023-05-20 04:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:50:50 --> Input Class Initialized
INFO - 2023-05-20 04:50:50 --> Language Class Initialized
INFO - 2023-05-20 04:50:50 --> Loader Class Initialized
INFO - 2023-05-20 04:50:50 --> Helper loaded: url_helper
INFO - 2023-05-20 04:50:50 --> Helper loaded: file_helper
INFO - 2023-05-20 04:50:50 --> Helper loaded: html_helper
INFO - 2023-05-20 04:50:50 --> Helper loaded: text_helper
INFO - 2023-05-20 04:50:50 --> Helper loaded: form_helper
INFO - 2023-05-20 04:50:50 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:50:50 --> Helper loaded: security_helper
INFO - 2023-05-20 04:50:50 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:50:50 --> Database Driver Class Initialized
INFO - 2023-05-20 04:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:50:50 --> Parser Class Initialized
INFO - 2023-05-20 04:50:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:50:50 --> Pagination Class Initialized
INFO - 2023-05-20 04:50:50 --> Form Validation Class Initialized
INFO - 2023-05-20 04:50:50 --> Controller Class Initialized
INFO - 2023-05-20 04:50:50 --> Model Class Initialized
DEBUG - 2023-05-20 04:50:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:50:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:50:50 --> Model Class Initialized
INFO - 2023-05-20 04:50:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-05-20 04:50:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:50:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 04:50:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 04:50:50 --> Model Class Initialized
INFO - 2023-05-20 04:50:50 --> Model Class Initialized
INFO - 2023-05-20 04:50:50 --> Model Class Initialized
INFO - 2023-05-20 04:50:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 04:50:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 04:50:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 04:50:50 --> Final output sent to browser
DEBUG - 2023-05-20 04:50:50 --> Total execution time: 0.0680
ERROR - 2023-05-20 04:50:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:50:51 --> Config Class Initialized
INFO - 2023-05-20 04:50:51 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:50:51 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:50:51 --> Utf8 Class Initialized
INFO - 2023-05-20 04:50:51 --> URI Class Initialized
INFO - 2023-05-20 04:50:51 --> Router Class Initialized
INFO - 2023-05-20 04:50:51 --> Output Class Initialized
INFO - 2023-05-20 04:50:51 --> Security Class Initialized
DEBUG - 2023-05-20 04:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:50:51 --> Input Class Initialized
INFO - 2023-05-20 04:50:51 --> Language Class Initialized
INFO - 2023-05-20 04:50:51 --> Loader Class Initialized
INFO - 2023-05-20 04:50:51 --> Helper loaded: url_helper
INFO - 2023-05-20 04:50:51 --> Helper loaded: file_helper
INFO - 2023-05-20 04:50:51 --> Helper loaded: html_helper
INFO - 2023-05-20 04:50:51 --> Helper loaded: text_helper
INFO - 2023-05-20 04:50:51 --> Helper loaded: form_helper
INFO - 2023-05-20 04:50:51 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:50:51 --> Helper loaded: security_helper
INFO - 2023-05-20 04:50:51 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:50:51 --> Database Driver Class Initialized
INFO - 2023-05-20 04:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:50:51 --> Parser Class Initialized
INFO - 2023-05-20 04:50:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:50:51 --> Pagination Class Initialized
INFO - 2023-05-20 04:50:51 --> Form Validation Class Initialized
INFO - 2023-05-20 04:50:51 --> Controller Class Initialized
INFO - 2023-05-20 04:50:51 --> Model Class Initialized
DEBUG - 2023-05-20 04:50:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:50:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:50:51 --> Model Class Initialized
INFO - 2023-05-20 04:50:51 --> Final output sent to browser
DEBUG - 2023-05-20 04:50:51 --> Total execution time: 0.0205
ERROR - 2023-05-20 04:50:55 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:50:55 --> Config Class Initialized
INFO - 2023-05-20 04:50:55 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:50:55 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:50:55 --> Utf8 Class Initialized
INFO - 2023-05-20 04:50:55 --> URI Class Initialized
INFO - 2023-05-20 04:50:55 --> Router Class Initialized
INFO - 2023-05-20 04:50:55 --> Output Class Initialized
INFO - 2023-05-20 04:50:55 --> Security Class Initialized
DEBUG - 2023-05-20 04:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:50:55 --> Input Class Initialized
INFO - 2023-05-20 04:50:55 --> Language Class Initialized
INFO - 2023-05-20 04:50:55 --> Loader Class Initialized
INFO - 2023-05-20 04:50:55 --> Helper loaded: url_helper
INFO - 2023-05-20 04:50:55 --> Helper loaded: file_helper
INFO - 2023-05-20 04:50:55 --> Helper loaded: html_helper
INFO - 2023-05-20 04:50:55 --> Helper loaded: text_helper
INFO - 2023-05-20 04:50:55 --> Helper loaded: form_helper
INFO - 2023-05-20 04:50:55 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:50:55 --> Helper loaded: security_helper
INFO - 2023-05-20 04:50:55 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:50:55 --> Database Driver Class Initialized
INFO - 2023-05-20 04:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:50:55 --> Parser Class Initialized
INFO - 2023-05-20 04:50:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:50:55 --> Pagination Class Initialized
INFO - 2023-05-20 04:50:55 --> Form Validation Class Initialized
INFO - 2023-05-20 04:50:55 --> Controller Class Initialized
INFO - 2023-05-20 04:50:55 --> Model Class Initialized
DEBUG - 2023-05-20 04:50:55 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:50:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:50:55 --> Model Class Initialized
DEBUG - 2023-05-20 04:50:55 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:50:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-05-20 04:50:55 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:50:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 04:50:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 04:50:55 --> Model Class Initialized
INFO - 2023-05-20 04:50:55 --> Model Class Initialized
INFO - 2023-05-20 04:50:55 --> Model Class Initialized
INFO - 2023-05-20 04:50:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 04:50:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 04:50:55 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 04:50:55 --> Final output sent to browser
DEBUG - 2023-05-20 04:50:55 --> Total execution time: 0.0605
ERROR - 2023-05-20 04:51:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:51:18 --> Config Class Initialized
INFO - 2023-05-20 04:51:18 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:51:18 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:51:18 --> Utf8 Class Initialized
INFO - 2023-05-20 04:51:18 --> URI Class Initialized
INFO - 2023-05-20 04:51:18 --> Router Class Initialized
INFO - 2023-05-20 04:51:18 --> Output Class Initialized
INFO - 2023-05-20 04:51:18 --> Security Class Initialized
DEBUG - 2023-05-20 04:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:51:18 --> Input Class Initialized
INFO - 2023-05-20 04:51:18 --> Language Class Initialized
INFO - 2023-05-20 04:51:18 --> Loader Class Initialized
INFO - 2023-05-20 04:51:18 --> Helper loaded: url_helper
INFO - 2023-05-20 04:51:18 --> Helper loaded: file_helper
INFO - 2023-05-20 04:51:18 --> Helper loaded: html_helper
INFO - 2023-05-20 04:51:18 --> Helper loaded: text_helper
INFO - 2023-05-20 04:51:18 --> Helper loaded: form_helper
INFO - 2023-05-20 04:51:18 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:51:18 --> Helper loaded: security_helper
INFO - 2023-05-20 04:51:18 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:51:18 --> Database Driver Class Initialized
INFO - 2023-05-20 04:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:51:18 --> Parser Class Initialized
INFO - 2023-05-20 04:51:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:51:18 --> Pagination Class Initialized
INFO - 2023-05-20 04:51:18 --> Form Validation Class Initialized
INFO - 2023-05-20 04:51:18 --> Controller Class Initialized
INFO - 2023-05-20 04:51:18 --> Model Class Initialized
DEBUG - 2023-05-20 04:51:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:51:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:51:18 --> Model Class Initialized
INFO - 2023-05-20 04:51:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/stockrequest.php
DEBUG - 2023-05-20 04:51:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:51:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 04:51:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 04:51:18 --> Model Class Initialized
INFO - 2023-05-20 04:51:18 --> Model Class Initialized
INFO - 2023-05-20 04:51:18 --> Model Class Initialized
INFO - 2023-05-20 04:51:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 04:51:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 04:51:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 04:51:18 --> Final output sent to browser
DEBUG - 2023-05-20 04:51:18 --> Total execution time: 0.0757
ERROR - 2023-05-20 04:51:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:51:18 --> Config Class Initialized
INFO - 2023-05-20 04:51:18 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:51:18 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:51:18 --> Utf8 Class Initialized
INFO - 2023-05-20 04:51:18 --> URI Class Initialized
INFO - 2023-05-20 04:51:18 --> Router Class Initialized
INFO - 2023-05-20 04:51:18 --> Output Class Initialized
INFO - 2023-05-20 04:51:18 --> Security Class Initialized
DEBUG - 2023-05-20 04:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:51:18 --> Input Class Initialized
INFO - 2023-05-20 04:51:18 --> Language Class Initialized
INFO - 2023-05-20 04:51:18 --> Loader Class Initialized
INFO - 2023-05-20 04:51:18 --> Helper loaded: url_helper
INFO - 2023-05-20 04:51:18 --> Helper loaded: file_helper
INFO - 2023-05-20 04:51:18 --> Helper loaded: html_helper
INFO - 2023-05-20 04:51:18 --> Helper loaded: text_helper
INFO - 2023-05-20 04:51:18 --> Helper loaded: form_helper
INFO - 2023-05-20 04:51:18 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:51:18 --> Helper loaded: security_helper
INFO - 2023-05-20 04:51:18 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:51:18 --> Database Driver Class Initialized
INFO - 2023-05-20 04:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:51:18 --> Parser Class Initialized
INFO - 2023-05-20 04:51:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:51:18 --> Pagination Class Initialized
INFO - 2023-05-20 04:51:18 --> Form Validation Class Initialized
INFO - 2023-05-20 04:51:18 --> Controller Class Initialized
INFO - 2023-05-20 04:51:18 --> Model Class Initialized
DEBUG - 2023-05-20 04:51:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:51:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:51:18 --> Model Class Initialized
INFO - 2023-05-20 04:51:18 --> Final output sent to browser
DEBUG - 2023-05-20 04:51:18 --> Total execution time: 0.0274
ERROR - 2023-05-20 04:51:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:51:22 --> Config Class Initialized
INFO - 2023-05-20 04:51:22 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:51:22 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:51:22 --> Utf8 Class Initialized
INFO - 2023-05-20 04:51:22 --> URI Class Initialized
DEBUG - 2023-05-20 04:51:22 --> No URI present. Default controller set.
INFO - 2023-05-20 04:51:22 --> Router Class Initialized
INFO - 2023-05-20 04:51:22 --> Output Class Initialized
INFO - 2023-05-20 04:51:22 --> Security Class Initialized
DEBUG - 2023-05-20 04:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:51:22 --> Input Class Initialized
INFO - 2023-05-20 04:51:22 --> Language Class Initialized
INFO - 2023-05-20 04:51:22 --> Loader Class Initialized
INFO - 2023-05-20 04:51:22 --> Helper loaded: url_helper
INFO - 2023-05-20 04:51:22 --> Helper loaded: file_helper
INFO - 2023-05-20 04:51:22 --> Helper loaded: html_helper
INFO - 2023-05-20 04:51:22 --> Helper loaded: text_helper
INFO - 2023-05-20 04:51:22 --> Helper loaded: form_helper
INFO - 2023-05-20 04:51:22 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:51:22 --> Helper loaded: security_helper
INFO - 2023-05-20 04:51:22 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:51:22 --> Database Driver Class Initialized
INFO - 2023-05-20 04:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:51:22 --> Parser Class Initialized
INFO - 2023-05-20 04:51:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:51:22 --> Pagination Class Initialized
INFO - 2023-05-20 04:51:22 --> Form Validation Class Initialized
INFO - 2023-05-20 04:51:22 --> Controller Class Initialized
INFO - 2023-05-20 04:51:22 --> Model Class Initialized
DEBUG - 2023-05-20 04:51:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:51:22 --> Model Class Initialized
DEBUG - 2023-05-20 04:51:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:51:22 --> Model Class Initialized
INFO - 2023-05-20 04:51:22 --> Model Class Initialized
INFO - 2023-05-20 04:51:22 --> Model Class Initialized
INFO - 2023-05-20 04:51:22 --> Model Class Initialized
DEBUG - 2023-05-20 04:51:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:51:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:51:22 --> Model Class Initialized
INFO - 2023-05-20 04:51:22 --> Model Class Initialized
INFO - 2023-05-20 04:51:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 04:51:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:51:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 04:51:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 04:51:22 --> Model Class Initialized
INFO - 2023-05-20 04:51:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 04:51:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 04:51:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 04:51:22 --> Final output sent to browser
DEBUG - 2023-05-20 04:51:22 --> Total execution time: 0.0779
ERROR - 2023-05-20 04:51:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:51:29 --> Config Class Initialized
INFO - 2023-05-20 04:51:29 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:51:29 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:51:29 --> Utf8 Class Initialized
INFO - 2023-05-20 04:51:29 --> URI Class Initialized
INFO - 2023-05-20 04:51:29 --> Router Class Initialized
INFO - 2023-05-20 04:51:29 --> Output Class Initialized
INFO - 2023-05-20 04:51:29 --> Security Class Initialized
DEBUG - 2023-05-20 04:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:51:29 --> Input Class Initialized
INFO - 2023-05-20 04:51:29 --> Language Class Initialized
INFO - 2023-05-20 04:51:29 --> Loader Class Initialized
INFO - 2023-05-20 04:51:29 --> Helper loaded: url_helper
INFO - 2023-05-20 04:51:29 --> Helper loaded: file_helper
INFO - 2023-05-20 04:51:29 --> Helper loaded: html_helper
INFO - 2023-05-20 04:51:29 --> Helper loaded: text_helper
INFO - 2023-05-20 04:51:29 --> Helper loaded: form_helper
INFO - 2023-05-20 04:51:29 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:51:29 --> Helper loaded: security_helper
INFO - 2023-05-20 04:51:29 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:51:29 --> Database Driver Class Initialized
INFO - 2023-05-20 04:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:51:29 --> Parser Class Initialized
INFO - 2023-05-20 04:51:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:51:29 --> Pagination Class Initialized
INFO - 2023-05-20 04:51:29 --> Form Validation Class Initialized
INFO - 2023-05-20 04:51:29 --> Controller Class Initialized
INFO - 2023-05-20 04:51:29 --> Model Class Initialized
DEBUG - 2023-05-20 04:51:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:51:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:51:29 --> Model Class Initialized
DEBUG - 2023-05-20 04:51:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:51:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-05-20 04:51:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:51:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 04:51:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 04:51:30 --> Model Class Initialized
INFO - 2023-05-20 04:51:30 --> Model Class Initialized
INFO - 2023-05-20 04:51:30 --> Model Class Initialized
INFO - 2023-05-20 04:51:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 04:51:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 04:51:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 04:51:30 --> Final output sent to browser
DEBUG - 2023-05-20 04:51:30 --> Total execution time: 0.0824
ERROR - 2023-05-20 04:51:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:51:35 --> Config Class Initialized
INFO - 2023-05-20 04:51:35 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:51:35 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:51:35 --> Utf8 Class Initialized
INFO - 2023-05-20 04:51:35 --> URI Class Initialized
INFO - 2023-05-20 04:51:35 --> Router Class Initialized
INFO - 2023-05-20 04:51:35 --> Output Class Initialized
INFO - 2023-05-20 04:51:35 --> Security Class Initialized
DEBUG - 2023-05-20 04:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:51:35 --> Input Class Initialized
INFO - 2023-05-20 04:51:35 --> Language Class Initialized
INFO - 2023-05-20 04:51:35 --> Loader Class Initialized
INFO - 2023-05-20 04:51:35 --> Helper loaded: url_helper
INFO - 2023-05-20 04:51:35 --> Helper loaded: file_helper
INFO - 2023-05-20 04:51:35 --> Helper loaded: html_helper
INFO - 2023-05-20 04:51:35 --> Helper loaded: text_helper
INFO - 2023-05-20 04:51:35 --> Helper loaded: form_helper
INFO - 2023-05-20 04:51:35 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:51:35 --> Helper loaded: security_helper
INFO - 2023-05-20 04:51:35 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:51:35 --> Database Driver Class Initialized
INFO - 2023-05-20 04:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:51:35 --> Parser Class Initialized
INFO - 2023-05-20 04:51:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:51:35 --> Pagination Class Initialized
INFO - 2023-05-20 04:51:35 --> Form Validation Class Initialized
INFO - 2023-05-20 04:51:35 --> Controller Class Initialized
INFO - 2023-05-20 04:51:35 --> Model Class Initialized
DEBUG - 2023-05-20 04:51:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:51:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:51:35 --> Model Class Initialized
INFO - 2023-05-20 04:51:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2023-05-20 04:51:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:51:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 04:51:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 04:51:35 --> Model Class Initialized
INFO - 2023-05-20 04:51:35 --> Model Class Initialized
INFO - 2023-05-20 04:51:35 --> Model Class Initialized
INFO - 2023-05-20 04:51:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 04:51:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 04:51:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 04:51:35 --> Final output sent to browser
DEBUG - 2023-05-20 04:51:35 --> Total execution time: 0.0697
ERROR - 2023-05-20 04:51:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:51:35 --> Config Class Initialized
INFO - 2023-05-20 04:51:35 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:51:35 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:51:35 --> Utf8 Class Initialized
INFO - 2023-05-20 04:51:35 --> URI Class Initialized
INFO - 2023-05-20 04:51:35 --> Router Class Initialized
INFO - 2023-05-20 04:51:35 --> Output Class Initialized
INFO - 2023-05-20 04:51:35 --> Security Class Initialized
DEBUG - 2023-05-20 04:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:51:35 --> Input Class Initialized
INFO - 2023-05-20 04:51:35 --> Language Class Initialized
INFO - 2023-05-20 04:51:35 --> Loader Class Initialized
INFO - 2023-05-20 04:51:35 --> Helper loaded: url_helper
INFO - 2023-05-20 04:51:35 --> Helper loaded: file_helper
INFO - 2023-05-20 04:51:35 --> Helper loaded: html_helper
INFO - 2023-05-20 04:51:35 --> Helper loaded: text_helper
INFO - 2023-05-20 04:51:35 --> Helper loaded: form_helper
INFO - 2023-05-20 04:51:35 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:51:35 --> Helper loaded: security_helper
INFO - 2023-05-20 04:51:35 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:51:35 --> Database Driver Class Initialized
INFO - 2023-05-20 04:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:51:35 --> Parser Class Initialized
INFO - 2023-05-20 04:51:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:51:35 --> Pagination Class Initialized
INFO - 2023-05-20 04:51:35 --> Form Validation Class Initialized
INFO - 2023-05-20 04:51:35 --> Controller Class Initialized
INFO - 2023-05-20 04:51:35 --> Model Class Initialized
DEBUG - 2023-05-20 04:51:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:51:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:51:35 --> Model Class Initialized
INFO - 2023-05-20 04:51:35 --> Final output sent to browser
DEBUG - 2023-05-20 04:51:35 --> Total execution time: 0.0161
ERROR - 2023-05-20 04:51:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:51:38 --> Config Class Initialized
INFO - 2023-05-20 04:51:38 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:51:38 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:51:38 --> Utf8 Class Initialized
INFO - 2023-05-20 04:51:38 --> URI Class Initialized
INFO - 2023-05-20 04:51:38 --> Router Class Initialized
INFO - 2023-05-20 04:51:38 --> Output Class Initialized
INFO - 2023-05-20 04:51:38 --> Security Class Initialized
DEBUG - 2023-05-20 04:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:51:38 --> Input Class Initialized
INFO - 2023-05-20 04:51:38 --> Language Class Initialized
INFO - 2023-05-20 04:51:38 --> Loader Class Initialized
INFO - 2023-05-20 04:51:38 --> Helper loaded: url_helper
INFO - 2023-05-20 04:51:38 --> Helper loaded: file_helper
INFO - 2023-05-20 04:51:38 --> Helper loaded: html_helper
INFO - 2023-05-20 04:51:38 --> Helper loaded: text_helper
INFO - 2023-05-20 04:51:38 --> Helper loaded: form_helper
INFO - 2023-05-20 04:51:38 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:51:38 --> Helper loaded: security_helper
INFO - 2023-05-20 04:51:38 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:51:38 --> Database Driver Class Initialized
INFO - 2023-05-20 04:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:51:38 --> Parser Class Initialized
INFO - 2023-05-20 04:51:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:51:38 --> Pagination Class Initialized
INFO - 2023-05-20 04:51:38 --> Form Validation Class Initialized
INFO - 2023-05-20 04:51:38 --> Controller Class Initialized
INFO - 2023-05-20 04:51:38 --> Model Class Initialized
DEBUG - 2023-05-20 04:51:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:51:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:51:38 --> Model Class Initialized
DEBUG - 2023-05-20 04:51:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:51:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-05-20 04:51:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:51:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 04:51:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 04:51:38 --> Model Class Initialized
INFO - 2023-05-20 04:51:38 --> Model Class Initialized
INFO - 2023-05-20 04:51:38 --> Model Class Initialized
INFO - 2023-05-20 04:51:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 04:51:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 04:51:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 04:51:38 --> Final output sent to browser
DEBUG - 2023-05-20 04:51:38 --> Total execution time: 0.0716
ERROR - 2023-05-20 04:51:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:51:59 --> Config Class Initialized
INFO - 2023-05-20 04:51:59 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:51:59 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:51:59 --> Utf8 Class Initialized
INFO - 2023-05-20 04:51:59 --> URI Class Initialized
INFO - 2023-05-20 04:51:59 --> Router Class Initialized
INFO - 2023-05-20 04:51:59 --> Output Class Initialized
INFO - 2023-05-20 04:51:59 --> Security Class Initialized
DEBUG - 2023-05-20 04:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:51:59 --> Input Class Initialized
INFO - 2023-05-20 04:51:59 --> Language Class Initialized
INFO - 2023-05-20 04:51:59 --> Loader Class Initialized
INFO - 2023-05-20 04:51:59 --> Helper loaded: url_helper
INFO - 2023-05-20 04:51:59 --> Helper loaded: file_helper
INFO - 2023-05-20 04:51:59 --> Helper loaded: html_helper
INFO - 2023-05-20 04:51:59 --> Helper loaded: text_helper
INFO - 2023-05-20 04:51:59 --> Helper loaded: form_helper
INFO - 2023-05-20 04:51:59 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:51:59 --> Helper loaded: security_helper
INFO - 2023-05-20 04:51:59 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:51:59 --> Database Driver Class Initialized
INFO - 2023-05-20 04:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:51:59 --> Parser Class Initialized
INFO - 2023-05-20 04:51:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:51:59 --> Pagination Class Initialized
INFO - 2023-05-20 04:51:59 --> Form Validation Class Initialized
INFO - 2023-05-20 04:51:59 --> Controller Class Initialized
INFO - 2023-05-20 04:51:59 --> Model Class Initialized
DEBUG - 2023-05-20 04:51:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:51:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:51:59 --> Model Class Initialized
INFO - 2023-05-20 04:51:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-05-20 04:51:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:51:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 04:51:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 04:51:59 --> Model Class Initialized
INFO - 2023-05-20 04:51:59 --> Model Class Initialized
INFO - 2023-05-20 04:51:59 --> Model Class Initialized
INFO - 2023-05-20 04:51:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 04:51:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 04:51:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 04:51:59 --> Final output sent to browser
DEBUG - 2023-05-20 04:51:59 --> Total execution time: 0.0711
ERROR - 2023-05-20 04:51:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:51:59 --> Config Class Initialized
INFO - 2023-05-20 04:51:59 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:51:59 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:51:59 --> Utf8 Class Initialized
INFO - 2023-05-20 04:51:59 --> URI Class Initialized
INFO - 2023-05-20 04:51:59 --> Router Class Initialized
INFO - 2023-05-20 04:51:59 --> Output Class Initialized
INFO - 2023-05-20 04:51:59 --> Security Class Initialized
DEBUG - 2023-05-20 04:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:51:59 --> Input Class Initialized
INFO - 2023-05-20 04:51:59 --> Language Class Initialized
INFO - 2023-05-20 04:51:59 --> Loader Class Initialized
INFO - 2023-05-20 04:51:59 --> Helper loaded: url_helper
INFO - 2023-05-20 04:51:59 --> Helper loaded: file_helper
INFO - 2023-05-20 04:51:59 --> Helper loaded: html_helper
INFO - 2023-05-20 04:51:59 --> Helper loaded: text_helper
INFO - 2023-05-20 04:51:59 --> Helper loaded: form_helper
INFO - 2023-05-20 04:51:59 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:51:59 --> Helper loaded: security_helper
INFO - 2023-05-20 04:51:59 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:51:59 --> Database Driver Class Initialized
INFO - 2023-05-20 04:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:51:59 --> Parser Class Initialized
INFO - 2023-05-20 04:51:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:51:59 --> Pagination Class Initialized
INFO - 2023-05-20 04:51:59 --> Form Validation Class Initialized
INFO - 2023-05-20 04:51:59 --> Controller Class Initialized
INFO - 2023-05-20 04:51:59 --> Model Class Initialized
DEBUG - 2023-05-20 04:51:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:51:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:51:59 --> Model Class Initialized
INFO - 2023-05-20 04:51:59 --> Final output sent to browser
DEBUG - 2023-05-20 04:51:59 --> Total execution time: 0.0177
ERROR - 2023-05-20 04:52:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:52:05 --> Config Class Initialized
INFO - 2023-05-20 04:52:05 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:52:05 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:52:05 --> Utf8 Class Initialized
INFO - 2023-05-20 04:52:05 --> URI Class Initialized
INFO - 2023-05-20 04:52:05 --> Router Class Initialized
INFO - 2023-05-20 04:52:05 --> Output Class Initialized
INFO - 2023-05-20 04:52:05 --> Security Class Initialized
DEBUG - 2023-05-20 04:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:52:05 --> Input Class Initialized
INFO - 2023-05-20 04:52:05 --> Language Class Initialized
INFO - 2023-05-20 04:52:05 --> Loader Class Initialized
INFO - 2023-05-20 04:52:05 --> Helper loaded: url_helper
INFO - 2023-05-20 04:52:05 --> Helper loaded: file_helper
INFO - 2023-05-20 04:52:05 --> Helper loaded: html_helper
INFO - 2023-05-20 04:52:05 --> Helper loaded: text_helper
INFO - 2023-05-20 04:52:05 --> Helper loaded: form_helper
INFO - 2023-05-20 04:52:05 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:52:05 --> Helper loaded: security_helper
INFO - 2023-05-20 04:52:05 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:52:05 --> Database Driver Class Initialized
INFO - 2023-05-20 04:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:52:05 --> Parser Class Initialized
INFO - 2023-05-20 04:52:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:52:05 --> Pagination Class Initialized
INFO - 2023-05-20 04:52:05 --> Form Validation Class Initialized
INFO - 2023-05-20 04:52:05 --> Controller Class Initialized
INFO - 2023-05-20 04:52:05 --> Model Class Initialized
DEBUG - 2023-05-20 04:52:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:52:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:52:05 --> Model Class Initialized
DEBUG - 2023-05-20 04:52:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:52:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-05-20 04:52:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:52:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 04:52:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 04:52:05 --> Model Class Initialized
INFO - 2023-05-20 04:52:05 --> Model Class Initialized
INFO - 2023-05-20 04:52:05 --> Model Class Initialized
INFO - 2023-05-20 04:52:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 04:52:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 04:52:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 04:52:05 --> Final output sent to browser
DEBUG - 2023-05-20 04:52:05 --> Total execution time: 0.0675
ERROR - 2023-05-20 04:52:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:52:13 --> Config Class Initialized
INFO - 2023-05-20 04:52:13 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:52:13 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:52:13 --> Utf8 Class Initialized
INFO - 2023-05-20 04:52:13 --> URI Class Initialized
INFO - 2023-05-20 04:52:13 --> Router Class Initialized
INFO - 2023-05-20 04:52:13 --> Output Class Initialized
INFO - 2023-05-20 04:52:13 --> Security Class Initialized
DEBUG - 2023-05-20 04:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:52:13 --> Input Class Initialized
INFO - 2023-05-20 04:52:13 --> Language Class Initialized
INFO - 2023-05-20 04:52:13 --> Loader Class Initialized
INFO - 2023-05-20 04:52:13 --> Helper loaded: url_helper
INFO - 2023-05-20 04:52:13 --> Helper loaded: file_helper
INFO - 2023-05-20 04:52:13 --> Helper loaded: html_helper
INFO - 2023-05-20 04:52:13 --> Helper loaded: text_helper
INFO - 2023-05-20 04:52:13 --> Helper loaded: form_helper
INFO - 2023-05-20 04:52:13 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:52:13 --> Helper loaded: security_helper
INFO - 2023-05-20 04:52:13 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:52:13 --> Database Driver Class Initialized
INFO - 2023-05-20 04:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:52:13 --> Parser Class Initialized
INFO - 2023-05-20 04:52:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:52:13 --> Pagination Class Initialized
INFO - 2023-05-20 04:52:13 --> Form Validation Class Initialized
INFO - 2023-05-20 04:52:13 --> Controller Class Initialized
INFO - 2023-05-20 04:52:13 --> Model Class Initialized
DEBUG - 2023-05-20 04:52:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:52:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:52:13 --> Model Class Initialized
INFO - 2023-05-20 04:52:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-05-20 04:52:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:52:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 04:52:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 04:52:13 --> Model Class Initialized
INFO - 2023-05-20 04:52:13 --> Model Class Initialized
INFO - 2023-05-20 04:52:13 --> Model Class Initialized
INFO - 2023-05-20 04:52:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 04:52:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 04:52:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 04:52:13 --> Final output sent to browser
DEBUG - 2023-05-20 04:52:13 --> Total execution time: 0.0672
ERROR - 2023-05-20 04:52:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:52:13 --> Config Class Initialized
INFO - 2023-05-20 04:52:13 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:52:13 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:52:13 --> Utf8 Class Initialized
INFO - 2023-05-20 04:52:13 --> URI Class Initialized
INFO - 2023-05-20 04:52:13 --> Router Class Initialized
INFO - 2023-05-20 04:52:13 --> Output Class Initialized
INFO - 2023-05-20 04:52:13 --> Security Class Initialized
DEBUG - 2023-05-20 04:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:52:13 --> Input Class Initialized
INFO - 2023-05-20 04:52:13 --> Language Class Initialized
INFO - 2023-05-20 04:52:13 --> Loader Class Initialized
INFO - 2023-05-20 04:52:13 --> Helper loaded: url_helper
INFO - 2023-05-20 04:52:13 --> Helper loaded: file_helper
INFO - 2023-05-20 04:52:13 --> Helper loaded: html_helper
INFO - 2023-05-20 04:52:13 --> Helper loaded: text_helper
INFO - 2023-05-20 04:52:13 --> Helper loaded: form_helper
INFO - 2023-05-20 04:52:13 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:52:13 --> Helper loaded: security_helper
INFO - 2023-05-20 04:52:13 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:52:13 --> Database Driver Class Initialized
INFO - 2023-05-20 04:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:52:13 --> Parser Class Initialized
INFO - 2023-05-20 04:52:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:52:13 --> Pagination Class Initialized
INFO - 2023-05-20 04:52:13 --> Form Validation Class Initialized
INFO - 2023-05-20 04:52:13 --> Controller Class Initialized
INFO - 2023-05-20 04:52:13 --> Model Class Initialized
DEBUG - 2023-05-20 04:52:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:52:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:52:13 --> Model Class Initialized
INFO - 2023-05-20 04:52:13 --> Final output sent to browser
DEBUG - 2023-05-20 04:52:13 --> Total execution time: 0.0188
ERROR - 2023-05-20 04:52:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:52:17 --> Config Class Initialized
INFO - 2023-05-20 04:52:17 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:52:17 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:52:17 --> Utf8 Class Initialized
INFO - 2023-05-20 04:52:17 --> URI Class Initialized
INFO - 2023-05-20 04:52:17 --> Router Class Initialized
INFO - 2023-05-20 04:52:17 --> Output Class Initialized
INFO - 2023-05-20 04:52:17 --> Security Class Initialized
DEBUG - 2023-05-20 04:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:52:17 --> Input Class Initialized
INFO - 2023-05-20 04:52:17 --> Language Class Initialized
INFO - 2023-05-20 04:52:17 --> Loader Class Initialized
INFO - 2023-05-20 04:52:17 --> Helper loaded: url_helper
INFO - 2023-05-20 04:52:17 --> Helper loaded: file_helper
INFO - 2023-05-20 04:52:17 --> Helper loaded: html_helper
INFO - 2023-05-20 04:52:17 --> Helper loaded: text_helper
INFO - 2023-05-20 04:52:17 --> Helper loaded: form_helper
INFO - 2023-05-20 04:52:17 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:52:17 --> Helper loaded: security_helper
INFO - 2023-05-20 04:52:17 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:52:17 --> Database Driver Class Initialized
INFO - 2023-05-20 04:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:52:17 --> Parser Class Initialized
INFO - 2023-05-20 04:52:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:52:17 --> Pagination Class Initialized
INFO - 2023-05-20 04:52:17 --> Form Validation Class Initialized
INFO - 2023-05-20 04:52:17 --> Controller Class Initialized
INFO - 2023-05-20 04:52:17 --> Model Class Initialized
DEBUG - 2023-05-20 04:52:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:52:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:52:17 --> Model Class Initialized
DEBUG - 2023-05-20 04:52:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:52:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-05-20 04:52:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:52:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 04:52:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 04:52:17 --> Model Class Initialized
INFO - 2023-05-20 04:52:17 --> Model Class Initialized
INFO - 2023-05-20 04:52:17 --> Model Class Initialized
INFO - 2023-05-20 04:52:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 04:52:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 04:52:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 04:52:17 --> Final output sent to browser
DEBUG - 2023-05-20 04:52:17 --> Total execution time: 0.0756
ERROR - 2023-05-20 04:52:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:52:18 --> Config Class Initialized
INFO - 2023-05-20 04:52:18 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:52:18 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:52:18 --> Utf8 Class Initialized
INFO - 2023-05-20 04:52:18 --> URI Class Initialized
DEBUG - 2023-05-20 04:52:18 --> No URI present. Default controller set.
INFO - 2023-05-20 04:52:18 --> Router Class Initialized
INFO - 2023-05-20 04:52:18 --> Output Class Initialized
INFO - 2023-05-20 04:52:18 --> Security Class Initialized
DEBUG - 2023-05-20 04:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:52:18 --> Input Class Initialized
INFO - 2023-05-20 04:52:18 --> Language Class Initialized
INFO - 2023-05-20 04:52:18 --> Loader Class Initialized
INFO - 2023-05-20 04:52:18 --> Helper loaded: url_helper
INFO - 2023-05-20 04:52:18 --> Helper loaded: file_helper
INFO - 2023-05-20 04:52:18 --> Helper loaded: html_helper
INFO - 2023-05-20 04:52:18 --> Helper loaded: text_helper
INFO - 2023-05-20 04:52:18 --> Helper loaded: form_helper
INFO - 2023-05-20 04:52:18 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:52:18 --> Helper loaded: security_helper
INFO - 2023-05-20 04:52:18 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:52:18 --> Database Driver Class Initialized
INFO - 2023-05-20 04:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:52:18 --> Parser Class Initialized
INFO - 2023-05-20 04:52:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:52:18 --> Pagination Class Initialized
INFO - 2023-05-20 04:52:18 --> Form Validation Class Initialized
INFO - 2023-05-20 04:52:18 --> Controller Class Initialized
INFO - 2023-05-20 04:52:18 --> Model Class Initialized
DEBUG - 2023-05-20 04:52:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:52:18 --> Model Class Initialized
DEBUG - 2023-05-20 04:52:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:52:18 --> Model Class Initialized
INFO - 2023-05-20 04:52:18 --> Model Class Initialized
INFO - 2023-05-20 04:52:18 --> Model Class Initialized
INFO - 2023-05-20 04:52:18 --> Model Class Initialized
DEBUG - 2023-05-20 04:52:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:52:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:52:18 --> Model Class Initialized
INFO - 2023-05-20 04:52:18 --> Model Class Initialized
INFO - 2023-05-20 04:52:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 04:52:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:52:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 04:52:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 04:52:18 --> Model Class Initialized
INFO - 2023-05-20 04:52:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 04:52:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 04:52:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 04:52:18 --> Final output sent to browser
DEBUG - 2023-05-20 04:52:18 --> Total execution time: 0.0778
ERROR - 2023-05-20 04:54:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:54:58 --> Config Class Initialized
INFO - 2023-05-20 04:54:58 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:54:58 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:54:58 --> Utf8 Class Initialized
INFO - 2023-05-20 04:54:58 --> URI Class Initialized
INFO - 2023-05-20 04:54:58 --> Router Class Initialized
INFO - 2023-05-20 04:54:58 --> Output Class Initialized
INFO - 2023-05-20 04:54:58 --> Security Class Initialized
DEBUG - 2023-05-20 04:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:54:58 --> Input Class Initialized
INFO - 2023-05-20 04:54:58 --> Language Class Initialized
INFO - 2023-05-20 04:54:58 --> Loader Class Initialized
INFO - 2023-05-20 04:54:58 --> Helper loaded: url_helper
INFO - 2023-05-20 04:54:58 --> Helper loaded: file_helper
INFO - 2023-05-20 04:54:58 --> Helper loaded: html_helper
INFO - 2023-05-20 04:54:58 --> Helper loaded: text_helper
INFO - 2023-05-20 04:54:58 --> Helper loaded: form_helper
INFO - 2023-05-20 04:54:58 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:54:58 --> Helper loaded: security_helper
INFO - 2023-05-20 04:54:58 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:54:58 --> Database Driver Class Initialized
INFO - 2023-05-20 04:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:54:58 --> Parser Class Initialized
INFO - 2023-05-20 04:54:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:54:58 --> Pagination Class Initialized
INFO - 2023-05-20 04:54:58 --> Form Validation Class Initialized
INFO - 2023-05-20 04:54:58 --> Controller Class Initialized
INFO - 2023-05-20 04:54:58 --> Model Class Initialized
DEBUG - 2023-05-20 04:54:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:54:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:54:58 --> Model Class Initialized
INFO - 2023-05-20 04:54:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-20 04:54:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:54:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 04:54:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 04:54:58 --> Model Class Initialized
INFO - 2023-05-20 04:54:58 --> Model Class Initialized
INFO - 2023-05-20 04:54:58 --> Model Class Initialized
INFO - 2023-05-20 04:54:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 04:54:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 04:54:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 04:54:58 --> Final output sent to browser
DEBUG - 2023-05-20 04:54:58 --> Total execution time: 0.0625
ERROR - 2023-05-20 04:54:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:54:59 --> Config Class Initialized
INFO - 2023-05-20 04:54:59 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:54:59 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:54:59 --> Utf8 Class Initialized
INFO - 2023-05-20 04:54:59 --> URI Class Initialized
INFO - 2023-05-20 04:54:59 --> Router Class Initialized
INFO - 2023-05-20 04:54:59 --> Output Class Initialized
INFO - 2023-05-20 04:54:59 --> Security Class Initialized
DEBUG - 2023-05-20 04:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:54:59 --> Input Class Initialized
INFO - 2023-05-20 04:54:59 --> Language Class Initialized
INFO - 2023-05-20 04:54:59 --> Loader Class Initialized
INFO - 2023-05-20 04:54:59 --> Helper loaded: url_helper
INFO - 2023-05-20 04:54:59 --> Helper loaded: file_helper
INFO - 2023-05-20 04:54:59 --> Helper loaded: html_helper
INFO - 2023-05-20 04:54:59 --> Helper loaded: text_helper
INFO - 2023-05-20 04:54:59 --> Helper loaded: form_helper
INFO - 2023-05-20 04:54:59 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:54:59 --> Helper loaded: security_helper
INFO - 2023-05-20 04:54:59 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:54:59 --> Database Driver Class Initialized
INFO - 2023-05-20 04:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:54:59 --> Parser Class Initialized
INFO - 2023-05-20 04:54:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:54:59 --> Pagination Class Initialized
INFO - 2023-05-20 04:54:59 --> Form Validation Class Initialized
INFO - 2023-05-20 04:54:59 --> Controller Class Initialized
INFO - 2023-05-20 04:54:59 --> Model Class Initialized
DEBUG - 2023-05-20 04:54:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:54:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:54:59 --> Model Class Initialized
INFO - 2023-05-20 04:54:59 --> Final output sent to browser
DEBUG - 2023-05-20 04:54:59 --> Total execution time: 0.0198
ERROR - 2023-05-20 04:55:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:55:02 --> Config Class Initialized
INFO - 2023-05-20 04:55:02 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:55:02 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:55:02 --> Utf8 Class Initialized
INFO - 2023-05-20 04:55:02 --> URI Class Initialized
INFO - 2023-05-20 04:55:02 --> Router Class Initialized
INFO - 2023-05-20 04:55:02 --> Output Class Initialized
INFO - 2023-05-20 04:55:02 --> Security Class Initialized
DEBUG - 2023-05-20 04:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:55:02 --> Input Class Initialized
INFO - 2023-05-20 04:55:02 --> Language Class Initialized
INFO - 2023-05-20 04:55:02 --> Loader Class Initialized
INFO - 2023-05-20 04:55:02 --> Helper loaded: url_helper
INFO - 2023-05-20 04:55:02 --> Helper loaded: file_helper
INFO - 2023-05-20 04:55:02 --> Helper loaded: html_helper
INFO - 2023-05-20 04:55:02 --> Helper loaded: text_helper
INFO - 2023-05-20 04:55:02 --> Helper loaded: form_helper
INFO - 2023-05-20 04:55:02 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:55:02 --> Helper loaded: security_helper
INFO - 2023-05-20 04:55:02 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:55:02 --> Database Driver Class Initialized
INFO - 2023-05-20 04:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:55:02 --> Parser Class Initialized
INFO - 2023-05-20 04:55:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:55:02 --> Pagination Class Initialized
INFO - 2023-05-20 04:55:02 --> Form Validation Class Initialized
INFO - 2023-05-20 04:55:02 --> Controller Class Initialized
INFO - 2023-05-20 04:55:02 --> Model Class Initialized
DEBUG - 2023-05-20 04:55:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:55:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:55:02 --> Model Class Initialized
INFO - 2023-05-20 04:55:02 --> Final output sent to browser
DEBUG - 2023-05-20 04:55:02 --> Total execution time: 0.0192
ERROR - 2023-05-20 04:55:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:55:40 --> Config Class Initialized
INFO - 2023-05-20 04:55:40 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:55:40 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:55:40 --> Utf8 Class Initialized
INFO - 2023-05-20 04:55:40 --> URI Class Initialized
DEBUG - 2023-05-20 04:55:40 --> No URI present. Default controller set.
INFO - 2023-05-20 04:55:40 --> Router Class Initialized
INFO - 2023-05-20 04:55:40 --> Output Class Initialized
INFO - 2023-05-20 04:55:40 --> Security Class Initialized
DEBUG - 2023-05-20 04:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:55:40 --> Input Class Initialized
INFO - 2023-05-20 04:55:40 --> Language Class Initialized
INFO - 2023-05-20 04:55:40 --> Loader Class Initialized
INFO - 2023-05-20 04:55:40 --> Helper loaded: url_helper
INFO - 2023-05-20 04:55:40 --> Helper loaded: file_helper
INFO - 2023-05-20 04:55:40 --> Helper loaded: html_helper
INFO - 2023-05-20 04:55:40 --> Helper loaded: text_helper
INFO - 2023-05-20 04:55:40 --> Helper loaded: form_helper
INFO - 2023-05-20 04:55:40 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:55:40 --> Helper loaded: security_helper
INFO - 2023-05-20 04:55:40 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:55:40 --> Database Driver Class Initialized
INFO - 2023-05-20 04:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:55:40 --> Parser Class Initialized
INFO - 2023-05-20 04:55:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:55:40 --> Pagination Class Initialized
INFO - 2023-05-20 04:55:40 --> Form Validation Class Initialized
INFO - 2023-05-20 04:55:40 --> Controller Class Initialized
INFO - 2023-05-20 04:55:40 --> Model Class Initialized
DEBUG - 2023-05-20 04:55:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:55:40 --> Model Class Initialized
DEBUG - 2023-05-20 04:55:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:55:40 --> Model Class Initialized
INFO - 2023-05-20 04:55:40 --> Model Class Initialized
INFO - 2023-05-20 04:55:40 --> Model Class Initialized
INFO - 2023-05-20 04:55:40 --> Model Class Initialized
DEBUG - 2023-05-20 04:55:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:55:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:55:40 --> Model Class Initialized
INFO - 2023-05-20 04:55:40 --> Model Class Initialized
INFO - 2023-05-20 04:55:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 04:55:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:55:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 04:55:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 04:55:41 --> Model Class Initialized
INFO - 2023-05-20 04:55:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 04:55:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 04:55:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 04:55:41 --> Final output sent to browser
DEBUG - 2023-05-20 04:55:41 --> Total execution time: 0.1972
ERROR - 2023-05-20 04:55:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:55:51 --> Config Class Initialized
INFO - 2023-05-20 04:55:51 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:55:51 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:55:51 --> Utf8 Class Initialized
INFO - 2023-05-20 04:55:51 --> URI Class Initialized
INFO - 2023-05-20 04:55:51 --> Router Class Initialized
INFO - 2023-05-20 04:55:51 --> Output Class Initialized
INFO - 2023-05-20 04:55:51 --> Security Class Initialized
DEBUG - 2023-05-20 04:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:55:51 --> Input Class Initialized
INFO - 2023-05-20 04:55:51 --> Language Class Initialized
INFO - 2023-05-20 04:55:51 --> Loader Class Initialized
INFO - 2023-05-20 04:55:51 --> Helper loaded: url_helper
INFO - 2023-05-20 04:55:51 --> Helper loaded: file_helper
INFO - 2023-05-20 04:55:51 --> Helper loaded: html_helper
INFO - 2023-05-20 04:55:51 --> Helper loaded: text_helper
INFO - 2023-05-20 04:55:51 --> Helper loaded: form_helper
INFO - 2023-05-20 04:55:51 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:55:51 --> Helper loaded: security_helper
INFO - 2023-05-20 04:55:51 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:55:51 --> Database Driver Class Initialized
INFO - 2023-05-20 04:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:55:51 --> Parser Class Initialized
INFO - 2023-05-20 04:55:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:55:51 --> Pagination Class Initialized
INFO - 2023-05-20 04:55:51 --> Form Validation Class Initialized
INFO - 2023-05-20 04:55:51 --> Controller Class Initialized
INFO - 2023-05-20 04:55:51 --> Model Class Initialized
DEBUG - 2023-05-20 04:55:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:55:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:55:51 --> Model Class Initialized
DEBUG - 2023-05-20 04:55:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:55:51 --> Model Class Initialized
INFO - 2023-05-20 04:55:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-20 04:55:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:55:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 04:55:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 04:55:51 --> Model Class Initialized
INFO - 2023-05-20 04:55:51 --> Model Class Initialized
INFO - 2023-05-20 04:55:51 --> Model Class Initialized
INFO - 2023-05-20 04:55:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 04:55:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 04:55:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 04:55:51 --> Final output sent to browser
DEBUG - 2023-05-20 04:55:51 --> Total execution time: 0.1475
ERROR - 2023-05-20 04:55:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:55:52 --> Config Class Initialized
INFO - 2023-05-20 04:55:52 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:55:52 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:55:52 --> Utf8 Class Initialized
INFO - 2023-05-20 04:55:52 --> URI Class Initialized
INFO - 2023-05-20 04:55:52 --> Router Class Initialized
INFO - 2023-05-20 04:55:52 --> Output Class Initialized
INFO - 2023-05-20 04:55:52 --> Security Class Initialized
DEBUG - 2023-05-20 04:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:55:52 --> Input Class Initialized
INFO - 2023-05-20 04:55:52 --> Language Class Initialized
INFO - 2023-05-20 04:55:52 --> Loader Class Initialized
INFO - 2023-05-20 04:55:52 --> Helper loaded: url_helper
INFO - 2023-05-20 04:55:52 --> Helper loaded: file_helper
INFO - 2023-05-20 04:55:52 --> Helper loaded: html_helper
INFO - 2023-05-20 04:55:52 --> Helper loaded: text_helper
INFO - 2023-05-20 04:55:52 --> Helper loaded: form_helper
INFO - 2023-05-20 04:55:52 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:55:52 --> Helper loaded: security_helper
INFO - 2023-05-20 04:55:52 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:55:52 --> Database Driver Class Initialized
INFO - 2023-05-20 04:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:55:52 --> Parser Class Initialized
INFO - 2023-05-20 04:55:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:55:52 --> Pagination Class Initialized
INFO - 2023-05-20 04:55:52 --> Form Validation Class Initialized
INFO - 2023-05-20 04:55:52 --> Controller Class Initialized
INFO - 2023-05-20 04:55:52 --> Model Class Initialized
DEBUG - 2023-05-20 04:55:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:55:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:55:52 --> Model Class Initialized
DEBUG - 2023-05-20 04:55:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:55:52 --> Model Class Initialized
INFO - 2023-05-20 04:55:52 --> Final output sent to browser
DEBUG - 2023-05-20 04:55:52 --> Total execution time: 0.0570
ERROR - 2023-05-20 04:55:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 04:55:57 --> Config Class Initialized
INFO - 2023-05-20 04:55:57 --> Hooks Class Initialized
DEBUG - 2023-05-20 04:55:57 --> UTF-8 Support Enabled
INFO - 2023-05-20 04:55:57 --> Utf8 Class Initialized
INFO - 2023-05-20 04:55:57 --> URI Class Initialized
INFO - 2023-05-20 04:55:57 --> Router Class Initialized
INFO - 2023-05-20 04:55:57 --> Output Class Initialized
INFO - 2023-05-20 04:55:57 --> Security Class Initialized
DEBUG - 2023-05-20 04:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 04:55:57 --> Input Class Initialized
INFO - 2023-05-20 04:55:57 --> Language Class Initialized
INFO - 2023-05-20 04:55:57 --> Loader Class Initialized
INFO - 2023-05-20 04:55:57 --> Helper loaded: url_helper
INFO - 2023-05-20 04:55:57 --> Helper loaded: file_helper
INFO - 2023-05-20 04:55:57 --> Helper loaded: html_helper
INFO - 2023-05-20 04:55:57 --> Helper loaded: text_helper
INFO - 2023-05-20 04:55:57 --> Helper loaded: form_helper
INFO - 2023-05-20 04:55:57 --> Helper loaded: lang_helper
INFO - 2023-05-20 04:55:57 --> Helper loaded: security_helper
INFO - 2023-05-20 04:55:57 --> Helper loaded: cookie_helper
INFO - 2023-05-20 04:55:57 --> Database Driver Class Initialized
INFO - 2023-05-20 04:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 04:55:57 --> Parser Class Initialized
INFO - 2023-05-20 04:55:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 04:55:57 --> Pagination Class Initialized
INFO - 2023-05-20 04:55:57 --> Form Validation Class Initialized
INFO - 2023-05-20 04:55:57 --> Controller Class Initialized
INFO - 2023-05-20 04:55:57 --> Model Class Initialized
DEBUG - 2023-05-20 04:55:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 04:55:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:55:57 --> Model Class Initialized
DEBUG - 2023-05-20 04:55:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 04:55:57 --> Model Class Initialized
INFO - 2023-05-20 04:55:57 --> Final output sent to browser
DEBUG - 2023-05-20 04:55:57 --> Total execution time: 0.1481
ERROR - 2023-05-20 05:00:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:00:23 --> Config Class Initialized
INFO - 2023-05-20 05:00:23 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:00:23 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:00:23 --> Utf8 Class Initialized
INFO - 2023-05-20 05:00:23 --> URI Class Initialized
DEBUG - 2023-05-20 05:00:23 --> No URI present. Default controller set.
INFO - 2023-05-20 05:00:23 --> Router Class Initialized
INFO - 2023-05-20 05:00:23 --> Output Class Initialized
INFO - 2023-05-20 05:00:23 --> Security Class Initialized
DEBUG - 2023-05-20 05:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:00:23 --> Input Class Initialized
INFO - 2023-05-20 05:00:23 --> Language Class Initialized
INFO - 2023-05-20 05:00:23 --> Loader Class Initialized
INFO - 2023-05-20 05:00:23 --> Helper loaded: url_helper
INFO - 2023-05-20 05:00:23 --> Helper loaded: file_helper
INFO - 2023-05-20 05:00:23 --> Helper loaded: html_helper
INFO - 2023-05-20 05:00:23 --> Helper loaded: text_helper
INFO - 2023-05-20 05:00:23 --> Helper loaded: form_helper
INFO - 2023-05-20 05:00:23 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:00:23 --> Helper loaded: security_helper
INFO - 2023-05-20 05:00:23 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:00:23 --> Database Driver Class Initialized
INFO - 2023-05-20 05:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:00:23 --> Parser Class Initialized
INFO - 2023-05-20 05:00:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:00:23 --> Pagination Class Initialized
INFO - 2023-05-20 05:00:23 --> Form Validation Class Initialized
INFO - 2023-05-20 05:00:23 --> Controller Class Initialized
INFO - 2023-05-20 05:00:23 --> Model Class Initialized
DEBUG - 2023-05-20 05:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:00:23 --> Model Class Initialized
DEBUG - 2023-05-20 05:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:00:23 --> Model Class Initialized
INFO - 2023-05-20 05:00:23 --> Model Class Initialized
INFO - 2023-05-20 05:00:23 --> Model Class Initialized
INFO - 2023-05-20 05:00:23 --> Model Class Initialized
DEBUG - 2023-05-20 05:00:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 05:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:00:23 --> Model Class Initialized
INFO - 2023-05-20 05:00:23 --> Model Class Initialized
INFO - 2023-05-20 05:00:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 05:00:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:00:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 05:00:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 05:00:23 --> Model Class Initialized
INFO - 2023-05-20 05:00:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 05:00:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 05:00:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 05:00:23 --> Final output sent to browser
DEBUG - 2023-05-20 05:00:23 --> Total execution time: 0.1973
ERROR - 2023-05-20 05:00:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:00:33 --> Config Class Initialized
INFO - 2023-05-20 05:00:33 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:00:33 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:00:33 --> Utf8 Class Initialized
INFO - 2023-05-20 05:00:33 --> URI Class Initialized
INFO - 2023-05-20 05:00:33 --> Router Class Initialized
INFO - 2023-05-20 05:00:33 --> Output Class Initialized
INFO - 2023-05-20 05:00:33 --> Security Class Initialized
DEBUG - 2023-05-20 05:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:00:33 --> Input Class Initialized
INFO - 2023-05-20 05:00:33 --> Language Class Initialized
INFO - 2023-05-20 05:00:33 --> Loader Class Initialized
INFO - 2023-05-20 05:00:33 --> Helper loaded: url_helper
INFO - 2023-05-20 05:00:33 --> Helper loaded: file_helper
INFO - 2023-05-20 05:00:33 --> Helper loaded: html_helper
INFO - 2023-05-20 05:00:33 --> Helper loaded: text_helper
INFO - 2023-05-20 05:00:33 --> Helper loaded: form_helper
INFO - 2023-05-20 05:00:33 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:00:33 --> Helper loaded: security_helper
INFO - 2023-05-20 05:00:33 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:00:33 --> Database Driver Class Initialized
INFO - 2023-05-20 05:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:00:33 --> Parser Class Initialized
INFO - 2023-05-20 05:00:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:00:33 --> Pagination Class Initialized
INFO - 2023-05-20 05:00:33 --> Form Validation Class Initialized
INFO - 2023-05-20 05:00:33 --> Controller Class Initialized
INFO - 2023-05-20 05:00:33 --> Model Class Initialized
DEBUG - 2023-05-20 05:00:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 05:00:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:00:33 --> Model Class Initialized
DEBUG - 2023-05-20 05:00:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:00:33 --> Model Class Initialized
INFO - 2023-05-20 05:00:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-05-20 05:00:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:00:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 05:00:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 05:00:33 --> Model Class Initialized
INFO - 2023-05-20 05:00:33 --> Model Class Initialized
INFO - 2023-05-20 05:00:33 --> Model Class Initialized
INFO - 2023-05-20 05:00:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 05:00:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 05:00:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 05:00:33 --> Final output sent to browser
DEBUG - 2023-05-20 05:00:33 --> Total execution time: 0.1371
ERROR - 2023-05-20 05:00:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:00:33 --> Config Class Initialized
INFO - 2023-05-20 05:00:33 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:00:33 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:00:33 --> Utf8 Class Initialized
INFO - 2023-05-20 05:00:33 --> URI Class Initialized
INFO - 2023-05-20 05:00:33 --> Router Class Initialized
INFO - 2023-05-20 05:00:33 --> Output Class Initialized
INFO - 2023-05-20 05:00:33 --> Security Class Initialized
DEBUG - 2023-05-20 05:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:00:33 --> Input Class Initialized
INFO - 2023-05-20 05:00:33 --> Language Class Initialized
INFO - 2023-05-20 05:00:33 --> Loader Class Initialized
INFO - 2023-05-20 05:00:33 --> Helper loaded: url_helper
INFO - 2023-05-20 05:00:33 --> Helper loaded: file_helper
INFO - 2023-05-20 05:00:33 --> Helper loaded: html_helper
INFO - 2023-05-20 05:00:33 --> Helper loaded: text_helper
INFO - 2023-05-20 05:00:33 --> Helper loaded: form_helper
INFO - 2023-05-20 05:00:33 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:00:33 --> Helper loaded: security_helper
INFO - 2023-05-20 05:00:33 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:00:33 --> Database Driver Class Initialized
INFO - 2023-05-20 05:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:00:33 --> Parser Class Initialized
INFO - 2023-05-20 05:00:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:00:33 --> Pagination Class Initialized
INFO - 2023-05-20 05:00:33 --> Form Validation Class Initialized
INFO - 2023-05-20 05:00:33 --> Controller Class Initialized
INFO - 2023-05-20 05:00:33 --> Model Class Initialized
DEBUG - 2023-05-20 05:00:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 05:00:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:00:33 --> Model Class Initialized
DEBUG - 2023-05-20 05:00:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:00:33 --> Model Class Initialized
INFO - 2023-05-20 05:00:33 --> Final output sent to browser
DEBUG - 2023-05-20 05:00:33 --> Total execution time: 0.0426
ERROR - 2023-05-20 05:00:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:00:39 --> Config Class Initialized
INFO - 2023-05-20 05:00:39 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:00:39 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:00:39 --> Utf8 Class Initialized
INFO - 2023-05-20 05:00:39 --> URI Class Initialized
INFO - 2023-05-20 05:00:39 --> Router Class Initialized
INFO - 2023-05-20 05:00:39 --> Output Class Initialized
INFO - 2023-05-20 05:00:39 --> Security Class Initialized
DEBUG - 2023-05-20 05:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:00:39 --> Input Class Initialized
INFO - 2023-05-20 05:00:39 --> Language Class Initialized
INFO - 2023-05-20 05:00:39 --> Loader Class Initialized
INFO - 2023-05-20 05:00:39 --> Helper loaded: url_helper
INFO - 2023-05-20 05:00:39 --> Helper loaded: file_helper
INFO - 2023-05-20 05:00:39 --> Helper loaded: html_helper
INFO - 2023-05-20 05:00:39 --> Helper loaded: text_helper
INFO - 2023-05-20 05:00:39 --> Helper loaded: form_helper
INFO - 2023-05-20 05:00:39 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:00:39 --> Helper loaded: security_helper
INFO - 2023-05-20 05:00:39 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:00:39 --> Database Driver Class Initialized
INFO - 2023-05-20 05:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:00:39 --> Parser Class Initialized
INFO - 2023-05-20 05:00:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:00:39 --> Pagination Class Initialized
INFO - 2023-05-20 05:00:39 --> Form Validation Class Initialized
INFO - 2023-05-20 05:00:39 --> Controller Class Initialized
INFO - 2023-05-20 05:00:39 --> Model Class Initialized
DEBUG - 2023-05-20 05:00:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 05:00:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:00:39 --> Model Class Initialized
DEBUG - 2023-05-20 05:00:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:00:39 --> Model Class Initialized
INFO - 2023-05-20 05:00:39 --> Final output sent to browser
DEBUG - 2023-05-20 05:00:39 --> Total execution time: 0.0529
ERROR - 2023-05-20 05:13:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:13:06 --> Config Class Initialized
INFO - 2023-05-20 05:13:06 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:13:06 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:13:06 --> Utf8 Class Initialized
INFO - 2023-05-20 05:13:06 --> URI Class Initialized
INFO - 2023-05-20 05:13:06 --> Router Class Initialized
INFO - 2023-05-20 05:13:06 --> Output Class Initialized
INFO - 2023-05-20 05:13:06 --> Security Class Initialized
DEBUG - 2023-05-20 05:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:13:06 --> Input Class Initialized
INFO - 2023-05-20 05:13:06 --> Language Class Initialized
INFO - 2023-05-20 05:13:06 --> Loader Class Initialized
INFO - 2023-05-20 05:13:06 --> Helper loaded: url_helper
INFO - 2023-05-20 05:13:06 --> Helper loaded: file_helper
INFO - 2023-05-20 05:13:06 --> Helper loaded: html_helper
INFO - 2023-05-20 05:13:06 --> Helper loaded: text_helper
INFO - 2023-05-20 05:13:06 --> Helper loaded: form_helper
INFO - 2023-05-20 05:13:06 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:13:06 --> Helper loaded: security_helper
INFO - 2023-05-20 05:13:06 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:13:06 --> Database Driver Class Initialized
INFO - 2023-05-20 05:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:13:06 --> Parser Class Initialized
INFO - 2023-05-20 05:13:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:13:06 --> Pagination Class Initialized
INFO - 2023-05-20 05:13:06 --> Form Validation Class Initialized
INFO - 2023-05-20 05:13:06 --> Controller Class Initialized
INFO - 2023-05-20 05:13:06 --> Model Class Initialized
DEBUG - 2023-05-20 05:13:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 05:13:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:13:06 --> Model Class Initialized
INFO - 2023-05-20 05:13:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-20 05:13:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:13:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 05:13:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 05:13:06 --> Model Class Initialized
INFO - 2023-05-20 05:13:06 --> Model Class Initialized
INFO - 2023-05-20 05:13:06 --> Model Class Initialized
INFO - 2023-05-20 05:13:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 05:13:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 05:13:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 05:13:06 --> Final output sent to browser
DEBUG - 2023-05-20 05:13:06 --> Total execution time: 0.0696
ERROR - 2023-05-20 05:13:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:13:07 --> Config Class Initialized
INFO - 2023-05-20 05:13:07 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:13:07 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:13:07 --> Utf8 Class Initialized
INFO - 2023-05-20 05:13:07 --> URI Class Initialized
INFO - 2023-05-20 05:13:07 --> Router Class Initialized
INFO - 2023-05-20 05:13:07 --> Output Class Initialized
INFO - 2023-05-20 05:13:07 --> Security Class Initialized
DEBUG - 2023-05-20 05:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:13:07 --> Input Class Initialized
INFO - 2023-05-20 05:13:07 --> Language Class Initialized
INFO - 2023-05-20 05:13:07 --> Loader Class Initialized
INFO - 2023-05-20 05:13:07 --> Helper loaded: url_helper
INFO - 2023-05-20 05:13:07 --> Helper loaded: file_helper
INFO - 2023-05-20 05:13:07 --> Helper loaded: html_helper
INFO - 2023-05-20 05:13:07 --> Helper loaded: text_helper
INFO - 2023-05-20 05:13:07 --> Helper loaded: form_helper
INFO - 2023-05-20 05:13:07 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:13:07 --> Helper loaded: security_helper
INFO - 2023-05-20 05:13:07 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:13:07 --> Database Driver Class Initialized
INFO - 2023-05-20 05:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:13:07 --> Parser Class Initialized
INFO - 2023-05-20 05:13:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:13:07 --> Pagination Class Initialized
INFO - 2023-05-20 05:13:07 --> Form Validation Class Initialized
INFO - 2023-05-20 05:13:07 --> Controller Class Initialized
INFO - 2023-05-20 05:13:07 --> Model Class Initialized
DEBUG - 2023-05-20 05:13:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 05:13:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:13:07 --> Model Class Initialized
INFO - 2023-05-20 05:13:07 --> Final output sent to browser
DEBUG - 2023-05-20 05:13:07 --> Total execution time: 0.0209
ERROR - 2023-05-20 05:13:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:13:10 --> Config Class Initialized
INFO - 2023-05-20 05:13:10 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:13:10 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:13:10 --> Utf8 Class Initialized
INFO - 2023-05-20 05:13:10 --> URI Class Initialized
INFO - 2023-05-20 05:13:10 --> Router Class Initialized
INFO - 2023-05-20 05:13:10 --> Output Class Initialized
INFO - 2023-05-20 05:13:10 --> Security Class Initialized
DEBUG - 2023-05-20 05:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:13:10 --> Input Class Initialized
INFO - 2023-05-20 05:13:10 --> Language Class Initialized
INFO - 2023-05-20 05:13:10 --> Loader Class Initialized
INFO - 2023-05-20 05:13:10 --> Helper loaded: url_helper
INFO - 2023-05-20 05:13:10 --> Helper loaded: file_helper
INFO - 2023-05-20 05:13:10 --> Helper loaded: html_helper
INFO - 2023-05-20 05:13:10 --> Helper loaded: text_helper
INFO - 2023-05-20 05:13:10 --> Helper loaded: form_helper
INFO - 2023-05-20 05:13:10 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:13:10 --> Helper loaded: security_helper
INFO - 2023-05-20 05:13:10 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:13:10 --> Database Driver Class Initialized
INFO - 2023-05-20 05:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:13:10 --> Parser Class Initialized
INFO - 2023-05-20 05:13:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:13:10 --> Pagination Class Initialized
INFO - 2023-05-20 05:13:10 --> Form Validation Class Initialized
INFO - 2023-05-20 05:13:10 --> Controller Class Initialized
INFO - 2023-05-20 05:13:10 --> Model Class Initialized
DEBUG - 2023-05-20 05:13:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 05:13:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:13:10 --> Model Class Initialized
INFO - 2023-05-20 05:13:10 --> Final output sent to browser
DEBUG - 2023-05-20 05:13:10 --> Total execution time: 0.0201
ERROR - 2023-05-20 05:16:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:16:33 --> Config Class Initialized
INFO - 2023-05-20 05:16:33 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:16:33 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:16:33 --> Utf8 Class Initialized
INFO - 2023-05-20 05:16:33 --> URI Class Initialized
DEBUG - 2023-05-20 05:16:33 --> No URI present. Default controller set.
INFO - 2023-05-20 05:16:33 --> Router Class Initialized
INFO - 2023-05-20 05:16:33 --> Output Class Initialized
INFO - 2023-05-20 05:16:33 --> Security Class Initialized
DEBUG - 2023-05-20 05:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:16:33 --> Input Class Initialized
INFO - 2023-05-20 05:16:33 --> Language Class Initialized
INFO - 2023-05-20 05:16:33 --> Loader Class Initialized
INFO - 2023-05-20 05:16:33 --> Helper loaded: url_helper
INFO - 2023-05-20 05:16:33 --> Helper loaded: file_helper
INFO - 2023-05-20 05:16:33 --> Helper loaded: html_helper
INFO - 2023-05-20 05:16:33 --> Helper loaded: text_helper
INFO - 2023-05-20 05:16:33 --> Helper loaded: form_helper
INFO - 2023-05-20 05:16:33 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:16:33 --> Helper loaded: security_helper
INFO - 2023-05-20 05:16:33 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:16:33 --> Database Driver Class Initialized
INFO - 2023-05-20 05:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:16:33 --> Parser Class Initialized
INFO - 2023-05-20 05:16:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:16:33 --> Pagination Class Initialized
INFO - 2023-05-20 05:16:33 --> Form Validation Class Initialized
INFO - 2023-05-20 05:16:33 --> Controller Class Initialized
INFO - 2023-05-20 05:16:33 --> Model Class Initialized
DEBUG - 2023-05-20 05:16:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:16:33 --> Model Class Initialized
DEBUG - 2023-05-20 05:16:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:16:33 --> Model Class Initialized
INFO - 2023-05-20 05:16:33 --> Model Class Initialized
INFO - 2023-05-20 05:16:33 --> Model Class Initialized
INFO - 2023-05-20 05:16:33 --> Model Class Initialized
DEBUG - 2023-05-20 05:16:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 05:16:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:16:33 --> Model Class Initialized
INFO - 2023-05-20 05:16:33 --> Model Class Initialized
INFO - 2023-05-20 05:16:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 05:16:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:16:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 05:16:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 05:16:33 --> Model Class Initialized
INFO - 2023-05-20 05:16:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 05:16:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 05:16:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 05:16:33 --> Final output sent to browser
DEBUG - 2023-05-20 05:16:33 --> Total execution time: 0.1981
ERROR - 2023-05-20 05:16:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:16:45 --> Config Class Initialized
INFO - 2023-05-20 05:16:45 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:16:45 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:16:45 --> Utf8 Class Initialized
INFO - 2023-05-20 05:16:45 --> URI Class Initialized
INFO - 2023-05-20 05:16:45 --> Router Class Initialized
INFO - 2023-05-20 05:16:45 --> Output Class Initialized
INFO - 2023-05-20 05:16:45 --> Security Class Initialized
DEBUG - 2023-05-20 05:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:16:45 --> Input Class Initialized
INFO - 2023-05-20 05:16:45 --> Language Class Initialized
INFO - 2023-05-20 05:16:45 --> Loader Class Initialized
INFO - 2023-05-20 05:16:45 --> Helper loaded: url_helper
INFO - 2023-05-20 05:16:45 --> Helper loaded: file_helper
INFO - 2023-05-20 05:16:45 --> Helper loaded: html_helper
INFO - 2023-05-20 05:16:45 --> Helper loaded: text_helper
INFO - 2023-05-20 05:16:45 --> Helper loaded: form_helper
INFO - 2023-05-20 05:16:45 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:16:45 --> Helper loaded: security_helper
INFO - 2023-05-20 05:16:45 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:16:45 --> Database Driver Class Initialized
INFO - 2023-05-20 05:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:16:45 --> Parser Class Initialized
INFO - 2023-05-20 05:16:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:16:45 --> Pagination Class Initialized
INFO - 2023-05-20 05:16:45 --> Form Validation Class Initialized
INFO - 2023-05-20 05:16:45 --> Controller Class Initialized
INFO - 2023-05-20 05:16:45 --> Model Class Initialized
DEBUG - 2023-05-20 05:16:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 05:16:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:16:45 --> Model Class Initialized
DEBUG - 2023-05-20 05:16:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:16:45 --> Model Class Initialized
INFO - 2023-05-20 05:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-20 05:16:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 05:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 05:16:45 --> Model Class Initialized
INFO - 2023-05-20 05:16:45 --> Model Class Initialized
INFO - 2023-05-20 05:16:45 --> Model Class Initialized
INFO - 2023-05-20 05:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 05:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 05:16:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 05:16:45 --> Final output sent to browser
DEBUG - 2023-05-20 05:16:45 --> Total execution time: 0.1517
ERROR - 2023-05-20 05:16:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:16:45 --> Config Class Initialized
INFO - 2023-05-20 05:16:45 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:16:45 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:16:45 --> Utf8 Class Initialized
INFO - 2023-05-20 05:16:45 --> URI Class Initialized
INFO - 2023-05-20 05:16:45 --> Router Class Initialized
INFO - 2023-05-20 05:16:45 --> Output Class Initialized
INFO - 2023-05-20 05:16:45 --> Security Class Initialized
DEBUG - 2023-05-20 05:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:16:45 --> Input Class Initialized
INFO - 2023-05-20 05:16:45 --> Language Class Initialized
INFO - 2023-05-20 05:16:45 --> Loader Class Initialized
INFO - 2023-05-20 05:16:45 --> Helper loaded: url_helper
INFO - 2023-05-20 05:16:45 --> Helper loaded: file_helper
INFO - 2023-05-20 05:16:45 --> Helper loaded: html_helper
INFO - 2023-05-20 05:16:45 --> Helper loaded: text_helper
INFO - 2023-05-20 05:16:45 --> Helper loaded: form_helper
INFO - 2023-05-20 05:16:45 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:16:45 --> Helper loaded: security_helper
INFO - 2023-05-20 05:16:45 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:16:45 --> Database Driver Class Initialized
INFO - 2023-05-20 05:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:16:45 --> Parser Class Initialized
INFO - 2023-05-20 05:16:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:16:45 --> Pagination Class Initialized
INFO - 2023-05-20 05:16:45 --> Form Validation Class Initialized
INFO - 2023-05-20 05:16:45 --> Controller Class Initialized
INFO - 2023-05-20 05:16:45 --> Model Class Initialized
DEBUG - 2023-05-20 05:16:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 05:16:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:16:45 --> Model Class Initialized
DEBUG - 2023-05-20 05:16:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:16:45 --> Model Class Initialized
INFO - 2023-05-20 05:16:45 --> Final output sent to browser
DEBUG - 2023-05-20 05:16:45 --> Total execution time: 0.0545
ERROR - 2023-05-20 05:16:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:16:50 --> Config Class Initialized
INFO - 2023-05-20 05:16:50 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:16:50 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:16:50 --> Utf8 Class Initialized
INFO - 2023-05-20 05:16:50 --> URI Class Initialized
INFO - 2023-05-20 05:16:50 --> Router Class Initialized
INFO - 2023-05-20 05:16:50 --> Output Class Initialized
INFO - 2023-05-20 05:16:50 --> Security Class Initialized
DEBUG - 2023-05-20 05:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:16:50 --> Input Class Initialized
INFO - 2023-05-20 05:16:50 --> Language Class Initialized
INFO - 2023-05-20 05:16:50 --> Loader Class Initialized
INFO - 2023-05-20 05:16:50 --> Helper loaded: url_helper
INFO - 2023-05-20 05:16:50 --> Helper loaded: file_helper
INFO - 2023-05-20 05:16:50 --> Helper loaded: html_helper
INFO - 2023-05-20 05:16:50 --> Helper loaded: text_helper
INFO - 2023-05-20 05:16:50 --> Helper loaded: form_helper
INFO - 2023-05-20 05:16:50 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:16:50 --> Helper loaded: security_helper
INFO - 2023-05-20 05:16:50 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:16:50 --> Database Driver Class Initialized
INFO - 2023-05-20 05:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:16:50 --> Parser Class Initialized
INFO - 2023-05-20 05:16:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:16:50 --> Pagination Class Initialized
INFO - 2023-05-20 05:16:50 --> Form Validation Class Initialized
INFO - 2023-05-20 05:16:50 --> Controller Class Initialized
INFO - 2023-05-20 05:16:50 --> Model Class Initialized
DEBUG - 2023-05-20 05:16:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 05:16:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:16:50 --> Model Class Initialized
DEBUG - 2023-05-20 05:16:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:16:50 --> Model Class Initialized
INFO - 2023-05-20 05:16:51 --> Final output sent to browser
DEBUG - 2023-05-20 05:16:51 --> Total execution time: 0.1659
ERROR - 2023-05-20 05:17:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:17:04 --> Config Class Initialized
INFO - 2023-05-20 05:17:04 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:17:04 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:17:04 --> Utf8 Class Initialized
INFO - 2023-05-20 05:17:04 --> URI Class Initialized
DEBUG - 2023-05-20 05:17:04 --> No URI present. Default controller set.
INFO - 2023-05-20 05:17:04 --> Router Class Initialized
INFO - 2023-05-20 05:17:04 --> Output Class Initialized
INFO - 2023-05-20 05:17:04 --> Security Class Initialized
DEBUG - 2023-05-20 05:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:17:04 --> Input Class Initialized
INFO - 2023-05-20 05:17:04 --> Language Class Initialized
INFO - 2023-05-20 05:17:04 --> Loader Class Initialized
INFO - 2023-05-20 05:17:04 --> Helper loaded: url_helper
INFO - 2023-05-20 05:17:04 --> Helper loaded: file_helper
INFO - 2023-05-20 05:17:04 --> Helper loaded: html_helper
INFO - 2023-05-20 05:17:04 --> Helper loaded: text_helper
INFO - 2023-05-20 05:17:04 --> Helper loaded: form_helper
INFO - 2023-05-20 05:17:04 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:17:04 --> Helper loaded: security_helper
INFO - 2023-05-20 05:17:04 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:17:04 --> Database Driver Class Initialized
INFO - 2023-05-20 05:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:17:04 --> Parser Class Initialized
INFO - 2023-05-20 05:17:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:17:04 --> Pagination Class Initialized
INFO - 2023-05-20 05:17:04 --> Form Validation Class Initialized
INFO - 2023-05-20 05:17:04 --> Controller Class Initialized
INFO - 2023-05-20 05:17:04 --> Model Class Initialized
DEBUG - 2023-05-20 05:17:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:17:04 --> Model Class Initialized
DEBUG - 2023-05-20 05:17:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:17:04 --> Model Class Initialized
INFO - 2023-05-20 05:17:04 --> Model Class Initialized
INFO - 2023-05-20 05:17:04 --> Model Class Initialized
INFO - 2023-05-20 05:17:04 --> Model Class Initialized
DEBUG - 2023-05-20 05:17:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 05:17:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:17:04 --> Model Class Initialized
INFO - 2023-05-20 05:17:04 --> Model Class Initialized
INFO - 2023-05-20 05:17:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 05:17:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:17:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 05:17:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 05:17:04 --> Model Class Initialized
INFO - 2023-05-20 05:17:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 05:17:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 05:17:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 05:17:04 --> Final output sent to browser
DEBUG - 2023-05-20 05:17:04 --> Total execution time: 0.1904
ERROR - 2023-05-20 05:18:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:18:34 --> Config Class Initialized
INFO - 2023-05-20 05:18:34 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:18:34 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:18:34 --> Utf8 Class Initialized
INFO - 2023-05-20 05:18:34 --> URI Class Initialized
DEBUG - 2023-05-20 05:18:34 --> No URI present. Default controller set.
INFO - 2023-05-20 05:18:34 --> Router Class Initialized
INFO - 2023-05-20 05:18:34 --> Output Class Initialized
INFO - 2023-05-20 05:18:34 --> Security Class Initialized
DEBUG - 2023-05-20 05:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:18:34 --> Input Class Initialized
INFO - 2023-05-20 05:18:34 --> Language Class Initialized
INFO - 2023-05-20 05:18:34 --> Loader Class Initialized
INFO - 2023-05-20 05:18:34 --> Helper loaded: url_helper
INFO - 2023-05-20 05:18:34 --> Helper loaded: file_helper
INFO - 2023-05-20 05:18:34 --> Helper loaded: html_helper
INFO - 2023-05-20 05:18:34 --> Helper loaded: text_helper
INFO - 2023-05-20 05:18:34 --> Helper loaded: form_helper
INFO - 2023-05-20 05:18:34 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:18:34 --> Helper loaded: security_helper
INFO - 2023-05-20 05:18:34 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:18:34 --> Database Driver Class Initialized
INFO - 2023-05-20 05:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:18:34 --> Parser Class Initialized
INFO - 2023-05-20 05:18:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:18:34 --> Pagination Class Initialized
INFO - 2023-05-20 05:18:34 --> Form Validation Class Initialized
INFO - 2023-05-20 05:18:34 --> Controller Class Initialized
INFO - 2023-05-20 05:18:34 --> Model Class Initialized
DEBUG - 2023-05-20 05:18:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:18:34 --> Model Class Initialized
DEBUG - 2023-05-20 05:18:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:18:34 --> Model Class Initialized
INFO - 2023-05-20 05:18:34 --> Model Class Initialized
INFO - 2023-05-20 05:18:34 --> Model Class Initialized
INFO - 2023-05-20 05:18:34 --> Model Class Initialized
DEBUG - 2023-05-20 05:18:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 05:18:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:18:34 --> Model Class Initialized
INFO - 2023-05-20 05:18:34 --> Model Class Initialized
INFO - 2023-05-20 05:18:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 05:18:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:18:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 05:18:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 05:18:34 --> Model Class Initialized
INFO - 2023-05-20 05:18:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 05:18:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 05:18:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 05:18:34 --> Final output sent to browser
DEBUG - 2023-05-20 05:18:34 --> Total execution time: 0.1686
ERROR - 2023-05-20 05:23:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:23:52 --> Config Class Initialized
INFO - 2023-05-20 05:23:52 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:23:52 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:23:52 --> Utf8 Class Initialized
INFO - 2023-05-20 05:23:52 --> URI Class Initialized
DEBUG - 2023-05-20 05:23:52 --> No URI present. Default controller set.
INFO - 2023-05-20 05:23:52 --> Router Class Initialized
INFO - 2023-05-20 05:23:52 --> Output Class Initialized
INFO - 2023-05-20 05:23:52 --> Security Class Initialized
DEBUG - 2023-05-20 05:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:23:52 --> Input Class Initialized
INFO - 2023-05-20 05:23:52 --> Language Class Initialized
INFO - 2023-05-20 05:23:52 --> Loader Class Initialized
INFO - 2023-05-20 05:23:52 --> Helper loaded: url_helper
INFO - 2023-05-20 05:23:52 --> Helper loaded: file_helper
INFO - 2023-05-20 05:23:52 --> Helper loaded: html_helper
INFO - 2023-05-20 05:23:52 --> Helper loaded: text_helper
INFO - 2023-05-20 05:23:52 --> Helper loaded: form_helper
INFO - 2023-05-20 05:23:52 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:23:52 --> Helper loaded: security_helper
INFO - 2023-05-20 05:23:52 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:23:52 --> Database Driver Class Initialized
INFO - 2023-05-20 05:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:23:52 --> Parser Class Initialized
INFO - 2023-05-20 05:23:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:23:52 --> Pagination Class Initialized
INFO - 2023-05-20 05:23:52 --> Form Validation Class Initialized
INFO - 2023-05-20 05:23:52 --> Controller Class Initialized
INFO - 2023-05-20 05:23:52 --> Model Class Initialized
DEBUG - 2023-05-20 05:23:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:23:52 --> Model Class Initialized
DEBUG - 2023-05-20 05:23:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:23:52 --> Model Class Initialized
INFO - 2023-05-20 05:23:52 --> Model Class Initialized
INFO - 2023-05-20 05:23:52 --> Model Class Initialized
INFO - 2023-05-20 05:23:52 --> Model Class Initialized
DEBUG - 2023-05-20 05:23:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 05:23:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:23:52 --> Model Class Initialized
INFO - 2023-05-20 05:23:52 --> Model Class Initialized
INFO - 2023-05-20 05:23:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 05:23:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:23:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 05:23:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 05:23:52 --> Model Class Initialized
INFO - 2023-05-20 05:23:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 05:23:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 05:23:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 05:23:52 --> Final output sent to browser
DEBUG - 2023-05-20 05:23:52 --> Total execution time: 0.0753
ERROR - 2023-05-20 05:24:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:24:02 --> Config Class Initialized
INFO - 2023-05-20 05:24:02 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:24:02 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:24:02 --> Utf8 Class Initialized
INFO - 2023-05-20 05:24:02 --> URI Class Initialized
INFO - 2023-05-20 05:24:02 --> Router Class Initialized
INFO - 2023-05-20 05:24:02 --> Output Class Initialized
INFO - 2023-05-20 05:24:02 --> Security Class Initialized
DEBUG - 2023-05-20 05:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:24:02 --> Input Class Initialized
INFO - 2023-05-20 05:24:02 --> Language Class Initialized
INFO - 2023-05-20 05:24:02 --> Loader Class Initialized
INFO - 2023-05-20 05:24:02 --> Helper loaded: url_helper
INFO - 2023-05-20 05:24:02 --> Helper loaded: file_helper
INFO - 2023-05-20 05:24:02 --> Helper loaded: html_helper
INFO - 2023-05-20 05:24:02 --> Helper loaded: text_helper
INFO - 2023-05-20 05:24:02 --> Helper loaded: form_helper
INFO - 2023-05-20 05:24:02 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:24:02 --> Helper loaded: security_helper
INFO - 2023-05-20 05:24:02 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:24:02 --> Database Driver Class Initialized
INFO - 2023-05-20 05:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:24:02 --> Parser Class Initialized
INFO - 2023-05-20 05:24:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:24:02 --> Pagination Class Initialized
INFO - 2023-05-20 05:24:02 --> Form Validation Class Initialized
INFO - 2023-05-20 05:24:02 --> Controller Class Initialized
INFO - 2023-05-20 05:24:02 --> Model Class Initialized
DEBUG - 2023-05-20 05:24:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:24:02 --> Final output sent to browser
DEBUG - 2023-05-20 05:24:02 --> Total execution time: 0.0132
ERROR - 2023-05-20 05:24:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:24:03 --> Config Class Initialized
INFO - 2023-05-20 05:24:03 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:24:03 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:24:03 --> Utf8 Class Initialized
INFO - 2023-05-20 05:24:03 --> URI Class Initialized
INFO - 2023-05-20 05:24:03 --> Router Class Initialized
INFO - 2023-05-20 05:24:03 --> Output Class Initialized
INFO - 2023-05-20 05:24:03 --> Security Class Initialized
DEBUG - 2023-05-20 05:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:24:03 --> Input Class Initialized
INFO - 2023-05-20 05:24:03 --> Language Class Initialized
INFO - 2023-05-20 05:24:03 --> Loader Class Initialized
INFO - 2023-05-20 05:24:03 --> Helper loaded: url_helper
INFO - 2023-05-20 05:24:03 --> Helper loaded: file_helper
INFO - 2023-05-20 05:24:03 --> Helper loaded: html_helper
INFO - 2023-05-20 05:24:03 --> Helper loaded: text_helper
INFO - 2023-05-20 05:24:03 --> Helper loaded: form_helper
INFO - 2023-05-20 05:24:03 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:24:03 --> Helper loaded: security_helper
INFO - 2023-05-20 05:24:03 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:24:03 --> Database Driver Class Initialized
INFO - 2023-05-20 05:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:24:03 --> Parser Class Initialized
INFO - 2023-05-20 05:24:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:24:03 --> Pagination Class Initialized
INFO - 2023-05-20 05:24:03 --> Form Validation Class Initialized
INFO - 2023-05-20 05:24:03 --> Controller Class Initialized
INFO - 2023-05-20 05:24:03 --> Model Class Initialized
DEBUG - 2023-05-20 05:24:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:24:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-20 05:24:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:24:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 05:24:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 05:24:03 --> Model Class Initialized
INFO - 2023-05-20 05:24:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 05:24:03 --> Final output sent to browser
DEBUG - 2023-05-20 05:24:03 --> Total execution time: 0.0297
ERROR - 2023-05-20 05:24:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:24:15 --> Config Class Initialized
INFO - 2023-05-20 05:24:15 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:24:15 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:24:15 --> Utf8 Class Initialized
INFO - 2023-05-20 05:24:15 --> URI Class Initialized
INFO - 2023-05-20 05:24:15 --> Router Class Initialized
INFO - 2023-05-20 05:24:15 --> Output Class Initialized
INFO - 2023-05-20 05:24:15 --> Security Class Initialized
DEBUG - 2023-05-20 05:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:24:15 --> Input Class Initialized
INFO - 2023-05-20 05:24:15 --> Language Class Initialized
INFO - 2023-05-20 05:24:15 --> Loader Class Initialized
INFO - 2023-05-20 05:24:15 --> Helper loaded: url_helper
INFO - 2023-05-20 05:24:15 --> Helper loaded: file_helper
INFO - 2023-05-20 05:24:15 --> Helper loaded: html_helper
INFO - 2023-05-20 05:24:15 --> Helper loaded: text_helper
INFO - 2023-05-20 05:24:15 --> Helper loaded: form_helper
INFO - 2023-05-20 05:24:15 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:24:15 --> Helper loaded: security_helper
INFO - 2023-05-20 05:24:15 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:24:15 --> Database Driver Class Initialized
INFO - 2023-05-20 05:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:24:15 --> Parser Class Initialized
INFO - 2023-05-20 05:24:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:24:15 --> Pagination Class Initialized
INFO - 2023-05-20 05:24:15 --> Form Validation Class Initialized
INFO - 2023-05-20 05:24:15 --> Controller Class Initialized
DEBUG - 2023-05-20 05:24:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 05:24:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:24:15 --> Model Class Initialized
DEBUG - 2023-05-20 05:24:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:24:15 --> Model Class Initialized
DEBUG - 2023-05-20 05:24:15 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:24:15 --> Model Class Initialized
INFO - 2023-05-20 05:24:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-05-20 05:24:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:24:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 05:24:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 05:24:15 --> Model Class Initialized
INFO - 2023-05-20 05:24:15 --> Model Class Initialized
INFO - 2023-05-20 05:24:15 --> Model Class Initialized
INFO - 2023-05-20 05:24:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 05:24:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 05:24:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 05:24:15 --> Final output sent to browser
DEBUG - 2023-05-20 05:24:15 --> Total execution time: 0.1406
ERROR - 2023-05-20 05:24:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:24:15 --> Config Class Initialized
INFO - 2023-05-20 05:24:15 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:24:15 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:24:15 --> Utf8 Class Initialized
INFO - 2023-05-20 05:24:15 --> URI Class Initialized
INFO - 2023-05-20 05:24:15 --> Router Class Initialized
INFO - 2023-05-20 05:24:15 --> Output Class Initialized
INFO - 2023-05-20 05:24:15 --> Security Class Initialized
DEBUG - 2023-05-20 05:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:24:15 --> Input Class Initialized
INFO - 2023-05-20 05:24:15 --> Language Class Initialized
INFO - 2023-05-20 05:24:15 --> Loader Class Initialized
INFO - 2023-05-20 05:24:15 --> Helper loaded: url_helper
INFO - 2023-05-20 05:24:15 --> Helper loaded: file_helper
INFO - 2023-05-20 05:24:15 --> Helper loaded: html_helper
INFO - 2023-05-20 05:24:15 --> Helper loaded: text_helper
INFO - 2023-05-20 05:24:15 --> Helper loaded: form_helper
INFO - 2023-05-20 05:24:15 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:24:15 --> Helper loaded: security_helper
INFO - 2023-05-20 05:24:15 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:24:15 --> Database Driver Class Initialized
INFO - 2023-05-20 05:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:24:15 --> Parser Class Initialized
INFO - 2023-05-20 05:24:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:24:15 --> Pagination Class Initialized
INFO - 2023-05-20 05:24:15 --> Form Validation Class Initialized
INFO - 2023-05-20 05:24:15 --> Controller Class Initialized
DEBUG - 2023-05-20 05:24:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 05:24:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:24:15 --> Model Class Initialized
DEBUG - 2023-05-20 05:24:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:24:15 --> Model Class Initialized
INFO - 2023-05-20 05:24:15 --> Final output sent to browser
DEBUG - 2023-05-20 05:24:15 --> Total execution time: 0.0370
ERROR - 2023-05-20 05:24:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:24:26 --> Config Class Initialized
INFO - 2023-05-20 05:24:26 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:24:26 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:24:26 --> Utf8 Class Initialized
INFO - 2023-05-20 05:24:26 --> URI Class Initialized
INFO - 2023-05-20 05:24:26 --> Router Class Initialized
INFO - 2023-05-20 05:24:26 --> Output Class Initialized
INFO - 2023-05-20 05:24:26 --> Security Class Initialized
DEBUG - 2023-05-20 05:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:24:26 --> Input Class Initialized
INFO - 2023-05-20 05:24:26 --> Language Class Initialized
INFO - 2023-05-20 05:24:26 --> Loader Class Initialized
INFO - 2023-05-20 05:24:26 --> Helper loaded: url_helper
INFO - 2023-05-20 05:24:26 --> Helper loaded: file_helper
INFO - 2023-05-20 05:24:26 --> Helper loaded: html_helper
INFO - 2023-05-20 05:24:26 --> Helper loaded: text_helper
INFO - 2023-05-20 05:24:26 --> Helper loaded: form_helper
INFO - 2023-05-20 05:24:26 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:24:26 --> Helper loaded: security_helper
INFO - 2023-05-20 05:24:26 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:24:26 --> Database Driver Class Initialized
INFO - 2023-05-20 05:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:24:26 --> Parser Class Initialized
INFO - 2023-05-20 05:24:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:24:26 --> Pagination Class Initialized
INFO - 2023-05-20 05:24:26 --> Form Validation Class Initialized
INFO - 2023-05-20 05:24:26 --> Controller Class Initialized
DEBUG - 2023-05-20 05:24:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 05:24:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:24:26 --> Model Class Initialized
DEBUG - 2023-05-20 05:24:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:24:26 --> Model Class Initialized
INFO - 2023-05-20 05:24:26 --> Final output sent to browser
DEBUG - 2023-05-20 05:24:26 --> Total execution time: 0.0943
ERROR - 2023-05-20 05:24:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:24:36 --> Config Class Initialized
INFO - 2023-05-20 05:24:36 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:24:36 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:24:36 --> Utf8 Class Initialized
INFO - 2023-05-20 05:24:36 --> URI Class Initialized
INFO - 2023-05-20 05:24:36 --> Router Class Initialized
INFO - 2023-05-20 05:24:36 --> Output Class Initialized
INFO - 2023-05-20 05:24:36 --> Security Class Initialized
DEBUG - 2023-05-20 05:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:24:36 --> Input Class Initialized
INFO - 2023-05-20 05:24:36 --> Language Class Initialized
INFO - 2023-05-20 05:24:36 --> Loader Class Initialized
INFO - 2023-05-20 05:24:36 --> Helper loaded: url_helper
INFO - 2023-05-20 05:24:36 --> Helper loaded: file_helper
INFO - 2023-05-20 05:24:36 --> Helper loaded: html_helper
INFO - 2023-05-20 05:24:36 --> Helper loaded: text_helper
INFO - 2023-05-20 05:24:36 --> Helper loaded: form_helper
INFO - 2023-05-20 05:24:36 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:24:36 --> Helper loaded: security_helper
INFO - 2023-05-20 05:24:36 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:24:36 --> Database Driver Class Initialized
INFO - 2023-05-20 05:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:24:36 --> Parser Class Initialized
INFO - 2023-05-20 05:24:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:24:36 --> Pagination Class Initialized
INFO - 2023-05-20 05:24:36 --> Form Validation Class Initialized
INFO - 2023-05-20 05:24:36 --> Controller Class Initialized
INFO - 2023-05-20 05:24:36 --> Model Class Initialized
DEBUG - 2023-05-20 05:24:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 05:24:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:24:36 --> Model Class Initialized
DEBUG - 2023-05-20 05:24:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:24:36 --> Model Class Initialized
INFO - 2023-05-20 05:24:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-20 05:24:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:24:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 05:24:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 05:24:36 --> Model Class Initialized
INFO - 2023-05-20 05:24:36 --> Model Class Initialized
INFO - 2023-05-20 05:24:36 --> Model Class Initialized
INFO - 2023-05-20 05:24:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 05:24:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 05:24:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 05:24:36 --> Final output sent to browser
DEBUG - 2023-05-20 05:24:36 --> Total execution time: 0.1543
ERROR - 2023-05-20 05:24:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:24:38 --> Config Class Initialized
INFO - 2023-05-20 05:24:38 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:24:38 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:24:38 --> Utf8 Class Initialized
INFO - 2023-05-20 05:24:38 --> URI Class Initialized
INFO - 2023-05-20 05:24:38 --> Router Class Initialized
INFO - 2023-05-20 05:24:38 --> Output Class Initialized
INFO - 2023-05-20 05:24:38 --> Security Class Initialized
DEBUG - 2023-05-20 05:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:24:38 --> Input Class Initialized
INFO - 2023-05-20 05:24:38 --> Language Class Initialized
INFO - 2023-05-20 05:24:38 --> Loader Class Initialized
INFO - 2023-05-20 05:24:38 --> Helper loaded: url_helper
INFO - 2023-05-20 05:24:38 --> Helper loaded: file_helper
INFO - 2023-05-20 05:24:38 --> Helper loaded: html_helper
INFO - 2023-05-20 05:24:38 --> Helper loaded: text_helper
INFO - 2023-05-20 05:24:38 --> Helper loaded: form_helper
INFO - 2023-05-20 05:24:38 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:24:38 --> Helper loaded: security_helper
INFO - 2023-05-20 05:24:38 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:24:38 --> Database Driver Class Initialized
INFO - 2023-05-20 05:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:24:38 --> Parser Class Initialized
INFO - 2023-05-20 05:24:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:24:38 --> Pagination Class Initialized
INFO - 2023-05-20 05:24:38 --> Form Validation Class Initialized
INFO - 2023-05-20 05:24:38 --> Controller Class Initialized
INFO - 2023-05-20 05:24:38 --> Model Class Initialized
DEBUG - 2023-05-20 05:24:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 05:24:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:24:38 --> Model Class Initialized
DEBUG - 2023-05-20 05:24:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:24:38 --> Model Class Initialized
INFO - 2023-05-20 05:24:38 --> Final output sent to browser
DEBUG - 2023-05-20 05:24:38 --> Total execution time: 0.0520
ERROR - 2023-05-20 05:24:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:24:40 --> Config Class Initialized
INFO - 2023-05-20 05:24:40 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:24:40 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:24:40 --> Utf8 Class Initialized
INFO - 2023-05-20 05:24:40 --> URI Class Initialized
INFO - 2023-05-20 05:24:40 --> Router Class Initialized
INFO - 2023-05-20 05:24:40 --> Output Class Initialized
INFO - 2023-05-20 05:24:40 --> Security Class Initialized
DEBUG - 2023-05-20 05:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:24:40 --> Input Class Initialized
INFO - 2023-05-20 05:24:40 --> Language Class Initialized
INFO - 2023-05-20 05:24:40 --> Loader Class Initialized
INFO - 2023-05-20 05:24:40 --> Helper loaded: url_helper
INFO - 2023-05-20 05:24:40 --> Helper loaded: file_helper
INFO - 2023-05-20 05:24:40 --> Helper loaded: html_helper
INFO - 2023-05-20 05:24:40 --> Helper loaded: text_helper
INFO - 2023-05-20 05:24:40 --> Helper loaded: form_helper
INFO - 2023-05-20 05:24:40 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:24:40 --> Helper loaded: security_helper
INFO - 2023-05-20 05:24:40 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:24:40 --> Database Driver Class Initialized
INFO - 2023-05-20 05:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:24:40 --> Parser Class Initialized
INFO - 2023-05-20 05:24:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:24:40 --> Pagination Class Initialized
INFO - 2023-05-20 05:24:40 --> Form Validation Class Initialized
INFO - 2023-05-20 05:24:40 --> Controller Class Initialized
INFO - 2023-05-20 05:24:40 --> Model Class Initialized
DEBUG - 2023-05-20 05:24:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 05:24:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:24:40 --> Model Class Initialized
DEBUG - 2023-05-20 05:24:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:24:40 --> Model Class Initialized
INFO - 2023-05-20 05:24:40 --> Final output sent to browser
DEBUG - 2023-05-20 05:24:40 --> Total execution time: 0.1569
ERROR - 2023-05-20 05:31:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:31:12 --> Config Class Initialized
INFO - 2023-05-20 05:31:12 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:31:12 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:31:12 --> Utf8 Class Initialized
INFO - 2023-05-20 05:31:12 --> URI Class Initialized
DEBUG - 2023-05-20 05:31:12 --> No URI present. Default controller set.
INFO - 2023-05-20 05:31:12 --> Router Class Initialized
INFO - 2023-05-20 05:31:12 --> Output Class Initialized
INFO - 2023-05-20 05:31:12 --> Security Class Initialized
DEBUG - 2023-05-20 05:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:31:12 --> Input Class Initialized
INFO - 2023-05-20 05:31:12 --> Language Class Initialized
INFO - 2023-05-20 05:31:12 --> Loader Class Initialized
INFO - 2023-05-20 05:31:12 --> Helper loaded: url_helper
INFO - 2023-05-20 05:31:12 --> Helper loaded: file_helper
INFO - 2023-05-20 05:31:12 --> Helper loaded: html_helper
INFO - 2023-05-20 05:31:12 --> Helper loaded: text_helper
INFO - 2023-05-20 05:31:12 --> Helper loaded: form_helper
INFO - 2023-05-20 05:31:12 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:31:12 --> Helper loaded: security_helper
INFO - 2023-05-20 05:31:12 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:31:12 --> Database Driver Class Initialized
INFO - 2023-05-20 05:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:31:12 --> Parser Class Initialized
INFO - 2023-05-20 05:31:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:31:12 --> Pagination Class Initialized
INFO - 2023-05-20 05:31:12 --> Form Validation Class Initialized
INFO - 2023-05-20 05:31:12 --> Controller Class Initialized
INFO - 2023-05-20 05:31:12 --> Model Class Initialized
DEBUG - 2023-05-20 05:31:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:31:12 --> Model Class Initialized
DEBUG - 2023-05-20 05:31:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:31:12 --> Model Class Initialized
INFO - 2023-05-20 05:31:12 --> Model Class Initialized
INFO - 2023-05-20 05:31:12 --> Model Class Initialized
INFO - 2023-05-20 05:31:12 --> Model Class Initialized
DEBUG - 2023-05-20 05:31:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 05:31:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:31:12 --> Model Class Initialized
INFO - 2023-05-20 05:31:12 --> Model Class Initialized
INFO - 2023-05-20 05:31:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 05:31:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:31:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 05:31:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 05:31:12 --> Model Class Initialized
INFO - 2023-05-20 05:31:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 05:31:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 05:31:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 05:31:12 --> Final output sent to browser
DEBUG - 2023-05-20 05:31:12 --> Total execution time: 0.2004
ERROR - 2023-05-20 05:41:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:41:05 --> Config Class Initialized
INFO - 2023-05-20 05:41:05 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:41:05 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:41:05 --> Utf8 Class Initialized
INFO - 2023-05-20 05:41:05 --> URI Class Initialized
DEBUG - 2023-05-20 05:41:05 --> No URI present. Default controller set.
INFO - 2023-05-20 05:41:05 --> Router Class Initialized
INFO - 2023-05-20 05:41:05 --> Output Class Initialized
INFO - 2023-05-20 05:41:05 --> Security Class Initialized
DEBUG - 2023-05-20 05:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:41:05 --> Input Class Initialized
INFO - 2023-05-20 05:41:05 --> Language Class Initialized
INFO - 2023-05-20 05:41:05 --> Loader Class Initialized
INFO - 2023-05-20 05:41:05 --> Helper loaded: url_helper
INFO - 2023-05-20 05:41:05 --> Helper loaded: file_helper
INFO - 2023-05-20 05:41:05 --> Helper loaded: html_helper
INFO - 2023-05-20 05:41:05 --> Helper loaded: text_helper
INFO - 2023-05-20 05:41:05 --> Helper loaded: form_helper
INFO - 2023-05-20 05:41:05 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:41:05 --> Helper loaded: security_helper
INFO - 2023-05-20 05:41:05 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:41:05 --> Database Driver Class Initialized
INFO - 2023-05-20 05:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:41:05 --> Parser Class Initialized
INFO - 2023-05-20 05:41:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:41:05 --> Pagination Class Initialized
INFO - 2023-05-20 05:41:05 --> Form Validation Class Initialized
INFO - 2023-05-20 05:41:05 --> Controller Class Initialized
INFO - 2023-05-20 05:41:05 --> Model Class Initialized
DEBUG - 2023-05-20 05:41:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-20 05:41:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:41:06 --> Config Class Initialized
INFO - 2023-05-20 05:41:06 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:41:06 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:41:06 --> Utf8 Class Initialized
INFO - 2023-05-20 05:41:06 --> URI Class Initialized
INFO - 2023-05-20 05:41:06 --> Router Class Initialized
INFO - 2023-05-20 05:41:06 --> Output Class Initialized
INFO - 2023-05-20 05:41:06 --> Security Class Initialized
DEBUG - 2023-05-20 05:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:41:06 --> Input Class Initialized
INFO - 2023-05-20 05:41:06 --> Language Class Initialized
INFO - 2023-05-20 05:41:06 --> Loader Class Initialized
INFO - 2023-05-20 05:41:06 --> Helper loaded: url_helper
INFO - 2023-05-20 05:41:06 --> Helper loaded: file_helper
INFO - 2023-05-20 05:41:06 --> Helper loaded: html_helper
INFO - 2023-05-20 05:41:06 --> Helper loaded: text_helper
INFO - 2023-05-20 05:41:06 --> Helper loaded: form_helper
INFO - 2023-05-20 05:41:06 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:41:06 --> Helper loaded: security_helper
INFO - 2023-05-20 05:41:06 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:41:06 --> Database Driver Class Initialized
INFO - 2023-05-20 05:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:41:06 --> Parser Class Initialized
INFO - 2023-05-20 05:41:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:41:06 --> Pagination Class Initialized
INFO - 2023-05-20 05:41:06 --> Form Validation Class Initialized
INFO - 2023-05-20 05:41:06 --> Controller Class Initialized
INFO - 2023-05-20 05:41:06 --> Model Class Initialized
DEBUG - 2023-05-20 05:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:41:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-20 05:41:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:41:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 05:41:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 05:41:06 --> Model Class Initialized
INFO - 2023-05-20 05:41:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 05:41:06 --> Final output sent to browser
DEBUG - 2023-05-20 05:41:06 --> Total execution time: 0.0289
ERROR - 2023-05-20 05:44:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:44:19 --> Config Class Initialized
INFO - 2023-05-20 05:44:19 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:44:19 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:44:19 --> Utf8 Class Initialized
INFO - 2023-05-20 05:44:19 --> URI Class Initialized
INFO - 2023-05-20 05:44:19 --> Router Class Initialized
INFO - 2023-05-20 05:44:19 --> Output Class Initialized
INFO - 2023-05-20 05:44:19 --> Security Class Initialized
DEBUG - 2023-05-20 05:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:44:19 --> Input Class Initialized
INFO - 2023-05-20 05:44:19 --> Language Class Initialized
INFO - 2023-05-20 05:44:19 --> Loader Class Initialized
INFO - 2023-05-20 05:44:19 --> Helper loaded: url_helper
INFO - 2023-05-20 05:44:19 --> Helper loaded: file_helper
INFO - 2023-05-20 05:44:19 --> Helper loaded: html_helper
INFO - 2023-05-20 05:44:19 --> Helper loaded: text_helper
INFO - 2023-05-20 05:44:19 --> Helper loaded: form_helper
INFO - 2023-05-20 05:44:19 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:44:19 --> Helper loaded: security_helper
INFO - 2023-05-20 05:44:19 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:44:19 --> Database Driver Class Initialized
INFO - 2023-05-20 05:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:44:19 --> Parser Class Initialized
INFO - 2023-05-20 05:44:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:44:19 --> Pagination Class Initialized
INFO - 2023-05-20 05:44:19 --> Form Validation Class Initialized
INFO - 2023-05-20 05:44:19 --> Controller Class Initialized
ERROR - 2023-05-20 05:44:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:44:29 --> Config Class Initialized
INFO - 2023-05-20 05:44:29 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:44:29 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:44:29 --> Utf8 Class Initialized
INFO - 2023-05-20 05:44:29 --> URI Class Initialized
DEBUG - 2023-05-20 05:44:29 --> No URI present. Default controller set.
INFO - 2023-05-20 05:44:29 --> Router Class Initialized
INFO - 2023-05-20 05:44:29 --> Output Class Initialized
INFO - 2023-05-20 05:44:29 --> Security Class Initialized
DEBUG - 2023-05-20 05:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:44:29 --> Input Class Initialized
INFO - 2023-05-20 05:44:29 --> Language Class Initialized
INFO - 2023-05-20 05:44:29 --> Loader Class Initialized
INFO - 2023-05-20 05:44:29 --> Helper loaded: url_helper
INFO - 2023-05-20 05:44:29 --> Helper loaded: file_helper
INFO - 2023-05-20 05:44:29 --> Helper loaded: html_helper
INFO - 2023-05-20 05:44:29 --> Helper loaded: text_helper
INFO - 2023-05-20 05:44:29 --> Helper loaded: form_helper
INFO - 2023-05-20 05:44:29 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:44:29 --> Helper loaded: security_helper
INFO - 2023-05-20 05:44:29 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:44:29 --> Database Driver Class Initialized
INFO - 2023-05-20 05:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:44:29 --> Parser Class Initialized
INFO - 2023-05-20 05:44:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:44:29 --> Pagination Class Initialized
INFO - 2023-05-20 05:44:29 --> Form Validation Class Initialized
INFO - 2023-05-20 05:44:29 --> Controller Class Initialized
INFO - 2023-05-20 05:44:29 --> Model Class Initialized
DEBUG - 2023-05-20 05:44:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:44:29 --> Model Class Initialized
DEBUG - 2023-05-20 05:44:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:44:29 --> Model Class Initialized
INFO - 2023-05-20 05:44:29 --> Model Class Initialized
INFO - 2023-05-20 05:44:29 --> Model Class Initialized
INFO - 2023-05-20 05:44:29 --> Model Class Initialized
DEBUG - 2023-05-20 05:44:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 05:44:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:44:29 --> Model Class Initialized
INFO - 2023-05-20 05:44:29 --> Model Class Initialized
INFO - 2023-05-20 05:44:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 05:44:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 05:44:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 05:44:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 05:44:29 --> Model Class Initialized
INFO - 2023-05-20 05:44:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 05:44:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 05:44:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 05:44:29 --> Final output sent to browser
DEBUG - 2023-05-20 05:44:29 --> Total execution time: 0.1911
ERROR - 2023-05-20 05:47:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:47:49 --> Config Class Initialized
INFO - 2023-05-20 05:47:49 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:47:49 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:47:49 --> Utf8 Class Initialized
INFO - 2023-05-20 05:47:49 --> URI Class Initialized
INFO - 2023-05-20 05:47:49 --> Router Class Initialized
INFO - 2023-05-20 05:47:49 --> Output Class Initialized
INFO - 2023-05-20 05:47:49 --> Security Class Initialized
DEBUG - 2023-05-20 05:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:47:49 --> Input Class Initialized
INFO - 2023-05-20 05:47:49 --> Language Class Initialized
INFO - 2023-05-20 05:47:49 --> Loader Class Initialized
INFO - 2023-05-20 05:47:49 --> Helper loaded: url_helper
INFO - 2023-05-20 05:47:49 --> Helper loaded: file_helper
INFO - 2023-05-20 05:47:49 --> Helper loaded: html_helper
INFO - 2023-05-20 05:47:49 --> Helper loaded: text_helper
INFO - 2023-05-20 05:47:49 --> Helper loaded: form_helper
INFO - 2023-05-20 05:47:49 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:47:49 --> Helper loaded: security_helper
INFO - 2023-05-20 05:47:49 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:47:49 --> Database Driver Class Initialized
INFO - 2023-05-20 05:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:47:49 --> Parser Class Initialized
INFO - 2023-05-20 05:47:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:47:49 --> Pagination Class Initialized
INFO - 2023-05-20 05:47:49 --> Form Validation Class Initialized
INFO - 2023-05-20 05:47:49 --> Controller Class Initialized
ERROR - 2023-05-20 05:49:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 05:49:00 --> Config Class Initialized
INFO - 2023-05-20 05:49:00 --> Hooks Class Initialized
DEBUG - 2023-05-20 05:49:00 --> UTF-8 Support Enabled
INFO - 2023-05-20 05:49:00 --> Utf8 Class Initialized
INFO - 2023-05-20 05:49:00 --> URI Class Initialized
INFO - 2023-05-20 05:49:00 --> Router Class Initialized
INFO - 2023-05-20 05:49:00 --> Output Class Initialized
INFO - 2023-05-20 05:49:00 --> Security Class Initialized
DEBUG - 2023-05-20 05:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 05:49:00 --> Input Class Initialized
INFO - 2023-05-20 05:49:00 --> Language Class Initialized
INFO - 2023-05-20 05:49:00 --> Loader Class Initialized
INFO - 2023-05-20 05:49:00 --> Helper loaded: url_helper
INFO - 2023-05-20 05:49:00 --> Helper loaded: file_helper
INFO - 2023-05-20 05:49:00 --> Helper loaded: html_helper
INFO - 2023-05-20 05:49:00 --> Helper loaded: text_helper
INFO - 2023-05-20 05:49:00 --> Helper loaded: form_helper
INFO - 2023-05-20 05:49:00 --> Helper loaded: lang_helper
INFO - 2023-05-20 05:49:00 --> Helper loaded: security_helper
INFO - 2023-05-20 05:49:00 --> Helper loaded: cookie_helper
INFO - 2023-05-20 05:49:00 --> Database Driver Class Initialized
INFO - 2023-05-20 05:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 05:49:00 --> Parser Class Initialized
INFO - 2023-05-20 05:49:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 05:49:00 --> Pagination Class Initialized
INFO - 2023-05-20 05:49:00 --> Form Validation Class Initialized
INFO - 2023-05-20 05:49:00 --> Controller Class Initialized
ERROR - 2023-05-20 06:34:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 06:34:52 --> Config Class Initialized
INFO - 2023-05-20 06:34:52 --> Hooks Class Initialized
DEBUG - 2023-05-20 06:34:52 --> UTF-8 Support Enabled
INFO - 2023-05-20 06:34:52 --> Utf8 Class Initialized
INFO - 2023-05-20 06:34:52 --> URI Class Initialized
DEBUG - 2023-05-20 06:34:52 --> No URI present. Default controller set.
INFO - 2023-05-20 06:34:52 --> Router Class Initialized
INFO - 2023-05-20 06:34:52 --> Output Class Initialized
INFO - 2023-05-20 06:34:52 --> Security Class Initialized
DEBUG - 2023-05-20 06:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 06:34:52 --> Input Class Initialized
INFO - 2023-05-20 06:34:52 --> Language Class Initialized
INFO - 2023-05-20 06:34:52 --> Loader Class Initialized
INFO - 2023-05-20 06:34:52 --> Helper loaded: url_helper
INFO - 2023-05-20 06:34:52 --> Helper loaded: file_helper
INFO - 2023-05-20 06:34:52 --> Helper loaded: html_helper
INFO - 2023-05-20 06:34:52 --> Helper loaded: text_helper
INFO - 2023-05-20 06:34:52 --> Helper loaded: form_helper
INFO - 2023-05-20 06:34:52 --> Helper loaded: lang_helper
INFO - 2023-05-20 06:34:52 --> Helper loaded: security_helper
INFO - 2023-05-20 06:34:52 --> Helper loaded: cookie_helper
INFO - 2023-05-20 06:34:52 --> Database Driver Class Initialized
INFO - 2023-05-20 06:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 06:34:52 --> Parser Class Initialized
INFO - 2023-05-20 06:34:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 06:34:52 --> Pagination Class Initialized
INFO - 2023-05-20 06:34:52 --> Form Validation Class Initialized
INFO - 2023-05-20 06:34:52 --> Controller Class Initialized
INFO - 2023-05-20 06:34:52 --> Model Class Initialized
DEBUG - 2023-05-20 06:34:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:34:52 --> Model Class Initialized
DEBUG - 2023-05-20 06:34:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:34:52 --> Model Class Initialized
INFO - 2023-05-20 06:34:52 --> Model Class Initialized
INFO - 2023-05-20 06:34:52 --> Model Class Initialized
INFO - 2023-05-20 06:34:52 --> Model Class Initialized
DEBUG - 2023-05-20 06:34:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 06:34:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:34:52 --> Model Class Initialized
INFO - 2023-05-20 06:34:52 --> Model Class Initialized
INFO - 2023-05-20 06:34:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 06:34:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:34:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 06:34:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 06:34:52 --> Model Class Initialized
INFO - 2023-05-20 06:34:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 06:34:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 06:34:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 06:34:52 --> Final output sent to browser
DEBUG - 2023-05-20 06:34:52 --> Total execution time: 0.1887
ERROR - 2023-05-20 06:35:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 06:35:02 --> Config Class Initialized
INFO - 2023-05-20 06:35:02 --> Hooks Class Initialized
DEBUG - 2023-05-20 06:35:02 --> UTF-8 Support Enabled
INFO - 2023-05-20 06:35:02 --> Utf8 Class Initialized
INFO - 2023-05-20 06:35:02 --> URI Class Initialized
INFO - 2023-05-20 06:35:02 --> Router Class Initialized
INFO - 2023-05-20 06:35:02 --> Output Class Initialized
INFO - 2023-05-20 06:35:02 --> Security Class Initialized
DEBUG - 2023-05-20 06:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 06:35:02 --> Input Class Initialized
INFO - 2023-05-20 06:35:02 --> Language Class Initialized
INFO - 2023-05-20 06:35:02 --> Loader Class Initialized
INFO - 2023-05-20 06:35:02 --> Helper loaded: url_helper
INFO - 2023-05-20 06:35:02 --> Helper loaded: file_helper
INFO - 2023-05-20 06:35:02 --> Helper loaded: html_helper
INFO - 2023-05-20 06:35:02 --> Helper loaded: text_helper
INFO - 2023-05-20 06:35:02 --> Helper loaded: form_helper
INFO - 2023-05-20 06:35:02 --> Helper loaded: lang_helper
INFO - 2023-05-20 06:35:02 --> Helper loaded: security_helper
INFO - 2023-05-20 06:35:02 --> Helper loaded: cookie_helper
INFO - 2023-05-20 06:35:02 --> Database Driver Class Initialized
INFO - 2023-05-20 06:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 06:35:02 --> Parser Class Initialized
INFO - 2023-05-20 06:35:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 06:35:02 --> Pagination Class Initialized
INFO - 2023-05-20 06:35:02 --> Form Validation Class Initialized
INFO - 2023-05-20 06:35:02 --> Controller Class Initialized
INFO - 2023-05-20 06:35:02 --> Model Class Initialized
DEBUG - 2023-05-20 06:35:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 06:35:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:35:02 --> Model Class Initialized
DEBUG - 2023-05-20 06:35:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:35:02 --> Model Class Initialized
INFO - 2023-05-20 06:35:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-20 06:35:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:35:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 06:35:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 06:35:02 --> Model Class Initialized
INFO - 2023-05-20 06:35:02 --> Model Class Initialized
INFO - 2023-05-20 06:35:02 --> Model Class Initialized
INFO - 2023-05-20 06:35:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 06:35:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 06:35:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 06:35:02 --> Final output sent to browser
DEBUG - 2023-05-20 06:35:02 --> Total execution time: 0.1433
ERROR - 2023-05-20 06:35:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 06:35:02 --> Config Class Initialized
INFO - 2023-05-20 06:35:02 --> Hooks Class Initialized
DEBUG - 2023-05-20 06:35:02 --> UTF-8 Support Enabled
INFO - 2023-05-20 06:35:02 --> Utf8 Class Initialized
INFO - 2023-05-20 06:35:02 --> URI Class Initialized
INFO - 2023-05-20 06:35:02 --> Router Class Initialized
INFO - 2023-05-20 06:35:02 --> Output Class Initialized
INFO - 2023-05-20 06:35:02 --> Security Class Initialized
DEBUG - 2023-05-20 06:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 06:35:02 --> Input Class Initialized
INFO - 2023-05-20 06:35:02 --> Language Class Initialized
INFO - 2023-05-20 06:35:02 --> Loader Class Initialized
INFO - 2023-05-20 06:35:02 --> Helper loaded: url_helper
INFO - 2023-05-20 06:35:02 --> Helper loaded: file_helper
INFO - 2023-05-20 06:35:02 --> Helper loaded: html_helper
INFO - 2023-05-20 06:35:02 --> Helper loaded: text_helper
INFO - 2023-05-20 06:35:02 --> Helper loaded: form_helper
INFO - 2023-05-20 06:35:02 --> Helper loaded: lang_helper
INFO - 2023-05-20 06:35:02 --> Helper loaded: security_helper
INFO - 2023-05-20 06:35:02 --> Helper loaded: cookie_helper
INFO - 2023-05-20 06:35:02 --> Database Driver Class Initialized
INFO - 2023-05-20 06:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 06:35:02 --> Parser Class Initialized
INFO - 2023-05-20 06:35:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 06:35:02 --> Pagination Class Initialized
INFO - 2023-05-20 06:35:02 --> Form Validation Class Initialized
INFO - 2023-05-20 06:35:02 --> Controller Class Initialized
INFO - 2023-05-20 06:35:02 --> Model Class Initialized
DEBUG - 2023-05-20 06:35:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 06:35:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:35:02 --> Model Class Initialized
DEBUG - 2023-05-20 06:35:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:35:02 --> Model Class Initialized
INFO - 2023-05-20 06:35:02 --> Final output sent to browser
DEBUG - 2023-05-20 06:35:02 --> Total execution time: 0.0515
ERROR - 2023-05-20 06:35:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 06:35:06 --> Config Class Initialized
INFO - 2023-05-20 06:35:06 --> Hooks Class Initialized
DEBUG - 2023-05-20 06:35:06 --> UTF-8 Support Enabled
INFO - 2023-05-20 06:35:06 --> Utf8 Class Initialized
INFO - 2023-05-20 06:35:06 --> URI Class Initialized
INFO - 2023-05-20 06:35:06 --> Router Class Initialized
INFO - 2023-05-20 06:35:06 --> Output Class Initialized
INFO - 2023-05-20 06:35:06 --> Security Class Initialized
DEBUG - 2023-05-20 06:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 06:35:06 --> Input Class Initialized
INFO - 2023-05-20 06:35:06 --> Language Class Initialized
INFO - 2023-05-20 06:35:06 --> Loader Class Initialized
INFO - 2023-05-20 06:35:06 --> Helper loaded: url_helper
INFO - 2023-05-20 06:35:06 --> Helper loaded: file_helper
INFO - 2023-05-20 06:35:06 --> Helper loaded: html_helper
INFO - 2023-05-20 06:35:06 --> Helper loaded: text_helper
INFO - 2023-05-20 06:35:06 --> Helper loaded: form_helper
INFO - 2023-05-20 06:35:06 --> Helper loaded: lang_helper
INFO - 2023-05-20 06:35:06 --> Helper loaded: security_helper
INFO - 2023-05-20 06:35:06 --> Helper loaded: cookie_helper
INFO - 2023-05-20 06:35:06 --> Database Driver Class Initialized
INFO - 2023-05-20 06:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 06:35:06 --> Parser Class Initialized
INFO - 2023-05-20 06:35:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 06:35:06 --> Pagination Class Initialized
INFO - 2023-05-20 06:35:06 --> Form Validation Class Initialized
INFO - 2023-05-20 06:35:06 --> Controller Class Initialized
INFO - 2023-05-20 06:35:06 --> Model Class Initialized
DEBUG - 2023-05-20 06:35:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 06:35:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:35:06 --> Model Class Initialized
DEBUG - 2023-05-20 06:35:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:35:06 --> Model Class Initialized
INFO - 2023-05-20 06:35:06 --> Final output sent to browser
DEBUG - 2023-05-20 06:35:06 --> Total execution time: 0.1527
ERROR - 2023-05-20 06:35:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 06:35:20 --> Config Class Initialized
INFO - 2023-05-20 06:35:20 --> Hooks Class Initialized
DEBUG - 2023-05-20 06:35:20 --> UTF-8 Support Enabled
INFO - 2023-05-20 06:35:20 --> Utf8 Class Initialized
INFO - 2023-05-20 06:35:20 --> URI Class Initialized
DEBUG - 2023-05-20 06:35:20 --> No URI present. Default controller set.
INFO - 2023-05-20 06:35:20 --> Router Class Initialized
INFO - 2023-05-20 06:35:20 --> Output Class Initialized
INFO - 2023-05-20 06:35:20 --> Security Class Initialized
DEBUG - 2023-05-20 06:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 06:35:20 --> Input Class Initialized
INFO - 2023-05-20 06:35:20 --> Language Class Initialized
INFO - 2023-05-20 06:35:20 --> Loader Class Initialized
INFO - 2023-05-20 06:35:20 --> Helper loaded: url_helper
INFO - 2023-05-20 06:35:20 --> Helper loaded: file_helper
INFO - 2023-05-20 06:35:20 --> Helper loaded: html_helper
INFO - 2023-05-20 06:35:20 --> Helper loaded: text_helper
INFO - 2023-05-20 06:35:20 --> Helper loaded: form_helper
INFO - 2023-05-20 06:35:20 --> Helper loaded: lang_helper
INFO - 2023-05-20 06:35:20 --> Helper loaded: security_helper
INFO - 2023-05-20 06:35:20 --> Helper loaded: cookie_helper
INFO - 2023-05-20 06:35:20 --> Database Driver Class Initialized
INFO - 2023-05-20 06:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 06:35:20 --> Parser Class Initialized
INFO - 2023-05-20 06:35:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 06:35:20 --> Pagination Class Initialized
INFO - 2023-05-20 06:35:20 --> Form Validation Class Initialized
INFO - 2023-05-20 06:35:20 --> Controller Class Initialized
INFO - 2023-05-20 06:35:20 --> Model Class Initialized
DEBUG - 2023-05-20 06:35:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:35:20 --> Model Class Initialized
DEBUG - 2023-05-20 06:35:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:35:20 --> Model Class Initialized
INFO - 2023-05-20 06:35:20 --> Model Class Initialized
INFO - 2023-05-20 06:35:20 --> Model Class Initialized
INFO - 2023-05-20 06:35:20 --> Model Class Initialized
DEBUG - 2023-05-20 06:35:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 06:35:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:35:20 --> Model Class Initialized
INFO - 2023-05-20 06:35:20 --> Model Class Initialized
INFO - 2023-05-20 06:35:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 06:35:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:35:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 06:35:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 06:35:20 --> Model Class Initialized
INFO - 2023-05-20 06:35:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 06:35:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 06:35:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 06:35:20 --> Final output sent to browser
DEBUG - 2023-05-20 06:35:20 --> Total execution time: 0.1799
ERROR - 2023-05-20 06:35:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 06:35:40 --> Config Class Initialized
INFO - 2023-05-20 06:35:40 --> Hooks Class Initialized
DEBUG - 2023-05-20 06:35:40 --> UTF-8 Support Enabled
INFO - 2023-05-20 06:35:40 --> Utf8 Class Initialized
INFO - 2023-05-20 06:35:40 --> URI Class Initialized
INFO - 2023-05-20 06:35:40 --> Router Class Initialized
INFO - 2023-05-20 06:35:40 --> Output Class Initialized
INFO - 2023-05-20 06:35:40 --> Security Class Initialized
DEBUG - 2023-05-20 06:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 06:35:40 --> Input Class Initialized
INFO - 2023-05-20 06:35:40 --> Language Class Initialized
INFO - 2023-05-20 06:35:40 --> Loader Class Initialized
INFO - 2023-05-20 06:35:40 --> Helper loaded: url_helper
INFO - 2023-05-20 06:35:40 --> Helper loaded: file_helper
INFO - 2023-05-20 06:35:40 --> Helper loaded: html_helper
INFO - 2023-05-20 06:35:40 --> Helper loaded: text_helper
INFO - 2023-05-20 06:35:40 --> Helper loaded: form_helper
INFO - 2023-05-20 06:35:40 --> Helper loaded: lang_helper
INFO - 2023-05-20 06:35:40 --> Helper loaded: security_helper
INFO - 2023-05-20 06:35:40 --> Helper loaded: cookie_helper
INFO - 2023-05-20 06:35:40 --> Database Driver Class Initialized
INFO - 2023-05-20 06:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 06:35:40 --> Parser Class Initialized
INFO - 2023-05-20 06:35:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 06:35:40 --> Pagination Class Initialized
INFO - 2023-05-20 06:35:40 --> Form Validation Class Initialized
INFO - 2023-05-20 06:35:40 --> Controller Class Initialized
INFO - 2023-05-20 06:35:40 --> Model Class Initialized
DEBUG - 2023-05-20 06:35:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 06:35:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:35:40 --> Model Class Initialized
DEBUG - 2023-05-20 06:35:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:35:40 --> Model Class Initialized
INFO - 2023-05-20 06:35:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-20 06:35:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:35:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 06:35:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 06:35:40 --> Model Class Initialized
INFO - 2023-05-20 06:35:40 --> Model Class Initialized
INFO - 2023-05-20 06:35:40 --> Model Class Initialized
INFO - 2023-05-20 06:35:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 06:35:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 06:35:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 06:35:40 --> Final output sent to browser
DEBUG - 2023-05-20 06:35:40 --> Total execution time: 0.1387
ERROR - 2023-05-20 06:35:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 06:35:41 --> Config Class Initialized
INFO - 2023-05-20 06:35:41 --> Hooks Class Initialized
DEBUG - 2023-05-20 06:35:41 --> UTF-8 Support Enabled
INFO - 2023-05-20 06:35:41 --> Utf8 Class Initialized
INFO - 2023-05-20 06:35:41 --> URI Class Initialized
INFO - 2023-05-20 06:35:41 --> Router Class Initialized
INFO - 2023-05-20 06:35:41 --> Output Class Initialized
INFO - 2023-05-20 06:35:41 --> Security Class Initialized
DEBUG - 2023-05-20 06:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 06:35:41 --> Input Class Initialized
INFO - 2023-05-20 06:35:41 --> Language Class Initialized
INFO - 2023-05-20 06:35:41 --> Loader Class Initialized
INFO - 2023-05-20 06:35:41 --> Helper loaded: url_helper
INFO - 2023-05-20 06:35:41 --> Helper loaded: file_helper
INFO - 2023-05-20 06:35:41 --> Helper loaded: html_helper
INFO - 2023-05-20 06:35:41 --> Helper loaded: text_helper
INFO - 2023-05-20 06:35:41 --> Helper loaded: form_helper
INFO - 2023-05-20 06:35:41 --> Helper loaded: lang_helper
INFO - 2023-05-20 06:35:41 --> Helper loaded: security_helper
INFO - 2023-05-20 06:35:41 --> Helper loaded: cookie_helper
INFO - 2023-05-20 06:35:41 --> Database Driver Class Initialized
INFO - 2023-05-20 06:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 06:35:41 --> Parser Class Initialized
INFO - 2023-05-20 06:35:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 06:35:41 --> Pagination Class Initialized
INFO - 2023-05-20 06:35:41 --> Form Validation Class Initialized
INFO - 2023-05-20 06:35:41 --> Controller Class Initialized
INFO - 2023-05-20 06:35:41 --> Model Class Initialized
DEBUG - 2023-05-20 06:35:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 06:35:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:35:41 --> Model Class Initialized
DEBUG - 2023-05-20 06:35:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:35:41 --> Model Class Initialized
INFO - 2023-05-20 06:35:41 --> Final output sent to browser
DEBUG - 2023-05-20 06:35:41 --> Total execution time: 0.0492
ERROR - 2023-05-20 06:35:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 06:35:47 --> Config Class Initialized
INFO - 2023-05-20 06:35:47 --> Hooks Class Initialized
DEBUG - 2023-05-20 06:35:47 --> UTF-8 Support Enabled
INFO - 2023-05-20 06:35:47 --> Utf8 Class Initialized
INFO - 2023-05-20 06:35:47 --> URI Class Initialized
INFO - 2023-05-20 06:35:47 --> Router Class Initialized
INFO - 2023-05-20 06:35:47 --> Output Class Initialized
INFO - 2023-05-20 06:35:47 --> Security Class Initialized
DEBUG - 2023-05-20 06:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 06:35:47 --> Input Class Initialized
INFO - 2023-05-20 06:35:47 --> Language Class Initialized
INFO - 2023-05-20 06:35:47 --> Loader Class Initialized
INFO - 2023-05-20 06:35:47 --> Helper loaded: url_helper
INFO - 2023-05-20 06:35:47 --> Helper loaded: file_helper
INFO - 2023-05-20 06:35:47 --> Helper loaded: html_helper
INFO - 2023-05-20 06:35:47 --> Helper loaded: text_helper
INFO - 2023-05-20 06:35:47 --> Helper loaded: form_helper
INFO - 2023-05-20 06:35:47 --> Helper loaded: lang_helper
INFO - 2023-05-20 06:35:47 --> Helper loaded: security_helper
INFO - 2023-05-20 06:35:47 --> Helper loaded: cookie_helper
INFO - 2023-05-20 06:35:47 --> Database Driver Class Initialized
INFO - 2023-05-20 06:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 06:35:47 --> Parser Class Initialized
INFO - 2023-05-20 06:35:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 06:35:47 --> Pagination Class Initialized
INFO - 2023-05-20 06:35:47 --> Form Validation Class Initialized
INFO - 2023-05-20 06:35:47 --> Controller Class Initialized
INFO - 2023-05-20 06:35:47 --> Model Class Initialized
DEBUG - 2023-05-20 06:35:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 06:35:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:35:47 --> Model Class Initialized
DEBUG - 2023-05-20 06:35:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:35:47 --> Model Class Initialized
INFO - 2023-05-20 06:35:47 --> Final output sent to browser
DEBUG - 2023-05-20 06:35:47 --> Total execution time: 0.1472
ERROR - 2023-05-20 06:36:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 06:36:47 --> Config Class Initialized
INFO - 2023-05-20 06:36:47 --> Hooks Class Initialized
DEBUG - 2023-05-20 06:36:47 --> UTF-8 Support Enabled
INFO - 2023-05-20 06:36:47 --> Utf8 Class Initialized
INFO - 2023-05-20 06:36:47 --> URI Class Initialized
DEBUG - 2023-05-20 06:36:47 --> No URI present. Default controller set.
INFO - 2023-05-20 06:36:47 --> Router Class Initialized
INFO - 2023-05-20 06:36:47 --> Output Class Initialized
INFO - 2023-05-20 06:36:47 --> Security Class Initialized
DEBUG - 2023-05-20 06:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 06:36:47 --> Input Class Initialized
INFO - 2023-05-20 06:36:47 --> Language Class Initialized
INFO - 2023-05-20 06:36:47 --> Loader Class Initialized
INFO - 2023-05-20 06:36:47 --> Helper loaded: url_helper
INFO - 2023-05-20 06:36:47 --> Helper loaded: file_helper
INFO - 2023-05-20 06:36:47 --> Helper loaded: html_helper
INFO - 2023-05-20 06:36:47 --> Helper loaded: text_helper
INFO - 2023-05-20 06:36:47 --> Helper loaded: form_helper
INFO - 2023-05-20 06:36:47 --> Helper loaded: lang_helper
INFO - 2023-05-20 06:36:47 --> Helper loaded: security_helper
INFO - 2023-05-20 06:36:47 --> Helper loaded: cookie_helper
INFO - 2023-05-20 06:36:47 --> Database Driver Class Initialized
INFO - 2023-05-20 06:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 06:36:47 --> Parser Class Initialized
INFO - 2023-05-20 06:36:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 06:36:47 --> Pagination Class Initialized
INFO - 2023-05-20 06:36:47 --> Form Validation Class Initialized
INFO - 2023-05-20 06:36:47 --> Controller Class Initialized
INFO - 2023-05-20 06:36:47 --> Model Class Initialized
DEBUG - 2023-05-20 06:36:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:36:47 --> Model Class Initialized
DEBUG - 2023-05-20 06:36:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:36:47 --> Model Class Initialized
INFO - 2023-05-20 06:36:47 --> Model Class Initialized
INFO - 2023-05-20 06:36:47 --> Model Class Initialized
INFO - 2023-05-20 06:36:47 --> Model Class Initialized
DEBUG - 2023-05-20 06:36:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 06:36:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:36:47 --> Model Class Initialized
INFO - 2023-05-20 06:36:47 --> Model Class Initialized
INFO - 2023-05-20 06:36:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 06:36:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:36:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 06:36:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 06:36:47 --> Model Class Initialized
INFO - 2023-05-20 06:36:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 06:36:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 06:36:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 06:36:48 --> Final output sent to browser
DEBUG - 2023-05-20 06:36:48 --> Total execution time: 0.1930
ERROR - 2023-05-20 06:36:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 06:36:57 --> Config Class Initialized
INFO - 2023-05-20 06:36:57 --> Hooks Class Initialized
DEBUG - 2023-05-20 06:36:57 --> UTF-8 Support Enabled
INFO - 2023-05-20 06:36:57 --> Utf8 Class Initialized
INFO - 2023-05-20 06:36:57 --> URI Class Initialized
INFO - 2023-05-20 06:36:57 --> Router Class Initialized
INFO - 2023-05-20 06:36:57 --> Output Class Initialized
INFO - 2023-05-20 06:36:57 --> Security Class Initialized
DEBUG - 2023-05-20 06:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 06:36:57 --> Input Class Initialized
INFO - 2023-05-20 06:36:57 --> Language Class Initialized
INFO - 2023-05-20 06:36:57 --> Loader Class Initialized
INFO - 2023-05-20 06:36:57 --> Helper loaded: url_helper
INFO - 2023-05-20 06:36:57 --> Helper loaded: file_helper
INFO - 2023-05-20 06:36:57 --> Helper loaded: html_helper
INFO - 2023-05-20 06:36:57 --> Helper loaded: text_helper
INFO - 2023-05-20 06:36:57 --> Helper loaded: form_helper
INFO - 2023-05-20 06:36:57 --> Helper loaded: lang_helper
INFO - 2023-05-20 06:36:57 --> Helper loaded: security_helper
INFO - 2023-05-20 06:36:57 --> Helper loaded: cookie_helper
INFO - 2023-05-20 06:36:57 --> Database Driver Class Initialized
INFO - 2023-05-20 06:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 06:36:57 --> Parser Class Initialized
INFO - 2023-05-20 06:36:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 06:36:57 --> Pagination Class Initialized
INFO - 2023-05-20 06:36:57 --> Form Validation Class Initialized
INFO - 2023-05-20 06:36:57 --> Controller Class Initialized
INFO - 2023-05-20 06:36:57 --> Model Class Initialized
DEBUG - 2023-05-20 06:36:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 06:36:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:36:57 --> Model Class Initialized
DEBUG - 2023-05-20 06:36:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:36:57 --> Model Class Initialized
INFO - 2023-05-20 06:36:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-20 06:36:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:36:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 06:36:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 06:36:57 --> Model Class Initialized
INFO - 2023-05-20 06:36:57 --> Model Class Initialized
INFO - 2023-05-20 06:36:57 --> Model Class Initialized
INFO - 2023-05-20 06:36:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 06:36:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 06:36:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 06:36:57 --> Final output sent to browser
DEBUG - 2023-05-20 06:36:57 --> Total execution time: 0.1430
ERROR - 2023-05-20 06:36:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 06:36:58 --> Config Class Initialized
INFO - 2023-05-20 06:36:58 --> Hooks Class Initialized
DEBUG - 2023-05-20 06:36:58 --> UTF-8 Support Enabled
INFO - 2023-05-20 06:36:58 --> Utf8 Class Initialized
INFO - 2023-05-20 06:36:58 --> URI Class Initialized
INFO - 2023-05-20 06:36:58 --> Router Class Initialized
INFO - 2023-05-20 06:36:58 --> Output Class Initialized
INFO - 2023-05-20 06:36:58 --> Security Class Initialized
DEBUG - 2023-05-20 06:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 06:36:58 --> Input Class Initialized
INFO - 2023-05-20 06:36:58 --> Language Class Initialized
INFO - 2023-05-20 06:36:58 --> Loader Class Initialized
INFO - 2023-05-20 06:36:58 --> Helper loaded: url_helper
INFO - 2023-05-20 06:36:58 --> Helper loaded: file_helper
INFO - 2023-05-20 06:36:58 --> Helper loaded: html_helper
INFO - 2023-05-20 06:36:58 --> Helper loaded: text_helper
INFO - 2023-05-20 06:36:58 --> Helper loaded: form_helper
INFO - 2023-05-20 06:36:58 --> Helper loaded: lang_helper
INFO - 2023-05-20 06:36:58 --> Helper loaded: security_helper
INFO - 2023-05-20 06:36:58 --> Helper loaded: cookie_helper
INFO - 2023-05-20 06:36:58 --> Database Driver Class Initialized
INFO - 2023-05-20 06:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 06:36:58 --> Parser Class Initialized
INFO - 2023-05-20 06:36:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 06:36:58 --> Pagination Class Initialized
INFO - 2023-05-20 06:36:58 --> Form Validation Class Initialized
INFO - 2023-05-20 06:36:58 --> Controller Class Initialized
INFO - 2023-05-20 06:36:58 --> Model Class Initialized
DEBUG - 2023-05-20 06:36:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 06:36:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:36:58 --> Model Class Initialized
DEBUG - 2023-05-20 06:36:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:36:58 --> Model Class Initialized
INFO - 2023-05-20 06:36:58 --> Final output sent to browser
DEBUG - 2023-05-20 06:36:58 --> Total execution time: 0.0616
ERROR - 2023-05-20 06:37:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 06:37:01 --> Config Class Initialized
INFO - 2023-05-20 06:37:01 --> Hooks Class Initialized
DEBUG - 2023-05-20 06:37:01 --> UTF-8 Support Enabled
INFO - 2023-05-20 06:37:01 --> Utf8 Class Initialized
INFO - 2023-05-20 06:37:01 --> URI Class Initialized
INFO - 2023-05-20 06:37:01 --> Router Class Initialized
INFO - 2023-05-20 06:37:01 --> Output Class Initialized
INFO - 2023-05-20 06:37:01 --> Security Class Initialized
DEBUG - 2023-05-20 06:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 06:37:01 --> Input Class Initialized
INFO - 2023-05-20 06:37:01 --> Language Class Initialized
INFO - 2023-05-20 06:37:01 --> Loader Class Initialized
INFO - 2023-05-20 06:37:01 --> Helper loaded: url_helper
INFO - 2023-05-20 06:37:01 --> Helper loaded: file_helper
INFO - 2023-05-20 06:37:01 --> Helper loaded: html_helper
INFO - 2023-05-20 06:37:01 --> Helper loaded: text_helper
INFO - 2023-05-20 06:37:01 --> Helper loaded: form_helper
INFO - 2023-05-20 06:37:01 --> Helper loaded: lang_helper
INFO - 2023-05-20 06:37:01 --> Helper loaded: security_helper
INFO - 2023-05-20 06:37:01 --> Helper loaded: cookie_helper
INFO - 2023-05-20 06:37:01 --> Database Driver Class Initialized
INFO - 2023-05-20 06:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 06:37:01 --> Parser Class Initialized
INFO - 2023-05-20 06:37:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 06:37:01 --> Pagination Class Initialized
INFO - 2023-05-20 06:37:01 --> Form Validation Class Initialized
INFO - 2023-05-20 06:37:01 --> Controller Class Initialized
INFO - 2023-05-20 06:37:01 --> Model Class Initialized
DEBUG - 2023-05-20 06:37:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 06:37:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:37:01 --> Model Class Initialized
DEBUG - 2023-05-20 06:37:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 06:37:01 --> Model Class Initialized
INFO - 2023-05-20 06:37:02 --> Final output sent to browser
DEBUG - 2023-05-20 06:37:02 --> Total execution time: 0.1738
ERROR - 2023-05-20 07:28:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 07:28:15 --> Config Class Initialized
INFO - 2023-05-20 07:28:15 --> Hooks Class Initialized
DEBUG - 2023-05-20 07:28:15 --> UTF-8 Support Enabled
INFO - 2023-05-20 07:28:15 --> Utf8 Class Initialized
INFO - 2023-05-20 07:28:15 --> URI Class Initialized
DEBUG - 2023-05-20 07:28:15 --> No URI present. Default controller set.
INFO - 2023-05-20 07:28:15 --> Router Class Initialized
INFO - 2023-05-20 07:28:15 --> Output Class Initialized
INFO - 2023-05-20 07:28:15 --> Security Class Initialized
DEBUG - 2023-05-20 07:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 07:28:15 --> Input Class Initialized
INFO - 2023-05-20 07:28:15 --> Language Class Initialized
INFO - 2023-05-20 07:28:15 --> Loader Class Initialized
INFO - 2023-05-20 07:28:15 --> Helper loaded: url_helper
INFO - 2023-05-20 07:28:15 --> Helper loaded: file_helper
INFO - 2023-05-20 07:28:15 --> Helper loaded: html_helper
INFO - 2023-05-20 07:28:15 --> Helper loaded: text_helper
INFO - 2023-05-20 07:28:15 --> Helper loaded: form_helper
INFO - 2023-05-20 07:28:15 --> Helper loaded: lang_helper
INFO - 2023-05-20 07:28:15 --> Helper loaded: security_helper
INFO - 2023-05-20 07:28:15 --> Helper loaded: cookie_helper
INFO - 2023-05-20 07:28:15 --> Database Driver Class Initialized
INFO - 2023-05-20 07:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 07:28:15 --> Parser Class Initialized
INFO - 2023-05-20 07:28:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 07:28:15 --> Pagination Class Initialized
INFO - 2023-05-20 07:28:15 --> Form Validation Class Initialized
INFO - 2023-05-20 07:28:15 --> Controller Class Initialized
INFO - 2023-05-20 07:28:15 --> Model Class Initialized
DEBUG - 2023-05-20 07:28:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-20 08:41:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 08:41:02 --> Config Class Initialized
INFO - 2023-05-20 08:41:02 --> Hooks Class Initialized
DEBUG - 2023-05-20 08:41:02 --> UTF-8 Support Enabled
INFO - 2023-05-20 08:41:02 --> Utf8 Class Initialized
INFO - 2023-05-20 08:41:02 --> URI Class Initialized
DEBUG - 2023-05-20 08:41:02 --> No URI present. Default controller set.
INFO - 2023-05-20 08:41:02 --> Router Class Initialized
INFO - 2023-05-20 08:41:02 --> Output Class Initialized
INFO - 2023-05-20 08:41:02 --> Security Class Initialized
DEBUG - 2023-05-20 08:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 08:41:02 --> Input Class Initialized
INFO - 2023-05-20 08:41:02 --> Language Class Initialized
INFO - 2023-05-20 08:41:02 --> Loader Class Initialized
INFO - 2023-05-20 08:41:02 --> Helper loaded: url_helper
INFO - 2023-05-20 08:41:02 --> Helper loaded: file_helper
INFO - 2023-05-20 08:41:02 --> Helper loaded: html_helper
INFO - 2023-05-20 08:41:02 --> Helper loaded: text_helper
INFO - 2023-05-20 08:41:02 --> Helper loaded: form_helper
INFO - 2023-05-20 08:41:02 --> Helper loaded: lang_helper
INFO - 2023-05-20 08:41:02 --> Helper loaded: security_helper
INFO - 2023-05-20 08:41:02 --> Helper loaded: cookie_helper
INFO - 2023-05-20 08:41:02 --> Database Driver Class Initialized
INFO - 2023-05-20 08:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 08:41:02 --> Parser Class Initialized
INFO - 2023-05-20 08:41:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 08:41:02 --> Pagination Class Initialized
INFO - 2023-05-20 08:41:02 --> Form Validation Class Initialized
INFO - 2023-05-20 08:41:02 --> Controller Class Initialized
INFO - 2023-05-20 08:41:02 --> Model Class Initialized
DEBUG - 2023-05-20 08:41:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-20 08:41:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 08:41:03 --> Config Class Initialized
INFO - 2023-05-20 08:41:03 --> Hooks Class Initialized
DEBUG - 2023-05-20 08:41:03 --> UTF-8 Support Enabled
INFO - 2023-05-20 08:41:03 --> Utf8 Class Initialized
INFO - 2023-05-20 08:41:03 --> URI Class Initialized
INFO - 2023-05-20 08:41:03 --> Router Class Initialized
INFO - 2023-05-20 08:41:03 --> Output Class Initialized
INFO - 2023-05-20 08:41:03 --> Security Class Initialized
DEBUG - 2023-05-20 08:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 08:41:03 --> Input Class Initialized
INFO - 2023-05-20 08:41:03 --> Language Class Initialized
INFO - 2023-05-20 08:41:03 --> Loader Class Initialized
INFO - 2023-05-20 08:41:03 --> Helper loaded: url_helper
INFO - 2023-05-20 08:41:03 --> Helper loaded: file_helper
INFO - 2023-05-20 08:41:03 --> Helper loaded: html_helper
INFO - 2023-05-20 08:41:03 --> Helper loaded: text_helper
INFO - 2023-05-20 08:41:03 --> Helper loaded: form_helper
INFO - 2023-05-20 08:41:03 --> Helper loaded: lang_helper
INFO - 2023-05-20 08:41:03 --> Helper loaded: security_helper
INFO - 2023-05-20 08:41:03 --> Helper loaded: cookie_helper
INFO - 2023-05-20 08:41:03 --> Database Driver Class Initialized
INFO - 2023-05-20 08:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 08:41:03 --> Parser Class Initialized
INFO - 2023-05-20 08:41:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 08:41:03 --> Pagination Class Initialized
INFO - 2023-05-20 08:41:03 --> Form Validation Class Initialized
INFO - 2023-05-20 08:41:03 --> Controller Class Initialized
INFO - 2023-05-20 08:41:03 --> Model Class Initialized
DEBUG - 2023-05-20 08:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 08:41:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-20 08:41:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 08:41:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 08:41:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 08:41:03 --> Model Class Initialized
INFO - 2023-05-20 08:41:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 08:41:03 --> Final output sent to browser
DEBUG - 2023-05-20 08:41:03 --> Total execution time: 0.0432
ERROR - 2023-05-20 13:05:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 13:05:44 --> Config Class Initialized
INFO - 2023-05-20 13:05:44 --> Hooks Class Initialized
DEBUG - 2023-05-20 13:05:44 --> UTF-8 Support Enabled
INFO - 2023-05-20 13:05:44 --> Utf8 Class Initialized
INFO - 2023-05-20 13:05:44 --> URI Class Initialized
DEBUG - 2023-05-20 13:05:44 --> No URI present. Default controller set.
INFO - 2023-05-20 13:05:44 --> Router Class Initialized
INFO - 2023-05-20 13:05:44 --> Output Class Initialized
INFO - 2023-05-20 13:05:44 --> Security Class Initialized
DEBUG - 2023-05-20 13:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 13:05:44 --> Input Class Initialized
INFO - 2023-05-20 13:05:44 --> Language Class Initialized
INFO - 2023-05-20 13:05:44 --> Loader Class Initialized
INFO - 2023-05-20 13:05:44 --> Helper loaded: url_helper
INFO - 2023-05-20 13:05:44 --> Helper loaded: file_helper
INFO - 2023-05-20 13:05:44 --> Helper loaded: html_helper
INFO - 2023-05-20 13:05:44 --> Helper loaded: text_helper
INFO - 2023-05-20 13:05:44 --> Helper loaded: form_helper
INFO - 2023-05-20 13:05:44 --> Helper loaded: lang_helper
INFO - 2023-05-20 13:05:44 --> Helper loaded: security_helper
INFO - 2023-05-20 13:05:44 --> Helper loaded: cookie_helper
INFO - 2023-05-20 13:05:44 --> Database Driver Class Initialized
INFO - 2023-05-20 13:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 13:05:44 --> Parser Class Initialized
INFO - 2023-05-20 13:05:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 13:05:44 --> Pagination Class Initialized
INFO - 2023-05-20 13:05:44 --> Form Validation Class Initialized
INFO - 2023-05-20 13:05:44 --> Controller Class Initialized
INFO - 2023-05-20 13:05:44 --> Model Class Initialized
DEBUG - 2023-05-20 13:05:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-20 13:05:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 13:05:45 --> Config Class Initialized
INFO - 2023-05-20 13:05:45 --> Hooks Class Initialized
DEBUG - 2023-05-20 13:05:45 --> UTF-8 Support Enabled
INFO - 2023-05-20 13:05:45 --> Utf8 Class Initialized
INFO - 2023-05-20 13:05:45 --> URI Class Initialized
INFO - 2023-05-20 13:05:45 --> Router Class Initialized
INFO - 2023-05-20 13:05:45 --> Output Class Initialized
INFO - 2023-05-20 13:05:45 --> Security Class Initialized
DEBUG - 2023-05-20 13:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 13:05:45 --> Input Class Initialized
INFO - 2023-05-20 13:05:45 --> Language Class Initialized
INFO - 2023-05-20 13:05:45 --> Loader Class Initialized
INFO - 2023-05-20 13:05:45 --> Helper loaded: url_helper
INFO - 2023-05-20 13:05:45 --> Helper loaded: file_helper
INFO - 2023-05-20 13:05:45 --> Helper loaded: html_helper
INFO - 2023-05-20 13:05:45 --> Helper loaded: text_helper
INFO - 2023-05-20 13:05:45 --> Helper loaded: form_helper
INFO - 2023-05-20 13:05:45 --> Helper loaded: lang_helper
INFO - 2023-05-20 13:05:45 --> Helper loaded: security_helper
INFO - 2023-05-20 13:05:45 --> Helper loaded: cookie_helper
INFO - 2023-05-20 13:05:45 --> Database Driver Class Initialized
INFO - 2023-05-20 13:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 13:05:45 --> Parser Class Initialized
INFO - 2023-05-20 13:05:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 13:05:45 --> Pagination Class Initialized
INFO - 2023-05-20 13:05:45 --> Form Validation Class Initialized
INFO - 2023-05-20 13:05:45 --> Controller Class Initialized
INFO - 2023-05-20 13:05:45 --> Model Class Initialized
DEBUG - 2023-05-20 13:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:05:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-20 13:05:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:05:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 13:05:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 13:05:45 --> Model Class Initialized
INFO - 2023-05-20 13:05:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 13:05:45 --> Final output sent to browser
DEBUG - 2023-05-20 13:05:45 --> Total execution time: 0.0349
ERROR - 2023-05-20 13:06:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 13:06:22 --> Config Class Initialized
INFO - 2023-05-20 13:06:22 --> Hooks Class Initialized
DEBUG - 2023-05-20 13:06:22 --> UTF-8 Support Enabled
INFO - 2023-05-20 13:06:22 --> Utf8 Class Initialized
INFO - 2023-05-20 13:06:22 --> URI Class Initialized
INFO - 2023-05-20 13:06:22 --> Router Class Initialized
INFO - 2023-05-20 13:06:22 --> Output Class Initialized
INFO - 2023-05-20 13:06:22 --> Security Class Initialized
DEBUG - 2023-05-20 13:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 13:06:22 --> Input Class Initialized
INFO - 2023-05-20 13:06:22 --> Language Class Initialized
INFO - 2023-05-20 13:06:22 --> Loader Class Initialized
INFO - 2023-05-20 13:06:22 --> Helper loaded: url_helper
INFO - 2023-05-20 13:06:22 --> Helper loaded: file_helper
INFO - 2023-05-20 13:06:22 --> Helper loaded: html_helper
INFO - 2023-05-20 13:06:22 --> Helper loaded: text_helper
INFO - 2023-05-20 13:06:22 --> Helper loaded: form_helper
INFO - 2023-05-20 13:06:22 --> Helper loaded: lang_helper
INFO - 2023-05-20 13:06:22 --> Helper loaded: security_helper
INFO - 2023-05-20 13:06:22 --> Helper loaded: cookie_helper
INFO - 2023-05-20 13:06:22 --> Database Driver Class Initialized
INFO - 2023-05-20 13:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 13:06:22 --> Parser Class Initialized
INFO - 2023-05-20 13:06:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 13:06:22 --> Pagination Class Initialized
INFO - 2023-05-20 13:06:22 --> Form Validation Class Initialized
INFO - 2023-05-20 13:06:22 --> Controller Class Initialized
INFO - 2023-05-20 13:06:22 --> Model Class Initialized
DEBUG - 2023-05-20 13:06:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:06:22 --> Model Class Initialized
INFO - 2023-05-20 13:06:22 --> Final output sent to browser
DEBUG - 2023-05-20 13:06:22 --> Total execution time: 0.0215
ERROR - 2023-05-20 13:06:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 13:06:23 --> Config Class Initialized
INFO - 2023-05-20 13:06:23 --> Hooks Class Initialized
DEBUG - 2023-05-20 13:06:23 --> UTF-8 Support Enabled
INFO - 2023-05-20 13:06:23 --> Utf8 Class Initialized
INFO - 2023-05-20 13:06:23 --> URI Class Initialized
DEBUG - 2023-05-20 13:06:23 --> No URI present. Default controller set.
INFO - 2023-05-20 13:06:23 --> Router Class Initialized
INFO - 2023-05-20 13:06:23 --> Output Class Initialized
INFO - 2023-05-20 13:06:23 --> Security Class Initialized
DEBUG - 2023-05-20 13:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 13:06:23 --> Input Class Initialized
INFO - 2023-05-20 13:06:23 --> Language Class Initialized
INFO - 2023-05-20 13:06:23 --> Loader Class Initialized
INFO - 2023-05-20 13:06:23 --> Helper loaded: url_helper
INFO - 2023-05-20 13:06:23 --> Helper loaded: file_helper
INFO - 2023-05-20 13:06:23 --> Helper loaded: html_helper
INFO - 2023-05-20 13:06:23 --> Helper loaded: text_helper
INFO - 2023-05-20 13:06:23 --> Helper loaded: form_helper
INFO - 2023-05-20 13:06:23 --> Helper loaded: lang_helper
INFO - 2023-05-20 13:06:23 --> Helper loaded: security_helper
INFO - 2023-05-20 13:06:23 --> Helper loaded: cookie_helper
INFO - 2023-05-20 13:06:23 --> Database Driver Class Initialized
INFO - 2023-05-20 13:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 13:06:23 --> Parser Class Initialized
INFO - 2023-05-20 13:06:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 13:06:23 --> Pagination Class Initialized
INFO - 2023-05-20 13:06:23 --> Form Validation Class Initialized
INFO - 2023-05-20 13:06:23 --> Controller Class Initialized
INFO - 2023-05-20 13:06:23 --> Model Class Initialized
DEBUG - 2023-05-20 13:06:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:06:23 --> Model Class Initialized
DEBUG - 2023-05-20 13:06:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:06:23 --> Model Class Initialized
INFO - 2023-05-20 13:06:23 --> Model Class Initialized
INFO - 2023-05-20 13:06:23 --> Model Class Initialized
INFO - 2023-05-20 13:06:23 --> Model Class Initialized
DEBUG - 2023-05-20 13:06:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 13:06:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:06:23 --> Model Class Initialized
INFO - 2023-05-20 13:06:23 --> Model Class Initialized
INFO - 2023-05-20 13:06:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 13:06:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:06:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 13:06:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 13:06:23 --> Model Class Initialized
INFO - 2023-05-20 13:06:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 13:06:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 13:06:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 13:06:23 --> Final output sent to browser
DEBUG - 2023-05-20 13:06:23 --> Total execution time: 0.0760
ERROR - 2023-05-20 13:06:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 13:06:34 --> Config Class Initialized
INFO - 2023-05-20 13:06:34 --> Hooks Class Initialized
DEBUG - 2023-05-20 13:06:34 --> UTF-8 Support Enabled
INFO - 2023-05-20 13:06:34 --> Utf8 Class Initialized
INFO - 2023-05-20 13:06:34 --> URI Class Initialized
INFO - 2023-05-20 13:06:34 --> Router Class Initialized
INFO - 2023-05-20 13:06:34 --> Output Class Initialized
INFO - 2023-05-20 13:06:34 --> Security Class Initialized
DEBUG - 2023-05-20 13:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 13:06:34 --> Input Class Initialized
INFO - 2023-05-20 13:06:34 --> Language Class Initialized
INFO - 2023-05-20 13:06:34 --> Loader Class Initialized
INFO - 2023-05-20 13:06:34 --> Helper loaded: url_helper
INFO - 2023-05-20 13:06:34 --> Helper loaded: file_helper
INFO - 2023-05-20 13:06:34 --> Helper loaded: html_helper
INFO - 2023-05-20 13:06:34 --> Helper loaded: text_helper
INFO - 2023-05-20 13:06:34 --> Helper loaded: form_helper
INFO - 2023-05-20 13:06:34 --> Helper loaded: lang_helper
INFO - 2023-05-20 13:06:34 --> Helper loaded: security_helper
INFO - 2023-05-20 13:06:34 --> Helper loaded: cookie_helper
INFO - 2023-05-20 13:06:34 --> Database Driver Class Initialized
INFO - 2023-05-20 13:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 13:06:34 --> Parser Class Initialized
INFO - 2023-05-20 13:06:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 13:06:34 --> Pagination Class Initialized
INFO - 2023-05-20 13:06:34 --> Form Validation Class Initialized
INFO - 2023-05-20 13:06:34 --> Controller Class Initialized
INFO - 2023-05-20 13:06:34 --> Model Class Initialized
DEBUG - 2023-05-20 13:06:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 13:06:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:06:34 --> Model Class Initialized
DEBUG - 2023-05-20 13:06:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:06:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-05-20 13:06:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:06:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 13:06:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 13:06:34 --> Model Class Initialized
INFO - 2023-05-20 13:06:34 --> Model Class Initialized
INFO - 2023-05-20 13:06:34 --> Model Class Initialized
INFO - 2023-05-20 13:06:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 13:06:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 13:06:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 13:06:34 --> Final output sent to browser
DEBUG - 2023-05-20 13:06:34 --> Total execution time: 0.0736
ERROR - 2023-05-20 13:06:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 13:06:39 --> Config Class Initialized
INFO - 2023-05-20 13:06:39 --> Hooks Class Initialized
DEBUG - 2023-05-20 13:06:39 --> UTF-8 Support Enabled
INFO - 2023-05-20 13:06:39 --> Utf8 Class Initialized
INFO - 2023-05-20 13:06:39 --> URI Class Initialized
INFO - 2023-05-20 13:06:39 --> Router Class Initialized
INFO - 2023-05-20 13:06:39 --> Output Class Initialized
INFO - 2023-05-20 13:06:39 --> Security Class Initialized
DEBUG - 2023-05-20 13:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 13:06:39 --> Input Class Initialized
INFO - 2023-05-20 13:06:39 --> Language Class Initialized
INFO - 2023-05-20 13:06:39 --> Loader Class Initialized
INFO - 2023-05-20 13:06:39 --> Helper loaded: url_helper
INFO - 2023-05-20 13:06:39 --> Helper loaded: file_helper
INFO - 2023-05-20 13:06:39 --> Helper loaded: html_helper
INFO - 2023-05-20 13:06:39 --> Helper loaded: text_helper
INFO - 2023-05-20 13:06:39 --> Helper loaded: form_helper
INFO - 2023-05-20 13:06:39 --> Helper loaded: lang_helper
INFO - 2023-05-20 13:06:39 --> Helper loaded: security_helper
INFO - 2023-05-20 13:06:39 --> Helper loaded: cookie_helper
INFO - 2023-05-20 13:06:39 --> Database Driver Class Initialized
INFO - 2023-05-20 13:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 13:06:39 --> Parser Class Initialized
INFO - 2023-05-20 13:06:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 13:06:39 --> Pagination Class Initialized
INFO - 2023-05-20 13:06:39 --> Form Validation Class Initialized
INFO - 2023-05-20 13:06:39 --> Controller Class Initialized
INFO - 2023-05-20 13:06:39 --> Model Class Initialized
DEBUG - 2023-05-20 13:06:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 13:06:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:06:39 --> Model Class Initialized
DEBUG - 2023-05-20 13:06:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:06:39 --> Model Class Initialized
INFO - 2023-05-20 13:06:39 --> Final output sent to browser
DEBUG - 2023-05-20 13:06:39 --> Total execution time: 0.0218
ERROR - 2023-05-20 13:06:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 13:06:39 --> Config Class Initialized
INFO - 2023-05-20 13:06:39 --> Hooks Class Initialized
DEBUG - 2023-05-20 13:06:39 --> UTF-8 Support Enabled
INFO - 2023-05-20 13:06:39 --> Utf8 Class Initialized
INFO - 2023-05-20 13:06:39 --> URI Class Initialized
INFO - 2023-05-20 13:06:39 --> Router Class Initialized
INFO - 2023-05-20 13:06:39 --> Output Class Initialized
INFO - 2023-05-20 13:06:39 --> Security Class Initialized
DEBUG - 2023-05-20 13:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 13:06:39 --> Input Class Initialized
INFO - 2023-05-20 13:06:39 --> Language Class Initialized
INFO - 2023-05-20 13:06:39 --> Loader Class Initialized
INFO - 2023-05-20 13:06:39 --> Helper loaded: url_helper
INFO - 2023-05-20 13:06:39 --> Helper loaded: file_helper
INFO - 2023-05-20 13:06:39 --> Helper loaded: html_helper
INFO - 2023-05-20 13:06:39 --> Helper loaded: text_helper
INFO - 2023-05-20 13:06:39 --> Helper loaded: form_helper
INFO - 2023-05-20 13:06:39 --> Helper loaded: lang_helper
INFO - 2023-05-20 13:06:39 --> Helper loaded: security_helper
INFO - 2023-05-20 13:06:39 --> Helper loaded: cookie_helper
INFO - 2023-05-20 13:06:39 --> Database Driver Class Initialized
INFO - 2023-05-20 13:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 13:06:39 --> Parser Class Initialized
INFO - 2023-05-20 13:06:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 13:06:39 --> Pagination Class Initialized
INFO - 2023-05-20 13:06:39 --> Form Validation Class Initialized
INFO - 2023-05-20 13:06:39 --> Controller Class Initialized
INFO - 2023-05-20 13:06:39 --> Model Class Initialized
DEBUG - 2023-05-20 13:06:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 13:06:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:06:39 --> Model Class Initialized
DEBUG - 2023-05-20 13:06:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:06:39 --> Model Class Initialized
INFO - 2023-05-20 13:06:39 --> Final output sent to browser
DEBUG - 2023-05-20 13:06:39 --> Total execution time: 0.0225
ERROR - 2023-05-20 13:06:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 13:06:40 --> Config Class Initialized
INFO - 2023-05-20 13:06:40 --> Hooks Class Initialized
DEBUG - 2023-05-20 13:06:40 --> UTF-8 Support Enabled
INFO - 2023-05-20 13:06:40 --> Utf8 Class Initialized
INFO - 2023-05-20 13:06:40 --> URI Class Initialized
INFO - 2023-05-20 13:06:40 --> Router Class Initialized
INFO - 2023-05-20 13:06:40 --> Output Class Initialized
INFO - 2023-05-20 13:06:40 --> Security Class Initialized
DEBUG - 2023-05-20 13:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 13:06:40 --> Input Class Initialized
INFO - 2023-05-20 13:06:40 --> Language Class Initialized
INFO - 2023-05-20 13:06:40 --> Loader Class Initialized
INFO - 2023-05-20 13:06:40 --> Helper loaded: url_helper
INFO - 2023-05-20 13:06:40 --> Helper loaded: file_helper
INFO - 2023-05-20 13:06:40 --> Helper loaded: html_helper
INFO - 2023-05-20 13:06:40 --> Helper loaded: text_helper
INFO - 2023-05-20 13:06:40 --> Helper loaded: form_helper
INFO - 2023-05-20 13:06:40 --> Helper loaded: lang_helper
INFO - 2023-05-20 13:06:40 --> Helper loaded: security_helper
INFO - 2023-05-20 13:06:40 --> Helper loaded: cookie_helper
INFO - 2023-05-20 13:06:40 --> Database Driver Class Initialized
INFO - 2023-05-20 13:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 13:06:40 --> Parser Class Initialized
INFO - 2023-05-20 13:06:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 13:06:40 --> Pagination Class Initialized
INFO - 2023-05-20 13:06:40 --> Form Validation Class Initialized
INFO - 2023-05-20 13:06:40 --> Controller Class Initialized
INFO - 2023-05-20 13:06:40 --> Model Class Initialized
DEBUG - 2023-05-20 13:06:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 13:06:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:06:40 --> Model Class Initialized
DEBUG - 2023-05-20 13:06:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:06:40 --> Model Class Initialized
INFO - 2023-05-20 13:06:40 --> Final output sent to browser
DEBUG - 2023-05-20 13:06:40 --> Total execution time: 0.0166
ERROR - 2023-05-20 13:06:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 13:06:44 --> Config Class Initialized
INFO - 2023-05-20 13:06:44 --> Hooks Class Initialized
DEBUG - 2023-05-20 13:06:44 --> UTF-8 Support Enabled
INFO - 2023-05-20 13:06:44 --> Utf8 Class Initialized
INFO - 2023-05-20 13:06:44 --> URI Class Initialized
INFO - 2023-05-20 13:06:44 --> Router Class Initialized
INFO - 2023-05-20 13:06:44 --> Output Class Initialized
INFO - 2023-05-20 13:06:44 --> Security Class Initialized
DEBUG - 2023-05-20 13:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 13:06:44 --> Input Class Initialized
INFO - 2023-05-20 13:06:44 --> Language Class Initialized
INFO - 2023-05-20 13:06:44 --> Loader Class Initialized
INFO - 2023-05-20 13:06:44 --> Helper loaded: url_helper
INFO - 2023-05-20 13:06:44 --> Helper loaded: file_helper
INFO - 2023-05-20 13:06:44 --> Helper loaded: html_helper
INFO - 2023-05-20 13:06:44 --> Helper loaded: text_helper
INFO - 2023-05-20 13:06:44 --> Helper loaded: form_helper
INFO - 2023-05-20 13:06:44 --> Helper loaded: lang_helper
INFO - 2023-05-20 13:06:44 --> Helper loaded: security_helper
INFO - 2023-05-20 13:06:44 --> Helper loaded: cookie_helper
INFO - 2023-05-20 13:06:44 --> Database Driver Class Initialized
INFO - 2023-05-20 13:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 13:06:44 --> Parser Class Initialized
INFO - 2023-05-20 13:06:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 13:06:44 --> Pagination Class Initialized
INFO - 2023-05-20 13:06:44 --> Form Validation Class Initialized
INFO - 2023-05-20 13:06:44 --> Controller Class Initialized
INFO - 2023-05-20 13:06:44 --> Model Class Initialized
DEBUG - 2023-05-20 13:06:44 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 13:06:44 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:06:44 --> Model Class Initialized
INFO - 2023-05-20 13:06:44 --> Model Class Initialized
INFO - 2023-05-20 13:06:44 --> Final output sent to browser
DEBUG - 2023-05-20 13:06:44 --> Total execution time: 0.0198
ERROR - 2023-05-20 13:07:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 13:07:06 --> Config Class Initialized
INFO - 2023-05-20 13:07:06 --> Hooks Class Initialized
DEBUG - 2023-05-20 13:07:06 --> UTF-8 Support Enabled
INFO - 2023-05-20 13:07:06 --> Utf8 Class Initialized
INFO - 2023-05-20 13:07:06 --> URI Class Initialized
DEBUG - 2023-05-20 13:07:06 --> No URI present. Default controller set.
INFO - 2023-05-20 13:07:06 --> Router Class Initialized
INFO - 2023-05-20 13:07:06 --> Output Class Initialized
INFO - 2023-05-20 13:07:06 --> Security Class Initialized
DEBUG - 2023-05-20 13:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 13:07:06 --> Input Class Initialized
INFO - 2023-05-20 13:07:06 --> Language Class Initialized
INFO - 2023-05-20 13:07:06 --> Loader Class Initialized
INFO - 2023-05-20 13:07:06 --> Helper loaded: url_helper
INFO - 2023-05-20 13:07:06 --> Helper loaded: file_helper
INFO - 2023-05-20 13:07:06 --> Helper loaded: html_helper
INFO - 2023-05-20 13:07:06 --> Helper loaded: text_helper
INFO - 2023-05-20 13:07:06 --> Helper loaded: form_helper
INFO - 2023-05-20 13:07:06 --> Helper loaded: lang_helper
INFO - 2023-05-20 13:07:06 --> Helper loaded: security_helper
INFO - 2023-05-20 13:07:06 --> Helper loaded: cookie_helper
INFO - 2023-05-20 13:07:06 --> Database Driver Class Initialized
INFO - 2023-05-20 13:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 13:07:06 --> Parser Class Initialized
INFO - 2023-05-20 13:07:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 13:07:06 --> Pagination Class Initialized
INFO - 2023-05-20 13:07:06 --> Form Validation Class Initialized
INFO - 2023-05-20 13:07:06 --> Controller Class Initialized
INFO - 2023-05-20 13:07:06 --> Model Class Initialized
DEBUG - 2023-05-20 13:07:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:07:06 --> Model Class Initialized
DEBUG - 2023-05-20 13:07:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:07:06 --> Model Class Initialized
INFO - 2023-05-20 13:07:06 --> Model Class Initialized
INFO - 2023-05-20 13:07:06 --> Model Class Initialized
INFO - 2023-05-20 13:07:06 --> Model Class Initialized
DEBUG - 2023-05-20 13:07:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 13:07:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:07:06 --> Model Class Initialized
INFO - 2023-05-20 13:07:06 --> Model Class Initialized
INFO - 2023-05-20 13:07:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 13:07:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:07:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 13:07:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 13:07:06 --> Model Class Initialized
INFO - 2023-05-20 13:07:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 13:07:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 13:07:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 13:07:06 --> Final output sent to browser
DEBUG - 2023-05-20 13:07:06 --> Total execution time: 0.0714
ERROR - 2023-05-20 13:07:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 13:07:32 --> Config Class Initialized
INFO - 2023-05-20 13:07:32 --> Hooks Class Initialized
DEBUG - 2023-05-20 13:07:32 --> UTF-8 Support Enabled
INFO - 2023-05-20 13:07:32 --> Utf8 Class Initialized
INFO - 2023-05-20 13:07:32 --> URI Class Initialized
INFO - 2023-05-20 13:07:32 --> Router Class Initialized
INFO - 2023-05-20 13:07:32 --> Output Class Initialized
INFO - 2023-05-20 13:07:32 --> Security Class Initialized
DEBUG - 2023-05-20 13:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 13:07:32 --> Input Class Initialized
INFO - 2023-05-20 13:07:32 --> Language Class Initialized
INFO - 2023-05-20 13:07:32 --> Loader Class Initialized
INFO - 2023-05-20 13:07:32 --> Helper loaded: url_helper
INFO - 2023-05-20 13:07:32 --> Helper loaded: file_helper
INFO - 2023-05-20 13:07:32 --> Helper loaded: html_helper
INFO - 2023-05-20 13:07:32 --> Helper loaded: text_helper
INFO - 2023-05-20 13:07:32 --> Helper loaded: form_helper
INFO - 2023-05-20 13:07:32 --> Helper loaded: lang_helper
INFO - 2023-05-20 13:07:32 --> Helper loaded: security_helper
INFO - 2023-05-20 13:07:32 --> Helper loaded: cookie_helper
INFO - 2023-05-20 13:07:32 --> Database Driver Class Initialized
INFO - 2023-05-20 13:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 13:07:32 --> Parser Class Initialized
INFO - 2023-05-20 13:07:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 13:07:32 --> Pagination Class Initialized
INFO - 2023-05-20 13:07:32 --> Form Validation Class Initialized
INFO - 2023-05-20 13:07:32 --> Controller Class Initialized
INFO - 2023-05-20 13:07:32 --> Model Class Initialized
DEBUG - 2023-05-20 13:07:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 13:07:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:07:32 --> Model Class Initialized
DEBUG - 2023-05-20 13:07:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:07:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/add_demandrequest_form.php
DEBUG - 2023-05-20 13:07:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:07:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 13:07:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 13:07:32 --> Model Class Initialized
INFO - 2023-05-20 13:07:32 --> Model Class Initialized
INFO - 2023-05-20 13:07:32 --> Model Class Initialized
INFO - 2023-05-20 13:07:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 13:07:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 13:07:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 13:07:32 --> Final output sent to browser
DEBUG - 2023-05-20 13:07:32 --> Total execution time: 0.0702
ERROR - 2023-05-20 13:07:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 13:07:33 --> Config Class Initialized
INFO - 2023-05-20 13:07:33 --> Hooks Class Initialized
DEBUG - 2023-05-20 13:07:33 --> UTF-8 Support Enabled
INFO - 2023-05-20 13:07:33 --> Utf8 Class Initialized
INFO - 2023-05-20 13:07:33 --> URI Class Initialized
DEBUG - 2023-05-20 13:07:33 --> No URI present. Default controller set.
INFO - 2023-05-20 13:07:33 --> Router Class Initialized
INFO - 2023-05-20 13:07:33 --> Output Class Initialized
INFO - 2023-05-20 13:07:33 --> Security Class Initialized
DEBUG - 2023-05-20 13:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 13:07:33 --> Input Class Initialized
INFO - 2023-05-20 13:07:33 --> Language Class Initialized
INFO - 2023-05-20 13:07:33 --> Loader Class Initialized
INFO - 2023-05-20 13:07:33 --> Helper loaded: url_helper
INFO - 2023-05-20 13:07:33 --> Helper loaded: file_helper
INFO - 2023-05-20 13:07:33 --> Helper loaded: html_helper
INFO - 2023-05-20 13:07:33 --> Helper loaded: text_helper
INFO - 2023-05-20 13:07:33 --> Helper loaded: form_helper
INFO - 2023-05-20 13:07:33 --> Helper loaded: lang_helper
INFO - 2023-05-20 13:07:33 --> Helper loaded: security_helper
INFO - 2023-05-20 13:07:33 --> Helper loaded: cookie_helper
INFO - 2023-05-20 13:07:33 --> Database Driver Class Initialized
INFO - 2023-05-20 13:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 13:07:33 --> Parser Class Initialized
INFO - 2023-05-20 13:07:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 13:07:33 --> Pagination Class Initialized
INFO - 2023-05-20 13:07:33 --> Form Validation Class Initialized
INFO - 2023-05-20 13:07:33 --> Controller Class Initialized
INFO - 2023-05-20 13:07:33 --> Model Class Initialized
DEBUG - 2023-05-20 13:07:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:07:33 --> Model Class Initialized
DEBUG - 2023-05-20 13:07:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:07:33 --> Model Class Initialized
INFO - 2023-05-20 13:07:33 --> Model Class Initialized
INFO - 2023-05-20 13:07:33 --> Model Class Initialized
INFO - 2023-05-20 13:07:33 --> Model Class Initialized
DEBUG - 2023-05-20 13:07:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 13:07:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:07:33 --> Model Class Initialized
INFO - 2023-05-20 13:07:33 --> Model Class Initialized
INFO - 2023-05-20 13:07:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 13:07:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:07:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 13:07:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 13:07:33 --> Model Class Initialized
INFO - 2023-05-20 13:07:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 13:07:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 13:07:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 13:07:33 --> Final output sent to browser
DEBUG - 2023-05-20 13:07:33 --> Total execution time: 0.0670
ERROR - 2023-05-20 13:07:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 13:07:34 --> Config Class Initialized
INFO - 2023-05-20 13:07:34 --> Hooks Class Initialized
DEBUG - 2023-05-20 13:07:34 --> UTF-8 Support Enabled
INFO - 2023-05-20 13:07:34 --> Utf8 Class Initialized
INFO - 2023-05-20 13:07:34 --> URI Class Initialized
INFO - 2023-05-20 13:07:34 --> Router Class Initialized
INFO - 2023-05-20 13:07:34 --> Output Class Initialized
INFO - 2023-05-20 13:07:34 --> Security Class Initialized
DEBUG - 2023-05-20 13:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 13:07:34 --> Input Class Initialized
INFO - 2023-05-20 13:07:34 --> Language Class Initialized
INFO - 2023-05-20 13:07:34 --> Loader Class Initialized
INFO - 2023-05-20 13:07:34 --> Helper loaded: url_helper
INFO - 2023-05-20 13:07:34 --> Helper loaded: file_helper
INFO - 2023-05-20 13:07:34 --> Helper loaded: html_helper
INFO - 2023-05-20 13:07:34 --> Helper loaded: text_helper
INFO - 2023-05-20 13:07:34 --> Helper loaded: form_helper
INFO - 2023-05-20 13:07:34 --> Helper loaded: lang_helper
INFO - 2023-05-20 13:07:34 --> Helper loaded: security_helper
INFO - 2023-05-20 13:07:34 --> Helper loaded: cookie_helper
INFO - 2023-05-20 13:07:34 --> Database Driver Class Initialized
INFO - 2023-05-20 13:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 13:07:34 --> Parser Class Initialized
INFO - 2023-05-20 13:07:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 13:07:34 --> Pagination Class Initialized
INFO - 2023-05-20 13:07:34 --> Form Validation Class Initialized
INFO - 2023-05-20 13:07:34 --> Controller Class Initialized
INFO - 2023-05-20 13:07:34 --> Model Class Initialized
DEBUG - 2023-05-20 13:07:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:07:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-20 13:07:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:07:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 13:07:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 13:07:34 --> Model Class Initialized
INFO - 2023-05-20 13:07:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 13:07:34 --> Final output sent to browser
DEBUG - 2023-05-20 13:07:34 --> Total execution time: 0.0318
ERROR - 2023-05-20 13:07:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 13:07:35 --> Config Class Initialized
INFO - 2023-05-20 13:07:35 --> Hooks Class Initialized
DEBUG - 2023-05-20 13:07:35 --> UTF-8 Support Enabled
INFO - 2023-05-20 13:07:35 --> Utf8 Class Initialized
INFO - 2023-05-20 13:07:35 --> URI Class Initialized
INFO - 2023-05-20 13:07:35 --> Router Class Initialized
INFO - 2023-05-20 13:07:35 --> Output Class Initialized
INFO - 2023-05-20 13:07:35 --> Security Class Initialized
DEBUG - 2023-05-20 13:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 13:07:35 --> Input Class Initialized
INFO - 2023-05-20 13:07:35 --> Language Class Initialized
INFO - 2023-05-20 13:07:35 --> Loader Class Initialized
INFO - 2023-05-20 13:07:35 --> Helper loaded: url_helper
INFO - 2023-05-20 13:07:35 --> Helper loaded: file_helper
INFO - 2023-05-20 13:07:35 --> Helper loaded: html_helper
INFO - 2023-05-20 13:07:35 --> Helper loaded: text_helper
INFO - 2023-05-20 13:07:35 --> Helper loaded: form_helper
INFO - 2023-05-20 13:07:35 --> Helper loaded: lang_helper
INFO - 2023-05-20 13:07:35 --> Helper loaded: security_helper
INFO - 2023-05-20 13:07:35 --> Helper loaded: cookie_helper
INFO - 2023-05-20 13:07:35 --> Database Driver Class Initialized
INFO - 2023-05-20 13:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 13:07:35 --> Parser Class Initialized
INFO - 2023-05-20 13:07:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 13:07:35 --> Pagination Class Initialized
INFO - 2023-05-20 13:07:35 --> Form Validation Class Initialized
INFO - 2023-05-20 13:07:35 --> Controller Class Initialized
INFO - 2023-05-20 13:07:35 --> Model Class Initialized
DEBUG - 2023-05-20 13:07:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:07:35 --> Model Class Initialized
DEBUG - 2023-05-20 13:07:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:07:35 --> Model Class Initialized
INFO - 2023-05-20 13:07:35 --> Model Class Initialized
INFO - 2023-05-20 13:07:35 --> Model Class Initialized
INFO - 2023-05-20 13:07:35 --> Model Class Initialized
DEBUG - 2023-05-20 13:07:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 13:07:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:07:35 --> Model Class Initialized
INFO - 2023-05-20 13:07:35 --> Model Class Initialized
INFO - 2023-05-20 13:07:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 13:07:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 13:07:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 13:07:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 13:07:35 --> Model Class Initialized
INFO - 2023-05-20 13:07:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 13:07:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 13:07:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 13:07:35 --> Final output sent to browser
DEBUG - 2023-05-20 13:07:35 --> Total execution time: 0.0769
ERROR - 2023-05-20 18:44:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 18:44:48 --> Config Class Initialized
INFO - 2023-05-20 18:44:48 --> Hooks Class Initialized
DEBUG - 2023-05-20 18:44:48 --> UTF-8 Support Enabled
INFO - 2023-05-20 18:44:48 --> Utf8 Class Initialized
INFO - 2023-05-20 18:44:48 --> URI Class Initialized
DEBUG - 2023-05-20 18:44:48 --> No URI present. Default controller set.
INFO - 2023-05-20 18:44:48 --> Router Class Initialized
INFO - 2023-05-20 18:44:48 --> Output Class Initialized
INFO - 2023-05-20 18:44:48 --> Security Class Initialized
DEBUG - 2023-05-20 18:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 18:44:48 --> Input Class Initialized
INFO - 2023-05-20 18:44:48 --> Language Class Initialized
INFO - 2023-05-20 18:44:48 --> Loader Class Initialized
INFO - 2023-05-20 18:44:48 --> Helper loaded: url_helper
INFO - 2023-05-20 18:44:48 --> Helper loaded: file_helper
INFO - 2023-05-20 18:44:48 --> Helper loaded: html_helper
INFO - 2023-05-20 18:44:48 --> Helper loaded: text_helper
INFO - 2023-05-20 18:44:48 --> Helper loaded: form_helper
INFO - 2023-05-20 18:44:48 --> Helper loaded: lang_helper
INFO - 2023-05-20 18:44:48 --> Helper loaded: security_helper
INFO - 2023-05-20 18:44:48 --> Helper loaded: cookie_helper
INFO - 2023-05-20 18:44:48 --> Database Driver Class Initialized
INFO - 2023-05-20 18:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 18:44:48 --> Parser Class Initialized
INFO - 2023-05-20 18:44:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 18:44:48 --> Pagination Class Initialized
INFO - 2023-05-20 18:44:48 --> Form Validation Class Initialized
INFO - 2023-05-20 18:44:48 --> Controller Class Initialized
INFO - 2023-05-20 18:44:48 --> Model Class Initialized
DEBUG - 2023-05-20 18:44:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-20 18:44:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 18:44:48 --> Config Class Initialized
INFO - 2023-05-20 18:44:48 --> Hooks Class Initialized
DEBUG - 2023-05-20 18:44:48 --> UTF-8 Support Enabled
INFO - 2023-05-20 18:44:48 --> Utf8 Class Initialized
INFO - 2023-05-20 18:44:48 --> URI Class Initialized
INFO - 2023-05-20 18:44:48 --> Router Class Initialized
INFO - 2023-05-20 18:44:48 --> Output Class Initialized
INFO - 2023-05-20 18:44:48 --> Security Class Initialized
DEBUG - 2023-05-20 18:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 18:44:48 --> Input Class Initialized
INFO - 2023-05-20 18:44:48 --> Language Class Initialized
INFO - 2023-05-20 18:44:48 --> Loader Class Initialized
INFO - 2023-05-20 18:44:48 --> Helper loaded: url_helper
INFO - 2023-05-20 18:44:48 --> Helper loaded: file_helper
INFO - 2023-05-20 18:44:48 --> Helper loaded: html_helper
INFO - 2023-05-20 18:44:48 --> Helper loaded: text_helper
INFO - 2023-05-20 18:44:48 --> Helper loaded: form_helper
INFO - 2023-05-20 18:44:48 --> Helper loaded: lang_helper
INFO - 2023-05-20 18:44:48 --> Helper loaded: security_helper
INFO - 2023-05-20 18:44:48 --> Helper loaded: cookie_helper
INFO - 2023-05-20 18:44:48 --> Database Driver Class Initialized
INFO - 2023-05-20 18:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 18:44:48 --> Parser Class Initialized
INFO - 2023-05-20 18:44:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 18:44:48 --> Pagination Class Initialized
INFO - 2023-05-20 18:44:48 --> Form Validation Class Initialized
INFO - 2023-05-20 18:44:48 --> Controller Class Initialized
INFO - 2023-05-20 18:44:48 --> Model Class Initialized
DEBUG - 2023-05-20 18:44:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 18:44:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-20 18:44:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 18:44:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 18:44:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 18:44:48 --> Model Class Initialized
INFO - 2023-05-20 18:44:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 18:44:48 --> Final output sent to browser
DEBUG - 2023-05-20 18:44:48 --> Total execution time: 0.0290
ERROR - 2023-05-20 18:44:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 18:44:51 --> Config Class Initialized
INFO - 2023-05-20 18:44:51 --> Hooks Class Initialized
DEBUG - 2023-05-20 18:44:51 --> UTF-8 Support Enabled
INFO - 2023-05-20 18:44:51 --> Utf8 Class Initialized
INFO - 2023-05-20 18:44:51 --> URI Class Initialized
INFO - 2023-05-20 18:44:51 --> Router Class Initialized
INFO - 2023-05-20 18:44:51 --> Output Class Initialized
INFO - 2023-05-20 18:44:51 --> Security Class Initialized
DEBUG - 2023-05-20 18:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 18:44:51 --> Input Class Initialized
INFO - 2023-05-20 18:44:51 --> Language Class Initialized
INFO - 2023-05-20 18:44:51 --> Loader Class Initialized
INFO - 2023-05-20 18:44:51 --> Helper loaded: url_helper
INFO - 2023-05-20 18:44:51 --> Helper loaded: file_helper
INFO - 2023-05-20 18:44:51 --> Helper loaded: html_helper
INFO - 2023-05-20 18:44:51 --> Helper loaded: text_helper
INFO - 2023-05-20 18:44:51 --> Helper loaded: form_helper
INFO - 2023-05-20 18:44:51 --> Helper loaded: lang_helper
INFO - 2023-05-20 18:44:51 --> Helper loaded: security_helper
INFO - 2023-05-20 18:44:51 --> Helper loaded: cookie_helper
INFO - 2023-05-20 18:44:51 --> Database Driver Class Initialized
INFO - 2023-05-20 18:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 18:44:51 --> Parser Class Initialized
INFO - 2023-05-20 18:44:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 18:44:51 --> Pagination Class Initialized
INFO - 2023-05-20 18:44:51 --> Form Validation Class Initialized
INFO - 2023-05-20 18:44:51 --> Controller Class Initialized
INFO - 2023-05-20 18:44:51 --> Model Class Initialized
DEBUG - 2023-05-20 18:44:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 18:44:51 --> Model Class Initialized
INFO - 2023-05-20 18:44:51 --> Final output sent to browser
DEBUG - 2023-05-20 18:44:51 --> Total execution time: 0.0171
ERROR - 2023-05-20 18:44:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 18:44:52 --> Config Class Initialized
INFO - 2023-05-20 18:44:52 --> Hooks Class Initialized
DEBUG - 2023-05-20 18:44:52 --> UTF-8 Support Enabled
INFO - 2023-05-20 18:44:52 --> Utf8 Class Initialized
INFO - 2023-05-20 18:44:52 --> URI Class Initialized
DEBUG - 2023-05-20 18:44:52 --> No URI present. Default controller set.
INFO - 2023-05-20 18:44:52 --> Router Class Initialized
INFO - 2023-05-20 18:44:52 --> Output Class Initialized
INFO - 2023-05-20 18:44:52 --> Security Class Initialized
DEBUG - 2023-05-20 18:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 18:44:52 --> Input Class Initialized
INFO - 2023-05-20 18:44:52 --> Language Class Initialized
INFO - 2023-05-20 18:44:52 --> Loader Class Initialized
INFO - 2023-05-20 18:44:52 --> Helper loaded: url_helper
INFO - 2023-05-20 18:44:52 --> Helper loaded: file_helper
INFO - 2023-05-20 18:44:52 --> Helper loaded: html_helper
INFO - 2023-05-20 18:44:52 --> Helper loaded: text_helper
INFO - 2023-05-20 18:44:52 --> Helper loaded: form_helper
INFO - 2023-05-20 18:44:52 --> Helper loaded: lang_helper
INFO - 2023-05-20 18:44:52 --> Helper loaded: security_helper
INFO - 2023-05-20 18:44:52 --> Helper loaded: cookie_helper
INFO - 2023-05-20 18:44:52 --> Database Driver Class Initialized
INFO - 2023-05-20 18:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 18:44:52 --> Parser Class Initialized
INFO - 2023-05-20 18:44:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 18:44:52 --> Pagination Class Initialized
INFO - 2023-05-20 18:44:52 --> Form Validation Class Initialized
INFO - 2023-05-20 18:44:52 --> Controller Class Initialized
INFO - 2023-05-20 18:44:52 --> Model Class Initialized
DEBUG - 2023-05-20 18:44:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 18:44:52 --> Model Class Initialized
DEBUG - 2023-05-20 18:44:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 18:44:52 --> Model Class Initialized
INFO - 2023-05-20 18:44:52 --> Model Class Initialized
INFO - 2023-05-20 18:44:52 --> Model Class Initialized
INFO - 2023-05-20 18:44:52 --> Model Class Initialized
DEBUG - 2023-05-20 18:44:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 18:44:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 18:44:52 --> Model Class Initialized
INFO - 2023-05-20 18:44:52 --> Model Class Initialized
INFO - 2023-05-20 18:44:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 18:44:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 18:44:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 18:44:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 18:44:52 --> Model Class Initialized
INFO - 2023-05-20 18:44:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 18:44:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 18:44:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 18:44:52 --> Final output sent to browser
DEBUG - 2023-05-20 18:44:52 --> Total execution time: 0.1646
ERROR - 2023-05-20 18:44:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 18:44:53 --> Config Class Initialized
INFO - 2023-05-20 18:44:53 --> Hooks Class Initialized
DEBUG - 2023-05-20 18:44:53 --> UTF-8 Support Enabled
INFO - 2023-05-20 18:44:53 --> Utf8 Class Initialized
INFO - 2023-05-20 18:44:53 --> URI Class Initialized
INFO - 2023-05-20 18:44:53 --> Router Class Initialized
INFO - 2023-05-20 18:44:53 --> Output Class Initialized
INFO - 2023-05-20 18:44:53 --> Security Class Initialized
DEBUG - 2023-05-20 18:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 18:44:53 --> Input Class Initialized
INFO - 2023-05-20 18:44:53 --> Language Class Initialized
INFO - 2023-05-20 18:44:53 --> Loader Class Initialized
INFO - 2023-05-20 18:44:53 --> Helper loaded: url_helper
INFO - 2023-05-20 18:44:53 --> Helper loaded: file_helper
INFO - 2023-05-20 18:44:53 --> Helper loaded: html_helper
INFO - 2023-05-20 18:44:53 --> Helper loaded: text_helper
INFO - 2023-05-20 18:44:53 --> Helper loaded: form_helper
INFO - 2023-05-20 18:44:53 --> Helper loaded: lang_helper
INFO - 2023-05-20 18:44:53 --> Helper loaded: security_helper
INFO - 2023-05-20 18:44:53 --> Helper loaded: cookie_helper
INFO - 2023-05-20 18:44:53 --> Database Driver Class Initialized
INFO - 2023-05-20 18:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 18:44:53 --> Parser Class Initialized
INFO - 2023-05-20 18:44:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 18:44:53 --> Pagination Class Initialized
INFO - 2023-05-20 18:44:53 --> Form Validation Class Initialized
INFO - 2023-05-20 18:44:53 --> Controller Class Initialized
DEBUG - 2023-05-20 18:44:53 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 18:44:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 18:44:53 --> Model Class Initialized
INFO - 2023-05-20 18:44:53 --> Final output sent to browser
DEBUG - 2023-05-20 18:44:53 --> Total execution time: 0.0129
ERROR - 2023-05-20 19:47:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 19:47:13 --> Config Class Initialized
INFO - 2023-05-20 19:47:13 --> Hooks Class Initialized
DEBUG - 2023-05-20 19:47:13 --> UTF-8 Support Enabled
INFO - 2023-05-20 19:47:13 --> Utf8 Class Initialized
INFO - 2023-05-20 19:47:13 --> URI Class Initialized
DEBUG - 2023-05-20 19:47:13 --> No URI present. Default controller set.
INFO - 2023-05-20 19:47:13 --> Router Class Initialized
INFO - 2023-05-20 19:47:13 --> Output Class Initialized
INFO - 2023-05-20 19:47:13 --> Security Class Initialized
DEBUG - 2023-05-20 19:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 19:47:13 --> Input Class Initialized
INFO - 2023-05-20 19:47:13 --> Language Class Initialized
INFO - 2023-05-20 19:47:13 --> Loader Class Initialized
INFO - 2023-05-20 19:47:13 --> Helper loaded: url_helper
INFO - 2023-05-20 19:47:13 --> Helper loaded: file_helper
INFO - 2023-05-20 19:47:13 --> Helper loaded: html_helper
INFO - 2023-05-20 19:47:13 --> Helper loaded: text_helper
INFO - 2023-05-20 19:47:13 --> Helper loaded: form_helper
INFO - 2023-05-20 19:47:13 --> Helper loaded: lang_helper
INFO - 2023-05-20 19:47:13 --> Helper loaded: security_helper
INFO - 2023-05-20 19:47:13 --> Helper loaded: cookie_helper
INFO - 2023-05-20 19:47:13 --> Database Driver Class Initialized
INFO - 2023-05-20 19:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 19:47:13 --> Parser Class Initialized
INFO - 2023-05-20 19:47:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 19:47:13 --> Pagination Class Initialized
INFO - 2023-05-20 19:47:13 --> Form Validation Class Initialized
INFO - 2023-05-20 19:47:13 --> Controller Class Initialized
INFO - 2023-05-20 19:47:13 --> Model Class Initialized
DEBUG - 2023-05-20 19:47:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-05-20 19:47:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 19:47:14 --> Config Class Initialized
INFO - 2023-05-20 19:47:14 --> Hooks Class Initialized
DEBUG - 2023-05-20 19:47:14 --> UTF-8 Support Enabled
INFO - 2023-05-20 19:47:14 --> Utf8 Class Initialized
INFO - 2023-05-20 19:47:14 --> URI Class Initialized
INFO - 2023-05-20 19:47:14 --> Router Class Initialized
INFO - 2023-05-20 19:47:14 --> Output Class Initialized
INFO - 2023-05-20 19:47:14 --> Security Class Initialized
DEBUG - 2023-05-20 19:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 19:47:14 --> Input Class Initialized
INFO - 2023-05-20 19:47:14 --> Language Class Initialized
INFO - 2023-05-20 19:47:14 --> Loader Class Initialized
INFO - 2023-05-20 19:47:14 --> Helper loaded: url_helper
INFO - 2023-05-20 19:47:14 --> Helper loaded: file_helper
INFO - 2023-05-20 19:47:14 --> Helper loaded: html_helper
INFO - 2023-05-20 19:47:14 --> Helper loaded: text_helper
INFO - 2023-05-20 19:47:14 --> Helper loaded: form_helper
INFO - 2023-05-20 19:47:14 --> Helper loaded: lang_helper
INFO - 2023-05-20 19:47:14 --> Helper loaded: security_helper
INFO - 2023-05-20 19:47:14 --> Helper loaded: cookie_helper
INFO - 2023-05-20 19:47:14 --> Database Driver Class Initialized
INFO - 2023-05-20 19:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 19:47:14 --> Parser Class Initialized
INFO - 2023-05-20 19:47:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 19:47:14 --> Pagination Class Initialized
INFO - 2023-05-20 19:47:14 --> Form Validation Class Initialized
INFO - 2023-05-20 19:47:14 --> Controller Class Initialized
INFO - 2023-05-20 19:47:14 --> Model Class Initialized
DEBUG - 2023-05-20 19:47:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:47:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-05-20 19:47:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:47:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 19:47:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 19:47:14 --> Model Class Initialized
INFO - 2023-05-20 19:47:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 19:47:14 --> Final output sent to browser
DEBUG - 2023-05-20 19:47:14 --> Total execution time: 0.0289
ERROR - 2023-05-20 19:47:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 19:47:20 --> Config Class Initialized
INFO - 2023-05-20 19:47:20 --> Hooks Class Initialized
DEBUG - 2023-05-20 19:47:20 --> UTF-8 Support Enabled
INFO - 2023-05-20 19:47:20 --> Utf8 Class Initialized
INFO - 2023-05-20 19:47:20 --> URI Class Initialized
INFO - 2023-05-20 19:47:20 --> Router Class Initialized
INFO - 2023-05-20 19:47:20 --> Output Class Initialized
INFO - 2023-05-20 19:47:20 --> Security Class Initialized
DEBUG - 2023-05-20 19:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 19:47:20 --> Input Class Initialized
INFO - 2023-05-20 19:47:20 --> Language Class Initialized
INFO - 2023-05-20 19:47:20 --> Loader Class Initialized
INFO - 2023-05-20 19:47:20 --> Helper loaded: url_helper
INFO - 2023-05-20 19:47:20 --> Helper loaded: file_helper
INFO - 2023-05-20 19:47:20 --> Helper loaded: html_helper
INFO - 2023-05-20 19:47:20 --> Helper loaded: text_helper
INFO - 2023-05-20 19:47:20 --> Helper loaded: form_helper
INFO - 2023-05-20 19:47:20 --> Helper loaded: lang_helper
INFO - 2023-05-20 19:47:20 --> Helper loaded: security_helper
INFO - 2023-05-20 19:47:20 --> Helper loaded: cookie_helper
INFO - 2023-05-20 19:47:20 --> Database Driver Class Initialized
INFO - 2023-05-20 19:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 19:47:20 --> Parser Class Initialized
INFO - 2023-05-20 19:47:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 19:47:20 --> Pagination Class Initialized
INFO - 2023-05-20 19:47:20 --> Form Validation Class Initialized
INFO - 2023-05-20 19:47:20 --> Controller Class Initialized
INFO - 2023-05-20 19:47:20 --> Model Class Initialized
DEBUG - 2023-05-20 19:47:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:47:20 --> Model Class Initialized
INFO - 2023-05-20 19:47:20 --> Final output sent to browser
DEBUG - 2023-05-20 19:47:20 --> Total execution time: 0.0176
ERROR - 2023-05-20 19:47:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 19:47:20 --> Config Class Initialized
INFO - 2023-05-20 19:47:20 --> Hooks Class Initialized
DEBUG - 2023-05-20 19:47:20 --> UTF-8 Support Enabled
INFO - 2023-05-20 19:47:20 --> Utf8 Class Initialized
INFO - 2023-05-20 19:47:20 --> URI Class Initialized
DEBUG - 2023-05-20 19:47:20 --> No URI present. Default controller set.
INFO - 2023-05-20 19:47:20 --> Router Class Initialized
INFO - 2023-05-20 19:47:20 --> Output Class Initialized
INFO - 2023-05-20 19:47:20 --> Security Class Initialized
DEBUG - 2023-05-20 19:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 19:47:20 --> Input Class Initialized
INFO - 2023-05-20 19:47:20 --> Language Class Initialized
INFO - 2023-05-20 19:47:20 --> Loader Class Initialized
INFO - 2023-05-20 19:47:20 --> Helper loaded: url_helper
INFO - 2023-05-20 19:47:20 --> Helper loaded: file_helper
INFO - 2023-05-20 19:47:20 --> Helper loaded: html_helper
INFO - 2023-05-20 19:47:20 --> Helper loaded: text_helper
INFO - 2023-05-20 19:47:20 --> Helper loaded: form_helper
INFO - 2023-05-20 19:47:20 --> Helper loaded: lang_helper
INFO - 2023-05-20 19:47:20 --> Helper loaded: security_helper
INFO - 2023-05-20 19:47:20 --> Helper loaded: cookie_helper
INFO - 2023-05-20 19:47:20 --> Database Driver Class Initialized
INFO - 2023-05-20 19:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 19:47:20 --> Parser Class Initialized
INFO - 2023-05-20 19:47:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 19:47:20 --> Pagination Class Initialized
INFO - 2023-05-20 19:47:20 --> Form Validation Class Initialized
INFO - 2023-05-20 19:47:20 --> Controller Class Initialized
INFO - 2023-05-20 19:47:20 --> Model Class Initialized
DEBUG - 2023-05-20 19:47:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:47:20 --> Model Class Initialized
DEBUG - 2023-05-20 19:47:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:47:20 --> Model Class Initialized
INFO - 2023-05-20 19:47:20 --> Model Class Initialized
INFO - 2023-05-20 19:47:20 --> Model Class Initialized
INFO - 2023-05-20 19:47:20 --> Model Class Initialized
DEBUG - 2023-05-20 19:47:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 19:47:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:47:20 --> Model Class Initialized
INFO - 2023-05-20 19:47:20 --> Model Class Initialized
INFO - 2023-05-20 19:47:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 19:47:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:47:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 19:47:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 19:47:20 --> Model Class Initialized
INFO - 2023-05-20 19:47:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 19:47:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 19:47:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 19:47:20 --> Final output sent to browser
DEBUG - 2023-05-20 19:47:20 --> Total execution time: 0.0718
ERROR - 2023-05-20 19:47:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 19:47:27 --> Config Class Initialized
INFO - 2023-05-20 19:47:27 --> Hooks Class Initialized
DEBUG - 2023-05-20 19:47:27 --> UTF-8 Support Enabled
INFO - 2023-05-20 19:47:27 --> Utf8 Class Initialized
INFO - 2023-05-20 19:47:27 --> URI Class Initialized
INFO - 2023-05-20 19:47:27 --> Router Class Initialized
INFO - 2023-05-20 19:47:27 --> Output Class Initialized
INFO - 2023-05-20 19:47:27 --> Security Class Initialized
DEBUG - 2023-05-20 19:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 19:47:27 --> Input Class Initialized
INFO - 2023-05-20 19:47:27 --> Language Class Initialized
INFO - 2023-05-20 19:47:27 --> Loader Class Initialized
INFO - 2023-05-20 19:47:27 --> Helper loaded: url_helper
INFO - 2023-05-20 19:47:27 --> Helper loaded: file_helper
INFO - 2023-05-20 19:47:27 --> Helper loaded: html_helper
INFO - 2023-05-20 19:47:27 --> Helper loaded: text_helper
INFO - 2023-05-20 19:47:27 --> Helper loaded: form_helper
INFO - 2023-05-20 19:47:27 --> Helper loaded: lang_helper
INFO - 2023-05-20 19:47:27 --> Helper loaded: security_helper
INFO - 2023-05-20 19:47:27 --> Helper loaded: cookie_helper
INFO - 2023-05-20 19:47:27 --> Database Driver Class Initialized
INFO - 2023-05-20 19:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 19:47:27 --> Parser Class Initialized
INFO - 2023-05-20 19:47:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 19:47:27 --> Pagination Class Initialized
INFO - 2023-05-20 19:47:27 --> Form Validation Class Initialized
INFO - 2023-05-20 19:47:27 --> Controller Class Initialized
INFO - 2023-05-20 19:47:27 --> Model Class Initialized
DEBUG - 2023-05-20 19:47:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 19:47:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:47:27 --> Model Class Initialized
INFO - 2023-05-20 19:47:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-05-20 19:47:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:47:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 19:47:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 19:47:27 --> Model Class Initialized
INFO - 2023-05-20 19:47:27 --> Model Class Initialized
INFO - 2023-05-20 19:47:27 --> Model Class Initialized
INFO - 2023-05-20 19:47:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 19:47:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 19:47:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 19:47:27 --> Final output sent to browser
DEBUG - 2023-05-20 19:47:27 --> Total execution time: 0.0676
ERROR - 2023-05-20 19:47:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 19:47:28 --> Config Class Initialized
INFO - 2023-05-20 19:47:28 --> Hooks Class Initialized
DEBUG - 2023-05-20 19:47:28 --> UTF-8 Support Enabled
INFO - 2023-05-20 19:47:28 --> Utf8 Class Initialized
INFO - 2023-05-20 19:47:28 --> URI Class Initialized
INFO - 2023-05-20 19:47:28 --> Router Class Initialized
INFO - 2023-05-20 19:47:28 --> Output Class Initialized
INFO - 2023-05-20 19:47:28 --> Security Class Initialized
DEBUG - 2023-05-20 19:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 19:47:28 --> Input Class Initialized
INFO - 2023-05-20 19:47:28 --> Language Class Initialized
INFO - 2023-05-20 19:47:28 --> Loader Class Initialized
INFO - 2023-05-20 19:47:28 --> Helper loaded: url_helper
INFO - 2023-05-20 19:47:28 --> Helper loaded: file_helper
INFO - 2023-05-20 19:47:28 --> Helper loaded: html_helper
INFO - 2023-05-20 19:47:28 --> Helper loaded: text_helper
INFO - 2023-05-20 19:47:28 --> Helper loaded: form_helper
INFO - 2023-05-20 19:47:28 --> Helper loaded: lang_helper
INFO - 2023-05-20 19:47:28 --> Helper loaded: security_helper
INFO - 2023-05-20 19:47:28 --> Helper loaded: cookie_helper
INFO - 2023-05-20 19:47:28 --> Database Driver Class Initialized
INFO - 2023-05-20 19:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 19:47:28 --> Parser Class Initialized
INFO - 2023-05-20 19:47:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 19:47:28 --> Pagination Class Initialized
INFO - 2023-05-20 19:47:28 --> Form Validation Class Initialized
INFO - 2023-05-20 19:47:28 --> Controller Class Initialized
INFO - 2023-05-20 19:47:28 --> Model Class Initialized
DEBUG - 2023-05-20 19:47:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 19:47:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:47:28 --> Model Class Initialized
INFO - 2023-05-20 19:47:28 --> Final output sent to browser
DEBUG - 2023-05-20 19:47:28 --> Total execution time: 0.0201
ERROR - 2023-05-20 19:47:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 19:47:35 --> Config Class Initialized
INFO - 2023-05-20 19:47:35 --> Hooks Class Initialized
DEBUG - 2023-05-20 19:47:35 --> UTF-8 Support Enabled
INFO - 2023-05-20 19:47:35 --> Utf8 Class Initialized
INFO - 2023-05-20 19:47:35 --> URI Class Initialized
INFO - 2023-05-20 19:47:35 --> Router Class Initialized
INFO - 2023-05-20 19:47:35 --> Output Class Initialized
INFO - 2023-05-20 19:47:35 --> Security Class Initialized
DEBUG - 2023-05-20 19:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 19:47:35 --> Input Class Initialized
INFO - 2023-05-20 19:47:35 --> Language Class Initialized
INFO - 2023-05-20 19:47:35 --> Loader Class Initialized
INFO - 2023-05-20 19:47:35 --> Helper loaded: url_helper
INFO - 2023-05-20 19:47:35 --> Helper loaded: file_helper
INFO - 2023-05-20 19:47:35 --> Helper loaded: html_helper
INFO - 2023-05-20 19:47:35 --> Helper loaded: text_helper
INFO - 2023-05-20 19:47:35 --> Helper loaded: form_helper
INFO - 2023-05-20 19:47:35 --> Helper loaded: lang_helper
INFO - 2023-05-20 19:47:35 --> Helper loaded: security_helper
INFO - 2023-05-20 19:47:35 --> Helper loaded: cookie_helper
INFO - 2023-05-20 19:47:35 --> Database Driver Class Initialized
INFO - 2023-05-20 19:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 19:47:35 --> Parser Class Initialized
INFO - 2023-05-20 19:47:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 19:47:35 --> Pagination Class Initialized
INFO - 2023-05-20 19:47:35 --> Form Validation Class Initialized
INFO - 2023-05-20 19:47:35 --> Controller Class Initialized
INFO - 2023-05-20 19:47:35 --> Model Class Initialized
DEBUG - 2023-05-20 19:47:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 19:47:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:47:35 --> Model Class Initialized
INFO - 2023-05-20 19:47:35 --> Final output sent to browser
DEBUG - 2023-05-20 19:47:35 --> Total execution time: 0.0200
ERROR - 2023-05-20 19:47:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 19:47:56 --> Config Class Initialized
INFO - 2023-05-20 19:47:56 --> Hooks Class Initialized
DEBUG - 2023-05-20 19:47:56 --> UTF-8 Support Enabled
INFO - 2023-05-20 19:47:56 --> Utf8 Class Initialized
INFO - 2023-05-20 19:47:56 --> URI Class Initialized
DEBUG - 2023-05-20 19:47:56 --> No URI present. Default controller set.
INFO - 2023-05-20 19:47:56 --> Router Class Initialized
INFO - 2023-05-20 19:47:56 --> Output Class Initialized
INFO - 2023-05-20 19:47:56 --> Security Class Initialized
DEBUG - 2023-05-20 19:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 19:47:56 --> Input Class Initialized
INFO - 2023-05-20 19:47:56 --> Language Class Initialized
INFO - 2023-05-20 19:47:56 --> Loader Class Initialized
INFO - 2023-05-20 19:47:56 --> Helper loaded: url_helper
INFO - 2023-05-20 19:47:56 --> Helper loaded: file_helper
INFO - 2023-05-20 19:47:56 --> Helper loaded: html_helper
INFO - 2023-05-20 19:47:56 --> Helper loaded: text_helper
INFO - 2023-05-20 19:47:56 --> Helper loaded: form_helper
INFO - 2023-05-20 19:47:56 --> Helper loaded: lang_helper
INFO - 2023-05-20 19:47:56 --> Helper loaded: security_helper
INFO - 2023-05-20 19:47:56 --> Helper loaded: cookie_helper
INFO - 2023-05-20 19:47:56 --> Database Driver Class Initialized
INFO - 2023-05-20 19:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 19:47:56 --> Parser Class Initialized
INFO - 2023-05-20 19:47:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 19:47:56 --> Pagination Class Initialized
INFO - 2023-05-20 19:47:56 --> Form Validation Class Initialized
INFO - 2023-05-20 19:47:56 --> Controller Class Initialized
INFO - 2023-05-20 19:47:56 --> Model Class Initialized
DEBUG - 2023-05-20 19:47:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:47:56 --> Model Class Initialized
DEBUG - 2023-05-20 19:47:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:47:56 --> Model Class Initialized
INFO - 2023-05-20 19:47:56 --> Model Class Initialized
INFO - 2023-05-20 19:47:56 --> Model Class Initialized
INFO - 2023-05-20 19:47:56 --> Model Class Initialized
DEBUG - 2023-05-20 19:47:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 19:47:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:47:56 --> Model Class Initialized
INFO - 2023-05-20 19:47:56 --> Model Class Initialized
INFO - 2023-05-20 19:47:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 19:47:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:47:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 19:47:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 19:47:57 --> Model Class Initialized
INFO - 2023-05-20 19:47:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 19:47:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 19:47:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 19:47:57 --> Final output sent to browser
DEBUG - 2023-05-20 19:47:57 --> Total execution time: 0.1597
ERROR - 2023-05-20 19:48:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 19:48:10 --> Config Class Initialized
INFO - 2023-05-20 19:48:10 --> Hooks Class Initialized
DEBUG - 2023-05-20 19:48:10 --> UTF-8 Support Enabled
INFO - 2023-05-20 19:48:10 --> Utf8 Class Initialized
INFO - 2023-05-20 19:48:10 --> URI Class Initialized
INFO - 2023-05-20 19:48:10 --> Router Class Initialized
INFO - 2023-05-20 19:48:10 --> Output Class Initialized
INFO - 2023-05-20 19:48:10 --> Security Class Initialized
DEBUG - 2023-05-20 19:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 19:48:10 --> Input Class Initialized
INFO - 2023-05-20 19:48:10 --> Language Class Initialized
INFO - 2023-05-20 19:48:10 --> Loader Class Initialized
INFO - 2023-05-20 19:48:10 --> Helper loaded: url_helper
INFO - 2023-05-20 19:48:10 --> Helper loaded: file_helper
INFO - 2023-05-20 19:48:10 --> Helper loaded: html_helper
INFO - 2023-05-20 19:48:10 --> Helper loaded: text_helper
INFO - 2023-05-20 19:48:10 --> Helper loaded: form_helper
INFO - 2023-05-20 19:48:10 --> Helper loaded: lang_helper
INFO - 2023-05-20 19:48:10 --> Helper loaded: security_helper
INFO - 2023-05-20 19:48:10 --> Helper loaded: cookie_helper
INFO - 2023-05-20 19:48:10 --> Database Driver Class Initialized
INFO - 2023-05-20 19:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 19:48:10 --> Parser Class Initialized
INFO - 2023-05-20 19:48:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 19:48:10 --> Pagination Class Initialized
INFO - 2023-05-20 19:48:10 --> Form Validation Class Initialized
INFO - 2023-05-20 19:48:10 --> Controller Class Initialized
INFO - 2023-05-20 19:48:10 --> Model Class Initialized
DEBUG - 2023-05-20 19:48:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 19:48:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:48:10 --> Model Class Initialized
DEBUG - 2023-05-20 19:48:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:48:10 --> Model Class Initialized
INFO - 2023-05-20 19:48:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-20 19:48:10 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:48:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 19:48:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 19:48:10 --> Model Class Initialized
INFO - 2023-05-20 19:48:10 --> Model Class Initialized
INFO - 2023-05-20 19:48:10 --> Model Class Initialized
INFO - 2023-05-20 19:48:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 19:48:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 19:48:10 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 19:48:10 --> Final output sent to browser
DEBUG - 2023-05-20 19:48:10 --> Total execution time: 0.1272
ERROR - 2023-05-20 19:48:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 19:48:11 --> Config Class Initialized
INFO - 2023-05-20 19:48:11 --> Hooks Class Initialized
DEBUG - 2023-05-20 19:48:11 --> UTF-8 Support Enabled
INFO - 2023-05-20 19:48:11 --> Utf8 Class Initialized
INFO - 2023-05-20 19:48:11 --> URI Class Initialized
INFO - 2023-05-20 19:48:11 --> Router Class Initialized
INFO - 2023-05-20 19:48:11 --> Output Class Initialized
INFO - 2023-05-20 19:48:11 --> Security Class Initialized
DEBUG - 2023-05-20 19:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 19:48:11 --> Input Class Initialized
INFO - 2023-05-20 19:48:11 --> Language Class Initialized
INFO - 2023-05-20 19:48:11 --> Loader Class Initialized
INFO - 2023-05-20 19:48:11 --> Helper loaded: url_helper
INFO - 2023-05-20 19:48:11 --> Helper loaded: file_helper
INFO - 2023-05-20 19:48:11 --> Helper loaded: html_helper
INFO - 2023-05-20 19:48:11 --> Helper loaded: text_helper
INFO - 2023-05-20 19:48:11 --> Helper loaded: form_helper
INFO - 2023-05-20 19:48:11 --> Helper loaded: lang_helper
INFO - 2023-05-20 19:48:11 --> Helper loaded: security_helper
INFO - 2023-05-20 19:48:11 --> Helper loaded: cookie_helper
INFO - 2023-05-20 19:48:11 --> Database Driver Class Initialized
INFO - 2023-05-20 19:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 19:48:11 --> Parser Class Initialized
INFO - 2023-05-20 19:48:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 19:48:11 --> Pagination Class Initialized
INFO - 2023-05-20 19:48:11 --> Form Validation Class Initialized
INFO - 2023-05-20 19:48:11 --> Controller Class Initialized
INFO - 2023-05-20 19:48:11 --> Model Class Initialized
DEBUG - 2023-05-20 19:48:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 19:48:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:48:11 --> Model Class Initialized
DEBUG - 2023-05-20 19:48:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:48:11 --> Model Class Initialized
INFO - 2023-05-20 19:48:11 --> Final output sent to browser
DEBUG - 2023-05-20 19:48:11 --> Total execution time: 0.0468
ERROR - 2023-05-20 19:48:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 19:48:14 --> Config Class Initialized
INFO - 2023-05-20 19:48:14 --> Hooks Class Initialized
DEBUG - 2023-05-20 19:48:14 --> UTF-8 Support Enabled
INFO - 2023-05-20 19:48:14 --> Utf8 Class Initialized
INFO - 2023-05-20 19:48:14 --> URI Class Initialized
INFO - 2023-05-20 19:48:14 --> Router Class Initialized
INFO - 2023-05-20 19:48:14 --> Output Class Initialized
INFO - 2023-05-20 19:48:14 --> Security Class Initialized
DEBUG - 2023-05-20 19:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 19:48:14 --> Input Class Initialized
INFO - 2023-05-20 19:48:14 --> Language Class Initialized
INFO - 2023-05-20 19:48:14 --> Loader Class Initialized
INFO - 2023-05-20 19:48:14 --> Helper loaded: url_helper
INFO - 2023-05-20 19:48:14 --> Helper loaded: file_helper
INFO - 2023-05-20 19:48:14 --> Helper loaded: html_helper
INFO - 2023-05-20 19:48:14 --> Helper loaded: text_helper
INFO - 2023-05-20 19:48:14 --> Helper loaded: form_helper
INFO - 2023-05-20 19:48:14 --> Helper loaded: lang_helper
INFO - 2023-05-20 19:48:14 --> Helper loaded: security_helper
INFO - 2023-05-20 19:48:14 --> Helper loaded: cookie_helper
INFO - 2023-05-20 19:48:14 --> Database Driver Class Initialized
INFO - 2023-05-20 19:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 19:48:14 --> Parser Class Initialized
INFO - 2023-05-20 19:48:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 19:48:14 --> Pagination Class Initialized
INFO - 2023-05-20 19:48:14 --> Form Validation Class Initialized
INFO - 2023-05-20 19:48:14 --> Controller Class Initialized
INFO - 2023-05-20 19:48:14 --> Model Class Initialized
DEBUG - 2023-05-20 19:48:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 19:48:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:48:14 --> Model Class Initialized
DEBUG - 2023-05-20 19:48:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:48:14 --> Model Class Initialized
INFO - 2023-05-20 19:48:14 --> Final output sent to browser
DEBUG - 2023-05-20 19:48:14 --> Total execution time: 0.1336
ERROR - 2023-05-20 19:48:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 19:48:20 --> Config Class Initialized
INFO - 2023-05-20 19:48:20 --> Hooks Class Initialized
DEBUG - 2023-05-20 19:48:20 --> UTF-8 Support Enabled
INFO - 2023-05-20 19:48:20 --> Utf8 Class Initialized
INFO - 2023-05-20 19:48:20 --> URI Class Initialized
INFO - 2023-05-20 19:48:20 --> Router Class Initialized
INFO - 2023-05-20 19:48:20 --> Output Class Initialized
INFO - 2023-05-20 19:48:20 --> Security Class Initialized
DEBUG - 2023-05-20 19:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 19:48:20 --> Input Class Initialized
INFO - 2023-05-20 19:48:20 --> Language Class Initialized
INFO - 2023-05-20 19:48:20 --> Loader Class Initialized
INFO - 2023-05-20 19:48:20 --> Helper loaded: url_helper
INFO - 2023-05-20 19:48:20 --> Helper loaded: file_helper
INFO - 2023-05-20 19:48:20 --> Helper loaded: html_helper
INFO - 2023-05-20 19:48:20 --> Helper loaded: text_helper
INFO - 2023-05-20 19:48:20 --> Helper loaded: form_helper
INFO - 2023-05-20 19:48:20 --> Helper loaded: lang_helper
INFO - 2023-05-20 19:48:20 --> Helper loaded: security_helper
INFO - 2023-05-20 19:48:20 --> Helper loaded: cookie_helper
INFO - 2023-05-20 19:48:20 --> Database Driver Class Initialized
INFO - 2023-05-20 19:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 19:48:20 --> Parser Class Initialized
INFO - 2023-05-20 19:48:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 19:48:20 --> Pagination Class Initialized
INFO - 2023-05-20 19:48:20 --> Form Validation Class Initialized
INFO - 2023-05-20 19:48:20 --> Controller Class Initialized
INFO - 2023-05-20 19:48:20 --> Model Class Initialized
DEBUG - 2023-05-20 19:48:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 19:48:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:48:20 --> Model Class Initialized
DEBUG - 2023-05-20 19:48:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:48:20 --> Model Class Initialized
INFO - 2023-05-20 19:48:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-20 19:48:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:48:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 19:48:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 19:48:20 --> Model Class Initialized
INFO - 2023-05-20 19:48:20 --> Model Class Initialized
INFO - 2023-05-20 19:48:20 --> Model Class Initialized
INFO - 2023-05-20 19:48:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 19:48:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 19:48:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 19:48:20 --> Final output sent to browser
DEBUG - 2023-05-20 19:48:20 --> Total execution time: 0.1305
ERROR - 2023-05-20 19:48:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 19:48:21 --> Config Class Initialized
INFO - 2023-05-20 19:48:21 --> Hooks Class Initialized
DEBUG - 2023-05-20 19:48:21 --> UTF-8 Support Enabled
INFO - 2023-05-20 19:48:21 --> Utf8 Class Initialized
INFO - 2023-05-20 19:48:21 --> URI Class Initialized
INFO - 2023-05-20 19:48:21 --> Router Class Initialized
INFO - 2023-05-20 19:48:21 --> Output Class Initialized
INFO - 2023-05-20 19:48:21 --> Security Class Initialized
DEBUG - 2023-05-20 19:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 19:48:21 --> Input Class Initialized
INFO - 2023-05-20 19:48:21 --> Language Class Initialized
INFO - 2023-05-20 19:48:21 --> Loader Class Initialized
INFO - 2023-05-20 19:48:21 --> Helper loaded: url_helper
INFO - 2023-05-20 19:48:21 --> Helper loaded: file_helper
INFO - 2023-05-20 19:48:21 --> Helper loaded: html_helper
INFO - 2023-05-20 19:48:21 --> Helper loaded: text_helper
INFO - 2023-05-20 19:48:21 --> Helper loaded: form_helper
INFO - 2023-05-20 19:48:21 --> Helper loaded: lang_helper
INFO - 2023-05-20 19:48:21 --> Helper loaded: security_helper
INFO - 2023-05-20 19:48:21 --> Helper loaded: cookie_helper
INFO - 2023-05-20 19:48:21 --> Database Driver Class Initialized
INFO - 2023-05-20 19:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 19:48:21 --> Parser Class Initialized
INFO - 2023-05-20 19:48:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 19:48:21 --> Pagination Class Initialized
INFO - 2023-05-20 19:48:21 --> Form Validation Class Initialized
INFO - 2023-05-20 19:48:21 --> Controller Class Initialized
INFO - 2023-05-20 19:48:21 --> Model Class Initialized
DEBUG - 2023-05-20 19:48:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 19:48:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:48:21 --> Model Class Initialized
DEBUG - 2023-05-20 19:48:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:48:21 --> Model Class Initialized
INFO - 2023-05-20 19:48:21 --> Final output sent to browser
DEBUG - 2023-05-20 19:48:21 --> Total execution time: 0.0493
ERROR - 2023-05-20 19:48:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 19:48:25 --> Config Class Initialized
INFO - 2023-05-20 19:48:25 --> Hooks Class Initialized
DEBUG - 2023-05-20 19:48:25 --> UTF-8 Support Enabled
INFO - 2023-05-20 19:48:25 --> Utf8 Class Initialized
INFO - 2023-05-20 19:48:25 --> URI Class Initialized
INFO - 2023-05-20 19:48:25 --> Router Class Initialized
INFO - 2023-05-20 19:48:25 --> Output Class Initialized
INFO - 2023-05-20 19:48:25 --> Security Class Initialized
DEBUG - 2023-05-20 19:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 19:48:25 --> Input Class Initialized
INFO - 2023-05-20 19:48:25 --> Language Class Initialized
INFO - 2023-05-20 19:48:25 --> Loader Class Initialized
INFO - 2023-05-20 19:48:25 --> Helper loaded: url_helper
INFO - 2023-05-20 19:48:25 --> Helper loaded: file_helper
INFO - 2023-05-20 19:48:25 --> Helper loaded: html_helper
INFO - 2023-05-20 19:48:25 --> Helper loaded: text_helper
INFO - 2023-05-20 19:48:25 --> Helper loaded: form_helper
INFO - 2023-05-20 19:48:25 --> Helper loaded: lang_helper
INFO - 2023-05-20 19:48:25 --> Helper loaded: security_helper
INFO - 2023-05-20 19:48:25 --> Helper loaded: cookie_helper
INFO - 2023-05-20 19:48:25 --> Database Driver Class Initialized
INFO - 2023-05-20 19:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 19:48:25 --> Parser Class Initialized
INFO - 2023-05-20 19:48:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 19:48:25 --> Pagination Class Initialized
INFO - 2023-05-20 19:48:25 --> Form Validation Class Initialized
INFO - 2023-05-20 19:48:25 --> Controller Class Initialized
INFO - 2023-05-20 19:48:25 --> Model Class Initialized
DEBUG - 2023-05-20 19:48:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 19:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:48:25 --> Model Class Initialized
DEBUG - 2023-05-20 19:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:48:25 --> Model Class Initialized
INFO - 2023-05-20 19:48:25 --> Final output sent to browser
DEBUG - 2023-05-20 19:48:25 --> Total execution time: 0.1220
ERROR - 2023-05-20 19:49:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 19:49:23 --> Config Class Initialized
INFO - 2023-05-20 19:49:23 --> Hooks Class Initialized
DEBUG - 2023-05-20 19:49:23 --> UTF-8 Support Enabled
INFO - 2023-05-20 19:49:23 --> Utf8 Class Initialized
INFO - 2023-05-20 19:49:23 --> URI Class Initialized
DEBUG - 2023-05-20 19:49:23 --> No URI present. Default controller set.
INFO - 2023-05-20 19:49:23 --> Router Class Initialized
INFO - 2023-05-20 19:49:23 --> Output Class Initialized
INFO - 2023-05-20 19:49:23 --> Security Class Initialized
DEBUG - 2023-05-20 19:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 19:49:23 --> Input Class Initialized
INFO - 2023-05-20 19:49:23 --> Language Class Initialized
INFO - 2023-05-20 19:49:23 --> Loader Class Initialized
INFO - 2023-05-20 19:49:23 --> Helper loaded: url_helper
INFO - 2023-05-20 19:49:23 --> Helper loaded: file_helper
INFO - 2023-05-20 19:49:23 --> Helper loaded: html_helper
INFO - 2023-05-20 19:49:23 --> Helper loaded: text_helper
INFO - 2023-05-20 19:49:23 --> Helper loaded: form_helper
INFO - 2023-05-20 19:49:23 --> Helper loaded: lang_helper
INFO - 2023-05-20 19:49:23 --> Helper loaded: security_helper
INFO - 2023-05-20 19:49:23 --> Helper loaded: cookie_helper
INFO - 2023-05-20 19:49:23 --> Database Driver Class Initialized
INFO - 2023-05-20 19:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 19:49:23 --> Parser Class Initialized
INFO - 2023-05-20 19:49:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 19:49:23 --> Pagination Class Initialized
INFO - 2023-05-20 19:49:23 --> Form Validation Class Initialized
INFO - 2023-05-20 19:49:23 --> Controller Class Initialized
INFO - 2023-05-20 19:49:23 --> Model Class Initialized
DEBUG - 2023-05-20 19:49:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:49:23 --> Model Class Initialized
DEBUG - 2023-05-20 19:49:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:49:23 --> Model Class Initialized
INFO - 2023-05-20 19:49:23 --> Model Class Initialized
INFO - 2023-05-20 19:49:23 --> Model Class Initialized
INFO - 2023-05-20 19:49:23 --> Model Class Initialized
DEBUG - 2023-05-20 19:49:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 19:49:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:49:23 --> Model Class Initialized
INFO - 2023-05-20 19:49:23 --> Model Class Initialized
INFO - 2023-05-20 19:49:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-05-20 19:49:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:49:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 19:49:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 19:49:23 --> Model Class Initialized
INFO - 2023-05-20 19:49:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 19:49:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 19:49:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 19:49:23 --> Final output sent to browser
DEBUG - 2023-05-20 19:49:23 --> Total execution time: 0.1682
ERROR - 2023-05-20 19:51:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 19:51:05 --> Config Class Initialized
INFO - 2023-05-20 19:51:05 --> Hooks Class Initialized
DEBUG - 2023-05-20 19:51:05 --> UTF-8 Support Enabled
INFO - 2023-05-20 19:51:05 --> Utf8 Class Initialized
INFO - 2023-05-20 19:51:05 --> URI Class Initialized
INFO - 2023-05-20 19:51:05 --> Router Class Initialized
INFO - 2023-05-20 19:51:05 --> Output Class Initialized
INFO - 2023-05-20 19:51:05 --> Security Class Initialized
DEBUG - 2023-05-20 19:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 19:51:05 --> Input Class Initialized
INFO - 2023-05-20 19:51:05 --> Language Class Initialized
INFO - 2023-05-20 19:51:05 --> Loader Class Initialized
INFO - 2023-05-20 19:51:05 --> Helper loaded: url_helper
INFO - 2023-05-20 19:51:05 --> Helper loaded: file_helper
INFO - 2023-05-20 19:51:05 --> Helper loaded: html_helper
INFO - 2023-05-20 19:51:05 --> Helper loaded: text_helper
INFO - 2023-05-20 19:51:05 --> Helper loaded: form_helper
INFO - 2023-05-20 19:51:05 --> Helper loaded: lang_helper
INFO - 2023-05-20 19:51:05 --> Helper loaded: security_helper
INFO - 2023-05-20 19:51:05 --> Helper loaded: cookie_helper
INFO - 2023-05-20 19:51:05 --> Database Driver Class Initialized
INFO - 2023-05-20 19:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 19:51:05 --> Parser Class Initialized
INFO - 2023-05-20 19:51:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 19:51:05 --> Pagination Class Initialized
INFO - 2023-05-20 19:51:05 --> Form Validation Class Initialized
INFO - 2023-05-20 19:51:05 --> Controller Class Initialized
INFO - 2023-05-20 19:51:05 --> Model Class Initialized
DEBUG - 2023-05-20 19:51:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 19:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:51:05 --> Model Class Initialized
DEBUG - 2023-05-20 19:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:51:05 --> Model Class Initialized
INFO - 2023-05-20 19:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-05-20 19:51:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 19:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 19:51:05 --> Model Class Initialized
INFO - 2023-05-20 19:51:05 --> Model Class Initialized
INFO - 2023-05-20 19:51:05 --> Model Class Initialized
INFO - 2023-05-20 19:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 19:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 19:51:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 19:51:05 --> Final output sent to browser
DEBUG - 2023-05-20 19:51:05 --> Total execution time: 0.0855
ERROR - 2023-05-20 19:51:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 19:51:06 --> Config Class Initialized
INFO - 2023-05-20 19:51:06 --> Hooks Class Initialized
DEBUG - 2023-05-20 19:51:06 --> UTF-8 Support Enabled
INFO - 2023-05-20 19:51:06 --> Utf8 Class Initialized
INFO - 2023-05-20 19:51:06 --> URI Class Initialized
INFO - 2023-05-20 19:51:06 --> Router Class Initialized
INFO - 2023-05-20 19:51:06 --> Output Class Initialized
INFO - 2023-05-20 19:51:06 --> Security Class Initialized
DEBUG - 2023-05-20 19:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 19:51:06 --> Input Class Initialized
INFO - 2023-05-20 19:51:06 --> Language Class Initialized
INFO - 2023-05-20 19:51:06 --> Loader Class Initialized
INFO - 2023-05-20 19:51:06 --> Helper loaded: url_helper
INFO - 2023-05-20 19:51:06 --> Helper loaded: file_helper
INFO - 2023-05-20 19:51:06 --> Helper loaded: html_helper
INFO - 2023-05-20 19:51:06 --> Helper loaded: text_helper
INFO - 2023-05-20 19:51:06 --> Helper loaded: form_helper
INFO - 2023-05-20 19:51:06 --> Helper loaded: lang_helper
INFO - 2023-05-20 19:51:06 --> Helper loaded: security_helper
INFO - 2023-05-20 19:51:06 --> Helper loaded: cookie_helper
INFO - 2023-05-20 19:51:06 --> Database Driver Class Initialized
INFO - 2023-05-20 19:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 19:51:06 --> Parser Class Initialized
INFO - 2023-05-20 19:51:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 19:51:06 --> Pagination Class Initialized
INFO - 2023-05-20 19:51:06 --> Form Validation Class Initialized
INFO - 2023-05-20 19:51:06 --> Controller Class Initialized
INFO - 2023-05-20 19:51:06 --> Model Class Initialized
DEBUG - 2023-05-20 19:51:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 19:51:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:51:06 --> Model Class Initialized
DEBUG - 2023-05-20 19:51:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:51:06 --> Model Class Initialized
INFO - 2023-05-20 19:51:06 --> Final output sent to browser
DEBUG - 2023-05-20 19:51:06 --> Total execution time: 0.0191
ERROR - 2023-05-20 19:51:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 19:51:09 --> Config Class Initialized
INFO - 2023-05-20 19:51:09 --> Hooks Class Initialized
DEBUG - 2023-05-20 19:51:09 --> UTF-8 Support Enabled
INFO - 2023-05-20 19:51:09 --> Utf8 Class Initialized
INFO - 2023-05-20 19:51:09 --> URI Class Initialized
INFO - 2023-05-20 19:51:09 --> Router Class Initialized
INFO - 2023-05-20 19:51:09 --> Output Class Initialized
INFO - 2023-05-20 19:51:09 --> Security Class Initialized
DEBUG - 2023-05-20 19:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 19:51:09 --> Input Class Initialized
INFO - 2023-05-20 19:51:09 --> Language Class Initialized
INFO - 2023-05-20 19:51:09 --> Loader Class Initialized
INFO - 2023-05-20 19:51:09 --> Helper loaded: url_helper
INFO - 2023-05-20 19:51:09 --> Helper loaded: file_helper
INFO - 2023-05-20 19:51:09 --> Helper loaded: html_helper
INFO - 2023-05-20 19:51:09 --> Helper loaded: text_helper
INFO - 2023-05-20 19:51:09 --> Helper loaded: form_helper
INFO - 2023-05-20 19:51:09 --> Helper loaded: lang_helper
INFO - 2023-05-20 19:51:09 --> Helper loaded: security_helper
INFO - 2023-05-20 19:51:09 --> Helper loaded: cookie_helper
INFO - 2023-05-20 19:51:09 --> Database Driver Class Initialized
INFO - 2023-05-20 19:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 19:51:09 --> Parser Class Initialized
INFO - 2023-05-20 19:51:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 19:51:09 --> Pagination Class Initialized
INFO - 2023-05-20 19:51:09 --> Form Validation Class Initialized
INFO - 2023-05-20 19:51:09 --> Controller Class Initialized
INFO - 2023-05-20 19:51:09 --> Model Class Initialized
DEBUG - 2023-05-20 19:51:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 19:51:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:51:09 --> Model Class Initialized
DEBUG - 2023-05-20 19:51:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:51:09 --> Model Class Initialized
INFO - 2023-05-20 19:51:09 --> Final output sent to browser
DEBUG - 2023-05-20 19:51:09 --> Total execution time: 0.0180
ERROR - 2023-05-20 19:51:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 19:51:16 --> Config Class Initialized
INFO - 2023-05-20 19:51:16 --> Hooks Class Initialized
DEBUG - 2023-05-20 19:51:16 --> UTF-8 Support Enabled
INFO - 2023-05-20 19:51:16 --> Utf8 Class Initialized
INFO - 2023-05-20 19:51:16 --> URI Class Initialized
INFO - 2023-05-20 19:51:16 --> Router Class Initialized
INFO - 2023-05-20 19:51:16 --> Output Class Initialized
INFO - 2023-05-20 19:51:16 --> Security Class Initialized
DEBUG - 2023-05-20 19:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 19:51:16 --> Input Class Initialized
INFO - 2023-05-20 19:51:16 --> Language Class Initialized
INFO - 2023-05-20 19:51:16 --> Loader Class Initialized
INFO - 2023-05-20 19:51:16 --> Helper loaded: url_helper
INFO - 2023-05-20 19:51:16 --> Helper loaded: file_helper
INFO - 2023-05-20 19:51:16 --> Helper loaded: html_helper
INFO - 2023-05-20 19:51:16 --> Helper loaded: text_helper
INFO - 2023-05-20 19:51:16 --> Helper loaded: form_helper
INFO - 2023-05-20 19:51:16 --> Helper loaded: lang_helper
INFO - 2023-05-20 19:51:16 --> Helper loaded: security_helper
INFO - 2023-05-20 19:51:16 --> Helper loaded: cookie_helper
INFO - 2023-05-20 19:51:16 --> Database Driver Class Initialized
INFO - 2023-05-20 19:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 19:51:16 --> Parser Class Initialized
INFO - 2023-05-20 19:51:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 19:51:16 --> Pagination Class Initialized
INFO - 2023-05-20 19:51:16 --> Form Validation Class Initialized
INFO - 2023-05-20 19:51:16 --> Controller Class Initialized
INFO - 2023-05-20 19:51:16 --> Model Class Initialized
DEBUG - 2023-05-20 19:51:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 19:51:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:51:16 --> Model Class Initialized
INFO - 2023-05-20 19:51:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-05-20 19:51:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:51:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 19:51:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 19:51:16 --> Model Class Initialized
INFO - 2023-05-20 19:51:16 --> Model Class Initialized
INFO - 2023-05-20 19:51:16 --> Model Class Initialized
INFO - 2023-05-20 19:51:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 19:51:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 19:51:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 19:51:16 --> Final output sent to browser
DEBUG - 2023-05-20 19:51:16 --> Total execution time: 0.0624
ERROR - 2023-05-20 19:51:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 19:51:16 --> Config Class Initialized
INFO - 2023-05-20 19:51:16 --> Hooks Class Initialized
DEBUG - 2023-05-20 19:51:16 --> UTF-8 Support Enabled
INFO - 2023-05-20 19:51:16 --> Utf8 Class Initialized
INFO - 2023-05-20 19:51:16 --> URI Class Initialized
INFO - 2023-05-20 19:51:16 --> Router Class Initialized
INFO - 2023-05-20 19:51:16 --> Output Class Initialized
INFO - 2023-05-20 19:51:16 --> Security Class Initialized
DEBUG - 2023-05-20 19:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 19:51:16 --> Input Class Initialized
INFO - 2023-05-20 19:51:16 --> Language Class Initialized
INFO - 2023-05-20 19:51:16 --> Loader Class Initialized
INFO - 2023-05-20 19:51:16 --> Helper loaded: url_helper
INFO - 2023-05-20 19:51:16 --> Helper loaded: file_helper
INFO - 2023-05-20 19:51:16 --> Helper loaded: html_helper
INFO - 2023-05-20 19:51:16 --> Helper loaded: text_helper
INFO - 2023-05-20 19:51:16 --> Helper loaded: form_helper
INFO - 2023-05-20 19:51:16 --> Helper loaded: lang_helper
INFO - 2023-05-20 19:51:16 --> Helper loaded: security_helper
INFO - 2023-05-20 19:51:16 --> Helper loaded: cookie_helper
INFO - 2023-05-20 19:51:16 --> Database Driver Class Initialized
INFO - 2023-05-20 19:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 19:51:16 --> Parser Class Initialized
INFO - 2023-05-20 19:51:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 19:51:16 --> Pagination Class Initialized
INFO - 2023-05-20 19:51:16 --> Form Validation Class Initialized
INFO - 2023-05-20 19:51:16 --> Controller Class Initialized
INFO - 2023-05-20 19:51:16 --> Model Class Initialized
DEBUG - 2023-05-20 19:51:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 19:51:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:51:16 --> Model Class Initialized
INFO - 2023-05-20 19:51:16 --> Final output sent to browser
DEBUG - 2023-05-20 19:51:16 --> Total execution time: 0.0174
ERROR - 2023-05-20 19:51:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 19:51:20 --> Config Class Initialized
INFO - 2023-05-20 19:51:20 --> Hooks Class Initialized
DEBUG - 2023-05-20 19:51:20 --> UTF-8 Support Enabled
INFO - 2023-05-20 19:51:20 --> Utf8 Class Initialized
INFO - 2023-05-20 19:51:20 --> URI Class Initialized
INFO - 2023-05-20 19:51:20 --> Router Class Initialized
INFO - 2023-05-20 19:51:20 --> Output Class Initialized
INFO - 2023-05-20 19:51:20 --> Security Class Initialized
DEBUG - 2023-05-20 19:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 19:51:20 --> Input Class Initialized
INFO - 2023-05-20 19:51:20 --> Language Class Initialized
INFO - 2023-05-20 19:51:20 --> Loader Class Initialized
INFO - 2023-05-20 19:51:20 --> Helper loaded: url_helper
INFO - 2023-05-20 19:51:20 --> Helper loaded: file_helper
INFO - 2023-05-20 19:51:20 --> Helper loaded: html_helper
INFO - 2023-05-20 19:51:20 --> Helper loaded: text_helper
INFO - 2023-05-20 19:51:20 --> Helper loaded: form_helper
INFO - 2023-05-20 19:51:20 --> Helper loaded: lang_helper
INFO - 2023-05-20 19:51:20 --> Helper loaded: security_helper
INFO - 2023-05-20 19:51:20 --> Helper loaded: cookie_helper
INFO - 2023-05-20 19:51:20 --> Database Driver Class Initialized
INFO - 2023-05-20 19:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 19:51:20 --> Parser Class Initialized
INFO - 2023-05-20 19:51:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 19:51:20 --> Pagination Class Initialized
INFO - 2023-05-20 19:51:20 --> Form Validation Class Initialized
INFO - 2023-05-20 19:51:20 --> Controller Class Initialized
INFO - 2023-05-20 19:51:20 --> Model Class Initialized
DEBUG - 2023-05-20 19:51:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-05-20 19:51:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:51:20 --> Model Class Initialized
DEBUG - 2023-05-20 19:51:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-05-20 19:51:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-05-20 19:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-05-20 19:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-05-20 19:51:20 --> Model Class Initialized
INFO - 2023-05-20 19:51:20 --> Model Class Initialized
INFO - 2023-05-20 19:51:20 --> Model Class Initialized
INFO - 2023-05-20 19:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-05-20 19:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-05-20 19:51:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-05-20 19:51:20 --> Final output sent to browser
DEBUG - 2023-05-20 19:51:20 --> Total execution time: 0.0560
ERROR - 2023-05-20 19:57:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-05-20 19:57:48 --> Config Class Initialized
INFO - 2023-05-20 19:57:48 --> Hooks Class Initialized
DEBUG - 2023-05-20 19:57:48 --> UTF-8 Support Enabled
INFO - 2023-05-20 19:57:48 --> Utf8 Class Initialized
INFO - 2023-05-20 19:57:48 --> URI Class Initialized
DEBUG - 2023-05-20 19:57:48 --> No URI present. Default controller set.
INFO - 2023-05-20 19:57:48 --> Router Class Initialized
INFO - 2023-05-20 19:57:48 --> Output Class Initialized
INFO - 2023-05-20 19:57:48 --> Security Class Initialized
DEBUG - 2023-05-20 19:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-20 19:57:48 --> Input Class Initialized
INFO - 2023-05-20 19:57:48 --> Language Class Initialized
INFO - 2023-05-20 19:57:48 --> Loader Class Initialized
INFO - 2023-05-20 19:57:48 --> Helper loaded: url_helper
INFO - 2023-05-20 19:57:48 --> Helper loaded: file_helper
INFO - 2023-05-20 19:57:48 --> Helper loaded: html_helper
INFO - 2023-05-20 19:57:48 --> Helper loaded: text_helper
INFO - 2023-05-20 19:57:48 --> Helper loaded: form_helper
INFO - 2023-05-20 19:57:48 --> Helper loaded: lang_helper
INFO - 2023-05-20 19:57:48 --> Helper loaded: security_helper
INFO - 2023-05-20 19:57:48 --> Helper loaded: cookie_helper
INFO - 2023-05-20 19:57:48 --> Database Driver Class Initialized
INFO - 2023-05-20 19:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-20 19:57:48 --> Parser Class Initialized
INFO - 2023-05-20 19:57:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-05-20 19:57:48 --> Pagination Class Initialized
INFO - 2023-05-20 19:57:48 --> Form Validation Class Initialized
INFO - 2023-05-20 19:57:48 --> Controller Class Initialized
INFO - 2023-05-20 19:57:48 --> Model Class Initialized
DEBUG - 2023-05-20 19:57:48 --> Session class already loaded. Second attempt ignored.
