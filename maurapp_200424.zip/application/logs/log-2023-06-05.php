<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-05 00:31:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 00:31:16 --> Config Class Initialized
INFO - 2023-06-05 00:31:16 --> Hooks Class Initialized
DEBUG - 2023-06-05 00:31:16 --> UTF-8 Support Enabled
INFO - 2023-06-05 00:31:16 --> Utf8 Class Initialized
INFO - 2023-06-05 00:31:16 --> URI Class Initialized
DEBUG - 2023-06-05 00:31:16 --> No URI present. Default controller set.
INFO - 2023-06-05 00:31:16 --> Router Class Initialized
INFO - 2023-06-05 00:31:16 --> Output Class Initialized
INFO - 2023-06-05 00:31:16 --> Security Class Initialized
DEBUG - 2023-06-05 00:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 00:31:16 --> Input Class Initialized
INFO - 2023-06-05 00:31:16 --> Language Class Initialized
INFO - 2023-06-05 00:31:16 --> Loader Class Initialized
INFO - 2023-06-05 00:31:16 --> Helper loaded: url_helper
INFO - 2023-06-05 00:31:16 --> Helper loaded: file_helper
INFO - 2023-06-05 00:31:16 --> Helper loaded: html_helper
INFO - 2023-06-05 00:31:16 --> Helper loaded: text_helper
INFO - 2023-06-05 00:31:16 --> Helper loaded: form_helper
INFO - 2023-06-05 00:31:16 --> Helper loaded: lang_helper
INFO - 2023-06-05 00:31:16 --> Helper loaded: security_helper
INFO - 2023-06-05 00:31:16 --> Helper loaded: cookie_helper
INFO - 2023-06-05 00:31:16 --> Database Driver Class Initialized
INFO - 2023-06-05 00:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 00:31:16 --> Parser Class Initialized
INFO - 2023-06-05 00:31:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 00:31:16 --> Pagination Class Initialized
INFO - 2023-06-05 00:31:16 --> Form Validation Class Initialized
INFO - 2023-06-05 00:31:16 --> Controller Class Initialized
INFO - 2023-06-05 00:31:16 --> Model Class Initialized
DEBUG - 2023-06-05 00:31:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-05 00:31:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 00:31:17 --> Config Class Initialized
INFO - 2023-06-05 00:31:17 --> Hooks Class Initialized
DEBUG - 2023-06-05 00:31:17 --> UTF-8 Support Enabled
INFO - 2023-06-05 00:31:17 --> Utf8 Class Initialized
INFO - 2023-06-05 00:31:17 --> URI Class Initialized
INFO - 2023-06-05 00:31:17 --> Router Class Initialized
INFO - 2023-06-05 00:31:17 --> Output Class Initialized
INFO - 2023-06-05 00:31:17 --> Security Class Initialized
DEBUG - 2023-06-05 00:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 00:31:17 --> Input Class Initialized
INFO - 2023-06-05 00:31:17 --> Language Class Initialized
INFO - 2023-06-05 00:31:17 --> Loader Class Initialized
INFO - 2023-06-05 00:31:17 --> Helper loaded: url_helper
INFO - 2023-06-05 00:31:17 --> Helper loaded: file_helper
INFO - 2023-06-05 00:31:17 --> Helper loaded: html_helper
INFO - 2023-06-05 00:31:17 --> Helper loaded: text_helper
INFO - 2023-06-05 00:31:17 --> Helper loaded: form_helper
INFO - 2023-06-05 00:31:17 --> Helper loaded: lang_helper
INFO - 2023-06-05 00:31:17 --> Helper loaded: security_helper
INFO - 2023-06-05 00:31:17 --> Helper loaded: cookie_helper
INFO - 2023-06-05 00:31:17 --> Database Driver Class Initialized
INFO - 2023-06-05 00:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 00:31:17 --> Parser Class Initialized
INFO - 2023-06-05 00:31:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 00:31:17 --> Pagination Class Initialized
INFO - 2023-06-05 00:31:17 --> Form Validation Class Initialized
INFO - 2023-06-05 00:31:17 --> Controller Class Initialized
INFO - 2023-06-05 00:31:17 --> Model Class Initialized
DEBUG - 2023-06-05 00:31:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 00:31:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-05 00:31:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 00:31:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 00:31:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 00:31:17 --> Model Class Initialized
INFO - 2023-06-05 00:31:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 00:31:17 --> Final output sent to browser
DEBUG - 2023-06-05 00:31:17 --> Total execution time: 0.0359
ERROR - 2023-06-05 00:31:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 00:31:45 --> Config Class Initialized
INFO - 2023-06-05 00:31:45 --> Hooks Class Initialized
DEBUG - 2023-06-05 00:31:45 --> UTF-8 Support Enabled
INFO - 2023-06-05 00:31:45 --> Utf8 Class Initialized
INFO - 2023-06-05 00:31:45 --> URI Class Initialized
INFO - 2023-06-05 00:31:45 --> Router Class Initialized
INFO - 2023-06-05 00:31:45 --> Output Class Initialized
INFO - 2023-06-05 00:31:45 --> Security Class Initialized
DEBUG - 2023-06-05 00:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 00:31:45 --> Input Class Initialized
INFO - 2023-06-05 00:31:45 --> Language Class Initialized
INFO - 2023-06-05 00:31:45 --> Loader Class Initialized
INFO - 2023-06-05 00:31:45 --> Helper loaded: url_helper
INFO - 2023-06-05 00:31:45 --> Helper loaded: file_helper
INFO - 2023-06-05 00:31:45 --> Helper loaded: html_helper
INFO - 2023-06-05 00:31:45 --> Helper loaded: text_helper
INFO - 2023-06-05 00:31:45 --> Helper loaded: form_helper
INFO - 2023-06-05 00:31:45 --> Helper loaded: lang_helper
INFO - 2023-06-05 00:31:45 --> Helper loaded: security_helper
INFO - 2023-06-05 00:31:45 --> Helper loaded: cookie_helper
INFO - 2023-06-05 00:31:45 --> Database Driver Class Initialized
INFO - 2023-06-05 00:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 00:31:45 --> Parser Class Initialized
INFO - 2023-06-05 00:31:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 00:31:45 --> Pagination Class Initialized
INFO - 2023-06-05 00:31:45 --> Form Validation Class Initialized
INFO - 2023-06-05 00:31:45 --> Controller Class Initialized
INFO - 2023-06-05 00:31:45 --> Model Class Initialized
DEBUG - 2023-06-05 00:31:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 00:31:45 --> Model Class Initialized
INFO - 2023-06-05 00:31:45 --> Final output sent to browser
DEBUG - 2023-06-05 00:31:45 --> Total execution time: 0.0209
ERROR - 2023-06-05 00:31:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 00:31:45 --> Config Class Initialized
INFO - 2023-06-05 00:31:45 --> Hooks Class Initialized
DEBUG - 2023-06-05 00:31:45 --> UTF-8 Support Enabled
INFO - 2023-06-05 00:31:45 --> Utf8 Class Initialized
INFO - 2023-06-05 00:31:45 --> URI Class Initialized
INFO - 2023-06-05 00:31:45 --> Router Class Initialized
INFO - 2023-06-05 00:31:45 --> Output Class Initialized
INFO - 2023-06-05 00:31:45 --> Security Class Initialized
DEBUG - 2023-06-05 00:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 00:31:45 --> Input Class Initialized
INFO - 2023-06-05 00:31:45 --> Language Class Initialized
INFO - 2023-06-05 00:31:45 --> Loader Class Initialized
INFO - 2023-06-05 00:31:45 --> Helper loaded: url_helper
INFO - 2023-06-05 00:31:45 --> Helper loaded: file_helper
INFO - 2023-06-05 00:31:45 --> Helper loaded: html_helper
INFO - 2023-06-05 00:31:45 --> Helper loaded: text_helper
INFO - 2023-06-05 00:31:45 --> Helper loaded: form_helper
INFO - 2023-06-05 00:31:45 --> Helper loaded: lang_helper
INFO - 2023-06-05 00:31:45 --> Helper loaded: security_helper
INFO - 2023-06-05 00:31:45 --> Helper loaded: cookie_helper
INFO - 2023-06-05 00:31:45 --> Database Driver Class Initialized
INFO - 2023-06-05 00:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 00:31:45 --> Parser Class Initialized
INFO - 2023-06-05 00:31:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 00:31:45 --> Pagination Class Initialized
INFO - 2023-06-05 00:31:45 --> Form Validation Class Initialized
INFO - 2023-06-05 00:31:45 --> Controller Class Initialized
INFO - 2023-06-05 00:31:45 --> Model Class Initialized
DEBUG - 2023-06-05 00:31:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 00:31:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-05 00:31:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 00:31:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 00:31:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 00:31:45 --> Model Class Initialized
INFO - 2023-06-05 00:31:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 00:31:45 --> Final output sent to browser
DEBUG - 2023-06-05 00:31:45 --> Total execution time: 0.0262
ERROR - 2023-06-05 00:32:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 00:32:04 --> Config Class Initialized
INFO - 2023-06-05 00:32:04 --> Hooks Class Initialized
DEBUG - 2023-06-05 00:32:04 --> UTF-8 Support Enabled
INFO - 2023-06-05 00:32:04 --> Utf8 Class Initialized
INFO - 2023-06-05 00:32:04 --> URI Class Initialized
INFO - 2023-06-05 00:32:04 --> Router Class Initialized
INFO - 2023-06-05 00:32:04 --> Output Class Initialized
INFO - 2023-06-05 00:32:04 --> Security Class Initialized
DEBUG - 2023-06-05 00:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 00:32:04 --> Input Class Initialized
INFO - 2023-06-05 00:32:04 --> Language Class Initialized
INFO - 2023-06-05 00:32:04 --> Loader Class Initialized
INFO - 2023-06-05 00:32:04 --> Helper loaded: url_helper
INFO - 2023-06-05 00:32:04 --> Helper loaded: file_helper
INFO - 2023-06-05 00:32:04 --> Helper loaded: html_helper
INFO - 2023-06-05 00:32:04 --> Helper loaded: text_helper
INFO - 2023-06-05 00:32:04 --> Helper loaded: form_helper
INFO - 2023-06-05 00:32:04 --> Helper loaded: lang_helper
INFO - 2023-06-05 00:32:04 --> Helper loaded: security_helper
INFO - 2023-06-05 00:32:04 --> Helper loaded: cookie_helper
INFO - 2023-06-05 00:32:04 --> Database Driver Class Initialized
INFO - 2023-06-05 00:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 00:32:04 --> Parser Class Initialized
INFO - 2023-06-05 00:32:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 00:32:04 --> Pagination Class Initialized
INFO - 2023-06-05 00:32:04 --> Form Validation Class Initialized
INFO - 2023-06-05 00:32:04 --> Controller Class Initialized
INFO - 2023-06-05 00:32:04 --> Model Class Initialized
DEBUG - 2023-06-05 00:32:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 00:32:04 --> Model Class Initialized
INFO - 2023-06-05 00:32:04 --> Final output sent to browser
DEBUG - 2023-06-05 00:32:04 --> Total execution time: 0.0207
ERROR - 2023-06-05 00:32:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 00:32:04 --> Config Class Initialized
INFO - 2023-06-05 00:32:04 --> Hooks Class Initialized
DEBUG - 2023-06-05 00:32:04 --> UTF-8 Support Enabled
INFO - 2023-06-05 00:32:04 --> Utf8 Class Initialized
INFO - 2023-06-05 00:32:04 --> URI Class Initialized
DEBUG - 2023-06-05 00:32:04 --> No URI present. Default controller set.
INFO - 2023-06-05 00:32:04 --> Router Class Initialized
INFO - 2023-06-05 00:32:04 --> Output Class Initialized
INFO - 2023-06-05 00:32:04 --> Security Class Initialized
DEBUG - 2023-06-05 00:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 00:32:04 --> Input Class Initialized
INFO - 2023-06-05 00:32:04 --> Language Class Initialized
INFO - 2023-06-05 00:32:04 --> Loader Class Initialized
INFO - 2023-06-05 00:32:04 --> Helper loaded: url_helper
INFO - 2023-06-05 00:32:04 --> Helper loaded: file_helper
INFO - 2023-06-05 00:32:04 --> Helper loaded: html_helper
INFO - 2023-06-05 00:32:04 --> Helper loaded: text_helper
INFO - 2023-06-05 00:32:04 --> Helper loaded: form_helper
INFO - 2023-06-05 00:32:04 --> Helper loaded: lang_helper
INFO - 2023-06-05 00:32:04 --> Helper loaded: security_helper
INFO - 2023-06-05 00:32:04 --> Helper loaded: cookie_helper
INFO - 2023-06-05 00:32:04 --> Database Driver Class Initialized
INFO - 2023-06-05 00:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 00:32:04 --> Parser Class Initialized
INFO - 2023-06-05 00:32:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 00:32:04 --> Pagination Class Initialized
INFO - 2023-06-05 00:32:04 --> Form Validation Class Initialized
INFO - 2023-06-05 00:32:04 --> Controller Class Initialized
INFO - 2023-06-05 00:32:04 --> Model Class Initialized
DEBUG - 2023-06-05 00:32:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 00:32:04 --> Model Class Initialized
DEBUG - 2023-06-05 00:32:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 00:32:04 --> Model Class Initialized
INFO - 2023-06-05 00:32:04 --> Model Class Initialized
INFO - 2023-06-05 00:32:04 --> Model Class Initialized
INFO - 2023-06-05 00:32:04 --> Model Class Initialized
DEBUG - 2023-06-05 00:32:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 00:32:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 00:32:04 --> Model Class Initialized
INFO - 2023-06-05 00:32:04 --> Model Class Initialized
INFO - 2023-06-05 00:32:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-05 00:32:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 00:32:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 00:32:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 00:32:04 --> Model Class Initialized
INFO - 2023-06-05 00:32:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 00:32:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 00:32:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 00:32:04 --> Final output sent to browser
DEBUG - 2023-06-05 00:32:04 --> Total execution time: 0.0874
ERROR - 2023-06-05 02:54:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 02:54:45 --> Config Class Initialized
INFO - 2023-06-05 02:54:45 --> Hooks Class Initialized
DEBUG - 2023-06-05 02:54:45 --> UTF-8 Support Enabled
INFO - 2023-06-05 02:54:45 --> Utf8 Class Initialized
INFO - 2023-06-05 02:54:45 --> URI Class Initialized
DEBUG - 2023-06-05 02:54:45 --> No URI present. Default controller set.
INFO - 2023-06-05 02:54:45 --> Router Class Initialized
INFO - 2023-06-05 02:54:45 --> Output Class Initialized
INFO - 2023-06-05 02:54:45 --> Security Class Initialized
DEBUG - 2023-06-05 02:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 02:54:45 --> Input Class Initialized
INFO - 2023-06-05 02:54:45 --> Language Class Initialized
INFO - 2023-06-05 02:54:45 --> Loader Class Initialized
INFO - 2023-06-05 02:54:45 --> Helper loaded: url_helper
INFO - 2023-06-05 02:54:45 --> Helper loaded: file_helper
INFO - 2023-06-05 02:54:45 --> Helper loaded: html_helper
INFO - 2023-06-05 02:54:45 --> Helper loaded: text_helper
INFO - 2023-06-05 02:54:45 --> Helper loaded: form_helper
INFO - 2023-06-05 02:54:45 --> Helper loaded: lang_helper
INFO - 2023-06-05 02:54:45 --> Helper loaded: security_helper
INFO - 2023-06-05 02:54:45 --> Helper loaded: cookie_helper
INFO - 2023-06-05 02:54:45 --> Database Driver Class Initialized
INFO - 2023-06-05 02:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 02:54:45 --> Parser Class Initialized
INFO - 2023-06-05 02:54:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 02:54:45 --> Pagination Class Initialized
INFO - 2023-06-05 02:54:45 --> Form Validation Class Initialized
INFO - 2023-06-05 02:54:45 --> Controller Class Initialized
INFO - 2023-06-05 02:54:45 --> Model Class Initialized
DEBUG - 2023-06-05 02:54:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-05 02:54:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 02:54:45 --> Config Class Initialized
INFO - 2023-06-05 02:54:45 --> Hooks Class Initialized
DEBUG - 2023-06-05 02:54:45 --> UTF-8 Support Enabled
INFO - 2023-06-05 02:54:45 --> Utf8 Class Initialized
INFO - 2023-06-05 02:54:45 --> URI Class Initialized
INFO - 2023-06-05 02:54:45 --> Router Class Initialized
INFO - 2023-06-05 02:54:45 --> Output Class Initialized
INFO - 2023-06-05 02:54:45 --> Security Class Initialized
DEBUG - 2023-06-05 02:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 02:54:45 --> Input Class Initialized
INFO - 2023-06-05 02:54:45 --> Language Class Initialized
INFO - 2023-06-05 02:54:45 --> Loader Class Initialized
INFO - 2023-06-05 02:54:45 --> Helper loaded: url_helper
INFO - 2023-06-05 02:54:45 --> Helper loaded: file_helper
INFO - 2023-06-05 02:54:45 --> Helper loaded: html_helper
INFO - 2023-06-05 02:54:45 --> Helper loaded: text_helper
INFO - 2023-06-05 02:54:45 --> Helper loaded: form_helper
INFO - 2023-06-05 02:54:45 --> Helper loaded: lang_helper
INFO - 2023-06-05 02:54:45 --> Helper loaded: security_helper
INFO - 2023-06-05 02:54:45 --> Helper loaded: cookie_helper
INFO - 2023-06-05 02:54:45 --> Database Driver Class Initialized
INFO - 2023-06-05 02:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 02:54:45 --> Parser Class Initialized
INFO - 2023-06-05 02:54:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 02:54:45 --> Pagination Class Initialized
INFO - 2023-06-05 02:54:45 --> Form Validation Class Initialized
INFO - 2023-06-05 02:54:45 --> Controller Class Initialized
INFO - 2023-06-05 02:54:45 --> Model Class Initialized
DEBUG - 2023-06-05 02:54:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 02:54:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-05 02:54:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 02:54:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 02:54:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 02:54:45 --> Model Class Initialized
INFO - 2023-06-05 02:54:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 02:54:45 --> Final output sent to browser
DEBUG - 2023-06-05 02:54:45 --> Total execution time: 0.0307
ERROR - 2023-06-05 02:55:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 02:55:05 --> Config Class Initialized
INFO - 2023-06-05 02:55:05 --> Hooks Class Initialized
DEBUG - 2023-06-05 02:55:05 --> UTF-8 Support Enabled
INFO - 2023-06-05 02:55:05 --> Utf8 Class Initialized
INFO - 2023-06-05 02:55:05 --> URI Class Initialized
INFO - 2023-06-05 02:55:05 --> Router Class Initialized
INFO - 2023-06-05 02:55:05 --> Output Class Initialized
INFO - 2023-06-05 02:55:05 --> Security Class Initialized
DEBUG - 2023-06-05 02:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 02:55:05 --> Input Class Initialized
INFO - 2023-06-05 02:55:05 --> Language Class Initialized
INFO - 2023-06-05 02:55:05 --> Loader Class Initialized
INFO - 2023-06-05 02:55:05 --> Helper loaded: url_helper
INFO - 2023-06-05 02:55:05 --> Helper loaded: file_helper
INFO - 2023-06-05 02:55:05 --> Helper loaded: html_helper
INFO - 2023-06-05 02:55:05 --> Helper loaded: text_helper
INFO - 2023-06-05 02:55:05 --> Helper loaded: form_helper
INFO - 2023-06-05 02:55:05 --> Helper loaded: lang_helper
INFO - 2023-06-05 02:55:05 --> Helper loaded: security_helper
INFO - 2023-06-05 02:55:05 --> Helper loaded: cookie_helper
INFO - 2023-06-05 02:55:05 --> Database Driver Class Initialized
INFO - 2023-06-05 02:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 02:55:05 --> Parser Class Initialized
INFO - 2023-06-05 02:55:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 02:55:05 --> Pagination Class Initialized
INFO - 2023-06-05 02:55:05 --> Form Validation Class Initialized
INFO - 2023-06-05 02:55:05 --> Controller Class Initialized
INFO - 2023-06-05 02:55:05 --> Model Class Initialized
DEBUG - 2023-06-05 02:55:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 02:55:05 --> Model Class Initialized
INFO - 2023-06-05 02:55:05 --> Final output sent to browser
DEBUG - 2023-06-05 02:55:05 --> Total execution time: 0.0212
ERROR - 2023-06-05 02:55:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 02:55:06 --> Config Class Initialized
INFO - 2023-06-05 02:55:06 --> Hooks Class Initialized
DEBUG - 2023-06-05 02:55:06 --> UTF-8 Support Enabled
INFO - 2023-06-05 02:55:06 --> Utf8 Class Initialized
INFO - 2023-06-05 02:55:06 --> URI Class Initialized
DEBUG - 2023-06-05 02:55:06 --> No URI present. Default controller set.
INFO - 2023-06-05 02:55:06 --> Router Class Initialized
INFO - 2023-06-05 02:55:06 --> Output Class Initialized
INFO - 2023-06-05 02:55:06 --> Security Class Initialized
DEBUG - 2023-06-05 02:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 02:55:06 --> Input Class Initialized
INFO - 2023-06-05 02:55:06 --> Language Class Initialized
INFO - 2023-06-05 02:55:06 --> Loader Class Initialized
INFO - 2023-06-05 02:55:06 --> Helper loaded: url_helper
INFO - 2023-06-05 02:55:06 --> Helper loaded: file_helper
INFO - 2023-06-05 02:55:06 --> Helper loaded: html_helper
INFO - 2023-06-05 02:55:06 --> Helper loaded: text_helper
INFO - 2023-06-05 02:55:06 --> Helper loaded: form_helper
INFO - 2023-06-05 02:55:06 --> Helper loaded: lang_helper
INFO - 2023-06-05 02:55:06 --> Helper loaded: security_helper
INFO - 2023-06-05 02:55:06 --> Helper loaded: cookie_helper
INFO - 2023-06-05 02:55:06 --> Database Driver Class Initialized
INFO - 2023-06-05 02:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 02:55:06 --> Parser Class Initialized
INFO - 2023-06-05 02:55:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 02:55:06 --> Pagination Class Initialized
INFO - 2023-06-05 02:55:06 --> Form Validation Class Initialized
INFO - 2023-06-05 02:55:06 --> Controller Class Initialized
INFO - 2023-06-05 02:55:06 --> Model Class Initialized
DEBUG - 2023-06-05 02:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 02:55:06 --> Model Class Initialized
DEBUG - 2023-06-05 02:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 02:55:06 --> Model Class Initialized
INFO - 2023-06-05 02:55:06 --> Model Class Initialized
INFO - 2023-06-05 02:55:06 --> Model Class Initialized
INFO - 2023-06-05 02:55:06 --> Model Class Initialized
DEBUG - 2023-06-05 02:55:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 02:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 02:55:06 --> Model Class Initialized
INFO - 2023-06-05 02:55:06 --> Model Class Initialized
INFO - 2023-06-05 02:55:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-05 02:55:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 02:55:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 02:55:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 02:55:06 --> Model Class Initialized
INFO - 2023-06-05 02:55:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 02:55:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 02:55:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 02:55:06 --> Final output sent to browser
DEBUG - 2023-06-05 02:55:06 --> Total execution time: 0.0976
ERROR - 2023-06-05 02:55:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 02:55:32 --> Config Class Initialized
INFO - 2023-06-05 02:55:32 --> Hooks Class Initialized
DEBUG - 2023-06-05 02:55:32 --> UTF-8 Support Enabled
INFO - 2023-06-05 02:55:32 --> Utf8 Class Initialized
INFO - 2023-06-05 02:55:32 --> URI Class Initialized
INFO - 2023-06-05 02:55:32 --> Router Class Initialized
INFO - 2023-06-05 02:55:32 --> Output Class Initialized
INFO - 2023-06-05 02:55:32 --> Security Class Initialized
DEBUG - 2023-06-05 02:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 02:55:32 --> Input Class Initialized
INFO - 2023-06-05 02:55:32 --> Language Class Initialized
INFO - 2023-06-05 02:55:32 --> Loader Class Initialized
INFO - 2023-06-05 02:55:32 --> Helper loaded: url_helper
INFO - 2023-06-05 02:55:32 --> Helper loaded: file_helper
INFO - 2023-06-05 02:55:32 --> Helper loaded: html_helper
INFO - 2023-06-05 02:55:32 --> Helper loaded: text_helper
INFO - 2023-06-05 02:55:32 --> Helper loaded: form_helper
INFO - 2023-06-05 02:55:32 --> Helper loaded: lang_helper
INFO - 2023-06-05 02:55:32 --> Helper loaded: security_helper
INFO - 2023-06-05 02:55:32 --> Helper loaded: cookie_helper
INFO - 2023-06-05 02:55:32 --> Database Driver Class Initialized
INFO - 2023-06-05 02:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 02:55:32 --> Parser Class Initialized
INFO - 2023-06-05 02:55:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 02:55:32 --> Pagination Class Initialized
INFO - 2023-06-05 02:55:32 --> Form Validation Class Initialized
INFO - 2023-06-05 02:55:32 --> Controller Class Initialized
INFO - 2023-06-05 02:55:32 --> Model Class Initialized
DEBUG - 2023-06-05 02:55:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 02:55:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 02:55:32 --> Model Class Initialized
INFO - 2023-06-05 02:55:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-05 02:55:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 02:55:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 02:55:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 02:55:32 --> Model Class Initialized
INFO - 2023-06-05 02:55:32 --> Model Class Initialized
INFO - 2023-06-05 02:55:32 --> Model Class Initialized
INFO - 2023-06-05 02:55:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 02:55:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 02:55:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 02:55:32 --> Final output sent to browser
DEBUG - 2023-06-05 02:55:32 --> Total execution time: 0.0726
ERROR - 2023-06-05 02:55:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 02:55:32 --> Config Class Initialized
INFO - 2023-06-05 02:55:32 --> Hooks Class Initialized
DEBUG - 2023-06-05 02:55:32 --> UTF-8 Support Enabled
INFO - 2023-06-05 02:55:32 --> Utf8 Class Initialized
INFO - 2023-06-05 02:55:32 --> URI Class Initialized
INFO - 2023-06-05 02:55:32 --> Router Class Initialized
INFO - 2023-06-05 02:55:32 --> Output Class Initialized
INFO - 2023-06-05 02:55:32 --> Security Class Initialized
DEBUG - 2023-06-05 02:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 02:55:32 --> Input Class Initialized
INFO - 2023-06-05 02:55:32 --> Language Class Initialized
INFO - 2023-06-05 02:55:32 --> Loader Class Initialized
INFO - 2023-06-05 02:55:32 --> Helper loaded: url_helper
INFO - 2023-06-05 02:55:32 --> Helper loaded: file_helper
INFO - 2023-06-05 02:55:32 --> Helper loaded: html_helper
INFO - 2023-06-05 02:55:32 --> Helper loaded: text_helper
INFO - 2023-06-05 02:55:32 --> Helper loaded: form_helper
INFO - 2023-06-05 02:55:32 --> Helper loaded: lang_helper
INFO - 2023-06-05 02:55:32 --> Helper loaded: security_helper
INFO - 2023-06-05 02:55:32 --> Helper loaded: cookie_helper
INFO - 2023-06-05 02:55:32 --> Database Driver Class Initialized
INFO - 2023-06-05 02:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 02:55:32 --> Parser Class Initialized
INFO - 2023-06-05 02:55:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 02:55:32 --> Pagination Class Initialized
INFO - 2023-06-05 02:55:32 --> Form Validation Class Initialized
INFO - 2023-06-05 02:55:32 --> Controller Class Initialized
INFO - 2023-06-05 02:55:32 --> Model Class Initialized
DEBUG - 2023-06-05 02:55:32 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 02:55:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 02:55:32 --> Model Class Initialized
INFO - 2023-06-05 02:55:32 --> Final output sent to browser
DEBUG - 2023-06-05 02:55:32 --> Total execution time: 0.0293
ERROR - 2023-06-05 03:39:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 03:39:27 --> Config Class Initialized
INFO - 2023-06-05 03:39:27 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:39:27 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:39:27 --> Utf8 Class Initialized
INFO - 2023-06-05 03:39:27 --> URI Class Initialized
INFO - 2023-06-05 03:39:27 --> Router Class Initialized
INFO - 2023-06-05 03:39:27 --> Output Class Initialized
INFO - 2023-06-05 03:39:27 --> Security Class Initialized
DEBUG - 2023-06-05 03:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:39:27 --> Input Class Initialized
INFO - 2023-06-05 03:39:27 --> Language Class Initialized
INFO - 2023-06-05 03:39:27 --> Loader Class Initialized
INFO - 2023-06-05 03:39:27 --> Helper loaded: url_helper
INFO - 2023-06-05 03:39:27 --> Helper loaded: file_helper
INFO - 2023-06-05 03:39:27 --> Helper loaded: html_helper
INFO - 2023-06-05 03:39:27 --> Helper loaded: text_helper
INFO - 2023-06-05 03:39:27 --> Helper loaded: form_helper
INFO - 2023-06-05 03:39:27 --> Helper loaded: lang_helper
INFO - 2023-06-05 03:39:27 --> Helper loaded: security_helper
INFO - 2023-06-05 03:39:27 --> Helper loaded: cookie_helper
INFO - 2023-06-05 03:39:27 --> Database Driver Class Initialized
INFO - 2023-06-05 03:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 03:39:27 --> Parser Class Initialized
INFO - 2023-06-05 03:39:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 03:39:27 --> Pagination Class Initialized
INFO - 2023-06-05 03:39:27 --> Form Validation Class Initialized
INFO - 2023-06-05 03:39:27 --> Controller Class Initialized
INFO - 2023-06-05 03:39:27 --> Model Class Initialized
DEBUG - 2023-06-05 03:39:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 03:39:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-05 03:39:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 03:39:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 03:39:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 03:39:27 --> Model Class Initialized
INFO - 2023-06-05 03:39:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 03:39:27 --> Final output sent to browser
DEBUG - 2023-06-05 03:39:27 --> Total execution time: 0.0327
ERROR - 2023-06-05 04:25:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 04:25:19 --> Config Class Initialized
INFO - 2023-06-05 04:25:19 --> Hooks Class Initialized
DEBUG - 2023-06-05 04:25:19 --> UTF-8 Support Enabled
INFO - 2023-06-05 04:25:19 --> Utf8 Class Initialized
INFO - 2023-06-05 04:25:19 --> URI Class Initialized
DEBUG - 2023-06-05 04:25:19 --> No URI present. Default controller set.
INFO - 2023-06-05 04:25:19 --> Router Class Initialized
INFO - 2023-06-05 04:25:19 --> Output Class Initialized
INFO - 2023-06-05 04:25:19 --> Security Class Initialized
DEBUG - 2023-06-05 04:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 04:25:19 --> Input Class Initialized
INFO - 2023-06-05 04:25:19 --> Language Class Initialized
INFO - 2023-06-05 04:25:19 --> Loader Class Initialized
INFO - 2023-06-05 04:25:19 --> Helper loaded: url_helper
INFO - 2023-06-05 04:25:19 --> Helper loaded: file_helper
INFO - 2023-06-05 04:25:19 --> Helper loaded: html_helper
INFO - 2023-06-05 04:25:19 --> Helper loaded: text_helper
INFO - 2023-06-05 04:25:19 --> Helper loaded: form_helper
INFO - 2023-06-05 04:25:19 --> Helper loaded: lang_helper
INFO - 2023-06-05 04:25:19 --> Helper loaded: security_helper
INFO - 2023-06-05 04:25:19 --> Helper loaded: cookie_helper
INFO - 2023-06-05 04:25:19 --> Database Driver Class Initialized
INFO - 2023-06-05 04:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 04:25:19 --> Parser Class Initialized
INFO - 2023-06-05 04:25:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 04:25:19 --> Pagination Class Initialized
INFO - 2023-06-05 04:25:19 --> Form Validation Class Initialized
INFO - 2023-06-05 04:25:19 --> Controller Class Initialized
INFO - 2023-06-05 04:25:19 --> Model Class Initialized
DEBUG - 2023-06-05 04:25:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-05 04:25:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 04:25:20 --> Config Class Initialized
INFO - 2023-06-05 04:25:20 --> Hooks Class Initialized
DEBUG - 2023-06-05 04:25:20 --> UTF-8 Support Enabled
INFO - 2023-06-05 04:25:20 --> Utf8 Class Initialized
INFO - 2023-06-05 04:25:20 --> URI Class Initialized
INFO - 2023-06-05 04:25:20 --> Router Class Initialized
INFO - 2023-06-05 04:25:20 --> Output Class Initialized
INFO - 2023-06-05 04:25:20 --> Security Class Initialized
DEBUG - 2023-06-05 04:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 04:25:20 --> Input Class Initialized
INFO - 2023-06-05 04:25:20 --> Language Class Initialized
INFO - 2023-06-05 04:25:20 --> Loader Class Initialized
INFO - 2023-06-05 04:25:20 --> Helper loaded: url_helper
INFO - 2023-06-05 04:25:20 --> Helper loaded: file_helper
INFO - 2023-06-05 04:25:20 --> Helper loaded: html_helper
INFO - 2023-06-05 04:25:20 --> Helper loaded: text_helper
INFO - 2023-06-05 04:25:20 --> Helper loaded: form_helper
INFO - 2023-06-05 04:25:20 --> Helper loaded: lang_helper
INFO - 2023-06-05 04:25:20 --> Helper loaded: security_helper
INFO - 2023-06-05 04:25:20 --> Helper loaded: cookie_helper
INFO - 2023-06-05 04:25:20 --> Database Driver Class Initialized
INFO - 2023-06-05 04:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 04:25:20 --> Parser Class Initialized
INFO - 2023-06-05 04:25:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 04:25:20 --> Pagination Class Initialized
INFO - 2023-06-05 04:25:20 --> Form Validation Class Initialized
INFO - 2023-06-05 04:25:20 --> Controller Class Initialized
INFO - 2023-06-05 04:25:20 --> Model Class Initialized
DEBUG - 2023-06-05 04:25:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 04:25:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-05 04:25:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 04:25:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 04:25:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 04:25:20 --> Model Class Initialized
INFO - 2023-06-05 04:25:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 04:25:20 --> Final output sent to browser
DEBUG - 2023-06-05 04:25:20 --> Total execution time: 0.0306
ERROR - 2023-06-05 04:31:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 04:31:33 --> Config Class Initialized
INFO - 2023-06-05 04:31:33 --> Hooks Class Initialized
DEBUG - 2023-06-05 04:31:33 --> UTF-8 Support Enabled
INFO - 2023-06-05 04:31:33 --> Utf8 Class Initialized
INFO - 2023-06-05 04:31:33 --> URI Class Initialized
DEBUG - 2023-06-05 04:31:33 --> No URI present. Default controller set.
INFO - 2023-06-05 04:31:33 --> Router Class Initialized
INFO - 2023-06-05 04:31:33 --> Output Class Initialized
INFO - 2023-06-05 04:31:33 --> Security Class Initialized
DEBUG - 2023-06-05 04:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 04:31:33 --> Input Class Initialized
INFO - 2023-06-05 04:31:33 --> Language Class Initialized
INFO - 2023-06-05 04:31:33 --> Loader Class Initialized
INFO - 2023-06-05 04:31:33 --> Helper loaded: url_helper
INFO - 2023-06-05 04:31:33 --> Helper loaded: file_helper
INFO - 2023-06-05 04:31:33 --> Helper loaded: html_helper
INFO - 2023-06-05 04:31:33 --> Helper loaded: text_helper
INFO - 2023-06-05 04:31:33 --> Helper loaded: form_helper
INFO - 2023-06-05 04:31:33 --> Helper loaded: lang_helper
INFO - 2023-06-05 04:31:33 --> Helper loaded: security_helper
INFO - 2023-06-05 04:31:33 --> Helper loaded: cookie_helper
INFO - 2023-06-05 04:31:33 --> Database Driver Class Initialized
INFO - 2023-06-05 04:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 04:31:33 --> Parser Class Initialized
INFO - 2023-06-05 04:31:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 04:31:33 --> Pagination Class Initialized
INFO - 2023-06-05 04:31:33 --> Form Validation Class Initialized
INFO - 2023-06-05 04:31:33 --> Controller Class Initialized
INFO - 2023-06-05 04:31:33 --> Model Class Initialized
DEBUG - 2023-06-05 04:31:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 04:31:33 --> Model Class Initialized
DEBUG - 2023-06-05 04:31:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 04:31:33 --> Model Class Initialized
INFO - 2023-06-05 04:31:33 --> Model Class Initialized
INFO - 2023-06-05 04:31:33 --> Model Class Initialized
INFO - 2023-06-05 04:31:33 --> Model Class Initialized
DEBUG - 2023-06-05 04:31:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 04:31:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 04:31:33 --> Model Class Initialized
INFO - 2023-06-05 04:31:33 --> Model Class Initialized
INFO - 2023-06-05 04:31:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-05 04:31:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 04:31:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 04:31:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 04:31:33 --> Model Class Initialized
INFO - 2023-06-05 04:31:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 04:31:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 04:31:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 04:31:33 --> Final output sent to browser
DEBUG - 2023-06-05 04:31:33 --> Total execution time: 0.0806
ERROR - 2023-06-05 05:18:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:18:22 --> Config Class Initialized
INFO - 2023-06-05 05:18:22 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:18:22 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:18:22 --> Utf8 Class Initialized
INFO - 2023-06-05 05:18:22 --> URI Class Initialized
DEBUG - 2023-06-05 05:18:22 --> No URI present. Default controller set.
INFO - 2023-06-05 05:18:22 --> Router Class Initialized
INFO - 2023-06-05 05:18:22 --> Output Class Initialized
INFO - 2023-06-05 05:18:22 --> Security Class Initialized
DEBUG - 2023-06-05 05:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:18:22 --> Input Class Initialized
INFO - 2023-06-05 05:18:22 --> Language Class Initialized
INFO - 2023-06-05 05:18:22 --> Loader Class Initialized
INFO - 2023-06-05 05:18:22 --> Helper loaded: url_helper
INFO - 2023-06-05 05:18:22 --> Helper loaded: file_helper
INFO - 2023-06-05 05:18:22 --> Helper loaded: html_helper
INFO - 2023-06-05 05:18:22 --> Helper loaded: text_helper
INFO - 2023-06-05 05:18:22 --> Helper loaded: form_helper
INFO - 2023-06-05 05:18:22 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:18:22 --> Helper loaded: security_helper
INFO - 2023-06-05 05:18:22 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:18:22 --> Database Driver Class Initialized
INFO - 2023-06-05 05:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:18:22 --> Parser Class Initialized
INFO - 2023-06-05 05:18:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:18:22 --> Pagination Class Initialized
INFO - 2023-06-05 05:18:22 --> Form Validation Class Initialized
INFO - 2023-06-05 05:18:22 --> Controller Class Initialized
INFO - 2023-06-05 05:18:22 --> Model Class Initialized
DEBUG - 2023-06-05 05:18:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-05 05:18:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:18:23 --> Config Class Initialized
INFO - 2023-06-05 05:18:23 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:18:23 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:18:23 --> Utf8 Class Initialized
INFO - 2023-06-05 05:18:23 --> URI Class Initialized
INFO - 2023-06-05 05:18:23 --> Router Class Initialized
INFO - 2023-06-05 05:18:23 --> Output Class Initialized
INFO - 2023-06-05 05:18:23 --> Security Class Initialized
DEBUG - 2023-06-05 05:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:18:23 --> Input Class Initialized
INFO - 2023-06-05 05:18:23 --> Language Class Initialized
INFO - 2023-06-05 05:18:23 --> Loader Class Initialized
INFO - 2023-06-05 05:18:23 --> Helper loaded: url_helper
INFO - 2023-06-05 05:18:23 --> Helper loaded: file_helper
INFO - 2023-06-05 05:18:23 --> Helper loaded: html_helper
INFO - 2023-06-05 05:18:23 --> Helper loaded: text_helper
INFO - 2023-06-05 05:18:23 --> Helper loaded: form_helper
INFO - 2023-06-05 05:18:23 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:18:23 --> Helper loaded: security_helper
INFO - 2023-06-05 05:18:23 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:18:23 --> Database Driver Class Initialized
INFO - 2023-06-05 05:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:18:23 --> Parser Class Initialized
INFO - 2023-06-05 05:18:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:18:23 --> Pagination Class Initialized
INFO - 2023-06-05 05:18:23 --> Form Validation Class Initialized
INFO - 2023-06-05 05:18:23 --> Controller Class Initialized
INFO - 2023-06-05 05:18:23 --> Model Class Initialized
DEBUG - 2023-06-05 05:18:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:18:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-05 05:18:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:18:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 05:18:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 05:18:23 --> Model Class Initialized
INFO - 2023-06-05 05:18:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 05:18:23 --> Final output sent to browser
DEBUG - 2023-06-05 05:18:23 --> Total execution time: 0.0290
ERROR - 2023-06-05 05:18:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:18:27 --> Config Class Initialized
INFO - 2023-06-05 05:18:27 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:18:27 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:18:27 --> Utf8 Class Initialized
INFO - 2023-06-05 05:18:27 --> URI Class Initialized
INFO - 2023-06-05 05:18:27 --> Router Class Initialized
INFO - 2023-06-05 05:18:27 --> Output Class Initialized
INFO - 2023-06-05 05:18:27 --> Security Class Initialized
DEBUG - 2023-06-05 05:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:18:27 --> Input Class Initialized
INFO - 2023-06-05 05:18:27 --> Language Class Initialized
INFO - 2023-06-05 05:18:27 --> Loader Class Initialized
INFO - 2023-06-05 05:18:27 --> Helper loaded: url_helper
INFO - 2023-06-05 05:18:27 --> Helper loaded: file_helper
INFO - 2023-06-05 05:18:27 --> Helper loaded: html_helper
INFO - 2023-06-05 05:18:27 --> Helper loaded: text_helper
INFO - 2023-06-05 05:18:27 --> Helper loaded: form_helper
INFO - 2023-06-05 05:18:27 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:18:27 --> Helper loaded: security_helper
INFO - 2023-06-05 05:18:27 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:18:27 --> Database Driver Class Initialized
INFO - 2023-06-05 05:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:18:27 --> Parser Class Initialized
INFO - 2023-06-05 05:18:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:18:27 --> Pagination Class Initialized
INFO - 2023-06-05 05:18:27 --> Form Validation Class Initialized
INFO - 2023-06-05 05:18:27 --> Controller Class Initialized
INFO - 2023-06-05 05:18:27 --> Model Class Initialized
DEBUG - 2023-06-05 05:18:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:18:27 --> Model Class Initialized
INFO - 2023-06-05 05:18:27 --> Final output sent to browser
DEBUG - 2023-06-05 05:18:27 --> Total execution time: 0.0173
ERROR - 2023-06-05 05:18:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:18:28 --> Config Class Initialized
INFO - 2023-06-05 05:18:28 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:18:28 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:18:28 --> Utf8 Class Initialized
INFO - 2023-06-05 05:18:28 --> URI Class Initialized
DEBUG - 2023-06-05 05:18:28 --> No URI present. Default controller set.
INFO - 2023-06-05 05:18:28 --> Router Class Initialized
INFO - 2023-06-05 05:18:28 --> Output Class Initialized
INFO - 2023-06-05 05:18:28 --> Security Class Initialized
DEBUG - 2023-06-05 05:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:18:28 --> Input Class Initialized
INFO - 2023-06-05 05:18:28 --> Language Class Initialized
INFO - 2023-06-05 05:18:28 --> Loader Class Initialized
INFO - 2023-06-05 05:18:28 --> Helper loaded: url_helper
INFO - 2023-06-05 05:18:28 --> Helper loaded: file_helper
INFO - 2023-06-05 05:18:28 --> Helper loaded: html_helper
INFO - 2023-06-05 05:18:28 --> Helper loaded: text_helper
INFO - 2023-06-05 05:18:28 --> Helper loaded: form_helper
INFO - 2023-06-05 05:18:28 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:18:28 --> Helper loaded: security_helper
INFO - 2023-06-05 05:18:28 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:18:28 --> Database Driver Class Initialized
INFO - 2023-06-05 05:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:18:28 --> Parser Class Initialized
INFO - 2023-06-05 05:18:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:18:28 --> Pagination Class Initialized
INFO - 2023-06-05 05:18:28 --> Form Validation Class Initialized
INFO - 2023-06-05 05:18:28 --> Controller Class Initialized
INFO - 2023-06-05 05:18:28 --> Model Class Initialized
DEBUG - 2023-06-05 05:18:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:18:28 --> Model Class Initialized
DEBUG - 2023-06-05 05:18:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:18:28 --> Model Class Initialized
INFO - 2023-06-05 05:18:28 --> Model Class Initialized
INFO - 2023-06-05 05:18:28 --> Model Class Initialized
INFO - 2023-06-05 05:18:28 --> Model Class Initialized
DEBUG - 2023-06-05 05:18:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:18:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:18:28 --> Model Class Initialized
INFO - 2023-06-05 05:18:28 --> Model Class Initialized
INFO - 2023-06-05 05:18:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-05 05:18:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:18:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 05:18:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 05:18:28 --> Model Class Initialized
INFO - 2023-06-05 05:18:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 05:18:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 05:18:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 05:18:28 --> Final output sent to browser
DEBUG - 2023-06-05 05:18:28 --> Total execution time: 0.1728
ERROR - 2023-06-05 05:18:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:18:29 --> Config Class Initialized
INFO - 2023-06-05 05:18:29 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:18:29 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:18:29 --> Utf8 Class Initialized
INFO - 2023-06-05 05:18:29 --> URI Class Initialized
INFO - 2023-06-05 05:18:29 --> Router Class Initialized
INFO - 2023-06-05 05:18:29 --> Output Class Initialized
INFO - 2023-06-05 05:18:29 --> Security Class Initialized
DEBUG - 2023-06-05 05:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:18:29 --> Input Class Initialized
INFO - 2023-06-05 05:18:29 --> Language Class Initialized
INFO - 2023-06-05 05:18:29 --> Loader Class Initialized
INFO - 2023-06-05 05:18:29 --> Helper loaded: url_helper
INFO - 2023-06-05 05:18:29 --> Helper loaded: file_helper
INFO - 2023-06-05 05:18:29 --> Helper loaded: html_helper
INFO - 2023-06-05 05:18:29 --> Helper loaded: text_helper
INFO - 2023-06-05 05:18:29 --> Helper loaded: form_helper
INFO - 2023-06-05 05:18:29 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:18:29 --> Helper loaded: security_helper
INFO - 2023-06-05 05:18:29 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:18:29 --> Database Driver Class Initialized
INFO - 2023-06-05 05:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:18:29 --> Parser Class Initialized
INFO - 2023-06-05 05:18:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:18:29 --> Pagination Class Initialized
INFO - 2023-06-05 05:18:29 --> Form Validation Class Initialized
INFO - 2023-06-05 05:18:29 --> Controller Class Initialized
DEBUG - 2023-06-05 05:18:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:18:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:18:29 --> Model Class Initialized
INFO - 2023-06-05 05:18:29 --> Final output sent to browser
DEBUG - 2023-06-05 05:18:29 --> Total execution time: 0.0167
ERROR - 2023-06-05 05:18:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:18:38 --> Config Class Initialized
INFO - 2023-06-05 05:18:38 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:18:38 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:18:38 --> Utf8 Class Initialized
INFO - 2023-06-05 05:18:38 --> URI Class Initialized
INFO - 2023-06-05 05:18:38 --> Router Class Initialized
INFO - 2023-06-05 05:18:38 --> Output Class Initialized
INFO - 2023-06-05 05:18:38 --> Security Class Initialized
DEBUG - 2023-06-05 05:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:18:38 --> Input Class Initialized
INFO - 2023-06-05 05:18:38 --> Language Class Initialized
INFO - 2023-06-05 05:18:38 --> Loader Class Initialized
INFO - 2023-06-05 05:18:38 --> Helper loaded: url_helper
INFO - 2023-06-05 05:18:38 --> Helper loaded: file_helper
INFO - 2023-06-05 05:18:38 --> Helper loaded: html_helper
INFO - 2023-06-05 05:18:38 --> Helper loaded: text_helper
INFO - 2023-06-05 05:18:38 --> Helper loaded: form_helper
INFO - 2023-06-05 05:18:38 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:18:38 --> Helper loaded: security_helper
INFO - 2023-06-05 05:18:38 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:18:38 --> Database Driver Class Initialized
INFO - 2023-06-05 05:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:18:38 --> Parser Class Initialized
INFO - 2023-06-05 05:18:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:18:38 --> Pagination Class Initialized
INFO - 2023-06-05 05:18:38 --> Form Validation Class Initialized
INFO - 2023-06-05 05:18:38 --> Controller Class Initialized
INFO - 2023-06-05 05:18:38 --> Model Class Initialized
DEBUG - 2023-06-05 05:18:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:18:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:18:38 --> Model Class Initialized
DEBUG - 2023-06-05 05:18:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:18:38 --> Model Class Initialized
INFO - 2023-06-05 05:18:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-05 05:18:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:18:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 05:18:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 05:18:38 --> Model Class Initialized
INFO - 2023-06-05 05:18:38 --> Model Class Initialized
INFO - 2023-06-05 05:18:38 --> Model Class Initialized
INFO - 2023-06-05 05:18:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 05:18:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 05:18:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 05:18:38 --> Final output sent to browser
DEBUG - 2023-06-05 05:18:38 --> Total execution time: 0.1330
ERROR - 2023-06-05 05:18:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:18:39 --> Config Class Initialized
INFO - 2023-06-05 05:18:39 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:18:39 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:18:39 --> Utf8 Class Initialized
INFO - 2023-06-05 05:18:39 --> URI Class Initialized
INFO - 2023-06-05 05:18:39 --> Router Class Initialized
INFO - 2023-06-05 05:18:39 --> Output Class Initialized
INFO - 2023-06-05 05:18:39 --> Security Class Initialized
DEBUG - 2023-06-05 05:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:18:39 --> Input Class Initialized
INFO - 2023-06-05 05:18:39 --> Language Class Initialized
INFO - 2023-06-05 05:18:39 --> Loader Class Initialized
INFO - 2023-06-05 05:18:39 --> Helper loaded: url_helper
INFO - 2023-06-05 05:18:39 --> Helper loaded: file_helper
INFO - 2023-06-05 05:18:39 --> Helper loaded: html_helper
INFO - 2023-06-05 05:18:39 --> Helper loaded: text_helper
INFO - 2023-06-05 05:18:39 --> Helper loaded: form_helper
INFO - 2023-06-05 05:18:39 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:18:39 --> Helper loaded: security_helper
INFO - 2023-06-05 05:18:39 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:18:39 --> Database Driver Class Initialized
INFO - 2023-06-05 05:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:18:39 --> Parser Class Initialized
INFO - 2023-06-05 05:18:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:18:39 --> Pagination Class Initialized
INFO - 2023-06-05 05:18:39 --> Form Validation Class Initialized
INFO - 2023-06-05 05:18:39 --> Controller Class Initialized
INFO - 2023-06-05 05:18:39 --> Model Class Initialized
DEBUG - 2023-06-05 05:18:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:18:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:18:39 --> Model Class Initialized
DEBUG - 2023-06-05 05:18:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:18:39 --> Model Class Initialized
INFO - 2023-06-05 05:18:39 --> Final output sent to browser
DEBUG - 2023-06-05 05:18:39 --> Total execution time: 0.0579
ERROR - 2023-06-05 05:19:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:19:00 --> Config Class Initialized
INFO - 2023-06-05 05:19:00 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:19:00 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:19:00 --> Utf8 Class Initialized
INFO - 2023-06-05 05:19:00 --> URI Class Initialized
INFO - 2023-06-05 05:19:00 --> Router Class Initialized
INFO - 2023-06-05 05:19:00 --> Output Class Initialized
INFO - 2023-06-05 05:19:00 --> Security Class Initialized
DEBUG - 2023-06-05 05:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:19:00 --> Input Class Initialized
INFO - 2023-06-05 05:19:00 --> Language Class Initialized
INFO - 2023-06-05 05:19:00 --> Loader Class Initialized
INFO - 2023-06-05 05:19:00 --> Helper loaded: url_helper
INFO - 2023-06-05 05:19:00 --> Helper loaded: file_helper
INFO - 2023-06-05 05:19:00 --> Helper loaded: html_helper
INFO - 2023-06-05 05:19:00 --> Helper loaded: text_helper
INFO - 2023-06-05 05:19:00 --> Helper loaded: form_helper
INFO - 2023-06-05 05:19:00 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:19:00 --> Helper loaded: security_helper
INFO - 2023-06-05 05:19:00 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:19:00 --> Database Driver Class Initialized
INFO - 2023-06-05 05:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:19:00 --> Parser Class Initialized
INFO - 2023-06-05 05:19:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:19:00 --> Pagination Class Initialized
INFO - 2023-06-05 05:19:00 --> Form Validation Class Initialized
INFO - 2023-06-05 05:19:00 --> Controller Class Initialized
INFO - 2023-06-05 05:19:00 --> Model Class Initialized
DEBUG - 2023-06-05 05:19:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:19:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:19:00 --> Model Class Initialized
DEBUG - 2023-06-05 05:19:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:19:00 --> Model Class Initialized
INFO - 2023-06-05 05:19:00 --> Final output sent to browser
DEBUG - 2023-06-05 05:19:00 --> Total execution time: 0.0588
ERROR - 2023-06-05 05:19:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:19:13 --> Config Class Initialized
INFO - 2023-06-05 05:19:13 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:19:13 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:19:13 --> Utf8 Class Initialized
INFO - 2023-06-05 05:19:13 --> URI Class Initialized
INFO - 2023-06-05 05:19:13 --> Router Class Initialized
INFO - 2023-06-05 05:19:13 --> Output Class Initialized
INFO - 2023-06-05 05:19:13 --> Security Class Initialized
DEBUG - 2023-06-05 05:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:19:13 --> Input Class Initialized
INFO - 2023-06-05 05:19:13 --> Language Class Initialized
INFO - 2023-06-05 05:19:13 --> Loader Class Initialized
INFO - 2023-06-05 05:19:13 --> Helper loaded: url_helper
INFO - 2023-06-05 05:19:13 --> Helper loaded: file_helper
INFO - 2023-06-05 05:19:13 --> Helper loaded: html_helper
INFO - 2023-06-05 05:19:13 --> Helper loaded: text_helper
INFO - 2023-06-05 05:19:13 --> Helper loaded: form_helper
INFO - 2023-06-05 05:19:13 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:19:13 --> Helper loaded: security_helper
INFO - 2023-06-05 05:19:13 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:19:13 --> Database Driver Class Initialized
INFO - 2023-06-05 05:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:19:13 --> Parser Class Initialized
INFO - 2023-06-05 05:19:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:19:13 --> Pagination Class Initialized
INFO - 2023-06-05 05:19:13 --> Form Validation Class Initialized
INFO - 2023-06-05 05:19:13 --> Controller Class Initialized
INFO - 2023-06-05 05:19:13 --> Model Class Initialized
DEBUG - 2023-06-05 05:19:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:19:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:19:13 --> Model Class Initialized
DEBUG - 2023-06-05 05:19:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:19:13 --> Model Class Initialized
INFO - 2023-06-05 05:19:13 --> Final output sent to browser
DEBUG - 2023-06-05 05:19:13 --> Total execution time: 0.2277
ERROR - 2023-06-05 05:22:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:22:33 --> Config Class Initialized
INFO - 2023-06-05 05:22:33 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:22:33 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:22:33 --> Utf8 Class Initialized
INFO - 2023-06-05 05:22:33 --> URI Class Initialized
INFO - 2023-06-05 05:22:33 --> Router Class Initialized
INFO - 2023-06-05 05:22:33 --> Output Class Initialized
INFO - 2023-06-05 05:22:33 --> Security Class Initialized
DEBUG - 2023-06-05 05:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:22:33 --> Input Class Initialized
INFO - 2023-06-05 05:22:33 --> Language Class Initialized
INFO - 2023-06-05 05:22:33 --> Loader Class Initialized
INFO - 2023-06-05 05:22:33 --> Helper loaded: url_helper
INFO - 2023-06-05 05:22:33 --> Helper loaded: file_helper
INFO - 2023-06-05 05:22:33 --> Helper loaded: html_helper
INFO - 2023-06-05 05:22:33 --> Helper loaded: text_helper
INFO - 2023-06-05 05:22:33 --> Helper loaded: form_helper
INFO - 2023-06-05 05:22:33 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:22:33 --> Helper loaded: security_helper
INFO - 2023-06-05 05:22:33 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:22:33 --> Database Driver Class Initialized
INFO - 2023-06-05 05:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:22:33 --> Parser Class Initialized
INFO - 2023-06-05 05:22:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:22:33 --> Pagination Class Initialized
INFO - 2023-06-05 05:22:33 --> Form Validation Class Initialized
INFO - 2023-06-05 05:22:33 --> Controller Class Initialized
INFO - 2023-06-05 05:22:33 --> Model Class Initialized
DEBUG - 2023-06-05 05:22:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:22:33 --> Model Class Initialized
DEBUG - 2023-06-05 05:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:22:33 --> Model Class Initialized
INFO - 2023-06-05 05:22:33 --> Final output sent to browser
DEBUG - 2023-06-05 05:22:33 --> Total execution time: 0.2213
ERROR - 2023-06-05 05:24:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:24:14 --> Config Class Initialized
INFO - 2023-06-05 05:24:14 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:24:14 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:24:14 --> Utf8 Class Initialized
INFO - 2023-06-05 05:24:14 --> URI Class Initialized
INFO - 2023-06-05 05:24:14 --> Router Class Initialized
INFO - 2023-06-05 05:24:14 --> Output Class Initialized
INFO - 2023-06-05 05:24:14 --> Security Class Initialized
DEBUG - 2023-06-05 05:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:24:14 --> Input Class Initialized
INFO - 2023-06-05 05:24:14 --> Language Class Initialized
INFO - 2023-06-05 05:24:14 --> Loader Class Initialized
INFO - 2023-06-05 05:24:14 --> Helper loaded: url_helper
INFO - 2023-06-05 05:24:14 --> Helper loaded: file_helper
INFO - 2023-06-05 05:24:14 --> Helper loaded: html_helper
INFO - 2023-06-05 05:24:14 --> Helper loaded: text_helper
INFO - 2023-06-05 05:24:14 --> Helper loaded: form_helper
INFO - 2023-06-05 05:24:14 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:24:14 --> Helper loaded: security_helper
INFO - 2023-06-05 05:24:14 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:24:14 --> Database Driver Class Initialized
INFO - 2023-06-05 05:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:24:14 --> Parser Class Initialized
INFO - 2023-06-05 05:24:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:24:14 --> Pagination Class Initialized
INFO - 2023-06-05 05:24:14 --> Form Validation Class Initialized
INFO - 2023-06-05 05:24:14 --> Controller Class Initialized
DEBUG - 2023-06-05 05:24:14 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:24:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:24:14 --> Model Class Initialized
DEBUG - 2023-06-05 05:24:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:24:14 --> Model Class Initialized
DEBUG - 2023-06-05 05:24:14 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:24:14 --> Model Class Initialized
INFO - 2023-06-05 05:24:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-06-05 05:24:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:24:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 05:24:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 05:24:14 --> Model Class Initialized
INFO - 2023-06-05 05:24:14 --> Model Class Initialized
INFO - 2023-06-05 05:24:14 --> Model Class Initialized
INFO - 2023-06-05 05:24:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 05:24:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 05:24:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 05:24:14 --> Final output sent to browser
DEBUG - 2023-06-05 05:24:14 --> Total execution time: 0.1444
ERROR - 2023-06-05 05:24:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:24:15 --> Config Class Initialized
INFO - 2023-06-05 05:24:15 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:24:15 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:24:15 --> Utf8 Class Initialized
INFO - 2023-06-05 05:24:15 --> URI Class Initialized
INFO - 2023-06-05 05:24:15 --> Router Class Initialized
INFO - 2023-06-05 05:24:15 --> Output Class Initialized
INFO - 2023-06-05 05:24:15 --> Security Class Initialized
DEBUG - 2023-06-05 05:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:24:15 --> Input Class Initialized
INFO - 2023-06-05 05:24:15 --> Language Class Initialized
INFO - 2023-06-05 05:24:15 --> Loader Class Initialized
INFO - 2023-06-05 05:24:15 --> Helper loaded: url_helper
INFO - 2023-06-05 05:24:15 --> Helper loaded: file_helper
INFO - 2023-06-05 05:24:15 --> Helper loaded: html_helper
INFO - 2023-06-05 05:24:15 --> Helper loaded: text_helper
INFO - 2023-06-05 05:24:15 --> Helper loaded: form_helper
INFO - 2023-06-05 05:24:15 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:24:15 --> Helper loaded: security_helper
INFO - 2023-06-05 05:24:15 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:24:15 --> Database Driver Class Initialized
INFO - 2023-06-05 05:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:24:15 --> Parser Class Initialized
INFO - 2023-06-05 05:24:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:24:15 --> Pagination Class Initialized
INFO - 2023-06-05 05:24:15 --> Form Validation Class Initialized
INFO - 2023-06-05 05:24:15 --> Controller Class Initialized
DEBUG - 2023-06-05 05:24:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:24:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:24:15 --> Model Class Initialized
DEBUG - 2023-06-05 05:24:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:24:15 --> Model Class Initialized
INFO - 2023-06-05 05:24:15 --> Final output sent to browser
DEBUG - 2023-06-05 05:24:15 --> Total execution time: 0.0331
ERROR - 2023-06-05 05:24:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:24:22 --> Config Class Initialized
INFO - 2023-06-05 05:24:22 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:24:22 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:24:22 --> Utf8 Class Initialized
INFO - 2023-06-05 05:24:22 --> URI Class Initialized
INFO - 2023-06-05 05:24:22 --> Router Class Initialized
INFO - 2023-06-05 05:24:22 --> Output Class Initialized
INFO - 2023-06-05 05:24:22 --> Security Class Initialized
DEBUG - 2023-06-05 05:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:24:22 --> Input Class Initialized
INFO - 2023-06-05 05:24:22 --> Language Class Initialized
INFO - 2023-06-05 05:24:22 --> Loader Class Initialized
INFO - 2023-06-05 05:24:22 --> Helper loaded: url_helper
INFO - 2023-06-05 05:24:22 --> Helper loaded: file_helper
INFO - 2023-06-05 05:24:22 --> Helper loaded: html_helper
INFO - 2023-06-05 05:24:22 --> Helper loaded: text_helper
INFO - 2023-06-05 05:24:22 --> Helper loaded: form_helper
INFO - 2023-06-05 05:24:22 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:24:22 --> Helper loaded: security_helper
INFO - 2023-06-05 05:24:22 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:24:22 --> Database Driver Class Initialized
INFO - 2023-06-05 05:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:24:22 --> Parser Class Initialized
INFO - 2023-06-05 05:24:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:24:22 --> Pagination Class Initialized
INFO - 2023-06-05 05:24:22 --> Form Validation Class Initialized
INFO - 2023-06-05 05:24:22 --> Controller Class Initialized
INFO - 2023-06-05 05:24:22 --> Model Class Initialized
DEBUG - 2023-06-05 05:24:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:24:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:24:22 --> Model Class Initialized
INFO - 2023-06-05 05:24:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-05 05:24:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:24:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 05:24:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 05:24:22 --> Model Class Initialized
INFO - 2023-06-05 05:24:22 --> Model Class Initialized
INFO - 2023-06-05 05:24:22 --> Model Class Initialized
INFO - 2023-06-05 05:24:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 05:24:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 05:24:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 05:24:22 --> Final output sent to browser
DEBUG - 2023-06-05 05:24:22 --> Total execution time: 0.1434
ERROR - 2023-06-05 05:24:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:24:23 --> Config Class Initialized
INFO - 2023-06-05 05:24:23 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:24:23 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:24:23 --> Utf8 Class Initialized
INFO - 2023-06-05 05:24:23 --> URI Class Initialized
INFO - 2023-06-05 05:24:23 --> Router Class Initialized
INFO - 2023-06-05 05:24:23 --> Output Class Initialized
INFO - 2023-06-05 05:24:23 --> Security Class Initialized
DEBUG - 2023-06-05 05:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:24:23 --> Input Class Initialized
INFO - 2023-06-05 05:24:23 --> Language Class Initialized
INFO - 2023-06-05 05:24:23 --> Loader Class Initialized
INFO - 2023-06-05 05:24:23 --> Helper loaded: url_helper
INFO - 2023-06-05 05:24:23 --> Helper loaded: file_helper
INFO - 2023-06-05 05:24:23 --> Helper loaded: html_helper
INFO - 2023-06-05 05:24:23 --> Helper loaded: text_helper
INFO - 2023-06-05 05:24:23 --> Helper loaded: form_helper
INFO - 2023-06-05 05:24:23 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:24:23 --> Helper loaded: security_helper
INFO - 2023-06-05 05:24:23 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:24:23 --> Database Driver Class Initialized
INFO - 2023-06-05 05:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:24:23 --> Parser Class Initialized
INFO - 2023-06-05 05:24:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:24:23 --> Pagination Class Initialized
INFO - 2023-06-05 05:24:23 --> Form Validation Class Initialized
INFO - 2023-06-05 05:24:23 --> Controller Class Initialized
INFO - 2023-06-05 05:24:23 --> Model Class Initialized
DEBUG - 2023-06-05 05:24:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:24:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:24:23 --> Model Class Initialized
INFO - 2023-06-05 05:24:23 --> Final output sent to browser
DEBUG - 2023-06-05 05:24:23 --> Total execution time: 0.0324
ERROR - 2023-06-05 05:24:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:24:30 --> Config Class Initialized
INFO - 2023-06-05 05:24:30 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:24:30 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:24:30 --> Utf8 Class Initialized
INFO - 2023-06-05 05:24:30 --> URI Class Initialized
INFO - 2023-06-05 05:24:30 --> Router Class Initialized
INFO - 2023-06-05 05:24:30 --> Output Class Initialized
INFO - 2023-06-05 05:24:30 --> Security Class Initialized
DEBUG - 2023-06-05 05:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:24:30 --> Input Class Initialized
INFO - 2023-06-05 05:24:30 --> Language Class Initialized
INFO - 2023-06-05 05:24:30 --> Loader Class Initialized
INFO - 2023-06-05 05:24:30 --> Helper loaded: url_helper
INFO - 2023-06-05 05:24:30 --> Helper loaded: file_helper
INFO - 2023-06-05 05:24:30 --> Helper loaded: html_helper
INFO - 2023-06-05 05:24:30 --> Helper loaded: text_helper
INFO - 2023-06-05 05:24:30 --> Helper loaded: form_helper
INFO - 2023-06-05 05:24:30 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:24:30 --> Helper loaded: security_helper
INFO - 2023-06-05 05:24:30 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:24:30 --> Database Driver Class Initialized
INFO - 2023-06-05 05:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:24:30 --> Parser Class Initialized
INFO - 2023-06-05 05:24:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:24:30 --> Pagination Class Initialized
INFO - 2023-06-05 05:24:30 --> Form Validation Class Initialized
INFO - 2023-06-05 05:24:30 --> Controller Class Initialized
INFO - 2023-06-05 05:24:30 --> Model Class Initialized
DEBUG - 2023-06-05 05:24:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:24:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:24:30 --> Model Class Initialized
INFO - 2023-06-05 05:24:30 --> Final output sent to browser
DEBUG - 2023-06-05 05:24:30 --> Total execution time: 0.0382
ERROR - 2023-06-05 05:25:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:25:07 --> Config Class Initialized
INFO - 2023-06-05 05:25:07 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:25:07 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:25:07 --> Utf8 Class Initialized
INFO - 2023-06-05 05:25:07 --> URI Class Initialized
INFO - 2023-06-05 05:25:07 --> Router Class Initialized
INFO - 2023-06-05 05:25:07 --> Output Class Initialized
INFO - 2023-06-05 05:25:07 --> Security Class Initialized
DEBUG - 2023-06-05 05:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:25:07 --> Input Class Initialized
INFO - 2023-06-05 05:25:07 --> Language Class Initialized
INFO - 2023-06-05 05:25:07 --> Loader Class Initialized
INFO - 2023-06-05 05:25:07 --> Helper loaded: url_helper
INFO - 2023-06-05 05:25:07 --> Helper loaded: file_helper
INFO - 2023-06-05 05:25:07 --> Helper loaded: html_helper
INFO - 2023-06-05 05:25:07 --> Helper loaded: text_helper
INFO - 2023-06-05 05:25:07 --> Helper loaded: form_helper
INFO - 2023-06-05 05:25:07 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:25:07 --> Helper loaded: security_helper
INFO - 2023-06-05 05:25:07 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:25:07 --> Database Driver Class Initialized
INFO - 2023-06-05 05:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:25:07 --> Parser Class Initialized
INFO - 2023-06-05 05:25:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:25:07 --> Pagination Class Initialized
INFO - 2023-06-05 05:25:07 --> Form Validation Class Initialized
INFO - 2023-06-05 05:25:07 --> Controller Class Initialized
INFO - 2023-06-05 05:25:07 --> Model Class Initialized
DEBUG - 2023-06-05 05:25:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:25:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:25:07 --> Model Class Initialized
DEBUG - 2023-06-05 05:25:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:25:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-06-05 05:25:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:25:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 05:25:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 05:25:07 --> Model Class Initialized
INFO - 2023-06-05 05:25:07 --> Model Class Initialized
INFO - 2023-06-05 05:25:07 --> Model Class Initialized
INFO - 2023-06-05 05:25:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 05:25:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 05:25:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 05:25:07 --> Final output sent to browser
DEBUG - 2023-06-05 05:25:07 --> Total execution time: 0.1302
ERROR - 2023-06-05 05:25:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:25:24 --> Config Class Initialized
INFO - 2023-06-05 05:25:24 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:25:24 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:25:24 --> Utf8 Class Initialized
INFO - 2023-06-05 05:25:24 --> URI Class Initialized
INFO - 2023-06-05 05:25:24 --> Router Class Initialized
INFO - 2023-06-05 05:25:24 --> Output Class Initialized
INFO - 2023-06-05 05:25:24 --> Security Class Initialized
DEBUG - 2023-06-05 05:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:25:24 --> Input Class Initialized
INFO - 2023-06-05 05:25:24 --> Language Class Initialized
INFO - 2023-06-05 05:25:24 --> Loader Class Initialized
INFO - 2023-06-05 05:25:24 --> Helper loaded: url_helper
INFO - 2023-06-05 05:25:24 --> Helper loaded: file_helper
INFO - 2023-06-05 05:25:24 --> Helper loaded: html_helper
INFO - 2023-06-05 05:25:24 --> Helper loaded: text_helper
INFO - 2023-06-05 05:25:24 --> Helper loaded: form_helper
INFO - 2023-06-05 05:25:24 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:25:24 --> Helper loaded: security_helper
INFO - 2023-06-05 05:25:24 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:25:24 --> Database Driver Class Initialized
INFO - 2023-06-05 05:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:25:24 --> Parser Class Initialized
INFO - 2023-06-05 05:25:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:25:24 --> Pagination Class Initialized
INFO - 2023-06-05 05:25:24 --> Form Validation Class Initialized
INFO - 2023-06-05 05:25:24 --> Controller Class Initialized
INFO - 2023-06-05 05:25:24 --> Model Class Initialized
DEBUG - 2023-06-05 05:25:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:25:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:25:24 --> Model Class Initialized
INFO - 2023-06-05 05:25:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-05 05:25:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:25:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 05:25:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 05:25:24 --> Model Class Initialized
INFO - 2023-06-05 05:25:24 --> Model Class Initialized
INFO - 2023-06-05 05:25:24 --> Model Class Initialized
INFO - 2023-06-05 05:25:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 05:25:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 05:25:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 05:25:24 --> Final output sent to browser
DEBUG - 2023-06-05 05:25:24 --> Total execution time: 0.1428
ERROR - 2023-06-05 05:25:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:25:24 --> Config Class Initialized
INFO - 2023-06-05 05:25:24 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:25:24 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:25:24 --> Utf8 Class Initialized
INFO - 2023-06-05 05:25:24 --> URI Class Initialized
INFO - 2023-06-05 05:25:24 --> Router Class Initialized
INFO - 2023-06-05 05:25:24 --> Output Class Initialized
INFO - 2023-06-05 05:25:24 --> Security Class Initialized
DEBUG - 2023-06-05 05:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:25:24 --> Input Class Initialized
INFO - 2023-06-05 05:25:24 --> Language Class Initialized
INFO - 2023-06-05 05:25:24 --> Loader Class Initialized
INFO - 2023-06-05 05:25:24 --> Helper loaded: url_helper
INFO - 2023-06-05 05:25:24 --> Helper loaded: file_helper
INFO - 2023-06-05 05:25:24 --> Helper loaded: html_helper
INFO - 2023-06-05 05:25:24 --> Helper loaded: text_helper
INFO - 2023-06-05 05:25:24 --> Helper loaded: form_helper
INFO - 2023-06-05 05:25:24 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:25:24 --> Helper loaded: security_helper
INFO - 2023-06-05 05:25:24 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:25:24 --> Database Driver Class Initialized
INFO - 2023-06-05 05:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:25:24 --> Parser Class Initialized
INFO - 2023-06-05 05:25:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:25:24 --> Pagination Class Initialized
INFO - 2023-06-05 05:25:24 --> Form Validation Class Initialized
INFO - 2023-06-05 05:25:24 --> Controller Class Initialized
INFO - 2023-06-05 05:25:24 --> Model Class Initialized
DEBUG - 2023-06-05 05:25:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:25:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:25:24 --> Model Class Initialized
INFO - 2023-06-05 05:25:24 --> Final output sent to browser
DEBUG - 2023-06-05 05:25:24 --> Total execution time: 0.0308
ERROR - 2023-06-05 05:25:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:25:46 --> Config Class Initialized
INFO - 2023-06-05 05:25:46 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:25:46 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:25:46 --> Utf8 Class Initialized
INFO - 2023-06-05 05:25:46 --> URI Class Initialized
INFO - 2023-06-05 05:25:46 --> Router Class Initialized
INFO - 2023-06-05 05:25:46 --> Output Class Initialized
INFO - 2023-06-05 05:25:46 --> Security Class Initialized
DEBUG - 2023-06-05 05:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:25:46 --> Input Class Initialized
INFO - 2023-06-05 05:25:46 --> Language Class Initialized
INFO - 2023-06-05 05:25:46 --> Loader Class Initialized
INFO - 2023-06-05 05:25:46 --> Helper loaded: url_helper
INFO - 2023-06-05 05:25:46 --> Helper loaded: file_helper
INFO - 2023-06-05 05:25:46 --> Helper loaded: html_helper
INFO - 2023-06-05 05:25:46 --> Helper loaded: text_helper
INFO - 2023-06-05 05:25:46 --> Helper loaded: form_helper
INFO - 2023-06-05 05:25:46 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:25:46 --> Helper loaded: security_helper
INFO - 2023-06-05 05:25:46 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:25:46 --> Database Driver Class Initialized
INFO - 2023-06-05 05:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:25:46 --> Parser Class Initialized
INFO - 2023-06-05 05:25:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:25:46 --> Pagination Class Initialized
INFO - 2023-06-05 05:25:46 --> Form Validation Class Initialized
INFO - 2023-06-05 05:25:46 --> Controller Class Initialized
INFO - 2023-06-05 05:25:46 --> Model Class Initialized
DEBUG - 2023-06-05 05:25:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:25:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:25:46 --> Model Class Initialized
INFO - 2023-06-05 05:25:46 --> Final output sent to browser
DEBUG - 2023-06-05 05:25:46 --> Total execution time: 0.0431
ERROR - 2023-06-05 05:26:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:26:17 --> Config Class Initialized
INFO - 2023-06-05 05:26:17 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:26:17 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:26:17 --> Utf8 Class Initialized
INFO - 2023-06-05 05:26:17 --> URI Class Initialized
INFO - 2023-06-05 05:26:17 --> Router Class Initialized
INFO - 2023-06-05 05:26:17 --> Output Class Initialized
INFO - 2023-06-05 05:26:17 --> Security Class Initialized
DEBUG - 2023-06-05 05:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:26:17 --> Input Class Initialized
INFO - 2023-06-05 05:26:17 --> Language Class Initialized
INFO - 2023-06-05 05:26:17 --> Loader Class Initialized
INFO - 2023-06-05 05:26:17 --> Helper loaded: url_helper
INFO - 2023-06-05 05:26:17 --> Helper loaded: file_helper
INFO - 2023-06-05 05:26:17 --> Helper loaded: html_helper
INFO - 2023-06-05 05:26:17 --> Helper loaded: text_helper
INFO - 2023-06-05 05:26:17 --> Helper loaded: form_helper
INFO - 2023-06-05 05:26:17 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:26:17 --> Helper loaded: security_helper
INFO - 2023-06-05 05:26:17 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:26:17 --> Database Driver Class Initialized
INFO - 2023-06-05 05:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:26:17 --> Parser Class Initialized
INFO - 2023-06-05 05:26:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:26:17 --> Pagination Class Initialized
INFO - 2023-06-05 05:26:17 --> Form Validation Class Initialized
INFO - 2023-06-05 05:26:17 --> Controller Class Initialized
INFO - 2023-06-05 05:26:17 --> Model Class Initialized
DEBUG - 2023-06-05 05:26:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:26:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:26:17 --> Model Class Initialized
DEBUG - 2023-06-05 05:26:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:26:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-06-05 05:26:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:26:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 05:26:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 05:26:17 --> Model Class Initialized
INFO - 2023-06-05 05:26:17 --> Model Class Initialized
INFO - 2023-06-05 05:26:17 --> Model Class Initialized
INFO - 2023-06-05 05:26:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 05:26:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 05:26:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 05:26:17 --> Final output sent to browser
DEBUG - 2023-06-05 05:26:17 --> Total execution time: 0.1370
ERROR - 2023-06-05 05:26:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:26:28 --> Config Class Initialized
INFO - 2023-06-05 05:26:28 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:26:28 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:26:28 --> Utf8 Class Initialized
INFO - 2023-06-05 05:26:28 --> URI Class Initialized
INFO - 2023-06-05 05:26:28 --> Router Class Initialized
INFO - 2023-06-05 05:26:28 --> Output Class Initialized
INFO - 2023-06-05 05:26:28 --> Security Class Initialized
DEBUG - 2023-06-05 05:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:26:28 --> Input Class Initialized
INFO - 2023-06-05 05:26:28 --> Language Class Initialized
INFO - 2023-06-05 05:26:28 --> Loader Class Initialized
INFO - 2023-06-05 05:26:28 --> Helper loaded: url_helper
INFO - 2023-06-05 05:26:28 --> Helper loaded: file_helper
INFO - 2023-06-05 05:26:28 --> Helper loaded: html_helper
INFO - 2023-06-05 05:26:28 --> Helper loaded: text_helper
INFO - 2023-06-05 05:26:28 --> Helper loaded: form_helper
INFO - 2023-06-05 05:26:28 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:26:28 --> Helper loaded: security_helper
INFO - 2023-06-05 05:26:28 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:26:28 --> Database Driver Class Initialized
INFO - 2023-06-05 05:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:26:28 --> Parser Class Initialized
INFO - 2023-06-05 05:26:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:26:28 --> Pagination Class Initialized
INFO - 2023-06-05 05:26:28 --> Form Validation Class Initialized
INFO - 2023-06-05 05:26:28 --> Controller Class Initialized
INFO - 2023-06-05 05:26:28 --> Model Class Initialized
DEBUG - 2023-06-05 05:26:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:26:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:26:28 --> Model Class Initialized
INFO - 2023-06-05 05:26:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-05 05:26:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:26:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 05:26:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 05:26:28 --> Model Class Initialized
INFO - 2023-06-05 05:26:28 --> Model Class Initialized
INFO - 2023-06-05 05:26:28 --> Model Class Initialized
INFO - 2023-06-05 05:26:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 05:26:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 05:26:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 05:26:28 --> Final output sent to browser
DEBUG - 2023-06-05 05:26:28 --> Total execution time: 0.1349
ERROR - 2023-06-05 05:26:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:26:28 --> Config Class Initialized
INFO - 2023-06-05 05:26:28 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:26:28 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:26:28 --> Utf8 Class Initialized
INFO - 2023-06-05 05:26:28 --> URI Class Initialized
INFO - 2023-06-05 05:26:28 --> Router Class Initialized
INFO - 2023-06-05 05:26:28 --> Output Class Initialized
INFO - 2023-06-05 05:26:28 --> Security Class Initialized
DEBUG - 2023-06-05 05:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:26:28 --> Input Class Initialized
INFO - 2023-06-05 05:26:28 --> Language Class Initialized
INFO - 2023-06-05 05:26:28 --> Loader Class Initialized
INFO - 2023-06-05 05:26:28 --> Helper loaded: url_helper
INFO - 2023-06-05 05:26:28 --> Helper loaded: file_helper
INFO - 2023-06-05 05:26:28 --> Helper loaded: html_helper
INFO - 2023-06-05 05:26:28 --> Helper loaded: text_helper
INFO - 2023-06-05 05:26:28 --> Helper loaded: form_helper
INFO - 2023-06-05 05:26:28 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:26:28 --> Helper loaded: security_helper
INFO - 2023-06-05 05:26:28 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:26:28 --> Database Driver Class Initialized
INFO - 2023-06-05 05:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:26:28 --> Parser Class Initialized
INFO - 2023-06-05 05:26:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:26:28 --> Pagination Class Initialized
INFO - 2023-06-05 05:26:28 --> Form Validation Class Initialized
INFO - 2023-06-05 05:26:28 --> Controller Class Initialized
INFO - 2023-06-05 05:26:28 --> Model Class Initialized
DEBUG - 2023-06-05 05:26:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:26:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:26:28 --> Model Class Initialized
INFO - 2023-06-05 05:26:28 --> Final output sent to browser
DEBUG - 2023-06-05 05:26:28 --> Total execution time: 0.0290
ERROR - 2023-06-05 05:27:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:27:01 --> Config Class Initialized
INFO - 2023-06-05 05:27:01 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:27:01 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:27:01 --> Utf8 Class Initialized
INFO - 2023-06-05 05:27:01 --> URI Class Initialized
INFO - 2023-06-05 05:27:01 --> Router Class Initialized
INFO - 2023-06-05 05:27:01 --> Output Class Initialized
INFO - 2023-06-05 05:27:01 --> Security Class Initialized
DEBUG - 2023-06-05 05:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:27:01 --> Input Class Initialized
INFO - 2023-06-05 05:27:01 --> Language Class Initialized
INFO - 2023-06-05 05:27:01 --> Loader Class Initialized
INFO - 2023-06-05 05:27:01 --> Helper loaded: url_helper
INFO - 2023-06-05 05:27:01 --> Helper loaded: file_helper
INFO - 2023-06-05 05:27:01 --> Helper loaded: html_helper
INFO - 2023-06-05 05:27:01 --> Helper loaded: text_helper
INFO - 2023-06-05 05:27:01 --> Helper loaded: form_helper
INFO - 2023-06-05 05:27:01 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:27:01 --> Helper loaded: security_helper
INFO - 2023-06-05 05:27:01 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:27:01 --> Database Driver Class Initialized
INFO - 2023-06-05 05:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:27:01 --> Parser Class Initialized
INFO - 2023-06-05 05:27:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:27:01 --> Pagination Class Initialized
INFO - 2023-06-05 05:27:01 --> Form Validation Class Initialized
INFO - 2023-06-05 05:27:01 --> Controller Class Initialized
INFO - 2023-06-05 05:27:01 --> Model Class Initialized
DEBUG - 2023-06-05 05:27:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:27:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:27:01 --> Model Class Initialized
DEBUG - 2023-06-05 05:27:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:27:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-06-05 05:27:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:27:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 05:27:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 05:27:01 --> Model Class Initialized
INFO - 2023-06-05 05:27:01 --> Model Class Initialized
INFO - 2023-06-05 05:27:01 --> Model Class Initialized
INFO - 2023-06-05 05:27:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 05:27:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 05:27:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 05:27:01 --> Final output sent to browser
DEBUG - 2023-06-05 05:27:01 --> Total execution time: 0.1367
ERROR - 2023-06-05 05:27:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:27:05 --> Config Class Initialized
INFO - 2023-06-05 05:27:05 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:27:05 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:27:05 --> Utf8 Class Initialized
INFO - 2023-06-05 05:27:05 --> URI Class Initialized
INFO - 2023-06-05 05:27:05 --> Router Class Initialized
INFO - 2023-06-05 05:27:05 --> Output Class Initialized
INFO - 2023-06-05 05:27:05 --> Security Class Initialized
DEBUG - 2023-06-05 05:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:27:05 --> Input Class Initialized
INFO - 2023-06-05 05:27:05 --> Language Class Initialized
INFO - 2023-06-05 05:27:05 --> Loader Class Initialized
INFO - 2023-06-05 05:27:05 --> Helper loaded: url_helper
INFO - 2023-06-05 05:27:05 --> Helper loaded: file_helper
INFO - 2023-06-05 05:27:05 --> Helper loaded: html_helper
INFO - 2023-06-05 05:27:05 --> Helper loaded: text_helper
INFO - 2023-06-05 05:27:05 --> Helper loaded: form_helper
INFO - 2023-06-05 05:27:05 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:27:05 --> Helper loaded: security_helper
INFO - 2023-06-05 05:27:05 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:27:05 --> Database Driver Class Initialized
INFO - 2023-06-05 05:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:27:05 --> Parser Class Initialized
INFO - 2023-06-05 05:27:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:27:05 --> Pagination Class Initialized
INFO - 2023-06-05 05:27:05 --> Form Validation Class Initialized
INFO - 2023-06-05 05:27:05 --> Controller Class Initialized
INFO - 2023-06-05 05:27:05 --> Model Class Initialized
DEBUG - 2023-06-05 05:27:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:27:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:27:05 --> Model Class Initialized
INFO - 2023-06-05 05:27:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-05 05:27:05 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:27:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 05:27:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 05:27:05 --> Model Class Initialized
INFO - 2023-06-05 05:27:05 --> Model Class Initialized
INFO - 2023-06-05 05:27:05 --> Model Class Initialized
INFO - 2023-06-05 05:27:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 05:27:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 05:27:05 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 05:27:05 --> Final output sent to browser
DEBUG - 2023-06-05 05:27:05 --> Total execution time: 0.1397
ERROR - 2023-06-05 05:27:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:27:06 --> Config Class Initialized
INFO - 2023-06-05 05:27:06 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:27:06 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:27:06 --> Utf8 Class Initialized
INFO - 2023-06-05 05:27:06 --> URI Class Initialized
INFO - 2023-06-05 05:27:06 --> Router Class Initialized
INFO - 2023-06-05 05:27:06 --> Output Class Initialized
INFO - 2023-06-05 05:27:06 --> Security Class Initialized
DEBUG - 2023-06-05 05:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:27:06 --> Input Class Initialized
INFO - 2023-06-05 05:27:06 --> Language Class Initialized
INFO - 2023-06-05 05:27:06 --> Loader Class Initialized
INFO - 2023-06-05 05:27:06 --> Helper loaded: url_helper
INFO - 2023-06-05 05:27:06 --> Helper loaded: file_helper
INFO - 2023-06-05 05:27:06 --> Helper loaded: html_helper
INFO - 2023-06-05 05:27:06 --> Helper loaded: text_helper
INFO - 2023-06-05 05:27:06 --> Helper loaded: form_helper
INFO - 2023-06-05 05:27:06 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:27:06 --> Helper loaded: security_helper
INFO - 2023-06-05 05:27:06 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:27:06 --> Database Driver Class Initialized
INFO - 2023-06-05 05:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:27:06 --> Parser Class Initialized
INFO - 2023-06-05 05:27:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:27:06 --> Pagination Class Initialized
INFO - 2023-06-05 05:27:06 --> Form Validation Class Initialized
INFO - 2023-06-05 05:27:06 --> Controller Class Initialized
INFO - 2023-06-05 05:27:06 --> Model Class Initialized
DEBUG - 2023-06-05 05:27:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:27:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:27:06 --> Model Class Initialized
INFO - 2023-06-05 05:27:06 --> Final output sent to browser
DEBUG - 2023-06-05 05:27:06 --> Total execution time: 0.0307
ERROR - 2023-06-05 05:27:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:27:09 --> Config Class Initialized
INFO - 2023-06-05 05:27:09 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:27:09 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:27:09 --> Utf8 Class Initialized
INFO - 2023-06-05 05:27:09 --> URI Class Initialized
INFO - 2023-06-05 05:27:09 --> Router Class Initialized
INFO - 2023-06-05 05:27:09 --> Output Class Initialized
INFO - 2023-06-05 05:27:09 --> Security Class Initialized
DEBUG - 2023-06-05 05:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:27:09 --> Input Class Initialized
INFO - 2023-06-05 05:27:09 --> Language Class Initialized
INFO - 2023-06-05 05:27:09 --> Loader Class Initialized
INFO - 2023-06-05 05:27:09 --> Helper loaded: url_helper
INFO - 2023-06-05 05:27:09 --> Helper loaded: file_helper
INFO - 2023-06-05 05:27:09 --> Helper loaded: html_helper
INFO - 2023-06-05 05:27:09 --> Helper loaded: text_helper
INFO - 2023-06-05 05:27:09 --> Helper loaded: form_helper
INFO - 2023-06-05 05:27:09 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:27:09 --> Helper loaded: security_helper
INFO - 2023-06-05 05:27:09 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:27:09 --> Database Driver Class Initialized
INFO - 2023-06-05 05:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:27:09 --> Parser Class Initialized
INFO - 2023-06-05 05:27:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:27:09 --> Pagination Class Initialized
INFO - 2023-06-05 05:27:09 --> Form Validation Class Initialized
INFO - 2023-06-05 05:27:09 --> Controller Class Initialized
INFO - 2023-06-05 05:27:09 --> Model Class Initialized
DEBUG - 2023-06-05 05:27:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:27:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:27:09 --> Model Class Initialized
INFO - 2023-06-05 05:27:09 --> Final output sent to browser
DEBUG - 2023-06-05 05:27:09 --> Total execution time: 0.0407
ERROR - 2023-06-05 05:27:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:27:19 --> Config Class Initialized
INFO - 2023-06-05 05:27:19 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:27:19 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:27:19 --> Utf8 Class Initialized
INFO - 2023-06-05 05:27:19 --> URI Class Initialized
INFO - 2023-06-05 05:27:19 --> Router Class Initialized
INFO - 2023-06-05 05:27:19 --> Output Class Initialized
INFO - 2023-06-05 05:27:19 --> Security Class Initialized
DEBUG - 2023-06-05 05:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:27:19 --> Input Class Initialized
INFO - 2023-06-05 05:27:19 --> Language Class Initialized
INFO - 2023-06-05 05:27:19 --> Loader Class Initialized
INFO - 2023-06-05 05:27:19 --> Helper loaded: url_helper
INFO - 2023-06-05 05:27:19 --> Helper loaded: file_helper
INFO - 2023-06-05 05:27:19 --> Helper loaded: html_helper
INFO - 2023-06-05 05:27:19 --> Helper loaded: text_helper
INFO - 2023-06-05 05:27:19 --> Helper loaded: form_helper
INFO - 2023-06-05 05:27:19 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:27:19 --> Helper loaded: security_helper
INFO - 2023-06-05 05:27:19 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:27:19 --> Database Driver Class Initialized
INFO - 2023-06-05 05:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:27:19 --> Parser Class Initialized
INFO - 2023-06-05 05:27:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:27:19 --> Pagination Class Initialized
INFO - 2023-06-05 05:27:19 --> Form Validation Class Initialized
INFO - 2023-06-05 05:27:19 --> Controller Class Initialized
INFO - 2023-06-05 05:27:19 --> Model Class Initialized
DEBUG - 2023-06-05 05:27:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:27:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:27:19 --> Model Class Initialized
DEBUG - 2023-06-05 05:27:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:27:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-06-05 05:27:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:27:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 05:27:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 05:27:19 --> Model Class Initialized
INFO - 2023-06-05 05:27:19 --> Model Class Initialized
INFO - 2023-06-05 05:27:19 --> Model Class Initialized
INFO - 2023-06-05 05:27:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 05:27:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 05:27:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 05:27:19 --> Final output sent to browser
DEBUG - 2023-06-05 05:27:19 --> Total execution time: 0.1161
ERROR - 2023-06-05 05:27:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:27:33 --> Config Class Initialized
INFO - 2023-06-05 05:27:33 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:27:33 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:27:33 --> Utf8 Class Initialized
INFO - 2023-06-05 05:27:33 --> URI Class Initialized
INFO - 2023-06-05 05:27:33 --> Router Class Initialized
INFO - 2023-06-05 05:27:33 --> Output Class Initialized
INFO - 2023-06-05 05:27:33 --> Security Class Initialized
DEBUG - 2023-06-05 05:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:27:33 --> Input Class Initialized
INFO - 2023-06-05 05:27:33 --> Language Class Initialized
INFO - 2023-06-05 05:27:33 --> Loader Class Initialized
INFO - 2023-06-05 05:27:33 --> Helper loaded: url_helper
INFO - 2023-06-05 05:27:33 --> Helper loaded: file_helper
INFO - 2023-06-05 05:27:33 --> Helper loaded: html_helper
INFO - 2023-06-05 05:27:33 --> Helper loaded: text_helper
INFO - 2023-06-05 05:27:33 --> Helper loaded: form_helper
INFO - 2023-06-05 05:27:33 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:27:33 --> Helper loaded: security_helper
INFO - 2023-06-05 05:27:33 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:27:33 --> Database Driver Class Initialized
INFO - 2023-06-05 05:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:27:33 --> Parser Class Initialized
INFO - 2023-06-05 05:27:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:27:33 --> Pagination Class Initialized
INFO - 2023-06-05 05:27:33 --> Form Validation Class Initialized
INFO - 2023-06-05 05:27:33 --> Controller Class Initialized
INFO - 2023-06-05 05:27:33 --> Model Class Initialized
DEBUG - 2023-06-05 05:27:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:27:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:27:33 --> Model Class Initialized
INFO - 2023-06-05 05:27:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-05 05:27:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:27:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 05:27:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 05:27:33 --> Model Class Initialized
INFO - 2023-06-05 05:27:33 --> Model Class Initialized
INFO - 2023-06-05 05:27:33 --> Model Class Initialized
INFO - 2023-06-05 05:27:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 05:27:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 05:27:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 05:27:33 --> Final output sent to browser
DEBUG - 2023-06-05 05:27:33 --> Total execution time: 0.1342
ERROR - 2023-06-05 05:27:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:27:34 --> Config Class Initialized
INFO - 2023-06-05 05:27:34 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:27:34 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:27:34 --> Utf8 Class Initialized
INFO - 2023-06-05 05:27:34 --> URI Class Initialized
INFO - 2023-06-05 05:27:34 --> Router Class Initialized
INFO - 2023-06-05 05:27:34 --> Output Class Initialized
INFO - 2023-06-05 05:27:34 --> Security Class Initialized
DEBUG - 2023-06-05 05:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:27:34 --> Input Class Initialized
INFO - 2023-06-05 05:27:34 --> Language Class Initialized
INFO - 2023-06-05 05:27:34 --> Loader Class Initialized
INFO - 2023-06-05 05:27:34 --> Helper loaded: url_helper
INFO - 2023-06-05 05:27:34 --> Helper loaded: file_helper
INFO - 2023-06-05 05:27:34 --> Helper loaded: html_helper
INFO - 2023-06-05 05:27:34 --> Helper loaded: text_helper
INFO - 2023-06-05 05:27:34 --> Helper loaded: form_helper
INFO - 2023-06-05 05:27:34 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:27:34 --> Helper loaded: security_helper
INFO - 2023-06-05 05:27:34 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:27:34 --> Database Driver Class Initialized
INFO - 2023-06-05 05:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:27:34 --> Parser Class Initialized
INFO - 2023-06-05 05:27:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:27:34 --> Pagination Class Initialized
INFO - 2023-06-05 05:27:34 --> Form Validation Class Initialized
INFO - 2023-06-05 05:27:34 --> Controller Class Initialized
INFO - 2023-06-05 05:27:34 --> Model Class Initialized
DEBUG - 2023-06-05 05:27:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:27:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:27:34 --> Model Class Initialized
INFO - 2023-06-05 05:27:34 --> Final output sent to browser
DEBUG - 2023-06-05 05:27:34 --> Total execution time: 0.0283
ERROR - 2023-06-05 05:27:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:27:38 --> Config Class Initialized
INFO - 2023-06-05 05:27:38 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:27:38 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:27:38 --> Utf8 Class Initialized
INFO - 2023-06-05 05:27:38 --> URI Class Initialized
INFO - 2023-06-05 05:27:38 --> Router Class Initialized
INFO - 2023-06-05 05:27:38 --> Output Class Initialized
INFO - 2023-06-05 05:27:38 --> Security Class Initialized
DEBUG - 2023-06-05 05:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:27:38 --> Input Class Initialized
INFO - 2023-06-05 05:27:38 --> Language Class Initialized
INFO - 2023-06-05 05:27:38 --> Loader Class Initialized
INFO - 2023-06-05 05:27:38 --> Helper loaded: url_helper
INFO - 2023-06-05 05:27:38 --> Helper loaded: file_helper
INFO - 2023-06-05 05:27:38 --> Helper loaded: html_helper
INFO - 2023-06-05 05:27:38 --> Helper loaded: text_helper
INFO - 2023-06-05 05:27:38 --> Helper loaded: form_helper
INFO - 2023-06-05 05:27:38 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:27:38 --> Helper loaded: security_helper
INFO - 2023-06-05 05:27:38 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:27:38 --> Database Driver Class Initialized
INFO - 2023-06-05 05:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:27:38 --> Parser Class Initialized
INFO - 2023-06-05 05:27:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:27:38 --> Pagination Class Initialized
INFO - 2023-06-05 05:27:38 --> Form Validation Class Initialized
INFO - 2023-06-05 05:27:38 --> Controller Class Initialized
INFO - 2023-06-05 05:27:38 --> Model Class Initialized
DEBUG - 2023-06-05 05:27:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:27:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:27:38 --> Model Class Initialized
INFO - 2023-06-05 05:27:38 --> Final output sent to browser
DEBUG - 2023-06-05 05:27:38 --> Total execution time: 0.0405
ERROR - 2023-06-05 05:30:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:30:27 --> Config Class Initialized
INFO - 2023-06-05 05:30:27 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:30:27 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:30:27 --> Utf8 Class Initialized
INFO - 2023-06-05 05:30:27 --> URI Class Initialized
INFO - 2023-06-05 05:30:27 --> Router Class Initialized
INFO - 2023-06-05 05:30:27 --> Output Class Initialized
INFO - 2023-06-05 05:30:27 --> Security Class Initialized
DEBUG - 2023-06-05 05:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:30:27 --> Input Class Initialized
INFO - 2023-06-05 05:30:27 --> Language Class Initialized
INFO - 2023-06-05 05:30:27 --> Loader Class Initialized
INFO - 2023-06-05 05:30:27 --> Helper loaded: url_helper
INFO - 2023-06-05 05:30:27 --> Helper loaded: file_helper
INFO - 2023-06-05 05:30:27 --> Helper loaded: html_helper
INFO - 2023-06-05 05:30:27 --> Helper loaded: text_helper
INFO - 2023-06-05 05:30:27 --> Helper loaded: form_helper
INFO - 2023-06-05 05:30:27 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:30:27 --> Helper loaded: security_helper
INFO - 2023-06-05 05:30:27 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:30:27 --> Database Driver Class Initialized
INFO - 2023-06-05 05:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:30:27 --> Parser Class Initialized
INFO - 2023-06-05 05:30:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:30:27 --> Pagination Class Initialized
INFO - 2023-06-05 05:30:27 --> Form Validation Class Initialized
INFO - 2023-06-05 05:30:27 --> Controller Class Initialized
INFO - 2023-06-05 05:30:27 --> Model Class Initialized
DEBUG - 2023-06-05 05:30:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:30:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:30:27 --> Model Class Initialized
INFO - 2023-06-05 05:30:27 --> Final output sent to browser
DEBUG - 2023-06-05 05:30:27 --> Total execution time: 0.0441
ERROR - 2023-06-05 05:33:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:33:11 --> Config Class Initialized
INFO - 2023-06-05 05:33:11 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:33:11 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:33:11 --> Utf8 Class Initialized
INFO - 2023-06-05 05:33:11 --> URI Class Initialized
INFO - 2023-06-05 05:33:11 --> Router Class Initialized
INFO - 2023-06-05 05:33:11 --> Output Class Initialized
INFO - 2023-06-05 05:33:11 --> Security Class Initialized
DEBUG - 2023-06-05 05:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:33:11 --> Input Class Initialized
INFO - 2023-06-05 05:33:11 --> Language Class Initialized
INFO - 2023-06-05 05:33:11 --> Loader Class Initialized
INFO - 2023-06-05 05:33:11 --> Helper loaded: url_helper
INFO - 2023-06-05 05:33:11 --> Helper loaded: file_helper
INFO - 2023-06-05 05:33:11 --> Helper loaded: html_helper
INFO - 2023-06-05 05:33:11 --> Helper loaded: text_helper
INFO - 2023-06-05 05:33:11 --> Helper loaded: form_helper
INFO - 2023-06-05 05:33:11 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:33:11 --> Helper loaded: security_helper
INFO - 2023-06-05 05:33:11 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:33:11 --> Database Driver Class Initialized
INFO - 2023-06-05 05:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:33:11 --> Parser Class Initialized
INFO - 2023-06-05 05:33:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:33:11 --> Pagination Class Initialized
INFO - 2023-06-05 05:33:11 --> Form Validation Class Initialized
INFO - 2023-06-05 05:33:11 --> Controller Class Initialized
INFO - 2023-06-05 05:33:11 --> Model Class Initialized
DEBUG - 2023-06-05 05:33:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:33:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:33:11 --> Model Class Initialized
INFO - 2023-06-05 05:33:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-05 05:33:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:33:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 05:33:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 05:33:11 --> Model Class Initialized
INFO - 2023-06-05 05:33:11 --> Model Class Initialized
INFO - 2023-06-05 05:33:11 --> Model Class Initialized
INFO - 2023-06-05 05:33:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 05:33:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 05:33:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 05:33:11 --> Final output sent to browser
DEBUG - 2023-06-05 05:33:11 --> Total execution time: 0.1428
ERROR - 2023-06-05 05:33:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:33:12 --> Config Class Initialized
INFO - 2023-06-05 05:33:12 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:33:12 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:33:12 --> Utf8 Class Initialized
INFO - 2023-06-05 05:33:12 --> URI Class Initialized
INFO - 2023-06-05 05:33:12 --> Router Class Initialized
INFO - 2023-06-05 05:33:12 --> Output Class Initialized
INFO - 2023-06-05 05:33:12 --> Security Class Initialized
DEBUG - 2023-06-05 05:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:33:12 --> Input Class Initialized
INFO - 2023-06-05 05:33:12 --> Language Class Initialized
INFO - 2023-06-05 05:33:12 --> Loader Class Initialized
INFO - 2023-06-05 05:33:12 --> Helper loaded: url_helper
INFO - 2023-06-05 05:33:12 --> Helper loaded: file_helper
INFO - 2023-06-05 05:33:12 --> Helper loaded: html_helper
INFO - 2023-06-05 05:33:12 --> Helper loaded: text_helper
INFO - 2023-06-05 05:33:12 --> Helper loaded: form_helper
INFO - 2023-06-05 05:33:12 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:33:12 --> Helper loaded: security_helper
INFO - 2023-06-05 05:33:12 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:33:12 --> Database Driver Class Initialized
INFO - 2023-06-05 05:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:33:12 --> Parser Class Initialized
INFO - 2023-06-05 05:33:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:33:12 --> Pagination Class Initialized
INFO - 2023-06-05 05:33:12 --> Form Validation Class Initialized
INFO - 2023-06-05 05:33:12 --> Controller Class Initialized
INFO - 2023-06-05 05:33:12 --> Model Class Initialized
DEBUG - 2023-06-05 05:33:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:33:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:33:12 --> Model Class Initialized
INFO - 2023-06-05 05:33:12 --> Final output sent to browser
DEBUG - 2023-06-05 05:33:12 --> Total execution time: 0.0360
ERROR - 2023-06-05 05:33:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:33:36 --> Config Class Initialized
INFO - 2023-06-05 05:33:36 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:33:36 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:33:36 --> Utf8 Class Initialized
INFO - 2023-06-05 05:33:36 --> URI Class Initialized
INFO - 2023-06-05 05:33:36 --> Router Class Initialized
INFO - 2023-06-05 05:33:36 --> Output Class Initialized
INFO - 2023-06-05 05:33:36 --> Security Class Initialized
DEBUG - 2023-06-05 05:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:33:36 --> Input Class Initialized
INFO - 2023-06-05 05:33:36 --> Language Class Initialized
INFO - 2023-06-05 05:33:36 --> Loader Class Initialized
INFO - 2023-06-05 05:33:36 --> Helper loaded: url_helper
INFO - 2023-06-05 05:33:36 --> Helper loaded: file_helper
INFO - 2023-06-05 05:33:36 --> Helper loaded: html_helper
INFO - 2023-06-05 05:33:36 --> Helper loaded: text_helper
INFO - 2023-06-05 05:33:36 --> Helper loaded: form_helper
INFO - 2023-06-05 05:33:36 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:33:36 --> Helper loaded: security_helper
INFO - 2023-06-05 05:33:36 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:33:36 --> Database Driver Class Initialized
INFO - 2023-06-05 05:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:33:36 --> Parser Class Initialized
INFO - 2023-06-05 05:33:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:33:36 --> Pagination Class Initialized
INFO - 2023-06-05 05:33:36 --> Form Validation Class Initialized
INFO - 2023-06-05 05:33:36 --> Controller Class Initialized
INFO - 2023-06-05 05:33:36 --> Model Class Initialized
DEBUG - 2023-06-05 05:33:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:33:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:33:36 --> Model Class Initialized
DEBUG - 2023-06-05 05:33:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-06-05 05:33:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 05:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 05:33:36 --> Model Class Initialized
INFO - 2023-06-05 05:33:36 --> Model Class Initialized
INFO - 2023-06-05 05:33:36 --> Model Class Initialized
INFO - 2023-06-05 05:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 05:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 05:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 05:33:36 --> Final output sent to browser
DEBUG - 2023-06-05 05:33:36 --> Total execution time: 0.1304
ERROR - 2023-06-05 05:33:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:33:45 --> Config Class Initialized
INFO - 2023-06-05 05:33:45 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:33:45 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:33:45 --> Utf8 Class Initialized
INFO - 2023-06-05 05:33:45 --> URI Class Initialized
INFO - 2023-06-05 05:33:45 --> Router Class Initialized
INFO - 2023-06-05 05:33:45 --> Output Class Initialized
INFO - 2023-06-05 05:33:45 --> Security Class Initialized
DEBUG - 2023-06-05 05:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:33:45 --> Input Class Initialized
INFO - 2023-06-05 05:33:45 --> Language Class Initialized
INFO - 2023-06-05 05:33:45 --> Loader Class Initialized
INFO - 2023-06-05 05:33:45 --> Helper loaded: url_helper
INFO - 2023-06-05 05:33:45 --> Helper loaded: file_helper
INFO - 2023-06-05 05:33:45 --> Helper loaded: html_helper
INFO - 2023-06-05 05:33:45 --> Helper loaded: text_helper
INFO - 2023-06-05 05:33:45 --> Helper loaded: form_helper
INFO - 2023-06-05 05:33:45 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:33:45 --> Helper loaded: security_helper
INFO - 2023-06-05 05:33:45 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:33:45 --> Database Driver Class Initialized
INFO - 2023-06-05 05:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:33:45 --> Parser Class Initialized
INFO - 2023-06-05 05:33:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:33:45 --> Pagination Class Initialized
INFO - 2023-06-05 05:33:45 --> Form Validation Class Initialized
INFO - 2023-06-05 05:33:45 --> Controller Class Initialized
INFO - 2023-06-05 05:33:45 --> Model Class Initialized
DEBUG - 2023-06-05 05:33:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:33:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:33:45 --> Model Class Initialized
INFO - 2023-06-05 05:33:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-05 05:33:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:33:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 05:33:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 05:33:45 --> Model Class Initialized
INFO - 2023-06-05 05:33:45 --> Model Class Initialized
INFO - 2023-06-05 05:33:45 --> Model Class Initialized
INFO - 2023-06-05 05:33:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 05:33:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 05:33:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 05:33:45 --> Final output sent to browser
DEBUG - 2023-06-05 05:33:45 --> Total execution time: 0.1264
ERROR - 2023-06-05 05:33:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:33:45 --> Config Class Initialized
INFO - 2023-06-05 05:33:45 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:33:45 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:33:45 --> Utf8 Class Initialized
INFO - 2023-06-05 05:33:45 --> URI Class Initialized
INFO - 2023-06-05 05:33:45 --> Router Class Initialized
INFO - 2023-06-05 05:33:45 --> Output Class Initialized
INFO - 2023-06-05 05:33:45 --> Security Class Initialized
DEBUG - 2023-06-05 05:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:33:45 --> Input Class Initialized
INFO - 2023-06-05 05:33:45 --> Language Class Initialized
INFO - 2023-06-05 05:33:45 --> Loader Class Initialized
INFO - 2023-06-05 05:33:45 --> Helper loaded: url_helper
INFO - 2023-06-05 05:33:45 --> Helper loaded: file_helper
INFO - 2023-06-05 05:33:45 --> Helper loaded: html_helper
INFO - 2023-06-05 05:33:45 --> Helper loaded: text_helper
INFO - 2023-06-05 05:33:45 --> Helper loaded: form_helper
INFO - 2023-06-05 05:33:45 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:33:45 --> Helper loaded: security_helper
INFO - 2023-06-05 05:33:45 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:33:45 --> Database Driver Class Initialized
INFO - 2023-06-05 05:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:33:45 --> Parser Class Initialized
INFO - 2023-06-05 05:33:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:33:45 --> Pagination Class Initialized
INFO - 2023-06-05 05:33:45 --> Form Validation Class Initialized
INFO - 2023-06-05 05:33:45 --> Controller Class Initialized
INFO - 2023-06-05 05:33:45 --> Model Class Initialized
DEBUG - 2023-06-05 05:33:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:33:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:33:45 --> Model Class Initialized
INFO - 2023-06-05 05:33:45 --> Final output sent to browser
DEBUG - 2023-06-05 05:33:45 --> Total execution time: 0.0281
ERROR - 2023-06-05 05:34:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:34:01 --> Config Class Initialized
INFO - 2023-06-05 05:34:01 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:34:01 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:34:01 --> Utf8 Class Initialized
INFO - 2023-06-05 05:34:01 --> URI Class Initialized
INFO - 2023-06-05 05:34:01 --> Router Class Initialized
INFO - 2023-06-05 05:34:01 --> Output Class Initialized
INFO - 2023-06-05 05:34:01 --> Security Class Initialized
DEBUG - 2023-06-05 05:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:34:01 --> Input Class Initialized
INFO - 2023-06-05 05:34:01 --> Language Class Initialized
INFO - 2023-06-05 05:34:01 --> Loader Class Initialized
INFO - 2023-06-05 05:34:01 --> Helper loaded: url_helper
INFO - 2023-06-05 05:34:01 --> Helper loaded: file_helper
INFO - 2023-06-05 05:34:01 --> Helper loaded: html_helper
INFO - 2023-06-05 05:34:01 --> Helper loaded: text_helper
INFO - 2023-06-05 05:34:01 --> Helper loaded: form_helper
INFO - 2023-06-05 05:34:01 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:34:01 --> Helper loaded: security_helper
INFO - 2023-06-05 05:34:01 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:34:01 --> Database Driver Class Initialized
INFO - 2023-06-05 05:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:34:01 --> Parser Class Initialized
INFO - 2023-06-05 05:34:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:34:01 --> Pagination Class Initialized
INFO - 2023-06-05 05:34:01 --> Form Validation Class Initialized
INFO - 2023-06-05 05:34:01 --> Controller Class Initialized
INFO - 2023-06-05 05:34:01 --> Model Class Initialized
DEBUG - 2023-06-05 05:34:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:34:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:34:01 --> Model Class Initialized
DEBUG - 2023-06-05 05:34:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:34:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest_html.php
DEBUG - 2023-06-05 05:34:01 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:34:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 05:34:01 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 05:34:01 --> Model Class Initialized
INFO - 2023-06-05 05:34:01 --> Model Class Initialized
INFO - 2023-06-05 05:34:01 --> Model Class Initialized
INFO - 2023-06-05 05:34:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 05:34:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 05:34:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 05:34:02 --> Final output sent to browser
DEBUG - 2023-06-05 05:34:02 --> Total execution time: 0.1328
ERROR - 2023-06-05 05:34:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:34:07 --> Config Class Initialized
INFO - 2023-06-05 05:34:07 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:34:07 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:34:07 --> Utf8 Class Initialized
INFO - 2023-06-05 05:34:07 --> URI Class Initialized
INFO - 2023-06-05 05:34:07 --> Router Class Initialized
INFO - 2023-06-05 05:34:07 --> Output Class Initialized
INFO - 2023-06-05 05:34:07 --> Security Class Initialized
DEBUG - 2023-06-05 05:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:34:07 --> Input Class Initialized
INFO - 2023-06-05 05:34:07 --> Language Class Initialized
INFO - 2023-06-05 05:34:07 --> Loader Class Initialized
INFO - 2023-06-05 05:34:07 --> Helper loaded: url_helper
INFO - 2023-06-05 05:34:07 --> Helper loaded: file_helper
INFO - 2023-06-05 05:34:07 --> Helper loaded: html_helper
INFO - 2023-06-05 05:34:07 --> Helper loaded: text_helper
INFO - 2023-06-05 05:34:07 --> Helper loaded: form_helper
INFO - 2023-06-05 05:34:07 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:34:07 --> Helper loaded: security_helper
INFO - 2023-06-05 05:34:07 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:34:07 --> Database Driver Class Initialized
INFO - 2023-06-05 05:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:34:07 --> Parser Class Initialized
INFO - 2023-06-05 05:34:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:34:07 --> Pagination Class Initialized
INFO - 2023-06-05 05:34:07 --> Form Validation Class Initialized
INFO - 2023-06-05 05:34:07 --> Controller Class Initialized
INFO - 2023-06-05 05:34:07 --> Model Class Initialized
DEBUG - 2023-06-05 05:34:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:34:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:34:07 --> Model Class Initialized
INFO - 2023-06-05 05:34:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-05 05:34:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:34:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 05:34:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 05:34:07 --> Model Class Initialized
INFO - 2023-06-05 05:34:07 --> Model Class Initialized
INFO - 2023-06-05 05:34:07 --> Model Class Initialized
INFO - 2023-06-05 05:34:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 05:34:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 05:34:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 05:34:07 --> Final output sent to browser
DEBUG - 2023-06-05 05:34:07 --> Total execution time: 0.1354
ERROR - 2023-06-05 05:34:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:34:08 --> Config Class Initialized
INFO - 2023-06-05 05:34:08 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:34:08 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:34:08 --> Utf8 Class Initialized
INFO - 2023-06-05 05:34:08 --> URI Class Initialized
INFO - 2023-06-05 05:34:08 --> Router Class Initialized
INFO - 2023-06-05 05:34:08 --> Output Class Initialized
INFO - 2023-06-05 05:34:08 --> Security Class Initialized
DEBUG - 2023-06-05 05:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:34:08 --> Input Class Initialized
INFO - 2023-06-05 05:34:08 --> Language Class Initialized
INFO - 2023-06-05 05:34:08 --> Loader Class Initialized
INFO - 2023-06-05 05:34:08 --> Helper loaded: url_helper
INFO - 2023-06-05 05:34:08 --> Helper loaded: file_helper
INFO - 2023-06-05 05:34:08 --> Helper loaded: html_helper
INFO - 2023-06-05 05:34:08 --> Helper loaded: text_helper
INFO - 2023-06-05 05:34:08 --> Helper loaded: form_helper
INFO - 2023-06-05 05:34:08 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:34:08 --> Helper loaded: security_helper
INFO - 2023-06-05 05:34:08 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:34:08 --> Database Driver Class Initialized
INFO - 2023-06-05 05:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:34:08 --> Parser Class Initialized
INFO - 2023-06-05 05:34:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:34:08 --> Pagination Class Initialized
INFO - 2023-06-05 05:34:08 --> Form Validation Class Initialized
INFO - 2023-06-05 05:34:08 --> Controller Class Initialized
INFO - 2023-06-05 05:34:08 --> Model Class Initialized
DEBUG - 2023-06-05 05:34:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:34:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:34:08 --> Model Class Initialized
INFO - 2023-06-05 05:34:08 --> Final output sent to browser
DEBUG - 2023-06-05 05:34:08 --> Total execution time: 0.0326
ERROR - 2023-06-05 05:34:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:34:12 --> Config Class Initialized
INFO - 2023-06-05 05:34:12 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:34:12 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:34:12 --> Utf8 Class Initialized
INFO - 2023-06-05 05:34:12 --> URI Class Initialized
INFO - 2023-06-05 05:34:12 --> Router Class Initialized
INFO - 2023-06-05 05:34:12 --> Output Class Initialized
INFO - 2023-06-05 05:34:12 --> Security Class Initialized
DEBUG - 2023-06-05 05:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:34:12 --> Input Class Initialized
INFO - 2023-06-05 05:34:12 --> Language Class Initialized
INFO - 2023-06-05 05:34:12 --> Loader Class Initialized
INFO - 2023-06-05 05:34:12 --> Helper loaded: url_helper
INFO - 2023-06-05 05:34:12 --> Helper loaded: file_helper
INFO - 2023-06-05 05:34:12 --> Helper loaded: html_helper
INFO - 2023-06-05 05:34:12 --> Helper loaded: text_helper
INFO - 2023-06-05 05:34:12 --> Helper loaded: form_helper
INFO - 2023-06-05 05:34:12 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:34:12 --> Helper loaded: security_helper
INFO - 2023-06-05 05:34:12 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:34:12 --> Database Driver Class Initialized
INFO - 2023-06-05 05:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:34:12 --> Parser Class Initialized
INFO - 2023-06-05 05:34:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:34:12 --> Pagination Class Initialized
INFO - 2023-06-05 05:34:12 --> Form Validation Class Initialized
INFO - 2023-06-05 05:34:12 --> Controller Class Initialized
INFO - 2023-06-05 05:34:12 --> Model Class Initialized
DEBUG - 2023-06-05 05:34:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:34:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:34:12 --> Model Class Initialized
INFO - 2023-06-05 05:34:12 --> Final output sent to browser
DEBUG - 2023-06-05 05:34:12 --> Total execution time: 0.0381
ERROR - 2023-06-05 05:37:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:37:39 --> Config Class Initialized
INFO - 2023-06-05 05:37:39 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:37:39 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:37:39 --> Utf8 Class Initialized
INFO - 2023-06-05 05:37:39 --> URI Class Initialized
INFO - 2023-06-05 05:37:39 --> Router Class Initialized
INFO - 2023-06-05 05:37:39 --> Output Class Initialized
INFO - 2023-06-05 05:37:39 --> Security Class Initialized
DEBUG - 2023-06-05 05:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:37:39 --> Input Class Initialized
INFO - 2023-06-05 05:37:39 --> Language Class Initialized
INFO - 2023-06-05 05:37:39 --> Loader Class Initialized
INFO - 2023-06-05 05:37:39 --> Helper loaded: url_helper
INFO - 2023-06-05 05:37:39 --> Helper loaded: file_helper
INFO - 2023-06-05 05:37:39 --> Helper loaded: html_helper
INFO - 2023-06-05 05:37:39 --> Helper loaded: text_helper
INFO - 2023-06-05 05:37:39 --> Helper loaded: form_helper
INFO - 2023-06-05 05:37:39 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:37:39 --> Helper loaded: security_helper
INFO - 2023-06-05 05:37:39 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:37:39 --> Database Driver Class Initialized
INFO - 2023-06-05 05:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:37:39 --> Parser Class Initialized
INFO - 2023-06-05 05:37:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:37:39 --> Pagination Class Initialized
INFO - 2023-06-05 05:37:39 --> Form Validation Class Initialized
INFO - 2023-06-05 05:37:39 --> Controller Class Initialized
INFO - 2023-06-05 05:37:39 --> Model Class Initialized
DEBUG - 2023-06-05 05:37:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:37:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:37:39 --> Model Class Initialized
INFO - 2023-06-05 05:37:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-05 05:37:39 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:37:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 05:37:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 05:37:39 --> Model Class Initialized
INFO - 2023-06-05 05:37:39 --> Model Class Initialized
INFO - 2023-06-05 05:37:39 --> Model Class Initialized
INFO - 2023-06-05 05:37:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 05:37:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 05:37:39 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 05:37:39 --> Final output sent to browser
DEBUG - 2023-06-05 05:37:39 --> Total execution time: 0.1392
ERROR - 2023-06-05 05:37:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:37:40 --> Config Class Initialized
INFO - 2023-06-05 05:37:40 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:37:40 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:37:40 --> Utf8 Class Initialized
INFO - 2023-06-05 05:37:40 --> URI Class Initialized
INFO - 2023-06-05 05:37:40 --> Router Class Initialized
INFO - 2023-06-05 05:37:40 --> Output Class Initialized
INFO - 2023-06-05 05:37:40 --> Security Class Initialized
DEBUG - 2023-06-05 05:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:37:40 --> Input Class Initialized
INFO - 2023-06-05 05:37:40 --> Language Class Initialized
INFO - 2023-06-05 05:37:40 --> Loader Class Initialized
INFO - 2023-06-05 05:37:40 --> Helper loaded: url_helper
INFO - 2023-06-05 05:37:40 --> Helper loaded: file_helper
INFO - 2023-06-05 05:37:40 --> Helper loaded: html_helper
INFO - 2023-06-05 05:37:40 --> Helper loaded: text_helper
INFO - 2023-06-05 05:37:40 --> Helper loaded: form_helper
INFO - 2023-06-05 05:37:40 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:37:40 --> Helper loaded: security_helper
INFO - 2023-06-05 05:37:40 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:37:40 --> Database Driver Class Initialized
INFO - 2023-06-05 05:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:37:40 --> Parser Class Initialized
INFO - 2023-06-05 05:37:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:37:40 --> Pagination Class Initialized
INFO - 2023-06-05 05:37:40 --> Form Validation Class Initialized
INFO - 2023-06-05 05:37:40 --> Controller Class Initialized
INFO - 2023-06-05 05:37:40 --> Model Class Initialized
DEBUG - 2023-06-05 05:37:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:37:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:37:40 --> Model Class Initialized
INFO - 2023-06-05 05:37:40 --> Final output sent to browser
DEBUG - 2023-06-05 05:37:40 --> Total execution time: 0.0283
ERROR - 2023-06-05 05:37:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 05:37:43 --> Config Class Initialized
INFO - 2023-06-05 05:37:43 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:37:43 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:37:43 --> Utf8 Class Initialized
INFO - 2023-06-05 05:37:43 --> URI Class Initialized
INFO - 2023-06-05 05:37:43 --> Router Class Initialized
INFO - 2023-06-05 05:37:43 --> Output Class Initialized
INFO - 2023-06-05 05:37:43 --> Security Class Initialized
DEBUG - 2023-06-05 05:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:37:43 --> Input Class Initialized
INFO - 2023-06-05 05:37:43 --> Language Class Initialized
INFO - 2023-06-05 05:37:43 --> Loader Class Initialized
INFO - 2023-06-05 05:37:43 --> Helper loaded: url_helper
INFO - 2023-06-05 05:37:43 --> Helper loaded: file_helper
INFO - 2023-06-05 05:37:43 --> Helper loaded: html_helper
INFO - 2023-06-05 05:37:43 --> Helper loaded: text_helper
INFO - 2023-06-05 05:37:43 --> Helper loaded: form_helper
INFO - 2023-06-05 05:37:43 --> Helper loaded: lang_helper
INFO - 2023-06-05 05:37:43 --> Helper loaded: security_helper
INFO - 2023-06-05 05:37:43 --> Helper loaded: cookie_helper
INFO - 2023-06-05 05:37:43 --> Database Driver Class Initialized
INFO - 2023-06-05 05:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 05:37:43 --> Parser Class Initialized
INFO - 2023-06-05 05:37:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 05:37:43 --> Pagination Class Initialized
INFO - 2023-06-05 05:37:43 --> Form Validation Class Initialized
INFO - 2023-06-05 05:37:43 --> Controller Class Initialized
INFO - 2023-06-05 05:37:43 --> Model Class Initialized
DEBUG - 2023-06-05 05:37:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 05:37:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 05:37:43 --> Model Class Initialized
INFO - 2023-06-05 05:37:43 --> Final output sent to browser
DEBUG - 2023-06-05 05:37:43 --> Total execution time: 0.0386
ERROR - 2023-06-05 10:37:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 10:37:27 --> Config Class Initialized
INFO - 2023-06-05 10:37:27 --> Hooks Class Initialized
DEBUG - 2023-06-05 10:37:27 --> UTF-8 Support Enabled
INFO - 2023-06-05 10:37:27 --> Utf8 Class Initialized
INFO - 2023-06-05 10:37:27 --> URI Class Initialized
DEBUG - 2023-06-05 10:37:27 --> No URI present. Default controller set.
INFO - 2023-06-05 10:37:27 --> Router Class Initialized
INFO - 2023-06-05 10:37:27 --> Output Class Initialized
INFO - 2023-06-05 10:37:27 --> Security Class Initialized
DEBUG - 2023-06-05 10:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 10:37:27 --> Input Class Initialized
INFO - 2023-06-05 10:37:27 --> Language Class Initialized
INFO - 2023-06-05 10:37:27 --> Loader Class Initialized
INFO - 2023-06-05 10:37:27 --> Helper loaded: url_helper
INFO - 2023-06-05 10:37:27 --> Helper loaded: file_helper
INFO - 2023-06-05 10:37:27 --> Helper loaded: html_helper
INFO - 2023-06-05 10:37:27 --> Helper loaded: text_helper
INFO - 2023-06-05 10:37:27 --> Helper loaded: form_helper
INFO - 2023-06-05 10:37:27 --> Helper loaded: lang_helper
INFO - 2023-06-05 10:37:27 --> Helper loaded: security_helper
INFO - 2023-06-05 10:37:27 --> Helper loaded: cookie_helper
INFO - 2023-06-05 10:37:27 --> Database Driver Class Initialized
INFO - 2023-06-05 10:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 10:37:27 --> Parser Class Initialized
INFO - 2023-06-05 10:37:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 10:37:27 --> Pagination Class Initialized
INFO - 2023-06-05 10:37:27 --> Form Validation Class Initialized
INFO - 2023-06-05 10:37:27 --> Controller Class Initialized
INFO - 2023-06-05 10:37:27 --> Model Class Initialized
DEBUG - 2023-06-05 10:37:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-05 10:37:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 10:37:29 --> Config Class Initialized
INFO - 2023-06-05 10:37:29 --> Hooks Class Initialized
DEBUG - 2023-06-05 10:37:29 --> UTF-8 Support Enabled
INFO - 2023-06-05 10:37:29 --> Utf8 Class Initialized
INFO - 2023-06-05 10:37:29 --> URI Class Initialized
INFO - 2023-06-05 10:37:29 --> Router Class Initialized
INFO - 2023-06-05 10:37:29 --> Output Class Initialized
INFO - 2023-06-05 10:37:29 --> Security Class Initialized
DEBUG - 2023-06-05 10:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 10:37:29 --> Input Class Initialized
INFO - 2023-06-05 10:37:29 --> Language Class Initialized
INFO - 2023-06-05 10:37:29 --> Loader Class Initialized
INFO - 2023-06-05 10:37:29 --> Helper loaded: url_helper
INFO - 2023-06-05 10:37:29 --> Helper loaded: file_helper
INFO - 2023-06-05 10:37:29 --> Helper loaded: html_helper
INFO - 2023-06-05 10:37:29 --> Helper loaded: text_helper
INFO - 2023-06-05 10:37:29 --> Helper loaded: form_helper
INFO - 2023-06-05 10:37:29 --> Helper loaded: lang_helper
INFO - 2023-06-05 10:37:29 --> Helper loaded: security_helper
INFO - 2023-06-05 10:37:29 --> Helper loaded: cookie_helper
INFO - 2023-06-05 10:37:29 --> Database Driver Class Initialized
INFO - 2023-06-05 10:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 10:37:29 --> Parser Class Initialized
INFO - 2023-06-05 10:37:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 10:37:29 --> Pagination Class Initialized
INFO - 2023-06-05 10:37:29 --> Form Validation Class Initialized
INFO - 2023-06-05 10:37:29 --> Controller Class Initialized
INFO - 2023-06-05 10:37:29 --> Model Class Initialized
DEBUG - 2023-06-05 10:37:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:37:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-05 10:37:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:37:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 10:37:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 10:37:29 --> Model Class Initialized
INFO - 2023-06-05 10:37:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 10:37:29 --> Final output sent to browser
DEBUG - 2023-06-05 10:37:29 --> Total execution time: 0.0428
ERROR - 2023-06-05 10:37:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 10:37:33 --> Config Class Initialized
INFO - 2023-06-05 10:37:33 --> Hooks Class Initialized
DEBUG - 2023-06-05 10:37:33 --> UTF-8 Support Enabled
INFO - 2023-06-05 10:37:33 --> Utf8 Class Initialized
INFO - 2023-06-05 10:37:33 --> URI Class Initialized
INFO - 2023-06-05 10:37:33 --> Router Class Initialized
INFO - 2023-06-05 10:37:33 --> Output Class Initialized
INFO - 2023-06-05 10:37:33 --> Security Class Initialized
DEBUG - 2023-06-05 10:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 10:37:33 --> Input Class Initialized
INFO - 2023-06-05 10:37:33 --> Language Class Initialized
INFO - 2023-06-05 10:37:33 --> Loader Class Initialized
INFO - 2023-06-05 10:37:33 --> Helper loaded: url_helper
INFO - 2023-06-05 10:37:33 --> Helper loaded: file_helper
INFO - 2023-06-05 10:37:33 --> Helper loaded: html_helper
INFO - 2023-06-05 10:37:33 --> Helper loaded: text_helper
INFO - 2023-06-05 10:37:33 --> Helper loaded: form_helper
INFO - 2023-06-05 10:37:33 --> Helper loaded: lang_helper
INFO - 2023-06-05 10:37:33 --> Helper loaded: security_helper
INFO - 2023-06-05 10:37:33 --> Helper loaded: cookie_helper
INFO - 2023-06-05 10:37:33 --> Database Driver Class Initialized
INFO - 2023-06-05 10:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 10:37:33 --> Parser Class Initialized
INFO - 2023-06-05 10:37:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 10:37:33 --> Pagination Class Initialized
INFO - 2023-06-05 10:37:33 --> Form Validation Class Initialized
INFO - 2023-06-05 10:37:33 --> Controller Class Initialized
INFO - 2023-06-05 10:37:33 --> Model Class Initialized
DEBUG - 2023-06-05 10:37:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:37:33 --> Model Class Initialized
INFO - 2023-06-05 10:37:33 --> Final output sent to browser
DEBUG - 2023-06-05 10:37:33 --> Total execution time: 0.0197
ERROR - 2023-06-05 10:37:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 10:37:34 --> Config Class Initialized
INFO - 2023-06-05 10:37:34 --> Hooks Class Initialized
DEBUG - 2023-06-05 10:37:34 --> UTF-8 Support Enabled
INFO - 2023-06-05 10:37:34 --> Utf8 Class Initialized
INFO - 2023-06-05 10:37:34 --> URI Class Initialized
DEBUG - 2023-06-05 10:37:34 --> No URI present. Default controller set.
INFO - 2023-06-05 10:37:34 --> Router Class Initialized
INFO - 2023-06-05 10:37:34 --> Output Class Initialized
INFO - 2023-06-05 10:37:34 --> Security Class Initialized
DEBUG - 2023-06-05 10:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 10:37:34 --> Input Class Initialized
INFO - 2023-06-05 10:37:34 --> Language Class Initialized
INFO - 2023-06-05 10:37:34 --> Loader Class Initialized
INFO - 2023-06-05 10:37:34 --> Helper loaded: url_helper
INFO - 2023-06-05 10:37:34 --> Helper loaded: file_helper
INFO - 2023-06-05 10:37:34 --> Helper loaded: html_helper
INFO - 2023-06-05 10:37:34 --> Helper loaded: text_helper
INFO - 2023-06-05 10:37:34 --> Helper loaded: form_helper
INFO - 2023-06-05 10:37:34 --> Helper loaded: lang_helper
INFO - 2023-06-05 10:37:34 --> Helper loaded: security_helper
INFO - 2023-06-05 10:37:34 --> Helper loaded: cookie_helper
INFO - 2023-06-05 10:37:34 --> Database Driver Class Initialized
INFO - 2023-06-05 10:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 10:37:34 --> Parser Class Initialized
INFO - 2023-06-05 10:37:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 10:37:34 --> Pagination Class Initialized
INFO - 2023-06-05 10:37:34 --> Form Validation Class Initialized
INFO - 2023-06-05 10:37:34 --> Controller Class Initialized
INFO - 2023-06-05 10:37:34 --> Model Class Initialized
DEBUG - 2023-06-05 10:37:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:37:34 --> Model Class Initialized
DEBUG - 2023-06-05 10:37:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:37:34 --> Model Class Initialized
INFO - 2023-06-05 10:37:34 --> Model Class Initialized
INFO - 2023-06-05 10:37:34 --> Model Class Initialized
INFO - 2023-06-05 10:37:34 --> Model Class Initialized
DEBUG - 2023-06-05 10:37:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 10:37:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:37:34 --> Model Class Initialized
INFO - 2023-06-05 10:37:34 --> Model Class Initialized
INFO - 2023-06-05 10:37:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-05 10:37:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:37:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 10:37:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 10:37:34 --> Model Class Initialized
INFO - 2023-06-05 10:37:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 10:37:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 10:37:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 10:37:34 --> Final output sent to browser
DEBUG - 2023-06-05 10:37:34 --> Total execution time: 0.1857
ERROR - 2023-06-05 10:37:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 10:37:35 --> Config Class Initialized
INFO - 2023-06-05 10:37:35 --> Hooks Class Initialized
DEBUG - 2023-06-05 10:37:35 --> UTF-8 Support Enabled
INFO - 2023-06-05 10:37:35 --> Utf8 Class Initialized
INFO - 2023-06-05 10:37:35 --> URI Class Initialized
INFO - 2023-06-05 10:37:35 --> Router Class Initialized
INFO - 2023-06-05 10:37:35 --> Output Class Initialized
INFO - 2023-06-05 10:37:35 --> Security Class Initialized
DEBUG - 2023-06-05 10:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 10:37:35 --> Input Class Initialized
INFO - 2023-06-05 10:37:35 --> Language Class Initialized
INFO - 2023-06-05 10:37:35 --> Loader Class Initialized
INFO - 2023-06-05 10:37:35 --> Helper loaded: url_helper
INFO - 2023-06-05 10:37:35 --> Helper loaded: file_helper
INFO - 2023-06-05 10:37:35 --> Helper loaded: html_helper
INFO - 2023-06-05 10:37:35 --> Helper loaded: text_helper
INFO - 2023-06-05 10:37:35 --> Helper loaded: form_helper
INFO - 2023-06-05 10:37:35 --> Helper loaded: lang_helper
INFO - 2023-06-05 10:37:35 --> Helper loaded: security_helper
INFO - 2023-06-05 10:37:35 --> Helper loaded: cookie_helper
INFO - 2023-06-05 10:37:35 --> Database Driver Class Initialized
INFO - 2023-06-05 10:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 10:37:35 --> Parser Class Initialized
INFO - 2023-06-05 10:37:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 10:37:35 --> Pagination Class Initialized
INFO - 2023-06-05 10:37:35 --> Form Validation Class Initialized
INFO - 2023-06-05 10:37:35 --> Controller Class Initialized
DEBUG - 2023-06-05 10:37:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 10:37:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:37:35 --> Model Class Initialized
INFO - 2023-06-05 10:37:35 --> Final output sent to browser
DEBUG - 2023-06-05 10:37:35 --> Total execution time: 0.0132
ERROR - 2023-06-05 10:38:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 10:38:02 --> Config Class Initialized
INFO - 2023-06-05 10:38:02 --> Hooks Class Initialized
DEBUG - 2023-06-05 10:38:02 --> UTF-8 Support Enabled
INFO - 2023-06-05 10:38:02 --> Utf8 Class Initialized
INFO - 2023-06-05 10:38:02 --> URI Class Initialized
INFO - 2023-06-05 10:38:02 --> Router Class Initialized
INFO - 2023-06-05 10:38:02 --> Output Class Initialized
INFO - 2023-06-05 10:38:02 --> Security Class Initialized
DEBUG - 2023-06-05 10:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 10:38:02 --> Input Class Initialized
INFO - 2023-06-05 10:38:02 --> Language Class Initialized
INFO - 2023-06-05 10:38:02 --> Loader Class Initialized
INFO - 2023-06-05 10:38:02 --> Helper loaded: url_helper
INFO - 2023-06-05 10:38:02 --> Helper loaded: file_helper
INFO - 2023-06-05 10:38:02 --> Helper loaded: html_helper
INFO - 2023-06-05 10:38:02 --> Helper loaded: text_helper
INFO - 2023-06-05 10:38:02 --> Helper loaded: form_helper
INFO - 2023-06-05 10:38:02 --> Helper loaded: lang_helper
INFO - 2023-06-05 10:38:02 --> Helper loaded: security_helper
INFO - 2023-06-05 10:38:02 --> Helper loaded: cookie_helper
INFO - 2023-06-05 10:38:02 --> Database Driver Class Initialized
INFO - 2023-06-05 10:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 10:38:02 --> Parser Class Initialized
INFO - 2023-06-05 10:38:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 10:38:02 --> Pagination Class Initialized
INFO - 2023-06-05 10:38:02 --> Form Validation Class Initialized
INFO - 2023-06-05 10:38:02 --> Controller Class Initialized
INFO - 2023-06-05 10:38:02 --> Model Class Initialized
DEBUG - 2023-06-05 10:38:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 10:38:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:38:02 --> Model Class Initialized
DEBUG - 2023-06-05 10:38:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:38:02 --> Model Class Initialized
INFO - 2023-06-05 10:38:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-06-05 10:38:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:38:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 10:38:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 10:38:02 --> Model Class Initialized
INFO - 2023-06-05 10:38:02 --> Model Class Initialized
INFO - 2023-06-05 10:38:02 --> Model Class Initialized
INFO - 2023-06-05 10:38:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 10:38:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 10:38:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 10:38:02 --> Final output sent to browser
DEBUG - 2023-06-05 10:38:02 --> Total execution time: 0.1770
ERROR - 2023-06-05 10:38:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 10:38:03 --> Config Class Initialized
INFO - 2023-06-05 10:38:03 --> Hooks Class Initialized
DEBUG - 2023-06-05 10:38:03 --> UTF-8 Support Enabled
INFO - 2023-06-05 10:38:03 --> Utf8 Class Initialized
INFO - 2023-06-05 10:38:03 --> URI Class Initialized
INFO - 2023-06-05 10:38:03 --> Router Class Initialized
INFO - 2023-06-05 10:38:03 --> Output Class Initialized
INFO - 2023-06-05 10:38:03 --> Security Class Initialized
DEBUG - 2023-06-05 10:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 10:38:03 --> Input Class Initialized
INFO - 2023-06-05 10:38:03 --> Language Class Initialized
INFO - 2023-06-05 10:38:03 --> Loader Class Initialized
INFO - 2023-06-05 10:38:03 --> Helper loaded: url_helper
INFO - 2023-06-05 10:38:03 --> Helper loaded: file_helper
INFO - 2023-06-05 10:38:03 --> Helper loaded: html_helper
INFO - 2023-06-05 10:38:03 --> Helper loaded: text_helper
INFO - 2023-06-05 10:38:03 --> Helper loaded: form_helper
INFO - 2023-06-05 10:38:03 --> Helper loaded: lang_helper
INFO - 2023-06-05 10:38:03 --> Helper loaded: security_helper
INFO - 2023-06-05 10:38:03 --> Helper loaded: cookie_helper
INFO - 2023-06-05 10:38:03 --> Database Driver Class Initialized
INFO - 2023-06-05 10:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 10:38:03 --> Parser Class Initialized
INFO - 2023-06-05 10:38:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 10:38:03 --> Pagination Class Initialized
INFO - 2023-06-05 10:38:03 --> Form Validation Class Initialized
INFO - 2023-06-05 10:38:03 --> Controller Class Initialized
INFO - 2023-06-05 10:38:03 --> Model Class Initialized
DEBUG - 2023-06-05 10:38:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 10:38:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:38:03 --> Model Class Initialized
DEBUG - 2023-06-05 10:38:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:38:03 --> Model Class Initialized
INFO - 2023-06-05 10:38:03 --> Final output sent to browser
DEBUG - 2023-06-05 10:38:03 --> Total execution time: 0.0528
ERROR - 2023-06-05 10:38:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 10:38:15 --> Config Class Initialized
INFO - 2023-06-05 10:38:15 --> Hooks Class Initialized
DEBUG - 2023-06-05 10:38:15 --> UTF-8 Support Enabled
INFO - 2023-06-05 10:38:15 --> Utf8 Class Initialized
INFO - 2023-06-05 10:38:15 --> URI Class Initialized
INFO - 2023-06-05 10:38:15 --> Router Class Initialized
INFO - 2023-06-05 10:38:15 --> Output Class Initialized
INFO - 2023-06-05 10:38:15 --> Security Class Initialized
DEBUG - 2023-06-05 10:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 10:38:15 --> Input Class Initialized
INFO - 2023-06-05 10:38:15 --> Language Class Initialized
INFO - 2023-06-05 10:38:15 --> Loader Class Initialized
INFO - 2023-06-05 10:38:15 --> Helper loaded: url_helper
INFO - 2023-06-05 10:38:15 --> Helper loaded: file_helper
INFO - 2023-06-05 10:38:15 --> Helper loaded: html_helper
INFO - 2023-06-05 10:38:15 --> Helper loaded: text_helper
INFO - 2023-06-05 10:38:15 --> Helper loaded: form_helper
INFO - 2023-06-05 10:38:15 --> Helper loaded: lang_helper
INFO - 2023-06-05 10:38:15 --> Helper loaded: security_helper
INFO - 2023-06-05 10:38:15 --> Helper loaded: cookie_helper
INFO - 2023-06-05 10:38:15 --> Database Driver Class Initialized
INFO - 2023-06-05 10:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 10:38:15 --> Parser Class Initialized
INFO - 2023-06-05 10:38:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 10:38:15 --> Pagination Class Initialized
INFO - 2023-06-05 10:38:15 --> Form Validation Class Initialized
INFO - 2023-06-05 10:38:15 --> Controller Class Initialized
INFO - 2023-06-05 10:38:15 --> Model Class Initialized
DEBUG - 2023-06-05 10:38:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 10:38:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:38:15 --> Model Class Initialized
DEBUG - 2023-06-05 10:38:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:38:15 --> Model Class Initialized
INFO - 2023-06-05 10:38:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-05 10:38:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:38:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 10:38:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 10:38:15 --> Model Class Initialized
INFO - 2023-06-05 10:38:15 --> Model Class Initialized
INFO - 2023-06-05 10:38:15 --> Model Class Initialized
INFO - 2023-06-05 10:38:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 10:38:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 10:38:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 10:38:15 --> Final output sent to browser
DEBUG - 2023-06-05 10:38:15 --> Total execution time: 0.1538
ERROR - 2023-06-05 10:38:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 10:38:16 --> Config Class Initialized
INFO - 2023-06-05 10:38:16 --> Hooks Class Initialized
DEBUG - 2023-06-05 10:38:16 --> UTF-8 Support Enabled
INFO - 2023-06-05 10:38:16 --> Utf8 Class Initialized
INFO - 2023-06-05 10:38:16 --> URI Class Initialized
INFO - 2023-06-05 10:38:16 --> Router Class Initialized
INFO - 2023-06-05 10:38:16 --> Output Class Initialized
INFO - 2023-06-05 10:38:16 --> Security Class Initialized
DEBUG - 2023-06-05 10:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 10:38:16 --> Input Class Initialized
INFO - 2023-06-05 10:38:16 --> Language Class Initialized
INFO - 2023-06-05 10:38:16 --> Loader Class Initialized
INFO - 2023-06-05 10:38:16 --> Helper loaded: url_helper
INFO - 2023-06-05 10:38:16 --> Helper loaded: file_helper
INFO - 2023-06-05 10:38:16 --> Helper loaded: html_helper
INFO - 2023-06-05 10:38:16 --> Helper loaded: text_helper
INFO - 2023-06-05 10:38:16 --> Helper loaded: form_helper
INFO - 2023-06-05 10:38:16 --> Helper loaded: lang_helper
INFO - 2023-06-05 10:38:16 --> Helper loaded: security_helper
INFO - 2023-06-05 10:38:16 --> Helper loaded: cookie_helper
INFO - 2023-06-05 10:38:16 --> Database Driver Class Initialized
INFO - 2023-06-05 10:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 10:38:16 --> Parser Class Initialized
INFO - 2023-06-05 10:38:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 10:38:16 --> Pagination Class Initialized
INFO - 2023-06-05 10:38:16 --> Form Validation Class Initialized
INFO - 2023-06-05 10:38:16 --> Controller Class Initialized
INFO - 2023-06-05 10:38:16 --> Model Class Initialized
DEBUG - 2023-06-05 10:38:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 10:38:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:38:16 --> Model Class Initialized
DEBUG - 2023-06-05 10:38:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:38:16 --> Model Class Initialized
INFO - 2023-06-05 10:38:16 --> Final output sent to browser
DEBUG - 2023-06-05 10:38:16 --> Total execution time: 0.0601
ERROR - 2023-06-05 10:38:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 10:38:56 --> Config Class Initialized
INFO - 2023-06-05 10:38:56 --> Hooks Class Initialized
DEBUG - 2023-06-05 10:38:56 --> UTF-8 Support Enabled
INFO - 2023-06-05 10:38:56 --> Utf8 Class Initialized
INFO - 2023-06-05 10:38:56 --> URI Class Initialized
DEBUG - 2023-06-05 10:38:56 --> No URI present. Default controller set.
INFO - 2023-06-05 10:38:56 --> Router Class Initialized
INFO - 2023-06-05 10:38:56 --> Output Class Initialized
INFO - 2023-06-05 10:38:56 --> Security Class Initialized
DEBUG - 2023-06-05 10:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 10:38:56 --> Input Class Initialized
INFO - 2023-06-05 10:38:56 --> Language Class Initialized
INFO - 2023-06-05 10:38:56 --> Loader Class Initialized
INFO - 2023-06-05 10:38:56 --> Helper loaded: url_helper
INFO - 2023-06-05 10:38:56 --> Helper loaded: file_helper
INFO - 2023-06-05 10:38:56 --> Helper loaded: html_helper
INFO - 2023-06-05 10:38:56 --> Helper loaded: text_helper
INFO - 2023-06-05 10:38:56 --> Helper loaded: form_helper
INFO - 2023-06-05 10:38:56 --> Helper loaded: lang_helper
INFO - 2023-06-05 10:38:56 --> Helper loaded: security_helper
INFO - 2023-06-05 10:38:56 --> Helper loaded: cookie_helper
INFO - 2023-06-05 10:38:56 --> Database Driver Class Initialized
INFO - 2023-06-05 10:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 10:38:56 --> Parser Class Initialized
INFO - 2023-06-05 10:38:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 10:38:56 --> Pagination Class Initialized
INFO - 2023-06-05 10:38:56 --> Form Validation Class Initialized
INFO - 2023-06-05 10:38:56 --> Controller Class Initialized
INFO - 2023-06-05 10:38:56 --> Model Class Initialized
DEBUG - 2023-06-05 10:38:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:38:56 --> Model Class Initialized
DEBUG - 2023-06-05 10:38:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:38:56 --> Model Class Initialized
INFO - 2023-06-05 10:38:56 --> Model Class Initialized
INFO - 2023-06-05 10:38:56 --> Model Class Initialized
INFO - 2023-06-05 10:38:56 --> Model Class Initialized
DEBUG - 2023-06-05 10:38:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 10:38:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:38:56 --> Model Class Initialized
INFO - 2023-06-05 10:38:56 --> Model Class Initialized
INFO - 2023-06-05 10:38:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-05 10:38:56 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:38:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 10:38:56 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 10:38:56 --> Model Class Initialized
INFO - 2023-06-05 10:38:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 10:38:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 10:38:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 10:38:57 --> Final output sent to browser
DEBUG - 2023-06-05 10:38:57 --> Total execution time: 0.1961
ERROR - 2023-06-05 10:39:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 10:39:06 --> Config Class Initialized
INFO - 2023-06-05 10:39:06 --> Hooks Class Initialized
DEBUG - 2023-06-05 10:39:06 --> UTF-8 Support Enabled
INFO - 2023-06-05 10:39:06 --> Utf8 Class Initialized
INFO - 2023-06-05 10:39:06 --> URI Class Initialized
INFO - 2023-06-05 10:39:06 --> Router Class Initialized
INFO - 2023-06-05 10:39:06 --> Output Class Initialized
INFO - 2023-06-05 10:39:06 --> Security Class Initialized
DEBUG - 2023-06-05 10:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 10:39:06 --> Input Class Initialized
INFO - 2023-06-05 10:39:06 --> Language Class Initialized
INFO - 2023-06-05 10:39:06 --> Loader Class Initialized
INFO - 2023-06-05 10:39:06 --> Helper loaded: url_helper
INFO - 2023-06-05 10:39:06 --> Helper loaded: file_helper
INFO - 2023-06-05 10:39:06 --> Helper loaded: html_helper
INFO - 2023-06-05 10:39:06 --> Helper loaded: text_helper
INFO - 2023-06-05 10:39:06 --> Helper loaded: form_helper
INFO - 2023-06-05 10:39:06 --> Helper loaded: lang_helper
INFO - 2023-06-05 10:39:06 --> Helper loaded: security_helper
INFO - 2023-06-05 10:39:06 --> Helper loaded: cookie_helper
INFO - 2023-06-05 10:39:06 --> Database Driver Class Initialized
INFO - 2023-06-05 10:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 10:39:06 --> Parser Class Initialized
INFO - 2023-06-05 10:39:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 10:39:06 --> Pagination Class Initialized
INFO - 2023-06-05 10:39:06 --> Form Validation Class Initialized
INFO - 2023-06-05 10:39:06 --> Controller Class Initialized
INFO - 2023-06-05 10:39:06 --> Model Class Initialized
DEBUG - 2023-06-05 10:39:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 10:39:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:39:06 --> Model Class Initialized
DEBUG - 2023-06-05 10:39:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:39:06 --> Model Class Initialized
INFO - 2023-06-05 10:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-05 10:39:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 10:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 10:39:06 --> Model Class Initialized
INFO - 2023-06-05 10:39:06 --> Model Class Initialized
INFO - 2023-06-05 10:39:06 --> Model Class Initialized
INFO - 2023-06-05 10:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 10:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 10:39:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 10:39:06 --> Final output sent to browser
DEBUG - 2023-06-05 10:39:06 --> Total execution time: 0.1533
ERROR - 2023-06-05 10:39:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 10:39:07 --> Config Class Initialized
INFO - 2023-06-05 10:39:07 --> Hooks Class Initialized
DEBUG - 2023-06-05 10:39:07 --> UTF-8 Support Enabled
INFO - 2023-06-05 10:39:07 --> Utf8 Class Initialized
INFO - 2023-06-05 10:39:07 --> URI Class Initialized
INFO - 2023-06-05 10:39:07 --> Router Class Initialized
INFO - 2023-06-05 10:39:07 --> Output Class Initialized
INFO - 2023-06-05 10:39:07 --> Security Class Initialized
DEBUG - 2023-06-05 10:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 10:39:07 --> Input Class Initialized
INFO - 2023-06-05 10:39:07 --> Language Class Initialized
INFO - 2023-06-05 10:39:07 --> Loader Class Initialized
INFO - 2023-06-05 10:39:07 --> Helper loaded: url_helper
INFO - 2023-06-05 10:39:07 --> Helper loaded: file_helper
INFO - 2023-06-05 10:39:07 --> Helper loaded: html_helper
INFO - 2023-06-05 10:39:07 --> Helper loaded: text_helper
INFO - 2023-06-05 10:39:07 --> Helper loaded: form_helper
INFO - 2023-06-05 10:39:07 --> Helper loaded: lang_helper
INFO - 2023-06-05 10:39:07 --> Helper loaded: security_helper
INFO - 2023-06-05 10:39:07 --> Helper loaded: cookie_helper
INFO - 2023-06-05 10:39:07 --> Database Driver Class Initialized
INFO - 2023-06-05 10:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 10:39:07 --> Parser Class Initialized
INFO - 2023-06-05 10:39:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 10:39:07 --> Pagination Class Initialized
INFO - 2023-06-05 10:39:07 --> Form Validation Class Initialized
INFO - 2023-06-05 10:39:07 --> Controller Class Initialized
INFO - 2023-06-05 10:39:07 --> Model Class Initialized
DEBUG - 2023-06-05 10:39:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 10:39:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:39:07 --> Model Class Initialized
DEBUG - 2023-06-05 10:39:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:39:07 --> Model Class Initialized
INFO - 2023-06-05 10:39:07 --> Final output sent to browser
DEBUG - 2023-06-05 10:39:07 --> Total execution time: 0.0625
ERROR - 2023-06-05 10:39:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 10:39:11 --> Config Class Initialized
INFO - 2023-06-05 10:39:11 --> Hooks Class Initialized
DEBUG - 2023-06-05 10:39:11 --> UTF-8 Support Enabled
INFO - 2023-06-05 10:39:11 --> Utf8 Class Initialized
INFO - 2023-06-05 10:39:11 --> URI Class Initialized
INFO - 2023-06-05 10:39:11 --> Router Class Initialized
INFO - 2023-06-05 10:39:11 --> Output Class Initialized
INFO - 2023-06-05 10:39:11 --> Security Class Initialized
DEBUG - 2023-06-05 10:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 10:39:11 --> Input Class Initialized
INFO - 2023-06-05 10:39:11 --> Language Class Initialized
INFO - 2023-06-05 10:39:11 --> Loader Class Initialized
INFO - 2023-06-05 10:39:11 --> Helper loaded: url_helper
INFO - 2023-06-05 10:39:11 --> Helper loaded: file_helper
INFO - 2023-06-05 10:39:11 --> Helper loaded: html_helper
INFO - 2023-06-05 10:39:11 --> Helper loaded: text_helper
INFO - 2023-06-05 10:39:11 --> Helper loaded: form_helper
INFO - 2023-06-05 10:39:11 --> Helper loaded: lang_helper
INFO - 2023-06-05 10:39:11 --> Helper loaded: security_helper
INFO - 2023-06-05 10:39:11 --> Helper loaded: cookie_helper
INFO - 2023-06-05 10:39:11 --> Database Driver Class Initialized
INFO - 2023-06-05 10:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 10:39:11 --> Parser Class Initialized
INFO - 2023-06-05 10:39:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 10:39:11 --> Pagination Class Initialized
INFO - 2023-06-05 10:39:11 --> Form Validation Class Initialized
INFO - 2023-06-05 10:39:11 --> Controller Class Initialized
INFO - 2023-06-05 10:39:11 --> Model Class Initialized
DEBUG - 2023-06-05 10:39:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 10:39:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:39:11 --> Model Class Initialized
DEBUG - 2023-06-05 10:39:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:39:11 --> Model Class Initialized
INFO - 2023-06-05 10:39:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-05 10:39:11 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:39:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 10:39:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 10:39:11 --> Model Class Initialized
INFO - 2023-06-05 10:39:11 --> Model Class Initialized
INFO - 2023-06-05 10:39:11 --> Model Class Initialized
INFO - 2023-06-05 10:39:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 10:39:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 10:39:11 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 10:39:11 --> Final output sent to browser
DEBUG - 2023-06-05 10:39:11 --> Total execution time: 0.1477
ERROR - 2023-06-05 10:39:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 10:39:11 --> Config Class Initialized
INFO - 2023-06-05 10:39:11 --> Hooks Class Initialized
DEBUG - 2023-06-05 10:39:11 --> UTF-8 Support Enabled
INFO - 2023-06-05 10:39:11 --> Utf8 Class Initialized
INFO - 2023-06-05 10:39:11 --> URI Class Initialized
INFO - 2023-06-05 10:39:11 --> Router Class Initialized
INFO - 2023-06-05 10:39:11 --> Output Class Initialized
INFO - 2023-06-05 10:39:11 --> Security Class Initialized
DEBUG - 2023-06-05 10:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 10:39:11 --> Input Class Initialized
INFO - 2023-06-05 10:39:11 --> Language Class Initialized
INFO - 2023-06-05 10:39:11 --> Loader Class Initialized
INFO - 2023-06-05 10:39:11 --> Helper loaded: url_helper
INFO - 2023-06-05 10:39:11 --> Helper loaded: file_helper
INFO - 2023-06-05 10:39:11 --> Helper loaded: html_helper
INFO - 2023-06-05 10:39:11 --> Helper loaded: text_helper
INFO - 2023-06-05 10:39:11 --> Helper loaded: form_helper
INFO - 2023-06-05 10:39:11 --> Helper loaded: lang_helper
INFO - 2023-06-05 10:39:11 --> Helper loaded: security_helper
INFO - 2023-06-05 10:39:11 --> Helper loaded: cookie_helper
INFO - 2023-06-05 10:39:11 --> Database Driver Class Initialized
INFO - 2023-06-05 10:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 10:39:11 --> Parser Class Initialized
INFO - 2023-06-05 10:39:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 10:39:11 --> Pagination Class Initialized
INFO - 2023-06-05 10:39:11 --> Form Validation Class Initialized
INFO - 2023-06-05 10:39:11 --> Controller Class Initialized
INFO - 2023-06-05 10:39:11 --> Model Class Initialized
DEBUG - 2023-06-05 10:39:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 10:39:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:39:11 --> Model Class Initialized
DEBUG - 2023-06-05 10:39:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:39:11 --> Model Class Initialized
INFO - 2023-06-05 10:39:11 --> Final output sent to browser
DEBUG - 2023-06-05 10:39:11 --> Total execution time: 0.0604
ERROR - 2023-06-05 10:39:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 10:39:27 --> Config Class Initialized
INFO - 2023-06-05 10:39:27 --> Hooks Class Initialized
DEBUG - 2023-06-05 10:39:27 --> UTF-8 Support Enabled
INFO - 2023-06-05 10:39:27 --> Utf8 Class Initialized
INFO - 2023-06-05 10:39:27 --> URI Class Initialized
INFO - 2023-06-05 10:39:27 --> Router Class Initialized
INFO - 2023-06-05 10:39:27 --> Output Class Initialized
INFO - 2023-06-05 10:39:27 --> Security Class Initialized
DEBUG - 2023-06-05 10:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 10:39:27 --> Input Class Initialized
INFO - 2023-06-05 10:39:27 --> Language Class Initialized
INFO - 2023-06-05 10:39:27 --> Loader Class Initialized
INFO - 2023-06-05 10:39:27 --> Helper loaded: url_helper
INFO - 2023-06-05 10:39:27 --> Helper loaded: file_helper
INFO - 2023-06-05 10:39:27 --> Helper loaded: html_helper
INFO - 2023-06-05 10:39:27 --> Helper loaded: text_helper
INFO - 2023-06-05 10:39:27 --> Helper loaded: form_helper
INFO - 2023-06-05 10:39:27 --> Helper loaded: lang_helper
INFO - 2023-06-05 10:39:27 --> Helper loaded: security_helper
INFO - 2023-06-05 10:39:27 --> Helper loaded: cookie_helper
INFO - 2023-06-05 10:39:27 --> Database Driver Class Initialized
INFO - 2023-06-05 10:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 10:39:27 --> Parser Class Initialized
INFO - 2023-06-05 10:39:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 10:39:27 --> Pagination Class Initialized
INFO - 2023-06-05 10:39:27 --> Form Validation Class Initialized
INFO - 2023-06-05 10:39:27 --> Controller Class Initialized
INFO - 2023-06-05 10:39:27 --> Model Class Initialized
DEBUG - 2023-06-05 10:39:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 10:39:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:39:27 --> Model Class Initialized
DEBUG - 2023-06-05 10:39:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:39:27 --> Model Class Initialized
INFO - 2023-06-05 10:39:27 --> Final output sent to browser
DEBUG - 2023-06-05 10:39:27 --> Total execution time: 0.0622
ERROR - 2023-06-05 10:39:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 10:39:30 --> Config Class Initialized
INFO - 2023-06-05 10:39:30 --> Hooks Class Initialized
DEBUG - 2023-06-05 10:39:30 --> UTF-8 Support Enabled
INFO - 2023-06-05 10:39:30 --> Utf8 Class Initialized
INFO - 2023-06-05 10:39:30 --> URI Class Initialized
INFO - 2023-06-05 10:39:30 --> Router Class Initialized
INFO - 2023-06-05 10:39:30 --> Output Class Initialized
INFO - 2023-06-05 10:39:30 --> Security Class Initialized
DEBUG - 2023-06-05 10:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 10:39:30 --> Input Class Initialized
INFO - 2023-06-05 10:39:30 --> Language Class Initialized
INFO - 2023-06-05 10:39:30 --> Loader Class Initialized
INFO - 2023-06-05 10:39:30 --> Helper loaded: url_helper
INFO - 2023-06-05 10:39:30 --> Helper loaded: file_helper
INFO - 2023-06-05 10:39:30 --> Helper loaded: html_helper
INFO - 2023-06-05 10:39:30 --> Helper loaded: text_helper
INFO - 2023-06-05 10:39:30 --> Helper loaded: form_helper
INFO - 2023-06-05 10:39:30 --> Helper loaded: lang_helper
INFO - 2023-06-05 10:39:30 --> Helper loaded: security_helper
INFO - 2023-06-05 10:39:30 --> Helper loaded: cookie_helper
INFO - 2023-06-05 10:39:30 --> Database Driver Class Initialized
INFO - 2023-06-05 10:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 10:39:30 --> Parser Class Initialized
INFO - 2023-06-05 10:39:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 10:39:30 --> Pagination Class Initialized
INFO - 2023-06-05 10:39:30 --> Form Validation Class Initialized
INFO - 2023-06-05 10:39:30 --> Controller Class Initialized
INFO - 2023-06-05 10:39:30 --> Model Class Initialized
DEBUG - 2023-06-05 10:39:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 10:39:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:39:30 --> Model Class Initialized
DEBUG - 2023-06-05 10:39:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:39:30 --> Model Class Initialized
INFO - 2023-06-05 10:39:30 --> Final output sent to browser
DEBUG - 2023-06-05 10:39:30 --> Total execution time: 0.0596
ERROR - 2023-06-05 10:39:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 10:39:38 --> Config Class Initialized
INFO - 2023-06-05 10:39:38 --> Hooks Class Initialized
DEBUG - 2023-06-05 10:39:38 --> UTF-8 Support Enabled
INFO - 2023-06-05 10:39:38 --> Utf8 Class Initialized
INFO - 2023-06-05 10:39:38 --> URI Class Initialized
INFO - 2023-06-05 10:39:38 --> Router Class Initialized
INFO - 2023-06-05 10:39:38 --> Output Class Initialized
INFO - 2023-06-05 10:39:38 --> Security Class Initialized
DEBUG - 2023-06-05 10:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 10:39:38 --> Input Class Initialized
INFO - 2023-06-05 10:39:38 --> Language Class Initialized
INFO - 2023-06-05 10:39:38 --> Loader Class Initialized
INFO - 2023-06-05 10:39:38 --> Helper loaded: url_helper
INFO - 2023-06-05 10:39:38 --> Helper loaded: file_helper
INFO - 2023-06-05 10:39:38 --> Helper loaded: html_helper
INFO - 2023-06-05 10:39:38 --> Helper loaded: text_helper
INFO - 2023-06-05 10:39:38 --> Helper loaded: form_helper
INFO - 2023-06-05 10:39:38 --> Helper loaded: lang_helper
INFO - 2023-06-05 10:39:38 --> Helper loaded: security_helper
INFO - 2023-06-05 10:39:38 --> Helper loaded: cookie_helper
INFO - 2023-06-05 10:39:38 --> Database Driver Class Initialized
INFO - 2023-06-05 10:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 10:39:38 --> Parser Class Initialized
INFO - 2023-06-05 10:39:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 10:39:38 --> Pagination Class Initialized
INFO - 2023-06-05 10:39:38 --> Form Validation Class Initialized
INFO - 2023-06-05 10:39:38 --> Controller Class Initialized
DEBUG - 2023-06-05 10:39:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 10:39:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:39:38 --> Model Class Initialized
DEBUG - 2023-06-05 10:39:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:39:38 --> Model Class Initialized
DEBUG - 2023-06-05 10:39:38 --> Lcustomer class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:39:38 --> Model Class Initialized
INFO - 2023-06-05 10:39:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/customer/customer.php
DEBUG - 2023-06-05 10:39:38 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:39:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 10:39:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 10:39:38 --> Model Class Initialized
INFO - 2023-06-05 10:39:38 --> Model Class Initialized
INFO - 2023-06-05 10:39:38 --> Model Class Initialized
INFO - 2023-06-05 10:39:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 10:39:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 10:39:38 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 10:39:38 --> Final output sent to browser
DEBUG - 2023-06-05 10:39:38 --> Total execution time: 0.1560
ERROR - 2023-06-05 10:39:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 10:39:39 --> Config Class Initialized
INFO - 2023-06-05 10:39:39 --> Hooks Class Initialized
DEBUG - 2023-06-05 10:39:39 --> UTF-8 Support Enabled
INFO - 2023-06-05 10:39:39 --> Utf8 Class Initialized
INFO - 2023-06-05 10:39:39 --> URI Class Initialized
INFO - 2023-06-05 10:39:39 --> Router Class Initialized
INFO - 2023-06-05 10:39:39 --> Output Class Initialized
INFO - 2023-06-05 10:39:39 --> Security Class Initialized
DEBUG - 2023-06-05 10:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 10:39:39 --> Input Class Initialized
INFO - 2023-06-05 10:39:39 --> Language Class Initialized
INFO - 2023-06-05 10:39:39 --> Loader Class Initialized
INFO - 2023-06-05 10:39:39 --> Helper loaded: url_helper
INFO - 2023-06-05 10:39:39 --> Helper loaded: file_helper
INFO - 2023-06-05 10:39:39 --> Helper loaded: html_helper
INFO - 2023-06-05 10:39:39 --> Helper loaded: text_helper
INFO - 2023-06-05 10:39:39 --> Helper loaded: form_helper
INFO - 2023-06-05 10:39:39 --> Helper loaded: lang_helper
INFO - 2023-06-05 10:39:39 --> Helper loaded: security_helper
INFO - 2023-06-05 10:39:39 --> Helper loaded: cookie_helper
INFO - 2023-06-05 10:39:39 --> Database Driver Class Initialized
INFO - 2023-06-05 10:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 10:39:39 --> Parser Class Initialized
INFO - 2023-06-05 10:39:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 10:39:39 --> Pagination Class Initialized
INFO - 2023-06-05 10:39:39 --> Form Validation Class Initialized
INFO - 2023-06-05 10:39:39 --> Controller Class Initialized
DEBUG - 2023-06-05 10:39:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 10:39:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:39:39 --> Model Class Initialized
DEBUG - 2023-06-05 10:39:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:39:39 --> Model Class Initialized
INFO - 2023-06-05 10:39:39 --> Final output sent to browser
DEBUG - 2023-06-05 10:39:39 --> Total execution time: 0.0313
ERROR - 2023-06-05 10:39:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 10:39:52 --> Config Class Initialized
INFO - 2023-06-05 10:39:52 --> Hooks Class Initialized
DEBUG - 2023-06-05 10:39:52 --> UTF-8 Support Enabled
INFO - 2023-06-05 10:39:52 --> Utf8 Class Initialized
INFO - 2023-06-05 10:39:52 --> URI Class Initialized
INFO - 2023-06-05 10:39:52 --> Router Class Initialized
INFO - 2023-06-05 10:39:52 --> Output Class Initialized
INFO - 2023-06-05 10:39:52 --> Security Class Initialized
DEBUG - 2023-06-05 10:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 10:39:52 --> Input Class Initialized
INFO - 2023-06-05 10:39:52 --> Language Class Initialized
INFO - 2023-06-05 10:39:52 --> Loader Class Initialized
INFO - 2023-06-05 10:39:52 --> Helper loaded: url_helper
INFO - 2023-06-05 10:39:52 --> Helper loaded: file_helper
INFO - 2023-06-05 10:39:52 --> Helper loaded: html_helper
INFO - 2023-06-05 10:39:52 --> Helper loaded: text_helper
INFO - 2023-06-05 10:39:52 --> Helper loaded: form_helper
INFO - 2023-06-05 10:39:52 --> Helper loaded: lang_helper
INFO - 2023-06-05 10:39:52 --> Helper loaded: security_helper
INFO - 2023-06-05 10:39:52 --> Helper loaded: cookie_helper
INFO - 2023-06-05 10:39:52 --> Database Driver Class Initialized
INFO - 2023-06-05 10:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 10:39:52 --> Parser Class Initialized
INFO - 2023-06-05 10:39:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 10:39:52 --> Pagination Class Initialized
INFO - 2023-06-05 10:39:52 --> Form Validation Class Initialized
INFO - 2023-06-05 10:39:52 --> Controller Class Initialized
INFO - 2023-06-05 10:39:52 --> Model Class Initialized
DEBUG - 2023-06-05 10:39:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 10:39:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:39:52 --> Model Class Initialized
INFO - 2023-06-05 10:39:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/customer_demandrequest.php
DEBUG - 2023-06-05 10:39:52 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:39:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 10:39:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 10:39:52 --> Model Class Initialized
INFO - 2023-06-05 10:39:52 --> Model Class Initialized
INFO - 2023-06-05 10:39:52 --> Model Class Initialized
INFO - 2023-06-05 10:39:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 10:39:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 10:39:52 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 10:39:52 --> Final output sent to browser
DEBUG - 2023-06-05 10:39:52 --> Total execution time: 0.1445
ERROR - 2023-06-05 10:39:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 10:39:52 --> Config Class Initialized
INFO - 2023-06-05 10:39:52 --> Hooks Class Initialized
DEBUG - 2023-06-05 10:39:52 --> UTF-8 Support Enabled
INFO - 2023-06-05 10:39:52 --> Utf8 Class Initialized
INFO - 2023-06-05 10:39:52 --> URI Class Initialized
INFO - 2023-06-05 10:39:52 --> Router Class Initialized
INFO - 2023-06-05 10:39:52 --> Output Class Initialized
INFO - 2023-06-05 10:39:52 --> Security Class Initialized
DEBUG - 2023-06-05 10:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 10:39:52 --> Input Class Initialized
INFO - 2023-06-05 10:39:52 --> Language Class Initialized
INFO - 2023-06-05 10:39:52 --> Loader Class Initialized
INFO - 2023-06-05 10:39:52 --> Helper loaded: url_helper
INFO - 2023-06-05 10:39:52 --> Helper loaded: file_helper
INFO - 2023-06-05 10:39:52 --> Helper loaded: html_helper
INFO - 2023-06-05 10:39:52 --> Helper loaded: text_helper
INFO - 2023-06-05 10:39:52 --> Helper loaded: form_helper
INFO - 2023-06-05 10:39:52 --> Helper loaded: lang_helper
INFO - 2023-06-05 10:39:52 --> Helper loaded: security_helper
INFO - 2023-06-05 10:39:52 --> Helper loaded: cookie_helper
INFO - 2023-06-05 10:39:52 --> Database Driver Class Initialized
INFO - 2023-06-05 10:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 10:39:52 --> Parser Class Initialized
INFO - 2023-06-05 10:39:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 10:39:52 --> Pagination Class Initialized
INFO - 2023-06-05 10:39:52 --> Form Validation Class Initialized
INFO - 2023-06-05 10:39:52 --> Controller Class Initialized
INFO - 2023-06-05 10:39:52 --> Model Class Initialized
DEBUG - 2023-06-05 10:39:52 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 10:39:52 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:39:52 --> Model Class Initialized
INFO - 2023-06-05 10:39:52 --> Final output sent to browser
DEBUG - 2023-06-05 10:39:52 --> Total execution time: 0.0286
ERROR - 2023-06-05 10:40:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 10:40:06 --> Config Class Initialized
INFO - 2023-06-05 10:40:06 --> Hooks Class Initialized
DEBUG - 2023-06-05 10:40:06 --> UTF-8 Support Enabled
INFO - 2023-06-05 10:40:06 --> Utf8 Class Initialized
INFO - 2023-06-05 10:40:06 --> URI Class Initialized
INFO - 2023-06-05 10:40:06 --> Router Class Initialized
INFO - 2023-06-05 10:40:06 --> Output Class Initialized
INFO - 2023-06-05 10:40:06 --> Security Class Initialized
DEBUG - 2023-06-05 10:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 10:40:06 --> Input Class Initialized
INFO - 2023-06-05 10:40:06 --> Language Class Initialized
INFO - 2023-06-05 10:40:06 --> Loader Class Initialized
INFO - 2023-06-05 10:40:06 --> Helper loaded: url_helper
INFO - 2023-06-05 10:40:06 --> Helper loaded: file_helper
INFO - 2023-06-05 10:40:06 --> Helper loaded: html_helper
INFO - 2023-06-05 10:40:06 --> Helper loaded: text_helper
INFO - 2023-06-05 10:40:06 --> Helper loaded: form_helper
INFO - 2023-06-05 10:40:06 --> Helper loaded: lang_helper
INFO - 2023-06-05 10:40:06 --> Helper loaded: security_helper
INFO - 2023-06-05 10:40:06 --> Helper loaded: cookie_helper
INFO - 2023-06-05 10:40:06 --> Database Driver Class Initialized
INFO - 2023-06-05 10:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 10:40:06 --> Parser Class Initialized
INFO - 2023-06-05 10:40:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 10:40:06 --> Pagination Class Initialized
INFO - 2023-06-05 10:40:06 --> Form Validation Class Initialized
INFO - 2023-06-05 10:40:06 --> Controller Class Initialized
INFO - 2023-06-05 10:40:06 --> Model Class Initialized
DEBUG - 2023-06-05 10:40:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 10:40:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:40:06 --> Model Class Initialized
INFO - 2023-06-05 10:40:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/demandrequest/demandrequest.php
DEBUG - 2023-06-05 10:40:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:40:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 10:40:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 10:40:06 --> Model Class Initialized
INFO - 2023-06-05 10:40:06 --> Model Class Initialized
INFO - 2023-06-05 10:40:06 --> Model Class Initialized
INFO - 2023-06-05 10:40:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 10:40:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 10:40:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 10:40:06 --> Final output sent to browser
DEBUG - 2023-06-05 10:40:06 --> Total execution time: 0.1444
ERROR - 2023-06-05 10:40:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 10:40:06 --> Config Class Initialized
INFO - 2023-06-05 10:40:06 --> Hooks Class Initialized
DEBUG - 2023-06-05 10:40:06 --> UTF-8 Support Enabled
INFO - 2023-06-05 10:40:06 --> Utf8 Class Initialized
INFO - 2023-06-05 10:40:06 --> URI Class Initialized
INFO - 2023-06-05 10:40:06 --> Router Class Initialized
INFO - 2023-06-05 10:40:06 --> Output Class Initialized
INFO - 2023-06-05 10:40:06 --> Security Class Initialized
DEBUG - 2023-06-05 10:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 10:40:06 --> Input Class Initialized
INFO - 2023-06-05 10:40:06 --> Language Class Initialized
INFO - 2023-06-05 10:40:06 --> Loader Class Initialized
INFO - 2023-06-05 10:40:06 --> Helper loaded: url_helper
INFO - 2023-06-05 10:40:06 --> Helper loaded: file_helper
INFO - 2023-06-05 10:40:06 --> Helper loaded: html_helper
INFO - 2023-06-05 10:40:06 --> Helper loaded: text_helper
INFO - 2023-06-05 10:40:06 --> Helper loaded: form_helper
INFO - 2023-06-05 10:40:06 --> Helper loaded: lang_helper
INFO - 2023-06-05 10:40:06 --> Helper loaded: security_helper
INFO - 2023-06-05 10:40:06 --> Helper loaded: cookie_helper
INFO - 2023-06-05 10:40:06 --> Database Driver Class Initialized
INFO - 2023-06-05 10:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 10:40:06 --> Parser Class Initialized
INFO - 2023-06-05 10:40:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 10:40:06 --> Pagination Class Initialized
INFO - 2023-06-05 10:40:06 --> Form Validation Class Initialized
INFO - 2023-06-05 10:40:06 --> Controller Class Initialized
INFO - 2023-06-05 10:40:06 --> Model Class Initialized
DEBUG - 2023-06-05 10:40:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 10:40:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:40:06 --> Model Class Initialized
INFO - 2023-06-05 10:40:06 --> Final output sent to browser
DEBUG - 2023-06-05 10:40:06 --> Total execution time: 0.0188
ERROR - 2023-06-05 10:41:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 10:41:58 --> Config Class Initialized
INFO - 2023-06-05 10:41:58 --> Hooks Class Initialized
DEBUG - 2023-06-05 10:41:58 --> UTF-8 Support Enabled
INFO - 2023-06-05 10:41:58 --> Utf8 Class Initialized
INFO - 2023-06-05 10:41:58 --> URI Class Initialized
INFO - 2023-06-05 10:41:58 --> Router Class Initialized
INFO - 2023-06-05 10:41:58 --> Output Class Initialized
INFO - 2023-06-05 10:41:58 --> Security Class Initialized
DEBUG - 2023-06-05 10:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 10:41:58 --> Input Class Initialized
INFO - 2023-06-05 10:41:58 --> Language Class Initialized
INFO - 2023-06-05 10:41:58 --> Loader Class Initialized
INFO - 2023-06-05 10:41:58 --> Helper loaded: url_helper
INFO - 2023-06-05 10:41:58 --> Helper loaded: file_helper
INFO - 2023-06-05 10:41:58 --> Helper loaded: html_helper
INFO - 2023-06-05 10:41:58 --> Helper loaded: text_helper
INFO - 2023-06-05 10:41:58 --> Helper loaded: form_helper
INFO - 2023-06-05 10:41:58 --> Helper loaded: lang_helper
INFO - 2023-06-05 10:41:58 --> Helper loaded: security_helper
INFO - 2023-06-05 10:41:58 --> Helper loaded: cookie_helper
INFO - 2023-06-05 10:41:58 --> Database Driver Class Initialized
INFO - 2023-06-05 10:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 10:41:58 --> Parser Class Initialized
INFO - 2023-06-05 10:41:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 10:41:58 --> Pagination Class Initialized
INFO - 2023-06-05 10:41:58 --> Form Validation Class Initialized
INFO - 2023-06-05 10:41:58 --> Controller Class Initialized
INFO - 2023-06-05 10:41:58 --> Model Class Initialized
INFO - 2023-06-05 10:41:58 --> Model Class Initialized
INFO - 2023-06-05 10:41:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-06-05 10:41:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:41:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 10:41:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 10:41:58 --> Model Class Initialized
INFO - 2023-06-05 10:41:58 --> Model Class Initialized
INFO - 2023-06-05 10:41:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 10:41:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 10:41:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 10:41:58 --> Final output sent to browser
DEBUG - 2023-06-05 10:41:58 --> Total execution time: 0.1436
ERROR - 2023-06-05 10:41:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 10:41:59 --> Config Class Initialized
INFO - 2023-06-05 10:41:59 --> Hooks Class Initialized
DEBUG - 2023-06-05 10:41:59 --> UTF-8 Support Enabled
INFO - 2023-06-05 10:41:59 --> Utf8 Class Initialized
INFO - 2023-06-05 10:41:59 --> URI Class Initialized
INFO - 2023-06-05 10:41:59 --> Router Class Initialized
INFO - 2023-06-05 10:41:59 --> Output Class Initialized
INFO - 2023-06-05 10:41:59 --> Security Class Initialized
DEBUG - 2023-06-05 10:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 10:41:59 --> Input Class Initialized
INFO - 2023-06-05 10:41:59 --> Language Class Initialized
INFO - 2023-06-05 10:41:59 --> Loader Class Initialized
INFO - 2023-06-05 10:41:59 --> Helper loaded: url_helper
INFO - 2023-06-05 10:41:59 --> Helper loaded: file_helper
INFO - 2023-06-05 10:41:59 --> Helper loaded: html_helper
INFO - 2023-06-05 10:41:59 --> Helper loaded: text_helper
INFO - 2023-06-05 10:41:59 --> Helper loaded: form_helper
INFO - 2023-06-05 10:41:59 --> Helper loaded: lang_helper
INFO - 2023-06-05 10:41:59 --> Helper loaded: security_helper
INFO - 2023-06-05 10:41:59 --> Helper loaded: cookie_helper
INFO - 2023-06-05 10:41:59 --> Database Driver Class Initialized
INFO - 2023-06-05 10:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 10:41:59 --> Parser Class Initialized
INFO - 2023-06-05 10:41:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 10:41:59 --> Pagination Class Initialized
INFO - 2023-06-05 10:41:59 --> Form Validation Class Initialized
INFO - 2023-06-05 10:41:59 --> Controller Class Initialized
INFO - 2023-06-05 10:41:59 --> Model Class Initialized
INFO - 2023-06-05 10:41:59 --> Model Class Initialized
INFO - 2023-06-05 10:41:59 --> Final output sent to browser
DEBUG - 2023-06-05 10:41:59 --> Total execution time: 0.0329
ERROR - 2023-06-05 10:42:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 10:42:02 --> Config Class Initialized
INFO - 2023-06-05 10:42:02 --> Hooks Class Initialized
DEBUG - 2023-06-05 10:42:02 --> UTF-8 Support Enabled
INFO - 2023-06-05 10:42:02 --> Utf8 Class Initialized
INFO - 2023-06-05 10:42:02 --> URI Class Initialized
INFO - 2023-06-05 10:42:02 --> Router Class Initialized
INFO - 2023-06-05 10:42:02 --> Output Class Initialized
INFO - 2023-06-05 10:42:02 --> Security Class Initialized
DEBUG - 2023-06-05 10:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 10:42:02 --> Input Class Initialized
INFO - 2023-06-05 10:42:02 --> Language Class Initialized
INFO - 2023-06-05 10:42:02 --> Loader Class Initialized
INFO - 2023-06-05 10:42:02 --> Helper loaded: url_helper
INFO - 2023-06-05 10:42:02 --> Helper loaded: file_helper
INFO - 2023-06-05 10:42:02 --> Helper loaded: html_helper
INFO - 2023-06-05 10:42:02 --> Helper loaded: text_helper
INFO - 2023-06-05 10:42:02 --> Helper loaded: form_helper
INFO - 2023-06-05 10:42:02 --> Helper loaded: lang_helper
INFO - 2023-06-05 10:42:02 --> Helper loaded: security_helper
INFO - 2023-06-05 10:42:02 --> Helper loaded: cookie_helper
INFO - 2023-06-05 10:42:02 --> Database Driver Class Initialized
INFO - 2023-06-05 10:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 10:42:02 --> Parser Class Initialized
INFO - 2023-06-05 10:42:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 10:42:02 --> Pagination Class Initialized
INFO - 2023-06-05 10:42:02 --> Form Validation Class Initialized
INFO - 2023-06-05 10:42:02 --> Controller Class Initialized
INFO - 2023-06-05 10:42:02 --> Model Class Initialized
INFO - 2023-06-05 10:42:02 --> Model Class Initialized
INFO - 2023-06-05 10:42:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-06-05 10:42:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 10:42:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 10:42:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 10:42:02 --> Model Class Initialized
INFO - 2023-06-05 10:42:02 --> Model Class Initialized
INFO - 2023-06-05 10:42:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 10:42:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 10:42:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 10:42:02 --> Final output sent to browser
DEBUG - 2023-06-05 10:42:02 --> Total execution time: 0.1367
ERROR - 2023-06-05 10:42:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 10:42:03 --> Config Class Initialized
INFO - 2023-06-05 10:42:03 --> Hooks Class Initialized
DEBUG - 2023-06-05 10:42:03 --> UTF-8 Support Enabled
INFO - 2023-06-05 10:42:03 --> Utf8 Class Initialized
INFO - 2023-06-05 10:42:03 --> URI Class Initialized
INFO - 2023-06-05 10:42:03 --> Router Class Initialized
INFO - 2023-06-05 10:42:03 --> Output Class Initialized
INFO - 2023-06-05 10:42:03 --> Security Class Initialized
DEBUG - 2023-06-05 10:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 10:42:03 --> Input Class Initialized
INFO - 2023-06-05 10:42:03 --> Language Class Initialized
INFO - 2023-06-05 10:42:03 --> Loader Class Initialized
INFO - 2023-06-05 10:42:03 --> Helper loaded: url_helper
INFO - 2023-06-05 10:42:03 --> Helper loaded: file_helper
INFO - 2023-06-05 10:42:03 --> Helper loaded: html_helper
INFO - 2023-06-05 10:42:03 --> Helper loaded: text_helper
INFO - 2023-06-05 10:42:03 --> Helper loaded: form_helper
INFO - 2023-06-05 10:42:03 --> Helper loaded: lang_helper
INFO - 2023-06-05 10:42:03 --> Helper loaded: security_helper
INFO - 2023-06-05 10:42:03 --> Helper loaded: cookie_helper
INFO - 2023-06-05 10:42:03 --> Database Driver Class Initialized
INFO - 2023-06-05 10:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 10:42:03 --> Parser Class Initialized
INFO - 2023-06-05 10:42:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 10:42:03 --> Pagination Class Initialized
INFO - 2023-06-05 10:42:03 --> Form Validation Class Initialized
INFO - 2023-06-05 10:42:03 --> Controller Class Initialized
INFO - 2023-06-05 10:42:03 --> Model Class Initialized
INFO - 2023-06-05 10:42:03 --> Model Class Initialized
INFO - 2023-06-05 10:42:03 --> Final output sent to browser
DEBUG - 2023-06-05 10:42:03 --> Total execution time: 0.0177
ERROR - 2023-06-05 13:48:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 13:48:49 --> Config Class Initialized
INFO - 2023-06-05 13:48:49 --> Hooks Class Initialized
DEBUG - 2023-06-05 13:48:49 --> UTF-8 Support Enabled
INFO - 2023-06-05 13:48:49 --> Utf8 Class Initialized
INFO - 2023-06-05 13:48:49 --> URI Class Initialized
DEBUG - 2023-06-05 13:48:49 --> No URI present. Default controller set.
INFO - 2023-06-05 13:48:49 --> Router Class Initialized
INFO - 2023-06-05 13:48:49 --> Output Class Initialized
INFO - 2023-06-05 13:48:49 --> Security Class Initialized
DEBUG - 2023-06-05 13:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 13:48:49 --> Input Class Initialized
INFO - 2023-06-05 13:48:49 --> Language Class Initialized
INFO - 2023-06-05 13:48:49 --> Loader Class Initialized
INFO - 2023-06-05 13:48:49 --> Helper loaded: url_helper
INFO - 2023-06-05 13:48:49 --> Helper loaded: file_helper
INFO - 2023-06-05 13:48:49 --> Helper loaded: html_helper
INFO - 2023-06-05 13:48:49 --> Helper loaded: text_helper
INFO - 2023-06-05 13:48:49 --> Helper loaded: form_helper
INFO - 2023-06-05 13:48:49 --> Helper loaded: lang_helper
INFO - 2023-06-05 13:48:49 --> Helper loaded: security_helper
INFO - 2023-06-05 13:48:49 --> Helper loaded: cookie_helper
INFO - 2023-06-05 13:48:49 --> Database Driver Class Initialized
INFO - 2023-06-05 13:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 13:48:49 --> Parser Class Initialized
INFO - 2023-06-05 13:48:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 13:48:49 --> Pagination Class Initialized
INFO - 2023-06-05 13:48:49 --> Form Validation Class Initialized
INFO - 2023-06-05 13:48:49 --> Controller Class Initialized
INFO - 2023-06-05 13:48:49 --> Model Class Initialized
DEBUG - 2023-06-05 13:48:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-05 13:48:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 13:48:50 --> Config Class Initialized
INFO - 2023-06-05 13:48:50 --> Hooks Class Initialized
DEBUG - 2023-06-05 13:48:50 --> UTF-8 Support Enabled
INFO - 2023-06-05 13:48:50 --> Utf8 Class Initialized
INFO - 2023-06-05 13:48:50 --> URI Class Initialized
INFO - 2023-06-05 13:48:50 --> Router Class Initialized
INFO - 2023-06-05 13:48:50 --> Output Class Initialized
INFO - 2023-06-05 13:48:50 --> Security Class Initialized
DEBUG - 2023-06-05 13:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 13:48:50 --> Input Class Initialized
INFO - 2023-06-05 13:48:50 --> Language Class Initialized
INFO - 2023-06-05 13:48:50 --> Loader Class Initialized
INFO - 2023-06-05 13:48:50 --> Helper loaded: url_helper
INFO - 2023-06-05 13:48:50 --> Helper loaded: file_helper
INFO - 2023-06-05 13:48:50 --> Helper loaded: html_helper
INFO - 2023-06-05 13:48:50 --> Helper loaded: text_helper
INFO - 2023-06-05 13:48:50 --> Helper loaded: form_helper
INFO - 2023-06-05 13:48:50 --> Helper loaded: lang_helper
INFO - 2023-06-05 13:48:50 --> Helper loaded: security_helper
INFO - 2023-06-05 13:48:50 --> Helper loaded: cookie_helper
INFO - 2023-06-05 13:48:50 --> Database Driver Class Initialized
INFO - 2023-06-05 13:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 13:48:50 --> Parser Class Initialized
INFO - 2023-06-05 13:48:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 13:48:50 --> Pagination Class Initialized
INFO - 2023-06-05 13:48:50 --> Form Validation Class Initialized
INFO - 2023-06-05 13:48:50 --> Controller Class Initialized
INFO - 2023-06-05 13:48:50 --> Model Class Initialized
DEBUG - 2023-06-05 13:48:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:48:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-05 13:48:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:48:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 13:48:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 13:48:50 --> Model Class Initialized
INFO - 2023-06-05 13:48:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 13:48:50 --> Final output sent to browser
DEBUG - 2023-06-05 13:48:50 --> Total execution time: 0.0356
ERROR - 2023-06-05 13:49:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 13:49:20 --> Config Class Initialized
INFO - 2023-06-05 13:49:20 --> Hooks Class Initialized
DEBUG - 2023-06-05 13:49:20 --> UTF-8 Support Enabled
INFO - 2023-06-05 13:49:20 --> Utf8 Class Initialized
INFO - 2023-06-05 13:49:20 --> URI Class Initialized
INFO - 2023-06-05 13:49:20 --> Router Class Initialized
INFO - 2023-06-05 13:49:20 --> Output Class Initialized
INFO - 2023-06-05 13:49:20 --> Security Class Initialized
DEBUG - 2023-06-05 13:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 13:49:20 --> Input Class Initialized
INFO - 2023-06-05 13:49:20 --> Language Class Initialized
INFO - 2023-06-05 13:49:20 --> Loader Class Initialized
INFO - 2023-06-05 13:49:20 --> Helper loaded: url_helper
INFO - 2023-06-05 13:49:20 --> Helper loaded: file_helper
INFO - 2023-06-05 13:49:20 --> Helper loaded: html_helper
INFO - 2023-06-05 13:49:20 --> Helper loaded: text_helper
INFO - 2023-06-05 13:49:20 --> Helper loaded: form_helper
INFO - 2023-06-05 13:49:20 --> Helper loaded: lang_helper
INFO - 2023-06-05 13:49:20 --> Helper loaded: security_helper
INFO - 2023-06-05 13:49:20 --> Helper loaded: cookie_helper
INFO - 2023-06-05 13:49:20 --> Database Driver Class Initialized
INFO - 2023-06-05 13:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 13:49:20 --> Parser Class Initialized
INFO - 2023-06-05 13:49:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 13:49:20 --> Pagination Class Initialized
INFO - 2023-06-05 13:49:20 --> Form Validation Class Initialized
INFO - 2023-06-05 13:49:20 --> Controller Class Initialized
INFO - 2023-06-05 13:49:20 --> Model Class Initialized
DEBUG - 2023-06-05 13:49:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:49:20 --> Model Class Initialized
INFO - 2023-06-05 13:49:20 --> Final output sent to browser
DEBUG - 2023-06-05 13:49:20 --> Total execution time: 0.0219
ERROR - 2023-06-05 13:49:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 13:49:27 --> Config Class Initialized
INFO - 2023-06-05 13:49:27 --> Hooks Class Initialized
DEBUG - 2023-06-05 13:49:27 --> UTF-8 Support Enabled
INFO - 2023-06-05 13:49:27 --> Utf8 Class Initialized
INFO - 2023-06-05 13:49:27 --> URI Class Initialized
INFO - 2023-06-05 13:49:27 --> Router Class Initialized
INFO - 2023-06-05 13:49:27 --> Output Class Initialized
INFO - 2023-06-05 13:49:27 --> Security Class Initialized
DEBUG - 2023-06-05 13:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 13:49:27 --> Input Class Initialized
INFO - 2023-06-05 13:49:27 --> Language Class Initialized
INFO - 2023-06-05 13:49:27 --> Loader Class Initialized
INFO - 2023-06-05 13:49:27 --> Helper loaded: url_helper
INFO - 2023-06-05 13:49:27 --> Helper loaded: file_helper
INFO - 2023-06-05 13:49:27 --> Helper loaded: html_helper
INFO - 2023-06-05 13:49:27 --> Helper loaded: text_helper
INFO - 2023-06-05 13:49:27 --> Helper loaded: form_helper
INFO - 2023-06-05 13:49:27 --> Helper loaded: lang_helper
INFO - 2023-06-05 13:49:27 --> Helper loaded: security_helper
INFO - 2023-06-05 13:49:27 --> Helper loaded: cookie_helper
INFO - 2023-06-05 13:49:27 --> Database Driver Class Initialized
INFO - 2023-06-05 13:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 13:49:27 --> Parser Class Initialized
INFO - 2023-06-05 13:49:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 13:49:27 --> Pagination Class Initialized
INFO - 2023-06-05 13:49:27 --> Form Validation Class Initialized
INFO - 2023-06-05 13:49:27 --> Controller Class Initialized
INFO - 2023-06-05 13:49:27 --> Model Class Initialized
DEBUG - 2023-06-05 13:49:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:49:27 --> Model Class Initialized
INFO - 2023-06-05 13:49:27 --> Final output sent to browser
DEBUG - 2023-06-05 13:49:27 --> Total execution time: 0.0189
ERROR - 2023-06-05 13:49:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 13:49:29 --> Config Class Initialized
INFO - 2023-06-05 13:49:29 --> Hooks Class Initialized
DEBUG - 2023-06-05 13:49:29 --> UTF-8 Support Enabled
INFO - 2023-06-05 13:49:29 --> Utf8 Class Initialized
INFO - 2023-06-05 13:49:29 --> URI Class Initialized
INFO - 2023-06-05 13:49:29 --> Router Class Initialized
INFO - 2023-06-05 13:49:29 --> Output Class Initialized
INFO - 2023-06-05 13:49:29 --> Security Class Initialized
DEBUG - 2023-06-05 13:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 13:49:29 --> Input Class Initialized
INFO - 2023-06-05 13:49:29 --> Language Class Initialized
INFO - 2023-06-05 13:49:29 --> Loader Class Initialized
INFO - 2023-06-05 13:49:29 --> Helper loaded: url_helper
INFO - 2023-06-05 13:49:29 --> Helper loaded: file_helper
INFO - 2023-06-05 13:49:29 --> Helper loaded: html_helper
INFO - 2023-06-05 13:49:29 --> Helper loaded: text_helper
INFO - 2023-06-05 13:49:29 --> Helper loaded: form_helper
INFO - 2023-06-05 13:49:29 --> Helper loaded: lang_helper
INFO - 2023-06-05 13:49:29 --> Helper loaded: security_helper
INFO - 2023-06-05 13:49:29 --> Helper loaded: cookie_helper
INFO - 2023-06-05 13:49:29 --> Database Driver Class Initialized
INFO - 2023-06-05 13:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 13:49:29 --> Parser Class Initialized
INFO - 2023-06-05 13:49:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 13:49:29 --> Pagination Class Initialized
INFO - 2023-06-05 13:49:29 --> Form Validation Class Initialized
INFO - 2023-06-05 13:49:29 --> Controller Class Initialized
INFO - 2023-06-05 13:49:29 --> Model Class Initialized
DEBUG - 2023-06-05 13:49:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:49:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-05 13:49:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:49:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 13:49:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 13:49:29 --> Model Class Initialized
INFO - 2023-06-05 13:49:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 13:49:29 --> Final output sent to browser
DEBUG - 2023-06-05 13:49:29 --> Total execution time: 0.0347
ERROR - 2023-06-05 13:51:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 13:51:37 --> Config Class Initialized
INFO - 2023-06-05 13:51:37 --> Hooks Class Initialized
DEBUG - 2023-06-05 13:51:37 --> UTF-8 Support Enabled
INFO - 2023-06-05 13:51:37 --> Utf8 Class Initialized
INFO - 2023-06-05 13:51:37 --> URI Class Initialized
INFO - 2023-06-05 13:51:37 --> Router Class Initialized
INFO - 2023-06-05 13:51:37 --> Output Class Initialized
INFO - 2023-06-05 13:51:37 --> Security Class Initialized
DEBUG - 2023-06-05 13:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 13:51:37 --> Input Class Initialized
INFO - 2023-06-05 13:51:37 --> Language Class Initialized
INFO - 2023-06-05 13:51:37 --> Loader Class Initialized
INFO - 2023-06-05 13:51:37 --> Helper loaded: url_helper
INFO - 2023-06-05 13:51:37 --> Helper loaded: file_helper
INFO - 2023-06-05 13:51:37 --> Helper loaded: html_helper
INFO - 2023-06-05 13:51:37 --> Helper loaded: text_helper
INFO - 2023-06-05 13:51:37 --> Helper loaded: form_helper
INFO - 2023-06-05 13:51:37 --> Helper loaded: lang_helper
INFO - 2023-06-05 13:51:37 --> Helper loaded: security_helper
INFO - 2023-06-05 13:51:37 --> Helper loaded: cookie_helper
INFO - 2023-06-05 13:51:37 --> Database Driver Class Initialized
INFO - 2023-06-05 13:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 13:51:37 --> Parser Class Initialized
INFO - 2023-06-05 13:51:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 13:51:37 --> Pagination Class Initialized
INFO - 2023-06-05 13:51:37 --> Form Validation Class Initialized
INFO - 2023-06-05 13:51:37 --> Controller Class Initialized
INFO - 2023-06-05 13:51:37 --> Model Class Initialized
DEBUG - 2023-06-05 13:51:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:51:37 --> Model Class Initialized
INFO - 2023-06-05 13:51:37 --> Final output sent to browser
DEBUG - 2023-06-05 13:51:37 --> Total execution time: 0.0193
ERROR - 2023-06-05 13:51:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 13:51:37 --> Config Class Initialized
INFO - 2023-06-05 13:51:37 --> Hooks Class Initialized
DEBUG - 2023-06-05 13:51:37 --> UTF-8 Support Enabled
INFO - 2023-06-05 13:51:37 --> Utf8 Class Initialized
INFO - 2023-06-05 13:51:37 --> URI Class Initialized
INFO - 2023-06-05 13:51:37 --> Router Class Initialized
INFO - 2023-06-05 13:51:37 --> Output Class Initialized
INFO - 2023-06-05 13:51:37 --> Security Class Initialized
DEBUG - 2023-06-05 13:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 13:51:37 --> Input Class Initialized
INFO - 2023-06-05 13:51:37 --> Language Class Initialized
INFO - 2023-06-05 13:51:37 --> Loader Class Initialized
INFO - 2023-06-05 13:51:37 --> Helper loaded: url_helper
INFO - 2023-06-05 13:51:37 --> Helper loaded: file_helper
INFO - 2023-06-05 13:51:37 --> Helper loaded: html_helper
INFO - 2023-06-05 13:51:37 --> Helper loaded: text_helper
INFO - 2023-06-05 13:51:37 --> Helper loaded: form_helper
INFO - 2023-06-05 13:51:37 --> Helper loaded: lang_helper
INFO - 2023-06-05 13:51:37 --> Helper loaded: security_helper
INFO - 2023-06-05 13:51:37 --> Helper loaded: cookie_helper
INFO - 2023-06-05 13:51:37 --> Database Driver Class Initialized
INFO - 2023-06-05 13:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 13:51:37 --> Parser Class Initialized
INFO - 2023-06-05 13:51:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 13:51:37 --> Pagination Class Initialized
INFO - 2023-06-05 13:51:37 --> Form Validation Class Initialized
INFO - 2023-06-05 13:51:37 --> Controller Class Initialized
INFO - 2023-06-05 13:51:37 --> Model Class Initialized
DEBUG - 2023-06-05 13:51:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:51:37 --> Model Class Initialized
INFO - 2023-06-05 13:51:37 --> Final output sent to browser
DEBUG - 2023-06-05 13:51:37 --> Total execution time: 0.0177
ERROR - 2023-06-05 13:51:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 13:51:37 --> Config Class Initialized
INFO - 2023-06-05 13:51:37 --> Hooks Class Initialized
DEBUG - 2023-06-05 13:51:37 --> UTF-8 Support Enabled
INFO - 2023-06-05 13:51:37 --> Utf8 Class Initialized
INFO - 2023-06-05 13:51:37 --> URI Class Initialized
DEBUG - 2023-06-05 13:51:37 --> No URI present. Default controller set.
INFO - 2023-06-05 13:51:37 --> Router Class Initialized
INFO - 2023-06-05 13:51:37 --> Output Class Initialized
INFO - 2023-06-05 13:51:37 --> Security Class Initialized
DEBUG - 2023-06-05 13:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 13:51:37 --> Input Class Initialized
INFO - 2023-06-05 13:51:37 --> Language Class Initialized
INFO - 2023-06-05 13:51:37 --> Loader Class Initialized
INFO - 2023-06-05 13:51:37 --> Helper loaded: url_helper
INFO - 2023-06-05 13:51:37 --> Helper loaded: file_helper
INFO - 2023-06-05 13:51:37 --> Helper loaded: html_helper
INFO - 2023-06-05 13:51:37 --> Helper loaded: text_helper
INFO - 2023-06-05 13:51:37 --> Helper loaded: form_helper
INFO - 2023-06-05 13:51:37 --> Helper loaded: lang_helper
INFO - 2023-06-05 13:51:37 --> Helper loaded: security_helper
INFO - 2023-06-05 13:51:37 --> Helper loaded: cookie_helper
INFO - 2023-06-05 13:51:37 --> Database Driver Class Initialized
INFO - 2023-06-05 13:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 13:51:37 --> Parser Class Initialized
INFO - 2023-06-05 13:51:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 13:51:37 --> Pagination Class Initialized
INFO - 2023-06-05 13:51:37 --> Form Validation Class Initialized
INFO - 2023-06-05 13:51:37 --> Controller Class Initialized
INFO - 2023-06-05 13:51:37 --> Model Class Initialized
DEBUG - 2023-06-05 13:51:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:51:37 --> Model Class Initialized
DEBUG - 2023-06-05 13:51:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:51:37 --> Model Class Initialized
INFO - 2023-06-05 13:51:37 --> Model Class Initialized
INFO - 2023-06-05 13:51:37 --> Model Class Initialized
INFO - 2023-06-05 13:51:37 --> Model Class Initialized
DEBUG - 2023-06-05 13:51:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 13:51:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:51:37 --> Model Class Initialized
INFO - 2023-06-05 13:51:37 --> Model Class Initialized
INFO - 2023-06-05 13:51:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-05 13:51:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:51:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 13:51:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 13:51:37 --> Model Class Initialized
INFO - 2023-06-05 13:51:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 13:51:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 13:51:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 13:51:37 --> Final output sent to browser
DEBUG - 2023-06-05 13:51:37 --> Total execution time: 0.0659
ERROR - 2023-06-05 13:52:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 13:52:18 --> Config Class Initialized
INFO - 2023-06-05 13:52:18 --> Hooks Class Initialized
DEBUG - 2023-06-05 13:52:18 --> UTF-8 Support Enabled
INFO - 2023-06-05 13:52:18 --> Utf8 Class Initialized
INFO - 2023-06-05 13:52:18 --> URI Class Initialized
INFO - 2023-06-05 13:52:18 --> Router Class Initialized
INFO - 2023-06-05 13:52:18 --> Output Class Initialized
INFO - 2023-06-05 13:52:18 --> Security Class Initialized
DEBUG - 2023-06-05 13:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 13:52:18 --> Input Class Initialized
INFO - 2023-06-05 13:52:18 --> Language Class Initialized
INFO - 2023-06-05 13:52:18 --> Loader Class Initialized
INFO - 2023-06-05 13:52:18 --> Helper loaded: url_helper
INFO - 2023-06-05 13:52:18 --> Helper loaded: file_helper
INFO - 2023-06-05 13:52:18 --> Helper loaded: html_helper
INFO - 2023-06-05 13:52:18 --> Helper loaded: text_helper
INFO - 2023-06-05 13:52:18 --> Helper loaded: form_helper
INFO - 2023-06-05 13:52:18 --> Helper loaded: lang_helper
INFO - 2023-06-05 13:52:18 --> Helper loaded: security_helper
INFO - 2023-06-05 13:52:18 --> Helper loaded: cookie_helper
INFO - 2023-06-05 13:52:18 --> Database Driver Class Initialized
INFO - 2023-06-05 13:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 13:52:18 --> Parser Class Initialized
INFO - 2023-06-05 13:52:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 13:52:18 --> Pagination Class Initialized
INFO - 2023-06-05 13:52:18 --> Form Validation Class Initialized
INFO - 2023-06-05 13:52:18 --> Controller Class Initialized
INFO - 2023-06-05 13:52:18 --> Model Class Initialized
DEBUG - 2023-06-05 13:52:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 13:52:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:52:18 --> Model Class Initialized
DEBUG - 2023-06-05 13:52:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:52:18 --> Model Class Initialized
INFO - 2023-06-05 13:52:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-06-05 13:52:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:52:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 13:52:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 13:52:18 --> Model Class Initialized
INFO - 2023-06-05 13:52:18 --> Model Class Initialized
INFO - 2023-06-05 13:52:18 --> Model Class Initialized
INFO - 2023-06-05 13:52:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 13:52:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 13:52:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 13:52:18 --> Final output sent to browser
DEBUG - 2023-06-05 13:52:18 --> Total execution time: 0.0693
ERROR - 2023-06-05 13:52:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 13:52:21 --> Config Class Initialized
INFO - 2023-06-05 13:52:21 --> Hooks Class Initialized
DEBUG - 2023-06-05 13:52:21 --> UTF-8 Support Enabled
INFO - 2023-06-05 13:52:21 --> Utf8 Class Initialized
INFO - 2023-06-05 13:52:21 --> URI Class Initialized
INFO - 2023-06-05 13:52:21 --> Router Class Initialized
INFO - 2023-06-05 13:52:21 --> Output Class Initialized
INFO - 2023-06-05 13:52:21 --> Security Class Initialized
DEBUG - 2023-06-05 13:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 13:52:21 --> Input Class Initialized
INFO - 2023-06-05 13:52:21 --> Language Class Initialized
INFO - 2023-06-05 13:52:21 --> Loader Class Initialized
INFO - 2023-06-05 13:52:21 --> Helper loaded: url_helper
INFO - 2023-06-05 13:52:21 --> Helper loaded: file_helper
INFO - 2023-06-05 13:52:21 --> Helper loaded: html_helper
INFO - 2023-06-05 13:52:21 --> Helper loaded: text_helper
INFO - 2023-06-05 13:52:21 --> Helper loaded: form_helper
INFO - 2023-06-05 13:52:21 --> Helper loaded: lang_helper
INFO - 2023-06-05 13:52:21 --> Helper loaded: security_helper
INFO - 2023-06-05 13:52:21 --> Helper loaded: cookie_helper
INFO - 2023-06-05 13:52:21 --> Database Driver Class Initialized
INFO - 2023-06-05 13:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 13:52:21 --> Parser Class Initialized
INFO - 2023-06-05 13:52:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 13:52:21 --> Pagination Class Initialized
INFO - 2023-06-05 13:52:21 --> Form Validation Class Initialized
INFO - 2023-06-05 13:52:21 --> Controller Class Initialized
INFO - 2023-06-05 13:52:21 --> Model Class Initialized
DEBUG - 2023-06-05 13:52:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 13:52:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:52:21 --> Model Class Initialized
DEBUG - 2023-06-05 13:52:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:52:21 --> Model Class Initialized
INFO - 2023-06-05 13:52:21 --> Final output sent to browser
DEBUG - 2023-06-05 13:52:21 --> Total execution time: 0.0202
ERROR - 2023-06-05 13:52:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 13:52:32 --> Config Class Initialized
INFO - 2023-06-05 13:52:32 --> Hooks Class Initialized
DEBUG - 2023-06-05 13:52:32 --> UTF-8 Support Enabled
INFO - 2023-06-05 13:52:32 --> Utf8 Class Initialized
INFO - 2023-06-05 13:52:32 --> URI Class Initialized
INFO - 2023-06-05 13:52:32 --> Router Class Initialized
INFO - 2023-06-05 13:52:32 --> Output Class Initialized
INFO - 2023-06-05 13:52:32 --> Security Class Initialized
DEBUG - 2023-06-05 13:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 13:52:32 --> Input Class Initialized
INFO - 2023-06-05 13:52:32 --> Language Class Initialized
INFO - 2023-06-05 13:52:32 --> Loader Class Initialized
INFO - 2023-06-05 13:52:32 --> Helper loaded: url_helper
INFO - 2023-06-05 13:52:32 --> Helper loaded: file_helper
INFO - 2023-06-05 13:52:32 --> Helper loaded: html_helper
INFO - 2023-06-05 13:52:32 --> Helper loaded: text_helper
INFO - 2023-06-05 13:52:32 --> Helper loaded: form_helper
INFO - 2023-06-05 13:52:32 --> Helper loaded: lang_helper
INFO - 2023-06-05 13:52:32 --> Helper loaded: security_helper
INFO - 2023-06-05 13:52:32 --> Helper loaded: cookie_helper
INFO - 2023-06-05 13:52:32 --> Database Driver Class Initialized
INFO - 2023-06-05 13:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 13:52:32 --> Parser Class Initialized
INFO - 2023-06-05 13:52:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 13:52:32 --> Pagination Class Initialized
INFO - 2023-06-05 13:52:32 --> Form Validation Class Initialized
INFO - 2023-06-05 13:52:32 --> Controller Class Initialized
INFO - 2023-06-05 13:52:32 --> Model Class Initialized
INFO - 2023-06-05 13:52:32 --> Model Class Initialized
INFO - 2023-06-05 13:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_date.php
DEBUG - 2023-06-05 13:52:32 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 13:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 13:52:32 --> Model Class Initialized
INFO - 2023-06-05 13:52:32 --> Model Class Initialized
INFO - 2023-06-05 13:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 13:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 13:52:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 13:52:32 --> Final output sent to browser
DEBUG - 2023-06-05 13:52:32 --> Total execution time: 0.0618
ERROR - 2023-06-05 13:52:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 13:52:33 --> Config Class Initialized
INFO - 2023-06-05 13:52:33 --> Hooks Class Initialized
DEBUG - 2023-06-05 13:52:33 --> UTF-8 Support Enabled
INFO - 2023-06-05 13:52:33 --> Utf8 Class Initialized
INFO - 2023-06-05 13:52:33 --> URI Class Initialized
INFO - 2023-06-05 13:52:33 --> Router Class Initialized
INFO - 2023-06-05 13:52:33 --> Output Class Initialized
INFO - 2023-06-05 13:52:33 --> Security Class Initialized
DEBUG - 2023-06-05 13:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 13:52:33 --> Input Class Initialized
INFO - 2023-06-05 13:52:33 --> Language Class Initialized
INFO - 2023-06-05 13:52:33 --> Loader Class Initialized
INFO - 2023-06-05 13:52:33 --> Helper loaded: url_helper
INFO - 2023-06-05 13:52:33 --> Helper loaded: file_helper
INFO - 2023-06-05 13:52:33 --> Helper loaded: html_helper
INFO - 2023-06-05 13:52:33 --> Helper loaded: text_helper
INFO - 2023-06-05 13:52:33 --> Helper loaded: form_helper
INFO - 2023-06-05 13:52:33 --> Helper loaded: lang_helper
INFO - 2023-06-05 13:52:33 --> Helper loaded: security_helper
INFO - 2023-06-05 13:52:33 --> Helper loaded: cookie_helper
INFO - 2023-06-05 13:52:33 --> Database Driver Class Initialized
INFO - 2023-06-05 13:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 13:52:33 --> Parser Class Initialized
INFO - 2023-06-05 13:52:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 13:52:33 --> Pagination Class Initialized
INFO - 2023-06-05 13:52:33 --> Form Validation Class Initialized
INFO - 2023-06-05 13:52:33 --> Controller Class Initialized
INFO - 2023-06-05 13:52:33 --> Model Class Initialized
INFO - 2023-06-05 13:52:33 --> Model Class Initialized
INFO - 2023-06-05 13:52:33 --> Final output sent to browser
DEBUG - 2023-06-05 13:52:33 --> Total execution time: 0.0172
ERROR - 2023-06-05 13:52:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 13:52:43 --> Config Class Initialized
INFO - 2023-06-05 13:52:43 --> Hooks Class Initialized
DEBUG - 2023-06-05 13:52:43 --> UTF-8 Support Enabled
INFO - 2023-06-05 13:52:43 --> Utf8 Class Initialized
INFO - 2023-06-05 13:52:43 --> URI Class Initialized
INFO - 2023-06-05 13:52:43 --> Router Class Initialized
INFO - 2023-06-05 13:52:43 --> Output Class Initialized
INFO - 2023-06-05 13:52:43 --> Security Class Initialized
DEBUG - 2023-06-05 13:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 13:52:43 --> Input Class Initialized
INFO - 2023-06-05 13:52:43 --> Language Class Initialized
INFO - 2023-06-05 13:52:43 --> Loader Class Initialized
INFO - 2023-06-05 13:52:43 --> Helper loaded: url_helper
INFO - 2023-06-05 13:52:43 --> Helper loaded: file_helper
INFO - 2023-06-05 13:52:43 --> Helper loaded: html_helper
INFO - 2023-06-05 13:52:43 --> Helper loaded: text_helper
INFO - 2023-06-05 13:52:43 --> Helper loaded: form_helper
INFO - 2023-06-05 13:52:43 --> Helper loaded: lang_helper
INFO - 2023-06-05 13:52:43 --> Helper loaded: security_helper
INFO - 2023-06-05 13:52:43 --> Helper loaded: cookie_helper
INFO - 2023-06-05 13:52:43 --> Database Driver Class Initialized
INFO - 2023-06-05 13:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 13:52:43 --> Parser Class Initialized
INFO - 2023-06-05 13:52:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 13:52:43 --> Pagination Class Initialized
INFO - 2023-06-05 13:52:43 --> Form Validation Class Initialized
INFO - 2023-06-05 13:52:43 --> Controller Class Initialized
INFO - 2023-06-05 13:52:43 --> Model Class Initialized
DEBUG - 2023-06-05 13:52:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 13:52:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:52:43 --> Model Class Initialized
DEBUG - 2023-06-05 13:52:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:52:43 --> Model Class Initialized
INFO - 2023-06-05 13:52:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-06-05 13:52:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:52:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 13:52:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 13:52:43 --> Model Class Initialized
INFO - 2023-06-05 13:52:43 --> Model Class Initialized
INFO - 2023-06-05 13:52:43 --> Model Class Initialized
INFO - 2023-06-05 13:52:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 13:52:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 13:52:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 13:52:43 --> Final output sent to browser
DEBUG - 2023-06-05 13:52:43 --> Total execution time: 0.0610
ERROR - 2023-06-05 13:52:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 13:52:45 --> Config Class Initialized
INFO - 2023-06-05 13:52:45 --> Hooks Class Initialized
DEBUG - 2023-06-05 13:52:45 --> UTF-8 Support Enabled
INFO - 2023-06-05 13:52:45 --> Utf8 Class Initialized
INFO - 2023-06-05 13:52:45 --> URI Class Initialized
INFO - 2023-06-05 13:52:45 --> Router Class Initialized
INFO - 2023-06-05 13:52:45 --> Output Class Initialized
INFO - 2023-06-05 13:52:45 --> Security Class Initialized
DEBUG - 2023-06-05 13:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 13:52:45 --> Input Class Initialized
INFO - 2023-06-05 13:52:45 --> Language Class Initialized
INFO - 2023-06-05 13:52:45 --> Loader Class Initialized
INFO - 2023-06-05 13:52:45 --> Helper loaded: url_helper
INFO - 2023-06-05 13:52:45 --> Helper loaded: file_helper
INFO - 2023-06-05 13:52:45 --> Helper loaded: html_helper
INFO - 2023-06-05 13:52:45 --> Helper loaded: text_helper
INFO - 2023-06-05 13:52:45 --> Helper loaded: form_helper
INFO - 2023-06-05 13:52:45 --> Helper loaded: lang_helper
INFO - 2023-06-05 13:52:45 --> Helper loaded: security_helper
INFO - 2023-06-05 13:52:45 --> Helper loaded: cookie_helper
INFO - 2023-06-05 13:52:45 --> Database Driver Class Initialized
INFO - 2023-06-05 13:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 13:52:45 --> Parser Class Initialized
INFO - 2023-06-05 13:52:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 13:52:45 --> Pagination Class Initialized
INFO - 2023-06-05 13:52:45 --> Form Validation Class Initialized
INFO - 2023-06-05 13:52:45 --> Controller Class Initialized
INFO - 2023-06-05 13:52:45 --> Model Class Initialized
DEBUG - 2023-06-05 13:52:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 13:52:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:52:45 --> Model Class Initialized
DEBUG - 2023-06-05 13:52:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:52:45 --> Model Class Initialized
INFO - 2023-06-05 13:52:45 --> Final output sent to browser
DEBUG - 2023-06-05 13:52:45 --> Total execution time: 0.0197
ERROR - 2023-06-05 13:52:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 13:52:48 --> Config Class Initialized
INFO - 2023-06-05 13:52:48 --> Hooks Class Initialized
DEBUG - 2023-06-05 13:52:48 --> UTF-8 Support Enabled
INFO - 2023-06-05 13:52:48 --> Utf8 Class Initialized
INFO - 2023-06-05 13:52:48 --> URI Class Initialized
INFO - 2023-06-05 13:52:48 --> Router Class Initialized
INFO - 2023-06-05 13:52:48 --> Output Class Initialized
INFO - 2023-06-05 13:52:48 --> Security Class Initialized
DEBUG - 2023-06-05 13:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 13:52:48 --> Input Class Initialized
INFO - 2023-06-05 13:52:48 --> Language Class Initialized
INFO - 2023-06-05 13:52:48 --> Loader Class Initialized
INFO - 2023-06-05 13:52:48 --> Helper loaded: url_helper
INFO - 2023-06-05 13:52:48 --> Helper loaded: file_helper
INFO - 2023-06-05 13:52:48 --> Helper loaded: html_helper
INFO - 2023-06-05 13:52:48 --> Helper loaded: text_helper
INFO - 2023-06-05 13:52:48 --> Helper loaded: form_helper
INFO - 2023-06-05 13:52:48 --> Helper loaded: lang_helper
INFO - 2023-06-05 13:52:48 --> Helper loaded: security_helper
INFO - 2023-06-05 13:52:48 --> Helper loaded: cookie_helper
INFO - 2023-06-05 13:52:48 --> Database Driver Class Initialized
INFO - 2023-06-05 13:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 13:52:48 --> Parser Class Initialized
INFO - 2023-06-05 13:52:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 13:52:48 --> Pagination Class Initialized
INFO - 2023-06-05 13:52:48 --> Form Validation Class Initialized
INFO - 2023-06-05 13:52:48 --> Controller Class Initialized
INFO - 2023-06-05 13:52:48 --> Model Class Initialized
INFO - 2023-06-05 13:52:48 --> Model Class Initialized
INFO - 2023-06-05 13:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-06-05 13:52:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 13:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 13:52:48 --> Model Class Initialized
INFO - 2023-06-05 13:52:48 --> Model Class Initialized
INFO - 2023-06-05 13:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 13:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 13:52:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 13:52:48 --> Final output sent to browser
DEBUG - 2023-06-05 13:52:48 --> Total execution time: 0.0573
ERROR - 2023-06-05 13:52:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 13:52:49 --> Config Class Initialized
INFO - 2023-06-05 13:52:49 --> Hooks Class Initialized
DEBUG - 2023-06-05 13:52:49 --> UTF-8 Support Enabled
INFO - 2023-06-05 13:52:49 --> Utf8 Class Initialized
INFO - 2023-06-05 13:52:49 --> URI Class Initialized
INFO - 2023-06-05 13:52:49 --> Router Class Initialized
INFO - 2023-06-05 13:52:49 --> Output Class Initialized
INFO - 2023-06-05 13:52:49 --> Security Class Initialized
DEBUG - 2023-06-05 13:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 13:52:49 --> Input Class Initialized
INFO - 2023-06-05 13:52:49 --> Language Class Initialized
INFO - 2023-06-05 13:52:49 --> Loader Class Initialized
INFO - 2023-06-05 13:52:49 --> Helper loaded: url_helper
INFO - 2023-06-05 13:52:49 --> Helper loaded: file_helper
INFO - 2023-06-05 13:52:49 --> Helper loaded: html_helper
INFO - 2023-06-05 13:52:49 --> Helper loaded: text_helper
INFO - 2023-06-05 13:52:49 --> Helper loaded: form_helper
INFO - 2023-06-05 13:52:49 --> Helper loaded: lang_helper
INFO - 2023-06-05 13:52:49 --> Helper loaded: security_helper
INFO - 2023-06-05 13:52:49 --> Helper loaded: cookie_helper
INFO - 2023-06-05 13:52:49 --> Database Driver Class Initialized
INFO - 2023-06-05 13:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 13:52:49 --> Parser Class Initialized
INFO - 2023-06-05 13:52:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 13:52:49 --> Pagination Class Initialized
INFO - 2023-06-05 13:52:49 --> Form Validation Class Initialized
INFO - 2023-06-05 13:52:49 --> Controller Class Initialized
INFO - 2023-06-05 13:52:49 --> Model Class Initialized
INFO - 2023-06-05 13:52:49 --> Model Class Initialized
INFO - 2023-06-05 13:52:49 --> Final output sent to browser
DEBUG - 2023-06-05 13:52:49 --> Total execution time: 0.0272
ERROR - 2023-06-05 13:53:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 13:53:17 --> Config Class Initialized
INFO - 2023-06-05 13:53:17 --> Hooks Class Initialized
DEBUG - 2023-06-05 13:53:17 --> UTF-8 Support Enabled
INFO - 2023-06-05 13:53:17 --> Utf8 Class Initialized
INFO - 2023-06-05 13:53:17 --> URI Class Initialized
INFO - 2023-06-05 13:53:17 --> Router Class Initialized
INFO - 2023-06-05 13:53:17 --> Output Class Initialized
INFO - 2023-06-05 13:53:17 --> Security Class Initialized
DEBUG - 2023-06-05 13:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 13:53:17 --> Input Class Initialized
INFO - 2023-06-05 13:53:17 --> Language Class Initialized
INFO - 2023-06-05 13:53:17 --> Loader Class Initialized
INFO - 2023-06-05 13:53:17 --> Helper loaded: url_helper
INFO - 2023-06-05 13:53:17 --> Helper loaded: file_helper
INFO - 2023-06-05 13:53:17 --> Helper loaded: html_helper
INFO - 2023-06-05 13:53:17 --> Helper loaded: text_helper
INFO - 2023-06-05 13:53:17 --> Helper loaded: form_helper
INFO - 2023-06-05 13:53:17 --> Helper loaded: lang_helper
INFO - 2023-06-05 13:53:17 --> Helper loaded: security_helper
INFO - 2023-06-05 13:53:17 --> Helper loaded: cookie_helper
INFO - 2023-06-05 13:53:17 --> Database Driver Class Initialized
INFO - 2023-06-05 13:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 13:53:17 --> Parser Class Initialized
INFO - 2023-06-05 13:53:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 13:53:17 --> Pagination Class Initialized
INFO - 2023-06-05 13:53:17 --> Form Validation Class Initialized
INFO - 2023-06-05 13:53:17 --> Controller Class Initialized
INFO - 2023-06-05 13:53:17 --> Model Class Initialized
DEBUG - 2023-06-05 13:53:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 13:53:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:53:17 --> Model Class Initialized
DEBUG - 2023-06-05 13:53:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:53:17 --> Model Class Initialized
INFO - 2023-06-05 13:53:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-06-05 13:53:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:53:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 13:53:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 13:53:17 --> Model Class Initialized
INFO - 2023-06-05 13:53:17 --> Model Class Initialized
INFO - 2023-06-05 13:53:17 --> Model Class Initialized
INFO - 2023-06-05 13:53:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 13:53:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 13:53:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 13:53:17 --> Final output sent to browser
DEBUG - 2023-06-05 13:53:17 --> Total execution time: 0.0704
ERROR - 2023-06-05 13:53:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 13:53:19 --> Config Class Initialized
INFO - 2023-06-05 13:53:19 --> Hooks Class Initialized
DEBUG - 2023-06-05 13:53:19 --> UTF-8 Support Enabled
INFO - 2023-06-05 13:53:19 --> Utf8 Class Initialized
INFO - 2023-06-05 13:53:19 --> URI Class Initialized
INFO - 2023-06-05 13:53:19 --> Router Class Initialized
INFO - 2023-06-05 13:53:19 --> Output Class Initialized
INFO - 2023-06-05 13:53:19 --> Security Class Initialized
DEBUG - 2023-06-05 13:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 13:53:19 --> Input Class Initialized
INFO - 2023-06-05 13:53:19 --> Language Class Initialized
INFO - 2023-06-05 13:53:19 --> Loader Class Initialized
INFO - 2023-06-05 13:53:19 --> Helper loaded: url_helper
INFO - 2023-06-05 13:53:19 --> Helper loaded: file_helper
INFO - 2023-06-05 13:53:19 --> Helper loaded: html_helper
INFO - 2023-06-05 13:53:19 --> Helper loaded: text_helper
INFO - 2023-06-05 13:53:19 --> Helper loaded: form_helper
INFO - 2023-06-05 13:53:19 --> Helper loaded: lang_helper
INFO - 2023-06-05 13:53:19 --> Helper loaded: security_helper
INFO - 2023-06-05 13:53:19 --> Helper loaded: cookie_helper
INFO - 2023-06-05 13:53:19 --> Database Driver Class Initialized
INFO - 2023-06-05 13:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 13:53:19 --> Parser Class Initialized
INFO - 2023-06-05 13:53:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 13:53:19 --> Pagination Class Initialized
INFO - 2023-06-05 13:53:19 --> Form Validation Class Initialized
INFO - 2023-06-05 13:53:19 --> Controller Class Initialized
INFO - 2023-06-05 13:53:19 --> Model Class Initialized
DEBUG - 2023-06-05 13:53:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 13:53:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:53:19 --> Model Class Initialized
DEBUG - 2023-06-05 13:53:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:53:19 --> Model Class Initialized
INFO - 2023-06-05 13:53:19 --> Final output sent to browser
DEBUG - 2023-06-05 13:53:19 --> Total execution time: 0.0197
ERROR - 2023-06-05 13:53:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 13:53:21 --> Config Class Initialized
INFO - 2023-06-05 13:53:21 --> Hooks Class Initialized
DEBUG - 2023-06-05 13:53:21 --> UTF-8 Support Enabled
INFO - 2023-06-05 13:53:21 --> Utf8 Class Initialized
INFO - 2023-06-05 13:53:21 --> URI Class Initialized
DEBUG - 2023-06-05 13:53:21 --> No URI present. Default controller set.
INFO - 2023-06-05 13:53:21 --> Router Class Initialized
INFO - 2023-06-05 13:53:21 --> Output Class Initialized
INFO - 2023-06-05 13:53:21 --> Security Class Initialized
DEBUG - 2023-06-05 13:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 13:53:21 --> Input Class Initialized
INFO - 2023-06-05 13:53:21 --> Language Class Initialized
INFO - 2023-06-05 13:53:21 --> Loader Class Initialized
INFO - 2023-06-05 13:53:21 --> Helper loaded: url_helper
INFO - 2023-06-05 13:53:21 --> Helper loaded: file_helper
INFO - 2023-06-05 13:53:21 --> Helper loaded: html_helper
INFO - 2023-06-05 13:53:21 --> Helper loaded: text_helper
INFO - 2023-06-05 13:53:21 --> Helper loaded: form_helper
INFO - 2023-06-05 13:53:21 --> Helper loaded: lang_helper
INFO - 2023-06-05 13:53:21 --> Helper loaded: security_helper
INFO - 2023-06-05 13:53:21 --> Helper loaded: cookie_helper
INFO - 2023-06-05 13:53:21 --> Database Driver Class Initialized
INFO - 2023-06-05 13:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 13:53:21 --> Parser Class Initialized
INFO - 2023-06-05 13:53:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 13:53:21 --> Pagination Class Initialized
INFO - 2023-06-05 13:53:21 --> Form Validation Class Initialized
INFO - 2023-06-05 13:53:21 --> Controller Class Initialized
INFO - 2023-06-05 13:53:21 --> Model Class Initialized
DEBUG - 2023-06-05 13:53:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:53:21 --> Model Class Initialized
DEBUG - 2023-06-05 13:53:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:53:21 --> Model Class Initialized
INFO - 2023-06-05 13:53:21 --> Model Class Initialized
INFO - 2023-06-05 13:53:21 --> Model Class Initialized
INFO - 2023-06-05 13:53:21 --> Model Class Initialized
DEBUG - 2023-06-05 13:53:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 13:53:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:53:21 --> Model Class Initialized
INFO - 2023-06-05 13:53:21 --> Model Class Initialized
INFO - 2023-06-05 13:53:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-05 13:53:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:53:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 13:53:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 13:53:21 --> Model Class Initialized
INFO - 2023-06-05 13:53:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 13:53:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 13:53:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 13:53:21 --> Final output sent to browser
DEBUG - 2023-06-05 13:53:21 --> Total execution time: 0.0648
ERROR - 2023-06-05 13:53:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 13:53:36 --> Config Class Initialized
INFO - 2023-06-05 13:53:36 --> Hooks Class Initialized
DEBUG - 2023-06-05 13:53:36 --> UTF-8 Support Enabled
INFO - 2023-06-05 13:53:36 --> Utf8 Class Initialized
INFO - 2023-06-05 13:53:36 --> URI Class Initialized
INFO - 2023-06-05 13:53:36 --> Router Class Initialized
INFO - 2023-06-05 13:53:36 --> Output Class Initialized
INFO - 2023-06-05 13:53:36 --> Security Class Initialized
DEBUG - 2023-06-05 13:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 13:53:36 --> Input Class Initialized
INFO - 2023-06-05 13:53:36 --> Language Class Initialized
INFO - 2023-06-05 13:53:36 --> Loader Class Initialized
INFO - 2023-06-05 13:53:36 --> Helper loaded: url_helper
INFO - 2023-06-05 13:53:36 --> Helper loaded: file_helper
INFO - 2023-06-05 13:53:36 --> Helper loaded: html_helper
INFO - 2023-06-05 13:53:36 --> Helper loaded: text_helper
INFO - 2023-06-05 13:53:36 --> Helper loaded: form_helper
INFO - 2023-06-05 13:53:36 --> Helper loaded: lang_helper
INFO - 2023-06-05 13:53:36 --> Helper loaded: security_helper
INFO - 2023-06-05 13:53:36 --> Helper loaded: cookie_helper
INFO - 2023-06-05 13:53:36 --> Database Driver Class Initialized
INFO - 2023-06-05 13:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 13:53:36 --> Parser Class Initialized
INFO - 2023-06-05 13:53:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 13:53:36 --> Pagination Class Initialized
INFO - 2023-06-05 13:53:36 --> Form Validation Class Initialized
INFO - 2023-06-05 13:53:36 --> Controller Class Initialized
INFO - 2023-06-05 13:53:36 --> Model Class Initialized
DEBUG - 2023-06-05 13:53:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:53:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-05 13:53:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:53:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 13:53:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 13:53:36 --> Model Class Initialized
INFO - 2023-06-05 13:53:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 13:53:36 --> Final output sent to browser
DEBUG - 2023-06-05 13:53:36 --> Total execution time: 0.0322
ERROR - 2023-06-05 13:53:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 13:53:36 --> Config Class Initialized
INFO - 2023-06-05 13:53:36 --> Hooks Class Initialized
DEBUG - 2023-06-05 13:53:36 --> UTF-8 Support Enabled
INFO - 2023-06-05 13:53:36 --> Utf8 Class Initialized
INFO - 2023-06-05 13:53:36 --> URI Class Initialized
INFO - 2023-06-05 13:53:36 --> Router Class Initialized
INFO - 2023-06-05 13:53:36 --> Output Class Initialized
INFO - 2023-06-05 13:53:36 --> Security Class Initialized
DEBUG - 2023-06-05 13:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 13:53:36 --> Input Class Initialized
INFO - 2023-06-05 13:53:36 --> Language Class Initialized
INFO - 2023-06-05 13:53:36 --> Loader Class Initialized
INFO - 2023-06-05 13:53:36 --> Helper loaded: url_helper
INFO - 2023-06-05 13:53:36 --> Helper loaded: file_helper
INFO - 2023-06-05 13:53:36 --> Helper loaded: html_helper
INFO - 2023-06-05 13:53:36 --> Helper loaded: text_helper
INFO - 2023-06-05 13:53:36 --> Helper loaded: form_helper
INFO - 2023-06-05 13:53:36 --> Helper loaded: lang_helper
INFO - 2023-06-05 13:53:36 --> Helper loaded: security_helper
INFO - 2023-06-05 13:53:36 --> Helper loaded: cookie_helper
INFO - 2023-06-05 13:53:36 --> Database Driver Class Initialized
INFO - 2023-06-05 13:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 13:53:36 --> Parser Class Initialized
INFO - 2023-06-05 13:53:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 13:53:36 --> Pagination Class Initialized
INFO - 2023-06-05 13:53:36 --> Form Validation Class Initialized
INFO - 2023-06-05 13:53:36 --> Controller Class Initialized
INFO - 2023-06-05 13:53:36 --> Model Class Initialized
DEBUG - 2023-06-05 13:53:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:53:36 --> Model Class Initialized
DEBUG - 2023-06-05 13:53:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:53:36 --> Model Class Initialized
INFO - 2023-06-05 13:53:36 --> Model Class Initialized
INFO - 2023-06-05 13:53:36 --> Model Class Initialized
INFO - 2023-06-05 13:53:36 --> Model Class Initialized
DEBUG - 2023-06-05 13:53:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 13:53:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:53:36 --> Model Class Initialized
INFO - 2023-06-05 13:53:36 --> Model Class Initialized
INFO - 2023-06-05 13:53:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-05 13:53:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:53:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 13:53:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 13:53:36 --> Model Class Initialized
INFO - 2023-06-05 13:53:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 13:53:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 13:53:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 13:53:36 --> Final output sent to browser
DEBUG - 2023-06-05 13:53:36 --> Total execution time: 0.0710
ERROR - 2023-06-05 13:53:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 13:53:37 --> Config Class Initialized
INFO - 2023-06-05 13:53:37 --> Hooks Class Initialized
DEBUG - 2023-06-05 13:53:37 --> UTF-8 Support Enabled
INFO - 2023-06-05 13:53:37 --> Utf8 Class Initialized
INFO - 2023-06-05 13:53:37 --> URI Class Initialized
INFO - 2023-06-05 13:53:37 --> Router Class Initialized
INFO - 2023-06-05 13:53:37 --> Output Class Initialized
INFO - 2023-06-05 13:53:37 --> Security Class Initialized
DEBUG - 2023-06-05 13:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 13:53:37 --> Input Class Initialized
INFO - 2023-06-05 13:53:37 --> Language Class Initialized
INFO - 2023-06-05 13:53:37 --> Loader Class Initialized
INFO - 2023-06-05 13:53:37 --> Helper loaded: url_helper
INFO - 2023-06-05 13:53:37 --> Helper loaded: file_helper
INFO - 2023-06-05 13:53:37 --> Helper loaded: html_helper
INFO - 2023-06-05 13:53:37 --> Helper loaded: text_helper
INFO - 2023-06-05 13:53:37 --> Helper loaded: form_helper
INFO - 2023-06-05 13:53:37 --> Helper loaded: lang_helper
INFO - 2023-06-05 13:53:37 --> Helper loaded: security_helper
INFO - 2023-06-05 13:53:37 --> Helper loaded: cookie_helper
INFO - 2023-06-05 13:53:37 --> Database Driver Class Initialized
INFO - 2023-06-05 13:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 13:53:37 --> Parser Class Initialized
INFO - 2023-06-05 13:53:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 13:53:37 --> Pagination Class Initialized
INFO - 2023-06-05 13:53:37 --> Form Validation Class Initialized
INFO - 2023-06-05 13:53:37 --> Controller Class Initialized
INFO - 2023-06-05 13:53:37 --> Model Class Initialized
DEBUG - 2023-06-05 13:53:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:53:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-05 13:53:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:53:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 13:53:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 13:53:37 --> Model Class Initialized
INFO - 2023-06-05 13:53:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 13:53:37 --> Final output sent to browser
DEBUG - 2023-06-05 13:53:37 --> Total execution time: 0.0324
ERROR - 2023-06-05 13:53:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 13:53:37 --> Config Class Initialized
INFO - 2023-06-05 13:53:37 --> Hooks Class Initialized
DEBUG - 2023-06-05 13:53:37 --> UTF-8 Support Enabled
INFO - 2023-06-05 13:53:37 --> Utf8 Class Initialized
INFO - 2023-06-05 13:53:37 --> URI Class Initialized
INFO - 2023-06-05 13:53:37 --> Router Class Initialized
INFO - 2023-06-05 13:53:37 --> Output Class Initialized
INFO - 2023-06-05 13:53:37 --> Security Class Initialized
DEBUG - 2023-06-05 13:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 13:53:37 --> Input Class Initialized
INFO - 2023-06-05 13:53:37 --> Language Class Initialized
INFO - 2023-06-05 13:53:37 --> Loader Class Initialized
INFO - 2023-06-05 13:53:37 --> Helper loaded: url_helper
INFO - 2023-06-05 13:53:37 --> Helper loaded: file_helper
INFO - 2023-06-05 13:53:37 --> Helper loaded: html_helper
INFO - 2023-06-05 13:53:37 --> Helper loaded: text_helper
INFO - 2023-06-05 13:53:37 --> Helper loaded: form_helper
INFO - 2023-06-05 13:53:37 --> Helper loaded: lang_helper
INFO - 2023-06-05 13:53:37 --> Helper loaded: security_helper
INFO - 2023-06-05 13:53:37 --> Helper loaded: cookie_helper
INFO - 2023-06-05 13:53:37 --> Database Driver Class Initialized
INFO - 2023-06-05 13:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 13:53:37 --> Parser Class Initialized
INFO - 2023-06-05 13:53:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 13:53:37 --> Pagination Class Initialized
INFO - 2023-06-05 13:53:37 --> Form Validation Class Initialized
INFO - 2023-06-05 13:53:37 --> Controller Class Initialized
INFO - 2023-06-05 13:53:37 --> Model Class Initialized
DEBUG - 2023-06-05 13:53:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:53:37 --> Model Class Initialized
DEBUG - 2023-06-05 13:53:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:53:37 --> Model Class Initialized
INFO - 2023-06-05 13:53:37 --> Model Class Initialized
INFO - 2023-06-05 13:53:37 --> Model Class Initialized
INFO - 2023-06-05 13:53:37 --> Model Class Initialized
DEBUG - 2023-06-05 13:53:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 13:53:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:53:37 --> Model Class Initialized
INFO - 2023-06-05 13:53:37 --> Model Class Initialized
INFO - 2023-06-05 13:53:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-05 13:53:37 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 13:53:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 13:53:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 13:53:37 --> Model Class Initialized
INFO - 2023-06-05 13:53:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 13:53:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 13:53:37 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 13:53:37 --> Final output sent to browser
DEBUG - 2023-06-05 13:53:37 --> Total execution time: 0.0729
ERROR - 2023-06-05 14:41:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 14:41:45 --> Config Class Initialized
INFO - 2023-06-05 14:41:45 --> Hooks Class Initialized
DEBUG - 2023-06-05 14:41:45 --> UTF-8 Support Enabled
INFO - 2023-06-05 14:41:45 --> Utf8 Class Initialized
INFO - 2023-06-05 14:41:45 --> URI Class Initialized
INFO - 2023-06-05 14:41:45 --> Router Class Initialized
INFO - 2023-06-05 14:41:45 --> Output Class Initialized
INFO - 2023-06-05 14:41:45 --> Security Class Initialized
DEBUG - 2023-06-05 14:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 14:41:45 --> Input Class Initialized
INFO - 2023-06-05 14:41:45 --> Language Class Initialized
INFO - 2023-06-05 14:41:45 --> Loader Class Initialized
INFO - 2023-06-05 14:41:45 --> Helper loaded: url_helper
INFO - 2023-06-05 14:41:45 --> Helper loaded: file_helper
INFO - 2023-06-05 14:41:45 --> Helper loaded: html_helper
INFO - 2023-06-05 14:41:45 --> Helper loaded: text_helper
INFO - 2023-06-05 14:41:45 --> Helper loaded: form_helper
INFO - 2023-06-05 14:41:45 --> Helper loaded: lang_helper
INFO - 2023-06-05 14:41:45 --> Helper loaded: security_helper
INFO - 2023-06-05 14:41:45 --> Helper loaded: cookie_helper
INFO - 2023-06-05 14:41:45 --> Database Driver Class Initialized
INFO - 2023-06-05 14:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 14:41:45 --> Parser Class Initialized
INFO - 2023-06-05 14:41:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 14:41:45 --> Pagination Class Initialized
INFO - 2023-06-05 14:41:45 --> Form Validation Class Initialized
INFO - 2023-06-05 14:41:45 --> Controller Class Initialized
ERROR - 2023-06-05 15:42:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 15:42:41 --> Config Class Initialized
INFO - 2023-06-05 15:42:41 --> Hooks Class Initialized
DEBUG - 2023-06-05 15:42:41 --> UTF-8 Support Enabled
INFO - 2023-06-05 15:42:41 --> Utf8 Class Initialized
INFO - 2023-06-05 15:42:41 --> URI Class Initialized
DEBUG - 2023-06-05 15:42:41 --> No URI present. Default controller set.
INFO - 2023-06-05 15:42:41 --> Router Class Initialized
INFO - 2023-06-05 15:42:41 --> Output Class Initialized
INFO - 2023-06-05 15:42:41 --> Security Class Initialized
DEBUG - 2023-06-05 15:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 15:42:41 --> Input Class Initialized
INFO - 2023-06-05 15:42:41 --> Language Class Initialized
INFO - 2023-06-05 15:42:41 --> Loader Class Initialized
INFO - 2023-06-05 15:42:41 --> Helper loaded: url_helper
INFO - 2023-06-05 15:42:41 --> Helper loaded: file_helper
INFO - 2023-06-05 15:42:41 --> Helper loaded: html_helper
INFO - 2023-06-05 15:42:41 --> Helper loaded: text_helper
INFO - 2023-06-05 15:42:41 --> Helper loaded: form_helper
INFO - 2023-06-05 15:42:41 --> Helper loaded: lang_helper
INFO - 2023-06-05 15:42:41 --> Helper loaded: security_helper
INFO - 2023-06-05 15:42:41 --> Helper loaded: cookie_helper
INFO - 2023-06-05 15:42:41 --> Database Driver Class Initialized
INFO - 2023-06-05 15:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 15:42:41 --> Parser Class Initialized
INFO - 2023-06-05 15:42:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 15:42:41 --> Pagination Class Initialized
INFO - 2023-06-05 15:42:41 --> Form Validation Class Initialized
INFO - 2023-06-05 15:42:41 --> Controller Class Initialized
INFO - 2023-06-05 15:42:41 --> Model Class Initialized
DEBUG - 2023-06-05 15:42:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-05 15:42:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 15:42:42 --> Config Class Initialized
INFO - 2023-06-05 15:42:42 --> Hooks Class Initialized
DEBUG - 2023-06-05 15:42:42 --> UTF-8 Support Enabled
INFO - 2023-06-05 15:42:42 --> Utf8 Class Initialized
INFO - 2023-06-05 15:42:42 --> URI Class Initialized
INFO - 2023-06-05 15:42:42 --> Router Class Initialized
INFO - 2023-06-05 15:42:42 --> Output Class Initialized
INFO - 2023-06-05 15:42:42 --> Security Class Initialized
DEBUG - 2023-06-05 15:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 15:42:42 --> Input Class Initialized
INFO - 2023-06-05 15:42:42 --> Language Class Initialized
INFO - 2023-06-05 15:42:42 --> Loader Class Initialized
INFO - 2023-06-05 15:42:42 --> Helper loaded: url_helper
INFO - 2023-06-05 15:42:42 --> Helper loaded: file_helper
INFO - 2023-06-05 15:42:42 --> Helper loaded: html_helper
INFO - 2023-06-05 15:42:42 --> Helper loaded: text_helper
INFO - 2023-06-05 15:42:42 --> Helper loaded: form_helper
INFO - 2023-06-05 15:42:42 --> Helper loaded: lang_helper
INFO - 2023-06-05 15:42:42 --> Helper loaded: security_helper
INFO - 2023-06-05 15:42:42 --> Helper loaded: cookie_helper
INFO - 2023-06-05 15:42:42 --> Database Driver Class Initialized
INFO - 2023-06-05 15:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 15:42:42 --> Parser Class Initialized
INFO - 2023-06-05 15:42:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 15:42:42 --> Pagination Class Initialized
INFO - 2023-06-05 15:42:42 --> Form Validation Class Initialized
INFO - 2023-06-05 15:42:42 --> Controller Class Initialized
INFO - 2023-06-05 15:42:42 --> Model Class Initialized
DEBUG - 2023-06-05 15:42:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 15:42:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-05 15:42:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 15:42:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 15:42:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 15:42:42 --> Model Class Initialized
INFO - 2023-06-05 15:42:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 15:42:42 --> Final output sent to browser
DEBUG - 2023-06-05 15:42:42 --> Total execution time: 0.0334
ERROR - 2023-06-05 15:43:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 15:43:04 --> Config Class Initialized
INFO - 2023-06-05 15:43:04 --> Hooks Class Initialized
DEBUG - 2023-06-05 15:43:04 --> UTF-8 Support Enabled
INFO - 2023-06-05 15:43:04 --> Utf8 Class Initialized
INFO - 2023-06-05 15:43:04 --> URI Class Initialized
INFO - 2023-06-05 15:43:04 --> Router Class Initialized
INFO - 2023-06-05 15:43:04 --> Output Class Initialized
INFO - 2023-06-05 15:43:04 --> Security Class Initialized
DEBUG - 2023-06-05 15:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 15:43:04 --> Input Class Initialized
INFO - 2023-06-05 15:43:04 --> Language Class Initialized
INFO - 2023-06-05 15:43:04 --> Loader Class Initialized
INFO - 2023-06-05 15:43:04 --> Helper loaded: url_helper
INFO - 2023-06-05 15:43:04 --> Helper loaded: file_helper
INFO - 2023-06-05 15:43:04 --> Helper loaded: html_helper
INFO - 2023-06-05 15:43:04 --> Helper loaded: text_helper
INFO - 2023-06-05 15:43:04 --> Helper loaded: form_helper
INFO - 2023-06-05 15:43:04 --> Helper loaded: lang_helper
INFO - 2023-06-05 15:43:04 --> Helper loaded: security_helper
INFO - 2023-06-05 15:43:04 --> Helper loaded: cookie_helper
INFO - 2023-06-05 15:43:04 --> Database Driver Class Initialized
INFO - 2023-06-05 15:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 15:43:04 --> Parser Class Initialized
INFO - 2023-06-05 15:43:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 15:43:04 --> Pagination Class Initialized
INFO - 2023-06-05 15:43:04 --> Form Validation Class Initialized
INFO - 2023-06-05 15:43:04 --> Controller Class Initialized
INFO - 2023-06-05 15:43:04 --> Model Class Initialized
DEBUG - 2023-06-05 15:43:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 15:43:04 --> Model Class Initialized
INFO - 2023-06-05 15:43:04 --> Final output sent to browser
DEBUG - 2023-06-05 15:43:04 --> Total execution time: 0.0201
ERROR - 2023-06-05 15:43:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 15:43:07 --> Config Class Initialized
INFO - 2023-06-05 15:43:07 --> Hooks Class Initialized
DEBUG - 2023-06-05 15:43:07 --> UTF-8 Support Enabled
INFO - 2023-06-05 15:43:07 --> Utf8 Class Initialized
INFO - 2023-06-05 15:43:07 --> URI Class Initialized
DEBUG - 2023-06-05 15:43:07 --> No URI present. Default controller set.
INFO - 2023-06-05 15:43:07 --> Router Class Initialized
INFO - 2023-06-05 15:43:07 --> Output Class Initialized
INFO - 2023-06-05 15:43:07 --> Security Class Initialized
DEBUG - 2023-06-05 15:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 15:43:07 --> Input Class Initialized
INFO - 2023-06-05 15:43:07 --> Language Class Initialized
INFO - 2023-06-05 15:43:07 --> Loader Class Initialized
INFO - 2023-06-05 15:43:07 --> Helper loaded: url_helper
INFO - 2023-06-05 15:43:07 --> Helper loaded: file_helper
INFO - 2023-06-05 15:43:07 --> Helper loaded: html_helper
INFO - 2023-06-05 15:43:07 --> Helper loaded: text_helper
INFO - 2023-06-05 15:43:07 --> Helper loaded: form_helper
INFO - 2023-06-05 15:43:07 --> Helper loaded: lang_helper
INFO - 2023-06-05 15:43:07 --> Helper loaded: security_helper
INFO - 2023-06-05 15:43:07 --> Helper loaded: cookie_helper
INFO - 2023-06-05 15:43:07 --> Database Driver Class Initialized
INFO - 2023-06-05 15:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 15:43:07 --> Parser Class Initialized
INFO - 2023-06-05 15:43:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 15:43:07 --> Pagination Class Initialized
INFO - 2023-06-05 15:43:07 --> Form Validation Class Initialized
INFO - 2023-06-05 15:43:07 --> Controller Class Initialized
INFO - 2023-06-05 15:43:07 --> Model Class Initialized
DEBUG - 2023-06-05 15:43:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 15:43:07 --> Model Class Initialized
DEBUG - 2023-06-05 15:43:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 15:43:07 --> Model Class Initialized
INFO - 2023-06-05 15:43:07 --> Model Class Initialized
INFO - 2023-06-05 15:43:07 --> Model Class Initialized
INFO - 2023-06-05 15:43:07 --> Model Class Initialized
DEBUG - 2023-06-05 15:43:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 15:43:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 15:43:07 --> Model Class Initialized
INFO - 2023-06-05 15:43:07 --> Model Class Initialized
INFO - 2023-06-05 15:43:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-05 15:43:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 15:43:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 15:43:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 15:43:07 --> Model Class Initialized
INFO - 2023-06-05 15:43:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 15:43:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 15:43:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 15:43:07 --> Final output sent to browser
DEBUG - 2023-06-05 15:43:07 --> Total execution time: 0.0816
ERROR - 2023-06-05 15:43:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 15:43:21 --> Config Class Initialized
INFO - 2023-06-05 15:43:21 --> Hooks Class Initialized
DEBUG - 2023-06-05 15:43:21 --> UTF-8 Support Enabled
INFO - 2023-06-05 15:43:21 --> Utf8 Class Initialized
INFO - 2023-06-05 15:43:21 --> URI Class Initialized
INFO - 2023-06-05 15:43:21 --> Router Class Initialized
INFO - 2023-06-05 15:43:21 --> Output Class Initialized
INFO - 2023-06-05 15:43:21 --> Security Class Initialized
DEBUG - 2023-06-05 15:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 15:43:21 --> Input Class Initialized
INFO - 2023-06-05 15:43:21 --> Language Class Initialized
INFO - 2023-06-05 15:43:21 --> Loader Class Initialized
INFO - 2023-06-05 15:43:21 --> Helper loaded: url_helper
INFO - 2023-06-05 15:43:21 --> Helper loaded: file_helper
INFO - 2023-06-05 15:43:21 --> Helper loaded: html_helper
INFO - 2023-06-05 15:43:21 --> Helper loaded: text_helper
INFO - 2023-06-05 15:43:21 --> Helper loaded: form_helper
INFO - 2023-06-05 15:43:21 --> Helper loaded: lang_helper
INFO - 2023-06-05 15:43:21 --> Helper loaded: security_helper
INFO - 2023-06-05 15:43:21 --> Helper loaded: cookie_helper
INFO - 2023-06-05 15:43:21 --> Database Driver Class Initialized
INFO - 2023-06-05 15:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 15:43:21 --> Parser Class Initialized
INFO - 2023-06-05 15:43:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 15:43:21 --> Pagination Class Initialized
INFO - 2023-06-05 15:43:21 --> Form Validation Class Initialized
INFO - 2023-06-05 15:43:21 --> Controller Class Initialized
INFO - 2023-06-05 15:43:21 --> Model Class Initialized
DEBUG - 2023-06-05 15:43:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 15:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 15:43:21 --> Model Class Initialized
INFO - 2023-06-05 15:43:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-06-05 15:43:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 15:43:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 15:43:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 15:43:21 --> Model Class Initialized
INFO - 2023-06-05 15:43:21 --> Model Class Initialized
INFO - 2023-06-05 15:43:21 --> Model Class Initialized
INFO - 2023-06-05 15:43:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 15:43:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 15:43:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 15:43:21 --> Final output sent to browser
DEBUG - 2023-06-05 15:43:21 --> Total execution time: 0.0739
ERROR - 2023-06-05 15:43:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 15:43:22 --> Config Class Initialized
INFO - 2023-06-05 15:43:22 --> Hooks Class Initialized
DEBUG - 2023-06-05 15:43:22 --> UTF-8 Support Enabled
INFO - 2023-06-05 15:43:22 --> Utf8 Class Initialized
INFO - 2023-06-05 15:43:22 --> URI Class Initialized
INFO - 2023-06-05 15:43:22 --> Router Class Initialized
INFO - 2023-06-05 15:43:22 --> Output Class Initialized
INFO - 2023-06-05 15:43:22 --> Security Class Initialized
DEBUG - 2023-06-05 15:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 15:43:22 --> Input Class Initialized
INFO - 2023-06-05 15:43:22 --> Language Class Initialized
INFO - 2023-06-05 15:43:22 --> Loader Class Initialized
INFO - 2023-06-05 15:43:22 --> Helper loaded: url_helper
INFO - 2023-06-05 15:43:22 --> Helper loaded: file_helper
INFO - 2023-06-05 15:43:22 --> Helper loaded: html_helper
INFO - 2023-06-05 15:43:22 --> Helper loaded: text_helper
INFO - 2023-06-05 15:43:22 --> Helper loaded: form_helper
INFO - 2023-06-05 15:43:22 --> Helper loaded: lang_helper
INFO - 2023-06-05 15:43:22 --> Helper loaded: security_helper
INFO - 2023-06-05 15:43:22 --> Helper loaded: cookie_helper
INFO - 2023-06-05 15:43:22 --> Database Driver Class Initialized
INFO - 2023-06-05 15:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 15:43:22 --> Parser Class Initialized
INFO - 2023-06-05 15:43:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 15:43:22 --> Pagination Class Initialized
INFO - 2023-06-05 15:43:22 --> Form Validation Class Initialized
INFO - 2023-06-05 15:43:22 --> Controller Class Initialized
INFO - 2023-06-05 15:43:22 --> Model Class Initialized
DEBUG - 2023-06-05 15:43:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 15:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 15:43:22 --> Model Class Initialized
INFO - 2023-06-05 15:43:22 --> Final output sent to browser
DEBUG - 2023-06-05 15:43:22 --> Total execution time: 0.0286
ERROR - 2023-06-05 15:43:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 15:43:25 --> Config Class Initialized
INFO - 2023-06-05 15:43:25 --> Hooks Class Initialized
DEBUG - 2023-06-05 15:43:25 --> UTF-8 Support Enabled
INFO - 2023-06-05 15:43:25 --> Utf8 Class Initialized
INFO - 2023-06-05 15:43:25 --> URI Class Initialized
INFO - 2023-06-05 15:43:25 --> Router Class Initialized
INFO - 2023-06-05 15:43:25 --> Output Class Initialized
INFO - 2023-06-05 15:43:25 --> Security Class Initialized
DEBUG - 2023-06-05 15:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 15:43:25 --> Input Class Initialized
INFO - 2023-06-05 15:43:25 --> Language Class Initialized
INFO - 2023-06-05 15:43:25 --> Loader Class Initialized
INFO - 2023-06-05 15:43:25 --> Helper loaded: url_helper
INFO - 2023-06-05 15:43:25 --> Helper loaded: file_helper
INFO - 2023-06-05 15:43:25 --> Helper loaded: html_helper
INFO - 2023-06-05 15:43:25 --> Helper loaded: text_helper
INFO - 2023-06-05 15:43:25 --> Helper loaded: form_helper
INFO - 2023-06-05 15:43:25 --> Helper loaded: lang_helper
INFO - 2023-06-05 15:43:25 --> Helper loaded: security_helper
INFO - 2023-06-05 15:43:25 --> Helper loaded: cookie_helper
INFO - 2023-06-05 15:43:25 --> Database Driver Class Initialized
INFO - 2023-06-05 15:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 15:43:25 --> Parser Class Initialized
INFO - 2023-06-05 15:43:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 15:43:25 --> Pagination Class Initialized
INFO - 2023-06-05 15:43:25 --> Form Validation Class Initialized
INFO - 2023-06-05 15:43:25 --> Controller Class Initialized
INFO - 2023-06-05 15:43:25 --> Model Class Initialized
DEBUG - 2023-06-05 15:43:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 15:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 15:43:25 --> Model Class Initialized
INFO - 2023-06-05 15:43:25 --> Final output sent to browser
DEBUG - 2023-06-05 15:43:25 --> Total execution time: 0.0298
ERROR - 2023-06-05 15:44:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 15:44:19 --> Config Class Initialized
INFO - 2023-06-05 15:44:19 --> Hooks Class Initialized
DEBUG - 2023-06-05 15:44:19 --> UTF-8 Support Enabled
INFO - 2023-06-05 15:44:19 --> Utf8 Class Initialized
INFO - 2023-06-05 15:44:19 --> URI Class Initialized
DEBUG - 2023-06-05 15:44:19 --> No URI present. Default controller set.
INFO - 2023-06-05 15:44:19 --> Router Class Initialized
INFO - 2023-06-05 15:44:19 --> Output Class Initialized
INFO - 2023-06-05 15:44:19 --> Security Class Initialized
DEBUG - 2023-06-05 15:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 15:44:19 --> Input Class Initialized
INFO - 2023-06-05 15:44:19 --> Language Class Initialized
INFO - 2023-06-05 15:44:19 --> Loader Class Initialized
INFO - 2023-06-05 15:44:19 --> Helper loaded: url_helper
INFO - 2023-06-05 15:44:19 --> Helper loaded: file_helper
INFO - 2023-06-05 15:44:19 --> Helper loaded: html_helper
INFO - 2023-06-05 15:44:19 --> Helper loaded: text_helper
INFO - 2023-06-05 15:44:19 --> Helper loaded: form_helper
INFO - 2023-06-05 15:44:19 --> Helper loaded: lang_helper
INFO - 2023-06-05 15:44:19 --> Helper loaded: security_helper
INFO - 2023-06-05 15:44:19 --> Helper loaded: cookie_helper
INFO - 2023-06-05 15:44:19 --> Database Driver Class Initialized
INFO - 2023-06-05 15:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 15:44:19 --> Parser Class Initialized
INFO - 2023-06-05 15:44:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 15:44:19 --> Pagination Class Initialized
INFO - 2023-06-05 15:44:19 --> Form Validation Class Initialized
INFO - 2023-06-05 15:44:19 --> Controller Class Initialized
INFO - 2023-06-05 15:44:19 --> Model Class Initialized
DEBUG - 2023-06-05 15:44:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 15:44:19 --> Model Class Initialized
DEBUG - 2023-06-05 15:44:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 15:44:19 --> Model Class Initialized
INFO - 2023-06-05 15:44:19 --> Model Class Initialized
INFO - 2023-06-05 15:44:19 --> Model Class Initialized
INFO - 2023-06-05 15:44:19 --> Model Class Initialized
DEBUG - 2023-06-05 15:44:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 15:44:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 15:44:19 --> Model Class Initialized
INFO - 2023-06-05 15:44:19 --> Model Class Initialized
INFO - 2023-06-05 15:44:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-05 15:44:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 15:44:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 15:44:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 15:44:19 --> Model Class Initialized
INFO - 2023-06-05 15:44:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 15:44:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 15:44:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 15:44:19 --> Final output sent to browser
DEBUG - 2023-06-05 15:44:19 --> Total execution time: 0.0818
ERROR - 2023-06-05 15:44:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 15:44:31 --> Config Class Initialized
INFO - 2023-06-05 15:44:31 --> Hooks Class Initialized
DEBUG - 2023-06-05 15:44:31 --> UTF-8 Support Enabled
INFO - 2023-06-05 15:44:31 --> Utf8 Class Initialized
INFO - 2023-06-05 15:44:31 --> URI Class Initialized
INFO - 2023-06-05 15:44:31 --> Router Class Initialized
INFO - 2023-06-05 15:44:31 --> Output Class Initialized
INFO - 2023-06-05 15:44:31 --> Security Class Initialized
DEBUG - 2023-06-05 15:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 15:44:31 --> Input Class Initialized
INFO - 2023-06-05 15:44:31 --> Language Class Initialized
INFO - 2023-06-05 15:44:31 --> Loader Class Initialized
INFO - 2023-06-05 15:44:31 --> Helper loaded: url_helper
INFO - 2023-06-05 15:44:31 --> Helper loaded: file_helper
INFO - 2023-06-05 15:44:31 --> Helper loaded: html_helper
INFO - 2023-06-05 15:44:31 --> Helper loaded: text_helper
INFO - 2023-06-05 15:44:31 --> Helper loaded: form_helper
INFO - 2023-06-05 15:44:31 --> Helper loaded: lang_helper
INFO - 2023-06-05 15:44:31 --> Helper loaded: security_helper
INFO - 2023-06-05 15:44:31 --> Helper loaded: cookie_helper
INFO - 2023-06-05 15:44:31 --> Database Driver Class Initialized
INFO - 2023-06-05 15:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 15:44:31 --> Parser Class Initialized
INFO - 2023-06-05 15:44:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 15:44:31 --> Pagination Class Initialized
INFO - 2023-06-05 15:44:31 --> Form Validation Class Initialized
INFO - 2023-06-05 15:44:31 --> Controller Class Initialized
INFO - 2023-06-05 15:44:31 --> Model Class Initialized
INFO - 2023-06-05 15:44:31 --> Model Class Initialized
INFO - 2023-06-05 15:44:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/report/out_of_stock.php
DEBUG - 2023-06-05 15:44:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 15:44:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 15:44:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 15:44:31 --> Model Class Initialized
INFO - 2023-06-05 15:44:31 --> Model Class Initialized
INFO - 2023-06-05 15:44:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 15:44:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 15:44:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 15:44:31 --> Final output sent to browser
DEBUG - 2023-06-05 15:44:31 --> Total execution time: 0.0752
ERROR - 2023-06-05 15:44:32 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 15:44:32 --> Config Class Initialized
INFO - 2023-06-05 15:44:32 --> Hooks Class Initialized
DEBUG - 2023-06-05 15:44:32 --> UTF-8 Support Enabled
INFO - 2023-06-05 15:44:32 --> Utf8 Class Initialized
INFO - 2023-06-05 15:44:32 --> URI Class Initialized
INFO - 2023-06-05 15:44:32 --> Router Class Initialized
INFO - 2023-06-05 15:44:32 --> Output Class Initialized
INFO - 2023-06-05 15:44:32 --> Security Class Initialized
DEBUG - 2023-06-05 15:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 15:44:32 --> Input Class Initialized
INFO - 2023-06-05 15:44:32 --> Language Class Initialized
INFO - 2023-06-05 15:44:32 --> Loader Class Initialized
INFO - 2023-06-05 15:44:32 --> Helper loaded: url_helper
INFO - 2023-06-05 15:44:32 --> Helper loaded: file_helper
INFO - 2023-06-05 15:44:32 --> Helper loaded: html_helper
INFO - 2023-06-05 15:44:32 --> Helper loaded: text_helper
INFO - 2023-06-05 15:44:32 --> Helper loaded: form_helper
INFO - 2023-06-05 15:44:32 --> Helper loaded: lang_helper
INFO - 2023-06-05 15:44:32 --> Helper loaded: security_helper
INFO - 2023-06-05 15:44:32 --> Helper loaded: cookie_helper
INFO - 2023-06-05 15:44:32 --> Database Driver Class Initialized
INFO - 2023-06-05 15:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 15:44:32 --> Parser Class Initialized
INFO - 2023-06-05 15:44:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 15:44:32 --> Pagination Class Initialized
INFO - 2023-06-05 15:44:32 --> Form Validation Class Initialized
INFO - 2023-06-05 15:44:32 --> Controller Class Initialized
INFO - 2023-06-05 15:44:32 --> Model Class Initialized
INFO - 2023-06-05 15:44:32 --> Model Class Initialized
INFO - 2023-06-05 15:44:32 --> Final output sent to browser
DEBUG - 2023-06-05 15:44:32 --> Total execution time: 0.0269
ERROR - 2023-06-05 15:45:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 15:45:13 --> Config Class Initialized
INFO - 2023-06-05 15:45:13 --> Hooks Class Initialized
DEBUG - 2023-06-05 15:45:13 --> UTF-8 Support Enabled
INFO - 2023-06-05 15:45:13 --> Utf8 Class Initialized
INFO - 2023-06-05 15:45:13 --> URI Class Initialized
DEBUG - 2023-06-05 15:45:13 --> No URI present. Default controller set.
INFO - 2023-06-05 15:45:13 --> Router Class Initialized
INFO - 2023-06-05 15:45:13 --> Output Class Initialized
INFO - 2023-06-05 15:45:13 --> Security Class Initialized
DEBUG - 2023-06-05 15:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 15:45:13 --> Input Class Initialized
INFO - 2023-06-05 15:45:13 --> Language Class Initialized
INFO - 2023-06-05 15:45:13 --> Loader Class Initialized
INFO - 2023-06-05 15:45:13 --> Helper loaded: url_helper
INFO - 2023-06-05 15:45:13 --> Helper loaded: file_helper
INFO - 2023-06-05 15:45:13 --> Helper loaded: html_helper
INFO - 2023-06-05 15:45:13 --> Helper loaded: text_helper
INFO - 2023-06-05 15:45:13 --> Helper loaded: form_helper
INFO - 2023-06-05 15:45:13 --> Helper loaded: lang_helper
INFO - 2023-06-05 15:45:13 --> Helper loaded: security_helper
INFO - 2023-06-05 15:45:13 --> Helper loaded: cookie_helper
INFO - 2023-06-05 15:45:13 --> Database Driver Class Initialized
INFO - 2023-06-05 15:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 15:45:13 --> Parser Class Initialized
INFO - 2023-06-05 15:45:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 15:45:13 --> Pagination Class Initialized
INFO - 2023-06-05 15:45:13 --> Form Validation Class Initialized
INFO - 2023-06-05 15:45:13 --> Controller Class Initialized
INFO - 2023-06-05 15:45:13 --> Model Class Initialized
DEBUG - 2023-06-05 15:45:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 15:45:13 --> Model Class Initialized
DEBUG - 2023-06-05 15:45:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 15:45:13 --> Model Class Initialized
INFO - 2023-06-05 15:45:13 --> Model Class Initialized
INFO - 2023-06-05 15:45:13 --> Model Class Initialized
INFO - 2023-06-05 15:45:13 --> Model Class Initialized
DEBUG - 2023-06-05 15:45:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 15:45:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 15:45:13 --> Model Class Initialized
INFO - 2023-06-05 15:45:13 --> Model Class Initialized
INFO - 2023-06-05 15:45:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-05 15:45:13 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 15:45:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 15:45:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 15:45:13 --> Model Class Initialized
INFO - 2023-06-05 15:45:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 15:45:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 15:45:13 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 15:45:13 --> Final output sent to browser
DEBUG - 2023-06-05 15:45:13 --> Total execution time: 0.0789
ERROR - 2023-06-05 15:45:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 15:45:22 --> Config Class Initialized
INFO - 2023-06-05 15:45:22 --> Hooks Class Initialized
DEBUG - 2023-06-05 15:45:22 --> UTF-8 Support Enabled
INFO - 2023-06-05 15:45:22 --> Utf8 Class Initialized
INFO - 2023-06-05 15:45:22 --> URI Class Initialized
INFO - 2023-06-05 15:45:22 --> Router Class Initialized
INFO - 2023-06-05 15:45:22 --> Output Class Initialized
INFO - 2023-06-05 15:45:22 --> Security Class Initialized
DEBUG - 2023-06-05 15:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 15:45:22 --> Input Class Initialized
INFO - 2023-06-05 15:45:22 --> Language Class Initialized
INFO - 2023-06-05 15:45:22 --> Loader Class Initialized
INFO - 2023-06-05 15:45:22 --> Helper loaded: url_helper
INFO - 2023-06-05 15:45:22 --> Helper loaded: file_helper
INFO - 2023-06-05 15:45:22 --> Helper loaded: html_helper
INFO - 2023-06-05 15:45:22 --> Helper loaded: text_helper
INFO - 2023-06-05 15:45:22 --> Helper loaded: form_helper
INFO - 2023-06-05 15:45:22 --> Helper loaded: lang_helper
INFO - 2023-06-05 15:45:22 --> Helper loaded: security_helper
INFO - 2023-06-05 15:45:22 --> Helper loaded: cookie_helper
INFO - 2023-06-05 15:45:22 --> Database Driver Class Initialized
INFO - 2023-06-05 15:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 15:45:22 --> Parser Class Initialized
INFO - 2023-06-05 15:45:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 15:45:22 --> Pagination Class Initialized
INFO - 2023-06-05 15:45:22 --> Form Validation Class Initialized
INFO - 2023-06-05 15:45:22 --> Controller Class Initialized
INFO - 2023-06-05 15:45:22 --> Model Class Initialized
DEBUG - 2023-06-05 15:45:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 15:45:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 15:45:22 --> Model Class Initialized
INFO - 2023-06-05 15:45:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-06-05 15:45:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 15:45:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 15:45:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 15:45:22 --> Model Class Initialized
INFO - 2023-06-05 15:45:22 --> Model Class Initialized
INFO - 2023-06-05 15:45:22 --> Model Class Initialized
INFO - 2023-06-05 15:45:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 15:45:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 15:45:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 15:45:22 --> Final output sent to browser
DEBUG - 2023-06-05 15:45:22 --> Total execution time: 0.0645
ERROR - 2023-06-05 15:45:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 15:45:23 --> Config Class Initialized
INFO - 2023-06-05 15:45:23 --> Hooks Class Initialized
DEBUG - 2023-06-05 15:45:23 --> UTF-8 Support Enabled
INFO - 2023-06-05 15:45:23 --> Utf8 Class Initialized
INFO - 2023-06-05 15:45:23 --> URI Class Initialized
INFO - 2023-06-05 15:45:23 --> Router Class Initialized
INFO - 2023-06-05 15:45:23 --> Output Class Initialized
INFO - 2023-06-05 15:45:23 --> Security Class Initialized
DEBUG - 2023-06-05 15:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 15:45:23 --> Input Class Initialized
INFO - 2023-06-05 15:45:23 --> Language Class Initialized
INFO - 2023-06-05 15:45:23 --> Loader Class Initialized
INFO - 2023-06-05 15:45:23 --> Helper loaded: url_helper
INFO - 2023-06-05 15:45:23 --> Helper loaded: file_helper
INFO - 2023-06-05 15:45:23 --> Helper loaded: html_helper
INFO - 2023-06-05 15:45:23 --> Helper loaded: text_helper
INFO - 2023-06-05 15:45:23 --> Helper loaded: form_helper
INFO - 2023-06-05 15:45:23 --> Helper loaded: lang_helper
INFO - 2023-06-05 15:45:23 --> Helper loaded: security_helper
INFO - 2023-06-05 15:45:23 --> Helper loaded: cookie_helper
INFO - 2023-06-05 15:45:23 --> Database Driver Class Initialized
INFO - 2023-06-05 15:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 15:45:23 --> Parser Class Initialized
INFO - 2023-06-05 15:45:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 15:45:23 --> Pagination Class Initialized
INFO - 2023-06-05 15:45:23 --> Form Validation Class Initialized
INFO - 2023-06-05 15:45:23 --> Controller Class Initialized
INFO - 2023-06-05 15:45:23 --> Model Class Initialized
DEBUG - 2023-06-05 15:45:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 15:45:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 15:45:23 --> Model Class Initialized
INFO - 2023-06-05 15:45:23 --> Final output sent to browser
DEBUG - 2023-06-05 15:45:23 --> Total execution time: 0.0259
ERROR - 2023-06-05 15:45:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 15:45:27 --> Config Class Initialized
INFO - 2023-06-05 15:45:27 --> Hooks Class Initialized
DEBUG - 2023-06-05 15:45:27 --> UTF-8 Support Enabled
INFO - 2023-06-05 15:45:27 --> Utf8 Class Initialized
INFO - 2023-06-05 15:45:27 --> URI Class Initialized
INFO - 2023-06-05 15:45:27 --> Router Class Initialized
INFO - 2023-06-05 15:45:27 --> Output Class Initialized
INFO - 2023-06-05 15:45:27 --> Security Class Initialized
DEBUG - 2023-06-05 15:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 15:45:27 --> Input Class Initialized
INFO - 2023-06-05 15:45:27 --> Language Class Initialized
INFO - 2023-06-05 15:45:27 --> Loader Class Initialized
INFO - 2023-06-05 15:45:27 --> Helper loaded: url_helper
INFO - 2023-06-05 15:45:27 --> Helper loaded: file_helper
INFO - 2023-06-05 15:45:27 --> Helper loaded: html_helper
INFO - 2023-06-05 15:45:27 --> Helper loaded: text_helper
INFO - 2023-06-05 15:45:27 --> Helper loaded: form_helper
INFO - 2023-06-05 15:45:27 --> Helper loaded: lang_helper
INFO - 2023-06-05 15:45:27 --> Helper loaded: security_helper
INFO - 2023-06-05 15:45:27 --> Helper loaded: cookie_helper
INFO - 2023-06-05 15:45:27 --> Database Driver Class Initialized
INFO - 2023-06-05 15:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 15:45:27 --> Parser Class Initialized
INFO - 2023-06-05 15:45:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 15:45:27 --> Pagination Class Initialized
INFO - 2023-06-05 15:45:27 --> Form Validation Class Initialized
INFO - 2023-06-05 15:45:27 --> Controller Class Initialized
INFO - 2023-06-05 15:45:27 --> Model Class Initialized
DEBUG - 2023-06-05 15:45:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 15:45:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 15:45:27 --> Model Class Initialized
INFO - 2023-06-05 15:45:27 --> Final output sent to browser
DEBUG - 2023-06-05 15:45:27 --> Total execution time: 0.0294
ERROR - 2023-06-05 16:29:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 16:29:28 --> Config Class Initialized
INFO - 2023-06-05 16:29:28 --> Hooks Class Initialized
DEBUG - 2023-06-05 16:29:28 --> UTF-8 Support Enabled
INFO - 2023-06-05 16:29:28 --> Utf8 Class Initialized
INFO - 2023-06-05 16:29:28 --> URI Class Initialized
DEBUG - 2023-06-05 16:29:28 --> No URI present. Default controller set.
INFO - 2023-06-05 16:29:28 --> Router Class Initialized
INFO - 2023-06-05 16:29:28 --> Output Class Initialized
INFO - 2023-06-05 16:29:28 --> Security Class Initialized
DEBUG - 2023-06-05 16:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 16:29:28 --> Input Class Initialized
INFO - 2023-06-05 16:29:28 --> Language Class Initialized
INFO - 2023-06-05 16:29:28 --> Loader Class Initialized
INFO - 2023-06-05 16:29:28 --> Helper loaded: url_helper
INFO - 2023-06-05 16:29:28 --> Helper loaded: file_helper
INFO - 2023-06-05 16:29:28 --> Helper loaded: html_helper
INFO - 2023-06-05 16:29:28 --> Helper loaded: text_helper
INFO - 2023-06-05 16:29:28 --> Helper loaded: form_helper
INFO - 2023-06-05 16:29:28 --> Helper loaded: lang_helper
INFO - 2023-06-05 16:29:28 --> Helper loaded: security_helper
INFO - 2023-06-05 16:29:28 --> Helper loaded: cookie_helper
INFO - 2023-06-05 16:29:28 --> Database Driver Class Initialized
INFO - 2023-06-05 16:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 16:29:28 --> Parser Class Initialized
INFO - 2023-06-05 16:29:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 16:29:28 --> Pagination Class Initialized
INFO - 2023-06-05 16:29:28 --> Form Validation Class Initialized
INFO - 2023-06-05 16:29:28 --> Controller Class Initialized
INFO - 2023-06-05 16:29:28 --> Model Class Initialized
DEBUG - 2023-06-05 16:29:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-05 16:29:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 16:29:29 --> Config Class Initialized
INFO - 2023-06-05 16:29:29 --> Hooks Class Initialized
DEBUG - 2023-06-05 16:29:29 --> UTF-8 Support Enabled
INFO - 2023-06-05 16:29:29 --> Utf8 Class Initialized
INFO - 2023-06-05 16:29:29 --> URI Class Initialized
INFO - 2023-06-05 16:29:29 --> Router Class Initialized
INFO - 2023-06-05 16:29:29 --> Output Class Initialized
INFO - 2023-06-05 16:29:29 --> Security Class Initialized
DEBUG - 2023-06-05 16:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 16:29:29 --> Input Class Initialized
INFO - 2023-06-05 16:29:29 --> Language Class Initialized
INFO - 2023-06-05 16:29:29 --> Loader Class Initialized
INFO - 2023-06-05 16:29:29 --> Helper loaded: url_helper
INFO - 2023-06-05 16:29:29 --> Helper loaded: file_helper
INFO - 2023-06-05 16:29:29 --> Helper loaded: html_helper
INFO - 2023-06-05 16:29:29 --> Helper loaded: text_helper
INFO - 2023-06-05 16:29:29 --> Helper loaded: form_helper
INFO - 2023-06-05 16:29:29 --> Helper loaded: lang_helper
INFO - 2023-06-05 16:29:29 --> Helper loaded: security_helper
INFO - 2023-06-05 16:29:29 --> Helper loaded: cookie_helper
INFO - 2023-06-05 16:29:29 --> Database Driver Class Initialized
INFO - 2023-06-05 16:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 16:29:29 --> Parser Class Initialized
INFO - 2023-06-05 16:29:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 16:29:29 --> Pagination Class Initialized
INFO - 2023-06-05 16:29:29 --> Form Validation Class Initialized
INFO - 2023-06-05 16:29:29 --> Controller Class Initialized
INFO - 2023-06-05 16:29:29 --> Model Class Initialized
DEBUG - 2023-06-05 16:29:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 16:29:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-05 16:29:29 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 16:29:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 16:29:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 16:29:29 --> Model Class Initialized
INFO - 2023-06-05 16:29:29 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 16:29:29 --> Final output sent to browser
DEBUG - 2023-06-05 16:29:29 --> Total execution time: 0.0299
ERROR - 2023-06-05 16:32:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 16:32:26 --> Config Class Initialized
INFO - 2023-06-05 16:32:26 --> Hooks Class Initialized
DEBUG - 2023-06-05 16:32:26 --> UTF-8 Support Enabled
INFO - 2023-06-05 16:32:26 --> Utf8 Class Initialized
INFO - 2023-06-05 16:32:26 --> URI Class Initialized
INFO - 2023-06-05 16:32:26 --> Router Class Initialized
INFO - 2023-06-05 16:32:26 --> Output Class Initialized
INFO - 2023-06-05 16:32:26 --> Security Class Initialized
DEBUG - 2023-06-05 16:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 16:32:26 --> Input Class Initialized
INFO - 2023-06-05 16:32:26 --> Language Class Initialized
INFO - 2023-06-05 16:32:26 --> Loader Class Initialized
INFO - 2023-06-05 16:32:26 --> Helper loaded: url_helper
INFO - 2023-06-05 16:32:26 --> Helper loaded: file_helper
INFO - 2023-06-05 16:32:26 --> Helper loaded: html_helper
INFO - 2023-06-05 16:32:26 --> Helper loaded: text_helper
INFO - 2023-06-05 16:32:26 --> Helper loaded: form_helper
INFO - 2023-06-05 16:32:26 --> Helper loaded: lang_helper
INFO - 2023-06-05 16:32:26 --> Helper loaded: security_helper
INFO - 2023-06-05 16:32:26 --> Helper loaded: cookie_helper
INFO - 2023-06-05 16:32:26 --> Database Driver Class Initialized
INFO - 2023-06-05 16:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 16:32:26 --> Parser Class Initialized
INFO - 2023-06-05 16:32:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 16:32:26 --> Pagination Class Initialized
INFO - 2023-06-05 16:32:26 --> Form Validation Class Initialized
INFO - 2023-06-05 16:32:26 --> Controller Class Initialized
INFO - 2023-06-05 16:32:26 --> Model Class Initialized
DEBUG - 2023-06-05 16:32:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 16:32:26 --> Model Class Initialized
INFO - 2023-06-05 16:32:26 --> Final output sent to browser
DEBUG - 2023-06-05 16:32:26 --> Total execution time: 0.0202
ERROR - 2023-06-05 16:32:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 16:32:27 --> Config Class Initialized
INFO - 2023-06-05 16:32:27 --> Hooks Class Initialized
DEBUG - 2023-06-05 16:32:27 --> UTF-8 Support Enabled
INFO - 2023-06-05 16:32:27 --> Utf8 Class Initialized
INFO - 2023-06-05 16:32:27 --> URI Class Initialized
DEBUG - 2023-06-05 16:32:27 --> No URI present. Default controller set.
INFO - 2023-06-05 16:32:27 --> Router Class Initialized
INFO - 2023-06-05 16:32:27 --> Output Class Initialized
INFO - 2023-06-05 16:32:27 --> Security Class Initialized
DEBUG - 2023-06-05 16:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 16:32:27 --> Input Class Initialized
INFO - 2023-06-05 16:32:27 --> Language Class Initialized
INFO - 2023-06-05 16:32:27 --> Loader Class Initialized
INFO - 2023-06-05 16:32:27 --> Helper loaded: url_helper
INFO - 2023-06-05 16:32:27 --> Helper loaded: file_helper
INFO - 2023-06-05 16:32:27 --> Helper loaded: html_helper
INFO - 2023-06-05 16:32:27 --> Helper loaded: text_helper
INFO - 2023-06-05 16:32:27 --> Helper loaded: form_helper
INFO - 2023-06-05 16:32:27 --> Helper loaded: lang_helper
INFO - 2023-06-05 16:32:27 --> Helper loaded: security_helper
INFO - 2023-06-05 16:32:27 --> Helper loaded: cookie_helper
INFO - 2023-06-05 16:32:27 --> Database Driver Class Initialized
INFO - 2023-06-05 16:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 16:32:27 --> Parser Class Initialized
INFO - 2023-06-05 16:32:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 16:32:27 --> Pagination Class Initialized
INFO - 2023-06-05 16:32:27 --> Form Validation Class Initialized
INFO - 2023-06-05 16:32:27 --> Controller Class Initialized
INFO - 2023-06-05 16:32:27 --> Model Class Initialized
DEBUG - 2023-06-05 16:32:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 16:32:27 --> Model Class Initialized
DEBUG - 2023-06-05 16:32:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 16:32:27 --> Model Class Initialized
INFO - 2023-06-05 16:32:27 --> Model Class Initialized
INFO - 2023-06-05 16:32:27 --> Model Class Initialized
INFO - 2023-06-05 16:32:27 --> Model Class Initialized
DEBUG - 2023-06-05 16:32:27 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 16:32:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 16:32:27 --> Model Class Initialized
INFO - 2023-06-05 16:32:27 --> Model Class Initialized
INFO - 2023-06-05 16:32:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-05 16:32:27 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 16:32:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 16:32:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 16:32:27 --> Model Class Initialized
INFO - 2023-06-05 16:32:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 16:32:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 16:32:27 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 16:32:27 --> Final output sent to browser
DEBUG - 2023-06-05 16:32:27 --> Total execution time: 0.0780
ERROR - 2023-06-05 16:32:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 16:32:33 --> Config Class Initialized
INFO - 2023-06-05 16:32:33 --> Hooks Class Initialized
DEBUG - 2023-06-05 16:32:33 --> UTF-8 Support Enabled
INFO - 2023-06-05 16:32:33 --> Utf8 Class Initialized
INFO - 2023-06-05 16:32:33 --> URI Class Initialized
INFO - 2023-06-05 16:32:33 --> Router Class Initialized
INFO - 2023-06-05 16:32:33 --> Output Class Initialized
INFO - 2023-06-05 16:32:33 --> Security Class Initialized
DEBUG - 2023-06-05 16:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 16:32:33 --> Input Class Initialized
INFO - 2023-06-05 16:32:33 --> Language Class Initialized
INFO - 2023-06-05 16:32:33 --> Loader Class Initialized
INFO - 2023-06-05 16:32:33 --> Helper loaded: url_helper
INFO - 2023-06-05 16:32:33 --> Helper loaded: file_helper
INFO - 2023-06-05 16:32:33 --> Helper loaded: html_helper
INFO - 2023-06-05 16:32:33 --> Helper loaded: text_helper
INFO - 2023-06-05 16:32:33 --> Helper loaded: form_helper
INFO - 2023-06-05 16:32:33 --> Helper loaded: lang_helper
INFO - 2023-06-05 16:32:33 --> Helper loaded: security_helper
INFO - 2023-06-05 16:32:33 --> Helper loaded: cookie_helper
INFO - 2023-06-05 16:32:33 --> Database Driver Class Initialized
INFO - 2023-06-05 16:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 16:32:33 --> Parser Class Initialized
INFO - 2023-06-05 16:32:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 16:32:33 --> Pagination Class Initialized
INFO - 2023-06-05 16:32:33 --> Form Validation Class Initialized
INFO - 2023-06-05 16:32:33 --> Controller Class Initialized
INFO - 2023-06-05 16:32:33 --> Model Class Initialized
DEBUG - 2023-06-05 16:32:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 16:32:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 16:32:33 --> Model Class Initialized
INFO - 2023-06-05 16:32:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-06-05 16:32:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 16:32:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 16:32:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 16:32:33 --> Model Class Initialized
INFO - 2023-06-05 16:32:33 --> Model Class Initialized
INFO - 2023-06-05 16:32:33 --> Model Class Initialized
INFO - 2023-06-05 16:32:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 16:32:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 16:32:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 16:32:33 --> Final output sent to browser
DEBUG - 2023-06-05 16:32:33 --> Total execution time: 0.0639
ERROR - 2023-06-05 16:32:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 16:32:34 --> Config Class Initialized
INFO - 2023-06-05 16:32:34 --> Hooks Class Initialized
DEBUG - 2023-06-05 16:32:34 --> UTF-8 Support Enabled
INFO - 2023-06-05 16:32:34 --> Utf8 Class Initialized
INFO - 2023-06-05 16:32:34 --> URI Class Initialized
INFO - 2023-06-05 16:32:34 --> Router Class Initialized
INFO - 2023-06-05 16:32:34 --> Output Class Initialized
INFO - 2023-06-05 16:32:34 --> Security Class Initialized
DEBUG - 2023-06-05 16:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 16:32:34 --> Input Class Initialized
INFO - 2023-06-05 16:32:34 --> Language Class Initialized
INFO - 2023-06-05 16:32:34 --> Loader Class Initialized
INFO - 2023-06-05 16:32:34 --> Helper loaded: url_helper
INFO - 2023-06-05 16:32:34 --> Helper loaded: file_helper
INFO - 2023-06-05 16:32:34 --> Helper loaded: html_helper
INFO - 2023-06-05 16:32:34 --> Helper loaded: text_helper
INFO - 2023-06-05 16:32:34 --> Helper loaded: form_helper
INFO - 2023-06-05 16:32:34 --> Helper loaded: lang_helper
INFO - 2023-06-05 16:32:34 --> Helper loaded: security_helper
INFO - 2023-06-05 16:32:34 --> Helper loaded: cookie_helper
INFO - 2023-06-05 16:32:34 --> Database Driver Class Initialized
INFO - 2023-06-05 16:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 16:32:34 --> Parser Class Initialized
INFO - 2023-06-05 16:32:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 16:32:34 --> Pagination Class Initialized
INFO - 2023-06-05 16:32:34 --> Form Validation Class Initialized
INFO - 2023-06-05 16:32:34 --> Controller Class Initialized
INFO - 2023-06-05 16:32:34 --> Model Class Initialized
DEBUG - 2023-06-05 16:32:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 16:32:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 16:32:34 --> Model Class Initialized
INFO - 2023-06-05 16:32:34 --> Final output sent to browser
DEBUG - 2023-06-05 16:32:34 --> Total execution time: 0.0263
ERROR - 2023-06-05 16:32:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 16:32:45 --> Config Class Initialized
INFO - 2023-06-05 16:32:45 --> Hooks Class Initialized
DEBUG - 2023-06-05 16:32:45 --> UTF-8 Support Enabled
INFO - 2023-06-05 16:32:45 --> Utf8 Class Initialized
INFO - 2023-06-05 16:32:45 --> URI Class Initialized
INFO - 2023-06-05 16:32:45 --> Router Class Initialized
INFO - 2023-06-05 16:32:45 --> Output Class Initialized
INFO - 2023-06-05 16:32:45 --> Security Class Initialized
DEBUG - 2023-06-05 16:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 16:32:45 --> Input Class Initialized
INFO - 2023-06-05 16:32:45 --> Language Class Initialized
INFO - 2023-06-05 16:32:45 --> Loader Class Initialized
INFO - 2023-06-05 16:32:45 --> Helper loaded: url_helper
INFO - 2023-06-05 16:32:45 --> Helper loaded: file_helper
INFO - 2023-06-05 16:32:45 --> Helper loaded: html_helper
INFO - 2023-06-05 16:32:45 --> Helper loaded: text_helper
INFO - 2023-06-05 16:32:45 --> Helper loaded: form_helper
INFO - 2023-06-05 16:32:45 --> Helper loaded: lang_helper
INFO - 2023-06-05 16:32:45 --> Helper loaded: security_helper
INFO - 2023-06-05 16:32:45 --> Helper loaded: cookie_helper
INFO - 2023-06-05 16:32:45 --> Database Driver Class Initialized
INFO - 2023-06-05 16:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 16:32:45 --> Parser Class Initialized
INFO - 2023-06-05 16:32:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 16:32:45 --> Pagination Class Initialized
INFO - 2023-06-05 16:32:45 --> Form Validation Class Initialized
INFO - 2023-06-05 16:32:45 --> Controller Class Initialized
INFO - 2023-06-05 16:32:45 --> Model Class Initialized
DEBUG - 2023-06-05 16:32:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 16:32:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 16:32:45 --> Model Class Initialized
INFO - 2023-06-05 16:32:45 --> Final output sent to browser
DEBUG - 2023-06-05 16:32:45 --> Total execution time: 0.0254
ERROR - 2023-06-05 16:34:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 16:34:23 --> Config Class Initialized
INFO - 2023-06-05 16:34:23 --> Hooks Class Initialized
DEBUG - 2023-06-05 16:34:23 --> UTF-8 Support Enabled
INFO - 2023-06-05 16:34:23 --> Utf8 Class Initialized
INFO - 2023-06-05 16:34:23 --> URI Class Initialized
INFO - 2023-06-05 16:34:23 --> Router Class Initialized
INFO - 2023-06-05 16:34:23 --> Output Class Initialized
INFO - 2023-06-05 16:34:23 --> Security Class Initialized
DEBUG - 2023-06-05 16:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 16:34:23 --> Input Class Initialized
INFO - 2023-06-05 16:34:23 --> Language Class Initialized
INFO - 2023-06-05 16:34:23 --> Loader Class Initialized
INFO - 2023-06-05 16:34:23 --> Helper loaded: url_helper
INFO - 2023-06-05 16:34:23 --> Helper loaded: file_helper
INFO - 2023-06-05 16:34:23 --> Helper loaded: html_helper
INFO - 2023-06-05 16:34:23 --> Helper loaded: text_helper
INFO - 2023-06-05 16:34:23 --> Helper loaded: form_helper
INFO - 2023-06-05 16:34:23 --> Helper loaded: lang_helper
INFO - 2023-06-05 16:34:23 --> Helper loaded: security_helper
INFO - 2023-06-05 16:34:23 --> Helper loaded: cookie_helper
INFO - 2023-06-05 16:34:23 --> Database Driver Class Initialized
INFO - 2023-06-05 16:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 16:34:23 --> Parser Class Initialized
INFO - 2023-06-05 16:34:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 16:34:23 --> Pagination Class Initialized
INFO - 2023-06-05 16:34:23 --> Form Validation Class Initialized
INFO - 2023-06-05 16:34:23 --> Controller Class Initialized
INFO - 2023-06-05 16:34:23 --> Model Class Initialized
DEBUG - 2023-06-05 16:34:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 16:34:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 16:34:23 --> Model Class Initialized
DEBUG - 2023-06-05 16:34:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 16:34:23 --> Model Class Initialized
INFO - 2023-06-05 16:34:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-06-05 16:34:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 16:34:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 16:34:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 16:34:23 --> Model Class Initialized
INFO - 2023-06-05 16:34:23 --> Model Class Initialized
INFO - 2023-06-05 16:34:23 --> Model Class Initialized
INFO - 2023-06-05 16:34:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 16:34:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 16:34:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 16:34:23 --> Final output sent to browser
DEBUG - 2023-06-05 16:34:23 --> Total execution time: 0.0718
ERROR - 2023-06-05 16:34:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 16:34:24 --> Config Class Initialized
INFO - 2023-06-05 16:34:24 --> Hooks Class Initialized
DEBUG - 2023-06-05 16:34:24 --> UTF-8 Support Enabled
INFO - 2023-06-05 16:34:24 --> Utf8 Class Initialized
INFO - 2023-06-05 16:34:24 --> URI Class Initialized
INFO - 2023-06-05 16:34:24 --> Router Class Initialized
INFO - 2023-06-05 16:34:24 --> Output Class Initialized
INFO - 2023-06-05 16:34:24 --> Security Class Initialized
DEBUG - 2023-06-05 16:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 16:34:24 --> Input Class Initialized
INFO - 2023-06-05 16:34:24 --> Language Class Initialized
INFO - 2023-06-05 16:34:24 --> Loader Class Initialized
INFO - 2023-06-05 16:34:24 --> Helper loaded: url_helper
INFO - 2023-06-05 16:34:24 --> Helper loaded: file_helper
INFO - 2023-06-05 16:34:24 --> Helper loaded: html_helper
INFO - 2023-06-05 16:34:24 --> Helper loaded: text_helper
INFO - 2023-06-05 16:34:24 --> Helper loaded: form_helper
INFO - 2023-06-05 16:34:24 --> Helper loaded: lang_helper
INFO - 2023-06-05 16:34:24 --> Helper loaded: security_helper
INFO - 2023-06-05 16:34:24 --> Helper loaded: cookie_helper
INFO - 2023-06-05 16:34:24 --> Database Driver Class Initialized
INFO - 2023-06-05 16:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 16:34:24 --> Parser Class Initialized
INFO - 2023-06-05 16:34:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 16:34:24 --> Pagination Class Initialized
INFO - 2023-06-05 16:34:24 --> Form Validation Class Initialized
INFO - 2023-06-05 16:34:24 --> Controller Class Initialized
INFO - 2023-06-05 16:34:24 --> Model Class Initialized
DEBUG - 2023-06-05 16:34:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 16:34:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 16:34:24 --> Model Class Initialized
DEBUG - 2023-06-05 16:34:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 16:34:24 --> Model Class Initialized
INFO - 2023-06-05 16:34:24 --> Final output sent to browser
DEBUG - 2023-06-05 16:34:24 --> Total execution time: 0.0204
ERROR - 2023-06-05 16:34:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 16:34:28 --> Config Class Initialized
INFO - 2023-06-05 16:34:28 --> Hooks Class Initialized
DEBUG - 2023-06-05 16:34:28 --> UTF-8 Support Enabled
INFO - 2023-06-05 16:34:28 --> Utf8 Class Initialized
INFO - 2023-06-05 16:34:28 --> URI Class Initialized
DEBUG - 2023-06-05 16:34:28 --> No URI present. Default controller set.
INFO - 2023-06-05 16:34:28 --> Router Class Initialized
INFO - 2023-06-05 16:34:28 --> Output Class Initialized
INFO - 2023-06-05 16:34:28 --> Security Class Initialized
DEBUG - 2023-06-05 16:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 16:34:28 --> Input Class Initialized
INFO - 2023-06-05 16:34:28 --> Language Class Initialized
INFO - 2023-06-05 16:34:28 --> Loader Class Initialized
INFO - 2023-06-05 16:34:28 --> Helper loaded: url_helper
INFO - 2023-06-05 16:34:28 --> Helper loaded: file_helper
INFO - 2023-06-05 16:34:28 --> Helper loaded: html_helper
INFO - 2023-06-05 16:34:28 --> Helper loaded: text_helper
INFO - 2023-06-05 16:34:28 --> Helper loaded: form_helper
INFO - 2023-06-05 16:34:28 --> Helper loaded: lang_helper
INFO - 2023-06-05 16:34:28 --> Helper loaded: security_helper
INFO - 2023-06-05 16:34:28 --> Helper loaded: cookie_helper
INFO - 2023-06-05 16:34:28 --> Database Driver Class Initialized
INFO - 2023-06-05 16:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 16:34:28 --> Parser Class Initialized
INFO - 2023-06-05 16:34:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 16:34:28 --> Pagination Class Initialized
INFO - 2023-06-05 16:34:28 --> Form Validation Class Initialized
INFO - 2023-06-05 16:34:28 --> Controller Class Initialized
INFO - 2023-06-05 16:34:28 --> Model Class Initialized
DEBUG - 2023-06-05 16:34:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 16:34:28 --> Model Class Initialized
DEBUG - 2023-06-05 16:34:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 16:34:28 --> Model Class Initialized
INFO - 2023-06-05 16:34:28 --> Model Class Initialized
INFO - 2023-06-05 16:34:28 --> Model Class Initialized
INFO - 2023-06-05 16:34:28 --> Model Class Initialized
DEBUG - 2023-06-05 16:34:28 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-06-05 16:34:28 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 16:34:28 --> Model Class Initialized
INFO - 2023-06-05 16:34:28 --> Model Class Initialized
INFO - 2023-06-05 16:34:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-06-05 16:34:28 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 16:34:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 16:34:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 16:34:28 --> Model Class Initialized
INFO - 2023-06-05 16:34:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-06-05 16:34:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-06-05 16:34:28 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 16:34:28 --> Final output sent to browser
DEBUG - 2023-06-05 16:34:28 --> Total execution time: 0.0815
ERROR - 2023-06-05 20:56:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 20:56:18 --> Config Class Initialized
INFO - 2023-06-05 20:56:18 --> Hooks Class Initialized
DEBUG - 2023-06-05 20:56:18 --> UTF-8 Support Enabled
INFO - 2023-06-05 20:56:18 --> Utf8 Class Initialized
INFO - 2023-06-05 20:56:18 --> URI Class Initialized
DEBUG - 2023-06-05 20:56:18 --> No URI present. Default controller set.
INFO - 2023-06-05 20:56:18 --> Router Class Initialized
INFO - 2023-06-05 20:56:18 --> Output Class Initialized
INFO - 2023-06-05 20:56:18 --> Security Class Initialized
DEBUG - 2023-06-05 20:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 20:56:18 --> Input Class Initialized
INFO - 2023-06-05 20:56:18 --> Language Class Initialized
INFO - 2023-06-05 20:56:18 --> Loader Class Initialized
INFO - 2023-06-05 20:56:18 --> Helper loaded: url_helper
INFO - 2023-06-05 20:56:18 --> Helper loaded: file_helper
INFO - 2023-06-05 20:56:18 --> Helper loaded: html_helper
INFO - 2023-06-05 20:56:18 --> Helper loaded: text_helper
INFO - 2023-06-05 20:56:18 --> Helper loaded: form_helper
INFO - 2023-06-05 20:56:18 --> Helper loaded: lang_helper
INFO - 2023-06-05 20:56:18 --> Helper loaded: security_helper
INFO - 2023-06-05 20:56:18 --> Helper loaded: cookie_helper
INFO - 2023-06-05 20:56:18 --> Database Driver Class Initialized
INFO - 2023-06-05 20:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 20:56:18 --> Parser Class Initialized
INFO - 2023-06-05 20:56:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 20:56:18 --> Pagination Class Initialized
INFO - 2023-06-05 20:56:18 --> Form Validation Class Initialized
INFO - 2023-06-05 20:56:18 --> Controller Class Initialized
INFO - 2023-06-05 20:56:18 --> Model Class Initialized
DEBUG - 2023-06-05 20:56:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-05 23:54:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 23:54:21 --> Config Class Initialized
INFO - 2023-06-05 23:54:21 --> Hooks Class Initialized
DEBUG - 2023-06-05 23:54:21 --> UTF-8 Support Enabled
INFO - 2023-06-05 23:54:21 --> Utf8 Class Initialized
INFO - 2023-06-05 23:54:21 --> URI Class Initialized
DEBUG - 2023-06-05 23:54:21 --> No URI present. Default controller set.
INFO - 2023-06-05 23:54:21 --> Router Class Initialized
INFO - 2023-06-05 23:54:21 --> Output Class Initialized
INFO - 2023-06-05 23:54:21 --> Security Class Initialized
DEBUG - 2023-06-05 23:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 23:54:21 --> Input Class Initialized
INFO - 2023-06-05 23:54:21 --> Language Class Initialized
INFO - 2023-06-05 23:54:21 --> Loader Class Initialized
INFO - 2023-06-05 23:54:21 --> Helper loaded: url_helper
INFO - 2023-06-05 23:54:21 --> Helper loaded: file_helper
INFO - 2023-06-05 23:54:21 --> Helper loaded: html_helper
INFO - 2023-06-05 23:54:21 --> Helper loaded: text_helper
INFO - 2023-06-05 23:54:21 --> Helper loaded: form_helper
INFO - 2023-06-05 23:54:21 --> Helper loaded: lang_helper
INFO - 2023-06-05 23:54:21 --> Helper loaded: security_helper
INFO - 2023-06-05 23:54:21 --> Helper loaded: cookie_helper
INFO - 2023-06-05 23:54:21 --> Database Driver Class Initialized
INFO - 2023-06-05 23:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 23:54:21 --> Parser Class Initialized
INFO - 2023-06-05 23:54:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 23:54:21 --> Pagination Class Initialized
INFO - 2023-06-05 23:54:21 --> Form Validation Class Initialized
INFO - 2023-06-05 23:54:21 --> Controller Class Initialized
INFO - 2023-06-05 23:54:21 --> Model Class Initialized
DEBUG - 2023-06-05 23:54:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-06-05 23:54:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-06-05 23:54:22 --> Config Class Initialized
INFO - 2023-06-05 23:54:22 --> Hooks Class Initialized
DEBUG - 2023-06-05 23:54:22 --> UTF-8 Support Enabled
INFO - 2023-06-05 23:54:22 --> Utf8 Class Initialized
INFO - 2023-06-05 23:54:22 --> URI Class Initialized
INFO - 2023-06-05 23:54:22 --> Router Class Initialized
INFO - 2023-06-05 23:54:22 --> Output Class Initialized
INFO - 2023-06-05 23:54:22 --> Security Class Initialized
DEBUG - 2023-06-05 23:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 23:54:22 --> Input Class Initialized
INFO - 2023-06-05 23:54:22 --> Language Class Initialized
INFO - 2023-06-05 23:54:22 --> Loader Class Initialized
INFO - 2023-06-05 23:54:22 --> Helper loaded: url_helper
INFO - 2023-06-05 23:54:22 --> Helper loaded: file_helper
INFO - 2023-06-05 23:54:22 --> Helper loaded: html_helper
INFO - 2023-06-05 23:54:22 --> Helper loaded: text_helper
INFO - 2023-06-05 23:54:22 --> Helper loaded: form_helper
INFO - 2023-06-05 23:54:22 --> Helper loaded: lang_helper
INFO - 2023-06-05 23:54:22 --> Helper loaded: security_helper
INFO - 2023-06-05 23:54:22 --> Helper loaded: cookie_helper
INFO - 2023-06-05 23:54:22 --> Database Driver Class Initialized
INFO - 2023-06-05 23:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-05 23:54:22 --> Parser Class Initialized
INFO - 2023-06-05 23:54:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-06-05 23:54:22 --> Pagination Class Initialized
INFO - 2023-06-05 23:54:22 --> Form Validation Class Initialized
INFO - 2023-06-05 23:54:22 --> Controller Class Initialized
INFO - 2023-06-05 23:54:22 --> Model Class Initialized
DEBUG - 2023-06-05 23:54:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-06-05 23:54:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-06-05 23:54:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-06-05 23:54:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-06-05 23:54:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-06-05 23:54:22 --> Model Class Initialized
INFO - 2023-06-05 23:54:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-06-05 23:54:22 --> Final output sent to browser
DEBUG - 2023-06-05 23:54:22 --> Total execution time: 0.0347
