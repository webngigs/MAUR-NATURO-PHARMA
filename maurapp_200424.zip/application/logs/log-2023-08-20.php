<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-20 02:37:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 02:37:53 --> Config Class Initialized
INFO - 2023-08-20 02:37:53 --> Hooks Class Initialized
DEBUG - 2023-08-20 02:37:53 --> UTF-8 Support Enabled
INFO - 2023-08-20 02:37:53 --> Utf8 Class Initialized
INFO - 2023-08-20 02:37:53 --> URI Class Initialized
DEBUG - 2023-08-20 02:37:53 --> No URI present. Default controller set.
INFO - 2023-08-20 02:37:53 --> Router Class Initialized
INFO - 2023-08-20 02:37:53 --> Output Class Initialized
INFO - 2023-08-20 02:37:53 --> Security Class Initialized
DEBUG - 2023-08-20 02:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 02:37:53 --> Input Class Initialized
INFO - 2023-08-20 02:37:53 --> Language Class Initialized
INFO - 2023-08-20 02:37:53 --> Loader Class Initialized
INFO - 2023-08-20 02:37:53 --> Helper loaded: url_helper
INFO - 2023-08-20 02:37:53 --> Helper loaded: file_helper
INFO - 2023-08-20 02:37:53 --> Helper loaded: html_helper
INFO - 2023-08-20 02:37:53 --> Helper loaded: text_helper
INFO - 2023-08-20 02:37:53 --> Helper loaded: form_helper
INFO - 2023-08-20 02:37:53 --> Helper loaded: lang_helper
INFO - 2023-08-20 02:37:53 --> Helper loaded: security_helper
INFO - 2023-08-20 02:37:53 --> Helper loaded: cookie_helper
INFO - 2023-08-20 02:37:53 --> Database Driver Class Initialized
INFO - 2023-08-20 02:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 02:37:53 --> Parser Class Initialized
INFO - 2023-08-20 02:37:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 02:37:53 --> Pagination Class Initialized
INFO - 2023-08-20 02:37:53 --> Form Validation Class Initialized
INFO - 2023-08-20 02:37:53 --> Controller Class Initialized
INFO - 2023-08-20 02:37:53 --> Model Class Initialized
DEBUG - 2023-08-20 02:37:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-20 02:37:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 02:37:54 --> Config Class Initialized
INFO - 2023-08-20 02:37:54 --> Hooks Class Initialized
DEBUG - 2023-08-20 02:37:54 --> UTF-8 Support Enabled
INFO - 2023-08-20 02:37:54 --> Utf8 Class Initialized
INFO - 2023-08-20 02:37:54 --> URI Class Initialized
INFO - 2023-08-20 02:37:54 --> Router Class Initialized
INFO - 2023-08-20 02:37:54 --> Output Class Initialized
INFO - 2023-08-20 02:37:54 --> Security Class Initialized
DEBUG - 2023-08-20 02:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 02:37:54 --> Input Class Initialized
INFO - 2023-08-20 02:37:54 --> Language Class Initialized
INFO - 2023-08-20 02:37:54 --> Loader Class Initialized
INFO - 2023-08-20 02:37:54 --> Helper loaded: url_helper
INFO - 2023-08-20 02:37:54 --> Helper loaded: file_helper
INFO - 2023-08-20 02:37:54 --> Helper loaded: html_helper
INFO - 2023-08-20 02:37:54 --> Helper loaded: text_helper
INFO - 2023-08-20 02:37:54 --> Helper loaded: form_helper
INFO - 2023-08-20 02:37:54 --> Helper loaded: lang_helper
INFO - 2023-08-20 02:37:54 --> Helper loaded: security_helper
INFO - 2023-08-20 02:37:54 --> Helper loaded: cookie_helper
INFO - 2023-08-20 02:37:54 --> Database Driver Class Initialized
INFO - 2023-08-20 02:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 02:37:54 --> Parser Class Initialized
INFO - 2023-08-20 02:37:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 02:37:54 --> Pagination Class Initialized
INFO - 2023-08-20 02:37:54 --> Form Validation Class Initialized
INFO - 2023-08-20 02:37:54 --> Controller Class Initialized
INFO - 2023-08-20 02:37:54 --> Model Class Initialized
DEBUG - 2023-08-20 02:37:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 02:37:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-20 02:37:54 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-20 02:37:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-20 02:37:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-20 02:37:54 --> Model Class Initialized
INFO - 2023-08-20 02:37:54 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-20 02:37:54 --> Final output sent to browser
DEBUG - 2023-08-20 02:37:54 --> Total execution time: 0.0318
ERROR - 2023-08-20 07:57:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 07:57:01 --> Config Class Initialized
INFO - 2023-08-20 07:57:01 --> Hooks Class Initialized
DEBUG - 2023-08-20 07:57:01 --> UTF-8 Support Enabled
INFO - 2023-08-20 07:57:01 --> Utf8 Class Initialized
INFO - 2023-08-20 07:57:01 --> URI Class Initialized
DEBUG - 2023-08-20 07:57:01 --> No URI present. Default controller set.
INFO - 2023-08-20 07:57:01 --> Router Class Initialized
INFO - 2023-08-20 07:57:01 --> Output Class Initialized
INFO - 2023-08-20 07:57:01 --> Security Class Initialized
DEBUG - 2023-08-20 07:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 07:57:01 --> Input Class Initialized
INFO - 2023-08-20 07:57:01 --> Language Class Initialized
INFO - 2023-08-20 07:57:01 --> Loader Class Initialized
INFO - 2023-08-20 07:57:01 --> Helper loaded: url_helper
INFO - 2023-08-20 07:57:01 --> Helper loaded: file_helper
INFO - 2023-08-20 07:57:01 --> Helper loaded: html_helper
INFO - 2023-08-20 07:57:01 --> Helper loaded: text_helper
INFO - 2023-08-20 07:57:01 --> Helper loaded: form_helper
INFO - 2023-08-20 07:57:01 --> Helper loaded: lang_helper
INFO - 2023-08-20 07:57:01 --> Helper loaded: security_helper
INFO - 2023-08-20 07:57:01 --> Helper loaded: cookie_helper
INFO - 2023-08-20 07:57:01 --> Database Driver Class Initialized
INFO - 2023-08-20 07:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 07:57:01 --> Parser Class Initialized
INFO - 2023-08-20 07:57:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 07:57:01 --> Pagination Class Initialized
INFO - 2023-08-20 07:57:01 --> Form Validation Class Initialized
INFO - 2023-08-20 07:57:01 --> Controller Class Initialized
INFO - 2023-08-20 07:57:01 --> Model Class Initialized
DEBUG - 2023-08-20 07:57:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-20 07:57:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 07:57:02 --> Config Class Initialized
INFO - 2023-08-20 07:57:02 --> Hooks Class Initialized
DEBUG - 2023-08-20 07:57:02 --> UTF-8 Support Enabled
INFO - 2023-08-20 07:57:02 --> Utf8 Class Initialized
INFO - 2023-08-20 07:57:02 --> URI Class Initialized
INFO - 2023-08-20 07:57:02 --> Router Class Initialized
INFO - 2023-08-20 07:57:02 --> Output Class Initialized
INFO - 2023-08-20 07:57:02 --> Security Class Initialized
DEBUG - 2023-08-20 07:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 07:57:02 --> Input Class Initialized
INFO - 2023-08-20 07:57:02 --> Language Class Initialized
INFO - 2023-08-20 07:57:02 --> Loader Class Initialized
INFO - 2023-08-20 07:57:02 --> Helper loaded: url_helper
INFO - 2023-08-20 07:57:02 --> Helper loaded: file_helper
INFO - 2023-08-20 07:57:02 --> Helper loaded: html_helper
INFO - 2023-08-20 07:57:02 --> Helper loaded: text_helper
INFO - 2023-08-20 07:57:02 --> Helper loaded: form_helper
INFO - 2023-08-20 07:57:02 --> Helper loaded: lang_helper
INFO - 2023-08-20 07:57:02 --> Helper loaded: security_helper
INFO - 2023-08-20 07:57:02 --> Helper loaded: cookie_helper
INFO - 2023-08-20 07:57:02 --> Database Driver Class Initialized
INFO - 2023-08-20 07:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 07:57:02 --> Parser Class Initialized
INFO - 2023-08-20 07:57:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 07:57:02 --> Pagination Class Initialized
INFO - 2023-08-20 07:57:02 --> Form Validation Class Initialized
INFO - 2023-08-20 07:57:02 --> Controller Class Initialized
INFO - 2023-08-20 07:57:02 --> Model Class Initialized
DEBUG - 2023-08-20 07:57:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 07:57:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-20 07:57:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-20 07:57:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-20 07:57:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-20 07:57:02 --> Model Class Initialized
INFO - 2023-08-20 07:57:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-20 07:57:02 --> Final output sent to browser
DEBUG - 2023-08-20 07:57:02 --> Total execution time: 0.0352
ERROR - 2023-08-20 07:57:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 07:57:06 --> Config Class Initialized
INFO - 2023-08-20 07:57:06 --> Hooks Class Initialized
DEBUG - 2023-08-20 07:57:06 --> UTF-8 Support Enabled
INFO - 2023-08-20 07:57:06 --> Utf8 Class Initialized
INFO - 2023-08-20 07:57:06 --> URI Class Initialized
INFO - 2023-08-20 07:57:06 --> Router Class Initialized
INFO - 2023-08-20 07:57:06 --> Output Class Initialized
INFO - 2023-08-20 07:57:06 --> Security Class Initialized
DEBUG - 2023-08-20 07:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 07:57:06 --> Input Class Initialized
INFO - 2023-08-20 07:57:06 --> Language Class Initialized
INFO - 2023-08-20 07:57:06 --> Loader Class Initialized
INFO - 2023-08-20 07:57:06 --> Helper loaded: url_helper
INFO - 2023-08-20 07:57:06 --> Helper loaded: file_helper
INFO - 2023-08-20 07:57:06 --> Helper loaded: html_helper
INFO - 2023-08-20 07:57:06 --> Helper loaded: text_helper
INFO - 2023-08-20 07:57:06 --> Helper loaded: form_helper
INFO - 2023-08-20 07:57:06 --> Helper loaded: lang_helper
INFO - 2023-08-20 07:57:06 --> Helper loaded: security_helper
INFO - 2023-08-20 07:57:06 --> Helper loaded: cookie_helper
INFO - 2023-08-20 07:57:06 --> Database Driver Class Initialized
INFO - 2023-08-20 07:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 07:57:06 --> Parser Class Initialized
INFO - 2023-08-20 07:57:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 07:57:06 --> Pagination Class Initialized
INFO - 2023-08-20 07:57:06 --> Form Validation Class Initialized
INFO - 2023-08-20 07:57:06 --> Controller Class Initialized
INFO - 2023-08-20 07:57:06 --> Model Class Initialized
DEBUG - 2023-08-20 07:57:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 07:57:06 --> Model Class Initialized
INFO - 2023-08-20 07:57:06 --> Final output sent to browser
DEBUG - 2023-08-20 07:57:06 --> Total execution time: 0.0208
ERROR - 2023-08-20 07:57:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 07:57:06 --> Config Class Initialized
INFO - 2023-08-20 07:57:06 --> Hooks Class Initialized
DEBUG - 2023-08-20 07:57:06 --> UTF-8 Support Enabled
INFO - 2023-08-20 07:57:06 --> Utf8 Class Initialized
INFO - 2023-08-20 07:57:06 --> URI Class Initialized
DEBUG - 2023-08-20 07:57:06 --> No URI present. Default controller set.
INFO - 2023-08-20 07:57:06 --> Router Class Initialized
INFO - 2023-08-20 07:57:06 --> Output Class Initialized
INFO - 2023-08-20 07:57:06 --> Security Class Initialized
DEBUG - 2023-08-20 07:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 07:57:06 --> Input Class Initialized
INFO - 2023-08-20 07:57:06 --> Language Class Initialized
INFO - 2023-08-20 07:57:06 --> Loader Class Initialized
INFO - 2023-08-20 07:57:06 --> Helper loaded: url_helper
INFO - 2023-08-20 07:57:06 --> Helper loaded: file_helper
INFO - 2023-08-20 07:57:06 --> Helper loaded: html_helper
INFO - 2023-08-20 07:57:06 --> Helper loaded: text_helper
INFO - 2023-08-20 07:57:06 --> Helper loaded: form_helper
INFO - 2023-08-20 07:57:06 --> Helper loaded: lang_helper
INFO - 2023-08-20 07:57:06 --> Helper loaded: security_helper
INFO - 2023-08-20 07:57:06 --> Helper loaded: cookie_helper
INFO - 2023-08-20 07:57:06 --> Database Driver Class Initialized
INFO - 2023-08-20 07:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 07:57:06 --> Parser Class Initialized
INFO - 2023-08-20 07:57:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 07:57:06 --> Pagination Class Initialized
INFO - 2023-08-20 07:57:06 --> Form Validation Class Initialized
INFO - 2023-08-20 07:57:06 --> Controller Class Initialized
INFO - 2023-08-20 07:57:06 --> Model Class Initialized
DEBUG - 2023-08-20 07:57:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 07:57:06 --> Model Class Initialized
DEBUG - 2023-08-20 07:57:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 07:57:06 --> Model Class Initialized
INFO - 2023-08-20 07:57:06 --> Model Class Initialized
INFO - 2023-08-20 07:57:06 --> Model Class Initialized
INFO - 2023-08-20 07:57:06 --> Model Class Initialized
DEBUG - 2023-08-20 07:57:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-20 07:57:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 07:57:06 --> Model Class Initialized
INFO - 2023-08-20 07:57:06 --> Model Class Initialized
INFO - 2023-08-20 07:57:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-20 07:57:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-20 07:57:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-20 07:57:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-20 07:57:06 --> Model Class Initialized
INFO - 2023-08-20 07:57:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-20 07:57:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-20 07:57:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-20 07:57:06 --> Final output sent to browser
DEBUG - 2023-08-20 07:57:06 --> Total execution time: 0.1985
ERROR - 2023-08-20 07:57:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 07:57:07 --> Config Class Initialized
INFO - 2023-08-20 07:57:07 --> Hooks Class Initialized
DEBUG - 2023-08-20 07:57:07 --> UTF-8 Support Enabled
INFO - 2023-08-20 07:57:07 --> Utf8 Class Initialized
INFO - 2023-08-20 07:57:07 --> URI Class Initialized
INFO - 2023-08-20 07:57:07 --> Router Class Initialized
INFO - 2023-08-20 07:57:07 --> Output Class Initialized
INFO - 2023-08-20 07:57:07 --> Security Class Initialized
DEBUG - 2023-08-20 07:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 07:57:07 --> Input Class Initialized
INFO - 2023-08-20 07:57:07 --> Language Class Initialized
INFO - 2023-08-20 07:57:07 --> Loader Class Initialized
INFO - 2023-08-20 07:57:07 --> Helper loaded: url_helper
INFO - 2023-08-20 07:57:07 --> Helper loaded: file_helper
INFO - 2023-08-20 07:57:07 --> Helper loaded: html_helper
INFO - 2023-08-20 07:57:07 --> Helper loaded: text_helper
INFO - 2023-08-20 07:57:07 --> Helper loaded: form_helper
INFO - 2023-08-20 07:57:07 --> Helper loaded: lang_helper
INFO - 2023-08-20 07:57:07 --> Helper loaded: security_helper
INFO - 2023-08-20 07:57:07 --> Helper loaded: cookie_helper
INFO - 2023-08-20 07:57:07 --> Database Driver Class Initialized
INFO - 2023-08-20 07:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 07:57:07 --> Parser Class Initialized
INFO - 2023-08-20 07:57:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 07:57:07 --> Pagination Class Initialized
INFO - 2023-08-20 07:57:07 --> Form Validation Class Initialized
INFO - 2023-08-20 07:57:07 --> Controller Class Initialized
DEBUG - 2023-08-20 07:57:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-20 07:57:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 07:57:07 --> Model Class Initialized
INFO - 2023-08-20 07:57:07 --> Final output sent to browser
DEBUG - 2023-08-20 07:57:07 --> Total execution time: 0.0127
ERROR - 2023-08-20 07:57:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 07:57:12 --> Config Class Initialized
INFO - 2023-08-20 07:57:12 --> Hooks Class Initialized
DEBUG - 2023-08-20 07:57:12 --> UTF-8 Support Enabled
INFO - 2023-08-20 07:57:12 --> Utf8 Class Initialized
INFO - 2023-08-20 07:57:12 --> URI Class Initialized
DEBUG - 2023-08-20 07:57:12 --> No URI present. Default controller set.
INFO - 2023-08-20 07:57:12 --> Router Class Initialized
INFO - 2023-08-20 07:57:12 --> Output Class Initialized
INFO - 2023-08-20 07:57:12 --> Security Class Initialized
DEBUG - 2023-08-20 07:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 07:57:12 --> Input Class Initialized
INFO - 2023-08-20 07:57:12 --> Language Class Initialized
INFO - 2023-08-20 07:57:12 --> Loader Class Initialized
INFO - 2023-08-20 07:57:12 --> Helper loaded: url_helper
INFO - 2023-08-20 07:57:12 --> Helper loaded: file_helper
INFO - 2023-08-20 07:57:12 --> Helper loaded: html_helper
INFO - 2023-08-20 07:57:12 --> Helper loaded: text_helper
INFO - 2023-08-20 07:57:12 --> Helper loaded: form_helper
INFO - 2023-08-20 07:57:12 --> Helper loaded: lang_helper
INFO - 2023-08-20 07:57:12 --> Helper loaded: security_helper
INFO - 2023-08-20 07:57:12 --> Helper loaded: cookie_helper
INFO - 2023-08-20 07:57:12 --> Database Driver Class Initialized
INFO - 2023-08-20 07:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 07:57:12 --> Parser Class Initialized
INFO - 2023-08-20 07:57:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 07:57:12 --> Pagination Class Initialized
INFO - 2023-08-20 07:57:12 --> Form Validation Class Initialized
INFO - 2023-08-20 07:57:12 --> Controller Class Initialized
INFO - 2023-08-20 07:57:12 --> Model Class Initialized
DEBUG - 2023-08-20 07:57:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 07:57:12 --> Model Class Initialized
DEBUG - 2023-08-20 07:57:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 07:57:12 --> Model Class Initialized
INFO - 2023-08-20 07:57:12 --> Model Class Initialized
INFO - 2023-08-20 07:57:12 --> Model Class Initialized
INFO - 2023-08-20 07:57:12 --> Model Class Initialized
DEBUG - 2023-08-20 07:57:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-20 07:57:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 07:57:12 --> Model Class Initialized
INFO - 2023-08-20 07:57:12 --> Model Class Initialized
INFO - 2023-08-20 07:57:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-20 07:57:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-20 07:57:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-20 07:57:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-20 07:57:12 --> Model Class Initialized
INFO - 2023-08-20 07:57:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-20 07:57:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-20 07:57:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-20 07:57:12 --> Final output sent to browser
DEBUG - 2023-08-20 07:57:12 --> Total execution time: 0.2125
ERROR - 2023-08-20 07:57:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 07:57:30 --> Config Class Initialized
INFO - 2023-08-20 07:57:30 --> Hooks Class Initialized
DEBUG - 2023-08-20 07:57:30 --> UTF-8 Support Enabled
INFO - 2023-08-20 07:57:30 --> Utf8 Class Initialized
INFO - 2023-08-20 07:57:30 --> URI Class Initialized
INFO - 2023-08-20 07:57:30 --> Router Class Initialized
INFO - 2023-08-20 07:57:30 --> Output Class Initialized
INFO - 2023-08-20 07:57:30 --> Security Class Initialized
DEBUG - 2023-08-20 07:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 07:57:30 --> Input Class Initialized
INFO - 2023-08-20 07:57:30 --> Language Class Initialized
INFO - 2023-08-20 07:57:30 --> Loader Class Initialized
INFO - 2023-08-20 07:57:30 --> Helper loaded: url_helper
INFO - 2023-08-20 07:57:30 --> Helper loaded: file_helper
INFO - 2023-08-20 07:57:30 --> Helper loaded: html_helper
INFO - 2023-08-20 07:57:30 --> Helper loaded: text_helper
INFO - 2023-08-20 07:57:30 --> Helper loaded: form_helper
INFO - 2023-08-20 07:57:30 --> Helper loaded: lang_helper
INFO - 2023-08-20 07:57:30 --> Helper loaded: security_helper
INFO - 2023-08-20 07:57:30 --> Helper loaded: cookie_helper
INFO - 2023-08-20 07:57:30 --> Database Driver Class Initialized
INFO - 2023-08-20 07:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 07:57:30 --> Parser Class Initialized
INFO - 2023-08-20 07:57:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 07:57:30 --> Pagination Class Initialized
INFO - 2023-08-20 07:57:30 --> Form Validation Class Initialized
INFO - 2023-08-20 07:57:30 --> Controller Class Initialized
ERROR - 2023-08-20 07:57:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 07:57:31 --> Config Class Initialized
INFO - 2023-08-20 07:57:31 --> Hooks Class Initialized
DEBUG - 2023-08-20 07:57:31 --> UTF-8 Support Enabled
INFO - 2023-08-20 07:57:31 --> Utf8 Class Initialized
INFO - 2023-08-20 07:57:31 --> URI Class Initialized
INFO - 2023-08-20 07:57:31 --> Router Class Initialized
INFO - 2023-08-20 07:57:31 --> Output Class Initialized
INFO - 2023-08-20 07:57:31 --> Security Class Initialized
DEBUG - 2023-08-20 07:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 07:57:31 --> Input Class Initialized
INFO - 2023-08-20 07:57:31 --> Language Class Initialized
INFO - 2023-08-20 07:57:31 --> Loader Class Initialized
INFO - 2023-08-20 07:57:31 --> Helper loaded: url_helper
INFO - 2023-08-20 07:57:31 --> Helper loaded: file_helper
INFO - 2023-08-20 07:57:31 --> Helper loaded: html_helper
INFO - 2023-08-20 07:57:31 --> Helper loaded: text_helper
INFO - 2023-08-20 07:57:31 --> Helper loaded: form_helper
INFO - 2023-08-20 07:57:31 --> Helper loaded: lang_helper
INFO - 2023-08-20 07:57:31 --> Helper loaded: security_helper
INFO - 2023-08-20 07:57:31 --> Helper loaded: cookie_helper
INFO - 2023-08-20 07:57:31 --> Database Driver Class Initialized
INFO - 2023-08-20 07:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 07:57:31 --> Parser Class Initialized
INFO - 2023-08-20 07:57:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 07:57:31 --> Pagination Class Initialized
INFO - 2023-08-20 07:57:31 --> Form Validation Class Initialized
INFO - 2023-08-20 07:57:31 --> Controller Class Initialized
INFO - 2023-08-20 07:57:31 --> Model Class Initialized
DEBUG - 2023-08-20 07:57:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 07:57:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-20 07:57:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-20 07:57:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-20 07:57:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-20 07:57:31 --> Model Class Initialized
INFO - 2023-08-20 07:57:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-20 07:57:31 --> Final output sent to browser
DEBUG - 2023-08-20 07:57:31 --> Total execution time: 0.0319
ERROR - 2023-08-20 07:57:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 07:57:36 --> Config Class Initialized
INFO - 2023-08-20 07:57:36 --> Hooks Class Initialized
DEBUG - 2023-08-20 07:57:36 --> UTF-8 Support Enabled
INFO - 2023-08-20 07:57:36 --> Utf8 Class Initialized
INFO - 2023-08-20 07:57:36 --> URI Class Initialized
INFO - 2023-08-20 07:57:36 --> Router Class Initialized
INFO - 2023-08-20 07:57:36 --> Output Class Initialized
INFO - 2023-08-20 07:57:36 --> Security Class Initialized
DEBUG - 2023-08-20 07:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 07:57:36 --> Input Class Initialized
INFO - 2023-08-20 07:57:36 --> Language Class Initialized
INFO - 2023-08-20 07:57:36 --> Loader Class Initialized
INFO - 2023-08-20 07:57:36 --> Helper loaded: url_helper
INFO - 2023-08-20 07:57:36 --> Helper loaded: file_helper
INFO - 2023-08-20 07:57:36 --> Helper loaded: html_helper
INFO - 2023-08-20 07:57:36 --> Helper loaded: text_helper
INFO - 2023-08-20 07:57:36 --> Helper loaded: form_helper
INFO - 2023-08-20 07:57:36 --> Helper loaded: lang_helper
INFO - 2023-08-20 07:57:36 --> Helper loaded: security_helper
INFO - 2023-08-20 07:57:36 --> Helper loaded: cookie_helper
INFO - 2023-08-20 07:57:36 --> Database Driver Class Initialized
INFO - 2023-08-20 07:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 07:57:36 --> Parser Class Initialized
INFO - 2023-08-20 07:57:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 07:57:36 --> Pagination Class Initialized
INFO - 2023-08-20 07:57:36 --> Form Validation Class Initialized
INFO - 2023-08-20 07:57:36 --> Controller Class Initialized
INFO - 2023-08-20 07:57:36 --> Model Class Initialized
DEBUG - 2023-08-20 07:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 07:57:36 --> Model Class Initialized
INFO - 2023-08-20 07:57:36 --> Final output sent to browser
DEBUG - 2023-08-20 07:57:36 --> Total execution time: 0.0188
ERROR - 2023-08-20 07:57:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 07:57:36 --> Config Class Initialized
INFO - 2023-08-20 07:57:36 --> Hooks Class Initialized
DEBUG - 2023-08-20 07:57:36 --> UTF-8 Support Enabled
INFO - 2023-08-20 07:57:36 --> Utf8 Class Initialized
INFO - 2023-08-20 07:57:36 --> URI Class Initialized
DEBUG - 2023-08-20 07:57:36 --> No URI present. Default controller set.
INFO - 2023-08-20 07:57:36 --> Router Class Initialized
INFO - 2023-08-20 07:57:36 --> Output Class Initialized
INFO - 2023-08-20 07:57:36 --> Security Class Initialized
DEBUG - 2023-08-20 07:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 07:57:36 --> Input Class Initialized
INFO - 2023-08-20 07:57:36 --> Language Class Initialized
INFO - 2023-08-20 07:57:36 --> Loader Class Initialized
INFO - 2023-08-20 07:57:36 --> Helper loaded: url_helper
INFO - 2023-08-20 07:57:36 --> Helper loaded: file_helper
INFO - 2023-08-20 07:57:36 --> Helper loaded: html_helper
INFO - 2023-08-20 07:57:36 --> Helper loaded: text_helper
INFO - 2023-08-20 07:57:36 --> Helper loaded: form_helper
INFO - 2023-08-20 07:57:36 --> Helper loaded: lang_helper
INFO - 2023-08-20 07:57:36 --> Helper loaded: security_helper
INFO - 2023-08-20 07:57:36 --> Helper loaded: cookie_helper
INFO - 2023-08-20 07:57:36 --> Database Driver Class Initialized
INFO - 2023-08-20 07:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 07:57:36 --> Parser Class Initialized
INFO - 2023-08-20 07:57:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 07:57:36 --> Pagination Class Initialized
INFO - 2023-08-20 07:57:36 --> Form Validation Class Initialized
INFO - 2023-08-20 07:57:36 --> Controller Class Initialized
INFO - 2023-08-20 07:57:36 --> Model Class Initialized
DEBUG - 2023-08-20 07:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 07:57:36 --> Model Class Initialized
DEBUG - 2023-08-20 07:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 07:57:36 --> Model Class Initialized
INFO - 2023-08-20 07:57:36 --> Model Class Initialized
INFO - 2023-08-20 07:57:36 --> Model Class Initialized
INFO - 2023-08-20 07:57:36 --> Model Class Initialized
DEBUG - 2023-08-20 07:57:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-20 07:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 07:57:36 --> Model Class Initialized
INFO - 2023-08-20 07:57:36 --> Model Class Initialized
INFO - 2023-08-20 07:57:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-20 07:57:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-20 07:57:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-20 07:57:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-20 07:57:36 --> Model Class Initialized
INFO - 2023-08-20 07:57:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-20 07:57:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-20 07:57:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-20 07:57:36 --> Final output sent to browser
DEBUG - 2023-08-20 07:57:36 --> Total execution time: 0.0967
ERROR - 2023-08-20 07:57:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 07:57:51 --> Config Class Initialized
INFO - 2023-08-20 07:57:51 --> Hooks Class Initialized
DEBUG - 2023-08-20 07:57:51 --> UTF-8 Support Enabled
INFO - 2023-08-20 07:57:51 --> Utf8 Class Initialized
INFO - 2023-08-20 07:57:51 --> URI Class Initialized
DEBUG - 2023-08-20 07:57:51 --> No URI present. Default controller set.
INFO - 2023-08-20 07:57:51 --> Router Class Initialized
INFO - 2023-08-20 07:57:51 --> Output Class Initialized
INFO - 2023-08-20 07:57:51 --> Security Class Initialized
DEBUG - 2023-08-20 07:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 07:57:51 --> Input Class Initialized
INFO - 2023-08-20 07:57:51 --> Language Class Initialized
INFO - 2023-08-20 07:57:51 --> Loader Class Initialized
INFO - 2023-08-20 07:57:51 --> Helper loaded: url_helper
INFO - 2023-08-20 07:57:51 --> Helper loaded: file_helper
INFO - 2023-08-20 07:57:51 --> Helper loaded: html_helper
INFO - 2023-08-20 07:57:51 --> Helper loaded: text_helper
INFO - 2023-08-20 07:57:51 --> Helper loaded: form_helper
INFO - 2023-08-20 07:57:51 --> Helper loaded: lang_helper
INFO - 2023-08-20 07:57:51 --> Helper loaded: security_helper
INFO - 2023-08-20 07:57:51 --> Helper loaded: cookie_helper
INFO - 2023-08-20 07:57:51 --> Database Driver Class Initialized
INFO - 2023-08-20 07:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 07:57:51 --> Parser Class Initialized
INFO - 2023-08-20 07:57:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 07:57:51 --> Pagination Class Initialized
INFO - 2023-08-20 07:57:51 --> Form Validation Class Initialized
INFO - 2023-08-20 07:57:51 --> Controller Class Initialized
INFO - 2023-08-20 07:57:51 --> Model Class Initialized
DEBUG - 2023-08-20 07:57:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 07:57:51 --> Model Class Initialized
DEBUG - 2023-08-20 07:57:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 07:57:51 --> Model Class Initialized
INFO - 2023-08-20 07:57:51 --> Model Class Initialized
INFO - 2023-08-20 07:57:51 --> Model Class Initialized
INFO - 2023-08-20 07:57:51 --> Model Class Initialized
DEBUG - 2023-08-20 07:57:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-20 07:57:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 07:57:51 --> Model Class Initialized
INFO - 2023-08-20 07:57:51 --> Model Class Initialized
INFO - 2023-08-20 07:57:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-20 07:57:51 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-20 07:57:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-20 07:57:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-20 07:57:51 --> Model Class Initialized
INFO - 2023-08-20 07:57:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-20 07:57:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-20 07:57:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-20 07:57:51 --> Final output sent to browser
DEBUG - 2023-08-20 07:57:51 --> Total execution time: 0.1546
ERROR - 2023-08-20 08:50:57 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 08:50:57 --> Config Class Initialized
INFO - 2023-08-20 08:50:57 --> Hooks Class Initialized
DEBUG - 2023-08-20 08:50:57 --> UTF-8 Support Enabled
INFO - 2023-08-20 08:50:57 --> Utf8 Class Initialized
INFO - 2023-08-20 08:50:57 --> URI Class Initialized
DEBUG - 2023-08-20 08:50:57 --> No URI present. Default controller set.
INFO - 2023-08-20 08:50:57 --> Router Class Initialized
INFO - 2023-08-20 08:50:57 --> Output Class Initialized
INFO - 2023-08-20 08:50:57 --> Security Class Initialized
DEBUG - 2023-08-20 08:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 08:50:57 --> Input Class Initialized
INFO - 2023-08-20 08:50:57 --> Language Class Initialized
INFO - 2023-08-20 08:50:57 --> Loader Class Initialized
INFO - 2023-08-20 08:50:57 --> Helper loaded: url_helper
INFO - 2023-08-20 08:50:57 --> Helper loaded: file_helper
INFO - 2023-08-20 08:50:57 --> Helper loaded: html_helper
INFO - 2023-08-20 08:50:57 --> Helper loaded: text_helper
INFO - 2023-08-20 08:50:57 --> Helper loaded: form_helper
INFO - 2023-08-20 08:50:57 --> Helper loaded: lang_helper
INFO - 2023-08-20 08:50:57 --> Helper loaded: security_helper
INFO - 2023-08-20 08:50:57 --> Helper loaded: cookie_helper
INFO - 2023-08-20 08:50:57 --> Database Driver Class Initialized
INFO - 2023-08-20 08:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 08:50:57 --> Parser Class Initialized
INFO - 2023-08-20 08:50:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 08:50:57 --> Pagination Class Initialized
INFO - 2023-08-20 08:50:57 --> Form Validation Class Initialized
INFO - 2023-08-20 08:50:57 --> Controller Class Initialized
INFO - 2023-08-20 08:50:57 --> Model Class Initialized
DEBUG - 2023-08-20 08:50:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 08:50:57 --> Model Class Initialized
DEBUG - 2023-08-20 08:50:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 08:50:57 --> Model Class Initialized
INFO - 2023-08-20 08:50:57 --> Model Class Initialized
INFO - 2023-08-20 08:50:57 --> Model Class Initialized
INFO - 2023-08-20 08:50:57 --> Model Class Initialized
DEBUG - 2023-08-20 08:50:57 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-20 08:50:57 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 08:50:57 --> Model Class Initialized
INFO - 2023-08-20 08:50:57 --> Model Class Initialized
INFO - 2023-08-20 08:50:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-20 08:50:57 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-20 08:50:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-20 08:50:57 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-20 08:50:57 --> Model Class Initialized
INFO - 2023-08-20 08:50:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-20 08:50:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-20 08:50:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-20 08:50:58 --> Final output sent to browser
DEBUG - 2023-08-20 08:50:58 --> Total execution time: 0.2856
ERROR - 2023-08-20 14:50:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 14:50:31 --> Config Class Initialized
INFO - 2023-08-20 14:50:31 --> Hooks Class Initialized
DEBUG - 2023-08-20 14:50:31 --> UTF-8 Support Enabled
INFO - 2023-08-20 14:50:31 --> Utf8 Class Initialized
INFO - 2023-08-20 14:50:31 --> URI Class Initialized
INFO - 2023-08-20 14:50:31 --> Router Class Initialized
INFO - 2023-08-20 14:50:31 --> Output Class Initialized
INFO - 2023-08-20 14:50:31 --> Security Class Initialized
DEBUG - 2023-08-20 14:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 14:50:31 --> Input Class Initialized
INFO - 2023-08-20 14:50:31 --> Language Class Initialized
ERROR - 2023-08-20 14:50:31 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2023-08-20 16:04:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 16:04:40 --> Config Class Initialized
INFO - 2023-08-20 16:04:40 --> Hooks Class Initialized
DEBUG - 2023-08-20 16:04:40 --> UTF-8 Support Enabled
INFO - 2023-08-20 16:04:40 --> Utf8 Class Initialized
INFO - 2023-08-20 16:04:40 --> URI Class Initialized
DEBUG - 2023-08-20 16:04:40 --> No URI present. Default controller set.
INFO - 2023-08-20 16:04:40 --> Router Class Initialized
INFO - 2023-08-20 16:04:40 --> Output Class Initialized
INFO - 2023-08-20 16:04:40 --> Security Class Initialized
DEBUG - 2023-08-20 16:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 16:04:40 --> Input Class Initialized
INFO - 2023-08-20 16:04:40 --> Language Class Initialized
INFO - 2023-08-20 16:04:40 --> Loader Class Initialized
INFO - 2023-08-20 16:04:40 --> Helper loaded: url_helper
INFO - 2023-08-20 16:04:40 --> Helper loaded: file_helper
INFO - 2023-08-20 16:04:40 --> Helper loaded: html_helper
INFO - 2023-08-20 16:04:40 --> Helper loaded: text_helper
INFO - 2023-08-20 16:04:40 --> Helper loaded: form_helper
INFO - 2023-08-20 16:04:40 --> Helper loaded: lang_helper
INFO - 2023-08-20 16:04:40 --> Helper loaded: security_helper
INFO - 2023-08-20 16:04:40 --> Helper loaded: cookie_helper
INFO - 2023-08-20 16:04:40 --> Database Driver Class Initialized
INFO - 2023-08-20 16:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 16:04:40 --> Parser Class Initialized
INFO - 2023-08-20 16:04:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 16:04:40 --> Pagination Class Initialized
INFO - 2023-08-20 16:04:40 --> Form Validation Class Initialized
INFO - 2023-08-20 16:04:40 --> Controller Class Initialized
INFO - 2023-08-20 16:04:40 --> Model Class Initialized
DEBUG - 2023-08-20 16:04:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-20 16:04:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 16:04:41 --> Config Class Initialized
INFO - 2023-08-20 16:04:41 --> Hooks Class Initialized
DEBUG - 2023-08-20 16:04:41 --> UTF-8 Support Enabled
INFO - 2023-08-20 16:04:41 --> Utf8 Class Initialized
INFO - 2023-08-20 16:04:41 --> URI Class Initialized
INFO - 2023-08-20 16:04:41 --> Router Class Initialized
INFO - 2023-08-20 16:04:41 --> Output Class Initialized
INFO - 2023-08-20 16:04:41 --> Security Class Initialized
DEBUG - 2023-08-20 16:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 16:04:41 --> Input Class Initialized
INFO - 2023-08-20 16:04:41 --> Language Class Initialized
INFO - 2023-08-20 16:04:41 --> Loader Class Initialized
INFO - 2023-08-20 16:04:41 --> Helper loaded: url_helper
INFO - 2023-08-20 16:04:41 --> Helper loaded: file_helper
INFO - 2023-08-20 16:04:41 --> Helper loaded: html_helper
INFO - 2023-08-20 16:04:41 --> Helper loaded: text_helper
INFO - 2023-08-20 16:04:41 --> Helper loaded: form_helper
INFO - 2023-08-20 16:04:41 --> Helper loaded: lang_helper
INFO - 2023-08-20 16:04:41 --> Helper loaded: security_helper
INFO - 2023-08-20 16:04:41 --> Helper loaded: cookie_helper
INFO - 2023-08-20 16:04:41 --> Database Driver Class Initialized
INFO - 2023-08-20 16:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 16:04:41 --> Parser Class Initialized
INFO - 2023-08-20 16:04:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 16:04:41 --> Pagination Class Initialized
INFO - 2023-08-20 16:04:41 --> Form Validation Class Initialized
INFO - 2023-08-20 16:04:41 --> Controller Class Initialized
INFO - 2023-08-20 16:04:41 --> Model Class Initialized
DEBUG - 2023-08-20 16:04:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 16:04:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-20 16:04:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-20 16:04:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-20 16:04:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-20 16:04:41 --> Model Class Initialized
INFO - 2023-08-20 16:04:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-20 16:04:41 --> Final output sent to browser
DEBUG - 2023-08-20 16:04:41 --> Total execution time: 0.0368
ERROR - 2023-08-20 16:04:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 16:04:41 --> Config Class Initialized
INFO - 2023-08-20 16:04:41 --> Hooks Class Initialized
DEBUG - 2023-08-20 16:04:41 --> UTF-8 Support Enabled
INFO - 2023-08-20 16:04:41 --> Utf8 Class Initialized
INFO - 2023-08-20 16:04:41 --> URI Class Initialized
INFO - 2023-08-20 16:04:41 --> Router Class Initialized
INFO - 2023-08-20 16:04:41 --> Output Class Initialized
INFO - 2023-08-20 16:04:41 --> Security Class Initialized
DEBUG - 2023-08-20 16:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 16:04:41 --> Input Class Initialized
INFO - 2023-08-20 16:04:41 --> Language Class Initialized
ERROR - 2023-08-20 16:04:41 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2023-08-20 16:04:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 16:04:41 --> Config Class Initialized
INFO - 2023-08-20 16:04:41 --> Hooks Class Initialized
DEBUG - 2023-08-20 16:04:41 --> UTF-8 Support Enabled
INFO - 2023-08-20 16:04:41 --> Utf8 Class Initialized
INFO - 2023-08-20 16:04:41 --> URI Class Initialized
INFO - 2023-08-20 16:04:41 --> Router Class Initialized
INFO - 2023-08-20 16:04:41 --> Output Class Initialized
INFO - 2023-08-20 16:04:41 --> Security Class Initialized
DEBUG - 2023-08-20 16:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 16:04:41 --> Input Class Initialized
INFO - 2023-08-20 16:04:41 --> Language Class Initialized
ERROR - 2023-08-20 16:04:41 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2023-08-20 16:04:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 16:04:45 --> Config Class Initialized
INFO - 2023-08-20 16:04:45 --> Hooks Class Initialized
DEBUG - 2023-08-20 16:04:45 --> UTF-8 Support Enabled
INFO - 2023-08-20 16:04:45 --> Utf8 Class Initialized
INFO - 2023-08-20 16:04:45 --> URI Class Initialized
INFO - 2023-08-20 16:04:45 --> Router Class Initialized
INFO - 2023-08-20 16:04:45 --> Output Class Initialized
INFO - 2023-08-20 16:04:45 --> Security Class Initialized
DEBUG - 2023-08-20 16:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 16:04:45 --> Input Class Initialized
INFO - 2023-08-20 16:04:45 --> Language Class Initialized
INFO - 2023-08-20 16:04:45 --> Loader Class Initialized
INFO - 2023-08-20 16:04:45 --> Helper loaded: url_helper
INFO - 2023-08-20 16:04:45 --> Helper loaded: file_helper
INFO - 2023-08-20 16:04:45 --> Helper loaded: html_helper
INFO - 2023-08-20 16:04:45 --> Helper loaded: text_helper
INFO - 2023-08-20 16:04:45 --> Helper loaded: form_helper
INFO - 2023-08-20 16:04:45 --> Helper loaded: lang_helper
INFO - 2023-08-20 16:04:45 --> Helper loaded: security_helper
INFO - 2023-08-20 16:04:45 --> Helper loaded: cookie_helper
INFO - 2023-08-20 16:04:45 --> Database Driver Class Initialized
INFO - 2023-08-20 16:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 16:04:45 --> Parser Class Initialized
INFO - 2023-08-20 16:04:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 16:04:45 --> Pagination Class Initialized
INFO - 2023-08-20 16:04:45 --> Form Validation Class Initialized
INFO - 2023-08-20 16:04:45 --> Controller Class Initialized
INFO - 2023-08-20 16:04:45 --> Model Class Initialized
DEBUG - 2023-08-20 16:04:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 16:04:45 --> Model Class Initialized
INFO - 2023-08-20 16:04:45 --> Final output sent to browser
DEBUG - 2023-08-20 16:04:45 --> Total execution time: 0.0211
ERROR - 2023-08-20 16:04:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 16:04:45 --> Config Class Initialized
INFO - 2023-08-20 16:04:45 --> Hooks Class Initialized
DEBUG - 2023-08-20 16:04:45 --> UTF-8 Support Enabled
INFO - 2023-08-20 16:04:45 --> Utf8 Class Initialized
INFO - 2023-08-20 16:04:45 --> URI Class Initialized
DEBUG - 2023-08-20 16:04:45 --> No URI present. Default controller set.
INFO - 2023-08-20 16:04:45 --> Router Class Initialized
INFO - 2023-08-20 16:04:45 --> Output Class Initialized
INFO - 2023-08-20 16:04:45 --> Security Class Initialized
DEBUG - 2023-08-20 16:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 16:04:45 --> Input Class Initialized
INFO - 2023-08-20 16:04:45 --> Language Class Initialized
INFO - 2023-08-20 16:04:45 --> Loader Class Initialized
INFO - 2023-08-20 16:04:45 --> Helper loaded: url_helper
INFO - 2023-08-20 16:04:45 --> Helper loaded: file_helper
INFO - 2023-08-20 16:04:45 --> Helper loaded: html_helper
INFO - 2023-08-20 16:04:45 --> Helper loaded: text_helper
INFO - 2023-08-20 16:04:45 --> Helper loaded: form_helper
INFO - 2023-08-20 16:04:45 --> Helper loaded: lang_helper
INFO - 2023-08-20 16:04:45 --> Helper loaded: security_helper
INFO - 2023-08-20 16:04:45 --> Helper loaded: cookie_helper
INFO - 2023-08-20 16:04:45 --> Database Driver Class Initialized
INFO - 2023-08-20 16:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 16:04:45 --> Parser Class Initialized
INFO - 2023-08-20 16:04:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 16:04:45 --> Pagination Class Initialized
INFO - 2023-08-20 16:04:45 --> Form Validation Class Initialized
INFO - 2023-08-20 16:04:45 --> Controller Class Initialized
INFO - 2023-08-20 16:04:45 --> Model Class Initialized
DEBUG - 2023-08-20 16:04:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 16:04:45 --> Model Class Initialized
DEBUG - 2023-08-20 16:04:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 16:04:45 --> Model Class Initialized
INFO - 2023-08-20 16:04:45 --> Model Class Initialized
INFO - 2023-08-20 16:04:45 --> Model Class Initialized
INFO - 2023-08-20 16:04:45 --> Model Class Initialized
DEBUG - 2023-08-20 16:04:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-20 16:04:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 16:04:45 --> Model Class Initialized
INFO - 2023-08-20 16:04:45 --> Model Class Initialized
INFO - 2023-08-20 16:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-08-20 16:04:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-20 16:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-20 16:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-20 16:04:45 --> Model Class Initialized
INFO - 2023-08-20 16:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-20 16:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-20 16:04:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-20 16:04:45 --> Final output sent to browser
DEBUG - 2023-08-20 16:04:45 --> Total execution time: 0.1139
ERROR - 2023-08-20 16:22:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 16:22:59 --> Config Class Initialized
INFO - 2023-08-20 16:22:59 --> Hooks Class Initialized
DEBUG - 2023-08-20 16:22:59 --> UTF-8 Support Enabled
INFO - 2023-08-20 16:22:59 --> Utf8 Class Initialized
INFO - 2023-08-20 16:22:59 --> URI Class Initialized
INFO - 2023-08-20 16:22:59 --> Router Class Initialized
INFO - 2023-08-20 16:22:59 --> Output Class Initialized
INFO - 2023-08-20 16:22:59 --> Security Class Initialized
DEBUG - 2023-08-20 16:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 16:22:59 --> Input Class Initialized
INFO - 2023-08-20 16:22:59 --> Language Class Initialized
INFO - 2023-08-20 16:22:59 --> Loader Class Initialized
INFO - 2023-08-20 16:22:59 --> Helper loaded: url_helper
INFO - 2023-08-20 16:22:59 --> Helper loaded: file_helper
INFO - 2023-08-20 16:22:59 --> Helper loaded: html_helper
INFO - 2023-08-20 16:22:59 --> Helper loaded: text_helper
INFO - 2023-08-20 16:22:59 --> Helper loaded: form_helper
INFO - 2023-08-20 16:22:59 --> Helper loaded: lang_helper
INFO - 2023-08-20 16:22:59 --> Helper loaded: security_helper
INFO - 2023-08-20 16:22:59 --> Helper loaded: cookie_helper
INFO - 2023-08-20 16:22:59 --> Database Driver Class Initialized
INFO - 2023-08-20 16:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 16:22:59 --> Parser Class Initialized
INFO - 2023-08-20 16:22:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 16:22:59 --> Pagination Class Initialized
INFO - 2023-08-20 16:22:59 --> Form Validation Class Initialized
INFO - 2023-08-20 16:22:59 --> Controller Class Initialized
INFO - 2023-08-20 16:22:59 --> Model Class Initialized
DEBUG - 2023-08-20 16:22:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-20 16:22:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 16:22:59 --> Model Class Initialized
DEBUG - 2023-08-20 16:22:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 16:22:59 --> Model Class Initialized
INFO - 2023-08-20 16:22:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-08-20 16:22:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-20 16:22:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-20 16:22:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-20 16:22:59 --> Model Class Initialized
INFO - 2023-08-20 16:22:59 --> Model Class Initialized
INFO - 2023-08-20 16:22:59 --> Model Class Initialized
INFO - 2023-08-20 16:22:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-20 16:22:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-20 16:22:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-20 16:22:59 --> Final output sent to browser
DEBUG - 2023-08-20 16:22:59 --> Total execution time: 0.0801
ERROR - 2023-08-20 16:23:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 16:23:01 --> Config Class Initialized
INFO - 2023-08-20 16:23:01 --> Hooks Class Initialized
DEBUG - 2023-08-20 16:23:01 --> UTF-8 Support Enabled
INFO - 2023-08-20 16:23:01 --> Utf8 Class Initialized
INFO - 2023-08-20 16:23:01 --> URI Class Initialized
INFO - 2023-08-20 16:23:01 --> Router Class Initialized
INFO - 2023-08-20 16:23:01 --> Output Class Initialized
INFO - 2023-08-20 16:23:01 --> Security Class Initialized
DEBUG - 2023-08-20 16:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 16:23:01 --> Input Class Initialized
INFO - 2023-08-20 16:23:01 --> Language Class Initialized
INFO - 2023-08-20 16:23:01 --> Loader Class Initialized
INFO - 2023-08-20 16:23:01 --> Helper loaded: url_helper
INFO - 2023-08-20 16:23:01 --> Helper loaded: file_helper
INFO - 2023-08-20 16:23:01 --> Helper loaded: html_helper
INFO - 2023-08-20 16:23:01 --> Helper loaded: text_helper
INFO - 2023-08-20 16:23:01 --> Helper loaded: form_helper
INFO - 2023-08-20 16:23:01 --> Helper loaded: lang_helper
INFO - 2023-08-20 16:23:01 --> Helper loaded: security_helper
INFO - 2023-08-20 16:23:01 --> Helper loaded: cookie_helper
INFO - 2023-08-20 16:23:01 --> Database Driver Class Initialized
INFO - 2023-08-20 16:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 16:23:01 --> Parser Class Initialized
INFO - 2023-08-20 16:23:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 16:23:01 --> Pagination Class Initialized
INFO - 2023-08-20 16:23:01 --> Form Validation Class Initialized
INFO - 2023-08-20 16:23:01 --> Controller Class Initialized
INFO - 2023-08-20 16:23:01 --> Model Class Initialized
DEBUG - 2023-08-20 16:23:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-20 16:23:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 16:23:01 --> Model Class Initialized
DEBUG - 2023-08-20 16:23:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 16:23:01 --> Model Class Initialized
INFO - 2023-08-20 16:23:01 --> Final output sent to browser
DEBUG - 2023-08-20 16:23:01 --> Total execution time: 0.0366
ERROR - 2023-08-20 16:23:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 16:23:04 --> Config Class Initialized
INFO - 2023-08-20 16:23:04 --> Hooks Class Initialized
DEBUG - 2023-08-20 16:23:04 --> UTF-8 Support Enabled
INFO - 2023-08-20 16:23:04 --> Utf8 Class Initialized
INFO - 2023-08-20 16:23:04 --> URI Class Initialized
INFO - 2023-08-20 16:23:04 --> Router Class Initialized
INFO - 2023-08-20 16:23:04 --> Output Class Initialized
INFO - 2023-08-20 16:23:04 --> Security Class Initialized
DEBUG - 2023-08-20 16:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 16:23:04 --> Input Class Initialized
INFO - 2023-08-20 16:23:04 --> Language Class Initialized
INFO - 2023-08-20 16:23:04 --> Loader Class Initialized
INFO - 2023-08-20 16:23:04 --> Helper loaded: url_helper
INFO - 2023-08-20 16:23:04 --> Helper loaded: file_helper
INFO - 2023-08-20 16:23:04 --> Helper loaded: html_helper
INFO - 2023-08-20 16:23:04 --> Helper loaded: text_helper
INFO - 2023-08-20 16:23:04 --> Helper loaded: form_helper
INFO - 2023-08-20 16:23:04 --> Helper loaded: lang_helper
INFO - 2023-08-20 16:23:04 --> Helper loaded: security_helper
INFO - 2023-08-20 16:23:04 --> Helper loaded: cookie_helper
INFO - 2023-08-20 16:23:04 --> Database Driver Class Initialized
INFO - 2023-08-20 16:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 16:23:04 --> Parser Class Initialized
INFO - 2023-08-20 16:23:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 16:23:04 --> Pagination Class Initialized
INFO - 2023-08-20 16:23:04 --> Form Validation Class Initialized
INFO - 2023-08-20 16:23:04 --> Controller Class Initialized
INFO - 2023-08-20 16:23:04 --> Model Class Initialized
DEBUG - 2023-08-20 16:23:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-20 16:23:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 16:23:04 --> Model Class Initialized
DEBUG - 2023-08-20 16:23:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 16:23:04 --> Model Class Initialized
INFO - 2023-08-20 16:23:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-08-20 16:23:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-20 16:23:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-20 16:23:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-20 16:23:04 --> Model Class Initialized
INFO - 2023-08-20 16:23:04 --> Model Class Initialized
INFO - 2023-08-20 16:23:04 --> Model Class Initialized
INFO - 2023-08-20 16:23:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-08-20 16:23:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-08-20 16:23:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-20 16:23:04 --> Final output sent to browser
DEBUG - 2023-08-20 16:23:04 --> Total execution time: 0.1063
ERROR - 2023-08-20 16:23:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 16:23:09 --> Config Class Initialized
INFO - 2023-08-20 16:23:09 --> Hooks Class Initialized
DEBUG - 2023-08-20 16:23:09 --> UTF-8 Support Enabled
INFO - 2023-08-20 16:23:09 --> Utf8 Class Initialized
INFO - 2023-08-20 16:23:09 --> URI Class Initialized
INFO - 2023-08-20 16:23:09 --> Router Class Initialized
INFO - 2023-08-20 16:23:09 --> Output Class Initialized
INFO - 2023-08-20 16:23:09 --> Security Class Initialized
DEBUG - 2023-08-20 16:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 16:23:09 --> Input Class Initialized
INFO - 2023-08-20 16:23:09 --> Language Class Initialized
INFO - 2023-08-20 16:23:09 --> Loader Class Initialized
INFO - 2023-08-20 16:23:09 --> Helper loaded: url_helper
INFO - 2023-08-20 16:23:09 --> Helper loaded: file_helper
INFO - 2023-08-20 16:23:09 --> Helper loaded: html_helper
INFO - 2023-08-20 16:23:09 --> Helper loaded: text_helper
INFO - 2023-08-20 16:23:09 --> Helper loaded: form_helper
INFO - 2023-08-20 16:23:09 --> Helper loaded: lang_helper
INFO - 2023-08-20 16:23:09 --> Helper loaded: security_helper
INFO - 2023-08-20 16:23:09 --> Helper loaded: cookie_helper
INFO - 2023-08-20 16:23:09 --> Database Driver Class Initialized
INFO - 2023-08-20 16:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 16:23:09 --> Parser Class Initialized
INFO - 2023-08-20 16:23:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 16:23:09 --> Pagination Class Initialized
INFO - 2023-08-20 16:23:09 --> Form Validation Class Initialized
INFO - 2023-08-20 16:23:09 --> Controller Class Initialized
INFO - 2023-08-20 16:23:09 --> Model Class Initialized
DEBUG - 2023-08-20 16:23:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 16:23:09 --> Final output sent to browser
DEBUG - 2023-08-20 16:23:09 --> Total execution time: 0.0158
ERROR - 2023-08-20 16:23:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 16:23:09 --> Config Class Initialized
INFO - 2023-08-20 16:23:09 --> Hooks Class Initialized
DEBUG - 2023-08-20 16:23:09 --> UTF-8 Support Enabled
INFO - 2023-08-20 16:23:09 --> Utf8 Class Initialized
INFO - 2023-08-20 16:23:09 --> URI Class Initialized
INFO - 2023-08-20 16:23:09 --> Router Class Initialized
INFO - 2023-08-20 16:23:09 --> Output Class Initialized
INFO - 2023-08-20 16:23:09 --> Security Class Initialized
DEBUG - 2023-08-20 16:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 16:23:09 --> Input Class Initialized
INFO - 2023-08-20 16:23:09 --> Language Class Initialized
INFO - 2023-08-20 16:23:09 --> Loader Class Initialized
INFO - 2023-08-20 16:23:09 --> Helper loaded: url_helper
INFO - 2023-08-20 16:23:09 --> Helper loaded: file_helper
INFO - 2023-08-20 16:23:09 --> Helper loaded: html_helper
INFO - 2023-08-20 16:23:09 --> Helper loaded: text_helper
INFO - 2023-08-20 16:23:09 --> Helper loaded: form_helper
INFO - 2023-08-20 16:23:09 --> Helper loaded: lang_helper
INFO - 2023-08-20 16:23:09 --> Helper loaded: security_helper
INFO - 2023-08-20 16:23:09 --> Helper loaded: cookie_helper
INFO - 2023-08-20 16:23:09 --> Database Driver Class Initialized
INFO - 2023-08-20 16:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 16:23:09 --> Parser Class Initialized
INFO - 2023-08-20 16:23:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 16:23:09 --> Pagination Class Initialized
INFO - 2023-08-20 16:23:09 --> Form Validation Class Initialized
INFO - 2023-08-20 16:23:09 --> Controller Class Initialized
INFO - 2023-08-20 16:23:09 --> Model Class Initialized
DEBUG - 2023-08-20 16:23:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 16:23:09 --> Final output sent to browser
DEBUG - 2023-08-20 16:23:09 --> Total execution time: 0.0156
ERROR - 2023-08-20 16:23:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 16:23:26 --> Config Class Initialized
INFO - 2023-08-20 16:23:26 --> Hooks Class Initialized
DEBUG - 2023-08-20 16:23:26 --> UTF-8 Support Enabled
INFO - 2023-08-20 16:23:26 --> Utf8 Class Initialized
INFO - 2023-08-20 16:23:26 --> URI Class Initialized
INFO - 2023-08-20 16:23:26 --> Router Class Initialized
INFO - 2023-08-20 16:23:26 --> Output Class Initialized
INFO - 2023-08-20 16:23:26 --> Security Class Initialized
DEBUG - 2023-08-20 16:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 16:23:26 --> Input Class Initialized
INFO - 2023-08-20 16:23:26 --> Language Class Initialized
INFO - 2023-08-20 16:23:26 --> Loader Class Initialized
INFO - 2023-08-20 16:23:26 --> Helper loaded: url_helper
INFO - 2023-08-20 16:23:26 --> Helper loaded: file_helper
INFO - 2023-08-20 16:23:26 --> Helper loaded: html_helper
INFO - 2023-08-20 16:23:26 --> Helper loaded: text_helper
INFO - 2023-08-20 16:23:26 --> Helper loaded: form_helper
INFO - 2023-08-20 16:23:26 --> Helper loaded: lang_helper
INFO - 2023-08-20 16:23:26 --> Helper loaded: security_helper
INFO - 2023-08-20 16:23:26 --> Helper loaded: cookie_helper
INFO - 2023-08-20 16:23:26 --> Database Driver Class Initialized
INFO - 2023-08-20 16:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 16:23:26 --> Parser Class Initialized
INFO - 2023-08-20 16:23:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 16:23:26 --> Pagination Class Initialized
INFO - 2023-08-20 16:23:26 --> Form Validation Class Initialized
INFO - 2023-08-20 16:23:26 --> Controller Class Initialized
INFO - 2023-08-20 16:23:26 --> Model Class Initialized
DEBUG - 2023-08-20 16:23:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 16:23:26 --> Final output sent to browser
DEBUG - 2023-08-20 16:23:26 --> Total execution time: 0.0183
ERROR - 2023-08-20 16:23:27 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 16:23:27 --> Config Class Initialized
INFO - 2023-08-20 16:23:27 --> Hooks Class Initialized
DEBUG - 2023-08-20 16:23:27 --> UTF-8 Support Enabled
INFO - 2023-08-20 16:23:27 --> Utf8 Class Initialized
INFO - 2023-08-20 16:23:27 --> URI Class Initialized
INFO - 2023-08-20 16:23:27 --> Router Class Initialized
INFO - 2023-08-20 16:23:27 --> Output Class Initialized
INFO - 2023-08-20 16:23:27 --> Security Class Initialized
DEBUG - 2023-08-20 16:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 16:23:27 --> Input Class Initialized
INFO - 2023-08-20 16:23:27 --> Language Class Initialized
INFO - 2023-08-20 16:23:27 --> Loader Class Initialized
INFO - 2023-08-20 16:23:27 --> Helper loaded: url_helper
INFO - 2023-08-20 16:23:27 --> Helper loaded: file_helper
INFO - 2023-08-20 16:23:27 --> Helper loaded: html_helper
INFO - 2023-08-20 16:23:27 --> Helper loaded: text_helper
INFO - 2023-08-20 16:23:27 --> Helper loaded: form_helper
INFO - 2023-08-20 16:23:27 --> Helper loaded: lang_helper
INFO - 2023-08-20 16:23:27 --> Helper loaded: security_helper
INFO - 2023-08-20 16:23:27 --> Helper loaded: cookie_helper
INFO - 2023-08-20 16:23:27 --> Database Driver Class Initialized
INFO - 2023-08-20 16:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 16:23:27 --> Parser Class Initialized
INFO - 2023-08-20 16:23:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 16:23:27 --> Pagination Class Initialized
INFO - 2023-08-20 16:23:27 --> Form Validation Class Initialized
INFO - 2023-08-20 16:23:27 --> Controller Class Initialized
INFO - 2023-08-20 16:23:27 --> Model Class Initialized
DEBUG - 2023-08-20 16:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 16:23:27 --> Final output sent to browser
DEBUG - 2023-08-20 16:23:27 --> Total execution time: 0.0163
ERROR - 2023-08-20 16:23:28 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 16:23:28 --> Config Class Initialized
INFO - 2023-08-20 16:23:28 --> Hooks Class Initialized
DEBUG - 2023-08-20 16:23:28 --> UTF-8 Support Enabled
INFO - 2023-08-20 16:23:28 --> Utf8 Class Initialized
INFO - 2023-08-20 16:23:28 --> URI Class Initialized
INFO - 2023-08-20 16:23:28 --> Router Class Initialized
INFO - 2023-08-20 16:23:28 --> Output Class Initialized
INFO - 2023-08-20 16:23:28 --> Security Class Initialized
DEBUG - 2023-08-20 16:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 16:23:28 --> Input Class Initialized
INFO - 2023-08-20 16:23:28 --> Language Class Initialized
INFO - 2023-08-20 16:23:28 --> Loader Class Initialized
INFO - 2023-08-20 16:23:28 --> Helper loaded: url_helper
INFO - 2023-08-20 16:23:28 --> Helper loaded: file_helper
INFO - 2023-08-20 16:23:28 --> Helper loaded: html_helper
INFO - 2023-08-20 16:23:28 --> Helper loaded: text_helper
INFO - 2023-08-20 16:23:28 --> Helper loaded: form_helper
INFO - 2023-08-20 16:23:28 --> Helper loaded: lang_helper
INFO - 2023-08-20 16:23:28 --> Helper loaded: security_helper
INFO - 2023-08-20 16:23:28 --> Helper loaded: cookie_helper
INFO - 2023-08-20 16:23:28 --> Database Driver Class Initialized
INFO - 2023-08-20 16:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 16:23:28 --> Parser Class Initialized
INFO - 2023-08-20 16:23:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 16:23:28 --> Pagination Class Initialized
INFO - 2023-08-20 16:23:28 --> Form Validation Class Initialized
INFO - 2023-08-20 16:23:28 --> Controller Class Initialized
INFO - 2023-08-20 16:23:28 --> Final output sent to browser
DEBUG - 2023-08-20 16:23:28 --> Total execution time: 0.0148
ERROR - 2023-08-20 16:23:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 16:23:30 --> Config Class Initialized
INFO - 2023-08-20 16:23:30 --> Hooks Class Initialized
DEBUG - 2023-08-20 16:23:30 --> UTF-8 Support Enabled
INFO - 2023-08-20 16:23:30 --> Utf8 Class Initialized
INFO - 2023-08-20 16:23:30 --> URI Class Initialized
INFO - 2023-08-20 16:23:30 --> Router Class Initialized
INFO - 2023-08-20 16:23:30 --> Output Class Initialized
INFO - 2023-08-20 16:23:30 --> Security Class Initialized
DEBUG - 2023-08-20 16:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 16:23:30 --> Input Class Initialized
INFO - 2023-08-20 16:23:30 --> Language Class Initialized
INFO - 2023-08-20 16:23:30 --> Loader Class Initialized
INFO - 2023-08-20 16:23:30 --> Helper loaded: url_helper
INFO - 2023-08-20 16:23:30 --> Helper loaded: file_helper
INFO - 2023-08-20 16:23:30 --> Helper loaded: html_helper
INFO - 2023-08-20 16:23:30 --> Helper loaded: text_helper
INFO - 2023-08-20 16:23:30 --> Helper loaded: form_helper
INFO - 2023-08-20 16:23:30 --> Helper loaded: lang_helper
INFO - 2023-08-20 16:23:30 --> Helper loaded: security_helper
INFO - 2023-08-20 16:23:30 --> Helper loaded: cookie_helper
INFO - 2023-08-20 16:23:30 --> Database Driver Class Initialized
INFO - 2023-08-20 16:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 16:23:30 --> Parser Class Initialized
INFO - 2023-08-20 16:23:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 16:23:30 --> Pagination Class Initialized
INFO - 2023-08-20 16:23:30 --> Form Validation Class Initialized
INFO - 2023-08-20 16:23:30 --> Controller Class Initialized
INFO - 2023-08-20 16:23:30 --> Model Class Initialized
DEBUG - 2023-08-20 16:23:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-20 16:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 16:23:30 --> Model Class Initialized
DEBUG - 2023-08-20 16:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 16:23:30 --> Model Class Initialized
INFO - 2023-08-20 16:23:30 --> Final output sent to browser
DEBUG - 2023-08-20 16:23:30 --> Total execution time: 0.0577
ERROR - 2023-08-20 16:23:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 16:23:31 --> Config Class Initialized
INFO - 2023-08-20 16:23:31 --> Hooks Class Initialized
DEBUG - 2023-08-20 16:23:31 --> UTF-8 Support Enabled
INFO - 2023-08-20 16:23:31 --> Utf8 Class Initialized
INFO - 2023-08-20 16:23:31 --> URI Class Initialized
INFO - 2023-08-20 16:23:31 --> Router Class Initialized
INFO - 2023-08-20 16:23:31 --> Output Class Initialized
INFO - 2023-08-20 16:23:31 --> Security Class Initialized
DEBUG - 2023-08-20 16:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 16:23:31 --> Input Class Initialized
INFO - 2023-08-20 16:23:31 --> Language Class Initialized
INFO - 2023-08-20 16:23:31 --> Loader Class Initialized
INFO - 2023-08-20 16:23:31 --> Helper loaded: url_helper
INFO - 2023-08-20 16:23:31 --> Helper loaded: file_helper
INFO - 2023-08-20 16:23:31 --> Helper loaded: html_helper
INFO - 2023-08-20 16:23:31 --> Helper loaded: text_helper
INFO - 2023-08-20 16:23:31 --> Helper loaded: form_helper
INFO - 2023-08-20 16:23:31 --> Helper loaded: lang_helper
INFO - 2023-08-20 16:23:31 --> Helper loaded: security_helper
INFO - 2023-08-20 16:23:31 --> Helper loaded: cookie_helper
INFO - 2023-08-20 16:23:31 --> Database Driver Class Initialized
INFO - 2023-08-20 16:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 16:23:31 --> Parser Class Initialized
INFO - 2023-08-20 16:23:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 16:23:31 --> Pagination Class Initialized
INFO - 2023-08-20 16:23:31 --> Form Validation Class Initialized
INFO - 2023-08-20 16:23:31 --> Controller Class Initialized
INFO - 2023-08-20 16:23:31 --> Model Class Initialized
DEBUG - 2023-08-20 16:23:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-20 16:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 16:23:31 --> Model Class Initialized
DEBUG - 2023-08-20 16:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 16:23:31 --> Model Class Initialized
INFO - 2023-08-20 16:23:31 --> Final output sent to browser
DEBUG - 2023-08-20 16:23:31 --> Total execution time: 0.0551
ERROR - 2023-08-20 16:23:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 16:23:35 --> Config Class Initialized
INFO - 2023-08-20 16:23:35 --> Hooks Class Initialized
DEBUG - 2023-08-20 16:23:35 --> UTF-8 Support Enabled
INFO - 2023-08-20 16:23:35 --> Utf8 Class Initialized
INFO - 2023-08-20 16:23:35 --> URI Class Initialized
INFO - 2023-08-20 16:23:35 --> Router Class Initialized
INFO - 2023-08-20 16:23:35 --> Output Class Initialized
INFO - 2023-08-20 16:23:35 --> Security Class Initialized
DEBUG - 2023-08-20 16:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 16:23:35 --> Input Class Initialized
INFO - 2023-08-20 16:23:35 --> Language Class Initialized
INFO - 2023-08-20 16:23:35 --> Loader Class Initialized
INFO - 2023-08-20 16:23:35 --> Helper loaded: url_helper
INFO - 2023-08-20 16:23:35 --> Helper loaded: file_helper
INFO - 2023-08-20 16:23:35 --> Helper loaded: html_helper
INFO - 2023-08-20 16:23:35 --> Helper loaded: text_helper
INFO - 2023-08-20 16:23:35 --> Helper loaded: form_helper
INFO - 2023-08-20 16:23:35 --> Helper loaded: lang_helper
INFO - 2023-08-20 16:23:35 --> Helper loaded: security_helper
INFO - 2023-08-20 16:23:35 --> Helper loaded: cookie_helper
INFO - 2023-08-20 16:23:35 --> Database Driver Class Initialized
INFO - 2023-08-20 16:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 16:23:35 --> Parser Class Initialized
INFO - 2023-08-20 16:23:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 16:23:35 --> Pagination Class Initialized
INFO - 2023-08-20 16:23:35 --> Form Validation Class Initialized
INFO - 2023-08-20 16:23:35 --> Controller Class Initialized
INFO - 2023-08-20 16:23:35 --> Model Class Initialized
DEBUG - 2023-08-20 16:23:35 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-20 16:23:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 16:23:35 --> Model Class Initialized
INFO - 2023-08-20 16:23:35 --> Model Class Initialized
INFO - 2023-08-20 16:23:35 --> Final output sent to browser
DEBUG - 2023-08-20 16:23:35 --> Total execution time: 0.0201
ERROR - 2023-08-20 16:23:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 16:23:38 --> Config Class Initialized
INFO - 2023-08-20 16:23:38 --> Hooks Class Initialized
DEBUG - 2023-08-20 16:23:38 --> UTF-8 Support Enabled
INFO - 2023-08-20 16:23:38 --> Utf8 Class Initialized
INFO - 2023-08-20 16:23:38 --> URI Class Initialized
INFO - 2023-08-20 16:23:38 --> Router Class Initialized
INFO - 2023-08-20 16:23:38 --> Output Class Initialized
INFO - 2023-08-20 16:23:38 --> Security Class Initialized
DEBUG - 2023-08-20 16:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 16:23:38 --> Input Class Initialized
INFO - 2023-08-20 16:23:38 --> Language Class Initialized
INFO - 2023-08-20 16:23:38 --> Loader Class Initialized
INFO - 2023-08-20 16:23:38 --> Helper loaded: url_helper
INFO - 2023-08-20 16:23:38 --> Helper loaded: file_helper
INFO - 2023-08-20 16:23:38 --> Helper loaded: html_helper
INFO - 2023-08-20 16:23:38 --> Helper loaded: text_helper
INFO - 2023-08-20 16:23:38 --> Helper loaded: form_helper
INFO - 2023-08-20 16:23:38 --> Helper loaded: lang_helper
INFO - 2023-08-20 16:23:38 --> Helper loaded: security_helper
INFO - 2023-08-20 16:23:38 --> Helper loaded: cookie_helper
INFO - 2023-08-20 16:23:38 --> Database Driver Class Initialized
INFO - 2023-08-20 16:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 16:23:38 --> Parser Class Initialized
INFO - 2023-08-20 16:23:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 16:23:38 --> Pagination Class Initialized
INFO - 2023-08-20 16:23:38 --> Form Validation Class Initialized
INFO - 2023-08-20 16:23:38 --> Controller Class Initialized
INFO - 2023-08-20 16:23:38 --> Model Class Initialized
DEBUG - 2023-08-20 16:23:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-08-20 16:23:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 16:23:38 --> Model Class Initialized
INFO - 2023-08-20 16:23:38 --> Final output sent to browser
DEBUG - 2023-08-20 16:23:38 --> Total execution time: 0.0168
ERROR - 2023-08-20 17:38:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 17:38:13 --> Config Class Initialized
INFO - 2023-08-20 17:38:13 --> Hooks Class Initialized
DEBUG - 2023-08-20 17:38:13 --> UTF-8 Support Enabled
INFO - 2023-08-20 17:38:13 --> Utf8 Class Initialized
INFO - 2023-08-20 17:38:13 --> URI Class Initialized
DEBUG - 2023-08-20 17:38:13 --> No URI present. Default controller set.
INFO - 2023-08-20 17:38:13 --> Router Class Initialized
INFO - 2023-08-20 17:38:13 --> Output Class Initialized
INFO - 2023-08-20 17:38:13 --> Security Class Initialized
DEBUG - 2023-08-20 17:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 17:38:13 --> Input Class Initialized
INFO - 2023-08-20 17:38:13 --> Language Class Initialized
INFO - 2023-08-20 17:38:13 --> Loader Class Initialized
INFO - 2023-08-20 17:38:13 --> Helper loaded: url_helper
INFO - 2023-08-20 17:38:13 --> Helper loaded: file_helper
INFO - 2023-08-20 17:38:13 --> Helper loaded: html_helper
INFO - 2023-08-20 17:38:13 --> Helper loaded: text_helper
INFO - 2023-08-20 17:38:13 --> Helper loaded: form_helper
INFO - 2023-08-20 17:38:13 --> Helper loaded: lang_helper
INFO - 2023-08-20 17:38:13 --> Helper loaded: security_helper
INFO - 2023-08-20 17:38:13 --> Helper loaded: cookie_helper
INFO - 2023-08-20 17:38:13 --> Database Driver Class Initialized
INFO - 2023-08-20 17:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 17:38:13 --> Parser Class Initialized
INFO - 2023-08-20 17:38:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 17:38:13 --> Pagination Class Initialized
INFO - 2023-08-20 17:38:13 --> Form Validation Class Initialized
INFO - 2023-08-20 17:38:13 --> Controller Class Initialized
INFO - 2023-08-20 17:38:13 --> Model Class Initialized
DEBUG - 2023-08-20 17:38:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-20 17:38:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 17:38:14 --> Config Class Initialized
INFO - 2023-08-20 17:38:14 --> Hooks Class Initialized
DEBUG - 2023-08-20 17:38:14 --> UTF-8 Support Enabled
INFO - 2023-08-20 17:38:14 --> Utf8 Class Initialized
INFO - 2023-08-20 17:38:14 --> URI Class Initialized
INFO - 2023-08-20 17:38:14 --> Router Class Initialized
INFO - 2023-08-20 17:38:14 --> Output Class Initialized
INFO - 2023-08-20 17:38:14 --> Security Class Initialized
DEBUG - 2023-08-20 17:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 17:38:14 --> Input Class Initialized
INFO - 2023-08-20 17:38:14 --> Language Class Initialized
INFO - 2023-08-20 17:38:14 --> Loader Class Initialized
INFO - 2023-08-20 17:38:14 --> Helper loaded: url_helper
INFO - 2023-08-20 17:38:14 --> Helper loaded: file_helper
INFO - 2023-08-20 17:38:14 --> Helper loaded: html_helper
INFO - 2023-08-20 17:38:14 --> Helper loaded: text_helper
INFO - 2023-08-20 17:38:14 --> Helper loaded: form_helper
INFO - 2023-08-20 17:38:14 --> Helper loaded: lang_helper
INFO - 2023-08-20 17:38:14 --> Helper loaded: security_helper
INFO - 2023-08-20 17:38:14 --> Helper loaded: cookie_helper
INFO - 2023-08-20 17:38:14 --> Database Driver Class Initialized
INFO - 2023-08-20 17:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 17:38:14 --> Parser Class Initialized
INFO - 2023-08-20 17:38:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 17:38:14 --> Pagination Class Initialized
INFO - 2023-08-20 17:38:14 --> Form Validation Class Initialized
INFO - 2023-08-20 17:38:14 --> Controller Class Initialized
INFO - 2023-08-20 17:38:14 --> Model Class Initialized
DEBUG - 2023-08-20 17:38:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 17:38:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-20 17:38:14 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-20 17:38:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-20 17:38:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-20 17:38:14 --> Model Class Initialized
INFO - 2023-08-20 17:38:14 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-20 17:38:14 --> Final output sent to browser
DEBUG - 2023-08-20 17:38:14 --> Total execution time: 0.0361
ERROR - 2023-08-20 17:38:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 17:38:21 --> Config Class Initialized
INFO - 2023-08-20 17:38:21 --> Hooks Class Initialized
DEBUG - 2023-08-20 17:38:21 --> UTF-8 Support Enabled
INFO - 2023-08-20 17:38:21 --> Utf8 Class Initialized
INFO - 2023-08-20 17:38:21 --> URI Class Initialized
DEBUG - 2023-08-20 17:38:21 --> No URI present. Default controller set.
INFO - 2023-08-20 17:38:21 --> Router Class Initialized
INFO - 2023-08-20 17:38:21 --> Output Class Initialized
INFO - 2023-08-20 17:38:21 --> Security Class Initialized
DEBUG - 2023-08-20 17:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 17:38:21 --> Input Class Initialized
INFO - 2023-08-20 17:38:21 --> Language Class Initialized
INFO - 2023-08-20 17:38:21 --> Loader Class Initialized
INFO - 2023-08-20 17:38:21 --> Helper loaded: url_helper
INFO - 2023-08-20 17:38:21 --> Helper loaded: file_helper
INFO - 2023-08-20 17:38:21 --> Helper loaded: html_helper
INFO - 2023-08-20 17:38:21 --> Helper loaded: text_helper
INFO - 2023-08-20 17:38:21 --> Helper loaded: form_helper
INFO - 2023-08-20 17:38:21 --> Helper loaded: lang_helper
INFO - 2023-08-20 17:38:21 --> Helper loaded: security_helper
INFO - 2023-08-20 17:38:21 --> Helper loaded: cookie_helper
INFO - 2023-08-20 17:38:21 --> Database Driver Class Initialized
INFO - 2023-08-20 17:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 17:38:21 --> Parser Class Initialized
INFO - 2023-08-20 17:38:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 17:38:21 --> Pagination Class Initialized
INFO - 2023-08-20 17:38:21 --> Form Validation Class Initialized
INFO - 2023-08-20 17:38:21 --> Controller Class Initialized
INFO - 2023-08-20 17:38:21 --> Model Class Initialized
DEBUG - 2023-08-20 17:38:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-20 17:38:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-08-20 17:38:21 --> Config Class Initialized
INFO - 2023-08-20 17:38:21 --> Hooks Class Initialized
DEBUG - 2023-08-20 17:38:21 --> UTF-8 Support Enabled
INFO - 2023-08-20 17:38:21 --> Utf8 Class Initialized
INFO - 2023-08-20 17:38:21 --> URI Class Initialized
INFO - 2023-08-20 17:38:22 --> Router Class Initialized
INFO - 2023-08-20 17:38:22 --> Output Class Initialized
INFO - 2023-08-20 17:38:22 --> Security Class Initialized
DEBUG - 2023-08-20 17:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-20 17:38:22 --> Input Class Initialized
INFO - 2023-08-20 17:38:22 --> Language Class Initialized
INFO - 2023-08-20 17:38:22 --> Loader Class Initialized
INFO - 2023-08-20 17:38:22 --> Helper loaded: url_helper
INFO - 2023-08-20 17:38:22 --> Helper loaded: file_helper
INFO - 2023-08-20 17:38:22 --> Helper loaded: html_helper
INFO - 2023-08-20 17:38:22 --> Helper loaded: text_helper
INFO - 2023-08-20 17:38:22 --> Helper loaded: form_helper
INFO - 2023-08-20 17:38:22 --> Helper loaded: lang_helper
INFO - 2023-08-20 17:38:22 --> Helper loaded: security_helper
INFO - 2023-08-20 17:38:22 --> Helper loaded: cookie_helper
INFO - 2023-08-20 17:38:22 --> Database Driver Class Initialized
INFO - 2023-08-20 17:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-20 17:38:22 --> Parser Class Initialized
INFO - 2023-08-20 17:38:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-08-20 17:38:22 --> Pagination Class Initialized
INFO - 2023-08-20 17:38:22 --> Form Validation Class Initialized
INFO - 2023-08-20 17:38:22 --> Controller Class Initialized
INFO - 2023-08-20 17:38:22 --> Model Class Initialized
DEBUG - 2023-08-20 17:38:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-08-20 17:38:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-08-20 17:38:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-08-20 17:38:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-08-20 17:38:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-08-20 17:38:22 --> Model Class Initialized
INFO - 2023-08-20 17:38:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-08-20 17:38:22 --> Final output sent to browser
DEBUG - 2023-08-20 17:38:22 --> Total execution time: 0.0323
