<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-07 06:49:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 06:49:30 --> Config Class Initialized
INFO - 2023-10-07 06:49:30 --> Hooks Class Initialized
DEBUG - 2023-10-07 06:49:30 --> UTF-8 Support Enabled
INFO - 2023-10-07 06:49:30 --> Utf8 Class Initialized
INFO - 2023-10-07 06:49:30 --> URI Class Initialized
DEBUG - 2023-10-07 06:49:30 --> No URI present. Default controller set.
INFO - 2023-10-07 06:49:30 --> Router Class Initialized
INFO - 2023-10-07 06:49:30 --> Output Class Initialized
INFO - 2023-10-07 06:49:30 --> Security Class Initialized
DEBUG - 2023-10-07 06:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 06:49:30 --> Input Class Initialized
INFO - 2023-10-07 06:49:30 --> Language Class Initialized
INFO - 2023-10-07 06:49:30 --> Loader Class Initialized
INFO - 2023-10-07 06:49:30 --> Helper loaded: url_helper
INFO - 2023-10-07 06:49:30 --> Helper loaded: file_helper
INFO - 2023-10-07 06:49:30 --> Helper loaded: html_helper
INFO - 2023-10-07 06:49:30 --> Helper loaded: text_helper
INFO - 2023-10-07 06:49:30 --> Helper loaded: form_helper
INFO - 2023-10-07 06:49:30 --> Helper loaded: lang_helper
INFO - 2023-10-07 06:49:30 --> Helper loaded: security_helper
INFO - 2023-10-07 06:49:30 --> Helper loaded: cookie_helper
INFO - 2023-10-07 06:49:30 --> Database Driver Class Initialized
INFO - 2023-10-07 06:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 06:49:30 --> Parser Class Initialized
INFO - 2023-10-07 06:49:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 06:49:30 --> Pagination Class Initialized
INFO - 2023-10-07 06:49:30 --> Form Validation Class Initialized
INFO - 2023-10-07 06:49:30 --> Controller Class Initialized
INFO - 2023-10-07 06:49:30 --> Model Class Initialized
DEBUG - 2023-10-07 06:49:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-07 07:29:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:29:34 --> Config Class Initialized
INFO - 2023-10-07 07:29:34 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:29:34 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:29:34 --> Utf8 Class Initialized
INFO - 2023-10-07 07:29:34 --> URI Class Initialized
DEBUG - 2023-10-07 07:29:34 --> No URI present. Default controller set.
INFO - 2023-10-07 07:29:34 --> Router Class Initialized
INFO - 2023-10-07 07:29:34 --> Output Class Initialized
INFO - 2023-10-07 07:29:34 --> Security Class Initialized
DEBUG - 2023-10-07 07:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:29:34 --> Input Class Initialized
INFO - 2023-10-07 07:29:34 --> Language Class Initialized
INFO - 2023-10-07 07:29:34 --> Loader Class Initialized
INFO - 2023-10-07 07:29:34 --> Helper loaded: url_helper
INFO - 2023-10-07 07:29:34 --> Helper loaded: file_helper
INFO - 2023-10-07 07:29:34 --> Helper loaded: html_helper
INFO - 2023-10-07 07:29:34 --> Helper loaded: text_helper
INFO - 2023-10-07 07:29:34 --> Helper loaded: form_helper
INFO - 2023-10-07 07:29:34 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:29:34 --> Helper loaded: security_helper
INFO - 2023-10-07 07:29:34 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:29:34 --> Database Driver Class Initialized
INFO - 2023-10-07 07:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:29:34 --> Parser Class Initialized
INFO - 2023-10-07 07:29:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:29:34 --> Pagination Class Initialized
INFO - 2023-10-07 07:29:34 --> Form Validation Class Initialized
INFO - 2023-10-07 07:29:34 --> Controller Class Initialized
INFO - 2023-10-07 07:29:34 --> Model Class Initialized
DEBUG - 2023-10-07 07:29:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-07 07:29:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:29:35 --> Config Class Initialized
INFO - 2023-10-07 07:29:35 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:29:35 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:29:35 --> Utf8 Class Initialized
INFO - 2023-10-07 07:29:35 --> URI Class Initialized
INFO - 2023-10-07 07:29:35 --> Router Class Initialized
INFO - 2023-10-07 07:29:35 --> Output Class Initialized
INFO - 2023-10-07 07:29:35 --> Security Class Initialized
DEBUG - 2023-10-07 07:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:29:35 --> Input Class Initialized
INFO - 2023-10-07 07:29:35 --> Language Class Initialized
INFO - 2023-10-07 07:29:35 --> Loader Class Initialized
INFO - 2023-10-07 07:29:35 --> Helper loaded: url_helper
INFO - 2023-10-07 07:29:35 --> Helper loaded: file_helper
INFO - 2023-10-07 07:29:35 --> Helper loaded: html_helper
INFO - 2023-10-07 07:29:35 --> Helper loaded: text_helper
INFO - 2023-10-07 07:29:35 --> Helper loaded: form_helper
INFO - 2023-10-07 07:29:35 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:29:35 --> Helper loaded: security_helper
INFO - 2023-10-07 07:29:35 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:29:35 --> Database Driver Class Initialized
INFO - 2023-10-07 07:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:29:35 --> Parser Class Initialized
INFO - 2023-10-07 07:29:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:29:35 --> Pagination Class Initialized
INFO - 2023-10-07 07:29:35 --> Form Validation Class Initialized
INFO - 2023-10-07 07:29:35 --> Controller Class Initialized
INFO - 2023-10-07 07:29:35 --> Model Class Initialized
DEBUG - 2023-10-07 07:29:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:29:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-07 07:29:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:29:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:29:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:29:35 --> Model Class Initialized
INFO - 2023-10-07 07:29:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:29:35 --> Final output sent to browser
DEBUG - 2023-10-07 07:29:35 --> Total execution time: 0.0344
ERROR - 2023-10-07 07:30:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:30:00 --> Config Class Initialized
INFO - 2023-10-07 07:30:00 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:30:00 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:30:00 --> Utf8 Class Initialized
INFO - 2023-10-07 07:30:00 --> URI Class Initialized
INFO - 2023-10-07 07:30:00 --> Router Class Initialized
INFO - 2023-10-07 07:30:00 --> Output Class Initialized
INFO - 2023-10-07 07:30:00 --> Security Class Initialized
DEBUG - 2023-10-07 07:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:30:00 --> Input Class Initialized
INFO - 2023-10-07 07:30:00 --> Language Class Initialized
INFO - 2023-10-07 07:30:00 --> Loader Class Initialized
INFO - 2023-10-07 07:30:00 --> Helper loaded: url_helper
INFO - 2023-10-07 07:30:00 --> Helper loaded: file_helper
INFO - 2023-10-07 07:30:00 --> Helper loaded: html_helper
INFO - 2023-10-07 07:30:00 --> Helper loaded: text_helper
INFO - 2023-10-07 07:30:00 --> Helper loaded: form_helper
INFO - 2023-10-07 07:30:00 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:30:00 --> Helper loaded: security_helper
INFO - 2023-10-07 07:30:00 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:30:00 --> Database Driver Class Initialized
INFO - 2023-10-07 07:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:30:00 --> Parser Class Initialized
INFO - 2023-10-07 07:30:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:30:00 --> Pagination Class Initialized
INFO - 2023-10-07 07:30:00 --> Form Validation Class Initialized
INFO - 2023-10-07 07:30:00 --> Controller Class Initialized
INFO - 2023-10-07 07:30:00 --> Model Class Initialized
DEBUG - 2023-10-07 07:30:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:30:00 --> Model Class Initialized
INFO - 2023-10-07 07:30:00 --> Final output sent to browser
DEBUG - 2023-10-07 07:30:00 --> Total execution time: 0.0200
ERROR - 2023-10-07 07:30:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:30:00 --> Config Class Initialized
INFO - 2023-10-07 07:30:00 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:30:00 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:30:00 --> Utf8 Class Initialized
INFO - 2023-10-07 07:30:00 --> URI Class Initialized
DEBUG - 2023-10-07 07:30:00 --> No URI present. Default controller set.
INFO - 2023-10-07 07:30:00 --> Router Class Initialized
INFO - 2023-10-07 07:30:00 --> Output Class Initialized
INFO - 2023-10-07 07:30:00 --> Security Class Initialized
DEBUG - 2023-10-07 07:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:30:00 --> Input Class Initialized
INFO - 2023-10-07 07:30:00 --> Language Class Initialized
INFO - 2023-10-07 07:30:00 --> Loader Class Initialized
INFO - 2023-10-07 07:30:00 --> Helper loaded: url_helper
INFO - 2023-10-07 07:30:00 --> Helper loaded: file_helper
INFO - 2023-10-07 07:30:00 --> Helper loaded: html_helper
INFO - 2023-10-07 07:30:00 --> Helper loaded: text_helper
INFO - 2023-10-07 07:30:00 --> Helper loaded: form_helper
INFO - 2023-10-07 07:30:00 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:30:00 --> Helper loaded: security_helper
INFO - 2023-10-07 07:30:00 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:30:00 --> Database Driver Class Initialized
INFO - 2023-10-07 07:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:30:00 --> Parser Class Initialized
INFO - 2023-10-07 07:30:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:30:00 --> Pagination Class Initialized
INFO - 2023-10-07 07:30:00 --> Form Validation Class Initialized
INFO - 2023-10-07 07:30:00 --> Controller Class Initialized
INFO - 2023-10-07 07:30:00 --> Model Class Initialized
DEBUG - 2023-10-07 07:30:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:30:00 --> Model Class Initialized
DEBUG - 2023-10-07 07:30:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:30:00 --> Model Class Initialized
INFO - 2023-10-07 07:30:00 --> Model Class Initialized
INFO - 2023-10-07 07:30:00 --> Model Class Initialized
INFO - 2023-10-07 07:30:00 --> Model Class Initialized
DEBUG - 2023-10-07 07:30:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:30:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:30:00 --> Model Class Initialized
INFO - 2023-10-07 07:30:00 --> Model Class Initialized
INFO - 2023-10-07 07:30:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 07:30:00 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:30:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:30:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:30:00 --> Model Class Initialized
INFO - 2023-10-07 07:30:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 07:30:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 07:30:00 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:30:00 --> Final output sent to browser
DEBUG - 2023-10-07 07:30:00 --> Total execution time: 0.1317
ERROR - 2023-10-07 07:30:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:30:21 --> Config Class Initialized
INFO - 2023-10-07 07:30:21 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:30:21 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:30:21 --> Utf8 Class Initialized
INFO - 2023-10-07 07:30:21 --> URI Class Initialized
INFO - 2023-10-07 07:30:21 --> Router Class Initialized
INFO - 2023-10-07 07:30:21 --> Output Class Initialized
INFO - 2023-10-07 07:30:21 --> Security Class Initialized
DEBUG - 2023-10-07 07:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:30:21 --> Input Class Initialized
INFO - 2023-10-07 07:30:21 --> Language Class Initialized
INFO - 2023-10-07 07:30:21 --> Loader Class Initialized
INFO - 2023-10-07 07:30:21 --> Helper loaded: url_helper
INFO - 2023-10-07 07:30:21 --> Helper loaded: file_helper
INFO - 2023-10-07 07:30:21 --> Helper loaded: html_helper
INFO - 2023-10-07 07:30:21 --> Helper loaded: text_helper
INFO - 2023-10-07 07:30:21 --> Helper loaded: form_helper
INFO - 2023-10-07 07:30:21 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:30:21 --> Helper loaded: security_helper
INFO - 2023-10-07 07:30:21 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:30:21 --> Database Driver Class Initialized
INFO - 2023-10-07 07:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:30:21 --> Parser Class Initialized
INFO - 2023-10-07 07:30:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:30:21 --> Pagination Class Initialized
INFO - 2023-10-07 07:30:21 --> Form Validation Class Initialized
INFO - 2023-10-07 07:30:21 --> Controller Class Initialized
INFO - 2023-10-07 07:30:21 --> Model Class Initialized
DEBUG - 2023-10-07 07:30:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:30:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:30:21 --> Model Class Initialized
DEBUG - 2023-10-07 07:30:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:30:21 --> Model Class Initialized
INFO - 2023-10-07 07:30:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-07 07:30:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:30:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:30:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:30:21 --> Model Class Initialized
INFO - 2023-10-07 07:30:21 --> Model Class Initialized
INFO - 2023-10-07 07:30:21 --> Model Class Initialized
INFO - 2023-10-07 07:30:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 07:30:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 07:30:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:30:21 --> Final output sent to browser
DEBUG - 2023-10-07 07:30:21 --> Total execution time: 0.0904
ERROR - 2023-10-07 07:30:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:30:24 --> Config Class Initialized
INFO - 2023-10-07 07:30:24 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:30:24 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:30:24 --> Utf8 Class Initialized
INFO - 2023-10-07 07:30:24 --> URI Class Initialized
INFO - 2023-10-07 07:30:24 --> Router Class Initialized
INFO - 2023-10-07 07:30:24 --> Output Class Initialized
INFO - 2023-10-07 07:30:24 --> Security Class Initialized
DEBUG - 2023-10-07 07:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:30:24 --> Input Class Initialized
INFO - 2023-10-07 07:30:24 --> Language Class Initialized
INFO - 2023-10-07 07:30:24 --> Loader Class Initialized
INFO - 2023-10-07 07:30:24 --> Helper loaded: url_helper
INFO - 2023-10-07 07:30:24 --> Helper loaded: file_helper
INFO - 2023-10-07 07:30:24 --> Helper loaded: html_helper
INFO - 2023-10-07 07:30:24 --> Helper loaded: text_helper
INFO - 2023-10-07 07:30:24 --> Helper loaded: form_helper
INFO - 2023-10-07 07:30:24 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:30:24 --> Helper loaded: security_helper
INFO - 2023-10-07 07:30:24 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:30:24 --> Database Driver Class Initialized
INFO - 2023-10-07 07:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:30:24 --> Parser Class Initialized
INFO - 2023-10-07 07:30:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:30:24 --> Pagination Class Initialized
INFO - 2023-10-07 07:30:24 --> Form Validation Class Initialized
INFO - 2023-10-07 07:30:24 --> Controller Class Initialized
INFO - 2023-10-07 07:30:24 --> Model Class Initialized
DEBUG - 2023-10-07 07:30:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:30:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:30:24 --> Model Class Initialized
DEBUG - 2023-10-07 07:30:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:30:24 --> Model Class Initialized
INFO - 2023-10-07 07:30:24 --> Final output sent to browser
DEBUG - 2023-10-07 07:30:24 --> Total execution time: 0.0462
ERROR - 2023-10-07 07:30:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:30:33 --> Config Class Initialized
INFO - 2023-10-07 07:30:33 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:30:33 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:30:33 --> Utf8 Class Initialized
INFO - 2023-10-07 07:30:33 --> URI Class Initialized
DEBUG - 2023-10-07 07:30:33 --> No URI present. Default controller set.
INFO - 2023-10-07 07:30:33 --> Router Class Initialized
INFO - 2023-10-07 07:30:33 --> Output Class Initialized
INFO - 2023-10-07 07:30:33 --> Security Class Initialized
DEBUG - 2023-10-07 07:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:30:33 --> Input Class Initialized
INFO - 2023-10-07 07:30:33 --> Language Class Initialized
INFO - 2023-10-07 07:30:33 --> Loader Class Initialized
INFO - 2023-10-07 07:30:33 --> Helper loaded: url_helper
INFO - 2023-10-07 07:30:33 --> Helper loaded: file_helper
INFO - 2023-10-07 07:30:33 --> Helper loaded: html_helper
INFO - 2023-10-07 07:30:33 --> Helper loaded: text_helper
INFO - 2023-10-07 07:30:33 --> Helper loaded: form_helper
INFO - 2023-10-07 07:30:33 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:30:33 --> Helper loaded: security_helper
INFO - 2023-10-07 07:30:33 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:30:33 --> Database Driver Class Initialized
INFO - 2023-10-07 07:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:30:33 --> Parser Class Initialized
INFO - 2023-10-07 07:30:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:30:33 --> Pagination Class Initialized
INFO - 2023-10-07 07:30:33 --> Form Validation Class Initialized
INFO - 2023-10-07 07:30:33 --> Controller Class Initialized
INFO - 2023-10-07 07:30:33 --> Model Class Initialized
DEBUG - 2023-10-07 07:30:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:30:33 --> Model Class Initialized
DEBUG - 2023-10-07 07:30:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:30:33 --> Model Class Initialized
INFO - 2023-10-07 07:30:33 --> Model Class Initialized
INFO - 2023-10-07 07:30:33 --> Model Class Initialized
INFO - 2023-10-07 07:30:33 --> Model Class Initialized
DEBUG - 2023-10-07 07:30:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:30:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:30:33 --> Model Class Initialized
INFO - 2023-10-07 07:30:33 --> Model Class Initialized
INFO - 2023-10-07 07:30:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 07:30:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:30:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:30:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:30:33 --> Model Class Initialized
INFO - 2023-10-07 07:30:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 07:30:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 07:30:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:30:33 --> Final output sent to browser
DEBUG - 2023-10-07 07:30:33 --> Total execution time: 0.1106
ERROR - 2023-10-07 07:30:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:30:36 --> Config Class Initialized
INFO - 2023-10-07 07:30:36 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:30:36 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:30:36 --> Utf8 Class Initialized
INFO - 2023-10-07 07:30:36 --> URI Class Initialized
INFO - 2023-10-07 07:30:36 --> Router Class Initialized
INFO - 2023-10-07 07:30:36 --> Output Class Initialized
INFO - 2023-10-07 07:30:36 --> Security Class Initialized
DEBUG - 2023-10-07 07:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:30:36 --> Input Class Initialized
INFO - 2023-10-07 07:30:36 --> Language Class Initialized
INFO - 2023-10-07 07:30:36 --> Loader Class Initialized
INFO - 2023-10-07 07:30:36 --> Helper loaded: url_helper
INFO - 2023-10-07 07:30:36 --> Helper loaded: file_helper
INFO - 2023-10-07 07:30:36 --> Helper loaded: html_helper
INFO - 2023-10-07 07:30:36 --> Helper loaded: text_helper
INFO - 2023-10-07 07:30:36 --> Helper loaded: form_helper
INFO - 2023-10-07 07:30:36 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:30:36 --> Helper loaded: security_helper
INFO - 2023-10-07 07:30:36 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:30:36 --> Database Driver Class Initialized
INFO - 2023-10-07 07:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:30:36 --> Parser Class Initialized
INFO - 2023-10-07 07:30:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:30:36 --> Pagination Class Initialized
INFO - 2023-10-07 07:30:36 --> Form Validation Class Initialized
INFO - 2023-10-07 07:30:36 --> Controller Class Initialized
INFO - 2023-10-07 07:30:36 --> Model Class Initialized
DEBUG - 2023-10-07 07:30:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:30:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:30:36 --> Model Class Initialized
DEBUG - 2023-10-07 07:30:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:30:36 --> Model Class Initialized
INFO - 2023-10-07 07:30:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-10-07 07:30:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:30:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:30:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:30:36 --> Model Class Initialized
INFO - 2023-10-07 07:30:36 --> Model Class Initialized
INFO - 2023-10-07 07:30:36 --> Model Class Initialized
INFO - 2023-10-07 07:30:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 07:30:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 07:30:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:30:36 --> Final output sent to browser
DEBUG - 2023-10-07 07:30:36 --> Total execution time: 0.1190
ERROR - 2023-10-07 07:30:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:30:41 --> Config Class Initialized
INFO - 2023-10-07 07:30:41 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:30:41 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:30:41 --> Utf8 Class Initialized
INFO - 2023-10-07 07:30:41 --> URI Class Initialized
INFO - 2023-10-07 07:30:41 --> Router Class Initialized
INFO - 2023-10-07 07:30:41 --> Output Class Initialized
INFO - 2023-10-07 07:30:41 --> Security Class Initialized
DEBUG - 2023-10-07 07:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:30:41 --> Input Class Initialized
INFO - 2023-10-07 07:30:41 --> Language Class Initialized
INFO - 2023-10-07 07:30:41 --> Loader Class Initialized
INFO - 2023-10-07 07:30:41 --> Helper loaded: url_helper
INFO - 2023-10-07 07:30:41 --> Helper loaded: file_helper
INFO - 2023-10-07 07:30:41 --> Helper loaded: html_helper
INFO - 2023-10-07 07:30:41 --> Helper loaded: text_helper
INFO - 2023-10-07 07:30:41 --> Helper loaded: form_helper
INFO - 2023-10-07 07:30:41 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:30:41 --> Helper loaded: security_helper
INFO - 2023-10-07 07:30:41 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:30:41 --> Database Driver Class Initialized
INFO - 2023-10-07 07:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:30:41 --> Parser Class Initialized
INFO - 2023-10-07 07:30:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:30:41 --> Pagination Class Initialized
INFO - 2023-10-07 07:30:41 --> Form Validation Class Initialized
INFO - 2023-10-07 07:30:41 --> Controller Class Initialized
INFO - 2023-10-07 07:30:41 --> Model Class Initialized
DEBUG - 2023-10-07 07:30:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:30:41 --> Final output sent to browser
DEBUG - 2023-10-07 07:30:41 --> Total execution time: 0.0157
ERROR - 2023-10-07 07:30:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:30:42 --> Config Class Initialized
INFO - 2023-10-07 07:30:42 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:30:42 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:30:42 --> Utf8 Class Initialized
INFO - 2023-10-07 07:30:42 --> URI Class Initialized
INFO - 2023-10-07 07:30:42 --> Router Class Initialized
INFO - 2023-10-07 07:30:42 --> Output Class Initialized
INFO - 2023-10-07 07:30:42 --> Security Class Initialized
DEBUG - 2023-10-07 07:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:30:42 --> Input Class Initialized
INFO - 2023-10-07 07:30:42 --> Language Class Initialized
INFO - 2023-10-07 07:30:42 --> Loader Class Initialized
INFO - 2023-10-07 07:30:42 --> Helper loaded: url_helper
INFO - 2023-10-07 07:30:42 --> Helper loaded: file_helper
INFO - 2023-10-07 07:30:42 --> Helper loaded: html_helper
INFO - 2023-10-07 07:30:42 --> Helper loaded: text_helper
INFO - 2023-10-07 07:30:42 --> Helper loaded: form_helper
INFO - 2023-10-07 07:30:42 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:30:42 --> Helper loaded: security_helper
INFO - 2023-10-07 07:30:42 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:30:42 --> Database Driver Class Initialized
INFO - 2023-10-07 07:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:30:42 --> Parser Class Initialized
INFO - 2023-10-07 07:30:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:30:42 --> Pagination Class Initialized
INFO - 2023-10-07 07:30:42 --> Form Validation Class Initialized
INFO - 2023-10-07 07:30:42 --> Controller Class Initialized
INFO - 2023-10-07 07:30:42 --> Model Class Initialized
DEBUG - 2023-10-07 07:30:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:30:42 --> Final output sent to browser
DEBUG - 2023-10-07 07:30:42 --> Total execution time: 0.0158
ERROR - 2023-10-07 07:30:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:30:43 --> Config Class Initialized
INFO - 2023-10-07 07:30:43 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:30:43 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:30:43 --> Utf8 Class Initialized
INFO - 2023-10-07 07:30:43 --> URI Class Initialized
INFO - 2023-10-07 07:30:43 --> Router Class Initialized
INFO - 2023-10-07 07:30:43 --> Output Class Initialized
INFO - 2023-10-07 07:30:43 --> Security Class Initialized
DEBUG - 2023-10-07 07:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:30:43 --> Input Class Initialized
INFO - 2023-10-07 07:30:43 --> Language Class Initialized
INFO - 2023-10-07 07:30:43 --> Loader Class Initialized
INFO - 2023-10-07 07:30:43 --> Helper loaded: url_helper
INFO - 2023-10-07 07:30:43 --> Helper loaded: file_helper
INFO - 2023-10-07 07:30:43 --> Helper loaded: html_helper
INFO - 2023-10-07 07:30:43 --> Helper loaded: text_helper
INFO - 2023-10-07 07:30:43 --> Helper loaded: form_helper
INFO - 2023-10-07 07:30:43 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:30:43 --> Helper loaded: security_helper
INFO - 2023-10-07 07:30:43 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:30:43 --> Database Driver Class Initialized
INFO - 2023-10-07 07:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:30:43 --> Parser Class Initialized
INFO - 2023-10-07 07:30:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:30:43 --> Pagination Class Initialized
INFO - 2023-10-07 07:30:43 --> Form Validation Class Initialized
INFO - 2023-10-07 07:30:43 --> Controller Class Initialized
INFO - 2023-10-07 07:30:43 --> Final output sent to browser
DEBUG - 2023-10-07 07:30:43 --> Total execution time: 0.0143
ERROR - 2023-10-07 07:30:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:30:47 --> Config Class Initialized
INFO - 2023-10-07 07:30:47 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:30:47 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:30:47 --> Utf8 Class Initialized
INFO - 2023-10-07 07:30:47 --> URI Class Initialized
INFO - 2023-10-07 07:30:47 --> Router Class Initialized
INFO - 2023-10-07 07:30:47 --> Output Class Initialized
INFO - 2023-10-07 07:30:47 --> Security Class Initialized
DEBUG - 2023-10-07 07:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:30:47 --> Input Class Initialized
INFO - 2023-10-07 07:30:47 --> Language Class Initialized
INFO - 2023-10-07 07:30:47 --> Loader Class Initialized
INFO - 2023-10-07 07:30:47 --> Helper loaded: url_helper
INFO - 2023-10-07 07:30:47 --> Helper loaded: file_helper
INFO - 2023-10-07 07:30:47 --> Helper loaded: html_helper
INFO - 2023-10-07 07:30:47 --> Helper loaded: text_helper
INFO - 2023-10-07 07:30:47 --> Helper loaded: form_helper
INFO - 2023-10-07 07:30:47 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:30:47 --> Helper loaded: security_helper
INFO - 2023-10-07 07:30:47 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:30:47 --> Database Driver Class Initialized
INFO - 2023-10-07 07:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:30:47 --> Parser Class Initialized
INFO - 2023-10-07 07:30:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:30:47 --> Pagination Class Initialized
INFO - 2023-10-07 07:30:47 --> Form Validation Class Initialized
INFO - 2023-10-07 07:30:47 --> Controller Class Initialized
INFO - 2023-10-07 07:30:47 --> Model Class Initialized
DEBUG - 2023-10-07 07:30:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:30:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:30:47 --> Model Class Initialized
DEBUG - 2023-10-07 07:30:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:30:47 --> Model Class Initialized
INFO - 2023-10-07 07:30:47 --> Final output sent to browser
DEBUG - 2023-10-07 07:30:47 --> Total execution time: 0.1395
ERROR - 2023-10-07 07:30:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:30:48 --> Config Class Initialized
INFO - 2023-10-07 07:30:48 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:30:48 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:30:48 --> Utf8 Class Initialized
INFO - 2023-10-07 07:30:48 --> URI Class Initialized
INFO - 2023-10-07 07:30:48 --> Router Class Initialized
INFO - 2023-10-07 07:30:48 --> Output Class Initialized
INFO - 2023-10-07 07:30:48 --> Security Class Initialized
DEBUG - 2023-10-07 07:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:30:48 --> Input Class Initialized
INFO - 2023-10-07 07:30:48 --> Language Class Initialized
INFO - 2023-10-07 07:30:48 --> Loader Class Initialized
INFO - 2023-10-07 07:30:48 --> Helper loaded: url_helper
INFO - 2023-10-07 07:30:48 --> Helper loaded: file_helper
INFO - 2023-10-07 07:30:48 --> Helper loaded: html_helper
INFO - 2023-10-07 07:30:48 --> Helper loaded: text_helper
INFO - 2023-10-07 07:30:48 --> Helper loaded: form_helper
INFO - 2023-10-07 07:30:48 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:30:48 --> Helper loaded: security_helper
INFO - 2023-10-07 07:30:48 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:30:48 --> Database Driver Class Initialized
INFO - 2023-10-07 07:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:30:48 --> Parser Class Initialized
INFO - 2023-10-07 07:30:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:30:48 --> Pagination Class Initialized
INFO - 2023-10-07 07:30:48 --> Form Validation Class Initialized
INFO - 2023-10-07 07:30:48 --> Controller Class Initialized
INFO - 2023-10-07 07:30:48 --> Model Class Initialized
DEBUG - 2023-10-07 07:30:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:30:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:30:48 --> Model Class Initialized
DEBUG - 2023-10-07 07:30:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:30:48 --> Model Class Initialized
INFO - 2023-10-07 07:30:48 --> Final output sent to browser
DEBUG - 2023-10-07 07:30:48 --> Total execution time: 0.1390
ERROR - 2023-10-07 07:30:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:30:48 --> Config Class Initialized
INFO - 2023-10-07 07:30:48 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:30:48 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:30:48 --> Utf8 Class Initialized
INFO - 2023-10-07 07:30:48 --> URI Class Initialized
INFO - 2023-10-07 07:30:48 --> Router Class Initialized
INFO - 2023-10-07 07:30:48 --> Output Class Initialized
INFO - 2023-10-07 07:30:48 --> Security Class Initialized
DEBUG - 2023-10-07 07:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:30:48 --> Input Class Initialized
INFO - 2023-10-07 07:30:48 --> Language Class Initialized
INFO - 2023-10-07 07:30:48 --> Loader Class Initialized
INFO - 2023-10-07 07:30:48 --> Helper loaded: url_helper
INFO - 2023-10-07 07:30:48 --> Helper loaded: file_helper
INFO - 2023-10-07 07:30:48 --> Helper loaded: html_helper
INFO - 2023-10-07 07:30:48 --> Helper loaded: text_helper
INFO - 2023-10-07 07:30:48 --> Helper loaded: form_helper
INFO - 2023-10-07 07:30:48 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:30:48 --> Helper loaded: security_helper
INFO - 2023-10-07 07:30:48 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:30:48 --> Database Driver Class Initialized
INFO - 2023-10-07 07:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:30:48 --> Parser Class Initialized
INFO - 2023-10-07 07:30:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:30:48 --> Pagination Class Initialized
INFO - 2023-10-07 07:30:48 --> Form Validation Class Initialized
INFO - 2023-10-07 07:30:48 --> Controller Class Initialized
INFO - 2023-10-07 07:30:48 --> Model Class Initialized
DEBUG - 2023-10-07 07:30:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:30:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:30:49 --> Model Class Initialized
DEBUG - 2023-10-07 07:30:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:30:49 --> Model Class Initialized
INFO - 2023-10-07 07:30:49 --> Final output sent to browser
DEBUG - 2023-10-07 07:30:49 --> Total execution time: 0.1353
ERROR - 2023-10-07 07:30:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:30:54 --> Config Class Initialized
INFO - 2023-10-07 07:30:54 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:30:54 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:30:54 --> Utf8 Class Initialized
INFO - 2023-10-07 07:30:54 --> URI Class Initialized
INFO - 2023-10-07 07:30:54 --> Router Class Initialized
INFO - 2023-10-07 07:30:54 --> Output Class Initialized
INFO - 2023-10-07 07:30:54 --> Security Class Initialized
DEBUG - 2023-10-07 07:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:30:54 --> Input Class Initialized
INFO - 2023-10-07 07:30:54 --> Language Class Initialized
INFO - 2023-10-07 07:30:54 --> Loader Class Initialized
INFO - 2023-10-07 07:30:54 --> Helper loaded: url_helper
INFO - 2023-10-07 07:30:54 --> Helper loaded: file_helper
INFO - 2023-10-07 07:30:54 --> Helper loaded: html_helper
INFO - 2023-10-07 07:30:54 --> Helper loaded: text_helper
INFO - 2023-10-07 07:30:54 --> Helper loaded: form_helper
INFO - 2023-10-07 07:30:54 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:30:54 --> Helper loaded: security_helper
INFO - 2023-10-07 07:30:54 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:30:54 --> Database Driver Class Initialized
INFO - 2023-10-07 07:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:30:54 --> Parser Class Initialized
INFO - 2023-10-07 07:30:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:30:54 --> Pagination Class Initialized
INFO - 2023-10-07 07:30:54 --> Form Validation Class Initialized
INFO - 2023-10-07 07:30:54 --> Controller Class Initialized
INFO - 2023-10-07 07:30:54 --> Model Class Initialized
DEBUG - 2023-10-07 07:30:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:30:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:30:54 --> Model Class Initialized
INFO - 2023-10-07 07:30:54 --> Model Class Initialized
INFO - 2023-10-07 07:30:54 --> Final output sent to browser
DEBUG - 2023-10-07 07:30:54 --> Total execution time: 0.0235
ERROR - 2023-10-07 07:30:56 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:30:56 --> Config Class Initialized
INFO - 2023-10-07 07:30:56 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:30:56 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:30:56 --> Utf8 Class Initialized
INFO - 2023-10-07 07:30:56 --> URI Class Initialized
INFO - 2023-10-07 07:30:56 --> Router Class Initialized
INFO - 2023-10-07 07:30:56 --> Output Class Initialized
INFO - 2023-10-07 07:30:56 --> Security Class Initialized
DEBUG - 2023-10-07 07:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:30:56 --> Input Class Initialized
INFO - 2023-10-07 07:30:56 --> Language Class Initialized
INFO - 2023-10-07 07:30:56 --> Loader Class Initialized
INFO - 2023-10-07 07:30:56 --> Helper loaded: url_helper
INFO - 2023-10-07 07:30:56 --> Helper loaded: file_helper
INFO - 2023-10-07 07:30:56 --> Helper loaded: html_helper
INFO - 2023-10-07 07:30:56 --> Helper loaded: text_helper
INFO - 2023-10-07 07:30:56 --> Helper loaded: form_helper
INFO - 2023-10-07 07:30:56 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:30:56 --> Helper loaded: security_helper
INFO - 2023-10-07 07:30:56 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:30:56 --> Database Driver Class Initialized
INFO - 2023-10-07 07:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:30:56 --> Parser Class Initialized
INFO - 2023-10-07 07:30:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:30:56 --> Pagination Class Initialized
INFO - 2023-10-07 07:30:56 --> Form Validation Class Initialized
INFO - 2023-10-07 07:30:56 --> Controller Class Initialized
INFO - 2023-10-07 07:30:56 --> Model Class Initialized
DEBUG - 2023-10-07 07:30:56 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:30:56 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:30:56 --> Model Class Initialized
INFO - 2023-10-07 07:30:56 --> Final output sent to browser
DEBUG - 2023-10-07 07:30:56 --> Total execution time: 0.0173
ERROR - 2023-10-07 07:31:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:31:06 --> Config Class Initialized
INFO - 2023-10-07 07:31:06 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:31:06 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:31:06 --> Utf8 Class Initialized
INFO - 2023-10-07 07:31:06 --> URI Class Initialized
INFO - 2023-10-07 07:31:06 --> Router Class Initialized
INFO - 2023-10-07 07:31:06 --> Output Class Initialized
INFO - 2023-10-07 07:31:06 --> Security Class Initialized
DEBUG - 2023-10-07 07:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:31:06 --> Input Class Initialized
INFO - 2023-10-07 07:31:06 --> Language Class Initialized
INFO - 2023-10-07 07:31:06 --> Loader Class Initialized
INFO - 2023-10-07 07:31:06 --> Helper loaded: url_helper
INFO - 2023-10-07 07:31:06 --> Helper loaded: file_helper
INFO - 2023-10-07 07:31:06 --> Helper loaded: html_helper
INFO - 2023-10-07 07:31:06 --> Helper loaded: text_helper
INFO - 2023-10-07 07:31:06 --> Helper loaded: form_helper
INFO - 2023-10-07 07:31:06 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:31:06 --> Helper loaded: security_helper
INFO - 2023-10-07 07:31:06 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:31:06 --> Database Driver Class Initialized
INFO - 2023-10-07 07:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:31:06 --> Parser Class Initialized
INFO - 2023-10-07 07:31:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:31:06 --> Pagination Class Initialized
INFO - 2023-10-07 07:31:06 --> Form Validation Class Initialized
INFO - 2023-10-07 07:31:06 --> Controller Class Initialized
INFO - 2023-10-07 07:31:06 --> Model Class Initialized
DEBUG - 2023-10-07 07:31:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:31:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:31:06 --> Model Class Initialized
DEBUG - 2023-10-07 07:31:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:31:06 --> Model Class Initialized
INFO - 2023-10-07 07:31:06 --> Final output sent to browser
DEBUG - 2023-10-07 07:31:06 --> Total execution time: 0.1411
ERROR - 2023-10-07 07:31:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:31:07 --> Config Class Initialized
INFO - 2023-10-07 07:31:07 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:31:07 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:31:07 --> Utf8 Class Initialized
INFO - 2023-10-07 07:31:07 --> URI Class Initialized
INFO - 2023-10-07 07:31:07 --> Router Class Initialized
INFO - 2023-10-07 07:31:07 --> Output Class Initialized
INFO - 2023-10-07 07:31:07 --> Security Class Initialized
DEBUG - 2023-10-07 07:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:31:07 --> Input Class Initialized
INFO - 2023-10-07 07:31:07 --> Language Class Initialized
INFO - 2023-10-07 07:31:07 --> Loader Class Initialized
INFO - 2023-10-07 07:31:07 --> Helper loaded: url_helper
INFO - 2023-10-07 07:31:07 --> Helper loaded: file_helper
INFO - 2023-10-07 07:31:07 --> Helper loaded: html_helper
INFO - 2023-10-07 07:31:07 --> Helper loaded: text_helper
INFO - 2023-10-07 07:31:07 --> Helper loaded: form_helper
INFO - 2023-10-07 07:31:07 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:31:07 --> Helper loaded: security_helper
INFO - 2023-10-07 07:31:07 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:31:07 --> Database Driver Class Initialized
INFO - 2023-10-07 07:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:31:07 --> Parser Class Initialized
INFO - 2023-10-07 07:31:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:31:07 --> Pagination Class Initialized
INFO - 2023-10-07 07:31:07 --> Form Validation Class Initialized
INFO - 2023-10-07 07:31:07 --> Controller Class Initialized
INFO - 2023-10-07 07:31:07 --> Model Class Initialized
DEBUG - 2023-10-07 07:31:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:31:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:31:07 --> Model Class Initialized
DEBUG - 2023-10-07 07:31:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:31:07 --> Model Class Initialized
INFO - 2023-10-07 07:31:07 --> Final output sent to browser
DEBUG - 2023-10-07 07:31:07 --> Total execution time: 0.1387
ERROR - 2023-10-07 07:31:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:31:07 --> Config Class Initialized
INFO - 2023-10-07 07:31:07 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:31:07 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:31:07 --> Utf8 Class Initialized
INFO - 2023-10-07 07:31:07 --> URI Class Initialized
INFO - 2023-10-07 07:31:07 --> Router Class Initialized
INFO - 2023-10-07 07:31:07 --> Output Class Initialized
INFO - 2023-10-07 07:31:07 --> Security Class Initialized
DEBUG - 2023-10-07 07:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:31:07 --> Input Class Initialized
INFO - 2023-10-07 07:31:07 --> Language Class Initialized
INFO - 2023-10-07 07:31:07 --> Loader Class Initialized
INFO - 2023-10-07 07:31:07 --> Helper loaded: url_helper
INFO - 2023-10-07 07:31:07 --> Helper loaded: file_helper
INFO - 2023-10-07 07:31:07 --> Helper loaded: html_helper
INFO - 2023-10-07 07:31:07 --> Helper loaded: text_helper
INFO - 2023-10-07 07:31:07 --> Helper loaded: form_helper
INFO - 2023-10-07 07:31:07 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:31:07 --> Helper loaded: security_helper
INFO - 2023-10-07 07:31:07 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:31:07 --> Database Driver Class Initialized
INFO - 2023-10-07 07:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:31:07 --> Parser Class Initialized
INFO - 2023-10-07 07:31:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:31:07 --> Pagination Class Initialized
INFO - 2023-10-07 07:31:07 --> Form Validation Class Initialized
INFO - 2023-10-07 07:31:07 --> Controller Class Initialized
INFO - 2023-10-07 07:31:07 --> Model Class Initialized
DEBUG - 2023-10-07 07:31:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:31:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:31:07 --> Model Class Initialized
DEBUG - 2023-10-07 07:31:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:31:07 --> Model Class Initialized
INFO - 2023-10-07 07:31:08 --> Final output sent to browser
DEBUG - 2023-10-07 07:31:08 --> Total execution time: 0.1428
ERROR - 2023-10-07 07:31:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:31:09 --> Config Class Initialized
INFO - 2023-10-07 07:31:09 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:31:09 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:31:09 --> Utf8 Class Initialized
INFO - 2023-10-07 07:31:09 --> URI Class Initialized
INFO - 2023-10-07 07:31:09 --> Router Class Initialized
INFO - 2023-10-07 07:31:09 --> Output Class Initialized
INFO - 2023-10-07 07:31:09 --> Security Class Initialized
DEBUG - 2023-10-07 07:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:31:09 --> Input Class Initialized
INFO - 2023-10-07 07:31:09 --> Language Class Initialized
INFO - 2023-10-07 07:31:09 --> Loader Class Initialized
INFO - 2023-10-07 07:31:09 --> Helper loaded: url_helper
INFO - 2023-10-07 07:31:09 --> Helper loaded: file_helper
INFO - 2023-10-07 07:31:09 --> Helper loaded: html_helper
INFO - 2023-10-07 07:31:09 --> Helper loaded: text_helper
INFO - 2023-10-07 07:31:09 --> Helper loaded: form_helper
INFO - 2023-10-07 07:31:09 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:31:09 --> Helper loaded: security_helper
INFO - 2023-10-07 07:31:09 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:31:09 --> Database Driver Class Initialized
INFO - 2023-10-07 07:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:31:09 --> Parser Class Initialized
INFO - 2023-10-07 07:31:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:31:09 --> Pagination Class Initialized
INFO - 2023-10-07 07:31:09 --> Form Validation Class Initialized
INFO - 2023-10-07 07:31:09 --> Controller Class Initialized
INFO - 2023-10-07 07:31:09 --> Model Class Initialized
DEBUG - 2023-10-07 07:31:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:31:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:31:09 --> Model Class Initialized
DEBUG - 2023-10-07 07:31:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:31:09 --> Model Class Initialized
INFO - 2023-10-07 07:31:10 --> Final output sent to browser
DEBUG - 2023-10-07 07:31:10 --> Total execution time: 0.0483
ERROR - 2023-10-07 07:31:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:31:10 --> Config Class Initialized
INFO - 2023-10-07 07:31:10 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:31:10 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:31:10 --> Utf8 Class Initialized
INFO - 2023-10-07 07:31:10 --> URI Class Initialized
INFO - 2023-10-07 07:31:10 --> Router Class Initialized
INFO - 2023-10-07 07:31:10 --> Output Class Initialized
INFO - 2023-10-07 07:31:10 --> Security Class Initialized
DEBUG - 2023-10-07 07:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:31:10 --> Input Class Initialized
INFO - 2023-10-07 07:31:10 --> Language Class Initialized
INFO - 2023-10-07 07:31:10 --> Loader Class Initialized
INFO - 2023-10-07 07:31:10 --> Helper loaded: url_helper
INFO - 2023-10-07 07:31:10 --> Helper loaded: file_helper
INFO - 2023-10-07 07:31:10 --> Helper loaded: html_helper
INFO - 2023-10-07 07:31:10 --> Helper loaded: text_helper
INFO - 2023-10-07 07:31:10 --> Helper loaded: form_helper
INFO - 2023-10-07 07:31:10 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:31:10 --> Helper loaded: security_helper
INFO - 2023-10-07 07:31:10 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:31:10 --> Database Driver Class Initialized
INFO - 2023-10-07 07:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:31:10 --> Parser Class Initialized
INFO - 2023-10-07 07:31:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:31:10 --> Pagination Class Initialized
INFO - 2023-10-07 07:31:10 --> Form Validation Class Initialized
INFO - 2023-10-07 07:31:10 --> Controller Class Initialized
INFO - 2023-10-07 07:31:10 --> Model Class Initialized
DEBUG - 2023-10-07 07:31:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:31:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:31:10 --> Model Class Initialized
DEBUG - 2023-10-07 07:31:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:31:10 --> Model Class Initialized
INFO - 2023-10-07 07:31:10 --> Final output sent to browser
DEBUG - 2023-10-07 07:31:10 --> Total execution time: 0.0218
ERROR - 2023-10-07 07:31:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:31:10 --> Config Class Initialized
INFO - 2023-10-07 07:31:10 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:31:10 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:31:10 --> Utf8 Class Initialized
INFO - 2023-10-07 07:31:10 --> URI Class Initialized
INFO - 2023-10-07 07:31:10 --> Router Class Initialized
INFO - 2023-10-07 07:31:10 --> Output Class Initialized
INFO - 2023-10-07 07:31:10 --> Security Class Initialized
DEBUG - 2023-10-07 07:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:31:10 --> Input Class Initialized
INFO - 2023-10-07 07:31:10 --> Language Class Initialized
INFO - 2023-10-07 07:31:10 --> Loader Class Initialized
INFO - 2023-10-07 07:31:10 --> Helper loaded: url_helper
INFO - 2023-10-07 07:31:10 --> Helper loaded: file_helper
INFO - 2023-10-07 07:31:10 --> Helper loaded: html_helper
INFO - 2023-10-07 07:31:10 --> Helper loaded: text_helper
INFO - 2023-10-07 07:31:10 --> Helper loaded: form_helper
INFO - 2023-10-07 07:31:10 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:31:10 --> Helper loaded: security_helper
INFO - 2023-10-07 07:31:10 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:31:10 --> Database Driver Class Initialized
INFO - 2023-10-07 07:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:31:10 --> Parser Class Initialized
INFO - 2023-10-07 07:31:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:31:10 --> Pagination Class Initialized
INFO - 2023-10-07 07:31:10 --> Form Validation Class Initialized
INFO - 2023-10-07 07:31:10 --> Controller Class Initialized
INFO - 2023-10-07 07:31:10 --> Model Class Initialized
DEBUG - 2023-10-07 07:31:10 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:31:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:31:10 --> Model Class Initialized
DEBUG - 2023-10-07 07:31:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:31:10 --> Model Class Initialized
INFO - 2023-10-07 07:31:10 --> Final output sent to browser
DEBUG - 2023-10-07 07:31:10 --> Total execution time: 0.0232
ERROR - 2023-10-07 07:31:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:31:11 --> Config Class Initialized
INFO - 2023-10-07 07:31:11 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:31:11 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:31:11 --> Utf8 Class Initialized
INFO - 2023-10-07 07:31:11 --> URI Class Initialized
INFO - 2023-10-07 07:31:11 --> Router Class Initialized
INFO - 2023-10-07 07:31:11 --> Output Class Initialized
INFO - 2023-10-07 07:31:11 --> Security Class Initialized
DEBUG - 2023-10-07 07:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:31:11 --> Input Class Initialized
INFO - 2023-10-07 07:31:11 --> Language Class Initialized
INFO - 2023-10-07 07:31:11 --> Loader Class Initialized
INFO - 2023-10-07 07:31:11 --> Helper loaded: url_helper
INFO - 2023-10-07 07:31:11 --> Helper loaded: file_helper
INFO - 2023-10-07 07:31:11 --> Helper loaded: html_helper
INFO - 2023-10-07 07:31:11 --> Helper loaded: text_helper
INFO - 2023-10-07 07:31:11 --> Helper loaded: form_helper
INFO - 2023-10-07 07:31:11 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:31:11 --> Helper loaded: security_helper
INFO - 2023-10-07 07:31:11 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:31:11 --> Database Driver Class Initialized
INFO - 2023-10-07 07:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:31:11 --> Parser Class Initialized
INFO - 2023-10-07 07:31:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:31:11 --> Pagination Class Initialized
INFO - 2023-10-07 07:31:11 --> Form Validation Class Initialized
INFO - 2023-10-07 07:31:11 --> Controller Class Initialized
INFO - 2023-10-07 07:31:11 --> Model Class Initialized
DEBUG - 2023-10-07 07:31:11 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:31:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:31:11 --> Model Class Initialized
INFO - 2023-10-07 07:31:11 --> Model Class Initialized
INFO - 2023-10-07 07:31:11 --> Final output sent to browser
DEBUG - 2023-10-07 07:31:11 --> Total execution time: 0.0190
ERROR - 2023-10-07 07:31:13 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:31:13 --> Config Class Initialized
INFO - 2023-10-07 07:31:13 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:31:13 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:31:13 --> Utf8 Class Initialized
INFO - 2023-10-07 07:31:13 --> URI Class Initialized
INFO - 2023-10-07 07:31:13 --> Router Class Initialized
INFO - 2023-10-07 07:31:13 --> Output Class Initialized
INFO - 2023-10-07 07:31:13 --> Security Class Initialized
DEBUG - 2023-10-07 07:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:31:13 --> Input Class Initialized
INFO - 2023-10-07 07:31:13 --> Language Class Initialized
INFO - 2023-10-07 07:31:13 --> Loader Class Initialized
INFO - 2023-10-07 07:31:13 --> Helper loaded: url_helper
INFO - 2023-10-07 07:31:13 --> Helper loaded: file_helper
INFO - 2023-10-07 07:31:13 --> Helper loaded: html_helper
INFO - 2023-10-07 07:31:13 --> Helper loaded: text_helper
INFO - 2023-10-07 07:31:13 --> Helper loaded: form_helper
INFO - 2023-10-07 07:31:13 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:31:13 --> Helper loaded: security_helper
INFO - 2023-10-07 07:31:13 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:31:13 --> Database Driver Class Initialized
INFO - 2023-10-07 07:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:31:13 --> Parser Class Initialized
INFO - 2023-10-07 07:31:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:31:13 --> Pagination Class Initialized
INFO - 2023-10-07 07:31:13 --> Form Validation Class Initialized
INFO - 2023-10-07 07:31:13 --> Controller Class Initialized
INFO - 2023-10-07 07:31:13 --> Model Class Initialized
DEBUG - 2023-10-07 07:31:13 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:31:13 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:31:13 --> Model Class Initialized
INFO - 2023-10-07 07:31:13 --> Final output sent to browser
DEBUG - 2023-10-07 07:31:13 --> Total execution time: 0.0156
ERROR - 2023-10-07 07:31:37 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:31:37 --> Config Class Initialized
INFO - 2023-10-07 07:31:37 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:31:37 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:31:37 --> Utf8 Class Initialized
INFO - 2023-10-07 07:31:37 --> URI Class Initialized
INFO - 2023-10-07 07:31:37 --> Router Class Initialized
INFO - 2023-10-07 07:31:37 --> Output Class Initialized
INFO - 2023-10-07 07:31:37 --> Security Class Initialized
DEBUG - 2023-10-07 07:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:31:37 --> Input Class Initialized
INFO - 2023-10-07 07:31:37 --> Language Class Initialized
INFO - 2023-10-07 07:31:37 --> Loader Class Initialized
INFO - 2023-10-07 07:31:37 --> Helper loaded: url_helper
INFO - 2023-10-07 07:31:37 --> Helper loaded: file_helper
INFO - 2023-10-07 07:31:37 --> Helper loaded: html_helper
INFO - 2023-10-07 07:31:37 --> Helper loaded: text_helper
INFO - 2023-10-07 07:31:37 --> Helper loaded: form_helper
INFO - 2023-10-07 07:31:37 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:31:37 --> Helper loaded: security_helper
INFO - 2023-10-07 07:31:37 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:31:37 --> Database Driver Class Initialized
INFO - 2023-10-07 07:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:31:37 --> Parser Class Initialized
INFO - 2023-10-07 07:31:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:31:37 --> Pagination Class Initialized
INFO - 2023-10-07 07:31:37 --> Form Validation Class Initialized
INFO - 2023-10-07 07:31:37 --> Controller Class Initialized
INFO - 2023-10-07 07:31:37 --> Model Class Initialized
DEBUG - 2023-10-07 07:31:37 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:31:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:31:37 --> Model Class Initialized
DEBUG - 2023-10-07 07:31:37 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:31:37 --> Model Class Initialized
INFO - 2023-10-07 07:31:37 --> Final output sent to browser
DEBUG - 2023-10-07 07:31:37 --> Total execution time: 0.1408
ERROR - 2023-10-07 07:31:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:31:38 --> Config Class Initialized
INFO - 2023-10-07 07:31:38 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:31:38 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:31:38 --> Utf8 Class Initialized
INFO - 2023-10-07 07:31:38 --> URI Class Initialized
INFO - 2023-10-07 07:31:38 --> Router Class Initialized
INFO - 2023-10-07 07:31:38 --> Output Class Initialized
INFO - 2023-10-07 07:31:38 --> Security Class Initialized
DEBUG - 2023-10-07 07:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:31:38 --> Input Class Initialized
INFO - 2023-10-07 07:31:38 --> Language Class Initialized
INFO - 2023-10-07 07:31:38 --> Loader Class Initialized
INFO - 2023-10-07 07:31:38 --> Helper loaded: url_helper
INFO - 2023-10-07 07:31:38 --> Helper loaded: file_helper
INFO - 2023-10-07 07:31:38 --> Helper loaded: html_helper
INFO - 2023-10-07 07:31:38 --> Helper loaded: text_helper
INFO - 2023-10-07 07:31:38 --> Helper loaded: form_helper
INFO - 2023-10-07 07:31:38 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:31:38 --> Helper loaded: security_helper
INFO - 2023-10-07 07:31:38 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:31:38 --> Database Driver Class Initialized
INFO - 2023-10-07 07:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:31:38 --> Parser Class Initialized
INFO - 2023-10-07 07:31:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:31:38 --> Pagination Class Initialized
INFO - 2023-10-07 07:31:38 --> Form Validation Class Initialized
INFO - 2023-10-07 07:31:38 --> Controller Class Initialized
INFO - 2023-10-07 07:31:38 --> Model Class Initialized
DEBUG - 2023-10-07 07:31:38 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:31:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:31:38 --> Model Class Initialized
DEBUG - 2023-10-07 07:31:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:31:38 --> Model Class Initialized
INFO - 2023-10-07 07:31:38 --> Final output sent to browser
DEBUG - 2023-10-07 07:31:38 --> Total execution time: 0.1386
ERROR - 2023-10-07 07:31:39 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:31:39 --> Config Class Initialized
INFO - 2023-10-07 07:31:39 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:31:39 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:31:39 --> Utf8 Class Initialized
INFO - 2023-10-07 07:31:39 --> URI Class Initialized
INFO - 2023-10-07 07:31:39 --> Router Class Initialized
INFO - 2023-10-07 07:31:39 --> Output Class Initialized
INFO - 2023-10-07 07:31:39 --> Security Class Initialized
DEBUG - 2023-10-07 07:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:31:39 --> Input Class Initialized
INFO - 2023-10-07 07:31:39 --> Language Class Initialized
INFO - 2023-10-07 07:31:39 --> Loader Class Initialized
INFO - 2023-10-07 07:31:39 --> Helper loaded: url_helper
INFO - 2023-10-07 07:31:39 --> Helper loaded: file_helper
INFO - 2023-10-07 07:31:39 --> Helper loaded: html_helper
INFO - 2023-10-07 07:31:39 --> Helper loaded: text_helper
INFO - 2023-10-07 07:31:39 --> Helper loaded: form_helper
INFO - 2023-10-07 07:31:39 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:31:39 --> Helper loaded: security_helper
INFO - 2023-10-07 07:31:39 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:31:39 --> Database Driver Class Initialized
INFO - 2023-10-07 07:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:31:39 --> Parser Class Initialized
INFO - 2023-10-07 07:31:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:31:39 --> Pagination Class Initialized
INFO - 2023-10-07 07:31:39 --> Form Validation Class Initialized
INFO - 2023-10-07 07:31:39 --> Controller Class Initialized
INFO - 2023-10-07 07:31:39 --> Model Class Initialized
DEBUG - 2023-10-07 07:31:39 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:31:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:31:39 --> Model Class Initialized
DEBUG - 2023-10-07 07:31:39 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:31:39 --> Model Class Initialized
INFO - 2023-10-07 07:31:39 --> Final output sent to browser
DEBUG - 2023-10-07 07:31:39 --> Total execution time: 0.1412
ERROR - 2023-10-07 07:31:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:31:40 --> Config Class Initialized
INFO - 2023-10-07 07:31:40 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:31:40 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:31:40 --> Utf8 Class Initialized
INFO - 2023-10-07 07:31:40 --> URI Class Initialized
INFO - 2023-10-07 07:31:40 --> Router Class Initialized
INFO - 2023-10-07 07:31:40 --> Output Class Initialized
INFO - 2023-10-07 07:31:40 --> Security Class Initialized
DEBUG - 2023-10-07 07:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:31:40 --> Input Class Initialized
INFO - 2023-10-07 07:31:40 --> Language Class Initialized
INFO - 2023-10-07 07:31:40 --> Loader Class Initialized
INFO - 2023-10-07 07:31:40 --> Helper loaded: url_helper
INFO - 2023-10-07 07:31:40 --> Helper loaded: file_helper
INFO - 2023-10-07 07:31:40 --> Helper loaded: html_helper
INFO - 2023-10-07 07:31:40 --> Helper loaded: text_helper
INFO - 2023-10-07 07:31:40 --> Helper loaded: form_helper
INFO - 2023-10-07 07:31:40 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:31:40 --> Helper loaded: security_helper
INFO - 2023-10-07 07:31:40 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:31:40 --> Database Driver Class Initialized
INFO - 2023-10-07 07:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:31:40 --> Parser Class Initialized
INFO - 2023-10-07 07:31:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:31:40 --> Pagination Class Initialized
INFO - 2023-10-07 07:31:40 --> Form Validation Class Initialized
INFO - 2023-10-07 07:31:40 --> Controller Class Initialized
INFO - 2023-10-07 07:31:40 --> Model Class Initialized
DEBUG - 2023-10-07 07:31:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:31:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:31:40 --> Model Class Initialized
DEBUG - 2023-10-07 07:31:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:31:40 --> Model Class Initialized
INFO - 2023-10-07 07:31:40 --> Final output sent to browser
DEBUG - 2023-10-07 07:31:40 --> Total execution time: 0.0511
ERROR - 2023-10-07 07:31:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:31:42 --> Config Class Initialized
INFO - 2023-10-07 07:31:42 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:31:42 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:31:42 --> Utf8 Class Initialized
INFO - 2023-10-07 07:31:42 --> URI Class Initialized
INFO - 2023-10-07 07:31:42 --> Router Class Initialized
INFO - 2023-10-07 07:31:42 --> Output Class Initialized
INFO - 2023-10-07 07:31:42 --> Security Class Initialized
DEBUG - 2023-10-07 07:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:31:42 --> Input Class Initialized
INFO - 2023-10-07 07:31:42 --> Language Class Initialized
INFO - 2023-10-07 07:31:42 --> Loader Class Initialized
INFO - 2023-10-07 07:31:42 --> Helper loaded: url_helper
INFO - 2023-10-07 07:31:42 --> Helper loaded: file_helper
INFO - 2023-10-07 07:31:42 --> Helper loaded: html_helper
INFO - 2023-10-07 07:31:42 --> Helper loaded: text_helper
INFO - 2023-10-07 07:31:42 --> Helper loaded: form_helper
INFO - 2023-10-07 07:31:42 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:31:42 --> Helper loaded: security_helper
INFO - 2023-10-07 07:31:42 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:31:42 --> Database Driver Class Initialized
INFO - 2023-10-07 07:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:31:42 --> Parser Class Initialized
INFO - 2023-10-07 07:31:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:31:42 --> Pagination Class Initialized
INFO - 2023-10-07 07:31:42 --> Form Validation Class Initialized
INFO - 2023-10-07 07:31:42 --> Controller Class Initialized
INFO - 2023-10-07 07:31:42 --> Model Class Initialized
DEBUG - 2023-10-07 07:31:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:31:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:31:42 --> Model Class Initialized
INFO - 2023-10-07 07:31:42 --> Model Class Initialized
INFO - 2023-10-07 07:31:42 --> Final output sent to browser
DEBUG - 2023-10-07 07:31:42 --> Total execution time: 0.0209
ERROR - 2023-10-07 07:31:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:31:45 --> Config Class Initialized
INFO - 2023-10-07 07:31:45 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:31:45 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:31:45 --> Utf8 Class Initialized
INFO - 2023-10-07 07:31:45 --> URI Class Initialized
INFO - 2023-10-07 07:31:45 --> Router Class Initialized
INFO - 2023-10-07 07:31:45 --> Output Class Initialized
INFO - 2023-10-07 07:31:45 --> Security Class Initialized
DEBUG - 2023-10-07 07:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:31:45 --> Input Class Initialized
INFO - 2023-10-07 07:31:45 --> Language Class Initialized
INFO - 2023-10-07 07:31:45 --> Loader Class Initialized
INFO - 2023-10-07 07:31:45 --> Helper loaded: url_helper
INFO - 2023-10-07 07:31:45 --> Helper loaded: file_helper
INFO - 2023-10-07 07:31:45 --> Helper loaded: html_helper
INFO - 2023-10-07 07:31:45 --> Helper loaded: text_helper
INFO - 2023-10-07 07:31:45 --> Helper loaded: form_helper
INFO - 2023-10-07 07:31:45 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:31:45 --> Helper loaded: security_helper
INFO - 2023-10-07 07:31:45 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:31:45 --> Database Driver Class Initialized
INFO - 2023-10-07 07:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:31:45 --> Parser Class Initialized
INFO - 2023-10-07 07:31:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:31:45 --> Pagination Class Initialized
INFO - 2023-10-07 07:31:45 --> Form Validation Class Initialized
INFO - 2023-10-07 07:31:45 --> Controller Class Initialized
INFO - 2023-10-07 07:31:45 --> Model Class Initialized
DEBUG - 2023-10-07 07:31:45 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:31:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:31:45 --> Model Class Initialized
INFO - 2023-10-07 07:31:45 --> Final output sent to browser
DEBUG - 2023-10-07 07:31:45 --> Total execution time: 0.0152
ERROR - 2023-10-07 07:32:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:32:01 --> Config Class Initialized
INFO - 2023-10-07 07:32:01 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:32:01 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:32:01 --> Utf8 Class Initialized
INFO - 2023-10-07 07:32:01 --> URI Class Initialized
INFO - 2023-10-07 07:32:01 --> Router Class Initialized
INFO - 2023-10-07 07:32:01 --> Output Class Initialized
INFO - 2023-10-07 07:32:01 --> Security Class Initialized
DEBUG - 2023-10-07 07:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:32:01 --> Input Class Initialized
INFO - 2023-10-07 07:32:01 --> Language Class Initialized
INFO - 2023-10-07 07:32:01 --> Loader Class Initialized
INFO - 2023-10-07 07:32:01 --> Helper loaded: url_helper
INFO - 2023-10-07 07:32:01 --> Helper loaded: file_helper
INFO - 2023-10-07 07:32:01 --> Helper loaded: html_helper
INFO - 2023-10-07 07:32:01 --> Helper loaded: text_helper
INFO - 2023-10-07 07:32:01 --> Helper loaded: form_helper
INFO - 2023-10-07 07:32:01 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:32:01 --> Helper loaded: security_helper
INFO - 2023-10-07 07:32:01 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:32:01 --> Database Driver Class Initialized
INFO - 2023-10-07 07:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:32:01 --> Parser Class Initialized
INFO - 2023-10-07 07:32:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:32:01 --> Pagination Class Initialized
INFO - 2023-10-07 07:32:01 --> Form Validation Class Initialized
INFO - 2023-10-07 07:32:01 --> Controller Class Initialized
INFO - 2023-10-07 07:32:01 --> Model Class Initialized
DEBUG - 2023-10-07 07:32:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:32:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:32:01 --> Model Class Initialized
DEBUG - 2023-10-07 07:32:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:32:01 --> Model Class Initialized
INFO - 2023-10-07 07:32:01 --> Final output sent to browser
DEBUG - 2023-10-07 07:32:01 --> Total execution time: 0.0231
ERROR - 2023-10-07 07:32:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:32:05 --> Config Class Initialized
INFO - 2023-10-07 07:32:05 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:32:05 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:32:05 --> Utf8 Class Initialized
INFO - 2023-10-07 07:32:05 --> URI Class Initialized
INFO - 2023-10-07 07:32:05 --> Router Class Initialized
INFO - 2023-10-07 07:32:05 --> Output Class Initialized
INFO - 2023-10-07 07:32:05 --> Security Class Initialized
DEBUG - 2023-10-07 07:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:32:05 --> Input Class Initialized
INFO - 2023-10-07 07:32:05 --> Language Class Initialized
INFO - 2023-10-07 07:32:05 --> Loader Class Initialized
INFO - 2023-10-07 07:32:05 --> Helper loaded: url_helper
INFO - 2023-10-07 07:32:05 --> Helper loaded: file_helper
INFO - 2023-10-07 07:32:05 --> Helper loaded: html_helper
INFO - 2023-10-07 07:32:05 --> Helper loaded: text_helper
INFO - 2023-10-07 07:32:05 --> Helper loaded: form_helper
INFO - 2023-10-07 07:32:05 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:32:05 --> Helper loaded: security_helper
INFO - 2023-10-07 07:32:05 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:32:05 --> Database Driver Class Initialized
INFO - 2023-10-07 07:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:32:05 --> Parser Class Initialized
INFO - 2023-10-07 07:32:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:32:05 --> Pagination Class Initialized
INFO - 2023-10-07 07:32:05 --> Form Validation Class Initialized
INFO - 2023-10-07 07:32:05 --> Controller Class Initialized
INFO - 2023-10-07 07:32:05 --> Model Class Initialized
DEBUG - 2023-10-07 07:32:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:32:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:32:05 --> Model Class Initialized
DEBUG - 2023-10-07 07:32:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:32:05 --> Model Class Initialized
INFO - 2023-10-07 07:32:05 --> Final output sent to browser
DEBUG - 2023-10-07 07:32:05 --> Total execution time: 0.0213
ERROR - 2023-10-07 07:32:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:32:06 --> Config Class Initialized
INFO - 2023-10-07 07:32:06 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:32:06 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:32:06 --> Utf8 Class Initialized
INFO - 2023-10-07 07:32:06 --> URI Class Initialized
INFO - 2023-10-07 07:32:06 --> Router Class Initialized
INFO - 2023-10-07 07:32:06 --> Output Class Initialized
INFO - 2023-10-07 07:32:06 --> Security Class Initialized
DEBUG - 2023-10-07 07:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:32:06 --> Input Class Initialized
INFO - 2023-10-07 07:32:06 --> Language Class Initialized
INFO - 2023-10-07 07:32:06 --> Loader Class Initialized
INFO - 2023-10-07 07:32:06 --> Helper loaded: url_helper
INFO - 2023-10-07 07:32:06 --> Helper loaded: file_helper
INFO - 2023-10-07 07:32:06 --> Helper loaded: html_helper
INFO - 2023-10-07 07:32:06 --> Helper loaded: text_helper
INFO - 2023-10-07 07:32:06 --> Helper loaded: form_helper
INFO - 2023-10-07 07:32:06 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:32:06 --> Helper loaded: security_helper
INFO - 2023-10-07 07:32:06 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:32:06 --> Database Driver Class Initialized
INFO - 2023-10-07 07:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:32:06 --> Parser Class Initialized
INFO - 2023-10-07 07:32:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:32:06 --> Pagination Class Initialized
INFO - 2023-10-07 07:32:06 --> Form Validation Class Initialized
INFO - 2023-10-07 07:32:06 --> Controller Class Initialized
INFO - 2023-10-07 07:32:06 --> Model Class Initialized
DEBUG - 2023-10-07 07:32:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:32:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:32:06 --> Model Class Initialized
DEBUG - 2023-10-07 07:32:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:32:06 --> Model Class Initialized
INFO - 2023-10-07 07:32:06 --> Final output sent to browser
DEBUG - 2023-10-07 07:32:06 --> Total execution time: 0.0259
ERROR - 2023-10-07 07:32:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:32:06 --> Config Class Initialized
INFO - 2023-10-07 07:32:06 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:32:06 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:32:06 --> Utf8 Class Initialized
INFO - 2023-10-07 07:32:06 --> URI Class Initialized
INFO - 2023-10-07 07:32:06 --> Router Class Initialized
INFO - 2023-10-07 07:32:06 --> Output Class Initialized
INFO - 2023-10-07 07:32:06 --> Security Class Initialized
DEBUG - 2023-10-07 07:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:32:06 --> Input Class Initialized
INFO - 2023-10-07 07:32:06 --> Language Class Initialized
INFO - 2023-10-07 07:32:06 --> Loader Class Initialized
INFO - 2023-10-07 07:32:06 --> Helper loaded: url_helper
INFO - 2023-10-07 07:32:06 --> Helper loaded: file_helper
INFO - 2023-10-07 07:32:06 --> Helper loaded: html_helper
INFO - 2023-10-07 07:32:06 --> Helper loaded: text_helper
INFO - 2023-10-07 07:32:06 --> Helper loaded: form_helper
INFO - 2023-10-07 07:32:06 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:32:06 --> Helper loaded: security_helper
INFO - 2023-10-07 07:32:06 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:32:06 --> Database Driver Class Initialized
INFO - 2023-10-07 07:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:32:06 --> Parser Class Initialized
INFO - 2023-10-07 07:32:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:32:06 --> Pagination Class Initialized
INFO - 2023-10-07 07:32:06 --> Form Validation Class Initialized
INFO - 2023-10-07 07:32:06 --> Controller Class Initialized
INFO - 2023-10-07 07:32:06 --> Model Class Initialized
DEBUG - 2023-10-07 07:32:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:32:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:32:06 --> Model Class Initialized
INFO - 2023-10-07 07:32:06 --> Model Class Initialized
INFO - 2023-10-07 07:32:06 --> Final output sent to browser
DEBUG - 2023-10-07 07:32:06 --> Total execution time: 0.0201
ERROR - 2023-10-07 07:32:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:32:09 --> Config Class Initialized
INFO - 2023-10-07 07:32:09 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:32:09 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:32:09 --> Utf8 Class Initialized
INFO - 2023-10-07 07:32:09 --> URI Class Initialized
INFO - 2023-10-07 07:32:09 --> Router Class Initialized
INFO - 2023-10-07 07:32:09 --> Output Class Initialized
INFO - 2023-10-07 07:32:09 --> Security Class Initialized
DEBUG - 2023-10-07 07:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:32:09 --> Input Class Initialized
INFO - 2023-10-07 07:32:09 --> Language Class Initialized
INFO - 2023-10-07 07:32:09 --> Loader Class Initialized
INFO - 2023-10-07 07:32:09 --> Helper loaded: url_helper
INFO - 2023-10-07 07:32:09 --> Helper loaded: file_helper
INFO - 2023-10-07 07:32:09 --> Helper loaded: html_helper
INFO - 2023-10-07 07:32:09 --> Helper loaded: text_helper
INFO - 2023-10-07 07:32:09 --> Helper loaded: form_helper
INFO - 2023-10-07 07:32:09 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:32:09 --> Helper loaded: security_helper
INFO - 2023-10-07 07:32:09 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:32:09 --> Database Driver Class Initialized
INFO - 2023-10-07 07:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:32:09 --> Parser Class Initialized
INFO - 2023-10-07 07:32:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:32:09 --> Pagination Class Initialized
INFO - 2023-10-07 07:32:09 --> Form Validation Class Initialized
INFO - 2023-10-07 07:32:09 --> Controller Class Initialized
INFO - 2023-10-07 07:32:09 --> Model Class Initialized
DEBUG - 2023-10-07 07:32:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:32:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:32:09 --> Model Class Initialized
INFO - 2023-10-07 07:32:09 --> Final output sent to browser
DEBUG - 2023-10-07 07:32:09 --> Total execution time: 0.0222
ERROR - 2023-10-07 07:33:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:33:21 --> Config Class Initialized
INFO - 2023-10-07 07:33:21 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:33:21 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:33:21 --> Utf8 Class Initialized
INFO - 2023-10-07 07:33:21 --> URI Class Initialized
INFO - 2023-10-07 07:33:21 --> Router Class Initialized
INFO - 2023-10-07 07:33:21 --> Output Class Initialized
INFO - 2023-10-07 07:33:21 --> Security Class Initialized
DEBUG - 2023-10-07 07:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:33:21 --> Input Class Initialized
INFO - 2023-10-07 07:33:21 --> Language Class Initialized
INFO - 2023-10-07 07:33:21 --> Loader Class Initialized
INFO - 2023-10-07 07:33:21 --> Helper loaded: url_helper
INFO - 2023-10-07 07:33:21 --> Helper loaded: file_helper
INFO - 2023-10-07 07:33:21 --> Helper loaded: html_helper
INFO - 2023-10-07 07:33:21 --> Helper loaded: text_helper
INFO - 2023-10-07 07:33:21 --> Helper loaded: form_helper
INFO - 2023-10-07 07:33:21 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:33:21 --> Helper loaded: security_helper
INFO - 2023-10-07 07:33:21 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:33:21 --> Database Driver Class Initialized
INFO - 2023-10-07 07:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:33:21 --> Parser Class Initialized
INFO - 2023-10-07 07:33:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:33:21 --> Pagination Class Initialized
INFO - 2023-10-07 07:33:21 --> Form Validation Class Initialized
INFO - 2023-10-07 07:33:21 --> Controller Class Initialized
INFO - 2023-10-07 07:33:21 --> Model Class Initialized
DEBUG - 2023-10-07 07:33:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:33:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:33:21 --> Model Class Initialized
DEBUG - 2023-10-07 07:33:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:33:21 --> Model Class Initialized
INFO - 2023-10-07 07:33:21 --> Email Class Initialized
DEBUG - 2023-10-07 07:33:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:33:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html_pdf.php
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 743
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/dompdf.cls.php 763
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/stylesheet.cls.php 1102
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/page_frame_decorator.cls.php 439
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> Division by zero /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 572
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/table_cell_frame_reflower.cls.php 103
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/cellmap.cls.php 709
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/text_renderer.cls.php 126
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
ERROR - 2023-10-07 07:33:21 --> Severity: Warning --> A non-numeric value encountered /home/powera7m/app.maurnaturo.com/vendor/dompdf/dompdf/include/style.cls.php 1280
INFO - 2023-10-07 07:33:21 --> Language file loaded: language/english/email_lang.php
INFO - 2023-10-07 07:33:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
INFO - 2023-10-07 07:33:21 --> Final output sent to browser
DEBUG - 2023-10-07 07:33:21 --> Total execution time: 0.5210
ERROR - 2023-10-07 07:33:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:33:23 --> Config Class Initialized
INFO - 2023-10-07 07:33:23 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:33:23 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:33:23 --> Utf8 Class Initialized
INFO - 2023-10-07 07:33:23 --> URI Class Initialized
INFO - 2023-10-07 07:33:23 --> Router Class Initialized
INFO - 2023-10-07 07:33:23 --> Output Class Initialized
INFO - 2023-10-07 07:33:23 --> Security Class Initialized
DEBUG - 2023-10-07 07:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:33:23 --> Input Class Initialized
INFO - 2023-10-07 07:33:23 --> Language Class Initialized
INFO - 2023-10-07 07:33:23 --> Loader Class Initialized
INFO - 2023-10-07 07:33:23 --> Helper loaded: url_helper
INFO - 2023-10-07 07:33:23 --> Helper loaded: file_helper
INFO - 2023-10-07 07:33:23 --> Helper loaded: html_helper
INFO - 2023-10-07 07:33:23 --> Helper loaded: text_helper
INFO - 2023-10-07 07:33:23 --> Helper loaded: form_helper
INFO - 2023-10-07 07:33:23 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:33:23 --> Helper loaded: security_helper
INFO - 2023-10-07 07:33:23 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:33:23 --> Database Driver Class Initialized
INFO - 2023-10-07 07:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:33:23 --> Parser Class Initialized
INFO - 2023-10-07 07:33:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:33:23 --> Pagination Class Initialized
INFO - 2023-10-07 07:33:23 --> Form Validation Class Initialized
INFO - 2023-10-07 07:33:23 --> Controller Class Initialized
INFO - 2023-10-07 07:33:23 --> Model Class Initialized
DEBUG - 2023-10-07 07:33:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:33:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:33:23 --> Model Class Initialized
DEBUG - 2023-10-07 07:33:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:33:23 --> Model Class Initialized
INFO - 2023-10-07 07:33:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-10-07 07:33:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:33:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:33:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:33:23 --> Model Class Initialized
INFO - 2023-10-07 07:33:23 --> Model Class Initialized
INFO - 2023-10-07 07:33:23 --> Model Class Initialized
INFO - 2023-10-07 07:33:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 07:33:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 07:33:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:33:23 --> Final output sent to browser
DEBUG - 2023-10-07 07:33:23 --> Total execution time: 0.1108
ERROR - 2023-10-07 07:33:36 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:33:36 --> Config Class Initialized
INFO - 2023-10-07 07:33:36 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:33:36 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:33:36 --> Utf8 Class Initialized
INFO - 2023-10-07 07:33:36 --> URI Class Initialized
DEBUG - 2023-10-07 07:33:36 --> No URI present. Default controller set.
INFO - 2023-10-07 07:33:36 --> Router Class Initialized
INFO - 2023-10-07 07:33:36 --> Output Class Initialized
INFO - 2023-10-07 07:33:36 --> Security Class Initialized
DEBUG - 2023-10-07 07:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:33:36 --> Input Class Initialized
INFO - 2023-10-07 07:33:36 --> Language Class Initialized
INFO - 2023-10-07 07:33:36 --> Loader Class Initialized
INFO - 2023-10-07 07:33:36 --> Helper loaded: url_helper
INFO - 2023-10-07 07:33:36 --> Helper loaded: file_helper
INFO - 2023-10-07 07:33:36 --> Helper loaded: html_helper
INFO - 2023-10-07 07:33:36 --> Helper loaded: text_helper
INFO - 2023-10-07 07:33:36 --> Helper loaded: form_helper
INFO - 2023-10-07 07:33:36 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:33:36 --> Helper loaded: security_helper
INFO - 2023-10-07 07:33:36 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:33:36 --> Database Driver Class Initialized
INFO - 2023-10-07 07:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:33:36 --> Parser Class Initialized
INFO - 2023-10-07 07:33:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:33:36 --> Pagination Class Initialized
INFO - 2023-10-07 07:33:36 --> Form Validation Class Initialized
INFO - 2023-10-07 07:33:36 --> Controller Class Initialized
INFO - 2023-10-07 07:33:36 --> Model Class Initialized
DEBUG - 2023-10-07 07:33:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:33:36 --> Model Class Initialized
DEBUG - 2023-10-07 07:33:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:33:36 --> Model Class Initialized
INFO - 2023-10-07 07:33:36 --> Model Class Initialized
INFO - 2023-10-07 07:33:36 --> Model Class Initialized
INFO - 2023-10-07 07:33:36 --> Model Class Initialized
DEBUG - 2023-10-07 07:33:36 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:33:36 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:33:36 --> Model Class Initialized
INFO - 2023-10-07 07:33:36 --> Model Class Initialized
INFO - 2023-10-07 07:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 07:33:36 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:33:36 --> Model Class Initialized
INFO - 2023-10-07 07:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 07:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 07:33:36 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:33:36 --> Final output sent to browser
DEBUG - 2023-10-07 07:33:36 --> Total execution time: 0.1238
ERROR - 2023-10-07 07:35:44 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:35:44 --> Config Class Initialized
INFO - 2023-10-07 07:35:44 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:35:44 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:35:44 --> Utf8 Class Initialized
INFO - 2023-10-07 07:35:44 --> URI Class Initialized
DEBUG - 2023-10-07 07:35:44 --> No URI present. Default controller set.
INFO - 2023-10-07 07:35:44 --> Router Class Initialized
INFO - 2023-10-07 07:35:44 --> Output Class Initialized
INFO - 2023-10-07 07:35:44 --> Security Class Initialized
DEBUG - 2023-10-07 07:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:35:44 --> Input Class Initialized
INFO - 2023-10-07 07:35:44 --> Language Class Initialized
INFO - 2023-10-07 07:35:44 --> Loader Class Initialized
INFO - 2023-10-07 07:35:44 --> Helper loaded: url_helper
INFO - 2023-10-07 07:35:44 --> Helper loaded: file_helper
INFO - 2023-10-07 07:35:44 --> Helper loaded: html_helper
INFO - 2023-10-07 07:35:44 --> Helper loaded: text_helper
INFO - 2023-10-07 07:35:44 --> Helper loaded: form_helper
INFO - 2023-10-07 07:35:44 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:35:44 --> Helper loaded: security_helper
INFO - 2023-10-07 07:35:44 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:35:44 --> Database Driver Class Initialized
INFO - 2023-10-07 07:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:35:44 --> Parser Class Initialized
INFO - 2023-10-07 07:35:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:35:44 --> Pagination Class Initialized
INFO - 2023-10-07 07:35:44 --> Form Validation Class Initialized
INFO - 2023-10-07 07:35:44 --> Controller Class Initialized
INFO - 2023-10-07 07:35:44 --> Model Class Initialized
DEBUG - 2023-10-07 07:35:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-07 07:35:45 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:35:45 --> Config Class Initialized
INFO - 2023-10-07 07:35:45 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:35:45 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:35:45 --> Utf8 Class Initialized
INFO - 2023-10-07 07:35:45 --> URI Class Initialized
INFO - 2023-10-07 07:35:45 --> Router Class Initialized
INFO - 2023-10-07 07:35:45 --> Output Class Initialized
INFO - 2023-10-07 07:35:45 --> Security Class Initialized
DEBUG - 2023-10-07 07:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:35:45 --> Input Class Initialized
INFO - 2023-10-07 07:35:45 --> Language Class Initialized
INFO - 2023-10-07 07:35:45 --> Loader Class Initialized
INFO - 2023-10-07 07:35:45 --> Helper loaded: url_helper
INFO - 2023-10-07 07:35:45 --> Helper loaded: file_helper
INFO - 2023-10-07 07:35:45 --> Helper loaded: html_helper
INFO - 2023-10-07 07:35:45 --> Helper loaded: text_helper
INFO - 2023-10-07 07:35:45 --> Helper loaded: form_helper
INFO - 2023-10-07 07:35:45 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:35:45 --> Helper loaded: security_helper
INFO - 2023-10-07 07:35:45 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:35:45 --> Database Driver Class Initialized
INFO - 2023-10-07 07:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:35:45 --> Parser Class Initialized
INFO - 2023-10-07 07:35:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:35:45 --> Pagination Class Initialized
INFO - 2023-10-07 07:35:45 --> Form Validation Class Initialized
INFO - 2023-10-07 07:35:45 --> Controller Class Initialized
INFO - 2023-10-07 07:35:45 --> Model Class Initialized
DEBUG - 2023-10-07 07:35:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:35:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-07 07:35:45 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:35:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:35:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:35:45 --> Model Class Initialized
INFO - 2023-10-07 07:35:45 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:35:45 --> Final output sent to browser
DEBUG - 2023-10-07 07:35:45 --> Total execution time: 0.0338
ERROR - 2023-10-07 07:35:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:35:50 --> Config Class Initialized
INFO - 2023-10-07 07:35:50 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:35:50 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:35:50 --> Utf8 Class Initialized
INFO - 2023-10-07 07:35:50 --> URI Class Initialized
INFO - 2023-10-07 07:35:50 --> Router Class Initialized
INFO - 2023-10-07 07:35:50 --> Output Class Initialized
INFO - 2023-10-07 07:35:50 --> Security Class Initialized
DEBUG - 2023-10-07 07:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:35:50 --> Input Class Initialized
INFO - 2023-10-07 07:35:50 --> Language Class Initialized
INFO - 2023-10-07 07:35:50 --> Loader Class Initialized
INFO - 2023-10-07 07:35:50 --> Helper loaded: url_helper
INFO - 2023-10-07 07:35:50 --> Helper loaded: file_helper
INFO - 2023-10-07 07:35:50 --> Helper loaded: html_helper
INFO - 2023-10-07 07:35:50 --> Helper loaded: text_helper
INFO - 2023-10-07 07:35:50 --> Helper loaded: form_helper
INFO - 2023-10-07 07:35:50 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:35:50 --> Helper loaded: security_helper
INFO - 2023-10-07 07:35:50 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:35:50 --> Database Driver Class Initialized
INFO - 2023-10-07 07:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:35:50 --> Parser Class Initialized
INFO - 2023-10-07 07:35:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:35:50 --> Pagination Class Initialized
INFO - 2023-10-07 07:35:50 --> Form Validation Class Initialized
INFO - 2023-10-07 07:35:50 --> Controller Class Initialized
INFO - 2023-10-07 07:35:50 --> Model Class Initialized
DEBUG - 2023-10-07 07:35:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:35:50 --> Model Class Initialized
INFO - 2023-10-07 07:35:50 --> Final output sent to browser
DEBUG - 2023-10-07 07:35:50 --> Total execution time: 0.0182
ERROR - 2023-10-07 07:35:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:35:50 --> Config Class Initialized
INFO - 2023-10-07 07:35:50 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:35:50 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:35:50 --> Utf8 Class Initialized
INFO - 2023-10-07 07:35:50 --> URI Class Initialized
DEBUG - 2023-10-07 07:35:50 --> No URI present. Default controller set.
INFO - 2023-10-07 07:35:50 --> Router Class Initialized
INFO - 2023-10-07 07:35:50 --> Output Class Initialized
INFO - 2023-10-07 07:35:50 --> Security Class Initialized
DEBUG - 2023-10-07 07:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:35:50 --> Input Class Initialized
INFO - 2023-10-07 07:35:50 --> Language Class Initialized
INFO - 2023-10-07 07:35:50 --> Loader Class Initialized
INFO - 2023-10-07 07:35:50 --> Helper loaded: url_helper
INFO - 2023-10-07 07:35:50 --> Helper loaded: file_helper
INFO - 2023-10-07 07:35:50 --> Helper loaded: html_helper
INFO - 2023-10-07 07:35:50 --> Helper loaded: text_helper
INFO - 2023-10-07 07:35:50 --> Helper loaded: form_helper
INFO - 2023-10-07 07:35:50 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:35:50 --> Helper loaded: security_helper
INFO - 2023-10-07 07:35:50 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:35:50 --> Database Driver Class Initialized
INFO - 2023-10-07 07:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:35:50 --> Parser Class Initialized
INFO - 2023-10-07 07:35:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:35:50 --> Pagination Class Initialized
INFO - 2023-10-07 07:35:50 --> Form Validation Class Initialized
INFO - 2023-10-07 07:35:50 --> Controller Class Initialized
INFO - 2023-10-07 07:35:50 --> Model Class Initialized
DEBUG - 2023-10-07 07:35:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:35:50 --> Model Class Initialized
DEBUG - 2023-10-07 07:35:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:35:50 --> Model Class Initialized
INFO - 2023-10-07 07:35:50 --> Model Class Initialized
INFO - 2023-10-07 07:35:50 --> Model Class Initialized
INFO - 2023-10-07 07:35:50 --> Model Class Initialized
DEBUG - 2023-10-07 07:35:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:35:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:35:50 --> Model Class Initialized
INFO - 2023-10-07 07:35:50 --> Model Class Initialized
INFO - 2023-10-07 07:35:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 07:35:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:35:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:35:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:35:50 --> Model Class Initialized
INFO - 2023-10-07 07:35:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 07:35:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 07:35:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:35:50 --> Final output sent to browser
DEBUG - 2023-10-07 07:35:50 --> Total execution time: 0.2458
ERROR - 2023-10-07 07:35:51 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:35:51 --> Config Class Initialized
INFO - 2023-10-07 07:35:51 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:35:51 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:35:51 --> Utf8 Class Initialized
INFO - 2023-10-07 07:35:51 --> URI Class Initialized
INFO - 2023-10-07 07:35:51 --> Router Class Initialized
INFO - 2023-10-07 07:35:51 --> Output Class Initialized
INFO - 2023-10-07 07:35:51 --> Security Class Initialized
DEBUG - 2023-10-07 07:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:35:51 --> Input Class Initialized
INFO - 2023-10-07 07:35:51 --> Language Class Initialized
INFO - 2023-10-07 07:35:51 --> Loader Class Initialized
INFO - 2023-10-07 07:35:51 --> Helper loaded: url_helper
INFO - 2023-10-07 07:35:51 --> Helper loaded: file_helper
INFO - 2023-10-07 07:35:51 --> Helper loaded: html_helper
INFO - 2023-10-07 07:35:51 --> Helper loaded: text_helper
INFO - 2023-10-07 07:35:51 --> Helper loaded: form_helper
INFO - 2023-10-07 07:35:51 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:35:51 --> Helper loaded: security_helper
INFO - 2023-10-07 07:35:51 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:35:51 --> Database Driver Class Initialized
INFO - 2023-10-07 07:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:35:51 --> Parser Class Initialized
INFO - 2023-10-07 07:35:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:35:51 --> Pagination Class Initialized
INFO - 2023-10-07 07:35:51 --> Form Validation Class Initialized
INFO - 2023-10-07 07:35:51 --> Controller Class Initialized
DEBUG - 2023-10-07 07:35:51 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:35:51 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:35:51 --> Model Class Initialized
INFO - 2023-10-07 07:35:51 --> Final output sent to browser
DEBUG - 2023-10-07 07:35:51 --> Total execution time: 0.0171
ERROR - 2023-10-07 07:35:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:35:59 --> Config Class Initialized
INFO - 2023-10-07 07:35:59 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:35:59 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:35:59 --> Utf8 Class Initialized
INFO - 2023-10-07 07:35:59 --> URI Class Initialized
INFO - 2023-10-07 07:35:59 --> Router Class Initialized
INFO - 2023-10-07 07:35:59 --> Output Class Initialized
INFO - 2023-10-07 07:35:59 --> Security Class Initialized
DEBUG - 2023-10-07 07:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:35:59 --> Input Class Initialized
INFO - 2023-10-07 07:35:59 --> Language Class Initialized
INFO - 2023-10-07 07:35:59 --> Loader Class Initialized
INFO - 2023-10-07 07:35:59 --> Helper loaded: url_helper
INFO - 2023-10-07 07:35:59 --> Helper loaded: file_helper
INFO - 2023-10-07 07:35:59 --> Helper loaded: html_helper
INFO - 2023-10-07 07:35:59 --> Helper loaded: text_helper
INFO - 2023-10-07 07:35:59 --> Helper loaded: form_helper
INFO - 2023-10-07 07:35:59 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:35:59 --> Helper loaded: security_helper
INFO - 2023-10-07 07:35:59 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:35:59 --> Database Driver Class Initialized
INFO - 2023-10-07 07:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:35:59 --> Parser Class Initialized
INFO - 2023-10-07 07:35:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:35:59 --> Pagination Class Initialized
INFO - 2023-10-07 07:35:59 --> Form Validation Class Initialized
INFO - 2023-10-07 07:35:59 --> Controller Class Initialized
INFO - 2023-10-07 07:35:59 --> Model Class Initialized
DEBUG - 2023-10-07 07:35:59 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:35:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:35:59 --> Model Class Initialized
DEBUG - 2023-10-07 07:35:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:35:59 --> Model Class Initialized
INFO - 2023-10-07 07:35:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-07 07:35:59 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:35:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:35:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:35:59 --> Model Class Initialized
INFO - 2023-10-07 07:35:59 --> Model Class Initialized
INFO - 2023-10-07 07:35:59 --> Model Class Initialized
INFO - 2023-10-07 07:35:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 07:35:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 07:35:59 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:35:59 --> Final output sent to browser
DEBUG - 2023-10-07 07:35:59 --> Total execution time: 0.1923
ERROR - 2023-10-07 07:36:00 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:36:00 --> Config Class Initialized
INFO - 2023-10-07 07:36:00 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:36:00 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:36:00 --> Utf8 Class Initialized
INFO - 2023-10-07 07:36:00 --> URI Class Initialized
INFO - 2023-10-07 07:36:00 --> Router Class Initialized
INFO - 2023-10-07 07:36:00 --> Output Class Initialized
INFO - 2023-10-07 07:36:00 --> Security Class Initialized
DEBUG - 2023-10-07 07:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:36:00 --> Input Class Initialized
INFO - 2023-10-07 07:36:00 --> Language Class Initialized
INFO - 2023-10-07 07:36:00 --> Loader Class Initialized
INFO - 2023-10-07 07:36:00 --> Helper loaded: url_helper
INFO - 2023-10-07 07:36:00 --> Helper loaded: file_helper
INFO - 2023-10-07 07:36:00 --> Helper loaded: html_helper
INFO - 2023-10-07 07:36:00 --> Helper loaded: text_helper
INFO - 2023-10-07 07:36:00 --> Helper loaded: form_helper
INFO - 2023-10-07 07:36:00 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:36:00 --> Helper loaded: security_helper
INFO - 2023-10-07 07:36:00 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:36:00 --> Database Driver Class Initialized
INFO - 2023-10-07 07:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:36:00 --> Parser Class Initialized
INFO - 2023-10-07 07:36:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:36:00 --> Pagination Class Initialized
INFO - 2023-10-07 07:36:00 --> Form Validation Class Initialized
INFO - 2023-10-07 07:36:00 --> Controller Class Initialized
INFO - 2023-10-07 07:36:00 --> Model Class Initialized
DEBUG - 2023-10-07 07:36:00 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:36:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:36:00 --> Model Class Initialized
DEBUG - 2023-10-07 07:36:00 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:36:00 --> Model Class Initialized
INFO - 2023-10-07 07:36:00 --> Final output sent to browser
DEBUG - 2023-10-07 07:36:00 --> Total execution time: 0.0648
ERROR - 2023-10-07 07:36:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:36:30 --> Config Class Initialized
INFO - 2023-10-07 07:36:30 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:36:30 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:36:30 --> Utf8 Class Initialized
INFO - 2023-10-07 07:36:30 --> URI Class Initialized
INFO - 2023-10-07 07:36:30 --> Router Class Initialized
INFO - 2023-10-07 07:36:30 --> Output Class Initialized
INFO - 2023-10-07 07:36:30 --> Security Class Initialized
DEBUG - 2023-10-07 07:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:36:30 --> Input Class Initialized
INFO - 2023-10-07 07:36:30 --> Language Class Initialized
INFO - 2023-10-07 07:36:30 --> Loader Class Initialized
INFO - 2023-10-07 07:36:30 --> Helper loaded: url_helper
INFO - 2023-10-07 07:36:30 --> Helper loaded: file_helper
INFO - 2023-10-07 07:36:30 --> Helper loaded: html_helper
INFO - 2023-10-07 07:36:30 --> Helper loaded: text_helper
INFO - 2023-10-07 07:36:30 --> Helper loaded: form_helper
INFO - 2023-10-07 07:36:30 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:36:30 --> Helper loaded: security_helper
INFO - 2023-10-07 07:36:30 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:36:30 --> Database Driver Class Initialized
INFO - 2023-10-07 07:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:36:30 --> Parser Class Initialized
INFO - 2023-10-07 07:36:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:36:30 --> Pagination Class Initialized
INFO - 2023-10-07 07:36:30 --> Form Validation Class Initialized
INFO - 2023-10-07 07:36:30 --> Controller Class Initialized
INFO - 2023-10-07 07:36:30 --> Model Class Initialized
DEBUG - 2023-10-07 07:36:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:36:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:36:30 --> Model Class Initialized
DEBUG - 2023-10-07 07:36:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:36:30 --> Model Class Initialized
DEBUG - 2023-10-07 07:36:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:36:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-07 07:36:30 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:36:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:36:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:36:30 --> Model Class Initialized
INFO - 2023-10-07 07:36:30 --> Model Class Initialized
INFO - 2023-10-07 07:36:30 --> Model Class Initialized
INFO - 2023-10-07 07:36:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 07:36:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 07:36:30 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:36:30 --> Final output sent to browser
DEBUG - 2023-10-07 07:36:30 --> Total execution time: 0.1743
ERROR - 2023-10-07 07:37:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:37:30 --> Config Class Initialized
INFO - 2023-10-07 07:37:30 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:37:30 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:37:30 --> Utf8 Class Initialized
INFO - 2023-10-07 07:37:30 --> URI Class Initialized
DEBUG - 2023-10-07 07:37:30 --> No URI present. Default controller set.
INFO - 2023-10-07 07:37:30 --> Router Class Initialized
INFO - 2023-10-07 07:37:30 --> Output Class Initialized
INFO - 2023-10-07 07:37:30 --> Security Class Initialized
DEBUG - 2023-10-07 07:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:37:30 --> Input Class Initialized
INFO - 2023-10-07 07:37:30 --> Language Class Initialized
INFO - 2023-10-07 07:37:30 --> Loader Class Initialized
INFO - 2023-10-07 07:37:30 --> Helper loaded: url_helper
INFO - 2023-10-07 07:37:30 --> Helper loaded: file_helper
INFO - 2023-10-07 07:37:30 --> Helper loaded: html_helper
INFO - 2023-10-07 07:37:30 --> Helper loaded: text_helper
INFO - 2023-10-07 07:37:30 --> Helper loaded: form_helper
INFO - 2023-10-07 07:37:30 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:37:30 --> Helper loaded: security_helper
INFO - 2023-10-07 07:37:30 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:37:30 --> Database Driver Class Initialized
INFO - 2023-10-07 07:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:37:30 --> Parser Class Initialized
INFO - 2023-10-07 07:37:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:37:30 --> Pagination Class Initialized
INFO - 2023-10-07 07:37:30 --> Form Validation Class Initialized
INFO - 2023-10-07 07:37:30 --> Controller Class Initialized
INFO - 2023-10-07 07:37:30 --> Model Class Initialized
DEBUG - 2023-10-07 07:37:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-07 07:37:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:37:31 --> Config Class Initialized
INFO - 2023-10-07 07:37:31 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:37:31 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:37:31 --> Utf8 Class Initialized
INFO - 2023-10-07 07:37:31 --> URI Class Initialized
INFO - 2023-10-07 07:37:31 --> Router Class Initialized
INFO - 2023-10-07 07:37:31 --> Output Class Initialized
INFO - 2023-10-07 07:37:31 --> Security Class Initialized
DEBUG - 2023-10-07 07:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:37:31 --> Input Class Initialized
INFO - 2023-10-07 07:37:31 --> Language Class Initialized
INFO - 2023-10-07 07:37:31 --> Loader Class Initialized
INFO - 2023-10-07 07:37:31 --> Helper loaded: url_helper
INFO - 2023-10-07 07:37:31 --> Helper loaded: file_helper
INFO - 2023-10-07 07:37:31 --> Helper loaded: html_helper
INFO - 2023-10-07 07:37:31 --> Helper loaded: text_helper
INFO - 2023-10-07 07:37:31 --> Helper loaded: form_helper
INFO - 2023-10-07 07:37:31 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:37:31 --> Helper loaded: security_helper
INFO - 2023-10-07 07:37:31 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:37:31 --> Database Driver Class Initialized
INFO - 2023-10-07 07:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:37:31 --> Parser Class Initialized
INFO - 2023-10-07 07:37:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:37:31 --> Pagination Class Initialized
INFO - 2023-10-07 07:37:31 --> Form Validation Class Initialized
INFO - 2023-10-07 07:37:31 --> Controller Class Initialized
INFO - 2023-10-07 07:37:31 --> Model Class Initialized
DEBUG - 2023-10-07 07:37:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:37:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-07 07:37:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:37:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:37:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:37:31 --> Model Class Initialized
INFO - 2023-10-07 07:37:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:37:31 --> Final output sent to browser
DEBUG - 2023-10-07 07:37:31 --> Total execution time: 0.0386
ERROR - 2023-10-07 07:37:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:37:40 --> Config Class Initialized
INFO - 2023-10-07 07:37:40 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:37:40 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:37:40 --> Utf8 Class Initialized
INFO - 2023-10-07 07:37:40 --> URI Class Initialized
INFO - 2023-10-07 07:37:40 --> Router Class Initialized
INFO - 2023-10-07 07:37:40 --> Output Class Initialized
INFO - 2023-10-07 07:37:40 --> Security Class Initialized
DEBUG - 2023-10-07 07:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:37:40 --> Input Class Initialized
INFO - 2023-10-07 07:37:40 --> Language Class Initialized
INFO - 2023-10-07 07:37:40 --> Loader Class Initialized
INFO - 2023-10-07 07:37:40 --> Helper loaded: url_helper
INFO - 2023-10-07 07:37:40 --> Helper loaded: file_helper
INFO - 2023-10-07 07:37:40 --> Helper loaded: html_helper
INFO - 2023-10-07 07:37:40 --> Helper loaded: text_helper
INFO - 2023-10-07 07:37:40 --> Helper loaded: form_helper
INFO - 2023-10-07 07:37:40 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:37:40 --> Helper loaded: security_helper
INFO - 2023-10-07 07:37:40 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:37:40 --> Database Driver Class Initialized
INFO - 2023-10-07 07:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:37:40 --> Parser Class Initialized
INFO - 2023-10-07 07:37:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:37:40 --> Pagination Class Initialized
INFO - 2023-10-07 07:37:40 --> Form Validation Class Initialized
INFO - 2023-10-07 07:37:40 --> Controller Class Initialized
INFO - 2023-10-07 07:37:40 --> Model Class Initialized
DEBUG - 2023-10-07 07:37:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:37:40 --> Model Class Initialized
INFO - 2023-10-07 07:37:40 --> Final output sent to browser
DEBUG - 2023-10-07 07:37:40 --> Total execution time: 0.0176
ERROR - 2023-10-07 07:37:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:37:40 --> Config Class Initialized
INFO - 2023-10-07 07:37:40 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:37:40 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:37:40 --> Utf8 Class Initialized
INFO - 2023-10-07 07:37:40 --> URI Class Initialized
DEBUG - 2023-10-07 07:37:40 --> No URI present. Default controller set.
INFO - 2023-10-07 07:37:40 --> Router Class Initialized
INFO - 2023-10-07 07:37:40 --> Output Class Initialized
INFO - 2023-10-07 07:37:40 --> Security Class Initialized
DEBUG - 2023-10-07 07:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:37:40 --> Input Class Initialized
INFO - 2023-10-07 07:37:40 --> Language Class Initialized
INFO - 2023-10-07 07:37:40 --> Loader Class Initialized
INFO - 2023-10-07 07:37:40 --> Helper loaded: url_helper
INFO - 2023-10-07 07:37:40 --> Helper loaded: file_helper
INFO - 2023-10-07 07:37:40 --> Helper loaded: html_helper
INFO - 2023-10-07 07:37:40 --> Helper loaded: text_helper
INFO - 2023-10-07 07:37:40 --> Helper loaded: form_helper
INFO - 2023-10-07 07:37:40 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:37:40 --> Helper loaded: security_helper
INFO - 2023-10-07 07:37:40 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:37:40 --> Database Driver Class Initialized
INFO - 2023-10-07 07:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:37:40 --> Parser Class Initialized
INFO - 2023-10-07 07:37:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:37:40 --> Pagination Class Initialized
INFO - 2023-10-07 07:37:40 --> Form Validation Class Initialized
INFO - 2023-10-07 07:37:40 --> Controller Class Initialized
INFO - 2023-10-07 07:37:40 --> Model Class Initialized
DEBUG - 2023-10-07 07:37:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:37:40 --> Model Class Initialized
DEBUG - 2023-10-07 07:37:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:37:40 --> Model Class Initialized
INFO - 2023-10-07 07:37:40 --> Model Class Initialized
INFO - 2023-10-07 07:37:40 --> Model Class Initialized
INFO - 2023-10-07 07:37:40 --> Model Class Initialized
DEBUG - 2023-10-07 07:37:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:37:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:37:40 --> Model Class Initialized
INFO - 2023-10-07 07:37:40 --> Model Class Initialized
INFO - 2023-10-07 07:37:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 07:37:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:37:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:37:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:37:40 --> Model Class Initialized
INFO - 2023-10-07 07:37:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 07:37:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 07:37:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:37:40 --> Final output sent to browser
DEBUG - 2023-10-07 07:37:40 --> Total execution time: 0.1109
ERROR - 2023-10-07 07:37:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:37:49 --> Config Class Initialized
INFO - 2023-10-07 07:37:49 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:37:49 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:37:49 --> Utf8 Class Initialized
INFO - 2023-10-07 07:37:49 --> URI Class Initialized
INFO - 2023-10-07 07:37:49 --> Router Class Initialized
INFO - 2023-10-07 07:37:49 --> Output Class Initialized
INFO - 2023-10-07 07:37:49 --> Security Class Initialized
DEBUG - 2023-10-07 07:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:37:49 --> Input Class Initialized
INFO - 2023-10-07 07:37:49 --> Language Class Initialized
INFO - 2023-10-07 07:37:49 --> Loader Class Initialized
INFO - 2023-10-07 07:37:49 --> Helper loaded: url_helper
INFO - 2023-10-07 07:37:49 --> Helper loaded: file_helper
INFO - 2023-10-07 07:37:49 --> Helper loaded: html_helper
INFO - 2023-10-07 07:37:49 --> Helper loaded: text_helper
INFO - 2023-10-07 07:37:49 --> Helper loaded: form_helper
INFO - 2023-10-07 07:37:49 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:37:49 --> Helper loaded: security_helper
INFO - 2023-10-07 07:37:49 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:37:49 --> Database Driver Class Initialized
INFO - 2023-10-07 07:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:37:49 --> Parser Class Initialized
INFO - 2023-10-07 07:37:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:37:49 --> Pagination Class Initialized
INFO - 2023-10-07 07:37:49 --> Form Validation Class Initialized
INFO - 2023-10-07 07:37:49 --> Controller Class Initialized
INFO - 2023-10-07 07:37:49 --> Model Class Initialized
DEBUG - 2023-10-07 07:37:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:37:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:37:49 --> Model Class Initialized
INFO - 2023-10-07 07:37:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-10-07 07:37:49 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:37:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:37:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:37:49 --> Model Class Initialized
INFO - 2023-10-07 07:37:49 --> Model Class Initialized
INFO - 2023-10-07 07:37:49 --> Model Class Initialized
INFO - 2023-10-07 07:37:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 07:37:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 07:37:49 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:37:49 --> Final output sent to browser
DEBUG - 2023-10-07 07:37:49 --> Total execution time: 0.0897
ERROR - 2023-10-07 07:37:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:37:50 --> Config Class Initialized
INFO - 2023-10-07 07:37:50 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:37:50 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:37:50 --> Utf8 Class Initialized
INFO - 2023-10-07 07:37:50 --> URI Class Initialized
INFO - 2023-10-07 07:37:50 --> Router Class Initialized
INFO - 2023-10-07 07:37:50 --> Output Class Initialized
INFO - 2023-10-07 07:37:50 --> Security Class Initialized
DEBUG - 2023-10-07 07:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:37:50 --> Input Class Initialized
INFO - 2023-10-07 07:37:50 --> Language Class Initialized
INFO - 2023-10-07 07:37:50 --> Loader Class Initialized
INFO - 2023-10-07 07:37:50 --> Helper loaded: url_helper
INFO - 2023-10-07 07:37:50 --> Helper loaded: file_helper
INFO - 2023-10-07 07:37:50 --> Helper loaded: html_helper
INFO - 2023-10-07 07:37:50 --> Helper loaded: text_helper
INFO - 2023-10-07 07:37:50 --> Helper loaded: form_helper
INFO - 2023-10-07 07:37:50 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:37:50 --> Helper loaded: security_helper
INFO - 2023-10-07 07:37:50 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:37:50 --> Database Driver Class Initialized
INFO - 2023-10-07 07:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:37:50 --> Parser Class Initialized
INFO - 2023-10-07 07:37:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:37:50 --> Pagination Class Initialized
INFO - 2023-10-07 07:37:50 --> Form Validation Class Initialized
INFO - 2023-10-07 07:37:50 --> Controller Class Initialized
INFO - 2023-10-07 07:37:50 --> Model Class Initialized
DEBUG - 2023-10-07 07:37:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:37:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:37:50 --> Model Class Initialized
INFO - 2023-10-07 07:37:50 --> Final output sent to browser
DEBUG - 2023-10-07 07:37:50 --> Total execution time: 0.0234
ERROR - 2023-10-07 07:37:54 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:37:54 --> Config Class Initialized
INFO - 2023-10-07 07:37:54 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:37:54 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:37:54 --> Utf8 Class Initialized
INFO - 2023-10-07 07:37:54 --> URI Class Initialized
INFO - 2023-10-07 07:37:54 --> Router Class Initialized
INFO - 2023-10-07 07:37:54 --> Output Class Initialized
INFO - 2023-10-07 07:37:54 --> Security Class Initialized
DEBUG - 2023-10-07 07:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:37:54 --> Input Class Initialized
INFO - 2023-10-07 07:37:54 --> Language Class Initialized
INFO - 2023-10-07 07:37:54 --> Loader Class Initialized
INFO - 2023-10-07 07:37:54 --> Helper loaded: url_helper
INFO - 2023-10-07 07:37:54 --> Helper loaded: file_helper
INFO - 2023-10-07 07:37:54 --> Helper loaded: html_helper
INFO - 2023-10-07 07:37:54 --> Helper loaded: text_helper
INFO - 2023-10-07 07:37:54 --> Helper loaded: form_helper
INFO - 2023-10-07 07:37:54 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:37:54 --> Helper loaded: security_helper
INFO - 2023-10-07 07:37:54 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:37:54 --> Database Driver Class Initialized
INFO - 2023-10-07 07:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:37:54 --> Parser Class Initialized
INFO - 2023-10-07 07:37:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:37:54 --> Pagination Class Initialized
INFO - 2023-10-07 07:37:54 --> Form Validation Class Initialized
INFO - 2023-10-07 07:37:54 --> Controller Class Initialized
INFO - 2023-10-07 07:37:54 --> Model Class Initialized
DEBUG - 2023-10-07 07:37:54 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:37:54 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:37:54 --> Model Class Initialized
INFO - 2023-10-07 07:37:54 --> Final output sent to browser
DEBUG - 2023-10-07 07:37:54 --> Total execution time: 0.0221
ERROR - 2023-10-07 07:43:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:43:12 --> Config Class Initialized
INFO - 2023-10-07 07:43:12 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:43:12 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:43:12 --> Utf8 Class Initialized
INFO - 2023-10-07 07:43:12 --> URI Class Initialized
DEBUG - 2023-10-07 07:43:12 --> No URI present. Default controller set.
INFO - 2023-10-07 07:43:12 --> Router Class Initialized
INFO - 2023-10-07 07:43:12 --> Output Class Initialized
INFO - 2023-10-07 07:43:12 --> Security Class Initialized
DEBUG - 2023-10-07 07:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:43:12 --> Input Class Initialized
INFO - 2023-10-07 07:43:12 --> Language Class Initialized
INFO - 2023-10-07 07:43:12 --> Loader Class Initialized
INFO - 2023-10-07 07:43:12 --> Helper loaded: url_helper
INFO - 2023-10-07 07:43:12 --> Helper loaded: file_helper
INFO - 2023-10-07 07:43:12 --> Helper loaded: html_helper
INFO - 2023-10-07 07:43:12 --> Helper loaded: text_helper
INFO - 2023-10-07 07:43:12 --> Helper loaded: form_helper
INFO - 2023-10-07 07:43:12 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:43:12 --> Helper loaded: security_helper
INFO - 2023-10-07 07:43:12 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:43:12 --> Database Driver Class Initialized
INFO - 2023-10-07 07:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:43:12 --> Parser Class Initialized
INFO - 2023-10-07 07:43:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:43:12 --> Pagination Class Initialized
INFO - 2023-10-07 07:43:12 --> Form Validation Class Initialized
INFO - 2023-10-07 07:43:12 --> Controller Class Initialized
INFO - 2023-10-07 07:43:12 --> Model Class Initialized
DEBUG - 2023-10-07 07:43:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:43:12 --> Model Class Initialized
DEBUG - 2023-10-07 07:43:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:43:12 --> Model Class Initialized
INFO - 2023-10-07 07:43:12 --> Model Class Initialized
INFO - 2023-10-07 07:43:12 --> Model Class Initialized
INFO - 2023-10-07 07:43:12 --> Model Class Initialized
DEBUG - 2023-10-07 07:43:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:43:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:43:12 --> Model Class Initialized
INFO - 2023-10-07 07:43:12 --> Model Class Initialized
INFO - 2023-10-07 07:43:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 07:43:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:43:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:43:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:43:12 --> Model Class Initialized
INFO - 2023-10-07 07:43:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 07:43:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 07:43:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:43:12 --> Final output sent to browser
DEBUG - 2023-10-07 07:43:12 --> Total execution time: 0.1173
ERROR - 2023-10-07 07:50:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:50:58 --> Config Class Initialized
INFO - 2023-10-07 07:50:58 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:50:58 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:50:58 --> Utf8 Class Initialized
INFO - 2023-10-07 07:50:58 --> URI Class Initialized
INFO - 2023-10-07 07:50:58 --> Router Class Initialized
INFO - 2023-10-07 07:50:58 --> Output Class Initialized
INFO - 2023-10-07 07:50:58 --> Security Class Initialized
DEBUG - 2023-10-07 07:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:50:58 --> Input Class Initialized
INFO - 2023-10-07 07:50:58 --> Language Class Initialized
INFO - 2023-10-07 07:50:58 --> Loader Class Initialized
INFO - 2023-10-07 07:50:58 --> Helper loaded: url_helper
INFO - 2023-10-07 07:50:58 --> Helper loaded: file_helper
INFO - 2023-10-07 07:50:58 --> Helper loaded: html_helper
INFO - 2023-10-07 07:50:58 --> Helper loaded: text_helper
INFO - 2023-10-07 07:50:58 --> Helper loaded: form_helper
INFO - 2023-10-07 07:50:58 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:50:58 --> Helper loaded: security_helper
INFO - 2023-10-07 07:50:58 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:50:58 --> Database Driver Class Initialized
INFO - 2023-10-07 07:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:50:58 --> Parser Class Initialized
INFO - 2023-10-07 07:50:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:50:58 --> Pagination Class Initialized
INFO - 2023-10-07 07:50:58 --> Form Validation Class Initialized
INFO - 2023-10-07 07:50:58 --> Controller Class Initialized
INFO - 2023-10-07 07:50:58 --> Model Class Initialized
DEBUG - 2023-10-07 07:50:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:50:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:50:58 --> Model Class Initialized
DEBUG - 2023-10-07 07:50:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:50:58 --> Model Class Initialized
INFO - 2023-10-07 07:50:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-07 07:50:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:50:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:50:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:50:58 --> Model Class Initialized
INFO - 2023-10-07 07:50:58 --> Model Class Initialized
INFO - 2023-10-07 07:50:58 --> Model Class Initialized
INFO - 2023-10-07 07:50:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 07:50:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 07:50:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:50:58 --> Final output sent to browser
DEBUG - 2023-10-07 07:50:58 --> Total execution time: 0.1003
ERROR - 2023-10-07 07:50:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:50:58 --> Config Class Initialized
INFO - 2023-10-07 07:50:58 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:50:58 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:50:58 --> Utf8 Class Initialized
INFO - 2023-10-07 07:50:58 --> URI Class Initialized
INFO - 2023-10-07 07:50:58 --> Router Class Initialized
INFO - 2023-10-07 07:50:58 --> Output Class Initialized
INFO - 2023-10-07 07:50:58 --> Security Class Initialized
DEBUG - 2023-10-07 07:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:50:58 --> Input Class Initialized
INFO - 2023-10-07 07:50:58 --> Language Class Initialized
INFO - 2023-10-07 07:50:58 --> Loader Class Initialized
INFO - 2023-10-07 07:50:58 --> Helper loaded: url_helper
INFO - 2023-10-07 07:50:58 --> Helper loaded: file_helper
INFO - 2023-10-07 07:50:58 --> Helper loaded: html_helper
INFO - 2023-10-07 07:50:58 --> Helper loaded: text_helper
INFO - 2023-10-07 07:50:58 --> Helper loaded: form_helper
INFO - 2023-10-07 07:50:58 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:50:58 --> Helper loaded: security_helper
INFO - 2023-10-07 07:50:58 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:50:58 --> Database Driver Class Initialized
INFO - 2023-10-07 07:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:50:58 --> Parser Class Initialized
INFO - 2023-10-07 07:50:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:50:58 --> Pagination Class Initialized
INFO - 2023-10-07 07:50:58 --> Form Validation Class Initialized
INFO - 2023-10-07 07:50:58 --> Controller Class Initialized
INFO - 2023-10-07 07:50:58 --> Model Class Initialized
DEBUG - 2023-10-07 07:50:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:50:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:50:58 --> Model Class Initialized
DEBUG - 2023-10-07 07:50:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:50:58 --> Model Class Initialized
INFO - 2023-10-07 07:50:58 --> Final output sent to browser
DEBUG - 2023-10-07 07:50:58 --> Total execution time: 0.0475
ERROR - 2023-10-07 07:51:05 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:51:05 --> Config Class Initialized
INFO - 2023-10-07 07:51:05 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:51:05 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:51:05 --> Utf8 Class Initialized
INFO - 2023-10-07 07:51:05 --> URI Class Initialized
INFO - 2023-10-07 07:51:05 --> Router Class Initialized
INFO - 2023-10-07 07:51:05 --> Output Class Initialized
INFO - 2023-10-07 07:51:05 --> Security Class Initialized
DEBUG - 2023-10-07 07:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:51:05 --> Input Class Initialized
INFO - 2023-10-07 07:51:05 --> Language Class Initialized
INFO - 2023-10-07 07:51:05 --> Loader Class Initialized
INFO - 2023-10-07 07:51:05 --> Helper loaded: url_helper
INFO - 2023-10-07 07:51:05 --> Helper loaded: file_helper
INFO - 2023-10-07 07:51:05 --> Helper loaded: html_helper
INFO - 2023-10-07 07:51:05 --> Helper loaded: text_helper
INFO - 2023-10-07 07:51:05 --> Helper loaded: form_helper
INFO - 2023-10-07 07:51:05 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:51:05 --> Helper loaded: security_helper
INFO - 2023-10-07 07:51:05 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:51:05 --> Database Driver Class Initialized
INFO - 2023-10-07 07:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:51:05 --> Parser Class Initialized
INFO - 2023-10-07 07:51:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:51:05 --> Pagination Class Initialized
INFO - 2023-10-07 07:51:05 --> Form Validation Class Initialized
INFO - 2023-10-07 07:51:05 --> Controller Class Initialized
INFO - 2023-10-07 07:51:05 --> Model Class Initialized
DEBUG - 2023-10-07 07:51:05 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:51:05 --> Model Class Initialized
DEBUG - 2023-10-07 07:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:51:05 --> Model Class Initialized
INFO - 2023-10-07 07:51:05 --> Final output sent to browser
DEBUG - 2023-10-07 07:51:05 --> Total execution time: 0.0597
ERROR - 2023-10-07 07:51:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:51:24 --> Config Class Initialized
INFO - 2023-10-07 07:51:24 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:51:24 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:51:24 --> Utf8 Class Initialized
INFO - 2023-10-07 07:51:24 --> URI Class Initialized
INFO - 2023-10-07 07:51:24 --> Router Class Initialized
INFO - 2023-10-07 07:51:24 --> Output Class Initialized
INFO - 2023-10-07 07:51:24 --> Security Class Initialized
DEBUG - 2023-10-07 07:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:51:24 --> Input Class Initialized
INFO - 2023-10-07 07:51:24 --> Language Class Initialized
INFO - 2023-10-07 07:51:24 --> Loader Class Initialized
INFO - 2023-10-07 07:51:24 --> Helper loaded: url_helper
INFO - 2023-10-07 07:51:24 --> Helper loaded: file_helper
INFO - 2023-10-07 07:51:24 --> Helper loaded: html_helper
INFO - 2023-10-07 07:51:24 --> Helper loaded: text_helper
INFO - 2023-10-07 07:51:24 --> Helper loaded: form_helper
INFO - 2023-10-07 07:51:24 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:51:24 --> Helper loaded: security_helper
INFO - 2023-10-07 07:51:24 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:51:24 --> Database Driver Class Initialized
INFO - 2023-10-07 07:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:51:24 --> Parser Class Initialized
INFO - 2023-10-07 07:51:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:51:24 --> Pagination Class Initialized
INFO - 2023-10-07 07:51:24 --> Form Validation Class Initialized
INFO - 2023-10-07 07:51:24 --> Controller Class Initialized
INFO - 2023-10-07 07:51:24 --> Model Class Initialized
DEBUG - 2023-10-07 07:51:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:51:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:51:24 --> Model Class Initialized
DEBUG - 2023-10-07 07:51:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:51:24 --> Model Class Initialized
INFO - 2023-10-07 07:51:24 --> Final output sent to browser
DEBUG - 2023-10-07 07:51:24 --> Total execution time: 0.0396
ERROR - 2023-10-07 07:51:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:51:25 --> Config Class Initialized
INFO - 2023-10-07 07:51:25 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:51:25 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:51:25 --> Utf8 Class Initialized
INFO - 2023-10-07 07:51:25 --> URI Class Initialized
INFO - 2023-10-07 07:51:25 --> Router Class Initialized
INFO - 2023-10-07 07:51:25 --> Output Class Initialized
INFO - 2023-10-07 07:51:25 --> Security Class Initialized
DEBUG - 2023-10-07 07:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:51:25 --> Input Class Initialized
INFO - 2023-10-07 07:51:25 --> Language Class Initialized
INFO - 2023-10-07 07:51:25 --> Loader Class Initialized
INFO - 2023-10-07 07:51:25 --> Helper loaded: url_helper
INFO - 2023-10-07 07:51:25 --> Helper loaded: file_helper
INFO - 2023-10-07 07:51:25 --> Helper loaded: html_helper
INFO - 2023-10-07 07:51:25 --> Helper loaded: text_helper
INFO - 2023-10-07 07:51:25 --> Helper loaded: form_helper
INFO - 2023-10-07 07:51:25 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:51:25 --> Helper loaded: security_helper
INFO - 2023-10-07 07:51:25 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:51:25 --> Database Driver Class Initialized
INFO - 2023-10-07 07:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:51:25 --> Parser Class Initialized
INFO - 2023-10-07 07:51:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:51:25 --> Pagination Class Initialized
INFO - 2023-10-07 07:51:25 --> Form Validation Class Initialized
INFO - 2023-10-07 07:51:25 --> Controller Class Initialized
INFO - 2023-10-07 07:51:25 --> Model Class Initialized
DEBUG - 2023-10-07 07:51:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:51:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:51:25 --> Model Class Initialized
DEBUG - 2023-10-07 07:51:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:51:25 --> Model Class Initialized
INFO - 2023-10-07 07:51:25 --> Final output sent to browser
DEBUG - 2023-10-07 07:51:25 --> Total execution time: 0.0363
ERROR - 2023-10-07 07:54:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:54:07 --> Config Class Initialized
INFO - 2023-10-07 07:54:07 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:54:07 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:54:07 --> Utf8 Class Initialized
INFO - 2023-10-07 07:54:07 --> URI Class Initialized
DEBUG - 2023-10-07 07:54:07 --> No URI present. Default controller set.
INFO - 2023-10-07 07:54:07 --> Router Class Initialized
INFO - 2023-10-07 07:54:07 --> Output Class Initialized
INFO - 2023-10-07 07:54:07 --> Security Class Initialized
DEBUG - 2023-10-07 07:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:54:07 --> Input Class Initialized
INFO - 2023-10-07 07:54:07 --> Language Class Initialized
INFO - 2023-10-07 07:54:07 --> Loader Class Initialized
INFO - 2023-10-07 07:54:07 --> Helper loaded: url_helper
INFO - 2023-10-07 07:54:07 --> Helper loaded: file_helper
INFO - 2023-10-07 07:54:07 --> Helper loaded: html_helper
INFO - 2023-10-07 07:54:07 --> Helper loaded: text_helper
INFO - 2023-10-07 07:54:07 --> Helper loaded: form_helper
INFO - 2023-10-07 07:54:07 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:54:07 --> Helper loaded: security_helper
INFO - 2023-10-07 07:54:07 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:54:07 --> Database Driver Class Initialized
INFO - 2023-10-07 07:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:54:07 --> Parser Class Initialized
INFO - 2023-10-07 07:54:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:54:07 --> Pagination Class Initialized
INFO - 2023-10-07 07:54:07 --> Form Validation Class Initialized
INFO - 2023-10-07 07:54:07 --> Controller Class Initialized
INFO - 2023-10-07 07:54:07 --> Model Class Initialized
DEBUG - 2023-10-07 07:54:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:54:07 --> Model Class Initialized
DEBUG - 2023-10-07 07:54:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:54:07 --> Model Class Initialized
INFO - 2023-10-07 07:54:07 --> Model Class Initialized
INFO - 2023-10-07 07:54:07 --> Model Class Initialized
INFO - 2023-10-07 07:54:07 --> Model Class Initialized
DEBUG - 2023-10-07 07:54:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:54:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:54:07 --> Model Class Initialized
INFO - 2023-10-07 07:54:07 --> Model Class Initialized
INFO - 2023-10-07 07:54:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 07:54:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:54:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:54:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:54:07 --> Model Class Initialized
INFO - 2023-10-07 07:54:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 07:54:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 07:54:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:54:07 --> Final output sent to browser
DEBUG - 2023-10-07 07:54:07 --> Total execution time: 0.1177
ERROR - 2023-10-07 07:54:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:54:22 --> Config Class Initialized
INFO - 2023-10-07 07:54:22 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:54:22 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:54:22 --> Utf8 Class Initialized
INFO - 2023-10-07 07:54:22 --> URI Class Initialized
INFO - 2023-10-07 07:54:22 --> Router Class Initialized
INFO - 2023-10-07 07:54:22 --> Output Class Initialized
INFO - 2023-10-07 07:54:22 --> Security Class Initialized
DEBUG - 2023-10-07 07:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:54:22 --> Input Class Initialized
INFO - 2023-10-07 07:54:22 --> Language Class Initialized
INFO - 2023-10-07 07:54:22 --> Loader Class Initialized
INFO - 2023-10-07 07:54:22 --> Helper loaded: url_helper
INFO - 2023-10-07 07:54:22 --> Helper loaded: file_helper
INFO - 2023-10-07 07:54:22 --> Helper loaded: html_helper
INFO - 2023-10-07 07:54:22 --> Helper loaded: text_helper
INFO - 2023-10-07 07:54:22 --> Helper loaded: form_helper
INFO - 2023-10-07 07:54:22 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:54:22 --> Helper loaded: security_helper
INFO - 2023-10-07 07:54:22 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:54:22 --> Database Driver Class Initialized
INFO - 2023-10-07 07:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:54:22 --> Parser Class Initialized
INFO - 2023-10-07 07:54:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:54:22 --> Pagination Class Initialized
INFO - 2023-10-07 07:54:22 --> Form Validation Class Initialized
INFO - 2023-10-07 07:54:22 --> Controller Class Initialized
INFO - 2023-10-07 07:54:22 --> Model Class Initialized
DEBUG - 2023-10-07 07:54:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:54:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:54:22 --> Model Class Initialized
INFO - 2023-10-07 07:54:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-10-07 07:54:22 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:54:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:54:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:54:22 --> Model Class Initialized
INFO - 2023-10-07 07:54:22 --> Model Class Initialized
INFO - 2023-10-07 07:54:22 --> Model Class Initialized
INFO - 2023-10-07 07:54:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 07:54:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 07:54:22 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:54:22 --> Final output sent to browser
DEBUG - 2023-10-07 07:54:22 --> Total execution time: 0.0819
ERROR - 2023-10-07 07:54:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:54:22 --> Config Class Initialized
INFO - 2023-10-07 07:54:22 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:54:22 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:54:22 --> Utf8 Class Initialized
INFO - 2023-10-07 07:54:22 --> URI Class Initialized
INFO - 2023-10-07 07:54:22 --> Router Class Initialized
INFO - 2023-10-07 07:54:22 --> Output Class Initialized
INFO - 2023-10-07 07:54:22 --> Security Class Initialized
DEBUG - 2023-10-07 07:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:54:22 --> Input Class Initialized
INFO - 2023-10-07 07:54:22 --> Language Class Initialized
INFO - 2023-10-07 07:54:22 --> Loader Class Initialized
INFO - 2023-10-07 07:54:22 --> Helper loaded: url_helper
INFO - 2023-10-07 07:54:22 --> Helper loaded: file_helper
INFO - 2023-10-07 07:54:22 --> Helper loaded: html_helper
INFO - 2023-10-07 07:54:22 --> Helper loaded: text_helper
INFO - 2023-10-07 07:54:22 --> Helper loaded: form_helper
INFO - 2023-10-07 07:54:22 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:54:22 --> Helper loaded: security_helper
INFO - 2023-10-07 07:54:22 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:54:22 --> Database Driver Class Initialized
INFO - 2023-10-07 07:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:54:22 --> Parser Class Initialized
INFO - 2023-10-07 07:54:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:54:22 --> Pagination Class Initialized
INFO - 2023-10-07 07:54:22 --> Form Validation Class Initialized
INFO - 2023-10-07 07:54:22 --> Controller Class Initialized
INFO - 2023-10-07 07:54:22 --> Model Class Initialized
DEBUG - 2023-10-07 07:54:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:54:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:54:22 --> Model Class Initialized
INFO - 2023-10-07 07:54:22 --> Final output sent to browser
DEBUG - 2023-10-07 07:54:22 --> Total execution time: 0.0243
ERROR - 2023-10-07 07:54:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:54:25 --> Config Class Initialized
INFO - 2023-10-07 07:54:25 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:54:25 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:54:25 --> Utf8 Class Initialized
INFO - 2023-10-07 07:54:25 --> URI Class Initialized
INFO - 2023-10-07 07:54:25 --> Router Class Initialized
INFO - 2023-10-07 07:54:25 --> Output Class Initialized
INFO - 2023-10-07 07:54:25 --> Security Class Initialized
DEBUG - 2023-10-07 07:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:54:25 --> Input Class Initialized
INFO - 2023-10-07 07:54:25 --> Language Class Initialized
INFO - 2023-10-07 07:54:25 --> Loader Class Initialized
INFO - 2023-10-07 07:54:25 --> Helper loaded: url_helper
INFO - 2023-10-07 07:54:25 --> Helper loaded: file_helper
INFO - 2023-10-07 07:54:25 --> Helper loaded: html_helper
INFO - 2023-10-07 07:54:25 --> Helper loaded: text_helper
INFO - 2023-10-07 07:54:25 --> Helper loaded: form_helper
INFO - 2023-10-07 07:54:25 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:54:25 --> Helper loaded: security_helper
INFO - 2023-10-07 07:54:25 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:54:25 --> Database Driver Class Initialized
INFO - 2023-10-07 07:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:54:25 --> Parser Class Initialized
INFO - 2023-10-07 07:54:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:54:25 --> Pagination Class Initialized
INFO - 2023-10-07 07:54:25 --> Form Validation Class Initialized
INFO - 2023-10-07 07:54:25 --> Controller Class Initialized
INFO - 2023-10-07 07:54:25 --> Model Class Initialized
DEBUG - 2023-10-07 07:54:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:54:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:54:25 --> Model Class Initialized
INFO - 2023-10-07 07:54:25 --> Final output sent to browser
DEBUG - 2023-10-07 07:54:25 --> Total execution time: 0.0265
ERROR - 2023-10-07 07:54:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:54:34 --> Config Class Initialized
INFO - 2023-10-07 07:54:34 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:54:34 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:54:34 --> Utf8 Class Initialized
INFO - 2023-10-07 07:54:34 --> URI Class Initialized
DEBUG - 2023-10-07 07:54:34 --> No URI present. Default controller set.
INFO - 2023-10-07 07:54:34 --> Router Class Initialized
INFO - 2023-10-07 07:54:34 --> Output Class Initialized
INFO - 2023-10-07 07:54:34 --> Security Class Initialized
DEBUG - 2023-10-07 07:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:54:34 --> Input Class Initialized
INFO - 2023-10-07 07:54:34 --> Language Class Initialized
INFO - 2023-10-07 07:54:34 --> Loader Class Initialized
INFO - 2023-10-07 07:54:34 --> Helper loaded: url_helper
INFO - 2023-10-07 07:54:34 --> Helper loaded: file_helper
INFO - 2023-10-07 07:54:34 --> Helper loaded: html_helper
INFO - 2023-10-07 07:54:34 --> Helper loaded: text_helper
INFO - 2023-10-07 07:54:34 --> Helper loaded: form_helper
INFO - 2023-10-07 07:54:34 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:54:34 --> Helper loaded: security_helper
INFO - 2023-10-07 07:54:34 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:54:34 --> Database Driver Class Initialized
INFO - 2023-10-07 07:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:54:34 --> Parser Class Initialized
INFO - 2023-10-07 07:54:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:54:34 --> Pagination Class Initialized
INFO - 2023-10-07 07:54:34 --> Form Validation Class Initialized
INFO - 2023-10-07 07:54:34 --> Controller Class Initialized
INFO - 2023-10-07 07:54:34 --> Model Class Initialized
DEBUG - 2023-10-07 07:54:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:54:34 --> Model Class Initialized
DEBUG - 2023-10-07 07:54:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:54:34 --> Model Class Initialized
INFO - 2023-10-07 07:54:34 --> Model Class Initialized
INFO - 2023-10-07 07:54:34 --> Model Class Initialized
INFO - 2023-10-07 07:54:34 --> Model Class Initialized
DEBUG - 2023-10-07 07:54:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:54:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:54:34 --> Model Class Initialized
INFO - 2023-10-07 07:54:34 --> Model Class Initialized
INFO - 2023-10-07 07:54:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 07:54:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:54:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:54:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:54:34 --> Model Class Initialized
INFO - 2023-10-07 07:54:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 07:54:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 07:54:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:54:34 --> Final output sent to browser
DEBUG - 2023-10-07 07:54:34 --> Total execution time: 0.1202
ERROR - 2023-10-07 07:54:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:54:50 --> Config Class Initialized
INFO - 2023-10-07 07:54:50 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:54:50 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:54:50 --> Utf8 Class Initialized
INFO - 2023-10-07 07:54:50 --> URI Class Initialized
DEBUG - 2023-10-07 07:54:50 --> No URI present. Default controller set.
INFO - 2023-10-07 07:54:50 --> Router Class Initialized
INFO - 2023-10-07 07:54:50 --> Output Class Initialized
INFO - 2023-10-07 07:54:50 --> Security Class Initialized
DEBUG - 2023-10-07 07:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:54:50 --> Input Class Initialized
INFO - 2023-10-07 07:54:50 --> Language Class Initialized
INFO - 2023-10-07 07:54:50 --> Loader Class Initialized
INFO - 2023-10-07 07:54:50 --> Helper loaded: url_helper
INFO - 2023-10-07 07:54:50 --> Helper loaded: file_helper
INFO - 2023-10-07 07:54:50 --> Helper loaded: html_helper
INFO - 2023-10-07 07:54:50 --> Helper loaded: text_helper
INFO - 2023-10-07 07:54:50 --> Helper loaded: form_helper
INFO - 2023-10-07 07:54:50 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:54:50 --> Helper loaded: security_helper
INFO - 2023-10-07 07:54:50 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:54:50 --> Database Driver Class Initialized
INFO - 2023-10-07 07:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:54:50 --> Parser Class Initialized
INFO - 2023-10-07 07:54:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:54:50 --> Pagination Class Initialized
INFO - 2023-10-07 07:54:50 --> Form Validation Class Initialized
INFO - 2023-10-07 07:54:50 --> Controller Class Initialized
INFO - 2023-10-07 07:54:50 --> Model Class Initialized
DEBUG - 2023-10-07 07:54:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:54:50 --> Model Class Initialized
DEBUG - 2023-10-07 07:54:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:54:50 --> Model Class Initialized
INFO - 2023-10-07 07:54:50 --> Model Class Initialized
INFO - 2023-10-07 07:54:50 --> Model Class Initialized
INFO - 2023-10-07 07:54:50 --> Model Class Initialized
DEBUG - 2023-10-07 07:54:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:54:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:54:50 --> Model Class Initialized
INFO - 2023-10-07 07:54:50 --> Model Class Initialized
INFO - 2023-10-07 07:54:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 07:54:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:54:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:54:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:54:50 --> Model Class Initialized
INFO - 2023-10-07 07:54:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 07:54:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 07:54:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:54:50 --> Final output sent to browser
DEBUG - 2023-10-07 07:54:50 --> Total execution time: 0.1132
ERROR - 2023-10-07 07:54:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:54:58 --> Config Class Initialized
INFO - 2023-10-07 07:54:58 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:54:58 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:54:58 --> Utf8 Class Initialized
INFO - 2023-10-07 07:54:58 --> URI Class Initialized
INFO - 2023-10-07 07:54:58 --> Router Class Initialized
INFO - 2023-10-07 07:54:58 --> Output Class Initialized
INFO - 2023-10-07 07:54:58 --> Security Class Initialized
DEBUG - 2023-10-07 07:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:54:58 --> Input Class Initialized
INFO - 2023-10-07 07:54:58 --> Language Class Initialized
INFO - 2023-10-07 07:54:58 --> Loader Class Initialized
INFO - 2023-10-07 07:54:58 --> Helper loaded: url_helper
INFO - 2023-10-07 07:54:58 --> Helper loaded: file_helper
INFO - 2023-10-07 07:54:58 --> Helper loaded: html_helper
INFO - 2023-10-07 07:54:58 --> Helper loaded: text_helper
INFO - 2023-10-07 07:54:58 --> Helper loaded: form_helper
INFO - 2023-10-07 07:54:58 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:54:58 --> Helper loaded: security_helper
INFO - 2023-10-07 07:54:58 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:54:58 --> Database Driver Class Initialized
INFO - 2023-10-07 07:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:54:58 --> Parser Class Initialized
INFO - 2023-10-07 07:54:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:54:58 --> Pagination Class Initialized
INFO - 2023-10-07 07:54:58 --> Form Validation Class Initialized
INFO - 2023-10-07 07:54:58 --> Controller Class Initialized
INFO - 2023-10-07 07:54:58 --> Model Class Initialized
DEBUG - 2023-10-07 07:54:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:54:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:54:58 --> Model Class Initialized
INFO - 2023-10-07 07:54:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-10-07 07:54:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:54:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:54:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:54:58 --> Model Class Initialized
INFO - 2023-10-07 07:54:58 --> Model Class Initialized
INFO - 2023-10-07 07:54:58 --> Model Class Initialized
INFO - 2023-10-07 07:54:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 07:54:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 07:54:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:54:58 --> Final output sent to browser
DEBUG - 2023-10-07 07:54:58 --> Total execution time: 0.0909
ERROR - 2023-10-07 07:54:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:54:58 --> Config Class Initialized
INFO - 2023-10-07 07:54:58 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:54:58 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:54:58 --> Utf8 Class Initialized
INFO - 2023-10-07 07:54:58 --> URI Class Initialized
INFO - 2023-10-07 07:54:58 --> Router Class Initialized
INFO - 2023-10-07 07:54:58 --> Output Class Initialized
INFO - 2023-10-07 07:54:58 --> Security Class Initialized
DEBUG - 2023-10-07 07:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:54:58 --> Input Class Initialized
INFO - 2023-10-07 07:54:58 --> Language Class Initialized
INFO - 2023-10-07 07:54:58 --> Loader Class Initialized
INFO - 2023-10-07 07:54:58 --> Helper loaded: url_helper
INFO - 2023-10-07 07:54:58 --> Helper loaded: file_helper
INFO - 2023-10-07 07:54:58 --> Helper loaded: html_helper
INFO - 2023-10-07 07:54:58 --> Helper loaded: text_helper
INFO - 2023-10-07 07:54:58 --> Helper loaded: form_helper
INFO - 2023-10-07 07:54:58 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:54:58 --> Helper loaded: security_helper
INFO - 2023-10-07 07:54:58 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:54:58 --> Database Driver Class Initialized
INFO - 2023-10-07 07:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:54:58 --> Parser Class Initialized
INFO - 2023-10-07 07:54:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:54:58 --> Pagination Class Initialized
INFO - 2023-10-07 07:54:58 --> Form Validation Class Initialized
INFO - 2023-10-07 07:54:58 --> Controller Class Initialized
INFO - 2023-10-07 07:54:58 --> Model Class Initialized
DEBUG - 2023-10-07 07:54:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:54:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:54:58 --> Model Class Initialized
INFO - 2023-10-07 07:54:58 --> Final output sent to browser
DEBUG - 2023-10-07 07:54:58 --> Total execution time: 0.0230
ERROR - 2023-10-07 07:55:01 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:55:01 --> Config Class Initialized
INFO - 2023-10-07 07:55:01 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:55:01 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:55:01 --> Utf8 Class Initialized
INFO - 2023-10-07 07:55:01 --> URI Class Initialized
INFO - 2023-10-07 07:55:01 --> Router Class Initialized
INFO - 2023-10-07 07:55:01 --> Output Class Initialized
INFO - 2023-10-07 07:55:01 --> Security Class Initialized
DEBUG - 2023-10-07 07:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:55:01 --> Input Class Initialized
INFO - 2023-10-07 07:55:01 --> Language Class Initialized
INFO - 2023-10-07 07:55:01 --> Loader Class Initialized
INFO - 2023-10-07 07:55:01 --> Helper loaded: url_helper
INFO - 2023-10-07 07:55:01 --> Helper loaded: file_helper
INFO - 2023-10-07 07:55:01 --> Helper loaded: html_helper
INFO - 2023-10-07 07:55:01 --> Helper loaded: text_helper
INFO - 2023-10-07 07:55:01 --> Helper loaded: form_helper
INFO - 2023-10-07 07:55:01 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:55:01 --> Helper loaded: security_helper
INFO - 2023-10-07 07:55:01 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:55:01 --> Database Driver Class Initialized
INFO - 2023-10-07 07:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:55:01 --> Parser Class Initialized
INFO - 2023-10-07 07:55:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:55:01 --> Pagination Class Initialized
INFO - 2023-10-07 07:55:01 --> Form Validation Class Initialized
INFO - 2023-10-07 07:55:01 --> Controller Class Initialized
INFO - 2023-10-07 07:55:01 --> Model Class Initialized
DEBUG - 2023-10-07 07:55:01 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:55:01 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:55:01 --> Model Class Initialized
INFO - 2023-10-07 07:55:01 --> Final output sent to browser
DEBUG - 2023-10-07 07:55:01 --> Total execution time: 0.0246
ERROR - 2023-10-07 07:55:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:55:16 --> Config Class Initialized
INFO - 2023-10-07 07:55:16 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:55:16 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:55:16 --> Utf8 Class Initialized
INFO - 2023-10-07 07:55:16 --> URI Class Initialized
DEBUG - 2023-10-07 07:55:16 --> No URI present. Default controller set.
INFO - 2023-10-07 07:55:16 --> Router Class Initialized
INFO - 2023-10-07 07:55:16 --> Output Class Initialized
INFO - 2023-10-07 07:55:16 --> Security Class Initialized
DEBUG - 2023-10-07 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:55:16 --> Input Class Initialized
INFO - 2023-10-07 07:55:16 --> Language Class Initialized
INFO - 2023-10-07 07:55:16 --> Loader Class Initialized
INFO - 2023-10-07 07:55:16 --> Helper loaded: url_helper
INFO - 2023-10-07 07:55:16 --> Helper loaded: file_helper
INFO - 2023-10-07 07:55:16 --> Helper loaded: html_helper
INFO - 2023-10-07 07:55:16 --> Helper loaded: text_helper
INFO - 2023-10-07 07:55:16 --> Helper loaded: form_helper
INFO - 2023-10-07 07:55:16 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:55:16 --> Helper loaded: security_helper
INFO - 2023-10-07 07:55:16 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:55:16 --> Database Driver Class Initialized
INFO - 2023-10-07 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:55:16 --> Parser Class Initialized
INFO - 2023-10-07 07:55:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:55:16 --> Pagination Class Initialized
INFO - 2023-10-07 07:55:16 --> Form Validation Class Initialized
INFO - 2023-10-07 07:55:16 --> Controller Class Initialized
INFO - 2023-10-07 07:55:16 --> Model Class Initialized
DEBUG - 2023-10-07 07:55:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:55:16 --> Model Class Initialized
DEBUG - 2023-10-07 07:55:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:55:16 --> Model Class Initialized
INFO - 2023-10-07 07:55:16 --> Model Class Initialized
INFO - 2023-10-07 07:55:16 --> Model Class Initialized
INFO - 2023-10-07 07:55:16 --> Model Class Initialized
DEBUG - 2023-10-07 07:55:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:55:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:55:16 --> Model Class Initialized
INFO - 2023-10-07 07:55:16 --> Model Class Initialized
INFO - 2023-10-07 07:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 07:55:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:55:16 --> Model Class Initialized
INFO - 2023-10-07 07:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 07:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 07:55:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:55:16 --> Final output sent to browser
DEBUG - 2023-10-07 07:55:16 --> Total execution time: 0.1245
ERROR - 2023-10-07 07:55:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:55:25 --> Config Class Initialized
INFO - 2023-10-07 07:55:25 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:55:25 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:55:25 --> Utf8 Class Initialized
INFO - 2023-10-07 07:55:25 --> URI Class Initialized
INFO - 2023-10-07 07:55:25 --> Router Class Initialized
INFO - 2023-10-07 07:55:25 --> Output Class Initialized
INFO - 2023-10-07 07:55:25 --> Security Class Initialized
DEBUG - 2023-10-07 07:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:55:25 --> Input Class Initialized
INFO - 2023-10-07 07:55:25 --> Language Class Initialized
INFO - 2023-10-07 07:55:25 --> Loader Class Initialized
INFO - 2023-10-07 07:55:25 --> Helper loaded: url_helper
INFO - 2023-10-07 07:55:25 --> Helper loaded: file_helper
INFO - 2023-10-07 07:55:25 --> Helper loaded: html_helper
INFO - 2023-10-07 07:55:25 --> Helper loaded: text_helper
INFO - 2023-10-07 07:55:25 --> Helper loaded: form_helper
INFO - 2023-10-07 07:55:25 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:55:25 --> Helper loaded: security_helper
INFO - 2023-10-07 07:55:25 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:55:25 --> Database Driver Class Initialized
INFO - 2023-10-07 07:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:55:25 --> Parser Class Initialized
INFO - 2023-10-07 07:55:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:55:25 --> Pagination Class Initialized
INFO - 2023-10-07 07:55:25 --> Form Validation Class Initialized
INFO - 2023-10-07 07:55:25 --> Controller Class Initialized
INFO - 2023-10-07 07:55:25 --> Model Class Initialized
DEBUG - 2023-10-07 07:55:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:55:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:55:25 --> Model Class Initialized
DEBUG - 2023-10-07 07:55:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:55:25 --> Model Class Initialized
INFO - 2023-10-07 07:55:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/invoice/invoice.php
DEBUG - 2023-10-07 07:55:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:55:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:55:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:55:25 --> Model Class Initialized
INFO - 2023-10-07 07:55:25 --> Model Class Initialized
INFO - 2023-10-07 07:55:25 --> Model Class Initialized
INFO - 2023-10-07 07:55:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 07:55:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 07:55:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:55:25 --> Final output sent to browser
DEBUG - 2023-10-07 07:55:25 --> Total execution time: 0.1001
ERROR - 2023-10-07 07:55:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:55:25 --> Config Class Initialized
INFO - 2023-10-07 07:55:25 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:55:25 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:55:25 --> Utf8 Class Initialized
INFO - 2023-10-07 07:55:25 --> URI Class Initialized
INFO - 2023-10-07 07:55:25 --> Router Class Initialized
INFO - 2023-10-07 07:55:25 --> Output Class Initialized
INFO - 2023-10-07 07:55:25 --> Security Class Initialized
DEBUG - 2023-10-07 07:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:55:25 --> Input Class Initialized
INFO - 2023-10-07 07:55:25 --> Language Class Initialized
INFO - 2023-10-07 07:55:25 --> Loader Class Initialized
INFO - 2023-10-07 07:55:25 --> Helper loaded: url_helper
INFO - 2023-10-07 07:55:25 --> Helper loaded: file_helper
INFO - 2023-10-07 07:55:25 --> Helper loaded: html_helper
INFO - 2023-10-07 07:55:25 --> Helper loaded: text_helper
INFO - 2023-10-07 07:55:25 --> Helper loaded: form_helper
INFO - 2023-10-07 07:55:25 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:55:25 --> Helper loaded: security_helper
INFO - 2023-10-07 07:55:25 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:55:25 --> Database Driver Class Initialized
INFO - 2023-10-07 07:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:55:25 --> Parser Class Initialized
INFO - 2023-10-07 07:55:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:55:25 --> Pagination Class Initialized
INFO - 2023-10-07 07:55:25 --> Form Validation Class Initialized
INFO - 2023-10-07 07:55:25 --> Controller Class Initialized
INFO - 2023-10-07 07:55:25 --> Model Class Initialized
DEBUG - 2023-10-07 07:55:25 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:55:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:55:25 --> Model Class Initialized
DEBUG - 2023-10-07 07:55:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:55:25 --> Model Class Initialized
INFO - 2023-10-07 07:55:25 --> Final output sent to browser
DEBUG - 2023-10-07 07:55:25 --> Total execution time: 0.0299
ERROR - 2023-10-07 07:55:34 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:55:34 --> Config Class Initialized
INFO - 2023-10-07 07:55:34 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:55:34 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:55:34 --> Utf8 Class Initialized
INFO - 2023-10-07 07:55:34 --> URI Class Initialized
DEBUG - 2023-10-07 07:55:34 --> No URI present. Default controller set.
INFO - 2023-10-07 07:55:34 --> Router Class Initialized
INFO - 2023-10-07 07:55:34 --> Output Class Initialized
INFO - 2023-10-07 07:55:34 --> Security Class Initialized
DEBUG - 2023-10-07 07:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:55:34 --> Input Class Initialized
INFO - 2023-10-07 07:55:34 --> Language Class Initialized
INFO - 2023-10-07 07:55:34 --> Loader Class Initialized
INFO - 2023-10-07 07:55:34 --> Helper loaded: url_helper
INFO - 2023-10-07 07:55:34 --> Helper loaded: file_helper
INFO - 2023-10-07 07:55:34 --> Helper loaded: html_helper
INFO - 2023-10-07 07:55:34 --> Helper loaded: text_helper
INFO - 2023-10-07 07:55:34 --> Helper loaded: form_helper
INFO - 2023-10-07 07:55:34 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:55:34 --> Helper loaded: security_helper
INFO - 2023-10-07 07:55:34 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:55:34 --> Database Driver Class Initialized
INFO - 2023-10-07 07:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:55:34 --> Parser Class Initialized
INFO - 2023-10-07 07:55:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:55:34 --> Pagination Class Initialized
INFO - 2023-10-07 07:55:34 --> Form Validation Class Initialized
INFO - 2023-10-07 07:55:34 --> Controller Class Initialized
INFO - 2023-10-07 07:55:34 --> Model Class Initialized
DEBUG - 2023-10-07 07:55:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:55:34 --> Model Class Initialized
DEBUG - 2023-10-07 07:55:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:55:34 --> Model Class Initialized
INFO - 2023-10-07 07:55:34 --> Model Class Initialized
INFO - 2023-10-07 07:55:34 --> Model Class Initialized
INFO - 2023-10-07 07:55:34 --> Model Class Initialized
DEBUG - 2023-10-07 07:55:34 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:55:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:55:34 --> Model Class Initialized
INFO - 2023-10-07 07:55:34 --> Model Class Initialized
INFO - 2023-10-07 07:55:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 07:55:34 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:55:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:55:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:55:34 --> Model Class Initialized
INFO - 2023-10-07 07:55:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 07:55:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 07:55:34 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:55:34 --> Final output sent to browser
DEBUG - 2023-10-07 07:55:34 --> Total execution time: 0.1089
ERROR - 2023-10-07 07:56:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:56:21 --> Config Class Initialized
INFO - 2023-10-07 07:56:21 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:56:21 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:56:21 --> Utf8 Class Initialized
INFO - 2023-10-07 07:56:21 --> URI Class Initialized
DEBUG - 2023-10-07 07:56:21 --> No URI present. Default controller set.
INFO - 2023-10-07 07:56:21 --> Router Class Initialized
INFO - 2023-10-07 07:56:21 --> Output Class Initialized
INFO - 2023-10-07 07:56:21 --> Security Class Initialized
DEBUG - 2023-10-07 07:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:56:21 --> Input Class Initialized
INFO - 2023-10-07 07:56:21 --> Language Class Initialized
INFO - 2023-10-07 07:56:21 --> Loader Class Initialized
INFO - 2023-10-07 07:56:21 --> Helper loaded: url_helper
INFO - 2023-10-07 07:56:21 --> Helper loaded: file_helper
INFO - 2023-10-07 07:56:21 --> Helper loaded: html_helper
INFO - 2023-10-07 07:56:21 --> Helper loaded: text_helper
INFO - 2023-10-07 07:56:21 --> Helper loaded: form_helper
INFO - 2023-10-07 07:56:21 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:56:21 --> Helper loaded: security_helper
INFO - 2023-10-07 07:56:21 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:56:21 --> Database Driver Class Initialized
INFO - 2023-10-07 07:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:56:21 --> Parser Class Initialized
INFO - 2023-10-07 07:56:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:56:21 --> Pagination Class Initialized
INFO - 2023-10-07 07:56:21 --> Form Validation Class Initialized
INFO - 2023-10-07 07:56:21 --> Controller Class Initialized
INFO - 2023-10-07 07:56:21 --> Model Class Initialized
DEBUG - 2023-10-07 07:56:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:56:21 --> Model Class Initialized
DEBUG - 2023-10-07 07:56:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:56:21 --> Model Class Initialized
INFO - 2023-10-07 07:56:21 --> Model Class Initialized
INFO - 2023-10-07 07:56:21 --> Model Class Initialized
INFO - 2023-10-07 07:56:21 --> Model Class Initialized
DEBUG - 2023-10-07 07:56:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:56:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:56:21 --> Model Class Initialized
INFO - 2023-10-07 07:56:21 --> Model Class Initialized
INFO - 2023-10-07 07:56:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 07:56:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:56:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:56:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:56:21 --> Model Class Initialized
INFO - 2023-10-07 07:56:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 07:56:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 07:56:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:56:21 --> Final output sent to browser
DEBUG - 2023-10-07 07:56:21 --> Total execution time: 0.1143
ERROR - 2023-10-07 07:56:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:56:26 --> Config Class Initialized
INFO - 2023-10-07 07:56:26 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:56:26 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:56:26 --> Utf8 Class Initialized
INFO - 2023-10-07 07:56:26 --> URI Class Initialized
INFO - 2023-10-07 07:56:26 --> Router Class Initialized
INFO - 2023-10-07 07:56:26 --> Output Class Initialized
INFO - 2023-10-07 07:56:26 --> Security Class Initialized
DEBUG - 2023-10-07 07:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:56:26 --> Input Class Initialized
INFO - 2023-10-07 07:56:26 --> Language Class Initialized
INFO - 2023-10-07 07:56:26 --> Loader Class Initialized
INFO - 2023-10-07 07:56:26 --> Helper loaded: url_helper
INFO - 2023-10-07 07:56:26 --> Helper loaded: file_helper
INFO - 2023-10-07 07:56:26 --> Helper loaded: html_helper
INFO - 2023-10-07 07:56:26 --> Helper loaded: text_helper
INFO - 2023-10-07 07:56:26 --> Helper loaded: form_helper
INFO - 2023-10-07 07:56:26 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:56:26 --> Helper loaded: security_helper
INFO - 2023-10-07 07:56:26 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:56:26 --> Database Driver Class Initialized
INFO - 2023-10-07 07:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:56:26 --> Parser Class Initialized
INFO - 2023-10-07 07:56:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:56:26 --> Pagination Class Initialized
INFO - 2023-10-07 07:56:26 --> Form Validation Class Initialized
INFO - 2023-10-07 07:56:26 --> Controller Class Initialized
INFO - 2023-10-07 07:56:26 --> Model Class Initialized
DEBUG - 2023-10-07 07:56:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:56:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:56:26 --> Model Class Initialized
DEBUG - 2023-10-07 07:56:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:56:26 --> Model Class Initialized
INFO - 2023-10-07 07:56:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-07 07:56:26 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:56:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:56:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:56:26 --> Model Class Initialized
INFO - 2023-10-07 07:56:26 --> Model Class Initialized
INFO - 2023-10-07 07:56:26 --> Model Class Initialized
INFO - 2023-10-07 07:56:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 07:56:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 07:56:26 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:56:26 --> Final output sent to browser
DEBUG - 2023-10-07 07:56:26 --> Total execution time: 0.0875
ERROR - 2023-10-07 07:56:26 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:56:26 --> Config Class Initialized
INFO - 2023-10-07 07:56:26 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:56:26 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:56:26 --> Utf8 Class Initialized
INFO - 2023-10-07 07:56:26 --> URI Class Initialized
INFO - 2023-10-07 07:56:26 --> Router Class Initialized
INFO - 2023-10-07 07:56:26 --> Output Class Initialized
INFO - 2023-10-07 07:56:26 --> Security Class Initialized
DEBUG - 2023-10-07 07:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:56:26 --> Input Class Initialized
INFO - 2023-10-07 07:56:26 --> Language Class Initialized
INFO - 2023-10-07 07:56:26 --> Loader Class Initialized
INFO - 2023-10-07 07:56:26 --> Helper loaded: url_helper
INFO - 2023-10-07 07:56:26 --> Helper loaded: file_helper
INFO - 2023-10-07 07:56:26 --> Helper loaded: html_helper
INFO - 2023-10-07 07:56:26 --> Helper loaded: text_helper
INFO - 2023-10-07 07:56:26 --> Helper loaded: form_helper
INFO - 2023-10-07 07:56:26 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:56:26 --> Helper loaded: security_helper
INFO - 2023-10-07 07:56:26 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:56:26 --> Database Driver Class Initialized
INFO - 2023-10-07 07:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:56:26 --> Parser Class Initialized
INFO - 2023-10-07 07:56:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:56:26 --> Pagination Class Initialized
INFO - 2023-10-07 07:56:26 --> Form Validation Class Initialized
INFO - 2023-10-07 07:56:26 --> Controller Class Initialized
INFO - 2023-10-07 07:56:26 --> Model Class Initialized
DEBUG - 2023-10-07 07:56:26 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:56:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:56:26 --> Model Class Initialized
DEBUG - 2023-10-07 07:56:26 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:56:26 --> Model Class Initialized
INFO - 2023-10-07 07:56:26 --> Final output sent to browser
DEBUG - 2023-10-07 07:56:26 --> Total execution time: 0.0399
ERROR - 2023-10-07 07:56:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:56:30 --> Config Class Initialized
INFO - 2023-10-07 07:56:30 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:56:30 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:56:30 --> Utf8 Class Initialized
INFO - 2023-10-07 07:56:30 --> URI Class Initialized
INFO - 2023-10-07 07:56:30 --> Router Class Initialized
INFO - 2023-10-07 07:56:30 --> Output Class Initialized
INFO - 2023-10-07 07:56:30 --> Security Class Initialized
DEBUG - 2023-10-07 07:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:56:30 --> Input Class Initialized
INFO - 2023-10-07 07:56:30 --> Language Class Initialized
INFO - 2023-10-07 07:56:30 --> Loader Class Initialized
INFO - 2023-10-07 07:56:30 --> Helper loaded: url_helper
INFO - 2023-10-07 07:56:30 --> Helper loaded: file_helper
INFO - 2023-10-07 07:56:30 --> Helper loaded: html_helper
INFO - 2023-10-07 07:56:30 --> Helper loaded: text_helper
INFO - 2023-10-07 07:56:30 --> Helper loaded: form_helper
INFO - 2023-10-07 07:56:30 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:56:30 --> Helper loaded: security_helper
INFO - 2023-10-07 07:56:30 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:56:30 --> Database Driver Class Initialized
INFO - 2023-10-07 07:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:56:30 --> Parser Class Initialized
INFO - 2023-10-07 07:56:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:56:30 --> Pagination Class Initialized
INFO - 2023-10-07 07:56:30 --> Form Validation Class Initialized
INFO - 2023-10-07 07:56:30 --> Controller Class Initialized
INFO - 2023-10-07 07:56:30 --> Model Class Initialized
DEBUG - 2023-10-07 07:56:30 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:56:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:56:30 --> Model Class Initialized
DEBUG - 2023-10-07 07:56:30 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:56:30 --> Model Class Initialized
INFO - 2023-10-07 07:56:30 --> Final output sent to browser
DEBUG - 2023-10-07 07:56:30 --> Total execution time: 0.0545
ERROR - 2023-10-07 07:56:58 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:56:58 --> Config Class Initialized
INFO - 2023-10-07 07:56:58 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:56:58 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:56:58 --> Utf8 Class Initialized
INFO - 2023-10-07 07:56:58 --> URI Class Initialized
DEBUG - 2023-10-07 07:56:58 --> No URI present. Default controller set.
INFO - 2023-10-07 07:56:58 --> Router Class Initialized
INFO - 2023-10-07 07:56:58 --> Output Class Initialized
INFO - 2023-10-07 07:56:58 --> Security Class Initialized
DEBUG - 2023-10-07 07:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:56:58 --> Input Class Initialized
INFO - 2023-10-07 07:56:58 --> Language Class Initialized
INFO - 2023-10-07 07:56:58 --> Loader Class Initialized
INFO - 2023-10-07 07:56:58 --> Helper loaded: url_helper
INFO - 2023-10-07 07:56:58 --> Helper loaded: file_helper
INFO - 2023-10-07 07:56:58 --> Helper loaded: html_helper
INFO - 2023-10-07 07:56:58 --> Helper loaded: text_helper
INFO - 2023-10-07 07:56:58 --> Helper loaded: form_helper
INFO - 2023-10-07 07:56:58 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:56:58 --> Helper loaded: security_helper
INFO - 2023-10-07 07:56:58 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:56:58 --> Database Driver Class Initialized
INFO - 2023-10-07 07:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:56:58 --> Parser Class Initialized
INFO - 2023-10-07 07:56:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:56:58 --> Pagination Class Initialized
INFO - 2023-10-07 07:56:58 --> Form Validation Class Initialized
INFO - 2023-10-07 07:56:58 --> Controller Class Initialized
INFO - 2023-10-07 07:56:58 --> Model Class Initialized
DEBUG - 2023-10-07 07:56:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:56:58 --> Model Class Initialized
DEBUG - 2023-10-07 07:56:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:56:58 --> Model Class Initialized
INFO - 2023-10-07 07:56:58 --> Model Class Initialized
INFO - 2023-10-07 07:56:58 --> Model Class Initialized
INFO - 2023-10-07 07:56:58 --> Model Class Initialized
DEBUG - 2023-10-07 07:56:58 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:56:58 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:56:58 --> Model Class Initialized
INFO - 2023-10-07 07:56:58 --> Model Class Initialized
INFO - 2023-10-07 07:56:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 07:56:58 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:56:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:56:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:56:58 --> Model Class Initialized
INFO - 2023-10-07 07:56:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 07:56:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 07:56:58 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:56:58 --> Final output sent to browser
DEBUG - 2023-10-07 07:56:58 --> Total execution time: 0.2202
ERROR - 2023-10-07 07:57:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:57:07 --> Config Class Initialized
INFO - 2023-10-07 07:57:07 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:57:07 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:57:07 --> Utf8 Class Initialized
INFO - 2023-10-07 07:57:07 --> URI Class Initialized
INFO - 2023-10-07 07:57:07 --> Router Class Initialized
INFO - 2023-10-07 07:57:07 --> Output Class Initialized
INFO - 2023-10-07 07:57:07 --> Security Class Initialized
DEBUG - 2023-10-07 07:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:57:07 --> Input Class Initialized
INFO - 2023-10-07 07:57:07 --> Language Class Initialized
INFO - 2023-10-07 07:57:07 --> Loader Class Initialized
INFO - 2023-10-07 07:57:07 --> Helper loaded: url_helper
INFO - 2023-10-07 07:57:07 --> Helper loaded: file_helper
INFO - 2023-10-07 07:57:07 --> Helper loaded: html_helper
INFO - 2023-10-07 07:57:07 --> Helper loaded: text_helper
INFO - 2023-10-07 07:57:07 --> Helper loaded: form_helper
INFO - 2023-10-07 07:57:07 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:57:07 --> Helper loaded: security_helper
INFO - 2023-10-07 07:57:07 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:57:07 --> Database Driver Class Initialized
INFO - 2023-10-07 07:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:57:08 --> Parser Class Initialized
INFO - 2023-10-07 07:57:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:57:08 --> Pagination Class Initialized
INFO - 2023-10-07 07:57:08 --> Form Validation Class Initialized
INFO - 2023-10-07 07:57:08 --> Controller Class Initialized
INFO - 2023-10-07 07:57:08 --> Model Class Initialized
DEBUG - 2023-10-07 07:57:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:57:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:57:08 --> Model Class Initialized
DEBUG - 2023-10-07 07:57:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:57:08 --> Model Class Initialized
INFO - 2023-10-07 07:57:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-07 07:57:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:57:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:57:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:57:08 --> Model Class Initialized
INFO - 2023-10-07 07:57:08 --> Model Class Initialized
INFO - 2023-10-07 07:57:08 --> Model Class Initialized
INFO - 2023-10-07 07:57:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 07:57:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 07:57:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:57:08 --> Final output sent to browser
DEBUG - 2023-10-07 07:57:08 --> Total execution time: 0.1559
ERROR - 2023-10-07 07:57:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:57:08 --> Config Class Initialized
INFO - 2023-10-07 07:57:08 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:57:08 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:57:08 --> Utf8 Class Initialized
INFO - 2023-10-07 07:57:08 --> URI Class Initialized
INFO - 2023-10-07 07:57:08 --> Router Class Initialized
INFO - 2023-10-07 07:57:08 --> Output Class Initialized
INFO - 2023-10-07 07:57:08 --> Security Class Initialized
DEBUG - 2023-10-07 07:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:57:08 --> Input Class Initialized
INFO - 2023-10-07 07:57:08 --> Language Class Initialized
INFO - 2023-10-07 07:57:08 --> Loader Class Initialized
INFO - 2023-10-07 07:57:08 --> Helper loaded: url_helper
INFO - 2023-10-07 07:57:08 --> Helper loaded: file_helper
INFO - 2023-10-07 07:57:08 --> Helper loaded: html_helper
INFO - 2023-10-07 07:57:08 --> Helper loaded: text_helper
INFO - 2023-10-07 07:57:08 --> Helper loaded: form_helper
INFO - 2023-10-07 07:57:08 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:57:08 --> Helper loaded: security_helper
INFO - 2023-10-07 07:57:08 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:57:08 --> Database Driver Class Initialized
INFO - 2023-10-07 07:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:57:08 --> Parser Class Initialized
INFO - 2023-10-07 07:57:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:57:08 --> Pagination Class Initialized
INFO - 2023-10-07 07:57:08 --> Form Validation Class Initialized
INFO - 2023-10-07 07:57:08 --> Controller Class Initialized
INFO - 2023-10-07 07:57:08 --> Model Class Initialized
DEBUG - 2023-10-07 07:57:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:57:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:57:08 --> Model Class Initialized
DEBUG - 2023-10-07 07:57:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:57:08 --> Model Class Initialized
INFO - 2023-10-07 07:57:08 --> Final output sent to browser
DEBUG - 2023-10-07 07:57:08 --> Total execution time: 0.0581
ERROR - 2023-10-07 07:57:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:57:23 --> Config Class Initialized
INFO - 2023-10-07 07:57:23 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:57:23 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:57:23 --> Utf8 Class Initialized
INFO - 2023-10-07 07:57:23 --> URI Class Initialized
INFO - 2023-10-07 07:57:23 --> Router Class Initialized
INFO - 2023-10-07 07:57:23 --> Output Class Initialized
INFO - 2023-10-07 07:57:23 --> Security Class Initialized
DEBUG - 2023-10-07 07:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:57:23 --> Input Class Initialized
INFO - 2023-10-07 07:57:23 --> Language Class Initialized
INFO - 2023-10-07 07:57:23 --> Loader Class Initialized
INFO - 2023-10-07 07:57:23 --> Helper loaded: url_helper
INFO - 2023-10-07 07:57:23 --> Helper loaded: file_helper
INFO - 2023-10-07 07:57:23 --> Helper loaded: html_helper
INFO - 2023-10-07 07:57:23 --> Helper loaded: text_helper
INFO - 2023-10-07 07:57:23 --> Helper loaded: form_helper
INFO - 2023-10-07 07:57:23 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:57:23 --> Helper loaded: security_helper
INFO - 2023-10-07 07:57:23 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:57:23 --> Database Driver Class Initialized
INFO - 2023-10-07 07:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:57:23 --> Parser Class Initialized
INFO - 2023-10-07 07:57:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:57:23 --> Pagination Class Initialized
INFO - 2023-10-07 07:57:23 --> Form Validation Class Initialized
INFO - 2023-10-07 07:57:23 --> Controller Class Initialized
INFO - 2023-10-07 07:57:23 --> Model Class Initialized
DEBUG - 2023-10-07 07:57:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:57:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:57:23 --> Model Class Initialized
DEBUG - 2023-10-07 07:57:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:57:23 --> Model Class Initialized
DEBUG - 2023-10-07 07:57:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:57:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice_html.php
DEBUG - 2023-10-07 07:57:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:57:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:57:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:57:23 --> Model Class Initialized
INFO - 2023-10-07 07:57:23 --> Model Class Initialized
INFO - 2023-10-07 07:57:23 --> Model Class Initialized
INFO - 2023-10-07 07:57:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 07:57:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 07:57:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:57:23 --> Final output sent to browser
DEBUG - 2023-10-07 07:57:23 --> Total execution time: 0.1687
ERROR - 2023-10-07 07:58:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 07:58:48 --> Config Class Initialized
INFO - 2023-10-07 07:58:48 --> Hooks Class Initialized
DEBUG - 2023-10-07 07:58:48 --> UTF-8 Support Enabled
INFO - 2023-10-07 07:58:48 --> Utf8 Class Initialized
INFO - 2023-10-07 07:58:48 --> URI Class Initialized
DEBUG - 2023-10-07 07:58:48 --> No URI present. Default controller set.
INFO - 2023-10-07 07:58:48 --> Router Class Initialized
INFO - 2023-10-07 07:58:48 --> Output Class Initialized
INFO - 2023-10-07 07:58:48 --> Security Class Initialized
DEBUG - 2023-10-07 07:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 07:58:48 --> Input Class Initialized
INFO - 2023-10-07 07:58:48 --> Language Class Initialized
INFO - 2023-10-07 07:58:48 --> Loader Class Initialized
INFO - 2023-10-07 07:58:48 --> Helper loaded: url_helper
INFO - 2023-10-07 07:58:48 --> Helper loaded: file_helper
INFO - 2023-10-07 07:58:48 --> Helper loaded: html_helper
INFO - 2023-10-07 07:58:48 --> Helper loaded: text_helper
INFO - 2023-10-07 07:58:48 --> Helper loaded: form_helper
INFO - 2023-10-07 07:58:48 --> Helper loaded: lang_helper
INFO - 2023-10-07 07:58:48 --> Helper loaded: security_helper
INFO - 2023-10-07 07:58:48 --> Helper loaded: cookie_helper
INFO - 2023-10-07 07:58:48 --> Database Driver Class Initialized
INFO - 2023-10-07 07:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 07:58:48 --> Parser Class Initialized
INFO - 2023-10-07 07:58:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 07:58:48 --> Pagination Class Initialized
INFO - 2023-10-07 07:58:48 --> Form Validation Class Initialized
INFO - 2023-10-07 07:58:48 --> Controller Class Initialized
INFO - 2023-10-07 07:58:48 --> Model Class Initialized
DEBUG - 2023-10-07 07:58:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:58:48 --> Model Class Initialized
DEBUG - 2023-10-07 07:58:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:58:48 --> Model Class Initialized
INFO - 2023-10-07 07:58:48 --> Model Class Initialized
INFO - 2023-10-07 07:58:48 --> Model Class Initialized
INFO - 2023-10-07 07:58:48 --> Model Class Initialized
DEBUG - 2023-10-07 07:58:48 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 07:58:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:58:48 --> Model Class Initialized
INFO - 2023-10-07 07:58:48 --> Model Class Initialized
INFO - 2023-10-07 07:58:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 07:58:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 07:58:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 07:58:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 07:58:48 --> Model Class Initialized
INFO - 2023-10-07 07:58:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 07:58:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 07:58:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 07:58:48 --> Final output sent to browser
DEBUG - 2023-10-07 07:58:48 --> Total execution time: 0.2180
ERROR - 2023-10-07 12:57:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 12:57:20 --> Config Class Initialized
INFO - 2023-10-07 12:57:20 --> Hooks Class Initialized
DEBUG - 2023-10-07 12:57:20 --> UTF-8 Support Enabled
INFO - 2023-10-07 12:57:20 --> Utf8 Class Initialized
INFO - 2023-10-07 12:57:20 --> URI Class Initialized
DEBUG - 2023-10-07 12:57:20 --> No URI present. Default controller set.
INFO - 2023-10-07 12:57:20 --> Router Class Initialized
INFO - 2023-10-07 12:57:20 --> Output Class Initialized
INFO - 2023-10-07 12:57:20 --> Security Class Initialized
DEBUG - 2023-10-07 12:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 12:57:20 --> Input Class Initialized
INFO - 2023-10-07 12:57:20 --> Language Class Initialized
INFO - 2023-10-07 12:57:20 --> Loader Class Initialized
INFO - 2023-10-07 12:57:20 --> Helper loaded: url_helper
INFO - 2023-10-07 12:57:20 --> Helper loaded: file_helper
INFO - 2023-10-07 12:57:20 --> Helper loaded: html_helper
INFO - 2023-10-07 12:57:20 --> Helper loaded: text_helper
INFO - 2023-10-07 12:57:20 --> Helper loaded: form_helper
INFO - 2023-10-07 12:57:20 --> Helper loaded: lang_helper
INFO - 2023-10-07 12:57:20 --> Helper loaded: security_helper
INFO - 2023-10-07 12:57:20 --> Helper loaded: cookie_helper
INFO - 2023-10-07 12:57:20 --> Database Driver Class Initialized
INFO - 2023-10-07 12:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 12:57:20 --> Parser Class Initialized
INFO - 2023-10-07 12:57:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 12:57:20 --> Pagination Class Initialized
INFO - 2023-10-07 12:57:20 --> Form Validation Class Initialized
INFO - 2023-10-07 12:57:20 --> Controller Class Initialized
INFO - 2023-10-07 12:57:20 --> Model Class Initialized
DEBUG - 2023-10-07 12:57:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-07 12:57:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 12:57:20 --> Config Class Initialized
INFO - 2023-10-07 12:57:20 --> Hooks Class Initialized
DEBUG - 2023-10-07 12:57:20 --> UTF-8 Support Enabled
INFO - 2023-10-07 12:57:20 --> Utf8 Class Initialized
INFO - 2023-10-07 12:57:20 --> URI Class Initialized
INFO - 2023-10-07 12:57:20 --> Router Class Initialized
INFO - 2023-10-07 12:57:20 --> Output Class Initialized
INFO - 2023-10-07 12:57:20 --> Security Class Initialized
DEBUG - 2023-10-07 12:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 12:57:20 --> Input Class Initialized
INFO - 2023-10-07 12:57:20 --> Language Class Initialized
INFO - 2023-10-07 12:57:20 --> Loader Class Initialized
INFO - 2023-10-07 12:57:20 --> Helper loaded: url_helper
INFO - 2023-10-07 12:57:20 --> Helper loaded: file_helper
INFO - 2023-10-07 12:57:20 --> Helper loaded: html_helper
INFO - 2023-10-07 12:57:20 --> Helper loaded: text_helper
INFO - 2023-10-07 12:57:20 --> Helper loaded: form_helper
INFO - 2023-10-07 12:57:20 --> Helper loaded: lang_helper
INFO - 2023-10-07 12:57:20 --> Helper loaded: security_helper
INFO - 2023-10-07 12:57:20 --> Helper loaded: cookie_helper
INFO - 2023-10-07 12:57:20 --> Database Driver Class Initialized
INFO - 2023-10-07 12:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 12:57:20 --> Parser Class Initialized
INFO - 2023-10-07 12:57:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 12:57:20 --> Pagination Class Initialized
INFO - 2023-10-07 12:57:20 --> Form Validation Class Initialized
INFO - 2023-10-07 12:57:20 --> Controller Class Initialized
INFO - 2023-10-07 12:57:20 --> Model Class Initialized
DEBUG - 2023-10-07 12:57:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:57:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-07 12:57:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:57:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 12:57:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 12:57:20 --> Model Class Initialized
INFO - 2023-10-07 12:57:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 12:57:20 --> Final output sent to browser
DEBUG - 2023-10-07 12:57:20 --> Total execution time: 0.0315
ERROR - 2023-10-07 12:57:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 12:57:42 --> Config Class Initialized
INFO - 2023-10-07 12:57:42 --> Hooks Class Initialized
DEBUG - 2023-10-07 12:57:42 --> UTF-8 Support Enabled
INFO - 2023-10-07 12:57:42 --> Utf8 Class Initialized
INFO - 2023-10-07 12:57:42 --> URI Class Initialized
INFO - 2023-10-07 12:57:42 --> Router Class Initialized
INFO - 2023-10-07 12:57:42 --> Output Class Initialized
INFO - 2023-10-07 12:57:42 --> Security Class Initialized
DEBUG - 2023-10-07 12:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 12:57:42 --> Input Class Initialized
INFO - 2023-10-07 12:57:42 --> Language Class Initialized
INFO - 2023-10-07 12:57:42 --> Loader Class Initialized
INFO - 2023-10-07 12:57:42 --> Helper loaded: url_helper
INFO - 2023-10-07 12:57:42 --> Helper loaded: file_helper
INFO - 2023-10-07 12:57:42 --> Helper loaded: html_helper
INFO - 2023-10-07 12:57:42 --> Helper loaded: text_helper
INFO - 2023-10-07 12:57:42 --> Helper loaded: form_helper
INFO - 2023-10-07 12:57:42 --> Helper loaded: lang_helper
INFO - 2023-10-07 12:57:42 --> Helper loaded: security_helper
INFO - 2023-10-07 12:57:42 --> Helper loaded: cookie_helper
INFO - 2023-10-07 12:57:42 --> Database Driver Class Initialized
INFO - 2023-10-07 12:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 12:57:42 --> Parser Class Initialized
INFO - 2023-10-07 12:57:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 12:57:42 --> Pagination Class Initialized
INFO - 2023-10-07 12:57:42 --> Form Validation Class Initialized
INFO - 2023-10-07 12:57:42 --> Controller Class Initialized
INFO - 2023-10-07 12:57:42 --> Model Class Initialized
DEBUG - 2023-10-07 12:57:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:57:42 --> Model Class Initialized
INFO - 2023-10-07 12:57:42 --> Final output sent to browser
DEBUG - 2023-10-07 12:57:42 --> Total execution time: 0.0220
ERROR - 2023-10-07 12:57:42 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 12:57:42 --> Config Class Initialized
INFO - 2023-10-07 12:57:42 --> Hooks Class Initialized
DEBUG - 2023-10-07 12:57:42 --> UTF-8 Support Enabled
INFO - 2023-10-07 12:57:42 --> Utf8 Class Initialized
INFO - 2023-10-07 12:57:42 --> URI Class Initialized
DEBUG - 2023-10-07 12:57:42 --> No URI present. Default controller set.
INFO - 2023-10-07 12:57:42 --> Router Class Initialized
INFO - 2023-10-07 12:57:42 --> Output Class Initialized
INFO - 2023-10-07 12:57:42 --> Security Class Initialized
DEBUG - 2023-10-07 12:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 12:57:42 --> Input Class Initialized
INFO - 2023-10-07 12:57:42 --> Language Class Initialized
INFO - 2023-10-07 12:57:42 --> Loader Class Initialized
INFO - 2023-10-07 12:57:42 --> Helper loaded: url_helper
INFO - 2023-10-07 12:57:42 --> Helper loaded: file_helper
INFO - 2023-10-07 12:57:42 --> Helper loaded: html_helper
INFO - 2023-10-07 12:57:42 --> Helper loaded: text_helper
INFO - 2023-10-07 12:57:42 --> Helper loaded: form_helper
INFO - 2023-10-07 12:57:42 --> Helper loaded: lang_helper
INFO - 2023-10-07 12:57:42 --> Helper loaded: security_helper
INFO - 2023-10-07 12:57:42 --> Helper loaded: cookie_helper
INFO - 2023-10-07 12:57:42 --> Database Driver Class Initialized
INFO - 2023-10-07 12:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 12:57:42 --> Parser Class Initialized
INFO - 2023-10-07 12:57:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 12:57:42 --> Pagination Class Initialized
INFO - 2023-10-07 12:57:42 --> Form Validation Class Initialized
INFO - 2023-10-07 12:57:42 --> Controller Class Initialized
INFO - 2023-10-07 12:57:42 --> Model Class Initialized
DEBUG - 2023-10-07 12:57:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:57:42 --> Model Class Initialized
DEBUG - 2023-10-07 12:57:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:57:42 --> Model Class Initialized
INFO - 2023-10-07 12:57:42 --> Model Class Initialized
INFO - 2023-10-07 12:57:42 --> Model Class Initialized
INFO - 2023-10-07 12:57:42 --> Model Class Initialized
DEBUG - 2023-10-07 12:57:42 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 12:57:42 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:57:42 --> Model Class Initialized
INFO - 2023-10-07 12:57:42 --> Model Class Initialized
INFO - 2023-10-07 12:57:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 12:57:42 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:57:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 12:57:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 12:57:42 --> Model Class Initialized
INFO - 2023-10-07 12:57:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 12:57:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 12:57:42 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 12:57:42 --> Final output sent to browser
DEBUG - 2023-10-07 12:57:42 --> Total execution time: 0.1103
ERROR - 2023-10-07 12:58:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 12:58:19 --> Config Class Initialized
INFO - 2023-10-07 12:58:19 --> Hooks Class Initialized
DEBUG - 2023-10-07 12:58:19 --> UTF-8 Support Enabled
INFO - 2023-10-07 12:58:19 --> Utf8 Class Initialized
INFO - 2023-10-07 12:58:19 --> URI Class Initialized
INFO - 2023-10-07 12:58:19 --> Router Class Initialized
INFO - 2023-10-07 12:58:19 --> Output Class Initialized
INFO - 2023-10-07 12:58:19 --> Security Class Initialized
DEBUG - 2023-10-07 12:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 12:58:19 --> Input Class Initialized
INFO - 2023-10-07 12:58:19 --> Language Class Initialized
INFO - 2023-10-07 12:58:19 --> Loader Class Initialized
INFO - 2023-10-07 12:58:19 --> Helper loaded: url_helper
INFO - 2023-10-07 12:58:19 --> Helper loaded: file_helper
INFO - 2023-10-07 12:58:19 --> Helper loaded: html_helper
INFO - 2023-10-07 12:58:19 --> Helper loaded: text_helper
INFO - 2023-10-07 12:58:19 --> Helper loaded: form_helper
INFO - 2023-10-07 12:58:19 --> Helper loaded: lang_helper
INFO - 2023-10-07 12:58:19 --> Helper loaded: security_helper
INFO - 2023-10-07 12:58:19 --> Helper loaded: cookie_helper
INFO - 2023-10-07 12:58:19 --> Database Driver Class Initialized
INFO - 2023-10-07 12:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 12:58:19 --> Parser Class Initialized
INFO - 2023-10-07 12:58:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 12:58:19 --> Pagination Class Initialized
INFO - 2023-10-07 12:58:19 --> Form Validation Class Initialized
INFO - 2023-10-07 12:58:19 --> Controller Class Initialized
INFO - 2023-10-07 12:58:19 --> Model Class Initialized
DEBUG - 2023-10-07 12:58:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:58:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-07 12:58:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:58:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 12:58:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 12:58:19 --> Model Class Initialized
INFO - 2023-10-07 12:58:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 12:58:19 --> Final output sent to browser
DEBUG - 2023-10-07 12:58:19 --> Total execution time: 0.0324
ERROR - 2023-10-07 12:58:19 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 12:58:19 --> Config Class Initialized
INFO - 2023-10-07 12:58:19 --> Hooks Class Initialized
DEBUG - 2023-10-07 12:58:19 --> UTF-8 Support Enabled
INFO - 2023-10-07 12:58:19 --> Utf8 Class Initialized
INFO - 2023-10-07 12:58:19 --> URI Class Initialized
INFO - 2023-10-07 12:58:19 --> Router Class Initialized
INFO - 2023-10-07 12:58:19 --> Output Class Initialized
INFO - 2023-10-07 12:58:19 --> Security Class Initialized
DEBUG - 2023-10-07 12:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 12:58:19 --> Input Class Initialized
INFO - 2023-10-07 12:58:19 --> Language Class Initialized
INFO - 2023-10-07 12:58:19 --> Loader Class Initialized
INFO - 2023-10-07 12:58:19 --> Helper loaded: url_helper
INFO - 2023-10-07 12:58:19 --> Helper loaded: file_helper
INFO - 2023-10-07 12:58:19 --> Helper loaded: html_helper
INFO - 2023-10-07 12:58:19 --> Helper loaded: text_helper
INFO - 2023-10-07 12:58:19 --> Helper loaded: form_helper
INFO - 2023-10-07 12:58:19 --> Helper loaded: lang_helper
INFO - 2023-10-07 12:58:19 --> Helper loaded: security_helper
INFO - 2023-10-07 12:58:19 --> Helper loaded: cookie_helper
INFO - 2023-10-07 12:58:19 --> Database Driver Class Initialized
INFO - 2023-10-07 12:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 12:58:19 --> Parser Class Initialized
INFO - 2023-10-07 12:58:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 12:58:19 --> Pagination Class Initialized
INFO - 2023-10-07 12:58:19 --> Form Validation Class Initialized
INFO - 2023-10-07 12:58:19 --> Controller Class Initialized
INFO - 2023-10-07 12:58:19 --> Model Class Initialized
DEBUG - 2023-10-07 12:58:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:58:19 --> Model Class Initialized
DEBUG - 2023-10-07 12:58:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:58:19 --> Model Class Initialized
INFO - 2023-10-07 12:58:19 --> Model Class Initialized
INFO - 2023-10-07 12:58:19 --> Model Class Initialized
INFO - 2023-10-07 12:58:19 --> Model Class Initialized
DEBUG - 2023-10-07 12:58:19 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 12:58:19 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:58:19 --> Model Class Initialized
INFO - 2023-10-07 12:58:19 --> Model Class Initialized
INFO - 2023-10-07 12:58:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 12:58:19 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:58:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 12:58:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 12:58:19 --> Model Class Initialized
INFO - 2023-10-07 12:58:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 12:58:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 12:58:19 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 12:58:19 --> Final output sent to browser
DEBUG - 2023-10-07 12:58:19 --> Total execution time: 0.1133
ERROR - 2023-10-07 12:58:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 12:58:24 --> Config Class Initialized
INFO - 2023-10-07 12:58:24 --> Hooks Class Initialized
DEBUG - 2023-10-07 12:58:24 --> UTF-8 Support Enabled
INFO - 2023-10-07 12:58:24 --> Utf8 Class Initialized
INFO - 2023-10-07 12:58:24 --> URI Class Initialized
DEBUG - 2023-10-07 12:58:24 --> No URI present. Default controller set.
INFO - 2023-10-07 12:58:24 --> Router Class Initialized
INFO - 2023-10-07 12:58:24 --> Output Class Initialized
INFO - 2023-10-07 12:58:24 --> Security Class Initialized
DEBUG - 2023-10-07 12:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 12:58:24 --> Input Class Initialized
INFO - 2023-10-07 12:58:24 --> Language Class Initialized
INFO - 2023-10-07 12:58:24 --> Loader Class Initialized
INFO - 2023-10-07 12:58:24 --> Helper loaded: url_helper
INFO - 2023-10-07 12:58:24 --> Helper loaded: file_helper
INFO - 2023-10-07 12:58:24 --> Helper loaded: html_helper
INFO - 2023-10-07 12:58:24 --> Helper loaded: text_helper
INFO - 2023-10-07 12:58:24 --> Helper loaded: form_helper
INFO - 2023-10-07 12:58:24 --> Helper loaded: lang_helper
INFO - 2023-10-07 12:58:24 --> Helper loaded: security_helper
INFO - 2023-10-07 12:58:24 --> Helper loaded: cookie_helper
INFO - 2023-10-07 12:58:24 --> Database Driver Class Initialized
INFO - 2023-10-07 12:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 12:58:24 --> Parser Class Initialized
INFO - 2023-10-07 12:58:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 12:58:24 --> Pagination Class Initialized
INFO - 2023-10-07 12:58:24 --> Form Validation Class Initialized
INFO - 2023-10-07 12:58:24 --> Controller Class Initialized
INFO - 2023-10-07 12:58:24 --> Model Class Initialized
DEBUG - 2023-10-07 12:58:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:58:24 --> Model Class Initialized
DEBUG - 2023-10-07 12:58:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:58:24 --> Model Class Initialized
INFO - 2023-10-07 12:58:24 --> Model Class Initialized
INFO - 2023-10-07 12:58:24 --> Model Class Initialized
INFO - 2023-10-07 12:58:24 --> Model Class Initialized
DEBUG - 2023-10-07 12:58:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 12:58:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:58:24 --> Model Class Initialized
INFO - 2023-10-07 12:58:24 --> Model Class Initialized
INFO - 2023-10-07 12:58:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 12:58:24 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:58:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 12:58:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 12:58:24 --> Model Class Initialized
INFO - 2023-10-07 12:58:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 12:58:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 12:58:24 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 12:58:24 --> Final output sent to browser
DEBUG - 2023-10-07 12:58:24 --> Total execution time: 0.1066
ERROR - 2023-10-07 12:59:06 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 12:59:06 --> Config Class Initialized
INFO - 2023-10-07 12:59:06 --> Hooks Class Initialized
DEBUG - 2023-10-07 12:59:06 --> UTF-8 Support Enabled
INFO - 2023-10-07 12:59:06 --> Utf8 Class Initialized
INFO - 2023-10-07 12:59:06 --> URI Class Initialized
INFO - 2023-10-07 12:59:06 --> Router Class Initialized
INFO - 2023-10-07 12:59:06 --> Output Class Initialized
INFO - 2023-10-07 12:59:06 --> Security Class Initialized
DEBUG - 2023-10-07 12:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 12:59:06 --> Input Class Initialized
INFO - 2023-10-07 12:59:06 --> Language Class Initialized
INFO - 2023-10-07 12:59:06 --> Loader Class Initialized
INFO - 2023-10-07 12:59:06 --> Helper loaded: url_helper
INFO - 2023-10-07 12:59:06 --> Helper loaded: file_helper
INFO - 2023-10-07 12:59:06 --> Helper loaded: html_helper
INFO - 2023-10-07 12:59:06 --> Helper loaded: text_helper
INFO - 2023-10-07 12:59:06 --> Helper loaded: form_helper
INFO - 2023-10-07 12:59:06 --> Helper loaded: lang_helper
INFO - 2023-10-07 12:59:06 --> Helper loaded: security_helper
INFO - 2023-10-07 12:59:06 --> Helper loaded: cookie_helper
INFO - 2023-10-07 12:59:06 --> Database Driver Class Initialized
INFO - 2023-10-07 12:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 12:59:06 --> Parser Class Initialized
INFO - 2023-10-07 12:59:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 12:59:06 --> Pagination Class Initialized
INFO - 2023-10-07 12:59:06 --> Form Validation Class Initialized
INFO - 2023-10-07 12:59:06 --> Controller Class Initialized
DEBUG - 2023-10-07 12:59:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 12:59:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:59:06 --> Model Class Initialized
DEBUG - 2023-10-07 12:59:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 12:59:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 12:59:06 --> Ltarget class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:59:06 --> Model Class Initialized
DEBUG - 2023-10-07 12:59:06 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 12:59:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:59:06 --> Model Class Initialized
DEBUG - 2023-10-07 12:59:06 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:59:06 --> Model Class Initialized
INFO - 2023-10-07 12:59:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/target/target.php
DEBUG - 2023-10-07 12:59:06 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:59:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 12:59:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 12:59:06 --> Model Class Initialized
INFO - 2023-10-07 12:59:06 --> Model Class Initialized
INFO - 2023-10-07 12:59:06 --> Model Class Initialized
INFO - 2023-10-07 12:59:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 12:59:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 12:59:06 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 12:59:06 --> Final output sent to browser
DEBUG - 2023-10-07 12:59:06 --> Total execution time: 0.0856
ERROR - 2023-10-07 12:59:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 12:59:07 --> Config Class Initialized
INFO - 2023-10-07 12:59:07 --> Hooks Class Initialized
DEBUG - 2023-10-07 12:59:07 --> UTF-8 Support Enabled
INFO - 2023-10-07 12:59:07 --> Utf8 Class Initialized
INFO - 2023-10-07 12:59:07 --> URI Class Initialized
INFO - 2023-10-07 12:59:07 --> Router Class Initialized
INFO - 2023-10-07 12:59:07 --> Output Class Initialized
INFO - 2023-10-07 12:59:07 --> Security Class Initialized
DEBUG - 2023-10-07 12:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 12:59:07 --> Input Class Initialized
INFO - 2023-10-07 12:59:07 --> Language Class Initialized
INFO - 2023-10-07 12:59:07 --> Loader Class Initialized
INFO - 2023-10-07 12:59:07 --> Helper loaded: url_helper
INFO - 2023-10-07 12:59:07 --> Helper loaded: file_helper
INFO - 2023-10-07 12:59:07 --> Helper loaded: html_helper
INFO - 2023-10-07 12:59:07 --> Helper loaded: text_helper
INFO - 2023-10-07 12:59:07 --> Helper loaded: form_helper
INFO - 2023-10-07 12:59:07 --> Helper loaded: lang_helper
INFO - 2023-10-07 12:59:07 --> Helper loaded: security_helper
INFO - 2023-10-07 12:59:07 --> Helper loaded: cookie_helper
INFO - 2023-10-07 12:59:07 --> Database Driver Class Initialized
INFO - 2023-10-07 12:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 12:59:07 --> Parser Class Initialized
INFO - 2023-10-07 12:59:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 12:59:07 --> Pagination Class Initialized
INFO - 2023-10-07 12:59:07 --> Form Validation Class Initialized
INFO - 2023-10-07 12:59:07 --> Controller Class Initialized
DEBUG - 2023-10-07 12:59:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 12:59:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:59:07 --> Model Class Initialized
DEBUG - 2023-10-07 12:59:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 12:59:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:59:07 --> Model Class Initialized
DEBUG - 2023-10-07 12:59:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 12:59:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:59:07 --> Model Class Initialized
DEBUG - 2023-10-07 12:59:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:59:07 --> Model Class Initialized
INFO - 2023-10-07 12:59:07 --> Final output sent to browser
DEBUG - 2023-10-07 12:59:07 --> Total execution time: 0.0200
ERROR - 2023-10-07 12:59:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 12:59:16 --> Config Class Initialized
INFO - 2023-10-07 12:59:16 --> Hooks Class Initialized
DEBUG - 2023-10-07 12:59:16 --> UTF-8 Support Enabled
INFO - 2023-10-07 12:59:16 --> Utf8 Class Initialized
INFO - 2023-10-07 12:59:16 --> URI Class Initialized
DEBUG - 2023-10-07 12:59:16 --> No URI present. Default controller set.
INFO - 2023-10-07 12:59:16 --> Router Class Initialized
INFO - 2023-10-07 12:59:16 --> Output Class Initialized
INFO - 2023-10-07 12:59:16 --> Security Class Initialized
DEBUG - 2023-10-07 12:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 12:59:16 --> Input Class Initialized
INFO - 2023-10-07 12:59:16 --> Language Class Initialized
INFO - 2023-10-07 12:59:16 --> Loader Class Initialized
INFO - 2023-10-07 12:59:16 --> Helper loaded: url_helper
INFO - 2023-10-07 12:59:16 --> Helper loaded: file_helper
INFO - 2023-10-07 12:59:16 --> Helper loaded: html_helper
INFO - 2023-10-07 12:59:16 --> Helper loaded: text_helper
INFO - 2023-10-07 12:59:16 --> Helper loaded: form_helper
INFO - 2023-10-07 12:59:16 --> Helper loaded: lang_helper
INFO - 2023-10-07 12:59:16 --> Helper loaded: security_helper
INFO - 2023-10-07 12:59:16 --> Helper loaded: cookie_helper
INFO - 2023-10-07 12:59:16 --> Database Driver Class Initialized
INFO - 2023-10-07 12:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 12:59:16 --> Parser Class Initialized
INFO - 2023-10-07 12:59:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 12:59:16 --> Pagination Class Initialized
INFO - 2023-10-07 12:59:16 --> Form Validation Class Initialized
INFO - 2023-10-07 12:59:16 --> Controller Class Initialized
INFO - 2023-10-07 12:59:16 --> Model Class Initialized
DEBUG - 2023-10-07 12:59:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:59:16 --> Model Class Initialized
DEBUG - 2023-10-07 12:59:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:59:16 --> Model Class Initialized
INFO - 2023-10-07 12:59:16 --> Model Class Initialized
INFO - 2023-10-07 12:59:16 --> Model Class Initialized
INFO - 2023-10-07 12:59:16 --> Model Class Initialized
DEBUG - 2023-10-07 12:59:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 12:59:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:59:16 --> Model Class Initialized
INFO - 2023-10-07 12:59:16 --> Model Class Initialized
INFO - 2023-10-07 12:59:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 12:59:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:59:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 12:59:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 12:59:16 --> Model Class Initialized
INFO - 2023-10-07 12:59:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 12:59:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 12:59:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 12:59:16 --> Final output sent to browser
DEBUG - 2023-10-07 12:59:16 --> Total execution time: 0.1082
ERROR - 2023-10-07 12:59:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 12:59:23 --> Config Class Initialized
INFO - 2023-10-07 12:59:23 --> Hooks Class Initialized
DEBUG - 2023-10-07 12:59:23 --> UTF-8 Support Enabled
INFO - 2023-10-07 12:59:23 --> Utf8 Class Initialized
INFO - 2023-10-07 12:59:23 --> URI Class Initialized
INFO - 2023-10-07 12:59:23 --> Router Class Initialized
INFO - 2023-10-07 12:59:23 --> Output Class Initialized
INFO - 2023-10-07 12:59:23 --> Security Class Initialized
DEBUG - 2023-10-07 12:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 12:59:23 --> Input Class Initialized
INFO - 2023-10-07 12:59:23 --> Language Class Initialized
INFO - 2023-10-07 12:59:23 --> Loader Class Initialized
INFO - 2023-10-07 12:59:23 --> Helper loaded: url_helper
INFO - 2023-10-07 12:59:23 --> Helper loaded: file_helper
INFO - 2023-10-07 12:59:23 --> Helper loaded: html_helper
INFO - 2023-10-07 12:59:23 --> Helper loaded: text_helper
INFO - 2023-10-07 12:59:23 --> Helper loaded: form_helper
INFO - 2023-10-07 12:59:23 --> Helper loaded: lang_helper
INFO - 2023-10-07 12:59:23 --> Helper loaded: security_helper
INFO - 2023-10-07 12:59:23 --> Helper loaded: cookie_helper
INFO - 2023-10-07 12:59:23 --> Database Driver Class Initialized
INFO - 2023-10-07 12:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 12:59:23 --> Parser Class Initialized
INFO - 2023-10-07 12:59:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 12:59:23 --> Pagination Class Initialized
INFO - 2023-10-07 12:59:23 --> Form Validation Class Initialized
INFO - 2023-10-07 12:59:23 --> Controller Class Initialized
INFO - 2023-10-07 12:59:23 --> Model Class Initialized
DEBUG - 2023-10-07 12:59:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:59:23 --> Model Class Initialized
DEBUG - 2023-10-07 12:59:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:59:23 --> Model Class Initialized
INFO - 2023-10-07 12:59:23 --> Model Class Initialized
INFO - 2023-10-07 12:59:23 --> Model Class Initialized
INFO - 2023-10-07 12:59:23 --> Model Class Initialized
DEBUG - 2023-10-07 12:59:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 12:59:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:59:23 --> Model Class Initialized
INFO - 2023-10-07 12:59:23 --> Model Class Initialized
INFO - 2023-10-07 12:59:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 12:59:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 12:59:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 12:59:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 12:59:23 --> Model Class Initialized
INFO - 2023-10-07 12:59:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 12:59:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 12:59:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 12:59:23 --> Final output sent to browser
DEBUG - 2023-10-07 12:59:23 --> Total execution time: 0.1106
ERROR - 2023-10-07 17:07:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:07:07 --> Config Class Initialized
INFO - 2023-10-07 17:07:07 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:07:07 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:07:07 --> Utf8 Class Initialized
INFO - 2023-10-07 17:07:07 --> URI Class Initialized
DEBUG - 2023-10-07 17:07:07 --> No URI present. Default controller set.
INFO - 2023-10-07 17:07:07 --> Router Class Initialized
INFO - 2023-10-07 17:07:07 --> Output Class Initialized
INFO - 2023-10-07 17:07:07 --> Security Class Initialized
DEBUG - 2023-10-07 17:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:07:07 --> Input Class Initialized
INFO - 2023-10-07 17:07:07 --> Language Class Initialized
INFO - 2023-10-07 17:07:07 --> Loader Class Initialized
INFO - 2023-10-07 17:07:07 --> Helper loaded: url_helper
INFO - 2023-10-07 17:07:07 --> Helper loaded: file_helper
INFO - 2023-10-07 17:07:07 --> Helper loaded: html_helper
INFO - 2023-10-07 17:07:07 --> Helper loaded: text_helper
INFO - 2023-10-07 17:07:07 --> Helper loaded: form_helper
INFO - 2023-10-07 17:07:07 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:07:07 --> Helper loaded: security_helper
INFO - 2023-10-07 17:07:07 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:07:07 --> Database Driver Class Initialized
INFO - 2023-10-07 17:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:07:07 --> Parser Class Initialized
INFO - 2023-10-07 17:07:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:07:07 --> Pagination Class Initialized
INFO - 2023-10-07 17:07:07 --> Form Validation Class Initialized
INFO - 2023-10-07 17:07:07 --> Controller Class Initialized
INFO - 2023-10-07 17:07:07 --> Model Class Initialized
DEBUG - 2023-10-07 17:07:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-07 17:07:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:07:08 --> Config Class Initialized
INFO - 2023-10-07 17:07:08 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:07:08 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:07:08 --> Utf8 Class Initialized
INFO - 2023-10-07 17:07:08 --> URI Class Initialized
INFO - 2023-10-07 17:07:08 --> Router Class Initialized
INFO - 2023-10-07 17:07:08 --> Output Class Initialized
INFO - 2023-10-07 17:07:08 --> Security Class Initialized
DEBUG - 2023-10-07 17:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:07:08 --> Input Class Initialized
INFO - 2023-10-07 17:07:08 --> Language Class Initialized
INFO - 2023-10-07 17:07:08 --> Loader Class Initialized
INFO - 2023-10-07 17:07:08 --> Helper loaded: url_helper
INFO - 2023-10-07 17:07:08 --> Helper loaded: file_helper
INFO - 2023-10-07 17:07:08 --> Helper loaded: html_helper
INFO - 2023-10-07 17:07:08 --> Helper loaded: text_helper
INFO - 2023-10-07 17:07:08 --> Helper loaded: form_helper
INFO - 2023-10-07 17:07:08 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:07:08 --> Helper loaded: security_helper
INFO - 2023-10-07 17:07:08 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:07:08 --> Database Driver Class Initialized
INFO - 2023-10-07 17:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:07:08 --> Parser Class Initialized
INFO - 2023-10-07 17:07:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:07:08 --> Pagination Class Initialized
INFO - 2023-10-07 17:07:08 --> Form Validation Class Initialized
INFO - 2023-10-07 17:07:08 --> Controller Class Initialized
INFO - 2023-10-07 17:07:08 --> Model Class Initialized
DEBUG - 2023-10-07 17:07:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:07:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-07 17:07:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:07:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 17:07:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 17:07:08 --> Model Class Initialized
INFO - 2023-10-07 17:07:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 17:07:08 --> Final output sent to browser
DEBUG - 2023-10-07 17:07:08 --> Total execution time: 0.0315
ERROR - 2023-10-07 17:07:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:07:11 --> Config Class Initialized
INFO - 2023-10-07 17:07:11 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:07:11 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:07:11 --> Utf8 Class Initialized
INFO - 2023-10-07 17:07:11 --> URI Class Initialized
INFO - 2023-10-07 17:07:11 --> Router Class Initialized
INFO - 2023-10-07 17:07:11 --> Output Class Initialized
INFO - 2023-10-07 17:07:11 --> Security Class Initialized
DEBUG - 2023-10-07 17:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:07:11 --> Input Class Initialized
INFO - 2023-10-07 17:07:11 --> Language Class Initialized
INFO - 2023-10-07 17:07:12 --> Loader Class Initialized
INFO - 2023-10-07 17:07:12 --> Helper loaded: url_helper
INFO - 2023-10-07 17:07:12 --> Helper loaded: file_helper
INFO - 2023-10-07 17:07:12 --> Helper loaded: html_helper
INFO - 2023-10-07 17:07:12 --> Helper loaded: text_helper
INFO - 2023-10-07 17:07:12 --> Helper loaded: form_helper
INFO - 2023-10-07 17:07:12 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:07:12 --> Helper loaded: security_helper
INFO - 2023-10-07 17:07:12 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:07:12 --> Database Driver Class Initialized
INFO - 2023-10-07 17:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:07:12 --> Parser Class Initialized
INFO - 2023-10-07 17:07:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:07:12 --> Pagination Class Initialized
INFO - 2023-10-07 17:07:12 --> Form Validation Class Initialized
INFO - 2023-10-07 17:07:12 --> Controller Class Initialized
INFO - 2023-10-07 17:07:12 --> Model Class Initialized
DEBUG - 2023-10-07 17:07:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:07:12 --> Model Class Initialized
INFO - 2023-10-07 17:07:12 --> Final output sent to browser
DEBUG - 2023-10-07 17:07:12 --> Total execution time: 0.0203
ERROR - 2023-10-07 17:07:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:07:12 --> Config Class Initialized
INFO - 2023-10-07 17:07:12 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:07:12 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:07:12 --> Utf8 Class Initialized
INFO - 2023-10-07 17:07:12 --> URI Class Initialized
DEBUG - 2023-10-07 17:07:12 --> No URI present. Default controller set.
INFO - 2023-10-07 17:07:12 --> Router Class Initialized
INFO - 2023-10-07 17:07:12 --> Output Class Initialized
INFO - 2023-10-07 17:07:12 --> Security Class Initialized
DEBUG - 2023-10-07 17:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:07:12 --> Input Class Initialized
INFO - 2023-10-07 17:07:12 --> Language Class Initialized
INFO - 2023-10-07 17:07:12 --> Loader Class Initialized
INFO - 2023-10-07 17:07:12 --> Helper loaded: url_helper
INFO - 2023-10-07 17:07:12 --> Helper loaded: file_helper
INFO - 2023-10-07 17:07:12 --> Helper loaded: html_helper
INFO - 2023-10-07 17:07:12 --> Helper loaded: text_helper
INFO - 2023-10-07 17:07:12 --> Helper loaded: form_helper
INFO - 2023-10-07 17:07:12 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:07:12 --> Helper loaded: security_helper
INFO - 2023-10-07 17:07:12 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:07:12 --> Database Driver Class Initialized
INFO - 2023-10-07 17:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:07:12 --> Parser Class Initialized
INFO - 2023-10-07 17:07:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:07:12 --> Pagination Class Initialized
INFO - 2023-10-07 17:07:12 --> Form Validation Class Initialized
INFO - 2023-10-07 17:07:12 --> Controller Class Initialized
INFO - 2023-10-07 17:07:12 --> Model Class Initialized
DEBUG - 2023-10-07 17:07:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:07:12 --> Model Class Initialized
DEBUG - 2023-10-07 17:07:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:07:12 --> Model Class Initialized
INFO - 2023-10-07 17:07:12 --> Model Class Initialized
INFO - 2023-10-07 17:07:12 --> Model Class Initialized
INFO - 2023-10-07 17:07:12 --> Model Class Initialized
DEBUG - 2023-10-07 17:07:12 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 17:07:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:07:12 --> Model Class Initialized
INFO - 2023-10-07 17:07:12 --> Model Class Initialized
INFO - 2023-10-07 17:07:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 17:07:12 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:07:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 17:07:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 17:07:12 --> Model Class Initialized
INFO - 2023-10-07 17:07:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 17:07:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 17:07:12 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 17:07:12 --> Final output sent to browser
DEBUG - 2023-10-07 17:07:12 --> Total execution time: 0.1168
ERROR - 2023-10-07 17:07:16 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:07:16 --> Config Class Initialized
INFO - 2023-10-07 17:07:16 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:07:16 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:07:16 --> Utf8 Class Initialized
INFO - 2023-10-07 17:07:16 --> URI Class Initialized
INFO - 2023-10-07 17:07:16 --> Router Class Initialized
INFO - 2023-10-07 17:07:16 --> Output Class Initialized
INFO - 2023-10-07 17:07:16 --> Security Class Initialized
DEBUG - 2023-10-07 17:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:07:16 --> Input Class Initialized
INFO - 2023-10-07 17:07:16 --> Language Class Initialized
INFO - 2023-10-07 17:07:16 --> Loader Class Initialized
INFO - 2023-10-07 17:07:16 --> Helper loaded: url_helper
INFO - 2023-10-07 17:07:16 --> Helper loaded: file_helper
INFO - 2023-10-07 17:07:16 --> Helper loaded: html_helper
INFO - 2023-10-07 17:07:16 --> Helper loaded: text_helper
INFO - 2023-10-07 17:07:16 --> Helper loaded: form_helper
INFO - 2023-10-07 17:07:16 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:07:16 --> Helper loaded: security_helper
INFO - 2023-10-07 17:07:16 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:07:16 --> Database Driver Class Initialized
INFO - 2023-10-07 17:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:07:16 --> Parser Class Initialized
INFO - 2023-10-07 17:07:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:07:16 --> Pagination Class Initialized
INFO - 2023-10-07 17:07:16 --> Form Validation Class Initialized
INFO - 2023-10-07 17:07:16 --> Controller Class Initialized
INFO - 2023-10-07 17:07:16 --> Model Class Initialized
DEBUG - 2023-10-07 17:07:16 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 17:07:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:07:16 --> Model Class Initialized
DEBUG - 2023-10-07 17:07:16 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:07:16 --> Model Class Initialized
INFO - 2023-10-07 17:07:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-10-07 17:07:16 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:07:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 17:07:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 17:07:16 --> Model Class Initialized
INFO - 2023-10-07 17:07:16 --> Model Class Initialized
INFO - 2023-10-07 17:07:16 --> Model Class Initialized
INFO - 2023-10-07 17:07:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 17:07:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 17:07:16 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 17:07:16 --> Final output sent to browser
DEBUG - 2023-10-07 17:07:16 --> Total execution time: 0.1241
ERROR - 2023-10-07 17:07:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:07:20 --> Config Class Initialized
INFO - 2023-10-07 17:07:20 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:07:20 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:07:20 --> Utf8 Class Initialized
INFO - 2023-10-07 17:07:20 --> URI Class Initialized
INFO - 2023-10-07 17:07:20 --> Router Class Initialized
INFO - 2023-10-07 17:07:20 --> Output Class Initialized
INFO - 2023-10-07 17:07:20 --> Security Class Initialized
DEBUG - 2023-10-07 17:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:07:20 --> Input Class Initialized
INFO - 2023-10-07 17:07:20 --> Language Class Initialized
INFO - 2023-10-07 17:07:20 --> Loader Class Initialized
INFO - 2023-10-07 17:07:20 --> Helper loaded: url_helper
INFO - 2023-10-07 17:07:20 --> Helper loaded: file_helper
INFO - 2023-10-07 17:07:20 --> Helper loaded: html_helper
INFO - 2023-10-07 17:07:20 --> Helper loaded: text_helper
INFO - 2023-10-07 17:07:20 --> Helper loaded: form_helper
INFO - 2023-10-07 17:07:20 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:07:20 --> Helper loaded: security_helper
INFO - 2023-10-07 17:07:20 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:07:20 --> Database Driver Class Initialized
INFO - 2023-10-07 17:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:07:20 --> Parser Class Initialized
INFO - 2023-10-07 17:07:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:07:20 --> Pagination Class Initialized
INFO - 2023-10-07 17:07:20 --> Form Validation Class Initialized
INFO - 2023-10-07 17:07:20 --> Controller Class Initialized
INFO - 2023-10-07 17:07:20 --> Model Class Initialized
DEBUG - 2023-10-07 17:07:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:07:20 --> Final output sent to browser
DEBUG - 2023-10-07 17:07:20 --> Total execution time: 0.0166
ERROR - 2023-10-07 17:07:30 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:07:30 --> Config Class Initialized
INFO - 2023-10-07 17:07:30 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:07:30 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:07:30 --> Utf8 Class Initialized
INFO - 2023-10-07 17:07:30 --> URI Class Initialized
INFO - 2023-10-07 17:07:30 --> Router Class Initialized
INFO - 2023-10-07 17:07:30 --> Output Class Initialized
INFO - 2023-10-07 17:07:30 --> Security Class Initialized
DEBUG - 2023-10-07 17:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:07:30 --> Input Class Initialized
INFO - 2023-10-07 17:07:30 --> Language Class Initialized
INFO - 2023-10-07 17:07:30 --> Loader Class Initialized
INFO - 2023-10-07 17:07:30 --> Helper loaded: url_helper
INFO - 2023-10-07 17:07:30 --> Helper loaded: file_helper
INFO - 2023-10-07 17:07:30 --> Helper loaded: html_helper
INFO - 2023-10-07 17:07:30 --> Helper loaded: text_helper
INFO - 2023-10-07 17:07:30 --> Helper loaded: form_helper
INFO - 2023-10-07 17:07:30 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:07:30 --> Helper loaded: security_helper
INFO - 2023-10-07 17:07:30 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:07:30 --> Database Driver Class Initialized
INFO - 2023-10-07 17:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:07:30 --> Parser Class Initialized
INFO - 2023-10-07 17:07:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:07:30 --> Pagination Class Initialized
INFO - 2023-10-07 17:07:30 --> Form Validation Class Initialized
INFO - 2023-10-07 17:07:30 --> Controller Class Initialized
INFO - 2023-10-07 17:07:30 --> Final output sent to browser
DEBUG - 2023-10-07 17:07:30 --> Total execution time: 0.0144
ERROR - 2023-10-07 17:12:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:12:33 --> Config Class Initialized
INFO - 2023-10-07 17:12:33 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:12:33 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:12:33 --> Utf8 Class Initialized
INFO - 2023-10-07 17:12:33 --> URI Class Initialized
DEBUG - 2023-10-07 17:12:33 --> No URI present. Default controller set.
INFO - 2023-10-07 17:12:33 --> Router Class Initialized
INFO - 2023-10-07 17:12:33 --> Output Class Initialized
INFO - 2023-10-07 17:12:33 --> Security Class Initialized
DEBUG - 2023-10-07 17:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:12:33 --> Input Class Initialized
INFO - 2023-10-07 17:12:33 --> Language Class Initialized
INFO - 2023-10-07 17:12:33 --> Loader Class Initialized
INFO - 2023-10-07 17:12:33 --> Helper loaded: url_helper
INFO - 2023-10-07 17:12:33 --> Helper loaded: file_helper
INFO - 2023-10-07 17:12:33 --> Helper loaded: html_helper
INFO - 2023-10-07 17:12:33 --> Helper loaded: text_helper
INFO - 2023-10-07 17:12:33 --> Helper loaded: form_helper
INFO - 2023-10-07 17:12:33 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:12:33 --> Helper loaded: security_helper
INFO - 2023-10-07 17:12:33 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:12:33 --> Database Driver Class Initialized
INFO - 2023-10-07 17:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:12:33 --> Parser Class Initialized
INFO - 2023-10-07 17:12:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:12:33 --> Pagination Class Initialized
INFO - 2023-10-07 17:12:33 --> Form Validation Class Initialized
INFO - 2023-10-07 17:12:33 --> Controller Class Initialized
INFO - 2023-10-07 17:12:33 --> Model Class Initialized
DEBUG - 2023-10-07 17:12:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-07 17:12:35 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:12:35 --> Config Class Initialized
INFO - 2023-10-07 17:12:35 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:12:35 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:12:35 --> Utf8 Class Initialized
INFO - 2023-10-07 17:12:35 --> URI Class Initialized
INFO - 2023-10-07 17:12:35 --> Router Class Initialized
INFO - 2023-10-07 17:12:35 --> Output Class Initialized
INFO - 2023-10-07 17:12:35 --> Security Class Initialized
DEBUG - 2023-10-07 17:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:12:35 --> Input Class Initialized
INFO - 2023-10-07 17:12:35 --> Language Class Initialized
INFO - 2023-10-07 17:12:35 --> Loader Class Initialized
INFO - 2023-10-07 17:12:35 --> Helper loaded: url_helper
INFO - 2023-10-07 17:12:35 --> Helper loaded: file_helper
INFO - 2023-10-07 17:12:35 --> Helper loaded: html_helper
INFO - 2023-10-07 17:12:35 --> Helper loaded: text_helper
INFO - 2023-10-07 17:12:35 --> Helper loaded: form_helper
INFO - 2023-10-07 17:12:35 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:12:35 --> Helper loaded: security_helper
INFO - 2023-10-07 17:12:35 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:12:35 --> Database Driver Class Initialized
INFO - 2023-10-07 17:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:12:35 --> Parser Class Initialized
INFO - 2023-10-07 17:12:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:12:35 --> Pagination Class Initialized
INFO - 2023-10-07 17:12:35 --> Form Validation Class Initialized
INFO - 2023-10-07 17:12:35 --> Controller Class Initialized
INFO - 2023-10-07 17:12:35 --> Model Class Initialized
DEBUG - 2023-10-07 17:12:35 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:12:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-07 17:12:35 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:12:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 17:12:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 17:12:35 --> Model Class Initialized
INFO - 2023-10-07 17:12:35 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 17:12:35 --> Final output sent to browser
DEBUG - 2023-10-07 17:12:35 --> Total execution time: 0.0394
ERROR - 2023-10-07 17:12:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:12:50 --> Config Class Initialized
INFO - 2023-10-07 17:12:50 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:12:50 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:12:50 --> Utf8 Class Initialized
INFO - 2023-10-07 17:12:50 --> URI Class Initialized
INFO - 2023-10-07 17:12:50 --> Router Class Initialized
INFO - 2023-10-07 17:12:50 --> Output Class Initialized
INFO - 2023-10-07 17:12:50 --> Security Class Initialized
DEBUG - 2023-10-07 17:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:12:50 --> Input Class Initialized
INFO - 2023-10-07 17:12:50 --> Language Class Initialized
INFO - 2023-10-07 17:12:50 --> Loader Class Initialized
INFO - 2023-10-07 17:12:50 --> Helper loaded: url_helper
INFO - 2023-10-07 17:12:50 --> Helper loaded: file_helper
INFO - 2023-10-07 17:12:50 --> Helper loaded: html_helper
INFO - 2023-10-07 17:12:50 --> Helper loaded: text_helper
INFO - 2023-10-07 17:12:50 --> Helper loaded: form_helper
INFO - 2023-10-07 17:12:50 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:12:50 --> Helper loaded: security_helper
INFO - 2023-10-07 17:12:50 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:12:50 --> Database Driver Class Initialized
INFO - 2023-10-07 17:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:12:50 --> Parser Class Initialized
INFO - 2023-10-07 17:12:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:12:50 --> Pagination Class Initialized
INFO - 2023-10-07 17:12:50 --> Form Validation Class Initialized
INFO - 2023-10-07 17:12:50 --> Controller Class Initialized
INFO - 2023-10-07 17:12:50 --> Model Class Initialized
DEBUG - 2023-10-07 17:12:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:12:50 --> Model Class Initialized
INFO - 2023-10-07 17:12:50 --> Final output sent to browser
DEBUG - 2023-10-07 17:12:50 --> Total execution time: 0.0221
ERROR - 2023-10-07 17:12:50 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:12:50 --> Config Class Initialized
INFO - 2023-10-07 17:12:50 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:12:50 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:12:50 --> Utf8 Class Initialized
INFO - 2023-10-07 17:12:50 --> URI Class Initialized
DEBUG - 2023-10-07 17:12:50 --> No URI present. Default controller set.
INFO - 2023-10-07 17:12:50 --> Router Class Initialized
INFO - 2023-10-07 17:12:50 --> Output Class Initialized
INFO - 2023-10-07 17:12:50 --> Security Class Initialized
DEBUG - 2023-10-07 17:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:12:50 --> Input Class Initialized
INFO - 2023-10-07 17:12:50 --> Language Class Initialized
INFO - 2023-10-07 17:12:50 --> Loader Class Initialized
INFO - 2023-10-07 17:12:50 --> Helper loaded: url_helper
INFO - 2023-10-07 17:12:50 --> Helper loaded: file_helper
INFO - 2023-10-07 17:12:50 --> Helper loaded: html_helper
INFO - 2023-10-07 17:12:50 --> Helper loaded: text_helper
INFO - 2023-10-07 17:12:50 --> Helper loaded: form_helper
INFO - 2023-10-07 17:12:50 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:12:50 --> Helper loaded: security_helper
INFO - 2023-10-07 17:12:50 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:12:50 --> Database Driver Class Initialized
INFO - 2023-10-07 17:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:12:50 --> Parser Class Initialized
INFO - 2023-10-07 17:12:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:12:50 --> Pagination Class Initialized
INFO - 2023-10-07 17:12:50 --> Form Validation Class Initialized
INFO - 2023-10-07 17:12:50 --> Controller Class Initialized
INFO - 2023-10-07 17:12:50 --> Model Class Initialized
DEBUG - 2023-10-07 17:12:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:12:50 --> Model Class Initialized
DEBUG - 2023-10-07 17:12:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:12:50 --> Model Class Initialized
INFO - 2023-10-07 17:12:50 --> Model Class Initialized
INFO - 2023-10-07 17:12:50 --> Model Class Initialized
INFO - 2023-10-07 17:12:50 --> Model Class Initialized
DEBUG - 2023-10-07 17:12:50 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 17:12:50 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:12:50 --> Model Class Initialized
INFO - 2023-10-07 17:12:50 --> Model Class Initialized
INFO - 2023-10-07 17:12:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 17:12:50 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:12:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 17:12:50 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 17:12:50 --> Model Class Initialized
INFO - 2023-10-07 17:12:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 17:12:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 17:12:51 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 17:12:51 --> Final output sent to browser
DEBUG - 2023-10-07 17:12:51 --> Total execution time: 0.1169
ERROR - 2023-10-07 17:13:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:13:07 --> Config Class Initialized
INFO - 2023-10-07 17:13:07 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:13:07 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:13:07 --> Utf8 Class Initialized
INFO - 2023-10-07 17:13:07 --> URI Class Initialized
DEBUG - 2023-10-07 17:13:07 --> No URI present. Default controller set.
INFO - 2023-10-07 17:13:07 --> Router Class Initialized
INFO - 2023-10-07 17:13:07 --> Output Class Initialized
INFO - 2023-10-07 17:13:07 --> Security Class Initialized
DEBUG - 2023-10-07 17:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:13:07 --> Input Class Initialized
INFO - 2023-10-07 17:13:07 --> Language Class Initialized
INFO - 2023-10-07 17:13:07 --> Loader Class Initialized
INFO - 2023-10-07 17:13:07 --> Helper loaded: url_helper
INFO - 2023-10-07 17:13:07 --> Helper loaded: file_helper
INFO - 2023-10-07 17:13:07 --> Helper loaded: html_helper
INFO - 2023-10-07 17:13:07 --> Helper loaded: text_helper
INFO - 2023-10-07 17:13:07 --> Helper loaded: form_helper
INFO - 2023-10-07 17:13:07 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:13:07 --> Helper loaded: security_helper
INFO - 2023-10-07 17:13:07 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:13:07 --> Database Driver Class Initialized
INFO - 2023-10-07 17:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:13:07 --> Parser Class Initialized
INFO - 2023-10-07 17:13:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:13:07 --> Pagination Class Initialized
INFO - 2023-10-07 17:13:07 --> Form Validation Class Initialized
INFO - 2023-10-07 17:13:07 --> Controller Class Initialized
INFO - 2023-10-07 17:13:07 --> Model Class Initialized
DEBUG - 2023-10-07 17:13:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:13:07 --> Model Class Initialized
DEBUG - 2023-10-07 17:13:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:13:07 --> Model Class Initialized
INFO - 2023-10-07 17:13:07 --> Model Class Initialized
INFO - 2023-10-07 17:13:07 --> Model Class Initialized
INFO - 2023-10-07 17:13:07 --> Model Class Initialized
DEBUG - 2023-10-07 17:13:07 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 17:13:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:13:07 --> Model Class Initialized
INFO - 2023-10-07 17:13:07 --> Model Class Initialized
INFO - 2023-10-07 17:13:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 17:13:07 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:13:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 17:13:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 17:13:07 --> Model Class Initialized
INFO - 2023-10-07 17:13:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 17:13:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 17:13:07 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 17:13:07 --> Final output sent to browser
DEBUG - 2023-10-07 17:13:07 --> Total execution time: 0.1114
ERROR - 2023-10-07 17:13:20 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:13:20 --> Config Class Initialized
INFO - 2023-10-07 17:13:20 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:13:20 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:13:20 --> Utf8 Class Initialized
INFO - 2023-10-07 17:13:20 --> URI Class Initialized
INFO - 2023-10-07 17:13:20 --> Router Class Initialized
INFO - 2023-10-07 17:13:20 --> Output Class Initialized
INFO - 2023-10-07 17:13:20 --> Security Class Initialized
DEBUG - 2023-10-07 17:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:13:20 --> Input Class Initialized
INFO - 2023-10-07 17:13:20 --> Language Class Initialized
INFO - 2023-10-07 17:13:20 --> Loader Class Initialized
INFO - 2023-10-07 17:13:20 --> Helper loaded: url_helper
INFO - 2023-10-07 17:13:20 --> Helper loaded: file_helper
INFO - 2023-10-07 17:13:20 --> Helper loaded: html_helper
INFO - 2023-10-07 17:13:20 --> Helper loaded: text_helper
INFO - 2023-10-07 17:13:20 --> Helper loaded: form_helper
INFO - 2023-10-07 17:13:20 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:13:20 --> Helper loaded: security_helper
INFO - 2023-10-07 17:13:20 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:13:20 --> Database Driver Class Initialized
INFO - 2023-10-07 17:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:13:20 --> Parser Class Initialized
INFO - 2023-10-07 17:13:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:13:20 --> Pagination Class Initialized
INFO - 2023-10-07 17:13:20 --> Form Validation Class Initialized
INFO - 2023-10-07 17:13:20 --> Controller Class Initialized
INFO - 2023-10-07 17:13:20 --> Model Class Initialized
DEBUG - 2023-10-07 17:13:20 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 17:13:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:13:20 --> Model Class Initialized
DEBUG - 2023-10-07 17:13:20 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:13:20 --> Model Class Initialized
INFO - 2023-10-07 17:13:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-10-07 17:13:20 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:13:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 17:13:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 17:13:20 --> Model Class Initialized
INFO - 2023-10-07 17:13:20 --> Model Class Initialized
INFO - 2023-10-07 17:13:20 --> Model Class Initialized
INFO - 2023-10-07 17:13:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 17:13:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 17:13:20 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 17:13:20 --> Final output sent to browser
DEBUG - 2023-10-07 17:13:20 --> Total execution time: 0.1146
ERROR - 2023-10-07 17:15:14 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:15:14 --> Config Class Initialized
INFO - 2023-10-07 17:15:14 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:15:14 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:15:14 --> Utf8 Class Initialized
INFO - 2023-10-07 17:15:14 --> URI Class Initialized
INFO - 2023-10-07 17:15:14 --> Router Class Initialized
INFO - 2023-10-07 17:15:14 --> Output Class Initialized
INFO - 2023-10-07 17:15:14 --> Security Class Initialized
DEBUG - 2023-10-07 17:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:15:14 --> Input Class Initialized
INFO - 2023-10-07 17:15:14 --> Language Class Initialized
INFO - 2023-10-07 17:15:14 --> Loader Class Initialized
INFO - 2023-10-07 17:15:14 --> Helper loaded: url_helper
INFO - 2023-10-07 17:15:14 --> Helper loaded: file_helper
INFO - 2023-10-07 17:15:14 --> Helper loaded: html_helper
INFO - 2023-10-07 17:15:14 --> Helper loaded: text_helper
INFO - 2023-10-07 17:15:14 --> Helper loaded: form_helper
INFO - 2023-10-07 17:15:14 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:15:14 --> Helper loaded: security_helper
INFO - 2023-10-07 17:15:14 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:15:14 --> Database Driver Class Initialized
INFO - 2023-10-07 17:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:15:14 --> Parser Class Initialized
INFO - 2023-10-07 17:15:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:15:14 --> Pagination Class Initialized
INFO - 2023-10-07 17:15:14 --> Form Validation Class Initialized
INFO - 2023-10-07 17:15:14 --> Controller Class Initialized
INFO - 2023-10-07 17:15:14 --> Model Class Initialized
DEBUG - 2023-10-07 17:15:14 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:15:14 --> Final output sent to browser
DEBUG - 2023-10-07 17:15:14 --> Total execution time: 0.0186
ERROR - 2023-10-07 17:15:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:15:21 --> Config Class Initialized
INFO - 2023-10-07 17:15:21 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:15:21 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:15:21 --> Utf8 Class Initialized
INFO - 2023-10-07 17:15:21 --> URI Class Initialized
INFO - 2023-10-07 17:15:21 --> Router Class Initialized
INFO - 2023-10-07 17:15:21 --> Output Class Initialized
INFO - 2023-10-07 17:15:21 --> Security Class Initialized
DEBUG - 2023-10-07 17:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:15:21 --> Input Class Initialized
INFO - 2023-10-07 17:15:21 --> Language Class Initialized
INFO - 2023-10-07 17:15:21 --> Loader Class Initialized
INFO - 2023-10-07 17:15:21 --> Helper loaded: url_helper
INFO - 2023-10-07 17:15:21 --> Helper loaded: file_helper
INFO - 2023-10-07 17:15:21 --> Helper loaded: html_helper
INFO - 2023-10-07 17:15:21 --> Helper loaded: text_helper
INFO - 2023-10-07 17:15:21 --> Helper loaded: form_helper
INFO - 2023-10-07 17:15:21 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:15:21 --> Helper loaded: security_helper
INFO - 2023-10-07 17:15:21 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:15:21 --> Database Driver Class Initialized
INFO - 2023-10-07 17:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:15:21 --> Parser Class Initialized
INFO - 2023-10-07 17:15:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:15:21 --> Pagination Class Initialized
INFO - 2023-10-07 17:15:21 --> Form Validation Class Initialized
INFO - 2023-10-07 17:15:21 --> Controller Class Initialized
INFO - 2023-10-07 17:15:21 --> Model Class Initialized
DEBUG - 2023-10-07 17:15:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-07 17:15:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-07 17:15:21 --> Final output sent to browser
DEBUG - 2023-10-07 17:15:21 --> Total execution time: 0.0154
ERROR - 2023-10-07 17:15:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:15:25 --> Config Class Initialized
INFO - 2023-10-07 17:15:25 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:15:25 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:15:25 --> Utf8 Class Initialized
INFO - 2023-10-07 17:15:25 --> URI Class Initialized
INFO - 2023-10-07 17:15:25 --> Router Class Initialized
INFO - 2023-10-07 17:15:25 --> Output Class Initialized
INFO - 2023-10-07 17:15:25 --> Security Class Initialized
DEBUG - 2023-10-07 17:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:15:25 --> Input Class Initialized
INFO - 2023-10-07 17:15:25 --> Language Class Initialized
INFO - 2023-10-07 17:15:25 --> Loader Class Initialized
INFO - 2023-10-07 17:15:25 --> Helper loaded: url_helper
INFO - 2023-10-07 17:15:25 --> Helper loaded: file_helper
INFO - 2023-10-07 17:15:25 --> Helper loaded: html_helper
INFO - 2023-10-07 17:15:25 --> Helper loaded: text_helper
INFO - 2023-10-07 17:15:25 --> Helper loaded: form_helper
INFO - 2023-10-07 17:15:25 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:15:25 --> Helper loaded: security_helper
INFO - 2023-10-07 17:15:25 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:15:25 --> Database Driver Class Initialized
INFO - 2023-10-07 17:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:15:25 --> Parser Class Initialized
INFO - 2023-10-07 17:15:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:15:25 --> Pagination Class Initialized
INFO - 2023-10-07 17:15:25 --> Form Validation Class Initialized
INFO - 2023-10-07 17:15:25 --> Controller Class Initialized
INFO - 2023-10-07 17:15:25 --> Model Class Initialized
DEBUG - 2023-10-07 17:15:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:15:25 --> Final output sent to browser
DEBUG - 2023-10-07 17:15:25 --> Total execution time: 0.0153
ERROR - 2023-10-07 17:15:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:15:46 --> Config Class Initialized
INFO - 2023-10-07 17:15:46 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:15:46 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:15:46 --> Utf8 Class Initialized
INFO - 2023-10-07 17:15:46 --> URI Class Initialized
DEBUG - 2023-10-07 17:15:46 --> No URI present. Default controller set.
INFO - 2023-10-07 17:15:46 --> Router Class Initialized
INFO - 2023-10-07 17:15:46 --> Output Class Initialized
INFO - 2023-10-07 17:15:46 --> Security Class Initialized
DEBUG - 2023-10-07 17:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:15:46 --> Input Class Initialized
INFO - 2023-10-07 17:15:46 --> Language Class Initialized
INFO - 2023-10-07 17:15:46 --> Loader Class Initialized
INFO - 2023-10-07 17:15:46 --> Helper loaded: url_helper
INFO - 2023-10-07 17:15:46 --> Helper loaded: file_helper
INFO - 2023-10-07 17:15:46 --> Helper loaded: html_helper
INFO - 2023-10-07 17:15:46 --> Helper loaded: text_helper
INFO - 2023-10-07 17:15:46 --> Helper loaded: form_helper
INFO - 2023-10-07 17:15:46 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:15:46 --> Helper loaded: security_helper
INFO - 2023-10-07 17:15:46 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:15:46 --> Database Driver Class Initialized
INFO - 2023-10-07 17:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:15:46 --> Parser Class Initialized
INFO - 2023-10-07 17:15:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:15:46 --> Pagination Class Initialized
INFO - 2023-10-07 17:15:46 --> Form Validation Class Initialized
INFO - 2023-10-07 17:15:46 --> Controller Class Initialized
INFO - 2023-10-07 17:15:46 --> Model Class Initialized
DEBUG - 2023-10-07 17:15:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:15:46 --> Model Class Initialized
DEBUG - 2023-10-07 17:15:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:15:46 --> Model Class Initialized
INFO - 2023-10-07 17:15:46 --> Model Class Initialized
INFO - 2023-10-07 17:15:46 --> Model Class Initialized
INFO - 2023-10-07 17:15:46 --> Model Class Initialized
DEBUG - 2023-10-07 17:15:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 17:15:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:15:46 --> Model Class Initialized
INFO - 2023-10-07 17:15:46 --> Model Class Initialized
INFO - 2023-10-07 17:15:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 17:15:46 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:15:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 17:15:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 17:15:46 --> Model Class Initialized
INFO - 2023-10-07 17:15:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 17:15:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 17:15:46 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 17:15:46 --> Final output sent to browser
DEBUG - 2023-10-07 17:15:46 --> Total execution time: 0.1121
ERROR - 2023-10-07 17:15:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:15:47 --> Config Class Initialized
INFO - 2023-10-07 17:15:47 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:15:47 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:15:47 --> Utf8 Class Initialized
INFO - 2023-10-07 17:15:47 --> URI Class Initialized
INFO - 2023-10-07 17:15:47 --> Router Class Initialized
INFO - 2023-10-07 17:15:47 --> Output Class Initialized
INFO - 2023-10-07 17:15:47 --> Security Class Initialized
DEBUG - 2023-10-07 17:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:15:47 --> Input Class Initialized
INFO - 2023-10-07 17:15:47 --> Language Class Initialized
INFO - 2023-10-07 17:15:47 --> Loader Class Initialized
INFO - 2023-10-07 17:15:47 --> Helper loaded: url_helper
INFO - 2023-10-07 17:15:47 --> Helper loaded: file_helper
INFO - 2023-10-07 17:15:47 --> Helper loaded: html_helper
INFO - 2023-10-07 17:15:47 --> Helper loaded: text_helper
INFO - 2023-10-07 17:15:47 --> Helper loaded: form_helper
INFO - 2023-10-07 17:15:47 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:15:47 --> Helper loaded: security_helper
INFO - 2023-10-07 17:15:47 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:15:47 --> Database Driver Class Initialized
INFO - 2023-10-07 17:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:15:47 --> Parser Class Initialized
INFO - 2023-10-07 17:15:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:15:47 --> Pagination Class Initialized
INFO - 2023-10-07 17:15:47 --> Form Validation Class Initialized
INFO - 2023-10-07 17:15:47 --> Controller Class Initialized
INFO - 2023-10-07 17:15:47 --> Model Class Initialized
DEBUG - 2023-10-07 17:15:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:15:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-10-07 17:15:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:15:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 17:15:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 17:15:47 --> Model Class Initialized
INFO - 2023-10-07 17:15:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 17:15:47 --> Final output sent to browser
DEBUG - 2023-10-07 17:15:47 --> Total execution time: 0.0332
ERROR - 2023-10-07 17:15:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:15:47 --> Config Class Initialized
INFO - 2023-10-07 17:15:47 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:15:47 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:15:47 --> Utf8 Class Initialized
INFO - 2023-10-07 17:15:47 --> URI Class Initialized
INFO - 2023-10-07 17:15:47 --> Router Class Initialized
INFO - 2023-10-07 17:15:47 --> Output Class Initialized
INFO - 2023-10-07 17:15:47 --> Security Class Initialized
DEBUG - 2023-10-07 17:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:15:47 --> Input Class Initialized
INFO - 2023-10-07 17:15:47 --> Language Class Initialized
INFO - 2023-10-07 17:15:47 --> Loader Class Initialized
INFO - 2023-10-07 17:15:47 --> Helper loaded: url_helper
INFO - 2023-10-07 17:15:47 --> Helper loaded: file_helper
INFO - 2023-10-07 17:15:47 --> Helper loaded: html_helper
INFO - 2023-10-07 17:15:47 --> Helper loaded: text_helper
INFO - 2023-10-07 17:15:47 --> Helper loaded: form_helper
INFO - 2023-10-07 17:15:47 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:15:47 --> Helper loaded: security_helper
INFO - 2023-10-07 17:15:47 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:15:47 --> Database Driver Class Initialized
INFO - 2023-10-07 17:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:15:47 --> Parser Class Initialized
INFO - 2023-10-07 17:15:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:15:47 --> Pagination Class Initialized
INFO - 2023-10-07 17:15:47 --> Form Validation Class Initialized
INFO - 2023-10-07 17:15:47 --> Controller Class Initialized
INFO - 2023-10-07 17:15:47 --> Model Class Initialized
DEBUG - 2023-10-07 17:15:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:15:47 --> Model Class Initialized
DEBUG - 2023-10-07 17:15:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:15:47 --> Model Class Initialized
INFO - 2023-10-07 17:15:47 --> Model Class Initialized
INFO - 2023-10-07 17:15:47 --> Model Class Initialized
INFO - 2023-10-07 17:15:47 --> Model Class Initialized
DEBUG - 2023-10-07 17:15:47 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 17:15:47 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:15:47 --> Model Class Initialized
INFO - 2023-10-07 17:15:47 --> Model Class Initialized
INFO - 2023-10-07 17:15:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 17:15:47 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:15:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 17:15:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 17:15:47 --> Model Class Initialized
INFO - 2023-10-07 17:15:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 17:15:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 17:15:47 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 17:15:47 --> Final output sent to browser
DEBUG - 2023-10-07 17:15:47 --> Total execution time: 0.1098
ERROR - 2023-10-07 17:16:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:16:03 --> Config Class Initialized
INFO - 2023-10-07 17:16:03 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:16:03 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:16:03 --> Utf8 Class Initialized
INFO - 2023-10-07 17:16:03 --> URI Class Initialized
INFO - 2023-10-07 17:16:03 --> Router Class Initialized
INFO - 2023-10-07 17:16:03 --> Output Class Initialized
INFO - 2023-10-07 17:16:03 --> Security Class Initialized
DEBUG - 2023-10-07 17:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:16:03 --> Input Class Initialized
INFO - 2023-10-07 17:16:03 --> Language Class Initialized
INFO - 2023-10-07 17:16:03 --> Loader Class Initialized
INFO - 2023-10-07 17:16:03 --> Helper loaded: url_helper
INFO - 2023-10-07 17:16:03 --> Helper loaded: file_helper
INFO - 2023-10-07 17:16:03 --> Helper loaded: html_helper
INFO - 2023-10-07 17:16:03 --> Helper loaded: text_helper
INFO - 2023-10-07 17:16:03 --> Helper loaded: form_helper
INFO - 2023-10-07 17:16:03 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:16:03 --> Helper loaded: security_helper
INFO - 2023-10-07 17:16:03 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:16:03 --> Database Driver Class Initialized
INFO - 2023-10-07 17:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:16:03 --> Parser Class Initialized
INFO - 2023-10-07 17:16:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:16:03 --> Pagination Class Initialized
INFO - 2023-10-07 17:16:03 --> Form Validation Class Initialized
INFO - 2023-10-07 17:16:03 --> Controller Class Initialized
INFO - 2023-10-07 17:16:03 --> Model Class Initialized
DEBUG - 2023-10-07 17:16:03 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 17:16:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:16:03 --> Model Class Initialized
DEBUG - 2023-10-07 17:16:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:16:03 --> Model Class Initialized
INFO - 2023-10-07 17:16:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-10-07 17:16:03 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:16:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 17:16:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 17:16:03 --> Model Class Initialized
INFO - 2023-10-07 17:16:03 --> Model Class Initialized
INFO - 2023-10-07 17:16:03 --> Model Class Initialized
INFO - 2023-10-07 17:16:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 17:16:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 17:16:03 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 17:16:03 --> Final output sent to browser
DEBUG - 2023-10-07 17:16:03 --> Total execution time: 0.0971
ERROR - 2023-10-07 17:16:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:16:04 --> Config Class Initialized
INFO - 2023-10-07 17:16:04 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:16:04 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:16:04 --> Utf8 Class Initialized
INFO - 2023-10-07 17:16:04 --> URI Class Initialized
INFO - 2023-10-07 17:16:04 --> Router Class Initialized
INFO - 2023-10-07 17:16:04 --> Output Class Initialized
INFO - 2023-10-07 17:16:04 --> Security Class Initialized
DEBUG - 2023-10-07 17:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:16:04 --> Input Class Initialized
INFO - 2023-10-07 17:16:04 --> Language Class Initialized
INFO - 2023-10-07 17:16:04 --> Loader Class Initialized
INFO - 2023-10-07 17:16:04 --> Helper loaded: url_helper
INFO - 2023-10-07 17:16:04 --> Helper loaded: file_helper
INFO - 2023-10-07 17:16:04 --> Helper loaded: html_helper
INFO - 2023-10-07 17:16:04 --> Helper loaded: text_helper
INFO - 2023-10-07 17:16:04 --> Helper loaded: form_helper
INFO - 2023-10-07 17:16:04 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:16:04 --> Helper loaded: security_helper
INFO - 2023-10-07 17:16:04 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:16:04 --> Database Driver Class Initialized
INFO - 2023-10-07 17:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:16:04 --> Parser Class Initialized
INFO - 2023-10-07 17:16:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:16:04 --> Pagination Class Initialized
INFO - 2023-10-07 17:16:04 --> Form Validation Class Initialized
INFO - 2023-10-07 17:16:04 --> Controller Class Initialized
INFO - 2023-10-07 17:16:04 --> Model Class Initialized
DEBUG - 2023-10-07 17:16:04 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 17:16:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:16:04 --> Model Class Initialized
DEBUG - 2023-10-07 17:16:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:16:04 --> Model Class Initialized
INFO - 2023-10-07 17:16:04 --> Final output sent to browser
DEBUG - 2023-10-07 17:16:04 --> Total execution time: 0.0431
ERROR - 2023-10-07 17:16:31 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:16:31 --> Config Class Initialized
INFO - 2023-10-07 17:16:31 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:16:31 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:16:31 --> Utf8 Class Initialized
INFO - 2023-10-07 17:16:31 --> URI Class Initialized
INFO - 2023-10-07 17:16:31 --> Router Class Initialized
INFO - 2023-10-07 17:16:31 --> Output Class Initialized
INFO - 2023-10-07 17:16:31 --> Security Class Initialized
DEBUG - 2023-10-07 17:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:16:31 --> Input Class Initialized
INFO - 2023-10-07 17:16:31 --> Language Class Initialized
INFO - 2023-10-07 17:16:31 --> Loader Class Initialized
INFO - 2023-10-07 17:16:31 --> Helper loaded: url_helper
INFO - 2023-10-07 17:16:31 --> Helper loaded: file_helper
INFO - 2023-10-07 17:16:31 --> Helper loaded: html_helper
INFO - 2023-10-07 17:16:31 --> Helper loaded: text_helper
INFO - 2023-10-07 17:16:31 --> Helper loaded: form_helper
INFO - 2023-10-07 17:16:31 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:16:31 --> Helper loaded: security_helper
INFO - 2023-10-07 17:16:31 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:16:31 --> Database Driver Class Initialized
INFO - 2023-10-07 17:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:16:31 --> Parser Class Initialized
INFO - 2023-10-07 17:16:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:16:31 --> Pagination Class Initialized
INFO - 2023-10-07 17:16:31 --> Form Validation Class Initialized
INFO - 2023-10-07 17:16:31 --> Controller Class Initialized
INFO - 2023-10-07 17:16:31 --> Model Class Initialized
DEBUG - 2023-10-07 17:16:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:16:31 --> Model Class Initialized
DEBUG - 2023-10-07 17:16:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:16:31 --> Model Class Initialized
INFO - 2023-10-07 17:16:31 --> Model Class Initialized
INFO - 2023-10-07 17:16:31 --> Model Class Initialized
INFO - 2023-10-07 17:16:31 --> Model Class Initialized
DEBUG - 2023-10-07 17:16:31 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 17:16:31 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:16:31 --> Model Class Initialized
INFO - 2023-10-07 17:16:31 --> Model Class Initialized
INFO - 2023-10-07 17:16:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 17:16:31 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:16:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 17:16:31 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 17:16:31 --> Model Class Initialized
INFO - 2023-10-07 17:16:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 17:16:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 17:16:32 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 17:16:32 --> Final output sent to browser
DEBUG - 2023-10-07 17:16:32 --> Total execution time: 0.1102
ERROR - 2023-10-07 17:16:43 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:16:43 --> Config Class Initialized
INFO - 2023-10-07 17:16:43 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:16:43 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:16:43 --> Utf8 Class Initialized
INFO - 2023-10-07 17:16:43 --> URI Class Initialized
INFO - 2023-10-07 17:16:43 --> Router Class Initialized
INFO - 2023-10-07 17:16:43 --> Output Class Initialized
INFO - 2023-10-07 17:16:43 --> Security Class Initialized
DEBUG - 2023-10-07 17:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:16:43 --> Input Class Initialized
INFO - 2023-10-07 17:16:43 --> Language Class Initialized
INFO - 2023-10-07 17:16:43 --> Loader Class Initialized
INFO - 2023-10-07 17:16:43 --> Helper loaded: url_helper
INFO - 2023-10-07 17:16:43 --> Helper loaded: file_helper
INFO - 2023-10-07 17:16:43 --> Helper loaded: html_helper
INFO - 2023-10-07 17:16:43 --> Helper loaded: text_helper
INFO - 2023-10-07 17:16:43 --> Helper loaded: form_helper
INFO - 2023-10-07 17:16:43 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:16:43 --> Helper loaded: security_helper
INFO - 2023-10-07 17:16:43 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:16:43 --> Database Driver Class Initialized
INFO - 2023-10-07 17:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:16:43 --> Parser Class Initialized
INFO - 2023-10-07 17:16:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:16:43 --> Pagination Class Initialized
INFO - 2023-10-07 17:16:43 --> Form Validation Class Initialized
INFO - 2023-10-07 17:16:43 --> Controller Class Initialized
INFO - 2023-10-07 17:16:43 --> Model Class Initialized
DEBUG - 2023-10-07 17:16:43 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 17:16:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:16:43 --> Model Class Initialized
DEBUG - 2023-10-07 17:16:43 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:16:43 --> Model Class Initialized
INFO - 2023-10-07 17:16:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-10-07 17:16:43 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:16:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 17:16:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 17:16:43 --> Model Class Initialized
INFO - 2023-10-07 17:16:43 --> Model Class Initialized
INFO - 2023-10-07 17:16:43 --> Model Class Initialized
INFO - 2023-10-07 17:16:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 17:16:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 17:16:43 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 17:16:43 --> Final output sent to browser
DEBUG - 2023-10-07 17:16:43 --> Total execution time: 0.1131
ERROR - 2023-10-07 17:17:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:17:08 --> Config Class Initialized
INFO - 2023-10-07 17:17:08 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:17:08 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:17:08 --> Utf8 Class Initialized
INFO - 2023-10-07 17:17:08 --> URI Class Initialized
INFO - 2023-10-07 17:17:08 --> Router Class Initialized
INFO - 2023-10-07 17:17:08 --> Output Class Initialized
INFO - 2023-10-07 17:17:08 --> Security Class Initialized
DEBUG - 2023-10-07 17:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:17:08 --> Input Class Initialized
INFO - 2023-10-07 17:17:08 --> Language Class Initialized
INFO - 2023-10-07 17:17:08 --> Loader Class Initialized
INFO - 2023-10-07 17:17:08 --> Helper loaded: url_helper
INFO - 2023-10-07 17:17:08 --> Helper loaded: file_helper
INFO - 2023-10-07 17:17:08 --> Helper loaded: html_helper
INFO - 2023-10-07 17:17:08 --> Helper loaded: text_helper
INFO - 2023-10-07 17:17:08 --> Helper loaded: form_helper
INFO - 2023-10-07 17:17:08 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:17:08 --> Helper loaded: security_helper
INFO - 2023-10-07 17:17:08 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:17:08 --> Database Driver Class Initialized
INFO - 2023-10-07 17:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:17:08 --> Parser Class Initialized
INFO - 2023-10-07 17:17:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:17:08 --> Pagination Class Initialized
INFO - 2023-10-07 17:17:08 --> Form Validation Class Initialized
INFO - 2023-10-07 17:17:08 --> Controller Class Initialized
INFO - 2023-10-07 17:17:08 --> Model Class Initialized
DEBUG - 2023-10-07 17:17:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:17:08 --> Final output sent to browser
DEBUG - 2023-10-07 17:17:08 --> Total execution time: 0.0187
ERROR - 2023-10-07 17:17:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:17:22 --> Config Class Initialized
INFO - 2023-10-07 17:17:22 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:17:22 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:17:22 --> Utf8 Class Initialized
INFO - 2023-10-07 17:17:22 --> URI Class Initialized
INFO - 2023-10-07 17:17:22 --> Router Class Initialized
INFO - 2023-10-07 17:17:22 --> Output Class Initialized
INFO - 2023-10-07 17:17:22 --> Security Class Initialized
DEBUG - 2023-10-07 17:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:17:22 --> Input Class Initialized
INFO - 2023-10-07 17:17:22 --> Language Class Initialized
INFO - 2023-10-07 17:17:22 --> Loader Class Initialized
INFO - 2023-10-07 17:17:22 --> Helper loaded: url_helper
INFO - 2023-10-07 17:17:22 --> Helper loaded: file_helper
INFO - 2023-10-07 17:17:22 --> Helper loaded: html_helper
INFO - 2023-10-07 17:17:22 --> Helper loaded: text_helper
INFO - 2023-10-07 17:17:22 --> Helper loaded: form_helper
INFO - 2023-10-07 17:17:22 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:17:22 --> Helper loaded: security_helper
INFO - 2023-10-07 17:17:22 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:17:22 --> Database Driver Class Initialized
INFO - 2023-10-07 17:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:17:22 --> Parser Class Initialized
INFO - 2023-10-07 17:17:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:17:22 --> Pagination Class Initialized
INFO - 2023-10-07 17:17:22 --> Form Validation Class Initialized
INFO - 2023-10-07 17:17:22 --> Controller Class Initialized
INFO - 2023-10-07 17:17:22 --> Model Class Initialized
DEBUG - 2023-10-07 17:17:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:17:22 --> Final output sent to browser
DEBUG - 2023-10-07 17:17:22 --> Total execution time: 0.0185
ERROR - 2023-10-07 17:17:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:17:23 --> Config Class Initialized
INFO - 2023-10-07 17:17:23 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:17:23 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:17:23 --> Utf8 Class Initialized
INFO - 2023-10-07 17:17:23 --> URI Class Initialized
INFO - 2023-10-07 17:17:23 --> Router Class Initialized
INFO - 2023-10-07 17:17:23 --> Output Class Initialized
INFO - 2023-10-07 17:17:23 --> Security Class Initialized
DEBUG - 2023-10-07 17:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:17:23 --> Input Class Initialized
INFO - 2023-10-07 17:17:23 --> Language Class Initialized
INFO - 2023-10-07 17:17:23 --> Loader Class Initialized
INFO - 2023-10-07 17:17:23 --> Helper loaded: url_helper
INFO - 2023-10-07 17:17:23 --> Helper loaded: file_helper
INFO - 2023-10-07 17:17:23 --> Helper loaded: html_helper
INFO - 2023-10-07 17:17:23 --> Helper loaded: text_helper
INFO - 2023-10-07 17:17:23 --> Helper loaded: form_helper
INFO - 2023-10-07 17:17:23 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:17:23 --> Helper loaded: security_helper
INFO - 2023-10-07 17:17:23 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:17:23 --> Database Driver Class Initialized
INFO - 2023-10-07 17:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:17:23 --> Parser Class Initialized
INFO - 2023-10-07 17:17:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:17:23 --> Pagination Class Initialized
INFO - 2023-10-07 17:17:23 --> Form Validation Class Initialized
INFO - 2023-10-07 17:17:23 --> Controller Class Initialized
INFO - 2023-10-07 17:17:23 --> Model Class Initialized
DEBUG - 2023-10-07 17:17:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:17:23 --> Final output sent to browser
DEBUG - 2023-10-07 17:17:23 --> Total execution time: 0.0165
ERROR - 2023-10-07 17:17:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:17:41 --> Config Class Initialized
INFO - 2023-10-07 17:17:41 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:17:41 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:17:41 --> Utf8 Class Initialized
INFO - 2023-10-07 17:17:41 --> URI Class Initialized
INFO - 2023-10-07 17:17:41 --> Router Class Initialized
INFO - 2023-10-07 17:17:41 --> Output Class Initialized
INFO - 2023-10-07 17:17:41 --> Security Class Initialized
DEBUG - 2023-10-07 17:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:17:41 --> Input Class Initialized
INFO - 2023-10-07 17:17:41 --> Language Class Initialized
INFO - 2023-10-07 17:17:41 --> Loader Class Initialized
INFO - 2023-10-07 17:17:41 --> Helper loaded: url_helper
INFO - 2023-10-07 17:17:41 --> Helper loaded: file_helper
INFO - 2023-10-07 17:17:41 --> Helper loaded: html_helper
INFO - 2023-10-07 17:17:41 --> Helper loaded: text_helper
INFO - 2023-10-07 17:17:41 --> Helper loaded: form_helper
INFO - 2023-10-07 17:17:41 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:17:41 --> Helper loaded: security_helper
INFO - 2023-10-07 17:17:41 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:17:41 --> Database Driver Class Initialized
INFO - 2023-10-07 17:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:17:41 --> Parser Class Initialized
INFO - 2023-10-07 17:17:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:17:41 --> Pagination Class Initialized
INFO - 2023-10-07 17:17:41 --> Form Validation Class Initialized
INFO - 2023-10-07 17:17:41 --> Controller Class Initialized
INFO - 2023-10-07 17:17:41 --> Model Class Initialized
DEBUG - 2023-10-07 17:17:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:17:41 --> Model Class Initialized
DEBUG - 2023-10-07 17:17:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:17:41 --> Model Class Initialized
INFO - 2023-10-07 17:17:41 --> Model Class Initialized
INFO - 2023-10-07 17:17:41 --> Model Class Initialized
INFO - 2023-10-07 17:17:41 --> Model Class Initialized
DEBUG - 2023-10-07 17:17:41 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 17:17:41 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:17:41 --> Model Class Initialized
INFO - 2023-10-07 17:17:41 --> Model Class Initialized
INFO - 2023-10-07 17:17:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 17:17:41 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:17:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 17:17:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 17:17:41 --> Model Class Initialized
INFO - 2023-10-07 17:17:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 17:17:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 17:17:41 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 17:17:41 --> Final output sent to browser
DEBUG - 2023-10-07 17:17:41 --> Total execution time: 0.1419
ERROR - 2023-10-07 17:18:08 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:18:08 --> Config Class Initialized
INFO - 2023-10-07 17:18:08 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:18:08 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:18:08 --> Utf8 Class Initialized
INFO - 2023-10-07 17:18:08 --> URI Class Initialized
INFO - 2023-10-07 17:18:08 --> Router Class Initialized
INFO - 2023-10-07 17:18:08 --> Output Class Initialized
INFO - 2023-10-07 17:18:08 --> Security Class Initialized
DEBUG - 2023-10-07 17:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:18:08 --> Input Class Initialized
INFO - 2023-10-07 17:18:08 --> Language Class Initialized
INFO - 2023-10-07 17:18:08 --> Loader Class Initialized
INFO - 2023-10-07 17:18:08 --> Helper loaded: url_helper
INFO - 2023-10-07 17:18:08 --> Helper loaded: file_helper
INFO - 2023-10-07 17:18:08 --> Helper loaded: html_helper
INFO - 2023-10-07 17:18:08 --> Helper loaded: text_helper
INFO - 2023-10-07 17:18:08 --> Helper loaded: form_helper
INFO - 2023-10-07 17:18:08 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:18:08 --> Helper loaded: security_helper
INFO - 2023-10-07 17:18:08 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:18:08 --> Database Driver Class Initialized
INFO - 2023-10-07 17:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:18:08 --> Parser Class Initialized
INFO - 2023-10-07 17:18:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:18:08 --> Pagination Class Initialized
INFO - 2023-10-07 17:18:08 --> Form Validation Class Initialized
INFO - 2023-10-07 17:18:08 --> Controller Class Initialized
INFO - 2023-10-07 17:18:08 --> Model Class Initialized
DEBUG - 2023-10-07 17:18:08 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 17:18:08 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:18:08 --> Model Class Initialized
INFO - 2023-10-07 17:18:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/stockrequest/inventory.php
DEBUG - 2023-10-07 17:18:08 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:18:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 17:18:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 17:18:08 --> Model Class Initialized
INFO - 2023-10-07 17:18:08 --> Model Class Initialized
INFO - 2023-10-07 17:18:08 --> Model Class Initialized
INFO - 2023-10-07 17:18:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 17:18:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 17:18:08 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 17:18:08 --> Final output sent to browser
DEBUG - 2023-10-07 17:18:08 --> Total execution time: 0.0835
ERROR - 2023-10-07 17:18:09 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:18:09 --> Config Class Initialized
INFO - 2023-10-07 17:18:09 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:18:09 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:18:09 --> Utf8 Class Initialized
INFO - 2023-10-07 17:18:09 --> URI Class Initialized
INFO - 2023-10-07 17:18:09 --> Router Class Initialized
INFO - 2023-10-07 17:18:09 --> Output Class Initialized
INFO - 2023-10-07 17:18:09 --> Security Class Initialized
DEBUG - 2023-10-07 17:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:18:09 --> Input Class Initialized
INFO - 2023-10-07 17:18:09 --> Language Class Initialized
INFO - 2023-10-07 17:18:09 --> Loader Class Initialized
INFO - 2023-10-07 17:18:09 --> Helper loaded: url_helper
INFO - 2023-10-07 17:18:09 --> Helper loaded: file_helper
INFO - 2023-10-07 17:18:09 --> Helper loaded: html_helper
INFO - 2023-10-07 17:18:09 --> Helper loaded: text_helper
INFO - 2023-10-07 17:18:09 --> Helper loaded: form_helper
INFO - 2023-10-07 17:18:09 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:18:09 --> Helper loaded: security_helper
INFO - 2023-10-07 17:18:09 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:18:09 --> Database Driver Class Initialized
INFO - 2023-10-07 17:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:18:09 --> Parser Class Initialized
INFO - 2023-10-07 17:18:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:18:09 --> Pagination Class Initialized
INFO - 2023-10-07 17:18:09 --> Form Validation Class Initialized
INFO - 2023-10-07 17:18:09 --> Controller Class Initialized
INFO - 2023-10-07 17:18:09 --> Model Class Initialized
DEBUG - 2023-10-07 17:18:09 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 17:18:09 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:18:09 --> Model Class Initialized
INFO - 2023-10-07 17:18:09 --> Final output sent to browser
DEBUG - 2023-10-07 17:18:09 --> Total execution time: 0.0254
ERROR - 2023-10-07 17:19:02 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:19:02 --> Config Class Initialized
INFO - 2023-10-07 17:19:02 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:19:02 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:19:02 --> Utf8 Class Initialized
INFO - 2023-10-07 17:19:02 --> URI Class Initialized
INFO - 2023-10-07 17:19:02 --> Router Class Initialized
INFO - 2023-10-07 17:19:02 --> Output Class Initialized
INFO - 2023-10-07 17:19:02 --> Security Class Initialized
DEBUG - 2023-10-07 17:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:19:02 --> Input Class Initialized
INFO - 2023-10-07 17:19:02 --> Language Class Initialized
INFO - 2023-10-07 17:19:02 --> Loader Class Initialized
INFO - 2023-10-07 17:19:02 --> Helper loaded: url_helper
INFO - 2023-10-07 17:19:02 --> Helper loaded: file_helper
INFO - 2023-10-07 17:19:02 --> Helper loaded: html_helper
INFO - 2023-10-07 17:19:02 --> Helper loaded: text_helper
INFO - 2023-10-07 17:19:02 --> Helper loaded: form_helper
INFO - 2023-10-07 17:19:02 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:19:02 --> Helper loaded: security_helper
INFO - 2023-10-07 17:19:02 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:19:02 --> Database Driver Class Initialized
INFO - 2023-10-07 17:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:19:02 --> Parser Class Initialized
INFO - 2023-10-07 17:19:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:19:02 --> Pagination Class Initialized
INFO - 2023-10-07 17:19:02 --> Form Validation Class Initialized
INFO - 2023-10-07 17:19:02 --> Controller Class Initialized
INFO - 2023-10-07 17:19:02 --> Model Class Initialized
DEBUG - 2023-10-07 17:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:19:02 --> Model Class Initialized
DEBUG - 2023-10-07 17:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:19:02 --> Model Class Initialized
INFO - 2023-10-07 17:19:02 --> Model Class Initialized
INFO - 2023-10-07 17:19:02 --> Model Class Initialized
INFO - 2023-10-07 17:19:02 --> Model Class Initialized
DEBUG - 2023-10-07 17:19:02 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 17:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:19:02 --> Model Class Initialized
INFO - 2023-10-07 17:19:02 --> Model Class Initialized
INFO - 2023-10-07 17:19:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 17:19:02 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:19:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 17:19:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 17:19:02 --> Model Class Initialized
INFO - 2023-10-07 17:19:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 17:19:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 17:19:02 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 17:19:02 --> Final output sent to browser
DEBUG - 2023-10-07 17:19:02 --> Total execution time: 0.1202
ERROR - 2023-10-07 17:19:40 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:19:40 --> Config Class Initialized
INFO - 2023-10-07 17:19:40 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:19:40 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:19:40 --> Utf8 Class Initialized
INFO - 2023-10-07 17:19:40 --> URI Class Initialized
INFO - 2023-10-07 17:19:40 --> Router Class Initialized
INFO - 2023-10-07 17:19:40 --> Output Class Initialized
INFO - 2023-10-07 17:19:40 --> Security Class Initialized
DEBUG - 2023-10-07 17:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:19:40 --> Input Class Initialized
INFO - 2023-10-07 17:19:40 --> Language Class Initialized
INFO - 2023-10-07 17:19:40 --> Loader Class Initialized
INFO - 2023-10-07 17:19:40 --> Helper loaded: url_helper
INFO - 2023-10-07 17:19:40 --> Helper loaded: file_helper
INFO - 2023-10-07 17:19:40 --> Helper loaded: html_helper
INFO - 2023-10-07 17:19:40 --> Helper loaded: text_helper
INFO - 2023-10-07 17:19:40 --> Helper loaded: form_helper
INFO - 2023-10-07 17:19:40 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:19:40 --> Helper loaded: security_helper
INFO - 2023-10-07 17:19:40 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:19:40 --> Database Driver Class Initialized
INFO - 2023-10-07 17:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:19:40 --> Parser Class Initialized
INFO - 2023-10-07 17:19:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:19:40 --> Pagination Class Initialized
INFO - 2023-10-07 17:19:40 --> Form Validation Class Initialized
INFO - 2023-10-07 17:19:40 --> Controller Class Initialized
INFO - 2023-10-07 17:19:40 --> Model Class Initialized
DEBUG - 2023-10-07 17:19:40 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 17:19:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:19:40 --> Model Class Initialized
DEBUG - 2023-10-07 17:19:40 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:19:40 --> Model Class Initialized
INFO - 2023-10-07 17:19:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/add_invoice_form.php
DEBUG - 2023-10-07 17:19:40 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:19:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 17:19:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 17:19:40 --> Model Class Initialized
INFO - 2023-10-07 17:19:40 --> Model Class Initialized
INFO - 2023-10-07 17:19:40 --> Model Class Initialized
INFO - 2023-10-07 17:19:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 17:19:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 17:19:40 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 17:19:40 --> Final output sent to browser
DEBUG - 2023-10-07 17:19:40 --> Total execution time: 0.1463
ERROR - 2023-10-07 17:20:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:20:11 --> Config Class Initialized
INFO - 2023-10-07 17:20:11 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:20:11 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:20:11 --> Utf8 Class Initialized
INFO - 2023-10-07 17:20:11 --> URI Class Initialized
INFO - 2023-10-07 17:20:11 --> Router Class Initialized
INFO - 2023-10-07 17:20:11 --> Output Class Initialized
INFO - 2023-10-07 17:20:11 --> Security Class Initialized
DEBUG - 2023-10-07 17:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:20:11 --> Input Class Initialized
INFO - 2023-10-07 17:20:11 --> Language Class Initialized
INFO - 2023-10-07 17:20:11 --> Loader Class Initialized
INFO - 2023-10-07 17:20:11 --> Helper loaded: url_helper
INFO - 2023-10-07 17:20:11 --> Helper loaded: file_helper
INFO - 2023-10-07 17:20:11 --> Helper loaded: html_helper
INFO - 2023-10-07 17:20:11 --> Helper loaded: text_helper
INFO - 2023-10-07 17:20:11 --> Helper loaded: form_helper
INFO - 2023-10-07 17:20:11 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:20:11 --> Helper loaded: security_helper
INFO - 2023-10-07 17:20:11 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:20:11 --> Database Driver Class Initialized
INFO - 2023-10-07 17:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:20:11 --> Parser Class Initialized
INFO - 2023-10-07 17:20:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:20:11 --> Pagination Class Initialized
INFO - 2023-10-07 17:20:11 --> Form Validation Class Initialized
INFO - 2023-10-07 17:20:11 --> Controller Class Initialized
INFO - 2023-10-07 17:20:11 --> Model Class Initialized
DEBUG - 2023-10-07 17:20:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-07 17:20:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-07 17:20:11 --> Final output sent to browser
DEBUG - 2023-10-07 17:20:11 --> Total execution time: 0.0187
ERROR - 2023-10-07 17:20:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:20:18 --> Config Class Initialized
INFO - 2023-10-07 17:20:18 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:20:18 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:20:18 --> Utf8 Class Initialized
INFO - 2023-10-07 17:20:18 --> URI Class Initialized
INFO - 2023-10-07 17:20:18 --> Router Class Initialized
INFO - 2023-10-07 17:20:18 --> Output Class Initialized
INFO - 2023-10-07 17:20:18 --> Security Class Initialized
DEBUG - 2023-10-07 17:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:20:18 --> Input Class Initialized
INFO - 2023-10-07 17:20:18 --> Language Class Initialized
INFO - 2023-10-07 17:20:18 --> Loader Class Initialized
INFO - 2023-10-07 17:20:18 --> Helper loaded: url_helper
INFO - 2023-10-07 17:20:18 --> Helper loaded: file_helper
INFO - 2023-10-07 17:20:18 --> Helper loaded: html_helper
INFO - 2023-10-07 17:20:18 --> Helper loaded: text_helper
INFO - 2023-10-07 17:20:18 --> Helper loaded: form_helper
INFO - 2023-10-07 17:20:18 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:20:18 --> Helper loaded: security_helper
INFO - 2023-10-07 17:20:18 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:20:18 --> Database Driver Class Initialized
INFO - 2023-10-07 17:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:20:18 --> Parser Class Initialized
INFO - 2023-10-07 17:20:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:20:18 --> Pagination Class Initialized
INFO - 2023-10-07 17:20:18 --> Form Validation Class Initialized
INFO - 2023-10-07 17:20:18 --> Controller Class Initialized
INFO - 2023-10-07 17:20:18 --> Model Class Initialized
DEBUG - 2023-10-07 17:20:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-07 17:20:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-07 17:20:18 --> Final output sent to browser
DEBUG - 2023-10-07 17:20:18 --> Total execution time: 0.0164
ERROR - 2023-10-07 17:20:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:20:22 --> Config Class Initialized
INFO - 2023-10-07 17:20:22 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:20:22 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:20:22 --> Utf8 Class Initialized
INFO - 2023-10-07 17:20:22 --> URI Class Initialized
INFO - 2023-10-07 17:20:22 --> Router Class Initialized
INFO - 2023-10-07 17:20:22 --> Output Class Initialized
INFO - 2023-10-07 17:20:22 --> Security Class Initialized
DEBUG - 2023-10-07 17:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:20:22 --> Input Class Initialized
INFO - 2023-10-07 17:20:22 --> Language Class Initialized
INFO - 2023-10-07 17:20:22 --> Loader Class Initialized
INFO - 2023-10-07 17:20:22 --> Helper loaded: url_helper
INFO - 2023-10-07 17:20:22 --> Helper loaded: file_helper
INFO - 2023-10-07 17:20:22 --> Helper loaded: html_helper
INFO - 2023-10-07 17:20:22 --> Helper loaded: text_helper
INFO - 2023-10-07 17:20:22 --> Helper loaded: form_helper
INFO - 2023-10-07 17:20:22 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:20:22 --> Helper loaded: security_helper
INFO - 2023-10-07 17:20:22 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:20:22 --> Database Driver Class Initialized
INFO - 2023-10-07 17:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:20:22 --> Parser Class Initialized
INFO - 2023-10-07 17:20:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:20:22 --> Pagination Class Initialized
INFO - 2023-10-07 17:20:22 --> Form Validation Class Initialized
INFO - 2023-10-07 17:20:22 --> Controller Class Initialized
INFO - 2023-10-07 17:20:22 --> Model Class Initialized
DEBUG - 2023-10-07 17:20:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-07 17:20:22 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-07 17:20:22 --> Final output sent to browser
DEBUG - 2023-10-07 17:20:22 --> Total execution time: 0.0161
ERROR - 2023-10-07 17:20:38 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:20:38 --> Config Class Initialized
INFO - 2023-10-07 17:20:38 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:20:38 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:20:38 --> Utf8 Class Initialized
INFO - 2023-10-07 17:20:38 --> URI Class Initialized
INFO - 2023-10-07 17:20:38 --> Router Class Initialized
INFO - 2023-10-07 17:20:38 --> Output Class Initialized
INFO - 2023-10-07 17:20:38 --> Security Class Initialized
DEBUG - 2023-10-07 17:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:20:38 --> Input Class Initialized
INFO - 2023-10-07 17:20:38 --> Language Class Initialized
INFO - 2023-10-07 17:20:38 --> Loader Class Initialized
INFO - 2023-10-07 17:20:38 --> Helper loaded: url_helper
INFO - 2023-10-07 17:20:38 --> Helper loaded: file_helper
INFO - 2023-10-07 17:20:38 --> Helper loaded: html_helper
INFO - 2023-10-07 17:20:38 --> Helper loaded: text_helper
INFO - 2023-10-07 17:20:38 --> Helper loaded: form_helper
INFO - 2023-10-07 17:20:38 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:20:38 --> Helper loaded: security_helper
INFO - 2023-10-07 17:20:38 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:20:38 --> Database Driver Class Initialized
INFO - 2023-10-07 17:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:20:38 --> Parser Class Initialized
INFO - 2023-10-07 17:20:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:20:38 --> Pagination Class Initialized
INFO - 2023-10-07 17:20:38 --> Form Validation Class Initialized
INFO - 2023-10-07 17:20:38 --> Controller Class Initialized
INFO - 2023-10-07 17:20:38 --> Model Class Initialized
DEBUG - 2023-10-07 17:20:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-07 17:20:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-07 17:20:38 --> Final output sent to browser
DEBUG - 2023-10-07 17:20:38 --> Total execution time: 0.0186
ERROR - 2023-10-07 17:20:41 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:20:41 --> Config Class Initialized
INFO - 2023-10-07 17:20:41 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:20:41 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:20:41 --> Utf8 Class Initialized
INFO - 2023-10-07 17:20:41 --> URI Class Initialized
INFO - 2023-10-07 17:20:41 --> Router Class Initialized
INFO - 2023-10-07 17:20:41 --> Output Class Initialized
INFO - 2023-10-07 17:20:41 --> Security Class Initialized
DEBUG - 2023-10-07 17:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:20:41 --> Input Class Initialized
INFO - 2023-10-07 17:20:41 --> Language Class Initialized
INFO - 2023-10-07 17:20:41 --> Loader Class Initialized
INFO - 2023-10-07 17:20:41 --> Helper loaded: url_helper
INFO - 2023-10-07 17:20:41 --> Helper loaded: file_helper
INFO - 2023-10-07 17:20:41 --> Helper loaded: html_helper
INFO - 2023-10-07 17:20:41 --> Helper loaded: text_helper
INFO - 2023-10-07 17:20:41 --> Helper loaded: form_helper
INFO - 2023-10-07 17:20:41 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:20:41 --> Helper loaded: security_helper
INFO - 2023-10-07 17:20:41 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:20:41 --> Database Driver Class Initialized
INFO - 2023-10-07 17:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:20:41 --> Parser Class Initialized
INFO - 2023-10-07 17:20:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:20:41 --> Pagination Class Initialized
INFO - 2023-10-07 17:20:41 --> Form Validation Class Initialized
INFO - 2023-10-07 17:20:41 --> Controller Class Initialized
INFO - 2023-10-07 17:20:41 --> Model Class Initialized
DEBUG - 2023-10-07 17:20:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-07 17:20:41 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-07 17:20:41 --> Final output sent to browser
DEBUG - 2023-10-07 17:20:41 --> Total execution time: 0.0169
ERROR - 2023-10-07 17:20:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:20:48 --> Config Class Initialized
INFO - 2023-10-07 17:20:48 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:20:48 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:20:48 --> Utf8 Class Initialized
INFO - 2023-10-07 17:20:48 --> URI Class Initialized
INFO - 2023-10-07 17:20:48 --> Router Class Initialized
INFO - 2023-10-07 17:20:48 --> Output Class Initialized
INFO - 2023-10-07 17:20:48 --> Security Class Initialized
DEBUG - 2023-10-07 17:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:20:48 --> Input Class Initialized
INFO - 2023-10-07 17:20:48 --> Language Class Initialized
INFO - 2023-10-07 17:20:48 --> Loader Class Initialized
INFO - 2023-10-07 17:20:48 --> Helper loaded: url_helper
INFO - 2023-10-07 17:20:48 --> Helper loaded: file_helper
INFO - 2023-10-07 17:20:48 --> Helper loaded: html_helper
INFO - 2023-10-07 17:20:48 --> Helper loaded: text_helper
INFO - 2023-10-07 17:20:48 --> Helper loaded: form_helper
INFO - 2023-10-07 17:20:48 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:20:48 --> Helper loaded: security_helper
INFO - 2023-10-07 17:20:48 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:20:48 --> Database Driver Class Initialized
INFO - 2023-10-07 17:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:20:48 --> Parser Class Initialized
INFO - 2023-10-07 17:20:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:20:48 --> Pagination Class Initialized
INFO - 2023-10-07 17:20:48 --> Form Validation Class Initialized
INFO - 2023-10-07 17:20:48 --> Controller Class Initialized
INFO - 2023-10-07 17:20:48 --> Model Class Initialized
DEBUG - 2023-10-07 17:20:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-07 17:20:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-07 17:20:48 --> Final output sent to browser
DEBUG - 2023-10-07 17:20:48 --> Total execution time: 0.0160
ERROR - 2023-10-07 17:20:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:20:48 --> Config Class Initialized
INFO - 2023-10-07 17:20:48 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:20:48 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:20:48 --> Utf8 Class Initialized
INFO - 2023-10-07 17:20:48 --> URI Class Initialized
INFO - 2023-10-07 17:20:48 --> Router Class Initialized
INFO - 2023-10-07 17:20:48 --> Output Class Initialized
INFO - 2023-10-07 17:20:48 --> Security Class Initialized
DEBUG - 2023-10-07 17:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:20:48 --> Input Class Initialized
INFO - 2023-10-07 17:20:48 --> Language Class Initialized
INFO - 2023-10-07 17:20:48 --> Loader Class Initialized
INFO - 2023-10-07 17:20:48 --> Helper loaded: url_helper
INFO - 2023-10-07 17:20:48 --> Helper loaded: file_helper
INFO - 2023-10-07 17:20:48 --> Helper loaded: html_helper
INFO - 2023-10-07 17:20:48 --> Helper loaded: text_helper
INFO - 2023-10-07 17:20:48 --> Helper loaded: form_helper
INFO - 2023-10-07 17:20:48 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:20:48 --> Helper loaded: security_helper
INFO - 2023-10-07 17:20:48 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:20:48 --> Database Driver Class Initialized
INFO - 2023-10-07 17:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:20:48 --> Parser Class Initialized
INFO - 2023-10-07 17:20:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:20:48 --> Pagination Class Initialized
INFO - 2023-10-07 17:20:48 --> Form Validation Class Initialized
INFO - 2023-10-07 17:20:48 --> Controller Class Initialized
INFO - 2023-10-07 17:20:48 --> Model Class Initialized
DEBUG - 2023-10-07 17:20:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-07 17:20:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-07 17:20:48 --> Final output sent to browser
DEBUG - 2023-10-07 17:20:48 --> Total execution time: 0.0154
ERROR - 2023-10-07 17:20:53 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:20:53 --> Config Class Initialized
INFO - 2023-10-07 17:20:53 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:20:53 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:20:53 --> Utf8 Class Initialized
INFO - 2023-10-07 17:20:53 --> URI Class Initialized
INFO - 2023-10-07 17:20:53 --> Router Class Initialized
INFO - 2023-10-07 17:20:53 --> Output Class Initialized
INFO - 2023-10-07 17:20:53 --> Security Class Initialized
DEBUG - 2023-10-07 17:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:20:53 --> Input Class Initialized
INFO - 2023-10-07 17:20:53 --> Language Class Initialized
INFO - 2023-10-07 17:20:53 --> Loader Class Initialized
INFO - 2023-10-07 17:20:53 --> Helper loaded: url_helper
INFO - 2023-10-07 17:20:53 --> Helper loaded: file_helper
INFO - 2023-10-07 17:20:53 --> Helper loaded: html_helper
INFO - 2023-10-07 17:20:53 --> Helper loaded: text_helper
INFO - 2023-10-07 17:20:53 --> Helper loaded: form_helper
INFO - 2023-10-07 17:20:53 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:20:53 --> Helper loaded: security_helper
INFO - 2023-10-07 17:20:53 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:20:53 --> Database Driver Class Initialized
INFO - 2023-10-07 17:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:20:53 --> Parser Class Initialized
INFO - 2023-10-07 17:20:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:20:53 --> Pagination Class Initialized
INFO - 2023-10-07 17:20:53 --> Form Validation Class Initialized
INFO - 2023-10-07 17:20:53 --> Controller Class Initialized
INFO - 2023-10-07 17:20:53 --> Model Class Initialized
DEBUG - 2023-10-07 17:20:53 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:20:53 --> Final output sent to browser
DEBUG - 2023-10-07 17:20:53 --> Total execution time: 0.0181
ERROR - 2023-10-07 17:20:59 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:20:59 --> Config Class Initialized
INFO - 2023-10-07 17:20:59 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:20:59 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:20:59 --> Utf8 Class Initialized
INFO - 2023-10-07 17:20:59 --> URI Class Initialized
INFO - 2023-10-07 17:20:59 --> Router Class Initialized
INFO - 2023-10-07 17:20:59 --> Output Class Initialized
INFO - 2023-10-07 17:20:59 --> Security Class Initialized
DEBUG - 2023-10-07 17:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:20:59 --> Input Class Initialized
INFO - 2023-10-07 17:20:59 --> Language Class Initialized
INFO - 2023-10-07 17:20:59 --> Loader Class Initialized
INFO - 2023-10-07 17:20:59 --> Helper loaded: url_helper
INFO - 2023-10-07 17:20:59 --> Helper loaded: file_helper
INFO - 2023-10-07 17:20:59 --> Helper loaded: html_helper
INFO - 2023-10-07 17:20:59 --> Helper loaded: text_helper
INFO - 2023-10-07 17:20:59 --> Helper loaded: form_helper
INFO - 2023-10-07 17:20:59 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:20:59 --> Helper loaded: security_helper
INFO - 2023-10-07 17:20:59 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:20:59 --> Database Driver Class Initialized
INFO - 2023-10-07 17:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:20:59 --> Parser Class Initialized
INFO - 2023-10-07 17:20:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:20:59 --> Pagination Class Initialized
INFO - 2023-10-07 17:20:59 --> Form Validation Class Initialized
INFO - 2023-10-07 17:20:59 --> Controller Class Initialized
INFO - 2023-10-07 17:20:59 --> Model Class Initialized
DEBUG - 2023-10-07 17:20:59 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:20:59 --> Final output sent to browser
DEBUG - 2023-10-07 17:20:59 --> Total execution time: 0.0157
ERROR - 2023-10-07 17:21:03 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:21:03 --> Config Class Initialized
INFO - 2023-10-07 17:21:03 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:21:03 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:21:03 --> Utf8 Class Initialized
INFO - 2023-10-07 17:21:03 --> URI Class Initialized
INFO - 2023-10-07 17:21:03 --> Router Class Initialized
INFO - 2023-10-07 17:21:03 --> Output Class Initialized
INFO - 2023-10-07 17:21:03 --> Security Class Initialized
DEBUG - 2023-10-07 17:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:21:03 --> Input Class Initialized
INFO - 2023-10-07 17:21:03 --> Language Class Initialized
INFO - 2023-10-07 17:21:03 --> Loader Class Initialized
INFO - 2023-10-07 17:21:03 --> Helper loaded: url_helper
INFO - 2023-10-07 17:21:03 --> Helper loaded: file_helper
INFO - 2023-10-07 17:21:03 --> Helper loaded: html_helper
INFO - 2023-10-07 17:21:03 --> Helper loaded: text_helper
INFO - 2023-10-07 17:21:03 --> Helper loaded: form_helper
INFO - 2023-10-07 17:21:03 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:21:03 --> Helper loaded: security_helper
INFO - 2023-10-07 17:21:03 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:21:03 --> Database Driver Class Initialized
INFO - 2023-10-07 17:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:21:03 --> Parser Class Initialized
INFO - 2023-10-07 17:21:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:21:03 --> Pagination Class Initialized
INFO - 2023-10-07 17:21:03 --> Form Validation Class Initialized
INFO - 2023-10-07 17:21:03 --> Controller Class Initialized
INFO - 2023-10-07 17:21:03 --> Model Class Initialized
DEBUG - 2023-10-07 17:21:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:21:03 --> Final output sent to browser
DEBUG - 2023-10-07 17:21:03 --> Total execution time: 0.0204
ERROR - 2023-10-07 17:21:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:21:04 --> Config Class Initialized
INFO - 2023-10-07 17:21:04 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:21:04 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:21:04 --> Utf8 Class Initialized
INFO - 2023-10-07 17:21:04 --> URI Class Initialized
INFO - 2023-10-07 17:21:04 --> Router Class Initialized
INFO - 2023-10-07 17:21:04 --> Output Class Initialized
INFO - 2023-10-07 17:21:04 --> Security Class Initialized
DEBUG - 2023-10-07 17:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:21:04 --> Input Class Initialized
INFO - 2023-10-07 17:21:04 --> Language Class Initialized
INFO - 2023-10-07 17:21:04 --> Loader Class Initialized
INFO - 2023-10-07 17:21:04 --> Helper loaded: url_helper
INFO - 2023-10-07 17:21:04 --> Helper loaded: file_helper
INFO - 2023-10-07 17:21:04 --> Helper loaded: html_helper
INFO - 2023-10-07 17:21:04 --> Helper loaded: text_helper
INFO - 2023-10-07 17:21:04 --> Helper loaded: form_helper
INFO - 2023-10-07 17:21:04 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:21:04 --> Helper loaded: security_helper
INFO - 2023-10-07 17:21:04 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:21:04 --> Database Driver Class Initialized
INFO - 2023-10-07 17:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:21:04 --> Parser Class Initialized
INFO - 2023-10-07 17:21:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:21:04 --> Pagination Class Initialized
INFO - 2023-10-07 17:21:04 --> Form Validation Class Initialized
INFO - 2023-10-07 17:21:04 --> Controller Class Initialized
INFO - 2023-10-07 17:21:04 --> Model Class Initialized
DEBUG - 2023-10-07 17:21:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:21:04 --> Final output sent to browser
DEBUG - 2023-10-07 17:21:04 --> Total execution time: 0.0154
ERROR - 2023-10-07 17:21:07 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:21:07 --> Config Class Initialized
INFO - 2023-10-07 17:21:07 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:21:07 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:21:07 --> Utf8 Class Initialized
INFO - 2023-10-07 17:21:07 --> URI Class Initialized
INFO - 2023-10-07 17:21:07 --> Router Class Initialized
INFO - 2023-10-07 17:21:07 --> Output Class Initialized
INFO - 2023-10-07 17:21:07 --> Security Class Initialized
DEBUG - 2023-10-07 17:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:21:07 --> Input Class Initialized
INFO - 2023-10-07 17:21:07 --> Language Class Initialized
INFO - 2023-10-07 17:21:07 --> Loader Class Initialized
INFO - 2023-10-07 17:21:07 --> Helper loaded: url_helper
INFO - 2023-10-07 17:21:07 --> Helper loaded: file_helper
INFO - 2023-10-07 17:21:07 --> Helper loaded: html_helper
INFO - 2023-10-07 17:21:07 --> Helper loaded: text_helper
INFO - 2023-10-07 17:21:07 --> Helper loaded: form_helper
INFO - 2023-10-07 17:21:07 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:21:07 --> Helper loaded: security_helper
INFO - 2023-10-07 17:21:07 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:21:07 --> Database Driver Class Initialized
INFO - 2023-10-07 17:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:21:07 --> Parser Class Initialized
INFO - 2023-10-07 17:21:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:21:07 --> Pagination Class Initialized
INFO - 2023-10-07 17:21:07 --> Form Validation Class Initialized
INFO - 2023-10-07 17:21:07 --> Controller Class Initialized
INFO - 2023-10-07 17:21:07 --> Model Class Initialized
DEBUG - 2023-10-07 17:21:07 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:21:07 --> Final output sent to browser
DEBUG - 2023-10-07 17:21:07 --> Total execution time: 0.0211
ERROR - 2023-10-07 17:21:11 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:21:11 --> Config Class Initialized
INFO - 2023-10-07 17:21:11 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:21:11 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:21:11 --> Utf8 Class Initialized
INFO - 2023-10-07 17:21:11 --> URI Class Initialized
INFO - 2023-10-07 17:21:11 --> Router Class Initialized
INFO - 2023-10-07 17:21:11 --> Output Class Initialized
INFO - 2023-10-07 17:21:11 --> Security Class Initialized
DEBUG - 2023-10-07 17:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:21:11 --> Input Class Initialized
INFO - 2023-10-07 17:21:11 --> Language Class Initialized
INFO - 2023-10-07 17:21:11 --> Loader Class Initialized
INFO - 2023-10-07 17:21:11 --> Helper loaded: url_helper
INFO - 2023-10-07 17:21:11 --> Helper loaded: file_helper
INFO - 2023-10-07 17:21:11 --> Helper loaded: html_helper
INFO - 2023-10-07 17:21:11 --> Helper loaded: text_helper
INFO - 2023-10-07 17:21:11 --> Helper loaded: form_helper
INFO - 2023-10-07 17:21:11 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:21:11 --> Helper loaded: security_helper
INFO - 2023-10-07 17:21:11 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:21:11 --> Database Driver Class Initialized
INFO - 2023-10-07 17:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:21:11 --> Parser Class Initialized
INFO - 2023-10-07 17:21:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:21:11 --> Pagination Class Initialized
INFO - 2023-10-07 17:21:11 --> Form Validation Class Initialized
INFO - 2023-10-07 17:21:11 --> Controller Class Initialized
INFO - 2023-10-07 17:21:11 --> Model Class Initialized
DEBUG - 2023-10-07 17:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:21:11 --> Final output sent to browser
DEBUG - 2023-10-07 17:21:11 --> Total execution time: 0.0174
ERROR - 2023-10-07 17:21:12 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:21:12 --> Config Class Initialized
INFO - 2023-10-07 17:21:12 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:21:12 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:21:12 --> Utf8 Class Initialized
INFO - 2023-10-07 17:21:12 --> URI Class Initialized
INFO - 2023-10-07 17:21:12 --> Router Class Initialized
INFO - 2023-10-07 17:21:12 --> Output Class Initialized
INFO - 2023-10-07 17:21:12 --> Security Class Initialized
DEBUG - 2023-10-07 17:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:21:12 --> Input Class Initialized
INFO - 2023-10-07 17:21:12 --> Language Class Initialized
INFO - 2023-10-07 17:21:12 --> Loader Class Initialized
INFO - 2023-10-07 17:21:12 --> Helper loaded: url_helper
INFO - 2023-10-07 17:21:12 --> Helper loaded: file_helper
INFO - 2023-10-07 17:21:12 --> Helper loaded: html_helper
INFO - 2023-10-07 17:21:12 --> Helper loaded: text_helper
INFO - 2023-10-07 17:21:12 --> Helper loaded: form_helper
INFO - 2023-10-07 17:21:12 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:21:12 --> Helper loaded: security_helper
INFO - 2023-10-07 17:21:12 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:21:12 --> Database Driver Class Initialized
INFO - 2023-10-07 17:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:21:12 --> Parser Class Initialized
INFO - 2023-10-07 17:21:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:21:12 --> Pagination Class Initialized
INFO - 2023-10-07 17:21:12 --> Form Validation Class Initialized
INFO - 2023-10-07 17:21:12 --> Controller Class Initialized
INFO - 2023-10-07 17:21:12 --> Model Class Initialized
DEBUG - 2023-10-07 17:21:12 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:21:12 --> Final output sent to browser
DEBUG - 2023-10-07 17:21:12 --> Total execution time: 0.0155
ERROR - 2023-10-07 17:21:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:21:23 --> Config Class Initialized
INFO - 2023-10-07 17:21:23 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:21:23 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:21:23 --> Utf8 Class Initialized
INFO - 2023-10-07 17:21:23 --> URI Class Initialized
INFO - 2023-10-07 17:21:23 --> Router Class Initialized
INFO - 2023-10-07 17:21:23 --> Output Class Initialized
INFO - 2023-10-07 17:21:23 --> Security Class Initialized
DEBUG - 2023-10-07 17:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:21:23 --> Input Class Initialized
INFO - 2023-10-07 17:21:23 --> Language Class Initialized
INFO - 2023-10-07 17:21:23 --> Loader Class Initialized
INFO - 2023-10-07 17:21:23 --> Helper loaded: url_helper
INFO - 2023-10-07 17:21:23 --> Helper loaded: file_helper
INFO - 2023-10-07 17:21:23 --> Helper loaded: html_helper
INFO - 2023-10-07 17:21:23 --> Helper loaded: text_helper
INFO - 2023-10-07 17:21:23 --> Helper loaded: form_helper
INFO - 2023-10-07 17:21:23 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:21:23 --> Helper loaded: security_helper
INFO - 2023-10-07 17:21:23 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:21:23 --> Database Driver Class Initialized
INFO - 2023-10-07 17:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:21:23 --> Parser Class Initialized
INFO - 2023-10-07 17:21:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:21:23 --> Pagination Class Initialized
INFO - 2023-10-07 17:21:23 --> Form Validation Class Initialized
INFO - 2023-10-07 17:21:23 --> Controller Class Initialized
INFO - 2023-10-07 17:21:23 --> Model Class Initialized
DEBUG - 2023-10-07 17:21:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:21:23 --> Final output sent to browser
DEBUG - 2023-10-07 17:21:23 --> Total execution time: 0.0178
ERROR - 2023-10-07 17:21:52 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:21:52 --> Config Class Initialized
INFO - 2023-10-07 17:21:52 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:21:52 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:21:52 --> Utf8 Class Initialized
INFO - 2023-10-07 17:21:52 --> URI Class Initialized
INFO - 2023-10-07 17:21:52 --> Router Class Initialized
INFO - 2023-10-07 17:21:52 --> Output Class Initialized
INFO - 2023-10-07 17:21:52 --> Security Class Initialized
DEBUG - 2023-10-07 17:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:21:52 --> Input Class Initialized
INFO - 2023-10-07 17:21:52 --> Language Class Initialized
INFO - 2023-10-07 17:21:52 --> Loader Class Initialized
INFO - 2023-10-07 17:21:52 --> Helper loaded: url_helper
INFO - 2023-10-07 17:21:52 --> Helper loaded: file_helper
INFO - 2023-10-07 17:21:52 --> Helper loaded: html_helper
INFO - 2023-10-07 17:21:52 --> Helper loaded: text_helper
INFO - 2023-10-07 17:21:52 --> Helper loaded: form_helper
INFO - 2023-10-07 17:21:52 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:21:52 --> Helper loaded: security_helper
INFO - 2023-10-07 17:21:52 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:21:52 --> Database Driver Class Initialized
INFO - 2023-10-07 17:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:21:52 --> Parser Class Initialized
INFO - 2023-10-07 17:21:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:21:52 --> Pagination Class Initialized
INFO - 2023-10-07 17:21:52 --> Form Validation Class Initialized
INFO - 2023-10-07 17:21:52 --> Controller Class Initialized
INFO - 2023-10-07 17:21:52 --> Final output sent to browser
DEBUG - 2023-10-07 17:21:52 --> Total execution time: 0.0169
ERROR - 2023-10-07 17:22:10 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:22:10 --> Config Class Initialized
INFO - 2023-10-07 17:22:10 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:22:10 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:22:10 --> Utf8 Class Initialized
INFO - 2023-10-07 17:22:10 --> URI Class Initialized
INFO - 2023-10-07 17:22:10 --> Router Class Initialized
INFO - 2023-10-07 17:22:10 --> Output Class Initialized
INFO - 2023-10-07 17:22:10 --> Security Class Initialized
DEBUG - 2023-10-07 17:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:22:10 --> Input Class Initialized
INFO - 2023-10-07 17:22:10 --> Language Class Initialized
INFO - 2023-10-07 17:22:10 --> Loader Class Initialized
INFO - 2023-10-07 17:22:10 --> Helper loaded: url_helper
INFO - 2023-10-07 17:22:10 --> Helper loaded: file_helper
INFO - 2023-10-07 17:22:10 --> Helper loaded: html_helper
INFO - 2023-10-07 17:22:10 --> Helper loaded: text_helper
INFO - 2023-10-07 17:22:10 --> Helper loaded: form_helper
INFO - 2023-10-07 17:22:10 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:22:10 --> Helper loaded: security_helper
INFO - 2023-10-07 17:22:10 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:22:10 --> Database Driver Class Initialized
INFO - 2023-10-07 17:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:22:11 --> Parser Class Initialized
INFO - 2023-10-07 17:22:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:22:11 --> Pagination Class Initialized
INFO - 2023-10-07 17:22:11 --> Form Validation Class Initialized
INFO - 2023-10-07 17:22:11 --> Controller Class Initialized
INFO - 2023-10-07 17:22:11 --> Model Class Initialized
DEBUG - 2023-10-07 17:22:11 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:22:11 --> Final output sent to browser
DEBUG - 2023-10-07 17:22:11 --> Total execution time: 0.0211
ERROR - 2023-10-07 17:22:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:22:25 --> Config Class Initialized
INFO - 2023-10-07 17:22:25 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:22:25 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:22:25 --> Utf8 Class Initialized
INFO - 2023-10-07 17:22:25 --> URI Class Initialized
INFO - 2023-10-07 17:22:25 --> Router Class Initialized
INFO - 2023-10-07 17:22:25 --> Output Class Initialized
INFO - 2023-10-07 17:22:25 --> Security Class Initialized
DEBUG - 2023-10-07 17:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:22:25 --> Input Class Initialized
INFO - 2023-10-07 17:22:25 --> Language Class Initialized
INFO - 2023-10-07 17:22:25 --> Loader Class Initialized
INFO - 2023-10-07 17:22:25 --> Helper loaded: url_helper
INFO - 2023-10-07 17:22:25 --> Helper loaded: file_helper
INFO - 2023-10-07 17:22:25 --> Helper loaded: html_helper
INFO - 2023-10-07 17:22:25 --> Helper loaded: text_helper
INFO - 2023-10-07 17:22:25 --> Helper loaded: form_helper
INFO - 2023-10-07 17:22:25 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:22:25 --> Helper loaded: security_helper
INFO - 2023-10-07 17:22:25 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:22:25 --> Database Driver Class Initialized
INFO - 2023-10-07 17:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:22:25 --> Parser Class Initialized
INFO - 2023-10-07 17:22:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:22:25 --> Pagination Class Initialized
INFO - 2023-10-07 17:22:25 --> Form Validation Class Initialized
INFO - 2023-10-07 17:22:25 --> Controller Class Initialized
INFO - 2023-10-07 17:22:25 --> Model Class Initialized
DEBUG - 2023-10-07 17:22:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-10-07 17:22:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/powera7m/app.maurnaturo.com/application/controllers/Cproformainvoice.php 664
INFO - 2023-10-07 17:22:25 --> Final output sent to browser
DEBUG - 2023-10-07 17:22:25 --> Total execution time: 0.0195
ERROR - 2023-10-07 17:22:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:22:29 --> Config Class Initialized
INFO - 2023-10-07 17:22:29 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:22:29 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:22:29 --> Utf8 Class Initialized
INFO - 2023-10-07 17:22:29 --> URI Class Initialized
INFO - 2023-10-07 17:22:29 --> Router Class Initialized
INFO - 2023-10-07 17:22:29 --> Output Class Initialized
INFO - 2023-10-07 17:22:29 --> Security Class Initialized
DEBUG - 2023-10-07 17:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:22:29 --> Input Class Initialized
INFO - 2023-10-07 17:22:29 --> Language Class Initialized
INFO - 2023-10-07 17:22:29 --> Loader Class Initialized
INFO - 2023-10-07 17:22:29 --> Helper loaded: url_helper
INFO - 2023-10-07 17:22:29 --> Helper loaded: file_helper
INFO - 2023-10-07 17:22:29 --> Helper loaded: html_helper
INFO - 2023-10-07 17:22:29 --> Helper loaded: text_helper
INFO - 2023-10-07 17:22:29 --> Helper loaded: form_helper
INFO - 2023-10-07 17:22:29 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:22:29 --> Helper loaded: security_helper
INFO - 2023-10-07 17:22:29 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:22:29 --> Database Driver Class Initialized
INFO - 2023-10-07 17:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:22:29 --> Parser Class Initialized
INFO - 2023-10-07 17:22:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:22:29 --> Pagination Class Initialized
INFO - 2023-10-07 17:22:29 --> Form Validation Class Initialized
INFO - 2023-10-07 17:22:29 --> Controller Class Initialized
INFO - 2023-10-07 17:22:29 --> Model Class Initialized
DEBUG - 2023-10-07 17:22:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:22:29 --> Final output sent to browser
DEBUG - 2023-10-07 17:22:29 --> Total execution time: 0.0161
ERROR - 2023-10-07 17:22:33 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-10-07 17:22:33 --> Config Class Initialized
INFO - 2023-10-07 17:22:33 --> Hooks Class Initialized
DEBUG - 2023-10-07 17:22:33 --> UTF-8 Support Enabled
INFO - 2023-10-07 17:22:33 --> Utf8 Class Initialized
INFO - 2023-10-07 17:22:33 --> URI Class Initialized
INFO - 2023-10-07 17:22:33 --> Router Class Initialized
INFO - 2023-10-07 17:22:33 --> Output Class Initialized
INFO - 2023-10-07 17:22:33 --> Security Class Initialized
DEBUG - 2023-10-07 17:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 17:22:33 --> Input Class Initialized
INFO - 2023-10-07 17:22:33 --> Language Class Initialized
INFO - 2023-10-07 17:22:33 --> Loader Class Initialized
INFO - 2023-10-07 17:22:33 --> Helper loaded: url_helper
INFO - 2023-10-07 17:22:33 --> Helper loaded: file_helper
INFO - 2023-10-07 17:22:33 --> Helper loaded: html_helper
INFO - 2023-10-07 17:22:33 --> Helper loaded: text_helper
INFO - 2023-10-07 17:22:33 --> Helper loaded: form_helper
INFO - 2023-10-07 17:22:33 --> Helper loaded: lang_helper
INFO - 2023-10-07 17:22:33 --> Helper loaded: security_helper
INFO - 2023-10-07 17:22:33 --> Helper loaded: cookie_helper
INFO - 2023-10-07 17:22:33 --> Database Driver Class Initialized
INFO - 2023-10-07 17:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 17:22:33 --> Parser Class Initialized
INFO - 2023-10-07 17:22:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-10-07 17:22:33 --> Pagination Class Initialized
INFO - 2023-10-07 17:22:33 --> Form Validation Class Initialized
INFO - 2023-10-07 17:22:33 --> Controller Class Initialized
INFO - 2023-10-07 17:22:33 --> Model Class Initialized
DEBUG - 2023-10-07 17:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:22:33 --> Model Class Initialized
DEBUG - 2023-10-07 17:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:22:33 --> Model Class Initialized
INFO - 2023-10-07 17:22:33 --> Model Class Initialized
INFO - 2023-10-07 17:22:33 --> Model Class Initialized
INFO - 2023-10-07 17:22:33 --> Model Class Initialized
DEBUG - 2023-10-07 17:22:33 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-10-07 17:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:22:33 --> Model Class Initialized
INFO - 2023-10-07 17:22:33 --> Model Class Initialized
INFO - 2023-10-07 17:22:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-10-07 17:22:33 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-10-07 17:22:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-10-07 17:22:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-10-07 17:22:33 --> Model Class Initialized
INFO - 2023-10-07 17:22:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-10-07 17:22:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-10-07 17:22:33 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-10-07 17:22:33 --> Final output sent to browser
DEBUG - 2023-10-07 17:22:33 --> Total execution time: 0.1066
