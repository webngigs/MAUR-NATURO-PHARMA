<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-30 03:44:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-30 03:44:48 --> Config Class Initialized
INFO - 2023-11-30 03:44:48 --> Hooks Class Initialized
DEBUG - 2023-11-30 03:44:48 --> UTF-8 Support Enabled
INFO - 2023-11-30 03:44:48 --> Utf8 Class Initialized
INFO - 2023-11-30 03:44:48 --> URI Class Initialized
DEBUG - 2023-11-30 03:44:48 --> No URI present. Default controller set.
INFO - 2023-11-30 03:44:48 --> Router Class Initialized
INFO - 2023-11-30 03:44:48 --> Output Class Initialized
INFO - 2023-11-30 03:44:48 --> Security Class Initialized
DEBUG - 2023-11-30 03:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 03:44:48 --> Input Class Initialized
INFO - 2023-11-30 03:44:48 --> Language Class Initialized
INFO - 2023-11-30 03:44:48 --> Loader Class Initialized
INFO - 2023-11-30 03:44:48 --> Helper loaded: url_helper
INFO - 2023-11-30 03:44:48 --> Helper loaded: file_helper
INFO - 2023-11-30 03:44:48 --> Helper loaded: html_helper
INFO - 2023-11-30 03:44:48 --> Helper loaded: text_helper
INFO - 2023-11-30 03:44:48 --> Helper loaded: form_helper
INFO - 2023-11-30 03:44:48 --> Helper loaded: lang_helper
INFO - 2023-11-30 03:44:48 --> Helper loaded: security_helper
INFO - 2023-11-30 03:44:48 --> Helper loaded: cookie_helper
INFO - 2023-11-30 03:44:48 --> Database Driver Class Initialized
INFO - 2023-11-30 03:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 03:44:48 --> Parser Class Initialized
INFO - 2023-11-30 03:44:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-30 03:44:48 --> Pagination Class Initialized
INFO - 2023-11-30 03:44:48 --> Form Validation Class Initialized
INFO - 2023-11-30 03:44:48 --> Controller Class Initialized
INFO - 2023-11-30 03:44:48 --> Model Class Initialized
DEBUG - 2023-11-30 03:44:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-30 03:44:48 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-30 03:44:48 --> Config Class Initialized
INFO - 2023-11-30 03:44:48 --> Hooks Class Initialized
DEBUG - 2023-11-30 03:44:48 --> UTF-8 Support Enabled
INFO - 2023-11-30 03:44:48 --> Utf8 Class Initialized
INFO - 2023-11-30 03:44:48 --> URI Class Initialized
INFO - 2023-11-30 03:44:48 --> Router Class Initialized
INFO - 2023-11-30 03:44:48 --> Output Class Initialized
INFO - 2023-11-30 03:44:48 --> Security Class Initialized
DEBUG - 2023-11-30 03:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 03:44:48 --> Input Class Initialized
INFO - 2023-11-30 03:44:48 --> Language Class Initialized
INFO - 2023-11-30 03:44:48 --> Loader Class Initialized
INFO - 2023-11-30 03:44:48 --> Helper loaded: url_helper
INFO - 2023-11-30 03:44:48 --> Helper loaded: file_helper
INFO - 2023-11-30 03:44:48 --> Helper loaded: html_helper
INFO - 2023-11-30 03:44:48 --> Helper loaded: text_helper
INFO - 2023-11-30 03:44:48 --> Helper loaded: form_helper
INFO - 2023-11-30 03:44:48 --> Helper loaded: lang_helper
INFO - 2023-11-30 03:44:48 --> Helper loaded: security_helper
INFO - 2023-11-30 03:44:48 --> Helper loaded: cookie_helper
INFO - 2023-11-30 03:44:48 --> Database Driver Class Initialized
INFO - 2023-11-30 03:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 03:44:48 --> Parser Class Initialized
INFO - 2023-11-30 03:44:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-30 03:44:48 --> Pagination Class Initialized
INFO - 2023-11-30 03:44:48 --> Form Validation Class Initialized
INFO - 2023-11-30 03:44:48 --> Controller Class Initialized
INFO - 2023-11-30 03:44:48 --> Model Class Initialized
DEBUG - 2023-11-30 03:44:48 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:44:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-30 03:44:48 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:44:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-30 03:44:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-30 03:44:48 --> Model Class Initialized
INFO - 2023-11-30 03:44:48 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-30 03:44:48 --> Final output sent to browser
DEBUG - 2023-11-30 03:44:48 --> Total execution time: 0.0308
ERROR - 2023-11-30 03:45:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-30 03:45:17 --> Config Class Initialized
INFO - 2023-11-30 03:45:17 --> Hooks Class Initialized
DEBUG - 2023-11-30 03:45:17 --> UTF-8 Support Enabled
INFO - 2023-11-30 03:45:17 --> Utf8 Class Initialized
INFO - 2023-11-30 03:45:17 --> URI Class Initialized
INFO - 2023-11-30 03:45:17 --> Router Class Initialized
INFO - 2023-11-30 03:45:17 --> Output Class Initialized
INFO - 2023-11-30 03:45:17 --> Security Class Initialized
DEBUG - 2023-11-30 03:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 03:45:17 --> Input Class Initialized
INFO - 2023-11-30 03:45:17 --> Language Class Initialized
INFO - 2023-11-30 03:45:17 --> Loader Class Initialized
INFO - 2023-11-30 03:45:17 --> Helper loaded: url_helper
INFO - 2023-11-30 03:45:17 --> Helper loaded: file_helper
INFO - 2023-11-30 03:45:17 --> Helper loaded: html_helper
INFO - 2023-11-30 03:45:17 --> Helper loaded: text_helper
INFO - 2023-11-30 03:45:17 --> Helper loaded: form_helper
INFO - 2023-11-30 03:45:17 --> Helper loaded: lang_helper
INFO - 2023-11-30 03:45:17 --> Helper loaded: security_helper
INFO - 2023-11-30 03:45:17 --> Helper loaded: cookie_helper
INFO - 2023-11-30 03:45:17 --> Database Driver Class Initialized
INFO - 2023-11-30 03:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 03:45:17 --> Parser Class Initialized
INFO - 2023-11-30 03:45:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-30 03:45:17 --> Pagination Class Initialized
INFO - 2023-11-30 03:45:17 --> Form Validation Class Initialized
INFO - 2023-11-30 03:45:17 --> Controller Class Initialized
INFO - 2023-11-30 03:45:17 --> Model Class Initialized
DEBUG - 2023-11-30 03:45:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:45:17 --> Model Class Initialized
INFO - 2023-11-30 03:45:17 --> Final output sent to browser
DEBUG - 2023-11-30 03:45:17 --> Total execution time: 0.0183
ERROR - 2023-11-30 03:45:18 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-30 03:45:18 --> Config Class Initialized
INFO - 2023-11-30 03:45:18 --> Hooks Class Initialized
DEBUG - 2023-11-30 03:45:18 --> UTF-8 Support Enabled
INFO - 2023-11-30 03:45:18 --> Utf8 Class Initialized
INFO - 2023-11-30 03:45:18 --> URI Class Initialized
DEBUG - 2023-11-30 03:45:18 --> No URI present. Default controller set.
INFO - 2023-11-30 03:45:18 --> Router Class Initialized
INFO - 2023-11-30 03:45:18 --> Output Class Initialized
INFO - 2023-11-30 03:45:18 --> Security Class Initialized
DEBUG - 2023-11-30 03:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 03:45:18 --> Input Class Initialized
INFO - 2023-11-30 03:45:18 --> Language Class Initialized
INFO - 2023-11-30 03:45:18 --> Loader Class Initialized
INFO - 2023-11-30 03:45:18 --> Helper loaded: url_helper
INFO - 2023-11-30 03:45:18 --> Helper loaded: file_helper
INFO - 2023-11-30 03:45:18 --> Helper loaded: html_helper
INFO - 2023-11-30 03:45:18 --> Helper loaded: text_helper
INFO - 2023-11-30 03:45:18 --> Helper loaded: form_helper
INFO - 2023-11-30 03:45:18 --> Helper loaded: lang_helper
INFO - 2023-11-30 03:45:18 --> Helper loaded: security_helper
INFO - 2023-11-30 03:45:18 --> Helper loaded: cookie_helper
INFO - 2023-11-30 03:45:18 --> Database Driver Class Initialized
INFO - 2023-11-30 03:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 03:45:18 --> Parser Class Initialized
INFO - 2023-11-30 03:45:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-30 03:45:18 --> Pagination Class Initialized
INFO - 2023-11-30 03:45:18 --> Form Validation Class Initialized
INFO - 2023-11-30 03:45:18 --> Controller Class Initialized
INFO - 2023-11-30 03:45:18 --> Model Class Initialized
DEBUG - 2023-11-30 03:45:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:45:18 --> Model Class Initialized
DEBUG - 2023-11-30 03:45:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:45:18 --> Model Class Initialized
INFO - 2023-11-30 03:45:18 --> Model Class Initialized
INFO - 2023-11-30 03:45:18 --> Model Class Initialized
INFO - 2023-11-30 03:45:18 --> Model Class Initialized
DEBUG - 2023-11-30 03:45:18 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-30 03:45:18 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:45:18 --> Model Class Initialized
INFO - 2023-11-30 03:45:18 --> Model Class Initialized
INFO - 2023-11-30 03:45:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-30 03:45:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:45:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-30 03:45:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-30 03:45:18 --> Model Class Initialized
INFO - 2023-11-30 03:45:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-30 03:45:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-30 03:45:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-30 03:45:18 --> Final output sent to browser
DEBUG - 2023-11-30 03:45:18 --> Total execution time: 0.2194
ERROR - 2023-11-30 03:45:23 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-30 03:45:23 --> Config Class Initialized
INFO - 2023-11-30 03:45:23 --> Hooks Class Initialized
DEBUG - 2023-11-30 03:45:23 --> UTF-8 Support Enabled
INFO - 2023-11-30 03:45:23 --> Utf8 Class Initialized
INFO - 2023-11-30 03:45:23 --> URI Class Initialized
INFO - 2023-11-30 03:45:23 --> Router Class Initialized
INFO - 2023-11-30 03:45:23 --> Output Class Initialized
INFO - 2023-11-30 03:45:23 --> Security Class Initialized
DEBUG - 2023-11-30 03:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 03:45:23 --> Input Class Initialized
INFO - 2023-11-30 03:45:23 --> Language Class Initialized
INFO - 2023-11-30 03:45:23 --> Loader Class Initialized
INFO - 2023-11-30 03:45:23 --> Helper loaded: url_helper
INFO - 2023-11-30 03:45:23 --> Helper loaded: file_helper
INFO - 2023-11-30 03:45:23 --> Helper loaded: html_helper
INFO - 2023-11-30 03:45:23 --> Helper loaded: text_helper
INFO - 2023-11-30 03:45:23 --> Helper loaded: form_helper
INFO - 2023-11-30 03:45:23 --> Helper loaded: lang_helper
INFO - 2023-11-30 03:45:23 --> Helper loaded: security_helper
INFO - 2023-11-30 03:45:23 --> Helper loaded: cookie_helper
INFO - 2023-11-30 03:45:23 --> Database Driver Class Initialized
INFO - 2023-11-30 03:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 03:45:23 --> Parser Class Initialized
INFO - 2023-11-30 03:45:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-30 03:45:23 --> Pagination Class Initialized
INFO - 2023-11-30 03:45:23 --> Form Validation Class Initialized
INFO - 2023-11-30 03:45:23 --> Controller Class Initialized
INFO - 2023-11-30 03:45:23 --> Model Class Initialized
DEBUG - 2023-11-30 03:45:23 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-30 03:45:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:45:23 --> Model Class Initialized
DEBUG - 2023-11-30 03:45:23 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:45:23 --> Model Class Initialized
INFO - 2023-11-30 03:45:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-11-30 03:45:23 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:45:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-30 03:45:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-30 03:45:23 --> Model Class Initialized
INFO - 2023-11-30 03:45:23 --> Model Class Initialized
INFO - 2023-11-30 03:45:23 --> Model Class Initialized
INFO - 2023-11-30 03:45:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-30 03:45:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-30 03:45:23 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-30 03:45:23 --> Final output sent to browser
DEBUG - 2023-11-30 03:45:23 --> Total execution time: 0.1436
ERROR - 2023-11-30 03:45:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-30 03:45:24 --> Config Class Initialized
INFO - 2023-11-30 03:45:24 --> Hooks Class Initialized
DEBUG - 2023-11-30 03:45:24 --> UTF-8 Support Enabled
INFO - 2023-11-30 03:45:24 --> Utf8 Class Initialized
INFO - 2023-11-30 03:45:24 --> URI Class Initialized
INFO - 2023-11-30 03:45:24 --> Router Class Initialized
INFO - 2023-11-30 03:45:24 --> Output Class Initialized
INFO - 2023-11-30 03:45:24 --> Security Class Initialized
DEBUG - 2023-11-30 03:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 03:45:24 --> Input Class Initialized
INFO - 2023-11-30 03:45:24 --> Language Class Initialized
INFO - 2023-11-30 03:45:24 --> Loader Class Initialized
INFO - 2023-11-30 03:45:24 --> Helper loaded: url_helper
INFO - 2023-11-30 03:45:24 --> Helper loaded: file_helper
INFO - 2023-11-30 03:45:24 --> Helper loaded: html_helper
INFO - 2023-11-30 03:45:24 --> Helper loaded: text_helper
INFO - 2023-11-30 03:45:24 --> Helper loaded: form_helper
INFO - 2023-11-30 03:45:24 --> Helper loaded: lang_helper
INFO - 2023-11-30 03:45:24 --> Helper loaded: security_helper
INFO - 2023-11-30 03:45:24 --> Helper loaded: cookie_helper
INFO - 2023-11-30 03:45:24 --> Database Driver Class Initialized
INFO - 2023-11-30 03:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 03:45:24 --> Parser Class Initialized
INFO - 2023-11-30 03:45:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-30 03:45:24 --> Pagination Class Initialized
INFO - 2023-11-30 03:45:24 --> Form Validation Class Initialized
INFO - 2023-11-30 03:45:24 --> Controller Class Initialized
INFO - 2023-11-30 03:45:24 --> Model Class Initialized
DEBUG - 2023-11-30 03:45:24 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-30 03:45:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:45:24 --> Model Class Initialized
DEBUG - 2023-11-30 03:45:24 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:45:24 --> Model Class Initialized
INFO - 2023-11-30 03:45:24 --> Final output sent to browser
DEBUG - 2023-11-30 03:45:24 --> Total execution time: 0.0446
ERROR - 2023-11-30 03:45:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-30 03:45:46 --> Config Class Initialized
INFO - 2023-11-30 03:45:46 --> Hooks Class Initialized
DEBUG - 2023-11-30 03:45:46 --> UTF-8 Support Enabled
INFO - 2023-11-30 03:45:46 --> Utf8 Class Initialized
INFO - 2023-11-30 03:45:46 --> URI Class Initialized
INFO - 2023-11-30 03:45:46 --> Router Class Initialized
INFO - 2023-11-30 03:45:46 --> Output Class Initialized
INFO - 2023-11-30 03:45:46 --> Security Class Initialized
DEBUG - 2023-11-30 03:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 03:45:46 --> Input Class Initialized
INFO - 2023-11-30 03:45:46 --> Language Class Initialized
INFO - 2023-11-30 03:45:46 --> Loader Class Initialized
INFO - 2023-11-30 03:45:46 --> Helper loaded: url_helper
INFO - 2023-11-30 03:45:46 --> Helper loaded: file_helper
INFO - 2023-11-30 03:45:46 --> Helper loaded: html_helper
INFO - 2023-11-30 03:45:46 --> Helper loaded: text_helper
INFO - 2023-11-30 03:45:46 --> Helper loaded: form_helper
INFO - 2023-11-30 03:45:46 --> Helper loaded: lang_helper
INFO - 2023-11-30 03:45:46 --> Helper loaded: security_helper
INFO - 2023-11-30 03:45:46 --> Helper loaded: cookie_helper
INFO - 2023-11-30 03:45:46 --> Database Driver Class Initialized
INFO - 2023-11-30 03:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 03:45:46 --> Parser Class Initialized
INFO - 2023-11-30 03:45:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-30 03:45:46 --> Pagination Class Initialized
INFO - 2023-11-30 03:45:46 --> Form Validation Class Initialized
INFO - 2023-11-30 03:45:46 --> Controller Class Initialized
INFO - 2023-11-30 03:45:46 --> Model Class Initialized
DEBUG - 2023-11-30 03:45:46 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-30 03:45:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:45:46 --> Model Class Initialized
DEBUG - 2023-11-30 03:45:46 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:45:46 --> Model Class Initialized
INFO - 2023-11-30 03:45:46 --> Final output sent to browser
DEBUG - 2023-11-30 03:45:46 --> Total execution time: 0.0431
ERROR - 2023-11-30 03:45:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-30 03:45:49 --> Config Class Initialized
INFO - 2023-11-30 03:45:49 --> Hooks Class Initialized
DEBUG - 2023-11-30 03:45:49 --> UTF-8 Support Enabled
INFO - 2023-11-30 03:45:49 --> Utf8 Class Initialized
INFO - 2023-11-30 03:45:49 --> URI Class Initialized
INFO - 2023-11-30 03:45:49 --> Router Class Initialized
INFO - 2023-11-30 03:45:49 --> Output Class Initialized
INFO - 2023-11-30 03:45:49 --> Security Class Initialized
DEBUG - 2023-11-30 03:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 03:45:49 --> Input Class Initialized
INFO - 2023-11-30 03:45:49 --> Language Class Initialized
INFO - 2023-11-30 03:45:49 --> Loader Class Initialized
INFO - 2023-11-30 03:45:49 --> Helper loaded: url_helper
INFO - 2023-11-30 03:45:49 --> Helper loaded: file_helper
INFO - 2023-11-30 03:45:49 --> Helper loaded: html_helper
INFO - 2023-11-30 03:45:49 --> Helper loaded: text_helper
INFO - 2023-11-30 03:45:49 --> Helper loaded: form_helper
INFO - 2023-11-30 03:45:49 --> Helper loaded: lang_helper
INFO - 2023-11-30 03:45:49 --> Helper loaded: security_helper
INFO - 2023-11-30 03:45:49 --> Helper loaded: cookie_helper
INFO - 2023-11-30 03:45:49 --> Database Driver Class Initialized
INFO - 2023-11-30 03:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 03:45:49 --> Parser Class Initialized
INFO - 2023-11-30 03:45:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-30 03:45:49 --> Pagination Class Initialized
INFO - 2023-11-30 03:45:49 --> Form Validation Class Initialized
INFO - 2023-11-30 03:45:49 --> Controller Class Initialized
INFO - 2023-11-30 03:45:49 --> Model Class Initialized
DEBUG - 2023-11-30 03:45:49 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-30 03:45:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:45:49 --> Model Class Initialized
DEBUG - 2023-11-30 03:45:49 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:45:49 --> Model Class Initialized
INFO - 2023-11-30 03:45:49 --> Final output sent to browser
DEBUG - 2023-11-30 03:45:49 --> Total execution time: 0.0691
ERROR - 2023-11-30 03:46:15 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-30 03:46:15 --> Config Class Initialized
INFO - 2023-11-30 03:46:15 --> Hooks Class Initialized
DEBUG - 2023-11-30 03:46:15 --> UTF-8 Support Enabled
INFO - 2023-11-30 03:46:15 --> Utf8 Class Initialized
INFO - 2023-11-30 03:46:15 --> URI Class Initialized
DEBUG - 2023-11-30 03:46:15 --> No URI present. Default controller set.
INFO - 2023-11-30 03:46:15 --> Router Class Initialized
INFO - 2023-11-30 03:46:15 --> Output Class Initialized
INFO - 2023-11-30 03:46:15 --> Security Class Initialized
DEBUG - 2023-11-30 03:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 03:46:15 --> Input Class Initialized
INFO - 2023-11-30 03:46:15 --> Language Class Initialized
INFO - 2023-11-30 03:46:15 --> Loader Class Initialized
INFO - 2023-11-30 03:46:15 --> Helper loaded: url_helper
INFO - 2023-11-30 03:46:15 --> Helper loaded: file_helper
INFO - 2023-11-30 03:46:15 --> Helper loaded: html_helper
INFO - 2023-11-30 03:46:15 --> Helper loaded: text_helper
INFO - 2023-11-30 03:46:15 --> Helper loaded: form_helper
INFO - 2023-11-30 03:46:15 --> Helper loaded: lang_helper
INFO - 2023-11-30 03:46:15 --> Helper loaded: security_helper
INFO - 2023-11-30 03:46:15 --> Helper loaded: cookie_helper
INFO - 2023-11-30 03:46:15 --> Database Driver Class Initialized
INFO - 2023-11-30 03:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 03:46:15 --> Parser Class Initialized
INFO - 2023-11-30 03:46:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-30 03:46:15 --> Pagination Class Initialized
INFO - 2023-11-30 03:46:15 --> Form Validation Class Initialized
INFO - 2023-11-30 03:46:15 --> Controller Class Initialized
INFO - 2023-11-30 03:46:15 --> Model Class Initialized
DEBUG - 2023-11-30 03:46:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:46:15 --> Model Class Initialized
DEBUG - 2023-11-30 03:46:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:46:15 --> Model Class Initialized
INFO - 2023-11-30 03:46:15 --> Model Class Initialized
INFO - 2023-11-30 03:46:15 --> Model Class Initialized
INFO - 2023-11-30 03:46:15 --> Model Class Initialized
DEBUG - 2023-11-30 03:46:15 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-30 03:46:15 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:46:15 --> Model Class Initialized
INFO - 2023-11-30 03:46:15 --> Model Class Initialized
INFO - 2023-11-30 03:46:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-30 03:46:15 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:46:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-30 03:46:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-30 03:46:15 --> Model Class Initialized
INFO - 2023-11-30 03:46:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-30 03:46:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-30 03:46:15 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-30 03:46:15 --> Final output sent to browser
DEBUG - 2023-11-30 03:46:15 --> Total execution time: 0.2201
ERROR - 2023-11-30 03:46:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-30 03:46:17 --> Config Class Initialized
INFO - 2023-11-30 03:46:17 --> Hooks Class Initialized
DEBUG - 2023-11-30 03:46:17 --> UTF-8 Support Enabled
INFO - 2023-11-30 03:46:17 --> Utf8 Class Initialized
INFO - 2023-11-30 03:46:17 --> URI Class Initialized
INFO - 2023-11-30 03:46:17 --> Router Class Initialized
INFO - 2023-11-30 03:46:17 --> Output Class Initialized
INFO - 2023-11-30 03:46:17 --> Security Class Initialized
DEBUG - 2023-11-30 03:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 03:46:17 --> Input Class Initialized
INFO - 2023-11-30 03:46:17 --> Language Class Initialized
INFO - 2023-11-30 03:46:17 --> Loader Class Initialized
INFO - 2023-11-30 03:46:17 --> Helper loaded: url_helper
INFO - 2023-11-30 03:46:17 --> Helper loaded: file_helper
INFO - 2023-11-30 03:46:17 --> Helper loaded: html_helper
INFO - 2023-11-30 03:46:17 --> Helper loaded: text_helper
INFO - 2023-11-30 03:46:17 --> Helper loaded: form_helper
INFO - 2023-11-30 03:46:17 --> Helper loaded: lang_helper
INFO - 2023-11-30 03:46:17 --> Helper loaded: security_helper
INFO - 2023-11-30 03:46:17 --> Helper loaded: cookie_helper
INFO - 2023-11-30 03:46:17 --> Database Driver Class Initialized
INFO - 2023-11-30 03:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 03:46:17 --> Parser Class Initialized
INFO - 2023-11-30 03:46:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-30 03:46:17 --> Pagination Class Initialized
INFO - 2023-11-30 03:46:17 --> Form Validation Class Initialized
INFO - 2023-11-30 03:46:17 --> Controller Class Initialized
INFO - 2023-11-30 03:46:17 --> Model Class Initialized
DEBUG - 2023-11-30 03:46:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:46:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-30 03:46:17 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:46:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-30 03:46:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-30 03:46:17 --> Model Class Initialized
INFO - 2023-11-30 03:46:17 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-30 03:46:17 --> Final output sent to browser
DEBUG - 2023-11-30 03:46:17 --> Total execution time: 0.0328
ERROR - 2023-11-30 03:46:17 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-30 03:46:17 --> Config Class Initialized
INFO - 2023-11-30 03:46:17 --> Hooks Class Initialized
DEBUG - 2023-11-30 03:46:17 --> UTF-8 Support Enabled
INFO - 2023-11-30 03:46:17 --> Utf8 Class Initialized
INFO - 2023-11-30 03:46:17 --> URI Class Initialized
INFO - 2023-11-30 03:46:17 --> Router Class Initialized
INFO - 2023-11-30 03:46:17 --> Output Class Initialized
INFO - 2023-11-30 03:46:17 --> Security Class Initialized
DEBUG - 2023-11-30 03:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 03:46:17 --> Input Class Initialized
INFO - 2023-11-30 03:46:17 --> Language Class Initialized
INFO - 2023-11-30 03:46:17 --> Loader Class Initialized
INFO - 2023-11-30 03:46:17 --> Helper loaded: url_helper
INFO - 2023-11-30 03:46:17 --> Helper loaded: file_helper
INFO - 2023-11-30 03:46:17 --> Helper loaded: html_helper
INFO - 2023-11-30 03:46:17 --> Helper loaded: text_helper
INFO - 2023-11-30 03:46:17 --> Helper loaded: form_helper
INFO - 2023-11-30 03:46:17 --> Helper loaded: lang_helper
INFO - 2023-11-30 03:46:17 --> Helper loaded: security_helper
INFO - 2023-11-30 03:46:17 --> Helper loaded: cookie_helper
INFO - 2023-11-30 03:46:17 --> Database Driver Class Initialized
INFO - 2023-11-30 03:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 03:46:17 --> Parser Class Initialized
INFO - 2023-11-30 03:46:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-30 03:46:17 --> Pagination Class Initialized
INFO - 2023-11-30 03:46:17 --> Form Validation Class Initialized
INFO - 2023-11-30 03:46:17 --> Controller Class Initialized
INFO - 2023-11-30 03:46:17 --> Model Class Initialized
DEBUG - 2023-11-30 03:46:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:46:17 --> Model Class Initialized
DEBUG - 2023-11-30 03:46:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:46:17 --> Model Class Initialized
INFO - 2023-11-30 03:46:17 --> Model Class Initialized
INFO - 2023-11-30 03:46:17 --> Model Class Initialized
INFO - 2023-11-30 03:46:17 --> Model Class Initialized
DEBUG - 2023-11-30 03:46:17 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-30 03:46:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:46:17 --> Model Class Initialized
INFO - 2023-11-30 03:46:17 --> Model Class Initialized
INFO - 2023-11-30 03:46:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_home.php
DEBUG - 2023-11-30 03:46:18 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:46:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-30 03:46:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-30 03:46:18 --> Model Class Initialized
INFO - 2023-11-30 03:46:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-30 03:46:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-30 03:46:18 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-30 03:46:18 --> Final output sent to browser
DEBUG - 2023-11-30 03:46:18 --> Total execution time: 0.2170
ERROR - 2023-11-30 03:46:21 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-30 03:46:21 --> Config Class Initialized
INFO - 2023-11-30 03:46:21 --> Hooks Class Initialized
DEBUG - 2023-11-30 03:46:21 --> UTF-8 Support Enabled
INFO - 2023-11-30 03:46:21 --> Utf8 Class Initialized
INFO - 2023-11-30 03:46:21 --> URI Class Initialized
INFO - 2023-11-30 03:46:21 --> Router Class Initialized
INFO - 2023-11-30 03:46:21 --> Output Class Initialized
INFO - 2023-11-30 03:46:21 --> Security Class Initialized
DEBUG - 2023-11-30 03:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 03:46:21 --> Input Class Initialized
INFO - 2023-11-30 03:46:21 --> Language Class Initialized
INFO - 2023-11-30 03:46:21 --> Loader Class Initialized
INFO - 2023-11-30 03:46:21 --> Helper loaded: url_helper
INFO - 2023-11-30 03:46:21 --> Helper loaded: file_helper
INFO - 2023-11-30 03:46:21 --> Helper loaded: html_helper
INFO - 2023-11-30 03:46:21 --> Helper loaded: text_helper
INFO - 2023-11-30 03:46:21 --> Helper loaded: form_helper
INFO - 2023-11-30 03:46:21 --> Helper loaded: lang_helper
INFO - 2023-11-30 03:46:21 --> Helper loaded: security_helper
INFO - 2023-11-30 03:46:21 --> Helper loaded: cookie_helper
INFO - 2023-11-30 03:46:21 --> Database Driver Class Initialized
INFO - 2023-11-30 03:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 03:46:21 --> Parser Class Initialized
INFO - 2023-11-30 03:46:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-30 03:46:21 --> Pagination Class Initialized
INFO - 2023-11-30 03:46:21 --> Form Validation Class Initialized
INFO - 2023-11-30 03:46:21 --> Controller Class Initialized
INFO - 2023-11-30 03:46:21 --> Model Class Initialized
DEBUG - 2023-11-30 03:46:21 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-30 03:46:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:46:21 --> Model Class Initialized
DEBUG - 2023-11-30 03:46:21 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:46:21 --> Model Class Initialized
INFO - 2023-11-30 03:46:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/proformainvoice/invoice.php
DEBUG - 2023-11-30 03:46:21 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:46:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-30 03:46:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-30 03:46:21 --> Model Class Initialized
INFO - 2023-11-30 03:46:21 --> Model Class Initialized
INFO - 2023-11-30 03:46:21 --> Model Class Initialized
INFO - 2023-11-30 03:46:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_header.php
INFO - 2023-11-30 03:46:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_footer.php
INFO - 2023-11-30 03:46:21 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-30 03:46:21 --> Final output sent to browser
DEBUG - 2023-11-30 03:46:21 --> Total execution time: 0.1449
ERROR - 2023-11-30 03:46:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-30 03:46:22 --> Config Class Initialized
INFO - 2023-11-30 03:46:22 --> Hooks Class Initialized
DEBUG - 2023-11-30 03:46:22 --> UTF-8 Support Enabled
INFO - 2023-11-30 03:46:22 --> Utf8 Class Initialized
INFO - 2023-11-30 03:46:22 --> URI Class Initialized
INFO - 2023-11-30 03:46:22 --> Router Class Initialized
INFO - 2023-11-30 03:46:22 --> Output Class Initialized
INFO - 2023-11-30 03:46:22 --> Security Class Initialized
DEBUG - 2023-11-30 03:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 03:46:22 --> Input Class Initialized
INFO - 2023-11-30 03:46:22 --> Language Class Initialized
INFO - 2023-11-30 03:46:22 --> Loader Class Initialized
INFO - 2023-11-30 03:46:22 --> Helper loaded: url_helper
INFO - 2023-11-30 03:46:22 --> Helper loaded: file_helper
INFO - 2023-11-30 03:46:22 --> Helper loaded: html_helper
INFO - 2023-11-30 03:46:22 --> Helper loaded: text_helper
INFO - 2023-11-30 03:46:22 --> Helper loaded: form_helper
INFO - 2023-11-30 03:46:22 --> Helper loaded: lang_helper
INFO - 2023-11-30 03:46:22 --> Helper loaded: security_helper
INFO - 2023-11-30 03:46:22 --> Helper loaded: cookie_helper
INFO - 2023-11-30 03:46:22 --> Database Driver Class Initialized
INFO - 2023-11-30 03:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 03:46:22 --> Parser Class Initialized
INFO - 2023-11-30 03:46:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-30 03:46:22 --> Pagination Class Initialized
INFO - 2023-11-30 03:46:22 --> Form Validation Class Initialized
INFO - 2023-11-30 03:46:22 --> Controller Class Initialized
INFO - 2023-11-30 03:46:22 --> Model Class Initialized
DEBUG - 2023-11-30 03:46:22 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-30 03:46:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:46:22 --> Model Class Initialized
DEBUG - 2023-11-30 03:46:22 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:46:22 --> Model Class Initialized
INFO - 2023-11-30 03:46:22 --> Final output sent to browser
DEBUG - 2023-11-30 03:46:22 --> Total execution time: 0.0480
ERROR - 2023-11-30 03:46:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-30 03:46:29 --> Config Class Initialized
INFO - 2023-11-30 03:46:29 --> Hooks Class Initialized
DEBUG - 2023-11-30 03:46:29 --> UTF-8 Support Enabled
INFO - 2023-11-30 03:46:29 --> Utf8 Class Initialized
INFO - 2023-11-30 03:46:29 --> URI Class Initialized
INFO - 2023-11-30 03:46:29 --> Router Class Initialized
INFO - 2023-11-30 03:46:29 --> Output Class Initialized
INFO - 2023-11-30 03:46:29 --> Security Class Initialized
DEBUG - 2023-11-30 03:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 03:46:29 --> Input Class Initialized
INFO - 2023-11-30 03:46:29 --> Language Class Initialized
INFO - 2023-11-30 03:46:29 --> Loader Class Initialized
INFO - 2023-11-30 03:46:29 --> Helper loaded: url_helper
INFO - 2023-11-30 03:46:29 --> Helper loaded: file_helper
INFO - 2023-11-30 03:46:29 --> Helper loaded: html_helper
INFO - 2023-11-30 03:46:29 --> Helper loaded: text_helper
INFO - 2023-11-30 03:46:29 --> Helper loaded: form_helper
INFO - 2023-11-30 03:46:29 --> Helper loaded: lang_helper
INFO - 2023-11-30 03:46:29 --> Helper loaded: security_helper
INFO - 2023-11-30 03:46:29 --> Helper loaded: cookie_helper
INFO - 2023-11-30 03:46:29 --> Database Driver Class Initialized
INFO - 2023-11-30 03:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 03:46:29 --> Parser Class Initialized
INFO - 2023-11-30 03:46:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-30 03:46:29 --> Pagination Class Initialized
INFO - 2023-11-30 03:46:29 --> Form Validation Class Initialized
INFO - 2023-11-30 03:46:29 --> Controller Class Initialized
INFO - 2023-11-30 03:46:29 --> Model Class Initialized
DEBUG - 2023-11-30 03:46:29 --> Auth class already loaded. Second attempt ignored.
DEBUG - 2023-11-30 03:46:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:46:29 --> Model Class Initialized
DEBUG - 2023-11-30 03:46:29 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 03:46:29 --> Model Class Initialized
INFO - 2023-11-30 03:46:30 --> Final output sent to browser
DEBUG - 2023-11-30 03:46:30 --> Total execution time: 0.0212
ERROR - 2023-11-30 04:54:22 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-30 04:54:22 --> Config Class Initialized
INFO - 2023-11-30 04:54:22 --> Hooks Class Initialized
DEBUG - 2023-11-30 04:54:22 --> UTF-8 Support Enabled
INFO - 2023-11-30 04:54:22 --> Utf8 Class Initialized
INFO - 2023-11-30 04:54:22 --> URI Class Initialized
INFO - 2023-11-30 04:54:22 --> Router Class Initialized
INFO - 2023-11-30 04:54:22 --> Output Class Initialized
INFO - 2023-11-30 04:54:22 --> Security Class Initialized
DEBUG - 2023-11-30 04:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 04:54:22 --> Input Class Initialized
INFO - 2023-11-30 04:54:22 --> Language Class Initialized
ERROR - 2023-11-30 04:54:22 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2023-11-30 13:03:46 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-30 13:03:46 --> Config Class Initialized
INFO - 2023-11-30 13:03:46 --> Hooks Class Initialized
DEBUG - 2023-11-30 13:03:46 --> UTF-8 Support Enabled
INFO - 2023-11-30 13:03:46 --> Utf8 Class Initialized
INFO - 2023-11-30 13:03:46 --> URI Class Initialized
INFO - 2023-11-30 13:03:46 --> Router Class Initialized
INFO - 2023-11-30 13:03:46 --> Output Class Initialized
INFO - 2023-11-30 13:03:46 --> Security Class Initialized
DEBUG - 2023-11-30 13:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 13:03:46 --> Input Class Initialized
INFO - 2023-11-30 13:03:46 --> Language Class Initialized
ERROR - 2023-11-30 13:03:46 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-11-30 13:03:47 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-30 13:03:47 --> Config Class Initialized
INFO - 2023-11-30 13:03:47 --> Hooks Class Initialized
DEBUG - 2023-11-30 13:03:47 --> UTF-8 Support Enabled
INFO - 2023-11-30 13:03:47 --> Utf8 Class Initialized
INFO - 2023-11-30 13:03:47 --> URI Class Initialized
DEBUG - 2023-11-30 13:03:47 --> No URI present. Default controller set.
INFO - 2023-11-30 13:03:47 --> Router Class Initialized
INFO - 2023-11-30 13:03:47 --> Output Class Initialized
INFO - 2023-11-30 13:03:47 --> Security Class Initialized
DEBUG - 2023-11-30 13:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 13:03:47 --> Input Class Initialized
INFO - 2023-11-30 13:03:47 --> Language Class Initialized
INFO - 2023-11-30 13:03:47 --> Loader Class Initialized
INFO - 2023-11-30 13:03:47 --> Helper loaded: url_helper
INFO - 2023-11-30 13:03:47 --> Helper loaded: file_helper
INFO - 2023-11-30 13:03:47 --> Helper loaded: html_helper
INFO - 2023-11-30 13:03:47 --> Helper loaded: text_helper
INFO - 2023-11-30 13:03:47 --> Helper loaded: form_helper
INFO - 2023-11-30 13:03:47 --> Helper loaded: lang_helper
INFO - 2023-11-30 13:03:47 --> Helper loaded: security_helper
INFO - 2023-11-30 13:03:47 --> Helper loaded: cookie_helper
INFO - 2023-11-30 13:03:47 --> Database Driver Class Initialized
INFO - 2023-11-30 13:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 13:03:47 --> Parser Class Initialized
INFO - 2023-11-30 13:03:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-30 13:03:47 --> Pagination Class Initialized
INFO - 2023-11-30 13:03:47 --> Form Validation Class Initialized
INFO - 2023-11-30 13:03:47 --> Controller Class Initialized
INFO - 2023-11-30 13:03:47 --> Model Class Initialized
DEBUG - 2023-11-30 13:03:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-30 13:03:49 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-30 13:03:49 --> Config Class Initialized
INFO - 2023-11-30 13:03:49 --> Hooks Class Initialized
DEBUG - 2023-11-30 13:03:49 --> UTF-8 Support Enabled
INFO - 2023-11-30 13:03:49 --> Utf8 Class Initialized
INFO - 2023-11-30 13:03:49 --> URI Class Initialized
INFO - 2023-11-30 13:03:49 --> Router Class Initialized
INFO - 2023-11-30 13:03:49 --> Output Class Initialized
INFO - 2023-11-30 13:03:49 --> Security Class Initialized
DEBUG - 2023-11-30 13:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 13:03:49 --> Input Class Initialized
INFO - 2023-11-30 13:03:49 --> Language Class Initialized
ERROR - 2023-11-30 13:03:49 --> 404 Page Not Found: Wp-cronphp/index
ERROR - 2023-11-30 15:51:24 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-30 15:51:24 --> Config Class Initialized
INFO - 2023-11-30 15:51:24 --> Hooks Class Initialized
DEBUG - 2023-11-30 15:51:24 --> UTF-8 Support Enabled
INFO - 2023-11-30 15:51:24 --> Utf8 Class Initialized
INFO - 2023-11-30 15:51:24 --> URI Class Initialized
DEBUG - 2023-11-30 15:51:24 --> No URI present. Default controller set.
INFO - 2023-11-30 15:51:24 --> Router Class Initialized
INFO - 2023-11-30 15:51:24 --> Output Class Initialized
INFO - 2023-11-30 15:51:24 --> Security Class Initialized
DEBUG - 2023-11-30 15:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 15:51:24 --> Input Class Initialized
INFO - 2023-11-30 15:51:24 --> Language Class Initialized
INFO - 2023-11-30 15:51:24 --> Loader Class Initialized
INFO - 2023-11-30 15:51:24 --> Helper loaded: url_helper
INFO - 2023-11-30 15:51:24 --> Helper loaded: file_helper
INFO - 2023-11-30 15:51:24 --> Helper loaded: html_helper
INFO - 2023-11-30 15:51:24 --> Helper loaded: text_helper
INFO - 2023-11-30 15:51:24 --> Helper loaded: form_helper
INFO - 2023-11-30 15:51:24 --> Helper loaded: lang_helper
INFO - 2023-11-30 15:51:24 --> Helper loaded: security_helper
INFO - 2023-11-30 15:51:24 --> Helper loaded: cookie_helper
INFO - 2023-11-30 15:51:25 --> Database Driver Class Initialized
INFO - 2023-11-30 15:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 15:51:25 --> Parser Class Initialized
INFO - 2023-11-30 15:51:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-30 15:51:25 --> Pagination Class Initialized
INFO - 2023-11-30 15:51:25 --> Form Validation Class Initialized
INFO - 2023-11-30 15:51:25 --> Controller Class Initialized
INFO - 2023-11-30 15:51:25 --> Model Class Initialized
DEBUG - 2023-11-30 15:51:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-30 15:51:25 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-30 15:51:25 --> Config Class Initialized
INFO - 2023-11-30 15:51:25 --> Hooks Class Initialized
DEBUG - 2023-11-30 15:51:25 --> UTF-8 Support Enabled
INFO - 2023-11-30 15:51:25 --> Utf8 Class Initialized
INFO - 2023-11-30 15:51:25 --> URI Class Initialized
INFO - 2023-11-30 15:51:25 --> Router Class Initialized
INFO - 2023-11-30 15:51:25 --> Output Class Initialized
INFO - 2023-11-30 15:51:25 --> Security Class Initialized
DEBUG - 2023-11-30 15:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 15:51:25 --> Input Class Initialized
INFO - 2023-11-30 15:51:25 --> Language Class Initialized
INFO - 2023-11-30 15:51:25 --> Loader Class Initialized
INFO - 2023-11-30 15:51:25 --> Helper loaded: url_helper
INFO - 2023-11-30 15:51:25 --> Helper loaded: file_helper
INFO - 2023-11-30 15:51:25 --> Helper loaded: html_helper
INFO - 2023-11-30 15:51:25 --> Helper loaded: text_helper
INFO - 2023-11-30 15:51:25 --> Helper loaded: form_helper
INFO - 2023-11-30 15:51:25 --> Helper loaded: lang_helper
INFO - 2023-11-30 15:51:25 --> Helper loaded: security_helper
INFO - 2023-11-30 15:51:25 --> Helper loaded: cookie_helper
INFO - 2023-11-30 15:51:25 --> Database Driver Class Initialized
INFO - 2023-11-30 15:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 15:51:25 --> Parser Class Initialized
INFO - 2023-11-30 15:51:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-30 15:51:25 --> Pagination Class Initialized
INFO - 2023-11-30 15:51:25 --> Form Validation Class Initialized
INFO - 2023-11-30 15:51:25 --> Controller Class Initialized
INFO - 2023-11-30 15:51:25 --> Model Class Initialized
DEBUG - 2023-11-30 15:51:25 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 15:51:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-30 15:51:25 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-30 15:51:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-30 15:51:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-30 15:51:25 --> Model Class Initialized
INFO - 2023-11-30 15:51:25 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-30 15:51:25 --> Final output sent to browser
DEBUG - 2023-11-30 15:51:25 --> Total execution time: 0.0345
ERROR - 2023-11-30 16:29:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-30 16:29:04 --> Config Class Initialized
INFO - 2023-11-30 16:29:04 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:29:04 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:29:04 --> Utf8 Class Initialized
INFO - 2023-11-30 16:29:04 --> URI Class Initialized
DEBUG - 2023-11-30 16:29:04 --> No URI present. Default controller set.
INFO - 2023-11-30 16:29:04 --> Router Class Initialized
INFO - 2023-11-30 16:29:04 --> Output Class Initialized
INFO - 2023-11-30 16:29:04 --> Security Class Initialized
DEBUG - 2023-11-30 16:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:29:04 --> Input Class Initialized
INFO - 2023-11-30 16:29:04 --> Language Class Initialized
INFO - 2023-11-30 16:29:04 --> Loader Class Initialized
INFO - 2023-11-30 16:29:04 --> Helper loaded: url_helper
INFO - 2023-11-30 16:29:04 --> Helper loaded: file_helper
INFO - 2023-11-30 16:29:04 --> Helper loaded: html_helper
INFO - 2023-11-30 16:29:04 --> Helper loaded: text_helper
INFO - 2023-11-30 16:29:04 --> Helper loaded: form_helper
INFO - 2023-11-30 16:29:04 --> Helper loaded: lang_helper
INFO - 2023-11-30 16:29:04 --> Helper loaded: security_helper
INFO - 2023-11-30 16:29:04 --> Helper loaded: cookie_helper
INFO - 2023-11-30 16:29:04 --> Database Driver Class Initialized
INFO - 2023-11-30 16:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:29:04 --> Parser Class Initialized
INFO - 2023-11-30 16:29:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-30 16:29:04 --> Pagination Class Initialized
INFO - 2023-11-30 16:29:04 --> Form Validation Class Initialized
INFO - 2023-11-30 16:29:04 --> Controller Class Initialized
INFO - 2023-11-30 16:29:04 --> Model Class Initialized
DEBUG - 2023-11-30 16:29:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-11-30 16:29:04 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-30 16:29:04 --> Config Class Initialized
INFO - 2023-11-30 16:29:04 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:29:04 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:29:04 --> Utf8 Class Initialized
INFO - 2023-11-30 16:29:04 --> URI Class Initialized
INFO - 2023-11-30 16:29:04 --> Router Class Initialized
INFO - 2023-11-30 16:29:04 --> Output Class Initialized
INFO - 2023-11-30 16:29:04 --> Security Class Initialized
DEBUG - 2023-11-30 16:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:29:04 --> Input Class Initialized
INFO - 2023-11-30 16:29:04 --> Language Class Initialized
INFO - 2023-11-30 16:29:04 --> Loader Class Initialized
INFO - 2023-11-30 16:29:04 --> Helper loaded: url_helper
INFO - 2023-11-30 16:29:04 --> Helper loaded: file_helper
INFO - 2023-11-30 16:29:04 --> Helper loaded: html_helper
INFO - 2023-11-30 16:29:04 --> Helper loaded: text_helper
INFO - 2023-11-30 16:29:04 --> Helper loaded: form_helper
INFO - 2023-11-30 16:29:04 --> Helper loaded: lang_helper
INFO - 2023-11-30 16:29:04 --> Helper loaded: security_helper
INFO - 2023-11-30 16:29:04 --> Helper loaded: cookie_helper
INFO - 2023-11-30 16:29:04 --> Database Driver Class Initialized
INFO - 2023-11-30 16:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:29:04 --> Parser Class Initialized
INFO - 2023-11-30 16:29:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2023-11-30 16:29:04 --> Pagination Class Initialized
INFO - 2023-11-30 16:29:04 --> Form Validation Class Initialized
INFO - 2023-11-30 16:29:04 --> Controller Class Initialized
INFO - 2023-11-30 16:29:04 --> Model Class Initialized
DEBUG - 2023-11-30 16:29:04 --> Session class already loaded. Second attempt ignored.
INFO - 2023-11-30 16:29:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/user/admin_login_form.php
DEBUG - 2023-11-30 16:29:04 --> Parser class already loaded. Second attempt ignored.
INFO - 2023-11-30 16:29:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/top_menu.php
INFO - 2023-11-30 16:29:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/include/admin_loggedin_info.php
INFO - 2023-11-30 16:29:04 --> Model Class Initialized
INFO - 2023-11-30 16:29:04 --> File loaded: /home/powera7m/app.maurnaturo.com/application/views/admin_html_template.php
INFO - 2023-11-30 16:29:04 --> Final output sent to browser
DEBUG - 2023-11-30 16:29:04 --> Total execution time: 0.0366
ERROR - 2023-11-30 16:39:29 --> $config['composer_autoload'] is set to TRUE but /home/powera7m/app.maurnaturo.com/application/vendor/autoload.php was not found.
INFO - 2023-11-30 16:39:29 --> Config Class Initialized
INFO - 2023-11-30 16:39:29 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:39:29 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:39:29 --> Utf8 Class Initialized
INFO - 2023-11-30 16:39:29 --> URI Class Initialized
INFO - 2023-11-30 16:39:29 --> Router Class Initialized
INFO - 2023-11-30 16:39:29 --> Output Class Initialized
INFO - 2023-11-30 16:39:29 --> Security Class Initialized
DEBUG - 2023-11-30 16:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:39:29 --> Input Class Initialized
INFO - 2023-11-30 16:39:29 --> Language Class Initialized
ERROR - 2023-11-30 16:39:29 --> 404 Page Not Found: Well-known/assetlinks.json
